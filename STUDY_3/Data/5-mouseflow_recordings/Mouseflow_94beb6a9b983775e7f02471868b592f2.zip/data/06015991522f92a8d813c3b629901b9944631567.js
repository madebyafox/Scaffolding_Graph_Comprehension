var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06015991522f92a8d813c3b629901b9944631567"] = {
  "startTime": "2018-06-01T18:18:59.684057Z",
  "websitePageUrl": "/16",
  "visitTime": 67329,
  "engagementTime": 54495,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "94beb6a9b983775e7f02471868b592f2",
    "created": "2018-06-01T18:18:59.6475924+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=41Y1H",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0c1aa9c5c1169a5bfbfe620e100a9809",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/94beb6a9b983775e7f02471868b592f2/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 282,
      "e": 282,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 282,
      "e": 282,
      "ty": 2,
      "x": 831,
      "y": 599
    },
    {
      "t": 282,
      "e": 282,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 283,
      "e": 283,
      "ty": 41,
      "x": 3172,
      "y": 33018,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 828,
      "y": 603
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 827,
      "y": 603
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 55755,
      "y": 32471,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 814,
      "y": 605
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 773,
      "y": 606
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 3151,
      "y": 33442,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 707,
      "y": 617
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 652,
      "y": 633
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 614,
      "y": 642
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 58105,
      "y": 35121,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 584,
      "y": 646
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 533,
      "y": 640
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 43604,
      "y": 34069,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 467,
      "y": 608
    },
    {
      "t": 1816,
      "e": 1816,
      "ty": 6,
      "x": 463,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 443,
      "y": 582
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 442,
      "y": 580
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 38770,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 441,
      "y": 580
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 38658,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2450,
      "e": 2450,
      "ty": 3,
      "x": 441,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2452,
      "e": 2452,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2594,
      "e": 2594,
      "ty": 4,
      "x": 38658,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2595,
      "e": 2595,
      "ty": 5,
      "x": 441,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9703,
      "e": 7595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9942,
      "e": 7834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10001,
      "e": 7893,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10534,
      "e": 8426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10877,
      "e": 8769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 12606,
      "e": 10498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12814,
      "e": 10706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12814,
      "e": 10706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12934,
      "e": 10826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 13014,
      "e": 10906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 13134,
      "e": 11026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13134,
      "e": 11026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13197,
      "e": 11089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 13301,
      "e": 11193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13302,
      "e": 11194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13382,
      "e": 11274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 13598,
      "e": 11490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13599,
      "e": 11491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13710,
      "e": 11602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 13782,
      "e": 11674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13783,
      "e": 11675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13869,
      "e": 11761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14406,
      "e": 12298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14407,
      "e": 12299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14462,
      "e": 12354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 14463,
      "e": 12355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14464,
      "e": 12356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14573,
      "e": 12465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14574,
      "e": 12466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14574,
      "e": 12466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14637,
      "e": 12529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14726,
      "e": 12618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14727,
      "e": 12619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14821,
      "e": 12713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15470,
      "e": 13362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15471,
      "e": 13363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15582,
      "e": 13474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 16445,
      "e": 14337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16565,
      "e": 14457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for "
    },
    {
      "t": 16710,
      "e": 14602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16710,
      "e": 14602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16813,
      "e": 14705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 16926,
      "e": 14818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16927,
      "e": 14819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17038,
      "e": 14930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17198,
      "e": 15090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17199,
      "e": 15091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17206,
      "e": 15098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 17206,
      "e": 15098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17245,
      "e": 15137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||iu"
    },
    {
      "t": 17253,
      "e": 15145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17366,
      "e": 15258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17366,
      "e": 15258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17453,
      "e": 15345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17510,
      "e": 15402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17511,
      "e": 15403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17565,
      "e": 15457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17565,
      "e": 15457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17605,
      "e": 15497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 17685,
      "e": 15577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17686,
      "e": 15578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17697,
      "e": 15589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17803,
      "e": 15695,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiunts "
    },
    {
      "t": 17813,
      "e": 15705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17821,
      "e": 15713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17821,
      "e": 15713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17885,
      "e": 15777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17885,
      "e": 15777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17917,
      "e": 15809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tg"
    },
    {
      "t": 17925,
      "e": 15817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18126,
      "e": 16018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18181,
      "e": 16073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiunts t"
    },
    {
      "t": 18293,
      "e": 16185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18334,
      "e": 16226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiunts "
    },
    {
      "t": 18558,
      "e": 16450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18646,
      "e": 16538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiunts"
    },
    {
      "t": 18741,
      "e": 16633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18806,
      "e": 16698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiunt"
    },
    {
      "t": 18910,
      "e": 16802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18965,
      "e": 16857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiun"
    },
    {
      "t": 19070,
      "e": 16962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19109,
      "e": 17001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poiu"
    },
    {
      "t": 19462,
      "e": 17354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19541,
      "e": 17433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for poi"
    },
    {
      "t": 19654,
      "e": 17546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19654,
      "e": 17546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19709,
      "e": 17601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19743,
      "e": 17635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19745,
      "e": 17637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19829,
      "e": 17721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19973,
      "e": 17865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19975,
      "e": 17867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20000,
      "e": 17892,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20093,
      "e": 17985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20125,
      "e": 18017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20125,
      "e": 18017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20238,
      "e": 18130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20245,
      "e": 18137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20246,
      "e": 18138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20310,
      "e": 18202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20311,
      "e": 18203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20325,
      "e": 18217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 20421,
      "e": 18313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20461,
      "e": 18353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20461,
      "e": 18353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20598,
      "e": 18490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20598,
      "e": 18490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20669,
      "e": 18561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 20726,
      "e": 18618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20789,
      "e": 18681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20790,
      "e": 18682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20901,
      "e": 18793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20933,
      "e": 18825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20933,
      "e": 18825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21045,
      "e": 18937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21047,
      "e": 18939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21077,
      "e": 18969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 21157,
      "e": 19049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21206,
      "e": 19098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21206,
      "e": 19098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21318,
      "e": 19210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21319,
      "e": 19211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21365,
      "e": 19257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 21421,
      "e": 19313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21542,
      "e": 19434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21543,
      "e": 19435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21605,
      "e": 19497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21733,
      "e": 19625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21734,
      "e": 19626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21829,
      "e": 19721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21990,
      "e": 19882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21990,
      "e": 19882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22085,
      "e": 19977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23206,
      "e": 21098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23207,
      "e": 21099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23317,
      "e": 21209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23365,
      "e": 21257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23366,
      "e": 21258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23485,
      "e": 21377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23566,
      "e": 21458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 23567,
      "e": 21459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23637,
      "e": 21529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 23750,
      "e": 21642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 23750,
      "e": 21642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23837,
      "e": 21729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 24037,
      "e": 21929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24038,
      "e": 21930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24126,
      "e": 22018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 24334,
      "e": 22226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 24335,
      "e": 22227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24453,
      "e": 22345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25068,
      "e": 22960,
      "ty": 7,
      "x": 427,
      "y": 617,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25100,
      "e": 22992,
      "ty": 2,
      "x": 422,
      "y": 639
    },
    {
      "t": 25118,
      "e": 23010,
      "ty": 6,
      "x": 418,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 25200,
      "e": 23092,
      "ty": 2,
      "x": 416,
      "y": 670
    },
    {
      "t": 25250,
      "e": 23142,
      "ty": 41,
      "x": 40088,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 25251,
      "e": 23143,
      "ty": 7,
      "x": 412,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 25300,
      "e": 23192,
      "ty": 2,
      "x": 411,
      "y": 693
    },
    {
      "t": 25400,
      "e": 23292,
      "ty": 2,
      "x": 411,
      "y": 691
    },
    {
      "t": 25402,
      "e": 23294,
      "ty": 6,
      "x": 414,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 25500,
      "e": 23392,
      "ty": 2,
      "x": 417,
      "y": 672
    },
    {
      "t": 25500,
      "e": 23392,
      "ty": 41,
      "x": 42819,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 25554,
      "e": 23446,
      "ty": 3,
      "x": 418,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 25554,
      "e": 23446,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look for points that start at 12pm"
    },
    {
      "t": 25555,
      "e": 23447,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25555,
      "e": 23447,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 25600,
      "e": 23492,
      "ty": 2,
      "x": 418,
      "y": 668
    },
    {
      "t": 25657,
      "e": 23549,
      "ty": 4,
      "x": 43365,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 25668,
      "e": 23560,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 25670,
      "e": 23562,
      "ty": 5,
      "x": 418,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 25676,
      "e": 23568,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 25751,
      "e": 23643,
      "ty": 41,
      "x": 14119,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 26001,
      "e": 23893,
      "ty": 2,
      "x": 354,
      "y": 715
    },
    {
      "t": 26001,
      "e": 23893,
      "ty": 41,
      "x": 11915,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 26100,
      "e": 23992,
      "ty": 2,
      "x": 230,
      "y": 806
    },
    {
      "t": 26251,
      "e": 24143,
      "ty": 41,
      "x": 7645,
      "y": 44207,
      "ta": "html > body"
    },
    {
      "t": 26400,
      "e": 24292,
      "ty": 2,
      "x": 229,
      "y": 792
    },
    {
      "t": 26500,
      "e": 24392,
      "ty": 2,
      "x": 245,
      "y": 767
    },
    {
      "t": 26500,
      "e": 24392,
      "ty": 41,
      "x": 8161,
      "y": 42046,
      "ta": "html > body"
    },
    {
      "t": 26600,
      "e": 24492,
      "ty": 2,
      "x": 277,
      "y": 746
    },
    {
      "t": 26673,
      "e": 24565,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 26700,
      "e": 24592,
      "ty": 2,
      "x": 289,
      "y": 737
    },
    {
      "t": 26750,
      "e": 24642,
      "ty": 41,
      "x": 11020,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 26800,
      "e": 24692,
      "ty": 2,
      "x": 385,
      "y": 707
    },
    {
      "t": 26900,
      "e": 24792,
      "ty": 2,
      "x": 441,
      "y": 675
    },
    {
      "t": 27000,
      "e": 24892,
      "ty": 2,
      "x": 448,
      "y": 665
    },
    {
      "t": 27000,
      "e": 24892,
      "ty": 41,
      "x": 15152,
      "y": 36396,
      "ta": "html > body"
    },
    {
      "t": 27201,
      "e": 25093,
      "ty": 2,
      "x": 508,
      "y": 662
    },
    {
      "t": 27250,
      "e": 25142,
      "ty": 41,
      "x": 21041,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 27301,
      "e": 25193,
      "ty": 2,
      "x": 796,
      "y": 619
    },
    {
      "t": 27336,
      "e": 25228,
      "ty": 6,
      "x": 889,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27400,
      "e": 25292,
      "ty": 2,
      "x": 901,
      "y": 556
    },
    {
      "t": 27403,
      "e": 25295,
      "ty": 7,
      "x": 908,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27500,
      "e": 25392,
      "ty": 2,
      "x": 913,
      "y": 549
    },
    {
      "t": 27501,
      "e": 25393,
      "ty": 41,
      "x": 22710,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 27571,
      "e": 25463,
      "ty": 6,
      "x": 914,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27600,
      "e": 25492,
      "ty": 2,
      "x": 914,
      "y": 557
    },
    {
      "t": 27682,
      "e": 25574,
      "ty": 3,
      "x": 914,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27682,
      "e": 25574,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27701,
      "e": 25593,
      "ty": 2,
      "x": 914,
      "y": 559
    },
    {
      "t": 27751,
      "e": 25643,
      "ty": 41,
      "x": 22926,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27778,
      "e": 25670,
      "ty": 4,
      "x": 22926,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27778,
      "e": 25670,
      "ty": 5,
      "x": 914,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29398,
      "e": 27290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 29399,
      "e": 27291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29501,
      "e": 27393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 30000,
      "e": 27892,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30294,
      "e": 28186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 30365,
      "e": 28257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 30662,
      "e": 28554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 30662,
      "e": 28554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30790,
      "e": 28682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 30801,
      "e": 28693,
      "ty": 2,
      "x": 913,
      "y": 560
    },
    {
      "t": 30806,
      "e": 28698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 30806,
      "e": 28698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30900,
      "e": 28792,
      "ty": 2,
      "x": 911,
      "y": 567
    },
    {
      "t": 30909,
      "e": 28801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 30939,
      "e": 28831,
      "ty": 7,
      "x": 910,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31001,
      "e": 28893,
      "ty": 2,
      "x": 908,
      "y": 599
    },
    {
      "t": 31001,
      "e": 28893,
      "ty": 41,
      "x": 21628,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 31101,
      "e": 28993,
      "ty": 2,
      "x": 899,
      "y": 635
    },
    {
      "t": 31201,
      "e": 29093,
      "ty": 2,
      "x": 897,
      "y": 644
    },
    {
      "t": 31209,
      "e": 29101,
      "ty": 6,
      "x": 896,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31250,
      "e": 29142,
      "ty": 41,
      "x": 18600,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31301,
      "e": 29193,
      "ty": 2,
      "x": 892,
      "y": 664
    },
    {
      "t": 31354,
      "e": 29246,
      "ty": 3,
      "x": 892,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31355,
      "e": 29247,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 31356,
      "e": 29248,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31356,
      "e": 29248,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31401,
      "e": 29293,
      "ty": 2,
      "x": 892,
      "y": 665
    },
    {
      "t": 31489,
      "e": 29381,
      "ty": 4,
      "x": 18168,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31489,
      "e": 29381,
      "ty": 5,
      "x": 892,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31501,
      "e": 29393,
      "ty": 41,
      "x": 18168,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31900,
      "e": 29792,
      "ty": 2,
      "x": 875,
      "y": 666
    },
    {
      "t": 32000,
      "e": 29892,
      "ty": 2,
      "x": 858,
      "y": 666
    },
    {
      "t": 32000,
      "e": 29892,
      "ty": 41,
      "x": 10814,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32510,
      "e": 30402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 32670,
      "e": 30562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 32671,
      "e": 30563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32749,
      "e": 30641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 32773,
      "e": 30665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 32773,
      "e": 30665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32878,
      "e": 30770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 32990,
      "e": 30882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 32990,
      "e": 30882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33086,
      "e": 30978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 33094,
      "e": 30986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 33507,
      "e": 31399,
      "ty": 7,
      "x": 861,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33600,
      "e": 31492,
      "ty": 2,
      "x": 900,
      "y": 672
    },
    {
      "t": 33700,
      "e": 31592,
      "ty": 2,
      "x": 913,
      "y": 675
    },
    {
      "t": 33708,
      "e": 31600,
      "ty": 6,
      "x": 913,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33751,
      "e": 31643,
      "ty": 41,
      "x": 9832,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33800,
      "e": 31692,
      "ty": 2,
      "x": 916,
      "y": 694
    },
    {
      "t": 33954,
      "e": 31846,
      "ty": 3,
      "x": 916,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33955,
      "e": 31847,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 33955,
      "e": 31847,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33956,
      "e": 31848,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34000,
      "e": 31892,
      "ty": 41,
      "x": 10348,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34008,
      "e": 31900,
      "ty": 4,
      "x": 10348,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34010,
      "e": 31902,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34010,
      "e": 31902,
      "ty": 5,
      "x": 916,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34010,
      "e": 31902,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 34201,
      "e": 32093,
      "ty": 2,
      "x": 882,
      "y": 715
    },
    {
      "t": 34251,
      "e": 32143,
      "ty": 41,
      "x": 28480,
      "y": 40218,
      "ta": "html > body"
    },
    {
      "t": 34301,
      "e": 32193,
      "ty": 2,
      "x": 779,
      "y": 739
    },
    {
      "t": 34404,
      "e": 32296,
      "ty": 2,
      "x": 704,
      "y": 733
    },
    {
      "t": 34504,
      "e": 32396,
      "ty": 2,
      "x": 703,
      "y": 733
    },
    {
      "t": 34505,
      "e": 32397,
      "ty": 41,
      "x": 23934,
      "y": 40163,
      "ta": "html > body"
    },
    {
      "t": 35030,
      "e": 32922,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 35704,
      "e": 33596,
      "ty": 2,
      "x": 711,
      "y": 687
    },
    {
      "t": 35755,
      "e": 33647,
      "ty": 41,
      "x": 26241,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 35805,
      "e": 33697,
      "ty": 2,
      "x": 795,
      "y": 538
    },
    {
      "t": 35904,
      "e": 33796,
      "ty": 2,
      "x": 818,
      "y": 486
    },
    {
      "t": 35980,
      "e": 33872,
      "ty": 6,
      "x": 829,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 36005,
      "e": 33897,
      "ty": 2,
      "x": 832,
      "y": 439
    },
    {
      "t": 36005,
      "e": 33897,
      "ty": 41,
      "x": 28120,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 36014,
      "e": 33906,
      "ty": 7,
      "x": 832,
      "y": 429,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 36030,
      "e": 33922,
      "ty": 6,
      "x": 835,
      "y": 413,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 36047,
      "e": 33939,
      "ty": 7,
      "x": 840,
      "y": 392,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 36104,
      "e": 33996,
      "ty": 2,
      "x": 834,
      "y": 332
    },
    {
      "t": 36114,
      "e": 34006,
      "ty": 6,
      "x": 828,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 36130,
      "e": 34022,
      "ty": 7,
      "x": 824,
      "y": 307,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 36204,
      "e": 34096,
      "ty": 2,
      "x": 823,
      "y": 248
    },
    {
      "t": 36255,
      "e": 34147,
      "ty": 41,
      "x": 1292,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 36305,
      "e": 34197,
      "ty": 2,
      "x": 823,
      "y": 243
    },
    {
      "t": 36704,
      "e": 34596,
      "ty": 2,
      "x": 823,
      "y": 242
    },
    {
      "t": 36755,
      "e": 34647,
      "ty": 41,
      "x": 1292,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 36804,
      "e": 34696,
      "ty": 2,
      "x": 824,
      "y": 239
    },
    {
      "t": 36815,
      "e": 34697,
      "ty": 6,
      "x": 826,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36904,
      "e": 34786,
      "ty": 2,
      "x": 827,
      "y": 238
    },
    {
      "t": 37004,
      "e": 34886,
      "ty": 2,
      "x": 829,
      "y": 238
    },
    {
      "t": 37004,
      "e": 34886,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 37255,
      "e": 35137,
      "ty": 41,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 37304,
      "e": 35186,
      "ty": 2,
      "x": 836,
      "y": 238
    },
    {
      "t": 37348,
      "e": 35230,
      "ty": 7,
      "x": 841,
      "y": 250,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 37404,
      "e": 35286,
      "ty": 2,
      "x": 849,
      "y": 271
    },
    {
      "t": 37504,
      "e": 35386,
      "ty": 2,
      "x": 858,
      "y": 290
    },
    {
      "t": 37504,
      "e": 35386,
      "ty": 41,
      "x": 11463,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 37605,
      "e": 35487,
      "ty": 2,
      "x": 858,
      "y": 291
    },
    {
      "t": 37646,
      "e": 35528,
      "ty": 3,
      "x": 858,
      "y": 291,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 37752,
      "e": 35634,
      "ty": 4,
      "x": 11463,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 37752,
      "e": 35634,
      "ty": 5,
      "x": 858,
      "y": 291,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 37754,
      "e": 35636,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 37755,
      "e": 35637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 37757,
      "e": 35639,
      "ty": 41,
      "x": 11463,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 38105,
      "e": 35987,
      "ty": 2,
      "x": 872,
      "y": 330
    },
    {
      "t": 38204,
      "e": 36086,
      "ty": 2,
      "x": 902,
      "y": 370
    },
    {
      "t": 38255,
      "e": 36137,
      "ty": 41,
      "x": 19597,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 38304,
      "e": 36186,
      "ty": 2,
      "x": 906,
      "y": 395
    },
    {
      "t": 38405,
      "e": 36287,
      "ty": 2,
      "x": 906,
      "y": 429
    },
    {
      "t": 38505,
      "e": 36387,
      "ty": 2,
      "x": 906,
      "y": 443
    },
    {
      "t": 38505,
      "e": 36387,
      "ty": 41,
      "x": 20072,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 38605,
      "e": 36487,
      "ty": 2,
      "x": 906,
      "y": 444
    },
    {
      "t": 38704,
      "e": 36586,
      "ty": 2,
      "x": 905,
      "y": 446
    },
    {
      "t": 38755,
      "e": 36637,
      "ty": 41,
      "x": 19835,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 38804,
      "e": 36686,
      "ty": 2,
      "x": 905,
      "y": 447
    },
    {
      "t": 39005,
      "e": 36887,
      "ty": 41,
      "x": 19835,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 40005,
      "e": 37887,
      "ty": 2,
      "x": 905,
      "y": 456
    },
    {
      "t": 40005,
      "e": 37887,
      "ty": 41,
      "x": 19835,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 40104,
      "e": 37986,
      "ty": 2,
      "x": 902,
      "y": 470
    },
    {
      "t": 40204,
      "e": 38086,
      "ty": 2,
      "x": 893,
      "y": 497
    },
    {
      "t": 40254,
      "e": 38136,
      "ty": 41,
      "x": 60654,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 40304,
      "e": 38186,
      "ty": 2,
      "x": 888,
      "y": 510
    },
    {
      "t": 40404,
      "e": 38286,
      "ty": 2,
      "x": 884,
      "y": 519
    },
    {
      "t": 40505,
      "e": 38387,
      "ty": 2,
      "x": 884,
      "y": 530
    },
    {
      "t": 40505,
      "e": 38387,
      "ty": 41,
      "x": 14851,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 40604,
      "e": 38486,
      "ty": 2,
      "x": 880,
      "y": 536
    },
    {
      "t": 40755,
      "e": 38637,
      "ty": 41,
      "x": 13902,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 40904,
      "e": 38786,
      "ty": 2,
      "x": 876,
      "y": 528
    },
    {
      "t": 41004,
      "e": 38886,
      "ty": 2,
      "x": 873,
      "y": 519
    },
    {
      "t": 41005,
      "e": 38887,
      "ty": 41,
      "x": 60360,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 41104,
      "e": 38986,
      "ty": 2,
      "x": 871,
      "y": 507
    },
    {
      "t": 41203,
      "e": 39085,
      "ty": 2,
      "x": 870,
      "y": 503
    },
    {
      "t": 41254,
      "e": 39136,
      "ty": 41,
      "x": 40010,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 41304,
      "e": 39186,
      "ty": 2,
      "x": 865,
      "y": 493
    },
    {
      "t": 41404,
      "e": 39286,
      "ty": 2,
      "x": 861,
      "y": 471
    },
    {
      "t": 41500,
      "e": 39382,
      "ty": 3,
      "x": 860,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41501,
      "e": 39383,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 41504,
      "e": 39386,
      "ty": 2,
      "x": 860,
      "y": 469
    },
    {
      "t": 41504,
      "e": 39386,
      "ty": 41,
      "x": 40777,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41604,
      "e": 39486,
      "ty": 4,
      "x": 40777,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41604,
      "e": 39486,
      "ty": 5,
      "x": 860,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41605,
      "e": 39487,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 41607,
      "e": 39489,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 41754,
      "e": 39636,
      "ty": 41,
      "x": 40777,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41804,
      "e": 39686,
      "ty": 2,
      "x": 883,
      "y": 512
    },
    {
      "t": 41904,
      "e": 39786,
      "ty": 2,
      "x": 911,
      "y": 565
    },
    {
      "t": 42003,
      "e": 39885,
      "ty": 2,
      "x": 919,
      "y": 659
    },
    {
      "t": 42003,
      "e": 39885,
      "ty": 41,
      "x": 23157,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 42104,
      "e": 39986,
      "ty": 2,
      "x": 900,
      "y": 723
    },
    {
      "t": 42203,
      "e": 40085,
      "ty": 2,
      "x": 900,
      "y": 731
    },
    {
      "t": 42253,
      "e": 40135,
      "ty": 41,
      "x": 19722,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 42304,
      "e": 40186,
      "ty": 2,
      "x": 900,
      "y": 732
    },
    {
      "t": 42704,
      "e": 40586,
      "ty": 2,
      "x": 911,
      "y": 713
    },
    {
      "t": 42754,
      "e": 40636,
      "ty": 41,
      "x": 22920,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 42804,
      "e": 40686,
      "ty": 2,
      "x": 919,
      "y": 675
    },
    {
      "t": 42904,
      "e": 40786,
      "ty": 2,
      "x": 919,
      "y": 670
    },
    {
      "t": 43004,
      "e": 40886,
      "ty": 41,
      "x": 26199,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 43104,
      "e": 40986,
      "ty": 2,
      "x": 918,
      "y": 670
    },
    {
      "t": 43204,
      "e": 41086,
      "ty": 2,
      "x": 917,
      "y": 672
    },
    {
      "t": 43254,
      "e": 41136,
      "ty": 41,
      "x": 25394,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 43304,
      "e": 41186,
      "ty": 2,
      "x": 910,
      "y": 700
    },
    {
      "t": 43405,
      "e": 41287,
      "ty": 2,
      "x": 906,
      "y": 723
    },
    {
      "t": 43503,
      "e": 41385,
      "ty": 2,
      "x": 906,
      "y": 725
    },
    {
      "t": 43504,
      "e": 41386,
      "ty": 41,
      "x": 21227,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 43705,
      "e": 41587,
      "ty": 2,
      "x": 908,
      "y": 720
    },
    {
      "t": 43755,
      "e": 41637,
      "ty": 41,
      "x": 22572,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 43804,
      "e": 41686,
      "ty": 2,
      "x": 913,
      "y": 703
    },
    {
      "t": 43904,
      "e": 41786,
      "ty": 2,
      "x": 916,
      "y": 695
    },
    {
      "t": 43925,
      "e": 41807,
      "ty": 3,
      "x": 916,
      "y": 695,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 43926,
      "e": 41808,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 44004,
      "e": 41886,
      "ty": 41,
      "x": 23831,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 44037,
      "e": 41919,
      "ty": 4,
      "x": 23831,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 44037,
      "e": 41919,
      "ty": 5,
      "x": 916,
      "y": 695,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 44037,
      "e": 41919,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44038,
      "e": 41920,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 44303,
      "e": 42185,
      "ty": 2,
      "x": 916,
      "y": 699
    },
    {
      "t": 44405,
      "e": 42287,
      "ty": 2,
      "x": 918,
      "y": 743
    },
    {
      "t": 44503,
      "e": 42385,
      "ty": 2,
      "x": 938,
      "y": 773
    },
    {
      "t": 44503,
      "e": 42385,
      "ty": 41,
      "x": 27666,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 44604,
      "e": 42486,
      "ty": 2,
      "x": 970,
      "y": 787
    },
    {
      "t": 44704,
      "e": 42586,
      "ty": 2,
      "x": 991,
      "y": 798
    },
    {
      "t": 44754,
      "e": 42636,
      "ty": 41,
      "x": 40719,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 44804,
      "e": 42686,
      "ty": 2,
      "x": 995,
      "y": 803
    },
    {
      "t": 44904,
      "e": 42786,
      "ty": 2,
      "x": 999,
      "y": 834
    },
    {
      "t": 45004,
      "e": 42886,
      "ty": 2,
      "x": 1006,
      "y": 843
    },
    {
      "t": 45004,
      "e": 42886,
      "ty": 41,
      "x": 43804,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 45504,
      "e": 43386,
      "ty": 2,
      "x": 1004,
      "y": 860
    },
    {
      "t": 45504,
      "e": 43386,
      "ty": 41,
      "x": 43330,
      "y": 52233,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 45603,
      "e": 43485,
      "ty": 2,
      "x": 975,
      "y": 919
    },
    {
      "t": 45704,
      "e": 43586,
      "ty": 2,
      "x": 923,
      "y": 953
    },
    {
      "t": 45754,
      "e": 43636,
      "ty": 41,
      "x": 21971,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 45804,
      "e": 43686,
      "ty": 2,
      "x": 907,
      "y": 952
    },
    {
      "t": 45904,
      "e": 43686,
      "ty": 2,
      "x": 888,
      "y": 955
    },
    {
      "t": 45988,
      "e": 43770,
      "ty": 3,
      "x": 887,
      "y": 956,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 45990,
      "e": 43772,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 46004,
      "e": 43786,
      "ty": 2,
      "x": 887,
      "y": 956
    },
    {
      "t": 46004,
      "e": 43786,
      "ty": 41,
      "x": 53047,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46093,
      "e": 43875,
      "ty": 4,
      "x": 53047,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46094,
      "e": 43876,
      "ty": 5,
      "x": 887,
      "y": 956,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46094,
      "e": 43876,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 46096,
      "e": 43878,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 46204,
      "e": 43986,
      "ty": 2,
      "x": 885,
      "y": 972
    },
    {
      "t": 46254,
      "e": 44036,
      "ty": 41,
      "x": 59144,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 46303,
      "e": 44085,
      "ty": 2,
      "x": 881,
      "y": 1002
    },
    {
      "t": 46326,
      "e": 44108,
      "ty": 6,
      "x": 881,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46403,
      "e": 44185,
      "ty": 2,
      "x": 881,
      "y": 1009
    },
    {
      "t": 46485,
      "e": 44267,
      "ty": 3,
      "x": 881,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46486,
      "e": 44268,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 46486,
      "e": 44268,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46504,
      "e": 44286,
      "ty": 41,
      "x": 26582,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46573,
      "e": 44355,
      "ty": 4,
      "x": 26582,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46575,
      "e": 44357,
      "ty": 5,
      "x": 881,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46581,
      "e": 44363,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46583,
      "e": 44365,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 46586,
      "e": 44368,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46803,
      "e": 44585,
      "ty": 2,
      "x": 900,
      "y": 1003
    },
    {
      "t": 46904,
      "e": 44686,
      "ty": 2,
      "x": 1089,
      "y": 882
    },
    {
      "t": 47004,
      "e": 44786,
      "ty": 2,
      "x": 1122,
      "y": 849
    },
    {
      "t": 47004,
      "e": 44786,
      "ty": 41,
      "x": 38363,
      "y": 46589,
      "ta": "html > body"
    },
    {
      "t": 47104,
      "e": 44886,
      "ty": 2,
      "x": 1122,
      "y": 838
    },
    {
      "t": 47204,
      "e": 44986,
      "ty": 2,
      "x": 1122,
      "y": 836
    },
    {
      "t": 47254,
      "e": 45036,
      "ty": 41,
      "x": 38363,
      "y": 45868,
      "ta": "html > body"
    },
    {
      "t": 47684,
      "e": 45466,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 47754,
      "e": 45536,
      "ty": 41,
      "x": 40663,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 47804,
      "e": 45586,
      "ty": 2,
      "x": 1116,
      "y": 835
    },
    {
      "t": 47904,
      "e": 45686,
      "ty": 2,
      "x": 1114,
      "y": 835
    },
    {
      "t": 48005,
      "e": 45787,
      "ty": 41,
      "x": 40368,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 48254,
      "e": 46036,
      "ty": 41,
      "x": 40171,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 48304,
      "e": 46086,
      "ty": 2,
      "x": 1103,
      "y": 835
    },
    {
      "t": 48404,
      "e": 46186,
      "ty": 2,
      "x": 1099,
      "y": 837
    },
    {
      "t": 48504,
      "e": 46286,
      "ty": 2,
      "x": 1093,
      "y": 846
    },
    {
      "t": 48504,
      "e": 46286,
      "ty": 41,
      "x": 39335,
      "y": 55606,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 48604,
      "e": 46386,
      "ty": 2,
      "x": 1066,
      "y": 922
    },
    {
      "t": 48704,
      "e": 46486,
      "ty": 2,
      "x": 1042,
      "y": 1002
    },
    {
      "t": 48754,
      "e": 46536,
      "ty": 41,
      "x": 36334,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48804,
      "e": 46586,
      "ty": 2,
      "x": 1020,
      "y": 1044
    },
    {
      "t": 48904,
      "e": 46686,
      "ty": 2,
      "x": 999,
      "y": 1068
    },
    {
      "t": 48926,
      "e": 46708,
      "ty": 6,
      "x": 992,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 49004,
      "e": 46786,
      "ty": 2,
      "x": 981,
      "y": 1086
    },
    {
      "t": 49004,
      "e": 46786,
      "ty": 41,
      "x": 39047,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 49104,
      "e": 46886,
      "ty": 2,
      "x": 980,
      "y": 1086
    },
    {
      "t": 49254,
      "e": 47036,
      "ty": 41,
      "x": 38501,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 60004,
      "e": 52036,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 64870,
      "e": 52036,
      "ty": 3,
      "x": 980,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 64871,
      "e": 52037,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 65012,
      "e": 52178,
      "ty": 4,
      "x": 38501,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 65013,
      "e": 52179,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 65013,
      "e": 52179,
      "ty": 5,
      "x": 980,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 65014,
      "e": 52180,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 66049,
      "e": 53215,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 67329,
      "e": 54495,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 118782, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 118789, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3873, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 124021, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11025, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 136053, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11270, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 148420, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 20177, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 169601, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 29801, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 200833, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-A -A -A -11 AM-A -A -A -A -A -A -A -11 AM-10 AM-11 AM-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:955,y:1097,t:1527876571263};\\\", \\\"{x:955,y:1096,t:1527876571270};\\\", \\\"{x:957,y:1094,t:1527876571285};\\\", \\\"{x:961,y:1091,t:1527876571302};\\\", \\\"{x:962,y:1090,t:1527876571319};\\\", \\\"{x:964,y:1089,t:1527876571336};\\\", \\\"{x:968,y:1085,t:1527876571352};\\\", \\\"{x:976,y:1074,t:1527876571368};\\\", \\\"{x:986,y:1065,t:1527876571385};\\\", \\\"{x:991,y:1053,t:1527876571402};\\\", \\\"{x:995,y:1045,t:1527876571419};\\\", \\\"{x:1002,y:1034,t:1527876571436};\\\", \\\"{x:1006,y:1025,t:1527876571453};\\\", \\\"{x:1011,y:1016,t:1527876571468};\\\", \\\"{x:1015,y:1012,t:1527876571485};\\\", \\\"{x:1018,y:1009,t:1527876571502};\\\", \\\"{x:1020,y:1006,t:1527876571518};\\\", \\\"{x:1024,y:1003,t:1527876571535};\\\", \\\"{x:1026,y:1001,t:1527876571552};\\\", \\\"{x:1027,y:1001,t:1527876571581};\\\", \\\"{x:1029,y:1001,t:1527876571597};\\\", \\\"{x:1033,y:1001,t:1527876571613};\\\", \\\"{x:1038,y:1001,t:1527876571621};\\\", \\\"{x:1040,y:1001,t:1527876571635};\\\", \\\"{x:1054,y:1001,t:1527876571652};\\\", \\\"{x:1081,y:1001,t:1527876571669};\\\", \\\"{x:1102,y:1001,t:1527876571685};\\\", \\\"{x:1121,y:1001,t:1527876571702};\\\", \\\"{x:1136,y:1001,t:1527876571719};\\\", \\\"{x:1161,y:1001,t:1527876571736};\\\", \\\"{x:1188,y:1001,t:1527876571752};\\\", \\\"{x:1232,y:994,t:1527876571769};\\\", \\\"{x:1290,y:977,t:1527876571785};\\\", \\\"{x:1344,y:959,t:1527876571803};\\\", \\\"{x:1370,y:949,t:1527876571819};\\\", \\\"{x:1385,y:942,t:1527876571835};\\\", \\\"{x:1393,y:939,t:1527876571853};\\\", \\\"{x:1394,y:938,t:1527876571870};\\\", \\\"{x:1388,y:938,t:1527876571973};\\\", \\\"{x:1378,y:940,t:1527876571985};\\\", \\\"{x:1360,y:944,t:1527876572002};\\\", \\\"{x:1339,y:949,t:1527876572019};\\\", \\\"{x:1333,y:951,t:1527876572035};\\\", \\\"{x:1321,y:955,t:1527876572052};\\\", \\\"{x:1294,y:960,t:1527876572069};\\\", \\\"{x:1282,y:961,t:1527876572086};\\\", \\\"{x:1280,y:963,t:1527876572102};\\\", \\\"{x:1273,y:965,t:1527876572120};\\\", \\\"{x:1271,y:965,t:1527876572136};\\\", \\\"{x:1270,y:966,t:1527876572153};\\\", \\\"{x:1269,y:966,t:1527876572214};\\\", \\\"{x:1269,y:967,t:1527876572806};\\\", \\\"{x:1269,y:968,t:1527876572819};\\\", \\\"{x:1269,y:970,t:1527876572837};\\\", \\\"{x:1271,y:975,t:1527876572853};\\\", \\\"{x:1272,y:978,t:1527876572870};\\\", \\\"{x:1272,y:979,t:1527876572886};\\\", \\\"{x:1272,y:982,t:1527876572903};\\\", \\\"{x:1273,y:983,t:1527876572925};\\\", \\\"{x:1274,y:985,t:1527876572937};\\\", \\\"{x:1274,y:987,t:1527876572953};\\\", \\\"{x:1274,y:989,t:1527876572970};\\\", \\\"{x:1275,y:990,t:1527876573239};\\\", \\\"{x:1277,y:990,t:1527876573262};\\\", \\\"{x:1278,y:989,t:1527876573270};\\\", \\\"{x:1279,y:989,t:1527876573287};\\\", \\\"{x:1280,y:985,t:1527876573303};\\\", \\\"{x:1281,y:983,t:1527876573320};\\\", \\\"{x:1282,y:981,t:1527876573336};\\\", \\\"{x:1284,y:978,t:1527876573353};\\\", \\\"{x:1286,y:975,t:1527876573369};\\\", \\\"{x:1288,y:974,t:1527876573386};\\\", \\\"{x:1289,y:972,t:1527876573403};\\\", \\\"{x:1290,y:972,t:1527876573420};\\\", \\\"{x:1293,y:970,t:1527876573436};\\\", \\\"{x:1293,y:969,t:1527876573462};\\\", \\\"{x:1294,y:969,t:1527876573767};\\\", \\\"{x:1294,y:967,t:1527876573785};\\\", \\\"{x:1294,y:965,t:1527876573796};\\\", \\\"{x:1294,y:962,t:1527876573812};\\\", \\\"{x:1294,y:960,t:1527876573829};\\\", \\\"{x:1293,y:957,t:1527876573846};\\\", \\\"{x:1291,y:955,t:1527876575191};\\\", \\\"{x:1290,y:954,t:1527876575198};\\\", \\\"{x:1289,y:953,t:1527876575213};\\\", \\\"{x:1288,y:953,t:1527876575239};\\\", \\\"{x:1287,y:953,t:1527876575279};\\\", \\\"{x:1286,y:952,t:1527876575295};\\\", \\\"{x:1286,y:950,t:1527876575502};\\\", \\\"{x:1286,y:949,t:1527876575515};\\\", \\\"{x:1286,y:945,t:1527876575531};\\\", \\\"{x:1286,y:938,t:1527876575547};\\\", \\\"{x:1286,y:932,t:1527876575564};\\\", \\\"{x:1286,y:926,t:1527876575580};\\\", \\\"{x:1286,y:920,t:1527876575597};\\\", \\\"{x:1286,y:909,t:1527876575614};\\\", \\\"{x:1284,y:896,t:1527876575630};\\\", \\\"{x:1283,y:885,t:1527876575649};\\\", \\\"{x:1283,y:880,t:1527876575665};\\\", \\\"{x:1281,y:873,t:1527876575681};\\\", \\\"{x:1281,y:866,t:1527876575698};\\\", \\\"{x:1281,y:858,t:1527876575715};\\\", \\\"{x:1281,y:852,t:1527876575731};\\\", \\\"{x:1281,y:846,t:1527876575747};\\\", \\\"{x:1281,y:841,t:1527876575765};\\\", \\\"{x:1281,y:839,t:1527876575781};\\\", \\\"{x:1281,y:837,t:1527876575798};\\\", \\\"{x:1281,y:833,t:1527876575819};\\\", \\\"{x:1280,y:830,t:1527876575847};\\\", \\\"{x:1280,y:829,t:1527876575869};\\\", \\\"{x:1280,y:827,t:1527876575881};\\\", \\\"{x:1280,y:826,t:1527876575902};\\\", \\\"{x:1280,y:825,t:1527876575914};\\\", \\\"{x:1280,y:823,t:1527876575932};\\\", \\\"{x:1280,y:821,t:1527876575948};\\\", \\\"{x:1280,y:820,t:1527876575964};\\\", \\\"{x:1280,y:817,t:1527876575981};\\\", \\\"{x:1280,y:814,t:1527876575998};\\\", \\\"{x:1280,y:812,t:1527876576015};\\\", \\\"{x:1280,y:811,t:1527876576031};\\\", \\\"{x:1280,y:812,t:1527876576255};\\\", \\\"{x:1280,y:814,t:1527876576266};\\\", \\\"{x:1280,y:815,t:1527876576283};\\\", \\\"{x:1280,y:817,t:1527876576299};\\\", \\\"{x:1280,y:818,t:1527876576327};\\\", \\\"{x:1280,y:819,t:1527876576342};\\\", \\\"{x:1280,y:820,t:1527876576351};\\\", \\\"{x:1280,y:821,t:1527876576367};\\\", \\\"{x:1280,y:823,t:1527876576382};\\\", \\\"{x:1280,y:824,t:1527876576407};\\\", \\\"{x:1280,y:825,t:1527876576421};\\\", \\\"{x:1280,y:826,t:1527876576432};\\\", \\\"{x:1280,y:827,t:1527876576526};\\\", \\\"{x:1280,y:828,t:1527876576534};\\\", \\\"{x:1280,y:829,t:1527876576550};\\\", \\\"{x:1280,y:832,t:1527876579543};\\\", \\\"{x:1280,y:835,t:1527876579551};\\\", \\\"{x:1281,y:841,t:1527876579570};\\\", \\\"{x:1282,y:846,t:1527876579582};\\\", \\\"{x:1283,y:849,t:1527876579600};\\\", \\\"{x:1284,y:853,t:1527876579619};\\\", \\\"{x:1286,y:859,t:1527876579634};\\\", \\\"{x:1287,y:866,t:1527876579651};\\\", \\\"{x:1288,y:874,t:1527876579668};\\\", \\\"{x:1288,y:881,t:1527876579685};\\\", \\\"{x:1290,y:890,t:1527876579701};\\\", \\\"{x:1293,y:902,t:1527876579717};\\\", \\\"{x:1295,y:910,t:1527876579734};\\\", \\\"{x:1296,y:917,t:1527876579752};\\\", \\\"{x:1297,y:924,t:1527876579769};\\\", \\\"{x:1299,y:931,t:1527876579784};\\\", \\\"{x:1299,y:935,t:1527876579801};\\\", \\\"{x:1299,y:938,t:1527876579818};\\\", \\\"{x:1299,y:941,t:1527876579834};\\\", \\\"{x:1299,y:944,t:1527876579852};\\\", \\\"{x:1299,y:948,t:1527876579868};\\\", \\\"{x:1299,y:952,t:1527876579885};\\\", \\\"{x:1299,y:955,t:1527876579901};\\\", \\\"{x:1300,y:961,t:1527876579919};\\\", \\\"{x:1300,y:965,t:1527876579934};\\\", \\\"{x:1300,y:970,t:1527876579952};\\\", \\\"{x:1300,y:972,t:1527876579969};\\\", \\\"{x:1299,y:973,t:1527876579985};\\\", \\\"{x:1299,y:975,t:1527876580001};\\\", \\\"{x:1298,y:976,t:1527876580019};\\\", \\\"{x:1298,y:977,t:1527876580063};\\\", \\\"{x:1297,y:978,t:1527876580071};\\\", \\\"{x:1296,y:979,t:1527876580087};\\\", \\\"{x:1295,y:979,t:1527876580168};\\\", \\\"{x:1294,y:979,t:1527876580183};\\\", \\\"{x:1292,y:979,t:1527876580207};\\\", \\\"{x:1291,y:979,t:1527876580223};\\\", \\\"{x:1290,y:979,t:1527876580239};\\\", \\\"{x:1289,y:978,t:1527876580253};\\\", \\\"{x:1288,y:977,t:1527876580269};\\\", \\\"{x:1287,y:977,t:1527876580287};\\\", \\\"{x:1286,y:975,t:1527876580302};\\\", \\\"{x:1285,y:975,t:1527876580319};\\\", \\\"{x:1285,y:974,t:1527876580336};\\\", \\\"{x:1285,y:973,t:1527876580359};\\\", \\\"{x:1284,y:972,t:1527876580369};\\\", \\\"{x:1283,y:971,t:1527876580386};\\\", \\\"{x:1283,y:970,t:1527876580402};\\\", \\\"{x:1281,y:967,t:1527876580419};\\\", \\\"{x:1280,y:965,t:1527876580436};\\\", \\\"{x:1280,y:964,t:1527876580453};\\\", \\\"{x:1279,y:963,t:1527876580470};\\\", \\\"{x:1279,y:962,t:1527876580487};\\\", \\\"{x:1278,y:959,t:1527876580503};\\\", \\\"{x:1278,y:958,t:1527876580519};\\\", \\\"{x:1278,y:956,t:1527876580536};\\\", \\\"{x:1277,y:954,t:1527876580553};\\\", \\\"{x:1276,y:952,t:1527876580575};\\\", \\\"{x:1276,y:951,t:1527876580591};\\\", \\\"{x:1276,y:949,t:1527876580607};\\\", \\\"{x:1276,y:948,t:1527876580619};\\\", \\\"{x:1274,y:943,t:1527876580636};\\\", \\\"{x:1274,y:936,t:1527876580654};\\\", \\\"{x:1272,y:927,t:1527876580669};\\\", \\\"{x:1269,y:918,t:1527876580686};\\\", \\\"{x:1268,y:893,t:1527876580703};\\\", \\\"{x:1268,y:875,t:1527876580719};\\\", \\\"{x:1268,y:854,t:1527876580736};\\\", \\\"{x:1272,y:840,t:1527876580753};\\\", \\\"{x:1276,y:830,t:1527876580775};\\\", \\\"{x:1277,y:820,t:1527876580786};\\\", \\\"{x:1279,y:813,t:1527876580803};\\\", \\\"{x:1281,y:807,t:1527876580819};\\\", \\\"{x:1282,y:805,t:1527876580835};\\\", \\\"{x:1282,y:804,t:1527876580853};\\\", \\\"{x:1283,y:801,t:1527876580868};\\\", \\\"{x:1284,y:801,t:1527876580885};\\\", \\\"{x:1284,y:798,t:1527876580902};\\\", \\\"{x:1284,y:799,t:1527876581040};\\\", \\\"{x:1284,y:801,t:1527876581052};\\\", \\\"{x:1284,y:807,t:1527876581070};\\\", \\\"{x:1283,y:809,t:1527876581086};\\\", \\\"{x:1282,y:813,t:1527876581102};\\\", \\\"{x:1282,y:816,t:1527876581119};\\\", \\\"{x:1282,y:818,t:1527876581135};\\\", \\\"{x:1282,y:819,t:1527876581191};\\\", \\\"{x:1282,y:820,t:1527876581222};\\\", \\\"{x:1282,y:821,t:1527876581246};\\\", \\\"{x:1282,y:822,t:1527876581295};\\\", \\\"{x:1282,y:823,t:1527876581455};\\\", \\\"{x:1282,y:824,t:1527876581470};\\\", \\\"{x:1282,y:825,t:1527876581491};\\\", \\\"{x:1282,y:826,t:1527876581519};\\\", \\\"{x:1282,y:827,t:1527876581535};\\\", \\\"{x:1282,y:828,t:1527876581671};\\\", \\\"{x:1282,y:829,t:1527876582173};\\\", \\\"{x:1281,y:830,t:1527876582543};\\\", \\\"{x:1280,y:830,t:1527876582575};\\\", \\\"{x:1280,y:829,t:1527876582711};\\\", \\\"{x:1280,y:828,t:1527876582759};\\\", \\\"{x:1281,y:828,t:1527876582815};\\\", \\\"{x:1282,y:827,t:1527876582839};\\\", \\\"{x:1282,y:826,t:1527876584711};\\\", \\\"{x:1282,y:825,t:1527876584719};\\\", \\\"{x:1282,y:824,t:1527876584737};\\\", \\\"{x:1282,y:821,t:1527876584752};\\\", \\\"{x:1281,y:818,t:1527876584768};\\\", \\\"{x:1281,y:817,t:1527876584790};\\\", \\\"{x:1281,y:815,t:1527876584806};\\\", \\\"{x:1281,y:814,t:1527876584822};\\\", \\\"{x:1281,y:812,t:1527876584839};\\\", \\\"{x:1280,y:811,t:1527876584855};\\\", \\\"{x:1280,y:809,t:1527876584872};\\\", \\\"{x:1279,y:807,t:1527876584889};\\\", \\\"{x:1279,y:806,t:1527876584910};\\\", \\\"{x:1278,y:805,t:1527876585222};\\\", \\\"{x:1278,y:811,t:1527876585239};\\\", \\\"{x:1276,y:819,t:1527876585255};\\\", \\\"{x:1275,y:823,t:1527876585272};\\\", \\\"{x:1275,y:824,t:1527876585294};\\\", \\\"{x:1275,y:825,t:1527876585376};\\\", \\\"{x:1275,y:824,t:1527876586687};\\\", \\\"{x:1275,y:825,t:1527876587048};\\\", \\\"{x:1279,y:832,t:1527876587063};\\\", \\\"{x:1287,y:855,t:1527876587075};\\\", \\\"{x:1295,y:873,t:1527876587089};\\\", \\\"{x:1303,y:897,t:1527876587107};\\\", \\\"{x:1306,y:911,t:1527876587124};\\\", \\\"{x:1309,y:923,t:1527876587141};\\\", \\\"{x:1311,y:940,t:1527876587158};\\\", \\\"{x:1312,y:948,t:1527876587173};\\\", \\\"{x:1312,y:955,t:1527876587190};\\\", \\\"{x:1312,y:957,t:1527876587207};\\\", \\\"{x:1312,y:959,t:1527876587223};\\\", \\\"{x:1312,y:960,t:1527876587391};\\\", \\\"{x:1304,y:963,t:1527876587409};\\\", \\\"{x:1301,y:964,t:1527876587426};\\\", \\\"{x:1298,y:966,t:1527876587442};\\\", \\\"{x:1297,y:966,t:1527876587458};\\\", \\\"{x:1295,y:966,t:1527876587475};\\\", \\\"{x:1294,y:966,t:1527876587503};\\\", \\\"{x:1293,y:966,t:1527876587511};\\\", \\\"{x:1292,y:966,t:1527876587527};\\\", \\\"{x:1291,y:966,t:1527876587542};\\\", \\\"{x:1288,y:967,t:1527876587559};\\\", \\\"{x:1287,y:967,t:1527876587623};\\\", \\\"{x:1285,y:968,t:1527876587630};\\\", \\\"{x:1284,y:969,t:1527876587641};\\\", \\\"{x:1282,y:969,t:1527876587658};\\\", \\\"{x:1277,y:970,t:1527876587674};\\\", \\\"{x:1276,y:970,t:1527876587935};\\\", \\\"{x:1275,y:970,t:1527876587943};\\\", \\\"{x:1275,y:969,t:1527876587959};\\\", \\\"{x:1275,y:968,t:1527876588015};\\\", \\\"{x:1275,y:967,t:1527876588025};\\\", \\\"{x:1275,y:966,t:1527876588046};\\\", \\\"{x:1275,y:964,t:1527876588078};\\\", \\\"{x:1275,y:963,t:1527876588093};\\\", \\\"{x:1275,y:962,t:1527876588107};\\\", \\\"{x:1275,y:958,t:1527876588125};\\\", \\\"{x:1275,y:946,t:1527876588141};\\\", \\\"{x:1274,y:937,t:1527876588158};\\\", \\\"{x:1271,y:926,t:1527876588175};\\\", \\\"{x:1267,y:911,t:1527876588192};\\\", \\\"{x:1264,y:896,t:1527876588208};\\\", \\\"{x:1259,y:880,t:1527876588225};\\\", \\\"{x:1256,y:868,t:1527876588242};\\\", \\\"{x:1253,y:854,t:1527876588258};\\\", \\\"{x:1252,y:847,t:1527876588275};\\\", \\\"{x:1250,y:842,t:1527876588292};\\\", \\\"{x:1250,y:835,t:1527876588309};\\\", \\\"{x:1250,y:829,t:1527876588325};\\\", \\\"{x:1248,y:818,t:1527876588342};\\\", \\\"{x:1248,y:815,t:1527876588358};\\\", \\\"{x:1248,y:812,t:1527876588375};\\\", \\\"{x:1248,y:810,t:1527876588392};\\\", \\\"{x:1248,y:808,t:1527876588409};\\\", \\\"{x:1249,y:807,t:1527876588425};\\\", \\\"{x:1249,y:806,t:1527876588447};\\\", \\\"{x:1250,y:805,t:1527876588479};\\\", \\\"{x:1251,y:805,t:1527876588552};\\\", \\\"{x:1252,y:805,t:1527876588559};\\\", \\\"{x:1254,y:805,t:1527876588598};\\\", \\\"{x:1255,y:805,t:1527876588614};\\\", \\\"{x:1257,y:805,t:1527876588625};\\\", \\\"{x:1262,y:808,t:1527876588642};\\\", \\\"{x:1265,y:809,t:1527876588660};\\\", \\\"{x:1266,y:810,t:1527876588675};\\\", \\\"{x:1266,y:811,t:1527876588719};\\\", \\\"{x:1266,y:812,t:1527876588727};\\\", \\\"{x:1267,y:813,t:1527876588743};\\\", \\\"{x:1267,y:815,t:1527876588760};\\\", \\\"{x:1267,y:816,t:1527876588850};\\\", \\\"{x:1262,y:816,t:1527876588858};\\\", \\\"{x:1228,y:813,t:1527876588875};\\\", \\\"{x:1137,y:803,t:1527876588892};\\\", \\\"{x:1033,y:793,t:1527876588909};\\\", \\\"{x:942,y:782,t:1527876588926};\\\", \\\"{x:861,y:773,t:1527876588942};\\\", \\\"{x:767,y:761,t:1527876588958};\\\", \\\"{x:725,y:754,t:1527876588976};\\\", \\\"{x:694,y:748,t:1527876588991};\\\", \\\"{x:673,y:744,t:1527876589009};\\\", \\\"{x:652,y:741,t:1527876589026};\\\", \\\"{x:637,y:739,t:1527876589042};\\\", \\\"{x:620,y:737,t:1527876589059};\\\", \\\"{x:603,y:736,t:1527876589076};\\\", \\\"{x:594,y:734,t:1527876589092};\\\", \\\"{x:587,y:732,t:1527876589109};\\\", \\\"{x:579,y:728,t:1527876589126};\\\", \\\"{x:573,y:721,t:1527876589142};\\\", \\\"{x:571,y:716,t:1527876589160};\\\", \\\"{x:568,y:712,t:1527876589176};\\\", \\\"{x:566,y:706,t:1527876589192};\\\", \\\"{x:561,y:699,t:1527876589209};\\\", \\\"{x:552,y:681,t:1527876589227};\\\", \\\"{x:537,y:662,t:1527876589242};\\\", \\\"{x:528,y:651,t:1527876589259};\\\", \\\"{x:509,y:634,t:1527876589276};\\\", \\\"{x:490,y:619,t:1527876589294};\\\", \\\"{x:483,y:615,t:1527876589309};\\\", \\\"{x:460,y:608,t:1527876589326};\\\", \\\"{x:446,y:606,t:1527876589343};\\\", \\\"{x:433,y:605,t:1527876589359};\\\", \\\"{x:425,y:605,t:1527876589376};\\\", \\\"{x:423,y:604,t:1527876589393};\\\", \\\"{x:419,y:602,t:1527876589408};\\\", \\\"{x:413,y:602,t:1527876589426};\\\", \\\"{x:411,y:600,t:1527876589443};\\\", \\\"{x:410,y:600,t:1527876589458};\\\", \\\"{x:406,y:599,t:1527876589476};\\\", \\\"{x:404,y:595,t:1527876589493};\\\", \\\"{x:402,y:594,t:1527876589509};\\\", \\\"{x:401,y:591,t:1527876589543};\\\", \\\"{x:401,y:590,t:1527876589550};\\\", \\\"{x:398,y:584,t:1527876589560};\\\", \\\"{x:396,y:580,t:1527876589577};\\\", \\\"{x:394,y:576,t:1527876589593};\\\", \\\"{x:393,y:573,t:1527876589610};\\\", \\\"{x:388,y:568,t:1527876589627};\\\", \\\"{x:386,y:562,t:1527876589643};\\\", \\\"{x:385,y:561,t:1527876589660};\\\", \\\"{x:385,y:560,t:1527876589676};\\\", \\\"{x:385,y:559,t:1527876589693};\\\", \\\"{x:383,y:554,t:1527876589710};\\\", \\\"{x:383,y:551,t:1527876589727};\\\", \\\"{x:383,y:553,t:1527876590103};\\\", \\\"{x:384,y:555,t:1527876590110};\\\", \\\"{x:387,y:558,t:1527876590127};\\\", \\\"{x:390,y:562,t:1527876590144};\\\", \\\"{x:392,y:565,t:1527876590160};\\\", \\\"{x:393,y:567,t:1527876590178};\\\", \\\"{x:395,y:569,t:1527876590194};\\\", \\\"{x:398,y:574,t:1527876590210};\\\", \\\"{x:401,y:578,t:1527876590226};\\\", \\\"{x:405,y:583,t:1527876590243};\\\", \\\"{x:407,y:586,t:1527876590260};\\\", \\\"{x:413,y:590,t:1527876590277};\\\", \\\"{x:419,y:597,t:1527876590293};\\\", \\\"{x:423,y:601,t:1527876590310};\\\", \\\"{x:432,y:611,t:1527876590327};\\\", \\\"{x:442,y:624,t:1527876590344};\\\", \\\"{x:456,y:635,t:1527876590360};\\\", \\\"{x:473,y:648,t:1527876590377};\\\", \\\"{x:489,y:660,t:1527876590393};\\\", \\\"{x:508,y:674,t:1527876590410};\\\", \\\"{x:528,y:687,t:1527876590427};\\\", \\\"{x:542,y:695,t:1527876590444};\\\", \\\"{x:555,y:705,t:1527876590460};\\\", \\\"{x:565,y:715,t:1527876590477};\\\", \\\"{x:594,y:733,t:1527876590493};\\\", \\\"{x:619,y:745,t:1527876590509};\\\", \\\"{x:644,y:759,t:1527876590526};\\\", \\\"{x:655,y:773,t:1527876590544};\\\", \\\"{x:690,y:788,t:1527876590560};\\\", \\\"{x:736,y:807,t:1527876590577};\\\", \\\"{x:826,y:840,t:1527876590594};\\\", \\\"{x:885,y:861,t:1527876590609};\\\", \\\"{x:980,y:890,t:1527876590627};\\\", \\\"{x:1057,y:909,t:1527876590644};\\\", \\\"{x:1090,y:918,t:1527876590659};\\\", \\\"{x:1126,y:931,t:1527876590677};\\\", \\\"{x:1157,y:946,t:1527876590694};\\\", \\\"{x:1174,y:952,t:1527876590710};\\\", \\\"{x:1191,y:957,t:1527876590727};\\\", \\\"{x:1200,y:962,t:1527876590744};\\\", \\\"{x:1204,y:963,t:1527876590760};\\\", \\\"{x:1210,y:967,t:1527876590778};\\\", \\\"{x:1212,y:967,t:1527876590794};\\\", \\\"{x:1215,y:969,t:1527876590810};\\\", \\\"{x:1216,y:970,t:1527876590827};\\\", \\\"{x:1217,y:971,t:1527876590903};\\\", \\\"{x:1218,y:971,t:1527876590926};\\\", \\\"{x:1219,y:972,t:1527876590944};\\\", \\\"{x:1223,y:972,t:1527876590962};\\\", \\\"{x:1224,y:972,t:1527876590977};\\\", \\\"{x:1227,y:972,t:1527876590995};\\\", \\\"{x:1231,y:972,t:1527876591012};\\\", \\\"{x:1241,y:972,t:1527876591028};\\\", \\\"{x:1248,y:972,t:1527876591044};\\\", \\\"{x:1252,y:972,t:1527876591060};\\\", \\\"{x:1257,y:972,t:1527876591077};\\\", \\\"{x:1259,y:972,t:1527876591093};\\\", \\\"{x:1260,y:972,t:1527876591111};\\\", \\\"{x:1261,y:972,t:1527876591134};\\\", \\\"{x:1262,y:973,t:1527876591199};\\\", \\\"{x:1265,y:973,t:1527876591214};\\\", \\\"{x:1266,y:973,t:1527876591238};\\\", \\\"{x:1268,y:974,t:1527876591343};\\\", \\\"{x:1270,y:974,t:1527876591383};\\\", \\\"{x:1271,y:974,t:1527876591398};\\\", \\\"{x:1275,y:974,t:1527876591415};\\\", \\\"{x:1277,y:975,t:1527876591429};\\\", \\\"{x:1283,y:975,t:1527876591445};\\\", \\\"{x:1289,y:977,t:1527876591461};\\\", \\\"{x:1294,y:978,t:1527876591478};\\\", \\\"{x:1295,y:978,t:1527876591494};\\\", \\\"{x:1300,y:976,t:1527876592455};\\\", \\\"{x:1302,y:975,t:1527876592463};\\\", \\\"{x:1308,y:971,t:1527876592479};\\\", \\\"{x:1312,y:968,t:1527876592496};\\\", \\\"{x:1314,y:967,t:1527876592513};\\\", \\\"{x:1315,y:966,t:1527876592535};\\\", \\\"{x:1315,y:965,t:1527876592599};\\\", \\\"{x:1314,y:965,t:1527876592959};\\\", \\\"{x:1313,y:965,t:1527876592967};\\\", \\\"{x:1311,y:965,t:1527876593007};\\\", \\\"{x:1310,y:964,t:1527876593031};\\\", \\\"{x:1308,y:960,t:1527876593046};\\\", \\\"{x:1304,y:951,t:1527876593063};\\\", \\\"{x:1302,y:935,t:1527876593080};\\\", \\\"{x:1298,y:919,t:1527876593096};\\\", \\\"{x:1298,y:900,t:1527876593113};\\\", \\\"{x:1298,y:884,t:1527876593130};\\\", \\\"{x:1298,y:875,t:1527876593147};\\\", \\\"{x:1298,y:867,t:1527876593162};\\\", \\\"{x:1296,y:857,t:1527876593180};\\\", \\\"{x:1293,y:853,t:1527876593197};\\\", \\\"{x:1289,y:844,t:1527876593213};\\\", \\\"{x:1286,y:837,t:1527876593230};\\\", \\\"{x:1281,y:831,t:1527876593250};\\\", \\\"{x:1278,y:826,t:1527876593278};\\\", \\\"{x:1277,y:823,t:1527876593296};\\\", \\\"{x:1276,y:822,t:1527876593312};\\\", \\\"{x:1275,y:821,t:1527876593329};\\\", \\\"{x:1274,y:820,t:1527876593358};\\\", \\\"{x:1274,y:819,t:1527876593382};\\\", \\\"{x:1273,y:818,t:1527876593406};\\\", \\\"{x:1273,y:817,t:1527876593422};\\\", \\\"{x:1272,y:816,t:1527876593430};\\\", \\\"{x:1272,y:814,t:1527876593454};\\\", \\\"{x:1271,y:813,t:1527876593462};\\\", \\\"{x:1270,y:810,t:1527876593479};\\\", \\\"{x:1270,y:808,t:1527876593496};\\\", \\\"{x:1269,y:804,t:1527876593513};\\\", \\\"{x:1269,y:803,t:1527876593530};\\\", \\\"{x:1269,y:799,t:1527876593546};\\\", \\\"{x:1268,y:794,t:1527876593562};\\\", \\\"{x:1267,y:789,t:1527876593579};\\\", \\\"{x:1266,y:784,t:1527876593596};\\\", \\\"{x:1265,y:781,t:1527876593612};\\\", \\\"{x:1265,y:778,t:1527876593629};\\\", \\\"{x:1265,y:777,t:1527876593646};\\\", \\\"{x:1265,y:775,t:1527876593671};\\\", \\\"{x:1264,y:773,t:1527876593695};\\\", \\\"{x:1264,y:772,t:1527876593703};\\\", \\\"{x:1264,y:771,t:1527876593712};\\\", \\\"{x:1264,y:768,t:1527876593729};\\\", \\\"{x:1264,y:765,t:1527876593746};\\\", \\\"{x:1262,y:762,t:1527876593763};\\\", \\\"{x:1261,y:758,t:1527876593779};\\\", \\\"{x:1261,y:753,t:1527876593796};\\\", \\\"{x:1261,y:749,t:1527876593813};\\\", \\\"{x:1260,y:746,t:1527876593829};\\\", \\\"{x:1260,y:744,t:1527876593845};\\\", \\\"{x:1260,y:743,t:1527876593863};\\\", \\\"{x:1260,y:739,t:1527876593879};\\\", \\\"{x:1260,y:736,t:1527876593896};\\\", \\\"{x:1259,y:731,t:1527876593913};\\\", \\\"{x:1259,y:730,t:1527876593942};\\\", \\\"{x:1258,y:730,t:1527876593950};\\\", \\\"{x:1258,y:729,t:1527876593964};\\\", \\\"{x:1257,y:729,t:1527876593980};\\\", \\\"{x:1257,y:727,t:1527876593999};\\\", \\\"{x:1256,y:726,t:1527876594014};\\\", \\\"{x:1256,y:725,t:1527876594029};\\\", \\\"{x:1255,y:723,t:1527876594046};\\\", \\\"{x:1255,y:722,t:1527876594086};\\\", \\\"{x:1254,y:720,t:1527876594111};\\\", \\\"{x:1254,y:719,t:1527876594143};\\\", \\\"{x:1254,y:718,t:1527876594151};\\\", \\\"{x:1254,y:717,t:1527876594183};\\\", \\\"{x:1252,y:715,t:1527876594199};\\\", \\\"{x:1252,y:714,t:1527876594215};\\\", \\\"{x:1252,y:713,t:1527876594239};\\\", \\\"{x:1252,y:711,t:1527876594255};\\\", \\\"{x:1252,y:710,t:1527876594278};\\\", \\\"{x:1251,y:710,t:1527876594286};\\\", \\\"{x:1250,y:709,t:1527876594407};\\\", \\\"{x:1245,y:709,t:1527876594415};\\\", \\\"{x:1233,y:720,t:1527876594431};\\\", \\\"{x:1214,y:740,t:1527876594447};\\\", \\\"{x:1194,y:757,t:1527876594464};\\\", \\\"{x:1178,y:768,t:1527876594481};\\\", \\\"{x:1152,y:782,t:1527876594497};\\\", \\\"{x:1110,y:799,t:1527876594514};\\\", \\\"{x:1052,y:815,t:1527876594531};\\\", \\\"{x:966,y:827,t:1527876594547};\\\", \\\"{x:880,y:836,t:1527876594563};\\\", \\\"{x:818,y:839,t:1527876594580};\\\", \\\"{x:749,y:846,t:1527876594597};\\\", \\\"{x:716,y:846,t:1527876594613};\\\", \\\"{x:678,y:846,t:1527876594630};\\\", \\\"{x:656,y:847,t:1527876594647};\\\", \\\"{x:634,y:851,t:1527876594663};\\\", \\\"{x:622,y:852,t:1527876594681};\\\", \\\"{x:605,y:855,t:1527876594697};\\\", \\\"{x:591,y:856,t:1527876594713};\\\", \\\"{x:577,y:856,t:1527876594730};\\\", \\\"{x:556,y:850,t:1527876594748};\\\", \\\"{x:540,y:843,t:1527876594763};\\\", \\\"{x:527,y:836,t:1527876594780};\\\", \\\"{x:513,y:824,t:1527876594797};\\\", \\\"{x:502,y:807,t:1527876594813};\\\", \\\"{x:498,y:792,t:1527876594830};\\\", \\\"{x:498,y:790,t:1527876594848};\\\", \\\"{x:500,y:785,t:1527876594863};\\\", \\\"{x:502,y:782,t:1527876594880};\\\", \\\"{x:502,y:780,t:1527876594897};\\\", \\\"{x:502,y:778,t:1527876594913};\\\", \\\"{x:502,y:774,t:1527876594930};\\\", \\\"{x:505,y:769,t:1527876594948};\\\", \\\"{x:506,y:761,t:1527876594963};\\\", \\\"{x:507,y:753,t:1527876594981};\\\", \\\"{x:509,y:749,t:1527876594997};\\\", \\\"{x:510,y:746,t:1527876595015};\\\", \\\"{x:510,y:744,t:1527876595032};\\\", \\\"{x:510,y:743,t:1527876595055};\\\", \\\"{x:510,y:741,t:1527876595065};\\\", \\\"{x:511,y:739,t:1527876595081};\\\", \\\"{x:512,y:739,t:1527876595358};\\\", \\\"{x:513,y:741,t:1527876595511};\\\", \\\"{x:513,y:743,t:1527876595518};\\\", \\\"{x:514,y:746,t:1527876595531};\\\", \\\"{x:516,y:749,t:1527876595547};\\\", \\\"{x:517,y:755,t:1527876595564};\\\", \\\"{x:520,y:760,t:1527876595582};\\\", \\\"{x:523,y:762,t:1527876595597};\\\", \\\"{x:525,y:768,t:1527876595614};\\\", \\\"{x:530,y:776,t:1527876595631};\\\", \\\"{x:538,y:785,t:1527876595647};\\\", \\\"{x:545,y:792,t:1527876595664};\\\", \\\"{x:551,y:796,t:1527876595681};\\\", \\\"{x:559,y:800,t:1527876595699};\\\", \\\"{x:568,y:802,t:1527876595714};\\\", \\\"{x:577,y:806,t:1527876595731};\\\", \\\"{x:588,y:808,t:1527876595747};\\\", \\\"{x:604,y:811,t:1527876595764};\\\", \\\"{x:620,y:818,t:1527876595781};\\\", \\\"{x:647,y:821,t:1527876595798};\\\", \\\"{x:666,y:828,t:1527876595815};\\\", \\\"{x:675,y:832,t:1527876595832};\\\", \\\"{x:687,y:837,t:1527876595848};\\\", \\\"{x:703,y:839,t:1527876595864};\\\", \\\"{x:708,y:841,t:1527876595881};\\\", \\\"{x:717,y:843,t:1527876595898};\\\", \\\"{x:719,y:844,t:1527876595914};\\\", \\\"{x:721,y:845,t:1527876595931};\\\" ] }, { \\\"rt\\\": 11850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 213930, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:721,y:844,t:1527876597199};\\\", \\\"{x:721,y:843,t:1527876597230};\\\", \\\"{x:722,y:848,t:1527876599230};\\\", \\\"{x:728,y:852,t:1527876599239};\\\", \\\"{x:733,y:854,t:1527876599251};\\\", \\\"{x:751,y:862,t:1527876599268};\\\", \\\"{x:767,y:868,t:1527876599285};\\\", \\\"{x:786,y:874,t:1527876599300};\\\", \\\"{x:800,y:879,t:1527876599317};\\\", \\\"{x:818,y:884,t:1527876599334};\\\", \\\"{x:831,y:889,t:1527876599351};\\\", \\\"{x:846,y:893,t:1527876599367};\\\", \\\"{x:862,y:899,t:1527876599384};\\\", \\\"{x:868,y:900,t:1527876599401};\\\", \\\"{x:871,y:904,t:1527876599417};\\\", \\\"{x:875,y:907,t:1527876599435};\\\", \\\"{x:883,y:909,t:1527876599451};\\\", \\\"{x:886,y:912,t:1527876599468};\\\", \\\"{x:894,y:915,t:1527876599485};\\\", \\\"{x:902,y:916,t:1527876599500};\\\", \\\"{x:910,y:919,t:1527876599517};\\\", \\\"{x:927,y:927,t:1527876599534};\\\", \\\"{x:940,y:931,t:1527876599550};\\\", \\\"{x:952,y:935,t:1527876599568};\\\", \\\"{x:970,y:938,t:1527876599584};\\\", \\\"{x:992,y:944,t:1527876599602};\\\", \\\"{x:1012,y:949,t:1527876599618};\\\", \\\"{x:1026,y:952,t:1527876599635};\\\", \\\"{x:1038,y:957,t:1527876599651};\\\", \\\"{x:1052,y:962,t:1527876599668};\\\", \\\"{x:1066,y:966,t:1527876599686};\\\", \\\"{x:1076,y:970,t:1527876599701};\\\", \\\"{x:1082,y:973,t:1527876599717};\\\", \\\"{x:1089,y:978,t:1527876599734};\\\", \\\"{x:1090,y:979,t:1527876599751};\\\", \\\"{x:1093,y:981,t:1527876599768};\\\", \\\"{x:1095,y:983,t:1527876599784};\\\", \\\"{x:1097,y:985,t:1527876599802};\\\", \\\"{x:1098,y:986,t:1527876599818};\\\", \\\"{x:1099,y:986,t:1527876599834};\\\", \\\"{x:1100,y:988,t:1527876599851};\\\", \\\"{x:1100,y:991,t:1527876599868};\\\", \\\"{x:1101,y:992,t:1527876599887};\\\", \\\"{x:1107,y:986,t:1527876600535};\\\", \\\"{x:1133,y:960,t:1527876600552};\\\", \\\"{x:1176,y:927,t:1527876600569};\\\", \\\"{x:1220,y:887,t:1527876600585};\\\", \\\"{x:1235,y:870,t:1527876600602};\\\", \\\"{x:1271,y:846,t:1527876600619};\\\", \\\"{x:1290,y:829,t:1527876600635};\\\", \\\"{x:1301,y:815,t:1527876600652};\\\", \\\"{x:1308,y:799,t:1527876600669};\\\", \\\"{x:1326,y:769,t:1527876600686};\\\", \\\"{x:1336,y:755,t:1527876600702};\\\", \\\"{x:1367,y:712,t:1527876600719};\\\", \\\"{x:1376,y:693,t:1527876600736};\\\", \\\"{x:1404,y:655,t:1527876600752};\\\", \\\"{x:1431,y:622,t:1527876600769};\\\", \\\"{x:1464,y:586,t:1527876600785};\\\", \\\"{x:1493,y:559,t:1527876600802};\\\", \\\"{x:1510,y:546,t:1527876600819};\\\", \\\"{x:1524,y:535,t:1527876600836};\\\", \\\"{x:1533,y:525,t:1527876600851};\\\", \\\"{x:1544,y:515,t:1527876600868};\\\", \\\"{x:1557,y:502,t:1527876600885};\\\", \\\"{x:1563,y:493,t:1527876600901};\\\", \\\"{x:1571,y:482,t:1527876600919};\\\", \\\"{x:1579,y:469,t:1527876600935};\\\", \\\"{x:1585,y:459,t:1527876600952};\\\", \\\"{x:1591,y:448,t:1527876600968};\\\", \\\"{x:1596,y:433,t:1527876600985};\\\", \\\"{x:1603,y:422,t:1527876601001};\\\", \\\"{x:1603,y:419,t:1527876601019};\\\", \\\"{x:1605,y:417,t:1527876601035};\\\", \\\"{x:1606,y:415,t:1527876601051};\\\", \\\"{x:1607,y:410,t:1527876601068};\\\", \\\"{x:1609,y:409,t:1527876601086};\\\", \\\"{x:1610,y:408,t:1527876601102};\\\", \\\"{x:1611,y:408,t:1527876601215};\\\", \\\"{x:1611,y:409,t:1527876601223};\\\", \\\"{x:1611,y:410,t:1527876601236};\\\", \\\"{x:1611,y:413,t:1527876601255};\\\", \\\"{x:1611,y:417,t:1527876601268};\\\", \\\"{x:1611,y:419,t:1527876601285};\\\", \\\"{x:1611,y:424,t:1527876601302};\\\", \\\"{x:1611,y:425,t:1527876601333};\\\", \\\"{x:1611,y:426,t:1527876601352};\\\", \\\"{x:1611,y:427,t:1527876601382};\\\", \\\"{x:1611,y:429,t:1527876605606};\\\", \\\"{x:1611,y:430,t:1527876605629};\\\", \\\"{x:1611,y:431,t:1527876605717};\\\", \\\"{x:1611,y:433,t:1527876605797};\\\", \\\"{x:1611,y:434,t:1527876605837};\\\", \\\"{x:1611,y:435,t:1527876605855};\\\", \\\"{x:1609,y:435,t:1527876605873};\\\", \\\"{x:1608,y:435,t:1527876605902};\\\", \\\"{x:1607,y:436,t:1527876605909};\\\", \\\"{x:1605,y:437,t:1527876605925};\\\", \\\"{x:1603,y:437,t:1527876605941};\\\", \\\"{x:1601,y:438,t:1527876605956};\\\", \\\"{x:1598,y:438,t:1527876605972};\\\", \\\"{x:1593,y:439,t:1527876605989};\\\", \\\"{x:1589,y:439,t:1527876606005};\\\", \\\"{x:1580,y:442,t:1527876606022};\\\", \\\"{x:1574,y:442,t:1527876606040};\\\", \\\"{x:1569,y:443,t:1527876606056};\\\", \\\"{x:1567,y:443,t:1527876606072};\\\", \\\"{x:1566,y:443,t:1527876606090};\\\", \\\"{x:1560,y:445,t:1527876606106};\\\", \\\"{x:1554,y:446,t:1527876606122};\\\", \\\"{x:1547,y:446,t:1527876606139};\\\", \\\"{x:1540,y:446,t:1527876606156};\\\", \\\"{x:1525,y:446,t:1527876606173};\\\", \\\"{x:1490,y:445,t:1527876606189};\\\", \\\"{x:1469,y:445,t:1527876606206};\\\", \\\"{x:1447,y:444,t:1527876606223};\\\", \\\"{x:1422,y:444,t:1527876606240};\\\", \\\"{x:1406,y:444,t:1527876606257};\\\", \\\"{x:1397,y:444,t:1527876606273};\\\", \\\"{x:1376,y:444,t:1527876606290};\\\", \\\"{x:1356,y:450,t:1527876606306};\\\", \\\"{x:1321,y:457,t:1527876606323};\\\", \\\"{x:1269,y:476,t:1527876606340};\\\", \\\"{x:1209,y:498,t:1527876606356};\\\", \\\"{x:1073,y:539,t:1527876606373};\\\", \\\"{x:1043,y:549,t:1527876606389};\\\", \\\"{x:949,y:573,t:1527876606407};\\\", \\\"{x:855,y:598,t:1527876606424};\\\", \\\"{x:779,y:611,t:1527876606439};\\\", \\\"{x:720,y:631,t:1527876606457};\\\", \\\"{x:697,y:640,t:1527876606473};\\\", \\\"{x:666,y:657,t:1527876606490};\\\", \\\"{x:641,y:672,t:1527876606506};\\\", \\\"{x:625,y:683,t:1527876606524};\\\", \\\"{x:618,y:689,t:1527876606540};\\\", \\\"{x:609,y:696,t:1527876606556};\\\", \\\"{x:604,y:699,t:1527876606574};\\\", \\\"{x:604,y:696,t:1527876606646};\\\", \\\"{x:604,y:693,t:1527876606656};\\\", \\\"{x:606,y:687,t:1527876606673};\\\", \\\"{x:609,y:679,t:1527876606691};\\\", \\\"{x:613,y:670,t:1527876606707};\\\", \\\"{x:621,y:658,t:1527876606723};\\\", \\\"{x:627,y:648,t:1527876606741};\\\", \\\"{x:628,y:646,t:1527876606757};\\\", \\\"{x:632,y:641,t:1527876606774};\\\", \\\"{x:635,y:638,t:1527876606790};\\\", \\\"{x:636,y:637,t:1527876606806};\\\", \\\"{x:637,y:637,t:1527876606854};\\\", \\\"{x:638,y:637,t:1527876606862};\\\", \\\"{x:642,y:634,t:1527876606873};\\\", \\\"{x:653,y:632,t:1527876606891};\\\", \\\"{x:668,y:628,t:1527876606907};\\\", \\\"{x:684,y:627,t:1527876606923};\\\", \\\"{x:700,y:627,t:1527876606941};\\\", \\\"{x:721,y:624,t:1527876606957};\\\", \\\"{x:745,y:624,t:1527876606975};\\\", \\\"{x:756,y:624,t:1527876606991};\\\", \\\"{x:760,y:624,t:1527876607006};\\\", \\\"{x:762,y:624,t:1527876607023};\\\", \\\"{x:763,y:624,t:1527876607041};\\\", \\\"{x:769,y:624,t:1527876607056};\\\", \\\"{x:779,y:624,t:1527876607073};\\\", \\\"{x:782,y:624,t:1527876607091};\\\", \\\"{x:790,y:624,t:1527876607106};\\\", \\\"{x:796,y:624,t:1527876607123};\\\", \\\"{x:806,y:622,t:1527876607141};\\\", \\\"{x:807,y:620,t:1527876607156};\\\", \\\"{x:813,y:618,t:1527876607174};\\\", \\\"{x:817,y:616,t:1527876607190};\\\", \\\"{x:820,y:614,t:1527876607207};\\\", \\\"{x:824,y:611,t:1527876607223};\\\", \\\"{x:829,y:608,t:1527876607242};\\\", \\\"{x:833,y:605,t:1527876607258};\\\", \\\"{x:836,y:604,t:1527876607273};\\\", \\\"{x:838,y:602,t:1527876607290};\\\", \\\"{x:840,y:601,t:1527876607307};\\\", \\\"{x:840,y:600,t:1527876607323};\\\", \\\"{x:844,y:597,t:1527876607340};\\\", \\\"{x:849,y:593,t:1527876607357};\\\", \\\"{x:850,y:592,t:1527876607374};\\\", \\\"{x:850,y:591,t:1527876607441};\\\", \\\"{x:850,y:591,t:1527876607554};\\\", \\\"{x:844,y:596,t:1527876607630};\\\", \\\"{x:839,y:601,t:1527876607640};\\\", \\\"{x:821,y:612,t:1527876607657};\\\", \\\"{x:800,y:624,t:1527876607675};\\\", \\\"{x:776,y:635,t:1527876607690};\\\", \\\"{x:765,y:641,t:1527876607707};\\\", \\\"{x:751,y:649,t:1527876607726};\\\", \\\"{x:741,y:655,t:1527876607740};\\\", \\\"{x:726,y:666,t:1527876607757};\\\", \\\"{x:715,y:672,t:1527876607775};\\\", \\\"{x:707,y:680,t:1527876607790};\\\", \\\"{x:692,y:687,t:1527876607808};\\\", \\\"{x:682,y:694,t:1527876607825};\\\", \\\"{x:674,y:699,t:1527876607841};\\\", \\\"{x:668,y:703,t:1527876607857};\\\", \\\"{x:666,y:704,t:1527876607875};\\\", \\\"{x:664,y:706,t:1527876607890};\\\", \\\"{x:657,y:710,t:1527876607907};\\\", \\\"{x:655,y:711,t:1527876607925};\\\", \\\"{x:649,y:715,t:1527876607941};\\\", \\\"{x:643,y:718,t:1527876607957};\\\", \\\"{x:640,y:718,t:1527876607975};\\\", \\\"{x:634,y:722,t:1527876607990};\\\", \\\"{x:629,y:724,t:1527876608008};\\\", \\\"{x:618,y:732,t:1527876608025};\\\", \\\"{x:607,y:737,t:1527876608041};\\\", \\\"{x:599,y:740,t:1527876608057};\\\", \\\"{x:592,y:744,t:1527876608075};\\\", \\\"{x:584,y:747,t:1527876608091};\\\", \\\"{x:582,y:748,t:1527876608108};\\\", \\\"{x:582,y:749,t:1527876608125};\\\", \\\"{x:581,y:750,t:1527876608140};\\\", \\\"{x:580,y:751,t:1527876608157};\\\", \\\"{x:573,y:752,t:1527876608174};\\\", \\\"{x:568,y:752,t:1527876608192};\\\", \\\"{x:563,y:752,t:1527876608208};\\\", \\\"{x:562,y:752,t:1527876608224};\\\", \\\"{x:561,y:752,t:1527876608326};\\\", \\\"{x:560,y:752,t:1527876608333};\\\", \\\"{x:556,y:753,t:1527876608357};\\\", \\\"{x:554,y:753,t:1527876608374};\\\", \\\"{x:553,y:754,t:1527876608391};\\\", \\\"{x:556,y:752,t:1527876608646};\\\", \\\"{x:558,y:751,t:1527876608659};\\\", \\\"{x:569,y:747,t:1527876608676};\\\", \\\"{x:584,y:743,t:1527876608692};\\\", \\\"{x:595,y:738,t:1527876608709};\\\", \\\"{x:624,y:735,t:1527876608726};\\\", \\\"{x:640,y:731,t:1527876608742};\\\", \\\"{x:655,y:729,t:1527876608759};\\\", \\\"{x:664,y:729,t:1527876608776};\\\", \\\"{x:671,y:728,t:1527876608792};\\\", \\\"{x:673,y:727,t:1527876608809};\\\", \\\"{x:679,y:726,t:1527876608826};\\\", \\\"{x:684,y:726,t:1527876608842};\\\", \\\"{x:687,y:726,t:1527876608859};\\\", \\\"{x:688,y:724,t:1527876608875};\\\", \\\"{x:690,y:724,t:1527876608892};\\\", \\\"{x:691,y:724,t:1527876608950};\\\", \\\"{x:692,y:723,t:1527876608959};\\\", \\\"{x:693,y:723,t:1527876608975};\\\", \\\"{x:696,y:723,t:1527876608992};\\\", \\\"{x:698,y:723,t:1527876609014};\\\", \\\"{x:700,y:723,t:1527876609038};\\\", \\\"{x:703,y:723,t:1527876609046};\\\", \\\"{x:706,y:721,t:1527876609059};\\\", \\\"{x:711,y:721,t:1527876609075};\\\", \\\"{x:722,y:720,t:1527876609093};\\\", \\\"{x:729,y:720,t:1527876609108};\\\", \\\"{x:741,y:720,t:1527876609126};\\\", \\\"{x:749,y:720,t:1527876609142};\\\", \\\"{x:756,y:720,t:1527876609159};\\\", \\\"{x:758,y:720,t:1527876609175};\\\", \\\"{x:760,y:720,t:1527876609192};\\\" ] }, { \\\"rt\\\": 30285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 245478, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -C -C -C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:762,y:720,t:1527876612359};\\\", \\\"{x:765,y:722,t:1527876612366};\\\", \\\"{x:771,y:728,t:1527876612377};\\\", \\\"{x:782,y:734,t:1527876612395};\\\", \\\"{x:795,y:740,t:1527876612411};\\\", \\\"{x:810,y:745,t:1527876612428};\\\", \\\"{x:828,y:752,t:1527876612445};\\\", \\\"{x:837,y:752,t:1527876612461};\\\", \\\"{x:869,y:763,t:1527876612477};\\\", \\\"{x:911,y:774,t:1527876612494};\\\", \\\"{x:949,y:786,t:1527876612511};\\\", \\\"{x:976,y:794,t:1527876612528};\\\", \\\"{x:996,y:798,t:1527876612545};\\\", \\\"{x:1006,y:804,t:1527876612561};\\\", \\\"{x:1022,y:808,t:1527876612577};\\\", \\\"{x:1037,y:810,t:1527876612595};\\\", \\\"{x:1054,y:816,t:1527876612611};\\\", \\\"{x:1068,y:819,t:1527876612628};\\\", \\\"{x:1087,y:823,t:1527876612645};\\\", \\\"{x:1100,y:831,t:1527876612661};\\\", \\\"{x:1109,y:837,t:1527876612678};\\\", \\\"{x:1118,y:843,t:1527876612695};\\\", \\\"{x:1121,y:845,t:1527876612712};\\\", \\\"{x:1127,y:848,t:1527876612728};\\\", \\\"{x:1128,y:848,t:1527876612745};\\\", \\\"{x:1129,y:849,t:1527876612847};\\\", \\\"{x:1129,y:850,t:1527876612903};\\\", \\\"{x:1129,y:851,t:1527876612912};\\\", \\\"{x:1126,y:853,t:1527876612929};\\\", \\\"{x:1122,y:853,t:1527876612945};\\\", \\\"{x:1115,y:853,t:1527876612962};\\\", \\\"{x:1100,y:853,t:1527876612978};\\\", \\\"{x:1085,y:853,t:1527876612995};\\\", \\\"{x:1071,y:853,t:1527876613012};\\\", \\\"{x:1061,y:852,t:1527876613028};\\\", \\\"{x:1058,y:852,t:1527876613046};\\\", \\\"{x:1058,y:851,t:1527876613070};\\\", \\\"{x:1058,y:850,t:1527876613127};\\\", \\\"{x:1058,y:849,t:1527876613150};\\\", \\\"{x:1058,y:848,t:1527876613162};\\\", \\\"{x:1059,y:848,t:1527876613207};\\\", \\\"{x:1063,y:848,t:1527876613214};\\\", \\\"{x:1070,y:847,t:1527876613230};\\\", \\\"{x:1086,y:847,t:1527876613246};\\\", \\\"{x:1124,y:847,t:1527876613262};\\\", \\\"{x:1146,y:847,t:1527876613278};\\\", \\\"{x:1164,y:847,t:1527876613295};\\\", \\\"{x:1203,y:846,t:1527876613312};\\\", \\\"{x:1247,y:837,t:1527876613329};\\\", \\\"{x:1289,y:816,t:1527876613346};\\\", \\\"{x:1306,y:805,t:1527876613363};\\\", \\\"{x:1329,y:788,t:1527876613379};\\\", \\\"{x:1360,y:769,t:1527876613396};\\\", \\\"{x:1389,y:752,t:1527876613412};\\\", \\\"{x:1406,y:738,t:1527876613430};\\\", \\\"{x:1428,y:720,t:1527876613445};\\\", \\\"{x:1447,y:696,t:1527876613462};\\\", \\\"{x:1454,y:683,t:1527876613480};\\\", \\\"{x:1465,y:670,t:1527876613496};\\\", \\\"{x:1476,y:662,t:1527876613512};\\\", \\\"{x:1486,y:648,t:1527876613529};\\\", \\\"{x:1500,y:630,t:1527876613546};\\\", \\\"{x:1509,y:619,t:1527876613562};\\\", \\\"{x:1519,y:607,t:1527876613580};\\\", \\\"{x:1524,y:600,t:1527876613595};\\\", \\\"{x:1525,y:598,t:1527876613612};\\\", \\\"{x:1527,y:597,t:1527876613639};\\\", \\\"{x:1528,y:598,t:1527876613710};\\\", \\\"{x:1530,y:605,t:1527876613718};\\\", \\\"{x:1530,y:612,t:1527876613729};\\\", \\\"{x:1524,y:631,t:1527876613746};\\\", \\\"{x:1519,y:647,t:1527876613763};\\\", \\\"{x:1514,y:664,t:1527876613779};\\\", \\\"{x:1502,y:687,t:1527876613796};\\\", \\\"{x:1489,y:705,t:1527876613812};\\\", \\\"{x:1474,y:724,t:1527876613829};\\\", \\\"{x:1449,y:754,t:1527876613846};\\\", \\\"{x:1426,y:775,t:1527876613862};\\\", \\\"{x:1404,y:792,t:1527876613880};\\\", \\\"{x:1387,y:804,t:1527876613896};\\\", \\\"{x:1368,y:816,t:1527876613912};\\\", \\\"{x:1354,y:824,t:1527876613929};\\\", \\\"{x:1346,y:827,t:1527876613947};\\\", \\\"{x:1344,y:828,t:1527876613963};\\\", \\\"{x:1342,y:829,t:1527876613982};\\\", \\\"{x:1341,y:829,t:1527876613997};\\\", \\\"{x:1340,y:829,t:1527876614012};\\\", \\\"{x:1339,y:830,t:1527876614030};\\\", \\\"{x:1338,y:831,t:1527876614047};\\\", \\\"{x:1337,y:831,t:1527876614063};\\\", \\\"{x:1336,y:832,t:1527876614080};\\\", \\\"{x:1330,y:834,t:1527876614096};\\\", \\\"{x:1321,y:837,t:1527876614114};\\\", \\\"{x:1309,y:842,t:1527876614129};\\\", \\\"{x:1301,y:847,t:1527876614146};\\\", \\\"{x:1280,y:853,t:1527876614164};\\\", \\\"{x:1267,y:859,t:1527876614179};\\\", \\\"{x:1252,y:862,t:1527876614196};\\\", \\\"{x:1242,y:864,t:1527876614213};\\\", \\\"{x:1230,y:866,t:1527876614230};\\\", \\\"{x:1216,y:866,t:1527876614247};\\\", \\\"{x:1208,y:866,t:1527876614264};\\\", \\\"{x:1200,y:864,t:1527876614280};\\\", \\\"{x:1198,y:864,t:1527876614296};\\\", \\\"{x:1197,y:863,t:1527876614839};\\\", \\\"{x:1197,y:862,t:1527876615118};\\\", \\\"{x:1197,y:861,t:1527876615133};\\\", \\\"{x:1197,y:860,t:1527876615166};\\\", \\\"{x:1199,y:859,t:1527876615190};\\\", \\\"{x:1199,y:858,t:1527876615222};\\\", \\\"{x:1200,y:857,t:1527876615238};\\\", \\\"{x:1200,y:856,t:1527876615294};\\\", \\\"{x:1201,y:855,t:1527876615311};\\\", \\\"{x:1201,y:854,t:1527876615318};\\\", \\\"{x:1201,y:853,t:1527876615351};\\\", \\\"{x:1202,y:852,t:1527876615366};\\\", \\\"{x:1202,y:851,t:1527876615398};\\\", \\\"{x:1203,y:850,t:1527876615422};\\\", \\\"{x:1203,y:849,t:1527876615438};\\\", \\\"{x:1203,y:847,t:1527876616063};\\\", \\\"{x:1203,y:846,t:1527876616070};\\\", \\\"{x:1203,y:844,t:1527876616150};\\\", \\\"{x:1203,y:843,t:1527876616207};\\\", \\\"{x:1203,y:841,t:1527876616222};\\\", \\\"{x:1203,y:840,t:1527876616246};\\\", \\\"{x:1203,y:838,t:1527876616264};\\\", \\\"{x:1204,y:836,t:1527876616286};\\\", \\\"{x:1205,y:835,t:1527876616318};\\\", \\\"{x:1206,y:833,t:1527876616334};\\\", \\\"{x:1208,y:831,t:1527876616358};\\\", \\\"{x:1209,y:830,t:1527876616449};\\\", \\\"{x:1211,y:829,t:1527876616481};\\\", \\\"{x:1213,y:827,t:1527876616501};\\\", \\\"{x:1215,y:826,t:1527876616517};\\\", \\\"{x:1216,y:825,t:1527876616534};\\\", \\\"{x:1217,y:824,t:1527876616623};\\\", \\\"{x:1218,y:824,t:1527876616632};\\\", \\\"{x:1219,y:824,t:1527876616653};\\\", \\\"{x:1220,y:823,t:1527876616664};\\\", \\\"{x:1220,y:822,t:1527876616766};\\\", \\\"{x:1220,y:821,t:1527876617134};\\\", \\\"{x:1219,y:821,t:1527876617149};\\\", \\\"{x:1218,y:822,t:1527876617174};\\\", \\\"{x:1217,y:822,t:1527876617263};\\\", \\\"{x:1216,y:823,t:1527876617278};\\\", \\\"{x:1216,y:824,t:1527876617366};\\\", \\\"{x:1215,y:824,t:1527876617406};\\\", \\\"{x:1215,y:825,t:1527876617426};\\\", \\\"{x:1213,y:826,t:1527876617431};\\\", \\\"{x:1213,y:827,t:1527876617453};\\\", \\\"{x:1212,y:827,t:1527876617485};\\\", \\\"{x:1212,y:828,t:1527876617499};\\\", \\\"{x:1211,y:829,t:1527876617517};\\\", \\\"{x:1209,y:831,t:1527876617533};\\\", \\\"{x:1208,y:831,t:1527876617583};\\\", \\\"{x:1207,y:832,t:1527876618183};\\\", \\\"{x:1207,y:833,t:1527876618200};\\\", \\\"{x:1206,y:833,t:1527876618216};\\\", \\\"{x:1206,y:834,t:1527876618335};\\\", \\\"{x:1206,y:835,t:1527876618350};\\\", \\\"{x:1206,y:836,t:1527876618423};\\\", \\\"{x:1206,y:837,t:1527876618542};\\\", \\\"{x:1206,y:838,t:1527876618566};\\\", \\\"{x:1206,y:839,t:1527876618583};\\\", \\\"{x:1206,y:840,t:1527876618614};\\\", \\\"{x:1206,y:841,t:1527876618622};\\\", \\\"{x:1206,y:842,t:1527876618638};\\\", \\\"{x:1205,y:843,t:1527876618654};\\\", \\\"{x:1205,y:844,t:1527876618670};\\\", \\\"{x:1207,y:841,t:1527876618895};\\\", \\\"{x:1208,y:840,t:1527876618902};\\\", \\\"{x:1208,y:838,t:1527876618917};\\\", \\\"{x:1208,y:837,t:1527876618933};\\\", \\\"{x:1210,y:836,t:1527876618951};\\\", \\\"{x:1211,y:836,t:1527876618967};\\\", \\\"{x:1211,y:835,t:1527876618983};\\\", \\\"{x:1212,y:833,t:1527876619004};\\\", \\\"{x:1214,y:831,t:1527876619016};\\\", \\\"{x:1216,y:827,t:1527876619032};\\\", \\\"{x:1218,y:826,t:1527876619049};\\\", \\\"{x:1218,y:825,t:1527876619066};\\\", \\\"{x:1218,y:824,t:1527876619736};\\\", \\\"{x:1218,y:818,t:1527876619750};\\\", \\\"{x:1218,y:813,t:1527876619767};\\\", \\\"{x:1218,y:807,t:1527876619784};\\\", \\\"{x:1218,y:799,t:1527876619801};\\\", \\\"{x:1218,y:796,t:1527876619817};\\\", \\\"{x:1218,y:792,t:1527876619834};\\\", \\\"{x:1218,y:789,t:1527876619851};\\\", \\\"{x:1218,y:787,t:1527876619867};\\\", \\\"{x:1218,y:783,t:1527876619884};\\\", \\\"{x:1217,y:780,t:1527876619901};\\\", \\\"{x:1216,y:778,t:1527876619917};\\\", \\\"{x:1216,y:776,t:1527876619934};\\\", \\\"{x:1214,y:773,t:1527876619951};\\\", \\\"{x:1213,y:769,t:1527876619967};\\\", \\\"{x:1213,y:766,t:1527876619984};\\\", \\\"{x:1212,y:766,t:1527876620001};\\\", \\\"{x:1212,y:764,t:1527876620021};\\\", \\\"{x:1212,y:763,t:1527876620781};\\\", \\\"{x:1212,y:761,t:1527876620789};\\\", \\\"{x:1212,y:760,t:1527876620805};\\\", \\\"{x:1212,y:758,t:1527876620820};\\\", \\\"{x:1212,y:757,t:1527876620837};\\\", \\\"{x:1212,y:755,t:1527876620851};\\\", \\\"{x:1212,y:753,t:1527876620868};\\\", \\\"{x:1212,y:746,t:1527876620885};\\\", \\\"{x:1212,y:742,t:1527876620901};\\\", \\\"{x:1212,y:736,t:1527876620918};\\\", \\\"{x:1212,y:732,t:1527876620935};\\\", \\\"{x:1212,y:728,t:1527876620951};\\\", \\\"{x:1212,y:724,t:1527876620968};\\\", \\\"{x:1212,y:723,t:1527876620985};\\\", \\\"{x:1212,y:722,t:1527876621000};\\\", \\\"{x:1213,y:721,t:1527876621018};\\\", \\\"{x:1213,y:719,t:1527876621037};\\\", \\\"{x:1213,y:718,t:1527876621052};\\\", \\\"{x:1213,y:715,t:1527876621068};\\\", \\\"{x:1213,y:711,t:1527876621085};\\\", \\\"{x:1212,y:708,t:1527876621101};\\\", \\\"{x:1211,y:707,t:1527876621126};\\\", \\\"{x:1211,y:706,t:1527876621135};\\\", \\\"{x:1210,y:704,t:1527876621152};\\\", \\\"{x:1210,y:703,t:1527876621169};\\\", \\\"{x:1209,y:701,t:1527876621190};\\\", \\\"{x:1209,y:700,t:1527876621214};\\\", \\\"{x:1209,y:698,t:1527876621222};\\\", \\\"{x:1209,y:696,t:1527876621238};\\\", \\\"{x:1209,y:695,t:1527876621253};\\\", \\\"{x:1209,y:694,t:1527876621269};\\\", \\\"{x:1209,y:693,t:1527876621285};\\\", \\\"{x:1208,y:692,t:1527876621302};\\\", \\\"{x:1207,y:692,t:1527876628767};\\\", \\\"{x:1206,y:694,t:1527876628775};\\\", \\\"{x:1206,y:699,t:1527876628792};\\\", \\\"{x:1206,y:709,t:1527876628808};\\\", \\\"{x:1206,y:716,t:1527876628825};\\\", \\\"{x:1206,y:724,t:1527876628842};\\\", \\\"{x:1206,y:735,t:1527876628859};\\\", \\\"{x:1207,y:746,t:1527876628875};\\\", \\\"{x:1210,y:755,t:1527876628892};\\\", \\\"{x:1213,y:764,t:1527876628908};\\\", \\\"{x:1217,y:777,t:1527876628925};\\\", \\\"{x:1225,y:794,t:1527876628942};\\\", \\\"{x:1228,y:805,t:1527876628958};\\\", \\\"{x:1228,y:808,t:1527876628975};\\\", \\\"{x:1236,y:818,t:1527876628991};\\\", \\\"{x:1240,y:833,t:1527876629008};\\\", \\\"{x:1244,y:841,t:1527876629024};\\\", \\\"{x:1247,y:851,t:1527876629041};\\\", \\\"{x:1251,y:861,t:1527876629058};\\\", \\\"{x:1252,y:865,t:1527876629074};\\\", \\\"{x:1253,y:870,t:1527876629092};\\\", \\\"{x:1254,y:875,t:1527876629108};\\\", \\\"{x:1254,y:878,t:1527876629124};\\\", \\\"{x:1254,y:879,t:1527876629142};\\\", \\\"{x:1254,y:880,t:1527876629254};\\\", \\\"{x:1252,y:880,t:1527876629262};\\\", \\\"{x:1249,y:880,t:1527876629275};\\\", \\\"{x:1247,y:879,t:1527876629291};\\\", \\\"{x:1242,y:875,t:1527876629309};\\\", \\\"{x:1236,y:871,t:1527876629325};\\\", \\\"{x:1223,y:862,t:1527876629342};\\\", \\\"{x:1216,y:856,t:1527876629359};\\\", \\\"{x:1212,y:855,t:1527876629376};\\\", \\\"{x:1208,y:850,t:1527876629391};\\\", \\\"{x:1206,y:848,t:1527876629408};\\\", \\\"{x:1205,y:846,t:1527876629425};\\\", \\\"{x:1205,y:844,t:1527876629441};\\\", \\\"{x:1205,y:842,t:1527876629459};\\\", \\\"{x:1205,y:838,t:1527876629475};\\\", \\\"{x:1205,y:837,t:1527876629491};\\\", \\\"{x:1205,y:833,t:1527876629509};\\\", \\\"{x:1206,y:829,t:1527876629525};\\\", \\\"{x:1206,y:826,t:1527876629542};\\\", \\\"{x:1206,y:824,t:1527876629558};\\\", \\\"{x:1206,y:823,t:1527876629576};\\\", \\\"{x:1206,y:822,t:1527876629958};\\\", \\\"{x:1207,y:822,t:1527876630030};\\\", \\\"{x:1208,y:822,t:1527876630271};\\\", \\\"{x:1209,y:822,t:1527876630278};\\\", \\\"{x:1211,y:822,t:1527876630398};\\\", \\\"{x:1213,y:822,t:1527876630830};\\\", \\\"{x:1213,y:823,t:1527876630893};\\\", \\\"{x:1213,y:825,t:1527876630919};\\\", \\\"{x:1213,y:826,t:1527876630926};\\\", \\\"{x:1214,y:827,t:1527876630943};\\\", \\\"{x:1215,y:828,t:1527876632766};\\\", \\\"{x:1221,y:830,t:1527876632779};\\\", \\\"{x:1230,y:830,t:1527876632794};\\\", \\\"{x:1244,y:830,t:1527876632810};\\\", \\\"{x:1252,y:830,t:1527876632827};\\\", \\\"{x:1267,y:830,t:1527876632844};\\\", \\\"{x:1275,y:830,t:1527876632861};\\\", \\\"{x:1277,y:830,t:1527876632879};\\\", \\\"{x:1278,y:830,t:1527876632894};\\\", \\\"{x:1279,y:830,t:1527876632973};\\\", \\\"{x:1281,y:830,t:1527876632989};\\\", \\\"{x:1284,y:830,t:1527876633013};\\\", \\\"{x:1285,y:830,t:1527876633029};\\\", \\\"{x:1289,y:829,t:1527876633046};\\\", \\\"{x:1289,y:827,t:1527876633069};\\\", \\\"{x:1290,y:827,t:1527876633078};\\\", \\\"{x:1291,y:827,t:1527876633095};\\\", \\\"{x:1292,y:826,t:1527876633112};\\\", \\\"{x:1294,y:824,t:1527876633173};\\\", \\\"{x:1295,y:823,t:1527876633230};\\\", \\\"{x:1296,y:822,t:1527876633286};\\\", \\\"{x:1297,y:822,t:1527876633488};\\\", \\\"{x:1298,y:822,t:1527876633506};\\\", \\\"{x:1299,y:822,t:1527876633521};\\\", \\\"{x:1299,y:823,t:1527876633539};\\\", \\\"{x:1300,y:824,t:1527876633556};\\\", \\\"{x:1300,y:825,t:1527876633575};\\\", \\\"{x:1301,y:825,t:1527876633589};\\\", \\\"{x:1301,y:827,t:1527876633605};\\\", \\\"{x:1301,y:830,t:1527876633621};\\\", \\\"{x:1301,y:832,t:1527876633638};\\\", \\\"{x:1303,y:834,t:1527876633655};\\\", \\\"{x:1305,y:835,t:1527876633671};\\\", \\\"{x:1305,y:836,t:1527876633688};\\\", \\\"{x:1306,y:837,t:1527876633710};\\\", \\\"{x:1307,y:838,t:1527876633759};\\\", \\\"{x:1308,y:838,t:1527876633772};\\\", \\\"{x:1311,y:838,t:1527876633791};\\\", \\\"{x:1313,y:839,t:1527876633805};\\\", \\\"{x:1314,y:839,t:1527876633822};\\\", \\\"{x:1317,y:840,t:1527876633838};\\\", \\\"{x:1321,y:840,t:1527876633856};\\\", \\\"{x:1323,y:840,t:1527876633872};\\\", \\\"{x:1326,y:840,t:1527876633912};\\\", \\\"{x:1327,y:840,t:1527876633935};\\\", \\\"{x:1328,y:840,t:1527876633991};\\\", \\\"{x:1330,y:841,t:1527876634006};\\\", \\\"{x:1331,y:841,t:1527876634022};\\\", \\\"{x:1332,y:841,t:1527876634070};\\\", \\\"{x:1333,y:841,t:1527876634086};\\\", \\\"{x:1334,y:841,t:1527876634111};\\\", \\\"{x:1336,y:841,t:1527876634159};\\\", \\\"{x:1337,y:840,t:1527876634172};\\\", \\\"{x:1338,y:840,t:1527876634191};\\\", \\\"{x:1339,y:840,t:1527876634231};\\\", \\\"{x:1340,y:839,t:1527876634271};\\\", \\\"{x:1342,y:839,t:1527876634391};\\\", \\\"{x:1343,y:838,t:1527876634439};\\\", \\\"{x:1344,y:838,t:1527876634463};\\\", \\\"{x:1345,y:837,t:1527876634472};\\\", \\\"{x:1346,y:837,t:1527876634495};\\\", \\\"{x:1346,y:836,t:1527876634510};\\\", \\\"{x:1347,y:836,t:1527876634560};\\\", \\\"{x:1349,y:836,t:1527876634584};\\\", \\\"{x:1349,y:835,t:1527876634599};\\\", \\\"{x:1350,y:833,t:1527876634688};\\\", \\\"{x:1351,y:833,t:1527876634704};\\\", \\\"{x:1351,y:832,t:1527876634784};\\\", \\\"{x:1351,y:831,t:1527876634807};\\\", \\\"{x:1352,y:830,t:1527876634943};\\\", \\\"{x:1352,y:829,t:1527876635024};\\\", \\\"{x:1352,y:828,t:1527876635136};\\\", \\\"{x:1353,y:827,t:1527876635160};\\\", \\\"{x:1353,y:828,t:1527876636415};\\\", \\\"{x:1352,y:829,t:1527876636424};\\\", \\\"{x:1347,y:831,t:1527876636441};\\\", \\\"{x:1344,y:833,t:1527876636458};\\\", \\\"{x:1341,y:833,t:1527876636474};\\\", \\\"{x:1340,y:833,t:1527876636491};\\\", \\\"{x:1331,y:835,t:1527876637079};\\\", \\\"{x:1322,y:835,t:1527876637092};\\\", \\\"{x:1293,y:835,t:1527876637109};\\\", \\\"{x:1260,y:835,t:1527876637126};\\\", \\\"{x:1202,y:827,t:1527876637143};\\\", \\\"{x:1155,y:822,t:1527876637159};\\\", \\\"{x:1116,y:814,t:1527876637175};\\\", \\\"{x:1097,y:809,t:1527876637193};\\\", \\\"{x:1094,y:807,t:1527876637208};\\\", \\\"{x:1093,y:807,t:1527876637231};\\\", \\\"{x:1093,y:806,t:1527876637242};\\\", \\\"{x:1093,y:804,t:1527876637259};\\\", \\\"{x:1093,y:801,t:1527876637276};\\\", \\\"{x:1091,y:798,t:1527876637293};\\\", \\\"{x:1091,y:796,t:1527876637309};\\\", \\\"{x:1088,y:793,t:1527876637325};\\\", \\\"{x:1084,y:790,t:1527876637342};\\\", \\\"{x:1079,y:787,t:1527876637358};\\\", \\\"{x:1074,y:782,t:1527876637375};\\\", \\\"{x:1066,y:779,t:1527876637393};\\\", \\\"{x:988,y:770,t:1527876637409};\\\", \\\"{x:969,y:769,t:1527876637428};\\\", \\\"{x:933,y:762,t:1527876637442};\\\", \\\"{x:911,y:758,t:1527876637460};\\\", \\\"{x:900,y:757,t:1527876637475};\\\", \\\"{x:895,y:755,t:1527876637492};\\\", \\\"{x:894,y:755,t:1527876637509};\\\", \\\"{x:892,y:755,t:1527876637525};\\\", \\\"{x:889,y:755,t:1527876637566};\\\", \\\"{x:887,y:755,t:1527876637575};\\\", \\\"{x:879,y:756,t:1527876637593};\\\", \\\"{x:878,y:756,t:1527876637609};\\\", \\\"{x:871,y:757,t:1527876637625};\\\", \\\"{x:863,y:757,t:1527876637643};\\\", \\\"{x:843,y:752,t:1527876637659};\\\", \\\"{x:816,y:750,t:1527876637675};\\\", \\\"{x:768,y:747,t:1527876637692};\\\", \\\"{x:743,y:746,t:1527876637710};\\\", \\\"{x:723,y:744,t:1527876637725};\\\", \\\"{x:707,y:742,t:1527876637743};\\\", \\\"{x:697,y:741,t:1527876637759};\\\", \\\"{x:695,y:741,t:1527876637776};\\\", \\\"{x:694,y:741,t:1527876637832};\\\", \\\"{x:693,y:741,t:1527876637842};\\\", \\\"{x:689,y:741,t:1527876637859};\\\", \\\"{x:676,y:741,t:1527876637877};\\\", \\\"{x:662,y:741,t:1527876637892};\\\", \\\"{x:642,y:741,t:1527876637910};\\\", \\\"{x:619,y:741,t:1527876637926};\\\", \\\"{x:580,y:735,t:1527876637943};\\\", \\\"{x:485,y:725,t:1527876637960};\\\", \\\"{x:450,y:722,t:1527876637977};\\\", \\\"{x:432,y:718,t:1527876637992};\\\", \\\"{x:405,y:712,t:1527876638010};\\\", \\\"{x:351,y:711,t:1527876638026};\\\", \\\"{x:336,y:711,t:1527876638042};\\\", \\\"{x:333,y:711,t:1527876638059};\\\", \\\"{x:332,y:710,t:1527876638076};\\\", \\\"{x:329,y:710,t:1527876638128};\\\", \\\"{x:325,y:710,t:1527876638144};\\\", \\\"{x:313,y:709,t:1527876638159};\\\", \\\"{x:290,y:703,t:1527876638177};\\\", \\\"{x:252,y:694,t:1527876638194};\\\", \\\"{x:184,y:671,t:1527876638211};\\\", \\\"{x:146,y:651,t:1527876638227};\\\", \\\"{x:129,y:642,t:1527876638243};\\\", \\\"{x:119,y:633,t:1527876638258};\\\", \\\"{x:117,y:631,t:1527876638275};\\\", \\\"{x:117,y:630,t:1527876638292};\\\", \\\"{x:115,y:628,t:1527876638308};\\\", \\\"{x:115,y:627,t:1527876638325};\\\", \\\"{x:115,y:621,t:1527876638342};\\\", \\\"{x:113,y:619,t:1527876638358};\\\", \\\"{x:112,y:613,t:1527876638376};\\\", \\\"{x:112,y:612,t:1527876638393};\\\", \\\"{x:113,y:610,t:1527876638409};\\\", \\\"{x:115,y:607,t:1527876638426};\\\", \\\"{x:116,y:606,t:1527876638442};\\\", \\\"{x:123,y:606,t:1527876638459};\\\", \\\"{x:134,y:605,t:1527876638475};\\\", \\\"{x:143,y:605,t:1527876638492};\\\", \\\"{x:155,y:605,t:1527876638509};\\\", \\\"{x:164,y:605,t:1527876638525};\\\", \\\"{x:176,y:605,t:1527876638542};\\\", \\\"{x:181,y:605,t:1527876638558};\\\", \\\"{x:185,y:605,t:1527876638576};\\\", \\\"{x:186,y:605,t:1527876638606};\\\", \\\"{x:186,y:604,t:1527876638647};\\\", \\\"{x:187,y:604,t:1527876638671};\\\", \\\"{x:187,y:603,t:1527876638752};\\\", \\\"{x:187,y:602,t:1527876638759};\\\", \\\"{x:186,y:600,t:1527876638775};\\\", \\\"{x:180,y:597,t:1527876638793};\\\", \\\"{x:172,y:595,t:1527876638809};\\\", \\\"{x:168,y:594,t:1527876638827};\\\", \\\"{x:167,y:593,t:1527876638842};\\\", \\\"{x:164,y:593,t:1527876638859};\\\", \\\"{x:161,y:593,t:1527876638877};\\\", \\\"{x:157,y:593,t:1527876638893};\\\", \\\"{x:154,y:593,t:1527876638910};\\\", \\\"{x:155,y:593,t:1527876639207};\\\", \\\"{x:162,y:596,t:1527876639215};\\\", \\\"{x:172,y:598,t:1527876639226};\\\", \\\"{x:196,y:607,t:1527876639243};\\\", \\\"{x:219,y:615,t:1527876639260};\\\", \\\"{x:231,y:622,t:1527876639276};\\\", \\\"{x:252,y:636,t:1527876639292};\\\", \\\"{x:281,y:654,t:1527876639309};\\\", \\\"{x:319,y:672,t:1527876639327};\\\", \\\"{x:348,y:685,t:1527876639342};\\\", \\\"{x:372,y:697,t:1527876639360};\\\", \\\"{x:384,y:706,t:1527876639376};\\\", \\\"{x:399,y:712,t:1527876639392};\\\", \\\"{x:408,y:717,t:1527876639409};\\\", \\\"{x:413,y:720,t:1527876639427};\\\", \\\"{x:415,y:721,t:1527876639444};\\\", \\\"{x:416,y:722,t:1527876639494};\\\", \\\"{x:417,y:722,t:1527876639509};\\\", \\\"{x:417,y:723,t:1527876639526};\\\", \\\"{x:421,y:724,t:1527876639543};\\\", \\\"{x:427,y:727,t:1527876639559};\\\", \\\"{x:435,y:731,t:1527876639576};\\\", \\\"{x:448,y:735,t:1527876639594};\\\", \\\"{x:459,y:741,t:1527876639611};\\\", \\\"{x:465,y:745,t:1527876639626};\\\", \\\"{x:468,y:747,t:1527876639643};\\\", \\\"{x:472,y:749,t:1527876639659};\\\", \\\"{x:474,y:750,t:1527876639676};\\\", \\\"{x:475,y:750,t:1527876639793};\\\", \\\"{x:477,y:750,t:1527876639809};\\\", \\\"{x:478,y:750,t:1527876639864};\\\", \\\"{x:478,y:750,t:1527876639902};\\\" ] }, { \\\"rt\\\": 39539, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 286247, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-04 PM-04 PM-04 PM-04 PM-04 PM-02 PM-03 PM-04 PM-04 PM-04 PM-04 PM-04 PM-E -E -E -04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:748,t:1527876641110};\\\", \\\"{x:479,y:747,t:1527876641536};\\\", \\\"{x:479,y:746,t:1527876641551};\\\", \\\"{x:485,y:746,t:1527876641717};\\\", \\\"{x:486,y:746,t:1527876641727};\\\", \\\"{x:487,y:746,t:1527876641935};\\\", \\\"{x:489,y:748,t:1527876641975};\\\", \\\"{x:490,y:748,t:1527876641983};\\\", \\\"{x:490,y:749,t:1527876641995};\\\", \\\"{x:490,y:751,t:1527876642012};\\\", \\\"{x:491,y:753,t:1527876642029};\\\", \\\"{x:491,y:750,t:1527876642215};\\\", \\\"{x:493,y:749,t:1527876642228};\\\", \\\"{x:494,y:748,t:1527876642245};\\\", \\\"{x:494,y:744,t:1527876642262};\\\", \\\"{x:494,y:743,t:1527876642311};\\\", \\\"{x:494,y:746,t:1527876643151};\\\", \\\"{x:495,y:748,t:1527876643163};\\\", \\\"{x:497,y:754,t:1527876643179};\\\", \\\"{x:497,y:760,t:1527876643195};\\\", \\\"{x:497,y:768,t:1527876643213};\\\", \\\"{x:499,y:777,t:1527876643231};\\\", \\\"{x:504,y:784,t:1527876643245};\\\", \\\"{x:510,y:793,t:1527876643262};\\\", \\\"{x:518,y:796,t:1527876643279};\\\", \\\"{x:527,y:799,t:1527876643295};\\\", \\\"{x:536,y:801,t:1527876643313};\\\", \\\"{x:540,y:802,t:1527876643329};\\\", \\\"{x:551,y:806,t:1527876643346};\\\", \\\"{x:569,y:809,t:1527876643362};\\\", \\\"{x:589,y:814,t:1527876643379};\\\", \\\"{x:624,y:822,t:1527876643395};\\\", \\\"{x:654,y:829,t:1527876643413};\\\", \\\"{x:686,y:841,t:1527876643429};\\\", \\\"{x:756,y:867,t:1527876643445};\\\", \\\"{x:899,y:901,t:1527876643462};\\\", \\\"{x:1012,y:931,t:1527876643480};\\\", \\\"{x:1125,y:960,t:1527876643496};\\\", \\\"{x:1234,y:978,t:1527876643513};\\\", \\\"{x:1344,y:990,t:1527876643531};\\\", \\\"{x:1392,y:999,t:1527876643547};\\\", \\\"{x:1473,y:1006,t:1527876643563};\\\", \\\"{x:1546,y:1011,t:1527876643579};\\\", \\\"{x:1571,y:1011,t:1527876643597};\\\", \\\"{x:1587,y:1007,t:1527876643613};\\\", \\\"{x:1601,y:1002,t:1527876643629};\\\", \\\"{x:1615,y:995,t:1527876643647};\\\", \\\"{x:1615,y:992,t:1527876643663};\\\", \\\"{x:1616,y:986,t:1527876643679};\\\", \\\"{x:1616,y:981,t:1527876643697};\\\", \\\"{x:1616,y:979,t:1527876643713};\\\", \\\"{x:1616,y:978,t:1527876643729};\\\", \\\"{x:1616,y:976,t:1527876643747};\\\", \\\"{x:1615,y:974,t:1527876643766};\\\", \\\"{x:1614,y:973,t:1527876643780};\\\", \\\"{x:1609,y:971,t:1527876643796};\\\", \\\"{x:1606,y:970,t:1527876643812};\\\", \\\"{x:1604,y:969,t:1527876643829};\\\", \\\"{x:1594,y:968,t:1527876643846};\\\", \\\"{x:1585,y:968,t:1527876643863};\\\", \\\"{x:1579,y:968,t:1527876643879};\\\", \\\"{x:1572,y:968,t:1527876643897};\\\", \\\"{x:1570,y:968,t:1527876643912};\\\", \\\"{x:1569,y:968,t:1527876643959};\\\", \\\"{x:1569,y:969,t:1527876643975};\\\", \\\"{x:1569,y:970,t:1527876644000};\\\", \\\"{x:1570,y:971,t:1527876644014};\\\", \\\"{x:1570,y:972,t:1527876644030};\\\", \\\"{x:1572,y:972,t:1527876644063};\\\", \\\"{x:1575,y:972,t:1527876644080};\\\", \\\"{x:1580,y:972,t:1527876644097};\\\", \\\"{x:1583,y:972,t:1527876644116};\\\", \\\"{x:1584,y:972,t:1527876644130};\\\", \\\"{x:1590,y:972,t:1527876644147};\\\", \\\"{x:1594,y:972,t:1527876644164};\\\", \\\"{x:1599,y:972,t:1527876644180};\\\", \\\"{x:1601,y:972,t:1527876644197};\\\", \\\"{x:1602,y:972,t:1527876644214};\\\", \\\"{x:1604,y:972,t:1527876644239};\\\", \\\"{x:1606,y:971,t:1527876644271};\\\", \\\"{x:1607,y:971,t:1527876644344};\\\", \\\"{x:1608,y:971,t:1527876644367};\\\", \\\"{x:1610,y:971,t:1527876644424};\\\", \\\"{x:1611,y:971,t:1527876644439};\\\", \\\"{x:1611,y:970,t:1527876644871};\\\", \\\"{x:1614,y:969,t:1527876644887};\\\", \\\"{x:1615,y:969,t:1527876644952};\\\", \\\"{x:1615,y:968,t:1527876646784};\\\", \\\"{x:1615,y:966,t:1527876646848};\\\", \\\"{x:1615,y:965,t:1527876647648};\\\", \\\"{x:1615,y:963,t:1527876647656};\\\", \\\"{x:1615,y:961,t:1527876647679};\\\", \\\"{x:1615,y:959,t:1527876647696};\\\", \\\"{x:1615,y:958,t:1527876647712};\\\", \\\"{x:1615,y:956,t:1527876647719};\\\", \\\"{x:1615,y:955,t:1527876647734};\\\", \\\"{x:1615,y:953,t:1527876647749};\\\", \\\"{x:1616,y:952,t:1527876647766};\\\", \\\"{x:1616,y:949,t:1527876647783};\\\", \\\"{x:1616,y:947,t:1527876647807};\\\", \\\"{x:1617,y:946,t:1527876647823};\\\", \\\"{x:1617,y:945,t:1527876647839};\\\", \\\"{x:1618,y:942,t:1527876647855};\\\", \\\"{x:1618,y:940,t:1527876647903};\\\", \\\"{x:1619,y:938,t:1527876647916};\\\", \\\"{x:1619,y:937,t:1527876647933};\\\", \\\"{x:1619,y:936,t:1527876647950};\\\", \\\"{x:1619,y:934,t:1527876647966};\\\", \\\"{x:1619,y:933,t:1527876647983};\\\", \\\"{x:1619,y:932,t:1527876648000};\\\", \\\"{x:1619,y:931,t:1527876648016};\\\", \\\"{x:1619,y:930,t:1527876648033};\\\", \\\"{x:1619,y:928,t:1527876648055};\\\", \\\"{x:1619,y:927,t:1527876648066};\\\", \\\"{x:1619,y:926,t:1527876648083};\\\", \\\"{x:1619,y:925,t:1527876648103};\\\", \\\"{x:1619,y:924,t:1527876648119};\\\", \\\"{x:1619,y:923,t:1527876648143};\\\", \\\"{x:1619,y:922,t:1527876648151};\\\", \\\"{x:1619,y:921,t:1527876648167};\\\", \\\"{x:1621,y:917,t:1527876648183};\\\", \\\"{x:1621,y:914,t:1527876648200};\\\", \\\"{x:1621,y:910,t:1527876648216};\\\", \\\"{x:1621,y:904,t:1527876648234};\\\", \\\"{x:1621,y:902,t:1527876648250};\\\", \\\"{x:1621,y:901,t:1527876648266};\\\", \\\"{x:1621,y:900,t:1527876648407};\\\", \\\"{x:1621,y:899,t:1527876648423};\\\", \\\"{x:1621,y:898,t:1527876648433};\\\", \\\"{x:1621,y:896,t:1527876648451};\\\", \\\"{x:1620,y:892,t:1527876648468};\\\", \\\"{x:1620,y:887,t:1527876648483};\\\", \\\"{x:1619,y:886,t:1527876648500};\\\", \\\"{x:1618,y:884,t:1527876648518};\\\", \\\"{x:1618,y:883,t:1527876648534};\\\", \\\"{x:1617,y:882,t:1527876648550};\\\", \\\"{x:1617,y:881,t:1527876648567};\\\", \\\"{x:1617,y:880,t:1527876648584};\\\", \\\"{x:1617,y:879,t:1527876648631};\\\", \\\"{x:1617,y:878,t:1527876648639};\\\", \\\"{x:1616,y:878,t:1527876648650};\\\", \\\"{x:1615,y:876,t:1527876648667};\\\", \\\"{x:1615,y:875,t:1527876648703};\\\", \\\"{x:1614,y:873,t:1527876648719};\\\", \\\"{x:1613,y:871,t:1527876648751};\\\", \\\"{x:1613,y:870,t:1527876648775};\\\", \\\"{x:1611,y:868,t:1527876648784};\\\", \\\"{x:1611,y:867,t:1527876648800};\\\", \\\"{x:1611,y:865,t:1527876648818};\\\", \\\"{x:1611,y:864,t:1527876648834};\\\", \\\"{x:1611,y:861,t:1527876648896};\\\", \\\"{x:1611,y:860,t:1527876648903};\\\", \\\"{x:1610,y:860,t:1527876648927};\\\", \\\"{x:1610,y:857,t:1527876648943};\\\", \\\"{x:1608,y:855,t:1527876648976};\\\", \\\"{x:1607,y:853,t:1527876648999};\\\", \\\"{x:1607,y:855,t:1527876649392};\\\", \\\"{x:1607,y:857,t:1527876649401};\\\", \\\"{x:1606,y:867,t:1527876649417};\\\", \\\"{x:1606,y:877,t:1527876649434};\\\", \\\"{x:1606,y:889,t:1527876649452};\\\", \\\"{x:1607,y:898,t:1527876649467};\\\", \\\"{x:1609,y:910,t:1527876649484};\\\", \\\"{x:1610,y:925,t:1527876649501};\\\", \\\"{x:1612,y:937,t:1527876649518};\\\", \\\"{x:1612,y:943,t:1527876649534};\\\", \\\"{x:1613,y:954,t:1527876649551};\\\", \\\"{x:1613,y:961,t:1527876649567};\\\", \\\"{x:1613,y:965,t:1527876649584};\\\", \\\"{x:1614,y:969,t:1527876649601};\\\", \\\"{x:1613,y:977,t:1527876649617};\\\", \\\"{x:1613,y:982,t:1527876649634};\\\", \\\"{x:1613,y:989,t:1527876649652};\\\", \\\"{x:1613,y:992,t:1527876649668};\\\", \\\"{x:1613,y:994,t:1527876649684};\\\", \\\"{x:1613,y:992,t:1527876649840};\\\", \\\"{x:1613,y:989,t:1527876649852};\\\", \\\"{x:1613,y:983,t:1527876649869};\\\", \\\"{x:1613,y:980,t:1527876649884};\\\", \\\"{x:1614,y:974,t:1527876649901};\\\", \\\"{x:1614,y:971,t:1527876649918};\\\", \\\"{x:1615,y:966,t:1527876649935};\\\", \\\"{x:1616,y:965,t:1527876649951};\\\", \\\"{x:1617,y:963,t:1527876649968};\\\", \\\"{x:1617,y:962,t:1527876650008};\\\", \\\"{x:1617,y:961,t:1527876650018};\\\", \\\"{x:1617,y:960,t:1527876650039};\\\", \\\"{x:1617,y:959,t:1527876650051};\\\", \\\"{x:1617,y:958,t:1527876650069};\\\", \\\"{x:1617,y:957,t:1527876650084};\\\", \\\"{x:1617,y:956,t:1527876650103};\\\", \\\"{x:1617,y:955,t:1527876650151};\\\", \\\"{x:1617,y:956,t:1527876650439};\\\", \\\"{x:1617,y:957,t:1527876650452};\\\", \\\"{x:1617,y:959,t:1527876650469};\\\", \\\"{x:1617,y:961,t:1527876650485};\\\", \\\"{x:1617,y:962,t:1527876650501};\\\", \\\"{x:1617,y:963,t:1527876650592};\\\", \\\"{x:1617,y:964,t:1527876650696};\\\", \\\"{x:1617,y:965,t:1527876650736};\\\", \\\"{x:1617,y:966,t:1527876650753};\\\", \\\"{x:1617,y:967,t:1527876650768};\\\", \\\"{x:1617,y:970,t:1527876650786};\\\", \\\"{x:1616,y:970,t:1527876651038};\\\", \\\"{x:1615,y:968,t:1527876651062};\\\", \\\"{x:1615,y:967,t:1527876651070};\\\", \\\"{x:1615,y:966,t:1527876651084};\\\", \\\"{x:1614,y:964,t:1527876651102};\\\", \\\"{x:1613,y:960,t:1527876651117};\\\", \\\"{x:1613,y:958,t:1527876651134};\\\", \\\"{x:1612,y:956,t:1527876651152};\\\", \\\"{x:1612,y:954,t:1527876651169};\\\", \\\"{x:1612,y:952,t:1527876651214};\\\", \\\"{x:1612,y:951,t:1527876651238};\\\", \\\"{x:1611,y:949,t:1527876651254};\\\", \\\"{x:1611,y:947,t:1527876651279};\\\", \\\"{x:1610,y:947,t:1527876651286};\\\", \\\"{x:1610,y:946,t:1527876651302};\\\", \\\"{x:1609,y:945,t:1527876651319};\\\", \\\"{x:1609,y:944,t:1527876651335};\\\", \\\"{x:1609,y:943,t:1527876651367};\\\", \\\"{x:1609,y:941,t:1527876651407};\\\", \\\"{x:1608,y:941,t:1527876651431};\\\", \\\"{x:1608,y:939,t:1527876651447};\\\", \\\"{x:1608,y:938,t:1527876651471};\\\", \\\"{x:1608,y:936,t:1527876651487};\\\", \\\"{x:1608,y:934,t:1527876651503};\\\", \\\"{x:1607,y:931,t:1527876651519};\\\", \\\"{x:1607,y:930,t:1527876651535};\\\", \\\"{x:1606,y:928,t:1527876651552};\\\", \\\"{x:1606,y:927,t:1527876651582};\\\", \\\"{x:1606,y:926,t:1527876651606};\\\", \\\"{x:1606,y:925,t:1527876651630};\\\", \\\"{x:1606,y:924,t:1527876651646};\\\", \\\"{x:1606,y:923,t:1527876651663};\\\", \\\"{x:1606,y:922,t:1527876651678};\\\", \\\"{x:1606,y:921,t:1527876651694};\\\", \\\"{x:1606,y:920,t:1527876651702};\\\", \\\"{x:1606,y:919,t:1527876651719};\\\", \\\"{x:1606,y:917,t:1527876651736};\\\", \\\"{x:1606,y:913,t:1527876651752};\\\", \\\"{x:1606,y:909,t:1527876651768};\\\", \\\"{x:1606,y:906,t:1527876651786};\\\", \\\"{x:1607,y:903,t:1527876651802};\\\", \\\"{x:1607,y:900,t:1527876651819};\\\", \\\"{x:1608,y:896,t:1527876651836};\\\", \\\"{x:1608,y:891,t:1527876651853};\\\", \\\"{x:1609,y:886,t:1527876651869};\\\", \\\"{x:1610,y:884,t:1527876651886};\\\", \\\"{x:1610,y:878,t:1527876651902};\\\", \\\"{x:1610,y:876,t:1527876651918};\\\", \\\"{x:1611,y:875,t:1527876651935};\\\", \\\"{x:1613,y:871,t:1527876651952};\\\", \\\"{x:1613,y:868,t:1527876651968};\\\", \\\"{x:1613,y:863,t:1527876651986};\\\", \\\"{x:1613,y:860,t:1527876652001};\\\", \\\"{x:1614,y:855,t:1527876652019};\\\", \\\"{x:1614,y:853,t:1527876652036};\\\", \\\"{x:1614,y:850,t:1527876652051};\\\", \\\"{x:1614,y:848,t:1527876652068};\\\", \\\"{x:1615,y:845,t:1527876652086};\\\", \\\"{x:1617,y:842,t:1527876652102};\\\", \\\"{x:1617,y:839,t:1527876652119};\\\", \\\"{x:1617,y:836,t:1527876652136};\\\", \\\"{x:1617,y:833,t:1527876652154};\\\", \\\"{x:1617,y:831,t:1527876652169};\\\", \\\"{x:1615,y:826,t:1527876652186};\\\", \\\"{x:1615,y:825,t:1527876652203};\\\", \\\"{x:1615,y:822,t:1527876652219};\\\", \\\"{x:1614,y:820,t:1527876652237};\\\", \\\"{x:1614,y:818,t:1527876652253};\\\", \\\"{x:1614,y:815,t:1527876652270};\\\", \\\"{x:1613,y:813,t:1527876652286};\\\", \\\"{x:1613,y:811,t:1527876652303};\\\", \\\"{x:1612,y:808,t:1527876652319};\\\", \\\"{x:1612,y:806,t:1527876652337};\\\", \\\"{x:1612,y:805,t:1527876652354};\\\", \\\"{x:1611,y:801,t:1527876652369};\\\", \\\"{x:1611,y:799,t:1527876652387};\\\", \\\"{x:1610,y:796,t:1527876652404};\\\", \\\"{x:1610,y:795,t:1527876652420};\\\", \\\"{x:1610,y:791,t:1527876652437};\\\", \\\"{x:1610,y:789,t:1527876652453};\\\", \\\"{x:1610,y:786,t:1527876652469};\\\", \\\"{x:1610,y:783,t:1527876652487};\\\", \\\"{x:1610,y:778,t:1527876652503};\\\", \\\"{x:1609,y:774,t:1527876652521};\\\", \\\"{x:1609,y:772,t:1527876652536};\\\", \\\"{x:1609,y:769,t:1527876652553};\\\", \\\"{x:1609,y:766,t:1527876652571};\\\", \\\"{x:1607,y:763,t:1527876652587};\\\", \\\"{x:1607,y:762,t:1527876652604};\\\", \\\"{x:1607,y:760,t:1527876652620};\\\", \\\"{x:1607,y:759,t:1527876652636};\\\", \\\"{x:1607,y:756,t:1527876652654};\\\", \\\"{x:1607,y:754,t:1527876652670};\\\", \\\"{x:1607,y:752,t:1527876652687};\\\", \\\"{x:1606,y:749,t:1527876652703};\\\", \\\"{x:1605,y:740,t:1527876652720};\\\", \\\"{x:1605,y:732,t:1527876652736};\\\", \\\"{x:1603,y:728,t:1527876652753};\\\", \\\"{x:1603,y:724,t:1527876652769};\\\", \\\"{x:1602,y:721,t:1527876652786};\\\", \\\"{x:1602,y:719,t:1527876652803};\\\", \\\"{x:1602,y:717,t:1527876652819};\\\", \\\"{x:1600,y:711,t:1527876652836};\\\", \\\"{x:1599,y:707,t:1527876652853};\\\", \\\"{x:1597,y:703,t:1527876652870};\\\", \\\"{x:1597,y:701,t:1527876652886};\\\", \\\"{x:1594,y:696,t:1527876652903};\\\", \\\"{x:1594,y:693,t:1527876652920};\\\", \\\"{x:1593,y:692,t:1527876652936};\\\", \\\"{x:1592,y:691,t:1527876652954};\\\", \\\"{x:1589,y:689,t:1527876652970};\\\", \\\"{x:1589,y:687,t:1527876652986};\\\", \\\"{x:1588,y:684,t:1527876653003};\\\", \\\"{x:1588,y:682,t:1527876653038};\\\", \\\"{x:1588,y:680,t:1527876653054};\\\", \\\"{x:1588,y:678,t:1527876653070};\\\", \\\"{x:1586,y:676,t:1527876653087};\\\", \\\"{x:1585,y:675,t:1527876653103};\\\", \\\"{x:1585,y:673,t:1527876653120};\\\", \\\"{x:1585,y:672,t:1527876653137};\\\", \\\"{x:1585,y:670,t:1527876653154};\\\", \\\"{x:1585,y:669,t:1527876653171};\\\", \\\"{x:1585,y:666,t:1527876653187};\\\", \\\"{x:1585,y:664,t:1527876653203};\\\", \\\"{x:1585,y:661,t:1527876653221};\\\", \\\"{x:1585,y:659,t:1527876653236};\\\", \\\"{x:1585,y:657,t:1527876653252};\\\", \\\"{x:1585,y:654,t:1527876653270};\\\", \\\"{x:1583,y:650,t:1527876653286};\\\", \\\"{x:1583,y:647,t:1527876653303};\\\", \\\"{x:1583,y:641,t:1527876653320};\\\", \\\"{x:1583,y:635,t:1527876653337};\\\", \\\"{x:1583,y:629,t:1527876653352};\\\", \\\"{x:1582,y:623,t:1527876653370};\\\", \\\"{x:1582,y:615,t:1527876653387};\\\", \\\"{x:1582,y:601,t:1527876653403};\\\", \\\"{x:1582,y:592,t:1527876653420};\\\", \\\"{x:1579,y:585,t:1527876653437};\\\", \\\"{x:1579,y:580,t:1527876653453};\\\", \\\"{x:1579,y:577,t:1527876653470};\\\", \\\"{x:1579,y:572,t:1527876653487};\\\", \\\"{x:1578,y:566,t:1527876653504};\\\", \\\"{x:1578,y:562,t:1527876653521};\\\", \\\"{x:1578,y:555,t:1527876653538};\\\", \\\"{x:1577,y:551,t:1527876653554};\\\", \\\"{x:1575,y:547,t:1527876653570};\\\", \\\"{x:1575,y:543,t:1527876653587};\\\", \\\"{x:1575,y:536,t:1527876653604};\\\", \\\"{x:1575,y:533,t:1527876653620};\\\", \\\"{x:1575,y:528,t:1527876653637};\\\", \\\"{x:1575,y:526,t:1527876653654};\\\", \\\"{x:1576,y:524,t:1527876653671};\\\", \\\"{x:1576,y:521,t:1527876653687};\\\", \\\"{x:1576,y:519,t:1527876653705};\\\", \\\"{x:1576,y:518,t:1527876653720};\\\", \\\"{x:1576,y:517,t:1527876653737};\\\", \\\"{x:1576,y:516,t:1527876653754};\\\", \\\"{x:1576,y:515,t:1527876653775};\\\", \\\"{x:1578,y:514,t:1527876653799};\\\", \\\"{x:1578,y:513,t:1527876653823};\\\", \\\"{x:1578,y:512,t:1527876653847};\\\", \\\"{x:1578,y:513,t:1527876654919};\\\", \\\"{x:1578,y:514,t:1527876654983};\\\", \\\"{x:1578,y:515,t:1527876655072};\\\", \\\"{x:1576,y:515,t:1527876655424};\\\", \\\"{x:1575,y:516,t:1527876655918};\\\", \\\"{x:1575,y:519,t:1527876655950};\\\", \\\"{x:1573,y:520,t:1527876656087};\\\", \\\"{x:1572,y:521,t:1527876657655};\\\", \\\"{x:1572,y:522,t:1527876657673};\\\", \\\"{x:1571,y:522,t:1527876657689};\\\", \\\"{x:1570,y:523,t:1527876657706};\\\", \\\"{x:1569,y:524,t:1527876657742};\\\", \\\"{x:1568,y:525,t:1527876658039};\\\", \\\"{x:1567,y:526,t:1527876658079};\\\", \\\"{x:1566,y:527,t:1527876658095};\\\", \\\"{x:1566,y:528,t:1527876658160};\\\", \\\"{x:1566,y:529,t:1527876658272};\\\", \\\"{x:1565,y:531,t:1527876658279};\\\", \\\"{x:1565,y:533,t:1527876658326};\\\", \\\"{x:1565,y:534,t:1527876658342};\\\", \\\"{x:1563,y:537,t:1527876658356};\\\", \\\"{x:1563,y:540,t:1527876658374};\\\", \\\"{x:1563,y:543,t:1527876658390};\\\", \\\"{x:1563,y:546,t:1527876658407};\\\", \\\"{x:1562,y:548,t:1527876658424};\\\", \\\"{x:1561,y:553,t:1527876658440};\\\", \\\"{x:1560,y:559,t:1527876658457};\\\", \\\"{x:1559,y:565,t:1527876658474};\\\", \\\"{x:1556,y:572,t:1527876658491};\\\", \\\"{x:1553,y:579,t:1527876658507};\\\", \\\"{x:1551,y:587,t:1527876658524};\\\", \\\"{x:1548,y:598,t:1527876658540};\\\", \\\"{x:1544,y:612,t:1527876658557};\\\", \\\"{x:1540,y:643,t:1527876658575};\\\", \\\"{x:1538,y:665,t:1527876658590};\\\", \\\"{x:1534,y:694,t:1527876658607};\\\", \\\"{x:1532,y:725,t:1527876658624};\\\", \\\"{x:1521,y:771,t:1527876658640};\\\", \\\"{x:1510,y:826,t:1527876658657};\\\", \\\"{x:1498,y:873,t:1527876658674};\\\", \\\"{x:1488,y:914,t:1527876658690};\\\", \\\"{x:1480,y:942,t:1527876658707};\\\", \\\"{x:1474,y:974,t:1527876658725};\\\", \\\"{x:1466,y:998,t:1527876658741};\\\", \\\"{x:1463,y:1023,t:1527876658757};\\\", \\\"{x:1457,y:1055,t:1527876658775};\\\", \\\"{x:1452,y:1069,t:1527876658790};\\\", \\\"{x:1448,y:1080,t:1527876658807};\\\", \\\"{x:1445,y:1085,t:1527876658824};\\\", \\\"{x:1443,y:1094,t:1527876658841};\\\", \\\"{x:1439,y:1101,t:1527876658857};\\\", \\\"{x:1437,y:1106,t:1527876658874};\\\", \\\"{x:1435,y:1109,t:1527876658891};\\\", \\\"{x:1435,y:1110,t:1527876658907};\\\", \\\"{x:1436,y:1108,t:1527876659072};\\\", \\\"{x:1436,y:1107,t:1527876659095};\\\", \\\"{x:1436,y:1106,t:1527876659191};\\\", \\\"{x:1433,y:1104,t:1527876659551};\\\", \\\"{x:1432,y:1104,t:1527876659600};\\\", \\\"{x:1430,y:1102,t:1527876659623};\\\", \\\"{x:1428,y:1101,t:1527876659655};\\\", \\\"{x:1426,y:1101,t:1527876659663};\\\", \\\"{x:1425,y:1101,t:1527876659678};\\\", \\\"{x:1423,y:1099,t:1527876659695};\\\", \\\"{x:1422,y:1098,t:1527876659719};\\\", \\\"{x:1420,y:1097,t:1527876659726};\\\", \\\"{x:1418,y:1096,t:1527876659742};\\\", \\\"{x:1413,y:1094,t:1527876659759};\\\", \\\"{x:1410,y:1090,t:1527876659775};\\\", \\\"{x:1399,y:1087,t:1527876659792};\\\", \\\"{x:1394,y:1083,t:1527876659808};\\\", \\\"{x:1379,y:1076,t:1527876659826};\\\", \\\"{x:1366,y:1069,t:1527876659841};\\\", \\\"{x:1354,y:1065,t:1527876659859};\\\", \\\"{x:1342,y:1052,t:1527876659876};\\\", \\\"{x:1321,y:1041,t:1527876659891};\\\", \\\"{x:1304,y:1033,t:1527876659908};\\\", \\\"{x:1296,y:1030,t:1527876659926};\\\", \\\"{x:1291,y:1027,t:1527876659942};\\\", \\\"{x:1290,y:1026,t:1527876660007};\\\", \\\"{x:1290,y:1025,t:1527876660026};\\\", \\\"{x:1291,y:1020,t:1527876660042};\\\", \\\"{x:1294,y:1018,t:1527876660059};\\\", \\\"{x:1298,y:1016,t:1527876660075};\\\", \\\"{x:1306,y:1011,t:1527876660091};\\\", \\\"{x:1320,y:1005,t:1527876660108};\\\", \\\"{x:1336,y:1004,t:1527876660125};\\\", \\\"{x:1357,y:999,t:1527876660142};\\\", \\\"{x:1380,y:995,t:1527876660159};\\\", \\\"{x:1388,y:994,t:1527876660175};\\\", \\\"{x:1401,y:992,t:1527876660193};\\\", \\\"{x:1421,y:992,t:1527876660209};\\\", \\\"{x:1439,y:992,t:1527876660226};\\\", \\\"{x:1457,y:992,t:1527876660242};\\\", \\\"{x:1473,y:992,t:1527876660259};\\\", \\\"{x:1483,y:992,t:1527876660276};\\\", \\\"{x:1492,y:991,t:1527876660292};\\\", \\\"{x:1500,y:990,t:1527876660309};\\\", \\\"{x:1506,y:989,t:1527876660326};\\\", \\\"{x:1515,y:987,t:1527876660343};\\\", \\\"{x:1519,y:987,t:1527876660358};\\\", \\\"{x:1525,y:985,t:1527876660375};\\\", \\\"{x:1532,y:982,t:1527876660393};\\\", \\\"{x:1537,y:982,t:1527876660408};\\\", \\\"{x:1544,y:982,t:1527876660426};\\\", \\\"{x:1548,y:981,t:1527876660442};\\\", \\\"{x:1556,y:976,t:1527876660458};\\\", \\\"{x:1567,y:972,t:1527876660476};\\\", \\\"{x:1576,y:968,t:1527876660493};\\\", \\\"{x:1585,y:964,t:1527876660509};\\\", \\\"{x:1596,y:960,t:1527876660526};\\\", \\\"{x:1607,y:958,t:1527876660544};\\\", \\\"{x:1612,y:956,t:1527876660559};\\\", \\\"{x:1613,y:956,t:1527876660576};\\\", \\\"{x:1614,y:956,t:1527876660623};\\\", \\\"{x:1615,y:955,t:1527876660639};\\\", \\\"{x:1615,y:956,t:1527876660790};\\\", \\\"{x:1615,y:958,t:1527876660830};\\\", \\\"{x:1616,y:958,t:1527876660842};\\\", \\\"{x:1616,y:959,t:1527876660895};\\\", \\\"{x:1617,y:960,t:1527876660911};\\\", \\\"{x:1617,y:961,t:1527876660925};\\\", \\\"{x:1618,y:961,t:1527876660942};\\\", \\\"{x:1618,y:962,t:1527876660974};\\\", \\\"{x:1618,y:964,t:1527876660998};\\\", \\\"{x:1619,y:965,t:1527876661022};\\\", \\\"{x:1619,y:966,t:1527876661046};\\\", \\\"{x:1619,y:967,t:1527876661062};\\\", \\\"{x:1620,y:968,t:1527876661094};\\\", \\\"{x:1620,y:969,t:1527876662175};\\\", \\\"{x:1620,y:968,t:1527876662263};\\\", \\\"{x:1619,y:968,t:1527876662279};\\\", \\\"{x:1619,y:967,t:1527876662303};\\\", \\\"{x:1618,y:966,t:1527876662311};\\\", \\\"{x:1617,y:965,t:1527876662327};\\\", \\\"{x:1617,y:964,t:1527876662351};\\\", \\\"{x:1616,y:962,t:1527876662375};\\\", \\\"{x:1616,y:961,t:1527876662383};\\\", \\\"{x:1615,y:961,t:1527876662399};\\\", \\\"{x:1614,y:960,t:1527876662423};\\\", \\\"{x:1614,y:959,t:1527876662447};\\\", \\\"{x:1613,y:958,t:1527876662460};\\\", \\\"{x:1612,y:957,t:1527876662477};\\\", \\\"{x:1611,y:955,t:1527876662493};\\\", \\\"{x:1610,y:954,t:1527876662511};\\\", \\\"{x:1608,y:952,t:1527876662527};\\\", \\\"{x:1607,y:951,t:1527876662575};\\\", \\\"{x:1607,y:950,t:1527876662591};\\\", \\\"{x:1607,y:949,t:1527876662616};\\\", \\\"{x:1607,y:948,t:1527876662639};\\\", \\\"{x:1606,y:948,t:1527876662647};\\\", \\\"{x:1605,y:947,t:1527876662679};\\\", \\\"{x:1605,y:946,t:1527876662693};\\\", \\\"{x:1605,y:944,t:1527876662711};\\\", \\\"{x:1605,y:943,t:1527876662728};\\\", \\\"{x:1605,y:942,t:1527876662744};\\\", \\\"{x:1605,y:940,t:1527876662761};\\\", \\\"{x:1605,y:939,t:1527876662778};\\\", \\\"{x:1605,y:937,t:1527876662794};\\\", \\\"{x:1606,y:936,t:1527876662811};\\\", \\\"{x:1606,y:935,t:1527876662839};\\\", \\\"{x:1606,y:934,t:1527876662855};\\\", \\\"{x:1606,y:933,t:1527876662895};\\\", \\\"{x:1607,y:932,t:1527876662975};\\\", \\\"{x:1608,y:931,t:1527876662991};\\\", \\\"{x:1608,y:930,t:1527876663007};\\\", \\\"{x:1609,y:928,t:1527876663063};\\\", \\\"{x:1609,y:927,t:1527876663078};\\\", \\\"{x:1610,y:925,t:1527876663095};\\\", \\\"{x:1611,y:923,t:1527876663111};\\\", \\\"{x:1612,y:919,t:1527876663127};\\\", \\\"{x:1614,y:916,t:1527876663145};\\\", \\\"{x:1614,y:914,t:1527876663161};\\\", \\\"{x:1615,y:912,t:1527876663178};\\\", \\\"{x:1615,y:911,t:1527876663215};\\\", \\\"{x:1615,y:914,t:1527876663367};\\\", \\\"{x:1615,y:919,t:1527876663378};\\\", \\\"{x:1615,y:926,t:1527876663395};\\\", \\\"{x:1615,y:935,t:1527876663411};\\\", \\\"{x:1615,y:944,t:1527876663428};\\\", \\\"{x:1615,y:948,t:1527876663445};\\\", \\\"{x:1615,y:956,t:1527876663461};\\\", \\\"{x:1615,y:965,t:1527876663478};\\\", \\\"{x:1612,y:972,t:1527876663495};\\\", \\\"{x:1612,y:974,t:1527876663511};\\\", \\\"{x:1612,y:975,t:1527876663528};\\\", \\\"{x:1612,y:977,t:1527876663545};\\\", \\\"{x:1612,y:976,t:1527876663711};\\\", \\\"{x:1612,y:973,t:1527876663727};\\\", \\\"{x:1609,y:970,t:1527876663744};\\\", \\\"{x:1609,y:968,t:1527876663762};\\\", \\\"{x:1609,y:967,t:1527876663778};\\\", \\\"{x:1609,y:964,t:1527876663795};\\\", \\\"{x:1609,y:961,t:1527876663813};\\\", \\\"{x:1609,y:959,t:1527876663831};\\\", \\\"{x:1609,y:958,t:1527876663845};\\\", \\\"{x:1609,y:956,t:1527876663862};\\\", \\\"{x:1609,y:954,t:1527876663878};\\\", \\\"{x:1609,y:951,t:1527876663895};\\\", \\\"{x:1609,y:949,t:1527876663919};\\\", \\\"{x:1607,y:947,t:1527876664296};\\\", \\\"{x:1607,y:946,t:1527876664311};\\\", \\\"{x:1607,y:942,t:1527876664329};\\\", \\\"{x:1606,y:940,t:1527876664345};\\\", \\\"{x:1606,y:938,t:1527876664362};\\\", \\\"{x:1606,y:936,t:1527876664379};\\\", \\\"{x:1605,y:935,t:1527876664395};\\\", \\\"{x:1605,y:933,t:1527876664415};\\\", \\\"{x:1604,y:932,t:1527876664431};\\\", \\\"{x:1604,y:930,t:1527876664519};\\\", \\\"{x:1604,y:929,t:1527876664551};\\\", \\\"{x:1604,y:928,t:1527876664591};\\\", \\\"{x:1603,y:926,t:1527876664599};\\\", \\\"{x:1602,y:924,t:1527876664639};\\\", \\\"{x:1602,y:923,t:1527876664647};\\\", \\\"{x:1601,y:922,t:1527876664662};\\\", \\\"{x:1599,y:920,t:1527876664679};\\\", \\\"{x:1598,y:917,t:1527876664696};\\\", \\\"{x:1598,y:915,t:1527876664712};\\\", \\\"{x:1598,y:913,t:1527876664728};\\\", \\\"{x:1598,y:912,t:1527876664746};\\\", \\\"{x:1598,y:910,t:1527876664767};\\\", \\\"{x:1598,y:909,t:1527876664799};\\\", \\\"{x:1599,y:909,t:1527876664812};\\\", \\\"{x:1599,y:908,t:1527876664839};\\\", \\\"{x:1599,y:907,t:1527876664871};\\\", \\\"{x:1599,y:906,t:1527876664920};\\\", \\\"{x:1600,y:905,t:1527876664942};\\\", \\\"{x:1600,y:904,t:1527876664950};\\\", \\\"{x:1600,y:903,t:1527876664974};\\\", \\\"{x:1601,y:903,t:1527876664982};\\\", \\\"{x:1601,y:902,t:1527876664995};\\\", \\\"{x:1602,y:900,t:1527876665012};\\\", \\\"{x:1603,y:897,t:1527876665028};\\\", \\\"{x:1604,y:896,t:1527876665046};\\\", \\\"{x:1604,y:894,t:1527876665062};\\\", \\\"{x:1605,y:894,t:1527876665078};\\\", \\\"{x:1605,y:892,t:1527876665095};\\\", \\\"{x:1606,y:891,t:1527876665112};\\\", \\\"{x:1607,y:891,t:1527876665128};\\\", \\\"{x:1607,y:890,t:1527876665146};\\\", \\\"{x:1608,y:888,t:1527876665167};\\\", \\\"{x:1609,y:886,t:1527876665191};\\\", \\\"{x:1610,y:885,t:1527876665207};\\\", \\\"{x:1610,y:884,t:1527876665230};\\\", \\\"{x:1610,y:883,t:1527876665245};\\\", \\\"{x:1611,y:881,t:1527876665262};\\\", \\\"{x:1611,y:880,t:1527876665279};\\\", \\\"{x:1612,y:877,t:1527876665295};\\\", \\\"{x:1613,y:875,t:1527876665312};\\\", \\\"{x:1613,y:873,t:1527876665335};\\\", \\\"{x:1614,y:871,t:1527876665351};\\\", \\\"{x:1615,y:869,t:1527876665362};\\\", \\\"{x:1615,y:865,t:1527876665379};\\\", \\\"{x:1617,y:856,t:1527876665396};\\\", \\\"{x:1617,y:852,t:1527876665413};\\\", \\\"{x:1618,y:844,t:1527876665430};\\\", \\\"{x:1619,y:838,t:1527876665446};\\\", \\\"{x:1619,y:831,t:1527876665463};\\\", \\\"{x:1619,y:829,t:1527876665480};\\\", \\\"{x:1620,y:825,t:1527876665496};\\\", \\\"{x:1620,y:823,t:1527876665512};\\\", \\\"{x:1620,y:822,t:1527876665530};\\\", \\\"{x:1621,y:818,t:1527876665545};\\\", \\\"{x:1621,y:813,t:1527876665563};\\\", \\\"{x:1621,y:808,t:1527876665580};\\\", \\\"{x:1621,y:805,t:1527876665595};\\\", \\\"{x:1621,y:800,t:1527876665613};\\\", \\\"{x:1621,y:797,t:1527876665630};\\\", \\\"{x:1621,y:790,t:1527876665646};\\\", \\\"{x:1620,y:778,t:1527876665663};\\\", \\\"{x:1620,y:772,t:1527876665679};\\\", \\\"{x:1620,y:769,t:1527876665695};\\\", \\\"{x:1619,y:765,t:1527876665714};\\\", \\\"{x:1617,y:759,t:1527876665730};\\\", \\\"{x:1617,y:757,t:1527876665746};\\\", \\\"{x:1617,y:756,t:1527876665763};\\\", \\\"{x:1617,y:755,t:1527876665780};\\\", \\\"{x:1617,y:754,t:1527876665856};\\\", \\\"{x:1617,y:752,t:1527876665871};\\\", \\\"{x:1617,y:751,t:1527876665887};\\\", \\\"{x:1617,y:748,t:1527876665897};\\\", \\\"{x:1618,y:746,t:1527876665913};\\\", \\\"{x:1618,y:744,t:1527876665930};\\\", \\\"{x:1618,y:743,t:1527876665946};\\\", \\\"{x:1619,y:740,t:1527876665962};\\\", \\\"{x:1620,y:738,t:1527876665980};\\\", \\\"{x:1620,y:735,t:1527876665996};\\\", \\\"{x:1621,y:735,t:1527876666012};\\\", \\\"{x:1621,y:733,t:1527876666029};\\\", \\\"{x:1623,y:731,t:1527876666047};\\\", \\\"{x:1624,y:729,t:1527876666062};\\\", \\\"{x:1624,y:728,t:1527876666095};\\\", \\\"{x:1624,y:727,t:1527876666142};\\\", \\\"{x:1627,y:736,t:1527876666776};\\\", \\\"{x:1628,y:748,t:1527876666783};\\\", \\\"{x:1631,y:765,t:1527876666797};\\\", \\\"{x:1637,y:797,t:1527876666815};\\\", \\\"{x:1641,y:819,t:1527876666830};\\\", \\\"{x:1650,y:843,t:1527876666847};\\\", \\\"{x:1655,y:860,t:1527876666864};\\\", \\\"{x:1656,y:872,t:1527876666881};\\\", \\\"{x:1657,y:881,t:1527876666897};\\\", \\\"{x:1658,y:886,t:1527876666916};\\\", \\\"{x:1658,y:892,t:1527876666931};\\\", \\\"{x:1658,y:903,t:1527876666947};\\\", \\\"{x:1660,y:914,t:1527876666964};\\\", \\\"{x:1660,y:921,t:1527876666981};\\\", \\\"{x:1660,y:925,t:1527876666998};\\\", \\\"{x:1659,y:929,t:1527876667014};\\\", \\\"{x:1655,y:936,t:1527876667031};\\\", \\\"{x:1655,y:941,t:1527876667047};\\\", \\\"{x:1651,y:950,t:1527876667064};\\\", \\\"{x:1649,y:958,t:1527876667081};\\\", \\\"{x:1645,y:963,t:1527876667097};\\\", \\\"{x:1643,y:969,t:1527876667117};\\\", \\\"{x:1640,y:973,t:1527876667131};\\\", \\\"{x:1640,y:976,t:1527876667147};\\\", \\\"{x:1638,y:980,t:1527876667165};\\\", \\\"{x:1635,y:983,t:1527876667181};\\\", \\\"{x:1635,y:984,t:1527876667197};\\\", \\\"{x:1634,y:985,t:1527876667320};\\\", \\\"{x:1633,y:985,t:1527876667335};\\\", \\\"{x:1632,y:985,t:1527876667351};\\\", \\\"{x:1631,y:983,t:1527876667367};\\\", \\\"{x:1629,y:981,t:1527876667380};\\\", \\\"{x:1629,y:977,t:1527876667398};\\\", \\\"{x:1625,y:973,t:1527876667415};\\\", \\\"{x:1625,y:971,t:1527876667431};\\\", \\\"{x:1623,y:967,t:1527876667448};\\\", \\\"{x:1622,y:964,t:1527876667464};\\\", \\\"{x:1619,y:962,t:1527876667482};\\\", \\\"{x:1617,y:960,t:1527876667498};\\\", \\\"{x:1616,y:959,t:1527876667516};\\\", \\\"{x:1615,y:959,t:1527876667531};\\\", \\\"{x:1613,y:958,t:1527876667548};\\\", \\\"{x:1612,y:958,t:1527876667615};\\\", \\\"{x:1609,y:958,t:1527876667631};\\\", \\\"{x:1606,y:958,t:1527876667648};\\\", \\\"{x:1605,y:959,t:1527876667665};\\\", \\\"{x:1605,y:963,t:1527876667681};\\\", \\\"{x:1602,y:966,t:1527876667698};\\\", \\\"{x:1599,y:968,t:1527876667715};\\\", \\\"{x:1599,y:969,t:1527876667759};\\\", \\\"{x:1599,y:970,t:1527876667935};\\\", \\\"{x:1601,y:970,t:1527876667951};\\\", \\\"{x:1602,y:970,t:1527876667967};\\\", \\\"{x:1603,y:970,t:1527876667981};\\\", \\\"{x:1604,y:970,t:1527876667998};\\\", \\\"{x:1605,y:970,t:1527876668087};\\\", \\\"{x:1606,y:970,t:1527876668103};\\\", \\\"{x:1607,y:969,t:1527876668115};\\\", \\\"{x:1609,y:967,t:1527876668132};\\\", \\\"{x:1611,y:965,t:1527876668148};\\\", \\\"{x:1612,y:963,t:1527876668165};\\\", \\\"{x:1613,y:963,t:1527876668199};\\\", \\\"{x:1613,y:962,t:1527876668256};\\\", \\\"{x:1615,y:961,t:1527876668265};\\\", \\\"{x:1615,y:960,t:1527876668287};\\\", \\\"{x:1615,y:958,t:1527876668447};\\\", \\\"{x:1616,y:958,t:1527876668465};\\\", \\\"{x:1616,y:955,t:1527876668482};\\\", \\\"{x:1616,y:954,t:1527876668498};\\\", \\\"{x:1616,y:951,t:1527876668516};\\\", \\\"{x:1616,y:948,t:1527876668532};\\\", \\\"{x:1617,y:944,t:1527876668548};\\\", \\\"{x:1618,y:943,t:1527876668565};\\\", \\\"{x:1618,y:940,t:1527876668582};\\\", \\\"{x:1618,y:938,t:1527876668598};\\\", \\\"{x:1618,y:935,t:1527876668614};\\\", \\\"{x:1618,y:933,t:1527876668632};\\\", \\\"{x:1618,y:931,t:1527876668648};\\\", \\\"{x:1619,y:929,t:1527876668665};\\\", \\\"{x:1619,y:928,t:1527876668682};\\\", \\\"{x:1619,y:926,t:1527876668698};\\\", \\\"{x:1619,y:924,t:1527876668715};\\\", \\\"{x:1619,y:922,t:1527876668732};\\\", \\\"{x:1619,y:919,t:1527876668750};\\\", \\\"{x:1619,y:918,t:1527876668766};\\\", \\\"{x:1619,y:916,t:1527876668783};\\\", \\\"{x:1619,y:915,t:1527876668798};\\\", \\\"{x:1619,y:912,t:1527876668815};\\\", \\\"{x:1619,y:909,t:1527876668832};\\\", \\\"{x:1619,y:907,t:1527876668849};\\\", \\\"{x:1619,y:903,t:1527876668865};\\\", \\\"{x:1619,y:902,t:1527876668882};\\\", \\\"{x:1619,y:899,t:1527876668899};\\\", \\\"{x:1619,y:896,t:1527876668918};\\\", \\\"{x:1619,y:894,t:1527876668931};\\\", \\\"{x:1619,y:890,t:1527876668949};\\\", \\\"{x:1619,y:888,t:1527876668964};\\\", \\\"{x:1619,y:886,t:1527876668981};\\\", \\\"{x:1619,y:884,t:1527876668997};\\\", \\\"{x:1619,y:883,t:1527876669014};\\\", \\\"{x:1619,y:880,t:1527876669031};\\\", \\\"{x:1619,y:879,t:1527876669048};\\\", \\\"{x:1619,y:877,t:1527876669065};\\\", \\\"{x:1619,y:874,t:1527876669081};\\\", \\\"{x:1619,y:873,t:1527876669099};\\\", \\\"{x:1619,y:871,t:1527876669126};\\\", \\\"{x:1619,y:870,t:1527876669134};\\\", \\\"{x:1620,y:867,t:1527876669150};\\\", \\\"{x:1620,y:866,t:1527876669166};\\\", \\\"{x:1621,y:863,t:1527876669181};\\\", \\\"{x:1621,y:862,t:1527876669199};\\\", \\\"{x:1621,y:858,t:1527876669214};\\\", \\\"{x:1621,y:854,t:1527876669231};\\\", \\\"{x:1621,y:848,t:1527876669248};\\\", \\\"{x:1621,y:845,t:1527876669265};\\\", \\\"{x:1621,y:841,t:1527876669282};\\\", \\\"{x:1621,y:838,t:1527876669298};\\\", \\\"{x:1621,y:836,t:1527876669315};\\\", \\\"{x:1620,y:833,t:1527876669332};\\\", \\\"{x:1620,y:828,t:1527876669349};\\\", \\\"{x:1620,y:825,t:1527876669366};\\\", \\\"{x:1620,y:821,t:1527876669382};\\\", \\\"{x:1618,y:816,t:1527876669399};\\\", \\\"{x:1618,y:814,t:1527876669416};\\\", \\\"{x:1618,y:810,t:1527876669432};\\\", \\\"{x:1618,y:809,t:1527876669449};\\\", \\\"{x:1617,y:806,t:1527876669466};\\\", \\\"{x:1617,y:804,t:1527876669482};\\\", \\\"{x:1615,y:800,t:1527876669499};\\\", \\\"{x:1613,y:794,t:1527876669516};\\\", \\\"{x:1613,y:789,t:1527876669532};\\\", \\\"{x:1612,y:786,t:1527876669549};\\\", \\\"{x:1611,y:784,t:1527876669566};\\\", \\\"{x:1610,y:779,t:1527876669582};\\\", \\\"{x:1607,y:767,t:1527876669599};\\\", \\\"{x:1606,y:758,t:1527876669616};\\\", \\\"{x:1604,y:744,t:1527876669632};\\\", \\\"{x:1601,y:726,t:1527876669649};\\\", \\\"{x:1600,y:695,t:1527876669666};\\\", \\\"{x:1595,y:670,t:1527876669682};\\\", \\\"{x:1595,y:654,t:1527876669699};\\\", \\\"{x:1598,y:638,t:1527876669715};\\\", \\\"{x:1602,y:620,t:1527876669733};\\\", \\\"{x:1602,y:601,t:1527876669749};\\\", \\\"{x:1603,y:587,t:1527876669766};\\\", \\\"{x:1607,y:577,t:1527876669783};\\\", \\\"{x:1609,y:566,t:1527876669798};\\\", \\\"{x:1609,y:560,t:1527876669816};\\\", \\\"{x:1610,y:556,t:1527876669832};\\\", \\\"{x:1611,y:555,t:1527876669848};\\\", \\\"{x:1611,y:552,t:1527876669866};\\\", \\\"{x:1614,y:546,t:1527876669882};\\\", \\\"{x:1615,y:544,t:1527876669899};\\\", \\\"{x:1617,y:539,t:1527876669916};\\\", \\\"{x:1618,y:537,t:1527876669933};\\\", \\\"{x:1618,y:540,t:1527876670151};\\\", \\\"{x:1617,y:542,t:1527876670166};\\\", \\\"{x:1617,y:548,t:1527876670183};\\\", \\\"{x:1617,y:550,t:1527876670200};\\\", \\\"{x:1616,y:551,t:1527876670216};\\\", \\\"{x:1615,y:553,t:1527876670271};\\\", \\\"{x:1615,y:554,t:1527876670287};\\\", \\\"{x:1615,y:555,t:1527876670303};\\\", \\\"{x:1615,y:556,t:1527876670383};\\\", \\\"{x:1614,y:558,t:1527876670406};\\\", \\\"{x:1614,y:560,t:1527876670433};\\\", \\\"{x:1614,y:561,t:1527876670486};\\\", \\\"{x:1614,y:563,t:1527876670574};\\\", \\\"{x:1614,y:564,t:1527876671399};\\\", \\\"{x:1614,y:567,t:1527876671407};\\\", \\\"{x:1614,y:585,t:1527876671434};\\\", \\\"{x:1614,y:604,t:1527876671452};\\\", \\\"{x:1614,y:631,t:1527876671468};\\\", \\\"{x:1615,y:657,t:1527876671485};\\\", \\\"{x:1616,y:718,t:1527876671501};\\\", \\\"{x:1623,y:795,t:1527876671519};\\\", \\\"{x:1633,y:878,t:1527876671535};\\\", \\\"{x:1636,y:929,t:1527876671553};\\\", \\\"{x:1636,y:954,t:1527876671568};\\\", \\\"{x:1634,y:981,t:1527876671586};\\\", \\\"{x:1634,y:999,t:1527876671603};\\\", \\\"{x:1634,y:1005,t:1527876671619};\\\", \\\"{x:1634,y:1007,t:1527876671636};\\\", \\\"{x:1634,y:1008,t:1527876671686};\\\", \\\"{x:1634,y:1011,t:1527876671702};\\\", \\\"{x:1634,y:1005,t:1527876671815};\\\", \\\"{x:1634,y:996,t:1527876671823};\\\", \\\"{x:1632,y:989,t:1527876671836};\\\", \\\"{x:1631,y:980,t:1527876671854};\\\", \\\"{x:1630,y:972,t:1527876671869};\\\", \\\"{x:1625,y:961,t:1527876671886};\\\", \\\"{x:1625,y:959,t:1527876671903};\\\", \\\"{x:1624,y:958,t:1527876672038};\\\", \\\"{x:1623,y:956,t:1527876672052};\\\", \\\"{x:1621,y:956,t:1527876672069};\\\", \\\"{x:1620,y:956,t:1527876672085};\\\", \\\"{x:1618,y:956,t:1527876672103};\\\", \\\"{x:1617,y:956,t:1527876672120};\\\", \\\"{x:1613,y:959,t:1527876672136};\\\", \\\"{x:1612,y:960,t:1527876672153};\\\", \\\"{x:1611,y:961,t:1527876672170};\\\", \\\"{x:1610,y:962,t:1527876672186};\\\", \\\"{x:1610,y:963,t:1527876672203};\\\", \\\"{x:1610,y:961,t:1527876672416};\\\", \\\"{x:1610,y:959,t:1527876672423};\\\", \\\"{x:1607,y:956,t:1527876672437};\\\", \\\"{x:1607,y:953,t:1527876672454};\\\", \\\"{x:1607,y:949,t:1527876672470};\\\", \\\"{x:1606,y:944,t:1527876672487};\\\", \\\"{x:1606,y:940,t:1527876672503};\\\", \\\"{x:1605,y:937,t:1527876672520};\\\", \\\"{x:1605,y:934,t:1527876672537};\\\", \\\"{x:1605,y:932,t:1527876672553};\\\", \\\"{x:1605,y:931,t:1527876672574};\\\", \\\"{x:1605,y:929,t:1527876672587};\\\", \\\"{x:1604,y:924,t:1527876672604};\\\", \\\"{x:1604,y:923,t:1527876672620};\\\", \\\"{x:1603,y:918,t:1527876672637};\\\", \\\"{x:1603,y:916,t:1527876672653};\\\", \\\"{x:1603,y:913,t:1527876672670};\\\", \\\"{x:1603,y:908,t:1527876672687};\\\", \\\"{x:1604,y:906,t:1527876672702};\\\", \\\"{x:1604,y:904,t:1527876672720};\\\", \\\"{x:1604,y:900,t:1527876672737};\\\", \\\"{x:1604,y:897,t:1527876672753};\\\", \\\"{x:1605,y:893,t:1527876672770};\\\", \\\"{x:1605,y:891,t:1527876672787};\\\", \\\"{x:1605,y:890,t:1527876672803};\\\", \\\"{x:1605,y:888,t:1527876672820};\\\", \\\"{x:1605,y:887,t:1527876672837};\\\", \\\"{x:1605,y:886,t:1527876672863};\\\", \\\"{x:1605,y:884,t:1527876672878};\\\", \\\"{x:1605,y:883,t:1527876672895};\\\", \\\"{x:1605,y:882,t:1527876672904};\\\", \\\"{x:1605,y:881,t:1527876672920};\\\", \\\"{x:1605,y:880,t:1527876672951};\\\", \\\"{x:1605,y:879,t:1527876672959};\\\", \\\"{x:1605,y:878,t:1527876672975};\\\", \\\"{x:1606,y:877,t:1527876673064};\\\", \\\"{x:1606,y:876,t:1527876673095};\\\", \\\"{x:1606,y:875,t:1527876673104};\\\", \\\"{x:1606,y:874,t:1527876673120};\\\", \\\"{x:1606,y:872,t:1527876673137};\\\", \\\"{x:1606,y:870,t:1527876673154};\\\", \\\"{x:1606,y:868,t:1527876673171};\\\", \\\"{x:1606,y:865,t:1527876673187};\\\", \\\"{x:1606,y:863,t:1527876673204};\\\", \\\"{x:1606,y:862,t:1527876673220};\\\", \\\"{x:1606,y:860,t:1527876673239};\\\", \\\"{x:1606,y:859,t:1527876673263};\\\", \\\"{x:1606,y:857,t:1527876673463};\\\", \\\"{x:1606,y:855,t:1527876673471};\\\", \\\"{x:1607,y:852,t:1527876673487};\\\", \\\"{x:1607,y:850,t:1527876673519};\\\", \\\"{x:1607,y:849,t:1527876673583};\\\", \\\"{x:1607,y:847,t:1527876673598};\\\", \\\"{x:1607,y:846,t:1527876673615};\\\", \\\"{x:1607,y:844,t:1527876673647};\\\", \\\"{x:1607,y:843,t:1527876674544};\\\", \\\"{x:1607,y:838,t:1527876674556};\\\", \\\"{x:1608,y:832,t:1527876674572};\\\", \\\"{x:1610,y:826,t:1527876674588};\\\", \\\"{x:1610,y:823,t:1527876674605};\\\", \\\"{x:1610,y:820,t:1527876674622};\\\", \\\"{x:1610,y:819,t:1527876674639};\\\", \\\"{x:1610,y:817,t:1527876674655};\\\", \\\"{x:1611,y:816,t:1527876674671};\\\", \\\"{x:1611,y:815,t:1527876674689};\\\", \\\"{x:1611,y:814,t:1527876674705};\\\", \\\"{x:1611,y:813,t:1527876674721};\\\", \\\"{x:1611,y:812,t:1527876674737};\\\", \\\"{x:1611,y:811,t:1527876674754};\\\", \\\"{x:1611,y:809,t:1527876674771};\\\", \\\"{x:1611,y:808,t:1527876674787};\\\", \\\"{x:1611,y:805,t:1527876674805};\\\", \\\"{x:1613,y:801,t:1527876674822};\\\", \\\"{x:1613,y:800,t:1527876674838};\\\", \\\"{x:1613,y:798,t:1527876674854};\\\", \\\"{x:1613,y:794,t:1527876674872};\\\", \\\"{x:1613,y:793,t:1527876674894};\\\", \\\"{x:1613,y:792,t:1527876674905};\\\", \\\"{x:1613,y:791,t:1527876675007};\\\", \\\"{x:1613,y:789,t:1527876675037};\\\", \\\"{x:1613,y:788,t:1527876675054};\\\", \\\"{x:1613,y:786,t:1527876675077};\\\", \\\"{x:1613,y:785,t:1527876675102};\\\", \\\"{x:1613,y:783,t:1527876675117};\\\", \\\"{x:1613,y:782,t:1527876675133};\\\", \\\"{x:1613,y:781,t:1527876675150};\\\", \\\"{x:1613,y:780,t:1527876675158};\\\", \\\"{x:1613,y:779,t:1527876675172};\\\", \\\"{x:1613,y:777,t:1527876675188};\\\", \\\"{x:1613,y:776,t:1527876675204};\\\", \\\"{x:1612,y:773,t:1527876675222};\\\", \\\"{x:1611,y:771,t:1527876675238};\\\", \\\"{x:1611,y:770,t:1527876675254};\\\", \\\"{x:1610,y:769,t:1527876675272};\\\", \\\"{x:1610,y:768,t:1527876675293};\\\", \\\"{x:1610,y:767,t:1527876675310};\\\", \\\"{x:1610,y:766,t:1527876675334};\\\", \\\"{x:1610,y:765,t:1527876675349};\\\", \\\"{x:1610,y:764,t:1527876675358};\\\", \\\"{x:1609,y:763,t:1527876675382};\\\", \\\"{x:1608,y:760,t:1527876675390};\\\", \\\"{x:1607,y:759,t:1527876675414};\\\", \\\"{x:1606,y:759,t:1527876675422};\\\", \\\"{x:1606,y:757,t:1527876675438};\\\", \\\"{x:1605,y:755,t:1527876675454};\\\", \\\"{x:1604,y:753,t:1527876675472};\\\", \\\"{x:1603,y:747,t:1527876675489};\\\", \\\"{x:1602,y:745,t:1527876675505};\\\", \\\"{x:1602,y:743,t:1527876675522};\\\", \\\"{x:1600,y:742,t:1527876675539};\\\", \\\"{x:1600,y:740,t:1527876675555};\\\", \\\"{x:1600,y:737,t:1527876675572};\\\", \\\"{x:1599,y:735,t:1527876675589};\\\", \\\"{x:1599,y:733,t:1527876675606};\\\", \\\"{x:1599,y:732,t:1527876675639};\\\", \\\"{x:1598,y:730,t:1527876675656};\\\", \\\"{x:1597,y:727,t:1527876675672};\\\", \\\"{x:1596,y:725,t:1527876675689};\\\", \\\"{x:1596,y:724,t:1527876675705};\\\", \\\"{x:1596,y:723,t:1527876675723};\\\", \\\"{x:1596,y:720,t:1527876675739};\\\", \\\"{x:1596,y:719,t:1527876675756};\\\", \\\"{x:1596,y:716,t:1527876675773};\\\", \\\"{x:1596,y:714,t:1527876675789};\\\", \\\"{x:1596,y:710,t:1527876675806};\\\", \\\"{x:1596,y:709,t:1527876675822};\\\", \\\"{x:1596,y:706,t:1527876675839};\\\", \\\"{x:1596,y:704,t:1527876675856};\\\", \\\"{x:1596,y:703,t:1527876675872};\\\", \\\"{x:1594,y:701,t:1527876675889};\\\", \\\"{x:1594,y:700,t:1527876675907};\\\", \\\"{x:1593,y:700,t:1527876676223};\\\", \\\"{x:1589,y:700,t:1527876676240};\\\", \\\"{x:1588,y:705,t:1527876676256};\\\", \\\"{x:1580,y:710,t:1527876676273};\\\", \\\"{x:1573,y:715,t:1527876676289};\\\", \\\"{x:1569,y:723,t:1527876676307};\\\", \\\"{x:1557,y:729,t:1527876676323};\\\", \\\"{x:1544,y:732,t:1527876676339};\\\", \\\"{x:1528,y:736,t:1527876676356};\\\", \\\"{x:1517,y:737,t:1527876676374};\\\", \\\"{x:1496,y:738,t:1527876676390};\\\", \\\"{x:1466,y:738,t:1527876676406};\\\", \\\"{x:1412,y:738,t:1527876676422};\\\", \\\"{x:1353,y:738,t:1527876676440};\\\", \\\"{x:1273,y:738,t:1527876676456};\\\", \\\"{x:1192,y:738,t:1527876676473};\\\", \\\"{x:1112,y:738,t:1527876676489};\\\", \\\"{x:1066,y:738,t:1527876676506};\\\", \\\"{x:1025,y:738,t:1527876676523};\\\", \\\"{x:992,y:738,t:1527876676539};\\\", \\\"{x:948,y:737,t:1527876676556};\\\", \\\"{x:924,y:737,t:1527876676573};\\\", \\\"{x:894,y:737,t:1527876676589};\\\", \\\"{x:850,y:737,t:1527876676606};\\\", \\\"{x:827,y:737,t:1527876676623};\\\", \\\"{x:801,y:737,t:1527876676639};\\\", \\\"{x:784,y:737,t:1527876676656};\\\", \\\"{x:762,y:736,t:1527876676673};\\\", \\\"{x:749,y:734,t:1527876676689};\\\", \\\"{x:731,y:733,t:1527876676706};\\\", \\\"{x:710,y:730,t:1527876676723};\\\", \\\"{x:692,y:726,t:1527876676739};\\\", \\\"{x:671,y:722,t:1527876676756};\\\", \\\"{x:645,y:717,t:1527876676773};\\\", \\\"{x:608,y:703,t:1527876676791};\\\", \\\"{x:594,y:692,t:1527876676806};\\\", \\\"{x:575,y:683,t:1527876676825};\\\", \\\"{x:553,y:673,t:1527876676839};\\\", \\\"{x:533,y:666,t:1527876676856};\\\", \\\"{x:521,y:662,t:1527876676873};\\\", \\\"{x:499,y:658,t:1527876676889};\\\", \\\"{x:482,y:655,t:1527876676906};\\\", \\\"{x:473,y:652,t:1527876676923};\\\", \\\"{x:449,y:652,t:1527876676939};\\\", \\\"{x:428,y:651,t:1527876676956};\\\", \\\"{x:399,y:651,t:1527876676972};\\\", \\\"{x:359,y:649,t:1527876676989};\\\", \\\"{x:344,y:645,t:1527876677007};\\\", \\\"{x:320,y:641,t:1527876677022};\\\", \\\"{x:303,y:638,t:1527876677040};\\\", \\\"{x:289,y:635,t:1527876677057};\\\", \\\"{x:274,y:631,t:1527876677074};\\\", \\\"{x:254,y:627,t:1527876677092};\\\", \\\"{x:235,y:625,t:1527876677106};\\\", \\\"{x:219,y:625,t:1527876677124};\\\", \\\"{x:208,y:625,t:1527876677140};\\\", \\\"{x:205,y:625,t:1527876677156};\\\", \\\"{x:193,y:627,t:1527876677173};\\\", \\\"{x:188,y:630,t:1527876677190};\\\", \\\"{x:182,y:634,t:1527876677206};\\\", \\\"{x:179,y:636,t:1527876677224};\\\", \\\"{x:177,y:637,t:1527876677240};\\\", \\\"{x:174,y:639,t:1527876677257};\\\", \\\"{x:171,y:641,t:1527876677274};\\\", \\\"{x:170,y:642,t:1527876677290};\\\", \\\"{x:168,y:643,t:1527876677359};\\\", \\\"{x:166,y:647,t:1527876677374};\\\", \\\"{x:164,y:649,t:1527876677391};\\\", \\\"{x:163,y:651,t:1527876677407};\\\", \\\"{x:163,y:652,t:1527876677424};\\\", \\\"{x:161,y:653,t:1527876677439};\\\", \\\"{x:160,y:654,t:1527876677470};\\\", \\\"{x:160,y:655,t:1527876677502};\\\", \\\"{x:157,y:658,t:1527876677511};\\\", \\\"{x:152,y:663,t:1527876677524};\\\", \\\"{x:144,y:673,t:1527876677541};\\\", \\\"{x:144,y:674,t:1527876677557};\\\", \\\"{x:145,y:674,t:1527876677919};\\\", \\\"{x:146,y:674,t:1527876677926};\\\", \\\"{x:152,y:673,t:1527876677942};\\\", \\\"{x:164,y:672,t:1527876677958};\\\", \\\"{x:174,y:672,t:1527876677974};\\\", \\\"{x:176,y:671,t:1527876677991};\\\", \\\"{x:181,y:671,t:1527876678559};\\\", \\\"{x:196,y:666,t:1527876678575};\\\", \\\"{x:231,y:657,t:1527876678592};\\\", \\\"{x:255,y:654,t:1527876678608};\\\", \\\"{x:312,y:646,t:1527876678625};\\\", \\\"{x:388,y:632,t:1527876678641};\\\", \\\"{x:455,y:621,t:1527876678658};\\\", \\\"{x:512,y:614,t:1527876678675};\\\", \\\"{x:567,y:600,t:1527876678691};\\\", \\\"{x:626,y:592,t:1527876678708};\\\", \\\"{x:663,y:585,t:1527876678725};\\\", \\\"{x:680,y:583,t:1527876678740};\\\", \\\"{x:699,y:576,t:1527876678758};\\\", \\\"{x:705,y:574,t:1527876678775};\\\", \\\"{x:711,y:571,t:1527876678791};\\\", \\\"{x:721,y:570,t:1527876678808};\\\", \\\"{x:741,y:566,t:1527876678826};\\\", \\\"{x:754,y:561,t:1527876678841};\\\", \\\"{x:770,y:557,t:1527876678858};\\\", \\\"{x:781,y:556,t:1527876678875};\\\", \\\"{x:785,y:556,t:1527876678891};\\\", \\\"{x:781,y:557,t:1527876678966};\\\", \\\"{x:777,y:560,t:1527876678975};\\\", \\\"{x:768,y:568,t:1527876678992};\\\", \\\"{x:762,y:577,t:1527876679008};\\\", \\\"{x:759,y:582,t:1527876679025};\\\", \\\"{x:759,y:584,t:1527876679042};\\\", \\\"{x:758,y:584,t:1527876679058};\\\", \\\"{x:759,y:584,t:1527876679151};\\\", \\\"{x:764,y:584,t:1527876679158};\\\", \\\"{x:772,y:583,t:1527876679175};\\\", \\\"{x:786,y:580,t:1527876679192};\\\", \\\"{x:797,y:578,t:1527876679210};\\\", \\\"{x:807,y:577,t:1527876679225};\\\", \\\"{x:813,y:577,t:1527876679242};\\\", \\\"{x:817,y:577,t:1527876679258};\\\", \\\"{x:821,y:577,t:1527876679275};\\\", \\\"{x:825,y:577,t:1527876679292};\\\", \\\"{x:830,y:577,t:1527876679309};\\\", \\\"{x:836,y:578,t:1527876679324};\\\", \\\"{x:840,y:579,t:1527876679342};\\\", \\\"{x:845,y:581,t:1527876679360};\\\", \\\"{x:846,y:581,t:1527876679375};\\\", \\\"{x:850,y:583,t:1527876679393};\\\", \\\"{x:852,y:586,t:1527876679409};\\\", \\\"{x:855,y:588,t:1527876679425};\\\", \\\"{x:855,y:592,t:1527876679441};\\\", \\\"{x:858,y:601,t:1527876679459};\\\", \\\"{x:860,y:611,t:1527876679475};\\\", \\\"{x:863,y:622,t:1527876679493};\\\", \\\"{x:863,y:627,t:1527876679509};\\\", \\\"{x:864,y:631,t:1527876679524};\\\", \\\"{x:865,y:636,t:1527876679542};\\\", \\\"{x:865,y:640,t:1527876679559};\\\", \\\"{x:865,y:641,t:1527876679861};\\\", \\\"{x:863,y:641,t:1527876679875};\\\", \\\"{x:858,y:641,t:1527876679892};\\\", \\\"{x:855,y:641,t:1527876679909};\\\", \\\"{x:852,y:637,t:1527876679926};\\\", \\\"{x:851,y:637,t:1527876679942};\\\", \\\"{x:849,y:636,t:1527876679990};\\\", \\\"{x:847,y:636,t:1527876679998};\\\", \\\"{x:842,y:639,t:1527876680010};\\\", \\\"{x:821,y:651,t:1527876680027};\\\", \\\"{x:803,y:666,t:1527876680042};\\\", \\\"{x:797,y:669,t:1527876680059};\\\", \\\"{x:740,y:698,t:1527876680076};\\\", \\\"{x:673,y:731,t:1527876680094};\\\", \\\"{x:632,y:757,t:1527876680109};\\\", \\\"{x:600,y:777,t:1527876680125};\\\", \\\"{x:592,y:780,t:1527876680142};\\\", \\\"{x:586,y:782,t:1527876680159};\\\", \\\"{x:583,y:783,t:1527876680176};\\\", \\\"{x:582,y:783,t:1527876680193};\\\", \\\"{x:581,y:783,t:1527876680214};\\\", \\\"{x:579,y:783,t:1527876680226};\\\", \\\"{x:574,y:785,t:1527876680243};\\\", \\\"{x:567,y:788,t:1527876680259};\\\", \\\"{x:559,y:793,t:1527876680276};\\\", \\\"{x:554,y:796,t:1527876680294};\\\", \\\"{x:554,y:797,t:1527876680309};\\\", \\\"{x:551,y:797,t:1527876680383};\\\", \\\"{x:548,y:797,t:1527876680394};\\\", \\\"{x:536,y:786,t:1527876680409};\\\", \\\"{x:522,y:768,t:1527876680427};\\\", \\\"{x:514,y:759,t:1527876680443};\\\", \\\"{x:506,y:749,t:1527876680460};\\\", \\\"{x:502,y:746,t:1527876680476};\\\", \\\"{x:501,y:744,t:1527876680493};\\\", \\\"{x:500,y:743,t:1527876680509};\\\", \\\"{x:502,y:742,t:1527876680974};\\\", \\\"{x:506,y:743,t:1527876680982};\\\", \\\"{x:513,y:744,t:1527876680993};\\\", \\\"{x:530,y:744,t:1527876681010};\\\", \\\"{x:544,y:745,t:1527876681026};\\\", \\\"{x:579,y:745,t:1527876681043};\\\", \\\"{x:632,y:745,t:1527876681060};\\\", \\\"{x:694,y:745,t:1527876681076};\\\", \\\"{x:755,y:745,t:1527876681092};\\\", \\\"{x:836,y:745,t:1527876681110};\\\", \\\"{x:886,y:745,t:1527876681126};\\\", \\\"{x:918,y:745,t:1527876681143};\\\", \\\"{x:940,y:747,t:1527876681160};\\\", \\\"{x:949,y:748,t:1527876681176};\\\", \\\"{x:956,y:748,t:1527876681193};\\\", \\\"{x:960,y:749,t:1527876681210};\\\", \\\"{x:961,y:750,t:1527876681238};\\\", \\\"{x:961,y:751,t:1527876681245};\\\", \\\"{x:959,y:753,t:1527876681261};\\\", \\\"{x:958,y:753,t:1527876681276};\\\", \\\"{x:954,y:756,t:1527876681292};\\\", \\\"{x:950,y:762,t:1527876681309};\\\", \\\"{x:948,y:765,t:1527876681326};\\\", \\\"{x:945,y:769,t:1527876681342};\\\", \\\"{x:942,y:773,t:1527876681360};\\\", \\\"{x:941,y:774,t:1527876681377};\\\", \\\"{x:938,y:776,t:1527876681392};\\\", \\\"{x:938,y:777,t:1527876681410};\\\" ] }, { \\\"rt\\\": 53861, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 341395, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -I -I -I -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:936,y:777,t:1527876681941};\\\", \\\"{x:934,y:777,t:1527876682430};\\\", \\\"{x:932,y:777,t:1527876682444};\\\", \\\"{x:929,y:777,t:1527876682461};\\\", \\\"{x:925,y:778,t:1527876682477};\\\", \\\"{x:923,y:778,t:1527876682494};\\\", \\\"{x:921,y:779,t:1527876682975};\\\", \\\"{x:920,y:779,t:1527876682982};\\\", \\\"{x:916,y:780,t:1527876682995};\\\", \\\"{x:907,y:780,t:1527876683011};\\\", \\\"{x:888,y:780,t:1527876683028};\\\", \\\"{x:862,y:785,t:1527876683045};\\\", \\\"{x:852,y:786,t:1527876683062};\\\", \\\"{x:841,y:791,t:1527876683079};\\\", \\\"{x:841,y:790,t:1527876685231};\\\", \\\"{x:839,y:781,t:1527876685247};\\\", \\\"{x:838,y:781,t:1527876685264};\\\", \\\"{x:838,y:780,t:1527876685591};\\\", \\\"{x:837,y:780,t:1527876686199};\\\", \\\"{x:836,y:779,t:1527876686431};\\\", \\\"{x:836,y:777,t:1527876686447};\\\", \\\"{x:837,y:777,t:1527876686495};\\\", \\\"{x:839,y:777,t:1527876686503};\\\", \\\"{x:843,y:777,t:1527876686514};\\\", \\\"{x:845,y:775,t:1527876686532};\\\", \\\"{x:854,y:774,t:1527876686548};\\\", \\\"{x:855,y:772,t:1527876686564};\\\", \\\"{x:856,y:771,t:1527876686581};\\\", \\\"{x:857,y:771,t:1527876686614};\\\", \\\"{x:865,y:771,t:1527876686632};\\\", \\\"{x:866,y:772,t:1527876686648};\\\", \\\"{x:867,y:772,t:1527876686665};\\\", \\\"{x:876,y:772,t:1527876686682};\\\", \\\"{x:884,y:777,t:1527876686698};\\\", \\\"{x:893,y:779,t:1527876686714};\\\", \\\"{x:907,y:784,t:1527876686730};\\\", \\\"{x:919,y:787,t:1527876686748};\\\", \\\"{x:939,y:792,t:1527876686764};\\\", \\\"{x:966,y:800,t:1527876686781};\\\", \\\"{x:989,y:813,t:1527876686798};\\\", \\\"{x:1011,y:818,t:1527876686814};\\\", \\\"{x:1029,y:821,t:1527876686831};\\\", \\\"{x:1032,y:821,t:1527876686849};\\\", \\\"{x:1052,y:821,t:1527876686864};\\\", \\\"{x:1066,y:821,t:1527876686881};\\\", \\\"{x:1074,y:820,t:1527876686898};\\\", \\\"{x:1076,y:819,t:1527876686914};\\\", \\\"{x:1078,y:818,t:1527876686931};\\\", \\\"{x:1079,y:816,t:1527876686949};\\\", \\\"{x:1098,y:811,t:1527876686964};\\\", \\\"{x:1151,y:808,t:1527876686981};\\\", \\\"{x:1196,y:791,t:1527876686998};\\\", \\\"{x:1230,y:777,t:1527876687014};\\\", \\\"{x:1280,y:759,t:1527876687031};\\\", \\\"{x:1306,y:750,t:1527876687048};\\\", \\\"{x:1344,y:736,t:1527876687064};\\\", \\\"{x:1361,y:731,t:1527876687082};\\\", \\\"{x:1380,y:727,t:1527876687099};\\\", \\\"{x:1398,y:725,t:1527876687115};\\\", \\\"{x:1412,y:721,t:1527876687131};\\\", \\\"{x:1422,y:717,t:1527876687148};\\\", \\\"{x:1436,y:716,t:1527876687166};\\\", \\\"{x:1449,y:715,t:1527876687181};\\\", \\\"{x:1458,y:713,t:1527876687198};\\\", \\\"{x:1469,y:712,t:1527876687216};\\\", \\\"{x:1486,y:708,t:1527876687231};\\\", \\\"{x:1500,y:707,t:1527876687248};\\\", \\\"{x:1507,y:706,t:1527876687266};\\\", \\\"{x:1519,y:706,t:1527876687281};\\\", \\\"{x:1524,y:706,t:1527876687299};\\\", \\\"{x:1526,y:706,t:1527876687315};\\\", \\\"{x:1528,y:706,t:1527876687332};\\\", \\\"{x:1530,y:706,t:1527876687348};\\\", \\\"{x:1532,y:706,t:1527876687366};\\\", \\\"{x:1535,y:706,t:1527876687381};\\\", \\\"{x:1536,y:707,t:1527876687399};\\\", \\\"{x:1537,y:708,t:1527876687415};\\\", \\\"{x:1539,y:710,t:1527876687432};\\\", \\\"{x:1541,y:714,t:1527876687448};\\\", \\\"{x:1541,y:716,t:1527876687465};\\\", \\\"{x:1541,y:721,t:1527876687481};\\\", \\\"{x:1541,y:725,t:1527876687499};\\\", \\\"{x:1541,y:730,t:1527876687515};\\\", \\\"{x:1540,y:733,t:1527876687532};\\\", \\\"{x:1538,y:735,t:1527876687547};\\\", \\\"{x:1534,y:736,t:1527876687565};\\\", \\\"{x:1516,y:736,t:1527876687582};\\\", \\\"{x:1499,y:730,t:1527876687598};\\\", \\\"{x:1476,y:717,t:1527876687616};\\\", \\\"{x:1447,y:703,t:1527876687632};\\\", \\\"{x:1396,y:679,t:1527876687648};\\\", \\\"{x:1364,y:660,t:1527876687665};\\\", \\\"{x:1335,y:639,t:1527876687682};\\\", \\\"{x:1314,y:624,t:1527876687698};\\\", \\\"{x:1307,y:617,t:1527876687716};\\\", \\\"{x:1303,y:609,t:1527876687732};\\\", \\\"{x:1298,y:596,t:1527876687748};\\\", \\\"{x:1290,y:587,t:1527876687765};\\\", \\\"{x:1281,y:565,t:1527876687782};\\\", \\\"{x:1268,y:546,t:1527876687799};\\\", \\\"{x:1258,y:528,t:1527876687815};\\\", \\\"{x:1253,y:520,t:1527876687833};\\\", \\\"{x:1252,y:516,t:1527876687848};\\\", \\\"{x:1252,y:514,t:1527876687866};\\\", \\\"{x:1252,y:512,t:1527876687882};\\\", \\\"{x:1252,y:508,t:1527876687898};\\\", \\\"{x:1253,y:502,t:1527876687916};\\\", \\\"{x:1254,y:497,t:1527876687932};\\\", \\\"{x:1257,y:495,t:1527876687948};\\\", \\\"{x:1257,y:494,t:1527876687966};\\\", \\\"{x:1259,y:494,t:1527876687982};\\\", \\\"{x:1263,y:492,t:1527876688000};\\\", \\\"{x:1267,y:492,t:1527876688016};\\\", \\\"{x:1271,y:492,t:1527876688032};\\\", \\\"{x:1277,y:492,t:1527876688049};\\\", \\\"{x:1280,y:491,t:1527876688065};\\\", \\\"{x:1284,y:491,t:1527876688082};\\\", \\\"{x:1285,y:491,t:1527876688100};\\\", \\\"{x:1287,y:491,t:1527876688116};\\\", \\\"{x:1288,y:491,t:1527876688132};\\\", \\\"{x:1290,y:491,t:1527876688150};\\\", \\\"{x:1291,y:491,t:1527876688167};\\\", \\\"{x:1294,y:491,t:1527876688182};\\\", \\\"{x:1297,y:492,t:1527876688199};\\\", \\\"{x:1298,y:492,t:1527876688216};\\\", \\\"{x:1300,y:493,t:1527876688233};\\\", \\\"{x:1302,y:493,t:1527876688250};\\\", \\\"{x:1305,y:496,t:1527876688266};\\\", \\\"{x:1309,y:498,t:1527876688289};\\\", \\\"{x:1311,y:498,t:1527876688299};\\\", \\\"{x:1312,y:498,t:1527876688325};\\\", \\\"{x:1314,y:498,t:1527876688341};\\\", \\\"{x:1315,y:499,t:1527876706072};\\\", \\\"{x:1315,y:502,t:1527876713911};\\\", \\\"{x:1315,y:504,t:1527876713921};\\\", \\\"{x:1315,y:506,t:1527876713932};\\\", \\\"{x:1317,y:509,t:1527876713949};\\\", \\\"{x:1318,y:511,t:1527876713963};\\\", \\\"{x:1318,y:512,t:1527876713979};\\\", \\\"{x:1318,y:513,t:1527876713995};\\\", \\\"{x:1319,y:513,t:1527876714013};\\\", \\\"{x:1319,y:514,t:1527876714038};\\\", \\\"{x:1319,y:516,t:1527876714095};\\\", \\\"{x:1319,y:518,t:1527876714216};\\\", \\\"{x:1321,y:517,t:1527876714328};\\\", \\\"{x:1321,y:515,t:1527876714335};\\\", \\\"{x:1321,y:512,t:1527876714346};\\\", \\\"{x:1321,y:506,t:1527876714363};\\\", \\\"{x:1322,y:500,t:1527876714380};\\\", \\\"{x:1322,y:495,t:1527876714396};\\\", \\\"{x:1322,y:491,t:1527876714413};\\\", \\\"{x:1322,y:488,t:1527876714430};\\\", \\\"{x:1322,y:486,t:1527876714446};\\\", \\\"{x:1322,y:485,t:1527876714463};\\\", \\\"{x:1321,y:486,t:1527876714720};\\\", \\\"{x:1321,y:487,t:1527876714731};\\\", \\\"{x:1318,y:490,t:1527876714747};\\\", \\\"{x:1317,y:492,t:1527876714768};\\\", \\\"{x:1316,y:492,t:1527876714796};\\\", \\\"{x:1314,y:494,t:1527876714855};\\\", \\\"{x:1314,y:495,t:1527876714911};\\\", \\\"{x:1311,y:497,t:1527876730032};\\\", \\\"{x:1303,y:504,t:1527876730045};\\\", \\\"{x:1278,y:519,t:1527876730059};\\\", \\\"{x:1254,y:529,t:1527876730075};\\\", \\\"{x:1228,y:537,t:1527876730091};\\\", \\\"{x:1201,y:545,t:1527876730108};\\\", \\\"{x:1178,y:551,t:1527876730124};\\\", \\\"{x:1155,y:551,t:1527876730142};\\\", \\\"{x:1139,y:552,t:1527876730158};\\\", \\\"{x:1138,y:552,t:1527876730175};\\\", \\\"{x:1138,y:553,t:1527876730400};\\\", \\\"{x:1139,y:553,t:1527876730415};\\\", \\\"{x:1146,y:551,t:1527876730426};\\\", \\\"{x:1159,y:546,t:1527876730442};\\\", \\\"{x:1167,y:541,t:1527876730459};\\\", \\\"{x:1174,y:537,t:1527876730476};\\\", \\\"{x:1180,y:535,t:1527876730492};\\\", \\\"{x:1186,y:532,t:1527876730509};\\\", \\\"{x:1194,y:528,t:1527876730527};\\\", \\\"{x:1196,y:528,t:1527876730542};\\\", \\\"{x:1204,y:523,t:1527876730559};\\\", \\\"{x:1213,y:520,t:1527876730575};\\\", \\\"{x:1218,y:517,t:1527876730592};\\\", \\\"{x:1224,y:516,t:1527876730609};\\\", \\\"{x:1229,y:514,t:1527876730627};\\\", \\\"{x:1240,y:511,t:1527876730643};\\\", \\\"{x:1244,y:509,t:1527876730660};\\\", \\\"{x:1249,y:508,t:1527876730676};\\\", \\\"{x:1251,y:507,t:1527876730693};\\\", \\\"{x:1257,y:506,t:1527876730709};\\\", \\\"{x:1263,y:505,t:1527876730726};\\\", \\\"{x:1265,y:504,t:1527876730743};\\\", \\\"{x:1267,y:503,t:1527876730791};\\\", \\\"{x:1269,y:502,t:1527876730815};\\\", \\\"{x:1270,y:502,t:1527876730827};\\\", \\\"{x:1274,y:501,t:1527876730843};\\\", \\\"{x:1278,y:501,t:1527876730859};\\\", \\\"{x:1284,y:500,t:1527876730876};\\\", \\\"{x:1288,y:500,t:1527876730893};\\\", \\\"{x:1290,y:498,t:1527876730909};\\\", \\\"{x:1293,y:498,t:1527876730926};\\\", \\\"{x:1299,y:496,t:1527876730943};\\\", \\\"{x:1305,y:494,t:1527876730959};\\\", \\\"{x:1306,y:494,t:1527876730976};\\\", \\\"{x:1307,y:494,t:1527876730993};\\\", \\\"{x:1308,y:494,t:1527876731038};\\\", \\\"{x:1309,y:494,t:1527876731048};\\\", \\\"{x:1310,y:494,t:1527876731077};\\\", \\\"{x:1311,y:494,t:1527876731094};\\\", \\\"{x:1313,y:494,t:1527876731111};\\\", \\\"{x:1316,y:494,t:1527876731126};\\\", \\\"{x:1317,y:494,t:1527876731150};\\\", \\\"{x:1319,y:494,t:1527876731174};\\\", \\\"{x:1320,y:494,t:1527876731183};\\\", \\\"{x:1320,y:495,t:1527876731667};\\\", \\\"{x:1320,y:497,t:1527876731677};\\\", \\\"{x:1319,y:501,t:1527876731694};\\\", \\\"{x:1312,y:510,t:1527876731710};\\\", \\\"{x:1311,y:512,t:1527876731727};\\\", \\\"{x:1311,y:511,t:1527876732152};\\\", \\\"{x:1312,y:510,t:1527876732161};\\\", \\\"{x:1312,y:509,t:1527876732178};\\\", \\\"{x:1313,y:507,t:1527876732195};\\\", \\\"{x:1314,y:506,t:1527876732211};\\\", \\\"{x:1315,y:505,t:1527876732479};\\\", \\\"{x:1315,y:503,t:1527876732494};\\\", \\\"{x:1316,y:501,t:1527876732514};\\\", \\\"{x:1316,y:500,t:1527876732528};\\\", \\\"{x:1316,y:498,t:1527876732551};\\\", \\\"{x:1316,y:497,t:1527876732561};\\\", \\\"{x:1316,y:496,t:1527876732583};\\\", \\\"{x:1316,y:495,t:1527876732595};\\\", \\\"{x:1315,y:494,t:1527876734095};\\\", \\\"{x:1313,y:494,t:1527876734102};\\\", \\\"{x:1305,y:494,t:1527876734115};\\\", \\\"{x:1287,y:494,t:1527876734130};\\\", \\\"{x:1258,y:494,t:1527876734146};\\\", \\\"{x:1233,y:500,t:1527876734163};\\\", \\\"{x:1199,y:508,t:1527876734180};\\\", \\\"{x:1178,y:514,t:1527876734195};\\\", \\\"{x:1132,y:526,t:1527876734212};\\\", \\\"{x:1079,y:533,t:1527876734229};\\\", \\\"{x:1023,y:543,t:1527876734245};\\\", \\\"{x:969,y:551,t:1527876734263};\\\", \\\"{x:945,y:556,t:1527876734280};\\\", \\\"{x:931,y:557,t:1527876734295};\\\", \\\"{x:921,y:562,t:1527876734313};\\\", \\\"{x:913,y:565,t:1527876734330};\\\", \\\"{x:911,y:567,t:1527876734345};\\\", \\\"{x:907,y:569,t:1527876734362};\\\", \\\"{x:903,y:570,t:1527876734379};\\\", \\\"{x:898,y:572,t:1527876734396};\\\", \\\"{x:895,y:573,t:1527876734413};\\\", \\\"{x:886,y:576,t:1527876734430};\\\", \\\"{x:877,y:578,t:1527876734446};\\\", \\\"{x:873,y:578,t:1527876734463};\\\", \\\"{x:872,y:578,t:1527876734591};\\\", \\\"{x:870,y:578,t:1527876734599};\\\", \\\"{x:869,y:578,t:1527876734613};\\\", \\\"{x:865,y:578,t:1527876734630};\\\", \\\"{x:863,y:577,t:1527876734647};\\\", \\\"{x:860,y:577,t:1527876734926};\\\", \\\"{x:858,y:577,t:1527876734942};\\\", \\\"{x:850,y:580,t:1527876734950};\\\", \\\"{x:844,y:586,t:1527876734964};\\\", \\\"{x:829,y:598,t:1527876734980};\\\", \\\"{x:809,y:611,t:1527876734997};\\\", \\\"{x:785,y:624,t:1527876735013};\\\", \\\"{x:763,y:634,t:1527876735030};\\\", \\\"{x:729,y:651,t:1527876735046};\\\", \\\"{x:709,y:662,t:1527876735065};\\\", \\\"{x:701,y:669,t:1527876735080};\\\", \\\"{x:689,y:676,t:1527876735097};\\\", \\\"{x:670,y:688,t:1527876735113};\\\", \\\"{x:663,y:696,t:1527876735130};\\\", \\\"{x:658,y:702,t:1527876735147};\\\", \\\"{x:656,y:706,t:1527876735163};\\\", \\\"{x:655,y:714,t:1527876735181};\\\", \\\"{x:654,y:721,t:1527876735197};\\\", \\\"{x:651,y:734,t:1527876735213};\\\", \\\"{x:642,y:746,t:1527876735230};\\\", \\\"{x:634,y:755,t:1527876735246};\\\", \\\"{x:624,y:762,t:1527876735263};\\\", \\\"{x:618,y:768,t:1527876735280};\\\", \\\"{x:609,y:773,t:1527876735296};\\\", \\\"{x:591,y:782,t:1527876735313};\\\", \\\"{x:578,y:789,t:1527876735330};\\\", \\\"{x:559,y:795,t:1527876735347};\\\", \\\"{x:546,y:800,t:1527876735363};\\\", \\\"{x:531,y:807,t:1527876735381};\\\", \\\"{x:520,y:811,t:1527876735396};\\\", \\\"{x:508,y:813,t:1527876735413};\\\", \\\"{x:499,y:817,t:1527876735430};\\\", \\\"{x:497,y:819,t:1527876735447};\\\", \\\"{x:496,y:820,t:1527876735464};\\\", \\\"{x:495,y:816,t:1527876735536};\\\", \\\"{x:492,y:808,t:1527876735547};\\\", \\\"{x:492,y:798,t:1527876735564};\\\", \\\"{x:490,y:788,t:1527876735581};\\\", \\\"{x:487,y:780,t:1527876735598};\\\", \\\"{x:487,y:773,t:1527876735613};\\\", \\\"{x:487,y:772,t:1527876735630};\\\", \\\"{x:487,y:770,t:1527876735646};\\\", \\\"{x:488,y:770,t:1527876736143};\\\", \\\"{x:491,y:768,t:1527876736151};\\\", \\\"{x:494,y:766,t:1527876736165};\\\", \\\"{x:501,y:761,t:1527876736181};\\\", \\\"{x:505,y:758,t:1527876736198};\\\", \\\"{x:507,y:756,t:1527876736214};\\\", \\\"{x:508,y:756,t:1527876736231};\\\", \\\"{x:509,y:755,t:1527876736248};\\\", \\\"{x:510,y:754,t:1527876736279};\\\", \\\"{x:511,y:753,t:1527876736336};\\\", \\\"{x:511,y:752,t:1527876736423};\\\", \\\"{x:511,y:751,t:1527876736447};\\\", \\\"{x:512,y:750,t:1527876736464};\\\", \\\"{x:512,y:749,t:1527876736591};\\\" ] }, { \\\"rt\\\": 22796, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 365520, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-E -E -E -E -G -G -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:748,t:1527876737165};\\\", \\\"{x:512,y:747,t:1527876737679};\\\", \\\"{x:514,y:745,t:1527876737694};\\\", \\\"{x:516,y:744,t:1527876737698};\\\", \\\"{x:521,y:742,t:1527876737715};\\\", \\\"{x:523,y:739,t:1527876737732};\\\", \\\"{x:524,y:739,t:1527876737749};\\\", \\\"{x:524,y:738,t:1527876737765};\\\", \\\"{x:525,y:737,t:1527876737839};\\\", \\\"{x:525,y:736,t:1527876738111};\\\", \\\"{x:525,y:735,t:1527876738119};\\\", \\\"{x:527,y:734,t:1527876738133};\\\", \\\"{x:527,y:732,t:1527876738149};\\\", \\\"{x:529,y:727,t:1527876738167};\\\", \\\"{x:529,y:725,t:1527876738184};\\\", \\\"{x:529,y:724,t:1527876738199};\\\", \\\"{x:531,y:723,t:1527876738216};\\\", \\\"{x:531,y:722,t:1527876738247};\\\", \\\"{x:532,y:721,t:1527876738271};\\\", \\\"{x:533,y:720,t:1527876738283};\\\", \\\"{x:534,y:720,t:1527876738303};\\\", \\\"{x:534,y:719,t:1527876738336};\\\", \\\"{x:535,y:718,t:1527876738390};\\\", \\\"{x:536,y:718,t:1527876738414};\\\", \\\"{x:538,y:718,t:1527876738422};\\\", \\\"{x:540,y:718,t:1527876738432};\\\", \\\"{x:545,y:718,t:1527876738455};\\\", \\\"{x:553,y:719,t:1527876738465};\\\", \\\"{x:572,y:723,t:1527876738483};\\\", \\\"{x:591,y:725,t:1527876738499};\\\", \\\"{x:605,y:726,t:1527876738516};\\\", \\\"{x:628,y:728,t:1527876738532};\\\", \\\"{x:673,y:733,t:1527876738549};\\\", \\\"{x:712,y:742,t:1527876738566};\\\", \\\"{x:744,y:748,t:1527876738583};\\\", \\\"{x:759,y:751,t:1527876738599};\\\", \\\"{x:779,y:751,t:1527876738616};\\\", \\\"{x:798,y:754,t:1527876738633};\\\", \\\"{x:812,y:755,t:1527876738649};\\\", \\\"{x:817,y:757,t:1527876738666};\\\", \\\"{x:820,y:757,t:1527876738683};\\\", \\\"{x:820,y:758,t:1527876738700};\\\", \\\"{x:820,y:760,t:1527876738791};\\\", \\\"{x:820,y:761,t:1527876738799};\\\", \\\"{x:820,y:762,t:1527876738816};\\\", \\\"{x:821,y:762,t:1527876741110};\\\", \\\"{x:829,y:762,t:1527876741118};\\\", \\\"{x:837,y:760,t:1527876741134};\\\", \\\"{x:866,y:760,t:1527876741150};\\\", \\\"{x:886,y:758,t:1527876741167};\\\", \\\"{x:886,y:759,t:1527876741184};\\\", \\\"{x:886,y:758,t:1527876741207};\\\", \\\"{x:894,y:755,t:1527876741217};\\\", \\\"{x:910,y:753,t:1527876741235};\\\", \\\"{x:947,y:750,t:1527876741250};\\\", \\\"{x:951,y:750,t:1527876741267};\\\", \\\"{x:972,y:749,t:1527876741284};\\\", \\\"{x:977,y:749,t:1527876741301};\\\", \\\"{x:979,y:749,t:1527876741317};\\\", \\\"{x:980,y:749,t:1527876741641};\\\", \\\"{x:980,y:750,t:1527876741655};\\\", \\\"{x:980,y:752,t:1527876741671};\\\", \\\"{x:980,y:753,t:1527876741684};\\\", \\\"{x:979,y:757,t:1527876741701};\\\", \\\"{x:977,y:763,t:1527876741718};\\\", \\\"{x:976,y:770,t:1527876741735};\\\", \\\"{x:973,y:775,t:1527876741751};\\\", \\\"{x:973,y:776,t:1527876741767};\\\", \\\"{x:973,y:777,t:1527876741784};\\\", \\\"{x:973,y:779,t:1527876741806};\\\", \\\"{x:972,y:779,t:1527876741822};\\\", \\\"{x:977,y:782,t:1527876741950};\\\", \\\"{x:982,y:782,t:1527876741968};\\\", \\\"{x:993,y:782,t:1527876741984};\\\", \\\"{x:1001,y:780,t:1527876742001};\\\", \\\"{x:1006,y:776,t:1527876742018};\\\", \\\"{x:1018,y:776,t:1527876742034};\\\", \\\"{x:1020,y:776,t:1527876742050};\\\", \\\"{x:1037,y:771,t:1527876742067};\\\", \\\"{x:1048,y:762,t:1527876742084};\\\", \\\"{x:1060,y:756,t:1527876742101};\\\", \\\"{x:1073,y:745,t:1527876742119};\\\", \\\"{x:1084,y:735,t:1527876742134};\\\", \\\"{x:1106,y:717,t:1527876742151};\\\", \\\"{x:1121,y:704,t:1527876742168};\\\", \\\"{x:1143,y:690,t:1527876742184};\\\", \\\"{x:1162,y:677,t:1527876742201};\\\", \\\"{x:1178,y:664,t:1527876742218};\\\", \\\"{x:1200,y:648,t:1527876742234};\\\", \\\"{x:1218,y:632,t:1527876742251};\\\", \\\"{x:1226,y:623,t:1527876742268};\\\", \\\"{x:1240,y:608,t:1527876742284};\\\", \\\"{x:1264,y:589,t:1527876742301};\\\", \\\"{x:1285,y:571,t:1527876742318};\\\", \\\"{x:1297,y:557,t:1527876742335};\\\", \\\"{x:1307,y:547,t:1527876742351};\\\", \\\"{x:1307,y:546,t:1527876742368};\\\", \\\"{x:1307,y:545,t:1527876742385};\\\", \\\"{x:1307,y:543,t:1527876742431};\\\", \\\"{x:1307,y:542,t:1527876742441};\\\", \\\"{x:1307,y:540,t:1527876742455};\\\", \\\"{x:1306,y:540,t:1527876742598};\\\", \\\"{x:1304,y:541,t:1527876742606};\\\", \\\"{x:1302,y:544,t:1527876742618};\\\", \\\"{x:1299,y:547,t:1527876742635};\\\", \\\"{x:1297,y:551,t:1527876742651};\\\", \\\"{x:1294,y:553,t:1527876742668};\\\", \\\"{x:1292,y:555,t:1527876742685};\\\", \\\"{x:1291,y:555,t:1527876742701};\\\", \\\"{x:1289,y:556,t:1527876742768};\\\", \\\"{x:1289,y:557,t:1527876742791};\\\", \\\"{x:1288,y:557,t:1527876742824};\\\", \\\"{x:1286,y:558,t:1527876742836};\\\", \\\"{x:1284,y:560,t:1527876742857};\\\", \\\"{x:1283,y:561,t:1527876742951};\\\", \\\"{x:1282,y:561,t:1527876742968};\\\", \\\"{x:1281,y:561,t:1527876743064};\\\", \\\"{x:1279,y:561,t:1527876743103};\\\", \\\"{x:1278,y:561,t:1527876743127};\\\", \\\"{x:1276,y:560,t:1527876743183};\\\", \\\"{x:1274,y:558,t:1527876743200};\\\", \\\"{x:1271,y:558,t:1527876743224};\\\", \\\"{x:1270,y:557,t:1527876743263};\\\", \\\"{x:1270,y:556,t:1527876743271};\\\", \\\"{x:1270,y:557,t:1527876743542};\\\", \\\"{x:1271,y:557,t:1527876743559};\\\", \\\"{x:1271,y:559,t:1527876743568};\\\", \\\"{x:1272,y:559,t:1527876743585};\\\", \\\"{x:1274,y:560,t:1527876743602};\\\", \\\"{x:1275,y:562,t:1527876743619};\\\", \\\"{x:1276,y:563,t:1527876743636};\\\", \\\"{x:1279,y:566,t:1527876743668};\\\", \\\"{x:1280,y:568,t:1527876743685};\\\", \\\"{x:1281,y:569,t:1527876743702};\\\", \\\"{x:1282,y:569,t:1527876743720};\\\", \\\"{x:1283,y:571,t:1527876743735};\\\", \\\"{x:1283,y:570,t:1527876744080};\\\", \\\"{x:1283,y:569,t:1527876744087};\\\", \\\"{x:1283,y:568,t:1527876744103};\\\", \\\"{x:1282,y:567,t:1527876744120};\\\", \\\"{x:1282,y:566,t:1527876744136};\\\", \\\"{x:1282,y:565,t:1527876744152};\\\", \\\"{x:1282,y:564,t:1527876744175};\\\", \\\"{x:1282,y:563,t:1527876744271};\\\", \\\"{x:1282,y:562,t:1527876744295};\\\", \\\"{x:1282,y:561,t:1527876744319};\\\", \\\"{x:1282,y:560,t:1527876744335};\\\", \\\"{x:1281,y:560,t:1527876744359};\\\", \\\"{x:1281,y:559,t:1527876744399};\\\", \\\"{x:1280,y:559,t:1527876744543};\\\", \\\"{x:1280,y:557,t:1527876744808};\\\", \\\"{x:1280,y:556,t:1527876744820};\\\", \\\"{x:1280,y:552,t:1527876744836};\\\", \\\"{x:1279,y:546,t:1527876744852};\\\", \\\"{x:1278,y:543,t:1527876744870};\\\", \\\"{x:1277,y:540,t:1527876744886};\\\", \\\"{x:1277,y:538,t:1527876744902};\\\", \\\"{x:1277,y:536,t:1527876744920};\\\", \\\"{x:1277,y:535,t:1527876745008};\\\", \\\"{x:1274,y:538,t:1527876745023};\\\", \\\"{x:1272,y:543,t:1527876745036};\\\", \\\"{x:1269,y:549,t:1527876745052};\\\", \\\"{x:1268,y:551,t:1527876745070};\\\", \\\"{x:1266,y:555,t:1527876745086};\\\", \\\"{x:1264,y:559,t:1527876745103};\\\", \\\"{x:1260,y:565,t:1527876745119};\\\", \\\"{x:1260,y:568,t:1527876745137};\\\", \\\"{x:1261,y:568,t:1527876745240};\\\", \\\"{x:1265,y:568,t:1527876745252};\\\", \\\"{x:1276,y:567,t:1527876745270};\\\", \\\"{x:1288,y:566,t:1527876745287};\\\", \\\"{x:1302,y:566,t:1527876745303};\\\", \\\"{x:1330,y:566,t:1527876745320};\\\", \\\"{x:1345,y:566,t:1527876745336};\\\", \\\"{x:1355,y:566,t:1527876745353};\\\", \\\"{x:1367,y:566,t:1527876745370};\\\", \\\"{x:1372,y:566,t:1527876745387};\\\", \\\"{x:1375,y:566,t:1527876745403};\\\", \\\"{x:1377,y:566,t:1527876745424};\\\", \\\"{x:1378,y:566,t:1527876745436};\\\", \\\"{x:1380,y:564,t:1527876745452};\\\", \\\"{x:1383,y:562,t:1527876745470};\\\", \\\"{x:1389,y:560,t:1527876745487};\\\", \\\"{x:1393,y:559,t:1527876745503};\\\", \\\"{x:1395,y:559,t:1527876745520};\\\", \\\"{x:1396,y:558,t:1527876745543};\\\", \\\"{x:1396,y:557,t:1527876745559};\\\", \\\"{x:1398,y:557,t:1527876745575};\\\", \\\"{x:1399,y:556,t:1527876745591};\\\", \\\"{x:1400,y:556,t:1527876745604};\\\", \\\"{x:1401,y:556,t:1527876745620};\\\", \\\"{x:1402,y:556,t:1527876745637};\\\", \\\"{x:1403,y:556,t:1527876745688};\\\", \\\"{x:1404,y:556,t:1527876745703};\\\", \\\"{x:1405,y:555,t:1527876745720};\\\", \\\"{x:1406,y:555,t:1527876745768};\\\", \\\"{x:1407,y:555,t:1527876745783};\\\", \\\"{x:1408,y:555,t:1527876745807};\\\", \\\"{x:1409,y:555,t:1527876745831};\\\", \\\"{x:1410,y:555,t:1527876745841};\\\", \\\"{x:1411,y:555,t:1527876745926};\\\", \\\"{x:1412,y:555,t:1527876745958};\\\", \\\"{x:1413,y:555,t:1527876746031};\\\", \\\"{x:1414,y:555,t:1527876746063};\\\", \\\"{x:1414,y:556,t:1527876746088};\\\", \\\"{x:1414,y:557,t:1527876746111};\\\", \\\"{x:1414,y:559,t:1527876746288};\\\", \\\"{x:1411,y:563,t:1527876746303};\\\", \\\"{x:1389,y:566,t:1527876746321};\\\", \\\"{x:1370,y:572,t:1527876746337};\\\", \\\"{x:1348,y:576,t:1527876746354};\\\", \\\"{x:1328,y:576,t:1527876746371};\\\", \\\"{x:1314,y:576,t:1527876746387};\\\", \\\"{x:1306,y:576,t:1527876746403};\\\", \\\"{x:1304,y:576,t:1527876746421};\\\", \\\"{x:1302,y:576,t:1527876746436};\\\", \\\"{x:1301,y:576,t:1527876746453};\\\", \\\"{x:1300,y:576,t:1527876746470};\\\", \\\"{x:1299,y:576,t:1527876746487};\\\", \\\"{x:1298,y:576,t:1527876746503};\\\", \\\"{x:1297,y:576,t:1527876746527};\\\", \\\"{x:1296,y:575,t:1527876746537};\\\", \\\"{x:1295,y:574,t:1527876746553};\\\", \\\"{x:1292,y:574,t:1527876746571};\\\", \\\"{x:1289,y:570,t:1527876746587};\\\", \\\"{x:1285,y:567,t:1527876746604};\\\", \\\"{x:1279,y:563,t:1527876746621};\\\", \\\"{x:1275,y:561,t:1527876746638};\\\", \\\"{x:1274,y:560,t:1527876746653};\\\", \\\"{x:1271,y:558,t:1527876746671};\\\", \\\"{x:1270,y:557,t:1527876746687};\\\", \\\"{x:1267,y:557,t:1527876746703};\\\", \\\"{x:1266,y:557,t:1527876746727};\\\", \\\"{x:1266,y:556,t:1527876746736};\\\", \\\"{x:1267,y:557,t:1527876746918};\\\", \\\"{x:1269,y:557,t:1527876746926};\\\", \\\"{x:1270,y:557,t:1527876746937};\\\", \\\"{x:1273,y:559,t:1527876746953};\\\", \\\"{x:1274,y:559,t:1527876746970};\\\", \\\"{x:1279,y:559,t:1527876746987};\\\", \\\"{x:1280,y:559,t:1527876747003};\\\", \\\"{x:1282,y:559,t:1527876747020};\\\", \\\"{x:1283,y:559,t:1527876747704};\\\", \\\"{x:1283,y:563,t:1527876747720};\\\", \\\"{x:1282,y:565,t:1527876747738};\\\", \\\"{x:1281,y:567,t:1527876747755};\\\", \\\"{x:1280,y:568,t:1527876747783};\\\", \\\"{x:1280,y:569,t:1527876747889};\\\", \\\"{x:1278,y:570,t:1527876747905};\\\", \\\"{x:1277,y:574,t:1527876747921};\\\", \\\"{x:1273,y:580,t:1527876747938};\\\", \\\"{x:1271,y:585,t:1527876747955};\\\", \\\"{x:1268,y:591,t:1527876747971};\\\", \\\"{x:1267,y:595,t:1527876747988};\\\", \\\"{x:1265,y:599,t:1527876748005};\\\", \\\"{x:1265,y:601,t:1527876748021};\\\", \\\"{x:1265,y:602,t:1527876748055};\\\", \\\"{x:1265,y:598,t:1527876748288};\\\", \\\"{x:1266,y:594,t:1527876748305};\\\", \\\"{x:1266,y:590,t:1527876748322};\\\", \\\"{x:1266,y:589,t:1527876748338};\\\", \\\"{x:1266,y:587,t:1527876748354};\\\", \\\"{x:1266,y:586,t:1527876748375};\\\", \\\"{x:1266,y:585,t:1527876748388};\\\", \\\"{x:1266,y:584,t:1527876748405};\\\", \\\"{x:1266,y:582,t:1527876748421};\\\", \\\"{x:1266,y:581,t:1527876748438};\\\", \\\"{x:1266,y:578,t:1527876748455};\\\", \\\"{x:1266,y:576,t:1527876748479};\\\", \\\"{x:1267,y:572,t:1527876748495};\\\", \\\"{x:1267,y:571,t:1527876748511};\\\", \\\"{x:1268,y:570,t:1527876748521};\\\", \\\"{x:1269,y:566,t:1527876748538};\\\", \\\"{x:1270,y:565,t:1527876748555};\\\", \\\"{x:1271,y:563,t:1527876748572};\\\", \\\"{x:1274,y:560,t:1527876748588};\\\", \\\"{x:1275,y:560,t:1527876748604};\\\", \\\"{x:1275,y:559,t:1527876748622};\\\", \\\"{x:1276,y:558,t:1527876748647};\\\", \\\"{x:1277,y:558,t:1527876748679};\\\", \\\"{x:1277,y:557,t:1527876748735};\\\", \\\"{x:1278,y:557,t:1527876748751};\\\", \\\"{x:1279,y:557,t:1527876748775};\\\", \\\"{x:1280,y:557,t:1527876748787};\\\", \\\"{x:1282,y:557,t:1527876748814};\\\", \\\"{x:1283,y:556,t:1527876756455};\\\", \\\"{x:1285,y:557,t:1527876756487};\\\", \\\"{x:1285,y:558,t:1527876756500};\\\", \\\"{x:1285,y:560,t:1527876756518};\\\", \\\"{x:1285,y:561,t:1527876756838};\\\", \\\"{x:1286,y:562,t:1527876756853};\\\", \\\"{x:1286,y:563,t:1527876756918};\\\", \\\"{x:1286,y:564,t:1527876756949};\\\", \\\"{x:1285,y:566,t:1527876757487};\\\", \\\"{x:1279,y:569,t:1527876757500};\\\", \\\"{x:1266,y:573,t:1527876757517};\\\", \\\"{x:1242,y:578,t:1527876757533};\\\", \\\"{x:1218,y:584,t:1527876757550};\\\", \\\"{x:1175,y:590,t:1527876757567};\\\", \\\"{x:1153,y:594,t:1527876757583};\\\", \\\"{x:1130,y:597,t:1527876757600};\\\", \\\"{x:1106,y:600,t:1527876757616};\\\", \\\"{x:1084,y:600,t:1527876757633};\\\", \\\"{x:1039,y:604,t:1527876757649};\\\", \\\"{x:1003,y:608,t:1527876757667};\\\", \\\"{x:991,y:612,t:1527876757683};\\\", \\\"{x:967,y:615,t:1527876757700};\\\", \\\"{x:943,y:619,t:1527876757717};\\\", \\\"{x:926,y:624,t:1527876757733};\\\", \\\"{x:907,y:624,t:1527876757750};\\\", \\\"{x:900,y:625,t:1527876757774};\\\", \\\"{x:896,y:625,t:1527876757789};\\\", \\\"{x:874,y:625,t:1527876757806};\\\", \\\"{x:845,y:617,t:1527876757823};\\\", \\\"{x:822,y:609,t:1527876757840};\\\", \\\"{x:799,y:600,t:1527876757857};\\\", \\\"{x:774,y:588,t:1527876757874};\\\", \\\"{x:752,y:579,t:1527876757889};\\\", \\\"{x:732,y:566,t:1527876757907};\\\", \\\"{x:719,y:554,t:1527876757924};\\\", \\\"{x:705,y:544,t:1527876757940};\\\", \\\"{x:695,y:538,t:1527876757956};\\\", \\\"{x:684,y:531,t:1527876757974};\\\", \\\"{x:678,y:527,t:1527876757989};\\\", \\\"{x:676,y:523,t:1527876758007};\\\", \\\"{x:673,y:522,t:1527876758087};\\\", \\\"{x:670,y:521,t:1527876758095};\\\", \\\"{x:665,y:520,t:1527876758107};\\\", \\\"{x:658,y:517,t:1527876758126};\\\", \\\"{x:650,y:514,t:1527876758141};\\\", \\\"{x:642,y:513,t:1527876758156};\\\", \\\"{x:639,y:513,t:1527876758173};\\\", \\\"{x:634,y:511,t:1527876758191};\\\", \\\"{x:631,y:510,t:1527876758206};\\\", \\\"{x:627,y:508,t:1527876758224};\\\", \\\"{x:624,y:507,t:1527876758241};\\\", \\\"{x:618,y:504,t:1527876758257};\\\", \\\"{x:615,y:502,t:1527876758274};\\\", \\\"{x:613,y:501,t:1527876758290};\\\", \\\"{x:610,y:499,t:1527876758307};\\\", \\\"{x:609,y:499,t:1527876758326};\\\", \\\"{x:608,y:498,t:1527876758358};\\\", \\\"{x:607,y:498,t:1527876758566};\\\", \\\"{x:613,y:499,t:1527876758590};\\\", \\\"{x:624,y:503,t:1527876758607};\\\", \\\"{x:646,y:512,t:1527876758624};\\\", \\\"{x:671,y:523,t:1527876758641};\\\", \\\"{x:695,y:532,t:1527876758658};\\\", \\\"{x:729,y:539,t:1527876758675};\\\", \\\"{x:741,y:541,t:1527876758691};\\\", \\\"{x:772,y:551,t:1527876758707};\\\", \\\"{x:800,y:559,t:1527876758724};\\\", \\\"{x:813,y:567,t:1527876758741};\\\", \\\"{x:826,y:569,t:1527876758758};\\\", \\\"{x:829,y:569,t:1527876758774};\\\", \\\"{x:830,y:569,t:1527876758790};\\\", \\\"{x:831,y:570,t:1527876758814};\\\", \\\"{x:831,y:569,t:1527876758895};\\\", \\\"{x:831,y:564,t:1527876758909};\\\", \\\"{x:831,y:557,t:1527876758924};\\\", \\\"{x:834,y:550,t:1527876758941};\\\", \\\"{x:834,y:545,t:1527876758958};\\\", \\\"{x:835,y:538,t:1527876758974};\\\", \\\"{x:835,y:535,t:1527876758990};\\\", \\\"{x:835,y:533,t:1527876759007};\\\", \\\"{x:835,y:535,t:1527876759222};\\\", \\\"{x:833,y:542,t:1527876759230};\\\", \\\"{x:828,y:548,t:1527876759240};\\\", \\\"{x:809,y:562,t:1527876759258};\\\", \\\"{x:790,y:574,t:1527876759275};\\\", \\\"{x:780,y:587,t:1527876759290};\\\", \\\"{x:771,y:599,t:1527876759308};\\\", \\\"{x:767,y:608,t:1527876759325};\\\", \\\"{x:758,y:618,t:1527876759341};\\\", \\\"{x:746,y:629,t:1527876759357};\\\", \\\"{x:725,y:654,t:1527876759374};\\\", \\\"{x:709,y:667,t:1527876759390};\\\", \\\"{x:699,y:680,t:1527876759408};\\\", \\\"{x:688,y:688,t:1527876759425};\\\", \\\"{x:679,y:695,t:1527876759442};\\\", \\\"{x:668,y:701,t:1527876759458};\\\", \\\"{x:660,y:704,t:1527876759474};\\\", \\\"{x:650,y:709,t:1527876759491};\\\", \\\"{x:640,y:713,t:1527876759507};\\\", \\\"{x:632,y:718,t:1527876759525};\\\", \\\"{x:628,y:720,t:1527876759541};\\\", \\\"{x:622,y:724,t:1527876759558};\\\", \\\"{x:607,y:731,t:1527876759575};\\\", \\\"{x:597,y:737,t:1527876759591};\\\", \\\"{x:587,y:741,t:1527876759608};\\\", \\\"{x:580,y:742,t:1527876759625};\\\", \\\"{x:575,y:743,t:1527876759642};\\\", \\\"{x:563,y:743,t:1527876759658};\\\", \\\"{x:561,y:743,t:1527876759675};\\\", \\\"{x:557,y:743,t:1527876759692};\\\", \\\"{x:553,y:743,t:1527876759708};\\\", \\\"{x:550,y:743,t:1527876759725};\\\", \\\"{x:545,y:743,t:1527876759741};\\\", \\\"{x:539,y:742,t:1527876759758};\\\", \\\"{x:536,y:741,t:1527876759775};\\\", \\\"{x:539,y:741,t:1527876760175};\\\", \\\"{x:544,y:741,t:1527876760192};\\\", \\\"{x:551,y:741,t:1527876760209};\\\", \\\"{x:566,y:741,t:1527876760225};\\\", \\\"{x:589,y:741,t:1527876760242};\\\", \\\"{x:607,y:741,t:1527876760259};\\\", \\\"{x:623,y:741,t:1527876760275};\\\", \\\"{x:642,y:741,t:1527876760292};\\\", \\\"{x:665,y:741,t:1527876760309};\\\", \\\"{x:690,y:741,t:1527876760326};\\\", \\\"{x:711,y:741,t:1527876760342};\\\", \\\"{x:729,y:738,t:1527876760358};\\\", \\\"{x:738,y:735,t:1527876760376};\\\", \\\"{x:742,y:735,t:1527876760392};\\\", \\\"{x:749,y:732,t:1527876760409};\\\", \\\"{x:758,y:730,t:1527876760426};\\\", \\\"{x:766,y:727,t:1527876760442};\\\", \\\"{x:769,y:726,t:1527876760459};\\\", \\\"{x:778,y:725,t:1527876760476};\\\", \\\"{x:785,y:723,t:1527876760492};\\\", \\\"{x:787,y:723,t:1527876760509};\\\", \\\"{x:790,y:723,t:1527876760526};\\\", \\\"{x:793,y:723,t:1527876760542};\\\", \\\"{x:794,y:723,t:1527876760623};\\\", \\\"{x:796,y:723,t:1527876760639};\\\", \\\"{x:797,y:721,t:1527876760646};\\\", \\\"{x:798,y:721,t:1527876760659};\\\", \\\"{x:798,y:719,t:1527876760676};\\\", \\\"{x:801,y:716,t:1527876760692};\\\", \\\"{x:801,y:715,t:1527876760709};\\\", \\\"{x:801,y:713,t:1527876760726};\\\" ] }, { \\\"rt\\\": 31758, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 398535, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-B -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:804,y:719,t:1527876771590};\\\", \\\"{x:809,y:728,t:1527876771600};\\\", \\\"{x:811,y:732,t:1527876771617};\\\", \\\"{x:811,y:733,t:1527876771633};\\\", \\\"{x:811,y:736,t:1527876771653};\\\", \\\"{x:813,y:741,t:1527876771667};\\\", \\\"{x:814,y:744,t:1527876771684};\\\", \\\"{x:818,y:751,t:1527876771700};\\\", \\\"{x:820,y:755,t:1527876771717};\\\", \\\"{x:825,y:761,t:1527876771734};\\\", \\\"{x:832,y:771,t:1527876771750};\\\", \\\"{x:835,y:776,t:1527876771767};\\\", \\\"{x:836,y:778,t:1527876771784};\\\", \\\"{x:839,y:784,t:1527876771800};\\\", \\\"{x:844,y:789,t:1527876771817};\\\", \\\"{x:853,y:798,t:1527876771834};\\\", \\\"{x:862,y:807,t:1527876771850};\\\", \\\"{x:872,y:815,t:1527876771867};\\\", \\\"{x:890,y:832,t:1527876771884};\\\", \\\"{x:905,y:844,t:1527876771900};\\\", \\\"{x:927,y:868,t:1527876771917};\\\", \\\"{x:962,y:890,t:1527876771933};\\\", \\\"{x:967,y:900,t:1527876771950};\\\", \\\"{x:1002,y:911,t:1527876771968};\\\", \\\"{x:1027,y:918,t:1527876771984};\\\", \\\"{x:1087,y:933,t:1527876772000};\\\", \\\"{x:1151,y:941,t:1527876772017};\\\", \\\"{x:1198,y:949,t:1527876772034};\\\", \\\"{x:1251,y:965,t:1527876772051};\\\", \\\"{x:1269,y:969,t:1527876772067};\\\", \\\"{x:1296,y:971,t:1527876772084};\\\", \\\"{x:1301,y:971,t:1527876772101};\\\", \\\"{x:1316,y:971,t:1527876772117};\\\", \\\"{x:1336,y:963,t:1527876772134};\\\", \\\"{x:1353,y:954,t:1527876772152};\\\", \\\"{x:1372,y:946,t:1527876772167};\\\", \\\"{x:1385,y:940,t:1527876772184};\\\", \\\"{x:1392,y:937,t:1527876772201};\\\", \\\"{x:1395,y:937,t:1527876772217};\\\", \\\"{x:1396,y:937,t:1527876772234};\\\", \\\"{x:1398,y:937,t:1527876772251};\\\", \\\"{x:1399,y:937,t:1527876772846};\\\", \\\"{x:1402,y:937,t:1527876772878};\\\", \\\"{x:1403,y:937,t:1527876772910};\\\", \\\"{x:1405,y:937,t:1527876772918};\\\", \\\"{x:1410,y:937,t:1527876772935};\\\", \\\"{x:1415,y:937,t:1527876772951};\\\", \\\"{x:1417,y:937,t:1527876772968};\\\", \\\"{x:1419,y:937,t:1527876772985};\\\", \\\"{x:1419,y:936,t:1527876773054};\\\", \\\"{x:1419,y:935,t:1527876773078};\\\", \\\"{x:1419,y:934,t:1527876773102};\\\", \\\"{x:1416,y:931,t:1527876773117};\\\", \\\"{x:1405,y:931,t:1527876773135};\\\", \\\"{x:1394,y:930,t:1527876773151};\\\", \\\"{x:1383,y:930,t:1527876773168};\\\", \\\"{x:1362,y:932,t:1527876773185};\\\", \\\"{x:1353,y:932,t:1527876773201};\\\", \\\"{x:1353,y:933,t:1527876774102};\\\", \\\"{x:1353,y:934,t:1527876774119};\\\", \\\"{x:1355,y:937,t:1527876774135};\\\", \\\"{x:1364,y:941,t:1527876774152};\\\", \\\"{x:1373,y:941,t:1527876774169};\\\", \\\"{x:1386,y:944,t:1527876774185};\\\", \\\"{x:1397,y:947,t:1527876774203};\\\", \\\"{x:1404,y:948,t:1527876774219};\\\", \\\"{x:1412,y:949,t:1527876774235};\\\", \\\"{x:1421,y:949,t:1527876774252};\\\", \\\"{x:1424,y:949,t:1527876774269};\\\", \\\"{x:1424,y:947,t:1527876774317};\\\", \\\"{x:1426,y:944,t:1527876774325};\\\", \\\"{x:1428,y:942,t:1527876774336};\\\", \\\"{x:1435,y:933,t:1527876774353};\\\", \\\"{x:1437,y:927,t:1527876774369};\\\", \\\"{x:1440,y:918,t:1527876774385};\\\", \\\"{x:1446,y:907,t:1527876774402};\\\", \\\"{x:1452,y:898,t:1527876774420};\\\", \\\"{x:1457,y:891,t:1527876774437};\\\", \\\"{x:1458,y:888,t:1527876774452};\\\", \\\"{x:1461,y:886,t:1527876774470};\\\", \\\"{x:1462,y:884,t:1527876774486};\\\", \\\"{x:1463,y:884,t:1527876774518};\\\", \\\"{x:1463,y:883,t:1527876774533};\\\", \\\"{x:1462,y:883,t:1527876774606};\\\", \\\"{x:1459,y:883,t:1527876774619};\\\", \\\"{x:1454,y:886,t:1527876774636};\\\", \\\"{x:1444,y:893,t:1527876774652};\\\", \\\"{x:1436,y:901,t:1527876774669};\\\", \\\"{x:1422,y:912,t:1527876774686};\\\", \\\"{x:1412,y:918,t:1527876774702};\\\", \\\"{x:1398,y:923,t:1527876774719};\\\", \\\"{x:1386,y:927,t:1527876774737};\\\", \\\"{x:1374,y:932,t:1527876774752};\\\", \\\"{x:1365,y:937,t:1527876774770};\\\", \\\"{x:1353,y:939,t:1527876774786};\\\", \\\"{x:1344,y:943,t:1527876774802};\\\", \\\"{x:1338,y:944,t:1527876774819};\\\", \\\"{x:1337,y:946,t:1527876774836};\\\", \\\"{x:1336,y:947,t:1527876774852};\\\", \\\"{x:1335,y:947,t:1527876774869};\\\", \\\"{x:1334,y:949,t:1527876775134};\\\", \\\"{x:1334,y:950,t:1527876775214};\\\", \\\"{x:1334,y:951,t:1527876775270};\\\", \\\"{x:1334,y:952,t:1527876775286};\\\", \\\"{x:1334,y:954,t:1527876775303};\\\", \\\"{x:1334,y:955,t:1527876775319};\\\", \\\"{x:1334,y:956,t:1527876775350};\\\", \\\"{x:1334,y:958,t:1527876775366};\\\", \\\"{x:1334,y:959,t:1527876775382};\\\", \\\"{x:1334,y:960,t:1527876775390};\\\", \\\"{x:1334,y:961,t:1527876775406};\\\", \\\"{x:1334,y:958,t:1527876775534};\\\", \\\"{x:1334,y:954,t:1527876775542};\\\", \\\"{x:1335,y:950,t:1527876775553};\\\", \\\"{x:1340,y:940,t:1527876775570};\\\", \\\"{x:1351,y:926,t:1527876775586};\\\", \\\"{x:1360,y:914,t:1527876775604};\\\", \\\"{x:1366,y:902,t:1527876775621};\\\", \\\"{x:1369,y:891,t:1527876775636};\\\", \\\"{x:1374,y:882,t:1527876775654};\\\", \\\"{x:1380,y:866,t:1527876775670};\\\", \\\"{x:1385,y:854,t:1527876775686};\\\", \\\"{x:1386,y:841,t:1527876775704};\\\", \\\"{x:1387,y:830,t:1527876775721};\\\", \\\"{x:1387,y:825,t:1527876775736};\\\", \\\"{x:1387,y:816,t:1527876775753};\\\", \\\"{x:1387,y:807,t:1527876775771};\\\", \\\"{x:1387,y:803,t:1527876775786};\\\", \\\"{x:1384,y:798,t:1527876775804};\\\", \\\"{x:1382,y:796,t:1527876775821};\\\", \\\"{x:1381,y:794,t:1527876775836};\\\", \\\"{x:1380,y:794,t:1527876775854};\\\", \\\"{x:1378,y:791,t:1527876775870};\\\", \\\"{x:1375,y:788,t:1527876775887};\\\", \\\"{x:1373,y:785,t:1527876775904};\\\", \\\"{x:1371,y:782,t:1527876775921};\\\", \\\"{x:1366,y:775,t:1527876775938};\\\", \\\"{x:1363,y:768,t:1527876775954};\\\", \\\"{x:1358,y:762,t:1527876775971};\\\", \\\"{x:1355,y:759,t:1527876775987};\\\", \\\"{x:1353,y:756,t:1527876776003};\\\", \\\"{x:1350,y:753,t:1527876776021};\\\", \\\"{x:1347,y:748,t:1527876776037};\\\", \\\"{x:1345,y:745,t:1527876776053};\\\", \\\"{x:1342,y:741,t:1527876776070};\\\", \\\"{x:1340,y:738,t:1527876776087};\\\", \\\"{x:1339,y:735,t:1527876776103};\\\", \\\"{x:1338,y:733,t:1527876776120};\\\", \\\"{x:1337,y:732,t:1527876776137};\\\", \\\"{x:1336,y:731,t:1527876776206};\\\", \\\"{x:1336,y:730,t:1527876776220};\\\", \\\"{x:1336,y:729,t:1527876776238};\\\", \\\"{x:1336,y:728,t:1527876776254};\\\", \\\"{x:1336,y:727,t:1527876776270};\\\", \\\"{x:1336,y:726,t:1527876776287};\\\", \\\"{x:1336,y:724,t:1527876776304};\\\", \\\"{x:1336,y:721,t:1527876776321};\\\", \\\"{x:1337,y:720,t:1527876776337};\\\", \\\"{x:1337,y:719,t:1527876776354};\\\", \\\"{x:1338,y:718,t:1527876776370};\\\", \\\"{x:1340,y:714,t:1527876776387};\\\", \\\"{x:1341,y:710,t:1527876776405};\\\", \\\"{x:1342,y:708,t:1527876776420};\\\", \\\"{x:1343,y:706,t:1527876776437};\\\", \\\"{x:1343,y:705,t:1527876776455};\\\", \\\"{x:1343,y:704,t:1527876776558};\\\", \\\"{x:1344,y:703,t:1527876776574};\\\", \\\"{x:1344,y:702,t:1527876776694};\\\", \\\"{x:1344,y:701,t:1527876776711};\\\", \\\"{x:1344,y:700,t:1527876776738};\\\", \\\"{x:1344,y:699,t:1527876776757};\\\", \\\"{x:1345,y:697,t:1527876776774};\\\", \\\"{x:1345,y:696,t:1527876776814};\\\", \\\"{x:1345,y:695,t:1527876776862};\\\", \\\"{x:1345,y:694,t:1527876776871};\\\", \\\"{x:1345,y:693,t:1527876776887};\\\", \\\"{x:1345,y:695,t:1527876787319};\\\", \\\"{x:1345,y:703,t:1527876787331};\\\", \\\"{x:1347,y:720,t:1527876787346};\\\", \\\"{x:1348,y:738,t:1527876787362};\\\", \\\"{x:1350,y:750,t:1527876787379};\\\", \\\"{x:1353,y:760,t:1527876787396};\\\", \\\"{x:1354,y:766,t:1527876787411};\\\", \\\"{x:1356,y:768,t:1527876787429};\\\", \\\"{x:1356,y:769,t:1527876787446};\\\", \\\"{x:1356,y:771,t:1527876787469};\\\", \\\"{x:1355,y:773,t:1527876787695};\\\", \\\"{x:1351,y:777,t:1527876787703};\\\", \\\"{x:1346,y:779,t:1527876787712};\\\", \\\"{x:1339,y:784,t:1527876787729};\\\", \\\"{x:1337,y:785,t:1527876787746};\\\", \\\"{x:1333,y:785,t:1527876787763};\\\", \\\"{x:1324,y:785,t:1527876787779};\\\", \\\"{x:1309,y:785,t:1527876787796};\\\", \\\"{x:1283,y:781,t:1527876787813};\\\", \\\"{x:1223,y:771,t:1527876787829};\\\", \\\"{x:1168,y:756,t:1527876787846};\\\", \\\"{x:1131,y:743,t:1527876787863};\\\", \\\"{x:1075,y:728,t:1527876787879};\\\", \\\"{x:992,y:703,t:1527876787896};\\\", \\\"{x:901,y:682,t:1527876787913};\\\", \\\"{x:818,y:669,t:1527876787928};\\\", \\\"{x:748,y:659,t:1527876787946};\\\", \\\"{x:689,y:649,t:1527876787963};\\\", \\\"{x:624,y:639,t:1527876787979};\\\", \\\"{x:550,y:632,t:1527876787996};\\\", \\\"{x:470,y:623,t:1527876788014};\\\", \\\"{x:444,y:620,t:1527876788029};\\\", \\\"{x:406,y:615,t:1527876788046};\\\", \\\"{x:381,y:611,t:1527876788065};\\\", \\\"{x:358,y:609,t:1527876788081};\\\", \\\"{x:350,y:609,t:1527876788098};\\\", \\\"{x:346,y:609,t:1527876788115};\\\", \\\"{x:345,y:609,t:1527876788158};\\\", \\\"{x:344,y:607,t:1527876788166};\\\", \\\"{x:342,y:605,t:1527876788181};\\\", \\\"{x:335,y:601,t:1527876788198};\\\", \\\"{x:331,y:599,t:1527876788216};\\\", \\\"{x:331,y:598,t:1527876788231};\\\", \\\"{x:330,y:597,t:1527876788247};\\\", \\\"{x:329,y:595,t:1527876788265};\\\", \\\"{x:327,y:592,t:1527876788282};\\\", \\\"{x:326,y:591,t:1527876788297};\\\", \\\"{x:324,y:589,t:1527876788315};\\\", \\\"{x:324,y:582,t:1527876788332};\\\", \\\"{x:324,y:577,t:1527876788348};\\\", \\\"{x:324,y:571,t:1527876788365};\\\", \\\"{x:333,y:562,t:1527876788382};\\\", \\\"{x:356,y:547,t:1527876788399};\\\", \\\"{x:364,y:539,t:1527876788415};\\\", \\\"{x:365,y:538,t:1527876788432};\\\", \\\"{x:364,y:538,t:1527876788448};\\\", \\\"{x:356,y:537,t:1527876788465};\\\", \\\"{x:342,y:537,t:1527876788483};\\\", \\\"{x:321,y:541,t:1527876788498};\\\", \\\"{x:296,y:555,t:1527876788514};\\\", \\\"{x:275,y:574,t:1527876788533};\\\", \\\"{x:265,y:587,t:1527876788549};\\\", \\\"{x:263,y:600,t:1527876788566};\\\", \\\"{x:258,y:610,t:1527876788581};\\\", \\\"{x:257,y:612,t:1527876788597};\\\", \\\"{x:257,y:613,t:1527876788614};\\\", \\\"{x:257,y:610,t:1527876788670};\\\", \\\"{x:254,y:600,t:1527876788681};\\\", \\\"{x:251,y:589,t:1527876788698};\\\", \\\"{x:245,y:574,t:1527876788715};\\\", \\\"{x:238,y:563,t:1527876788732};\\\", \\\"{x:236,y:555,t:1527876788749};\\\", \\\"{x:232,y:553,t:1527876788764};\\\", \\\"{x:229,y:551,t:1527876788782};\\\", \\\"{x:228,y:551,t:1527876788799};\\\", \\\"{x:227,y:551,t:1527876788815};\\\", \\\"{x:226,y:551,t:1527876788871};\\\", \\\"{x:225,y:551,t:1527876788886};\\\", \\\"{x:224,y:551,t:1527876788899};\\\", \\\"{x:220,y:551,t:1527876788916};\\\", \\\"{x:213,y:550,t:1527876788932};\\\", \\\"{x:205,y:545,t:1527876788949};\\\", \\\"{x:201,y:543,t:1527876788965};\\\", \\\"{x:196,y:541,t:1527876788982};\\\", \\\"{x:187,y:540,t:1527876788999};\\\", \\\"{x:186,y:540,t:1527876789015};\\\", \\\"{x:185,y:539,t:1527876789253};\\\", \\\"{x:188,y:539,t:1527876789266};\\\", \\\"{x:242,y:540,t:1527876789283};\\\", \\\"{x:282,y:540,t:1527876789300};\\\", \\\"{x:318,y:540,t:1527876789316};\\\", \\\"{x:337,y:540,t:1527876789331};\\\", \\\"{x:352,y:540,t:1527876789348};\\\", \\\"{x:373,y:540,t:1527876789366};\\\", \\\"{x:388,y:540,t:1527876789382};\\\", \\\"{x:405,y:541,t:1527876789399};\\\", \\\"{x:425,y:541,t:1527876789417};\\\", \\\"{x:438,y:541,t:1527876789433};\\\", \\\"{x:465,y:541,t:1527876789449};\\\", \\\"{x:485,y:541,t:1527876789466};\\\", \\\"{x:503,y:541,t:1527876789483};\\\", \\\"{x:521,y:541,t:1527876789499};\\\", \\\"{x:525,y:541,t:1527876789516};\\\", \\\"{x:529,y:541,t:1527876789532};\\\", \\\"{x:531,y:541,t:1527876789549};\\\", \\\"{x:533,y:542,t:1527876789566};\\\", \\\"{x:534,y:542,t:1527876789581};\\\", \\\"{x:536,y:542,t:1527876789599};\\\", \\\"{x:537,y:542,t:1527876789616};\\\", \\\"{x:538,y:542,t:1527876789633};\\\", \\\"{x:541,y:543,t:1527876789655};\\\", \\\"{x:542,y:543,t:1527876789666};\\\", \\\"{x:552,y:543,t:1527876789683};\\\", \\\"{x:578,y:543,t:1527876789700};\\\", \\\"{x:596,y:543,t:1527876789717};\\\", \\\"{x:627,y:542,t:1527876789735};\\\", \\\"{x:653,y:542,t:1527876789749};\\\", \\\"{x:729,y:542,t:1527876789766};\\\", \\\"{x:761,y:542,t:1527876789782};\\\", \\\"{x:775,y:542,t:1527876789799};\\\", \\\"{x:778,y:542,t:1527876789816};\\\", \\\"{x:779,y:541,t:1527876789833};\\\", \\\"{x:780,y:540,t:1527876789848};\\\", \\\"{x:781,y:540,t:1527876789866};\\\", \\\"{x:781,y:539,t:1527876789894};\\\", \\\"{x:782,y:538,t:1527876789902};\\\", \\\"{x:782,y:537,t:1527876789916};\\\", \\\"{x:785,y:535,t:1527876789933};\\\", \\\"{x:788,y:529,t:1527876789949};\\\", \\\"{x:789,y:526,t:1527876789967};\\\", \\\"{x:791,y:524,t:1527876789990};\\\", \\\"{x:793,y:521,t:1527876789999};\\\", \\\"{x:800,y:517,t:1527876790018};\\\", \\\"{x:811,y:511,t:1527876790034};\\\", \\\"{x:817,y:505,t:1527876790050};\\\", \\\"{x:819,y:504,t:1527876790066};\\\", \\\"{x:825,y:502,t:1527876790083};\\\", \\\"{x:828,y:500,t:1527876790101};\\\", \\\"{x:834,y:497,t:1527876790115};\\\", \\\"{x:838,y:495,t:1527876790133};\\\", \\\"{x:841,y:493,t:1527876790149};\\\", \\\"{x:846,y:492,t:1527876790165};\\\", \\\"{x:849,y:490,t:1527876790183};\\\", \\\"{x:850,y:489,t:1527876790200};\\\", \\\"{x:849,y:489,t:1527876790415};\\\", \\\"{x:845,y:490,t:1527876790431};\\\", \\\"{x:836,y:506,t:1527876790450};\\\", \\\"{x:823,y:520,t:1527876790467};\\\", \\\"{x:812,y:534,t:1527876790483};\\\", \\\"{x:807,y:537,t:1527876790500};\\\", \\\"{x:807,y:538,t:1527876790574};\\\", \\\"{x:808,y:538,t:1527876790654};\\\", \\\"{x:809,y:534,t:1527876790667};\\\", \\\"{x:817,y:524,t:1527876790684};\\\", \\\"{x:827,y:513,t:1527876790701};\\\", \\\"{x:829,y:510,t:1527876790716};\\\", \\\"{x:831,y:507,t:1527876790732};\\\", \\\"{x:833,y:505,t:1527876790749};\\\", \\\"{x:836,y:502,t:1527876790766};\\\", \\\"{x:838,y:502,t:1527876790783};\\\", \\\"{x:838,y:501,t:1527876790799};\\\", \\\"{x:836,y:503,t:1527876791101};\\\", \\\"{x:822,y:517,t:1527876791118};\\\", \\\"{x:766,y:581,t:1527876791134};\\\", \\\"{x:713,y:628,t:1527876791151};\\\", \\\"{x:677,y:658,t:1527876791167};\\\", \\\"{x:649,y:684,t:1527876791184};\\\", \\\"{x:617,y:704,t:1527876791200};\\\", \\\"{x:603,y:719,t:1527876791217};\\\", \\\"{x:589,y:730,t:1527876791234};\\\", \\\"{x:581,y:742,t:1527876791250};\\\", \\\"{x:573,y:750,t:1527876791267};\\\", \\\"{x:559,y:762,t:1527876791284};\\\", \\\"{x:556,y:764,t:1527876791300};\\\", \\\"{x:550,y:773,t:1527876791317};\\\", \\\"{x:550,y:770,t:1527876791423};\\\", \\\"{x:549,y:763,t:1527876791433};\\\", \\\"{x:547,y:750,t:1527876791452};\\\", \\\"{x:545,y:740,t:1527876791467};\\\", \\\"{x:544,y:730,t:1527876791484};\\\", \\\"{x:540,y:725,t:1527876791501};\\\", \\\"{x:535,y:718,t:1527876791517};\\\", \\\"{x:535,y:717,t:1527876791991};\\\", \\\"{x:534,y:717,t:1527876792063};\\\", \\\"{x:534,y:718,t:1527876792070};\\\", \\\"{x:534,y:719,t:1527876792084};\\\", \\\"{x:534,y:723,t:1527876792103};\\\", \\\"{x:534,y:725,t:1527876792118};\\\", \\\"{x:534,y:726,t:1527876792133};\\\", \\\"{x:534,y:727,t:1527876792151};\\\", \\\"{x:534,y:728,t:1527876793286};\\\", \\\"{x:540,y:728,t:1527876793302};\\\", \\\"{x:551,y:729,t:1527876793319};\\\", \\\"{x:567,y:733,t:1527876793335};\\\", \\\"{x:581,y:735,t:1527876793352};\\\", \\\"{x:589,y:738,t:1527876793369};\\\", \\\"{x:593,y:739,t:1527876793386};\\\", \\\"{x:594,y:739,t:1527876793406};\\\", \\\"{x:595,y:739,t:1527876793895};\\\", \\\"{x:595,y:738,t:1527876793918};\\\", \\\"{x:595,y:737,t:1527876793942};\\\", \\\"{x:595,y:735,t:1527876794010};\\\" ] }, { \\\"rt\\\": 56325, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 456120, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -M -X -X -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:596,y:739,t:1527876797575};\\\", \\\"{x:602,y:747,t:1527876797596};\\\", \\\"{x:602,y:748,t:1527876797606};\\\", \\\"{x:607,y:753,t:1527876797621};\\\", \\\"{x:610,y:756,t:1527876797638};\\\", \\\"{x:611,y:757,t:1527876797655};\\\", \\\"{x:613,y:757,t:1527876797677};\\\", \\\"{x:614,y:757,t:1527876797839};\\\", \\\"{x:617,y:760,t:1527876797856};\\\", \\\"{x:619,y:762,t:1527876797873};\\\", \\\"{x:620,y:763,t:1527876797889};\\\", \\\"{x:622,y:766,t:1527876797906};\\\", \\\"{x:623,y:766,t:1527876797922};\\\", \\\"{x:627,y:766,t:1527876797940};\\\", \\\"{x:631,y:767,t:1527876797956};\\\", \\\"{x:639,y:770,t:1527876797973};\\\", \\\"{x:647,y:772,t:1527876797990};\\\", \\\"{x:665,y:775,t:1527876798006};\\\", \\\"{x:702,y:777,t:1527876798023};\\\", \\\"{x:719,y:780,t:1527876798040};\\\", \\\"{x:748,y:781,t:1527876798055};\\\", \\\"{x:780,y:781,t:1527876798073};\\\", \\\"{x:810,y:766,t:1527876798090};\\\", \\\"{x:844,y:747,t:1527876798106};\\\", \\\"{x:861,y:734,t:1527876798122};\\\", \\\"{x:878,y:720,t:1527876798139};\\\", \\\"{x:891,y:704,t:1527876798156};\\\", \\\"{x:900,y:693,t:1527876798173};\\\", \\\"{x:910,y:685,t:1527876798190};\\\", \\\"{x:916,y:678,t:1527876798206};\\\", \\\"{x:917,y:676,t:1527876798223};\\\", \\\"{x:917,y:675,t:1527876798254};\\\", \\\"{x:918,y:675,t:1527876799054};\\\", \\\"{x:919,y:676,t:1527876799062};\\\", \\\"{x:920,y:676,t:1527876799074};\\\", \\\"{x:920,y:677,t:1527876799090};\\\", \\\"{x:920,y:676,t:1527876799106};\\\", \\\"{x:920,y:675,t:1527876799143};\\\", \\\"{x:937,y:675,t:1527876799157};\\\", \\\"{x:1001,y:675,t:1527876799174};\\\", \\\"{x:1078,y:677,t:1527876799190};\\\", \\\"{x:1120,y:683,t:1527876799207};\\\", \\\"{x:1150,y:686,t:1527876799224};\\\", \\\"{x:1180,y:689,t:1527876799241};\\\", \\\"{x:1199,y:690,t:1527876799256};\\\", \\\"{x:1213,y:693,t:1527876799274};\\\", \\\"{x:1226,y:700,t:1527876799291};\\\", \\\"{x:1239,y:712,t:1527876799307};\\\", \\\"{x:1256,y:726,t:1527876799324};\\\", \\\"{x:1263,y:731,t:1527876799341};\\\", \\\"{x:1276,y:745,t:1527876799357};\\\", \\\"{x:1288,y:760,t:1527876799374};\\\", \\\"{x:1308,y:782,t:1527876799390};\\\", \\\"{x:1319,y:795,t:1527876799408};\\\", \\\"{x:1324,y:803,t:1527876799424};\\\", \\\"{x:1327,y:807,t:1527876799441};\\\", \\\"{x:1330,y:813,t:1527876799457};\\\", \\\"{x:1338,y:821,t:1527876799474};\\\", \\\"{x:1347,y:831,t:1527876799491};\\\", \\\"{x:1353,y:835,t:1527876799507};\\\", \\\"{x:1356,y:836,t:1527876799524};\\\", \\\"{x:1357,y:836,t:1527876799541};\\\", \\\"{x:1365,y:837,t:1527876799558};\\\", \\\"{x:1380,y:837,t:1527876799574};\\\", \\\"{x:1393,y:837,t:1527876799591};\\\", \\\"{x:1399,y:834,t:1527876799607};\\\", \\\"{x:1401,y:833,t:1527876799624};\\\", \\\"{x:1402,y:832,t:1527876799654};\\\", \\\"{x:1402,y:831,t:1527876799663};\\\", \\\"{x:1402,y:829,t:1527876799674};\\\", \\\"{x:1404,y:827,t:1527876799691};\\\", \\\"{x:1404,y:825,t:1527876799708};\\\", \\\"{x:1403,y:820,t:1527876799724};\\\", \\\"{x:1401,y:816,t:1527876799741};\\\", \\\"{x:1396,y:801,t:1527876799759};\\\", \\\"{x:1389,y:791,t:1527876799774};\\\", \\\"{x:1384,y:781,t:1527876799791};\\\", \\\"{x:1375,y:774,t:1527876799808};\\\", \\\"{x:1370,y:767,t:1527876799824};\\\", \\\"{x:1367,y:763,t:1527876799841};\\\", \\\"{x:1364,y:761,t:1527876799858};\\\", \\\"{x:1360,y:757,t:1527876799874};\\\", \\\"{x:1358,y:757,t:1527876799895};\\\", \\\"{x:1357,y:755,t:1527876799910};\\\", \\\"{x:1355,y:754,t:1527876799926};\\\", \\\"{x:1353,y:753,t:1527876799941};\\\", \\\"{x:1347,y:752,t:1527876799959};\\\", \\\"{x:1346,y:752,t:1527876800238};\\\", \\\"{x:1347,y:749,t:1527876800574};\\\", \\\"{x:1352,y:742,t:1527876800591};\\\", \\\"{x:1356,y:735,t:1527876800607};\\\", \\\"{x:1360,y:728,t:1527876800624};\\\", \\\"{x:1361,y:723,t:1527876800641};\\\", \\\"{x:1363,y:719,t:1527876800658};\\\", \\\"{x:1364,y:715,t:1527876800674};\\\", \\\"{x:1365,y:709,t:1527876800691};\\\", \\\"{x:1365,y:705,t:1527876800707};\\\", \\\"{x:1365,y:702,t:1527876800724};\\\", \\\"{x:1367,y:700,t:1527876800742};\\\", \\\"{x:1367,y:699,t:1527876800765};\\\", \\\"{x:1369,y:697,t:1527876800774};\\\", \\\"{x:1369,y:696,t:1527876800791};\\\", \\\"{x:1370,y:694,t:1527876800808};\\\", \\\"{x:1371,y:693,t:1527876800824};\\\", \\\"{x:1373,y:690,t:1527876800841};\\\", \\\"{x:1374,y:688,t:1527876800858};\\\", \\\"{x:1375,y:685,t:1527876800875};\\\", \\\"{x:1377,y:683,t:1527876800892};\\\", \\\"{x:1380,y:679,t:1527876800907};\\\", \\\"{x:1382,y:675,t:1527876800924};\\\", \\\"{x:1385,y:672,t:1527876800941};\\\", \\\"{x:1385,y:670,t:1527876800957};\\\", \\\"{x:1387,y:668,t:1527876800974};\\\", \\\"{x:1387,y:667,t:1527876801006};\\\", \\\"{x:1388,y:667,t:1527876801014};\\\", \\\"{x:1388,y:665,t:1527876801029};\\\", \\\"{x:1388,y:664,t:1527876801046};\\\", \\\"{x:1389,y:664,t:1527876801069};\\\", \\\"{x:1389,y:662,t:1527876801085};\\\", \\\"{x:1390,y:662,t:1527876801102};\\\", \\\"{x:1391,y:661,t:1527876801134};\\\", \\\"{x:1393,y:660,t:1527876801174};\\\", \\\"{x:1392,y:660,t:1527876801535};\\\", \\\"{x:1389,y:661,t:1527876801599};\\\", \\\"{x:1389,y:662,t:1527876801623};\\\", \\\"{x:1389,y:663,t:1527876801631};\\\", \\\"{x:1389,y:664,t:1527876801642};\\\", \\\"{x:1386,y:667,t:1527876801659};\\\", \\\"{x:1386,y:671,t:1527876801676};\\\", \\\"{x:1386,y:676,t:1527876801692};\\\", \\\"{x:1386,y:684,t:1527876801709};\\\", \\\"{x:1386,y:698,t:1527876801726};\\\", \\\"{x:1386,y:711,t:1527876801742};\\\", \\\"{x:1386,y:719,t:1527876801759};\\\", \\\"{x:1386,y:724,t:1527876801776};\\\", \\\"{x:1386,y:731,t:1527876801792};\\\", \\\"{x:1386,y:737,t:1527876801809};\\\", \\\"{x:1387,y:743,t:1527876801826};\\\", \\\"{x:1388,y:750,t:1527876801842};\\\", \\\"{x:1388,y:754,t:1527876801859};\\\", \\\"{x:1388,y:757,t:1527876801876};\\\", \\\"{x:1390,y:761,t:1527876801892};\\\", \\\"{x:1391,y:765,t:1527876801909};\\\", \\\"{x:1391,y:768,t:1527876801926};\\\", \\\"{x:1391,y:771,t:1527876801941};\\\", \\\"{x:1391,y:773,t:1527876801958};\\\", \\\"{x:1391,y:774,t:1527876801975};\\\", \\\"{x:1391,y:775,t:1527876801992};\\\", \\\"{x:1391,y:776,t:1527876802009};\\\", \\\"{x:1391,y:777,t:1527876802025};\\\", \\\"{x:1391,y:778,t:1527876802053};\\\", \\\"{x:1391,y:779,t:1527876802199};\\\", \\\"{x:1390,y:779,t:1527876802222};\\\", \\\"{x:1388,y:780,t:1527876802231};\\\", \\\"{x:1387,y:780,t:1527876802247};\\\", \\\"{x:1384,y:780,t:1527876802260};\\\", \\\"{x:1384,y:781,t:1527876802276};\\\", \\\"{x:1383,y:782,t:1527876802293};\\\", \\\"{x:1382,y:783,t:1527876802319};\\\", \\\"{x:1379,y:784,t:1527876802334};\\\", \\\"{x:1377,y:785,t:1527876802342};\\\", \\\"{x:1374,y:786,t:1527876802367};\\\", \\\"{x:1373,y:787,t:1527876802376};\\\", \\\"{x:1371,y:788,t:1527876802393};\\\", \\\"{x:1367,y:789,t:1527876802409};\\\", \\\"{x:1365,y:792,t:1527876802426};\\\", \\\"{x:1361,y:793,t:1527876802443};\\\", \\\"{x:1355,y:798,t:1527876802460};\\\", \\\"{x:1349,y:802,t:1527876802476};\\\", \\\"{x:1343,y:806,t:1527876802493};\\\", \\\"{x:1343,y:807,t:1527876802533};\\\", \\\"{x:1343,y:808,t:1527876802542};\\\", \\\"{x:1340,y:813,t:1527876802559};\\\", \\\"{x:1337,y:818,t:1527876802575};\\\", \\\"{x:1335,y:820,t:1527876802592};\\\", \\\"{x:1334,y:823,t:1527876802609};\\\", \\\"{x:1331,y:826,t:1527876802625};\\\", \\\"{x:1328,y:831,t:1527876802642};\\\", \\\"{x:1327,y:833,t:1527876802659};\\\", \\\"{x:1324,y:837,t:1527876802676};\\\", \\\"{x:1324,y:838,t:1527876802693};\\\", \\\"{x:1321,y:843,t:1527876802710};\\\", \\\"{x:1320,y:844,t:1527876802725};\\\", \\\"{x:1319,y:846,t:1527876802742};\\\", \\\"{x:1318,y:848,t:1527876802760};\\\", \\\"{x:1317,y:850,t:1527876802776};\\\", \\\"{x:1316,y:851,t:1527876802793};\\\", \\\"{x:1313,y:854,t:1527876802811};\\\", \\\"{x:1313,y:856,t:1527876802825};\\\", \\\"{x:1311,y:857,t:1527876802845};\\\", \\\"{x:1311,y:858,t:1527876802860};\\\", \\\"{x:1310,y:861,t:1527876802876};\\\", \\\"{x:1310,y:863,t:1527876802893};\\\", \\\"{x:1308,y:865,t:1527876802910};\\\", \\\"{x:1306,y:868,t:1527876802926};\\\", \\\"{x:1303,y:872,t:1527876802943};\\\", \\\"{x:1303,y:875,t:1527876802960};\\\", \\\"{x:1301,y:881,t:1527876802977};\\\", \\\"{x:1301,y:886,t:1527876802993};\\\", \\\"{x:1301,y:890,t:1527876803011};\\\", \\\"{x:1301,y:896,t:1527876803027};\\\", \\\"{x:1302,y:904,t:1527876803043};\\\", \\\"{x:1304,y:911,t:1527876803059};\\\", \\\"{x:1307,y:915,t:1527876803077};\\\", \\\"{x:1309,y:918,t:1527876803093};\\\", \\\"{x:1312,y:921,t:1527876803110};\\\", \\\"{x:1314,y:921,t:1527876803423};\\\", \\\"{x:1316,y:921,t:1527876803463};\\\", \\\"{x:1317,y:921,t:1527876803502};\\\", \\\"{x:1318,y:920,t:1527876803511};\\\", \\\"{x:1319,y:920,t:1527876803534};\\\", \\\"{x:1321,y:919,t:1527876803558};\\\", \\\"{x:1322,y:919,t:1527876803575};\\\", \\\"{x:1324,y:919,t:1527876803583};\\\", \\\"{x:1326,y:919,t:1527876803594};\\\", \\\"{x:1332,y:918,t:1527876803612};\\\", \\\"{x:1341,y:916,t:1527876803627};\\\", \\\"{x:1352,y:915,t:1527876803644};\\\", \\\"{x:1359,y:911,t:1527876803660};\\\", \\\"{x:1363,y:907,t:1527876803678};\\\", \\\"{x:1382,y:902,t:1527876803697};\\\", \\\"{x:1393,y:900,t:1527876803710};\\\", \\\"{x:1402,y:898,t:1527876803727};\\\", \\\"{x:1406,y:897,t:1527876803744};\\\", \\\"{x:1412,y:897,t:1527876803759};\\\", \\\"{x:1413,y:897,t:1527876803776};\\\", \\\"{x:1415,y:897,t:1527876803794};\\\", \\\"{x:1418,y:897,t:1527876803810};\\\", \\\"{x:1421,y:897,t:1527876803826};\\\", \\\"{x:1423,y:897,t:1527876803843};\\\", \\\"{x:1427,y:897,t:1527876803860};\\\", \\\"{x:1430,y:897,t:1527876803877};\\\", \\\"{x:1436,y:897,t:1527876803894};\\\", \\\"{x:1437,y:897,t:1527876803910};\\\", \\\"{x:1439,y:897,t:1527876803934};\\\", \\\"{x:1440,y:897,t:1527876803958};\\\", \\\"{x:1440,y:896,t:1527876803966};\\\", \\\"{x:1441,y:895,t:1527876803982};\\\", \\\"{x:1442,y:894,t:1527876803994};\\\", \\\"{x:1445,y:892,t:1527876804013};\\\", \\\"{x:1447,y:890,t:1527876804027};\\\", \\\"{x:1447,y:888,t:1527876804043};\\\", \\\"{x:1451,y:881,t:1527876804060};\\\", \\\"{x:1455,y:875,t:1527876804077};\\\", \\\"{x:1461,y:866,t:1527876804093};\\\", \\\"{x:1465,y:858,t:1527876804110};\\\", \\\"{x:1466,y:856,t:1527876804126};\\\", \\\"{x:1466,y:854,t:1527876804143};\\\", \\\"{x:1468,y:849,t:1527876804160};\\\", \\\"{x:1470,y:844,t:1527876804176};\\\", \\\"{x:1471,y:842,t:1527876804194};\\\", \\\"{x:1473,y:840,t:1527876804211};\\\", \\\"{x:1474,y:838,t:1527876804227};\\\", \\\"{x:1474,y:837,t:1527876804335};\\\", \\\"{x:1475,y:835,t:1527876804344};\\\", \\\"{x:1475,y:834,t:1527876804366};\\\", \\\"{x:1476,y:833,t:1527876804382};\\\", \\\"{x:1476,y:832,t:1527876804395};\\\", \\\"{x:1476,y:831,t:1527876804411};\\\", \\\"{x:1477,y:829,t:1527876804427};\\\", \\\"{x:1478,y:828,t:1527876804443};\\\", \\\"{x:1478,y:826,t:1527876804460};\\\", \\\"{x:1478,y:823,t:1527876827571};\\\", \\\"{x:1477,y:821,t:1527876827582};\\\", \\\"{x:1472,y:817,t:1527876827599};\\\", \\\"{x:1467,y:814,t:1527876827616};\\\", \\\"{x:1457,y:810,t:1527876827632};\\\", \\\"{x:1452,y:806,t:1527876827649};\\\", \\\"{x:1447,y:801,t:1527876827664};\\\", \\\"{x:1436,y:786,t:1527876827681};\\\", \\\"{x:1426,y:772,t:1527876827699};\\\", \\\"{x:1416,y:757,t:1527876827715};\\\", \\\"{x:1407,y:733,t:1527876827731};\\\", \\\"{x:1395,y:704,t:1527876827749};\\\", \\\"{x:1368,y:664,t:1527876827765};\\\", \\\"{x:1343,y:631,t:1527876827782};\\\", \\\"{x:1333,y:616,t:1527876827798};\\\", \\\"{x:1324,y:605,t:1527876827815};\\\", \\\"{x:1313,y:590,t:1527876827832};\\\", \\\"{x:1308,y:584,t:1527876827849};\\\", \\\"{x:1304,y:580,t:1527876827866};\\\", \\\"{x:1302,y:577,t:1527876827881};\\\", \\\"{x:1300,y:574,t:1527876827899};\\\", \\\"{x:1297,y:573,t:1527876827916};\\\", \\\"{x:1294,y:570,t:1527876827931};\\\", \\\"{x:1292,y:567,t:1527876827949};\\\", \\\"{x:1291,y:567,t:1527876827965};\\\", \\\"{x:1288,y:566,t:1527876827982};\\\", \\\"{x:1285,y:565,t:1527876827999};\\\", \\\"{x:1284,y:564,t:1527876828015};\\\", \\\"{x:1282,y:564,t:1527876828031};\\\", \\\"{x:1279,y:563,t:1527876828048};\\\", \\\"{x:1278,y:563,t:1527876828065};\\\", \\\"{x:1277,y:563,t:1527876828121};\\\", \\\"{x:1276,y:563,t:1527876828144};\\\", \\\"{x:1275,y:563,t:1527876828152};\\\", \\\"{x:1275,y:565,t:1527876834003};\\\", \\\"{x:1283,y:593,t:1527876834020};\\\", \\\"{x:1294,y:632,t:1527876834036};\\\", \\\"{x:1304,y:661,t:1527876834052};\\\", \\\"{x:1332,y:701,t:1527876834070};\\\", \\\"{x:1356,y:739,t:1527876834086};\\\", \\\"{x:1377,y:758,t:1527876834102};\\\", \\\"{x:1397,y:775,t:1527876834120};\\\", \\\"{x:1422,y:794,t:1527876834136};\\\", \\\"{x:1439,y:808,t:1527876834153};\\\", \\\"{x:1451,y:818,t:1527876834169};\\\", \\\"{x:1469,y:829,t:1527876834186};\\\", \\\"{x:1481,y:836,t:1527876834202};\\\", \\\"{x:1483,y:836,t:1527876834220};\\\", \\\"{x:1485,y:838,t:1527876834236};\\\", \\\"{x:1487,y:841,t:1527876834253};\\\", \\\"{x:1491,y:846,t:1527876834269};\\\", \\\"{x:1491,y:849,t:1527876834287};\\\", \\\"{x:1495,y:854,t:1527876834303};\\\", \\\"{x:1495,y:855,t:1527876834345};\\\", \\\"{x:1495,y:857,t:1527876834490};\\\", \\\"{x:1495,y:859,t:1527876834505};\\\", \\\"{x:1495,y:865,t:1527876834520};\\\", \\\"{x:1491,y:880,t:1527876834538};\\\", \\\"{x:1487,y:887,t:1527876834553};\\\", \\\"{x:1485,y:891,t:1527876834570};\\\", \\\"{x:1484,y:893,t:1527876834587};\\\", \\\"{x:1484,y:884,t:1527876834690};\\\", \\\"{x:1480,y:871,t:1527876834704};\\\", \\\"{x:1469,y:844,t:1527876834720};\\\", \\\"{x:1435,y:788,t:1527876834737};\\\", \\\"{x:1404,y:743,t:1527876834753};\\\", \\\"{x:1365,y:699,t:1527876834770};\\\", \\\"{x:1318,y:657,t:1527876834787};\\\", \\\"{x:1285,y:632,t:1527876834804};\\\", \\\"{x:1269,y:618,t:1527876834821};\\\", \\\"{x:1246,y:607,t:1527876834837};\\\", \\\"{x:1229,y:599,t:1527876834854};\\\", \\\"{x:1222,y:595,t:1527876834871};\\\", \\\"{x:1222,y:594,t:1527876834887};\\\", \\\"{x:1221,y:594,t:1527876834904};\\\", \\\"{x:1220,y:592,t:1527876834921};\\\", \\\"{x:1219,y:592,t:1527876834937};\\\", \\\"{x:1219,y:590,t:1527876834977};\\\", \\\"{x:1219,y:588,t:1527876834987};\\\", \\\"{x:1219,y:582,t:1527876835004};\\\", \\\"{x:1219,y:574,t:1527876835021};\\\", \\\"{x:1219,y:568,t:1527876835037};\\\", \\\"{x:1221,y:564,t:1527876835054};\\\", \\\"{x:1221,y:562,t:1527876835071};\\\", \\\"{x:1225,y:559,t:1527876835087};\\\", \\\"{x:1226,y:558,t:1527876835129};\\\", \\\"{x:1227,y:558,t:1527876835138};\\\", \\\"{x:1229,y:557,t:1527876835154};\\\", \\\"{x:1230,y:556,t:1527876835171};\\\", \\\"{x:1234,y:556,t:1527876835187};\\\", \\\"{x:1238,y:559,t:1527876835204};\\\", \\\"{x:1242,y:561,t:1527876835221};\\\", \\\"{x:1247,y:563,t:1527876835236};\\\", \\\"{x:1251,y:564,t:1527876835253};\\\", \\\"{x:1253,y:564,t:1527876835289};\\\", \\\"{x:1255,y:564,t:1527876835303};\\\", \\\"{x:1257,y:564,t:1527876835321};\\\", \\\"{x:1262,y:565,t:1527876835337};\\\", \\\"{x:1264,y:565,t:1527876835376};\\\", \\\"{x:1265,y:565,t:1527876835392};\\\", \\\"{x:1269,y:563,t:1527876835403};\\\", \\\"{x:1272,y:563,t:1527876835420};\\\", \\\"{x:1275,y:561,t:1527876835437};\\\", \\\"{x:1278,y:560,t:1527876835454};\\\", \\\"{x:1283,y:558,t:1527876835537};\\\", \\\"{x:1279,y:560,t:1527876848898};\\\", \\\"{x:1255,y:574,t:1527876848916};\\\", \\\"{x:1214,y:584,t:1527876848931};\\\", \\\"{x:1138,y:594,t:1527876848948};\\\", \\\"{x:1074,y:604,t:1527876848964};\\\", \\\"{x:1009,y:608,t:1527876848981};\\\", \\\"{x:876,y:610,t:1527876848999};\\\", \\\"{x:759,y:610,t:1527876849014};\\\", \\\"{x:662,y:609,t:1527876849030};\\\", \\\"{x:507,y:599,t:1527876849051};\\\", \\\"{x:422,y:590,t:1527876849068};\\\", \\\"{x:339,y:579,t:1527876849083};\\\", \\\"{x:282,y:567,t:1527876849101};\\\", \\\"{x:250,y:562,t:1527876849118};\\\", \\\"{x:231,y:559,t:1527876849135};\\\", \\\"{x:230,y:559,t:1527876849151};\\\", \\\"{x:230,y:558,t:1527876849209};\\\", \\\"{x:230,y:555,t:1527876849219};\\\", \\\"{x:234,y:547,t:1527876849234};\\\", \\\"{x:253,y:536,t:1527876849251};\\\", \\\"{x:268,y:527,t:1527876849268};\\\", \\\"{x:303,y:518,t:1527876849285};\\\", \\\"{x:327,y:510,t:1527876849301};\\\", \\\"{x:365,y:504,t:1527876849318};\\\", \\\"{x:398,y:502,t:1527876849336};\\\", \\\"{x:441,y:502,t:1527876849351};\\\", \\\"{x:466,y:502,t:1527876849367};\\\", \\\"{x:499,y:506,t:1527876849385};\\\", \\\"{x:506,y:507,t:1527876849401};\\\", \\\"{x:508,y:507,t:1527876849418};\\\", \\\"{x:509,y:508,t:1527876849435};\\\", \\\"{x:510,y:509,t:1527876849451};\\\", \\\"{x:511,y:511,t:1527876849468};\\\", \\\"{x:513,y:512,t:1527876849485};\\\", \\\"{x:517,y:514,t:1527876849502};\\\", \\\"{x:521,y:514,t:1527876849518};\\\", \\\"{x:523,y:514,t:1527876849535};\\\", \\\"{x:525,y:514,t:1527876849551};\\\", \\\"{x:541,y:514,t:1527876849568};\\\", \\\"{x:584,y:505,t:1527876849585};\\\", \\\"{x:603,y:503,t:1527876849603};\\\", \\\"{x:615,y:500,t:1527876849618};\\\", \\\"{x:616,y:500,t:1527876849635};\\\", \\\"{x:617,y:500,t:1527876849993};\\\", \\\"{x:617,y:507,t:1527876850002};\\\", \\\"{x:609,y:540,t:1527876850020};\\\", \\\"{x:597,y:577,t:1527876850036};\\\", \\\"{x:582,y:615,t:1527876850052};\\\", \\\"{x:576,y:641,t:1527876850069};\\\", \\\"{x:572,y:656,t:1527876850085};\\\", \\\"{x:571,y:665,t:1527876850102};\\\", \\\"{x:569,y:676,t:1527876850119};\\\", \\\"{x:565,y:685,t:1527876850135};\\\", \\\"{x:560,y:701,t:1527876850152};\\\", \\\"{x:558,y:706,t:1527876850168};\\\", \\\"{x:557,y:709,t:1527876850185};\\\", \\\"{x:556,y:710,t:1527876850202};\\\", \\\"{x:555,y:714,t:1527876850219};\\\", \\\"{x:553,y:718,t:1527876850235};\\\", \\\"{x:550,y:720,t:1527876850253};\\\", \\\"{x:550,y:721,t:1527876850268};\\\", \\\"{x:549,y:721,t:1527876850313};\\\", \\\"{x:545,y:724,t:1527876850361};\\\", \\\"{x:545,y:725,t:1527876850369};\\\", \\\"{x:539,y:728,t:1527876850386};\\\", \\\"{x:536,y:730,t:1527876850403};\\\", \\\"{x:535,y:731,t:1527876850419};\\\", \\\"{x:538,y:731,t:1527876850922};\\\", \\\"{x:540,y:731,t:1527876850936};\\\", \\\"{x:560,y:727,t:1527876850952};\\\", \\\"{x:575,y:726,t:1527876850969};\\\", \\\"{x:596,y:721,t:1527876850986};\\\", \\\"{x:605,y:719,t:1527876851003};\\\", \\\"{x:628,y:712,t:1527876851019};\\\", \\\"{x:647,y:706,t:1527876851036};\\\", \\\"{x:664,y:702,t:1527876851053};\\\", \\\"{x:675,y:697,t:1527876851069};\\\", \\\"{x:684,y:694,t:1527876851086};\\\", \\\"{x:696,y:689,t:1527876851102};\\\", \\\"{x:704,y:687,t:1527876851119};\\\", \\\"{x:711,y:684,t:1527876851136};\\\", \\\"{x:712,y:682,t:1527876851153};\\\", \\\"{x:714,y:681,t:1527876851192};\\\", \\\"{x:715,y:680,t:1527876851203};\\\", \\\"{x:717,y:679,t:1527876851219};\\\", \\\"{x:719,y:678,t:1527876851236};\\\", \\\"{x:723,y:676,t:1527876851253};\\\", \\\"{x:727,y:674,t:1527876851269};\\\", \\\"{x:729,y:672,t:1527876851286};\\\", \\\"{x:730,y:672,t:1527876851321};\\\", \\\"{x:731,y:671,t:1527876851409};\\\", \\\"{x:732,y:670,t:1527876851424};\\\", \\\"{x:732,y:669,t:1527876851436};\\\", \\\"{x:734,y:667,t:1527876851456};\\\", \\\"{x:734,y:666,t:1527876851505};\\\", \\\"{x:735,y:665,t:1527876851520};\\\" ] }, { \\\"rt\\\": 28756, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 486173, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:736,y:665,t:1527876853977};\\\", \\\"{x:738,y:666,t:1527876853988};\\\", \\\"{x:739,y:668,t:1527876854005};\\\", \\\"{x:742,y:671,t:1527876854022};\\\", \\\"{x:742,y:672,t:1527876854038};\\\", \\\"{x:744,y:674,t:1527876854056};\\\", \\\"{x:748,y:681,t:1527876854073};\\\", \\\"{x:754,y:685,t:1527876854088};\\\", \\\"{x:767,y:685,t:1527876854105};\\\", \\\"{x:790,y:691,t:1527876854123};\\\", \\\"{x:808,y:699,t:1527876854138};\\\", \\\"{x:827,y:704,t:1527876854155};\\\", \\\"{x:843,y:713,t:1527876854172};\\\", \\\"{x:859,y:718,t:1527876854188};\\\", \\\"{x:876,y:724,t:1527876854205};\\\", \\\"{x:883,y:725,t:1527876854222};\\\", \\\"{x:895,y:730,t:1527876854238};\\\", \\\"{x:915,y:739,t:1527876854255};\\\", \\\"{x:940,y:746,t:1527876854272};\\\", \\\"{x:962,y:756,t:1527876854288};\\\", \\\"{x:975,y:765,t:1527876854305};\\\", \\\"{x:990,y:772,t:1527876854322};\\\", \\\"{x:1005,y:779,t:1527876854339};\\\", \\\"{x:1021,y:789,t:1527876854355};\\\", \\\"{x:1035,y:798,t:1527876854372};\\\", \\\"{x:1047,y:806,t:1527876854389};\\\", \\\"{x:1053,y:812,t:1527876854405};\\\", \\\"{x:1057,y:814,t:1527876854422};\\\", \\\"{x:1063,y:819,t:1527876854439};\\\", \\\"{x:1069,y:823,t:1527876854455};\\\", \\\"{x:1077,y:829,t:1527876854472};\\\", \\\"{x:1082,y:833,t:1527876854489};\\\", \\\"{x:1085,y:835,t:1527876854506};\\\", \\\"{x:1089,y:836,t:1527876854523};\\\", \\\"{x:1096,y:837,t:1527876854539};\\\", \\\"{x:1104,y:837,t:1527876854556};\\\", \\\"{x:1115,y:841,t:1527876854573};\\\", \\\"{x:1126,y:844,t:1527876854590};\\\", \\\"{x:1140,y:850,t:1527876854605};\\\", \\\"{x:1152,y:855,t:1527876854622};\\\", \\\"{x:1157,y:856,t:1527876854639};\\\", \\\"{x:1159,y:857,t:1527876854655};\\\", \\\"{x:1163,y:861,t:1527876854672};\\\", \\\"{x:1168,y:864,t:1527876854690};\\\", \\\"{x:1172,y:869,t:1527876854705};\\\", \\\"{x:1177,y:872,t:1527876854722};\\\", \\\"{x:1180,y:875,t:1527876854739};\\\", \\\"{x:1182,y:878,t:1527876854755};\\\", \\\"{x:1184,y:881,t:1527876854772};\\\", \\\"{x:1185,y:882,t:1527876854789};\\\", \\\"{x:1188,y:883,t:1527876854807};\\\", \\\"{x:1193,y:886,t:1527876854823};\\\", \\\"{x:1202,y:891,t:1527876854840};\\\", \\\"{x:1207,y:894,t:1527876854856};\\\", \\\"{x:1208,y:894,t:1527876855290};\\\", \\\"{x:1207,y:893,t:1527876855307};\\\", \\\"{x:1205,y:890,t:1527876855324};\\\", \\\"{x:1200,y:889,t:1527876855340};\\\", \\\"{x:1198,y:888,t:1527876855357};\\\", \\\"{x:1196,y:887,t:1527876855373};\\\", \\\"{x:1194,y:885,t:1527876855389};\\\", \\\"{x:1189,y:884,t:1527876855406};\\\", \\\"{x:1187,y:883,t:1527876855423};\\\", \\\"{x:1185,y:882,t:1527876855448};\\\", \\\"{x:1183,y:882,t:1527876855471};\\\", \\\"{x:1182,y:882,t:1527876855496};\\\", \\\"{x:1180,y:882,t:1527876855519};\\\", \\\"{x:1178,y:882,t:1527876855527};\\\", \\\"{x:1178,y:881,t:1527876855841};\\\", \\\"{x:1178,y:880,t:1527876855857};\\\", \\\"{x:1178,y:877,t:1527876855873};\\\", \\\"{x:1178,y:876,t:1527876855890};\\\", \\\"{x:1177,y:874,t:1527876855906};\\\", \\\"{x:1177,y:872,t:1527876855923};\\\", \\\"{x:1177,y:870,t:1527876855940};\\\", \\\"{x:1177,y:869,t:1527876855961};\\\", \\\"{x:1177,y:867,t:1527876855977};\\\", \\\"{x:1177,y:866,t:1527876855991};\\\", \\\"{x:1177,y:863,t:1527876856007};\\\", \\\"{x:1177,y:861,t:1527876856024};\\\", \\\"{x:1177,y:860,t:1527876856041};\\\", \\\"{x:1177,y:859,t:1527876856112};\\\", \\\"{x:1177,y:858,t:1527876856144};\\\", \\\"{x:1177,y:857,t:1527876856176};\\\", \\\"{x:1178,y:856,t:1527876856289};\\\", \\\"{x:1179,y:856,t:1527876856361};\\\", \\\"{x:1180,y:855,t:1527876856522};\\\", \\\"{x:1180,y:853,t:1527876856545};\\\", \\\"{x:1180,y:851,t:1527876857001};\\\", \\\"{x:1180,y:850,t:1527876857017};\\\", \\\"{x:1181,y:849,t:1527876857025};\\\", \\\"{x:1182,y:848,t:1527876857041};\\\", \\\"{x:1183,y:848,t:1527876857057};\\\", \\\"{x:1183,y:846,t:1527876857137};\\\", \\\"{x:1183,y:845,t:1527876857145};\\\", \\\"{x:1183,y:844,t:1527876857177};\\\", \\\"{x:1184,y:843,t:1527876857209};\\\", \\\"{x:1185,y:843,t:1527876857225};\\\", \\\"{x:1185,y:842,t:1527876857242};\\\", \\\"{x:1185,y:841,t:1527876857289};\\\", \\\"{x:1186,y:841,t:1527876857385};\\\", \\\"{x:1187,y:841,t:1527876858209};\\\", \\\"{x:1188,y:842,t:1527876860497};\\\", \\\"{x:1189,y:842,t:1527876860511};\\\", \\\"{x:1188,y:842,t:1527876865689};\\\", \\\"{x:1188,y:841,t:1527876865698};\\\", \\\"{x:1187,y:837,t:1527876865715};\\\", \\\"{x:1186,y:835,t:1527876865732};\\\", \\\"{x:1185,y:832,t:1527876865748};\\\", \\\"{x:1184,y:829,t:1527876865765};\\\", \\\"{x:1184,y:827,t:1527876865781};\\\", \\\"{x:1183,y:823,t:1527876865798};\\\", \\\"{x:1183,y:821,t:1527876865816};\\\", \\\"{x:1183,y:818,t:1527876865832};\\\", \\\"{x:1183,y:817,t:1527876865848};\\\", \\\"{x:1181,y:814,t:1527876865865};\\\", \\\"{x:1181,y:812,t:1527876865882};\\\", \\\"{x:1181,y:810,t:1527876865898};\\\", \\\"{x:1181,y:809,t:1527876865916};\\\", \\\"{x:1180,y:807,t:1527876865932};\\\", \\\"{x:1179,y:804,t:1527876865949};\\\", \\\"{x:1179,y:802,t:1527876865977};\\\", \\\"{x:1179,y:801,t:1527876866001};\\\", \\\"{x:1179,y:799,t:1527876866017};\\\", \\\"{x:1179,y:798,t:1527876866033};\\\", \\\"{x:1179,y:796,t:1527876866049};\\\", \\\"{x:1179,y:790,t:1527876866065};\\\", \\\"{x:1179,y:785,t:1527876866083};\\\", \\\"{x:1179,y:781,t:1527876866098};\\\", \\\"{x:1179,y:778,t:1527876866115};\\\", \\\"{x:1179,y:774,t:1527876866131};\\\", \\\"{x:1179,y:770,t:1527876866149};\\\", \\\"{x:1179,y:766,t:1527876866165};\\\", \\\"{x:1179,y:761,t:1527876866181};\\\", \\\"{x:1180,y:758,t:1527876866199};\\\", \\\"{x:1181,y:756,t:1527876866233};\\\", \\\"{x:1182,y:755,t:1527876866248};\\\", \\\"{x:1182,y:756,t:1527876868321};\\\", \\\"{x:1182,y:758,t:1527876868334};\\\", \\\"{x:1182,y:761,t:1527876868350};\\\", \\\"{x:1182,y:764,t:1527876868367};\\\", \\\"{x:1186,y:770,t:1527876868384};\\\", \\\"{x:1186,y:773,t:1527876868400};\\\", \\\"{x:1190,y:780,t:1527876868417};\\\", \\\"{x:1192,y:782,t:1527876868435};\\\", \\\"{x:1192,y:783,t:1527876868490};\\\", \\\"{x:1192,y:784,t:1527876868505};\\\", \\\"{x:1193,y:785,t:1527876868529};\\\", \\\"{x:1194,y:786,t:1527876868553};\\\", \\\"{x:1194,y:787,t:1527876868569};\\\", \\\"{x:1194,y:788,t:1527876868584};\\\", \\\"{x:1195,y:788,t:1527876868826};\\\", \\\"{x:1195,y:787,t:1527876868834};\\\", \\\"{x:1195,y:785,t:1527876868851};\\\", \\\"{x:1195,y:784,t:1527876868867};\\\", \\\"{x:1195,y:782,t:1527876868884};\\\", \\\"{x:1195,y:781,t:1527876868901};\\\", \\\"{x:1194,y:778,t:1527876868917};\\\", \\\"{x:1194,y:777,t:1527876868934};\\\", \\\"{x:1193,y:776,t:1527876868951};\\\", \\\"{x:1191,y:776,t:1527876868969};\\\", \\\"{x:1191,y:775,t:1527876868984};\\\", \\\"{x:1190,y:775,t:1527876869001};\\\", \\\"{x:1189,y:775,t:1527876869016};\\\", \\\"{x:1188,y:774,t:1527876869056};\\\", \\\"{x:1186,y:773,t:1527876869080};\\\", \\\"{x:1185,y:772,t:1527876869096};\\\", \\\"{x:1184,y:772,t:1527876869112};\\\", \\\"{x:1183,y:772,t:1527876869120};\\\", \\\"{x:1182,y:771,t:1527876869136};\\\", \\\"{x:1180,y:771,t:1527876869160};\\\", \\\"{x:1179,y:770,t:1527876869169};\\\", \\\"{x:1176,y:769,t:1527876869193};\\\", \\\"{x:1174,y:769,t:1527876869209};\\\", \\\"{x:1173,y:769,t:1527876869425};\\\", \\\"{x:1173,y:770,t:1527876869434};\\\", \\\"{x:1174,y:775,t:1527876869452};\\\", \\\"{x:1174,y:777,t:1527876869468};\\\", \\\"{x:1174,y:779,t:1527876869483};\\\", \\\"{x:1174,y:785,t:1527876869501};\\\", \\\"{x:1174,y:787,t:1527876869517};\\\", \\\"{x:1174,y:789,t:1527876869533};\\\", \\\"{x:1174,y:792,t:1527876869551};\\\", \\\"{x:1178,y:798,t:1527876869568};\\\", \\\"{x:1178,y:801,t:1527876869584};\\\", \\\"{x:1180,y:805,t:1527876869600};\\\", \\\"{x:1180,y:806,t:1527876869617};\\\", \\\"{x:1181,y:808,t:1527876869634};\\\", \\\"{x:1182,y:810,t:1527876869650};\\\", \\\"{x:1183,y:812,t:1527876869668};\\\", \\\"{x:1185,y:814,t:1527876869684};\\\", \\\"{x:1186,y:816,t:1527876869703};\\\", \\\"{x:1186,y:817,t:1527876869720};\\\", \\\"{x:1187,y:819,t:1527876869736};\\\", \\\"{x:1187,y:820,t:1527876869760};\\\", \\\"{x:1188,y:821,t:1527876869767};\\\", \\\"{x:1188,y:822,t:1527876869784};\\\", \\\"{x:1189,y:824,t:1527876869800};\\\", \\\"{x:1189,y:825,t:1527876869818};\\\", \\\"{x:1190,y:826,t:1527876869834};\\\", \\\"{x:1190,y:827,t:1527876869895};\\\", \\\"{x:1190,y:828,t:1527876869912};\\\", \\\"{x:1190,y:829,t:1527876869927};\\\", \\\"{x:1190,y:830,t:1527876869936};\\\", \\\"{x:1190,y:831,t:1527876869951};\\\", \\\"{x:1190,y:832,t:1527876869984};\\\", \\\"{x:1190,y:833,t:1527876870000};\\\", \\\"{x:1190,y:835,t:1527876870018};\\\", \\\"{x:1190,y:837,t:1527876870034};\\\", \\\"{x:1190,y:840,t:1527876870051};\\\", \\\"{x:1190,y:842,t:1527876870068};\\\", \\\"{x:1190,y:845,t:1527876870085};\\\", \\\"{x:1191,y:848,t:1527876870101};\\\", \\\"{x:1191,y:854,t:1527876870118};\\\", \\\"{x:1191,y:859,t:1527876870135};\\\", \\\"{x:1191,y:867,t:1527876870153};\\\", \\\"{x:1191,y:872,t:1527876870168};\\\", \\\"{x:1191,y:876,t:1527876870185};\\\", \\\"{x:1191,y:879,t:1527876870203};\\\", \\\"{x:1191,y:885,t:1527876870218};\\\", \\\"{x:1191,y:889,t:1527876870235};\\\", \\\"{x:1191,y:893,t:1527876870252};\\\", \\\"{x:1190,y:895,t:1527876870268};\\\", \\\"{x:1190,y:899,t:1527876870285};\\\", \\\"{x:1190,y:903,t:1527876870302};\\\", \\\"{x:1190,y:906,t:1527876870318};\\\", \\\"{x:1192,y:910,t:1527876870335};\\\", \\\"{x:1192,y:911,t:1527876870361};\\\", \\\"{x:1192,y:912,t:1527876870368};\\\", \\\"{x:1192,y:917,t:1527876870385};\\\", \\\"{x:1192,y:919,t:1527876870403};\\\", \\\"{x:1192,y:922,t:1527876870419};\\\", \\\"{x:1192,y:924,t:1527876870435};\\\", \\\"{x:1192,y:928,t:1527876870451};\\\", \\\"{x:1190,y:931,t:1527876870467};\\\", \\\"{x:1190,y:932,t:1527876870484};\\\", \\\"{x:1190,y:935,t:1527876870502};\\\", \\\"{x:1190,y:937,t:1527876870518};\\\", \\\"{x:1190,y:939,t:1527876870534};\\\", \\\"{x:1190,y:943,t:1527876870552};\\\", \\\"{x:1190,y:945,t:1527876870568};\\\", \\\"{x:1190,y:947,t:1527876870584};\\\", \\\"{x:1190,y:949,t:1527876870601};\\\", \\\"{x:1190,y:950,t:1527876870619};\\\", \\\"{x:1190,y:951,t:1527876870635};\\\", \\\"{x:1190,y:953,t:1527876870652};\\\", \\\"{x:1190,y:954,t:1527876870669};\\\", \\\"{x:1190,y:955,t:1527876870722};\\\", \\\"{x:1190,y:956,t:1527876870825};\\\", \\\"{x:1190,y:957,t:1527876870873};\\\", \\\"{x:1190,y:955,t:1527876871273};\\\", \\\"{x:1190,y:953,t:1527876871286};\\\", \\\"{x:1190,y:946,t:1527876871302};\\\", \\\"{x:1191,y:937,t:1527876871319};\\\", \\\"{x:1194,y:920,t:1527876871336};\\\", \\\"{x:1199,y:912,t:1527876871352};\\\", \\\"{x:1199,y:898,t:1527876871369};\\\", \\\"{x:1201,y:888,t:1527876871386};\\\", \\\"{x:1201,y:880,t:1527876871403};\\\", \\\"{x:1201,y:876,t:1527876871420};\\\", \\\"{x:1201,y:869,t:1527876871436};\\\", \\\"{x:1200,y:866,t:1527876871454};\\\", \\\"{x:1200,y:865,t:1527876871469};\\\", \\\"{x:1199,y:861,t:1527876871487};\\\", \\\"{x:1199,y:858,t:1527876871503};\\\", \\\"{x:1199,y:855,t:1527876871519};\\\", \\\"{x:1199,y:847,t:1527876871536};\\\", \\\"{x:1200,y:838,t:1527876871552};\\\", \\\"{x:1200,y:832,t:1527876871569};\\\", \\\"{x:1203,y:829,t:1527876871586};\\\", \\\"{x:1203,y:823,t:1527876871603};\\\", \\\"{x:1203,y:816,t:1527876871620};\\\", \\\"{x:1203,y:808,t:1527876871636};\\\", \\\"{x:1203,y:803,t:1527876871653};\\\", \\\"{x:1203,y:800,t:1527876871669};\\\", \\\"{x:1203,y:799,t:1527876871688};\\\", \\\"{x:1203,y:798,t:1527876871704};\\\", \\\"{x:1203,y:797,t:1527876871718};\\\", \\\"{x:1204,y:795,t:1527876871800};\\\", \\\"{x:1204,y:794,t:1527876871808};\\\", \\\"{x:1204,y:793,t:1527876871824};\\\", \\\"{x:1204,y:792,t:1527876871840};\\\", \\\"{x:1204,y:791,t:1527876871853};\\\", \\\"{x:1204,y:789,t:1527876871870};\\\", \\\"{x:1204,y:785,t:1527876871886};\\\", \\\"{x:1203,y:779,t:1527876871903};\\\", \\\"{x:1199,y:771,t:1527876871920};\\\", \\\"{x:1197,y:763,t:1527876871936};\\\", \\\"{x:1195,y:760,t:1527876871952};\\\", \\\"{x:1192,y:757,t:1527876871969};\\\", \\\"{x:1192,y:755,t:1527876871986};\\\", \\\"{x:1190,y:752,t:1527876872003};\\\", \\\"{x:1188,y:750,t:1527876872020};\\\", \\\"{x:1188,y:749,t:1527876872035};\\\", \\\"{x:1187,y:748,t:1527876872053};\\\", \\\"{x:1187,y:747,t:1527876872080};\\\", \\\"{x:1186,y:746,t:1527876872104};\\\", \\\"{x:1185,y:746,t:1527876873257};\\\", \\\"{x:1184,y:746,t:1527876873329};\\\", \\\"{x:1183,y:746,t:1527876873353};\\\", \\\"{x:1182,y:746,t:1527876873369};\\\", \\\"{x:1181,y:746,t:1527876873761};\\\", \\\"{x:1180,y:747,t:1527876873793};\\\", \\\"{x:1179,y:747,t:1527876873805};\\\", \\\"{x:1179,y:749,t:1527876873825};\\\", \\\"{x:1179,y:750,t:1527876873842};\\\", \\\"{x:1179,y:751,t:1527876873858};\\\", \\\"{x:1178,y:753,t:1527876873875};\\\", \\\"{x:1177,y:758,t:1527876873893};\\\", \\\"{x:1177,y:759,t:1527876873908};\\\", \\\"{x:1177,y:761,t:1527876873925};\\\", \\\"{x:1177,y:763,t:1527876873942};\\\", \\\"{x:1176,y:765,t:1527876873958};\\\", \\\"{x:1176,y:766,t:1527876873975};\\\", \\\"{x:1176,y:768,t:1527876873993};\\\", \\\"{x:1176,y:769,t:1527876874012};\\\", \\\"{x:1176,y:770,t:1527876874025};\\\", \\\"{x:1176,y:771,t:1527876874041};\\\", \\\"{x:1176,y:772,t:1527876874059};\\\", \\\"{x:1176,y:773,t:1527876874076};\\\", \\\"{x:1176,y:774,t:1527876874091};\\\", \\\"{x:1176,y:775,t:1527876874163};\\\", \\\"{x:1173,y:775,t:1527876878108};\\\", \\\"{x:1169,y:777,t:1527876878116};\\\", \\\"{x:1162,y:777,t:1527876878128};\\\", \\\"{x:1158,y:779,t:1527876878144};\\\", \\\"{x:1147,y:780,t:1527876878162};\\\", \\\"{x:1134,y:782,t:1527876878177};\\\", \\\"{x:1122,y:782,t:1527876878194};\\\", \\\"{x:1087,y:782,t:1527876878211};\\\", \\\"{x:1048,y:779,t:1527876878227};\\\", \\\"{x:966,y:764,t:1527876878245};\\\", \\\"{x:896,y:754,t:1527876878262};\\\", \\\"{x:822,y:735,t:1527876878277};\\\", \\\"{x:772,y:725,t:1527876878294};\\\", \\\"{x:722,y:713,t:1527876878311};\\\", \\\"{x:681,y:701,t:1527876878328};\\\", \\\"{x:628,y:685,t:1527876878344};\\\", \\\"{x:605,y:677,t:1527876878362};\\\", \\\"{x:578,y:668,t:1527876878377};\\\", \\\"{x:564,y:664,t:1527876878394};\\\", \\\"{x:555,y:655,t:1527876878411};\\\", \\\"{x:552,y:651,t:1527876878429};\\\", \\\"{x:552,y:647,t:1527876878445};\\\", \\\"{x:549,y:641,t:1527876878462};\\\", \\\"{x:548,y:638,t:1527876878478};\\\", \\\"{x:548,y:635,t:1527876878500};\\\", \\\"{x:554,y:630,t:1527876878514};\\\", \\\"{x:567,y:622,t:1527876878529};\\\", \\\"{x:588,y:616,t:1527876878544};\\\", \\\"{x:611,y:608,t:1527876878562};\\\", \\\"{x:637,y:602,t:1527876878579};\\\", \\\"{x:669,y:596,t:1527876878595};\\\", \\\"{x:686,y:594,t:1527876878611};\\\", \\\"{x:709,y:590,t:1527876878628};\\\", \\\"{x:734,y:586,t:1527876878646};\\\", \\\"{x:746,y:583,t:1527876878661};\\\", \\\"{x:750,y:579,t:1527876878679};\\\", \\\"{x:758,y:577,t:1527876878695};\\\", \\\"{x:768,y:573,t:1527876878712};\\\", \\\"{x:773,y:570,t:1527876878729};\\\", \\\"{x:776,y:568,t:1527876878746};\\\", \\\"{x:777,y:568,t:1527876878763};\\\", \\\"{x:775,y:568,t:1527876878884};\\\", \\\"{x:774,y:568,t:1527876878896};\\\", \\\"{x:771,y:569,t:1527876878913};\\\", \\\"{x:768,y:570,t:1527876878929};\\\", \\\"{x:762,y:573,t:1527876878946};\\\", \\\"{x:751,y:578,t:1527876878963};\\\", \\\"{x:721,y:595,t:1527876878980};\\\", \\\"{x:698,y:603,t:1527876878997};\\\", \\\"{x:688,y:606,t:1527876879012};\\\", \\\"{x:650,y:610,t:1527876879029};\\\", \\\"{x:610,y:613,t:1527876879046};\\\", \\\"{x:557,y:613,t:1527876879063};\\\", \\\"{x:506,y:613,t:1527876879079};\\\", \\\"{x:472,y:613,t:1527876879096};\\\", \\\"{x:447,y:610,t:1527876879113};\\\", \\\"{x:424,y:611,t:1527876879129};\\\", \\\"{x:405,y:610,t:1527876879146};\\\", \\\"{x:389,y:611,t:1527876879163};\\\", \\\"{x:386,y:611,t:1527876879179};\\\", \\\"{x:373,y:611,t:1527876879196};\\\", \\\"{x:368,y:611,t:1527876879212};\\\", \\\"{x:366,y:612,t:1527876879228};\\\", \\\"{x:365,y:612,t:1527876879246};\\\", \\\"{x:363,y:612,t:1527876879262};\\\", \\\"{x:361,y:612,t:1527876879279};\\\", \\\"{x:357,y:607,t:1527876879295};\\\", \\\"{x:353,y:598,t:1527876879313};\\\", \\\"{x:343,y:579,t:1527876879330};\\\", \\\"{x:324,y:559,t:1527876879346};\\\", \\\"{x:306,y:536,t:1527876879363};\\\", \\\"{x:275,y:503,t:1527876879380};\\\", \\\"{x:250,y:486,t:1527876879396};\\\", \\\"{x:231,y:475,t:1527876879412};\\\", \\\"{x:225,y:473,t:1527876879428};\\\", \\\"{x:218,y:470,t:1527876879445};\\\", \\\"{x:216,y:470,t:1527876879462};\\\", \\\"{x:216,y:469,t:1527876879479};\\\", \\\"{x:215,y:469,t:1527876879532};\\\", \\\"{x:212,y:469,t:1527876879546};\\\", \\\"{x:208,y:472,t:1527876879564};\\\", \\\"{x:198,y:478,t:1527876879580};\\\", \\\"{x:193,y:483,t:1527876879596};\\\", \\\"{x:189,y:487,t:1527876879615};\\\", \\\"{x:186,y:489,t:1527876879629};\\\", \\\"{x:182,y:492,t:1527876879646};\\\", \\\"{x:179,y:495,t:1527876879662};\\\", \\\"{x:177,y:497,t:1527876879680};\\\", \\\"{x:176,y:498,t:1527876879697};\\\", \\\"{x:176,y:500,t:1527876879940};\\\", \\\"{x:176,y:502,t:1527876879947};\\\", \\\"{x:178,y:505,t:1527876879963};\\\", \\\"{x:195,y:520,t:1527876879979};\\\", \\\"{x:215,y:537,t:1527876879998};\\\", \\\"{x:232,y:551,t:1527876880012};\\\", \\\"{x:256,y:571,t:1527876880031};\\\", \\\"{x:295,y:605,t:1527876880047};\\\", \\\"{x:329,y:637,t:1527876880063};\\\", \\\"{x:373,y:679,t:1527876880079};\\\", \\\"{x:407,y:704,t:1527876880096};\\\", \\\"{x:432,y:725,t:1527876880114};\\\", \\\"{x:455,y:742,t:1527876880130};\\\", \\\"{x:477,y:755,t:1527876880148};\\\", \\\"{x:494,y:766,t:1527876880163};\\\", \\\"{x:504,y:771,t:1527876880179};\\\", \\\"{x:511,y:774,t:1527876880197};\\\", \\\"{x:517,y:776,t:1527876880214};\\\", \\\"{x:521,y:775,t:1527876880229};\\\", \\\"{x:523,y:775,t:1527876880247};\\\", \\\"{x:524,y:775,t:1527876880264};\\\", \\\"{x:525,y:774,t:1527876880280};\\\", \\\"{x:525,y:773,t:1527876880299};\\\", \\\"{x:526,y:773,t:1527876880314};\\\", \\\"{x:528,y:769,t:1527876880329};\\\", \\\"{x:531,y:760,t:1527876880347};\\\", \\\"{x:535,y:740,t:1527876880364};\\\", \\\"{x:538,y:731,t:1527876880379};\\\", \\\"{x:538,y:728,t:1527876880397};\\\", \\\"{x:538,y:727,t:1527876880420};\\\", \\\"{x:538,y:725,t:1527876880430};\\\", \\\"{x:537,y:725,t:1527876880447};\\\" ] }, { \\\"rt\\\": 83477, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 570888, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -04 PM-04 PM-B -B -B -F -B -B -B -B -F -F -X -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:724,t:1527876886276};\\\", \\\"{x:537,y:723,t:1527876886300};\\\", \\\"{x:537,y:721,t:1527876886315};\\\", \\\"{x:537,y:720,t:1527876886380};\\\", \\\"{x:538,y:719,t:1527876886517};\\\", \\\"{x:541,y:719,t:1527876886533};\\\", \\\"{x:547,y:716,t:1527876886551};\\\", \\\"{x:554,y:712,t:1527876886564};\\\", \\\"{x:560,y:708,t:1527876886580};\\\", \\\"{x:575,y:704,t:1527876886597};\\\", \\\"{x:602,y:694,t:1527876886614};\\\", \\\"{x:645,y:685,t:1527876886631};\\\", \\\"{x:702,y:676,t:1527876886647};\\\", \\\"{x:765,y:673,t:1527876886664};\\\", \\\"{x:860,y:676,t:1527876886681};\\\", \\\"{x:961,y:682,t:1527876886697};\\\", \\\"{x:1053,y:695,t:1527876886715};\\\", \\\"{x:1179,y:725,t:1527876886731};\\\", \\\"{x:1242,y:750,t:1527876886747};\\\", \\\"{x:1285,y:764,t:1527876886764};\\\", \\\"{x:1314,y:776,t:1527876886781};\\\", \\\"{x:1336,y:786,t:1527876886797};\\\", \\\"{x:1349,y:792,t:1527876886814};\\\", \\\"{x:1357,y:797,t:1527876886831};\\\", \\\"{x:1365,y:801,t:1527876886847};\\\", \\\"{x:1369,y:803,t:1527876886864};\\\", \\\"{x:1370,y:804,t:1527876886882};\\\", \\\"{x:1372,y:795,t:1527876887053};\\\", \\\"{x:1372,y:783,t:1527876887065};\\\", \\\"{x:1372,y:765,t:1527876887082};\\\", \\\"{x:1365,y:750,t:1527876887098};\\\", \\\"{x:1364,y:748,t:1527876887115};\\\", \\\"{x:1364,y:745,t:1527876887131};\\\", \\\"{x:1364,y:742,t:1527876887147};\\\", \\\"{x:1364,y:739,t:1527876887165};\\\", \\\"{x:1364,y:734,t:1527876887182};\\\", \\\"{x:1364,y:732,t:1527876887198};\\\", \\\"{x:1364,y:731,t:1527876887215};\\\", \\\"{x:1364,y:730,t:1527876887275};\\\", \\\"{x:1363,y:728,t:1527876887283};\\\", \\\"{x:1361,y:723,t:1527876887297};\\\", \\\"{x:1359,y:714,t:1527876887314};\\\", \\\"{x:1353,y:695,t:1527876887332};\\\", \\\"{x:1351,y:689,t:1527876887347};\\\", \\\"{x:1351,y:688,t:1527876887372};\\\", \\\"{x:1350,y:690,t:1527876887796};\\\", \\\"{x:1349,y:690,t:1527876887804};\\\", \\\"{x:1348,y:691,t:1527876887814};\\\", \\\"{x:1347,y:691,t:1527876887832};\\\", \\\"{x:1346,y:691,t:1527876887885};\\\", \\\"{x:1345,y:691,t:1527876887923};\\\", \\\"{x:1344,y:692,t:1527876887998};\\\", \\\"{x:1343,y:695,t:1527876888032};\\\", \\\"{x:1340,y:698,t:1527876888048};\\\", \\\"{x:1340,y:699,t:1527876888064};\\\", \\\"{x:1340,y:700,t:1527876888108};\\\", \\\"{x:1339,y:700,t:1527876888117};\\\", \\\"{x:1338,y:700,t:1527876889821};\\\", \\\"{x:1338,y:699,t:1527876890164};\\\", \\\"{x:1339,y:697,t:1527876890180};\\\", \\\"{x:1340,y:698,t:1527876893435};\\\", \\\"{x:1341,y:698,t:1527876893451};\\\", \\\"{x:1342,y:697,t:1527876893475};\\\", \\\"{x:1343,y:697,t:1527876893499};\\\", \\\"{x:1344,y:697,t:1527876893685};\\\", \\\"{x:1346,y:697,t:1527876893700};\\\", \\\"{x:1347,y:697,t:1527876893714};\\\", \\\"{x:1348,y:698,t:1527876893730};\\\", \\\"{x:1349,y:698,t:1527876893747};\\\", \\\"{x:1351,y:698,t:1527876894108};\\\", \\\"{x:1354,y:697,t:1527876894125};\\\", \\\"{x:1356,y:696,t:1527876894989};\\\", \\\"{x:1357,y:695,t:1527876895005};\\\", \\\"{x:1359,y:694,t:1527876895093};\\\", \\\"{x:1360,y:693,t:1527876895116};\\\", \\\"{x:1361,y:691,t:1527876895139};\\\", \\\"{x:1363,y:691,t:1527876895164};\\\", \\\"{x:1365,y:690,t:1527876895180};\\\", \\\"{x:1370,y:688,t:1527876895196};\\\", \\\"{x:1373,y:688,t:1527876895213};\\\", \\\"{x:1376,y:685,t:1527876895229};\\\", \\\"{x:1382,y:684,t:1527876895246};\\\", \\\"{x:1386,y:682,t:1527876895263};\\\", \\\"{x:1392,y:681,t:1527876895280};\\\", \\\"{x:1402,y:680,t:1527876895297};\\\", \\\"{x:1408,y:680,t:1527876895312};\\\", \\\"{x:1417,y:678,t:1527876895330};\\\", \\\"{x:1421,y:678,t:1527876895347};\\\", \\\"{x:1428,y:678,t:1527876895362};\\\", \\\"{x:1437,y:678,t:1527876895380};\\\", \\\"{x:1446,y:679,t:1527876895397};\\\", \\\"{x:1453,y:679,t:1527876895413};\\\", \\\"{x:1463,y:682,t:1527876895429};\\\", \\\"{x:1472,y:683,t:1527876895447};\\\", \\\"{x:1483,y:686,t:1527876895462};\\\", \\\"{x:1492,y:687,t:1527876895480};\\\", \\\"{x:1498,y:688,t:1527876895497};\\\", \\\"{x:1502,y:688,t:1527876895513};\\\", \\\"{x:1511,y:690,t:1527876895529};\\\", \\\"{x:1517,y:690,t:1527876895547};\\\", \\\"{x:1520,y:691,t:1527876895563};\\\", \\\"{x:1525,y:691,t:1527876895579};\\\", \\\"{x:1529,y:692,t:1527876895597};\\\", \\\"{x:1531,y:692,t:1527876895613};\\\", \\\"{x:1533,y:694,t:1527876895630};\\\", \\\"{x:1534,y:695,t:1527876895647};\\\", \\\"{x:1536,y:696,t:1527876895932};\\\", \\\"{x:1539,y:696,t:1527876895946};\\\", \\\"{x:1543,y:703,t:1527876895963};\\\", \\\"{x:1556,y:713,t:1527876895980};\\\", \\\"{x:1566,y:719,t:1527876895997};\\\", \\\"{x:1577,y:726,t:1527876896013};\\\", \\\"{x:1593,y:740,t:1527876896030};\\\", \\\"{x:1608,y:753,t:1527876896047};\\\", \\\"{x:1623,y:772,t:1527876896062};\\\", \\\"{x:1638,y:790,t:1527876896079};\\\", \\\"{x:1651,y:809,t:1527876896097};\\\", \\\"{x:1664,y:825,t:1527876896113};\\\", \\\"{x:1672,y:844,t:1527876896130};\\\", \\\"{x:1678,y:856,t:1527876896146};\\\", \\\"{x:1681,y:865,t:1527876896162};\\\", \\\"{x:1682,y:878,t:1527876896178};\\\", \\\"{x:1682,y:887,t:1527876896196};\\\", \\\"{x:1679,y:897,t:1527876896212};\\\", \\\"{x:1674,y:902,t:1527876896229};\\\", \\\"{x:1671,y:907,t:1527876896246};\\\", \\\"{x:1671,y:911,t:1527876896262};\\\", \\\"{x:1671,y:913,t:1527876896279};\\\", \\\"{x:1671,y:915,t:1527876896297};\\\", \\\"{x:1671,y:916,t:1527876896312};\\\", \\\"{x:1669,y:919,t:1527876896329};\\\", \\\"{x:1663,y:922,t:1527876896347};\\\", \\\"{x:1659,y:927,t:1527876896362};\\\", \\\"{x:1648,y:949,t:1527876896379};\\\", \\\"{x:1639,y:964,t:1527876896397};\\\", \\\"{x:1634,y:971,t:1527876896413};\\\", \\\"{x:1633,y:973,t:1527876896429};\\\", \\\"{x:1632,y:975,t:1527876896445};\\\", \\\"{x:1630,y:979,t:1527876896463};\\\", \\\"{x:1630,y:981,t:1527876896479};\\\", \\\"{x:1629,y:982,t:1527876896496};\\\", \\\"{x:1628,y:982,t:1527876896513};\\\", \\\"{x:1627,y:983,t:1527876896530};\\\", \\\"{x:1627,y:984,t:1527876896546};\\\", \\\"{x:1626,y:984,t:1527876896563};\\\", \\\"{x:1625,y:985,t:1527876896581};\\\", \\\"{x:1624,y:985,t:1527876896717};\\\", \\\"{x:1622,y:985,t:1527876896755};\\\", \\\"{x:1621,y:985,t:1527876896771};\\\", \\\"{x:1621,y:984,t:1527876896780};\\\", \\\"{x:1619,y:983,t:1527876896796};\\\", \\\"{x:1618,y:981,t:1527876896813};\\\", \\\"{x:1617,y:979,t:1527876896829};\\\", \\\"{x:1616,y:978,t:1527876896846};\\\", \\\"{x:1615,y:975,t:1527876896862};\\\", \\\"{x:1614,y:973,t:1527876896880};\\\", \\\"{x:1614,y:972,t:1527876896896};\\\", \\\"{x:1614,y:971,t:1527876896913};\\\", \\\"{x:1614,y:970,t:1527876896929};\\\", \\\"{x:1614,y:968,t:1527876896948};\\\", \\\"{x:1613,y:967,t:1527876896972};\\\", \\\"{x:1613,y:966,t:1527876896996};\\\", \\\"{x:1613,y:965,t:1527876897013};\\\", \\\"{x:1613,y:964,t:1527876897036};\\\", \\\"{x:1613,y:963,t:1527876897068};\\\", \\\"{x:1613,y:962,t:1527876897092};\\\", \\\"{x:1613,y:961,t:1527876898324};\\\", \\\"{x:1613,y:960,t:1527876898331};\\\", \\\"{x:1613,y:959,t:1527876898348};\\\", \\\"{x:1613,y:958,t:1527876898428};\\\", \\\"{x:1612,y:958,t:1527876898572};\\\", \\\"{x:1609,y:958,t:1527876898588};\\\", \\\"{x:1605,y:958,t:1527876898596};\\\", \\\"{x:1591,y:958,t:1527876898613};\\\", \\\"{x:1584,y:957,t:1527876898628};\\\", \\\"{x:1565,y:956,t:1527876898646};\\\", \\\"{x:1556,y:953,t:1527876898662};\\\", \\\"{x:1536,y:947,t:1527876898678};\\\", \\\"{x:1519,y:940,t:1527876898695};\\\", \\\"{x:1499,y:930,t:1527876898712};\\\", \\\"{x:1472,y:918,t:1527876898729};\\\", \\\"{x:1444,y:900,t:1527876898745};\\\", \\\"{x:1414,y:885,t:1527876898762};\\\", \\\"{x:1384,y:861,t:1527876898778};\\\", \\\"{x:1349,y:832,t:1527876898797};\\\", \\\"{x:1339,y:808,t:1527876898812};\\\", \\\"{x:1327,y:784,t:1527876898828};\\\", \\\"{x:1323,y:764,t:1527876898846};\\\", \\\"{x:1322,y:754,t:1527876898863};\\\", \\\"{x:1321,y:745,t:1527876898879};\\\", \\\"{x:1319,y:739,t:1527876898896};\\\", \\\"{x:1319,y:737,t:1527876898913};\\\", \\\"{x:1319,y:736,t:1527876899148};\\\", \\\"{x:1320,y:732,t:1527876899163};\\\", \\\"{x:1323,y:729,t:1527876899179};\\\", \\\"{x:1329,y:724,t:1527876899196};\\\", \\\"{x:1336,y:718,t:1527876899213};\\\", \\\"{x:1341,y:712,t:1527876899229};\\\", \\\"{x:1346,y:707,t:1527876899246};\\\", \\\"{x:1348,y:705,t:1527876899263};\\\", \\\"{x:1349,y:704,t:1527876899279};\\\", \\\"{x:1348,y:704,t:1527876899396};\\\", \\\"{x:1346,y:705,t:1527876899413};\\\", \\\"{x:1344,y:710,t:1527876899430};\\\", \\\"{x:1343,y:714,t:1527876899446};\\\", \\\"{x:1343,y:721,t:1527876899463};\\\", \\\"{x:1343,y:725,t:1527876899479};\\\", \\\"{x:1343,y:732,t:1527876899496};\\\", \\\"{x:1343,y:742,t:1527876899513};\\\", \\\"{x:1344,y:752,t:1527876899530};\\\", \\\"{x:1344,y:759,t:1527876899547};\\\", \\\"{x:1346,y:766,t:1527876899563};\\\", \\\"{x:1350,y:775,t:1527876899581};\\\", \\\"{x:1354,y:783,t:1527876899596};\\\", \\\"{x:1354,y:786,t:1527876899613};\\\", \\\"{x:1354,y:789,t:1527876899629};\\\", \\\"{x:1356,y:792,t:1527876899645};\\\", \\\"{x:1358,y:795,t:1527876899663};\\\", \\\"{x:1360,y:797,t:1527876899679};\\\", \\\"{x:1361,y:798,t:1527876899696};\\\", \\\"{x:1362,y:798,t:1527876899796};\\\", \\\"{x:1363,y:788,t:1527876899813};\\\", \\\"{x:1363,y:777,t:1527876899829};\\\", \\\"{x:1359,y:761,t:1527876899846};\\\", \\\"{x:1356,y:754,t:1527876899862};\\\", \\\"{x:1354,y:751,t:1527876899879};\\\", \\\"{x:1353,y:749,t:1527876899896};\\\", \\\"{x:1353,y:748,t:1527876899923};\\\", \\\"{x:1352,y:747,t:1527876899940};\\\", \\\"{x:1352,y:746,t:1527876899948};\\\", \\\"{x:1351,y:746,t:1527876899962};\\\", \\\"{x:1349,y:744,t:1527876899979};\\\", \\\"{x:1347,y:743,t:1527876900021};\\\", \\\"{x:1347,y:742,t:1527876900044};\\\", \\\"{x:1347,y:740,t:1527876900052};\\\", \\\"{x:1347,y:738,t:1527876900068};\\\", \\\"{x:1347,y:737,t:1527876900079};\\\", \\\"{x:1345,y:735,t:1527876900096};\\\", \\\"{x:1344,y:735,t:1527876900348};\\\", \\\"{x:1342,y:735,t:1527876900362};\\\", \\\"{x:1341,y:735,t:1527876900379};\\\", \\\"{x:1338,y:741,t:1527876900396};\\\", \\\"{x:1335,y:747,t:1527876900413};\\\", \\\"{x:1332,y:751,t:1527876900429};\\\", \\\"{x:1329,y:756,t:1527876900447};\\\", \\\"{x:1328,y:757,t:1527876900462};\\\", \\\"{x:1328,y:759,t:1527876900480};\\\", \\\"{x:1327,y:760,t:1527876900508};\\\", \\\"{x:1327,y:759,t:1527876900644};\\\", \\\"{x:1327,y:757,t:1527876900652};\\\", \\\"{x:1328,y:757,t:1527876900662};\\\", \\\"{x:1331,y:752,t:1527876900679};\\\", \\\"{x:1336,y:747,t:1527876900697};\\\", \\\"{x:1339,y:741,t:1527876900712};\\\", \\\"{x:1340,y:734,t:1527876900729};\\\", \\\"{x:1342,y:727,t:1527876900747};\\\", \\\"{x:1342,y:721,t:1527876900762};\\\", \\\"{x:1342,y:720,t:1527876900780};\\\", \\\"{x:1342,y:718,t:1527876900796};\\\", \\\"{x:1344,y:716,t:1527876900813};\\\", \\\"{x:1344,y:715,t:1527876900830};\\\", \\\"{x:1346,y:710,t:1527876900846};\\\", \\\"{x:1347,y:709,t:1527876900862};\\\", \\\"{x:1349,y:707,t:1527876900879};\\\", \\\"{x:1349,y:706,t:1527876900896};\\\", \\\"{x:1350,y:705,t:1527876900916};\\\", \\\"{x:1350,y:704,t:1527876900940};\\\", \\\"{x:1351,y:703,t:1527876900948};\\\", \\\"{x:1351,y:702,t:1527876900962};\\\", \\\"{x:1351,y:701,t:1527876900980};\\\", \\\"{x:1351,y:700,t:1527876900995};\\\", \\\"{x:1352,y:700,t:1527876901012};\\\", \\\"{x:1352,y:699,t:1527876901036};\\\", \\\"{x:1351,y:699,t:1527876906132};\\\", \\\"{x:1351,y:703,t:1527876906146};\\\", \\\"{x:1351,y:711,t:1527876906162};\\\", \\\"{x:1348,y:723,t:1527876906178};\\\", \\\"{x:1348,y:733,t:1527876906196};\\\", \\\"{x:1348,y:744,t:1527876906213};\\\", \\\"{x:1349,y:757,t:1527876906227};\\\", \\\"{x:1352,y:766,t:1527876906246};\\\", \\\"{x:1354,y:772,t:1527876906262};\\\", \\\"{x:1357,y:778,t:1527876906279};\\\", \\\"{x:1359,y:782,t:1527876906295};\\\", \\\"{x:1361,y:785,t:1527876906311};\\\", \\\"{x:1362,y:788,t:1527876906328};\\\", \\\"{x:1363,y:789,t:1527876906345};\\\", \\\"{x:1364,y:789,t:1527876906565};\\\", \\\"{x:1365,y:789,t:1527876906578};\\\", \\\"{x:1365,y:788,t:1527876906594};\\\", \\\"{x:1366,y:787,t:1527876906611};\\\", \\\"{x:1366,y:786,t:1527876906636};\\\", \\\"{x:1367,y:785,t:1527876906651};\\\", \\\"{x:1367,y:783,t:1527876906692};\\\", \\\"{x:1367,y:782,t:1527876906716};\\\", \\\"{x:1367,y:780,t:1527876906780};\\\", \\\"{x:1367,y:779,t:1527876906813};\\\", \\\"{x:1367,y:778,t:1527876906877};\\\", \\\"{x:1367,y:777,t:1527876906900};\\\", \\\"{x:1368,y:777,t:1527876906932};\\\", \\\"{x:1368,y:775,t:1527876906948};\\\", \\\"{x:1369,y:775,t:1527876906964};\\\", \\\"{x:1370,y:774,t:1527876906995};\\\", \\\"{x:1371,y:773,t:1527876907020};\\\", \\\"{x:1371,y:772,t:1527876907068};\\\", \\\"{x:1371,y:771,t:1527876907079};\\\", \\\"{x:1371,y:770,t:1527876907244};\\\", \\\"{x:1371,y:768,t:1527876908085};\\\", \\\"{x:1371,y:767,t:1527876908100};\\\", \\\"{x:1371,y:766,t:1527876908112};\\\", \\\"{x:1367,y:764,t:1527876908128};\\\", \\\"{x:1363,y:763,t:1527876908145};\\\", \\\"{x:1357,y:763,t:1527876908161};\\\", \\\"{x:1357,y:762,t:1527876908179};\\\", \\\"{x:1356,y:762,t:1527876908236};\\\", \\\"{x:1355,y:762,t:1527876911644};\\\", \\\"{x:1353,y:762,t:1527876911763};\\\", \\\"{x:1352,y:762,t:1527876911793};\\\", \\\"{x:1351,y:761,t:1527876911810};\\\", \\\"{x:1349,y:760,t:1527876911826};\\\", \\\"{x:1348,y:760,t:1527876911859};\\\", \\\"{x:1347,y:760,t:1527876916477};\\\", \\\"{x:1347,y:758,t:1527876917556};\\\", \\\"{x:1347,y:757,t:1527876917564};\\\", \\\"{x:1347,y:756,t:1527876917580};\\\", \\\"{x:1347,y:755,t:1527876917592};\\\", \\\"{x:1347,y:753,t:1527876917844};\\\", \\\"{x:1347,y:749,t:1527876917859};\\\", \\\"{x:1348,y:748,t:1527876917877};\\\", \\\"{x:1350,y:740,t:1527876917893};\\\", \\\"{x:1351,y:736,t:1527876917909};\\\", \\\"{x:1355,y:729,t:1527876917927};\\\", \\\"{x:1356,y:727,t:1527876917942};\\\", \\\"{x:1359,y:721,t:1527876917960};\\\", \\\"{x:1359,y:720,t:1527876917977};\\\", \\\"{x:1359,y:716,t:1527876917993};\\\", \\\"{x:1359,y:713,t:1527876918009};\\\", \\\"{x:1360,y:711,t:1527876918027};\\\", \\\"{x:1360,y:710,t:1527876918043};\\\", \\\"{x:1360,y:708,t:1527876918060};\\\", \\\"{x:1360,y:707,t:1527876918076};\\\", \\\"{x:1360,y:706,t:1527876918093};\\\", \\\"{x:1361,y:705,t:1527876918110};\\\", \\\"{x:1361,y:704,t:1527876918132};\\\", \\\"{x:1361,y:703,t:1527876918164};\\\", \\\"{x:1361,y:702,t:1527876918175};\\\", \\\"{x:1362,y:702,t:1527876918193};\\\", \\\"{x:1362,y:701,t:1527876918213};\\\", \\\"{x:1362,y:700,t:1527876918228};\\\", \\\"{x:1362,y:699,t:1527876918242};\\\", \\\"{x:1362,y:697,t:1527876918260};\\\", \\\"{x:1359,y:694,t:1527876918277};\\\", \\\"{x:1357,y:694,t:1527876918292};\\\", \\\"{x:1355,y:693,t:1527876918332};\\\", \\\"{x:1354,y:693,t:1527876918347};\\\", \\\"{x:1353,y:692,t:1527876918371};\\\", \\\"{x:1352,y:692,t:1527876918420};\\\", \\\"{x:1351,y:692,t:1527876918461};\\\", \\\"{x:1350,y:692,t:1527876918476};\\\", \\\"{x:1349,y:692,t:1527876918523};\\\", \\\"{x:1348,y:692,t:1527876922035};\\\", \\\"{x:1347,y:692,t:1527876922042};\\\", \\\"{x:1347,y:693,t:1527876922075};\\\", \\\"{x:1347,y:694,t:1527876922092};\\\", \\\"{x:1347,y:695,t:1527876922116};\\\", \\\"{x:1347,y:697,t:1527876922140};\\\", \\\"{x:1347,y:699,t:1527876922155};\\\", \\\"{x:1347,y:700,t:1527876922164};\\\", \\\"{x:1347,y:701,t:1527876922176};\\\", \\\"{x:1347,y:703,t:1527876922221};\\\", \\\"{x:1347,y:704,t:1527876922227};\\\", \\\"{x:1347,y:709,t:1527876922241};\\\", \\\"{x:1352,y:717,t:1527876922259};\\\", \\\"{x:1366,y:731,t:1527876922275};\\\", \\\"{x:1373,y:736,t:1527876922292};\\\", \\\"{x:1379,y:741,t:1527876922309};\\\", \\\"{x:1385,y:745,t:1527876922326};\\\", \\\"{x:1390,y:749,t:1527876922342};\\\", \\\"{x:1394,y:750,t:1527876922359};\\\", \\\"{x:1399,y:753,t:1527876922376};\\\", \\\"{x:1399,y:754,t:1527876922392};\\\", \\\"{x:1400,y:756,t:1527876922409};\\\", \\\"{x:1402,y:756,t:1527876922426};\\\", \\\"{x:1401,y:757,t:1527876922708};\\\", \\\"{x:1399,y:759,t:1527876922725};\\\", \\\"{x:1398,y:759,t:1527876922742};\\\", \\\"{x:1395,y:760,t:1527876922759};\\\", \\\"{x:1393,y:761,t:1527876922779};\\\", \\\"{x:1391,y:762,t:1527876922792};\\\", \\\"{x:1390,y:763,t:1527876922810};\\\", \\\"{x:1385,y:767,t:1527876922827};\\\", \\\"{x:1380,y:767,t:1527876922842};\\\", \\\"{x:1376,y:769,t:1527876922859};\\\", \\\"{x:1376,y:770,t:1527876922876};\\\", \\\"{x:1375,y:771,t:1527876922891};\\\", \\\"{x:1374,y:771,t:1527876923019};\\\", \\\"{x:1372,y:770,t:1527876923035};\\\", \\\"{x:1370,y:765,t:1527876923052};\\\", \\\"{x:1369,y:762,t:1527876923060};\\\", \\\"{x:1364,y:750,t:1527876923076};\\\", \\\"{x:1362,y:743,t:1527876923092};\\\", \\\"{x:1359,y:736,t:1527876923109};\\\", \\\"{x:1355,y:729,t:1527876923126};\\\", \\\"{x:1354,y:723,t:1527876923142};\\\", \\\"{x:1352,y:718,t:1527876923159};\\\", \\\"{x:1351,y:714,t:1527876923175};\\\", \\\"{x:1351,y:711,t:1527876923192};\\\", \\\"{x:1350,y:707,t:1527876923209};\\\", \\\"{x:1348,y:704,t:1527876923226};\\\", \\\"{x:1348,y:702,t:1527876923243};\\\", \\\"{x:1347,y:699,t:1527876923258};\\\", \\\"{x:1346,y:697,t:1527876923284};\\\", \\\"{x:1345,y:696,t:1527876923292};\\\", \\\"{x:1345,y:695,t:1527876923309};\\\", \\\"{x:1348,y:695,t:1527876931202};\\\", \\\"{x:1349,y:695,t:1527876931210};\\\", \\\"{x:1352,y:695,t:1527876931224};\\\", \\\"{x:1355,y:695,t:1527876931241};\\\", \\\"{x:1360,y:693,t:1527876931257};\\\", \\\"{x:1362,y:693,t:1527876931299};\\\", \\\"{x:1363,y:693,t:1527876931346};\\\", \\\"{x:1366,y:692,t:1527876931357};\\\", \\\"{x:1368,y:692,t:1527876931386};\\\", \\\"{x:1370,y:692,t:1527876931394};\\\", \\\"{x:1373,y:692,t:1527876931406};\\\", \\\"{x:1383,y:695,t:1527876931424};\\\", \\\"{x:1387,y:697,t:1527876931441};\\\", \\\"{x:1389,y:697,t:1527876931457};\\\", \\\"{x:1400,y:700,t:1527876931474};\\\", \\\"{x:1406,y:700,t:1527876931490};\\\", \\\"{x:1407,y:700,t:1527876931514};\\\", \\\"{x:1408,y:700,t:1527876931524};\\\", \\\"{x:1409,y:700,t:1527876931571};\\\", \\\"{x:1412,y:700,t:1527876931579};\\\", \\\"{x:1413,y:700,t:1527876931594};\\\", \\\"{x:1417,y:700,t:1527876931607};\\\", \\\"{x:1420,y:700,t:1527876931624};\\\", \\\"{x:1422,y:700,t:1527876931640};\\\", \\\"{x:1423,y:700,t:1527876931657};\\\", \\\"{x:1426,y:700,t:1527876931675};\\\", \\\"{x:1428,y:700,t:1527876931690};\\\", \\\"{x:1437,y:700,t:1527876931706};\\\", \\\"{x:1439,y:700,t:1527876931724};\\\", \\\"{x:1443,y:700,t:1527876931740};\\\", \\\"{x:1449,y:700,t:1527876931756};\\\", \\\"{x:1453,y:700,t:1527876931774};\\\", \\\"{x:1456,y:700,t:1527876931790};\\\", \\\"{x:1458,y:699,t:1527876931810};\\\", \\\"{x:1462,y:699,t:1527876931824};\\\", \\\"{x:1472,y:698,t:1527876931840};\\\", \\\"{x:1476,y:698,t:1527876931857};\\\", \\\"{x:1481,y:698,t:1527876931873};\\\", \\\"{x:1483,y:698,t:1527876931890};\\\", \\\"{x:1484,y:698,t:1527876932058};\\\", \\\"{x:1485,y:698,t:1527876932074};\\\", \\\"{x:1491,y:698,t:1527876932089};\\\", \\\"{x:1504,y:698,t:1527876932106};\\\", \\\"{x:1509,y:698,t:1527876932123};\\\", \\\"{x:1517,y:698,t:1527876932140};\\\", \\\"{x:1526,y:698,t:1527876932157};\\\", \\\"{x:1528,y:698,t:1527876932174};\\\", \\\"{x:1529,y:698,t:1527876932227};\\\", \\\"{x:1530,y:698,t:1527876932266};\\\", \\\"{x:1531,y:698,t:1527876932314};\\\", \\\"{x:1532,y:698,t:1527876932323};\\\", \\\"{x:1536,y:696,t:1527876932339};\\\", \\\"{x:1542,y:695,t:1527876932356};\\\", \\\"{x:1543,y:695,t:1527876932374};\\\", \\\"{x:1542,y:696,t:1527876932843};\\\", \\\"{x:1538,y:696,t:1527876932857};\\\", \\\"{x:1534,y:701,t:1527876932874};\\\", \\\"{x:1527,y:710,t:1527876932890};\\\", \\\"{x:1516,y:730,t:1527876932906};\\\", \\\"{x:1513,y:740,t:1527876932923};\\\", \\\"{x:1503,y:755,t:1527876932940};\\\", \\\"{x:1497,y:770,t:1527876932957};\\\", \\\"{x:1487,y:789,t:1527876932974};\\\", \\\"{x:1478,y:815,t:1527876932990};\\\", \\\"{x:1468,y:842,t:1527876933007};\\\", \\\"{x:1465,y:869,t:1527876933024};\\\", \\\"{x:1461,y:879,t:1527876933039};\\\", \\\"{x:1460,y:887,t:1527876933057};\\\", \\\"{x:1458,y:894,t:1527876933073};\\\", \\\"{x:1458,y:899,t:1527876933090};\\\", \\\"{x:1458,y:905,t:1527876933106};\\\", \\\"{x:1457,y:908,t:1527876933124};\\\", \\\"{x:1456,y:909,t:1527876933139};\\\", \\\"{x:1456,y:910,t:1527876933157};\\\", \\\"{x:1454,y:910,t:1527876933174};\\\", \\\"{x:1452,y:912,t:1527876933190};\\\", \\\"{x:1449,y:915,t:1527876933206};\\\", \\\"{x:1448,y:917,t:1527876933223};\\\", \\\"{x:1445,y:920,t:1527876933240};\\\", \\\"{x:1441,y:923,t:1527876933256};\\\", \\\"{x:1439,y:927,t:1527876933274};\\\", \\\"{x:1438,y:928,t:1527876933290};\\\", \\\"{x:1437,y:934,t:1527876933306};\\\", \\\"{x:1437,y:935,t:1527876933331};\\\", \\\"{x:1437,y:937,t:1527876933346};\\\", \\\"{x:1436,y:939,t:1527876933530};\\\", \\\"{x:1436,y:940,t:1527876933546};\\\", \\\"{x:1435,y:940,t:1527876933557};\\\", \\\"{x:1434,y:941,t:1527876933578};\\\", \\\"{x:1434,y:942,t:1527876933594};\\\", \\\"{x:1433,y:944,t:1527876933607};\\\", \\\"{x:1433,y:945,t:1527876933730};\\\", \\\"{x:1433,y:946,t:1527876933771};\\\", \\\"{x:1433,y:947,t:1527876933786};\\\", \\\"{x:1432,y:948,t:1527876933794};\\\", \\\"{x:1432,y:949,t:1527876933818};\\\", \\\"{x:1432,y:950,t:1527876933831};\\\", \\\"{x:1432,y:951,t:1527876933855};\\\", \\\"{x:1432,y:952,t:1527876933863};\\\", \\\"{x:1432,y:954,t:1527876933886};\\\", \\\"{x:1432,y:956,t:1527876933894};\\\", \\\"{x:1431,y:957,t:1527876933911};\\\", \\\"{x:1431,y:958,t:1527876934015};\\\", \\\"{x:1431,y:959,t:1527876934031};\\\", \\\"{x:1431,y:961,t:1527876934062};\\\", \\\"{x:1433,y:962,t:1527876934077};\\\", \\\"{x:1440,y:964,t:1527876934094};\\\", \\\"{x:1453,y:964,t:1527876934110};\\\", \\\"{x:1466,y:964,t:1527876934127};\\\", \\\"{x:1479,y:966,t:1527876934145};\\\", \\\"{x:1493,y:969,t:1527876934161};\\\", \\\"{x:1498,y:970,t:1527876934177};\\\", \\\"{x:1501,y:970,t:1527876934194};\\\", \\\"{x:1504,y:970,t:1527876934212};\\\", \\\"{x:1506,y:970,t:1527876934227};\\\", \\\"{x:1507,y:970,t:1527876934263};\\\", \\\"{x:1508,y:970,t:1527876934383};\\\", \\\"{x:1510,y:970,t:1527876934394};\\\", \\\"{x:1512,y:969,t:1527876934411};\\\", \\\"{x:1514,y:968,t:1527876934427};\\\", \\\"{x:1516,y:967,t:1527876934444};\\\", \\\"{x:1522,y:965,t:1527876934461};\\\", \\\"{x:1533,y:963,t:1527876934477};\\\", \\\"{x:1545,y:961,t:1527876934494};\\\", \\\"{x:1566,y:961,t:1527876934511};\\\", \\\"{x:1579,y:961,t:1527876934527};\\\", \\\"{x:1582,y:960,t:1527876934544};\\\", \\\"{x:1585,y:960,t:1527876934561};\\\", \\\"{x:1586,y:960,t:1527876934578};\\\", \\\"{x:1588,y:960,t:1527876934719};\\\", \\\"{x:1589,y:960,t:1527876934735};\\\", \\\"{x:1591,y:962,t:1527876934751};\\\", \\\"{x:1593,y:962,t:1527876934775};\\\", \\\"{x:1593,y:963,t:1527876934791};\\\", \\\"{x:1593,y:964,t:1527876934799};\\\", \\\"{x:1595,y:965,t:1527876934812};\\\", \\\"{x:1597,y:967,t:1527876934827};\\\", \\\"{x:1598,y:967,t:1527876934844};\\\", \\\"{x:1599,y:968,t:1527876934861};\\\", \\\"{x:1602,y:968,t:1527876934877};\\\", \\\"{x:1605,y:968,t:1527876934894};\\\", \\\"{x:1606,y:968,t:1527876934911};\\\", \\\"{x:1608,y:968,t:1527876935023};\\\", \\\"{x:1609,y:968,t:1527876935047};\\\", \\\"{x:1610,y:968,t:1527876935060};\\\", \\\"{x:1613,y:967,t:1527876935078};\\\", \\\"{x:1615,y:966,t:1527876935095};\\\", \\\"{x:1617,y:964,t:1527876935111};\\\", \\\"{x:1617,y:963,t:1527876935215};\\\", \\\"{x:1619,y:962,t:1527876935263};\\\", \\\"{x:1619,y:961,t:1527876957800};\\\", \\\"{x:1615,y:958,t:1527876963768};\\\", \\\"{x:1604,y:956,t:1527876963775};\\\", \\\"{x:1579,y:954,t:1527876963790};\\\", \\\"{x:1431,y:924,t:1527876963807};\\\", \\\"{x:1324,y:900,t:1527876963823};\\\", \\\"{x:1179,y:867,t:1527876963840};\\\", \\\"{x:1015,y:834,t:1527876963857};\\\", \\\"{x:867,y:801,t:1527876963874};\\\", \\\"{x:719,y:773,t:1527876963890};\\\", \\\"{x:634,y:756,t:1527876963906};\\\", \\\"{x:580,y:736,t:1527876963923};\\\", \\\"{x:562,y:728,t:1527876963941};\\\", \\\"{x:536,y:713,t:1527876963956};\\\", \\\"{x:511,y:700,t:1527876963972};\\\", \\\"{x:490,y:689,t:1527876963985};\\\", \\\"{x:472,y:678,t:1527876964002};\\\", \\\"{x:458,y:672,t:1527876964019};\\\", \\\"{x:452,y:671,t:1527876964035};\\\", \\\"{x:449,y:670,t:1527876964052};\\\", \\\"{x:449,y:669,t:1527876964069};\\\", \\\"{x:447,y:667,t:1527876964086};\\\", \\\"{x:448,y:660,t:1527876964102};\\\", \\\"{x:456,y:651,t:1527876964120};\\\", \\\"{x:471,y:641,t:1527876964135};\\\", \\\"{x:479,y:635,t:1527876964153};\\\", \\\"{x:487,y:630,t:1527876964170};\\\", \\\"{x:497,y:627,t:1527876964185};\\\", \\\"{x:508,y:624,t:1527876964203};\\\", \\\"{x:514,y:623,t:1527876964220};\\\", \\\"{x:528,y:619,t:1527876964235};\\\", \\\"{x:541,y:614,t:1527876964252};\\\", \\\"{x:550,y:612,t:1527876964270};\\\", \\\"{x:566,y:607,t:1527876964286};\\\", \\\"{x:575,y:603,t:1527876964303};\\\", \\\"{x:585,y:600,t:1527876964321};\\\", \\\"{x:593,y:598,t:1527876964336};\\\", \\\"{x:606,y:593,t:1527876964354};\\\", \\\"{x:614,y:589,t:1527876964370};\\\", \\\"{x:622,y:586,t:1527876964387};\\\", \\\"{x:629,y:583,t:1527876964402};\\\", \\\"{x:632,y:580,t:1527876964419};\\\", \\\"{x:633,y:579,t:1527876964437};\\\", \\\"{x:634,y:578,t:1527876964452};\\\", \\\"{x:634,y:577,t:1527876964470};\\\", \\\"{x:636,y:576,t:1527876964486};\\\", \\\"{x:637,y:573,t:1527876964502};\\\", \\\"{x:637,y:572,t:1527876964520};\\\", \\\"{x:637,y:573,t:1527876964750};\\\", \\\"{x:637,y:574,t:1527876964758};\\\", \\\"{x:637,y:576,t:1527876964769};\\\", \\\"{x:633,y:583,t:1527876964787};\\\", \\\"{x:626,y:593,t:1527876964803};\\\", \\\"{x:617,y:604,t:1527876964820};\\\", \\\"{x:607,y:618,t:1527876964837};\\\", \\\"{x:595,y:632,t:1527876964854};\\\", \\\"{x:591,y:641,t:1527876964870};\\\", \\\"{x:571,y:664,t:1527876964887};\\\", \\\"{x:558,y:674,t:1527876964903};\\\", \\\"{x:546,y:695,t:1527876964919};\\\", \\\"{x:537,y:711,t:1527876964936};\\\", \\\"{x:533,y:718,t:1527876964954};\\\", \\\"{x:531,y:720,t:1527876964970};\\\", \\\"{x:529,y:721,t:1527876964987};\\\", \\\"{x:527,y:723,t:1527876965002};\\\", \\\"{x:526,y:724,t:1527876965020};\\\", \\\"{x:525,y:724,t:1527876965036};\\\", \\\"{x:524,y:724,t:1527876965053};\\\", \\\"{x:523,y:726,t:1527876965079};\\\", \\\"{x:521,y:728,t:1527876965087};\\\", \\\"{x:513,y:739,t:1527876965103};\\\", \\\"{x:508,y:747,t:1527876965120};\\\", \\\"{x:507,y:749,t:1527876965137};\\\", \\\"{x:511,y:749,t:1527876965655};\\\", \\\"{x:524,y:740,t:1527876965670};\\\", \\\"{x:547,y:731,t:1527876965687};\\\", \\\"{x:570,y:719,t:1527876965704};\\\", \\\"{x:601,y:706,t:1527876965720};\\\", \\\"{x:633,y:696,t:1527876965738};\\\", \\\"{x:674,y:689,t:1527876965753};\\\", \\\"{x:709,y:682,t:1527876965771};\\\", \\\"{x:735,y:681,t:1527876965788};\\\", \\\"{x:744,y:681,t:1527876965804};\\\", \\\"{x:757,y:681,t:1527876965821};\\\", \\\"{x:759,y:681,t:1527876965838};\\\", \\\"{x:760,y:681,t:1527876965853};\\\", \\\"{x:760,y:682,t:1527876966056};\\\", \\\"{x:758,y:689,t:1527876966071};\\\", \\\"{x:756,y:691,t:1527876966088};\\\", \\\"{x:749,y:694,t:1527876966104};\\\" ] }, { \\\"rt\\\": 17329, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 589838, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:748,y:694,t:1527876967295};\\\", \\\"{x:747,y:693,t:1527876967319};\\\", \\\"{x:746,y:692,t:1527876967327};\\\", \\\"{x:745,y:691,t:1527876967343};\\\", \\\"{x:744,y:689,t:1527876967359};\\\", \\\"{x:743,y:689,t:1527876967371};\\\", \\\"{x:743,y:688,t:1527876967389};\\\", \\\"{x:742,y:686,t:1527876968232};\\\", \\\"{x:742,y:685,t:1527876968447};\\\", \\\"{x:746,y:684,t:1527876968456};\\\", \\\"{x:775,y:689,t:1527876968474};\\\", \\\"{x:804,y:698,t:1527876968490};\\\", \\\"{x:832,y:707,t:1527876968506};\\\", \\\"{x:884,y:723,t:1527876968523};\\\", \\\"{x:919,y:735,t:1527876968539};\\\", \\\"{x:974,y:749,t:1527876968555};\\\", \\\"{x:1053,y:778,t:1527876968573};\\\", \\\"{x:1111,y:795,t:1527876968589};\\\", \\\"{x:1162,y:812,t:1527876968606};\\\", \\\"{x:1200,y:823,t:1527876968622};\\\", \\\"{x:1214,y:825,t:1527876968640};\\\", \\\"{x:1227,y:829,t:1527876968657};\\\", \\\"{x:1233,y:833,t:1527876968673};\\\", \\\"{x:1239,y:836,t:1527876968690};\\\", \\\"{x:1245,y:839,t:1527876968705};\\\", \\\"{x:1251,y:841,t:1527876968723};\\\", \\\"{x:1259,y:845,t:1527876968740};\\\", \\\"{x:1265,y:849,t:1527876968757};\\\", \\\"{x:1275,y:855,t:1527876968772};\\\", \\\"{x:1277,y:857,t:1527876968790};\\\", \\\"{x:1281,y:859,t:1527876968807};\\\", \\\"{x:1283,y:864,t:1527876968823};\\\", \\\"{x:1286,y:870,t:1527876968840};\\\", \\\"{x:1290,y:875,t:1527876968857};\\\", \\\"{x:1296,y:881,t:1527876968873};\\\", \\\"{x:1298,y:885,t:1527876968890};\\\", \\\"{x:1300,y:893,t:1527876968907};\\\", \\\"{x:1306,y:901,t:1527876968923};\\\", \\\"{x:1312,y:912,t:1527876968939};\\\", \\\"{x:1317,y:922,t:1527876968957};\\\", \\\"{x:1319,y:931,t:1527876968972};\\\", \\\"{x:1322,y:939,t:1527876968989};\\\", \\\"{x:1325,y:947,t:1527876969006};\\\", \\\"{x:1327,y:949,t:1527876969022};\\\", \\\"{x:1328,y:951,t:1527876969039};\\\", \\\"{x:1328,y:952,t:1527876969057};\\\", \\\"{x:1329,y:952,t:1527876969078};\\\", \\\"{x:1329,y:953,t:1527876969089};\\\", \\\"{x:1330,y:953,t:1527876969107};\\\", \\\"{x:1331,y:953,t:1527876969215};\\\", \\\"{x:1332,y:954,t:1527876969224};\\\", \\\"{x:1335,y:957,t:1527876969240};\\\", \\\"{x:1336,y:958,t:1527876969257};\\\", \\\"{x:1336,y:959,t:1527876969274};\\\", \\\"{x:1338,y:960,t:1527876969290};\\\", \\\"{x:1339,y:960,t:1527876969311};\\\", \\\"{x:1340,y:960,t:1527876969368};\\\", \\\"{x:1340,y:961,t:1527876969375};\\\", \\\"{x:1341,y:961,t:1527876969399};\\\", \\\"{x:1341,y:962,t:1527876969416};\\\", \\\"{x:1342,y:963,t:1527876969664};\\\", \\\"{x:1342,y:964,t:1527876969679};\\\", \\\"{x:1345,y:966,t:1527876969691};\\\", \\\"{x:1348,y:967,t:1527876969707};\\\", \\\"{x:1350,y:967,t:1527876969725};\\\", \\\"{x:1349,y:966,t:1527876971472};\\\", \\\"{x:1348,y:965,t:1527876971486};\\\", \\\"{x:1348,y:964,t:1527876971503};\\\", \\\"{x:1348,y:963,t:1527876971527};\\\", \\\"{x:1348,y:962,t:1527876971542};\\\", \\\"{x:1347,y:962,t:1527876971808};\\\", \\\"{x:1346,y:962,t:1527876971855};\\\", \\\"{x:1346,y:963,t:1527876971872};\\\", \\\"{x:1346,y:964,t:1527876971911};\\\", \\\"{x:1346,y:965,t:1527876972030};\\\", \\\"{x:1346,y:966,t:1527876972046};\\\", \\\"{x:1344,y:968,t:1527876972151};\\\", \\\"{x:1344,y:970,t:1527876973200};\\\", \\\"{x:1343,y:970,t:1527876973215};\\\", \\\"{x:1342,y:971,t:1527876973231};\\\", \\\"{x:1342,y:972,t:1527876973244};\\\", \\\"{x:1342,y:973,t:1527876973263};\\\", \\\"{x:1341,y:973,t:1527876973277};\\\", \\\"{x:1341,y:974,t:1527876973294};\\\", \\\"{x:1341,y:976,t:1527876973310};\\\", \\\"{x:1340,y:978,t:1527876973351};\\\", \\\"{x:1340,y:979,t:1527876973382};\\\", \\\"{x:1340,y:980,t:1527876973393};\\\", \\\"{x:1339,y:980,t:1527876973438};\\\", \\\"{x:1338,y:980,t:1527876974335};\\\", \\\"{x:1338,y:979,t:1527876974345};\\\", \\\"{x:1338,y:977,t:1527876974361};\\\", \\\"{x:1339,y:976,t:1527876974378};\\\", \\\"{x:1340,y:975,t:1527876974394};\\\", \\\"{x:1340,y:974,t:1527876974431};\\\", \\\"{x:1342,y:973,t:1527876974704};\\\", \\\"{x:1342,y:972,t:1527876974711};\\\", \\\"{x:1343,y:972,t:1527876974735};\\\", \\\"{x:1344,y:972,t:1527876974759};\\\", \\\"{x:1345,y:972,t:1527876974767};\\\", \\\"{x:1345,y:969,t:1527876980191};\\\", \\\"{x:1344,y:968,t:1527876980199};\\\", \\\"{x:1344,y:967,t:1527876980216};\\\", \\\"{x:1344,y:966,t:1527876980416};\\\", \\\"{x:1338,y:963,t:1527876980768};\\\", \\\"{x:1325,y:957,t:1527876980783};\\\", \\\"{x:1266,y:933,t:1527876980799};\\\", \\\"{x:1192,y:907,t:1527876980816};\\\", \\\"{x:1142,y:885,t:1527876980833};\\\", \\\"{x:1083,y:858,t:1527876980848};\\\", \\\"{x:1032,y:831,t:1527876980865};\\\", \\\"{x:947,y:792,t:1527876980882};\\\", \\\"{x:870,y:762,t:1527876980898};\\\", \\\"{x:823,y:737,t:1527876980915};\\\", \\\"{x:790,y:715,t:1527876980932};\\\", \\\"{x:760,y:695,t:1527876980948};\\\", \\\"{x:737,y:676,t:1527876980966};\\\", \\\"{x:693,y:650,t:1527876980983};\\\", \\\"{x:667,y:633,t:1527876980999};\\\", \\\"{x:641,y:618,t:1527876981017};\\\", \\\"{x:621,y:608,t:1527876981032};\\\", \\\"{x:598,y:600,t:1527876981049};\\\", \\\"{x:586,y:597,t:1527876981063};\\\", \\\"{x:579,y:595,t:1527876981079};\\\", \\\"{x:577,y:594,t:1527876981096};\\\", \\\"{x:576,y:594,t:1527876981117};\\\", \\\"{x:575,y:593,t:1527876981142};\\\", \\\"{x:575,y:592,t:1527876981150};\\\", \\\"{x:572,y:584,t:1527876981165};\\\", \\\"{x:571,y:571,t:1527876981183};\\\", \\\"{x:569,y:562,t:1527876981201};\\\", \\\"{x:569,y:561,t:1527876981216};\\\", \\\"{x:569,y:558,t:1527876981233};\\\", \\\"{x:569,y:555,t:1527876981251};\\\", \\\"{x:574,y:550,t:1527876981266};\\\", \\\"{x:580,y:546,t:1527876981283};\\\", \\\"{x:590,y:541,t:1527876981300};\\\", \\\"{x:596,y:538,t:1527876981317};\\\", \\\"{x:601,y:535,t:1527876981334};\\\", \\\"{x:603,y:534,t:1527876981350};\\\", \\\"{x:604,y:533,t:1527876981399};\\\", \\\"{x:606,y:532,t:1527876981423};\\\", \\\"{x:607,y:532,t:1527876981487};\\\", \\\"{x:608,y:530,t:1527876981527};\\\", \\\"{x:609,y:529,t:1527876981534};\\\", \\\"{x:609,y:525,t:1527876981552};\\\", \\\"{x:609,y:523,t:1527876981568};\\\", \\\"{x:609,y:518,t:1527876981583};\\\", \\\"{x:610,y:511,t:1527876981601};\\\", \\\"{x:610,y:507,t:1527876981617};\\\", \\\"{x:611,y:505,t:1527876981633};\\\", \\\"{x:612,y:504,t:1527876981662};\\\", \\\"{x:614,y:503,t:1527876981670};\\\", \\\"{x:615,y:503,t:1527876981684};\\\", \\\"{x:618,y:500,t:1527876981700};\\\", \\\"{x:621,y:500,t:1527876981717};\\\", \\\"{x:643,y:501,t:1527876981735};\\\", \\\"{x:666,y:508,t:1527876981750};\\\", \\\"{x:688,y:508,t:1527876981767};\\\", \\\"{x:730,y:512,t:1527876981784};\\\", \\\"{x:762,y:516,t:1527876981800};\\\", \\\"{x:781,y:518,t:1527876981817};\\\", \\\"{x:792,y:519,t:1527876981833};\\\", \\\"{x:795,y:519,t:1527876981850};\\\", \\\"{x:796,y:519,t:1527876981886};\\\", \\\"{x:798,y:519,t:1527876981900};\\\", \\\"{x:799,y:519,t:1527876981917};\\\", \\\"{x:801,y:518,t:1527876981934};\\\", \\\"{x:803,y:517,t:1527876981990};\\\", \\\"{x:805,y:515,t:1527876982000};\\\", \\\"{x:808,y:512,t:1527876982017};\\\", \\\"{x:811,y:509,t:1527876982034};\\\", \\\"{x:813,y:507,t:1527876982050};\\\", \\\"{x:816,y:504,t:1527876982067};\\\", \\\"{x:821,y:501,t:1527876982084};\\\", \\\"{x:826,y:499,t:1527876982100};\\\", \\\"{x:829,y:497,t:1527876982117};\\\", \\\"{x:840,y:493,t:1527876982134};\\\", \\\"{x:843,y:491,t:1527876982150};\\\", \\\"{x:844,y:491,t:1527876982234};\\\", \\\"{x:844,y:491,t:1527876982348};\\\", \\\"{x:842,y:491,t:1527876982438};\\\", \\\"{x:838,y:492,t:1527876982451};\\\", \\\"{x:833,y:496,t:1527876982467};\\\", \\\"{x:828,y:499,t:1527876982485};\\\", \\\"{x:818,y:507,t:1527876982502};\\\", \\\"{x:802,y:519,t:1527876982519};\\\", \\\"{x:783,y:528,t:1527876982535};\\\", \\\"{x:757,y:535,t:1527876982551};\\\", \\\"{x:743,y:540,t:1527876982567};\\\", \\\"{x:723,y:546,t:1527876982585};\\\", \\\"{x:713,y:552,t:1527876982602};\\\", \\\"{x:711,y:553,t:1527876982617};\\\", \\\"{x:708,y:554,t:1527876982634};\\\", \\\"{x:707,y:555,t:1527876982652};\\\", \\\"{x:707,y:556,t:1527876982669};\\\", \\\"{x:705,y:558,t:1527876982684};\\\", \\\"{x:702,y:558,t:1527876982702};\\\", \\\"{x:700,y:560,t:1527876982717};\\\", \\\"{x:687,y:562,t:1527876982734};\\\", \\\"{x:679,y:565,t:1527876982751};\\\", \\\"{x:658,y:566,t:1527876982768};\\\", \\\"{x:628,y:566,t:1527876982784};\\\", \\\"{x:605,y:567,t:1527876982801};\\\", \\\"{x:574,y:568,t:1527876982817};\\\", \\\"{x:507,y:568,t:1527876982834};\\\", \\\"{x:443,y:568,t:1527876982852};\\\", \\\"{x:414,y:570,t:1527876982867};\\\", \\\"{x:382,y:570,t:1527876982884};\\\", \\\"{x:369,y:570,t:1527876982901};\\\", \\\"{x:352,y:569,t:1527876982917};\\\", \\\"{x:345,y:568,t:1527876982934};\\\", \\\"{x:339,y:566,t:1527876982951};\\\", \\\"{x:337,y:566,t:1527876982968};\\\", \\\"{x:336,y:566,t:1527876982984};\\\", \\\"{x:334,y:565,t:1527876983001};\\\", \\\"{x:330,y:565,t:1527876983018};\\\", \\\"{x:324,y:562,t:1527876983034};\\\", \\\"{x:317,y:559,t:1527876983051};\\\", \\\"{x:302,y:557,t:1527876983068};\\\", \\\"{x:291,y:556,t:1527876983084};\\\", \\\"{x:276,y:553,t:1527876983102};\\\", \\\"{x:260,y:552,t:1527876983118};\\\", \\\"{x:241,y:551,t:1527876983135};\\\", \\\"{x:234,y:550,t:1527876983151};\\\", \\\"{x:228,y:549,t:1527876983168};\\\", \\\"{x:220,y:545,t:1527876983185};\\\", \\\"{x:217,y:545,t:1527876983201};\\\", \\\"{x:212,y:544,t:1527876983218};\\\", \\\"{x:207,y:541,t:1527876983235};\\\", \\\"{x:195,y:535,t:1527876983251};\\\", \\\"{x:193,y:534,t:1527876983268};\\\", \\\"{x:191,y:532,t:1527876983285};\\\", \\\"{x:188,y:531,t:1527876983335};\\\", \\\"{x:192,y:532,t:1527876983550};\\\", \\\"{x:204,y:542,t:1527876983568};\\\", \\\"{x:221,y:554,t:1527876983585};\\\", \\\"{x:248,y:572,t:1527876983601};\\\", \\\"{x:277,y:593,t:1527876983619};\\\", \\\"{x:290,y:600,t:1527876983635};\\\", \\\"{x:325,y:620,t:1527876983653};\\\", \\\"{x:374,y:639,t:1527876983669};\\\", \\\"{x:379,y:641,t:1527876983685};\\\", \\\"{x:396,y:650,t:1527876983702};\\\", \\\"{x:411,y:657,t:1527876983718};\\\", \\\"{x:414,y:659,t:1527876983735};\\\", \\\"{x:415,y:660,t:1527876983791};\\\", \\\"{x:417,y:661,t:1527876983814};\\\", \\\"{x:419,y:663,t:1527876983823};\\\", \\\"{x:419,y:664,t:1527876983835};\\\", \\\"{x:423,y:671,t:1527876983853};\\\", \\\"{x:427,y:675,t:1527876983869};\\\", \\\"{x:433,y:682,t:1527876983885};\\\", \\\"{x:444,y:691,t:1527876983902};\\\", \\\"{x:453,y:702,t:1527876983918};\\\", \\\"{x:459,y:712,t:1527876983935};\\\", \\\"{x:464,y:718,t:1527876983952};\\\", \\\"{x:472,y:722,t:1527876983969};\\\", \\\"{x:478,y:725,t:1527876983985};\\\", \\\"{x:482,y:725,t:1527876984002};\\\", \\\"{x:485,y:725,t:1527876984019};\\\", \\\"{x:486,y:725,t:1527876984039};\\\", \\\"{x:486,y:726,t:1527876984053};\\\", \\\"{x:487,y:727,t:1527876984070};\\\", \\\"{x:490,y:729,t:1527876984085};\\\", \\\"{x:495,y:730,t:1527876984102};\\\", \\\"{x:497,y:732,t:1527876984119};\\\", \\\"{x:499,y:732,t:1527876984136};\\\", \\\"{x:500,y:732,t:1527876984447};\\\", \\\"{x:501,y:734,t:1527876984478};\\\", \\\"{x:501,y:735,t:1527876984495};\\\", \\\"{x:501,y:736,t:1527876984527};\\\", \\\"{x:502,y:736,t:1527876984902};\\\", \\\"{x:504,y:736,t:1527876985039};\\\", \\\"{x:504,y:735,t:1527876985104};\\\", \\\"{x:507,y:735,t:1527876985119};\\\", \\\"{x:515,y:735,t:1527876985136};\\\", \\\"{x:528,y:734,t:1527876985152};\\\", \\\"{x:543,y:733,t:1527876985170};\\\", \\\"{x:567,y:733,t:1527876985186};\\\", \\\"{x:600,y:733,t:1527876985203};\\\", \\\"{x:618,y:733,t:1527876985219};\\\", \\\"{x:646,y:733,t:1527876985235};\\\", \\\"{x:673,y:733,t:1527876985253};\\\", \\\"{x:698,y:731,t:1527876985277};\\\", \\\"{x:715,y:730,t:1527876985285};\\\", \\\"{x:723,y:730,t:1527876985302};\\\", \\\"{x:724,y:730,t:1527876985319};\\\" ] }, { \\\"rt\\\": 9891, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 600971, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:727,y:730,t:1527876986190};\\\", \\\"{x:730,y:731,t:1527876986204};\\\", \\\"{x:746,y:737,t:1527876986220};\\\", \\\"{x:765,y:743,t:1527876986237};\\\", \\\"{x:773,y:746,t:1527876986253};\\\", \\\"{x:787,y:750,t:1527876986270};\\\", \\\"{x:793,y:751,t:1527876986807};\\\", \\\"{x:801,y:751,t:1527876986821};\\\", \\\"{x:822,y:752,t:1527876986838};\\\", \\\"{x:874,y:756,t:1527876986854};\\\", \\\"{x:928,y:757,t:1527876986871};\\\", \\\"{x:984,y:758,t:1527876986888};\\\", \\\"{x:1030,y:758,t:1527876986905};\\\", \\\"{x:1066,y:758,t:1527876986921};\\\", \\\"{x:1103,y:753,t:1527876986938};\\\", \\\"{x:1130,y:753,t:1527876986955};\\\", \\\"{x:1149,y:753,t:1527876986972};\\\", \\\"{x:1157,y:752,t:1527876986988};\\\", \\\"{x:1171,y:749,t:1527876987005};\\\", \\\"{x:1192,y:746,t:1527876987022};\\\", \\\"{x:1193,y:745,t:1527876987039};\\\", \\\"{x:1196,y:743,t:1527876987054};\\\", \\\"{x:1203,y:742,t:1527876987072};\\\", \\\"{x:1218,y:742,t:1527876987088};\\\", \\\"{x:1228,y:741,t:1527876987105};\\\", \\\"{x:1243,y:741,t:1527876987121};\\\", \\\"{x:1255,y:741,t:1527876987138};\\\", \\\"{x:1265,y:741,t:1527876987155};\\\", \\\"{x:1274,y:740,t:1527876987171};\\\", \\\"{x:1279,y:740,t:1527876987189};\\\", \\\"{x:1281,y:739,t:1527876987205};\\\", \\\"{x:1282,y:738,t:1527876987280};\\\", \\\"{x:1283,y:737,t:1527876987288};\\\", \\\"{x:1285,y:737,t:1527876987305};\\\", \\\"{x:1287,y:737,t:1527876987327};\\\", \\\"{x:1288,y:736,t:1527876987343};\\\", \\\"{x:1290,y:734,t:1527876987383};\\\", \\\"{x:1291,y:734,t:1527876987399};\\\", \\\"{x:1294,y:734,t:1527876987407};\\\", \\\"{x:1295,y:734,t:1527876987422};\\\", \\\"{x:1298,y:733,t:1527876987438};\\\", \\\"{x:1299,y:733,t:1527876987528};\\\", \\\"{x:1299,y:732,t:1527876987543};\\\", \\\"{x:1301,y:731,t:1527876987555};\\\", \\\"{x:1302,y:731,t:1527876987571};\\\", \\\"{x:1303,y:731,t:1527876987589};\\\", \\\"{x:1307,y:730,t:1527876987605};\\\", \\\"{x:1308,y:728,t:1527876987622};\\\", \\\"{x:1309,y:728,t:1527876987639};\\\", \\\"{x:1310,y:728,t:1527876987655};\\\", \\\"{x:1312,y:727,t:1527876987679};\\\", \\\"{x:1313,y:727,t:1527876987702};\\\", \\\"{x:1314,y:727,t:1527876987711};\\\", \\\"{x:1315,y:726,t:1527876988072};\\\", \\\"{x:1318,y:725,t:1527876988089};\\\", \\\"{x:1321,y:723,t:1527876988106};\\\", \\\"{x:1323,y:721,t:1527876988126};\\\", \\\"{x:1324,y:720,t:1527876988139};\\\", \\\"{x:1325,y:719,t:1527876988156};\\\", \\\"{x:1326,y:718,t:1527876988231};\\\", \\\"{x:1327,y:717,t:1527876988247};\\\", \\\"{x:1327,y:716,t:1527876988263};\\\", \\\"{x:1329,y:714,t:1527876988280};\\\", \\\"{x:1330,y:714,t:1527876988295};\\\", \\\"{x:1330,y:713,t:1527876988306};\\\", \\\"{x:1331,y:711,t:1527876988335};\\\", \\\"{x:1332,y:711,t:1527876988342};\\\", \\\"{x:1332,y:710,t:1527876988356};\\\", \\\"{x:1332,y:708,t:1527876988373};\\\", \\\"{x:1334,y:706,t:1527876988389};\\\", \\\"{x:1334,y:705,t:1527876988406};\\\", \\\"{x:1334,y:701,t:1527876988422};\\\", \\\"{x:1334,y:698,t:1527876988439};\\\", \\\"{x:1334,y:697,t:1527876988495};\\\", \\\"{x:1334,y:696,t:1527876988506};\\\", \\\"{x:1335,y:696,t:1527876988523};\\\", \\\"{x:1335,y:695,t:1527876988540};\\\", \\\"{x:1336,y:695,t:1527876988556};\\\", \\\"{x:1337,y:694,t:1527876988573};\\\", \\\"{x:1338,y:694,t:1527876988599};\\\", \\\"{x:1341,y:694,t:1527876988639};\\\", \\\"{x:1343,y:694,t:1527876988659};\\\", \\\"{x:1345,y:694,t:1527876988688};\\\", \\\"{x:1346,y:694,t:1527876988705};\\\", \\\"{x:1347,y:694,t:1527876988723};\\\", \\\"{x:1348,y:694,t:1527876988798};\\\", \\\"{x:1349,y:694,t:1527876989015};\\\", \\\"{x:1350,y:694,t:1527876989167};\\\", \\\"{x:1351,y:694,t:1527876989447};\\\", \\\"{x:1353,y:696,t:1527876989711};\\\", \\\"{x:1353,y:697,t:1527876989726};\\\", \\\"{x:1354,y:697,t:1527876989768};\\\", \\\"{x:1354,y:698,t:1527876989798};\\\", \\\"{x:1355,y:699,t:1527876989903};\\\", \\\"{x:1356,y:699,t:1527876989918};\\\", \\\"{x:1356,y:700,t:1527876989927};\\\", \\\"{x:1357,y:701,t:1527876989975};\\\", \\\"{x:1359,y:702,t:1527876989991};\\\", \\\"{x:1359,y:704,t:1527876990103};\\\", \\\"{x:1359,y:705,t:1527876990110};\\\", \\\"{x:1360,y:707,t:1527876990124};\\\", \\\"{x:1360,y:708,t:1527876990140};\\\", \\\"{x:1361,y:710,t:1527876990157};\\\", \\\"{x:1361,y:712,t:1527876990174};\\\", \\\"{x:1361,y:715,t:1527876990191};\\\", \\\"{x:1361,y:717,t:1527876990207};\\\", \\\"{x:1361,y:718,t:1527876990230};\\\", \\\"{x:1361,y:719,t:1527876990240};\\\", \\\"{x:1361,y:721,t:1527876990257};\\\", \\\"{x:1361,y:722,t:1527876990274};\\\", \\\"{x:1361,y:724,t:1527876990290};\\\", \\\"{x:1361,y:726,t:1527876990306};\\\", \\\"{x:1361,y:728,t:1527876990323};\\\", \\\"{x:1360,y:731,t:1527876990340};\\\", \\\"{x:1360,y:734,t:1527876990356};\\\", \\\"{x:1359,y:736,t:1527876990373};\\\", \\\"{x:1358,y:738,t:1527876990390};\\\", \\\"{x:1358,y:740,t:1527876990407};\\\", \\\"{x:1358,y:741,t:1527876990424};\\\", \\\"{x:1358,y:742,t:1527876990440};\\\", \\\"{x:1357,y:744,t:1527876990457};\\\", \\\"{x:1356,y:745,t:1527876990474};\\\", \\\"{x:1356,y:749,t:1527876990491};\\\", \\\"{x:1355,y:752,t:1527876990507};\\\", \\\"{x:1355,y:754,t:1527876990524};\\\", \\\"{x:1354,y:755,t:1527876990541};\\\", \\\"{x:1354,y:757,t:1527876990566};\\\", \\\"{x:1354,y:758,t:1527876990631};\\\", \\\"{x:1354,y:760,t:1527876990647};\\\", \\\"{x:1354,y:761,t:1527876990663};\\\", \\\"{x:1353,y:762,t:1527876990675};\\\", \\\"{x:1353,y:763,t:1527876990691};\\\", \\\"{x:1353,y:764,t:1527876990719};\\\", \\\"{x:1353,y:765,t:1527876990775};\\\", \\\"{x:1353,y:766,t:1527876991465};\\\", \\\"{x:1353,y:767,t:1527876991495};\\\", \\\"{x:1353,y:768,t:1527876991535};\\\", \\\"{x:1353,y:769,t:1527876991551};\\\", \\\"{x:1352,y:769,t:1527876991559};\\\", \\\"{x:1347,y:769,t:1527876992438};\\\", \\\"{x:1334,y:768,t:1527876992446};\\\", \\\"{x:1323,y:767,t:1527876992458};\\\", \\\"{x:1280,y:757,t:1527876992474};\\\", \\\"{x:1215,y:736,t:1527876992492};\\\", \\\"{x:1117,y:715,t:1527876992509};\\\", \\\"{x:1093,y:709,t:1527876992525};\\\", \\\"{x:988,y:684,t:1527876992541};\\\", \\\"{x:914,y:666,t:1527876992558};\\\", \\\"{x:869,y:653,t:1527876992576};\\\", \\\"{x:851,y:645,t:1527876992592};\\\", \\\"{x:837,y:638,t:1527876992609};\\\", \\\"{x:825,y:635,t:1527876992626};\\\", \\\"{x:820,y:632,t:1527876992642};\\\", \\\"{x:818,y:631,t:1527876992661};\\\", \\\"{x:813,y:628,t:1527876992675};\\\", \\\"{x:809,y:625,t:1527876992691};\\\", \\\"{x:796,y:618,t:1527876992709};\\\", \\\"{x:766,y:603,t:1527876992725};\\\", \\\"{x:743,y:597,t:1527876992743};\\\", \\\"{x:713,y:590,t:1527876992760};\\\", \\\"{x:695,y:581,t:1527876992775};\\\", \\\"{x:682,y:572,t:1527876992792};\\\", \\\"{x:665,y:568,t:1527876992809};\\\", \\\"{x:656,y:563,t:1527876992825};\\\", \\\"{x:654,y:563,t:1527876992843};\\\", \\\"{x:654,y:562,t:1527876992887};\\\", \\\"{x:656,y:561,t:1527876992893};\\\", \\\"{x:662,y:561,t:1527876992910};\\\", \\\"{x:670,y:561,t:1527876992925};\\\", \\\"{x:705,y:564,t:1527876992943};\\\", \\\"{x:746,y:567,t:1527876992960};\\\", \\\"{x:787,y:577,t:1527876992975};\\\", \\\"{x:810,y:578,t:1527876992992};\\\", \\\"{x:827,y:578,t:1527876993010};\\\", \\\"{x:839,y:578,t:1527876993026};\\\", \\\"{x:841,y:578,t:1527876993042};\\\", \\\"{x:837,y:578,t:1527876993070};\\\", \\\"{x:824,y:578,t:1527876993078};\\\", \\\"{x:802,y:575,t:1527876993093};\\\", \\\"{x:708,y:560,t:1527876993112};\\\", \\\"{x:593,y:550,t:1527876993126};\\\", \\\"{x:488,y:540,t:1527876993142};\\\", \\\"{x:409,y:536,t:1527876993160};\\\", \\\"{x:387,y:533,t:1527876993175};\\\", \\\"{x:368,y:533,t:1527876993193};\\\", \\\"{x:359,y:535,t:1527876993210};\\\", \\\"{x:357,y:535,t:1527876993227};\\\", \\\"{x:352,y:538,t:1527876993243};\\\", \\\"{x:345,y:544,t:1527876993260};\\\", \\\"{x:338,y:548,t:1527876993276};\\\", \\\"{x:329,y:554,t:1527876993294};\\\", \\\"{x:326,y:554,t:1527876993310};\\\", \\\"{x:313,y:556,t:1527876993327};\\\", \\\"{x:298,y:556,t:1527876993344};\\\", \\\"{x:278,y:556,t:1527876993359};\\\", \\\"{x:263,y:556,t:1527876993376};\\\", \\\"{x:248,y:556,t:1527876993392};\\\", \\\"{x:231,y:556,t:1527876993410};\\\", \\\"{x:211,y:551,t:1527876993428};\\\", \\\"{x:199,y:549,t:1527876993442};\\\", \\\"{x:192,y:548,t:1527876993460};\\\", \\\"{x:188,y:546,t:1527876993477};\\\", \\\"{x:184,y:543,t:1527876993494};\\\", \\\"{x:181,y:543,t:1527876993518};\\\", \\\"{x:180,y:543,t:1527876993549};\\\", \\\"{x:180,y:542,t:1527876993560};\\\", \\\"{x:179,y:542,t:1527876993576};\\\", \\\"{x:179,y:541,t:1527876993766};\\\", \\\"{x:181,y:540,t:1527876993777};\\\", \\\"{x:184,y:540,t:1527876993794};\\\", \\\"{x:189,y:540,t:1527876993810};\\\", \\\"{x:193,y:540,t:1527876993827};\\\", \\\"{x:202,y:552,t:1527876993847};\\\", \\\"{x:229,y:566,t:1527876993864};\\\", \\\"{x:293,y:593,t:1527876993880};\\\", \\\"{x:340,y:624,t:1527876993898};\\\", \\\"{x:381,y:648,t:1527876993913};\\\", \\\"{x:419,y:669,t:1527876993930};\\\", \\\"{x:438,y:682,t:1527876993947};\\\", \\\"{x:457,y:693,t:1527876993964};\\\", \\\"{x:467,y:702,t:1527876993980};\\\", \\\"{x:475,y:709,t:1527876993997};\\\", \\\"{x:478,y:713,t:1527876994014};\\\", \\\"{x:481,y:715,t:1527876994030};\\\", \\\"{x:482,y:717,t:1527876994047};\\\", \\\"{x:483,y:717,t:1527876994064};\\\", \\\"{x:485,y:719,t:1527876994218};\\\", \\\"{x:489,y:720,t:1527876994232};\\\", \\\"{x:491,y:723,t:1527876994247};\\\", \\\"{x:495,y:726,t:1527876994265};\\\", \\\"{x:496,y:726,t:1527876994280};\\\", \\\"{x:499,y:728,t:1527876994297};\\\", \\\"{x:501,y:728,t:1527876994314};\\\", \\\"{x:502,y:729,t:1527876994330};\\\", \\\"{x:503,y:729,t:1527876994362};\\\", \\\"{x:504,y:729,t:1527876994634};\\\", \\\"{x:506,y:729,t:1527876995818};\\\", \\\"{x:507,y:729,t:1527876995831};\\\", \\\"{x:511,y:729,t:1527876995848};\\\", \\\"{x:515,y:726,t:1527876995866};\\\", \\\"{x:518,y:725,t:1527876995882};\\\", \\\"{x:521,y:724,t:1527876995898};\\\", \\\"{x:528,y:724,t:1527876995915};\\\", \\\"{x:529,y:724,t:1527876995932};\\\", \\\"{x:538,y:724,t:1527876995949};\\\", \\\"{x:548,y:724,t:1527876995965};\\\", \\\"{x:554,y:724,t:1527876995983};\\\", \\\"{x:558,y:724,t:1527876995998};\\\", \\\"{x:560,y:724,t:1527876996015};\\\", \\\"{x:561,y:724,t:1527876996106};\\\", \\\"{x:564,y:724,t:1527876996122};\\\", \\\"{x:565,y:724,t:1527876996154};\\\", \\\"{x:565,y:723,t:1527876996165};\\\", \\\"{x:567,y:723,t:1527876996183};\\\", \\\"{x:569,y:723,t:1527876996198};\\\", \\\"{x:571,y:721,t:1527876996215};\\\", \\\"{x:572,y:720,t:1527876996232};\\\", \\\"{x:574,y:720,t:1527876996248};\\\", \\\"{x:576,y:719,t:1527876996265};\\\", \\\"{x:578,y:718,t:1527876996282};\\\", \\\"{x:578,y:716,t:1527876996298};\\\", \\\"{x:579,y:714,t:1527876996316};\\\", \\\"{x:581,y:712,t:1527876996345};\\\", \\\"{x:581,y:711,t:1527876996354};\\\", \\\"{x:581,y:709,t:1527876996370};\\\", \\\"{x:581,y:707,t:1527876996382};\\\", \\\"{x:578,y:701,t:1527876996398};\\\", \\\"{x:574,y:698,t:1527876996415};\\\", \\\"{x:573,y:697,t:1527876996432};\\\" ] }, { \\\"rt\\\": 36752, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 638966, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z -X -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:573,y:696,t:1527876996737};\\\", \\\"{x:573,y:695,t:1527876996761};\\\", \\\"{x:573,y:694,t:1527876996785};\\\", \\\"{x:575,y:693,t:1527876996799};\\\", \\\"{x:576,y:692,t:1527876996817};\\\", \\\"{x:577,y:692,t:1527876996833};\\\", \\\"{x:579,y:692,t:1527876997434};\\\", \\\"{x:588,y:692,t:1527876997449};\\\", \\\"{x:603,y:692,t:1527876997466};\\\", \\\"{x:618,y:694,t:1527876997483};\\\", \\\"{x:633,y:694,t:1527876997499};\\\", \\\"{x:650,y:698,t:1527876997516};\\\", \\\"{x:673,y:703,t:1527876997533};\\\", \\\"{x:702,y:709,t:1527876997549};\\\", \\\"{x:722,y:712,t:1527876997566};\\\", \\\"{x:748,y:716,t:1527876997583};\\\", \\\"{x:770,y:717,t:1527876997600};\\\", \\\"{x:793,y:717,t:1527876997617};\\\", \\\"{x:816,y:721,t:1527876997634};\\\", \\\"{x:831,y:722,t:1527876997650};\\\", \\\"{x:839,y:725,t:1527876997667};\\\", \\\"{x:842,y:726,t:1527876997684};\\\", \\\"{x:844,y:728,t:1527876997700};\\\", \\\"{x:844,y:729,t:1527876998258};\\\", \\\"{x:850,y:730,t:1527876998329};\\\", \\\"{x:851,y:731,t:1527876998337};\\\", \\\"{x:853,y:732,t:1527876998350};\\\", \\\"{x:854,y:733,t:1527876998367};\\\", \\\"{x:855,y:733,t:1527876998383};\\\", \\\"{x:855,y:734,t:1527876998609};\\\", \\\"{x:859,y:735,t:1527876998617};\\\", \\\"{x:873,y:738,t:1527876998634};\\\", \\\"{x:897,y:741,t:1527876998650};\\\", \\\"{x:911,y:747,t:1527876998667};\\\", \\\"{x:938,y:751,t:1527876998684};\\\", \\\"{x:974,y:760,t:1527876998700};\\\", \\\"{x:1000,y:773,t:1527876998717};\\\", \\\"{x:1049,y:788,t:1527876998735};\\\", \\\"{x:1114,y:813,t:1527876998750};\\\", \\\"{x:1165,y:835,t:1527876998767};\\\", \\\"{x:1209,y:853,t:1527876998785};\\\", \\\"{x:1244,y:865,t:1527876998800};\\\", \\\"{x:1270,y:878,t:1527876998818};\\\", \\\"{x:1287,y:889,t:1527876998834};\\\", \\\"{x:1298,y:892,t:1527876998850};\\\", \\\"{x:1301,y:893,t:1527876998868};\\\", \\\"{x:1303,y:894,t:1527876999297};\\\", \\\"{x:1304,y:894,t:1527876999498};\\\", \\\"{x:1306,y:894,t:1527877000282};\\\", \\\"{x:1309,y:893,t:1527877000297};\\\", \\\"{x:1310,y:893,t:1527877000306};\\\", \\\"{x:1311,y:893,t:1527877000318};\\\", \\\"{x:1311,y:892,t:1527877000336};\\\", \\\"{x:1311,y:891,t:1527877000352};\\\", \\\"{x:1314,y:889,t:1527877000369};\\\", \\\"{x:1318,y:886,t:1527877000386};\\\", \\\"{x:1324,y:884,t:1527877000402};\\\", \\\"{x:1330,y:880,t:1527877000419};\\\", \\\"{x:1338,y:874,t:1527877000436};\\\", \\\"{x:1348,y:866,t:1527877000453};\\\", \\\"{x:1360,y:859,t:1527877000469};\\\", \\\"{x:1366,y:854,t:1527877000486};\\\", \\\"{x:1373,y:846,t:1527877000503};\\\", \\\"{x:1378,y:838,t:1527877000519};\\\", \\\"{x:1384,y:833,t:1527877000535};\\\", \\\"{x:1386,y:828,t:1527877000553};\\\", \\\"{x:1389,y:824,t:1527877000569};\\\", \\\"{x:1392,y:819,t:1527877000585};\\\", \\\"{x:1393,y:818,t:1527877000602};\\\", \\\"{x:1393,y:817,t:1527877000626};\\\", \\\"{x:1393,y:816,t:1527877001522};\\\", \\\"{x:1394,y:814,t:1527877001538};\\\", \\\"{x:1395,y:814,t:1527877001553};\\\", \\\"{x:1399,y:811,t:1527877001570};\\\", \\\"{x:1404,y:808,t:1527877001586};\\\", \\\"{x:1409,y:806,t:1527877001603};\\\", \\\"{x:1416,y:802,t:1527877001620};\\\", \\\"{x:1423,y:799,t:1527877001637};\\\", \\\"{x:1425,y:799,t:1527877001653};\\\", \\\"{x:1430,y:798,t:1527877001671};\\\", \\\"{x:1434,y:798,t:1527877001687};\\\", \\\"{x:1437,y:799,t:1527877001703};\\\", \\\"{x:1441,y:801,t:1527877001720};\\\", \\\"{x:1447,y:805,t:1527877001737};\\\", \\\"{x:1453,y:808,t:1527877001753};\\\", \\\"{x:1462,y:813,t:1527877001770};\\\", \\\"{x:1466,y:816,t:1527877001787};\\\", \\\"{x:1470,y:820,t:1527877001803};\\\", \\\"{x:1473,y:825,t:1527877001819};\\\", \\\"{x:1476,y:829,t:1527877001836};\\\", \\\"{x:1476,y:833,t:1527877001853};\\\", \\\"{x:1479,y:839,t:1527877001869};\\\", \\\"{x:1480,y:843,t:1527877001886};\\\", \\\"{x:1480,y:851,t:1527877001903};\\\", \\\"{x:1482,y:857,t:1527877001920};\\\", \\\"{x:1481,y:867,t:1527877001936};\\\", \\\"{x:1480,y:879,t:1527877001953};\\\", \\\"{x:1478,y:884,t:1527877001970};\\\", \\\"{x:1478,y:886,t:1527877001987};\\\", \\\"{x:1473,y:891,t:1527877002003};\\\", \\\"{x:1471,y:893,t:1527877002019};\\\", \\\"{x:1470,y:894,t:1527877002107};\\\", \\\"{x:1469,y:895,t:1527877002122};\\\", \\\"{x:1472,y:894,t:1527877002314};\\\", \\\"{x:1474,y:891,t:1527877002322};\\\", \\\"{x:1476,y:889,t:1527877002337};\\\", \\\"{x:1490,y:880,t:1527877002353};\\\", \\\"{x:1496,y:871,t:1527877002371};\\\", \\\"{x:1507,y:861,t:1527877002387};\\\", \\\"{x:1513,y:855,t:1527877002403};\\\", \\\"{x:1518,y:848,t:1527877002421};\\\", \\\"{x:1522,y:837,t:1527877002436};\\\", \\\"{x:1526,y:828,t:1527877002453};\\\", \\\"{x:1529,y:819,t:1527877002470};\\\", \\\"{x:1533,y:814,t:1527877002486};\\\", \\\"{x:1537,y:810,t:1527877002503};\\\", \\\"{x:1538,y:809,t:1527877002521};\\\", \\\"{x:1539,y:808,t:1527877002537};\\\", \\\"{x:1541,y:807,t:1527877002554};\\\", \\\"{x:1544,y:805,t:1527877002570};\\\", \\\"{x:1546,y:803,t:1527877002586};\\\", \\\"{x:1550,y:800,t:1527877002604};\\\", \\\"{x:1556,y:796,t:1527877002621};\\\", \\\"{x:1563,y:791,t:1527877002637};\\\", \\\"{x:1572,y:784,t:1527877002653};\\\", \\\"{x:1578,y:777,t:1527877002670};\\\", \\\"{x:1583,y:768,t:1527877002687};\\\", \\\"{x:1586,y:755,t:1527877002704};\\\", \\\"{x:1591,y:742,t:1527877002721};\\\", \\\"{x:1596,y:736,t:1527877002737};\\\", \\\"{x:1598,y:734,t:1527877002754};\\\", \\\"{x:1598,y:733,t:1527877002777};\\\", \\\"{x:1598,y:730,t:1527877002787};\\\", \\\"{x:1598,y:729,t:1527877002804};\\\", \\\"{x:1598,y:726,t:1527877002821};\\\", \\\"{x:1598,y:724,t:1527877002838};\\\", \\\"{x:1598,y:723,t:1527877002854};\\\", \\\"{x:1598,y:721,t:1527877002871};\\\", \\\"{x:1598,y:720,t:1527877002889};\\\", \\\"{x:1598,y:718,t:1527877002930};\\\", \\\"{x:1598,y:716,t:1527877002962};\\\", \\\"{x:1598,y:715,t:1527877002971};\\\", \\\"{x:1598,y:714,t:1527877002987};\\\", \\\"{x:1598,y:713,t:1527877003010};\\\", \\\"{x:1597,y:713,t:1527877003026};\\\", \\\"{x:1598,y:713,t:1527877003817};\\\", \\\"{x:1600,y:712,t:1527877003841};\\\", \\\"{x:1601,y:712,t:1527877003874};\\\", \\\"{x:1603,y:711,t:1527877003897};\\\", \\\"{x:1603,y:710,t:1527877003906};\\\", \\\"{x:1605,y:707,t:1527877003921};\\\", \\\"{x:1607,y:702,t:1527877003937};\\\", \\\"{x:1607,y:701,t:1527877003955};\\\", \\\"{x:1608,y:699,t:1527877003972};\\\", \\\"{x:1608,y:698,t:1527877003988};\\\", \\\"{x:1609,y:697,t:1527877004011};\\\", \\\"{x:1610,y:697,t:1527877004082};\\\", \\\"{x:1605,y:697,t:1527877023691};\\\", \\\"{x:1597,y:698,t:1527877023702};\\\", \\\"{x:1540,y:701,t:1527877023720};\\\", \\\"{x:1439,y:696,t:1527877023736};\\\", \\\"{x:1353,y:682,t:1527877023753};\\\", \\\"{x:1129,y:656,t:1527877023769};\\\", \\\"{x:982,y:635,t:1527877023787};\\\", \\\"{x:844,y:618,t:1527877023804};\\\", \\\"{x:725,y:603,t:1527877023819};\\\", \\\"{x:658,y:603,t:1527877023836};\\\", \\\"{x:649,y:602,t:1527877023852};\\\", \\\"{x:635,y:601,t:1527877023867};\\\", \\\"{x:629,y:601,t:1527877023885};\\\", \\\"{x:626,y:602,t:1527877023902};\\\", \\\"{x:623,y:604,t:1527877023918};\\\", \\\"{x:620,y:605,t:1527877023935};\\\", \\\"{x:617,y:609,t:1527877023954};\\\", \\\"{x:616,y:609,t:1527877023971};\\\", \\\"{x:615,y:609,t:1527877024001};\\\", \\\"{x:614,y:610,t:1527877024008};\\\", \\\"{x:614,y:611,t:1527877024057};\\\", \\\"{x:616,y:611,t:1527877024178};\\\", \\\"{x:618,y:607,t:1527877024188};\\\", \\\"{x:622,y:602,t:1527877024205};\\\", \\\"{x:627,y:595,t:1527877024221};\\\", \\\"{x:630,y:591,t:1527877024239};\\\", \\\"{x:634,y:585,t:1527877024255};\\\", \\\"{x:635,y:583,t:1527877024271};\\\", \\\"{x:635,y:581,t:1527877024288};\\\", \\\"{x:635,y:580,t:1527877024320};\\\", \\\"{x:635,y:579,t:1527877024338};\\\", \\\"{x:634,y:578,t:1527877024355};\\\", \\\"{x:631,y:576,t:1527877024384};\\\", \\\"{x:638,y:578,t:1527877024729};\\\", \\\"{x:662,y:582,t:1527877024739};\\\", \\\"{x:743,y:595,t:1527877024756};\\\", \\\"{x:824,y:608,t:1527877024772};\\\", \\\"{x:926,y:620,t:1527877024788};\\\", \\\"{x:1026,y:635,t:1527877024805};\\\", \\\"{x:1133,y:658,t:1527877024823};\\\", \\\"{x:1223,y:679,t:1527877024839};\\\", \\\"{x:1293,y:700,t:1527877024855};\\\", \\\"{x:1318,y:713,t:1527877024872};\\\", \\\"{x:1331,y:719,t:1527877024888};\\\", \\\"{x:1333,y:720,t:1527877024905};\\\", \\\"{x:1333,y:721,t:1527877024953};\\\", \\\"{x:1333,y:722,t:1527877024961};\\\", \\\"{x:1333,y:723,t:1527877024973};\\\", \\\"{x:1333,y:724,t:1527877024990};\\\", \\\"{x:1333,y:726,t:1527877025006};\\\", \\\"{x:1333,y:728,t:1527877025023};\\\", \\\"{x:1333,y:732,t:1527877025040};\\\", \\\"{x:1333,y:736,t:1527877025056};\\\", \\\"{x:1338,y:743,t:1527877025073};\\\", \\\"{x:1366,y:755,t:1527877025089};\\\", \\\"{x:1391,y:764,t:1527877025106};\\\", \\\"{x:1407,y:772,t:1527877025122};\\\", \\\"{x:1425,y:777,t:1527877025140};\\\", \\\"{x:1440,y:784,t:1527877025156};\\\", \\\"{x:1454,y:791,t:1527877025173};\\\", \\\"{x:1459,y:794,t:1527877025190};\\\", \\\"{x:1460,y:795,t:1527877025206};\\\", \\\"{x:1461,y:796,t:1527877025222};\\\", \\\"{x:1461,y:797,t:1527877025240};\\\", \\\"{x:1463,y:799,t:1527877025257};\\\", \\\"{x:1465,y:801,t:1527877025290};\\\", \\\"{x:1468,y:804,t:1527877025307};\\\", \\\"{x:1473,y:809,t:1527877025323};\\\", \\\"{x:1482,y:814,t:1527877025339};\\\", \\\"{x:1487,y:816,t:1527877025357};\\\", \\\"{x:1490,y:817,t:1527877025373};\\\", \\\"{x:1491,y:817,t:1527877025389};\\\", \\\"{x:1491,y:818,t:1527877026401};\\\", \\\"{x:1490,y:819,t:1527877026409};\\\", \\\"{x:1488,y:819,t:1527877026425};\\\", \\\"{x:1488,y:820,t:1527877026442};\\\", \\\"{x:1487,y:820,t:1527877026473};\\\", \\\"{x:1486,y:821,t:1527877026482};\\\", \\\"{x:1488,y:820,t:1527877026674};\\\", \\\"{x:1490,y:819,t:1527877026692};\\\", \\\"{x:1495,y:817,t:1527877026709};\\\", \\\"{x:1498,y:814,t:1527877026726};\\\", \\\"{x:1504,y:810,t:1527877026741};\\\", \\\"{x:1508,y:806,t:1527877026759};\\\", \\\"{x:1511,y:803,t:1527877026776};\\\", \\\"{x:1520,y:796,t:1527877026792};\\\", \\\"{x:1528,y:788,t:1527877026809};\\\", \\\"{x:1540,y:765,t:1527877026825};\\\", \\\"{x:1544,y:756,t:1527877026842};\\\", \\\"{x:1550,y:748,t:1527877026859};\\\", \\\"{x:1554,y:741,t:1527877026876};\\\", \\\"{x:1558,y:734,t:1527877026892};\\\", \\\"{x:1563,y:727,t:1527877026909};\\\", \\\"{x:1565,y:724,t:1527877026926};\\\", \\\"{x:1568,y:719,t:1527877026942};\\\", \\\"{x:1568,y:718,t:1527877026959};\\\", \\\"{x:1571,y:715,t:1527877026976};\\\", \\\"{x:1575,y:713,t:1527877026992};\\\", \\\"{x:1579,y:710,t:1527877027009};\\\", \\\"{x:1582,y:707,t:1527877027025};\\\", \\\"{x:1584,y:707,t:1527877027042};\\\", \\\"{x:1586,y:706,t:1527877027059};\\\", \\\"{x:1588,y:704,t:1527877027076};\\\", \\\"{x:1590,y:703,t:1527877027093};\\\", \\\"{x:1592,y:702,t:1527877027109};\\\", \\\"{x:1593,y:701,t:1527877027126};\\\", \\\"{x:1594,y:701,t:1527877027177};\\\", \\\"{x:1595,y:700,t:1527877027193};\\\", \\\"{x:1596,y:700,t:1527877027282};\\\", \\\"{x:1597,y:700,t:1527877027297};\\\", \\\"{x:1598,y:700,t:1527877027310};\\\", \\\"{x:1600,y:700,t:1527877027326};\\\", \\\"{x:1602,y:701,t:1527877027345};\\\", \\\"{x:1603,y:701,t:1527877027369};\\\", \\\"{x:1604,y:701,t:1527877027498};\\\", \\\"{x:1607,y:701,t:1527877027513};\\\", \\\"{x:1609,y:701,t:1527877027529};\\\", \\\"{x:1610,y:701,t:1527877027543};\\\", \\\"{x:1611,y:700,t:1527877027560};\\\", \\\"{x:1613,y:700,t:1527877027577};\\\", \\\"{x:1614,y:700,t:1527877027889};\\\", \\\"{x:1615,y:700,t:1527877027897};\\\", \\\"{x:1616,y:700,t:1527877027970};\\\", \\\"{x:1616,y:699,t:1527877031146};\\\", \\\"{x:1613,y:699,t:1527877031185};\\\", \\\"{x:1608,y:701,t:1527877031200};\\\", \\\"{x:1590,y:708,t:1527877031215};\\\", \\\"{x:1560,y:714,t:1527877031231};\\\", \\\"{x:1472,y:724,t:1527877031248};\\\", \\\"{x:1358,y:727,t:1527877031264};\\\", \\\"{x:1235,y:726,t:1527877031281};\\\", \\\"{x:1113,y:724,t:1527877031298};\\\", \\\"{x:994,y:724,t:1527877031315};\\\", \\\"{x:864,y:722,t:1527877031331};\\\", \\\"{x:755,y:716,t:1527877031349};\\\", \\\"{x:655,y:705,t:1527877031365};\\\", \\\"{x:626,y:699,t:1527877031381};\\\", \\\"{x:611,y:695,t:1527877031399};\\\", \\\"{x:603,y:692,t:1527877031415};\\\", \\\"{x:602,y:690,t:1527877031432};\\\", \\\"{x:602,y:688,t:1527877031481};\\\", \\\"{x:601,y:683,t:1527877031489};\\\", \\\"{x:599,y:679,t:1527877031499};\\\", \\\"{x:592,y:668,t:1527877031515};\\\", \\\"{x:588,y:660,t:1527877031533};\\\", \\\"{x:586,y:658,t:1527877031548};\\\", \\\"{x:585,y:654,t:1527877031566};\\\", \\\"{x:585,y:648,t:1527877031583};\\\", \\\"{x:585,y:641,t:1527877031599};\\\", \\\"{x:585,y:632,t:1527877031616};\\\", \\\"{x:585,y:620,t:1527877031634};\\\", \\\"{x:586,y:613,t:1527877031650};\\\", \\\"{x:586,y:611,t:1527877031666};\\\", \\\"{x:586,y:609,t:1527877031677};\\\", \\\"{x:588,y:607,t:1527877031694};\\\", \\\"{x:589,y:607,t:1527877031710};\\\", \\\"{x:590,y:603,t:1527877031727};\\\", \\\"{x:592,y:595,t:1527877031744};\\\", \\\"{x:593,y:590,t:1527877031760};\\\", \\\"{x:595,y:583,t:1527877031777};\\\", \\\"{x:595,y:577,t:1527877031794};\\\", \\\"{x:597,y:569,t:1527877031810};\\\", \\\"{x:598,y:559,t:1527877031828};\\\", \\\"{x:599,y:552,t:1527877031844};\\\", \\\"{x:600,y:545,t:1527877031861};\\\", \\\"{x:602,y:536,t:1527877031877};\\\", \\\"{x:608,y:525,t:1527877031895};\\\", \\\"{x:608,y:523,t:1527877031912};\\\", \\\"{x:609,y:522,t:1527877031927};\\\", \\\"{x:609,y:521,t:1527877031969};\\\", \\\"{x:611,y:519,t:1527877031993};\\\", \\\"{x:612,y:519,t:1527877032001};\\\", \\\"{x:615,y:519,t:1527877032011};\\\", \\\"{x:629,y:519,t:1527877032027};\\\", \\\"{x:645,y:519,t:1527877032045};\\\", \\\"{x:671,y:519,t:1527877032062};\\\", \\\"{x:695,y:519,t:1527877032077};\\\", \\\"{x:726,y:519,t:1527877032095};\\\", \\\"{x:752,y:518,t:1527877032112};\\\", \\\"{x:769,y:518,t:1527877032128};\\\", \\\"{x:777,y:518,t:1527877032145};\\\", \\\"{x:779,y:518,t:1527877032162};\\\", \\\"{x:780,y:518,t:1527877032226};\\\", \\\"{x:782,y:518,t:1527877032234};\\\", \\\"{x:783,y:518,t:1527877032249};\\\", \\\"{x:785,y:518,t:1527877032262};\\\", \\\"{x:787,y:516,t:1527877032280};\\\", \\\"{x:787,y:515,t:1527877032295};\\\", \\\"{x:789,y:513,t:1527877032313};\\\", \\\"{x:792,y:512,t:1527877032329};\\\", \\\"{x:794,y:509,t:1527877032345};\\\", \\\"{x:798,y:507,t:1527877032361};\\\", \\\"{x:805,y:504,t:1527877032378};\\\", \\\"{x:811,y:503,t:1527877032395};\\\", \\\"{x:820,y:500,t:1527877032412};\\\", \\\"{x:823,y:498,t:1527877032429};\\\", \\\"{x:826,y:495,t:1527877032444};\\\", \\\"{x:827,y:493,t:1527877032462};\\\", \\\"{x:828,y:493,t:1527877032478};\\\", \\\"{x:828,y:496,t:1527877032760};\\\", \\\"{x:827,y:500,t:1527877032768};\\\", \\\"{x:827,y:506,t:1527877032778};\\\", \\\"{x:823,y:515,t:1527877032796};\\\", \\\"{x:814,y:533,t:1527877032813};\\\", \\\"{x:805,y:550,t:1527877032829};\\\", \\\"{x:790,y:569,t:1527877032847};\\\", \\\"{x:769,y:597,t:1527877032862};\\\", \\\"{x:733,y:628,t:1527877032879};\\\", \\\"{x:696,y:656,t:1527877032895};\\\", \\\"{x:670,y:678,t:1527877032911};\\\", \\\"{x:621,y:709,t:1527877032929};\\\", \\\"{x:599,y:719,t:1527877032945};\\\", \\\"{x:587,y:722,t:1527877032962};\\\", \\\"{x:581,y:722,t:1527877032978};\\\", \\\"{x:579,y:724,t:1527877032994};\\\", \\\"{x:578,y:724,t:1527877033033};\\\", \\\"{x:578,y:725,t:1527877033045};\\\", \\\"{x:574,y:728,t:1527877033062};\\\", \\\"{x:570,y:732,t:1527877033079};\\\", \\\"{x:568,y:735,t:1527877033094};\\\", \\\"{x:568,y:736,t:1527877033112};\\\", \\\"{x:566,y:736,t:1527877033153};\\\", \\\"{x:564,y:736,t:1527877033162};\\\", \\\"{x:562,y:736,t:1527877033177};\\\", \\\"{x:560,y:738,t:1527877033196};\\\", \\\"{x:558,y:738,t:1527877033212};\\\", \\\"{x:557,y:739,t:1527877033228};\\\", \\\"{x:555,y:739,t:1527877033245};\\\", \\\"{x:554,y:740,t:1527877033392};\\\", \\\"{x:558,y:740,t:1527877033609};\\\", \\\"{x:569,y:745,t:1527877033617};\\\", \\\"{x:592,y:757,t:1527877033629};\\\", \\\"{x:635,y:773,t:1527877033646};\\\", \\\"{x:714,y:797,t:1527877033663};\\\", \\\"{x:766,y:810,t:1527877033679};\\\", \\\"{x:813,y:822,t:1527877033696};\\\", \\\"{x:855,y:837,t:1527877033713};\\\", \\\"{x:875,y:841,t:1527877033729};\\\", \\\"{x:888,y:846,t:1527877033745};\\\", \\\"{x:893,y:846,t:1527877033762};\\\", \\\"{x:895,y:846,t:1527877033780};\\\", \\\"{x:898,y:844,t:1527877033825};\\\", \\\"{x:901,y:838,t:1527877033833};\\\", \\\"{x:905,y:836,t:1527877033846};\\\", \\\"{x:905,y:832,t:1527877033863};\\\" ] }, { \\\"rt\\\": 51386, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 691765, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:974,y:785,t:1527877034788};\\\", \\\"{x:974,y:784,t:1527877035152};\\\", \\\"{x:971,y:784,t:1527877035164};\\\", \\\"{x:970,y:785,t:1527877035181};\\\", \\\"{x:968,y:785,t:1527877035197};\\\", \\\"{x:966,y:785,t:1527877035213};\\\", \\\"{x:961,y:786,t:1527877035230};\\\", \\\"{x:957,y:788,t:1527877035246};\\\", \\\"{x:950,y:788,t:1527877035264};\\\", \\\"{x:944,y:788,t:1527877035281};\\\", \\\"{x:934,y:788,t:1527877035297};\\\", \\\"{x:923,y:786,t:1527877035313};\\\", \\\"{x:905,y:783,t:1527877035331};\\\", \\\"{x:884,y:779,t:1527877035346};\\\", \\\"{x:871,y:779,t:1527877035364};\\\", \\\"{x:864,y:779,t:1527877035380};\\\", \\\"{x:863,y:779,t:1527877035396};\\\", \\\"{x:861,y:779,t:1527877035413};\\\", \\\"{x:859,y:780,t:1527877035431};\\\", \\\"{x:857,y:782,t:1527877035447};\\\", \\\"{x:856,y:785,t:1527877035463};\\\", \\\"{x:854,y:790,t:1527877035480};\\\", \\\"{x:853,y:791,t:1527877035561};\\\", \\\"{x:853,y:792,t:1527877035593};\\\", \\\"{x:853,y:793,t:1527877035625};\\\", \\\"{x:855,y:794,t:1527877035641};\\\", \\\"{x:856,y:795,t:1527877035649};\\\", \\\"{x:857,y:795,t:1527877035665};\\\", \\\"{x:859,y:797,t:1527877035682};\\\", \\\"{x:859,y:799,t:1527877035698};\\\", \\\"{x:859,y:800,t:1527877035721};\\\", \\\"{x:860,y:800,t:1527877036809};\\\", \\\"{x:866,y:800,t:1527877036817};\\\", \\\"{x:873,y:800,t:1527877036832};\\\", \\\"{x:892,y:800,t:1527877036848};\\\", \\\"{x:928,y:800,t:1527877036865};\\\", \\\"{x:944,y:800,t:1527877036882};\\\", \\\"{x:965,y:800,t:1527877036898};\\\", \\\"{x:993,y:799,t:1527877036915};\\\", \\\"{x:1012,y:799,t:1527877036932};\\\", \\\"{x:1043,y:799,t:1527877036950};\\\", \\\"{x:1070,y:799,t:1527877036965};\\\", \\\"{x:1100,y:799,t:1527877036983};\\\", \\\"{x:1133,y:803,t:1527877037000};\\\", \\\"{x:1170,y:804,t:1527877037015};\\\", \\\"{x:1223,y:804,t:1527877037032};\\\", \\\"{x:1262,y:804,t:1527877037049};\\\", \\\"{x:1284,y:804,t:1527877037065};\\\", \\\"{x:1295,y:808,t:1527877037082};\\\", \\\"{x:1323,y:808,t:1527877037099};\\\", \\\"{x:1342,y:808,t:1527877037115};\\\", \\\"{x:1346,y:808,t:1527877037132};\\\", \\\"{x:1349,y:808,t:1527877037149};\\\", \\\"{x:1350,y:808,t:1527877037177};\\\", \\\"{x:1344,y:808,t:1527877038097};\\\", \\\"{x:1337,y:804,t:1527877038105};\\\", \\\"{x:1328,y:799,t:1527877038117};\\\", \\\"{x:1307,y:789,t:1527877038133};\\\", \\\"{x:1294,y:784,t:1527877038149};\\\", \\\"{x:1284,y:783,t:1527877038166};\\\", \\\"{x:1273,y:783,t:1527877038183};\\\", \\\"{x:1260,y:782,t:1527877038199};\\\", \\\"{x:1253,y:781,t:1527877038217};\\\", \\\"{x:1248,y:781,t:1527877038234};\\\", \\\"{x:1245,y:781,t:1527877038249};\\\", \\\"{x:1244,y:781,t:1527877038267};\\\", \\\"{x:1241,y:783,t:1527877038284};\\\", \\\"{x:1238,y:784,t:1527877038300};\\\", \\\"{x:1234,y:784,t:1527877038316};\\\", \\\"{x:1230,y:784,t:1527877038333};\\\", \\\"{x:1228,y:784,t:1527877038353};\\\", \\\"{x:1226,y:784,t:1527877038366};\\\", \\\"{x:1222,y:786,t:1527877038383};\\\", \\\"{x:1215,y:787,t:1527877038400};\\\", \\\"{x:1209,y:787,t:1527877038416};\\\", \\\"{x:1204,y:789,t:1527877038433};\\\", \\\"{x:1203,y:789,t:1527877038457};\\\", \\\"{x:1203,y:790,t:1527877038467};\\\", \\\"{x:1202,y:791,t:1527877038483};\\\", \\\"{x:1200,y:791,t:1527877038500};\\\", \\\"{x:1193,y:794,t:1527877038516};\\\", \\\"{x:1188,y:795,t:1527877038533};\\\", \\\"{x:1185,y:798,t:1527877038551};\\\", \\\"{x:1180,y:799,t:1527877038567};\\\", \\\"{x:1178,y:801,t:1527877038583};\\\", \\\"{x:1174,y:802,t:1527877038601};\\\", \\\"{x:1170,y:805,t:1527877038617};\\\", \\\"{x:1155,y:808,t:1527877038634};\\\", \\\"{x:1142,y:809,t:1527877038650};\\\", \\\"{x:1139,y:809,t:1527877038667};\\\", \\\"{x:1138,y:809,t:1527877038684};\\\", \\\"{x:1138,y:810,t:1527877038713};\\\", \\\"{x:1138,y:811,t:1527877038737};\\\", \\\"{x:1137,y:814,t:1527877038750};\\\", \\\"{x:1136,y:815,t:1527877038767};\\\", \\\"{x:1135,y:817,t:1527877038784};\\\", \\\"{x:1134,y:817,t:1527877038801};\\\", \\\"{x:1133,y:819,t:1527877038817};\\\", \\\"{x:1131,y:821,t:1527877038834};\\\", \\\"{x:1130,y:821,t:1527877038850};\\\", \\\"{x:1129,y:822,t:1527877039106};\\\", \\\"{x:1127,y:822,t:1527877039129};\\\", \\\"{x:1125,y:821,t:1527877039138};\\\", \\\"{x:1123,y:821,t:1527877039153};\\\", \\\"{x:1122,y:820,t:1527877039168};\\\", \\\"{x:1119,y:819,t:1527877039183};\\\", \\\"{x:1118,y:819,t:1527877039200};\\\", \\\"{x:1118,y:817,t:1527877039217};\\\", \\\"{x:1115,y:814,t:1527877039234};\\\", \\\"{x:1113,y:810,t:1527877039251};\\\", \\\"{x:1110,y:804,t:1527877039267};\\\", \\\"{x:1106,y:791,t:1527877039283};\\\", \\\"{x:1103,y:779,t:1527877039300};\\\", \\\"{x:1103,y:765,t:1527877039317};\\\", \\\"{x:1100,y:752,t:1527877039334};\\\", \\\"{x:1097,y:746,t:1527877039350};\\\", \\\"{x:1097,y:735,t:1527877039367};\\\", \\\"{x:1097,y:719,t:1527877039385};\\\", \\\"{x:1096,y:714,t:1527877039400};\\\", \\\"{x:1099,y:692,t:1527877039416};\\\", \\\"{x:1100,y:683,t:1527877039433};\\\", \\\"{x:1100,y:680,t:1527877039450};\\\", \\\"{x:1100,y:669,t:1527877039466};\\\", \\\"{x:1100,y:663,t:1527877039484};\\\", \\\"{x:1099,y:657,t:1527877039500};\\\", \\\"{x:1099,y:656,t:1527877039517};\\\", \\\"{x:1099,y:655,t:1527877039534};\\\", \\\"{x:1098,y:655,t:1527877039658};\\\", \\\"{x:1095,y:655,t:1527877039668};\\\", \\\"{x:1094,y:656,t:1527877039685};\\\", \\\"{x:1093,y:657,t:1527877039701};\\\", \\\"{x:1093,y:658,t:1527877039717};\\\", \\\"{x:1093,y:659,t:1527877039737};\\\", \\\"{x:1092,y:660,t:1527877039750};\\\", \\\"{x:1091,y:660,t:1527877039785};\\\", \\\"{x:1090,y:660,t:1527877039865};\\\", \\\"{x:1089,y:661,t:1527877039873};\\\", \\\"{x:1088,y:661,t:1527877039884};\\\", \\\"{x:1088,y:662,t:1527877039902};\\\", \\\"{x:1087,y:663,t:1527877039946};\\\", \\\"{x:1087,y:664,t:1527877039952};\\\", \\\"{x:1086,y:664,t:1527877039968};\\\", \\\"{x:1085,y:665,t:1527877039985};\\\", \\\"{x:1085,y:666,t:1527877040001};\\\", \\\"{x:1084,y:667,t:1527877040017};\\\", \\\"{x:1084,y:668,t:1527877040035};\\\", \\\"{x:1084,y:670,t:1527877040051};\\\", \\\"{x:1083,y:672,t:1527877040068};\\\", \\\"{x:1083,y:673,t:1527877040084};\\\", \\\"{x:1082,y:675,t:1527877040101};\\\", \\\"{x:1082,y:678,t:1527877040117};\\\", \\\"{x:1082,y:682,t:1527877040135};\\\", \\\"{x:1082,y:688,t:1527877040151};\\\", \\\"{x:1082,y:692,t:1527877040167};\\\", \\\"{x:1082,y:696,t:1527877040185};\\\", \\\"{x:1082,y:703,t:1527877040201};\\\", \\\"{x:1082,y:705,t:1527877040217};\\\", \\\"{x:1082,y:710,t:1527877040234};\\\", \\\"{x:1083,y:712,t:1527877040251};\\\", \\\"{x:1085,y:717,t:1527877040268};\\\", \\\"{x:1087,y:718,t:1527877040284};\\\", \\\"{x:1088,y:722,t:1527877040301};\\\", \\\"{x:1092,y:728,t:1527877040318};\\\", \\\"{x:1093,y:730,t:1527877040334};\\\", \\\"{x:1094,y:732,t:1527877040352};\\\", \\\"{x:1094,y:733,t:1527877040377};\\\", \\\"{x:1095,y:733,t:1527877040401};\\\", \\\"{x:1096,y:735,t:1527877041033};\\\", \\\"{x:1098,y:736,t:1527877041041};\\\", \\\"{x:1099,y:738,t:1527877041051};\\\", \\\"{x:1104,y:741,t:1527877041068};\\\", \\\"{x:1108,y:744,t:1527877041085};\\\", \\\"{x:1111,y:747,t:1527877041101};\\\", \\\"{x:1114,y:749,t:1527877041119};\\\", \\\"{x:1114,y:750,t:1527877041233};\\\", \\\"{x:1114,y:751,t:1527877041249};\\\", \\\"{x:1114,y:752,t:1527877041281};\\\", \\\"{x:1114,y:753,t:1527877041304};\\\", \\\"{x:1114,y:754,t:1527877041320};\\\", \\\"{x:1113,y:755,t:1527877041335};\\\", \\\"{x:1112,y:756,t:1527877041376};\\\", \\\"{x:1112,y:757,t:1527877041393};\\\", \\\"{x:1111,y:757,t:1527877041409};\\\", \\\"{x:1110,y:757,t:1527877041417};\\\", \\\"{x:1108,y:758,t:1527877041435};\\\", \\\"{x:1104,y:759,t:1527877041452};\\\", \\\"{x:1099,y:760,t:1527877041468};\\\", \\\"{x:1097,y:762,t:1527877041485};\\\", \\\"{x:1092,y:762,t:1527877041502};\\\", \\\"{x:1089,y:762,t:1527877041518};\\\", \\\"{x:1088,y:763,t:1527877041536};\\\", \\\"{x:1090,y:767,t:1527877041825};\\\", \\\"{x:1093,y:767,t:1527877041836};\\\", \\\"{x:1108,y:771,t:1527877041852};\\\", \\\"{x:1125,y:776,t:1527877041869};\\\", \\\"{x:1140,y:780,t:1527877041885};\\\", \\\"{x:1152,y:783,t:1527877041902};\\\", \\\"{x:1170,y:785,t:1527877041920};\\\", \\\"{x:1180,y:788,t:1527877041935};\\\", \\\"{x:1188,y:789,t:1527877041952};\\\", \\\"{x:1203,y:793,t:1527877041969};\\\", \\\"{x:1209,y:795,t:1527877041985};\\\", \\\"{x:1221,y:798,t:1527877042003};\\\", \\\"{x:1231,y:801,t:1527877042020};\\\", \\\"{x:1242,y:803,t:1527877042035};\\\", \\\"{x:1253,y:807,t:1527877042052};\\\", \\\"{x:1257,y:807,t:1527877042069};\\\", \\\"{x:1259,y:809,t:1527877042085};\\\", \\\"{x:1265,y:813,t:1527877042103};\\\", \\\"{x:1269,y:814,t:1527877042120};\\\", \\\"{x:1277,y:815,t:1527877042136};\\\", \\\"{x:1282,y:817,t:1527877042153};\\\", \\\"{x:1296,y:821,t:1527877042169};\\\", \\\"{x:1305,y:823,t:1527877042186};\\\", \\\"{x:1317,y:827,t:1527877042203};\\\", \\\"{x:1326,y:833,t:1527877042219};\\\", \\\"{x:1339,y:839,t:1527877042236};\\\", \\\"{x:1343,y:843,t:1527877042252};\\\", \\\"{x:1347,y:845,t:1527877042270};\\\", \\\"{x:1348,y:846,t:1527877042286};\\\", \\\"{x:1348,y:847,t:1527877042338};\\\", \\\"{x:1348,y:849,t:1527877042353};\\\", \\\"{x:1346,y:852,t:1527877042369};\\\", \\\"{x:1345,y:856,t:1527877042387};\\\", \\\"{x:1344,y:858,t:1527877042402};\\\", \\\"{x:1344,y:862,t:1527877042419};\\\", \\\"{x:1344,y:869,t:1527877042437};\\\", \\\"{x:1351,y:877,t:1527877042453};\\\", \\\"{x:1360,y:890,t:1527877042470};\\\", \\\"{x:1368,y:898,t:1527877042487};\\\", \\\"{x:1377,y:906,t:1527877042502};\\\", \\\"{x:1391,y:916,t:1527877042520};\\\", \\\"{x:1405,y:923,t:1527877042537};\\\", \\\"{x:1419,y:930,t:1527877042552};\\\", \\\"{x:1441,y:943,t:1527877042569};\\\", \\\"{x:1456,y:948,t:1527877042586};\\\", \\\"{x:1466,y:951,t:1527877042603};\\\", \\\"{x:1479,y:954,t:1527877042620};\\\", \\\"{x:1492,y:957,t:1527877042636};\\\", \\\"{x:1502,y:958,t:1527877042653};\\\", \\\"{x:1511,y:959,t:1527877042670};\\\", \\\"{x:1519,y:961,t:1527877042687};\\\", \\\"{x:1524,y:962,t:1527877042703};\\\", \\\"{x:1533,y:963,t:1527877042720};\\\", \\\"{x:1539,y:965,t:1527877042737};\\\", \\\"{x:1542,y:968,t:1527877042753};\\\", \\\"{x:1555,y:974,t:1527877042770};\\\", \\\"{x:1559,y:975,t:1527877042786};\\\", \\\"{x:1560,y:975,t:1527877042809};\\\", \\\"{x:1559,y:975,t:1527877043048};\\\", \\\"{x:1557,y:975,t:1527877043057};\\\", \\\"{x:1554,y:975,t:1527877043088};\\\", \\\"{x:1553,y:975,t:1527877043102};\\\", \\\"{x:1551,y:976,t:1527877043120};\\\", \\\"{x:1550,y:977,t:1527877043136};\\\", \\\"{x:1549,y:977,t:1527877043241};\\\", \\\"{x:1548,y:977,t:1527877043257};\\\", \\\"{x:1546,y:976,t:1527877043290};\\\", \\\"{x:1546,y:975,t:1527877043305};\\\", \\\"{x:1545,y:974,t:1527877043321};\\\", \\\"{x:1544,y:974,t:1527877043337};\\\", \\\"{x:1543,y:971,t:1527877043353};\\\", \\\"{x:1543,y:970,t:1527877043370};\\\", \\\"{x:1541,y:969,t:1527877043386};\\\", \\\"{x:1541,y:968,t:1527877043405};\\\", \\\"{x:1541,y:967,t:1527877043464};\\\", \\\"{x:1541,y:966,t:1527877045569};\\\", \\\"{x:1541,y:965,t:1527877045625};\\\", \\\"{x:1541,y:964,t:1527877045638};\\\", \\\"{x:1541,y:962,t:1527877045656};\\\", \\\"{x:1541,y:961,t:1527877045689};\\\", \\\"{x:1540,y:959,t:1527877045705};\\\", \\\"{x:1540,y:961,t:1527877045906};\\\", \\\"{x:1540,y:963,t:1527877045922};\\\", \\\"{x:1540,y:966,t:1527877045939};\\\", \\\"{x:1540,y:967,t:1527877045955};\\\", \\\"{x:1540,y:968,t:1527877046009};\\\", \\\"{x:1541,y:968,t:1527877046290};\\\", \\\"{x:1542,y:968,t:1527877046305};\\\", \\\"{x:1543,y:967,t:1527877046322};\\\", \\\"{x:1543,y:966,t:1527877046338};\\\", \\\"{x:1544,y:965,t:1527877046355};\\\", \\\"{x:1545,y:962,t:1527877046409};\\\", \\\"{x:1545,y:960,t:1527877046722};\\\", \\\"{x:1541,y:958,t:1527877046740};\\\", \\\"{x:1539,y:958,t:1527877046755};\\\", \\\"{x:1535,y:957,t:1527877046773};\\\", \\\"{x:1534,y:958,t:1527877046961};\\\", \\\"{x:1534,y:959,t:1527877047002};\\\", \\\"{x:1533,y:960,t:1527877047010};\\\", \\\"{x:1533,y:961,t:1527877047082};\\\", \\\"{x:1535,y:961,t:1527877047170};\\\", \\\"{x:1536,y:961,t:1527877047177};\\\", \\\"{x:1537,y:961,t:1527877047189};\\\", \\\"{x:1539,y:961,t:1527877047206};\\\", \\\"{x:1541,y:961,t:1527877047223};\\\", \\\"{x:1542,y:961,t:1527877047257};\\\", \\\"{x:1543,y:961,t:1527877047273};\\\", \\\"{x:1546,y:961,t:1527877047289};\\\", \\\"{x:1548,y:961,t:1527877047307};\\\", \\\"{x:1549,y:961,t:1527877047323};\\\", \\\"{x:1550,y:961,t:1527877047354};\\\", \\\"{x:1552,y:960,t:1527877047386};\\\", \\\"{x:1552,y:959,t:1527877047409};\\\", \\\"{x:1553,y:959,t:1527877047425};\\\", \\\"{x:1553,y:958,t:1527877048433};\\\", \\\"{x:1553,y:956,t:1527877048448};\\\", \\\"{x:1553,y:955,t:1527877048497};\\\", \\\"{x:1553,y:953,t:1527877048586};\\\", \\\"{x:1552,y:953,t:1527877057806};\\\", \\\"{x:1551,y:953,t:1527877057973};\\\", \\\"{x:1550,y:953,t:1527877057997};\\\", \\\"{x:1549,y:953,t:1527877058005};\\\", \\\"{x:1547,y:953,t:1527877058029};\\\", \\\"{x:1545,y:953,t:1527877058117};\\\", \\\"{x:1545,y:956,t:1527877058136};\\\", \\\"{x:1545,y:960,t:1527877058152};\\\", \\\"{x:1545,y:964,t:1527877058169};\\\", \\\"{x:1546,y:968,t:1527877058185};\\\", \\\"{x:1549,y:971,t:1527877058203};\\\", \\\"{x:1549,y:973,t:1527877058218};\\\", \\\"{x:1548,y:972,t:1527877058405};\\\", \\\"{x:1547,y:972,t:1527877058460};\\\", \\\"{x:1546,y:972,t:1527877067101};\\\", \\\"{x:1546,y:971,t:1527877067108};\\\", \\\"{x:1544,y:970,t:1527877067125};\\\", \\\"{x:1542,y:967,t:1527877067142};\\\", \\\"{x:1542,y:965,t:1527877067941};\\\", \\\"{x:1542,y:964,t:1527877068077};\\\", \\\"{x:1543,y:964,t:1527877068973};\\\", \\\"{x:1543,y:963,t:1527877068989};\\\", \\\"{x:1544,y:963,t:1527877069029};\\\", \\\"{x:1545,y:962,t:1527877069053};\\\", \\\"{x:1545,y:961,t:1527877070933};\\\", \\\"{x:1545,y:958,t:1527877072941};\\\", \\\"{x:1541,y:953,t:1527877072948};\\\", \\\"{x:1534,y:945,t:1527877072962};\\\", \\\"{x:1501,y:908,t:1527877072980};\\\", \\\"{x:1424,y:862,t:1527877072995};\\\", \\\"{x:1270,y:781,t:1527877073012};\\\", \\\"{x:1140,y:725,t:1527877073030};\\\", \\\"{x:1007,y:662,t:1527877073046};\\\", \\\"{x:905,y:612,t:1527877073063};\\\", \\\"{x:818,y:581,t:1527877073080};\\\", \\\"{x:782,y:566,t:1527877073096};\\\", \\\"{x:771,y:557,t:1527877073115};\\\", \\\"{x:753,y:551,t:1527877073132};\\\", \\\"{x:749,y:549,t:1527877073148};\\\", \\\"{x:748,y:549,t:1527877073573};\\\", \\\"{x:747,y:549,t:1527877073588};\\\", \\\"{x:746,y:549,t:1527877073599};\\\", \\\"{x:746,y:550,t:1527877073615};\\\", \\\"{x:746,y:551,t:1527877073632};\\\", \\\"{x:746,y:552,t:1527877073648};\\\", \\\"{x:748,y:555,t:1527877073665};\\\", \\\"{x:754,y:555,t:1527877073681};\\\", \\\"{x:765,y:554,t:1527877073699};\\\", \\\"{x:784,y:543,t:1527877073715};\\\", \\\"{x:798,y:533,t:1527877073731};\\\", \\\"{x:813,y:525,t:1527877073748};\\\", \\\"{x:819,y:520,t:1527877073765};\\\", \\\"{x:823,y:516,t:1527877073781};\\\", \\\"{x:823,y:515,t:1527877073799};\\\", \\\"{x:824,y:515,t:1527877073816};\\\", \\\"{x:826,y:516,t:1527877073876};\\\", \\\"{x:827,y:519,t:1527877073884};\\\", \\\"{x:827,y:521,t:1527877073899};\\\", \\\"{x:832,y:531,t:1527877073916};\\\", \\\"{x:840,y:544,t:1527877073932};\\\", \\\"{x:845,y:551,t:1527877073950};\\\", \\\"{x:846,y:558,t:1527877073967};\\\", \\\"{x:848,y:563,t:1527877073982};\\\", \\\"{x:849,y:569,t:1527877073999};\\\", \\\"{x:849,y:575,t:1527877074016};\\\", \\\"{x:849,y:582,t:1527877074032};\\\", \\\"{x:849,y:586,t:1527877074049};\\\", \\\"{x:849,y:588,t:1527877074066};\\\", \\\"{x:849,y:589,t:1527877074083};\\\", \\\"{x:849,y:591,t:1527877074100};\\\", \\\"{x:849,y:592,t:1527877074116};\\\", \\\"{x:848,y:591,t:1527877074237};\\\", \\\"{x:847,y:588,t:1527877074249};\\\", \\\"{x:843,y:582,t:1527877074267};\\\", \\\"{x:841,y:578,t:1527877074283};\\\", \\\"{x:840,y:577,t:1527877074299};\\\", \\\"{x:841,y:577,t:1527877078557};\\\", \\\"{x:850,y:585,t:1527877078573};\\\", \\\"{x:868,y:601,t:1527877078589};\\\", \\\"{x:921,y:638,t:1527877078604};\\\", \\\"{x:990,y:667,t:1527877078621};\\\", \\\"{x:1003,y:678,t:1527877078633};\\\", \\\"{x:1046,y:703,t:1527877078649};\\\", \\\"{x:1085,y:723,t:1527877078666};\\\", \\\"{x:1117,y:740,t:1527877078684};\\\", \\\"{x:1150,y:755,t:1527877078700};\\\", \\\"{x:1180,y:766,t:1527877078718};\\\", \\\"{x:1188,y:770,t:1527877078734};\\\", \\\"{x:1195,y:774,t:1527877078749};\\\", \\\"{x:1197,y:777,t:1527877078766};\\\", \\\"{x:1201,y:779,t:1527877078783};\\\", \\\"{x:1206,y:785,t:1527877078800};\\\", \\\"{x:1210,y:788,t:1527877078817};\\\", \\\"{x:1217,y:793,t:1527877078834};\\\", \\\"{x:1226,y:800,t:1527877078850};\\\", \\\"{x:1233,y:810,t:1527877078867};\\\", \\\"{x:1250,y:816,t:1527877078883};\\\", \\\"{x:1268,y:824,t:1527877078899};\\\", \\\"{x:1294,y:836,t:1527877078917};\\\", \\\"{x:1312,y:842,t:1527877078934};\\\", \\\"{x:1330,y:849,t:1527877078950};\\\", \\\"{x:1348,y:856,t:1527877078966};\\\", \\\"{x:1353,y:861,t:1527877078983};\\\", \\\"{x:1364,y:865,t:1527877079000};\\\", \\\"{x:1368,y:868,t:1527877079017};\\\", \\\"{x:1374,y:869,t:1527877079034};\\\", \\\"{x:1377,y:871,t:1527877079050};\\\", \\\"{x:1379,y:871,t:1527877079067};\\\", \\\"{x:1385,y:874,t:1527877079084};\\\", \\\"{x:1395,y:878,t:1527877079100};\\\", \\\"{x:1403,y:882,t:1527877079117};\\\", \\\"{x:1409,y:887,t:1527877079134};\\\", \\\"{x:1431,y:894,t:1527877079150};\\\", \\\"{x:1452,y:906,t:1527877079167};\\\", \\\"{x:1459,y:910,t:1527877079184};\\\", \\\"{x:1470,y:910,t:1527877079200};\\\", \\\"{x:1480,y:917,t:1527877079217};\\\", \\\"{x:1485,y:920,t:1527877079234};\\\", \\\"{x:1491,y:923,t:1527877079249};\\\", \\\"{x:1492,y:924,t:1527877079268};\\\", \\\"{x:1494,y:927,t:1527877079284};\\\", \\\"{x:1497,y:927,t:1527877079300};\\\", \\\"{x:1502,y:929,t:1527877079317};\\\", \\\"{x:1506,y:932,t:1527877079334};\\\", \\\"{x:1507,y:933,t:1527877079350};\\\", \\\"{x:1508,y:933,t:1527877079367};\\\", \\\"{x:1511,y:934,t:1527877079384};\\\", \\\"{x:1516,y:938,t:1527877079400};\\\", \\\"{x:1522,y:942,t:1527877079417};\\\", \\\"{x:1528,y:946,t:1527877079434};\\\", \\\"{x:1531,y:952,t:1527877079450};\\\", \\\"{x:1533,y:956,t:1527877079467};\\\", \\\"{x:1533,y:954,t:1527877080765};\\\", \\\"{x:1530,y:943,t:1527877080773};\\\", \\\"{x:1519,y:930,t:1527877080784};\\\", \\\"{x:1462,y:900,t:1527877080800};\\\", \\\"{x:1375,y:873,t:1527877080816};\\\", \\\"{x:1306,y:854,t:1527877080833};\\\", \\\"{x:1268,y:840,t:1527877080850};\\\", \\\"{x:1238,y:830,t:1527877080866};\\\", \\\"{x:1225,y:823,t:1527877080883};\\\", \\\"{x:1218,y:821,t:1527877080899};\\\", \\\"{x:1218,y:819,t:1527877081077};\\\", \\\"{x:1220,y:819,t:1527877081085};\\\", \\\"{x:1220,y:818,t:1527877081100};\\\", \\\"{x:1223,y:797,t:1527877081117};\\\", \\\"{x:1223,y:774,t:1527877081134};\\\", \\\"{x:1218,y:754,t:1527877081150};\\\", \\\"{x:1215,y:749,t:1527877081167};\\\", \\\"{x:1217,y:753,t:1527877081397};\\\", \\\"{x:1221,y:758,t:1527877081404};\\\", \\\"{x:1225,y:764,t:1527877081417};\\\", \\\"{x:1236,y:772,t:1527877081434};\\\", \\\"{x:1245,y:777,t:1527877081450};\\\", \\\"{x:1261,y:778,t:1527877081467};\\\", \\\"{x:1280,y:780,t:1527877081484};\\\", \\\"{x:1301,y:785,t:1527877081500};\\\", \\\"{x:1334,y:795,t:1527877081517};\\\", \\\"{x:1359,y:798,t:1527877081534};\\\", \\\"{x:1376,y:802,t:1527877081550};\\\", \\\"{x:1386,y:805,t:1527877081567};\\\", \\\"{x:1388,y:806,t:1527877081584};\\\", \\\"{x:1388,y:807,t:1527877081837};\\\", \\\"{x:1385,y:807,t:1527877081852};\\\", \\\"{x:1374,y:807,t:1527877081867};\\\", \\\"{x:1359,y:798,t:1527877081884};\\\", \\\"{x:1342,y:792,t:1527877081900};\\\", \\\"{x:1305,y:779,t:1527877081917};\\\", \\\"{x:1290,y:773,t:1527877081934};\\\", \\\"{x:1282,y:771,t:1527877081950};\\\", \\\"{x:1281,y:771,t:1527877081995};\\\", \\\"{x:1281,y:770,t:1527877082084};\\\", \\\"{x:1281,y:768,t:1527877082108};\\\", \\\"{x:1282,y:768,t:1527877082117};\\\", \\\"{x:1294,y:771,t:1527877082134};\\\", \\\"{x:1313,y:777,t:1527877082150};\\\", \\\"{x:1328,y:782,t:1527877082167};\\\", \\\"{x:1337,y:783,t:1527877082183};\\\", \\\"{x:1339,y:784,t:1527877082200};\\\", \\\"{x:1340,y:784,t:1527877082217};\\\", \\\"{x:1338,y:781,t:1527877082269};\\\", \\\"{x:1303,y:770,t:1527877082284};\\\", \\\"{x:1206,y:744,t:1527877082300};\\\", \\\"{x:1047,y:706,t:1527877082317};\\\", \\\"{x:954,y:685,t:1527877082334};\\\", \\\"{x:870,y:660,t:1527877082350};\\\", \\\"{x:826,y:645,t:1527877082367};\\\", \\\"{x:801,y:636,t:1527877082383};\\\", \\\"{x:795,y:635,t:1527877082399};\\\", \\\"{x:794,y:635,t:1527877082420};\\\", \\\"{x:791,y:635,t:1527877082453};\\\", \\\"{x:789,y:634,t:1527877082467};\\\", \\\"{x:777,y:630,t:1527877082485};\\\", \\\"{x:755,y:624,t:1527877082500};\\\", \\\"{x:740,y:616,t:1527877082522};\\\", \\\"{x:704,y:603,t:1527877082540};\\\", \\\"{x:682,y:591,t:1527877082557};\\\", \\\"{x:664,y:584,t:1527877082572};\\\", \\\"{x:647,y:572,t:1527877082590};\\\", \\\"{x:635,y:564,t:1527877082606};\\\", \\\"{x:631,y:562,t:1527877082623};\\\", \\\"{x:631,y:561,t:1527877082691};\\\", \\\"{x:634,y:560,t:1527877082708};\\\", \\\"{x:641,y:560,t:1527877082724};\\\", \\\"{x:651,y:559,t:1527877082740};\\\", \\\"{x:658,y:559,t:1527877082756};\\\", \\\"{x:668,y:559,t:1527877082773};\\\", \\\"{x:682,y:559,t:1527877082790};\\\", \\\"{x:705,y:559,t:1527877082806};\\\", \\\"{x:733,y:560,t:1527877082823};\\\", \\\"{x:748,y:563,t:1527877082841};\\\", \\\"{x:764,y:565,t:1527877082856};\\\", \\\"{x:769,y:565,t:1527877082874};\\\", \\\"{x:775,y:566,t:1527877082890};\\\", \\\"{x:779,y:566,t:1527877082907};\\\", \\\"{x:787,y:566,t:1527877082924};\\\", \\\"{x:789,y:566,t:1527877082940};\\\", \\\"{x:791,y:566,t:1527877082956};\\\", \\\"{x:793,y:566,t:1527877082973};\\\", \\\"{x:801,y:562,t:1527877082992};\\\", \\\"{x:813,y:556,t:1527877083007};\\\", \\\"{x:820,y:553,t:1527877083025};\\\", \\\"{x:822,y:552,t:1527877083039};\\\", \\\"{x:813,y:552,t:1527877083099};\\\", \\\"{x:801,y:553,t:1527877083108};\\\", \\\"{x:758,y:553,t:1527877083123};\\\", \\\"{x:669,y:555,t:1527877083141};\\\", \\\"{x:605,y:564,t:1527877083157};\\\", \\\"{x:565,y:578,t:1527877083174};\\\", \\\"{x:530,y:586,t:1527877083189};\\\", \\\"{x:524,y:594,t:1527877083207};\\\", \\\"{x:512,y:601,t:1527877083224};\\\", \\\"{x:502,y:609,t:1527877083241};\\\", \\\"{x:498,y:610,t:1527877083257};\\\", \\\"{x:492,y:613,t:1527877083273};\\\", \\\"{x:489,y:615,t:1527877083290};\\\", \\\"{x:485,y:620,t:1527877083306};\\\", \\\"{x:475,y:625,t:1527877083324};\\\", \\\"{x:468,y:626,t:1527877083340};\\\", \\\"{x:451,y:628,t:1527877083356};\\\", \\\"{x:444,y:628,t:1527877083373};\\\", \\\"{x:437,y:630,t:1527877083391};\\\", \\\"{x:428,y:630,t:1527877083408};\\\", \\\"{x:423,y:630,t:1527877083423};\\\", \\\"{x:409,y:634,t:1527877083442};\\\", \\\"{x:401,y:635,t:1527877083458};\\\", \\\"{x:397,y:637,t:1527877083473};\\\", \\\"{x:394,y:635,t:1527877083489};\\\", \\\"{x:391,y:633,t:1527877083507};\\\", \\\"{x:381,y:632,t:1527877083524};\\\", \\\"{x:379,y:632,t:1527877083556};\\\", \\\"{x:382,y:632,t:1527877083636};\\\", \\\"{x:387,y:632,t:1527877083643};\\\", \\\"{x:389,y:632,t:1527877083656};\\\", \\\"{x:396,y:628,t:1527877083674};\\\", \\\"{x:397,y:626,t:1527877083690};\\\", \\\"{x:397,y:625,t:1527877083707};\\\", \\\"{x:393,y:611,t:1527877083723};\\\", \\\"{x:367,y:593,t:1527877083741};\\\", \\\"{x:293,y:568,t:1527877083757};\\\", \\\"{x:233,y:552,t:1527877083774};\\\", \\\"{x:206,y:547,t:1527877083790};\\\", \\\"{x:181,y:543,t:1527877083808};\\\", \\\"{x:164,y:535,t:1527877083823};\\\", \\\"{x:151,y:531,t:1527877083840};\\\", \\\"{x:149,y:530,t:1527877083857};\\\", \\\"{x:148,y:529,t:1527877084188};\\\", \\\"{x:148,y:529,t:1527877084204};\\\", \\\"{x:148,y:528,t:1527877084244};\\\", \\\"{x:148,y:527,t:1527877084258};\\\", \\\"{x:153,y:527,t:1527877084284};\\\", \\\"{x:161,y:529,t:1527877084292};\\\", \\\"{x:181,y:540,t:1527877084307};\\\", \\\"{x:232,y:569,t:1527877084325};\\\", \\\"{x:281,y:599,t:1527877084342};\\\", \\\"{x:314,y:617,t:1527877084358};\\\", \\\"{x:386,y:650,t:1527877084376};\\\", \\\"{x:436,y:690,t:1527877084392};\\\", \\\"{x:470,y:717,t:1527877084408};\\\", \\\"{x:488,y:730,t:1527877084425};\\\", \\\"{x:496,y:741,t:1527877084441};\\\", \\\"{x:501,y:747,t:1527877084457};\\\", \\\"{x:503,y:749,t:1527877084475};\\\", \\\"{x:505,y:750,t:1527877084490};\\\", \\\"{x:506,y:750,t:1527877084508};\\\", \\\"{x:503,y:743,t:1527877084636};\\\", \\\"{x:485,y:729,t:1527877084644};\\\", \\\"{x:457,y:708,t:1527877084658};\\\", \\\"{x:366,y:652,t:1527877084675};\\\", \\\"{x:215,y:580,t:1527877084691};\\\", \\\"{x:116,y:540,t:1527877084708};\\\", \\\"{x:74,y:526,t:1527877084725};\\\", \\\"{x:59,y:524,t:1527877084742};\\\", \\\"{x:54,y:523,t:1527877084758};\\\", \\\"{x:53,y:522,t:1527877084796};\\\", \\\"{x:53,y:521,t:1527877084828};\\\", \\\"{x:53,y:519,t:1527877084842};\\\", \\\"{x:53,y:517,t:1527877084859};\\\", \\\"{x:53,y:515,t:1527877084874};\\\", \\\"{x:53,y:516,t:1527877084941};\\\", \\\"{x:62,y:525,t:1527877084960};\\\", \\\"{x:70,y:535,t:1527877084975};\\\", \\\"{x:82,y:539,t:1527877084992};\\\", \\\"{x:99,y:549,t:1527877085009};\\\", \\\"{x:111,y:552,t:1527877085025};\\\", \\\"{x:119,y:552,t:1527877085041};\\\", \\\"{x:122,y:552,t:1527877085059};\\\", \\\"{x:124,y:552,t:1527877085083};\\\", \\\"{x:125,y:549,t:1527877085091};\\\", \\\"{x:128,y:546,t:1527877085108};\\\", \\\"{x:131,y:541,t:1527877085124};\\\", \\\"{x:134,y:538,t:1527877085141};\\\", \\\"{x:137,y:533,t:1527877085159};\\\", \\\"{x:139,y:531,t:1527877085175};\\\", \\\"{x:140,y:531,t:1527877085192};\\\", \\\"{x:140,y:530,t:1527877085235};\\\", \\\"{x:141,y:530,t:1527877085244};\\\", \\\"{x:143,y:529,t:1527877085259};\\\", \\\"{x:145,y:529,t:1527877085275};\\\", \\\"{x:149,y:529,t:1527877085293};\\\", \\\"{x:155,y:529,t:1527877085309};\\\", \\\"{x:157,y:530,t:1527877085325};\\\", \\\"{x:158,y:531,t:1527877085342};\\\", \\\"{x:159,y:532,t:1527877085588};\\\", \\\"{x:159,y:533,t:1527877085596};\\\", \\\"{x:161,y:537,t:1527877085609};\\\", \\\"{x:179,y:552,t:1527877085626};\\\", \\\"{x:199,y:565,t:1527877085642};\\\", \\\"{x:211,y:574,t:1527877085658};\\\", \\\"{x:248,y:600,t:1527877085676};\\\", \\\"{x:298,y:634,t:1527877085692};\\\", \\\"{x:338,y:665,t:1527877085709};\\\", \\\"{x:376,y:695,t:1527877085726};\\\", \\\"{x:399,y:711,t:1527877085743};\\\", \\\"{x:414,y:723,t:1527877085759};\\\", \\\"{x:426,y:728,t:1527877085776};\\\", \\\"{x:435,y:733,t:1527877085793};\\\", \\\"{x:443,y:736,t:1527877085809};\\\", \\\"{x:446,y:736,t:1527877085827};\\\", \\\"{x:450,y:737,t:1527877085843};\\\", \\\"{x:456,y:737,t:1527877085859};\\\", \\\"{x:458,y:739,t:1527877085916};\\\", \\\"{x:461,y:740,t:1527877085932};\\\", \\\"{x:464,y:741,t:1527877085942};\\\", \\\"{x:465,y:743,t:1527877085958};\\\", \\\"{x:467,y:744,t:1527877085976};\\\", \\\"{x:472,y:746,t:1527877085992};\\\", \\\"{x:475,y:748,t:1527877086009};\\\", \\\"{x:483,y:752,t:1527877086025};\\\", \\\"{x:484,y:752,t:1527877086042};\\\", \\\"{x:489,y:752,t:1527877086058};\\\", \\\"{x:491,y:752,t:1527877086075};\\\", \\\"{x:491,y:751,t:1527877086124};\\\", \\\"{x:491,y:751,t:1527877086189};\\\", \\\"{x:491,y:750,t:1527877086412};\\\", \\\"{x:492,y:750,t:1527877087133};\\\", \\\"{x:493,y:748,t:1527877087172};\\\", \\\"{x:494,y:747,t:1527877087219};\\\", \\\"{x:496,y:746,t:1527877087284};\\\" ] }, { \\\"rt\\\": 51393, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 744462, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 0, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-02 PM-02 PM-X -X -X -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:718,t:1527877087478};\\\", \\\"{x:542,y:712,t:1527877087494};\\\", \\\"{x:547,y:709,t:1527877087510};\\\", \\\"{x:553,y:704,t:1527877087526};\\\", \\\"{x:558,y:700,t:1527877087543};\\\", \\\"{x:570,y:691,t:1527877087575};\\\", \\\"{x:576,y:690,t:1527877087595};\\\", \\\"{x:581,y:687,t:1527877087611};\\\", \\\"{x:589,y:686,t:1527877087626};\\\", \\\"{x:605,y:684,t:1527877087644};\\\", \\\"{x:615,y:683,t:1527877087661};\\\", \\\"{x:629,y:680,t:1527877087677};\\\", \\\"{x:641,y:679,t:1527877087693};\\\", \\\"{x:644,y:678,t:1527877087710};\\\", \\\"{x:646,y:677,t:1527877087727};\\\", \\\"{x:645,y:678,t:1527877088413};\\\", \\\"{x:643,y:681,t:1527877088428};\\\", \\\"{x:641,y:684,t:1527877088444};\\\", \\\"{x:640,y:687,t:1527877088461};\\\", \\\"{x:640,y:690,t:1527877088479};\\\", \\\"{x:640,y:691,t:1527877088495};\\\", \\\"{x:640,y:693,t:1527877088511};\\\", \\\"{x:640,y:694,t:1527877088529};\\\", \\\"{x:639,y:695,t:1527877088545};\\\", \\\"{x:640,y:697,t:1527877093749};\\\", \\\"{x:657,y:699,t:1527877093766};\\\", \\\"{x:695,y:710,t:1527877093783};\\\", \\\"{x:733,y:721,t:1527877093799};\\\", \\\"{x:796,y:735,t:1527877093815};\\\", \\\"{x:828,y:746,t:1527877093833};\\\", \\\"{x:888,y:768,t:1527877093850};\\\", \\\"{x:914,y:781,t:1527877093865};\\\", \\\"{x:952,y:789,t:1527877093883};\\\", \\\"{x:982,y:800,t:1527877093900};\\\", \\\"{x:1000,y:811,t:1527877093916};\\\", \\\"{x:1023,y:821,t:1527877093932};\\\", \\\"{x:1032,y:822,t:1527877093949};\\\", \\\"{x:1040,y:826,t:1527877093965};\\\", \\\"{x:1042,y:827,t:1527877093981};\\\", \\\"{x:1043,y:827,t:1527877094165};\\\", \\\"{x:1043,y:828,t:1527877094221};\\\", \\\"{x:1045,y:831,t:1527877094309};\\\", \\\"{x:1046,y:833,t:1527877094317};\\\", \\\"{x:1049,y:834,t:1527877094333};\\\", \\\"{x:1055,y:838,t:1527877094350};\\\", \\\"{x:1067,y:843,t:1527877094367};\\\", \\\"{x:1082,y:847,t:1527877094382};\\\", \\\"{x:1090,y:851,t:1527877094400};\\\", \\\"{x:1105,y:855,t:1527877094416};\\\", \\\"{x:1111,y:860,t:1527877094432};\\\", \\\"{x:1118,y:862,t:1527877094449};\\\", \\\"{x:1120,y:863,t:1527877094467};\\\", \\\"{x:1120,y:864,t:1527877094500};\\\", \\\"{x:1120,y:865,t:1527877094541};\\\", \\\"{x:1121,y:865,t:1527877099741};\\\", \\\"{x:1125,y:865,t:1527877099754};\\\", \\\"{x:1129,y:864,t:1527877099771};\\\", \\\"{x:1134,y:863,t:1527877099788};\\\", \\\"{x:1136,y:863,t:1527877099804};\\\", \\\"{x:1151,y:863,t:1527877099821};\\\", \\\"{x:1178,y:870,t:1527877099838};\\\", \\\"{x:1192,y:878,t:1527877099854};\\\", \\\"{x:1204,y:882,t:1527877099871};\\\", \\\"{x:1212,y:886,t:1527877099888};\\\", \\\"{x:1228,y:889,t:1527877099904};\\\", \\\"{x:1241,y:894,t:1527877099921};\\\", \\\"{x:1246,y:896,t:1527877099939};\\\", \\\"{x:1253,y:900,t:1527877099954};\\\", \\\"{x:1257,y:902,t:1527877099971};\\\", \\\"{x:1260,y:904,t:1527877099988};\\\", \\\"{x:1261,y:904,t:1527877100004};\\\", \\\"{x:1263,y:907,t:1527877100020};\\\", \\\"{x:1266,y:910,t:1527877100037};\\\", \\\"{x:1272,y:915,t:1527877100054};\\\", \\\"{x:1279,y:920,t:1527877100071};\\\", \\\"{x:1285,y:924,t:1527877100088};\\\", \\\"{x:1288,y:927,t:1527877100104};\\\", \\\"{x:1294,y:932,t:1527877100121};\\\", \\\"{x:1305,y:940,t:1527877100138};\\\", \\\"{x:1315,y:946,t:1527877100154};\\\", \\\"{x:1327,y:954,t:1527877100171};\\\", \\\"{x:1339,y:961,t:1527877100188};\\\", \\\"{x:1347,y:966,t:1527877100205};\\\", \\\"{x:1351,y:970,t:1527877100221};\\\", \\\"{x:1352,y:972,t:1527877100237};\\\", \\\"{x:1354,y:975,t:1527877100255};\\\", \\\"{x:1355,y:978,t:1527877100271};\\\", \\\"{x:1355,y:980,t:1527877100288};\\\", \\\"{x:1358,y:982,t:1527877100305};\\\", \\\"{x:1361,y:984,t:1527877100320};\\\", \\\"{x:1364,y:987,t:1527877100339};\\\", \\\"{x:1366,y:991,t:1527877100355};\\\", \\\"{x:1368,y:993,t:1527877100371};\\\", \\\"{x:1373,y:996,t:1527877100388};\\\", \\\"{x:1374,y:997,t:1527877100404};\\\", \\\"{x:1378,y:999,t:1527877100420};\\\", \\\"{x:1380,y:1001,t:1527877100437};\\\", \\\"{x:1382,y:1001,t:1527877100454};\\\", \\\"{x:1385,y:1002,t:1527877100470};\\\", \\\"{x:1386,y:1002,t:1527877100487};\\\", \\\"{x:1393,y:1003,t:1527877100504};\\\", \\\"{x:1395,y:1004,t:1527877100520};\\\", \\\"{x:1399,y:1004,t:1527877100537};\\\", \\\"{x:1406,y:1004,t:1527877100555};\\\", \\\"{x:1408,y:1004,t:1527877100570};\\\", \\\"{x:1409,y:1004,t:1527877100587};\\\", \\\"{x:1410,y:1004,t:1527877100605};\\\", \\\"{x:1411,y:1004,t:1527877100645};\\\", \\\"{x:1412,y:1004,t:1527877100693};\\\", \\\"{x:1414,y:1003,t:1527877100709};\\\", \\\"{x:1415,y:1002,t:1527877100720};\\\", \\\"{x:1417,y:1000,t:1527877100737};\\\", \\\"{x:1421,y:998,t:1527877100754};\\\", \\\"{x:1431,y:994,t:1527877100772};\\\", \\\"{x:1434,y:991,t:1527877100788};\\\", \\\"{x:1445,y:990,t:1527877100804};\\\", \\\"{x:1449,y:986,t:1527877100821};\\\", \\\"{x:1457,y:981,t:1527877100838};\\\", \\\"{x:1464,y:978,t:1527877100855};\\\", \\\"{x:1469,y:974,t:1527877100872};\\\", \\\"{x:1469,y:973,t:1527877100888};\\\", \\\"{x:1471,y:972,t:1527877100904};\\\", \\\"{x:1473,y:972,t:1527877100965};\\\", \\\"{x:1474,y:972,t:1527877100972};\\\", \\\"{x:1475,y:972,t:1527877101028};\\\", \\\"{x:1477,y:972,t:1527877101269};\\\", \\\"{x:1478,y:972,t:1527877101292};\\\", \\\"{x:1479,y:972,t:1527877101332};\\\", \\\"{x:1480,y:972,t:1527877101403};\\\", \\\"{x:1481,y:972,t:1527877101484};\\\", \\\"{x:1482,y:972,t:1527877101492};\\\", \\\"{x:1483,y:972,t:1527877101507};\\\", \\\"{x:1485,y:972,t:1527877101531};\\\", \\\"{x:1485,y:974,t:1527877101548};\\\", \\\"{x:1486,y:974,t:1527877101555};\\\", \\\"{x:1487,y:976,t:1527877101572};\\\", \\\"{x:1487,y:977,t:1527877101588};\\\", \\\"{x:1487,y:978,t:1527877101605};\\\", \\\"{x:1488,y:980,t:1527877101621};\\\", \\\"{x:1488,y:983,t:1527877101638};\\\", \\\"{x:1488,y:987,t:1527877101656};\\\", \\\"{x:1487,y:989,t:1527877101672};\\\", \\\"{x:1485,y:990,t:1527877101688};\\\", \\\"{x:1485,y:987,t:1527877101789};\\\", \\\"{x:1485,y:973,t:1527877101807};\\\", \\\"{x:1485,y:962,t:1527877101823};\\\", \\\"{x:1482,y:946,t:1527877101839};\\\", \\\"{x:1480,y:926,t:1527877101856};\\\", \\\"{x:1474,y:908,t:1527877101872};\\\", \\\"{x:1464,y:893,t:1527877101889};\\\", \\\"{x:1458,y:878,t:1527877101906};\\\", \\\"{x:1454,y:867,t:1527877101922};\\\", \\\"{x:1449,y:857,t:1527877101939};\\\", \\\"{x:1448,y:852,t:1527877101956};\\\", \\\"{x:1448,y:851,t:1527877101972};\\\", \\\"{x:1448,y:849,t:1527877101998};\\\", \\\"{x:1448,y:847,t:1527877102012};\\\", \\\"{x:1448,y:845,t:1527877102028};\\\", \\\"{x:1448,y:847,t:1527877102228};\\\", \\\"{x:1448,y:851,t:1527877102239};\\\", \\\"{x:1451,y:860,t:1527877102256};\\\", \\\"{x:1451,y:862,t:1527877102273};\\\", \\\"{x:1452,y:865,t:1527877102289};\\\", \\\"{x:1453,y:866,t:1527877102404};\\\", \\\"{x:1457,y:866,t:1527877102423};\\\", \\\"{x:1460,y:866,t:1527877102440};\\\", \\\"{x:1461,y:866,t:1527877102456};\\\", \\\"{x:1464,y:864,t:1527877102473};\\\", \\\"{x:1466,y:861,t:1527877102491};\\\", \\\"{x:1468,y:859,t:1527877102506};\\\", \\\"{x:1468,y:858,t:1527877102525};\\\", \\\"{x:1470,y:857,t:1527877102540};\\\", \\\"{x:1470,y:855,t:1527877102556};\\\", \\\"{x:1471,y:854,t:1527877102573};\\\", \\\"{x:1474,y:851,t:1527877102590};\\\", \\\"{x:1475,y:849,t:1527877102606};\\\", \\\"{x:1475,y:848,t:1527877102622};\\\", \\\"{x:1477,y:846,t:1527877102640};\\\", \\\"{x:1478,y:843,t:1527877102656};\\\", \\\"{x:1480,y:841,t:1527877102672};\\\", \\\"{x:1481,y:839,t:1527877102690};\\\", \\\"{x:1482,y:838,t:1527877102706};\\\", \\\"{x:1484,y:835,t:1527877102723};\\\", \\\"{x:1485,y:835,t:1527877102740};\\\", \\\"{x:1485,y:834,t:1527877102759};\\\", \\\"{x:1487,y:833,t:1527877102773};\\\", \\\"{x:1487,y:832,t:1527877102798};\\\", \\\"{x:1488,y:832,t:1527877102806};\\\", \\\"{x:1489,y:831,t:1527877102845};\\\", \\\"{x:1487,y:831,t:1527877103277};\\\", \\\"{x:1486,y:831,t:1527877103291};\\\", \\\"{x:1485,y:831,t:1527877103307};\\\", \\\"{x:1484,y:831,t:1527877103323};\\\", \\\"{x:1480,y:831,t:1527877119879};\\\", \\\"{x:1470,y:831,t:1527877119891};\\\", \\\"{x:1419,y:822,t:1527877119906};\\\", \\\"{x:1324,y:792,t:1527877119923};\\\", \\\"{x:1224,y:772,t:1527877119939};\\\", \\\"{x:1138,y:747,t:1527877119956};\\\", \\\"{x:1093,y:735,t:1527877119973};\\\", \\\"{x:1054,y:724,t:1527877119989};\\\", \\\"{x:1022,y:718,t:1527877120006};\\\", \\\"{x:996,y:708,t:1527877120023};\\\", \\\"{x:950,y:693,t:1527877120040};\\\", \\\"{x:900,y:685,t:1527877120056};\\\", \\\"{x:860,y:673,t:1527877120074};\\\", \\\"{x:816,y:662,t:1527877120090};\\\", \\\"{x:758,y:646,t:1527877120106};\\\", \\\"{x:690,y:632,t:1527877120125};\\\", \\\"{x:629,y:618,t:1527877120139};\\\", \\\"{x:595,y:608,t:1527877120156};\\\", \\\"{x:574,y:606,t:1527877120190};\\\", \\\"{x:573,y:605,t:1527877120246};\\\", \\\"{x:573,y:604,t:1527877120257};\\\", \\\"{x:573,y:600,t:1527877120272};\\\", \\\"{x:573,y:595,t:1527877120290};\\\", \\\"{x:573,y:590,t:1527877120307};\\\", \\\"{x:574,y:586,t:1527877120323};\\\", \\\"{x:576,y:581,t:1527877120340};\\\", \\\"{x:582,y:579,t:1527877120356};\\\", \\\"{x:594,y:574,t:1527877120373};\\\", \\\"{x:614,y:568,t:1527877120390};\\\", \\\"{x:632,y:562,t:1527877120406};\\\", \\\"{x:652,y:560,t:1527877120423};\\\", \\\"{x:666,y:558,t:1527877120439};\\\", \\\"{x:688,y:555,t:1527877120456};\\\", \\\"{x:719,y:553,t:1527877120473};\\\", \\\"{x:748,y:551,t:1527877120490};\\\", \\\"{x:772,y:550,t:1527877120507};\\\", \\\"{x:788,y:547,t:1527877120523};\\\", \\\"{x:799,y:546,t:1527877120540};\\\", \\\"{x:802,y:546,t:1527877120556};\\\", \\\"{x:802,y:545,t:1527877120573};\\\", \\\"{x:803,y:543,t:1527877120622};\\\", \\\"{x:803,y:542,t:1527877120638};\\\", \\\"{x:805,y:540,t:1527877120646};\\\", \\\"{x:806,y:540,t:1527877120656};\\\", \\\"{x:807,y:539,t:1527877120674};\\\", \\\"{x:807,y:538,t:1527877120691};\\\", \\\"{x:807,y:537,t:1527877120706};\\\", \\\"{x:807,y:536,t:1527877120723};\\\", \\\"{x:807,y:535,t:1527877120740};\\\", \\\"{x:810,y:530,t:1527877120757};\\\", \\\"{x:814,y:527,t:1527877120774};\\\", \\\"{x:815,y:526,t:1527877120822};\\\", \\\"{x:817,y:526,t:1527877120838};\\\", \\\"{x:819,y:525,t:1527877120862};\\\", \\\"{x:820,y:525,t:1527877120874};\\\", \\\"{x:821,y:523,t:1527877120891};\\\", \\\"{x:823,y:522,t:1527877120907};\\\", \\\"{x:824,y:522,t:1527877120924};\\\", \\\"{x:824,y:521,t:1527877121000};\\\", \\\"{x:826,y:519,t:1527877121015};\\\", \\\"{x:826,y:519,t:1527877121112};\\\", \\\"{x:828,y:520,t:1527877121415};\\\", \\\"{x:834,y:529,t:1527877121425};\\\", \\\"{x:839,y:542,t:1527877121441};\\\", \\\"{x:850,y:561,t:1527877121457};\\\", \\\"{x:874,y:583,t:1527877121475};\\\", \\\"{x:921,y:621,t:1527877121491};\\\", \\\"{x:979,y:660,t:1527877121508};\\\", \\\"{x:1002,y:679,t:1527877121524};\\\", \\\"{x:1089,y:728,t:1527877121541};\\\", \\\"{x:1146,y:768,t:1527877121558};\\\", \\\"{x:1204,y:813,t:1527877121574};\\\", \\\"{x:1237,y:831,t:1527877121591};\\\", \\\"{x:1251,y:841,t:1527877121607};\\\", \\\"{x:1264,y:848,t:1527877121624};\\\", \\\"{x:1275,y:852,t:1527877121641};\\\", \\\"{x:1284,y:854,t:1527877121657};\\\", \\\"{x:1289,y:856,t:1527877121674};\\\", \\\"{x:1291,y:857,t:1527877121691};\\\", \\\"{x:1301,y:856,t:1527877121708};\\\", \\\"{x:1310,y:855,t:1527877121724};\\\", \\\"{x:1324,y:849,t:1527877121741};\\\", \\\"{x:1362,y:839,t:1527877121759};\\\", \\\"{x:1387,y:826,t:1527877121774};\\\", \\\"{x:1406,y:809,t:1527877121791};\\\", \\\"{x:1423,y:797,t:1527877121808};\\\", \\\"{x:1430,y:792,t:1527877121824};\\\", \\\"{x:1434,y:792,t:1527877121841};\\\", \\\"{x:1437,y:792,t:1527877121858};\\\", \\\"{x:1439,y:792,t:1527877121874};\\\", \\\"{x:1440,y:792,t:1527877121895};\\\", \\\"{x:1444,y:793,t:1527877121911};\\\", \\\"{x:1445,y:798,t:1527877121924};\\\", \\\"{x:1450,y:805,t:1527877121942};\\\", \\\"{x:1455,y:812,t:1527877121959};\\\", \\\"{x:1456,y:813,t:1527877121974};\\\", \\\"{x:1457,y:815,t:1527877121991};\\\", \\\"{x:1458,y:817,t:1527877122007};\\\", \\\"{x:1459,y:820,t:1527877122030};\\\", \\\"{x:1460,y:822,t:1527877122041};\\\", \\\"{x:1464,y:828,t:1527877122058};\\\", \\\"{x:1468,y:832,t:1527877122075};\\\", \\\"{x:1469,y:833,t:1527877122091};\\\", \\\"{x:1470,y:835,t:1527877122108};\\\", \\\"{x:1471,y:835,t:1527877122183};\\\", \\\"{x:1473,y:835,t:1527877122191};\\\", \\\"{x:1474,y:835,t:1527877122223};\\\", \\\"{x:1476,y:833,t:1527877122239};\\\", \\\"{x:1476,y:832,t:1527877122247};\\\", \\\"{x:1476,y:831,t:1527877122367};\\\", \\\"{x:1477,y:830,t:1527877122390};\\\", \\\"{x:1478,y:829,t:1527877122408};\\\", \\\"{x:1479,y:829,t:1527877122425};\\\", \\\"{x:1480,y:829,t:1527877122775};\\\", \\\"{x:1481,y:828,t:1527877122793};\\\", \\\"{x:1483,y:828,t:1527877122815};\\\", \\\"{x:1483,y:827,t:1527877122830};\\\", \\\"{x:1482,y:827,t:1527877123191};\\\", \\\"{x:1481,y:827,t:1527877123207};\\\", \\\"{x:1480,y:828,t:1527877123223};\\\", \\\"{x:1478,y:831,t:1527877123415};\\\", \\\"{x:1478,y:833,t:1527877123427};\\\", \\\"{x:1478,y:840,t:1527877123444};\\\", \\\"{x:1478,y:847,t:1527877123460};\\\", \\\"{x:1478,y:851,t:1527877123477};\\\", \\\"{x:1478,y:859,t:1527877123493};\\\", \\\"{x:1480,y:866,t:1527877123509};\\\", \\\"{x:1482,y:876,t:1527877123527};\\\", \\\"{x:1485,y:885,t:1527877123543};\\\", \\\"{x:1485,y:891,t:1527877123560};\\\", \\\"{x:1486,y:897,t:1527877123577};\\\", \\\"{x:1488,y:902,t:1527877123593};\\\", \\\"{x:1489,y:904,t:1527877123609};\\\", \\\"{x:1489,y:907,t:1527877123626};\\\", \\\"{x:1489,y:908,t:1527877123643};\\\", \\\"{x:1490,y:911,t:1527877123660};\\\", \\\"{x:1490,y:913,t:1527877123677};\\\", \\\"{x:1490,y:915,t:1527877123694};\\\", \\\"{x:1492,y:917,t:1527877123709};\\\", \\\"{x:1492,y:915,t:1527877123935};\\\", \\\"{x:1491,y:913,t:1527877123944};\\\", \\\"{x:1491,y:911,t:1527877123960};\\\", \\\"{x:1491,y:910,t:1527877123977};\\\", \\\"{x:1489,y:909,t:1527877123993};\\\", \\\"{x:1489,y:904,t:1527877124011};\\\", \\\"{x:1487,y:895,t:1527877124027};\\\", \\\"{x:1487,y:891,t:1527877124044};\\\", \\\"{x:1486,y:887,t:1527877124060};\\\", \\\"{x:1486,y:885,t:1527877124077};\\\", \\\"{x:1485,y:884,t:1527877124094};\\\", \\\"{x:1485,y:882,t:1527877132271};\\\", \\\"{x:1483,y:877,t:1527877132727};\\\", \\\"{x:1480,y:866,t:1527877132734};\\\", \\\"{x:1452,y:823,t:1527877132751};\\\", \\\"{x:1430,y:785,t:1527877132768};\\\", \\\"{x:1411,y:754,t:1527877132784};\\\", \\\"{x:1388,y:718,t:1527877132801};\\\", \\\"{x:1370,y:702,t:1527877132817};\\\", \\\"{x:1357,y:682,t:1527877132833};\\\", \\\"{x:1348,y:670,t:1527877132850};\\\", \\\"{x:1342,y:658,t:1527877132868};\\\", \\\"{x:1337,y:648,t:1527877132883};\\\", \\\"{x:1334,y:640,t:1527877132900};\\\", \\\"{x:1333,y:634,t:1527877132917};\\\", \\\"{x:1331,y:630,t:1527877132934};\\\", \\\"{x:1331,y:628,t:1527877132950};\\\", \\\"{x:1330,y:625,t:1527877132968};\\\", \\\"{x:1330,y:621,t:1527877132985};\\\", \\\"{x:1330,y:617,t:1527877133001};\\\", \\\"{x:1330,y:609,t:1527877133017};\\\", \\\"{x:1330,y:602,t:1527877133034};\\\", \\\"{x:1338,y:586,t:1527877133051};\\\", \\\"{x:1343,y:579,t:1527877133068};\\\", \\\"{x:1350,y:570,t:1527877133085};\\\", \\\"{x:1356,y:562,t:1527877133101};\\\", \\\"{x:1359,y:558,t:1527877133118};\\\", \\\"{x:1360,y:557,t:1527877133134};\\\", \\\"{x:1360,y:556,t:1527877133150};\\\", \\\"{x:1360,y:555,t:1527877133168};\\\", \\\"{x:1361,y:554,t:1527877133184};\\\", \\\"{x:1362,y:554,t:1527877133201};\\\", \\\"{x:1363,y:554,t:1527877133218};\\\", \\\"{x:1365,y:556,t:1527877133440};\\\", \\\"{x:1366,y:556,t:1527877133451};\\\", \\\"{x:1368,y:558,t:1527877133468};\\\", \\\"{x:1368,y:559,t:1527877133485};\\\", \\\"{x:1371,y:559,t:1527877133501};\\\", \\\"{x:1378,y:559,t:1527877133518};\\\", \\\"{x:1384,y:559,t:1527877133535};\\\", \\\"{x:1389,y:559,t:1527877133552};\\\", \\\"{x:1395,y:559,t:1527877133568};\\\", \\\"{x:1399,y:559,t:1527877133584};\\\", \\\"{x:1403,y:559,t:1527877133602};\\\", \\\"{x:1404,y:559,t:1527877133622};\\\", \\\"{x:1405,y:559,t:1527877133646};\\\", \\\"{x:1406,y:559,t:1527877133662};\\\", \\\"{x:1408,y:559,t:1527877133671};\\\", \\\"{x:1411,y:559,t:1527877133686};\\\", \\\"{x:1412,y:559,t:1527877133702};\\\", \\\"{x:1414,y:559,t:1527877133717};\\\", \\\"{x:1415,y:559,t:1527877133735};\\\", \\\"{x:1416,y:559,t:1527877134127};\\\", \\\"{x:1419,y:559,t:1527877134136};\\\", \\\"{x:1425,y:559,t:1527877134152};\\\", \\\"{x:1429,y:559,t:1527877134169};\\\", \\\"{x:1434,y:560,t:1527877134186};\\\", \\\"{x:1436,y:560,t:1527877134202};\\\", \\\"{x:1442,y:562,t:1527877134219};\\\", \\\"{x:1443,y:562,t:1527877134271};\\\", \\\"{x:1444,y:562,t:1527877134286};\\\", \\\"{x:1448,y:563,t:1527877134302};\\\", \\\"{x:1453,y:564,t:1527877134319};\\\", \\\"{x:1458,y:564,t:1527877134336};\\\", \\\"{x:1462,y:564,t:1527877134352};\\\", \\\"{x:1465,y:565,t:1527877134369};\\\", \\\"{x:1469,y:566,t:1527877134386};\\\", \\\"{x:1473,y:567,t:1527877134403};\\\", \\\"{x:1477,y:567,t:1527877134419};\\\", \\\"{x:1483,y:567,t:1527877134436};\\\", \\\"{x:1484,y:568,t:1527877134452};\\\", \\\"{x:1487,y:569,t:1527877134470};\\\", \\\"{x:1492,y:570,t:1527877134486};\\\", \\\"{x:1493,y:570,t:1527877134503};\\\", \\\"{x:1494,y:571,t:1527877134520};\\\", \\\"{x:1495,y:571,t:1527877134536};\\\", \\\"{x:1497,y:571,t:1527877134553};\\\", \\\"{x:1499,y:571,t:1527877134569};\\\", \\\"{x:1500,y:571,t:1527877134586};\\\", \\\"{x:1501,y:571,t:1527877134603};\\\", \\\"{x:1502,y:571,t:1527877134623};\\\", \\\"{x:1500,y:572,t:1527877135279};\\\", \\\"{x:1498,y:572,t:1527877135286};\\\", \\\"{x:1494,y:572,t:1527877135303};\\\", \\\"{x:1489,y:572,t:1527877135320};\\\", \\\"{x:1487,y:572,t:1527877135336};\\\", \\\"{x:1485,y:572,t:1527877135353};\\\", \\\"{x:1484,y:572,t:1527877135370};\\\", \\\"{x:1483,y:573,t:1527877135387};\\\", \\\"{x:1482,y:573,t:1527877135402};\\\", \\\"{x:1481,y:573,t:1527877135420};\\\", \\\"{x:1480,y:573,t:1527877135486};\\\", \\\"{x:1479,y:574,t:1527877135502};\\\", \\\"{x:1474,y:575,t:1527877135519};\\\", \\\"{x:1473,y:575,t:1527877135536};\\\", \\\"{x:1469,y:575,t:1527877135553};\\\", \\\"{x:1461,y:576,t:1527877135570};\\\", \\\"{x:1450,y:578,t:1527877135586};\\\", \\\"{x:1434,y:581,t:1527877135602};\\\", \\\"{x:1422,y:581,t:1527877135619};\\\", \\\"{x:1412,y:582,t:1527877135637};\\\", \\\"{x:1407,y:582,t:1527877135653};\\\", \\\"{x:1401,y:583,t:1527877135670};\\\", \\\"{x:1399,y:583,t:1527877135686};\\\", \\\"{x:1396,y:583,t:1527877135752};\\\", \\\"{x:1392,y:583,t:1527877135758};\\\", \\\"{x:1389,y:584,t:1527877135770};\\\", \\\"{x:1380,y:585,t:1527877135787};\\\", \\\"{x:1375,y:585,t:1527877135803};\\\", \\\"{x:1365,y:586,t:1527877135820};\\\", \\\"{x:1357,y:586,t:1527877135836};\\\", \\\"{x:1351,y:586,t:1527877135854};\\\", \\\"{x:1346,y:586,t:1527877135869};\\\", \\\"{x:1345,y:586,t:1527877135887};\\\", \\\"{x:1343,y:586,t:1527877135934};\\\", \\\"{x:1342,y:586,t:1527877136071};\\\", \\\"{x:1341,y:586,t:1527877136087};\\\", \\\"{x:1338,y:584,t:1527877136104};\\\", \\\"{x:1336,y:581,t:1527877136120};\\\", \\\"{x:1335,y:579,t:1527877136137};\\\", \\\"{x:1334,y:577,t:1527877136154};\\\", \\\"{x:1334,y:575,t:1527877136170};\\\", \\\"{x:1334,y:574,t:1527877136186};\\\", \\\"{x:1334,y:573,t:1527877136204};\\\", \\\"{x:1334,y:572,t:1527877136220};\\\", \\\"{x:1334,y:570,t:1527877136238};\\\", \\\"{x:1334,y:569,t:1527877136287};\\\", \\\"{x:1334,y:568,t:1527877136391};\\\", \\\"{x:1334,y:567,t:1527877136405};\\\", \\\"{x:1334,y:566,t:1527877136430};\\\", \\\"{x:1334,y:565,t:1527877136486};\\\", \\\"{x:1334,y:564,t:1527877136517};\\\", \\\"{x:1334,y:563,t:1527877136647};\\\", \\\"{x:1335,y:562,t:1527877136711};\\\", \\\"{x:1338,y:562,t:1527877136721};\\\", \\\"{x:1347,y:563,t:1527877136738};\\\", \\\"{x:1361,y:564,t:1527877136755};\\\", \\\"{x:1370,y:567,t:1527877136771};\\\", \\\"{x:1377,y:568,t:1527877136788};\\\", \\\"{x:1381,y:568,t:1527877136804};\\\", \\\"{x:1383,y:568,t:1527877136821};\\\", \\\"{x:1384,y:568,t:1527877136838};\\\", \\\"{x:1386,y:568,t:1527877136854};\\\", \\\"{x:1386,y:570,t:1527877136871};\\\", \\\"{x:1387,y:570,t:1527877136911};\\\", \\\"{x:1388,y:570,t:1527877136927};\\\", \\\"{x:1389,y:570,t:1527877137000};\\\", \\\"{x:1390,y:570,t:1527877137006};\\\", \\\"{x:1393,y:570,t:1527877137021};\\\", \\\"{x:1402,y:569,t:1527877137038};\\\", \\\"{x:1407,y:568,t:1527877137055};\\\", \\\"{x:1412,y:568,t:1527877137071};\\\", \\\"{x:1413,y:566,t:1527877137088};\\\", \\\"{x:1415,y:566,t:1527877137105};\\\", \\\"{x:1416,y:566,t:1527877137121};\\\", \\\"{x:1416,y:565,t:1527877137138};\\\", \\\"{x:1417,y:565,t:1527877137155};\\\", \\\"{x:1418,y:564,t:1527877137175};\\\", \\\"{x:1419,y:564,t:1527877137231};\\\", \\\"{x:1421,y:564,t:1527877137320};\\\", \\\"{x:1422,y:563,t:1527877137337};\\\", \\\"{x:1423,y:563,t:1527877137357};\\\", \\\"{x:1426,y:563,t:1527877137371};\\\", \\\"{x:1430,y:561,t:1527877137388};\\\", \\\"{x:1436,y:560,t:1527877137405};\\\", \\\"{x:1441,y:560,t:1527877137421};\\\", \\\"{x:1459,y:555,t:1527877137437};\\\", \\\"{x:1468,y:552,t:1527877137455};\\\", \\\"{x:1474,y:550,t:1527877137472};\\\", \\\"{x:1478,y:547,t:1527877137488};\\\", \\\"{x:1481,y:546,t:1527877137505};\\\", \\\"{x:1482,y:546,t:1527877137781};\\\", \\\"{x:1483,y:547,t:1527877137790};\\\", \\\"{x:1483,y:548,t:1527877137806};\\\", \\\"{x:1483,y:549,t:1527877137821};\\\", \\\"{x:1483,y:550,t:1527877137846};\\\", \\\"{x:1483,y:551,t:1527877137927};\\\", \\\"{x:1483,y:552,t:1527877138015};\\\", \\\"{x:1483,y:553,t:1527877138031};\\\", \\\"{x:1483,y:555,t:1527877138038};\\\", \\\"{x:1480,y:563,t:1527877138055};\\\", \\\"{x:1474,y:570,t:1527877138072};\\\", \\\"{x:1458,y:586,t:1527877138089};\\\", \\\"{x:1431,y:605,t:1527877138105};\\\", \\\"{x:1363,y:634,t:1527877138122};\\\", \\\"{x:1328,y:644,t:1527877138139};\\\", \\\"{x:1241,y:673,t:1527877138155};\\\", \\\"{x:1158,y:696,t:1527877138172};\\\", \\\"{x:1065,y:715,t:1527877138189};\\\", \\\"{x:994,y:731,t:1527877138205};\\\", \\\"{x:912,y:742,t:1527877138222};\\\", \\\"{x:846,y:748,t:1527877138239};\\\", \\\"{x:824,y:760,t:1527877138256};\\\", \\\"{x:795,y:770,t:1527877138272};\\\", \\\"{x:770,y:778,t:1527877138289};\\\", \\\"{x:755,y:784,t:1527877138306};\\\", \\\"{x:735,y:792,t:1527877138322};\\\", \\\"{x:717,y:796,t:1527877138339};\\\", \\\"{x:701,y:803,t:1527877138356};\\\", \\\"{x:691,y:811,t:1527877138371};\\\", \\\"{x:680,y:818,t:1527877138388};\\\", \\\"{x:671,y:821,t:1527877138405};\\\", \\\"{x:669,y:822,t:1527877138422};\\\", \\\"{x:660,y:822,t:1527877138438};\\\", \\\"{x:651,y:817,t:1527877138456};\\\", \\\"{x:643,y:810,t:1527877138472};\\\", \\\"{x:619,y:792,t:1527877138488};\\\", \\\"{x:594,y:778,t:1527877138505};\\\", \\\"{x:563,y:768,t:1527877138522};\\\", \\\"{x:550,y:755,t:1527877138540};\\\", \\\"{x:525,y:748,t:1527877138556};\\\", \\\"{x:521,y:747,t:1527877138571};\\\", \\\"{x:520,y:746,t:1527877138588};\\\", \\\"{x:520,y:745,t:1527877139183};\\\", \\\"{x:522,y:740,t:1527877139191};\\\", \\\"{x:524,y:737,t:1527877139205};\\\", \\\"{x:529,y:732,t:1527877139222};\\\", \\\"{x:532,y:728,t:1527877139238};\\\", \\\"{x:535,y:723,t:1527877139254};\\\", \\\"{x:538,y:719,t:1527877139271};\\\", \\\"{x:542,y:713,t:1527877139289};\\\", \\\"{x:546,y:709,t:1527877139305};\\\", \\\"{x:547,y:706,t:1527877139322};\\\", \\\"{x:550,y:702,t:1527877139339};\\\", \\\"{x:550,y:696,t:1527877139356};\\\", \\\"{x:550,y:692,t:1527877139372};\\\", \\\"{x:551,y:688,t:1527877139389};\\\", \\\"{x:554,y:683,t:1527877139406};\\\", \\\"{x:554,y:682,t:1527877139422};\\\", \\\"{x:555,y:680,t:1527877139567};\\\", \\\"{x:557,y:677,t:1527877139574};\\\", \\\"{x:559,y:675,t:1527877139589};\\\", \\\"{x:574,y:660,t:1527877139606};\\\", \\\"{x:589,y:649,t:1527877139622};\\\", \\\"{x:610,y:642,t:1527877139639};\\\", \\\"{x:633,y:632,t:1527877139655};\\\", \\\"{x:657,y:623,t:1527877139672};\\\", \\\"{x:690,y:610,t:1527877139688};\\\", \\\"{x:719,y:603,t:1527877139706};\\\", \\\"{x:753,y:594,t:1527877139722};\\\", \\\"{x:782,y:586,t:1527877139739};\\\", \\\"{x:811,y:582,t:1527877139756};\\\", \\\"{x:830,y:578,t:1527877139772};\\\", \\\"{x:841,y:577,t:1527877139789};\\\", \\\"{x:842,y:577,t:1527877139806};\\\", \\\"{x:845,y:577,t:1527877139823};\\\", \\\"{x:845,y:578,t:1527877139862};\\\", \\\"{x:845,y:579,t:1527877139872};\\\", \\\"{x:844,y:582,t:1527877139894};\\\", \\\"{x:844,y:584,t:1527877139906};\\\", \\\"{x:844,y:585,t:1527877139922};\\\", \\\"{x:842,y:588,t:1527877139938};\\\", \\\"{x:840,y:590,t:1527877139956};\\\", \\\"{x:837,y:594,t:1527877139972};\\\" ] }, { \\\"rt\\\": 25378, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 771143, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look for points that start at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7336, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 779484, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11550, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 792056, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 17334, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 810487, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"41Y1H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"41Y1H\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 310, dom: 793, initialDom: 844",
  "javascriptErrors": []
}