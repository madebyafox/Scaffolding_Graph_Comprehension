var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8055dbb4e49f96d516c7354cc308ecb2",
  "created": "2018-05-22T13:13:06.8252098-07:00",
  "lastActivity": "2018-05-22T13:13:32.9522098-07:00",
  "pageViews": [
    {
      "id": "05220737b4768200fec1a2010a6b47272b0d8306",
      "startTime": "2018-05-22T13:13:06.8252098-07:00",
      "endTime": "2018-05-22T13:13:32.9522098-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 26127,
      "engagementTime": 26076,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26127,
  "engagementTime": 26076,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=39GMD",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "79d285ed6cc4345112ae6c635f7f0119",
  "gdpr": false
}