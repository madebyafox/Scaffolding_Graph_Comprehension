var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060150415fe937caef528a12f9b9d8a91540934e"] = {
  "startTime": "2018-06-01T17:06:50.8905235Z",
  "websitePageUrl": "/",
  "visitTime": 100680,
  "engagementTime": 49945,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "22c5c306496bcc9a3386de67a95abf44",
    "created": "2018-06-01T17:06:50.8421057+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0ec5d0c7796d74a61f1b388404a880ab",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/22c5c306496bcc9a3386de67a95abf44/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 240,
      "e": 240,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10001,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 39901,
      "e": 5102,
      "ty": 2,
      "x": 238,
      "y": 4
    },
    {
      "t": 40001,
      "e": 5202,
      "ty": 2,
      "x": 236,
      "y": 24
    },
    {
      "t": 40001,
      "e": 5202,
      "ty": 41,
      "x": 7851,
      "y": 973,
      "ta": "html > body"
    },
    {
      "t": 40100,
      "e": 5301,
      "ty": 2,
      "x": 244,
      "y": 51
    },
    {
      "t": 40100,
      "e": 5301,
      "ty": 1,
      "x": 0,
      "y": 3
    },
    {
      "t": 40201,
      "e": 5402,
      "ty": 2,
      "x": 248,
      "y": 76
    },
    {
      "t": 40201,
      "e": 5402,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 40251,
      "e": 5452,
      "ty": 41,
      "x": 8265,
      "y": 4137,
      "ta": "html > body"
    },
    {
      "t": 40301,
      "e": 5502,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 40401,
      "e": 5602,
      "ty": 2,
      "x": 243,
      "y": 83
    },
    {
      "t": 40501,
      "e": 5702,
      "ty": 2,
      "x": 240,
      "y": 85
    },
    {
      "t": 40502,
      "e": 5703,
      "ty": 41,
      "x": 7989,
      "y": 4685,
      "ta": "html > body"
    },
    {
      "t": 40751,
      "e": 5952,
      "ty": 41,
      "x": 7645,
      "y": 5476,
      "ta": "html > body"
    },
    {
      "t": 40801,
      "e": 6002,
      "ty": 2,
      "x": 196,
      "y": 261
    },
    {
      "t": 40901,
      "e": 6102,
      "ty": 2,
      "x": 212,
      "y": 333
    },
    {
      "t": 41001,
      "e": 6202,
      "ty": 41,
      "x": 7025,
      "y": 19776,
      "ta": "html > body"
    },
    {
      "t": 41300,
      "e": 6501,
      "ty": 2,
      "x": 212,
      "y": 337
    },
    {
      "t": 41401,
      "e": 6602,
      "ty": 2,
      "x": 641,
      "y": 665
    },
    {
      "t": 41461,
      "e": 6662,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 41501,
      "e": 6702,
      "ty": 2,
      "x": 1089,
      "y": 1093
    },
    {
      "t": 41701,
      "e": 6902,
      "ty": 2,
      "x": 1466,
      "y": 969
    },
    {
      "t": 41751,
      "e": 6952,
      "ty": 41,
      "x": 59008,
      "y": 63609,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 41801,
      "e": 7002,
      "ty": 2,
      "x": 1415,
      "y": 900
    },
    {
      "t": 41901,
      "e": 7102,
      "ty": 2,
      "x": 1290,
      "y": 869
    },
    {
      "t": 42001,
      "e": 7202,
      "ty": 2,
      "x": 1188,
      "y": 863
    },
    {
      "t": 42002,
      "e": 7203,
      "ty": 41,
      "x": 45246,
      "y": 58694,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42101,
      "e": 7302,
      "ty": 2,
      "x": 1135,
      "y": 813
    },
    {
      "t": 42201,
      "e": 7402,
      "ty": 2,
      "x": 1118,
      "y": 795
    },
    {
      "t": 42251,
      "e": 7452,
      "ty": 41,
      "x": 41423,
      "y": 53124,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42401,
      "e": 7602,
      "ty": 2,
      "x": 1052,
      "y": 752
    },
    {
      "t": 42501,
      "e": 7702,
      "ty": 2,
      "x": 887,
      "y": 653
    },
    {
      "t": 42501,
      "e": 7702,
      "ty": 41,
      "x": 28808,
      "y": 41491,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42601,
      "e": 7802,
      "ty": 2,
      "x": 869,
      "y": 639
    },
    {
      "t": 42701,
      "e": 7902,
      "ty": 2,
      "x": 826,
      "y": 610
    },
    {
      "t": 42752,
      "e": 7953,
      "ty": 41,
      "x": 24329,
      "y": 36740,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 42801,
      "e": 8002,
      "ty": 2,
      "x": 774,
      "y": 576
    },
    {
      "t": 42901,
      "e": 8102,
      "ty": 2,
      "x": 695,
      "y": 462
    },
    {
      "t": 43001,
      "e": 8202,
      "ty": 41,
      "x": 18322,
      "y": 25845,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 44559,
      "e": 9760,
      "ty": 3,
      "x": 695,
      "y": 462,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 44686,
      "e": 9887,
      "ty": 4,
      "x": 18322,
      "y": 25845,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 44687,
      "e": 9888,
      "ty": 5,
      "x": 695,
      "y": 462,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 45801,
      "e": 11002,
      "ty": 2,
      "x": 641,
      "y": 463
    },
    {
      "t": 45902,
      "e": 11103,
      "ty": 2,
      "x": 565,
      "y": 456
    },
    {
      "t": 46001,
      "e": 11202,
      "ty": 41,
      "x": 11222,
      "y": 25353,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 46138,
      "e": 11339,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 47242,
      "e": 12443,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 47901,
      "e": 13102,
      "ty": 2,
      "x": 592,
      "y": 481
    },
    {
      "t": 48001,
      "e": 13202,
      "ty": 2,
      "x": 619,
      "y": 511
    },
    {
      "t": 48002,
      "e": 13203,
      "ty": 41,
      "x": 16015,
      "y": 41869,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 48101,
      "e": 13302,
      "ty": 2,
      "x": 794,
      "y": 650
    },
    {
      "t": 48201,
      "e": 13402,
      "ty": 2,
      "x": 1011,
      "y": 756
    },
    {
      "t": 48251,
      "e": 13452,
      "ty": 41,
      "x": 38449,
      "y": 28086,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 48301,
      "e": 13502,
      "ty": 2,
      "x": 1087,
      "y": 808
    },
    {
      "t": 48401,
      "e": 13602,
      "ty": 2,
      "x": 1073,
      "y": 797
    },
    {
      "t": 48501,
      "e": 13702,
      "ty": 2,
      "x": 958,
      "y": 814
    },
    {
      "t": 48501,
      "e": 13702,
      "ty": 41,
      "x": 32693,
      "y": 42129,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 48602,
      "e": 13803,
      "ty": 2,
      "x": 841,
      "y": 853
    },
    {
      "t": 48702,
      "e": 13903,
      "ty": 2,
      "x": 826,
      "y": 869
    },
    {
      "t": 48752,
      "e": 13953,
      "ty": 41,
      "x": 4737,
      "y": 41704,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 48801,
      "e": 14002,
      "ty": 2,
      "x": 826,
      "y": 872
    },
    {
      "t": 48901,
      "e": 14102,
      "ty": 2,
      "x": 824,
      "y": 872
    },
    {
      "t": 48949,
      "e": 14150,
      "ty": 3,
      "x": 823,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49002,
      "e": 14203,
      "ty": 2,
      "x": 822,
      "y": 872
    },
    {
      "t": 49002,
      "e": 14203,
      "ty": 41,
      "x": 60824,
      "y": 45874,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49038,
      "e": 14239,
      "ty": 4,
      "x": 60824,
      "y": 45874,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49038,
      "e": 14239,
      "ty": 5,
      "x": 822,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49040,
      "e": 14241,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 49046,
      "e": 14247,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 49202,
      "e": 14403,
      "ty": 2,
      "x": 837,
      "y": 893
    },
    {
      "t": 49252,
      "e": 14453,
      "ty": 41,
      "x": 27970,
      "y": 61328,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49301,
      "e": 14502,
      "ty": 2,
      "x": 885,
      "y": 960
    },
    {
      "t": 49402,
      "e": 14603,
      "ty": 2,
      "x": 890,
      "y": 962
    },
    {
      "t": 49502,
      "e": 14703,
      "ty": 2,
      "x": 896,
      "y": 966
    },
    {
      "t": 49502,
      "e": 14703,
      "ty": 41,
      "x": 29643,
      "y": 64675,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49589,
      "e": 14790,
      "ty": 6,
      "x": 912,
      "y": 979,
      "ta": "#start"
    },
    {
      "t": 49602,
      "e": 14803,
      "ty": 2,
      "x": 912,
      "y": 979
    },
    {
      "t": 49701,
      "e": 14902,
      "ty": 2,
      "x": 942,
      "y": 988
    },
    {
      "t": 49751,
      "e": 14952,
      "ty": 41,
      "x": 24848,
      "y": 28340,
      "ta": "#start"
    },
    {
      "t": 49801,
      "e": 15002,
      "ty": 2,
      "x": 960,
      "y": 995
    },
    {
      "t": 49901,
      "e": 15102,
      "ty": 2,
      "x": 963,
      "y": 995
    },
    {
      "t": 50002,
      "e": 15203,
      "ty": 41,
      "x": 29217,
      "y": 34122,
      "ta": "#start"
    },
    {
      "t": 50002,
      "e": 15203,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51871,
      "e": 17072,
      "ty": 3,
      "x": 963,
      "y": 995,
      "ta": "#start"
    },
    {
      "t": 51873,
      "e": 17074,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 51874,
      "e": 17075,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 51964,
      "e": 17165,
      "ty": 4,
      "x": 29217,
      "y": 34122,
      "ta": "#start"
    },
    {
      "t": 51965,
      "e": 17166,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 51966,
      "e": 17167,
      "ty": 5,
      "x": 963,
      "y": 995,
      "ta": "#start"
    },
    {
      "t": 51967,
      "e": 17168,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 52973,
      "e": 18174,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 53601,
      "e": 18802,
      "ty": 2,
      "x": 894,
      "y": 866
    },
    {
      "t": 53674,
      "e": 18875,
      "ty": 6,
      "x": 838,
      "y": 637,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53690,
      "e": 18891,
      "ty": 7,
      "x": 845,
      "y": 555,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53701,
      "e": 18902,
      "ty": 2,
      "x": 845,
      "y": 555
    },
    {
      "t": 53752,
      "e": 18953,
      "ty": 41,
      "x": 25883,
      "y": 15359,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 53802,
      "e": 19003,
      "ty": 2,
      "x": 910,
      "y": 403
    },
    {
      "t": 53901,
      "e": 19102,
      "ty": 2,
      "x": 912,
      "y": 393
    },
    {
      "t": 54001,
      "e": 19202,
      "ty": 2,
      "x": 951,
      "y": 503
    },
    {
      "t": 54001,
      "e": 19202,
      "ty": 41,
      "x": 30929,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 54058,
      "e": 19259,
      "ty": 6,
      "x": 970,
      "y": 536,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54101,
      "e": 19302,
      "ty": 2,
      "x": 973,
      "y": 543
    },
    {
      "t": 54201,
      "e": 19402,
      "ty": 2,
      "x": 976,
      "y": 551
    },
    {
      "t": 54252,
      "e": 19453,
      "ty": 41,
      "x": 36336,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54382,
      "e": 19583,
      "ty": 3,
      "x": 976,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54383,
      "e": 19584,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54477,
      "e": 19678,
      "ty": 4,
      "x": 36336,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54477,
      "e": 19678,
      "ty": 5,
      "x": 976,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54902,
      "e": 20103,
      "ty": 2,
      "x": 977,
      "y": 548
    },
    {
      "t": 55001,
      "e": 20202,
      "ty": 2,
      "x": 978,
      "y": 546
    },
    {
      "t": 55002,
      "e": 20203,
      "ty": 41,
      "x": 36768,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55502,
      "e": 20703,
      "ty": 2,
      "x": 963,
      "y": 540
    },
    {
      "t": 55502,
      "e": 20703,
      "ty": 41,
      "x": 33524,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55602,
      "e": 20803,
      "ty": 2,
      "x": 959,
      "y": 540
    },
    {
      "t": 55752,
      "e": 20953,
      "ty": 41,
      "x": 32659,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56490,
      "e": 21691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "87"
    },
    {
      "t": 56491,
      "e": 21692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56606,
      "e": 21807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "w"
    },
    {
      "t": 56609,
      "e": 21810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "w"
    },
    {
      "t": 57386,
      "e": 22587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 57387,
      "e": 22588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57474,
      "e": 22675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "wh"
    },
    {
      "t": 57497,
      "e": 22698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 57498,
      "e": 22699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57585,
      "e": 22786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "whi"
    },
    {
      "t": 57624,
      "e": 22825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 57624,
      "e": 22825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57712,
      "e": 22913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "whis"
    },
    {
      "t": 57728,
      "e": 22929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 57729,
      "e": 22930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57889,
      "e": 23090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 57890,
      "e": 23091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57913,
      "e": 23114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||ke"
    },
    {
      "t": 57969,
      "e": 23170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 58720,
      "e": 23921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 58721,
      "e": 23922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58816,
      "e": 24017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||y"
    },
    {
      "t": 59560,
      "e": 24761,
      "ty": 7,
      "x": 964,
      "y": 527,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59598,
      "e": 24799,
      "ty": 2,
      "x": 964,
      "y": 527
    },
    {
      "t": 59677,
      "e": 24878,
      "ty": 6,
      "x": 980,
      "y": 533,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59698,
      "e": 24899,
      "ty": 2,
      "x": 985,
      "y": 545
    },
    {
      "t": 59711,
      "e": 24912,
      "ty": 7,
      "x": 994,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59748,
      "e": 24949,
      "ty": 41,
      "x": 43257,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 59799,
      "e": 25000,
      "ty": 2,
      "x": 1015,
      "y": 624
    },
    {
      "t": 59811,
      "e": 25012,
      "ty": 6,
      "x": 1016,
      "y": 633,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59844,
      "e": 25045,
      "ty": 7,
      "x": 1020,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59861,
      "e": 25062,
      "ty": 6,
      "x": 1020,
      "y": 658,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59876,
      "e": 25077,
      "ty": 7,
      "x": 1024,
      "y": 665,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59898,
      "e": 25099,
      "ty": 2,
      "x": 1025,
      "y": 668
    },
    {
      "t": 59999,
      "e": 25200,
      "ty": 2,
      "x": 1032,
      "y": 655
    },
    {
      "t": 59999,
      "e": 25200,
      "ty": 41,
      "x": 35264,
      "y": 39369,
      "ta": "html > body"
    },
    {
      "t": 59999,
      "e": 25200,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60027,
      "e": 25228,
      "ty": 6,
      "x": 1035,
      "y": 645,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60098,
      "e": 25299,
      "ty": 2,
      "x": 1039,
      "y": 637
    },
    {
      "t": 60187,
      "e": 25388,
      "ty": 3,
      "x": 1039,
      "y": 637,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60189,
      "e": 25390,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "whiskey"
    },
    {
      "t": 60189,
      "e": 25390,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60190,
      "e": 25391,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60249,
      "e": 25450,
      "ty": 41,
      "x": 49962,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60274,
      "e": 25475,
      "ty": 4,
      "x": 49962,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60274,
      "e": 25475,
      "ty": 5,
      "x": 1039,
      "y": 637,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61047,
      "e": 26248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 61047,
      "e": 26248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61110,
      "e": 26311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 61207,
      "e": 26408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 61207,
      "e": 26408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61279,
      "e": 26480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 61404,
      "e": 26605,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 61647,
      "e": 26848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 61648,
      "e": 26849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61734,
      "e": 26935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 63499,
      "e": 28700,
      "ty": 2,
      "x": 1039,
      "y": 642
    },
    {
      "t": 63499,
      "e": 28700,
      "ty": 41,
      "x": 49962,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63515,
      "e": 28716,
      "ty": 7,
      "x": 1029,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63531,
      "e": 28732,
      "ty": 6,
      "x": 1017,
      "y": 658,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63599,
      "e": 28800,
      "ty": 2,
      "x": 1012,
      "y": 662
    },
    {
      "t": 63698,
      "e": 28899,
      "ty": 2,
      "x": 1006,
      "y": 664
    },
    {
      "t": 63748,
      "e": 28949,
      "ty": 41,
      "x": 54156,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63798,
      "e": 28999,
      "ty": 2,
      "x": 1001,
      "y": 668
    },
    {
      "t": 63908,
      "e": 29109,
      "ty": 3,
      "x": 1001,
      "y": 668,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63908,
      "e": 29109,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 63909,
      "e": 29110,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63909,
      "e": 29110,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63979,
      "e": 29180,
      "ty": 4,
      "x": 54156,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63983,
      "e": 29184,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63985,
      "e": 29186,
      "ty": 5,
      "x": 1001,
      "y": 668,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63986,
      "e": 29187,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 65096,
      "e": 30297,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 65124,
      "e": 30325,
      "ty": 6,
      "x": 1001,
      "y": 668,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 69999,
      "e": 35200,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 78226,
      "e": 35325,
      "ty": 7,
      "x": 1002,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 78226,
      "e": 35325,
      "ty": 6,
      "x": 1002,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 78250,
      "e": 35349,
      "ty": 41,
      "x": 33994,
      "y": 37448,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 78251,
      "e": 35350,
      "ty": 7,
      "x": 1010,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 78251,
      "e": 35350,
      "ty": 6,
      "x": 1010,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 78268,
      "e": 35367,
      "ty": 7,
      "x": 1015,
      "y": 749,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 78299,
      "e": 35398,
      "ty": 2,
      "x": 1024,
      "y": 779
    },
    {
      "t": 78399,
      "e": 35498,
      "ty": 2,
      "x": 1051,
      "y": 911
    },
    {
      "t": 78499,
      "e": 35598,
      "ty": 2,
      "x": 1048,
      "y": 987
    },
    {
      "t": 78500,
      "e": 35599,
      "ty": 41,
      "x": 35815,
      "y": 59571,
      "ta": "> div.masterdiv"
    },
    {
      "t": 78599,
      "e": 35698,
      "ty": 2,
      "x": 1035,
      "y": 1001
    },
    {
      "t": 78635,
      "e": 35734,
      "ty": 6,
      "x": 1012,
      "y": 991,
      "ta": "#start"
    },
    {
      "t": 78699,
      "e": 35798,
      "ty": 2,
      "x": 995,
      "y": 986
    },
    {
      "t": 78749,
      "e": 35848,
      "ty": 41,
      "x": 39047,
      "y": 12920,
      "ta": "#start"
    },
    {
      "t": 78799,
      "e": 35898,
      "ty": 2,
      "x": 980,
      "y": 984
    },
    {
      "t": 79000,
      "e": 36099,
      "ty": 41,
      "x": 38501,
      "y": 12920,
      "ta": "#start"
    },
    {
      "t": 86153,
      "e": 41099,
      "ty": 7,
      "x": 980,
      "y": 984,
      "ta": "#start"
    },
    {
      "t": 86198,
      "e": 41144,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 86198,
      "e": 41144,
      "ty": 2,
      "x": 980,
      "y": 1050
    },
    {
      "t": 86249,
      "e": 41195,
      "ty": 41,
      "x": 33776,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86898,
      "e": 41844,
      "ty": 2,
      "x": 982,
      "y": 1059
    },
    {
      "t": 86952,
      "e": 41898,
      "ty": 6,
      "x": 988,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 86999,
      "e": 41945,
      "ty": 2,
      "x": 989,
      "y": 1078
    },
    {
      "t": 86999,
      "e": 41945,
      "ty": 41,
      "x": 43416,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 87067,
      "e": 42013,
      "ty": 7,
      "x": 998,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 87099,
      "e": 42045,
      "ty": 2,
      "x": 999,
      "y": 1110
    },
    {
      "t": 87198,
      "e": 42144,
      "ty": 2,
      "x": 1000,
      "y": 1111
    },
    {
      "t": 87249,
      "e": 42195,
      "ty": 41,
      "x": 51725,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 87334,
      "e": 42280,
      "ty": 6,
      "x": 1000,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 87398,
      "e": 42344,
      "ty": 2,
      "x": 1003,
      "y": 1097
    },
    {
      "t": 87499,
      "e": 42445,
      "ty": 41,
      "x": 51062,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 88211,
      "e": 43157,
      "ty": 3,
      "x": 1003,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 88212,
      "e": 43158,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88249,
      "e": 43195,
      "ty": 4,
      "x": 51062,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 88250,
      "e": 43196,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 88251,
      "e": 43197,
      "ty": 5,
      "x": 1003,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 88251,
      "e": 43197,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88281,
      "e": 43227,
      "ty": 3,
      "x": 1003,
      "y": 1097,
      "ta": "html > body"
    },
    {
      "t": 88361,
      "e": 43307,
      "ty": 4,
      "x": 34265,
      "y": 60327,
      "ta": "html > body"
    },
    {
      "t": 88361,
      "e": 43307,
      "ty": 5,
      "x": 1003,
      "y": 1097,
      "ta": "html > body"
    },
    {
      "t": 88698,
      "e": 43644,
      "ty": 2,
      "x": 1003,
      "y": 1019
    },
    {
      "t": 88749,
      "e": 43695,
      "ty": 41,
      "x": 34850,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 88798,
      "e": 43744,
      "ty": 2,
      "x": 1034,
      "y": 740
    },
    {
      "t": 88899,
      "e": 43845,
      "ty": 2,
      "x": 1046,
      "y": 708
    },
    {
      "t": 88998,
      "e": 43944,
      "ty": 2,
      "x": 1048,
      "y": 697
    },
    {
      "t": 88999,
      "e": 43945,
      "ty": 41,
      "x": 35815,
      "y": 38168,
      "ta": "html > body"
    },
    {
      "t": 89099,
      "e": 44045,
      "ty": 2,
      "x": 1045,
      "y": 687
    },
    {
      "t": 89198,
      "e": 44144,
      "ty": 2,
      "x": 1036,
      "y": 678
    },
    {
      "t": 89249,
      "e": 44195,
      "ty": 41,
      "x": 35367,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 89252,
      "e": 44198,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 89299,
      "e": 44245,
      "ty": 2,
      "x": 1035,
      "y": 676
    },
    {
      "t": 89398,
      "e": 44344,
      "ty": 2,
      "x": 1024,
      "y": 666
    },
    {
      "t": 89498,
      "e": 44444,
      "ty": 2,
      "x": 1013,
      "y": 660
    },
    {
      "t": 89498,
      "e": 44444,
      "ty": 41,
      "x": 35364,
      "y": 39949,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 89898,
      "e": 44844,
      "ty": 2,
      "x": 1007,
      "y": 658
    },
    {
      "t": 89999,
      "e": 44945,
      "ty": 2,
      "x": 1004,
      "y": 658
    },
    {
      "t": 89999,
      "e": 44945,
      "ty": 41,
      "x": 34927,
      "y": 39794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 89999,
      "e": 44945,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 99672,
      "e": 49945,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 100680,
      "e": 49945,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 140, dom: 626, initialDom: 636",
  "javascriptErrors": []
}