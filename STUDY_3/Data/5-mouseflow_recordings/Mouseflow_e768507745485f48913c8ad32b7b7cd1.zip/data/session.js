var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e768507745485f48913c8ad32b7b7cd1",
  "created": "2018-05-25T11:10:20.8788058-07:00",
  "lastActivity": "2018-05-25T11:10:37.6765816-07:00",
  "pageViews": [
    {
      "id": "0525201797e0061986b0e617141d934dac23c988",
      "startTime": "2018-05-25T11:10:20.9391184-07:00",
      "endTime": "2018-05-25T11:10:37.6765816-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 16745,
      "engagementTime": 16745,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16745,
  "engagementTime": 16745,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K8DJ0",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "08b65b6b3c67e02953ebe4c9f14aec6d",
  "gdpr": false
}