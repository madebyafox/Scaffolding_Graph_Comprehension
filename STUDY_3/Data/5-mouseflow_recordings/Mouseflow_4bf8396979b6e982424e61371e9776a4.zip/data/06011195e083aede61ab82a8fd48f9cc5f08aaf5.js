var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06011195e083aede61ab82a8fd48f9cc5f08aaf5"] = {
  "startTime": "2018-06-01T18:15:11.4438931Z",
  "websitePageUrl": "/16",
  "visitTime": 47685,
  "engagementTime": 46915,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "4bf8396979b6e982424e61371e9776a4",
    "created": "2018-06-01T18:15:11.4438931+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=202VN",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b1c9654cca3c7bd9582714ce16c79117",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4bf8396979b6e982424e61371e9776a4/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 193,
      "e": 193,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 759,
      "e": 759,
      "ty": 41,
      "x": 56756,
      "y": 38390,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 506,
      "y": 661
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 474,
      "y": 618
    },
    {
      "t": 922,
      "e": 922,
      "ty": 6,
      "x": 467,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 450,
      "y": 563
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 39670,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 446,
      "y": 537
    },
    {
      "t": 1143,
      "e": 1143,
      "ty": 3,
      "x": 446,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1145,
      "e": 1145,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1222,
      "e": 1222,
      "ty": 4,
      "x": 39220,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1222,
      "e": 1222,
      "ty": 5,
      "x": 446,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 39220,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 446,
      "y": 536
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 531,
      "y": 546
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 48775,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 543,
      "y": 549
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 582,
      "y": 545
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 54845,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 592,
      "y": 523
    },
    {
      "t": 1807,
      "e": 1807,
      "ty": 7,
      "x": 594,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 596,
      "y": 509
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 587,
      "y": 505
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 55070,
      "y": 24027,
      "ta": "#.strategy > p"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 550,
      "y": 501
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 442,
      "y": 501
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 30227,
      "y": 14664,
      "ta": "#.strategy > p"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 336,
      "y": 501
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 272,
      "y": 500
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 232,
      "y": 500
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 15164,
      "y": 12324,
      "ta": "#.strategy > p"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 207,
      "y": 503
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 193,
      "y": 503
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 10780,
      "y": 19345,
      "ta": "#.strategy > p"
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 309,
      "y": 505
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 395,
      "y": 507
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 33487,
      "y": 28708,
      "ta": "#.strategy > p"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 427,
      "y": 510
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 511,
      "y": 517
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 49337,
      "y": 47432,
      "ta": "#.strategy > p"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 553,
      "y": 515
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 2,
      "x": 559,
      "y": 515
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 602,
      "y": 521
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 56756,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 3508,
      "e": 3508,
      "ty": 6,
      "x": 621,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3558,
      "e": 3558,
      "ty": 7,
      "x": 700,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 798,
      "y": 582
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 932,
      "y": 622
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 12685,
      "y": 35739,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1046,
      "y": 686
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1163,
      "y": 803
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1235,
      "y": 893
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 31641,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1258,
      "y": 947
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1258,
      "y": 949
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 32486,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1237,
      "y": 957
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1186,
      "y": 960
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1176,
      "y": 960
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 27483,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1169,
      "y": 962
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1165,
      "y": 964
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 26074,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1094,
      "y": 801
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 954,
      "y": 693
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 904,
      "y": 663
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 8316,
      "y": 37602,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5451,
      "e": 5451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 5506,
      "e": 5506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 5507,
      "e": 5507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5593,
      "e": 5593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 5666,
      "e": 5666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 5674,
      "e": 5674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 5674,
      "e": 5674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5746,
      "e": 5746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 5746,
      "e": 5746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5810,
      "e": 5810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 5834,
      "e": 5834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5835,
      "e": 5835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5889,
      "e": 5889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 5922,
      "e": 5922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 5993,
      "e": 5993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5994,
      "e": 5994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6074,
      "e": 6074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 6170,
      "e": 6170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6170,
      "e": 6170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6209,
      "e": 6209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 6290,
      "e": 6290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6291,
      "e": 6291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6363,
      "e": 6363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 6363,
      "e": 6363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6426,
      "e": 6426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 6482,
      "e": 6482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6482,
      "e": 6482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6529,
      "e": 6529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 6577,
      "e": 6577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7075,
      "e": 7075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7076,
      "e": 7076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7194,
      "e": 7194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7194,
      "e": 7194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7266,
      "e": 7266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 7274,
      "e": 7274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7274,
      "e": 7274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7297,
      "e": 7297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7370,
      "e": 7370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7371,
      "e": 7371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7402,
      "e": 7402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 7434,
      "e": 7434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7450,
      "e": 7450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 7451,
      "e": 7451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7538,
      "e": 7538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7538,
      "e": 7538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7546,
      "e": 7546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 7618,
      "e": 7618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7618,
      "e": 7618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7642,
      "e": 7642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7674,
      "e": 7674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7803,
      "e": 7803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the "
    },
    {
      "t": 8163,
      "e": 8163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 8163,
      "e": 8163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8242,
      "e": 8242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 8490,
      "e": 8490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8546,
      "e": 8546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the "
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8634,
      "e": 8634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at the"
    },
    {
      "t": 8722,
      "e": 8722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8770,
      "e": 8770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at th"
    },
    {
      "t": 9019,
      "e": 9019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9082,
      "e": 9019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at t"
    },
    {
      "t": 9170,
      "e": 9107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9234,
      "e": 9171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at "
    },
    {
      "t": 9330,
      "e": 9267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 9331,
      "e": 9268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9433,
      "e": 9370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 9490,
      "e": 9427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 9490,
      "e": 9427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9602,
      "e": 9539,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at 12"
    },
    {
      "t": 9610,
      "e": 9547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 9770,
      "e": 9707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9851,
      "e": 9788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 9851,
      "e": 9788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9922,
      "e": 9859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 9946,
      "e": 9883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10050,
      "e": 9987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 10051,
      "e": 9988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10129,
      "e": 10066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10129,
      "e": 10066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10185,
      "e": 10122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 10218,
      "e": 10155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10370,
      "e": 10307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10514,
      "e": 10451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at 12Pm"
    },
    {
      "t": 10747,
      "e": 10684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10827,
      "e": 10764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at 12P"
    },
    {
      "t": 10882,
      "e": 10819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10986,
      "e": 10923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 10987,
      "e": 10924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11090,
      "e": 11027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 11098,
      "e": 11035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11099,
      "e": 11036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11122,
      "e": 11059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11162,
      "e": 11099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11235,
      "e": 11172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11235,
      "e": 11172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11346,
      "e": 11283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11346,
      "e": 11283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11394,
      "e": 11331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 11402,
      "e": 11339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11403,
      "e": 11340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11418,
      "e": 11355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11506,
      "e": 11443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11507,
      "e": 11444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11529,
      "e": 11466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11577,
      "e": 11514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11577,
      "e": 11514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11578,
      "e": 11515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11666,
      "e": 11603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11682,
      "e": 11619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11682,
      "e": 11619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11730,
      "e": 11667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11730,
      "e": 11667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11793,
      "e": 11730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 11794,
      "e": 11731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11898,
      "e": 11835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 11898,
      "e": 11835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11971,
      "e": 11908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 11979,
      "e": 11916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11979,
      "e": 11916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12058,
      "e": 11995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12090,
      "e": 12027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12090,
      "e": 12027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12138,
      "e": 12075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12170,
      "e": 12107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12170,
      "e": 12107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12251,
      "e": 12188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12251,
      "e": 12188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12257,
      "e": 12194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 12354,
      "e": 12291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12378,
      "e": 12315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12378,
      "e": 12315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12498,
      "e": 12435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12603,
      "e": 12540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 12604,
      "e": 12541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12707,
      "e": 12644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12707,
      "e": 12644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12714,
      "e": 12651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 12802,
      "e": 12739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12906,
      "e": 12843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12907,
      "e": 12844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13003,
      "e": 12940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13042,
      "e": 12979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13043,
      "e": 12980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13106,
      "e": 13043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13106,
      "e": 13043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13146,
      "e": 13083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 13203,
      "e": 13140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13203,
      "e": 13140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13226,
      "e": 13163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13274,
      "e": 13211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13314,
      "e": 13251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13315,
      "e": 13252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13361,
      "e": 13298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13378,
      "e": 13315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13378,
      "e": 13315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13458,
      "e": 13395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13482,
      "e": 13419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13482,
      "e": 13419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13546,
      "e": 13483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13562,
      "e": 13499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13563,
      "e": 13500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13642,
      "e": 13579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13642,
      "e": 13579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13714,
      "e": 13651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 13771,
      "e": 13708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14083,
      "e": 14020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14084,
      "e": 14021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14154,
      "e": 14091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 14162,
      "e": 14099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14162,
      "e": 14099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14217,
      "e": 14154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14306,
      "e": 14243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 14307,
      "e": 14244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14370,
      "e": 14307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 14433,
      "e": 14370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 14434,
      "e": 14371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14490,
      "e": 14427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 14554,
      "e": 14491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14555,
      "e": 14492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14634,
      "e": 14571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 14634,
      "e": 14571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14642,
      "e": 14579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 14706,
      "e": 14643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14706,
      "e": 14643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14762,
      "e": 14644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14785,
      "e": 14667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14785,
      "e": 14667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14803,
      "e": 14685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14858,
      "e": 14740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14866,
      "e": 14748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14866,
      "e": 14748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14954,
      "e": 14836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14962,
      "e": 14844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14963,
      "e": 14845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15027,
      "e": 14909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15028,
      "e": 14910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15105,
      "e": 14987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 15138,
      "e": 15020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15291,
      "e": 15173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 15291,
      "e": 15173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15354,
      "e": 15236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 15506,
      "e": 15388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15569,
      "e": 15451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at 12PM at the bottom, and then follow the "
    },
    {
      "t": 15982,
      "e": 15864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15982,
      "e": 15864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16055,
      "e": 15937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16056,
      "e": 15938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16110,
      "e": 15992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 16158,
      "e": 16040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16334,
      "e": 16216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16335,
      "e": 16217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16414,
      "e": 16296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 16430,
      "e": 16312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16430,
      "e": 16312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16510,
      "e": 16392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16591,
      "e": 16473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 16591,
      "e": 16473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16671,
      "e": 16553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 16991,
      "e": 16873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16991,
      "e": 16873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17054,
      "e": 16936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17055,
      "e": 16937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17094,
      "e": 16976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 17149,
      "e": 17031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17150,
      "e": 17032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17157,
      "e": 17039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17230,
      "e": 17112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17342,
      "e": 17224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17343,
      "e": 17225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17437,
      "e": 17319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17445,
      "e": 17327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17446,
      "e": 17328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17534,
      "e": 17416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17535,
      "e": 17417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17557,
      "e": 17439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 17630,
      "e": 17512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18166,
      "e": 18048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18166,
      "e": 18048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18238,
      "e": 18120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18238,
      "e": 18120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18302,
      "e": 18184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 18342,
      "e": 18224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18343,
      "e": 18225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18390,
      "e": 18272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18439,
      "e": 18321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18455,
      "e": 18337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18455,
      "e": 18337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18549,
      "e": 18431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18550,
      "e": 18432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18622,
      "e": 18504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 18678,
      "e": 18560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18822,
      "e": 18704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 18823,
      "e": 18705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18886,
      "e": 18768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 18894,
      "e": 18776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18894,
      "e": 18776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18957,
      "e": 18839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18958,
      "e": 18840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19013,
      "e": 18895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 19014,
      "e": 18896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19015,
      "e": 18897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19087,
      "e": 18969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19087,
      "e": 18969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 19087,
      "e": 18969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19125,
      "e": 19007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19126,
      "e": 19008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19134,
      "e": 19016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 19173,
      "e": 19055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19254,
      "e": 19136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19262,
      "e": 19144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19263,
      "e": 19145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19302,
      "e": 19184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19303,
      "e": 19185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19326,
      "e": 19208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 19358,
      "e": 19240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19358,
      "e": 19240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19406,
      "e": 19288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19438,
      "e": 19320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19446,
      "e": 19328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19446,
      "e": 19328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19486,
      "e": 19368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19502,
      "e": 19384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19502,
      "e": 19384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19582,
      "e": 19464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19582,
      "e": 19464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19582,
      "e": 19464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19662,
      "e": 19544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19663,
      "e": 19545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19710,
      "e": 19592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 19749,
      "e": 19631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19757,
      "e": 19639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19758,
      "e": 19640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19830,
      "e": 19712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 19830,
      "e": 19712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19830,
      "e": 19712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19902,
      "e": 19784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19927,
      "e": 19809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 19928,
      "e": 19810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19990,
      "e": 19872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19991,
      "e": 19873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19998,
      "e": 19880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 20005,
      "e": 19887,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20062,
      "e": 19944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20063,
      "e": 19945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20063,
      "e": 19945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20125,
      "e": 20007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20158,
      "e": 20040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 20158,
      "e": 20040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20254,
      "e": 20136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 20905,
      "e": 20787,
      "ty": 2,
      "x": 446,
      "y": 847
    },
    {
      "t": 21004,
      "e": 20886,
      "ty": 2,
      "x": 299,
      "y": 866
    },
    {
      "t": 21006,
      "e": 20888,
      "ty": 41,
      "x": 22696,
      "y": 47530,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 21104,
      "e": 20986,
      "ty": 2,
      "x": 305,
      "y": 773
    },
    {
      "t": 21205,
      "e": 21087,
      "ty": 2,
      "x": 426,
      "y": 705
    },
    {
      "t": 21243,
      "e": 21125,
      "ty": 6,
      "x": 432,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 21255,
      "e": 21137,
      "ty": 41,
      "x": 51011,
      "y": 60264,
      "ta": "#strategyButton"
    },
    {
      "t": 21305,
      "e": 21187,
      "ty": 2,
      "x": 424,
      "y": 673
    },
    {
      "t": 21405,
      "e": 21287,
      "ty": 2,
      "x": 410,
      "y": 661
    },
    {
      "t": 21411,
      "e": 21293,
      "ty": 3,
      "x": 410,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 21412,
      "e": 21294,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You look at 12PM at the bottom, and then follow the horizontal line going to the right."
    },
    {
      "t": 21412,
      "e": 21294,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21414,
      "e": 21296,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 21490,
      "e": 21372,
      "ty": 4,
      "x": 38996,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 21501,
      "e": 21383,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 21503,
      "e": 21385,
      "ty": 5,
      "x": 410,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 21509,
      "e": 21391,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 21511,
      "e": 21393,
      "ty": 41,
      "x": 13843,
      "y": 36174,
      "ta": "html > body"
    },
    {
      "t": 21605,
      "e": 21487,
      "ty": 2,
      "x": 412,
      "y": 662
    },
    {
      "t": 21705,
      "e": 21587,
      "ty": 2,
      "x": 411,
      "y": 666
    },
    {
      "t": 21755,
      "e": 21637,
      "ty": 41,
      "x": 13878,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 22105,
      "e": 21987,
      "ty": 2,
      "x": 435,
      "y": 646
    },
    {
      "t": 22205,
      "e": 22087,
      "ty": 2,
      "x": 493,
      "y": 600
    },
    {
      "t": 22256,
      "e": 22138,
      "ty": 41,
      "x": 16771,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 22305,
      "e": 22187,
      "ty": 2,
      "x": 495,
      "y": 599
    },
    {
      "t": 22505,
      "e": 22387,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 22805,
      "e": 22687,
      "ty": 2,
      "x": 501,
      "y": 599
    },
    {
      "t": 22905,
      "e": 22787,
      "ty": 2,
      "x": 722,
      "y": 647
    },
    {
      "t": 22943,
      "e": 22825,
      "ty": 6,
      "x": 836,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23005,
      "e": 22887,
      "ty": 2,
      "x": 910,
      "y": 652
    },
    {
      "t": 23005,
      "e": 22887,
      "ty": 41,
      "x": 22061,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23028,
      "e": 22910,
      "ty": 7,
      "x": 969,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23105,
      "e": 22987,
      "ty": 2,
      "x": 990,
      "y": 615
    },
    {
      "t": 23161,
      "e": 23043,
      "ty": 6,
      "x": 983,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23205,
      "e": 23087,
      "ty": 2,
      "x": 979,
      "y": 554
    },
    {
      "t": 23210,
      "e": 23092,
      "ty": 7,
      "x": 979,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23255,
      "e": 23137,
      "ty": 41,
      "x": 36985,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 23305,
      "e": 23187,
      "ty": 2,
      "x": 979,
      "y": 553
    },
    {
      "t": 23386,
      "e": 23268,
      "ty": 6,
      "x": 979,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23405,
      "e": 23287,
      "ty": 2,
      "x": 979,
      "y": 556
    },
    {
      "t": 23505,
      "e": 23387,
      "ty": 2,
      "x": 980,
      "y": 569
    },
    {
      "t": 23505,
      "e": 23387,
      "ty": 41,
      "x": 37201,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23529,
      "e": 23411,
      "ty": 3,
      "x": 980,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23530,
      "e": 23412,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23634,
      "e": 23516,
      "ty": 4,
      "x": 37201,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23634,
      "e": 23516,
      "ty": 5,
      "x": 980,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24063,
      "e": 23945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 24063,
      "e": 23945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24134,
      "e": 24016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 24222,
      "e": 24104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 24222,
      "e": 24104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24286,
      "e": 24168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 24406,
      "e": 24288,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 24950,
      "e": 24832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 25046,
      "e": 24928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 25223,
      "e": 25105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 25224,
      "e": 25106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25318,
      "e": 25200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 25398,
      "e": 25280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 25399,
      "e": 25281,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 25399,
      "e": 25281,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25400,
      "e": 25282,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25518,
      "e": 25400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 26422,
      "e": 26304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 26527,
      "e": 26409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 26527,
      "e": 26409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26558,
      "e": 26440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "M"
    },
    {
      "t": 26606,
      "e": 26488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "M"
    },
    {
      "t": 26759,
      "e": 26641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 26759,
      "e": 26641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26845,
      "e": 26727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ma"
    },
    {
      "t": 26854,
      "e": 26736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 26854,
      "e": 26736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26942,
      "e": 26824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mal"
    },
    {
      "t": 26950,
      "e": 26832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 26951,
      "e": 26833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27006,
      "e": 26888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "89"
    },
    {
      "t": 27006,
      "e": 26888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27030,
      "e": 26912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Malay"
    },
    {
      "t": 27094,
      "e": 26976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 27111,
      "e": 26993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 27111,
      "e": 26993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27189,
      "e": 27071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 27189,
      "e": 27071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 27190,
      "e": 27072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27262,
      "e": 27144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 27262,
      "e": 27144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27269,
      "e": 27151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ia"
    },
    {
      "t": 27366,
      "e": 27248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 27881,
      "e": 27763,
      "ty": 7,
      "x": 995,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27905,
      "e": 27787,
      "ty": 2,
      "x": 995,
      "y": 608
    },
    {
      "t": 27931,
      "e": 27813,
      "ty": 6,
      "x": 1001,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27965,
      "e": 27847,
      "ty": 7,
      "x": 1003,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27998,
      "e": 27880,
      "ty": 6,
      "x": 1004,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28005,
      "e": 27887,
      "ty": 2,
      "x": 1004,
      "y": 677
    },
    {
      "t": 28005,
      "e": 27887,
      "ty": 41,
      "x": 55702,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28105,
      "e": 27987,
      "ty": 2,
      "x": 1005,
      "y": 680
    },
    {
      "t": 28205,
      "e": 28087,
      "ty": 2,
      "x": 996,
      "y": 692
    },
    {
      "t": 28256,
      "e": 28138,
      "ty": 41,
      "x": 51579,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28283,
      "e": 28165,
      "ty": 3,
      "x": 996,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28283,
      "e": 28165,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Malaysia"
    },
    {
      "t": 28284,
      "e": 28166,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28285,
      "e": 28167,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28346,
      "e": 28228,
      "ty": 4,
      "x": 51579,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28347,
      "e": 28229,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28347,
      "e": 28229,
      "ty": 5,
      "x": 996,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28347,
      "e": 28229,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 28505,
      "e": 28387,
      "ty": 2,
      "x": 996,
      "y": 693
    },
    {
      "t": 28506,
      "e": 28388,
      "ty": 41,
      "x": 34024,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 28705,
      "e": 28587,
      "ty": 2,
      "x": 945,
      "y": 662
    },
    {
      "t": 28756,
      "e": 28587,
      "ty": 41,
      "x": 28962,
      "y": 34900,
      "ta": "html > body"
    },
    {
      "t": 28805,
      "e": 28636,
      "ty": 2,
      "x": 776,
      "y": 618
    },
    {
      "t": 28905,
      "e": 28736,
      "ty": 2,
      "x": 764,
      "y": 613
    },
    {
      "t": 29005,
      "e": 28836,
      "ty": 41,
      "x": 26034,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 29360,
      "e": 29191,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 29905,
      "e": 29736,
      "ty": 2,
      "x": 916,
      "y": 470
    },
    {
      "t": 30006,
      "e": 29837,
      "ty": 2,
      "x": 1069,
      "y": 300
    },
    {
      "t": 30006,
      "e": 29837,
      "ty": 41,
      "x": 58756,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 30105,
      "e": 29936,
      "ty": 2,
      "x": 1015,
      "y": 281
    },
    {
      "t": 30205,
      "e": 30036,
      "ty": 2,
      "x": 897,
      "y": 255
    },
    {
      "t": 30256,
      "e": 30087,
      "ty": 41,
      "x": 13427,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 30305,
      "e": 30136,
      "ty": 2,
      "x": 872,
      "y": 248
    },
    {
      "t": 30405,
      "e": 30236,
      "ty": 2,
      "x": 861,
      "y": 239
    },
    {
      "t": 30505,
      "e": 30336,
      "ty": 2,
      "x": 857,
      "y": 236
    },
    {
      "t": 30506,
      "e": 30337,
      "ty": 41,
      "x": 29133,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 30594,
      "e": 30425,
      "ty": 3,
      "x": 856,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 30605,
      "e": 30436,
      "ty": 2,
      "x": 856,
      "y": 235
    },
    {
      "t": 30667,
      "e": 30498,
      "ty": 4,
      "x": 28314,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 30667,
      "e": 30498,
      "ty": 5,
      "x": 856,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 30668,
      "e": 30499,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 30670,
      "e": 30501,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 30756,
      "e": 30587,
      "ty": 41,
      "x": 29952,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 30805,
      "e": 30636,
      "ty": 2,
      "x": 864,
      "y": 248
    },
    {
      "t": 30905,
      "e": 30736,
      "ty": 2,
      "x": 875,
      "y": 264
    },
    {
      "t": 31006,
      "e": 30837,
      "ty": 2,
      "x": 894,
      "y": 298
    },
    {
      "t": 31006,
      "e": 30837,
      "ty": 41,
      "x": 22746,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 31106,
      "e": 30937,
      "ty": 2,
      "x": 936,
      "y": 332
    },
    {
      "t": 31205,
      "e": 31036,
      "ty": 2,
      "x": 945,
      "y": 342
    },
    {
      "t": 31256,
      "e": 31087,
      "ty": 41,
      "x": 29328,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 31305,
      "e": 31136,
      "ty": 2,
      "x": 951,
      "y": 373
    },
    {
      "t": 31406,
      "e": 31237,
      "ty": 2,
      "x": 963,
      "y": 407
    },
    {
      "t": 31506,
      "e": 31337,
      "ty": 2,
      "x": 966,
      "y": 419
    },
    {
      "t": 31506,
      "e": 31337,
      "ty": 41,
      "x": 34311,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 31606,
      "e": 31437,
      "ty": 2,
      "x": 958,
      "y": 425
    },
    {
      "t": 31705,
      "e": 31536,
      "ty": 2,
      "x": 888,
      "y": 380
    },
    {
      "t": 31756,
      "e": 31587,
      "ty": 41,
      "x": 13190,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 31806,
      "e": 31637,
      "ty": 2,
      "x": 877,
      "y": 373
    },
    {
      "t": 31905,
      "e": 31736,
      "ty": 2,
      "x": 861,
      "y": 369
    },
    {
      "t": 32004,
      "e": 31835,
      "ty": 2,
      "x": 857,
      "y": 355
    },
    {
      "t": 32005,
      "e": 31836,
      "ty": 41,
      "x": 8443,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 32106,
      "e": 31937,
      "ty": 2,
      "x": 868,
      "y": 321
    },
    {
      "t": 32205,
      "e": 32036,
      "ty": 2,
      "x": 875,
      "y": 292
    },
    {
      "t": 32255,
      "e": 32086,
      "ty": 41,
      "x": 13664,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 32305,
      "e": 32136,
      "ty": 2,
      "x": 880,
      "y": 271
    },
    {
      "t": 32405,
      "e": 32236,
      "ty": 2,
      "x": 885,
      "y": 255
    },
    {
      "t": 32505,
      "e": 32336,
      "ty": 2,
      "x": 890,
      "y": 236
    },
    {
      "t": 32505,
      "e": 32336,
      "ty": 41,
      "x": 56156,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 32605,
      "e": 32436,
      "ty": 2,
      "x": 904,
      "y": 212
    },
    {
      "t": 32705,
      "e": 32536,
      "ty": 2,
      "x": 942,
      "y": 195
    },
    {
      "t": 32755,
      "e": 32586,
      "ty": 41,
      "x": 29565,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 32805,
      "e": 32636,
      "ty": 2,
      "x": 950,
      "y": 193
    },
    {
      "t": 32905,
      "e": 32736,
      "ty": 2,
      "x": 969,
      "y": 193
    },
    {
      "t": 33005,
      "e": 32836,
      "ty": 2,
      "x": 975,
      "y": 207
    },
    {
      "t": 33005,
      "e": 32836,
      "ty": 41,
      "x": 36447,
      "y": 11613,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 33104,
      "e": 32935,
      "ty": 2,
      "x": 954,
      "y": 290
    },
    {
      "t": 33206,
      "e": 33037,
      "ty": 2,
      "x": 946,
      "y": 319
    },
    {
      "t": 33256,
      "e": 33087,
      "ty": 41,
      "x": 31464,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 33306,
      "e": 33137,
      "ty": 2,
      "x": 976,
      "y": 346
    },
    {
      "t": 33406,
      "e": 33237,
      "ty": 2,
      "x": 986,
      "y": 352
    },
    {
      "t": 33505,
      "e": 33336,
      "ty": 2,
      "x": 986,
      "y": 369
    },
    {
      "t": 33505,
      "e": 33336,
      "ty": 41,
      "x": 39058,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 33606,
      "e": 33437,
      "ty": 2,
      "x": 970,
      "y": 385
    },
    {
      "t": 33706,
      "e": 33537,
      "ty": 2,
      "x": 954,
      "y": 396
    },
    {
      "t": 33756,
      "e": 33587,
      "ty": 41,
      "x": 30752,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 33806,
      "e": 33637,
      "ty": 2,
      "x": 944,
      "y": 401
    },
    {
      "t": 33906,
      "e": 33638,
      "ty": 2,
      "x": 915,
      "y": 402
    },
    {
      "t": 34005,
      "e": 33737,
      "ty": 2,
      "x": 900,
      "y": 393
    },
    {
      "t": 34005,
      "e": 33737,
      "ty": 41,
      "x": 18648,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 34105,
      "e": 33837,
      "ty": 2,
      "x": 896,
      "y": 389
    },
    {
      "t": 34206,
      "e": 33938,
      "ty": 2,
      "x": 910,
      "y": 383
    },
    {
      "t": 34255,
      "e": 33987,
      "ty": 41,
      "x": 26005,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 34305,
      "e": 34037,
      "ty": 2,
      "x": 940,
      "y": 383
    },
    {
      "t": 34405,
      "e": 34137,
      "ty": 2,
      "x": 921,
      "y": 417
    },
    {
      "t": 34506,
      "e": 34238,
      "ty": 2,
      "x": 884,
      "y": 447
    },
    {
      "t": 34506,
      "e": 34238,
      "ty": 41,
      "x": 49984,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 34606,
      "e": 34338,
      "ty": 2,
      "x": 883,
      "y": 447
    },
    {
      "t": 34705,
      "e": 34437,
      "ty": 2,
      "x": 883,
      "y": 448
    },
    {
      "t": 34755,
      "e": 34487,
      "ty": 41,
      "x": 47588,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 34805,
      "e": 34537,
      "ty": 2,
      "x": 873,
      "y": 420
    },
    {
      "t": 34905,
      "e": 34637,
      "ty": 2,
      "x": 863,
      "y": 398
    },
    {
      "t": 35006,
      "e": 34738,
      "ty": 2,
      "x": 855,
      "y": 382
    },
    {
      "t": 35006,
      "e": 34738,
      "ty": 41,
      "x": 7968,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 35106,
      "e": 34838,
      "ty": 2,
      "x": 861,
      "y": 369
    },
    {
      "t": 35206,
      "e": 34938,
      "ty": 2,
      "x": 921,
      "y": 359
    },
    {
      "t": 35256,
      "e": 34988,
      "ty": 41,
      "x": 24107,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 35305,
      "e": 35037,
      "ty": 2,
      "x": 937,
      "y": 369
    },
    {
      "t": 35406,
      "e": 35138,
      "ty": 2,
      "x": 985,
      "y": 379
    },
    {
      "t": 35505,
      "e": 35237,
      "ty": 2,
      "x": 962,
      "y": 418
    },
    {
      "t": 35506,
      "e": 35238,
      "ty": 41,
      "x": 33362,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 35605,
      "e": 35337,
      "ty": 2,
      "x": 948,
      "y": 442
    },
    {
      "t": 35706,
      "e": 35438,
      "ty": 2,
      "x": 921,
      "y": 460
    },
    {
      "t": 35756,
      "e": 35488,
      "ty": 41,
      "x": 20072,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 35805,
      "e": 35537,
      "ty": 2,
      "x": 889,
      "y": 464
    },
    {
      "t": 35905,
      "e": 35637,
      "ty": 2,
      "x": 870,
      "y": 453
    },
    {
      "t": 36005,
      "e": 35737,
      "ty": 2,
      "x": 867,
      "y": 438
    },
    {
      "t": 36005,
      "e": 35737,
      "ty": 41,
      "x": 36405,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 36116,
      "e": 35848,
      "ty": 3,
      "x": 867,
      "y": 438,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 36116,
      "e": 35848,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 36178,
      "e": 35910,
      "ty": 4,
      "x": 36405,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 36179,
      "e": 35911,
      "ty": 5,
      "x": 867,
      "y": 438,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 36180,
      "e": 35912,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 36181,
      "e": 35913,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 36406,
      "e": 36138,
      "ty": 2,
      "x": 873,
      "y": 443
    },
    {
      "t": 36505,
      "e": 36237,
      "ty": 2,
      "x": 885,
      "y": 472
    },
    {
      "t": 36505,
      "e": 36237,
      "ty": 41,
      "x": 15088,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 36604,
      "e": 36336,
      "ty": 2,
      "x": 929,
      "y": 524
    },
    {
      "t": 36704,
      "e": 36436,
      "ty": 2,
      "x": 962,
      "y": 541
    },
    {
      "t": 36755,
      "e": 36487,
      "ty": 41,
      "x": 34549,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 36806,
      "e": 36538,
      "ty": 2,
      "x": 971,
      "y": 556
    },
    {
      "t": 36904,
      "e": 36636,
      "ty": 2,
      "x": 974,
      "y": 575
    },
    {
      "t": 37004,
      "e": 36736,
      "ty": 2,
      "x": 979,
      "y": 600
    },
    {
      "t": 37005,
      "e": 36737,
      "ty": 41,
      "x": 37397,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 37104,
      "e": 36836,
      "ty": 2,
      "x": 976,
      "y": 617
    },
    {
      "t": 37205,
      "e": 36937,
      "ty": 2,
      "x": 949,
      "y": 632
    },
    {
      "t": 37255,
      "e": 36987,
      "ty": 41,
      "x": 27904,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 37306,
      "e": 37038,
      "ty": 2,
      "x": 924,
      "y": 636
    },
    {
      "t": 37406,
      "e": 37138,
      "ty": 2,
      "x": 912,
      "y": 648
    },
    {
      "t": 37505,
      "e": 37237,
      "ty": 2,
      "x": 931,
      "y": 683
    },
    {
      "t": 37506,
      "e": 37238,
      "ty": 41,
      "x": 29421,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 37605,
      "e": 37337,
      "ty": 2,
      "x": 957,
      "y": 701
    },
    {
      "t": 37704,
      "e": 37436,
      "ty": 2,
      "x": 963,
      "y": 718
    },
    {
      "t": 37755,
      "e": 37487,
      "ty": 41,
      "x": 35534,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 37805,
      "e": 37537,
      "ty": 2,
      "x": 963,
      "y": 723
    },
    {
      "t": 37904,
      "e": 37636,
      "ty": 2,
      "x": 972,
      "y": 706
    },
    {
      "t": 38005,
      "e": 37737,
      "ty": 2,
      "x": 985,
      "y": 681
    },
    {
      "t": 38005,
      "e": 37737,
      "ty": 41,
      "x": 43920,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 38104,
      "e": 37836,
      "ty": 2,
      "x": 988,
      "y": 679
    },
    {
      "t": 38204,
      "e": 37936,
      "ty": 2,
      "x": 1009,
      "y": 675
    },
    {
      "t": 38255,
      "e": 37987,
      "ty": 41,
      "x": 51438,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 38305,
      "e": 38037,
      "ty": 2,
      "x": 1017,
      "y": 674
    },
    {
      "t": 38405,
      "e": 38137,
      "ty": 2,
      "x": 1023,
      "y": 685
    },
    {
      "t": 38504,
      "e": 38236,
      "ty": 2,
      "x": 1023,
      "y": 710
    },
    {
      "t": 38506,
      "e": 38238,
      "ty": 41,
      "x": 50794,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 38605,
      "e": 38337,
      "ty": 2,
      "x": 1017,
      "y": 734
    },
    {
      "t": 38704,
      "e": 38436,
      "ty": 2,
      "x": 1016,
      "y": 732
    },
    {
      "t": 38756,
      "e": 38436,
      "ty": 41,
      "x": 48083,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 38805,
      "e": 38485,
      "ty": 2,
      "x": 1012,
      "y": 721
    },
    {
      "t": 38904,
      "e": 38584,
      "ty": 2,
      "x": 963,
      "y": 706
    },
    {
      "t": 39005,
      "e": 38685,
      "ty": 2,
      "x": 958,
      "y": 706
    },
    {
      "t": 39005,
      "e": 38685,
      "ty": 41,
      "x": 34415,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39105,
      "e": 38785,
      "ty": 2,
      "x": 934,
      "y": 710
    },
    {
      "t": 39204,
      "e": 38884,
      "ty": 2,
      "x": 927,
      "y": 711
    },
    {
      "t": 39255,
      "e": 38935,
      "ty": 41,
      "x": 26603,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39405,
      "e": 39085,
      "ty": 2,
      "x": 927,
      "y": 708
    },
    {
      "t": 39504,
      "e": 39184,
      "ty": 2,
      "x": 937,
      "y": 707
    },
    {
      "t": 39505,
      "e": 39185,
      "ty": 41,
      "x": 29123,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39605,
      "e": 39285,
      "ty": 2,
      "x": 942,
      "y": 707
    },
    {
      "t": 39704,
      "e": 39384,
      "ty": 2,
      "x": 948,
      "y": 707
    },
    {
      "t": 39755,
      "e": 39435,
      "ty": 41,
      "x": 33407,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39805,
      "e": 39485,
      "ty": 2,
      "x": 958,
      "y": 705
    },
    {
      "t": 39851,
      "e": 39531,
      "ty": 3,
      "x": 958,
      "y": 705,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39852,
      "e": 39532,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 39930,
      "e": 39610,
      "ty": 4,
      "x": 34415,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39930,
      "e": 39610,
      "ty": 5,
      "x": 958,
      "y": 705,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39932,
      "e": 39612,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 39933,
      "e": 39613,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 40005,
      "e": 39685,
      "ty": 41,
      "x": 34415,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 40104,
      "e": 39784,
      "ty": 2,
      "x": 958,
      "y": 707
    },
    {
      "t": 40205,
      "e": 39885,
      "ty": 2,
      "x": 963,
      "y": 747
    },
    {
      "t": 40255,
      "e": 39935,
      "ty": 41,
      "x": 60325,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 40305,
      "e": 39985,
      "ty": 2,
      "x": 966,
      "y": 758
    },
    {
      "t": 40405,
      "e": 40085,
      "ty": 2,
      "x": 967,
      "y": 773
    },
    {
      "t": 40504,
      "e": 40184,
      "ty": 2,
      "x": 961,
      "y": 822
    },
    {
      "t": 40505,
      "e": 40185,
      "ty": 41,
      "x": 33125,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 40604,
      "e": 40284,
      "ty": 2,
      "x": 960,
      "y": 837
    },
    {
      "t": 40704,
      "e": 40384,
      "ty": 2,
      "x": 966,
      "y": 857
    },
    {
      "t": 40755,
      "e": 40435,
      "ty": 41,
      "x": 34786,
      "y": 53279,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 40804,
      "e": 40484,
      "ty": 2,
      "x": 963,
      "y": 891
    },
    {
      "t": 40904,
      "e": 40584,
      "ty": 2,
      "x": 929,
      "y": 938
    },
    {
      "t": 41005,
      "e": 40685,
      "ty": 2,
      "x": 885,
      "y": 949
    },
    {
      "t": 41005,
      "e": 40685,
      "ty": 41,
      "x": 15088,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 41104,
      "e": 40784,
      "ty": 2,
      "x": 875,
      "y": 955
    },
    {
      "t": 41204,
      "e": 40884,
      "ty": 2,
      "x": 873,
      "y": 960
    },
    {
      "t": 41243,
      "e": 40923,
      "ty": 3,
      "x": 873,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 41244,
      "e": 40924,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 41255,
      "e": 40935,
      "ty": 41,
      "x": 41722,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 41304,
      "e": 40984,
      "ty": 2,
      "x": 873,
      "y": 961
    },
    {
      "t": 41314,
      "e": 40994,
      "ty": 4,
      "x": 41722,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 41315,
      "e": 40995,
      "ty": 5,
      "x": 873,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 41315,
      "e": 40995,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 41317,
      "e": 40997,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 41404,
      "e": 41084,
      "ty": 2,
      "x": 873,
      "y": 963
    },
    {
      "t": 41492,
      "e": 41172,
      "ty": 6,
      "x": 888,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41504,
      "e": 41184,
      "ty": 2,
      "x": 888,
      "y": 1010
    },
    {
      "t": 41505,
      "e": 41185,
      "ty": 41,
      "x": 30190,
      "y": 9929,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41605,
      "e": 41285,
      "ty": 2,
      "x": 890,
      "y": 1019
    },
    {
      "t": 41691,
      "e": 41371,
      "ty": 3,
      "x": 892,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41692,
      "e": 41372,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 41692,
      "e": 41372,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41704,
      "e": 41384,
      "ty": 2,
      "x": 892,
      "y": 1023
    },
    {
      "t": 41754,
      "e": 41434,
      "ty": 4,
      "x": 32252,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41754,
      "e": 41434,
      "ty": 5,
      "x": 892,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41755,
      "e": 41435,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41756,
      "e": 41436,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 41757,
      "e": 41437,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 41759,
      "e": 41439,
      "ty": 41,
      "x": 30442,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 42005,
      "e": 41685,
      "ty": 2,
      "x": 906,
      "y": 830
    },
    {
      "t": 42005,
      "e": 41685,
      "ty": 41,
      "x": 30925,
      "y": 45536,
      "ta": "html > body"
    },
    {
      "t": 42105,
      "e": 41785,
      "ty": 2,
      "x": 897,
      "y": 590
    },
    {
      "t": 42205,
      "e": 41885,
      "ty": 2,
      "x": 856,
      "y": 523
    },
    {
      "t": 42255,
      "e": 41935,
      "ty": 41,
      "x": 27412,
      "y": 26590,
      "ta": "html > body"
    },
    {
      "t": 42305,
      "e": 41985,
      "ty": 2,
      "x": 747,
      "y": 452
    },
    {
      "t": 42405,
      "e": 42085,
      "ty": 2,
      "x": 744,
      "y": 450
    },
    {
      "t": 42505,
      "e": 42185,
      "ty": 2,
      "x": 739,
      "y": 401
    },
    {
      "t": 42505,
      "e": 42185,
      "ty": 41,
      "x": 25173,
      "y": 21771,
      "ta": "html > body"
    },
    {
      "t": 42605,
      "e": 42285,
      "ty": 2,
      "x": 755,
      "y": 357
    },
    {
      "t": 42704,
      "e": 42384,
      "ty": 2,
      "x": 764,
      "y": 345
    },
    {
      "t": 42754,
      "e": 42434,
      "ty": 41,
      "x": 26069,
      "y": 18558,
      "ta": "html > body"
    },
    {
      "t": 42805,
      "e": 42485,
      "ty": 2,
      "x": 765,
      "y": 343
    },
    {
      "t": 42847,
      "e": 42527,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 43256,
      "e": 42486,
      "ty": 41,
      "x": 21870,
      "y": 59720,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 43305,
      "e": 42535,
      "ty": 2,
      "x": 662,
      "y": 377
    },
    {
      "t": 43405,
      "e": 42635,
      "ty": 2,
      "x": 614,
      "y": 437
    },
    {
      "t": 43504,
      "e": 42734,
      "ty": 2,
      "x": 799,
      "y": 514
    },
    {
      "t": 43505,
      "e": 42735,
      "ty": 41,
      "x": 24871,
      "y": 12293,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 43605,
      "e": 42835,
      "ty": 2,
      "x": 471,
      "y": 419
    },
    {
      "t": 43705,
      "e": 42935,
      "ty": 2,
      "x": 777,
      "y": 689
    },
    {
      "t": 43755,
      "e": 42985,
      "ty": 41,
      "x": 38252,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 43805,
      "e": 43035,
      "ty": 2,
      "x": 1104,
      "y": 963
    },
    {
      "t": 43905,
      "e": 43135,
      "ty": 2,
      "x": 1012,
      "y": 1041
    },
    {
      "t": 44005,
      "e": 43235,
      "ty": 2,
      "x": 991,
      "y": 1047
    },
    {
      "t": 44005,
      "e": 43235,
      "ty": 41,
      "x": 34317,
      "y": 63756,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 44078,
      "e": 43308,
      "ty": 6,
      "x": 993,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 44105,
      "e": 43335,
      "ty": 2,
      "x": 993,
      "y": 1082
    },
    {
      "t": 44205,
      "e": 43435,
      "ty": 2,
      "x": 993,
      "y": 1102
    },
    {
      "t": 44255,
      "e": 43485,
      "ty": 41,
      "x": 42870,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 44305,
      "e": 43535,
      "ty": 2,
      "x": 979,
      "y": 1097
    },
    {
      "t": 44505,
      "e": 43735,
      "ty": 2,
      "x": 978,
      "y": 1097
    },
    {
      "t": 44505,
      "e": 43735,
      "ty": 41,
      "x": 37409,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 45090,
      "e": 44320,
      "ty": 3,
      "x": 978,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 45092,
      "e": 44322,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 45177,
      "e": 44407,
      "ty": 4,
      "x": 37409,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 45178,
      "e": 44408,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 45178,
      "e": 44408,
      "ty": 5,
      "x": 978,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 45179,
      "e": 44409,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 45405,
      "e": 44635,
      "ty": 2,
      "x": 952,
      "y": 1092
    },
    {
      "t": 45505,
      "e": 44735,
      "ty": 2,
      "x": 787,
      "y": 928
    },
    {
      "t": 45505,
      "e": 44735,
      "ty": 41,
      "x": 26826,
      "y": 50965,
      "ta": "html > body"
    },
    {
      "t": 45605,
      "e": 44835,
      "ty": 2,
      "x": 730,
      "y": 753
    },
    {
      "t": 45705,
      "e": 44935,
      "ty": 2,
      "x": 724,
      "y": 735
    },
    {
      "t": 45755,
      "e": 44985,
      "ty": 41,
      "x": 24657,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 46221,
      "e": 45451,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 47605,
      "e": 46835,
      "ty": 2,
      "x": 843,
      "y": 766
    },
    {
      "t": 47685,
      "e": 46915,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 125258, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 125265, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3555, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 130180, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11181, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 142368, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4580, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 148040, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 37077, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 186120, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 15942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 203463, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:907,y:612,t:1527876577394};\\\", \\\"{x:904,y:612,t:1527876577401};\\\", \\\"{x:886,y:606,t:1527876577415};\\\", \\\"{x:841,y:592,t:1527876577431};\\\", \\\"{x:808,y:586,t:1527876577449};\\\", \\\"{x:783,y:580,t:1527876577464};\\\", \\\"{x:755,y:577,t:1527876577482};\\\", \\\"{x:708,y:568,t:1527876577498};\\\", \\\"{x:676,y:565,t:1527876577514};\\\", \\\"{x:641,y:560,t:1527876577532};\\\", \\\"{x:615,y:556,t:1527876577548};\\\", \\\"{x:598,y:556,t:1527876577564};\\\", \\\"{x:590,y:556,t:1527876577581};\\\", \\\"{x:588,y:556,t:1527876577599};\\\", \\\"{x:589,y:557,t:1527876578251};\\\", \\\"{x:590,y:558,t:1527876578275};\\\", \\\"{x:591,y:559,t:1527876578284};\\\", \\\"{x:592,y:560,t:1527876578301};\\\", \\\"{x:594,y:560,t:1527876578318};\\\", \\\"{x:596,y:562,t:1527876578334};\\\", \\\"{x:603,y:564,t:1527876578350};\\\", \\\"{x:616,y:567,t:1527876578369};\\\", \\\"{x:629,y:570,t:1527876578384};\\\", \\\"{x:647,y:572,t:1527876578399};\\\", \\\"{x:664,y:574,t:1527876578416};\\\", \\\"{x:679,y:577,t:1527876578432};\\\", \\\"{x:696,y:582,t:1527876578449};\\\", \\\"{x:704,y:583,t:1527876578465};\\\", \\\"{x:707,y:583,t:1527876578481};\\\", \\\"{x:709,y:584,t:1527876578498};\\\", \\\"{x:710,y:584,t:1527876578515};\\\", \\\"{x:711,y:584,t:1527876578531};\\\", \\\"{x:716,y:586,t:1527876579307};\\\", \\\"{x:721,y:588,t:1527876579316};\\\", \\\"{x:729,y:592,t:1527876579334};\\\", \\\"{x:733,y:594,t:1527876579349};\\\", \\\"{x:740,y:597,t:1527876579366};\\\", \\\"{x:758,y:611,t:1527876579382};\\\", \\\"{x:776,y:624,t:1527876579400};\\\", \\\"{x:804,y:645,t:1527876579417};\\\", \\\"{x:829,y:666,t:1527876579433};\\\", \\\"{x:850,y:687,t:1527876579450};\\\", \\\"{x:879,y:712,t:1527876579467};\\\", \\\"{x:901,y:726,t:1527876579484};\\\", \\\"{x:928,y:742,t:1527876579500};\\\", \\\"{x:969,y:760,t:1527876579516};\\\", \\\"{x:1003,y:776,t:1527876579534};\\\", \\\"{x:1057,y:796,t:1527876579549};\\\", \\\"{x:1108,y:812,t:1527876579567};\\\", \\\"{x:1151,y:827,t:1527876579584};\\\", \\\"{x:1182,y:837,t:1527876579601};\\\", \\\"{x:1199,y:842,t:1527876579617};\\\", \\\"{x:1215,y:848,t:1527876579634};\\\", \\\"{x:1235,y:854,t:1527876579651};\\\", \\\"{x:1242,y:858,t:1527876579668};\\\", \\\"{x:1243,y:859,t:1527876579684};\\\", \\\"{x:1245,y:859,t:1527876579715};\\\", \\\"{x:1246,y:861,t:1527876579722};\\\", \\\"{x:1247,y:861,t:1527876579735};\\\", \\\"{x:1251,y:866,t:1527876579751};\\\", \\\"{x:1255,y:873,t:1527876579767};\\\", \\\"{x:1259,y:878,t:1527876579784};\\\", \\\"{x:1262,y:883,t:1527876579800};\\\", \\\"{x:1265,y:888,t:1527876579817};\\\", \\\"{x:1269,y:895,t:1527876579835};\\\", \\\"{x:1271,y:897,t:1527876579851};\\\", \\\"{x:1273,y:900,t:1527876579867};\\\", \\\"{x:1274,y:903,t:1527876579884};\\\", \\\"{x:1274,y:904,t:1527876579901};\\\", \\\"{x:1274,y:907,t:1527876579919};\\\", \\\"{x:1274,y:910,t:1527876579935};\\\", \\\"{x:1274,y:915,t:1527876579952};\\\", \\\"{x:1274,y:921,t:1527876579969};\\\", \\\"{x:1274,y:923,t:1527876579985};\\\", \\\"{x:1274,y:925,t:1527876580001};\\\", \\\"{x:1274,y:928,t:1527876580018};\\\", \\\"{x:1274,y:931,t:1527876580036};\\\", \\\"{x:1274,y:933,t:1527876580053};\\\", \\\"{x:1274,y:934,t:1527876580068};\\\", \\\"{x:1274,y:936,t:1527876580086};\\\", \\\"{x:1274,y:937,t:1527876580103};\\\", \\\"{x:1274,y:938,t:1527876580120};\\\", \\\"{x:1275,y:939,t:1527876580136};\\\", \\\"{x:1276,y:941,t:1527876580153};\\\", \\\"{x:1277,y:942,t:1527876580170};\\\", \\\"{x:1278,y:943,t:1527876580186};\\\", \\\"{x:1284,y:945,t:1527876580203};\\\", \\\"{x:1289,y:948,t:1527876580220};\\\", \\\"{x:1291,y:949,t:1527876580238};\\\", \\\"{x:1293,y:949,t:1527876580253};\\\", \\\"{x:1295,y:949,t:1527876580270};\\\", \\\"{x:1297,y:949,t:1527876580287};\\\", \\\"{x:1298,y:949,t:1527876580304};\\\", \\\"{x:1299,y:947,t:1527876580320};\\\", \\\"{x:1299,y:945,t:1527876580338};\\\", \\\"{x:1299,y:942,t:1527876580354};\\\", \\\"{x:1299,y:941,t:1527876580370};\\\", \\\"{x:1301,y:938,t:1527876580387};\\\", \\\"{x:1301,y:936,t:1527876580459};\\\", \\\"{x:1301,y:935,t:1527876580515};\\\", \\\"{x:1301,y:934,t:1527876580587};\\\", \\\"{x:1301,y:933,t:1527876580605};\\\", \\\"{x:1301,y:932,t:1527876580626};\\\", \\\"{x:1301,y:930,t:1527876580642};\\\", \\\"{x:1301,y:929,t:1527876580659};\\\", \\\"{x:1301,y:927,t:1527876580672};\\\", \\\"{x:1301,y:923,t:1527876580688};\\\", \\\"{x:1301,y:921,t:1527876580706};\\\", \\\"{x:1301,y:918,t:1527876580722};\\\", \\\"{x:1302,y:909,t:1527876580740};\\\", \\\"{x:1305,y:900,t:1527876580755};\\\", \\\"{x:1306,y:891,t:1527876580772};\\\", \\\"{x:1306,y:881,t:1527876580790};\\\", \\\"{x:1306,y:875,t:1527876580806};\\\", \\\"{x:1306,y:869,t:1527876580822};\\\", \\\"{x:1307,y:862,t:1527876580839};\\\", \\\"{x:1307,y:860,t:1527876580856};\\\", \\\"{x:1307,y:859,t:1527876580873};\\\", \\\"{x:1307,y:856,t:1527876580889};\\\", \\\"{x:1307,y:855,t:1527876580905};\\\", \\\"{x:1307,y:854,t:1527876580922};\\\", \\\"{x:1307,y:853,t:1527876580939};\\\", \\\"{x:1307,y:852,t:1527876580955};\\\", \\\"{x:1307,y:851,t:1527876580973};\\\", \\\"{x:1306,y:850,t:1527876580990};\\\", \\\"{x:1305,y:848,t:1527876581050};\\\", \\\"{x:1303,y:847,t:1527876581058};\\\", \\\"{x:1301,y:845,t:1527876581072};\\\", \\\"{x:1297,y:842,t:1527876581090};\\\", \\\"{x:1293,y:837,t:1527876581106};\\\", \\\"{x:1289,y:834,t:1527876581123};\\\", \\\"{x:1286,y:831,t:1527876581144};\\\", \\\"{x:1286,y:830,t:1527876581156};\\\", \\\"{x:1285,y:829,t:1527876581174};\\\", \\\"{x:1284,y:829,t:1527876581182};\\\", \\\"{x:1284,y:828,t:1527876581210};\\\", \\\"{x:1284,y:827,t:1527876581217};\\\", \\\"{x:1284,y:826,t:1527876581234};\\\", \\\"{x:1284,y:825,t:1527876581250};\\\", \\\"{x:1284,y:824,t:1527876581494};\\\", \\\"{x:1284,y:825,t:1527876581760};\\\", \\\"{x:1283,y:827,t:1527876581784};\\\", \\\"{x:1282,y:828,t:1527876581801};\\\", \\\"{x:1281,y:828,t:1527876581930};\\\", \\\"{x:1279,y:828,t:1527876585980};\\\", \\\"{x:1256,y:835,t:1527876586004};\\\", \\\"{x:1227,y:835,t:1527876586021};\\\", \\\"{x:1198,y:835,t:1527876586037};\\\", \\\"{x:1169,y:835,t:1527876586055};\\\", \\\"{x:1133,y:834,t:1527876586072};\\\", \\\"{x:1093,y:829,t:1527876586087};\\\", \\\"{x:1040,y:813,t:1527876586104};\\\", \\\"{x:965,y:791,t:1527876586122};\\\", \\\"{x:933,y:779,t:1527876586138};\\\", \\\"{x:906,y:772,t:1527876586154};\\\", \\\"{x:888,y:768,t:1527876586172};\\\", \\\"{x:878,y:765,t:1527876586188};\\\", \\\"{x:869,y:764,t:1527876586205};\\\", \\\"{x:856,y:762,t:1527876586222};\\\", \\\"{x:842,y:758,t:1527876586238};\\\", \\\"{x:819,y:755,t:1527876586255};\\\", \\\"{x:789,y:746,t:1527876586272};\\\", \\\"{x:752,y:736,t:1527876586288};\\\", \\\"{x:707,y:722,t:1527876586305};\\\", \\\"{x:605,y:694,t:1527876586322};\\\", \\\"{x:567,y:680,t:1527876586339};\\\", \\\"{x:548,y:670,t:1527876586354};\\\", \\\"{x:535,y:662,t:1527876586372};\\\", \\\"{x:523,y:653,t:1527876586389};\\\", \\\"{x:517,y:643,t:1527876586405};\\\", \\\"{x:515,y:636,t:1527876586421};\\\", \\\"{x:514,y:624,t:1527876586439};\\\", \\\"{x:510,y:608,t:1527876586456};\\\", \\\"{x:503,y:593,t:1527876586472};\\\", \\\"{x:496,y:578,t:1527876586489};\\\", \\\"{x:486,y:563,t:1527876586505};\\\", \\\"{x:472,y:545,t:1527876586521};\\\", \\\"{x:463,y:537,t:1527876586538};\\\", \\\"{x:456,y:531,t:1527876586554};\\\", \\\"{x:448,y:527,t:1527876586572};\\\", \\\"{x:439,y:522,t:1527876586589};\\\", \\\"{x:435,y:522,t:1527876586605};\\\", \\\"{x:431,y:522,t:1527876586622};\\\", \\\"{x:427,y:522,t:1527876586638};\\\", \\\"{x:421,y:522,t:1527876586655};\\\", \\\"{x:416,y:522,t:1527876586672};\\\", \\\"{x:413,y:523,t:1527876586689};\\\", \\\"{x:408,y:524,t:1527876586706};\\\", \\\"{x:404,y:526,t:1527876586722};\\\", \\\"{x:402,y:526,t:1527876586740};\\\", \\\"{x:401,y:529,t:1527876586787};\\\", \\\"{x:401,y:532,t:1527876586802};\\\", \\\"{x:400,y:532,t:1527876586810};\\\", \\\"{x:400,y:533,t:1527876586821};\\\", \\\"{x:399,y:535,t:1527876586842};\\\", \\\"{x:399,y:536,t:1527876586858};\\\", \\\"{x:398,y:539,t:1527876586871};\\\", \\\"{x:397,y:540,t:1527876586888};\\\", \\\"{x:395,y:543,t:1527876586905};\\\", \\\"{x:394,y:545,t:1527876586921};\\\", \\\"{x:392,y:549,t:1527876586938};\\\", \\\"{x:390,y:552,t:1527876586955};\\\", \\\"{x:388,y:554,t:1527876586973};\\\", \\\"{x:387,y:556,t:1527876586989};\\\", \\\"{x:387,y:558,t:1527876587795};\\\", \\\"{x:388,y:559,t:1527876587810};\\\", \\\"{x:389,y:561,t:1527876587867};\\\", \\\"{x:389,y:562,t:1527876587940};\\\", \\\"{x:389,y:565,t:1527876587956};\\\", \\\"{x:389,y:566,t:1527876587973};\\\", \\\"{x:392,y:568,t:1527876587991};\\\", \\\"{x:405,y:574,t:1527876588008};\\\", \\\"{x:455,y:584,t:1527876588024};\\\", \\\"{x:535,y:601,t:1527876588040};\\\", \\\"{x:630,y:618,t:1527876588058};\\\", \\\"{x:734,y:640,t:1527876588073};\\\", \\\"{x:870,y:679,t:1527876588089};\\\", \\\"{x:928,y:696,t:1527876588105};\\\", \\\"{x:961,y:709,t:1527876588123};\\\", \\\"{x:977,y:719,t:1527876588140};\\\", \\\"{x:988,y:729,t:1527876588157};\\\", \\\"{x:1004,y:742,t:1527876588173};\\\", \\\"{x:1036,y:766,t:1527876588189};\\\", \\\"{x:1059,y:779,t:1527876588207};\\\", \\\"{x:1079,y:787,t:1527876588223};\\\", \\\"{x:1099,y:792,t:1527876588240};\\\", \\\"{x:1127,y:800,t:1527876588257};\\\", \\\"{x:1150,y:807,t:1527876588272};\\\", \\\"{x:1158,y:809,t:1527876588290};\\\", \\\"{x:1162,y:812,t:1527876588347};\\\", \\\"{x:1164,y:815,t:1527876588357};\\\", \\\"{x:1171,y:818,t:1527876588373};\\\", \\\"{x:1171,y:819,t:1527876588390};\\\", \\\"{x:1172,y:819,t:1527876588408};\\\", \\\"{x:1174,y:819,t:1527876588423};\\\", \\\"{x:1181,y:824,t:1527876588440};\\\", \\\"{x:1192,y:830,t:1527876588457};\\\", \\\"{x:1205,y:839,t:1527876588474};\\\", \\\"{x:1216,y:844,t:1527876588490};\\\", \\\"{x:1223,y:848,t:1527876588507};\\\", \\\"{x:1236,y:858,t:1527876588523};\\\", \\\"{x:1251,y:868,t:1527876588540};\\\", \\\"{x:1263,y:877,t:1527876588557};\\\", \\\"{x:1271,y:884,t:1527876588574};\\\", \\\"{x:1277,y:888,t:1527876588591};\\\", \\\"{x:1282,y:893,t:1527876588607};\\\", \\\"{x:1285,y:896,t:1527876588623};\\\", \\\"{x:1291,y:904,t:1527876588641};\\\", \\\"{x:1295,y:908,t:1527876588657};\\\", \\\"{x:1302,y:917,t:1527876588674};\\\", \\\"{x:1305,y:920,t:1527876588691};\\\", \\\"{x:1309,y:924,t:1527876588708};\\\", \\\"{x:1311,y:929,t:1527876588724};\\\", \\\"{x:1312,y:934,t:1527876588741};\\\", \\\"{x:1313,y:938,t:1527876588758};\\\", \\\"{x:1315,y:941,t:1527876588774};\\\", \\\"{x:1315,y:946,t:1527876588790};\\\", \\\"{x:1315,y:953,t:1527876588807};\\\", \\\"{x:1315,y:957,t:1527876588824};\\\", \\\"{x:1315,y:959,t:1527876588840};\\\", \\\"{x:1315,y:954,t:1527876588981};\\\", \\\"{x:1315,y:948,t:1527876588990};\\\", \\\"{x:1315,y:941,t:1527876589007};\\\", \\\"{x:1315,y:931,t:1527876589025};\\\", \\\"{x:1315,y:921,t:1527876589041};\\\", \\\"{x:1313,y:907,t:1527876589058};\\\", \\\"{x:1308,y:894,t:1527876589075};\\\", \\\"{x:1304,y:884,t:1527876589091};\\\", \\\"{x:1304,y:882,t:1527876589107};\\\", \\\"{x:1304,y:878,t:1527876589124};\\\", \\\"{x:1303,y:876,t:1527876589142};\\\", \\\"{x:1303,y:875,t:1527876589157};\\\", \\\"{x:1303,y:874,t:1527876589174};\\\", \\\"{x:1302,y:871,t:1527876589191};\\\", \\\"{x:1301,y:868,t:1527876589208};\\\", \\\"{x:1300,y:864,t:1527876589225};\\\", \\\"{x:1300,y:863,t:1527876589243};\\\", \\\"{x:1299,y:860,t:1527876589258};\\\", \\\"{x:1297,y:856,t:1527876589275};\\\", \\\"{x:1296,y:854,t:1527876589291};\\\", \\\"{x:1294,y:847,t:1527876589307};\\\", \\\"{x:1292,y:841,t:1527876589323};\\\", \\\"{x:1291,y:834,t:1527876589340};\\\", \\\"{x:1289,y:827,t:1527876589357};\\\", \\\"{x:1289,y:821,t:1527876589374};\\\", \\\"{x:1289,y:813,t:1527876589391};\\\", \\\"{x:1289,y:800,t:1527876589407};\\\", \\\"{x:1289,y:791,t:1527876589424};\\\", \\\"{x:1289,y:784,t:1527876589441};\\\", \\\"{x:1289,y:780,t:1527876589457};\\\", \\\"{x:1289,y:772,t:1527876589474};\\\", \\\"{x:1289,y:764,t:1527876589491};\\\", \\\"{x:1289,y:756,t:1527876589508};\\\", \\\"{x:1289,y:745,t:1527876589523};\\\", \\\"{x:1289,y:738,t:1527876589541};\\\", \\\"{x:1289,y:729,t:1527876589558};\\\", \\\"{x:1289,y:718,t:1527876589574};\\\", \\\"{x:1289,y:710,t:1527876589591};\\\", \\\"{x:1289,y:699,t:1527876589608};\\\", \\\"{x:1289,y:686,t:1527876589623};\\\", \\\"{x:1289,y:675,t:1527876589640};\\\", \\\"{x:1289,y:659,t:1527876589658};\\\", \\\"{x:1289,y:647,t:1527876589674};\\\", \\\"{x:1289,y:636,t:1527876589691};\\\", \\\"{x:1289,y:625,t:1527876589708};\\\", \\\"{x:1289,y:615,t:1527876589724};\\\", \\\"{x:1288,y:604,t:1527876589741};\\\", \\\"{x:1287,y:601,t:1527876589758};\\\", \\\"{x:1287,y:596,t:1527876589774};\\\", \\\"{x:1286,y:591,t:1527876589792};\\\", \\\"{x:1285,y:582,t:1527876589809};\\\", \\\"{x:1284,y:578,t:1527876589825};\\\", \\\"{x:1282,y:575,t:1527876589842};\\\", \\\"{x:1280,y:573,t:1527876589859};\\\", \\\"{x:1280,y:572,t:1527876589875};\\\", \\\"{x:1279,y:571,t:1527876589891};\\\", \\\"{x:1278,y:570,t:1527876589909};\\\", \\\"{x:1277,y:569,t:1527876589925};\\\", \\\"{x:1276,y:567,t:1527876589942};\\\", \\\"{x:1276,y:565,t:1527876589958};\\\", \\\"{x:1274,y:560,t:1527876589974};\\\", \\\"{x:1272,y:557,t:1527876589991};\\\", \\\"{x:1270,y:553,t:1527876590008};\\\", \\\"{x:1269,y:550,t:1527876590024};\\\", \\\"{x:1267,y:547,t:1527876590041};\\\", \\\"{x:1266,y:546,t:1527876590058};\\\", \\\"{x:1265,y:547,t:1527876590155};\\\", \\\"{x:1260,y:552,t:1527876590163};\\\", \\\"{x:1254,y:559,t:1527876590176};\\\", \\\"{x:1231,y:581,t:1527876590191};\\\", \\\"{x:1187,y:606,t:1527876590208};\\\", \\\"{x:1121,y:634,t:1527876590225};\\\", \\\"{x:1047,y:651,t:1527876590242};\\\", \\\"{x:970,y:663,t:1527876590259};\\\", \\\"{x:921,y:665,t:1527876590275};\\\", \\\"{x:877,y:665,t:1527876590291};\\\", \\\"{x:842,y:665,t:1527876590308};\\\", \\\"{x:804,y:662,t:1527876590325};\\\", \\\"{x:760,y:656,t:1527876590341};\\\", \\\"{x:722,y:653,t:1527876590358};\\\", \\\"{x:684,y:650,t:1527876590376};\\\", \\\"{x:653,y:650,t:1527876590391};\\\", \\\"{x:633,y:650,t:1527876590408};\\\", \\\"{x:621,y:651,t:1527876590425};\\\", \\\"{x:608,y:657,t:1527876590443};\\\", \\\"{x:588,y:676,t:1527876590457};\\\", \\\"{x:572,y:691,t:1527876590475};\\\", \\\"{x:555,y:701,t:1527876590491};\\\", \\\"{x:535,y:706,t:1527876590507};\\\", \\\"{x:517,y:707,t:1527876590524};\\\", \\\"{x:501,y:708,t:1527876590541};\\\", \\\"{x:496,y:709,t:1527876590559};\\\", \\\"{x:495,y:710,t:1527876590575};\\\", \\\"{x:494,y:710,t:1527876590592};\\\", \\\"{x:493,y:710,t:1527876590609};\\\", \\\"{x:489,y:715,t:1527876590625};\\\", \\\"{x:486,y:731,t:1527876590642};\\\", \\\"{x:483,y:739,t:1527876590660};\\\", \\\"{x:481,y:744,t:1527876590676};\\\", \\\"{x:480,y:746,t:1527876590691};\\\", \\\"{x:480,y:747,t:1527876590708};\\\", \\\"{x:480,y:748,t:1527876590754};\\\", \\\"{x:480,y:749,t:1527876590762};\\\", \\\"{x:481,y:750,t:1527876590775};\\\", \\\"{x:482,y:751,t:1527876590792};\\\", \\\"{x:485,y:753,t:1527876590808};\\\", \\\"{x:486,y:753,t:1527876590825};\\\", \\\"{x:488,y:754,t:1527876590842};\\\", \\\"{x:490,y:754,t:1527876590858};\\\", \\\"{x:493,y:758,t:1527876590875};\\\", \\\"{x:495,y:758,t:1527876590892};\\\", \\\"{x:496,y:759,t:1527876590909};\\\", \\\"{x:497,y:759,t:1527876591210};\\\" ] }, { \\\"rt\\\": 26324, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 231051, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:760,t:1527876594890};\\\", \\\"{x:498,y:759,t:1527876594906};\\\", \\\"{x:498,y:758,t:1527876594917};\\\", \\\"{x:498,y:757,t:1527876594934};\\\", \\\"{x:500,y:755,t:1527876594961};\\\", \\\"{x:503,y:753,t:1527876594969};\\\", \\\"{x:504,y:753,t:1527876594984};\\\", \\\"{x:507,y:753,t:1527876595001};\\\", \\\"{x:511,y:753,t:1527876595017};\\\", \\\"{x:515,y:753,t:1527876595035};\\\", \\\"{x:520,y:751,t:1527876595051};\\\", \\\"{x:526,y:750,t:1527876595068};\\\", \\\"{x:532,y:750,t:1527876595085};\\\", \\\"{x:542,y:749,t:1527876595101};\\\", \\\"{x:552,y:747,t:1527876595118};\\\", \\\"{x:571,y:746,t:1527876595136};\\\", \\\"{x:594,y:746,t:1527876595152};\\\", \\\"{x:617,y:746,t:1527876595167};\\\", \\\"{x:639,y:746,t:1527876595177};\\\", \\\"{x:665,y:746,t:1527876595195};\\\", \\\"{x:684,y:746,t:1527876595211};\\\", \\\"{x:703,y:746,t:1527876595228};\\\", \\\"{x:717,y:746,t:1527876595244};\\\", \\\"{x:728,y:745,t:1527876595261};\\\", \\\"{x:739,y:743,t:1527876595278};\\\", \\\"{x:747,y:741,t:1527876595294};\\\", \\\"{x:750,y:741,t:1527876595890};\\\", \\\"{x:751,y:741,t:1527876595898};\\\", \\\"{x:752,y:741,t:1527876595913};\\\", \\\"{x:754,y:741,t:1527876595928};\\\", \\\"{x:758,y:741,t:1527876595945};\\\", \\\"{x:759,y:741,t:1527876595962};\\\", \\\"{x:760,y:741,t:1527876596090};\\\", \\\"{x:761,y:741,t:1527876596106};\\\", \\\"{x:764,y:742,t:1527876596114};\\\", \\\"{x:768,y:743,t:1527876596128};\\\", \\\"{x:776,y:743,t:1527876596145};\\\", \\\"{x:789,y:747,t:1527876596162};\\\", \\\"{x:797,y:748,t:1527876596178};\\\", \\\"{x:805,y:750,t:1527876596195};\\\", \\\"{x:809,y:751,t:1527876596212};\\\", \\\"{x:812,y:751,t:1527876596229};\\\", \\\"{x:819,y:752,t:1527876596246};\\\", \\\"{x:834,y:753,t:1527876596263};\\\", \\\"{x:854,y:756,t:1527876596280};\\\", \\\"{x:868,y:758,t:1527876596295};\\\", \\\"{x:885,y:761,t:1527876596313};\\\", \\\"{x:903,y:763,t:1527876596329};\\\", \\\"{x:918,y:766,t:1527876596345};\\\", \\\"{x:943,y:768,t:1527876596363};\\\", \\\"{x:963,y:773,t:1527876596379};\\\", \\\"{x:981,y:777,t:1527876596396};\\\", \\\"{x:995,y:779,t:1527876596412};\\\", \\\"{x:1012,y:783,t:1527876596429};\\\", \\\"{x:1023,y:786,t:1527876596445};\\\", \\\"{x:1036,y:788,t:1527876596462};\\\", \\\"{x:1057,y:793,t:1527876596479};\\\", \\\"{x:1072,y:793,t:1527876596495};\\\", \\\"{x:1087,y:794,t:1527876596513};\\\", \\\"{x:1100,y:796,t:1527876596529};\\\", \\\"{x:1106,y:797,t:1527876596545};\\\", \\\"{x:1115,y:799,t:1527876596562};\\\", \\\"{x:1122,y:801,t:1527876596580};\\\", \\\"{x:1135,y:801,t:1527876596595};\\\", \\\"{x:1141,y:802,t:1527876596612};\\\", \\\"{x:1147,y:803,t:1527876596630};\\\", \\\"{x:1158,y:805,t:1527876596645};\\\", \\\"{x:1168,y:807,t:1527876596663};\\\", \\\"{x:1171,y:807,t:1527876596680};\\\", \\\"{x:1173,y:807,t:1527876596696};\\\", \\\"{x:1174,y:807,t:1527876596712};\\\", \\\"{x:1174,y:808,t:1527876596762};\\\", \\\"{x:1175,y:809,t:1527876596811};\\\", \\\"{x:1177,y:809,t:1527876596851};\\\", \\\"{x:1178,y:809,t:1527876596866};\\\", \\\"{x:1179,y:809,t:1527876596882};\\\", \\\"{x:1179,y:810,t:1527876597259};\\\", \\\"{x:1180,y:810,t:1527876597266};\\\", \\\"{x:1183,y:811,t:1527876597283};\\\", \\\"{x:1184,y:811,t:1527876597297};\\\", \\\"{x:1187,y:812,t:1527876597313};\\\", \\\"{x:1191,y:813,t:1527876597330};\\\", \\\"{x:1194,y:813,t:1527876597346};\\\", \\\"{x:1195,y:813,t:1527876597370};\\\", \\\"{x:1196,y:813,t:1527876597459};\\\", \\\"{x:1197,y:813,t:1527876597466};\\\", \\\"{x:1199,y:814,t:1527876597480};\\\", \\\"{x:1206,y:814,t:1527876597497};\\\", \\\"{x:1233,y:814,t:1527876597514};\\\", \\\"{x:1287,y:814,t:1527876597530};\\\", \\\"{x:1401,y:791,t:1527876597546};\\\", \\\"{x:1501,y:759,t:1527876597563};\\\", \\\"{x:1607,y:719,t:1527876597579};\\\", \\\"{x:1699,y:678,t:1527876597596};\\\", \\\"{x:1795,y:618,t:1527876597613};\\\", \\\"{x:1854,y:563,t:1527876597630};\\\", \\\"{x:1886,y:511,t:1527876597647};\\\", \\\"{x:1901,y:466,t:1527876597663};\\\", \\\"{x:1903,y:430,t:1527876597680};\\\", \\\"{x:1903,y:405,t:1527876597696};\\\", \\\"{x:1900,y:379,t:1527876597714};\\\", \\\"{x:1893,y:368,t:1527876597730};\\\", \\\"{x:1882,y:359,t:1527876597746};\\\", \\\"{x:1862,y:353,t:1527876597764};\\\", \\\"{x:1829,y:353,t:1527876597780};\\\", \\\"{x:1805,y:353,t:1527876597797};\\\", \\\"{x:1763,y:361,t:1527876597814};\\\", \\\"{x:1724,y:371,t:1527876597831};\\\", \\\"{x:1680,y:376,t:1527876597847};\\\", \\\"{x:1648,y:381,t:1527876597864};\\\", \\\"{x:1624,y:383,t:1527876597881};\\\", \\\"{x:1607,y:387,t:1527876597897};\\\", \\\"{x:1598,y:388,t:1527876597914};\\\", \\\"{x:1595,y:390,t:1527876597931};\\\", \\\"{x:1593,y:392,t:1527876597955};\\\", \\\"{x:1593,y:394,t:1527876597970};\\\", \\\"{x:1593,y:395,t:1527876597981};\\\", \\\"{x:1593,y:397,t:1527876597997};\\\", \\\"{x:1593,y:398,t:1527876598014};\\\", \\\"{x:1593,y:399,t:1527876598032};\\\", \\\"{x:1593,y:400,t:1527876598050};\\\", \\\"{x:1593,y:401,t:1527876598065};\\\", \\\"{x:1593,y:402,t:1527876598081};\\\", \\\"{x:1593,y:403,t:1527876598098};\\\", \\\"{x:1594,y:408,t:1527876598114};\\\", \\\"{x:1594,y:411,t:1527876598131};\\\", \\\"{x:1596,y:417,t:1527876598148};\\\", \\\"{x:1597,y:418,t:1527876598164};\\\", \\\"{x:1599,y:420,t:1527876598181};\\\", \\\"{x:1599,y:421,t:1527876598197};\\\", \\\"{x:1599,y:422,t:1527876598226};\\\", \\\"{x:1600,y:425,t:1527876598235};\\\", \\\"{x:1601,y:425,t:1527876598248};\\\", \\\"{x:1602,y:430,t:1527876598265};\\\", \\\"{x:1606,y:438,t:1527876598282};\\\", \\\"{x:1611,y:455,t:1527876598299};\\\", \\\"{x:1613,y:469,t:1527876598314};\\\", \\\"{x:1616,y:483,t:1527876598331};\\\", \\\"{x:1617,y:507,t:1527876598349};\\\", \\\"{x:1623,y:530,t:1527876598365};\\\", \\\"{x:1629,y:550,t:1527876598381};\\\", \\\"{x:1632,y:559,t:1527876598399};\\\", \\\"{x:1632,y:564,t:1527876598414};\\\", \\\"{x:1632,y:565,t:1527876598431};\\\", \\\"{x:1633,y:567,t:1527876598448};\\\", \\\"{x:1633,y:572,t:1527876598465};\\\", \\\"{x:1634,y:578,t:1527876598481};\\\", \\\"{x:1634,y:589,t:1527876598499};\\\", \\\"{x:1634,y:599,t:1527876598514};\\\", \\\"{x:1634,y:608,t:1527876598531};\\\", \\\"{x:1634,y:614,t:1527876598548};\\\", \\\"{x:1631,y:622,t:1527876598564};\\\", \\\"{x:1629,y:628,t:1527876598581};\\\", \\\"{x:1627,y:632,t:1527876598599};\\\", \\\"{x:1626,y:636,t:1527876598615};\\\", \\\"{x:1625,y:637,t:1527876598631};\\\", \\\"{x:1623,y:639,t:1527876598648};\\\", \\\"{x:1615,y:643,t:1527876598665};\\\", \\\"{x:1598,y:650,t:1527876598681};\\\", \\\"{x:1563,y:661,t:1527876598698};\\\", \\\"{x:1535,y:669,t:1527876598715};\\\", \\\"{x:1507,y:676,t:1527876598732};\\\", \\\"{x:1486,y:681,t:1527876598748};\\\", \\\"{x:1476,y:681,t:1527876598765};\\\", \\\"{x:1471,y:681,t:1527876598782};\\\", \\\"{x:1468,y:681,t:1527876598799};\\\", \\\"{x:1466,y:681,t:1527876598815};\\\", \\\"{x:1458,y:681,t:1527876598832};\\\", \\\"{x:1443,y:681,t:1527876598849};\\\", \\\"{x:1421,y:681,t:1527876598866};\\\", \\\"{x:1392,y:684,t:1527876598882};\\\", \\\"{x:1349,y:685,t:1527876598898};\\\", \\\"{x:1319,y:685,t:1527876598915};\\\", \\\"{x:1292,y:685,t:1527876598931};\\\", \\\"{x:1272,y:685,t:1527876598948};\\\", \\\"{x:1251,y:685,t:1527876598966};\\\", \\\"{x:1240,y:685,t:1527876598981};\\\", \\\"{x:1234,y:685,t:1527876598998};\\\", \\\"{x:1231,y:686,t:1527876599015};\\\", \\\"{x:1223,y:686,t:1527876599032};\\\", \\\"{x:1211,y:686,t:1527876599049};\\\", \\\"{x:1197,y:689,t:1527876599065};\\\", \\\"{x:1182,y:692,t:1527876599082};\\\", \\\"{x:1156,y:692,t:1527876599098};\\\", \\\"{x:1137,y:692,t:1527876599116};\\\", \\\"{x:1119,y:692,t:1527876599132};\\\", \\\"{x:1088,y:686,t:1527876599149};\\\", \\\"{x:1049,y:675,t:1527876599165};\\\", \\\"{x:985,y:658,t:1527876599182};\\\", \\\"{x:925,y:645,t:1527876599200};\\\", \\\"{x:863,y:633,t:1527876599216};\\\", \\\"{x:799,y:616,t:1527876599232};\\\", \\\"{x:733,y:598,t:1527876599249};\\\", \\\"{x:699,y:588,t:1527876599265};\\\", \\\"{x:663,y:574,t:1527876599282};\\\", \\\"{x:649,y:568,t:1527876599298};\\\", \\\"{x:644,y:566,t:1527876599315};\\\", \\\"{x:640,y:564,t:1527876599332};\\\", \\\"{x:631,y:560,t:1527876599349};\\\", \\\"{x:616,y:555,t:1527876599365};\\\", \\\"{x:596,y:549,t:1527876599382};\\\", \\\"{x:572,y:543,t:1527876599398};\\\", \\\"{x:550,y:537,t:1527876599415};\\\", \\\"{x:534,y:531,t:1527876599432};\\\", \\\"{x:526,y:528,t:1527876599448};\\\", \\\"{x:517,y:526,t:1527876599464};\\\", \\\"{x:512,y:524,t:1527876599482};\\\", \\\"{x:511,y:524,t:1527876599585};\\\", \\\"{x:510,y:524,t:1527876599699};\\\", \\\"{x:509,y:523,t:1527876600179};\\\", \\\"{x:510,y:524,t:1527876600370};\\\", \\\"{x:511,y:524,t:1527876600383};\\\", \\\"{x:513,y:525,t:1527876600400};\\\", \\\"{x:513,y:526,t:1527876600417};\\\", \\\"{x:514,y:526,t:1527876600442};\\\", \\\"{x:514,y:527,t:1527876600538};\\\", \\\"{x:514,y:529,t:1527876600578};\\\", \\\"{x:514,y:530,t:1527876600594};\\\", \\\"{x:513,y:530,t:1527876601474};\\\", \\\"{x:512,y:531,t:1527876601498};\\\", \\\"{x:515,y:534,t:1527876602978};\\\", \\\"{x:531,y:539,t:1527876602985};\\\", \\\"{x:568,y:544,t:1527876603002};\\\", \\\"{x:613,y:550,t:1527876603019};\\\", \\\"{x:660,y:556,t:1527876603033};\\\", \\\"{x:703,y:563,t:1527876603050};\\\", \\\"{x:739,y:568,t:1527876603069};\\\", \\\"{x:767,y:573,t:1527876603085};\\\", \\\"{x:798,y:579,t:1527876603101};\\\", \\\"{x:829,y:582,t:1527876603118};\\\", \\\"{x:856,y:587,t:1527876603135};\\\", \\\"{x:881,y:590,t:1527876603151};\\\", \\\"{x:905,y:593,t:1527876603168};\\\", \\\"{x:952,y:599,t:1527876603186};\\\", \\\"{x:1002,y:606,t:1527876603201};\\\", \\\"{x:1064,y:615,t:1527876603218};\\\", \\\"{x:1129,y:620,t:1527876603235};\\\", \\\"{x:1176,y:623,t:1527876603251};\\\", \\\"{x:1233,y:627,t:1527876603269};\\\", \\\"{x:1293,y:632,t:1527876603285};\\\", \\\"{x:1379,y:641,t:1527876603302};\\\", \\\"{x:1454,y:650,t:1527876603319};\\\", \\\"{x:1516,y:653,t:1527876603335};\\\", \\\"{x:1569,y:653,t:1527876603351};\\\", \\\"{x:1611,y:653,t:1527876603368};\\\", \\\"{x:1644,y:653,t:1527876603385};\\\", \\\"{x:1663,y:653,t:1527876603401};\\\", \\\"{x:1674,y:653,t:1527876603418};\\\", \\\"{x:1680,y:653,t:1527876603435};\\\", \\\"{x:1692,y:649,t:1527876603451};\\\", \\\"{x:1701,y:648,t:1527876603468};\\\", \\\"{x:1705,y:644,t:1527876603485};\\\", \\\"{x:1707,y:638,t:1527876603502};\\\", \\\"{x:1708,y:630,t:1527876603519};\\\", \\\"{x:1708,y:617,t:1527876603536};\\\", \\\"{x:1704,y:603,t:1527876603553};\\\", \\\"{x:1691,y:588,t:1527876603569};\\\", \\\"{x:1670,y:568,t:1527876603585};\\\", \\\"{x:1655,y:555,t:1527876603602};\\\", \\\"{x:1645,y:544,t:1527876603618};\\\", \\\"{x:1633,y:532,t:1527876603635};\\\", \\\"{x:1623,y:520,t:1527876603653};\\\", \\\"{x:1616,y:508,t:1527876603668};\\\", \\\"{x:1612,y:497,t:1527876603685};\\\", \\\"{x:1610,y:486,t:1527876603703};\\\", \\\"{x:1610,y:476,t:1527876603718};\\\", \\\"{x:1610,y:465,t:1527876603735};\\\", \\\"{x:1610,y:456,t:1527876603753};\\\", \\\"{x:1612,y:446,t:1527876603769};\\\", \\\"{x:1618,y:434,t:1527876603797};\\\", \\\"{x:1628,y:428,t:1527876603820};\\\", \\\"{x:1632,y:426,t:1527876603835};\\\", \\\"{x:1637,y:421,t:1527876603852};\\\", \\\"{x:1638,y:419,t:1527876603869};\\\", \\\"{x:1639,y:416,t:1527876603885};\\\", \\\"{x:1640,y:415,t:1527876603902};\\\", \\\"{x:1638,y:415,t:1527876604043};\\\", \\\"{x:1635,y:416,t:1527876604053};\\\", \\\"{x:1633,y:417,t:1527876604070};\\\", \\\"{x:1629,y:417,t:1527876604085};\\\", \\\"{x:1627,y:418,t:1527876604102};\\\", \\\"{x:1625,y:419,t:1527876604120};\\\", \\\"{x:1623,y:420,t:1527876604162};\\\", \\\"{x:1622,y:420,t:1527876604186};\\\", \\\"{x:1622,y:421,t:1527876604218};\\\", \\\"{x:1621,y:421,t:1527876604274};\\\", \\\"{x:1621,y:422,t:1527876604290};\\\", \\\"{x:1620,y:422,t:1527876604306};\\\", \\\"{x:1619,y:423,t:1527876604433};\\\", \\\"{x:1619,y:425,t:1527876604450};\\\", \\\"{x:1617,y:427,t:1527876604459};\\\", \\\"{x:1616,y:429,t:1527876604486};\\\", \\\"{x:1616,y:430,t:1527876604502};\\\", \\\"{x:1615,y:432,t:1527876604529};\\\", \\\"{x:1614,y:433,t:1527876613859};\\\", \\\"{x:1609,y:447,t:1527876613869};\\\", \\\"{x:1586,y:478,t:1527876613894};\\\", \\\"{x:1576,y:490,t:1527876613910};\\\", \\\"{x:1562,y:502,t:1527876613926};\\\", \\\"{x:1554,y:509,t:1527876613943};\\\", \\\"{x:1549,y:512,t:1527876613961};\\\", \\\"{x:1545,y:515,t:1527876613977};\\\", \\\"{x:1541,y:525,t:1527876613993};\\\", \\\"{x:1539,y:531,t:1527876614011};\\\", \\\"{x:1536,y:536,t:1527876614027};\\\", \\\"{x:1534,y:543,t:1527876614043};\\\", \\\"{x:1532,y:549,t:1527876614060};\\\", \\\"{x:1531,y:556,t:1527876614077};\\\", \\\"{x:1530,y:560,t:1527876614094};\\\", \\\"{x:1529,y:563,t:1527876614110};\\\", \\\"{x:1529,y:566,t:1527876614126};\\\", \\\"{x:1527,y:572,t:1527876614144};\\\", \\\"{x:1526,y:580,t:1527876614161};\\\", \\\"{x:1523,y:589,t:1527876614176};\\\", \\\"{x:1521,y:596,t:1527876614194};\\\", \\\"{x:1518,y:603,t:1527876614210};\\\", \\\"{x:1517,y:606,t:1527876614226};\\\", \\\"{x:1516,y:608,t:1527876614243};\\\", \\\"{x:1516,y:610,t:1527876614261};\\\", \\\"{x:1516,y:611,t:1527876614277};\\\", \\\"{x:1516,y:613,t:1527876614293};\\\", \\\"{x:1515,y:615,t:1527876614310};\\\", \\\"{x:1515,y:616,t:1527876614327};\\\", \\\"{x:1515,y:618,t:1527876614343};\\\", \\\"{x:1515,y:619,t:1527876614361};\\\", \\\"{x:1514,y:620,t:1527876614376};\\\", \\\"{x:1514,y:624,t:1527876614393};\\\", \\\"{x:1514,y:626,t:1527876614415};\\\", \\\"{x:1514,y:628,t:1527876614426};\\\", \\\"{x:1514,y:629,t:1527876614449};\\\", \\\"{x:1514,y:630,t:1527876614497};\\\", \\\"{x:1513,y:631,t:1527876614511};\\\", \\\"{x:1513,y:632,t:1527876614527};\\\", \\\"{x:1506,y:638,t:1527876616485};\\\", \\\"{x:1491,y:650,t:1527876616495};\\\", \\\"{x:1448,y:670,t:1527876616511};\\\", \\\"{x:1381,y:688,t:1527876616528};\\\", \\\"{x:1276,y:707,t:1527876616545};\\\", \\\"{x:1209,y:716,t:1527876616562};\\\", \\\"{x:1134,y:718,t:1527876616579};\\\", \\\"{x:1056,y:718,t:1527876616596};\\\", \\\"{x:1003,y:718,t:1527876616612};\\\", \\\"{x:958,y:718,t:1527876616629};\\\", \\\"{x:908,y:718,t:1527876616646};\\\", \\\"{x:853,y:716,t:1527876616662};\\\", \\\"{x:820,y:712,t:1527876616679};\\\", \\\"{x:776,y:706,t:1527876616695};\\\", \\\"{x:740,y:698,t:1527876616713};\\\", \\\"{x:703,y:691,t:1527876616729};\\\", \\\"{x:669,y:681,t:1527876616748};\\\", \\\"{x:643,y:674,t:1527876616762};\\\", \\\"{x:614,y:666,t:1527876616779};\\\", \\\"{x:593,y:659,t:1527876616796};\\\", \\\"{x:585,y:656,t:1527876616812};\\\", \\\"{x:581,y:653,t:1527876616829};\\\", \\\"{x:577,y:649,t:1527876616846};\\\", \\\"{x:574,y:645,t:1527876616863};\\\", \\\"{x:571,y:636,t:1527876616879};\\\", \\\"{x:570,y:629,t:1527876616895};\\\", \\\"{x:569,y:617,t:1527876616913};\\\", \\\"{x:565,y:602,t:1527876616929};\\\", \\\"{x:565,y:598,t:1527876616945};\\\", \\\"{x:565,y:593,t:1527876616962};\\\", \\\"{x:565,y:589,t:1527876616980};\\\", \\\"{x:566,y:586,t:1527876616995};\\\", \\\"{x:566,y:582,t:1527876617013};\\\", \\\"{x:565,y:579,t:1527876617030};\\\", \\\"{x:560,y:579,t:1527876617045};\\\", \\\"{x:554,y:579,t:1527876617063};\\\", \\\"{x:547,y:579,t:1527876617079};\\\", \\\"{x:540,y:579,t:1527876617096};\\\", \\\"{x:534,y:579,t:1527876617113};\\\", \\\"{x:525,y:579,t:1527876617129};\\\", \\\"{x:517,y:579,t:1527876617146};\\\", \\\"{x:505,y:581,t:1527876617163};\\\", \\\"{x:490,y:581,t:1527876617180};\\\", \\\"{x:473,y:581,t:1527876617196};\\\", \\\"{x:453,y:582,t:1527876617212};\\\", \\\"{x:439,y:582,t:1527876617229};\\\", \\\"{x:431,y:582,t:1527876617246};\\\", \\\"{x:422,y:582,t:1527876617262};\\\", \\\"{x:420,y:582,t:1527876617280};\\\", \\\"{x:418,y:582,t:1527876617295};\\\", \\\"{x:415,y:583,t:1527876617314};\\\", \\\"{x:411,y:585,t:1527876617329};\\\", \\\"{x:407,y:589,t:1527876617346};\\\", \\\"{x:402,y:593,t:1527876617362};\\\", \\\"{x:399,y:597,t:1527876617380};\\\", \\\"{x:396,y:600,t:1527876617396};\\\", \\\"{x:393,y:605,t:1527876617413};\\\", \\\"{x:391,y:609,t:1527876617430};\\\", \\\"{x:388,y:615,t:1527876617447};\\\", \\\"{x:387,y:617,t:1527876617462};\\\", \\\"{x:385,y:619,t:1527876617480};\\\", \\\"{x:385,y:620,t:1527876617497};\\\", \\\"{x:384,y:620,t:1527876617513};\\\", \\\"{x:384,y:622,t:1527876617530};\\\", \\\"{x:382,y:623,t:1527876617546};\\\", \\\"{x:382,y:624,t:1527876617698};\\\", \\\"{x:383,y:627,t:1527876617985};\\\", \\\"{x:386,y:631,t:1527876617997};\\\", \\\"{x:388,y:635,t:1527876618014};\\\", \\\"{x:395,y:644,t:1527876618030};\\\", \\\"{x:402,y:651,t:1527876618047};\\\", \\\"{x:412,y:661,t:1527876618064};\\\", \\\"{x:421,y:668,t:1527876618080};\\\", \\\"{x:426,y:672,t:1527876618097};\\\", \\\"{x:431,y:676,t:1527876618112};\\\", \\\"{x:434,y:681,t:1527876618129};\\\", \\\"{x:439,y:686,t:1527876618146};\\\", \\\"{x:441,y:689,t:1527876618164};\\\", \\\"{x:443,y:691,t:1527876618179};\\\", \\\"{x:448,y:696,t:1527876618197};\\\", \\\"{x:451,y:700,t:1527876618214};\\\", \\\"{x:454,y:704,t:1527876618230};\\\", \\\"{x:457,y:708,t:1527876618246};\\\", \\\"{x:460,y:710,t:1527876618263};\\\", \\\"{x:462,y:712,t:1527876618280};\\\", \\\"{x:465,y:717,t:1527876618296};\\\", \\\"{x:467,y:721,t:1527876618313};\\\", \\\"{x:474,y:727,t:1527876618330};\\\", \\\"{x:476,y:729,t:1527876618347};\\\", \\\"{x:478,y:731,t:1527876618363};\\\", \\\"{x:479,y:732,t:1527876618380};\\\", \\\"{x:480,y:735,t:1527876618396};\\\", \\\"{x:481,y:739,t:1527876618414};\\\", \\\"{x:483,y:743,t:1527876618430};\\\", \\\"{x:484,y:745,t:1527876618447};\\\", \\\"{x:485,y:747,t:1527876618463};\\\", \\\"{x:487,y:749,t:1527876618480};\\\", \\\"{x:487,y:751,t:1527876618784};\\\", \\\"{x:488,y:751,t:1527876619418};\\\", \\\"{x:489,y:751,t:1527876619642};\\\", \\\"{x:490,y:751,t:1527876619677};\\\", \\\"{x:491,y:751,t:1527876619682};\\\", \\\"{x:492,y:748,t:1527876619697};\\\", \\\"{x:492,y:745,t:1527876619715};\\\", \\\"{x:492,y:741,t:1527876619731};\\\", \\\"{x:492,y:739,t:1527876619748};\\\" ] }, { \\\"rt\\\": 13250, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 245568, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-F -C -C -C -A -F -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:718,t:1527876619916};\\\", \\\"{x:498,y:716,t:1527876619946};\\\", \\\"{x:499,y:716,t:1527876619969};\\\", \\\"{x:499,y:715,t:1527876619982};\\\", \\\"{x:502,y:711,t:1527876620010};\\\", \\\"{x:503,y:711,t:1527876620017};\\\", \\\"{x:505,y:710,t:1527876620031};\\\", \\\"{x:507,y:708,t:1527876620048};\\\", \\\"{x:509,y:707,t:1527876620065};\\\", \\\"{x:511,y:706,t:1527876620081};\\\", \\\"{x:513,y:705,t:1527876620099};\\\", \\\"{x:513,y:704,t:1527876620137};\\\", \\\"{x:514,y:703,t:1527876620149};\\\", \\\"{x:518,y:700,t:1527876620164};\\\", \\\"{x:523,y:697,t:1527876620182};\\\", \\\"{x:527,y:691,t:1527876620199};\\\", \\\"{x:533,y:683,t:1527876620216};\\\", \\\"{x:538,y:677,t:1527876620232};\\\", \\\"{x:541,y:673,t:1527876620249};\\\", \\\"{x:544,y:669,t:1527876620265};\\\", \\\"{x:554,y:658,t:1527876620281};\\\", \\\"{x:563,y:650,t:1527876620299};\\\", \\\"{x:568,y:644,t:1527876620315};\\\", \\\"{x:577,y:634,t:1527876620331};\\\", \\\"{x:581,y:630,t:1527876620349};\\\", \\\"{x:584,y:625,t:1527876620364};\\\", \\\"{x:590,y:618,t:1527876620382};\\\", \\\"{x:598,y:609,t:1527876620400};\\\", \\\"{x:610,y:600,t:1527876620416};\\\", \\\"{x:652,y:574,t:1527876620484};\\\", \\\"{x:652,y:573,t:1527876620499};\\\", \\\"{x:652,y:572,t:1527876620516};\\\", \\\"{x:652,y:569,t:1527876620532};\\\", \\\"{x:650,y:567,t:1527876620549};\\\", \\\"{x:644,y:562,t:1527876620566};\\\", \\\"{x:631,y:555,t:1527876620582};\\\", \\\"{x:619,y:548,t:1527876620598};\\\", \\\"{x:601,y:539,t:1527876620616};\\\", \\\"{x:563,y:525,t:1527876620633};\\\", \\\"{x:547,y:521,t:1527876620649};\\\", \\\"{x:502,y:509,t:1527876620665};\\\", \\\"{x:476,y:504,t:1527876620682};\\\", \\\"{x:455,y:502,t:1527876620699};\\\", \\\"{x:437,y:499,t:1527876620716};\\\", \\\"{x:423,y:499,t:1527876620732};\\\", \\\"{x:409,y:498,t:1527876620749};\\\", \\\"{x:399,y:498,t:1527876620765};\\\", \\\"{x:390,y:498,t:1527876620781};\\\", \\\"{x:384,y:498,t:1527876620799};\\\", \\\"{x:381,y:498,t:1527876620816};\\\", \\\"{x:379,y:500,t:1527876620832};\\\", \\\"{x:377,y:502,t:1527876620849};\\\", \\\"{x:376,y:502,t:1527876620866};\\\", \\\"{x:375,y:503,t:1527876620889};\\\", \\\"{x:374,y:504,t:1527876620913};\\\", \\\"{x:373,y:505,t:1527876620945};\\\", \\\"{x:375,y:506,t:1527876621146};\\\", \\\"{x:379,y:508,t:1527876621153};\\\", \\\"{x:382,y:508,t:1527876621166};\\\", \\\"{x:390,y:509,t:1527876621183};\\\", \\\"{x:398,y:510,t:1527876621199};\\\", \\\"{x:406,y:513,t:1527876621216};\\\", \\\"{x:415,y:513,t:1527876621233};\\\", \\\"{x:416,y:513,t:1527876621249};\\\", \\\"{x:417,y:513,t:1527876621266};\\\", \\\"{x:418,y:513,t:1527876621305};\\\", \\\"{x:419,y:513,t:1527876621345};\\\", \\\"{x:420,y:513,t:1527876621353};\\\", \\\"{x:421,y:513,t:1527876621366};\\\", \\\"{x:423,y:513,t:1527876621385};\\\", \\\"{x:424,y:513,t:1527876621399};\\\", \\\"{x:426,y:513,t:1527876621418};\\\", \\\"{x:427,y:513,t:1527876621450};\\\", \\\"{x:428,y:513,t:1527876621466};\\\", \\\"{x:429,y:513,t:1527876621498};\\\", \\\"{x:430,y:513,t:1527876621545};\\\", \\\"{x:431,y:513,t:1527876621665};\\\", \\\"{x:432,y:512,t:1527876621770};\\\", \\\"{x:433,y:512,t:1527876622186};\\\", \\\"{x:434,y:512,t:1527876622200};\\\", \\\"{x:438,y:512,t:1527876622217};\\\", \\\"{x:444,y:512,t:1527876622233};\\\", \\\"{x:449,y:512,t:1527876622250};\\\", \\\"{x:461,y:512,t:1527876622266};\\\", \\\"{x:466,y:512,t:1527876622283};\\\", \\\"{x:469,y:512,t:1527876622300};\\\", \\\"{x:470,y:512,t:1527876622370};\\\", \\\"{x:471,y:512,t:1527876622383};\\\", \\\"{x:472,y:512,t:1527876622400};\\\", \\\"{x:476,y:512,t:1527876622416};\\\", \\\"{x:488,y:512,t:1527876622433};\\\", \\\"{x:492,y:512,t:1527876622449};\\\", \\\"{x:500,y:512,t:1527876622466};\\\", \\\"{x:514,y:512,t:1527876622483};\\\", \\\"{x:522,y:512,t:1527876622500};\\\", \\\"{x:536,y:512,t:1527876622516};\\\", \\\"{x:544,y:512,t:1527876622533};\\\", \\\"{x:550,y:512,t:1527876622550};\\\", \\\"{x:559,y:512,t:1527876622567};\\\", \\\"{x:563,y:512,t:1527876622584};\\\", \\\"{x:565,y:512,t:1527876622600};\\\", \\\"{x:572,y:512,t:1527876622616};\\\", \\\"{x:601,y:512,t:1527876622633};\\\", \\\"{x:628,y:512,t:1527876622649};\\\", \\\"{x:654,y:512,t:1527876622666};\\\", \\\"{x:687,y:512,t:1527876622683};\\\", \\\"{x:729,y:514,t:1527876622701};\\\", \\\"{x:759,y:514,t:1527876622716};\\\", \\\"{x:796,y:515,t:1527876622734};\\\", \\\"{x:830,y:516,t:1527876622751};\\\", \\\"{x:856,y:518,t:1527876622766};\\\", \\\"{x:876,y:518,t:1527876622783};\\\", \\\"{x:887,y:518,t:1527876622801};\\\", \\\"{x:888,y:518,t:1527876622817};\\\", \\\"{x:889,y:518,t:1527876622882};\\\", \\\"{x:890,y:518,t:1527876622897};\\\", \\\"{x:891,y:518,t:1527876622906};\\\", \\\"{x:894,y:518,t:1527876622917};\\\", \\\"{x:894,y:520,t:1527876623306};\\\", \\\"{x:890,y:521,t:1527876623318};\\\", \\\"{x:876,y:526,t:1527876623333};\\\", \\\"{x:867,y:529,t:1527876623350};\\\", \\\"{x:853,y:533,t:1527876623368};\\\", \\\"{x:843,y:534,t:1527876623383};\\\", \\\"{x:835,y:535,t:1527876623400};\\\", \\\"{x:831,y:536,t:1527876623418};\\\", \\\"{x:830,y:536,t:1527876623434};\\\", \\\"{x:825,y:538,t:1527876623450};\\\", \\\"{x:816,y:538,t:1527876623467};\\\", \\\"{x:802,y:539,t:1527876623483};\\\", \\\"{x:788,y:542,t:1527876623502};\\\", \\\"{x:773,y:542,t:1527876623516};\\\", \\\"{x:754,y:542,t:1527876623533};\\\", \\\"{x:738,y:542,t:1527876623551};\\\", \\\"{x:722,y:542,t:1527876623568};\\\", \\\"{x:704,y:542,t:1527876623584};\\\", \\\"{x:689,y:542,t:1527876623601};\\\", \\\"{x:674,y:542,t:1527876623617};\\\", \\\"{x:656,y:537,t:1527876623635};\\\", \\\"{x:640,y:531,t:1527876623650};\\\", \\\"{x:620,y:524,t:1527876623668};\\\", \\\"{x:605,y:517,t:1527876623684};\\\", \\\"{x:601,y:515,t:1527876623700};\\\", \\\"{x:605,y:515,t:1527876623786};\\\", \\\"{x:625,y:515,t:1527876623801};\\\", \\\"{x:654,y:515,t:1527876623818};\\\", \\\"{x:708,y:515,t:1527876623835};\\\", \\\"{x:776,y:520,t:1527876623851};\\\", \\\"{x:850,y:527,t:1527876623869};\\\", \\\"{x:945,y:541,t:1527876623884};\\\", \\\"{x:1017,y:552,t:1527876623901};\\\", \\\"{x:1063,y:559,t:1527876623918};\\\", \\\"{x:1088,y:563,t:1527876623936};\\\", \\\"{x:1099,y:567,t:1527876623952};\\\", \\\"{x:1108,y:571,t:1527876623969};\\\", \\\"{x:1121,y:576,t:1527876623984};\\\", \\\"{x:1141,y:583,t:1527876624002};\\\", \\\"{x:1157,y:587,t:1527876624018};\\\", \\\"{x:1176,y:593,t:1527876624035};\\\", \\\"{x:1198,y:597,t:1527876624052};\\\", \\\"{x:1223,y:603,t:1527876624069};\\\", \\\"{x:1244,y:609,t:1527876624084};\\\", \\\"{x:1263,y:615,t:1527876624101};\\\", \\\"{x:1277,y:620,t:1527876624118};\\\", \\\"{x:1281,y:623,t:1527876624134};\\\", \\\"{x:1282,y:624,t:1527876624152};\\\", \\\"{x:1283,y:627,t:1527876624168};\\\", \\\"{x:1285,y:631,t:1527876624185};\\\", \\\"{x:1286,y:642,t:1527876624201};\\\", \\\"{x:1286,y:647,t:1527876624218};\\\", \\\"{x:1287,y:650,t:1527876624235};\\\", \\\"{x:1287,y:652,t:1527876624252};\\\", \\\"{x:1287,y:654,t:1527876624268};\\\", \\\"{x:1287,y:655,t:1527876624284};\\\", \\\"{x:1287,y:656,t:1527876624301};\\\", \\\"{x:1287,y:657,t:1527876624318};\\\", \\\"{x:1287,y:658,t:1527876624335};\\\", \\\"{x:1287,y:659,t:1527876624352};\\\", \\\"{x:1287,y:661,t:1527876624369};\\\", \\\"{x:1287,y:662,t:1527876624386};\\\", \\\"{x:1286,y:663,t:1527876624402};\\\", \\\"{x:1285,y:664,t:1527876624418};\\\", \\\"{x:1285,y:665,t:1527876624434};\\\", \\\"{x:1284,y:666,t:1527876624451};\\\", \\\"{x:1284,y:670,t:1527876624468};\\\", \\\"{x:1284,y:675,t:1527876624485};\\\", \\\"{x:1284,y:680,t:1527876624501};\\\", \\\"{x:1287,y:683,t:1527876624518};\\\", \\\"{x:1289,y:686,t:1527876624534};\\\", \\\"{x:1292,y:688,t:1527876624552};\\\", \\\"{x:1300,y:691,t:1527876624569};\\\", \\\"{x:1317,y:699,t:1527876624585};\\\", \\\"{x:1342,y:714,t:1527876624602};\\\", \\\"{x:1356,y:721,t:1527876624617};\\\", \\\"{x:1368,y:730,t:1527876624635};\\\", \\\"{x:1378,y:739,t:1527876624652};\\\", \\\"{x:1385,y:745,t:1527876624669};\\\", \\\"{x:1386,y:746,t:1527876624684};\\\", \\\"{x:1386,y:747,t:1527876624700};\\\", \\\"{x:1386,y:753,t:1527876624718};\\\", \\\"{x:1386,y:760,t:1527876624739};\\\", \\\"{x:1384,y:769,t:1527876624751};\\\", \\\"{x:1375,y:783,t:1527876624768};\\\", \\\"{x:1373,y:787,t:1527876624786};\\\", \\\"{x:1372,y:788,t:1527876624802};\\\", \\\"{x:1371,y:789,t:1527876624819};\\\", \\\"{x:1371,y:790,t:1527876624836};\\\", \\\"{x:1370,y:790,t:1527876624852};\\\", \\\"{x:1366,y:790,t:1527876624869};\\\", \\\"{x:1355,y:793,t:1527876624886};\\\", \\\"{x:1341,y:794,t:1527876624902};\\\", \\\"{x:1327,y:797,t:1527876624919};\\\", \\\"{x:1306,y:798,t:1527876624935};\\\", \\\"{x:1288,y:798,t:1527876624951};\\\", \\\"{x:1268,y:798,t:1527876624969};\\\", \\\"{x:1265,y:798,t:1527876624986};\\\", \\\"{x:1262,y:798,t:1527876625003};\\\", \\\"{x:1261,y:798,t:1527876625019};\\\", \\\"{x:1261,y:799,t:1527876625036};\\\", \\\"{x:1260,y:799,t:1527876625064};\\\", \\\"{x:1259,y:799,t:1527876625073};\\\", \\\"{x:1257,y:799,t:1527876625085};\\\", \\\"{x:1249,y:801,t:1527876625103};\\\", \\\"{x:1236,y:806,t:1527876625118};\\\", \\\"{x:1224,y:812,t:1527876625136};\\\", \\\"{x:1212,y:819,t:1527876625153};\\\", \\\"{x:1207,y:822,t:1527876625170};\\\", \\\"{x:1206,y:823,t:1527876625186};\\\", \\\"{x:1205,y:823,t:1527876625266};\\\", \\\"{x:1205,y:824,t:1527876625273};\\\", \\\"{x:1205,y:825,t:1527876625289};\\\", \\\"{x:1205,y:827,t:1527876625303};\\\", \\\"{x:1206,y:828,t:1527876625410};\\\", \\\"{x:1208,y:829,t:1527876625425};\\\", \\\"{x:1209,y:831,t:1527876625441};\\\", \\\"{x:1215,y:832,t:1527876625453};\\\", \\\"{x:1218,y:833,t:1527876625470};\\\", \\\"{x:1220,y:834,t:1527876625487};\\\", \\\"{x:1220,y:835,t:1527876625601};\\\", \\\"{x:1220,y:834,t:1527876625873};\\\", \\\"{x:1220,y:833,t:1527876625887};\\\", \\\"{x:1219,y:832,t:1527876625907};\\\", \\\"{x:1217,y:831,t:1527876625920};\\\", \\\"{x:1219,y:831,t:1527876627397};\\\", \\\"{x:1229,y:831,t:1527876627411};\\\", \\\"{x:1255,y:831,t:1527876627424};\\\", \\\"{x:1284,y:831,t:1527876627441};\\\", \\\"{x:1321,y:831,t:1527876627458};\\\", \\\"{x:1362,y:827,t:1527876627475};\\\", \\\"{x:1390,y:823,t:1527876627491};\\\", \\\"{x:1412,y:816,t:1527876627507};\\\", \\\"{x:1419,y:813,t:1527876627524};\\\", \\\"{x:1421,y:811,t:1527876627542};\\\", \\\"{x:1421,y:810,t:1527876627558};\\\", \\\"{x:1421,y:807,t:1527876627574};\\\", \\\"{x:1418,y:803,t:1527876627592};\\\", \\\"{x:1411,y:795,t:1527876627608};\\\", \\\"{x:1400,y:790,t:1527876627624};\\\", \\\"{x:1380,y:782,t:1527876627642};\\\", \\\"{x:1362,y:777,t:1527876627658};\\\", \\\"{x:1350,y:775,t:1527876627675};\\\", \\\"{x:1349,y:774,t:1527876627691};\\\", \\\"{x:1348,y:773,t:1527876627733};\\\", \\\"{x:1348,y:772,t:1527876627742};\\\", \\\"{x:1353,y:770,t:1527876627758};\\\", \\\"{x:1367,y:767,t:1527876627775};\\\", \\\"{x:1388,y:766,t:1527876627792};\\\", \\\"{x:1406,y:766,t:1527876627808};\\\", \\\"{x:1414,y:766,t:1527876627825};\\\", \\\"{x:1417,y:765,t:1527876627843};\\\", \\\"{x:1417,y:764,t:1527876627934};\\\", \\\"{x:1413,y:764,t:1527876627942};\\\", \\\"{x:1395,y:764,t:1527876627959};\\\", \\\"{x:1379,y:764,t:1527876627978};\\\", \\\"{x:1368,y:764,t:1527876627992};\\\", \\\"{x:1364,y:763,t:1527876628006};\\\", \\\"{x:1364,y:761,t:1527876628109};\\\", \\\"{x:1365,y:761,t:1527876628133};\\\", \\\"{x:1367,y:761,t:1527876628140};\\\", \\\"{x:1370,y:761,t:1527876628157};\\\", \\\"{x:1371,y:761,t:1527876628173};\\\", \\\"{x:1372,y:760,t:1527876628190};\\\", \\\"{x:1373,y:760,t:1527876628207};\\\", \\\"{x:1375,y:760,t:1527876628229};\\\", \\\"{x:1376,y:760,t:1527876628241};\\\", \\\"{x:1378,y:760,t:1527876628257};\\\", \\\"{x:1379,y:760,t:1527876628275};\\\", \\\"{x:1378,y:760,t:1527876628837};\\\", \\\"{x:1367,y:760,t:1527876628847};\\\", \\\"{x:1352,y:760,t:1527876628859};\\\", \\\"{x:1298,y:760,t:1527876628875};\\\", \\\"{x:1182,y:760,t:1527876628892};\\\", \\\"{x:1084,y:747,t:1527876628909};\\\", \\\"{x:1000,y:742,t:1527876628925};\\\", \\\"{x:938,y:730,t:1527876628942};\\\", \\\"{x:889,y:721,t:1527876628958};\\\", \\\"{x:848,y:711,t:1527876628976};\\\", \\\"{x:823,y:702,t:1527876628992};\\\", \\\"{x:776,y:687,t:1527876629009};\\\", \\\"{x:718,y:670,t:1527876629026};\\\", \\\"{x:668,y:656,t:1527876629042};\\\", \\\"{x:623,y:644,t:1527876629059};\\\", \\\"{x:600,y:640,t:1527876629077};\\\", \\\"{x:586,y:636,t:1527876629092};\\\", \\\"{x:581,y:633,t:1527876629110};\\\", \\\"{x:579,y:631,t:1527876629126};\\\", \\\"{x:570,y:625,t:1527876629143};\\\", \\\"{x:560,y:622,t:1527876629159};\\\", \\\"{x:540,y:615,t:1527876629176};\\\", \\\"{x:506,y:608,t:1527876629194};\\\", \\\"{x:464,y:604,t:1527876629210};\\\", \\\"{x:428,y:599,t:1527876629225};\\\", \\\"{x:404,y:595,t:1527876629243};\\\", \\\"{x:383,y:590,t:1527876629260};\\\", \\\"{x:376,y:588,t:1527876629276};\\\", \\\"{x:369,y:585,t:1527876629293};\\\", \\\"{x:367,y:585,t:1527876629309};\\\", \\\"{x:366,y:585,t:1527876629333};\\\", \\\"{x:363,y:585,t:1527876629343};\\\", \\\"{x:359,y:584,t:1527876629359};\\\", \\\"{x:353,y:584,t:1527876629376};\\\", \\\"{x:352,y:584,t:1527876629393};\\\", \\\"{x:352,y:585,t:1527876629428};\\\", \\\"{x:352,y:587,t:1527876629443};\\\", \\\"{x:352,y:588,t:1527876629460};\\\", \\\"{x:354,y:588,t:1527876629509};\\\", \\\"{x:356,y:590,t:1527876629526};\\\", \\\"{x:359,y:591,t:1527876629542};\\\", \\\"{x:362,y:593,t:1527876629560};\\\", \\\"{x:364,y:593,t:1527876629576};\\\", \\\"{x:366,y:595,t:1527876629593};\\\", \\\"{x:367,y:595,t:1527876629653};\\\", \\\"{x:369,y:596,t:1527876629669};\\\", \\\"{x:370,y:597,t:1527876629693};\\\", \\\"{x:371,y:597,t:1527876629709};\\\", \\\"{x:373,y:597,t:1527876629797};\\\", \\\"{x:373,y:599,t:1527876629812};\\\", \\\"{x:374,y:599,t:1527876629845};\\\", \\\"{x:375,y:599,t:1527876629998};\\\", \\\"{x:377,y:600,t:1527876630010};\\\", \\\"{x:379,y:601,t:1527876630026};\\\", \\\"{x:381,y:601,t:1527876630341};\\\", \\\"{x:407,y:604,t:1527876630348};\\\", \\\"{x:483,y:615,t:1527876630362};\\\", \\\"{x:655,y:639,t:1527876630377};\\\", \\\"{x:849,y:651,t:1527876630394};\\\", \\\"{x:1052,y:662,t:1527876630410};\\\", \\\"{x:1226,y:689,t:1527876630426};\\\", \\\"{x:1346,y:705,t:1527876630444};\\\", \\\"{x:1401,y:718,t:1527876630460};\\\", \\\"{x:1417,y:727,t:1527876630477};\\\", \\\"{x:1417,y:730,t:1527876630493};\\\", \\\"{x:1411,y:733,t:1527876630510};\\\", \\\"{x:1402,y:736,t:1527876630527};\\\", \\\"{x:1391,y:739,t:1527876630543};\\\", \\\"{x:1379,y:741,t:1527876630560};\\\", \\\"{x:1367,y:742,t:1527876630577};\\\", \\\"{x:1356,y:744,t:1527876630594};\\\", \\\"{x:1349,y:746,t:1527876630610};\\\", \\\"{x:1345,y:746,t:1527876630627};\\\", \\\"{x:1345,y:747,t:1527876630749};\\\", \\\"{x:1346,y:748,t:1527876630761};\\\", \\\"{x:1351,y:752,t:1527876630777};\\\", \\\"{x:1355,y:755,t:1527876630794};\\\", \\\"{x:1357,y:756,t:1527876630811};\\\", \\\"{x:1359,y:757,t:1527876630827};\\\", \\\"{x:1359,y:759,t:1527876630844};\\\", \\\"{x:1360,y:759,t:1527876630861};\\\", \\\"{x:1360,y:760,t:1527876630893};\\\", \\\"{x:1361,y:761,t:1527876630911};\\\", \\\"{x:1362,y:763,t:1527876630926};\\\", \\\"{x:1364,y:765,t:1527876630944};\\\", \\\"{x:1365,y:765,t:1527876631021};\\\", \\\"{x:1365,y:766,t:1527876631029};\\\", \\\"{x:1366,y:766,t:1527876631044};\\\", \\\"{x:1370,y:767,t:1527876631061};\\\", \\\"{x:1372,y:768,t:1527876631077};\\\", \\\"{x:1373,y:768,t:1527876631150};\\\", \\\"{x:1374,y:768,t:1527876631161};\\\", \\\"{x:1376,y:768,t:1527876631177};\\\", \\\"{x:1379,y:768,t:1527876631198};\\\", \\\"{x:1384,y:768,t:1527876631210};\\\", \\\"{x:1389,y:768,t:1527876631227};\\\", \\\"{x:1396,y:768,t:1527876631243};\\\", \\\"{x:1402,y:767,t:1527876631260};\\\", \\\"{x:1403,y:767,t:1527876631278};\\\", \\\"{x:1403,y:766,t:1527876631293};\\\", \\\"{x:1401,y:767,t:1527876631437};\\\", \\\"{x:1400,y:767,t:1527876631446};\\\", \\\"{x:1396,y:768,t:1527876631461};\\\", \\\"{x:1395,y:768,t:1527876631478};\\\", \\\"{x:1392,y:768,t:1527876631495};\\\", \\\"{x:1392,y:769,t:1527876631511};\\\", \\\"{x:1391,y:769,t:1527876631533};\\\", \\\"{x:1390,y:769,t:1527876631545};\\\", \\\"{x:1389,y:769,t:1527876631561};\\\", \\\"{x:1388,y:769,t:1527876631581};\\\", \\\"{x:1387,y:769,t:1527876631596};\\\", \\\"{x:1386,y:769,t:1527876631821};\\\", \\\"{x:1386,y:768,t:1527876631885};\\\", \\\"{x:1385,y:767,t:1527876631913};\\\", \\\"{x:1384,y:767,t:1527876631956};\\\", \\\"{x:1383,y:767,t:1527876631972};\\\", \\\"{x:1383,y:766,t:1527876631980};\\\", \\\"{x:1382,y:766,t:1527876632277};\\\", \\\"{x:1375,y:766,t:1527876632287};\\\", \\\"{x:1360,y:766,t:1527876632296};\\\", \\\"{x:1318,y:761,t:1527876632311};\\\", \\\"{x:1235,y:750,t:1527876632329};\\\", \\\"{x:1118,y:731,t:1527876632345};\\\", \\\"{x:996,y:711,t:1527876632361};\\\", \\\"{x:887,y:693,t:1527876632379};\\\", \\\"{x:817,y:682,t:1527876632395};\\\", \\\"{x:773,y:670,t:1527876632412};\\\", \\\"{x:743,y:659,t:1527876632428};\\\", \\\"{x:738,y:658,t:1527876632445};\\\", \\\"{x:736,y:658,t:1527876632462};\\\", \\\"{x:732,y:657,t:1527876632478};\\\", \\\"{x:726,y:657,t:1527876632495};\\\", \\\"{x:713,y:657,t:1527876632512};\\\", \\\"{x:694,y:663,t:1527876632528};\\\", \\\"{x:672,y:683,t:1527876632544};\\\", \\\"{x:650,y:698,t:1527876632562};\\\", \\\"{x:636,y:706,t:1527876632578};\\\", \\\"{x:619,y:714,t:1527876632594};\\\", \\\"{x:607,y:716,t:1527876632611};\\\", \\\"{x:604,y:718,t:1527876632628};\\\", \\\"{x:601,y:719,t:1527876632645};\\\", \\\"{x:596,y:722,t:1527876632661};\\\", \\\"{x:592,y:724,t:1527876632678};\\\", \\\"{x:577,y:726,t:1527876632695};\\\", \\\"{x:559,y:728,t:1527876632712};\\\", \\\"{x:552,y:730,t:1527876632729};\\\", \\\"{x:544,y:733,t:1527876632746};\\\", \\\"{x:534,y:734,t:1527876632761};\\\", \\\"{x:521,y:735,t:1527876632778};\\\", \\\"{x:513,y:738,t:1527876632797};\\\", \\\"{x:504,y:739,t:1527876632812};\\\", \\\"{x:498,y:739,t:1527876632828};\\\", \\\"{x:497,y:739,t:1527876632845};\\\", \\\"{x:496,y:740,t:1527876632862};\\\", \\\"{x:494,y:742,t:1527876632885};\\\", \\\"{x:493,y:743,t:1527876632909};\\\", \\\"{x:492,y:743,t:1527876632924};\\\", \\\"{x:492,y:744,t:1527876632932};\\\", \\\"{x:491,y:744,t:1527876632945};\\\", \\\"{x:490,y:745,t:1527876632964};\\\", \\\"{x:489,y:746,t:1527876632997};\\\", \\\"{x:489,y:748,t:1527876633292};\\\", \\\"{x:487,y:748,t:1527876633308};\\\", \\\"{x:486,y:748,t:1527876633876};\\\", \\\"{x:486,y:745,t:1527876633884};\\\", \\\"{x:486,y:741,t:1527876633896};\\\", \\\"{x:491,y:727,t:1527876633913};\\\", \\\"{x:497,y:716,t:1527876633930};\\\", \\\"{x:503,y:704,t:1527876633946};\\\", \\\"{x:508,y:694,t:1527876633962};\\\", \\\"{x:512,y:682,t:1527876633980};\\\", \\\"{x:516,y:671,t:1527876633996};\\\", \\\"{x:520,y:661,t:1527876634012};\\\", \\\"{x:524,y:652,t:1527876634030};\\\", \\\"{x:530,y:639,t:1527876634046};\\\", \\\"{x:538,y:623,t:1527876634063};\\\", \\\"{x:549,y:610,t:1527876634080};\\\", \\\"{x:556,y:600,t:1527876634097};\\\", \\\"{x:558,y:595,t:1527876634113};\\\", \\\"{x:562,y:587,t:1527876634130};\\\", \\\"{x:566,y:581,t:1527876634147};\\\", \\\"{x:569,y:578,t:1527876634163};\\\", \\\"{x:571,y:574,t:1527876634194};\\\", \\\"{x:572,y:573,t:1527876634228};\\\" ] }, { \\\"rt\\\": 9015, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 255887, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:571,y:571,t:1527876634942};\\\", \\\"{x:562,y:567,t:1527876634948};\\\", \\\"{x:555,y:564,t:1527876634963};\\\", \\\"{x:517,y:557,t:1527876635028};\\\", \\\"{x:516,y:556,t:1527876635052};\\\", \\\"{x:515,y:556,t:1527876635068};\\\", \\\"{x:515,y:555,t:1527876635080};\\\", \\\"{x:513,y:553,t:1527876635097};\\\", \\\"{x:512,y:550,t:1527876635114};\\\", \\\"{x:510,y:546,t:1527876635131};\\\", \\\"{x:508,y:545,t:1527876635147};\\\", \\\"{x:507,y:545,t:1527876635163};\\\", \\\"{x:505,y:545,t:1527876635181};\\\", \\\"{x:505,y:544,t:1527876635629};\\\", \\\"{x:504,y:542,t:1527876635644};\\\", \\\"{x:504,y:540,t:1527876635654};\\\", \\\"{x:502,y:539,t:1527876635668};\\\", \\\"{x:501,y:538,t:1527876635680};\\\", \\\"{x:500,y:536,t:1527876635698};\\\", \\\"{x:499,y:536,t:1527876635713};\\\", \\\"{x:496,y:535,t:1527876635730};\\\", \\\"{x:492,y:532,t:1527876635747};\\\", \\\"{x:487,y:531,t:1527876635764};\\\", \\\"{x:480,y:527,t:1527876635781};\\\", \\\"{x:476,y:524,t:1527876635798};\\\", \\\"{x:474,y:524,t:1527876635814};\\\", \\\"{x:472,y:523,t:1527876635831};\\\", \\\"{x:470,y:521,t:1527876635848};\\\", \\\"{x:468,y:520,t:1527876635865};\\\", \\\"{x:467,y:520,t:1527876635881};\\\", \\\"{x:465,y:520,t:1527876635898};\\\", \\\"{x:468,y:520,t:1527876636004};\\\", \\\"{x:474,y:520,t:1527876636015};\\\", \\\"{x:484,y:520,t:1527876636030};\\\", \\\"{x:497,y:520,t:1527876636048};\\\", \\\"{x:508,y:520,t:1527876636065};\\\", \\\"{x:522,y:520,t:1527876636081};\\\", \\\"{x:534,y:520,t:1527876636098};\\\", \\\"{x:539,y:520,t:1527876636115};\\\", \\\"{x:542,y:520,t:1527876636131};\\\", \\\"{x:543,y:520,t:1527876636229};\\\", \\\"{x:545,y:520,t:1527876636237};\\\", \\\"{x:547,y:520,t:1527876636248};\\\", \\\"{x:549,y:520,t:1527876636265};\\\", \\\"{x:552,y:520,t:1527876636281};\\\", \\\"{x:554,y:520,t:1527876636298};\\\", \\\"{x:556,y:520,t:1527876636315};\\\", \\\"{x:558,y:520,t:1527876636333};\\\", \\\"{x:562,y:520,t:1527876636349};\\\", \\\"{x:567,y:520,t:1527876636365};\\\", \\\"{x:569,y:520,t:1527876636382};\\\", \\\"{x:570,y:520,t:1527876636398};\\\", \\\"{x:572,y:520,t:1527876636437};\\\", \\\"{x:573,y:520,t:1527876636741};\\\", \\\"{x:575,y:520,t:1527876636765};\\\", \\\"{x:577,y:520,t:1527876636783};\\\", \\\"{x:579,y:520,t:1527876636799};\\\", \\\"{x:585,y:520,t:1527876636816};\\\", \\\"{x:591,y:520,t:1527876636832};\\\", \\\"{x:594,y:520,t:1527876636848};\\\", \\\"{x:597,y:520,t:1527876636865};\\\", \\\"{x:602,y:520,t:1527876636882};\\\", \\\"{x:609,y:520,t:1527876636899};\\\", \\\"{x:624,y:521,t:1527876636916};\\\", \\\"{x:644,y:525,t:1527876636932};\\\", \\\"{x:674,y:528,t:1527876636949};\\\", \\\"{x:698,y:532,t:1527876636965};\\\", \\\"{x:721,y:536,t:1527876636982};\\\", \\\"{x:747,y:539,t:1527876637000};\\\", \\\"{x:776,y:544,t:1527876637017};\\\", \\\"{x:812,y:548,t:1527876637032};\\\", \\\"{x:858,y:555,t:1527876637049};\\\", \\\"{x:911,y:561,t:1527876637066};\\\", \\\"{x:972,y:571,t:1527876637082};\\\", \\\"{x:1048,y:584,t:1527876637099};\\\", \\\"{x:1104,y:600,t:1527876637115};\\\", \\\"{x:1155,y:618,t:1527876637132};\\\", \\\"{x:1223,y:649,t:1527876637149};\\\", \\\"{x:1266,y:672,t:1527876637166};\\\", \\\"{x:1310,y:699,t:1527876637182};\\\", \\\"{x:1334,y:714,t:1527876637199};\\\", \\\"{x:1348,y:724,t:1527876637216};\\\", \\\"{x:1365,y:738,t:1527876637231};\\\", \\\"{x:1383,y:749,t:1527876637249};\\\", \\\"{x:1402,y:760,t:1527876637266};\\\", \\\"{x:1415,y:769,t:1527876637282};\\\", \\\"{x:1434,y:776,t:1527876637299};\\\", \\\"{x:1458,y:788,t:1527876637316};\\\", \\\"{x:1482,y:797,t:1527876637332};\\\", \\\"{x:1505,y:804,t:1527876637349};\\\", \\\"{x:1525,y:812,t:1527876637366};\\\", \\\"{x:1546,y:821,t:1527876637382};\\\", \\\"{x:1562,y:830,t:1527876637400};\\\", \\\"{x:1580,y:840,t:1527876637416};\\\", \\\"{x:1588,y:845,t:1527876637432};\\\", \\\"{x:1590,y:846,t:1527876637449};\\\", \\\"{x:1592,y:848,t:1527876637466};\\\", \\\"{x:1594,y:849,t:1527876637482};\\\", \\\"{x:1596,y:850,t:1527876637500};\\\", \\\"{x:1598,y:851,t:1527876637516};\\\", \\\"{x:1605,y:852,t:1527876637533};\\\", \\\"{x:1606,y:852,t:1527876637549};\\\", \\\"{x:1608,y:852,t:1527876637567};\\\", \\\"{x:1610,y:852,t:1527876637686};\\\", \\\"{x:1611,y:852,t:1527876637700};\\\", \\\"{x:1614,y:855,t:1527876637716};\\\", \\\"{x:1622,y:864,t:1527876637732};\\\", \\\"{x:1627,y:870,t:1527876637749};\\\", \\\"{x:1629,y:872,t:1527876637766};\\\", \\\"{x:1629,y:873,t:1527876637783};\\\", \\\"{x:1630,y:874,t:1527876637799};\\\", \\\"{x:1630,y:875,t:1527876637817};\\\", \\\"{x:1630,y:876,t:1527876637837};\\\", \\\"{x:1630,y:877,t:1527876637861};\\\", \\\"{x:1630,y:878,t:1527876637877};\\\", \\\"{x:1630,y:879,t:1527876637885};\\\", \\\"{x:1630,y:880,t:1527876637900};\\\", \\\"{x:1630,y:882,t:1527876637917};\\\", \\\"{x:1622,y:886,t:1527876637933};\\\", \\\"{x:1612,y:890,t:1527876637949};\\\", \\\"{x:1596,y:896,t:1527876637967};\\\", \\\"{x:1584,y:900,t:1527876637983};\\\", \\\"{x:1579,y:901,t:1527876638000};\\\", \\\"{x:1574,y:905,t:1527876638016};\\\", \\\"{x:1572,y:905,t:1527876638032};\\\", \\\"{x:1570,y:905,t:1527876638133};\\\", \\\"{x:1570,y:908,t:1527876638150};\\\", \\\"{x:1570,y:909,t:1527876638166};\\\", \\\"{x:1570,y:911,t:1527876638183};\\\", \\\"{x:1570,y:914,t:1527876638200};\\\", \\\"{x:1571,y:917,t:1527876638216};\\\", \\\"{x:1578,y:923,t:1527876638233};\\\", \\\"{x:1585,y:929,t:1527876638250};\\\", \\\"{x:1589,y:931,t:1527876638267};\\\", \\\"{x:1591,y:931,t:1527876638284};\\\", \\\"{x:1592,y:931,t:1527876638300};\\\", \\\"{x:1592,y:932,t:1527876638317};\\\", \\\"{x:1595,y:934,t:1527876638334};\\\", \\\"{x:1598,y:935,t:1527876638351};\\\", \\\"{x:1601,y:936,t:1527876638367};\\\", \\\"{x:1603,y:937,t:1527876638383};\\\", \\\"{x:1604,y:938,t:1527876638400};\\\", \\\"{x:1605,y:938,t:1527876638416};\\\", \\\"{x:1606,y:939,t:1527876638437};\\\", \\\"{x:1607,y:941,t:1527876638450};\\\", \\\"{x:1608,y:941,t:1527876638467};\\\", \\\"{x:1608,y:943,t:1527876638485};\\\", \\\"{x:1606,y:944,t:1527876638500};\\\", \\\"{x:1590,y:944,t:1527876638516};\\\", \\\"{x:1581,y:941,t:1527876638534};\\\", \\\"{x:1577,y:938,t:1527876638551};\\\", \\\"{x:1575,y:936,t:1527876638568};\\\", \\\"{x:1574,y:929,t:1527876638584};\\\", \\\"{x:1573,y:922,t:1527876638600};\\\", \\\"{x:1573,y:912,t:1527876638617};\\\", \\\"{x:1573,y:896,t:1527876638634};\\\", \\\"{x:1573,y:889,t:1527876638651};\\\", \\\"{x:1573,y:884,t:1527876638667};\\\", \\\"{x:1573,y:882,t:1527876638684};\\\", \\\"{x:1573,y:875,t:1527876638701};\\\", \\\"{x:1573,y:871,t:1527876638717};\\\", \\\"{x:1573,y:868,t:1527876638733};\\\", \\\"{x:1572,y:864,t:1527876638750};\\\", \\\"{x:1568,y:856,t:1527876638767};\\\", \\\"{x:1564,y:851,t:1527876638784};\\\", \\\"{x:1560,y:841,t:1527876638800};\\\", \\\"{x:1550,y:824,t:1527876638817};\\\", \\\"{x:1539,y:809,t:1527876638834};\\\", \\\"{x:1530,y:798,t:1527876638851};\\\", \\\"{x:1520,y:791,t:1527876638867};\\\", \\\"{x:1512,y:785,t:1527876638884};\\\", \\\"{x:1502,y:779,t:1527876638901};\\\", \\\"{x:1494,y:773,t:1527876638917};\\\", \\\"{x:1486,y:766,t:1527876638934};\\\", \\\"{x:1481,y:763,t:1527876638951};\\\", \\\"{x:1479,y:761,t:1527876638967};\\\", \\\"{x:1476,y:759,t:1527876638985};\\\", \\\"{x:1475,y:758,t:1527876639000};\\\", \\\"{x:1470,y:751,t:1527876639018};\\\", \\\"{x:1468,y:747,t:1527876639034};\\\", \\\"{x:1465,y:742,t:1527876639051};\\\", \\\"{x:1463,y:739,t:1527876639068};\\\", \\\"{x:1460,y:730,t:1527876639085};\\\", \\\"{x:1460,y:729,t:1527876639101};\\\", \\\"{x:1454,y:709,t:1527876639118};\\\", \\\"{x:1452,y:703,t:1527876639134};\\\", \\\"{x:1448,y:688,t:1527876639151};\\\", \\\"{x:1441,y:673,t:1527876639168};\\\", \\\"{x:1437,y:665,t:1527876639184};\\\", \\\"{x:1433,y:657,t:1527876639200};\\\", \\\"{x:1426,y:646,t:1527876639217};\\\", \\\"{x:1420,y:635,t:1527876639234};\\\", \\\"{x:1414,y:626,t:1527876639251};\\\", \\\"{x:1412,y:621,t:1527876639268};\\\", \\\"{x:1405,y:606,t:1527876639285};\\\", \\\"{x:1398,y:593,t:1527876639301};\\\", \\\"{x:1396,y:588,t:1527876639317};\\\", \\\"{x:1394,y:579,t:1527876639334};\\\", \\\"{x:1393,y:573,t:1527876639349};\\\", \\\"{x:1393,y:566,t:1527876639367};\\\", \\\"{x:1393,y:564,t:1527876639384};\\\", \\\"{x:1393,y:559,t:1527876639401};\\\", \\\"{x:1393,y:556,t:1527876639417};\\\", \\\"{x:1394,y:554,t:1527876639434};\\\", \\\"{x:1395,y:554,t:1527876639451};\\\", \\\"{x:1395,y:553,t:1527876639467};\\\", \\\"{x:1397,y:553,t:1527876639484};\\\", \\\"{x:1399,y:553,t:1527876639500};\\\", \\\"{x:1400,y:553,t:1527876639524};\\\", \\\"{x:1402,y:553,t:1527876639565};\\\", \\\"{x:1403,y:553,t:1527876639573};\\\", \\\"{x:1404,y:555,t:1527876639585};\\\", \\\"{x:1408,y:559,t:1527876639602};\\\", \\\"{x:1410,y:560,t:1527876639625};\\\", \\\"{x:1410,y:561,t:1527876639651};\\\", \\\"{x:1411,y:561,t:1527876639667};\\\", \\\"{x:1412,y:561,t:1527876639748};\\\", \\\"{x:1413,y:561,t:1527876639845};\\\", \\\"{x:1413,y:562,t:1527876641581};\\\", \\\"{x:1413,y:563,t:1527876641592};\\\", \\\"{x:1405,y:566,t:1527876641612};\\\", \\\"{x:1400,y:568,t:1527876641652};\\\", \\\"{x:1395,y:570,t:1527876641669};\\\", \\\"{x:1391,y:572,t:1527876641686};\\\", \\\"{x:1387,y:574,t:1527876641702};\\\", \\\"{x:1381,y:576,t:1527876641719};\\\", \\\"{x:1370,y:579,t:1527876641736};\\\", \\\"{x:1350,y:582,t:1527876641752};\\\", \\\"{x:1310,y:584,t:1527876641769};\\\", \\\"{x:1245,y:589,t:1527876641786};\\\", \\\"{x:1151,y:589,t:1527876641802};\\\", \\\"{x:1031,y:589,t:1527876641819};\\\", \\\"{x:862,y:589,t:1527876641836};\\\", \\\"{x:790,y:589,t:1527876641853};\\\", \\\"{x:732,y:589,t:1527876641869};\\\", \\\"{x:680,y:587,t:1527876641888};\\\", \\\"{x:640,y:580,t:1527876641903};\\\", \\\"{x:611,y:576,t:1527876641919};\\\", \\\"{x:601,y:575,t:1527876641936};\\\", \\\"{x:595,y:574,t:1527876641953};\\\", \\\"{x:590,y:574,t:1527876641969};\\\", \\\"{x:578,y:574,t:1527876641986};\\\", \\\"{x:567,y:574,t:1527876642003};\\\", \\\"{x:559,y:575,t:1527876642019};\\\", \\\"{x:544,y:580,t:1527876642036};\\\", \\\"{x:526,y:582,t:1527876642053};\\\", \\\"{x:504,y:585,t:1527876642069};\\\", \\\"{x:484,y:588,t:1527876642087};\\\", \\\"{x:465,y:591,t:1527876642103};\\\", \\\"{x:454,y:592,t:1527876642119};\\\", \\\"{x:441,y:594,t:1527876642136};\\\", \\\"{x:431,y:596,t:1527876642153};\\\", \\\"{x:424,y:596,t:1527876642169};\\\", \\\"{x:413,y:597,t:1527876642186};\\\", \\\"{x:398,y:600,t:1527876642202};\\\", \\\"{x:385,y:601,t:1527876642219};\\\", \\\"{x:383,y:603,t:1527876642236};\\\", \\\"{x:390,y:607,t:1527876642253};\\\", \\\"{x:463,y:614,t:1527876642270};\\\", \\\"{x:519,y:614,t:1527876642286};\\\", \\\"{x:558,y:614,t:1527876642303};\\\", \\\"{x:582,y:614,t:1527876642319};\\\", \\\"{x:591,y:614,t:1527876642336};\\\", \\\"{x:597,y:614,t:1527876642353};\\\", \\\"{x:598,y:614,t:1527876642371};\\\", \\\"{x:597,y:614,t:1527876642468};\\\", \\\"{x:597,y:613,t:1527876642549};\\\", \\\"{x:597,y:612,t:1527876642581};\\\", \\\"{x:597,y:610,t:1527876642590};\\\", \\\"{x:597,y:608,t:1527876642603};\\\", \\\"{x:602,y:599,t:1527876642620};\\\", \\\"{x:607,y:592,t:1527876642637};\\\", \\\"{x:609,y:589,t:1527876642653};\\\", \\\"{x:611,y:585,t:1527876642670};\\\", \\\"{x:612,y:585,t:1527876642686};\\\", \\\"{x:613,y:585,t:1527876642703};\\\", \\\"{x:608,y:588,t:1527876642972};\\\", \\\"{x:604,y:594,t:1527876642986};\\\", \\\"{x:593,y:609,t:1527876643003};\\\", \\\"{x:576,y:634,t:1527876643020};\\\", \\\"{x:570,y:645,t:1527876643036};\\\", \\\"{x:563,y:654,t:1527876643053};\\\", \\\"{x:556,y:663,t:1527876643070};\\\", \\\"{x:554,y:671,t:1527876643086};\\\", \\\"{x:551,y:679,t:1527876643103};\\\", \\\"{x:547,y:686,t:1527876643120};\\\", \\\"{x:540,y:698,t:1527876643137};\\\", \\\"{x:535,y:709,t:1527876643154};\\\", \\\"{x:533,y:718,t:1527876643170};\\\", \\\"{x:530,y:726,t:1527876643187};\\\", \\\"{x:528,y:732,t:1527876643203};\\\", \\\"{x:527,y:735,t:1527876643220};\\\", \\\"{x:523,y:743,t:1527876643237};\\\", \\\"{x:522,y:745,t:1527876643253};\\\", \\\"{x:521,y:749,t:1527876643269};\\\", \\\"{x:519,y:752,t:1527876643287};\\\", \\\"{x:519,y:753,t:1527876643304};\\\", \\\"{x:518,y:755,t:1527876643319};\\\", \\\"{x:517,y:756,t:1527876643372};\\\", \\\"{x:521,y:756,t:1527876643596};\\\", \\\"{x:532,y:756,t:1527876643604};\\\", \\\"{x:565,y:756,t:1527876643620};\\\", \\\"{x:588,y:754,t:1527876643637};\\\", \\\"{x:601,y:753,t:1527876643653};\\\", \\\"{x:601,y:751,t:1527876643671};\\\", \\\"{x:602,y:751,t:1527876644109};\\\", \\\"{x:603,y:749,t:1527876644125};\\\", \\\"{x:606,y:748,t:1527876644138};\\\", \\\"{x:610,y:744,t:1527876644154};\\\", \\\"{x:624,y:739,t:1527876644171};\\\", \\\"{x:653,y:724,t:1527876644188};\\\", \\\"{x:680,y:709,t:1527876644203};\\\", \\\"{x:702,y:700,t:1527876644221};\\\", \\\"{x:720,y:690,t:1527876644238};\\\", \\\"{x:733,y:685,t:1527876644254};\\\", \\\"{x:744,y:683,t:1527876644271};\\\", \\\"{x:750,y:681,t:1527876644288};\\\", \\\"{x:753,y:681,t:1527876644304};\\\", \\\"{x:753,y:679,t:1527876644320};\\\", \\\"{x:754,y:678,t:1527876644348};\\\", \\\"{x:755,y:677,t:1527876644364};\\\", \\\"{x:755,y:676,t:1527876644420};\\\" ] }, { \\\"rt\\\": 34840, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 291943, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -K -K -H -I -I -12 PM-Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:756,y:676,t:1527876645493};\\\", \\\"{x:756,y:675,t:1527876645532};\\\", \\\"{x:755,y:672,t:1527876645540};\\\", \\\"{x:753,y:671,t:1527876645554};\\\", \\\"{x:749,y:666,t:1527876645572};\\\", \\\"{x:747,y:661,t:1527876645590};\\\", \\\"{x:746,y:654,t:1527876645604};\\\", \\\"{x:745,y:648,t:1527876645622};\\\", \\\"{x:744,y:644,t:1527876645639};\\\", \\\"{x:741,y:639,t:1527876645655};\\\", \\\"{x:738,y:635,t:1527876645672};\\\", \\\"{x:733,y:631,t:1527876645689};\\\", \\\"{x:729,y:629,t:1527876645706};\\\", \\\"{x:726,y:628,t:1527876645722};\\\", \\\"{x:725,y:627,t:1527876645739};\\\", \\\"{x:724,y:627,t:1527876648341};\\\", \\\"{x:723,y:626,t:1527876648357};\\\", \\\"{x:722,y:625,t:1527876648397};\\\", \\\"{x:719,y:623,t:1527876648409};\\\", \\\"{x:719,y:622,t:1527876648424};\\\", \\\"{x:718,y:622,t:1527876648441};\\\", \\\"{x:717,y:621,t:1527876648457};\\\", \\\"{x:716,y:619,t:1527876648474};\\\", \\\"{x:715,y:617,t:1527876648492};\\\", \\\"{x:715,y:616,t:1527876648508};\\\", \\\"{x:713,y:614,t:1527876648524};\\\", \\\"{x:712,y:610,t:1527876648541};\\\", \\\"{x:711,y:606,t:1527876648558};\\\", \\\"{x:710,y:606,t:1527876648620};\\\", \\\"{x:709,y:606,t:1527876649460};\\\", \\\"{x:709,y:604,t:1527876650037};\\\", \\\"{x:709,y:603,t:1527876650044};\\\", \\\"{x:709,y:602,t:1527876650060};\\\", \\\"{x:709,y:601,t:1527876650076};\\\", \\\"{x:709,y:599,t:1527876650092};\\\", \\\"{x:709,y:598,t:1527876650109};\\\", \\\"{x:709,y:597,t:1527876650126};\\\", \\\"{x:709,y:595,t:1527876650142};\\\", \\\"{x:709,y:594,t:1527876650164};\\\", \\\"{x:709,y:593,t:1527876650178};\\\", \\\"{x:709,y:590,t:1527876650192};\\\", \\\"{x:705,y:586,t:1527876650209};\\\", \\\"{x:701,y:583,t:1527876650225};\\\", \\\"{x:696,y:581,t:1527876650242};\\\", \\\"{x:693,y:579,t:1527876650259};\\\", \\\"{x:690,y:578,t:1527876650276};\\\", \\\"{x:684,y:576,t:1527876650292};\\\", \\\"{x:680,y:576,t:1527876650309};\\\", \\\"{x:676,y:576,t:1527876650326};\\\", \\\"{x:672,y:576,t:1527876650342};\\\", \\\"{x:669,y:576,t:1527876650359};\\\", \\\"{x:671,y:576,t:1527876650404};\\\", \\\"{x:679,y:576,t:1527876650412};\\\", \\\"{x:689,y:576,t:1527876650427};\\\", \\\"{x:730,y:579,t:1527876650444};\\\", \\\"{x:782,y:586,t:1527876650460};\\\", \\\"{x:889,y:600,t:1527876650476};\\\", \\\"{x:956,y:610,t:1527876650492};\\\", \\\"{x:1031,y:617,t:1527876650509};\\\", \\\"{x:1080,y:628,t:1527876650527};\\\", \\\"{x:1109,y:633,t:1527876650542};\\\", \\\"{x:1130,y:640,t:1527876650559};\\\", \\\"{x:1149,y:644,t:1527876650576};\\\", \\\"{x:1167,y:645,t:1527876650593};\\\", \\\"{x:1182,y:645,t:1527876650609};\\\", \\\"{x:1195,y:645,t:1527876650627};\\\", \\\"{x:1210,y:645,t:1527876650643};\\\", \\\"{x:1236,y:641,t:1527876650659};\\\", \\\"{x:1300,y:640,t:1527876650676};\\\", \\\"{x:1349,y:637,t:1527876650694};\\\", \\\"{x:1387,y:629,t:1527876650709};\\\", \\\"{x:1413,y:619,t:1527876650726};\\\", \\\"{x:1427,y:612,t:1527876650743};\\\", \\\"{x:1437,y:607,t:1527876650759};\\\", \\\"{x:1445,y:602,t:1527876650776};\\\", \\\"{x:1450,y:598,t:1527876650794};\\\", \\\"{x:1455,y:593,t:1527876650810};\\\", \\\"{x:1458,y:587,t:1527876650827};\\\", \\\"{x:1458,y:581,t:1527876650844};\\\", \\\"{x:1459,y:576,t:1527876650860};\\\", \\\"{x:1459,y:573,t:1527876650877};\\\", \\\"{x:1459,y:571,t:1527876650894};\\\", \\\"{x:1457,y:569,t:1527876650910};\\\", \\\"{x:1454,y:568,t:1527876650926};\\\", \\\"{x:1452,y:568,t:1527876650943};\\\", \\\"{x:1451,y:568,t:1527876650960};\\\", \\\"{x:1450,y:566,t:1527876650976};\\\", \\\"{x:1448,y:566,t:1527876650993};\\\", \\\"{x:1446,y:565,t:1527876651019};\\\", \\\"{x:1445,y:565,t:1527876651036};\\\", \\\"{x:1443,y:565,t:1527876651052};\\\", \\\"{x:1442,y:565,t:1527876651060};\\\", \\\"{x:1438,y:564,t:1527876651076};\\\", \\\"{x:1435,y:564,t:1527876651093};\\\", \\\"{x:1432,y:564,t:1527876651110};\\\", \\\"{x:1430,y:563,t:1527876651126};\\\", \\\"{x:1429,y:563,t:1527876651144};\\\", \\\"{x:1428,y:563,t:1527876651160};\\\", \\\"{x:1426,y:563,t:1527876651177};\\\", \\\"{x:1424,y:563,t:1527876651193};\\\", \\\"{x:1423,y:563,t:1527876651210};\\\", \\\"{x:1422,y:563,t:1527876651226};\\\", \\\"{x:1421,y:563,t:1527876651244};\\\", \\\"{x:1420,y:563,t:1527876651282};\\\", \\\"{x:1418,y:563,t:1527876651372};\\\", \\\"{x:1417,y:563,t:1527876651380};\\\", \\\"{x:1416,y:563,t:1527876651393};\\\", \\\"{x:1415,y:563,t:1527876651410};\\\", \\\"{x:1413,y:563,t:1527876651426};\\\", \\\"{x:1412,y:563,t:1527876651452};\\\", \\\"{x:1411,y:563,t:1527876651468};\\\", \\\"{x:1410,y:565,t:1527876652485};\\\", \\\"{x:1412,y:567,t:1527876652495};\\\", \\\"{x:1418,y:576,t:1527876652515};\\\", \\\"{x:1428,y:582,t:1527876652527};\\\", \\\"{x:1435,y:586,t:1527876652545};\\\", \\\"{x:1444,y:590,t:1527876652561};\\\", \\\"{x:1451,y:593,t:1527876652577};\\\", \\\"{x:1456,y:594,t:1527876652594};\\\", \\\"{x:1457,y:594,t:1527876652611};\\\", \\\"{x:1459,y:594,t:1527876652627};\\\", \\\"{x:1462,y:595,t:1527876652645};\\\", \\\"{x:1468,y:597,t:1527876652661};\\\", \\\"{x:1475,y:599,t:1527876652678};\\\", \\\"{x:1481,y:602,t:1527876652694};\\\", \\\"{x:1486,y:605,t:1527876652711};\\\", \\\"{x:1491,y:608,t:1527876652727};\\\", \\\"{x:1494,y:611,t:1527876652744};\\\", \\\"{x:1498,y:614,t:1527876652762};\\\", \\\"{x:1499,y:615,t:1527876652778};\\\", \\\"{x:1500,y:616,t:1527876652795};\\\", \\\"{x:1500,y:618,t:1527876652860};\\\", \\\"{x:1500,y:619,t:1527876652932};\\\", \\\"{x:1501,y:619,t:1527876652945};\\\", \\\"{x:1503,y:620,t:1527876652962};\\\", \\\"{x:1505,y:621,t:1527876652978};\\\", \\\"{x:1508,y:623,t:1527876652994};\\\", \\\"{x:1510,y:623,t:1527876653013};\\\", \\\"{x:1512,y:625,t:1527876653033};\\\", \\\"{x:1513,y:626,t:1527876653044};\\\", \\\"{x:1514,y:626,t:1527876653061};\\\", \\\"{x:1516,y:627,t:1527876653078};\\\", \\\"{x:1518,y:628,t:1527876653107};\\\", \\\"{x:1518,y:629,t:1527876653140};\\\", \\\"{x:1519,y:629,t:1527876653172};\\\", \\\"{x:1519,y:630,t:1527876653196};\\\", \\\"{x:1519,y:631,t:1527876653220};\\\", \\\"{x:1519,y:633,t:1527876653236};\\\", \\\"{x:1519,y:636,t:1527876653247};\\\", \\\"{x:1519,y:643,t:1527876653262};\\\", \\\"{x:1518,y:656,t:1527876653278};\\\", \\\"{x:1512,y:672,t:1527876653296};\\\", \\\"{x:1506,y:696,t:1527876653312};\\\", \\\"{x:1499,y:721,t:1527876653329};\\\", \\\"{x:1490,y:748,t:1527876653345};\\\", \\\"{x:1488,y:768,t:1527876653361};\\\", \\\"{x:1486,y:779,t:1527876653378};\\\", \\\"{x:1486,y:785,t:1527876653395};\\\", \\\"{x:1487,y:788,t:1527876653412};\\\", \\\"{x:1492,y:790,t:1527876653428};\\\", \\\"{x:1498,y:793,t:1527876653445};\\\", \\\"{x:1508,y:796,t:1527876653461};\\\", \\\"{x:1518,y:799,t:1527876653479};\\\", \\\"{x:1524,y:801,t:1527876653496};\\\", \\\"{x:1526,y:803,t:1527876653512};\\\", \\\"{x:1527,y:804,t:1527876653529};\\\", \\\"{x:1529,y:806,t:1527876653546};\\\", \\\"{x:1529,y:808,t:1527876653562};\\\", \\\"{x:1530,y:810,t:1527876653579};\\\", \\\"{x:1532,y:814,t:1527876653596};\\\", \\\"{x:1538,y:818,t:1527876653612};\\\", \\\"{x:1548,y:821,t:1527876653629};\\\", \\\"{x:1555,y:822,t:1527876653646};\\\", \\\"{x:1567,y:825,t:1527876653662};\\\", \\\"{x:1578,y:826,t:1527876653679};\\\", \\\"{x:1587,y:827,t:1527876653696};\\\", \\\"{x:1589,y:827,t:1527876653714};\\\", \\\"{x:1581,y:827,t:1527876653797};\\\", \\\"{x:1562,y:827,t:1527876653813};\\\", \\\"{x:1539,y:827,t:1527876653829};\\\", \\\"{x:1495,y:827,t:1527876653846};\\\", \\\"{x:1442,y:827,t:1527876653863};\\\", \\\"{x:1404,y:827,t:1527876653879};\\\", \\\"{x:1383,y:827,t:1527876653896};\\\", \\\"{x:1365,y:827,t:1527876653914};\\\", \\\"{x:1359,y:827,t:1527876653929};\\\", \\\"{x:1356,y:826,t:1527876653946};\\\", \\\"{x:1353,y:826,t:1527876653963};\\\", \\\"{x:1350,y:825,t:1527876653979};\\\", \\\"{x:1348,y:825,t:1527876653997};\\\", \\\"{x:1345,y:825,t:1527876654012};\\\", \\\"{x:1342,y:825,t:1527876654029};\\\", \\\"{x:1337,y:825,t:1527876654046};\\\", \\\"{x:1330,y:825,t:1527876654063};\\\", \\\"{x:1322,y:826,t:1527876654079};\\\", \\\"{x:1318,y:828,t:1527876654096};\\\", \\\"{x:1314,y:830,t:1527876654115};\\\", \\\"{x:1311,y:830,t:1527876654129};\\\", \\\"{x:1310,y:830,t:1527876654189};\\\", \\\"{x:1310,y:823,t:1527876654197};\\\", \\\"{x:1310,y:808,t:1527876654213};\\\", \\\"{x:1316,y:785,t:1527876654230};\\\", \\\"{x:1327,y:758,t:1527876654246};\\\", \\\"{x:1339,y:731,t:1527876654262};\\\", \\\"{x:1356,y:692,t:1527876654280};\\\", \\\"{x:1373,y:656,t:1527876654296};\\\", \\\"{x:1396,y:603,t:1527876654314};\\\", \\\"{x:1410,y:566,t:1527876654330};\\\", \\\"{x:1415,y:538,t:1527876654346};\\\", \\\"{x:1412,y:518,t:1527876654363};\\\", \\\"{x:1401,y:502,t:1527876654379};\\\", \\\"{x:1388,y:493,t:1527876654395};\\\", \\\"{x:1374,y:490,t:1527876654412};\\\", \\\"{x:1367,y:489,t:1527876654430};\\\", \\\"{x:1366,y:489,t:1527876654445};\\\", \\\"{x:1364,y:487,t:1527876654462};\\\", \\\"{x:1362,y:486,t:1527876654479};\\\", \\\"{x:1359,y:484,t:1527876654496};\\\", \\\"{x:1357,y:483,t:1527876654513};\\\", \\\"{x:1354,y:483,t:1527876654532};\\\", \\\"{x:1353,y:483,t:1527876654556};\\\", \\\"{x:1351,y:483,t:1527876654572};\\\", \\\"{x:1350,y:483,t:1527876654580};\\\", \\\"{x:1346,y:484,t:1527876654596};\\\", \\\"{x:1343,y:485,t:1527876654612};\\\", \\\"{x:1340,y:486,t:1527876654629};\\\", \\\"{x:1339,y:486,t:1527876654646};\\\", \\\"{x:1336,y:489,t:1527876654663};\\\", \\\"{x:1333,y:489,t:1527876654680};\\\", \\\"{x:1328,y:491,t:1527876654697};\\\", \\\"{x:1321,y:494,t:1527876654713};\\\", \\\"{x:1311,y:499,t:1527876654733};\\\", \\\"{x:1306,y:501,t:1527876654746};\\\", \\\"{x:1304,y:502,t:1527876654762};\\\", \\\"{x:1302,y:503,t:1527876654779};\\\", \\\"{x:1301,y:503,t:1527876654796};\\\", \\\"{x:1301,y:502,t:1527876654900};\\\", \\\"{x:1303,y:501,t:1527876654913};\\\", \\\"{x:1307,y:498,t:1527876654929};\\\", \\\"{x:1309,y:497,t:1527876654948};\\\", \\\"{x:1309,y:496,t:1527876654963};\\\", \\\"{x:1310,y:496,t:1527876654979};\\\", \\\"{x:1311,y:496,t:1527876655019};\\\", \\\"{x:1317,y:511,t:1527876663447};\\\", \\\"{x:1353,y:600,t:1527876663469};\\\", \\\"{x:1366,y:630,t:1527876663487};\\\", \\\"{x:1371,y:653,t:1527876663502};\\\", \\\"{x:1374,y:664,t:1527876663520};\\\", \\\"{x:1377,y:673,t:1527876663536};\\\", \\\"{x:1381,y:683,t:1527876663552};\\\", \\\"{x:1386,y:694,t:1527876663569};\\\", \\\"{x:1390,y:708,t:1527876663587};\\\", \\\"{x:1392,y:716,t:1527876663603};\\\", \\\"{x:1394,y:732,t:1527876663619};\\\", \\\"{x:1395,y:746,t:1527876663637};\\\", \\\"{x:1398,y:763,t:1527876663653};\\\", \\\"{x:1398,y:777,t:1527876663670};\\\", \\\"{x:1398,y:788,t:1527876663687};\\\", \\\"{x:1396,y:802,t:1527876663703};\\\", \\\"{x:1391,y:823,t:1527876663720};\\\", \\\"{x:1385,y:843,t:1527876663736};\\\", \\\"{x:1377,y:868,t:1527876663753};\\\", \\\"{x:1372,y:892,t:1527876663770};\\\", \\\"{x:1365,y:914,t:1527876663787};\\\", \\\"{x:1360,y:934,t:1527876663803};\\\", \\\"{x:1355,y:950,t:1527876663819};\\\", \\\"{x:1353,y:954,t:1527876663837};\\\", \\\"{x:1352,y:956,t:1527876663893};\\\", \\\"{x:1352,y:957,t:1527876663908};\\\", \\\"{x:1351,y:958,t:1527876663924};\\\", \\\"{x:1351,y:959,t:1527876663940};\\\", \\\"{x:1351,y:960,t:1527876663956};\\\", \\\"{x:1351,y:962,t:1527876663970};\\\", \\\"{x:1351,y:963,t:1527876663988};\\\", \\\"{x:1351,y:965,t:1527876665829};\\\", \\\"{x:1352,y:966,t:1527876665861};\\\", \\\"{x:1353,y:966,t:1527876665884};\\\", \\\"{x:1354,y:966,t:1527876665900};\\\", \\\"{x:1355,y:967,t:1527876665964};\\\", \\\"{x:1356,y:968,t:1527876665997};\\\", \\\"{x:1357,y:969,t:1527876666053};\\\", \\\"{x:1356,y:969,t:1527876666349};\\\", \\\"{x:1355,y:969,t:1527876666356};\\\", \\\"{x:1355,y:968,t:1527876666469};\\\", \\\"{x:1355,y:967,t:1527876666492};\\\", \\\"{x:1355,y:966,t:1527876666508};\\\", \\\"{x:1355,y:965,t:1527876666540};\\\", \\\"{x:1355,y:964,t:1527876666588};\\\", \\\"{x:1355,y:963,t:1527876666749};\\\", \\\"{x:1354,y:962,t:1527876667445};\\\", \\\"{x:1352,y:962,t:1527876669228};\\\", \\\"{x:1351,y:962,t:1527876669268};\\\", \\\"{x:1350,y:962,t:1527876669276};\\\", \\\"{x:1349,y:962,t:1527876669300};\\\", \\\"{x:1348,y:963,t:1527876669403};\\\", \\\"{x:1349,y:963,t:1527876670572};\\\", \\\"{x:1351,y:963,t:1527876670652};\\\", \\\"{x:1352,y:962,t:1527876670683};\\\", \\\"{x:1353,y:962,t:1527876670699};\\\", \\\"{x:1354,y:962,t:1527876670723};\\\", \\\"{x:1354,y:961,t:1527876671509};\\\", \\\"{x:1354,y:960,t:1527876673733};\\\", \\\"{x:1354,y:959,t:1527876673744};\\\", \\\"{x:1355,y:950,t:1527876673761};\\\", \\\"{x:1356,y:944,t:1527876673778};\\\", \\\"{x:1356,y:940,t:1527876673795};\\\", \\\"{x:1356,y:936,t:1527876673811};\\\", \\\"{x:1356,y:933,t:1527876673827};\\\", \\\"{x:1356,y:930,t:1527876673844};\\\", \\\"{x:1356,y:928,t:1527876673860};\\\", \\\"{x:1356,y:927,t:1527876673877};\\\", \\\"{x:1356,y:925,t:1527876673894};\\\", \\\"{x:1356,y:922,t:1527876673911};\\\", \\\"{x:1357,y:919,t:1527876673927};\\\", \\\"{x:1358,y:916,t:1527876673944};\\\", \\\"{x:1358,y:914,t:1527876673961};\\\", \\\"{x:1358,y:911,t:1527876673977};\\\", \\\"{x:1358,y:909,t:1527876673994};\\\", \\\"{x:1358,y:905,t:1527876674012};\\\", \\\"{x:1357,y:903,t:1527876674027};\\\", \\\"{x:1356,y:901,t:1527876674044};\\\", \\\"{x:1355,y:900,t:1527876674061};\\\", \\\"{x:1355,y:897,t:1527876674077};\\\", \\\"{x:1355,y:896,t:1527876674095};\\\", \\\"{x:1354,y:893,t:1527876674112};\\\", \\\"{x:1354,y:891,t:1527876674164};\\\", \\\"{x:1354,y:890,t:1527876674177};\\\", \\\"{x:1353,y:889,t:1527876674195};\\\", \\\"{x:1353,y:888,t:1527876674212};\\\", \\\"{x:1353,y:887,t:1527876674236};\\\", \\\"{x:1353,y:886,t:1527876674268};\\\", \\\"{x:1352,y:885,t:1527876674278};\\\", \\\"{x:1350,y:884,t:1527876674294};\\\", \\\"{x:1349,y:884,t:1527876674340};\\\", \\\"{x:1348,y:884,t:1527876674348};\\\", \\\"{x:1347,y:884,t:1527876674388};\\\", \\\"{x:1346,y:884,t:1527876674484};\\\", \\\"{x:1345,y:885,t:1527876674547};\\\", \\\"{x:1343,y:885,t:1527876674561};\\\", \\\"{x:1343,y:886,t:1527876674577};\\\", \\\"{x:1343,y:887,t:1527876674594};\\\", \\\"{x:1343,y:888,t:1527876674660};\\\", \\\"{x:1343,y:889,t:1527876674667};\\\", \\\"{x:1343,y:890,t:1527876674678};\\\", \\\"{x:1343,y:891,t:1527876674694};\\\", \\\"{x:1344,y:891,t:1527876674772};\\\", \\\"{x:1346,y:892,t:1527876674840};\\\", \\\"{x:1347,y:893,t:1527876674861};\\\", \\\"{x:1348,y:893,t:1527876674878};\\\", \\\"{x:1349,y:893,t:1527876674923};\\\", \\\"{x:1351,y:893,t:1527876675028};\\\", \\\"{x:1347,y:889,t:1527876676206};\\\", \\\"{x:1314,y:877,t:1527876676213};\\\", \\\"{x:1213,y:836,t:1527876676231};\\\", \\\"{x:1115,y:802,t:1527876676246};\\\", \\\"{x:1020,y:787,t:1527876676263};\\\", \\\"{x:939,y:774,t:1527876676280};\\\", \\\"{x:866,y:763,t:1527876676296};\\\", \\\"{x:806,y:748,t:1527876676313};\\\", \\\"{x:750,y:734,t:1527876676330};\\\", \\\"{x:693,y:712,t:1527876676346};\\\", \\\"{x:662,y:694,t:1527876676364};\\\", \\\"{x:648,y:684,t:1527876676380};\\\", \\\"{x:632,y:674,t:1527876676396};\\\", \\\"{x:624,y:666,t:1527876676414};\\\", \\\"{x:619,y:660,t:1527876676431};\\\", \\\"{x:614,y:653,t:1527876676447};\\\", \\\"{x:602,y:643,t:1527876676463};\\\", \\\"{x:582,y:628,t:1527876676481};\\\", \\\"{x:542,y:612,t:1527876676498};\\\", \\\"{x:519,y:605,t:1527876676513};\\\", \\\"{x:500,y:604,t:1527876676530};\\\", \\\"{x:466,y:599,t:1527876676548};\\\", \\\"{x:449,y:599,t:1527876676563};\\\", \\\"{x:439,y:599,t:1527876676580};\\\", \\\"{x:427,y:602,t:1527876676597};\\\", \\\"{x:413,y:612,t:1527876676613};\\\", \\\"{x:408,y:619,t:1527876676630};\\\", \\\"{x:404,y:626,t:1527876676648};\\\", \\\"{x:397,y:637,t:1527876676664};\\\", \\\"{x:390,y:644,t:1527876676680};\\\", \\\"{x:389,y:649,t:1527876676697};\\\", \\\"{x:389,y:651,t:1527876676713};\\\", \\\"{x:389,y:655,t:1527876676730};\\\", \\\"{x:391,y:658,t:1527876676747};\\\", \\\"{x:393,y:659,t:1527876676764};\\\", \\\"{x:393,y:662,t:1527876676780};\\\", \\\"{x:393,y:665,t:1527876676798};\\\", \\\"{x:393,y:667,t:1527876676814};\\\", \\\"{x:393,y:670,t:1527876676831};\\\", \\\"{x:390,y:674,t:1527876676847};\\\", \\\"{x:377,y:676,t:1527876676864};\\\", \\\"{x:360,y:676,t:1527876676881};\\\", \\\"{x:348,y:676,t:1527876676897};\\\", \\\"{x:336,y:676,t:1527876676914};\\\", \\\"{x:320,y:672,t:1527876676930};\\\", \\\"{x:291,y:668,t:1527876676948};\\\", \\\"{x:268,y:667,t:1527876676964};\\\", \\\"{x:240,y:663,t:1527876676980};\\\", \\\"{x:214,y:661,t:1527876676998};\\\", \\\"{x:196,y:658,t:1527876677014};\\\", \\\"{x:176,y:655,t:1527876677031};\\\", \\\"{x:170,y:655,t:1527876677047};\\\", \\\"{x:167,y:654,t:1527876677065};\\\", \\\"{x:171,y:654,t:1527876677149};\\\", \\\"{x:199,y:654,t:1527876677165};\\\", \\\"{x:252,y:654,t:1527876677180};\\\", \\\"{x:347,y:654,t:1527876677198};\\\", \\\"{x:458,y:654,t:1527876677214};\\\", \\\"{x:571,y:654,t:1527876677231};\\\", \\\"{x:671,y:654,t:1527876677247};\\\", \\\"{x:743,y:654,t:1527876677265};\\\", \\\"{x:794,y:654,t:1527876677281};\\\", \\\"{x:819,y:654,t:1527876677297};\\\", \\\"{x:836,y:654,t:1527876677314};\\\", \\\"{x:850,y:654,t:1527876677331};\\\", \\\"{x:860,y:652,t:1527876677347};\\\", \\\"{x:869,y:650,t:1527876677364};\\\", \\\"{x:883,y:647,t:1527876677381};\\\", \\\"{x:897,y:645,t:1527876677396};\\\", \\\"{x:909,y:642,t:1527876677414};\\\", \\\"{x:915,y:641,t:1527876677431};\\\", \\\"{x:910,y:641,t:1527876677475};\\\", \\\"{x:900,y:640,t:1527876677483};\\\", \\\"{x:888,y:640,t:1527876677497};\\\", \\\"{x:851,y:638,t:1527876677515};\\\", \\\"{x:817,y:638,t:1527876677531};\\\", \\\"{x:773,y:635,t:1527876677547};\\\", \\\"{x:747,y:634,t:1527876677564};\\\", \\\"{x:731,y:631,t:1527876677583};\\\", \\\"{x:716,y:630,t:1527876677598};\\\", \\\"{x:706,y:630,t:1527876677615};\\\", \\\"{x:699,y:629,t:1527876677631};\\\", \\\"{x:695,y:629,t:1527876677649};\\\", \\\"{x:690,y:629,t:1527876677664};\\\", \\\"{x:687,y:629,t:1527876677681};\\\", \\\"{x:682,y:629,t:1527876677699};\\\", \\\"{x:672,y:631,t:1527876677715};\\\", \\\"{x:662,y:632,t:1527876677732};\\\", \\\"{x:646,y:635,t:1527876677748};\\\", \\\"{x:631,y:636,t:1527876677764};\\\", \\\"{x:613,y:638,t:1527876677781};\\\", \\\"{x:598,y:646,t:1527876677798};\\\", \\\"{x:584,y:649,t:1527876677814};\\\", \\\"{x:571,y:651,t:1527876677831};\\\", \\\"{x:554,y:653,t:1527876677848};\\\", \\\"{x:539,y:653,t:1527876677864};\\\", \\\"{x:523,y:653,t:1527876677881};\\\", \\\"{x:501,y:653,t:1527876677898};\\\", \\\"{x:473,y:653,t:1527876677915};\\\", \\\"{x:436,y:652,t:1527876677931};\\\", \\\"{x:411,y:649,t:1527876677948};\\\", \\\"{x:385,y:646,t:1527876677965};\\\", \\\"{x:361,y:644,t:1527876677982};\\\", \\\"{x:340,y:639,t:1527876677998};\\\", \\\"{x:318,y:637,t:1527876678015};\\\", \\\"{x:296,y:635,t:1527876678031};\\\", \\\"{x:277,y:635,t:1527876678048};\\\", \\\"{x:264,y:634,t:1527876678066};\\\", \\\"{x:249,y:634,t:1527876678081};\\\", \\\"{x:242,y:633,t:1527876678098};\\\", \\\"{x:240,y:632,t:1527876678114};\\\", \\\"{x:239,y:632,t:1527876678196};\\\", \\\"{x:236,y:632,t:1527876678204};\\\", \\\"{x:232,y:631,t:1527876678216};\\\", \\\"{x:222,y:630,t:1527876678232};\\\", \\\"{x:206,y:628,t:1527876678248};\\\", \\\"{x:191,y:625,t:1527876678265};\\\", \\\"{x:173,y:623,t:1527876678283};\\\", \\\"{x:153,y:618,t:1527876678299};\\\", \\\"{x:134,y:613,t:1527876678315};\\\", \\\"{x:131,y:613,t:1527876678331};\\\", \\\"{x:129,y:612,t:1527876678348};\\\", \\\"{x:129,y:611,t:1527876678371};\\\", \\\"{x:129,y:610,t:1527876678419};\\\", \\\"{x:129,y:609,t:1527876678435};\\\", \\\"{x:129,y:608,t:1527876678459};\\\", \\\"{x:130,y:607,t:1527876678475};\\\", \\\"{x:131,y:607,t:1527876678499};\\\", \\\"{x:132,y:607,t:1527876678515};\\\", \\\"{x:135,y:607,t:1527876678532};\\\", \\\"{x:136,y:607,t:1527876678549};\\\", \\\"{x:138,y:607,t:1527876678566};\\\", \\\"{x:139,y:607,t:1527876678581};\\\", \\\"{x:140,y:607,t:1527876678598};\\\", \\\"{x:142,y:607,t:1527876678616};\\\", \\\"{x:143,y:607,t:1527876678632};\\\", \\\"{x:145,y:607,t:1527876678649};\\\", \\\"{x:147,y:607,t:1527876678666};\\\", \\\"{x:148,y:607,t:1527876678682};\\\", \\\"{x:151,y:607,t:1527876678700};\\\", \\\"{x:154,y:608,t:1527876678715};\\\", \\\"{x:162,y:610,t:1527876678979};\\\", \\\"{x:185,y:617,t:1527876678987};\\\", \\\"{x:213,y:625,t:1527876679000};\\\", \\\"{x:271,y:640,t:1527876679016};\\\", \\\"{x:320,y:652,t:1527876679032};\\\", \\\"{x:369,y:669,t:1527876679050};\\\", \\\"{x:416,y:683,t:1527876679065};\\\", \\\"{x:456,y:695,t:1527876679083};\\\", \\\"{x:493,y:711,t:1527876679100};\\\", \\\"{x:507,y:718,t:1527876679115};\\\", \\\"{x:524,y:727,t:1527876679132};\\\", \\\"{x:533,y:731,t:1527876679148};\\\", \\\"{x:541,y:733,t:1527876679165};\\\", \\\"{x:541,y:734,t:1527876679182};\\\", \\\"{x:544,y:735,t:1527876679227};\\\", \\\"{x:544,y:737,t:1527876679235};\\\", \\\"{x:544,y:743,t:1527876679248};\\\", \\\"{x:545,y:749,t:1527876679265};\\\", \\\"{x:545,y:752,t:1527876679283};\\\", \\\"{x:545,y:753,t:1527876679299};\\\", \\\"{x:545,y:754,t:1527876679331};\\\", \\\"{x:545,y:755,t:1527876679347};\\\", \\\"{x:545,y:757,t:1527876679355};\\\", \\\"{x:545,y:759,t:1527876679379};\\\", \\\"{x:551,y:758,t:1527876680124};\\\", \\\"{x:554,y:754,t:1527876680133};\\\", \\\"{x:570,y:748,t:1527876680149};\\\", \\\"{x:582,y:740,t:1527876680166};\\\", \\\"{x:596,y:730,t:1527876680183};\\\", \\\"{x:608,y:722,t:1527876680200};\\\", \\\"{x:620,y:712,t:1527876680216};\\\", \\\"{x:630,y:704,t:1527876680233};\\\", \\\"{x:639,y:697,t:1527876680249};\\\", \\\"{x:650,y:689,t:1527876680266};\\\", \\\"{x:669,y:679,t:1527876680283};\\\", \\\"{x:682,y:668,t:1527876680300};\\\", \\\"{x:700,y:658,t:1527876680316};\\\", \\\"{x:716,y:648,t:1527876680333};\\\", \\\"{x:731,y:641,t:1527876680349};\\\", \\\"{x:746,y:635,t:1527876680366};\\\", \\\"{x:757,y:630,t:1527876680383};\\\", \\\"{x:763,y:628,t:1527876680400};\\\", \\\"{x:767,y:626,t:1527876680417};\\\", \\\"{x:768,y:625,t:1527876680435};\\\", \\\"{x:769,y:625,t:1527876680460};\\\", \\\"{x:772,y:624,t:1527876680467};\\\" ] }, { \\\"rt\\\": 36807, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 330024, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -3-I -I -3-E -A -A -K -O -10 AM-09 AM-J -10 AM-09 AM-J -11 AM-12 PM-02 PM-04 PM-O -O -H -H -G -11 AM-12 PM-01 PM-02 PM-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:774,y:624,t:1527876680833};\\\", \\\"{x:775,y:623,t:1527876681684};\\\", \\\"{x:774,y:620,t:1527876681702};\\\", \\\"{x:770,y:618,t:1527876681720};\\\", \\\"{x:764,y:615,t:1527876681735};\\\", \\\"{x:758,y:612,t:1527876681752};\\\", \\\"{x:753,y:610,t:1527876681770};\\\", \\\"{x:746,y:606,t:1527876681785};\\\", \\\"{x:741,y:603,t:1527876681803};\\\", \\\"{x:729,y:596,t:1527876681819};\\\", \\\"{x:716,y:589,t:1527876681837};\\\", \\\"{x:703,y:584,t:1527876681851};\\\", \\\"{x:682,y:576,t:1527876681868};\\\", \\\"{x:659,y:571,t:1527876681884};\\\", \\\"{x:637,y:563,t:1527876681901};\\\", \\\"{x:618,y:557,t:1527876681919};\\\", \\\"{x:605,y:554,t:1527876681935};\\\", \\\"{x:596,y:552,t:1527876681951};\\\", \\\"{x:588,y:548,t:1527876681967};\\\", \\\"{x:583,y:546,t:1527876681984};\\\", \\\"{x:578,y:544,t:1527876682001};\\\", \\\"{x:575,y:543,t:1527876682017};\\\", \\\"{x:566,y:540,t:1527876682035};\\\", \\\"{x:542,y:534,t:1527876682052};\\\", \\\"{x:525,y:530,t:1527876682067};\\\", \\\"{x:509,y:527,t:1527876682085};\\\", \\\"{x:495,y:523,t:1527876682103};\\\", \\\"{x:485,y:522,t:1527876682117};\\\", \\\"{x:476,y:521,t:1527876682134};\\\", \\\"{x:469,y:520,t:1527876682151};\\\", \\\"{x:464,y:518,t:1527876682168};\\\", \\\"{x:461,y:516,t:1527876682185};\\\", \\\"{x:460,y:516,t:1527876682201};\\\", \\\"{x:458,y:515,t:1527876682218};\\\", \\\"{x:457,y:515,t:1527876682268};\\\", \\\"{x:455,y:514,t:1527876682284};\\\", \\\"{x:453,y:512,t:1527876682302};\\\", \\\"{x:452,y:511,t:1527876682318};\\\", \\\"{x:451,y:511,t:1527876682334};\\\", \\\"{x:452,y:509,t:1527876682388};\\\", \\\"{x:463,y:508,t:1527876682402};\\\", \\\"{x:524,y:508,t:1527876682421};\\\", \\\"{x:616,y:508,t:1527876682435};\\\", \\\"{x:777,y:508,t:1527876682451};\\\", \\\"{x:931,y:525,t:1527876682469};\\\", \\\"{x:1078,y:547,t:1527876682485};\\\", \\\"{x:1205,y:565,t:1527876682501};\\\", \\\"{x:1290,y:584,t:1527876682518};\\\", \\\"{x:1336,y:597,t:1527876682535};\\\", \\\"{x:1349,y:603,t:1527876682551};\\\", \\\"{x:1352,y:606,t:1527876682568};\\\", \\\"{x:1354,y:610,t:1527876682585};\\\", \\\"{x:1357,y:614,t:1527876682602};\\\", \\\"{x:1357,y:622,t:1527876682618};\\\", \\\"{x:1357,y:638,t:1527876682635};\\\", \\\"{x:1356,y:649,t:1527876682651};\\\", \\\"{x:1352,y:657,t:1527876682668};\\\", \\\"{x:1347,y:662,t:1527876682686};\\\", \\\"{x:1341,y:672,t:1527876682702};\\\", \\\"{x:1335,y:682,t:1527876682718};\\\", \\\"{x:1334,y:689,t:1527876682735};\\\", \\\"{x:1333,y:692,t:1527876682751};\\\", \\\"{x:1333,y:693,t:1527876682811};\\\", \\\"{x:1332,y:693,t:1527876682819};\\\", \\\"{x:1328,y:697,t:1527876682835};\\\", \\\"{x:1312,y:705,t:1527876682851};\\\", \\\"{x:1286,y:714,t:1527876682869};\\\", \\\"{x:1261,y:721,t:1527876682886};\\\", \\\"{x:1235,y:727,t:1527876682901};\\\", \\\"{x:1207,y:730,t:1527876682919};\\\", \\\"{x:1191,y:730,t:1527876682935};\\\", \\\"{x:1180,y:731,t:1527876682951};\\\", \\\"{x:1177,y:731,t:1527876682969};\\\", \\\"{x:1176,y:731,t:1527876682986};\\\", \\\"{x:1175,y:731,t:1527876683001};\\\", \\\"{x:1174,y:732,t:1527876683020};\\\", \\\"{x:1174,y:734,t:1527876683036};\\\", \\\"{x:1174,y:736,t:1527876683051};\\\", \\\"{x:1174,y:737,t:1527876683069};\\\", \\\"{x:1174,y:738,t:1527876683085};\\\", \\\"{x:1175,y:739,t:1527876683102};\\\", \\\"{x:1177,y:741,t:1527876683118};\\\", \\\"{x:1180,y:744,t:1527876683136};\\\", \\\"{x:1185,y:749,t:1527876683152};\\\", \\\"{x:1188,y:753,t:1527876683168};\\\", \\\"{x:1189,y:756,t:1527876683186};\\\", \\\"{x:1190,y:758,t:1527876683202};\\\", \\\"{x:1190,y:759,t:1527876683219};\\\", \\\"{x:1190,y:760,t:1527876683260};\\\", \\\"{x:1190,y:761,t:1527876683300};\\\", \\\"{x:1190,y:762,t:1527876683332};\\\", \\\"{x:1189,y:763,t:1527876683356};\\\", \\\"{x:1188,y:764,t:1527876683381};\\\", \\\"{x:1187,y:764,t:1527876683387};\\\", \\\"{x:1186,y:765,t:1527876683405};\\\", \\\"{x:1185,y:765,t:1527876683418};\\\", \\\"{x:1185,y:766,t:1527876683435};\\\", \\\"{x:1183,y:766,t:1527876683539};\\\", \\\"{x:1181,y:768,t:1527876683555};\\\", \\\"{x:1179,y:769,t:1527876683580};\\\", \\\"{x:1179,y:770,t:1527876683620};\\\", \\\"{x:1178,y:770,t:1527876683828};\\\", \\\"{x:1178,y:769,t:1527876683835};\\\", \\\"{x:1179,y:768,t:1527876683853};\\\", \\\"{x:1180,y:764,t:1527876683869};\\\", \\\"{x:1181,y:764,t:1527876683885};\\\", \\\"{x:1181,y:762,t:1527876684076};\\\", \\\"{x:1180,y:762,t:1527876684092};\\\", \\\"{x:1179,y:762,t:1527876684107};\\\", \\\"{x:1178,y:761,t:1527876684139};\\\", \\\"{x:1177,y:761,t:1527876684485};\\\", \\\"{x:1177,y:762,t:1527876684492};\\\", \\\"{x:1177,y:765,t:1527876684503};\\\", \\\"{x:1177,y:769,t:1527876684521};\\\", \\\"{x:1177,y:772,t:1527876684536};\\\", \\\"{x:1179,y:780,t:1527876684553};\\\", \\\"{x:1180,y:784,t:1527876684570};\\\", \\\"{x:1182,y:787,t:1527876684586};\\\", \\\"{x:1184,y:791,t:1527876684603};\\\", \\\"{x:1184,y:794,t:1527876684620};\\\", \\\"{x:1186,y:799,t:1527876684635};\\\", \\\"{x:1186,y:802,t:1527876684653};\\\", \\\"{x:1186,y:805,t:1527876684670};\\\", \\\"{x:1186,y:808,t:1527876684686};\\\", \\\"{x:1186,y:810,t:1527876684703};\\\", \\\"{x:1186,y:811,t:1527876684720};\\\", \\\"{x:1186,y:814,t:1527876684735};\\\", \\\"{x:1186,y:817,t:1527876684752};\\\", \\\"{x:1183,y:820,t:1527876684769};\\\", \\\"{x:1179,y:824,t:1527876684785};\\\", \\\"{x:1176,y:826,t:1527876684803};\\\", \\\"{x:1172,y:827,t:1527876684819};\\\", \\\"{x:1171,y:827,t:1527876684836};\\\", \\\"{x:1165,y:824,t:1527876684852};\\\", \\\"{x:1158,y:816,t:1527876684870};\\\", \\\"{x:1148,y:805,t:1527876684886};\\\", \\\"{x:1133,y:793,t:1527876684902};\\\", \\\"{x:1107,y:779,t:1527876684919};\\\", \\\"{x:1083,y:769,t:1527876684936};\\\", \\\"{x:1060,y:761,t:1527876684953};\\\", \\\"{x:1040,y:759,t:1527876684971};\\\", \\\"{x:1023,y:755,t:1527876684986};\\\", \\\"{x:1012,y:754,t:1527876685003};\\\", \\\"{x:984,y:750,t:1527876685019};\\\", \\\"{x:963,y:748,t:1527876685036};\\\", \\\"{x:942,y:745,t:1527876685053};\\\", \\\"{x:926,y:745,t:1527876685070};\\\", \\\"{x:909,y:745,t:1527876685085};\\\", \\\"{x:897,y:745,t:1527876685103};\\\", \\\"{x:892,y:745,t:1527876685120};\\\", \\\"{x:891,y:745,t:1527876685135};\\\", \\\"{x:889,y:748,t:1527876685153};\\\", \\\"{x:888,y:751,t:1527876685170};\\\", \\\"{x:886,y:760,t:1527876685185};\\\", \\\"{x:885,y:769,t:1527876685203};\\\", \\\"{x:883,y:772,t:1527876685219};\\\", \\\"{x:887,y:772,t:1527876685516};\\\", \\\"{x:906,y:771,t:1527876685524};\\\", \\\"{x:929,y:768,t:1527876685536};\\\", \\\"{x:991,y:768,t:1527876685553};\\\", \\\"{x:1041,y:768,t:1527876685570};\\\", \\\"{x:1081,y:765,t:1527876685588};\\\", \\\"{x:1102,y:765,t:1527876685604};\\\", \\\"{x:1117,y:765,t:1527876685620};\\\", \\\"{x:1126,y:766,t:1527876685637};\\\", \\\"{x:1128,y:767,t:1527876685653};\\\", \\\"{x:1130,y:769,t:1527876685670};\\\", \\\"{x:1135,y:770,t:1527876685686};\\\", \\\"{x:1136,y:770,t:1527876685703};\\\", \\\"{x:1142,y:770,t:1527876685720};\\\", \\\"{x:1155,y:770,t:1527876685737};\\\", \\\"{x:1169,y:770,t:1527876685753};\\\", \\\"{x:1173,y:770,t:1527876685771};\\\", \\\"{x:1174,y:770,t:1527876685844};\\\", \\\"{x:1174,y:769,t:1527876685853};\\\", \\\"{x:1174,y:768,t:1527876685884};\\\", \\\"{x:1175,y:768,t:1527876685892};\\\", \\\"{x:1175,y:767,t:1527876685915};\\\", \\\"{x:1176,y:767,t:1527876685924};\\\", \\\"{x:1176,y:766,t:1527876685940};\\\", \\\"{x:1178,y:765,t:1527876685970};\\\", \\\"{x:1183,y:762,t:1527876685987};\\\", \\\"{x:1186,y:761,t:1527876686003};\\\", \\\"{x:1191,y:759,t:1527876686021};\\\", \\\"{x:1193,y:758,t:1527876686037};\\\", \\\"{x:1192,y:759,t:1527876686212};\\\", \\\"{x:1190,y:759,t:1527876686228};\\\", \\\"{x:1190,y:760,t:1527876686237};\\\", \\\"{x:1187,y:761,t:1527876686253};\\\", \\\"{x:1187,y:762,t:1527876686270};\\\", \\\"{x:1186,y:762,t:1527876686340};\\\", \\\"{x:1185,y:762,t:1527876686369};\\\", \\\"{x:1184,y:762,t:1527876686386};\\\", \\\"{x:1183,y:762,t:1527876686460};\\\", \\\"{x:1182,y:763,t:1527876686499};\\\", \\\"{x:1181,y:763,t:1527876686508};\\\", \\\"{x:1178,y:765,t:1527876686604};\\\", \\\"{x:1173,y:765,t:1527876686621};\\\", \\\"{x:1151,y:765,t:1527876686637};\\\", \\\"{x:1113,y:765,t:1527876686654};\\\", \\\"{x:1063,y:761,t:1527876686670};\\\", \\\"{x:1025,y:753,t:1527876686687};\\\", \\\"{x:1004,y:741,t:1527876686704};\\\", \\\"{x:996,y:703,t:1527876686720};\\\", \\\"{x:996,y:636,t:1527876686737};\\\", \\\"{x:1020,y:588,t:1527876686754};\\\", \\\"{x:1060,y:550,t:1527876686770};\\\", \\\"{x:1154,y:525,t:1527876686787};\\\", \\\"{x:1325,y:515,t:1527876686804};\\\", \\\"{x:1398,y:515,t:1527876686820};\\\", \\\"{x:1432,y:515,t:1527876686837};\\\", \\\"{x:1441,y:515,t:1527876686854};\\\", \\\"{x:1438,y:515,t:1527876686965};\\\", \\\"{x:1432,y:517,t:1527876686972};\\\", \\\"{x:1422,y:525,t:1527876686987};\\\", \\\"{x:1382,y:551,t:1527876687004};\\\", \\\"{x:1354,y:564,t:1527876687019};\\\", \\\"{x:1327,y:571,t:1527876687037};\\\", \\\"{x:1313,y:575,t:1527876687054};\\\", \\\"{x:1310,y:575,t:1527876687070};\\\", \\\"{x:1309,y:575,t:1527876687108};\\\", \\\"{x:1309,y:574,t:1527876687124};\\\", \\\"{x:1309,y:573,t:1527876687137};\\\", \\\"{x:1305,y:568,t:1527876687154};\\\", \\\"{x:1298,y:563,t:1527876687170};\\\", \\\"{x:1287,y:557,t:1527876687187};\\\", \\\"{x:1268,y:552,t:1527876687204};\\\", \\\"{x:1260,y:552,t:1527876687220};\\\", \\\"{x:1254,y:552,t:1527876687237};\\\", \\\"{x:1253,y:552,t:1527876687254};\\\", \\\"{x:1252,y:552,t:1527876687270};\\\", \\\"{x:1251,y:552,t:1527876687304};\\\", \\\"{x:1251,y:553,t:1527876687311};\\\", \\\"{x:1251,y:555,t:1527876687325};\\\", \\\"{x:1251,y:559,t:1527876687341};\\\", \\\"{x:1253,y:561,t:1527876687358};\\\", \\\"{x:1256,y:562,t:1527876687375};\\\", \\\"{x:1261,y:563,t:1527876687391};\\\", \\\"{x:1268,y:563,t:1527876687407};\\\", \\\"{x:1272,y:562,t:1527876687425};\\\", \\\"{x:1276,y:560,t:1527876687442};\\\", \\\"{x:1277,y:560,t:1527876687458};\\\", \\\"{x:1278,y:560,t:1527876687480};\\\", \\\"{x:1276,y:560,t:1527876687792};\\\", \\\"{x:1260,y:558,t:1527876687808};\\\", \\\"{x:1230,y:554,t:1527876687825};\\\", \\\"{x:1174,y:546,t:1527876687841};\\\", \\\"{x:1095,y:525,t:1527876687858};\\\", \\\"{x:1031,y:508,t:1527876687875};\\\", \\\"{x:977,y:488,t:1527876687891};\\\", \\\"{x:942,y:468,t:1527876687908};\\\", \\\"{x:918,y:453,t:1527876687925};\\\", \\\"{x:900,y:440,t:1527876687941};\\\", \\\"{x:886,y:430,t:1527876687957};\\\", \\\"{x:862,y:413,t:1527876687975};\\\", \\\"{x:838,y:397,t:1527876687992};\\\", \\\"{x:779,y:368,t:1527876688007};\\\", \\\"{x:762,y:359,t:1527876688025};\\\", \\\"{x:757,y:357,t:1527876688040};\\\", \\\"{x:756,y:357,t:1527876688288};\\\", \\\"{x:755,y:357,t:1527876688295};\\\", \\\"{x:772,y:363,t:1527876688307};\\\", \\\"{x:835,y:371,t:1527876688325};\\\", \\\"{x:916,y:382,t:1527876688342};\\\", \\\"{x:1014,y:398,t:1527876688358};\\\", \\\"{x:1143,y:412,t:1527876688375};\\\", \\\"{x:1358,y:442,t:1527876688392};\\\", \\\"{x:1453,y:462,t:1527876688408};\\\", \\\"{x:1486,y:475,t:1527876688425};\\\", \\\"{x:1504,y:485,t:1527876688442};\\\", \\\"{x:1505,y:486,t:1527876688458};\\\", \\\"{x:1505,y:489,t:1527876688479};\\\", \\\"{x:1503,y:489,t:1527876688504};\\\", \\\"{x:1502,y:489,t:1527876688519};\\\", \\\"{x:1499,y:489,t:1527876688528};\\\", \\\"{x:1493,y:489,t:1527876688542};\\\", \\\"{x:1475,y:486,t:1527876688558};\\\", \\\"{x:1457,y:476,t:1527876688575};\\\", \\\"{x:1434,y:461,t:1527876688592};\\\", \\\"{x:1422,y:453,t:1527876688608};\\\", \\\"{x:1416,y:446,t:1527876688625};\\\", \\\"{x:1415,y:443,t:1527876688642};\\\", \\\"{x:1414,y:441,t:1527876688658};\\\", \\\"{x:1414,y:438,t:1527876688675};\\\", \\\"{x:1414,y:433,t:1527876688692};\\\", \\\"{x:1413,y:429,t:1527876688707};\\\", \\\"{x:1412,y:426,t:1527876688724};\\\", \\\"{x:1412,y:425,t:1527876688822};\\\", \\\"{x:1410,y:425,t:1527876688840};\\\", \\\"{x:1410,y:423,t:1527876688993};\\\", \\\"{x:1423,y:408,t:1527876689008};\\\", \\\"{x:1438,y:393,t:1527876689025};\\\", \\\"{x:1450,y:376,t:1527876689042};\\\", \\\"{x:1456,y:363,t:1527876689058};\\\", \\\"{x:1459,y:357,t:1527876689076};\\\", \\\"{x:1460,y:354,t:1527876689092};\\\", \\\"{x:1460,y:352,t:1527876689108};\\\", \\\"{x:1460,y:348,t:1527876689125};\\\", \\\"{x:1460,y:347,t:1527876689142};\\\", \\\"{x:1460,y:344,t:1527876689158};\\\", \\\"{x:1459,y:337,t:1527876689175};\\\", \\\"{x:1459,y:329,t:1527876689191};\\\", \\\"{x:1459,y:320,t:1527876689209};\\\", \\\"{x:1459,y:311,t:1527876689225};\\\", \\\"{x:1459,y:304,t:1527876689242};\\\", \\\"{x:1460,y:301,t:1527876689259};\\\", \\\"{x:1461,y:297,t:1527876689275};\\\", \\\"{x:1462,y:296,t:1527876689293};\\\", \\\"{x:1463,y:296,t:1527876689423};\\\", \\\"{x:1464,y:296,t:1527876689431};\\\", \\\"{x:1465,y:295,t:1527876689442};\\\", \\\"{x:1466,y:295,t:1527876689459};\\\", \\\"{x:1468,y:294,t:1527876689474};\\\", \\\"{x:1469,y:294,t:1527876689491};\\\", \\\"{x:1470,y:294,t:1527876689508};\\\", \\\"{x:1471,y:294,t:1527876689525};\\\", \\\"{x:1473,y:293,t:1527876689542};\\\", \\\"{x:1474,y:293,t:1527876689560};\\\", \\\"{x:1475,y:293,t:1527876689592};\\\", \\\"{x:1477,y:293,t:1527876689609};\\\", \\\"{x:1479,y:293,t:1527876689642};\\\", \\\"{x:1480,y:293,t:1527876689664};\\\", \\\"{x:1481,y:293,t:1527876689694};\\\", \\\"{x:1482,y:293,t:1527876689708};\\\", \\\"{x:1483,y:293,t:1527876690152};\\\", \\\"{x:1488,y:295,t:1527876690161};\\\", \\\"{x:1498,y:301,t:1527876690176};\\\", \\\"{x:1514,y:308,t:1527876690192};\\\", \\\"{x:1523,y:312,t:1527876690209};\\\", \\\"{x:1533,y:318,t:1527876690225};\\\", \\\"{x:1538,y:321,t:1527876690242};\\\", \\\"{x:1543,y:324,t:1527876690259};\\\", \\\"{x:1546,y:326,t:1527876690276};\\\", \\\"{x:1551,y:329,t:1527876690292};\\\", \\\"{x:1558,y:331,t:1527876690309};\\\", \\\"{x:1563,y:332,t:1527876690326};\\\", \\\"{x:1565,y:332,t:1527876690342};\\\", \\\"{x:1567,y:333,t:1527876690359};\\\", \\\"{x:1570,y:335,t:1527876690376};\\\", \\\"{x:1571,y:335,t:1527876690392};\\\", \\\"{x:1574,y:336,t:1527876690410};\\\", \\\"{x:1577,y:338,t:1527876690426};\\\", \\\"{x:1578,y:339,t:1527876690442};\\\", \\\"{x:1583,y:342,t:1527876690459};\\\", \\\"{x:1586,y:344,t:1527876690477};\\\", \\\"{x:1591,y:347,t:1527876690492};\\\", \\\"{x:1596,y:351,t:1527876690509};\\\", \\\"{x:1598,y:354,t:1527876690527};\\\", \\\"{x:1600,y:358,t:1527876690542};\\\", \\\"{x:1601,y:361,t:1527876690559};\\\", \\\"{x:1601,y:371,t:1527876690575};\\\", \\\"{x:1601,y:376,t:1527876690592};\\\", \\\"{x:1601,y:380,t:1527876690609};\\\", \\\"{x:1601,y:384,t:1527876690626};\\\", \\\"{x:1600,y:388,t:1527876690642};\\\", \\\"{x:1597,y:391,t:1527876690659};\\\", \\\"{x:1593,y:396,t:1527876690676};\\\", \\\"{x:1584,y:403,t:1527876690692};\\\", \\\"{x:1569,y:413,t:1527876690710};\\\", \\\"{x:1550,y:425,t:1527876690726};\\\", \\\"{x:1532,y:437,t:1527876690742};\\\", \\\"{x:1512,y:452,t:1527876690759};\\\", \\\"{x:1473,y:480,t:1527876690776};\\\", \\\"{x:1443,y:505,t:1527876690792};\\\", \\\"{x:1422,y:527,t:1527876690810};\\\", \\\"{x:1409,y:546,t:1527876690826};\\\", \\\"{x:1399,y:561,t:1527876690842};\\\", \\\"{x:1395,y:572,t:1527876690859};\\\", \\\"{x:1393,y:581,t:1527876690876};\\\", \\\"{x:1393,y:588,t:1527876690892};\\\", \\\"{x:1393,y:592,t:1527876690909};\\\", \\\"{x:1393,y:599,t:1527876690925};\\\", \\\"{x:1393,y:606,t:1527876690941};\\\", \\\"{x:1393,y:614,t:1527876690958};\\\", \\\"{x:1393,y:621,t:1527876690975};\\\", \\\"{x:1393,y:631,t:1527876690991};\\\", \\\"{x:1393,y:642,t:1527876691008};\\\", \\\"{x:1390,y:651,t:1527876691026};\\\", \\\"{x:1389,y:663,t:1527876691042};\\\", \\\"{x:1388,y:672,t:1527876691058};\\\", \\\"{x:1387,y:677,t:1527876691076};\\\", \\\"{x:1386,y:678,t:1527876691095};\\\", \\\"{x:1385,y:677,t:1527876691264};\\\", \\\"{x:1383,y:676,t:1527876691277};\\\", \\\"{x:1378,y:672,t:1527876691292};\\\", \\\"{x:1366,y:667,t:1527876691309};\\\", \\\"{x:1351,y:660,t:1527876691325};\\\", \\\"{x:1343,y:657,t:1527876691343};\\\", \\\"{x:1336,y:657,t:1527876691359};\\\", \\\"{x:1330,y:658,t:1527876691375};\\\", \\\"{x:1328,y:661,t:1527876691393};\\\", \\\"{x:1325,y:670,t:1527876691409};\\\", \\\"{x:1323,y:678,t:1527876691426};\\\", \\\"{x:1323,y:679,t:1527876691443};\\\", \\\"{x:1323,y:686,t:1527876691459};\\\", \\\"{x:1325,y:694,t:1527876691476};\\\", \\\"{x:1331,y:704,t:1527876691493};\\\", \\\"{x:1341,y:715,t:1527876691509};\\\", \\\"{x:1346,y:721,t:1527876691526};\\\", \\\"{x:1349,y:722,t:1527876691543};\\\", \\\"{x:1351,y:725,t:1527876691559};\\\", \\\"{x:1353,y:727,t:1527876691576};\\\", \\\"{x:1354,y:727,t:1527876691593};\\\", \\\"{x:1354,y:728,t:1527876691615};\\\", \\\"{x:1355,y:729,t:1527876692136};\\\", \\\"{x:1356,y:730,t:1527876692151};\\\", \\\"{x:1357,y:731,t:1527876692160};\\\", \\\"{x:1359,y:732,t:1527876692176};\\\", \\\"{x:1362,y:732,t:1527876692194};\\\", \\\"{x:1366,y:733,t:1527876692211};\\\", \\\"{x:1372,y:734,t:1527876692227};\\\", \\\"{x:1381,y:737,t:1527876692244};\\\", \\\"{x:1385,y:737,t:1527876692260};\\\", \\\"{x:1388,y:737,t:1527876692276};\\\", \\\"{x:1396,y:739,t:1527876692293};\\\", \\\"{x:1400,y:740,t:1527876692310};\\\", \\\"{x:1404,y:742,t:1527876692326};\\\", \\\"{x:1411,y:744,t:1527876692343};\\\", \\\"{x:1426,y:747,t:1527876692359};\\\", \\\"{x:1440,y:749,t:1527876692376};\\\", \\\"{x:1447,y:750,t:1527876692393};\\\", \\\"{x:1452,y:751,t:1527876692411};\\\", \\\"{x:1453,y:751,t:1527876692426};\\\", \\\"{x:1455,y:752,t:1527876692443};\\\", \\\"{x:1456,y:752,t:1527876692464};\\\", \\\"{x:1457,y:753,t:1527876692476};\\\", \\\"{x:1459,y:754,t:1527876692493};\\\", \\\"{x:1464,y:755,t:1527876692511};\\\", \\\"{x:1470,y:758,t:1527876692527};\\\", \\\"{x:1481,y:760,t:1527876692544};\\\", \\\"{x:1489,y:762,t:1527876692559};\\\", \\\"{x:1494,y:763,t:1527876692576};\\\", \\\"{x:1499,y:763,t:1527876692593};\\\", \\\"{x:1501,y:763,t:1527876692610};\\\", \\\"{x:1502,y:763,t:1527876692625};\\\", \\\"{x:1503,y:763,t:1527876692743};\\\", \\\"{x:1504,y:763,t:1527876692760};\\\", \\\"{x:1507,y:765,t:1527876692776};\\\", \\\"{x:1513,y:766,t:1527876692793};\\\", \\\"{x:1520,y:769,t:1527876692811};\\\", \\\"{x:1527,y:771,t:1527876692826};\\\", \\\"{x:1533,y:774,t:1527876692843};\\\", \\\"{x:1535,y:777,t:1527876692860};\\\", \\\"{x:1537,y:778,t:1527876692876};\\\", \\\"{x:1539,y:780,t:1527876692893};\\\", \\\"{x:1540,y:781,t:1527876692910};\\\", \\\"{x:1542,y:783,t:1527876692927};\\\", \\\"{x:1543,y:787,t:1527876692944};\\\", \\\"{x:1544,y:793,t:1527876692960};\\\", \\\"{x:1545,y:799,t:1527876692977};\\\", \\\"{x:1545,y:805,t:1527876692993};\\\", \\\"{x:1545,y:810,t:1527876693010};\\\", \\\"{x:1545,y:814,t:1527876693026};\\\", \\\"{x:1545,y:817,t:1527876693044};\\\", \\\"{x:1545,y:819,t:1527876693060};\\\", \\\"{x:1545,y:822,t:1527876693077};\\\", \\\"{x:1545,y:823,t:1527876693096};\\\", \\\"{x:1545,y:824,t:1527876693111};\\\", \\\"{x:1545,y:826,t:1527876693128};\\\", \\\"{x:1545,y:828,t:1527876693144};\\\", \\\"{x:1545,y:829,t:1527876693160};\\\", \\\"{x:1545,y:830,t:1527876693177};\\\", \\\"{x:1545,y:831,t:1527876693216};\\\", \\\"{x:1545,y:840,t:1527876693584};\\\", \\\"{x:1543,y:850,t:1527876693593};\\\", \\\"{x:1536,y:865,t:1527876693610};\\\", \\\"{x:1523,y:883,t:1527876693628};\\\", \\\"{x:1506,y:896,t:1527876693643};\\\", \\\"{x:1483,y:908,t:1527876693660};\\\", \\\"{x:1462,y:916,t:1527876693677};\\\", \\\"{x:1443,y:921,t:1527876693693};\\\", \\\"{x:1425,y:924,t:1527876693711};\\\", \\\"{x:1402,y:926,t:1527876693727};\\\", \\\"{x:1391,y:927,t:1527876693744};\\\", \\\"{x:1375,y:930,t:1527876693760};\\\", \\\"{x:1364,y:931,t:1527876693777};\\\", \\\"{x:1349,y:934,t:1527876693794};\\\", \\\"{x:1333,y:936,t:1527876693810};\\\", \\\"{x:1321,y:940,t:1527876693827};\\\", \\\"{x:1308,y:945,t:1527876693844};\\\", \\\"{x:1302,y:947,t:1527876693860};\\\", \\\"{x:1298,y:949,t:1527876693877};\\\", \\\"{x:1296,y:950,t:1527876693893};\\\", \\\"{x:1295,y:951,t:1527876693984};\\\", \\\"{x:1295,y:953,t:1527876694000};\\\", \\\"{x:1295,y:954,t:1527876694015};\\\", \\\"{x:1294,y:955,t:1527876694027};\\\", \\\"{x:1294,y:956,t:1527876694044};\\\", \\\"{x:1293,y:956,t:1527876694064};\\\", \\\"{x:1292,y:957,t:1527876694078};\\\", \\\"{x:1290,y:958,t:1527876694094};\\\", \\\"{x:1286,y:960,t:1527876694111};\\\", \\\"{x:1270,y:966,t:1527876694127};\\\", \\\"{x:1262,y:968,t:1527876694144};\\\", \\\"{x:1255,y:969,t:1527876694160};\\\", \\\"{x:1247,y:971,t:1527876694177};\\\", \\\"{x:1243,y:971,t:1527876694195};\\\", \\\"{x:1240,y:971,t:1527876694211};\\\", \\\"{x:1239,y:971,t:1527876694228};\\\", \\\"{x:1237,y:970,t:1527876694244};\\\", \\\"{x:1236,y:970,t:1527876694260};\\\", \\\"{x:1233,y:970,t:1527876694278};\\\", \\\"{x:1230,y:968,t:1527876694294};\\\", \\\"{x:1227,y:967,t:1527876694310};\\\", \\\"{x:1221,y:967,t:1527876694328};\\\", \\\"{x:1215,y:967,t:1527876694344};\\\", \\\"{x:1205,y:967,t:1527876694361};\\\", \\\"{x:1191,y:970,t:1527876694376};\\\", \\\"{x:1176,y:974,t:1527876694393};\\\", \\\"{x:1164,y:978,t:1527876694410};\\\", \\\"{x:1153,y:981,t:1527876694426};\\\", \\\"{x:1145,y:983,t:1527876694443};\\\", \\\"{x:1140,y:984,t:1527876694460};\\\", \\\"{x:1136,y:984,t:1527876694477};\\\", \\\"{x:1135,y:984,t:1527876694503};\\\", \\\"{x:1135,y:983,t:1527876694551};\\\", \\\"{x:1135,y:980,t:1527876694560};\\\", \\\"{x:1135,y:973,t:1527876694577};\\\", \\\"{x:1135,y:963,t:1527876694594};\\\", \\\"{x:1135,y:952,t:1527876694610};\\\", \\\"{x:1136,y:937,t:1527876694627};\\\", \\\"{x:1138,y:915,t:1527876694644};\\\", \\\"{x:1143,y:895,t:1527876694660};\\\", \\\"{x:1148,y:878,t:1527876694677};\\\", \\\"{x:1153,y:862,t:1527876694694};\\\", \\\"{x:1159,y:848,t:1527876694710};\\\", \\\"{x:1164,y:837,t:1527876694727};\\\", \\\"{x:1168,y:829,t:1527876694744};\\\", \\\"{x:1172,y:821,t:1527876694760};\\\", \\\"{x:1176,y:812,t:1527876694777};\\\", \\\"{x:1182,y:806,t:1527876694794};\\\", \\\"{x:1186,y:798,t:1527876694810};\\\", \\\"{x:1187,y:788,t:1527876694827};\\\", \\\"{x:1189,y:780,t:1527876694844};\\\", \\\"{x:1189,y:779,t:1527876694860};\\\", \\\"{x:1189,y:777,t:1527876694878};\\\", \\\"{x:1189,y:775,t:1527876694894};\\\", \\\"{x:1189,y:774,t:1527876694910};\\\", \\\"{x:1190,y:772,t:1527876694928};\\\", \\\"{x:1191,y:772,t:1527876694983};\\\", \\\"{x:1193,y:774,t:1527876694993};\\\", \\\"{x:1200,y:790,t:1527876695010};\\\", \\\"{x:1208,y:810,t:1527876695026};\\\", \\\"{x:1215,y:831,t:1527876695043};\\\", \\\"{x:1220,y:851,t:1527876695061};\\\", \\\"{x:1224,y:865,t:1527876695076};\\\", \\\"{x:1226,y:873,t:1527876695094};\\\", \\\"{x:1228,y:882,t:1527876695110};\\\", \\\"{x:1229,y:892,t:1527876695126};\\\", \\\"{x:1229,y:901,t:1527876695144};\\\", \\\"{x:1229,y:914,t:1527876695161};\\\", \\\"{x:1229,y:926,t:1527876695177};\\\", \\\"{x:1230,y:940,t:1527876695194};\\\", \\\"{x:1230,y:947,t:1527876695211};\\\", \\\"{x:1230,y:956,t:1527876695227};\\\", \\\"{x:1230,y:964,t:1527876695244};\\\", \\\"{x:1228,y:970,t:1527876695261};\\\", \\\"{x:1225,y:973,t:1527876695278};\\\", \\\"{x:1218,y:980,t:1527876695294};\\\", \\\"{x:1202,y:987,t:1527876695312};\\\", \\\"{x:1190,y:991,t:1527876695327};\\\", \\\"{x:1175,y:996,t:1527876695344};\\\", \\\"{x:1160,y:997,t:1527876695361};\\\", \\\"{x:1148,y:998,t:1527876695378};\\\", \\\"{x:1143,y:998,t:1527876695394};\\\", \\\"{x:1138,y:999,t:1527876695412};\\\", \\\"{x:1137,y:999,t:1527876695427};\\\", \\\"{x:1136,y:999,t:1527876695504};\\\", \\\"{x:1136,y:996,t:1527876695512};\\\", \\\"{x:1139,y:980,t:1527876695528};\\\", \\\"{x:1144,y:965,t:1527876695544};\\\", \\\"{x:1155,y:943,t:1527876695561};\\\", \\\"{x:1163,y:926,t:1527876695577};\\\", \\\"{x:1171,y:910,t:1527876695594};\\\", \\\"{x:1180,y:891,t:1527876695611};\\\", \\\"{x:1186,y:875,t:1527876695627};\\\", \\\"{x:1192,y:861,t:1527876695644};\\\", \\\"{x:1197,y:849,t:1527876695661};\\\", \\\"{x:1204,y:836,t:1527876695676};\\\", \\\"{x:1212,y:828,t:1527876695694};\\\", \\\"{x:1226,y:816,t:1527876695711};\\\", \\\"{x:1237,y:807,t:1527876695726};\\\", \\\"{x:1242,y:803,t:1527876695744};\\\", \\\"{x:1245,y:801,t:1527876695761};\\\", \\\"{x:1247,y:800,t:1527876695777};\\\", \\\"{x:1249,y:800,t:1527876695799};\\\", \\\"{x:1252,y:801,t:1527876695811};\\\", \\\"{x:1261,y:809,t:1527876695827};\\\", \\\"{x:1266,y:815,t:1527876695844};\\\", \\\"{x:1274,y:827,t:1527876695861};\\\", \\\"{x:1282,y:845,t:1527876695877};\\\", \\\"{x:1292,y:868,t:1527876695894};\\\", \\\"{x:1309,y:905,t:1527876695911};\\\", \\\"{x:1318,y:926,t:1527876695928};\\\", \\\"{x:1323,y:935,t:1527876695945};\\\", \\\"{x:1324,y:935,t:1527876695976};\\\", \\\"{x:1325,y:935,t:1527876696016};\\\", \\\"{x:1329,y:934,t:1527876696028};\\\", \\\"{x:1335,y:930,t:1527876696044};\\\", \\\"{x:1345,y:922,t:1527876696061};\\\", \\\"{x:1363,y:908,t:1527876696079};\\\", \\\"{x:1375,y:893,t:1527876696094};\\\", \\\"{x:1389,y:870,t:1527876696111};\\\", \\\"{x:1391,y:860,t:1527876696127};\\\", \\\"{x:1395,y:845,t:1527876696145};\\\", \\\"{x:1396,y:834,t:1527876696162};\\\", \\\"{x:1398,y:827,t:1527876696178};\\\", \\\"{x:1399,y:821,t:1527876696194};\\\", \\\"{x:1399,y:816,t:1527876696211};\\\", \\\"{x:1399,y:809,t:1527876696228};\\\", \\\"{x:1399,y:805,t:1527876696245};\\\", \\\"{x:1399,y:802,t:1527876696262};\\\", \\\"{x:1398,y:801,t:1527876696279};\\\", \\\"{x:1397,y:800,t:1527876696295};\\\", \\\"{x:1396,y:799,t:1527876696311};\\\", \\\"{x:1396,y:798,t:1527876696328};\\\", \\\"{x:1393,y:796,t:1527876696345};\\\", \\\"{x:1392,y:795,t:1527876696362};\\\", \\\"{x:1390,y:793,t:1527876696378};\\\", \\\"{x:1388,y:791,t:1527876696394};\\\", \\\"{x:1385,y:788,t:1527876696410};\\\", \\\"{x:1382,y:785,t:1527876696427};\\\", \\\"{x:1378,y:781,t:1527876696444};\\\", \\\"{x:1373,y:780,t:1527876696461};\\\", \\\"{x:1369,y:777,t:1527876696478};\\\", \\\"{x:1367,y:776,t:1527876696494};\\\", \\\"{x:1363,y:773,t:1527876696511};\\\", \\\"{x:1362,y:771,t:1527876696527};\\\", \\\"{x:1361,y:771,t:1527876696544};\\\", \\\"{x:1360,y:770,t:1527876696561};\\\", \\\"{x:1359,y:769,t:1527876696599};\\\", \\\"{x:1358,y:768,t:1527876696648};\\\", \\\"{x:1357,y:768,t:1527876696736};\\\", \\\"{x:1351,y:775,t:1527876696745};\\\", \\\"{x:1345,y:787,t:1527876696762};\\\", \\\"{x:1335,y:797,t:1527876696778};\\\", \\\"{x:1322,y:809,t:1527876696794};\\\", \\\"{x:1311,y:819,t:1527876696811};\\\", \\\"{x:1298,y:828,t:1527876696828};\\\", \\\"{x:1293,y:837,t:1527876696845};\\\", \\\"{x:1291,y:839,t:1527876696861};\\\", \\\"{x:1289,y:842,t:1527876696878};\\\", \\\"{x:1289,y:843,t:1527876696894};\\\", \\\"{x:1289,y:841,t:1527876696975};\\\", \\\"{x:1291,y:835,t:1527876696984};\\\", \\\"{x:1296,y:824,t:1527876696995};\\\", \\\"{x:1304,y:807,t:1527876697011};\\\", \\\"{x:1313,y:789,t:1527876697028};\\\", \\\"{x:1321,y:771,t:1527876697045};\\\", \\\"{x:1326,y:759,t:1527876697062};\\\", \\\"{x:1334,y:743,t:1527876697078};\\\", \\\"{x:1339,y:727,t:1527876697095};\\\", \\\"{x:1340,y:720,t:1527876697111};\\\", \\\"{x:1340,y:717,t:1527876697128};\\\", \\\"{x:1341,y:715,t:1527876697146};\\\", \\\"{x:1341,y:713,t:1527876697162};\\\", \\\"{x:1341,y:712,t:1527876697178};\\\", \\\"{x:1342,y:710,t:1527876697195};\\\", \\\"{x:1342,y:709,t:1527876697211};\\\", \\\"{x:1343,y:708,t:1527876697229};\\\", \\\"{x:1343,y:709,t:1527876697432};\\\", \\\"{x:1341,y:711,t:1527876697445};\\\", \\\"{x:1340,y:713,t:1527876697464};\\\", \\\"{x:1339,y:714,t:1527876697479};\\\", \\\"{x:1339,y:716,t:1527876697496};\\\", \\\"{x:1338,y:716,t:1527876697512};\\\", \\\"{x:1336,y:721,t:1527876697529};\\\", \\\"{x:1334,y:724,t:1527876697545};\\\", \\\"{x:1332,y:727,t:1527876697561};\\\", \\\"{x:1329,y:734,t:1527876697578};\\\", \\\"{x:1326,y:740,t:1527876697595};\\\", \\\"{x:1321,y:747,t:1527876697612};\\\", \\\"{x:1319,y:755,t:1527876697628};\\\", \\\"{x:1316,y:768,t:1527876697645};\\\", \\\"{x:1312,y:780,t:1527876697661};\\\", \\\"{x:1310,y:787,t:1527876697678};\\\", \\\"{x:1308,y:794,t:1527876697695};\\\", \\\"{x:1307,y:794,t:1527876697776};\\\", \\\"{x:1308,y:789,t:1527876697784};\\\", \\\"{x:1314,y:781,t:1527876697795};\\\", \\\"{x:1324,y:762,t:1527876697812};\\\", \\\"{x:1331,y:750,t:1527876697828};\\\", \\\"{x:1339,y:740,t:1527876697846};\\\", \\\"{x:1341,y:736,t:1527876697862};\\\", \\\"{x:1343,y:732,t:1527876697878};\\\", \\\"{x:1346,y:727,t:1527876697895};\\\", \\\"{x:1349,y:724,t:1527876697912};\\\", \\\"{x:1350,y:723,t:1527876697929};\\\", \\\"{x:1354,y:721,t:1527876697946};\\\", \\\"{x:1358,y:721,t:1527876697962};\\\", \\\"{x:1362,y:721,t:1527876697978};\\\", \\\"{x:1364,y:722,t:1527876697995};\\\", \\\"{x:1367,y:725,t:1527876698012};\\\", \\\"{x:1368,y:728,t:1527876698028};\\\", \\\"{x:1369,y:728,t:1527876698045};\\\", \\\"{x:1370,y:728,t:1527876698072};\\\", \\\"{x:1371,y:728,t:1527876698079};\\\", \\\"{x:1379,y:726,t:1527876698096};\\\", \\\"{x:1392,y:716,t:1527876698112};\\\", \\\"{x:1403,y:707,t:1527876698129};\\\", \\\"{x:1409,y:701,t:1527876698145};\\\", \\\"{x:1414,y:694,t:1527876698162};\\\", \\\"{x:1419,y:686,t:1527876698179};\\\", \\\"{x:1420,y:679,t:1527876698196};\\\", \\\"{x:1422,y:674,t:1527876698212};\\\", \\\"{x:1423,y:665,t:1527876698227};\\\", \\\"{x:1424,y:662,t:1527876698245};\\\", \\\"{x:1426,y:657,t:1527876698262};\\\", \\\"{x:1427,y:653,t:1527876698278};\\\", \\\"{x:1427,y:651,t:1527876698295};\\\", \\\"{x:1427,y:650,t:1527876698312};\\\", \\\"{x:1427,y:648,t:1527876698335};\\\", \\\"{x:1428,y:647,t:1527876698351};\\\", \\\"{x:1429,y:647,t:1527876698362};\\\", \\\"{x:1430,y:646,t:1527876698378};\\\", \\\"{x:1433,y:644,t:1527876698395};\\\", \\\"{x:1436,y:642,t:1527876698413};\\\", \\\"{x:1438,y:641,t:1527876698429};\\\", \\\"{x:1438,y:640,t:1527876698446};\\\", \\\"{x:1440,y:639,t:1527876698462};\\\", \\\"{x:1442,y:638,t:1527876698503};\\\", \\\"{x:1443,y:637,t:1527876698512};\\\", \\\"{x:1444,y:636,t:1527876698536};\\\", \\\"{x:1444,y:639,t:1527876699224};\\\", \\\"{x:1443,y:645,t:1527876699231};\\\", \\\"{x:1441,y:650,t:1527876699246};\\\", \\\"{x:1438,y:656,t:1527876699263};\\\", \\\"{x:1434,y:664,t:1527876699279};\\\", \\\"{x:1433,y:671,t:1527876699295};\\\", \\\"{x:1430,y:680,t:1527876699313};\\\", \\\"{x:1426,y:693,t:1527876699329};\\\", \\\"{x:1423,y:704,t:1527876699345};\\\", \\\"{x:1420,y:717,t:1527876699362};\\\", \\\"{x:1419,y:727,t:1527876699379};\\\", \\\"{x:1418,y:732,t:1527876699394};\\\", \\\"{x:1417,y:736,t:1527876699412};\\\", \\\"{x:1416,y:740,t:1527876699429};\\\", \\\"{x:1415,y:743,t:1527876699445};\\\", \\\"{x:1415,y:745,t:1527876699462};\\\", \\\"{x:1413,y:749,t:1527876699479};\\\", \\\"{x:1412,y:753,t:1527876699495};\\\", \\\"{x:1412,y:756,t:1527876699512};\\\", \\\"{x:1411,y:761,t:1527876699529};\\\", \\\"{x:1408,y:768,t:1527876699545};\\\", \\\"{x:1405,y:778,t:1527876699562};\\\", \\\"{x:1402,y:791,t:1527876699579};\\\", \\\"{x:1396,y:810,t:1527876699595};\\\", \\\"{x:1386,y:837,t:1527876699612};\\\", \\\"{x:1374,y:864,t:1527876699629};\\\", \\\"{x:1362,y:885,t:1527876699645};\\\", \\\"{x:1354,y:900,t:1527876699662};\\\", \\\"{x:1348,y:914,t:1527876699679};\\\", \\\"{x:1346,y:920,t:1527876699695};\\\", \\\"{x:1340,y:930,t:1527876699712};\\\", \\\"{x:1336,y:934,t:1527876699729};\\\", \\\"{x:1332,y:939,t:1527876699746};\\\", \\\"{x:1327,y:945,t:1527876699762};\\\", \\\"{x:1322,y:949,t:1527876699779};\\\", \\\"{x:1321,y:950,t:1527876699795};\\\", \\\"{x:1320,y:951,t:1527876699812};\\\", \\\"{x:1318,y:952,t:1527876699839};\\\", \\\"{x:1317,y:953,t:1527876699856};\\\", \\\"{x:1316,y:953,t:1527876699863};\\\", \\\"{x:1313,y:955,t:1527876699879};\\\", \\\"{x:1306,y:957,t:1527876699895};\\\", \\\"{x:1299,y:961,t:1527876699912};\\\", \\\"{x:1292,y:962,t:1527876699929};\\\", \\\"{x:1289,y:965,t:1527876699947};\\\", \\\"{x:1287,y:966,t:1527876699968};\\\", \\\"{x:1286,y:966,t:1527876699979};\\\", \\\"{x:1285,y:968,t:1527876699997};\\\", \\\"{x:1284,y:969,t:1527876700013};\\\", \\\"{x:1283,y:969,t:1527876700030};\\\", \\\"{x:1282,y:971,t:1527876700046};\\\", \\\"{x:1281,y:971,t:1527876700063};\\\", \\\"{x:1282,y:971,t:1527876701072};\\\", \\\"{x:1283,y:971,t:1527876701182};\\\", \\\"{x:1283,y:970,t:1527876701196};\\\", \\\"{x:1284,y:970,t:1527876701279};\\\", \\\"{x:1285,y:969,t:1527876701303};\\\", \\\"{x:1286,y:968,t:1527876701343};\\\", \\\"{x:1287,y:967,t:1527876701351};\\\", \\\"{x:1288,y:967,t:1527876701375};\\\", \\\"{x:1288,y:966,t:1527876701391};\\\", \\\"{x:1289,y:966,t:1527876701398};\\\", \\\"{x:1290,y:965,t:1527876701415};\\\", \\\"{x:1291,y:965,t:1527876701431};\\\", \\\"{x:1292,y:964,t:1527876701447};\\\", \\\"{x:1292,y:963,t:1527876701463};\\\", \\\"{x:1293,y:962,t:1527876701479};\\\", \\\"{x:1296,y:962,t:1527876701496};\\\", \\\"{x:1300,y:962,t:1527876701513};\\\", \\\"{x:1304,y:961,t:1527876701530};\\\", \\\"{x:1305,y:961,t:1527876701545};\\\", \\\"{x:1308,y:961,t:1527876701563};\\\", \\\"{x:1314,y:961,t:1527876701580};\\\", \\\"{x:1319,y:961,t:1527876701595};\\\", \\\"{x:1323,y:961,t:1527876701612};\\\", \\\"{x:1328,y:961,t:1527876701630};\\\", \\\"{x:1332,y:963,t:1527876701645};\\\", \\\"{x:1336,y:965,t:1527876701663};\\\", \\\"{x:1338,y:966,t:1527876701680};\\\", \\\"{x:1341,y:968,t:1527876701695};\\\", \\\"{x:1342,y:970,t:1527876701718};\\\", \\\"{x:1344,y:970,t:1527876701830};\\\", \\\"{x:1347,y:969,t:1527876701846};\\\", \\\"{x:1352,y:964,t:1527876701863};\\\", \\\"{x:1359,y:960,t:1527876701880};\\\", \\\"{x:1363,y:958,t:1527876701896};\\\", \\\"{x:1368,y:954,t:1527876701912};\\\", \\\"{x:1371,y:953,t:1527876701930};\\\", \\\"{x:1374,y:952,t:1527876701946};\\\", \\\"{x:1379,y:951,t:1527876701963};\\\", \\\"{x:1381,y:950,t:1527876701980};\\\", \\\"{x:1386,y:949,t:1527876701996};\\\", \\\"{x:1391,y:949,t:1527876702013};\\\", \\\"{x:1396,y:949,t:1527876702030};\\\", \\\"{x:1399,y:949,t:1527876702045};\\\", \\\"{x:1400,y:950,t:1527876702063};\\\", \\\"{x:1401,y:951,t:1527876702080};\\\", \\\"{x:1402,y:953,t:1527876702096};\\\", \\\"{x:1404,y:955,t:1527876702113};\\\", \\\"{x:1405,y:957,t:1527876702130};\\\", \\\"{x:1407,y:959,t:1527876702147};\\\", \\\"{x:1408,y:960,t:1527876702163};\\\", \\\"{x:1409,y:961,t:1527876702181};\\\", \\\"{x:1410,y:962,t:1527876702197};\\\", \\\"{x:1410,y:963,t:1527876702272};\\\", \\\"{x:1411,y:965,t:1527876702288};\\\", \\\"{x:1412,y:965,t:1527876702303};\\\", \\\"{x:1414,y:965,t:1527876702314};\\\", \\\"{x:1422,y:965,t:1527876702331};\\\", \\\"{x:1431,y:963,t:1527876702346};\\\", \\\"{x:1443,y:959,t:1527876702364};\\\", \\\"{x:1453,y:955,t:1527876702380};\\\", \\\"{x:1458,y:954,t:1527876702396};\\\", \\\"{x:1460,y:954,t:1527876702413};\\\", \\\"{x:1461,y:953,t:1527876702446};\\\", \\\"{x:1462,y:953,t:1527876702478};\\\", \\\"{x:1464,y:953,t:1527876702487};\\\", \\\"{x:1465,y:953,t:1527876702496};\\\", \\\"{x:1468,y:953,t:1527876702513};\\\", \\\"{x:1470,y:954,t:1527876702530};\\\", \\\"{x:1473,y:957,t:1527876702546};\\\", \\\"{x:1477,y:960,t:1527876702563};\\\", \\\"{x:1478,y:961,t:1527876702580};\\\", \\\"{x:1481,y:964,t:1527876702597};\\\", \\\"{x:1482,y:964,t:1527876702613};\\\", \\\"{x:1483,y:965,t:1527876702631};\\\", \\\"{x:1484,y:968,t:1527876702647};\\\", \\\"{x:1485,y:968,t:1527876702663};\\\", \\\"{x:1485,y:969,t:1527876702720};\\\", \\\"{x:1485,y:970,t:1527876702895};\\\", \\\"{x:1487,y:969,t:1527876702911};\\\", \\\"{x:1488,y:969,t:1527876703407};\\\", \\\"{x:1489,y:968,t:1527876703431};\\\", \\\"{x:1491,y:968,t:1527876703448};\\\", \\\"{x:1492,y:965,t:1527876703464};\\\", \\\"{x:1494,y:964,t:1527876703481};\\\", \\\"{x:1499,y:961,t:1527876703498};\\\", \\\"{x:1505,y:957,t:1527876703513};\\\", \\\"{x:1517,y:950,t:1527876703530};\\\", \\\"{x:1533,y:943,t:1527876703548};\\\", \\\"{x:1537,y:940,t:1527876703564};\\\", \\\"{x:1545,y:939,t:1527876703580};\\\", \\\"{x:1551,y:938,t:1527876703597};\\\", \\\"{x:1555,y:938,t:1527876703613};\\\", \\\"{x:1557,y:938,t:1527876703630};\\\", \\\"{x:1559,y:945,t:1527876703646};\\\", \\\"{x:1563,y:953,t:1527876703664};\\\", \\\"{x:1565,y:958,t:1527876703680};\\\", \\\"{x:1566,y:962,t:1527876703697};\\\", \\\"{x:1567,y:964,t:1527876703714};\\\", \\\"{x:1567,y:965,t:1527876703735};\\\", \\\"{x:1567,y:966,t:1527876703848};\\\", \\\"{x:1568,y:964,t:1527876703865};\\\", \\\"{x:1571,y:962,t:1527876703881};\\\", \\\"{x:1577,y:957,t:1527876703897};\\\", \\\"{x:1589,y:957,t:1527876703915};\\\", \\\"{x:1602,y:957,t:1527876703930};\\\", \\\"{x:1610,y:957,t:1527876703947};\\\", \\\"{x:1614,y:958,t:1527876703964};\\\", \\\"{x:1614,y:959,t:1527876703980};\\\", \\\"{x:1615,y:961,t:1527876703997};\\\", \\\"{x:1615,y:964,t:1527876704014};\\\", \\\"{x:1616,y:970,t:1527876704030};\\\", \\\"{x:1616,y:971,t:1527876704047};\\\", \\\"{x:1616,y:969,t:1527876704086};\\\", \\\"{x:1613,y:961,t:1527876704097};\\\", \\\"{x:1607,y:947,t:1527876704114};\\\", \\\"{x:1602,y:930,t:1527876704130};\\\", \\\"{x:1595,y:906,t:1527876704147};\\\", \\\"{x:1585,y:879,t:1527876704165};\\\", \\\"{x:1574,y:848,t:1527876704180};\\\", \\\"{x:1563,y:825,t:1527876704197};\\\", \\\"{x:1554,y:801,t:1527876704214};\\\", \\\"{x:1549,y:791,t:1527876704231};\\\", \\\"{x:1546,y:785,t:1527876704247};\\\", \\\"{x:1545,y:784,t:1527876704264};\\\", \\\"{x:1544,y:782,t:1527876704288};\\\", \\\"{x:1539,y:783,t:1527876704320};\\\", \\\"{x:1536,y:785,t:1527876704330};\\\", \\\"{x:1524,y:793,t:1527876704348};\\\", \\\"{x:1522,y:794,t:1527876704364};\\\", \\\"{x:1521,y:794,t:1527876704380};\\\", \\\"{x:1521,y:793,t:1527876704503};\\\", \\\"{x:1521,y:790,t:1527876704514};\\\", \\\"{x:1521,y:786,t:1527876704530};\\\", \\\"{x:1522,y:782,t:1527876704547};\\\", \\\"{x:1522,y:775,t:1527876704564};\\\", \\\"{x:1524,y:771,t:1527876704581};\\\", \\\"{x:1524,y:770,t:1527876704598};\\\", \\\"{x:1525,y:767,t:1527876704615};\\\", \\\"{x:1526,y:764,t:1527876704631};\\\", \\\"{x:1526,y:762,t:1527876704648};\\\", \\\"{x:1527,y:760,t:1527876704671};\\\", \\\"{x:1526,y:760,t:1527876704896};\\\", \\\"{x:1525,y:760,t:1527876704903};\\\", \\\"{x:1522,y:760,t:1527876704915};\\\", \\\"{x:1521,y:760,t:1527876704931};\\\", \\\"{x:1517,y:761,t:1527876704948};\\\", \\\"{x:1516,y:761,t:1527876704965};\\\", \\\"{x:1515,y:762,t:1527876704982};\\\", \\\"{x:1513,y:762,t:1527876704997};\\\", \\\"{x:1510,y:763,t:1527876705015};\\\", \\\"{x:1507,y:766,t:1527876705032};\\\", \\\"{x:1506,y:767,t:1527876705047};\\\", \\\"{x:1507,y:767,t:1527876705240};\\\", \\\"{x:1510,y:765,t:1527876705247};\\\", \\\"{x:1514,y:761,t:1527876705264};\\\", \\\"{x:1527,y:752,t:1527876705282};\\\", \\\"{x:1537,y:743,t:1527876705298};\\\", \\\"{x:1540,y:740,t:1527876705315};\\\", \\\"{x:1543,y:737,t:1527876705332};\\\", \\\"{x:1546,y:733,t:1527876705348};\\\", \\\"{x:1551,y:722,t:1527876705364};\\\", \\\"{x:1556,y:716,t:1527876705382};\\\", \\\"{x:1559,y:710,t:1527876705398};\\\", \\\"{x:1563,y:703,t:1527876705414};\\\", \\\"{x:1563,y:695,t:1527876705431};\\\", \\\"{x:1563,y:690,t:1527876705448};\\\", \\\"{x:1563,y:686,t:1527876705465};\\\", \\\"{x:1563,y:683,t:1527876705482};\\\", \\\"{x:1563,y:678,t:1527876705497};\\\", \\\"{x:1563,y:672,t:1527876705514};\\\", \\\"{x:1563,y:666,t:1527876705530};\\\", \\\"{x:1563,y:660,t:1527876705547};\\\", \\\"{x:1563,y:656,t:1527876705564};\\\", \\\"{x:1564,y:654,t:1527876705581};\\\", \\\"{x:1566,y:652,t:1527876705598};\\\", \\\"{x:1566,y:651,t:1527876705621};\\\", \\\"{x:1566,y:650,t:1527876705638};\\\", \\\"{x:1566,y:649,t:1527876705647};\\\", \\\"{x:1566,y:648,t:1527876705670};\\\", \\\"{x:1568,y:648,t:1527876705750};\\\", \\\"{x:1570,y:646,t:1527876705764};\\\", \\\"{x:1577,y:642,t:1527876705781};\\\", \\\"{x:1583,y:637,t:1527876705798};\\\", \\\"{x:1586,y:636,t:1527876705813};\\\", \\\"{x:1587,y:636,t:1527876705831};\\\", \\\"{x:1589,y:636,t:1527876705910};\\\", \\\"{x:1590,y:636,t:1527876705942};\\\", \\\"{x:1591,y:636,t:1527876705958};\\\", \\\"{x:1592,y:636,t:1527876706006};\\\", \\\"{x:1592,y:635,t:1527876706207};\\\", \\\"{x:1592,y:634,t:1527876706214};\\\", \\\"{x:1590,y:634,t:1527876706231};\\\", \\\"{x:1589,y:633,t:1527876706248};\\\", \\\"{x:1588,y:633,t:1527876706264};\\\", \\\"{x:1587,y:632,t:1527876706281};\\\", \\\"{x:1586,y:632,t:1527876706302};\\\", \\\"{x:1586,y:631,t:1527876706331};\\\", \\\"{x:1585,y:631,t:1527876706399};\\\", \\\"{x:1583,y:631,t:1527876706431};\\\", \\\"{x:1583,y:630,t:1527876706448};\\\", \\\"{x:1582,y:628,t:1527876706464};\\\", \\\"{x:1581,y:626,t:1527876706481};\\\", \\\"{x:1579,y:623,t:1527876706499};\\\", \\\"{x:1578,y:622,t:1527876706515};\\\", \\\"{x:1569,y:619,t:1527876706532};\\\", \\\"{x:1555,y:617,t:1527876706548};\\\", \\\"{x:1535,y:616,t:1527876706566};\\\", \\\"{x:1507,y:612,t:1527876706582};\\\", \\\"{x:1489,y:611,t:1527876706598};\\\", \\\"{x:1477,y:608,t:1527876706615};\\\", \\\"{x:1474,y:606,t:1527876706759};\\\", \\\"{x:1470,y:603,t:1527876706767};\\\", \\\"{x:1467,y:598,t:1527876706781};\\\", \\\"{x:1461,y:589,t:1527876706798};\\\", \\\"{x:1446,y:578,t:1527876706814};\\\", \\\"{x:1433,y:569,t:1527876706832};\\\", \\\"{x:1427,y:565,t:1527876706848};\\\", \\\"{x:1426,y:564,t:1527876706866};\\\", \\\"{x:1425,y:564,t:1527876707063};\\\", \\\"{x:1423,y:564,t:1527876707071};\\\", \\\"{x:1422,y:564,t:1527876707081};\\\", \\\"{x:1420,y:564,t:1527876707098};\\\", \\\"{x:1418,y:564,t:1527876707115};\\\", \\\"{x:1417,y:564,t:1527876707131};\\\", \\\"{x:1414,y:566,t:1527876708495};\\\", \\\"{x:1406,y:577,t:1527876708504};\\\", \\\"{x:1401,y:583,t:1527876708515};\\\", \\\"{x:1390,y:598,t:1527876708533};\\\", \\\"{x:1383,y:609,t:1527876708550};\\\", \\\"{x:1374,y:619,t:1527876708566};\\\", \\\"{x:1370,y:623,t:1527876708582};\\\", \\\"{x:1367,y:630,t:1527876708600};\\\", \\\"{x:1362,y:640,t:1527876708616};\\\", \\\"{x:1356,y:648,t:1527876708632};\\\", \\\"{x:1348,y:661,t:1527876708649};\\\", \\\"{x:1344,y:668,t:1527876708666};\\\", \\\"{x:1339,y:679,t:1527876708682};\\\", \\\"{x:1336,y:685,t:1527876708699};\\\", \\\"{x:1332,y:695,t:1527876708715};\\\", \\\"{x:1329,y:703,t:1527876708732};\\\", \\\"{x:1325,y:713,t:1527876708749};\\\", \\\"{x:1319,y:735,t:1527876708765};\\\", \\\"{x:1316,y:750,t:1527876708782};\\\", \\\"{x:1309,y:769,t:1527876708799};\\\", \\\"{x:1306,y:776,t:1527876708815};\\\", \\\"{x:1305,y:782,t:1527876708832};\\\", \\\"{x:1304,y:786,t:1527876708849};\\\", \\\"{x:1304,y:789,t:1527876708865};\\\", \\\"{x:1303,y:793,t:1527876708882};\\\", \\\"{x:1301,y:800,t:1527876708900};\\\", \\\"{x:1299,y:809,t:1527876708915};\\\", \\\"{x:1297,y:818,t:1527876708932};\\\", \\\"{x:1292,y:827,t:1527876708949};\\\", \\\"{x:1287,y:836,t:1527876708966};\\\", \\\"{x:1281,y:847,t:1527876708983};\\\", \\\"{x:1268,y:865,t:1527876708999};\\\", \\\"{x:1260,y:878,t:1527876709016};\\\", \\\"{x:1252,y:889,t:1527876709033};\\\", \\\"{x:1245,y:901,t:1527876709050};\\\", \\\"{x:1237,y:915,t:1527876709066};\\\", \\\"{x:1234,y:919,t:1527876709082};\\\", \\\"{x:1232,y:923,t:1527876709100};\\\", \\\"{x:1231,y:925,t:1527876709116};\\\", \\\"{x:1231,y:926,t:1527876709143};\\\", \\\"{x:1229,y:927,t:1527876709160};\\\", \\\"{x:1229,y:929,t:1527876709167};\\\", \\\"{x:1229,y:930,t:1527876709191};\\\", \\\"{x:1228,y:931,t:1527876709198};\\\", \\\"{x:1226,y:933,t:1527876709216};\\\", \\\"{x:1225,y:936,t:1527876709233};\\\", \\\"{x:1224,y:940,t:1527876709250};\\\", \\\"{x:1221,y:945,t:1527876709265};\\\", \\\"{x:1219,y:948,t:1527876709282};\\\", \\\"{x:1218,y:952,t:1527876709299};\\\", \\\"{x:1216,y:955,t:1527876709315};\\\", \\\"{x:1214,y:959,t:1527876709332};\\\", \\\"{x:1213,y:960,t:1527876709349};\\\", \\\"{x:1214,y:961,t:1527876709406};\\\", \\\"{x:1217,y:961,t:1527876709415};\\\", \\\"{x:1224,y:959,t:1527876709432};\\\", \\\"{x:1237,y:954,t:1527876709449};\\\", \\\"{x:1247,y:951,t:1527876709466};\\\", \\\"{x:1255,y:950,t:1527876709482};\\\", \\\"{x:1260,y:949,t:1527876709500};\\\", \\\"{x:1262,y:949,t:1527876709517};\\\", \\\"{x:1263,y:949,t:1527876709535};\\\", \\\"{x:1264,y:949,t:1527876709550};\\\", \\\"{x:1265,y:950,t:1527876709566};\\\", \\\"{x:1269,y:956,t:1527876709582};\\\", \\\"{x:1271,y:959,t:1527876709599};\\\", \\\"{x:1272,y:962,t:1527876709617};\\\", \\\"{x:1273,y:965,t:1527876709633};\\\", \\\"{x:1274,y:970,t:1527876709650};\\\", \\\"{x:1277,y:973,t:1527876709667};\\\", \\\"{x:1279,y:977,t:1527876709683};\\\", \\\"{x:1280,y:978,t:1527876709699};\\\", \\\"{x:1281,y:978,t:1527876709743};\\\", \\\"{x:1283,y:978,t:1527876709751};\\\", \\\"{x:1284,y:978,t:1527876709766};\\\", \\\"{x:1293,y:974,t:1527876709782};\\\", \\\"{x:1308,y:969,t:1527876709800};\\\", \\\"{x:1322,y:964,t:1527876709817};\\\", \\\"{x:1332,y:960,t:1527876709833};\\\", \\\"{x:1343,y:957,t:1527876709850};\\\", \\\"{x:1351,y:956,t:1527876709867};\\\", \\\"{x:1360,y:955,t:1527876709883};\\\", \\\"{x:1366,y:955,t:1527876709900};\\\", \\\"{x:1369,y:955,t:1527876709916};\\\", \\\"{x:1371,y:955,t:1527876709932};\\\", \\\"{x:1371,y:956,t:1527876709951};\\\", \\\"{x:1371,y:958,t:1527876709967};\\\", \\\"{x:1371,y:960,t:1527876709983};\\\", \\\"{x:1371,y:961,t:1527876710000};\\\", \\\"{x:1371,y:963,t:1527876710016};\\\", \\\"{x:1371,y:965,t:1527876710033};\\\", \\\"{x:1370,y:967,t:1527876710049};\\\", \\\"{x:1369,y:968,t:1527876710066};\\\", \\\"{x:1369,y:969,t:1527876710082};\\\", \\\"{x:1368,y:970,t:1527876710099};\\\", \\\"{x:1367,y:971,t:1527876710116};\\\", \\\"{x:1368,y:971,t:1527876710207};\\\", \\\"{x:1368,y:970,t:1527876710216};\\\", \\\"{x:1375,y:965,t:1527876710234};\\\", \\\"{x:1385,y:961,t:1527876710249};\\\", \\\"{x:1400,y:958,t:1527876710266};\\\", \\\"{x:1415,y:957,t:1527876710283};\\\", \\\"{x:1425,y:956,t:1527876710299};\\\", \\\"{x:1427,y:956,t:1527876710316};\\\", \\\"{x:1428,y:956,t:1527876710333};\\\", \\\"{x:1428,y:958,t:1527876710359};\\\", \\\"{x:1429,y:959,t:1527876710366};\\\", \\\"{x:1429,y:960,t:1527876710383};\\\", \\\"{x:1429,y:964,t:1527876710399};\\\", \\\"{x:1429,y:965,t:1527876710416};\\\", \\\"{x:1429,y:967,t:1527876710433};\\\", \\\"{x:1429,y:969,t:1527876710449};\\\", \\\"{x:1429,y:970,t:1527876710466};\\\", \\\"{x:1429,y:972,t:1527876710483};\\\", \\\"{x:1429,y:973,t:1527876710499};\\\", \\\"{x:1429,y:975,t:1527876710517};\\\", \\\"{x:1428,y:975,t:1527876710622};\\\", \\\"{x:1430,y:972,t:1527876710633};\\\", \\\"{x:1435,y:968,t:1527876710649};\\\", \\\"{x:1445,y:963,t:1527876710667};\\\", \\\"{x:1459,y:957,t:1527876710684};\\\", \\\"{x:1475,y:953,t:1527876710699};\\\", \\\"{x:1484,y:951,t:1527876710716};\\\", \\\"{x:1486,y:951,t:1527876710734};\\\", \\\"{x:1488,y:950,t:1527876710750};\\\", \\\"{x:1488,y:952,t:1527876710808};\\\", \\\"{x:1488,y:953,t:1527876710817};\\\", \\\"{x:1488,y:956,t:1527876710833};\\\", \\\"{x:1488,y:959,t:1527876710849};\\\", \\\"{x:1487,y:962,t:1527876710866};\\\", \\\"{x:1487,y:964,t:1527876710884};\\\", \\\"{x:1487,y:966,t:1527876710900};\\\", \\\"{x:1485,y:968,t:1527876710917};\\\", \\\"{x:1485,y:969,t:1527876710933};\\\", \\\"{x:1485,y:970,t:1527876710966};\\\", \\\"{x:1489,y:968,t:1527876711095};\\\", \\\"{x:1493,y:966,t:1527876711103};\\\", \\\"{x:1496,y:964,t:1527876711116};\\\", \\\"{x:1507,y:959,t:1527876711134};\\\", \\\"{x:1521,y:955,t:1527876711149};\\\", \\\"{x:1538,y:955,t:1527876711166};\\\", \\\"{x:1548,y:955,t:1527876711183};\\\", \\\"{x:1551,y:955,t:1527876711200};\\\", \\\"{x:1552,y:955,t:1527876711216};\\\", \\\"{x:1552,y:956,t:1527876711238};\\\", \\\"{x:1552,y:958,t:1527876711250};\\\", \\\"{x:1552,y:960,t:1527876711267};\\\", \\\"{x:1552,y:961,t:1527876711283};\\\", \\\"{x:1552,y:963,t:1527876711300};\\\", \\\"{x:1552,y:964,t:1527876711316};\\\", \\\"{x:1552,y:966,t:1527876711334};\\\", \\\"{x:1551,y:967,t:1527876711350};\\\", \\\"{x:1551,y:966,t:1527876711711};\\\", \\\"{x:1552,y:965,t:1527876711719};\\\", \\\"{x:1553,y:963,t:1527876711734};\\\", \\\"{x:1554,y:961,t:1527876711752};\\\", \\\"{x:1556,y:960,t:1527876711767};\\\", \\\"{x:1557,y:959,t:1527876711783};\\\", \\\"{x:1559,y:959,t:1527876711801};\\\", \\\"{x:1568,y:955,t:1527876711817};\\\", \\\"{x:1577,y:952,t:1527876711833};\\\", \\\"{x:1587,y:951,t:1527876711851};\\\", \\\"{x:1593,y:951,t:1527876711866};\\\", \\\"{x:1598,y:951,t:1527876711884};\\\", \\\"{x:1600,y:951,t:1527876711903};\\\", \\\"{x:1602,y:951,t:1527876711918};\\\", \\\"{x:1604,y:952,t:1527876711933};\\\", \\\"{x:1608,y:959,t:1527876711950};\\\", \\\"{x:1610,y:964,t:1527876711967};\\\", \\\"{x:1612,y:965,t:1527876711983};\\\", \\\"{x:1612,y:961,t:1527876712054};\\\", \\\"{x:1609,y:954,t:1527876712066};\\\", \\\"{x:1595,y:932,t:1527876712083};\\\", \\\"{x:1557,y:871,t:1527876712101};\\\", \\\"{x:1518,y:810,t:1527876712117};\\\", \\\"{x:1487,y:756,t:1527876712133};\\\", \\\"{x:1463,y:696,t:1527876712150};\\\", \\\"{x:1454,y:676,t:1527876712167};\\\", \\\"{x:1449,y:663,t:1527876712183};\\\", \\\"{x:1443,y:650,t:1527876712201};\\\", \\\"{x:1439,y:642,t:1527876712217};\\\", \\\"{x:1438,y:639,t:1527876712233};\\\", \\\"{x:1438,y:638,t:1527876712251};\\\", \\\"{x:1438,y:636,t:1527876712271};\\\", \\\"{x:1438,y:634,t:1527876712284};\\\", \\\"{x:1438,y:624,t:1527876712301};\\\", \\\"{x:1436,y:611,t:1527876712317};\\\", \\\"{x:1436,y:600,t:1527876712333};\\\", \\\"{x:1436,y:587,t:1527876712350};\\\", \\\"{x:1435,y:582,t:1527876712366};\\\", \\\"{x:1435,y:577,t:1527876712383};\\\", \\\"{x:1432,y:569,t:1527876712400};\\\", \\\"{x:1429,y:561,t:1527876712417};\\\", \\\"{x:1427,y:556,t:1527876712433};\\\", \\\"{x:1427,y:553,t:1527876712450};\\\", \\\"{x:1426,y:550,t:1527876712468};\\\", \\\"{x:1426,y:549,t:1527876712484};\\\", \\\"{x:1425,y:547,t:1527876712500};\\\", \\\"{x:1424,y:547,t:1527876712680};\\\", \\\"{x:1420,y:547,t:1527876712688};\\\", \\\"{x:1415,y:547,t:1527876712701};\\\", \\\"{x:1398,y:554,t:1527876712718};\\\", \\\"{x:1384,y:561,t:1527876712734};\\\", \\\"{x:1368,y:567,t:1527876712751};\\\", \\\"{x:1364,y:568,t:1527876712767};\\\", \\\"{x:1361,y:568,t:1527876712784};\\\", \\\"{x:1359,y:568,t:1527876712800};\\\", \\\"{x:1354,y:571,t:1527876712817};\\\", \\\"{x:1344,y:572,t:1527876712833};\\\", \\\"{x:1333,y:573,t:1527876712851};\\\", \\\"{x:1318,y:575,t:1527876712867};\\\", \\\"{x:1301,y:576,t:1527876712884};\\\", \\\"{x:1285,y:576,t:1527876712901};\\\", \\\"{x:1271,y:576,t:1527876712917};\\\", \\\"{x:1267,y:576,t:1527876712934};\\\", \\\"{x:1266,y:576,t:1527876712951};\\\", \\\"{x:1265,y:576,t:1527876713048};\\\", \\\"{x:1266,y:577,t:1527876714119};\\\", \\\"{x:1271,y:579,t:1527876714135};\\\", \\\"{x:1281,y:581,t:1527876714151};\\\", \\\"{x:1296,y:586,t:1527876714168};\\\", \\\"{x:1301,y:589,t:1527876714185};\\\", \\\"{x:1307,y:590,t:1527876714202};\\\", \\\"{x:1310,y:592,t:1527876714218};\\\", \\\"{x:1312,y:592,t:1527876714235};\\\", \\\"{x:1312,y:596,t:1527876714296};\\\", \\\"{x:1304,y:600,t:1527876714303};\\\", \\\"{x:1302,y:605,t:1527876714318};\\\", \\\"{x:1295,y:609,t:1527876714335};\\\", \\\"{x:1295,y:606,t:1527876714648};\\\", \\\"{x:1291,y:602,t:1527876714679};\\\", \\\"{x:1277,y:599,t:1527876714687};\\\", \\\"{x:1263,y:594,t:1527876714702};\\\", \\\"{x:1227,y:590,t:1527876714718};\\\", \\\"{x:1177,y:589,t:1527876714735};\\\", \\\"{x:1146,y:587,t:1527876714751};\\\", \\\"{x:1115,y:582,t:1527876714767};\\\", \\\"{x:1085,y:576,t:1527876714785};\\\", \\\"{x:1056,y:571,t:1527876714802};\\\", \\\"{x:1029,y:568,t:1527876714818};\\\", \\\"{x:1009,y:564,t:1527876714835};\\\", \\\"{x:989,y:556,t:1527876714853};\\\", \\\"{x:967,y:549,t:1527876714868};\\\", \\\"{x:943,y:543,t:1527876714886};\\\", \\\"{x:916,y:536,t:1527876714901};\\\", \\\"{x:867,y:529,t:1527876714917};\\\", \\\"{x:820,y:523,t:1527876714932};\\\", \\\"{x:798,y:517,t:1527876714948};\\\", \\\"{x:774,y:513,t:1527876714964};\\\", \\\"{x:752,y:507,t:1527876714981};\\\", \\\"{x:737,y:504,t:1527876714998};\\\", \\\"{x:733,y:503,t:1527876715014};\\\", \\\"{x:731,y:502,t:1527876715031};\\\", \\\"{x:727,y:501,t:1527876715048};\\\", \\\"{x:717,y:499,t:1527876715064};\\\", \\\"{x:705,y:498,t:1527876715081};\\\", \\\"{x:689,y:494,t:1527876715098};\\\", \\\"{x:680,y:493,t:1527876715114};\\\", \\\"{x:672,y:491,t:1527876715132};\\\", \\\"{x:663,y:488,t:1527876715148};\\\", \\\"{x:658,y:487,t:1527876715164};\\\", \\\"{x:654,y:486,t:1527876715182};\\\", \\\"{x:647,y:485,t:1527876715198};\\\", \\\"{x:642,y:485,t:1527876715214};\\\", \\\"{x:637,y:485,t:1527876715231};\\\", \\\"{x:632,y:486,t:1527876715248};\\\", \\\"{x:628,y:486,t:1527876715264};\\\", \\\"{x:626,y:486,t:1527876715282};\\\", \\\"{x:624,y:487,t:1527876715302};\\\", \\\"{x:623,y:488,t:1527876715318};\\\", \\\"{x:622,y:489,t:1527876715331};\\\", \\\"{x:617,y:492,t:1527876715349};\\\", \\\"{x:612,y:496,t:1527876715365};\\\", \\\"{x:611,y:497,t:1527876715381};\\\", \\\"{x:609,y:498,t:1527876715398};\\\", \\\"{x:608,y:499,t:1527876715415};\\\", \\\"{x:607,y:499,t:1527876715431};\\\", \\\"{x:606,y:500,t:1527876715448};\\\", \\\"{x:607,y:499,t:1527876715550};\\\", \\\"{x:608,y:499,t:1527876715565};\\\", \\\"{x:609,y:499,t:1527876715590};\\\", \\\"{x:605,y:499,t:1527876715823};\\\", \\\"{x:600,y:500,t:1527876715833};\\\", \\\"{x:586,y:508,t:1527876715849};\\\", \\\"{x:561,y:516,t:1527876715865};\\\", \\\"{x:537,y:526,t:1527876715882};\\\", \\\"{x:516,y:532,t:1527876715898};\\\", \\\"{x:504,y:538,t:1527876715916};\\\", \\\"{x:490,y:543,t:1527876715933};\\\", \\\"{x:473,y:549,t:1527876715949};\\\", \\\"{x:454,y:553,t:1527876715965};\\\", \\\"{x:418,y:559,t:1527876715982};\\\", \\\"{x:387,y:562,t:1527876715998};\\\", \\\"{x:372,y:565,t:1527876716016};\\\", \\\"{x:351,y:569,t:1527876716032};\\\", \\\"{x:336,y:571,t:1527876716048};\\\", \\\"{x:323,y:572,t:1527876716065};\\\", \\\"{x:310,y:577,t:1527876716082};\\\", \\\"{x:301,y:579,t:1527876716098};\\\", \\\"{x:297,y:581,t:1527876716115};\\\", \\\"{x:294,y:585,t:1527876716132};\\\", \\\"{x:294,y:587,t:1527876716148};\\\", \\\"{x:294,y:589,t:1527876716165};\\\", \\\"{x:319,y:589,t:1527876716182};\\\", \\\"{x:351,y:589,t:1527876716198};\\\", \\\"{x:402,y:589,t:1527876716216};\\\", \\\"{x:468,y:589,t:1527876716233};\\\", \\\"{x:527,y:589,t:1527876716251};\\\", \\\"{x:588,y:589,t:1527876716265};\\\", \\\"{x:644,y:589,t:1527876716282};\\\", \\\"{x:681,y:589,t:1527876716300};\\\", \\\"{x:703,y:589,t:1527876716316};\\\", \\\"{x:717,y:589,t:1527876716332};\\\", \\\"{x:729,y:589,t:1527876716350};\\\", \\\"{x:761,y:585,t:1527876716366};\\\", \\\"{x:788,y:579,t:1527876716382};\\\", \\\"{x:814,y:574,t:1527876716399};\\\", \\\"{x:835,y:568,t:1527876716415};\\\", \\\"{x:856,y:564,t:1527876716433};\\\", \\\"{x:871,y:560,t:1527876716450};\\\", \\\"{x:881,y:555,t:1527876716466};\\\", \\\"{x:881,y:554,t:1527876716482};\\\", \\\"{x:881,y:552,t:1527876716518};\\\", \\\"{x:880,y:552,t:1527876716533};\\\", \\\"{x:879,y:551,t:1527876716549};\\\", \\\"{x:875,y:547,t:1527876716566};\\\", \\\"{x:861,y:533,t:1527876716582};\\\", \\\"{x:846,y:523,t:1527876716599};\\\", \\\"{x:837,y:520,t:1527876716616};\\\", \\\"{x:831,y:519,t:1527876716633};\\\", \\\"{x:827,y:519,t:1527876716649};\\\", \\\"{x:826,y:519,t:1527876716666};\\\", \\\"{x:824,y:519,t:1527876716682};\\\", \\\"{x:822,y:519,t:1527876716699};\\\", \\\"{x:820,y:519,t:1527876716716};\\\", \\\"{x:820,y:520,t:1527876716732};\\\", \\\"{x:820,y:522,t:1527876716749};\\\", \\\"{x:820,y:523,t:1527876716790};\\\", \\\"{x:820,y:525,t:1527876716807};\\\", \\\"{x:820,y:527,t:1527876716816};\\\", \\\"{x:823,y:530,t:1527876716833};\\\", \\\"{x:829,y:534,t:1527876716850};\\\", \\\"{x:835,y:539,t:1527876716866};\\\", \\\"{x:838,y:541,t:1527876716882};\\\", \\\"{x:839,y:541,t:1527876716900};\\\", \\\"{x:840,y:541,t:1527876716918};\\\", \\\"{x:840,y:542,t:1527876717134};\\\", \\\"{x:834,y:546,t:1527876717149};\\\", \\\"{x:800,y:564,t:1527876717167};\\\", \\\"{x:777,y:580,t:1527876717183};\\\", \\\"{x:725,y:602,t:1527876717200};\\\", \\\"{x:667,y:627,t:1527876717217};\\\", \\\"{x:612,y:649,t:1527876717234};\\\", \\\"{x:579,y:662,t:1527876717250};\\\", \\\"{x:562,y:672,t:1527876717267};\\\", \\\"{x:552,y:676,t:1527876717283};\\\", \\\"{x:547,y:682,t:1527876717300};\\\", \\\"{x:546,y:684,t:1527876717316};\\\", \\\"{x:544,y:691,t:1527876717334};\\\", \\\"{x:542,y:698,t:1527876717349};\\\", \\\"{x:541,y:702,t:1527876717367};\\\", \\\"{x:540,y:707,t:1527876717383};\\\", \\\"{x:539,y:719,t:1527876717400};\\\", \\\"{x:537,y:729,t:1527876717418};\\\", \\\"{x:535,y:737,t:1527876717434};\\\", \\\"{x:533,y:743,t:1527876717450};\\\", \\\"{x:532,y:745,t:1527876717466};\\\", \\\"{x:534,y:745,t:1527876717750};\\\", \\\"{x:554,y:744,t:1527876717766};\\\", \\\"{x:593,y:736,t:1527876717784};\\\", \\\"{x:598,y:731,t:1527876717800};\\\", \\\"{x:599,y:731,t:1527876718423};\\\", \\\"{x:602,y:731,t:1527876718434};\\\", \\\"{x:602,y:730,t:1527876718451};\\\", \\\"{x:603,y:729,t:1527876718494};\\\", \\\"{x:604,y:728,t:1527876718503};\\\", \\\"{x:605,y:727,t:1527876718526};\\\", \\\"{x:607,y:726,t:1527876718534};\\\", \\\"{x:611,y:724,t:1527876718551};\\\", \\\"{x:615,y:722,t:1527876718568};\\\", \\\"{x:621,y:719,t:1527876718584};\\\", \\\"{x:627,y:717,t:1527876718601};\\\", \\\"{x:635,y:714,t:1527876718618};\\\", \\\"{x:662,y:707,t:1527876718652};\\\", \\\"{x:679,y:701,t:1527876718667};\\\", \\\"{x:697,y:697,t:1527876718683};\\\", \\\"{x:707,y:693,t:1527876718700};\\\", \\\"{x:709,y:692,t:1527876718717};\\\", \\\"{x:724,y:689,t:1527876718733};\\\" ] }, { \\\"rt\\\": 28167, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 359425, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -E -F -11 AM-12 PM-F -O -X -X -X -O -O -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:806,y:675,t:1527876718857};\\\", \\\"{x:809,y:674,t:1527876718867};\\\", \\\"{x:818,y:673,t:1527876718885};\\\", \\\"{x:825,y:671,t:1527876718901};\\\", \\\"{x:828,y:671,t:1527876718917};\\\", \\\"{x:831,y:671,t:1527876718952};\\\", \\\"{x:833,y:671,t:1527876718968};\\\", \\\"{x:839,y:671,t:1527876718984};\\\", \\\"{x:841,y:671,t:1527876719002};\\\", \\\"{x:844,y:671,t:1527876719017};\\\", \\\"{x:848,y:671,t:1527876719034};\\\", \\\"{x:853,y:671,t:1527876719052};\\\", \\\"{x:854,y:671,t:1527876719068};\\\", \\\"{x:855,y:671,t:1527876719284};\\\", \\\"{x:856,y:671,t:1527876719350};\\\", \\\"{x:856,y:672,t:1527876719590};\\\", \\\"{x:856,y:671,t:1527876720079};\\\", \\\"{x:850,y:669,t:1527876720087};\\\", \\\"{x:846,y:665,t:1527876720102};\\\", \\\"{x:834,y:657,t:1527876720118};\\\", \\\"{x:830,y:654,t:1527876720136};\\\", \\\"{x:826,y:651,t:1527876720152};\\\", \\\"{x:821,y:648,t:1527876720169};\\\", \\\"{x:817,y:644,t:1527876720186};\\\", \\\"{x:809,y:640,t:1527876720203};\\\", \\\"{x:797,y:634,t:1527876720219};\\\", \\\"{x:782,y:626,t:1527876720237};\\\", \\\"{x:761,y:617,t:1527876720252};\\\", \\\"{x:728,y:607,t:1527876720268};\\\", \\\"{x:688,y:594,t:1527876720286};\\\", \\\"{x:629,y:576,t:1527876720302};\\\", \\\"{x:583,y:561,t:1527876720319};\\\", \\\"{x:545,y:547,t:1527876720336};\\\", \\\"{x:514,y:535,t:1527876720353};\\\", \\\"{x:481,y:520,t:1527876720369};\\\", \\\"{x:457,y:511,t:1527876720386};\\\", \\\"{x:436,y:504,t:1527876720403};\\\", \\\"{x:416,y:500,t:1527876720418};\\\", \\\"{x:400,y:494,t:1527876720436};\\\", \\\"{x:390,y:491,t:1527876720453};\\\", \\\"{x:382,y:490,t:1527876720468};\\\", \\\"{x:379,y:489,t:1527876720486};\\\", \\\"{x:375,y:487,t:1527876720502};\\\", \\\"{x:373,y:486,t:1527876720520};\\\", \\\"{x:371,y:485,t:1527876720535};\\\", \\\"{x:369,y:484,t:1527876720553};\\\", \\\"{x:367,y:483,t:1527876720568};\\\", \\\"{x:365,y:481,t:1527876720585};\\\", \\\"{x:364,y:480,t:1527876720603};\\\", \\\"{x:361,y:476,t:1527876720618};\\\", \\\"{x:359,y:473,t:1527876720635};\\\", \\\"{x:358,y:470,t:1527876720653};\\\", \\\"{x:357,y:469,t:1527876720669};\\\", \\\"{x:357,y:467,t:1527876720686};\\\", \\\"{x:357,y:466,t:1527876720703};\\\", \\\"{x:357,y:465,t:1527876720727};\\\", \\\"{x:357,y:464,t:1527876720759};\\\", \\\"{x:357,y:463,t:1527876720775};\\\", \\\"{x:358,y:463,t:1527876720786};\\\", \\\"{x:362,y:463,t:1527876720803};\\\", \\\"{x:369,y:465,t:1527876720819};\\\", \\\"{x:377,y:468,t:1527876720835};\\\", \\\"{x:383,y:470,t:1527876720853};\\\", \\\"{x:390,y:473,t:1527876720869};\\\", \\\"{x:398,y:477,t:1527876720886};\\\", \\\"{x:412,y:484,t:1527876720902};\\\", \\\"{x:430,y:494,t:1527876720919};\\\", \\\"{x:487,y:520,t:1527876720936};\\\", \\\"{x:591,y:546,t:1527876720953};\\\", \\\"{x:731,y:572,t:1527876720969};\\\", \\\"{x:872,y:591,t:1527876720986};\\\", \\\"{x:1020,y:602,t:1527876721003};\\\", \\\"{x:1164,y:606,t:1527876721020};\\\", \\\"{x:1307,y:621,t:1527876721037};\\\", \\\"{x:1405,y:623,t:1527876721052};\\\", \\\"{x:1435,y:623,t:1527876721070};\\\", \\\"{x:1439,y:623,t:1527876721086};\\\", \\\"{x:1437,y:622,t:1527876721151};\\\", \\\"{x:1437,y:621,t:1527876721158};\\\", \\\"{x:1435,y:620,t:1527876721169};\\\", \\\"{x:1438,y:613,t:1527876721187};\\\", \\\"{x:1450,y:598,t:1527876721204};\\\", \\\"{x:1453,y:580,t:1527876721220};\\\", \\\"{x:1455,y:562,t:1527876721237};\\\", \\\"{x:1455,y:555,t:1527876721254};\\\", \\\"{x:1447,y:550,t:1527876721270};\\\", \\\"{x:1431,y:550,t:1527876721287};\\\", \\\"{x:1410,y:550,t:1527876721304};\\\", \\\"{x:1388,y:553,t:1527876721322};\\\", \\\"{x:1363,y:558,t:1527876721337};\\\", \\\"{x:1336,y:559,t:1527876721353};\\\", \\\"{x:1311,y:561,t:1527876721371};\\\", \\\"{x:1303,y:561,t:1527876721388};\\\", \\\"{x:1298,y:563,t:1527876721404};\\\", \\\"{x:1297,y:563,t:1527876721455};\\\", \\\"{x:1296,y:563,t:1527876721471};\\\", \\\"{x:1295,y:563,t:1527876721488};\\\", \\\"{x:1293,y:565,t:1527876721505};\\\", \\\"{x:1292,y:565,t:1527876721551};\\\", \\\"{x:1289,y:565,t:1527876721567};\\\", \\\"{x:1288,y:565,t:1527876721575};\\\", \\\"{x:1285,y:565,t:1527876721591};\\\", \\\"{x:1281,y:565,t:1527876721604};\\\", \\\"{x:1277,y:565,t:1527876721621};\\\", \\\"{x:1274,y:565,t:1527876721638};\\\", \\\"{x:1272,y:565,t:1527876721654};\\\", \\\"{x:1271,y:565,t:1527876721710};\\\", \\\"{x:1270,y:564,t:1527876721831};\\\", \\\"{x:1267,y:564,t:1527876721839};\\\", \\\"{x:1245,y:556,t:1527876721856};\\\", \\\"{x:1194,y:548,t:1527876721872};\\\", \\\"{x:1095,y:536,t:1527876721888};\\\", \\\"{x:994,y:519,t:1527876721906};\\\", \\\"{x:867,y:506,t:1527876721923};\\\", \\\"{x:731,y:485,t:1527876721939};\\\", \\\"{x:618,y:471,t:1527876721952};\\\", \\\"{x:512,y:455,t:1527876721969};\\\", \\\"{x:440,y:444,t:1527876721986};\\\", \\\"{x:398,y:439,t:1527876722002};\\\", \\\"{x:371,y:434,t:1527876722019};\\\", \\\"{x:356,y:433,t:1527876722036};\\\", \\\"{x:347,y:432,t:1527876722053};\\\", \\\"{x:336,y:432,t:1527876722069};\\\", \\\"{x:329,y:432,t:1527876722086};\\\", \\\"{x:315,y:432,t:1527876722102};\\\", \\\"{x:308,y:432,t:1527876722120};\\\", \\\"{x:304,y:432,t:1527876722136};\\\", \\\"{x:304,y:433,t:1527876722223};\\\", \\\"{x:305,y:434,t:1527876722236};\\\", \\\"{x:306,y:439,t:1527876722253};\\\", \\\"{x:308,y:441,t:1527876722270};\\\", \\\"{x:309,y:442,t:1527876722286};\\\", \\\"{x:315,y:445,t:1527876722303};\\\", \\\"{x:325,y:448,t:1527876722320};\\\", \\\"{x:337,y:450,t:1527876722336};\\\", \\\"{x:342,y:450,t:1527876722353};\\\", \\\"{x:347,y:451,t:1527876722369};\\\", \\\"{x:349,y:451,t:1527876722386};\\\", \\\"{x:351,y:452,t:1527876722403};\\\", \\\"{x:353,y:452,t:1527876722519};\\\", \\\"{x:354,y:452,t:1527876722536};\\\", \\\"{x:356,y:453,t:1527876722553};\\\", \\\"{x:357,y:453,t:1527876722574};\\\", \\\"{x:358,y:453,t:1527876722591};\\\", \\\"{x:359,y:453,t:1527876722603};\\\", \\\"{x:362,y:454,t:1527876722619};\\\", \\\"{x:364,y:454,t:1527876722636};\\\", \\\"{x:366,y:454,t:1527876722653};\\\", \\\"{x:367,y:454,t:1527876722704};\\\", \\\"{x:368,y:454,t:1527876722887};\\\", \\\"{x:371,y:454,t:1527876722902};\\\", \\\"{x:372,y:454,t:1527876722919};\\\", \\\"{x:374,y:454,t:1527876722936};\\\", \\\"{x:375,y:454,t:1527876722958};\\\", \\\"{x:377,y:454,t:1527876723055};\\\", \\\"{x:382,y:454,t:1527876723487};\\\", \\\"{x:385,y:454,t:1527876723502};\\\", \\\"{x:395,y:454,t:1527876723519};\\\", \\\"{x:399,y:454,t:1527876723536};\\\", \\\"{x:400,y:454,t:1527876723552};\\\", \\\"{x:401,y:454,t:1527876723569};\\\", \\\"{x:402,y:454,t:1527876723599};\\\", \\\"{x:403,y:454,t:1527876723640};\\\", \\\"{x:405,y:454,t:1527876723670};\\\", \\\"{x:406,y:454,t:1527876723751};\\\", \\\"{x:408,y:454,t:1527876723769};\\\", \\\"{x:411,y:454,t:1527876723786};\\\", \\\"{x:417,y:454,t:1527876723802};\\\", \\\"{x:421,y:454,t:1527876723819};\\\", \\\"{x:422,y:454,t:1527876723836};\\\", \\\"{x:425,y:454,t:1527876723853};\\\", \\\"{x:426,y:454,t:1527876723879};\\\", \\\"{x:427,y:454,t:1527876723902};\\\", \\\"{x:428,y:454,t:1527876723919};\\\", \\\"{x:431,y:454,t:1527876723935};\\\", \\\"{x:440,y:454,t:1527876723952};\\\", \\\"{x:444,y:454,t:1527876723969};\\\", \\\"{x:450,y:454,t:1527876723986};\\\", \\\"{x:459,y:454,t:1527876724002};\\\", \\\"{x:466,y:454,t:1527876724019};\\\", \\\"{x:468,y:454,t:1527876724036};\\\", \\\"{x:469,y:454,t:1527876724071};\\\", \\\"{x:470,y:454,t:1527876724375};\\\", \\\"{x:471,y:454,t:1527876724399};\\\", \\\"{x:473,y:454,t:1527876724414};\\\", \\\"{x:474,y:454,t:1527876724422};\\\", \\\"{x:476,y:454,t:1527876724436};\\\", \\\"{x:485,y:455,t:1527876724453};\\\", \\\"{x:492,y:455,t:1527876724469};\\\", \\\"{x:501,y:455,t:1527876724485};\\\", \\\"{x:506,y:456,t:1527876724502};\\\", \\\"{x:507,y:456,t:1527876724519};\\\", \\\"{x:509,y:456,t:1527876725679};\\\", \\\"{x:510,y:456,t:1527876725687};\\\", \\\"{x:512,y:456,t:1527876725702};\\\", \\\"{x:516,y:456,t:1527876725718};\\\", \\\"{x:523,y:456,t:1527876725735};\\\", \\\"{x:529,y:456,t:1527876725752};\\\", \\\"{x:534,y:456,t:1527876725768};\\\", \\\"{x:539,y:456,t:1527876725785};\\\", \\\"{x:540,y:456,t:1527876725951};\\\", \\\"{x:540,y:454,t:1527876727631};\\\", \\\"{x:541,y:454,t:1527876727639};\\\", \\\"{x:542,y:453,t:1527876727652};\\\", \\\"{x:543,y:452,t:1527876727668};\\\", \\\"{x:543,y:451,t:1527876727686};\\\", \\\"{x:545,y:450,t:1527876727701};\\\", \\\"{x:546,y:449,t:1527876727718};\\\", \\\"{x:547,y:449,t:1527876727733};\\\", \\\"{x:548,y:449,t:1527876727750};\\\", \\\"{x:549,y:448,t:1527876727768};\\\", \\\"{x:550,y:448,t:1527876727784};\\\", \\\"{x:551,y:448,t:1527876727806};\\\", \\\"{x:552,y:448,t:1527876727830};\\\", \\\"{x:554,y:448,t:1527876727838};\\\", \\\"{x:556,y:448,t:1527876727862};\\\", \\\"{x:558,y:448,t:1527876727870};\\\", \\\"{x:562,y:449,t:1527876727884};\\\", \\\"{x:568,y:452,t:1527876727900};\\\", \\\"{x:584,y:458,t:1527876727918};\\\", \\\"{x:592,y:463,t:1527876727934};\\\", \\\"{x:598,y:465,t:1527876727951};\\\", \\\"{x:600,y:465,t:1527876727968};\\\", \\\"{x:602,y:465,t:1527876727984};\\\", \\\"{x:602,y:466,t:1527876728015};\\\", \\\"{x:602,y:468,t:1527876728030};\\\", \\\"{x:597,y:470,t:1527876728039};\\\", \\\"{x:591,y:471,t:1527876728051};\\\", \\\"{x:576,y:472,t:1527876728068};\\\", \\\"{x:562,y:472,t:1527876728084};\\\", \\\"{x:545,y:472,t:1527876728101};\\\", \\\"{x:526,y:472,t:1527876728118};\\\", \\\"{x:518,y:472,t:1527876728135};\\\", \\\"{x:511,y:472,t:1527876728152};\\\", \\\"{x:505,y:471,t:1527876728168};\\\", \\\"{x:499,y:470,t:1527876728184};\\\", \\\"{x:495,y:470,t:1527876728202};\\\", \\\"{x:488,y:469,t:1527876728218};\\\", \\\"{x:482,y:469,t:1527876728234};\\\", \\\"{x:476,y:469,t:1527876728251};\\\", \\\"{x:471,y:468,t:1527876728268};\\\", \\\"{x:465,y:463,t:1527876728284};\\\", \\\"{x:457,y:463,t:1527876728301};\\\", \\\"{x:448,y:461,t:1527876728317};\\\", \\\"{x:445,y:461,t:1527876728334};\\\", \\\"{x:445,y:460,t:1527876728350};\\\", \\\"{x:444,y:459,t:1527876728414};\\\", \\\"{x:444,y:457,t:1527876728438};\\\", \\\"{x:444,y:456,t:1527876728454};\\\", \\\"{x:444,y:455,t:1527876728470};\\\", \\\"{x:444,y:454,t:1527876728484};\\\", \\\"{x:444,y:452,t:1527876728510};\\\", \\\"{x:446,y:452,t:1527876728526};\\\", \\\"{x:449,y:452,t:1527876728534};\\\", \\\"{x:466,y:450,t:1527876728551};\\\", \\\"{x:496,y:450,t:1527876728568};\\\", \\\"{x:530,y:450,t:1527876728584};\\\", \\\"{x:569,y:453,t:1527876728601};\\\", \\\"{x:632,y:459,t:1527876728618};\\\", \\\"{x:705,y:470,t:1527876728634};\\\", \\\"{x:752,y:476,t:1527876728652};\\\", \\\"{x:800,y:484,t:1527876728668};\\\", \\\"{x:840,y:490,t:1527876728684};\\\", \\\"{x:869,y:495,t:1527876728700};\\\", \\\"{x:916,y:508,t:1527876728717};\\\", \\\"{x:969,y:523,t:1527876728742};\\\", \\\"{x:992,y:533,t:1527876728759};\\\", \\\"{x:1013,y:538,t:1527876728776};\\\", \\\"{x:1029,y:546,t:1527876728792};\\\", \\\"{x:1046,y:552,t:1527876728809};\\\", \\\"{x:1069,y:561,t:1527876728826};\\\", \\\"{x:1089,y:573,t:1527876728842};\\\", \\\"{x:1108,y:584,t:1527876728858};\\\", \\\"{x:1119,y:593,t:1527876728876};\\\", \\\"{x:1133,y:602,t:1527876728892};\\\", \\\"{x:1148,y:614,t:1527876728908};\\\", \\\"{x:1171,y:630,t:1527876728926};\\\", \\\"{x:1187,y:641,t:1527876728943};\\\", \\\"{x:1199,y:649,t:1527876728959};\\\", \\\"{x:1208,y:656,t:1527876728975};\\\", \\\"{x:1211,y:660,t:1527876728993};\\\", \\\"{x:1214,y:666,t:1527876729008};\\\", \\\"{x:1215,y:671,t:1527876729026};\\\", \\\"{x:1216,y:674,t:1527876729043};\\\", \\\"{x:1216,y:676,t:1527876729059};\\\", \\\"{x:1216,y:677,t:1527876729076};\\\", \\\"{x:1216,y:679,t:1527876729093};\\\", \\\"{x:1214,y:686,t:1527876729109};\\\", \\\"{x:1211,y:700,t:1527876729127};\\\", \\\"{x:1209,y:708,t:1527876729143};\\\", \\\"{x:1210,y:708,t:1527876729183};\\\", \\\"{x:1213,y:708,t:1527876729193};\\\", \\\"{x:1231,y:706,t:1527876729209};\\\", \\\"{x:1253,y:701,t:1527876729226};\\\", \\\"{x:1282,y:699,t:1527876729243};\\\", \\\"{x:1308,y:697,t:1527876729259};\\\", \\\"{x:1328,y:697,t:1527876729277};\\\", \\\"{x:1337,y:697,t:1527876729294};\\\", \\\"{x:1337,y:696,t:1527876729398};\\\", \\\"{x:1338,y:696,t:1527876729638};\\\", \\\"{x:1340,y:696,t:1527876729646};\\\", \\\"{x:1342,y:696,t:1527876729662};\\\", \\\"{x:1344,y:696,t:1527876729693};\\\", \\\"{x:1345,y:696,t:1527876729710};\\\", \\\"{x:1346,y:697,t:1527876729799};\\\", \\\"{x:1346,y:698,t:1527876729815};\\\", \\\"{x:1346,y:699,t:1527876729826};\\\", \\\"{x:1346,y:702,t:1527876729843};\\\", \\\"{x:1344,y:708,t:1527876729861};\\\", \\\"{x:1342,y:711,t:1527876729877};\\\", \\\"{x:1341,y:716,t:1527876729892};\\\", \\\"{x:1340,y:722,t:1527876729910};\\\", \\\"{x:1338,y:730,t:1527876729927};\\\", \\\"{x:1338,y:737,t:1527876729943};\\\", \\\"{x:1338,y:746,t:1527876729960};\\\", \\\"{x:1337,y:756,t:1527876729977};\\\", \\\"{x:1335,y:759,t:1527876729993};\\\", \\\"{x:1333,y:766,t:1527876730010};\\\", \\\"{x:1331,y:772,t:1527876730028};\\\", \\\"{x:1329,y:781,t:1527876730043};\\\", \\\"{x:1327,y:789,t:1527876730061};\\\", \\\"{x:1325,y:796,t:1527876730078};\\\", \\\"{x:1323,y:805,t:1527876730093};\\\", \\\"{x:1313,y:820,t:1527876730111};\\\", \\\"{x:1308,y:827,t:1527876730127};\\\", \\\"{x:1304,y:831,t:1527876730144};\\\", \\\"{x:1301,y:836,t:1527876730161};\\\", \\\"{x:1297,y:840,t:1527876730177};\\\", \\\"{x:1294,y:844,t:1527876730193};\\\", \\\"{x:1291,y:849,t:1527876730211};\\\", \\\"{x:1286,y:854,t:1527876730228};\\\", \\\"{x:1284,y:857,t:1527876730244};\\\", \\\"{x:1280,y:862,t:1527876730261};\\\", \\\"{x:1277,y:865,t:1527876730277};\\\", \\\"{x:1274,y:870,t:1527876730294};\\\", \\\"{x:1272,y:872,t:1527876730311};\\\", \\\"{x:1270,y:875,t:1527876730327};\\\", \\\"{x:1267,y:878,t:1527876730344};\\\", \\\"{x:1263,y:882,t:1527876730360};\\\", \\\"{x:1259,y:889,t:1527876730377};\\\", \\\"{x:1254,y:896,t:1527876730394};\\\", \\\"{x:1246,y:903,t:1527876730411};\\\", \\\"{x:1241,y:909,t:1527876730427};\\\", \\\"{x:1238,y:914,t:1527876730445};\\\", \\\"{x:1234,y:919,t:1527876730461};\\\", \\\"{x:1232,y:924,t:1527876730478};\\\", \\\"{x:1229,y:930,t:1527876730495};\\\", \\\"{x:1224,y:936,t:1527876730511};\\\", \\\"{x:1219,y:941,t:1527876730527};\\\", \\\"{x:1215,y:945,t:1527876730544};\\\", \\\"{x:1211,y:949,t:1527876730561};\\\", \\\"{x:1207,y:952,t:1527876730577};\\\", \\\"{x:1206,y:954,t:1527876730593};\\\", \\\"{x:1205,y:956,t:1527876730611};\\\", \\\"{x:1204,y:957,t:1527876730630};\\\", \\\"{x:1204,y:958,t:1527876730645};\\\", \\\"{x:1203,y:959,t:1527876730662};\\\", \\\"{x:1202,y:959,t:1527876730678};\\\", \\\"{x:1202,y:961,t:1527876730701};\\\", \\\"{x:1203,y:961,t:1527876730830};\\\", \\\"{x:1207,y:961,t:1527876730844};\\\", \\\"{x:1218,y:960,t:1527876730860};\\\", \\\"{x:1237,y:956,t:1527876730877};\\\", \\\"{x:1267,y:956,t:1527876730894};\\\", \\\"{x:1279,y:956,t:1527876730911};\\\", \\\"{x:1283,y:956,t:1527876730927};\\\", \\\"{x:1284,y:956,t:1527876730944};\\\", \\\"{x:1285,y:958,t:1527876730962};\\\", \\\"{x:1285,y:961,t:1527876730977};\\\", \\\"{x:1285,y:965,t:1527876730994};\\\", \\\"{x:1285,y:966,t:1527876731011};\\\", \\\"{x:1285,y:967,t:1527876731026};\\\", \\\"{x:1285,y:968,t:1527876731044};\\\", \\\"{x:1286,y:970,t:1527876731061};\\\", \\\"{x:1287,y:971,t:1527876731077};\\\", \\\"{x:1287,y:973,t:1527876731094};\\\", \\\"{x:1288,y:970,t:1527876731190};\\\", \\\"{x:1290,y:967,t:1527876731199};\\\", \\\"{x:1292,y:963,t:1527876731212};\\\", \\\"{x:1300,y:957,t:1527876731229};\\\", \\\"{x:1311,y:950,t:1527876731244};\\\", \\\"{x:1321,y:944,t:1527876731262};\\\", \\\"{x:1328,y:943,t:1527876731278};\\\", \\\"{x:1332,y:941,t:1527876731294};\\\", \\\"{x:1334,y:941,t:1527876731311};\\\", \\\"{x:1335,y:941,t:1527876731342};\\\", \\\"{x:1337,y:942,t:1527876731358};\\\", \\\"{x:1340,y:944,t:1527876731367};\\\", \\\"{x:1342,y:946,t:1527876731378};\\\", \\\"{x:1347,y:950,t:1527876731394};\\\", \\\"{x:1353,y:957,t:1527876731411};\\\", \\\"{x:1355,y:959,t:1527876731428};\\\", \\\"{x:1356,y:963,t:1527876731445};\\\", \\\"{x:1357,y:965,t:1527876731462};\\\", \\\"{x:1358,y:968,t:1527876731478};\\\", \\\"{x:1359,y:970,t:1527876731495};\\\", \\\"{x:1359,y:971,t:1527876731511};\\\", \\\"{x:1360,y:972,t:1527876731528};\\\", \\\"{x:1361,y:973,t:1527876731544};\\\", \\\"{x:1361,y:974,t:1527876731583};\\\", \\\"{x:1362,y:973,t:1527876731679};\\\", \\\"{x:1365,y:969,t:1527876731695};\\\", \\\"{x:1368,y:965,t:1527876731712};\\\", \\\"{x:1372,y:962,t:1527876731728};\\\", \\\"{x:1379,y:959,t:1527876731746};\\\", \\\"{x:1397,y:956,t:1527876731761};\\\", \\\"{x:1411,y:956,t:1527876731778};\\\", \\\"{x:1422,y:956,t:1527876731796};\\\", \\\"{x:1429,y:956,t:1527876731812};\\\", \\\"{x:1433,y:956,t:1527876731829};\\\", \\\"{x:1434,y:957,t:1527876731845};\\\", \\\"{x:1435,y:960,t:1527876731861};\\\", \\\"{x:1436,y:961,t:1527876731878};\\\", \\\"{x:1437,y:961,t:1527876731936};\\\", \\\"{x:1440,y:959,t:1527876731959};\\\", \\\"{x:1448,y:957,t:1527876731967};\\\", \\\"{x:1454,y:955,t:1527876731978};\\\", \\\"{x:1471,y:954,t:1527876731996};\\\", \\\"{x:1491,y:954,t:1527876732012};\\\", \\\"{x:1504,y:954,t:1527876732028};\\\", \\\"{x:1509,y:953,t:1527876732045};\\\", \\\"{x:1509,y:948,t:1527876732061};\\\", \\\"{x:1496,y:907,t:1527876732078};\\\", \\\"{x:1462,y:857,t:1527876732095};\\\", \\\"{x:1435,y:809,t:1527876732111};\\\", \\\"{x:1398,y:751,t:1527876732128};\\\", \\\"{x:1370,y:709,t:1527876732145};\\\", \\\"{x:1356,y:684,t:1527876732163};\\\", \\\"{x:1346,y:671,t:1527876732179};\\\", \\\"{x:1340,y:665,t:1527876732196};\\\", \\\"{x:1338,y:665,t:1527876732213};\\\", \\\"{x:1337,y:666,t:1527876732255};\\\", \\\"{x:1337,y:672,t:1527876732262};\\\", \\\"{x:1339,y:687,t:1527876732278};\\\", \\\"{x:1345,y:703,t:1527876732295};\\\", \\\"{x:1354,y:718,t:1527876732312};\\\", \\\"{x:1362,y:729,t:1527876732328};\\\", \\\"{x:1367,y:733,t:1527876732344};\\\", \\\"{x:1370,y:735,t:1527876732362};\\\", \\\"{x:1370,y:736,t:1527876732378};\\\", \\\"{x:1372,y:736,t:1527876732471};\\\", \\\"{x:1373,y:735,t:1527876732479};\\\", \\\"{x:1374,y:734,t:1527876732495};\\\", \\\"{x:1374,y:730,t:1527876732512};\\\", \\\"{x:1374,y:727,t:1527876732528};\\\", \\\"{x:1374,y:724,t:1527876732545};\\\", \\\"{x:1374,y:721,t:1527876732562};\\\", \\\"{x:1374,y:719,t:1527876732579};\\\", \\\"{x:1374,y:718,t:1527876732595};\\\", \\\"{x:1373,y:717,t:1527876732613};\\\", \\\"{x:1369,y:715,t:1527876732629};\\\", \\\"{x:1365,y:713,t:1527876732646};\\\", \\\"{x:1364,y:712,t:1527876732663};\\\", \\\"{x:1363,y:712,t:1527876732720};\\\", \\\"{x:1362,y:712,t:1527876732742};\\\", \\\"{x:1361,y:711,t:1527876732951};\\\", \\\"{x:1360,y:711,t:1527876732967};\\\", \\\"{x:1360,y:709,t:1527876733047};\\\", \\\"{x:1359,y:708,t:1527876733183};\\\", \\\"{x:1358,y:708,t:1527876733196};\\\", \\\"{x:1356,y:706,t:1527876733212};\\\", \\\"{x:1353,y:704,t:1527876733229};\\\", \\\"{x:1352,y:704,t:1527876733246};\\\", \\\"{x:1351,y:704,t:1527876733263};\\\", \\\"{x:1350,y:704,t:1527876733287};\\\", \\\"{x:1349,y:704,t:1527876733297};\\\", \\\"{x:1348,y:704,t:1527876733313};\\\", \\\"{x:1348,y:703,t:1527876733330};\\\", \\\"{x:1346,y:702,t:1527876733347};\\\", \\\"{x:1346,y:701,t:1527876733415};\\\", \\\"{x:1346,y:700,t:1527876736782};\\\", \\\"{x:1348,y:698,t:1527876736797};\\\", \\\"{x:1348,y:700,t:1527876737159};\\\", \\\"{x:1348,y:701,t:1527876737166};\\\", \\\"{x:1351,y:706,t:1527876737184};\\\", \\\"{x:1358,y:712,t:1527876737199};\\\", \\\"{x:1361,y:712,t:1527876737215};\\\", \\\"{x:1362,y:712,t:1527876738015};\\\", \\\"{x:1363,y:712,t:1527876739567};\\\", \\\"{x:1364,y:713,t:1527876739584};\\\", \\\"{x:1364,y:714,t:1527876739600};\\\", \\\"{x:1365,y:714,t:1527876739618};\\\", \\\"{x:1367,y:715,t:1527876739633};\\\", \\\"{x:1370,y:716,t:1527876739651};\\\", \\\"{x:1377,y:718,t:1527876739668};\\\", \\\"{x:1395,y:723,t:1527876739685};\\\", \\\"{x:1420,y:729,t:1527876739701};\\\", \\\"{x:1449,y:736,t:1527876739718};\\\", \\\"{x:1503,y:751,t:1527876739735};\\\", \\\"{x:1528,y:756,t:1527876739750};\\\", \\\"{x:1546,y:759,t:1527876739768};\\\", \\\"{x:1548,y:760,t:1527876739785};\\\", \\\"{x:1548,y:762,t:1527876739951};\\\", \\\"{x:1543,y:762,t:1527876739968};\\\", \\\"{x:1539,y:763,t:1527876739985};\\\", \\\"{x:1533,y:764,t:1527876740001};\\\", \\\"{x:1527,y:765,t:1527876740018};\\\", \\\"{x:1521,y:767,t:1527876740035};\\\", \\\"{x:1519,y:768,t:1527876740051};\\\", \\\"{x:1518,y:768,t:1527876740068};\\\", \\\"{x:1517,y:768,t:1527876740087};\\\", \\\"{x:1516,y:768,t:1527876740118};\\\", \\\"{x:1515,y:769,t:1527876740136};\\\", \\\"{x:1514,y:770,t:1527876740151};\\\", \\\"{x:1513,y:770,t:1527876740207};\\\", \\\"{x:1511,y:773,t:1527876740647};\\\", \\\"{x:1509,y:775,t:1527876740655};\\\", \\\"{x:1507,y:777,t:1527876740669};\\\", \\\"{x:1503,y:781,t:1527876740686};\\\", \\\"{x:1500,y:786,t:1527876740702};\\\", \\\"{x:1497,y:788,t:1527876740719};\\\", \\\"{x:1495,y:790,t:1527876740735};\\\", \\\"{x:1494,y:792,t:1527876740752};\\\", \\\"{x:1493,y:793,t:1527876740769};\\\", \\\"{x:1492,y:794,t:1527876740785};\\\", \\\"{x:1492,y:796,t:1527876740801};\\\", \\\"{x:1492,y:797,t:1527876740823};\\\", \\\"{x:1491,y:798,t:1527876740835};\\\", \\\"{x:1490,y:798,t:1527876740853};\\\", \\\"{x:1489,y:801,t:1527876740869};\\\", \\\"{x:1488,y:804,t:1527876740885};\\\", \\\"{x:1486,y:809,t:1527876740902};\\\", \\\"{x:1483,y:813,t:1527876740918};\\\", \\\"{x:1481,y:816,t:1527876740934};\\\", \\\"{x:1480,y:819,t:1527876740951};\\\", \\\"{x:1479,y:822,t:1527876740968};\\\", \\\"{x:1478,y:823,t:1527876740984};\\\", \\\"{x:1477,y:826,t:1527876741001};\\\", \\\"{x:1477,y:828,t:1527876741018};\\\", \\\"{x:1476,y:831,t:1527876741034};\\\", \\\"{x:1475,y:833,t:1527876741052};\\\", \\\"{x:1475,y:836,t:1527876741068};\\\", \\\"{x:1475,y:837,t:1527876741086};\\\", \\\"{x:1475,y:838,t:1527876741101};\\\", \\\"{x:1475,y:839,t:1527876741118};\\\", \\\"{x:1475,y:837,t:1527876741223};\\\", \\\"{x:1477,y:834,t:1527876741236};\\\", \\\"{x:1482,y:825,t:1527876741253};\\\", \\\"{x:1491,y:814,t:1527876741270};\\\", \\\"{x:1497,y:805,t:1527876741286};\\\", \\\"{x:1502,y:798,t:1527876741302};\\\", \\\"{x:1505,y:794,t:1527876741319};\\\", \\\"{x:1507,y:791,t:1527876741336};\\\", \\\"{x:1511,y:784,t:1527876741351};\\\", \\\"{x:1512,y:781,t:1527876741369};\\\", \\\"{x:1514,y:776,t:1527876741386};\\\", \\\"{x:1516,y:774,t:1527876741402};\\\", \\\"{x:1516,y:771,t:1527876741419};\\\", \\\"{x:1517,y:769,t:1527876741436};\\\", \\\"{x:1517,y:768,t:1527876741453};\\\", \\\"{x:1517,y:766,t:1527876741469};\\\", \\\"{x:1519,y:765,t:1527876741486};\\\", \\\"{x:1519,y:764,t:1527876741502};\\\", \\\"{x:1519,y:763,t:1527876741526};\\\", \\\"{x:1520,y:762,t:1527876741536};\\\", \\\"{x:1520,y:761,t:1527876741592};\\\", \\\"{x:1520,y:760,t:1527876741630};\\\", \\\"{x:1520,y:759,t:1527876741677};\\\", \\\"{x:1520,y:761,t:1527876741837};\\\", \\\"{x:1520,y:762,t:1527876741852};\\\", \\\"{x:1520,y:765,t:1527876741869};\\\", \\\"{x:1520,y:769,t:1527876741886};\\\", \\\"{x:1519,y:770,t:1527876741902};\\\", \\\"{x:1518,y:772,t:1527876741942};\\\", \\\"{x:1518,y:774,t:1527876741966};\\\", \\\"{x:1516,y:775,t:1527876741974};\\\", \\\"{x:1515,y:777,t:1527876741986};\\\", \\\"{x:1514,y:780,t:1527876742003};\\\", \\\"{x:1513,y:780,t:1527876742019};\\\", \\\"{x:1513,y:781,t:1527876742036};\\\", \\\"{x:1512,y:782,t:1527876742087};\\\", \\\"{x:1511,y:783,t:1527876742103};\\\", \\\"{x:1511,y:786,t:1527876742120};\\\", \\\"{x:1507,y:792,t:1527876742136};\\\", \\\"{x:1504,y:798,t:1527876742153};\\\", \\\"{x:1500,y:809,t:1527876742170};\\\", \\\"{x:1498,y:817,t:1527876742186};\\\", \\\"{x:1495,y:824,t:1527876742203};\\\", \\\"{x:1494,y:826,t:1527876742220};\\\", \\\"{x:1494,y:828,t:1527876742236};\\\", \\\"{x:1492,y:833,t:1527876742253};\\\", \\\"{x:1492,y:836,t:1527876742270};\\\", \\\"{x:1491,y:839,t:1527876742286};\\\", \\\"{x:1489,y:846,t:1527876742303};\\\", \\\"{x:1486,y:851,t:1527876742321};\\\", \\\"{x:1485,y:853,t:1527876742335};\\\", \\\"{x:1484,y:854,t:1527876742358};\\\", \\\"{x:1484,y:852,t:1527876742455};\\\", \\\"{x:1484,y:849,t:1527876742470};\\\", \\\"{x:1486,y:837,t:1527876742486};\\\", \\\"{x:1497,y:818,t:1527876742503};\\\", \\\"{x:1503,y:808,t:1527876742520};\\\", \\\"{x:1505,y:804,t:1527876742537};\\\", \\\"{x:1507,y:799,t:1527876742553};\\\", \\\"{x:1507,y:798,t:1527876742570};\\\", \\\"{x:1509,y:795,t:1527876742587};\\\", \\\"{x:1510,y:794,t:1527876742603};\\\", \\\"{x:1511,y:792,t:1527876742620};\\\", \\\"{x:1513,y:789,t:1527876742637};\\\", \\\"{x:1514,y:784,t:1527876742653};\\\", \\\"{x:1517,y:777,t:1527876742670};\\\", \\\"{x:1518,y:773,t:1527876742687};\\\", \\\"{x:1520,y:767,t:1527876742703};\\\", \\\"{x:1521,y:765,t:1527876742720};\\\", \\\"{x:1521,y:763,t:1527876742737};\\\", \\\"{x:1521,y:762,t:1527876742753};\\\", \\\"{x:1521,y:761,t:1527876742770};\\\", \\\"{x:1522,y:760,t:1527876742798};\\\", \\\"{x:1522,y:762,t:1527876742999};\\\", \\\"{x:1521,y:763,t:1527876743007};\\\", \\\"{x:1520,y:764,t:1527876743020};\\\", \\\"{x:1518,y:767,t:1527876743036};\\\", \\\"{x:1514,y:771,t:1527876743055};\\\", \\\"{x:1511,y:778,t:1527876743069};\\\", \\\"{x:1508,y:784,t:1527876743086};\\\", \\\"{x:1506,y:789,t:1527876743103};\\\", \\\"{x:1501,y:796,t:1527876743119};\\\", \\\"{x:1499,y:799,t:1527876743136};\\\", \\\"{x:1499,y:801,t:1527876743153};\\\", \\\"{x:1498,y:802,t:1527876743169};\\\", \\\"{x:1497,y:804,t:1527876743186};\\\", \\\"{x:1495,y:807,t:1527876743203};\\\", \\\"{x:1493,y:808,t:1527876743220};\\\", \\\"{x:1493,y:809,t:1527876743236};\\\", \\\"{x:1493,y:811,t:1527876743253};\\\", \\\"{x:1492,y:813,t:1527876743270};\\\", \\\"{x:1491,y:814,t:1527876743286};\\\", \\\"{x:1490,y:816,t:1527876743310};\\\", \\\"{x:1490,y:817,t:1527876743326};\\\", \\\"{x:1489,y:818,t:1527876743342};\\\", \\\"{x:1488,y:819,t:1527876743354};\\\", \\\"{x:1486,y:822,t:1527876743370};\\\", \\\"{x:1485,y:825,t:1527876743387};\\\", \\\"{x:1483,y:826,t:1527876743404};\\\", \\\"{x:1483,y:827,t:1527876743420};\\\", \\\"{x:1482,y:828,t:1527876743437};\\\", \\\"{x:1480,y:831,t:1527876743454};\\\", \\\"{x:1478,y:833,t:1527876743470};\\\", \\\"{x:1473,y:836,t:1527876743487};\\\", \\\"{x:1455,y:844,t:1527876743504};\\\", \\\"{x:1434,y:850,t:1527876743520};\\\", \\\"{x:1402,y:855,t:1527876743536};\\\", \\\"{x:1364,y:856,t:1527876743553};\\\", \\\"{x:1327,y:856,t:1527876743570};\\\", \\\"{x:1281,y:857,t:1527876743586};\\\", \\\"{x:1219,y:853,t:1527876743603};\\\", \\\"{x:1146,y:843,t:1527876743620};\\\", \\\"{x:1088,y:830,t:1527876743636};\\\", \\\"{x:1019,y:808,t:1527876743654};\\\", \\\"{x:919,y:780,t:1527876743670};\\\", \\\"{x:865,y:764,t:1527876743687};\\\", \\\"{x:821,y:752,t:1527876743704};\\\", \\\"{x:791,y:743,t:1527876743721};\\\", \\\"{x:771,y:738,t:1527876743737};\\\", \\\"{x:760,y:734,t:1527876743753};\\\", \\\"{x:754,y:730,t:1527876743771};\\\", \\\"{x:747,y:729,t:1527876743787};\\\", \\\"{x:742,y:726,t:1527876743803};\\\", \\\"{x:734,y:725,t:1527876743821};\\\", \\\"{x:718,y:722,t:1527876743836};\\\", \\\"{x:677,y:713,t:1527876743854};\\\", \\\"{x:640,y:703,t:1527876743870};\\\", \\\"{x:590,y:688,t:1527876743886};\\\", \\\"{x:557,y:680,t:1527876743904};\\\", \\\"{x:508,y:659,t:1527876743921};\\\", \\\"{x:477,y:646,t:1527876743938};\\\", \\\"{x:452,y:634,t:1527876743954};\\\", \\\"{x:432,y:622,t:1527876743971};\\\", \\\"{x:414,y:613,t:1527876743988};\\\", \\\"{x:403,y:607,t:1527876744004};\\\", \\\"{x:397,y:603,t:1527876744021};\\\", \\\"{x:394,y:600,t:1527876744037};\\\", \\\"{x:394,y:598,t:1527876744054};\\\", \\\"{x:391,y:594,t:1527876744072};\\\", \\\"{x:389,y:588,t:1527876744087};\\\", \\\"{x:388,y:587,t:1527876744104};\\\", \\\"{x:384,y:583,t:1527876744121};\\\", \\\"{x:377,y:579,t:1527876744137};\\\", \\\"{x:374,y:577,t:1527876744154};\\\", \\\"{x:372,y:576,t:1527876744172};\\\", \\\"{x:368,y:571,t:1527876744188};\\\", \\\"{x:365,y:568,t:1527876744205};\\\", \\\"{x:364,y:567,t:1527876744221};\\\", \\\"{x:364,y:566,t:1527876744239};\\\", \\\"{x:364,y:562,t:1527876744255};\\\", \\\"{x:364,y:555,t:1527876744272};\\\", \\\"{x:364,y:548,t:1527876744289};\\\", \\\"{x:364,y:545,t:1527876744305};\\\", \\\"{x:364,y:542,t:1527876744321};\\\", \\\"{x:364,y:539,t:1527876744338};\\\", \\\"{x:364,y:537,t:1527876744354};\\\", \\\"{x:365,y:536,t:1527876744372};\\\", \\\"{x:365,y:535,t:1527876744389};\\\", \\\"{x:364,y:535,t:1527876744406};\\\", \\\"{x:358,y:536,t:1527876744421};\\\", \\\"{x:327,y:547,t:1527876744438};\\\", \\\"{x:298,y:559,t:1527876744455};\\\", \\\"{x:259,y:569,t:1527876744472};\\\", \\\"{x:233,y:572,t:1527876744488};\\\", \\\"{x:215,y:576,t:1527876744505};\\\", \\\"{x:197,y:578,t:1527876744521};\\\", \\\"{x:191,y:578,t:1527876744538};\\\", \\\"{x:189,y:578,t:1527876744555};\\\", \\\"{x:189,y:579,t:1527876744622};\\\", \\\"{x:189,y:580,t:1527876744645};\\\", \\\"{x:188,y:583,t:1527876744669};\\\", \\\"{x:188,y:586,t:1527876744678};\\\", \\\"{x:187,y:590,t:1527876744689};\\\", \\\"{x:186,y:600,t:1527876744706};\\\", \\\"{x:185,y:610,t:1527876744722};\\\", \\\"{x:185,y:615,t:1527876744738};\\\", \\\"{x:185,y:621,t:1527876744755};\\\", \\\"{x:185,y:626,t:1527876744771};\\\", \\\"{x:192,y:637,t:1527876744789};\\\", \\\"{x:211,y:651,t:1527876744806};\\\", \\\"{x:241,y:659,t:1527876744821};\\\", \\\"{x:314,y:667,t:1527876744839};\\\", \\\"{x:362,y:668,t:1527876744856};\\\", \\\"{x:414,y:673,t:1527876744872};\\\", \\\"{x:475,y:679,t:1527876744888};\\\", \\\"{x:514,y:683,t:1527876744905};\\\", \\\"{x:547,y:683,t:1527876744921};\\\", \\\"{x:569,y:683,t:1527876744938};\\\", \\\"{x:583,y:683,t:1527876744955};\\\", \\\"{x:588,y:683,t:1527876744973};\\\", \\\"{x:592,y:683,t:1527876744988};\\\", \\\"{x:596,y:683,t:1527876745005};\\\", \\\"{x:616,y:678,t:1527876745022};\\\", \\\"{x:636,y:673,t:1527876745038};\\\", \\\"{x:665,y:667,t:1527876745056};\\\", \\\"{x:689,y:663,t:1527876745072};\\\", \\\"{x:719,y:658,t:1527876745090};\\\", \\\"{x:739,y:656,t:1527876745105};\\\", \\\"{x:749,y:653,t:1527876745123};\\\", \\\"{x:752,y:652,t:1527876745139};\\\", \\\"{x:755,y:650,t:1527876745156};\\\", \\\"{x:757,y:648,t:1527876745173};\\\", \\\"{x:769,y:646,t:1527876745190};\\\", \\\"{x:801,y:638,t:1527876745206};\\\", \\\"{x:821,y:629,t:1527876745223};\\\", \\\"{x:836,y:622,t:1527876745240};\\\", \\\"{x:850,y:613,t:1527876745255};\\\", \\\"{x:855,y:610,t:1527876745272};\\\", \\\"{x:856,y:608,t:1527876745288};\\\", \\\"{x:858,y:605,t:1527876745305};\\\", \\\"{x:858,y:600,t:1527876745322};\\\", \\\"{x:858,y:598,t:1527876745339};\\\", \\\"{x:858,y:596,t:1527876745355};\\\", \\\"{x:858,y:594,t:1527876745372};\\\", \\\"{x:858,y:592,t:1527876745390};\\\", \\\"{x:858,y:591,t:1527876745405};\\\", \\\"{x:858,y:589,t:1527876745422};\\\", \\\"{x:858,y:588,t:1527876745438};\\\", \\\"{x:854,y:587,t:1527876745455};\\\", \\\"{x:852,y:586,t:1527876745473};\\\", \\\"{x:851,y:586,t:1527876745489};\\\", \\\"{x:849,y:585,t:1527876745509};\\\", \\\"{x:848,y:584,t:1527876745525};\\\", \\\"{x:847,y:583,t:1527876745549};\\\", \\\"{x:845,y:582,t:1527876745557};\\\", \\\"{x:844,y:581,t:1527876745574};\\\", \\\"{x:844,y:580,t:1527876745590};\\\", \\\"{x:841,y:580,t:1527876745798};\\\", \\\"{x:838,y:580,t:1527876745806};\\\", \\\"{x:836,y:580,t:1527876745822};\\\", \\\"{x:827,y:584,t:1527876745839};\\\", \\\"{x:813,y:591,t:1527876745857};\\\", \\\"{x:800,y:595,t:1527876745872};\\\", \\\"{x:783,y:599,t:1527876745889};\\\", \\\"{x:761,y:605,t:1527876745907};\\\", \\\"{x:744,y:610,t:1527876745922};\\\", \\\"{x:724,y:613,t:1527876745939};\\\", \\\"{x:708,y:616,t:1527876745957};\\\", \\\"{x:699,y:617,t:1527876745972};\\\", \\\"{x:689,y:618,t:1527876745989};\\\", \\\"{x:681,y:618,t:1527876746006};\\\", \\\"{x:676,y:620,t:1527876746023};\\\", \\\"{x:670,y:620,t:1527876746039};\\\", \\\"{x:668,y:619,t:1527876746057};\\\", \\\"{x:663,y:615,t:1527876746072};\\\", \\\"{x:653,y:609,t:1527876746090};\\\", \\\"{x:644,y:605,t:1527876746106};\\\", \\\"{x:636,y:600,t:1527876746123};\\\", \\\"{x:632,y:596,t:1527876746139};\\\", \\\"{x:629,y:593,t:1527876746156};\\\", \\\"{x:620,y:586,t:1527876746174};\\\", \\\"{x:616,y:582,t:1527876746189};\\\", \\\"{x:615,y:581,t:1527876746206};\\\", \\\"{x:615,y:580,t:1527876746222};\\\", \\\"{x:614,y:580,t:1527876746302};\\\", \\\"{x:613,y:579,t:1527876746326};\\\", \\\"{x:612,y:583,t:1527876746518};\\\", \\\"{x:611,y:590,t:1527876746525};\\\", \\\"{x:608,y:595,t:1527876746540};\\\", \\\"{x:601,y:615,t:1527876746557};\\\", \\\"{x:590,y:637,t:1527876746574};\\\", \\\"{x:581,y:651,t:1527876746590};\\\", \\\"{x:572,y:667,t:1527876746607};\\\", \\\"{x:568,y:679,t:1527876746623};\\\", \\\"{x:564,y:688,t:1527876746640};\\\", \\\"{x:561,y:694,t:1527876746657};\\\", \\\"{x:560,y:700,t:1527876746673};\\\", \\\"{x:557,y:705,t:1527876746689};\\\", \\\"{x:552,y:711,t:1527876746707};\\\", \\\"{x:552,y:712,t:1527876746723};\\\", \\\"{x:550,y:716,t:1527876746740};\\\", \\\"{x:546,y:721,t:1527876746758};\\\", \\\"{x:541,y:730,t:1527876746774};\\\", \\\"{x:536,y:737,t:1527876746790};\\\", \\\"{x:533,y:741,t:1527876746806};\\\", \\\"{x:533,y:742,t:1527876747659};\\\", \\\"{x:533,y:743,t:1527876747667};\\\", \\\"{x:533,y:744,t:1527876747683};\\\", \\\"{x:533,y:745,t:1527876747695};\\\", \\\"{x:533,y:746,t:1527876747712};\\\", \\\"{x:533,y:747,t:1527876747729};\\\", \\\"{x:533,y:749,t:1527876747746};\\\", \\\"{x:533,y:752,t:1527876747763};\\\", \\\"{x:533,y:754,t:1527876747778};\\\", \\\"{x:533,y:757,t:1527876747796};\\\", \\\"{x:532,y:762,t:1527876747812};\\\", \\\"{x:530,y:767,t:1527876747829};\\\", \\\"{x:529,y:770,t:1527876747847};\\\", \\\"{x:528,y:774,t:1527876747862};\\\", \\\"{x:526,y:777,t:1527876747879};\\\", \\\"{x:525,y:778,t:1527876747896};\\\", \\\"{x:524,y:780,t:1527876747912};\\\", \\\"{x:523,y:781,t:1527876747979};\\\", \\\"{x:523,y:783,t:1527876748011};\\\" ] }, { \\\"rt\\\": 49933, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 410573, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -J -G -A -09 AM-11 AM-12 PM-01 PM-01 PM-02 PM-03 PM-J -J -I -B -B -B -B -I -B -E -X -O -O -C -C -G -11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:783,t:1527876748514};\\\", \\\"{x:523,y:783,t:1527876748987};\\\", \\\"{x:526,y:783,t:1527876748996};\\\", \\\"{x:529,y:782,t:1527876749013};\\\", \\\"{x:540,y:775,t:1527876749030};\\\", \\\"{x:551,y:767,t:1527876749046};\\\", \\\"{x:563,y:757,t:1527876749063};\\\", \\\"{x:571,y:746,t:1527876749080};\\\", \\\"{x:577,y:736,t:1527876749096};\\\", \\\"{x:583,y:725,t:1527876749113};\\\", \\\"{x:584,y:721,t:1527876749130};\\\", \\\"{x:585,y:717,t:1527876749147};\\\", \\\"{x:586,y:716,t:1527876749163};\\\", \\\"{x:585,y:714,t:1527876749180};\\\", \\\"{x:585,y:712,t:1527876750963};\\\", \\\"{x:587,y:712,t:1527876750971};\\\", \\\"{x:594,y:712,t:1527876750982};\\\", \\\"{x:616,y:708,t:1527876750998};\\\", \\\"{x:644,y:700,t:1527876751015};\\\", \\\"{x:666,y:693,t:1527876751031};\\\", \\\"{x:682,y:687,t:1527876751048};\\\", \\\"{x:688,y:683,t:1527876751064};\\\", \\\"{x:693,y:680,t:1527876751082};\\\", \\\"{x:699,y:676,t:1527876751099};\\\", \\\"{x:709,y:671,t:1527876751115};\\\", \\\"{x:722,y:665,t:1527876751131};\\\", \\\"{x:733,y:659,t:1527876751148};\\\", \\\"{x:747,y:649,t:1527876751165};\\\", \\\"{x:758,y:641,t:1527876751182};\\\", \\\"{x:767,y:633,t:1527876751198};\\\", \\\"{x:777,y:619,t:1527876751216};\\\", \\\"{x:782,y:607,t:1527876751230};\\\", \\\"{x:785,y:598,t:1527876751248};\\\", \\\"{x:787,y:589,t:1527876751266};\\\", \\\"{x:787,y:576,t:1527876751282};\\\", \\\"{x:785,y:564,t:1527876751298};\\\", \\\"{x:780,y:555,t:1527876751316};\\\", \\\"{x:773,y:545,t:1527876751331};\\\", \\\"{x:768,y:542,t:1527876751347};\\\", \\\"{x:764,y:540,t:1527876751364};\\\", \\\"{x:761,y:540,t:1527876751381};\\\", \\\"{x:758,y:538,t:1527876751398};\\\", \\\"{x:754,y:538,t:1527876751414};\\\", \\\"{x:748,y:537,t:1527876751430};\\\", \\\"{x:742,y:536,t:1527876751448};\\\", \\\"{x:736,y:535,t:1527876751464};\\\", \\\"{x:729,y:534,t:1527876751481};\\\", \\\"{x:717,y:532,t:1527876751498};\\\", \\\"{x:702,y:529,t:1527876751514};\\\", \\\"{x:681,y:527,t:1527876751530};\\\", \\\"{x:658,y:521,t:1527876751548};\\\", \\\"{x:637,y:515,t:1527876751565};\\\", \\\"{x:620,y:512,t:1527876751583};\\\", \\\"{x:604,y:511,t:1527876751598};\\\", \\\"{x:594,y:510,t:1527876751615};\\\", \\\"{x:585,y:510,t:1527876751632};\\\", \\\"{x:572,y:510,t:1527876751648};\\\", \\\"{x:562,y:510,t:1527876751664};\\\", \\\"{x:560,y:510,t:1527876751682};\\\", \\\"{x:558,y:510,t:1527876751698};\\\", \\\"{x:554,y:510,t:1527876751715};\\\", \\\"{x:550,y:510,t:1527876751732};\\\", \\\"{x:549,y:510,t:1527876751748};\\\", \\\"{x:554,y:508,t:1527876751874};\\\", \\\"{x:564,y:502,t:1527876751881};\\\", \\\"{x:588,y:489,t:1527876751898};\\\", \\\"{x:607,y:478,t:1527876751916};\\\", \\\"{x:618,y:473,t:1527876751932};\\\", \\\"{x:628,y:466,t:1527876751948};\\\", \\\"{x:632,y:465,t:1527876751965};\\\", \\\"{x:639,y:463,t:1527876751982};\\\", \\\"{x:639,y:462,t:1527876751999};\\\", \\\"{x:640,y:462,t:1527876752067};\\\", \\\"{x:641,y:462,t:1527876752099};\\\", \\\"{x:643,y:462,t:1527876752115};\\\", \\\"{x:645,y:462,t:1527876752132};\\\", \\\"{x:650,y:464,t:1527876752149};\\\", \\\"{x:653,y:466,t:1527876752166};\\\", \\\"{x:653,y:468,t:1527876752194};\\\", \\\"{x:650,y:469,t:1527876752274};\\\", \\\"{x:646,y:469,t:1527876752282};\\\", \\\"{x:628,y:470,t:1527876752299};\\\", \\\"{x:619,y:470,t:1527876752315};\\\", \\\"{x:614,y:471,t:1527876752333};\\\", \\\"{x:613,y:471,t:1527876752350};\\\", \\\"{x:613,y:472,t:1527876752411};\\\", \\\"{x:613,y:473,t:1527876752418};\\\", \\\"{x:610,y:478,t:1527876752432};\\\", \\\"{x:609,y:485,t:1527876752450};\\\", \\\"{x:609,y:495,t:1527876752467};\\\", \\\"{x:609,y:497,t:1527876752482};\\\", \\\"{x:610,y:500,t:1527876752499};\\\", \\\"{x:612,y:501,t:1527876752516};\\\", \\\"{x:615,y:504,t:1527876752532};\\\", \\\"{x:618,y:506,t:1527876752549};\\\", \\\"{x:619,y:507,t:1527876752566};\\\", \\\"{x:620,y:508,t:1527876752582};\\\", \\\"{x:621,y:508,t:1527876752610};\\\", \\\"{x:621,y:509,t:1527876752626};\\\", \\\"{x:621,y:510,t:1527876752642};\\\", \\\"{x:621,y:511,t:1527876752658};\\\", \\\"{x:621,y:512,t:1527876752666};\\\", \\\"{x:621,y:514,t:1527876752682};\\\", \\\"{x:618,y:516,t:1527876752699};\\\", \\\"{x:612,y:518,t:1527876752716};\\\", \\\"{x:608,y:518,t:1527876752732};\\\", \\\"{x:602,y:518,t:1527876752749};\\\", \\\"{x:597,y:518,t:1527876752766};\\\", \\\"{x:590,y:518,t:1527876752782};\\\", \\\"{x:577,y:514,t:1527876752800};\\\", \\\"{x:565,y:511,t:1527876752816};\\\", \\\"{x:550,y:508,t:1527876752833};\\\", \\\"{x:530,y:504,t:1527876752849};\\\", \\\"{x:501,y:499,t:1527876752866};\\\", \\\"{x:481,y:494,t:1527876752884};\\\", \\\"{x:463,y:489,t:1527876752899};\\\", \\\"{x:449,y:486,t:1527876752917};\\\", \\\"{x:442,y:483,t:1527876752933};\\\", \\\"{x:440,y:481,t:1527876752949};\\\", \\\"{x:438,y:480,t:1527876752966};\\\", \\\"{x:437,y:480,t:1527876752983};\\\", \\\"{x:436,y:479,t:1527876752999};\\\", \\\"{x:432,y:478,t:1527876753016};\\\", \\\"{x:430,y:477,t:1527876753033};\\\", \\\"{x:427,y:474,t:1527876753049};\\\", \\\"{x:424,y:471,t:1527876753066};\\\", \\\"{x:422,y:469,t:1527876753084};\\\", \\\"{x:422,y:467,t:1527876753099};\\\", \\\"{x:422,y:465,t:1527876753116};\\\", \\\"{x:422,y:462,t:1527876753133};\\\", \\\"{x:426,y:460,t:1527876753150};\\\", \\\"{x:431,y:458,t:1527876753166};\\\", \\\"{x:438,y:456,t:1527876753183};\\\", \\\"{x:443,y:455,t:1527876753200};\\\", \\\"{x:450,y:454,t:1527876753217};\\\", \\\"{x:454,y:454,t:1527876753234};\\\", \\\"{x:458,y:453,t:1527876753249};\\\", \\\"{x:462,y:452,t:1527876753267};\\\", \\\"{x:467,y:452,t:1527876753283};\\\", \\\"{x:480,y:453,t:1527876753299};\\\", \\\"{x:494,y:454,t:1527876753317};\\\", \\\"{x:509,y:454,t:1527876753333};\\\", \\\"{x:522,y:454,t:1527876753350};\\\", \\\"{x:531,y:455,t:1527876753367};\\\", \\\"{x:537,y:455,t:1527876753383};\\\", \\\"{x:539,y:456,t:1527876753401};\\\", \\\"{x:540,y:457,t:1527876753417};\\\", \\\"{x:541,y:457,t:1527876753434};\\\", \\\"{x:542,y:458,t:1527876753450};\\\", \\\"{x:543,y:459,t:1527876753466};\\\", \\\"{x:545,y:460,t:1527876753483};\\\", \\\"{x:547,y:461,t:1527876753501};\\\", \\\"{x:549,y:462,t:1527876753517};\\\", \\\"{x:553,y:464,t:1527876753533};\\\", \\\"{x:559,y:467,t:1527876753551};\\\", \\\"{x:562,y:468,t:1527876753567};\\\", \\\"{x:570,y:468,t:1527876753583};\\\", \\\"{x:579,y:469,t:1527876753600};\\\", \\\"{x:589,y:470,t:1527876753616};\\\", \\\"{x:600,y:471,t:1527876753633};\\\", \\\"{x:616,y:471,t:1527876753649};\\\", \\\"{x:619,y:471,t:1527876753666};\\\", \\\"{x:620,y:471,t:1527876753683};\\\", \\\"{x:624,y:469,t:1527876753876};\\\", \\\"{x:625,y:468,t:1527876753883};\\\", \\\"{x:632,y:463,t:1527876753901};\\\", \\\"{x:637,y:460,t:1527876753918};\\\", \\\"{x:645,y:457,t:1527876753934};\\\", \\\"{x:651,y:454,t:1527876753951};\\\", \\\"{x:657,y:454,t:1527876753967};\\\", \\\"{x:660,y:453,t:1527876753983};\\\", \\\"{x:665,y:453,t:1527876754000};\\\", \\\"{x:667,y:453,t:1527876754018};\\\", \\\"{x:671,y:453,t:1527876754033};\\\", \\\"{x:672,y:453,t:1527876754051};\\\", \\\"{x:674,y:453,t:1527876754195};\\\", \\\"{x:675,y:453,t:1527876754227};\\\", \\\"{x:676,y:453,t:1527876754259};\\\", \\\"{x:677,y:453,t:1527876754267};\\\", \\\"{x:679,y:454,t:1527876754284};\\\", \\\"{x:681,y:454,t:1527876754300};\\\", \\\"{x:684,y:455,t:1527876754317};\\\", \\\"{x:686,y:455,t:1527876754334};\\\", \\\"{x:694,y:455,t:1527876754350};\\\", \\\"{x:704,y:456,t:1527876754367};\\\", \\\"{x:712,y:458,t:1527876754384};\\\", \\\"{x:721,y:458,t:1527876754400};\\\", \\\"{x:725,y:458,t:1527876754417};\\\", \\\"{x:735,y:460,t:1527876754434};\\\", \\\"{x:745,y:462,t:1527876754450};\\\", \\\"{x:764,y:464,t:1527876754468};\\\", \\\"{x:792,y:468,t:1527876754484};\\\", \\\"{x:814,y:470,t:1527876754500};\\\", \\\"{x:841,y:473,t:1527876754518};\\\", \\\"{x:863,y:475,t:1527876754535};\\\", \\\"{x:887,y:481,t:1527876754550};\\\", \\\"{x:917,y:488,t:1527876754568};\\\", \\\"{x:958,y:501,t:1527876754584};\\\", \\\"{x:992,y:513,t:1527876754601};\\\", \\\"{x:1011,y:520,t:1527876754617};\\\", \\\"{x:1063,y:545,t:1527876754634};\\\", \\\"{x:1088,y:555,t:1527876754651};\\\", \\\"{x:1116,y:570,t:1527876754667};\\\", \\\"{x:1141,y:585,t:1527876754684};\\\", \\\"{x:1166,y:604,t:1527876754701};\\\", \\\"{x:1192,y:622,t:1527876754717};\\\", \\\"{x:1206,y:634,t:1527876754734};\\\", \\\"{x:1213,y:641,t:1527876754751};\\\", \\\"{x:1218,y:648,t:1527876754768};\\\", \\\"{x:1223,y:661,t:1527876754785};\\\", \\\"{x:1233,y:679,t:1527876754801};\\\", \\\"{x:1257,y:704,t:1527876754818};\\\", \\\"{x:1278,y:719,t:1527876754834};\\\", \\\"{x:1294,y:730,t:1527876754851};\\\", \\\"{x:1311,y:740,t:1527876754868};\\\", \\\"{x:1322,y:746,t:1527876754885};\\\", \\\"{x:1332,y:751,t:1527876754901};\\\", \\\"{x:1341,y:758,t:1527876754918};\\\", \\\"{x:1351,y:766,t:1527876754935};\\\", \\\"{x:1364,y:775,t:1527876754951};\\\", \\\"{x:1374,y:784,t:1527876754968};\\\", \\\"{x:1380,y:790,t:1527876754984};\\\", \\\"{x:1384,y:796,t:1527876755001};\\\", \\\"{x:1398,y:811,t:1527876755018};\\\", \\\"{x:1405,y:816,t:1527876755035};\\\", \\\"{x:1411,y:821,t:1527876755051};\\\", \\\"{x:1419,y:825,t:1527876755068};\\\", \\\"{x:1424,y:827,t:1527876755085};\\\", \\\"{x:1431,y:829,t:1527876755101};\\\", \\\"{x:1437,y:829,t:1527876755119};\\\", \\\"{x:1446,y:829,t:1527876755136};\\\", \\\"{x:1459,y:829,t:1527876755152};\\\", \\\"{x:1475,y:829,t:1527876755169};\\\", \\\"{x:1497,y:829,t:1527876755185};\\\", \\\"{x:1518,y:829,t:1527876755201};\\\", \\\"{x:1540,y:829,t:1527876755219};\\\", \\\"{x:1546,y:829,t:1527876755236};\\\", \\\"{x:1547,y:829,t:1527876755252};\\\", \\\"{x:1546,y:825,t:1527876755739};\\\", \\\"{x:1541,y:820,t:1527876755752};\\\", \\\"{x:1538,y:815,t:1527876755769};\\\", \\\"{x:1527,y:801,t:1527876755786};\\\", \\\"{x:1522,y:793,t:1527876755802};\\\", \\\"{x:1514,y:784,t:1527876755819};\\\", \\\"{x:1507,y:775,t:1527876755836};\\\", \\\"{x:1503,y:769,t:1527876755852};\\\", \\\"{x:1500,y:765,t:1527876755870};\\\", \\\"{x:1497,y:758,t:1527876755887};\\\", \\\"{x:1494,y:751,t:1527876755903};\\\", \\\"{x:1490,y:742,t:1527876755920};\\\", \\\"{x:1485,y:727,t:1527876755936};\\\", \\\"{x:1480,y:717,t:1527876755952};\\\", \\\"{x:1474,y:703,t:1527876755970};\\\", \\\"{x:1469,y:687,t:1527876755986};\\\", \\\"{x:1466,y:670,t:1527876756002};\\\", \\\"{x:1464,y:652,t:1527876756019};\\\", \\\"{x:1462,y:641,t:1527876756037};\\\", \\\"{x:1461,y:634,t:1527876756053};\\\", \\\"{x:1460,y:630,t:1527876756070};\\\", \\\"{x:1458,y:626,t:1527876756087};\\\", \\\"{x:1458,y:625,t:1527876756130};\\\", \\\"{x:1458,y:624,t:1527876756138};\\\", \\\"{x:1458,y:623,t:1527876756154};\\\", \\\"{x:1458,y:622,t:1527876756170};\\\", \\\"{x:1458,y:612,t:1527876756185};\\\", \\\"{x:1458,y:601,t:1527876756203};\\\", \\\"{x:1459,y:594,t:1527876756220};\\\", \\\"{x:1463,y:579,t:1527876756236};\\\", \\\"{x:1469,y:565,t:1527876756254};\\\", \\\"{x:1470,y:560,t:1527876756270};\\\", \\\"{x:1471,y:559,t:1527876756290};\\\", \\\"{x:1468,y:559,t:1527876757171};\\\", \\\"{x:1462,y:561,t:1527876757188};\\\", \\\"{x:1456,y:563,t:1527876757205};\\\", \\\"{x:1453,y:564,t:1527876757223};\\\", \\\"{x:1452,y:565,t:1527876757238};\\\", \\\"{x:1450,y:566,t:1527876757255};\\\", \\\"{x:1449,y:566,t:1527876757272};\\\", \\\"{x:1446,y:568,t:1527876757288};\\\", \\\"{x:1444,y:569,t:1527876757305};\\\", \\\"{x:1442,y:570,t:1527876757322};\\\", \\\"{x:1440,y:573,t:1527876757339};\\\", \\\"{x:1440,y:576,t:1527876757354};\\\", \\\"{x:1442,y:586,t:1527876757372};\\\", \\\"{x:1450,y:601,t:1527876757388};\\\", \\\"{x:1452,y:608,t:1527876757404};\\\", \\\"{x:1457,y:616,t:1527876757421};\\\", \\\"{x:1460,y:619,t:1527876757439};\\\", \\\"{x:1462,y:621,t:1527876757455};\\\", \\\"{x:1462,y:619,t:1527876757514};\\\", \\\"{x:1461,y:617,t:1527876757521};\\\", \\\"{x:1459,y:613,t:1527876757538};\\\", \\\"{x:1457,y:604,t:1527876757554};\\\", \\\"{x:1457,y:596,t:1527876757571};\\\", \\\"{x:1457,y:579,t:1527876757589};\\\", \\\"{x:1459,y:565,t:1527876757605};\\\", \\\"{x:1467,y:554,t:1527876757621};\\\", \\\"{x:1476,y:545,t:1527876757639};\\\", \\\"{x:1486,y:537,t:1527876757655};\\\", \\\"{x:1497,y:529,t:1527876757671};\\\", \\\"{x:1505,y:521,t:1527876757688};\\\", \\\"{x:1509,y:511,t:1527876757706};\\\", \\\"{x:1510,y:500,t:1527876757721};\\\", \\\"{x:1510,y:484,t:1527876757738};\\\", \\\"{x:1510,y:477,t:1527876757755};\\\", \\\"{x:1508,y:467,t:1527876757772};\\\", \\\"{x:1504,y:460,t:1527876757789};\\\", \\\"{x:1500,y:453,t:1527876757805};\\\", \\\"{x:1490,y:448,t:1527876757822};\\\", \\\"{x:1485,y:444,t:1527876757839};\\\", \\\"{x:1477,y:441,t:1527876757856};\\\", \\\"{x:1469,y:438,t:1527876757872};\\\", \\\"{x:1466,y:437,t:1527876757888};\\\", \\\"{x:1464,y:436,t:1527876757905};\\\", \\\"{x:1462,y:432,t:1527876757922};\\\", \\\"{x:1462,y:428,t:1527876757939};\\\", \\\"{x:1462,y:423,t:1527876757955};\\\", \\\"{x:1462,y:418,t:1527876757972};\\\", \\\"{x:1462,y:413,t:1527876757989};\\\", \\\"{x:1466,y:406,t:1527876758005};\\\", \\\"{x:1470,y:402,t:1527876758023};\\\", \\\"{x:1475,y:396,t:1527876758038};\\\", \\\"{x:1481,y:389,t:1527876758056};\\\", \\\"{x:1486,y:381,t:1527876758072};\\\", \\\"{x:1493,y:372,t:1527876758089};\\\", \\\"{x:1500,y:362,t:1527876758106};\\\", \\\"{x:1511,y:353,t:1527876758122};\\\", \\\"{x:1517,y:349,t:1527876758140};\\\", \\\"{x:1524,y:346,t:1527876758156};\\\", \\\"{x:1529,y:344,t:1527876758173};\\\", \\\"{x:1534,y:343,t:1527876758189};\\\", \\\"{x:1539,y:343,t:1527876758205};\\\", \\\"{x:1541,y:343,t:1527876758222};\\\", \\\"{x:1546,y:343,t:1527876758239};\\\", \\\"{x:1549,y:343,t:1527876758255};\\\", \\\"{x:1552,y:343,t:1527876758272};\\\", \\\"{x:1553,y:343,t:1527876758289};\\\", \\\"{x:1556,y:344,t:1527876758305};\\\", \\\"{x:1558,y:346,t:1527876758323};\\\", \\\"{x:1560,y:348,t:1527876758339};\\\", \\\"{x:1562,y:349,t:1527876758356};\\\", \\\"{x:1563,y:351,t:1527876758373};\\\", \\\"{x:1565,y:352,t:1527876758390};\\\", \\\"{x:1566,y:353,t:1527876758405};\\\", \\\"{x:1567,y:354,t:1527876758423};\\\", \\\"{x:1567,y:355,t:1527876758440};\\\", \\\"{x:1569,y:358,t:1527876758457};\\\", \\\"{x:1570,y:365,t:1527876758473};\\\", \\\"{x:1570,y:379,t:1527876758490};\\\", \\\"{x:1570,y:404,t:1527876758507};\\\", \\\"{x:1570,y:424,t:1527876758523};\\\", \\\"{x:1562,y:453,t:1527876758540};\\\", \\\"{x:1553,y:482,t:1527876758557};\\\", \\\"{x:1537,y:515,t:1527876758573};\\\", \\\"{x:1513,y:563,t:1527876758590};\\\", \\\"{x:1496,y:597,t:1527876758607};\\\", \\\"{x:1485,y:622,t:1527876758623};\\\", \\\"{x:1475,y:640,t:1527876758639};\\\", \\\"{x:1470,y:652,t:1527876758656};\\\", \\\"{x:1468,y:657,t:1527876758673};\\\", \\\"{x:1467,y:662,t:1527876758690};\\\", \\\"{x:1466,y:672,t:1527876758706};\\\", \\\"{x:1464,y:682,t:1527876758724};\\\", \\\"{x:1460,y:696,t:1527876758739};\\\", \\\"{x:1453,y:712,t:1527876758757};\\\", \\\"{x:1450,y:720,t:1527876758773};\\\", \\\"{x:1447,y:726,t:1527876758790};\\\", \\\"{x:1445,y:730,t:1527876758807};\\\", \\\"{x:1443,y:733,t:1527876758824};\\\", \\\"{x:1439,y:736,t:1527876758840};\\\", \\\"{x:1435,y:739,t:1527876758857};\\\", \\\"{x:1426,y:745,t:1527876758873};\\\", \\\"{x:1415,y:750,t:1527876758890};\\\", \\\"{x:1412,y:752,t:1527876758906};\\\", \\\"{x:1411,y:752,t:1527876758923};\\\", \\\"{x:1407,y:754,t:1527876758940};\\\", \\\"{x:1405,y:754,t:1527876758956};\\\", \\\"{x:1403,y:755,t:1527876758973};\\\", \\\"{x:1397,y:756,t:1527876758990};\\\", \\\"{x:1393,y:757,t:1527876759006};\\\", \\\"{x:1388,y:759,t:1527876759023};\\\", \\\"{x:1382,y:759,t:1527876759040};\\\", \\\"{x:1377,y:759,t:1527876759057};\\\", \\\"{x:1374,y:759,t:1527876759073};\\\", \\\"{x:1370,y:759,t:1527876759090};\\\", \\\"{x:1364,y:761,t:1527876759107};\\\", \\\"{x:1358,y:763,t:1527876759125};\\\", \\\"{x:1352,y:763,t:1527876759142};\\\", \\\"{x:1347,y:763,t:1527876759158};\\\", \\\"{x:1342,y:763,t:1527876759174};\\\", \\\"{x:1342,y:764,t:1527876760107};\\\", \\\"{x:1343,y:764,t:1527876760114};\\\", \\\"{x:1344,y:765,t:1527876760124};\\\", \\\"{x:1346,y:765,t:1527876760142};\\\", \\\"{x:1348,y:765,t:1527876760158};\\\", \\\"{x:1349,y:765,t:1527876760259};\\\", \\\"{x:1351,y:767,t:1527876760276};\\\", \\\"{x:1352,y:767,t:1527876760291};\\\", \\\"{x:1353,y:767,t:1527876760310};\\\", \\\"{x:1354,y:768,t:1527876760326};\\\", \\\"{x:1353,y:768,t:1527876760610};\\\", \\\"{x:1352,y:768,t:1527876760625};\\\", \\\"{x:1349,y:768,t:1527876761179};\\\", \\\"{x:1347,y:768,t:1527876761194};\\\", \\\"{x:1344,y:766,t:1527876761209};\\\", \\\"{x:1337,y:766,t:1527876761228};\\\", \\\"{x:1332,y:766,t:1527876761244};\\\", \\\"{x:1325,y:766,t:1527876761260};\\\", \\\"{x:1320,y:766,t:1527876761277};\\\", \\\"{x:1317,y:766,t:1527876761294};\\\", \\\"{x:1313,y:766,t:1527876761310};\\\", \\\"{x:1308,y:768,t:1527876761327};\\\", \\\"{x:1304,y:769,t:1527876761344};\\\", \\\"{x:1303,y:769,t:1527876761360};\\\", \\\"{x:1302,y:769,t:1527876761377};\\\", \\\"{x:1300,y:770,t:1527876761394};\\\", \\\"{x:1294,y:771,t:1527876761595};\\\", \\\"{x:1285,y:774,t:1527876761610};\\\", \\\"{x:1270,y:778,t:1527876761627};\\\", \\\"{x:1255,y:782,t:1527876761644};\\\", \\\"{x:1250,y:784,t:1527876761661};\\\", \\\"{x:1246,y:787,t:1527876761678};\\\", \\\"{x:1245,y:788,t:1527876761694};\\\", \\\"{x:1244,y:789,t:1527876761755};\\\", \\\"{x:1244,y:791,t:1527876761762};\\\", \\\"{x:1244,y:794,t:1527876761778};\\\", \\\"{x:1244,y:798,t:1527876761794};\\\", \\\"{x:1243,y:802,t:1527876761811};\\\", \\\"{x:1243,y:803,t:1527876761828};\\\", \\\"{x:1242,y:804,t:1527876761844};\\\", \\\"{x:1242,y:806,t:1527876761861};\\\", \\\"{x:1242,y:808,t:1527876761878};\\\", \\\"{x:1239,y:811,t:1527876761894};\\\", \\\"{x:1232,y:818,t:1527876761911};\\\", \\\"{x:1221,y:826,t:1527876761928};\\\", \\\"{x:1216,y:829,t:1527876761946};\\\", \\\"{x:1215,y:830,t:1527876761961};\\\", \\\"{x:1216,y:830,t:1527876763283};\\\", \\\"{x:1216,y:829,t:1527876763296};\\\", \\\"{x:1217,y:829,t:1527876763313};\\\", \\\"{x:1218,y:827,t:1527876763451};\\\", \\\"{x:1218,y:824,t:1527876763464};\\\", \\\"{x:1219,y:822,t:1527876763483};\\\", \\\"{x:1221,y:821,t:1527876763497};\\\", \\\"{x:1223,y:818,t:1527876763514};\\\", \\\"{x:1230,y:809,t:1527876763531};\\\", \\\"{x:1236,y:802,t:1527876763547};\\\", \\\"{x:1239,y:798,t:1527876763563};\\\", \\\"{x:1246,y:793,t:1527876763581};\\\", \\\"{x:1260,y:782,t:1527876763597};\\\", \\\"{x:1285,y:759,t:1527876763613};\\\", \\\"{x:1318,y:725,t:1527876763630};\\\", \\\"{x:1350,y:680,t:1527876763648};\\\", \\\"{x:1380,y:637,t:1527876763664};\\\", \\\"{x:1400,y:604,t:1527876763680};\\\", \\\"{x:1415,y:579,t:1527876763697};\\\", \\\"{x:1420,y:562,t:1527876763714};\\\", \\\"{x:1425,y:532,t:1527876763731};\\\", \\\"{x:1425,y:508,t:1527876763746};\\\", \\\"{x:1425,y:489,t:1527876763764};\\\", \\\"{x:1426,y:474,t:1527876763780};\\\", \\\"{x:1426,y:460,t:1527876763797};\\\", \\\"{x:1426,y:451,t:1527876763814};\\\", \\\"{x:1426,y:441,t:1527876763830};\\\", \\\"{x:1423,y:437,t:1527876763847};\\\", \\\"{x:1420,y:435,t:1527876763864};\\\", \\\"{x:1420,y:432,t:1527876763880};\\\", \\\"{x:1420,y:431,t:1527876763898};\\\", \\\"{x:1419,y:431,t:1527876769274};\\\", \\\"{x:1419,y:432,t:1527876769307};\\\", \\\"{x:1418,y:433,t:1527876769322};\\\", \\\"{x:1418,y:434,t:1527876769337};\\\", \\\"{x:1416,y:440,t:1527876769355};\\\", \\\"{x:1414,y:442,t:1527876769371};\\\", \\\"{x:1413,y:443,t:1527876769388};\\\", \\\"{x:1413,y:445,t:1527876769405};\\\", \\\"{x:1412,y:447,t:1527876769421};\\\", \\\"{x:1409,y:451,t:1527876769439};\\\", \\\"{x:1406,y:457,t:1527876769455};\\\", \\\"{x:1402,y:465,t:1527876769471};\\\", \\\"{x:1395,y:476,t:1527876769488};\\\", \\\"{x:1392,y:479,t:1527876769504};\\\", \\\"{x:1390,y:483,t:1527876769521};\\\", \\\"{x:1388,y:487,t:1527876769538};\\\", \\\"{x:1387,y:490,t:1527876769555};\\\", \\\"{x:1384,y:497,t:1527876769572};\\\", \\\"{x:1381,y:503,t:1527876769588};\\\", \\\"{x:1379,y:511,t:1527876769605};\\\", \\\"{x:1373,y:524,t:1527876769621};\\\", \\\"{x:1366,y:538,t:1527876769638};\\\", \\\"{x:1363,y:547,t:1527876769655};\\\", \\\"{x:1359,y:555,t:1527876769671};\\\", \\\"{x:1356,y:561,t:1527876769688};\\\", \\\"{x:1355,y:563,t:1527876769706};\\\", \\\"{x:1353,y:566,t:1527876769722};\\\", \\\"{x:1349,y:576,t:1527876769738};\\\", \\\"{x:1345,y:585,t:1527876769755};\\\", \\\"{x:1340,y:594,t:1527876769771};\\\", \\\"{x:1335,y:604,t:1527876769789};\\\", \\\"{x:1332,y:610,t:1527876769806};\\\", \\\"{x:1327,y:616,t:1527876769821};\\\", \\\"{x:1325,y:620,t:1527876769838};\\\", \\\"{x:1321,y:626,t:1527876769855};\\\", \\\"{x:1318,y:634,t:1527876769872};\\\", \\\"{x:1312,y:643,t:1527876769889};\\\", \\\"{x:1305,y:654,t:1527876769905};\\\", \\\"{x:1292,y:676,t:1527876769922};\\\", \\\"{x:1286,y:689,t:1527876769939};\\\", \\\"{x:1278,y:701,t:1527876769955};\\\", \\\"{x:1274,y:708,t:1527876769972};\\\", \\\"{x:1270,y:716,t:1527876769988};\\\", \\\"{x:1269,y:721,t:1527876770005};\\\", \\\"{x:1266,y:728,t:1527876770022};\\\", \\\"{x:1265,y:736,t:1527876770038};\\\", \\\"{x:1260,y:748,t:1527876770056};\\\", \\\"{x:1256,y:756,t:1527876770072};\\\", \\\"{x:1254,y:764,t:1527876770088};\\\", \\\"{x:1251,y:769,t:1527876770105};\\\", \\\"{x:1247,y:779,t:1527876770123};\\\", \\\"{x:1245,y:783,t:1527876770139};\\\", \\\"{x:1242,y:791,t:1527876770155};\\\", \\\"{x:1234,y:803,t:1527876770173};\\\", \\\"{x:1225,y:817,t:1527876770189};\\\", \\\"{x:1214,y:836,t:1527876770205};\\\", \\\"{x:1198,y:856,t:1527876770222};\\\", \\\"{x:1174,y:888,t:1527876770239};\\\", \\\"{x:1141,y:926,t:1527876770255};\\\", \\\"{x:1113,y:963,t:1527876770273};\\\", \\\"{x:1097,y:985,t:1527876770289};\\\", \\\"{x:1089,y:995,t:1527876770306};\\\", \\\"{x:1086,y:1001,t:1527876770323};\\\", \\\"{x:1090,y:998,t:1527876770394};\\\", \\\"{x:1093,y:995,t:1527876770407};\\\", \\\"{x:1098,y:991,t:1527876770422};\\\", \\\"{x:1108,y:985,t:1527876770439};\\\", \\\"{x:1120,y:980,t:1527876770456};\\\", \\\"{x:1135,y:973,t:1527876770472};\\\", \\\"{x:1155,y:962,t:1527876770489};\\\", \\\"{x:1168,y:954,t:1527876770505};\\\", \\\"{x:1172,y:950,t:1527876770522};\\\", \\\"{x:1173,y:949,t:1527876770539};\\\", \\\"{x:1176,y:949,t:1527876770666};\\\", \\\"{x:1179,y:949,t:1527876770674};\\\", \\\"{x:1183,y:949,t:1527876770689};\\\", \\\"{x:1205,y:949,t:1527876770706};\\\", \\\"{x:1224,y:949,t:1527876770723};\\\", \\\"{x:1239,y:949,t:1527876770739};\\\", \\\"{x:1249,y:950,t:1527876770756};\\\", \\\"{x:1253,y:951,t:1527876770772};\\\", \\\"{x:1255,y:953,t:1527876770789};\\\", \\\"{x:1256,y:956,t:1527876770806};\\\", \\\"{x:1256,y:961,t:1527876770823};\\\", \\\"{x:1256,y:969,t:1527876770839};\\\", \\\"{x:1252,y:975,t:1527876770856};\\\", \\\"{x:1247,y:983,t:1527876770873};\\\", \\\"{x:1244,y:986,t:1527876770890};\\\", \\\"{x:1243,y:986,t:1527876770930};\\\", \\\"{x:1243,y:987,t:1527876770954};\\\", \\\"{x:1243,y:986,t:1527876771035};\\\", \\\"{x:1243,y:984,t:1527876771042};\\\", \\\"{x:1246,y:981,t:1527876771058};\\\", \\\"{x:1257,y:973,t:1527876771073};\\\", \\\"{x:1282,y:961,t:1527876771091};\\\", \\\"{x:1296,y:953,t:1527876771107};\\\", \\\"{x:1304,y:950,t:1527876771123};\\\", \\\"{x:1306,y:950,t:1527876771141};\\\", \\\"{x:1306,y:951,t:1527876771203};\\\", \\\"{x:1306,y:952,t:1527876771210};\\\", \\\"{x:1306,y:954,t:1527876771224};\\\", \\\"{x:1306,y:959,t:1527876771240};\\\", \\\"{x:1304,y:963,t:1527876771258};\\\", \\\"{x:1301,y:967,t:1527876771274};\\\", \\\"{x:1296,y:974,t:1527876771290};\\\", \\\"{x:1294,y:976,t:1527876771308};\\\", \\\"{x:1294,y:978,t:1527876771324};\\\", \\\"{x:1295,y:978,t:1527876771419};\\\", \\\"{x:1298,y:975,t:1527876771426};\\\", \\\"{x:1301,y:973,t:1527876771440};\\\", \\\"{x:1316,y:963,t:1527876771458};\\\", \\\"{x:1328,y:959,t:1527876771475};\\\", \\\"{x:1333,y:957,t:1527876771491};\\\", \\\"{x:1335,y:957,t:1527876771508};\\\", \\\"{x:1336,y:957,t:1527876771547};\\\", \\\"{x:1336,y:958,t:1527876771563};\\\", \\\"{x:1336,y:960,t:1527876771579};\\\", \\\"{x:1338,y:963,t:1527876771590};\\\", \\\"{x:1338,y:965,t:1527876771608};\\\", \\\"{x:1340,y:970,t:1527876771625};\\\", \\\"{x:1341,y:973,t:1527876771642};\\\", \\\"{x:1342,y:976,t:1527876771657};\\\", \\\"{x:1343,y:980,t:1527876771674};\\\", \\\"{x:1343,y:981,t:1527876771715};\\\", \\\"{x:1343,y:980,t:1527876771803};\\\", \\\"{x:1346,y:979,t:1527876771811};\\\", \\\"{x:1349,y:974,t:1527876771824};\\\", \\\"{x:1360,y:965,t:1527876771842};\\\", \\\"{x:1388,y:953,t:1527876771859};\\\", \\\"{x:1397,y:949,t:1527876771874};\\\", \\\"{x:1402,y:946,t:1527876771891};\\\", \\\"{x:1404,y:945,t:1527876771908};\\\", \\\"{x:1406,y:944,t:1527876771924};\\\", \\\"{x:1407,y:944,t:1527876771940};\\\", \\\"{x:1409,y:946,t:1527876772010};\\\", \\\"{x:1409,y:947,t:1527876772024};\\\", \\\"{x:1411,y:950,t:1527876772040};\\\", \\\"{x:1414,y:959,t:1527876772058};\\\", \\\"{x:1415,y:966,t:1527876772074};\\\", \\\"{x:1415,y:973,t:1527876772091};\\\", \\\"{x:1418,y:979,t:1527876772108};\\\", \\\"{x:1420,y:983,t:1527876772124};\\\", \\\"{x:1422,y:986,t:1527876772141};\\\", \\\"{x:1425,y:986,t:1527876772218};\\\", \\\"{x:1426,y:984,t:1527876772227};\\\", \\\"{x:1431,y:982,t:1527876772242};\\\", \\\"{x:1445,y:969,t:1527876772258};\\\", \\\"{x:1456,y:960,t:1527876772275};\\\", \\\"{x:1463,y:954,t:1527876772291};\\\", \\\"{x:1473,y:949,t:1527876772308};\\\", \\\"{x:1493,y:941,t:1527876772324};\\\", \\\"{x:1510,y:939,t:1527876772341};\\\", \\\"{x:1516,y:938,t:1527876772358};\\\", \\\"{x:1517,y:938,t:1527876772386};\\\", \\\"{x:1517,y:939,t:1527876772394};\\\", \\\"{x:1517,y:941,t:1527876772408};\\\", \\\"{x:1517,y:946,t:1527876772425};\\\", \\\"{x:1511,y:954,t:1527876772442};\\\", \\\"{x:1505,y:960,t:1527876772458};\\\", \\\"{x:1499,y:962,t:1527876772475};\\\", \\\"{x:1494,y:965,t:1527876772492};\\\", \\\"{x:1492,y:965,t:1527876772509};\\\", \\\"{x:1491,y:966,t:1527876772525};\\\", \\\"{x:1489,y:968,t:1527876772578};\\\", \\\"{x:1489,y:969,t:1527876772610};\\\", \\\"{x:1490,y:969,t:1527876772658};\\\", \\\"{x:1498,y:964,t:1527876772676};\\\", \\\"{x:1512,y:955,t:1527876772693};\\\", \\\"{x:1527,y:950,t:1527876772710};\\\", \\\"{x:1542,y:946,t:1527876772725};\\\", \\\"{x:1552,y:944,t:1527876772742};\\\", \\\"{x:1556,y:944,t:1527876772759};\\\", \\\"{x:1557,y:944,t:1527876772775};\\\", \\\"{x:1558,y:944,t:1527876772792};\\\", \\\"{x:1558,y:945,t:1527876772809};\\\", \\\"{x:1558,y:948,t:1527876772825};\\\", \\\"{x:1559,y:955,t:1527876772842};\\\", \\\"{x:1560,y:963,t:1527876772860};\\\", \\\"{x:1560,y:965,t:1527876772876};\\\", \\\"{x:1560,y:967,t:1527876772892};\\\", \\\"{x:1560,y:969,t:1527876772909};\\\", \\\"{x:1560,y:970,t:1527876772927};\\\", \\\"{x:1561,y:970,t:1527876773027};\\\", \\\"{x:1565,y:968,t:1527876773045};\\\", \\\"{x:1577,y:962,t:1527876773058};\\\", \\\"{x:1593,y:954,t:1527876773076};\\\", \\\"{x:1609,y:949,t:1527876773092};\\\", \\\"{x:1621,y:948,t:1527876773108};\\\", \\\"{x:1627,y:948,t:1527876773126};\\\", \\\"{x:1630,y:948,t:1527876773142};\\\", \\\"{x:1631,y:950,t:1527876773159};\\\", \\\"{x:1632,y:952,t:1527876773176};\\\", \\\"{x:1633,y:954,t:1527876773193};\\\", \\\"{x:1633,y:957,t:1527876773209};\\\", \\\"{x:1634,y:959,t:1527876773225};\\\", \\\"{x:1634,y:961,t:1527876773243};\\\", \\\"{x:1634,y:962,t:1527876773282};\\\", \\\"{x:1634,y:963,t:1527876773298};\\\", \\\"{x:1634,y:964,t:1527876773330};\\\", \\\"{x:1634,y:965,t:1527876773355};\\\", \\\"{x:1633,y:965,t:1527876773362};\\\", \\\"{x:1633,y:966,t:1527876773394};\\\", \\\"{x:1632,y:966,t:1527876773418};\\\", \\\"{x:1632,y:965,t:1527876773803};\\\", \\\"{x:1632,y:964,t:1527876773810};\\\", \\\"{x:1632,y:962,t:1527876774075};\\\", \\\"{x:1634,y:961,t:1527876774082};\\\", \\\"{x:1635,y:961,t:1527876774095};\\\", \\\"{x:1639,y:959,t:1527876774110};\\\", \\\"{x:1645,y:957,t:1527876774127};\\\", \\\"{x:1649,y:957,t:1527876774145};\\\", \\\"{x:1654,y:956,t:1527876774160};\\\", \\\"{x:1656,y:956,t:1527876774177};\\\", \\\"{x:1657,y:953,t:1527876774226};\\\", \\\"{x:1657,y:932,t:1527876774245};\\\", \\\"{x:1657,y:917,t:1527876774262};\\\", \\\"{x:1652,y:892,t:1527876774277};\\\", \\\"{x:1640,y:853,t:1527876774295};\\\", \\\"{x:1622,y:814,t:1527876774312};\\\", \\\"{x:1599,y:775,t:1527876774328};\\\", \\\"{x:1573,y:741,t:1527876774344};\\\", \\\"{x:1560,y:716,t:1527876774361};\\\", \\\"{x:1542,y:687,t:1527876774377};\\\", \\\"{x:1525,y:653,t:1527876774394};\\\", \\\"{x:1513,y:633,t:1527876774412};\\\", \\\"{x:1496,y:619,t:1527876774428};\\\", \\\"{x:1487,y:613,t:1527876774444};\\\", \\\"{x:1480,y:609,t:1527876774461};\\\", \\\"{x:1471,y:607,t:1527876774477};\\\", \\\"{x:1464,y:605,t:1527876774493};\\\", \\\"{x:1459,y:604,t:1527876774511};\\\", \\\"{x:1454,y:602,t:1527876774528};\\\", \\\"{x:1450,y:601,t:1527876774543};\\\", \\\"{x:1446,y:598,t:1527876774561};\\\", \\\"{x:1437,y:590,t:1527876774577};\\\", \\\"{x:1431,y:581,t:1527876774594};\\\", \\\"{x:1423,y:568,t:1527876774610};\\\", \\\"{x:1407,y:549,t:1527876774628};\\\", \\\"{x:1397,y:536,t:1527876774644};\\\", \\\"{x:1391,y:533,t:1527876774661};\\\", \\\"{x:1390,y:533,t:1527876774698};\\\", \\\"{x:1386,y:533,t:1527876774713};\\\", \\\"{x:1382,y:535,t:1527876774728};\\\", \\\"{x:1381,y:535,t:1527876775139};\\\", \\\"{x:1381,y:536,t:1527876775146};\\\", \\\"{x:1379,y:538,t:1527876775162};\\\", \\\"{x:1377,y:540,t:1527876775180};\\\", \\\"{x:1372,y:546,t:1527876775195};\\\", \\\"{x:1364,y:555,t:1527876775212};\\\", \\\"{x:1355,y:570,t:1527876775229};\\\", \\\"{x:1347,y:588,t:1527876775246};\\\", \\\"{x:1338,y:614,t:1527876775263};\\\", \\\"{x:1326,y:648,t:1527876775279};\\\", \\\"{x:1315,y:675,t:1527876775295};\\\", \\\"{x:1307,y:692,t:1527876775312};\\\", \\\"{x:1297,y:705,t:1527876775329};\\\", \\\"{x:1287,y:723,t:1527876775346};\\\", \\\"{x:1277,y:738,t:1527876775362};\\\", \\\"{x:1274,y:745,t:1527876775379};\\\", \\\"{x:1272,y:749,t:1527876775396};\\\", \\\"{x:1269,y:755,t:1527876775413};\\\", \\\"{x:1261,y:766,t:1527876775429};\\\", \\\"{x:1251,y:779,t:1527876775446};\\\", \\\"{x:1246,y:787,t:1527876775462};\\\", \\\"{x:1240,y:791,t:1527876775480};\\\", \\\"{x:1237,y:793,t:1527876775496};\\\", \\\"{x:1235,y:795,t:1527876775513};\\\", \\\"{x:1233,y:798,t:1527876775529};\\\", \\\"{x:1231,y:803,t:1527876775546};\\\", \\\"{x:1230,y:805,t:1527876775562};\\\", \\\"{x:1230,y:809,t:1527876775579};\\\", \\\"{x:1228,y:813,t:1527876775597};\\\", \\\"{x:1226,y:816,t:1527876775612};\\\", \\\"{x:1225,y:819,t:1527876775630};\\\", \\\"{x:1224,y:823,t:1527876775646};\\\", \\\"{x:1223,y:823,t:1527876775690};\\\", \\\"{x:1223,y:824,t:1527876775714};\\\", \\\"{x:1222,y:824,t:1527876775730};\\\", \\\"{x:1219,y:828,t:1527876775747};\\\", \\\"{x:1217,y:829,t:1527876775763};\\\", \\\"{x:1216,y:830,t:1527876775780};\\\", \\\"{x:1215,y:830,t:1527876775796};\\\", \\\"{x:1214,y:830,t:1527876775814};\\\", \\\"{x:1213,y:832,t:1527876775829};\\\", \\\"{x:1212,y:831,t:1527876776874};\\\", \\\"{x:1212,y:829,t:1527876776881};\\\", \\\"{x:1212,y:824,t:1527876776899};\\\", \\\"{x:1210,y:808,t:1527876776915};\\\", \\\"{x:1210,y:801,t:1527876776932};\\\", \\\"{x:1209,y:797,t:1527876776947};\\\", \\\"{x:1208,y:790,t:1527876776965};\\\", \\\"{x:1206,y:786,t:1527876776981};\\\", \\\"{x:1205,y:784,t:1527876776999};\\\", \\\"{x:1204,y:783,t:1527876777015};\\\", \\\"{x:1203,y:781,t:1527876777031};\\\", \\\"{x:1202,y:781,t:1527876777048};\\\", \\\"{x:1200,y:779,t:1527876777064};\\\", \\\"{x:1199,y:778,t:1527876777082};\\\", \\\"{x:1198,y:777,t:1527876777098};\\\", \\\"{x:1197,y:777,t:1527876777114};\\\", \\\"{x:1194,y:777,t:1527876777131};\\\", \\\"{x:1191,y:776,t:1527876777148};\\\", \\\"{x:1190,y:776,t:1527876777165};\\\", \\\"{x:1188,y:774,t:1527876777182};\\\", \\\"{x:1187,y:774,t:1527876777198};\\\", \\\"{x:1186,y:774,t:1527876777214};\\\", \\\"{x:1184,y:774,t:1527876777232};\\\", \\\"{x:1183,y:774,t:1527876777249};\\\", \\\"{x:1183,y:773,t:1527876777266};\\\", \\\"{x:1182,y:772,t:1527876777323};\\\", \\\"{x:1182,y:771,t:1527876777346};\\\", \\\"{x:1182,y:770,t:1527876777378};\\\", \\\"{x:1182,y:769,t:1527876777403};\\\", \\\"{x:1185,y:767,t:1527876777963};\\\", \\\"{x:1201,y:755,t:1527876777984};\\\", \\\"{x:1231,y:732,t:1527876778000};\\\", \\\"{x:1251,y:713,t:1527876778016};\\\", \\\"{x:1262,y:704,t:1527876778033};\\\", \\\"{x:1268,y:698,t:1527876778050};\\\", \\\"{x:1272,y:687,t:1527876778065};\\\", \\\"{x:1274,y:678,t:1527876778082};\\\", \\\"{x:1275,y:669,t:1527876778099};\\\", \\\"{x:1277,y:662,t:1527876778116};\\\", \\\"{x:1277,y:657,t:1527876778132};\\\", \\\"{x:1277,y:649,t:1527876778149};\\\", \\\"{x:1277,y:639,t:1527876778165};\\\", \\\"{x:1278,y:632,t:1527876778182};\\\", \\\"{x:1278,y:630,t:1527876778202};\\\", \\\"{x:1278,y:628,t:1527876778218};\\\", \\\"{x:1279,y:625,t:1527876778234};\\\", \\\"{x:1280,y:624,t:1527876778249};\\\", \\\"{x:1282,y:620,t:1527876778265};\\\", \\\"{x:1285,y:617,t:1527876778282};\\\", \\\"{x:1288,y:614,t:1527876778299};\\\", \\\"{x:1291,y:613,t:1527876778316};\\\", \\\"{x:1294,y:613,t:1527876778333};\\\", \\\"{x:1295,y:613,t:1527876778349};\\\", \\\"{x:1296,y:613,t:1527876778367};\\\", \\\"{x:1299,y:617,t:1527876778383};\\\", \\\"{x:1303,y:629,t:1527876778400};\\\", \\\"{x:1309,y:650,t:1527876778416};\\\", \\\"{x:1322,y:676,t:1527876778434};\\\", \\\"{x:1339,y:707,t:1527876778449};\\\", \\\"{x:1346,y:719,t:1527876778467};\\\", \\\"{x:1347,y:721,t:1527876778569};\\\", \\\"{x:1347,y:722,t:1527876778583};\\\", \\\"{x:1347,y:726,t:1527876778600};\\\", \\\"{x:1347,y:728,t:1527876778616};\\\", \\\"{x:1348,y:729,t:1527876778633};\\\", \\\"{x:1348,y:735,t:1527876778650};\\\", \\\"{x:1348,y:739,t:1527876778666};\\\", \\\"{x:1348,y:742,t:1527876778683};\\\", \\\"{x:1348,y:745,t:1527876778701};\\\", \\\"{x:1348,y:748,t:1527876778716};\\\", \\\"{x:1348,y:751,t:1527876778733};\\\", \\\"{x:1348,y:752,t:1527876778750};\\\", \\\"{x:1348,y:753,t:1527876778770};\\\", \\\"{x:1348,y:754,t:1527876778785};\\\", \\\"{x:1347,y:755,t:1527876778800};\\\", \\\"{x:1346,y:760,t:1527876778817};\\\", \\\"{x:1344,y:769,t:1527876778835};\\\", \\\"{x:1343,y:774,t:1527876778850};\\\", \\\"{x:1342,y:774,t:1527876778868};\\\", \\\"{x:1341,y:774,t:1527876779066};\\\", \\\"{x:1341,y:773,t:1527876779085};\\\", \\\"{x:1341,y:772,t:1527876779100};\\\", \\\"{x:1341,y:771,t:1527876779138};\\\", \\\"{x:1342,y:769,t:1527876779395};\\\", \\\"{x:1342,y:768,t:1527876779435};\\\", \\\"{x:1342,y:766,t:1527876779457};\\\", \\\"{x:1342,y:765,t:1527876779482};\\\", \\\"{x:1343,y:765,t:1527876779489};\\\", \\\"{x:1343,y:763,t:1527876779500};\\\", \\\"{x:1343,y:762,t:1527876779521};\\\", \\\"{x:1344,y:761,t:1527876779534};\\\", \\\"{x:1344,y:760,t:1527876779554};\\\", \\\"{x:1344,y:759,t:1527876779922};\\\", \\\"{x:1344,y:757,t:1527876779939};\\\", \\\"{x:1344,y:756,t:1527876780034};\\\", \\\"{x:1332,y:756,t:1527876780052};\\\", \\\"{x:1327,y:756,t:1527876780069};\\\", \\\"{x:1322,y:755,t:1527876780086};\\\", \\\"{x:1320,y:755,t:1527876780103};\\\", \\\"{x:1317,y:752,t:1527876780118};\\\", \\\"{x:1315,y:752,t:1527876780135};\\\", \\\"{x:1312,y:751,t:1527876780153};\\\", \\\"{x:1307,y:751,t:1527876780169};\\\", \\\"{x:1302,y:751,t:1527876780186};\\\", \\\"{x:1286,y:751,t:1527876780202};\\\", \\\"{x:1268,y:751,t:1527876780218};\\\", \\\"{x:1246,y:751,t:1527876780236};\\\", \\\"{x:1230,y:751,t:1527876780253};\\\", \\\"{x:1213,y:751,t:1527876780269};\\\", \\\"{x:1201,y:751,t:1527876780286};\\\", \\\"{x:1194,y:751,t:1527876780303};\\\", \\\"{x:1187,y:751,t:1527876780320};\\\", \\\"{x:1185,y:751,t:1527876780336};\\\", \\\"{x:1180,y:752,t:1527876780353};\\\", \\\"{x:1177,y:754,t:1527876780369};\\\", \\\"{x:1173,y:760,t:1527876780386};\\\", \\\"{x:1168,y:768,t:1527876780402};\\\", \\\"{x:1168,y:776,t:1527876780419};\\\", \\\"{x:1168,y:781,t:1527876780436};\\\", \\\"{x:1168,y:785,t:1527876780452};\\\", \\\"{x:1168,y:787,t:1527876780470};\\\", \\\"{x:1168,y:791,t:1527876780485};\\\", \\\"{x:1168,y:793,t:1527876780503};\\\", \\\"{x:1168,y:795,t:1527876780520};\\\", \\\"{x:1168,y:798,t:1527876780535};\\\", \\\"{x:1169,y:801,t:1527876780553};\\\", \\\"{x:1169,y:806,t:1527876780569};\\\", \\\"{x:1169,y:813,t:1527876780586};\\\", \\\"{x:1169,y:820,t:1527876780603};\\\", \\\"{x:1169,y:825,t:1527876780619};\\\", \\\"{x:1169,y:831,t:1527876780636};\\\", \\\"{x:1171,y:840,t:1527876780653};\\\", \\\"{x:1171,y:842,t:1527876780669};\\\", \\\"{x:1173,y:848,t:1527876780687};\\\", \\\"{x:1175,y:855,t:1527876780702};\\\", \\\"{x:1178,y:863,t:1527876780719};\\\", \\\"{x:1179,y:869,t:1527876780736};\\\", \\\"{x:1182,y:873,t:1527876780753};\\\", \\\"{x:1182,y:876,t:1527876780770};\\\", \\\"{x:1185,y:879,t:1527876780786};\\\", \\\"{x:1187,y:879,t:1527876780826};\\\", \\\"{x:1188,y:879,t:1527876780836};\\\", \\\"{x:1192,y:879,t:1527876780854};\\\", \\\"{x:1194,y:879,t:1527876780870};\\\", \\\"{x:1195,y:879,t:1527876780887};\\\", \\\"{x:1197,y:879,t:1527876780930};\\\", \\\"{x:1199,y:879,t:1527876780945};\\\", \\\"{x:1203,y:877,t:1527876780953};\\\", \\\"{x:1214,y:869,t:1527876780969};\\\", \\\"{x:1225,y:858,t:1527876780986};\\\", \\\"{x:1238,y:847,t:1527876781003};\\\", \\\"{x:1245,y:840,t:1527876781019};\\\", \\\"{x:1254,y:834,t:1527876781036};\\\", \\\"{x:1261,y:830,t:1527876781053};\\\", \\\"{x:1264,y:828,t:1527876781070};\\\", \\\"{x:1266,y:827,t:1527876781086};\\\", \\\"{x:1268,y:827,t:1527876781103};\\\", \\\"{x:1272,y:826,t:1527876781120};\\\", \\\"{x:1278,y:823,t:1527876781136};\\\", \\\"{x:1289,y:821,t:1527876781153};\\\", \\\"{x:1297,y:819,t:1527876781170};\\\", \\\"{x:1299,y:819,t:1527876781187};\\\", \\\"{x:1300,y:819,t:1527876781204};\\\", \\\"{x:1302,y:818,t:1527876781220};\\\", \\\"{x:1305,y:817,t:1527876781236};\\\", \\\"{x:1309,y:813,t:1527876781253};\\\", \\\"{x:1316,y:806,t:1527876781271};\\\", \\\"{x:1323,y:799,t:1527876781287};\\\", \\\"{x:1329,y:793,t:1527876781304};\\\", \\\"{x:1336,y:782,t:1527876781321};\\\", \\\"{x:1341,y:775,t:1527876781336};\\\", \\\"{x:1346,y:762,t:1527876781354};\\\", \\\"{x:1351,y:753,t:1527876781371};\\\", \\\"{x:1354,y:740,t:1527876781388};\\\", \\\"{x:1357,y:727,t:1527876781404};\\\", \\\"{x:1361,y:713,t:1527876781420};\\\", \\\"{x:1365,y:700,t:1527876781437};\\\", \\\"{x:1367,y:691,t:1527876781454};\\\", \\\"{x:1370,y:686,t:1527876781470};\\\", \\\"{x:1371,y:682,t:1527876781488};\\\", \\\"{x:1374,y:673,t:1527876781503};\\\", \\\"{x:1376,y:660,t:1527876781520};\\\", \\\"{x:1385,y:626,t:1527876781538};\\\", \\\"{x:1392,y:604,t:1527876781554};\\\", \\\"{x:1396,y:591,t:1527876781571};\\\", \\\"{x:1397,y:586,t:1527876781588};\\\", \\\"{x:1398,y:579,t:1527876781604};\\\", \\\"{x:1398,y:568,t:1527876781621};\\\", \\\"{x:1398,y:556,t:1527876781637};\\\", \\\"{x:1398,y:548,t:1527876781655};\\\", \\\"{x:1398,y:547,t:1527876781671};\\\", \\\"{x:1398,y:544,t:1527876781687};\\\", \\\"{x:1396,y:542,t:1527876781705};\\\", \\\"{x:1393,y:540,t:1527876781721};\\\", \\\"{x:1382,y:539,t:1527876781738};\\\", \\\"{x:1364,y:539,t:1527876781754};\\\", \\\"{x:1343,y:539,t:1527876781771};\\\", \\\"{x:1324,y:539,t:1527876781788};\\\", \\\"{x:1311,y:539,t:1527876781804};\\\", \\\"{x:1304,y:539,t:1527876781820};\\\", \\\"{x:1300,y:539,t:1527876781838};\\\", \\\"{x:1299,y:539,t:1527876781854};\\\", \\\"{x:1298,y:539,t:1527876781898};\\\", \\\"{x:1297,y:540,t:1527876781946};\\\", \\\"{x:1296,y:542,t:1527876781954};\\\", \\\"{x:1295,y:549,t:1527876781971};\\\", \\\"{x:1293,y:552,t:1527876781988};\\\", \\\"{x:1293,y:554,t:1527876782005};\\\", \\\"{x:1292,y:555,t:1527876782082};\\\", \\\"{x:1289,y:557,t:1527876782098};\\\", \\\"{x:1288,y:557,t:1527876782106};\\\", \\\"{x:1286,y:559,t:1527876782122};\\\", \\\"{x:1285,y:559,t:1527876782155};\\\", \\\"{x:1283,y:559,t:1527876782194};\\\", \\\"{x:1282,y:559,t:1527876782218};\\\", \\\"{x:1281,y:559,t:1527876782226};\\\", \\\"{x:1280,y:559,t:1527876782239};\\\", \\\"{x:1280,y:567,t:1527876784906};\\\", \\\"{x:1292,y:583,t:1527876784915};\\\", \\\"{x:1311,y:602,t:1527876784925};\\\", \\\"{x:1349,y:636,t:1527876784942};\\\", \\\"{x:1380,y:655,t:1527876784959};\\\", \\\"{x:1403,y:665,t:1527876784976};\\\", \\\"{x:1416,y:670,t:1527876784991};\\\", \\\"{x:1425,y:676,t:1527876785009};\\\", \\\"{x:1437,y:682,t:1527876785026};\\\", \\\"{x:1444,y:692,t:1527876785042};\\\", \\\"{x:1451,y:705,t:1527876785059};\\\", \\\"{x:1457,y:720,t:1527876785075};\\\", \\\"{x:1463,y:736,t:1527876785091};\\\", \\\"{x:1468,y:755,t:1527876785108};\\\", \\\"{x:1470,y:776,t:1527876785125};\\\", \\\"{x:1475,y:797,t:1527876785141};\\\", \\\"{x:1477,y:811,t:1527876785158};\\\", \\\"{x:1480,y:823,t:1527876785175};\\\", \\\"{x:1486,y:840,t:1527876785192};\\\", \\\"{x:1491,y:853,t:1527876785209};\\\", \\\"{x:1496,y:860,t:1527876785225};\\\", \\\"{x:1497,y:860,t:1527876785298};\\\", \\\"{x:1498,y:860,t:1527876785309};\\\", \\\"{x:1500,y:859,t:1527876785325};\\\", \\\"{x:1506,y:854,t:1527876785343};\\\", \\\"{x:1511,y:848,t:1527876785358};\\\", \\\"{x:1516,y:841,t:1527876785375};\\\", \\\"{x:1522,y:832,t:1527876785392};\\\", \\\"{x:1526,y:819,t:1527876785409};\\\", \\\"{x:1526,y:814,t:1527876785425};\\\", \\\"{x:1526,y:810,t:1527876785443};\\\", \\\"{x:1526,y:807,t:1527876785459};\\\", \\\"{x:1526,y:802,t:1527876785476};\\\", \\\"{x:1526,y:798,t:1527876785492};\\\", \\\"{x:1524,y:794,t:1527876785509};\\\", \\\"{x:1524,y:791,t:1527876785525};\\\", \\\"{x:1524,y:789,t:1527876785542};\\\", \\\"{x:1523,y:787,t:1527876785559};\\\", \\\"{x:1523,y:786,t:1527876785576};\\\", \\\"{x:1522,y:784,t:1527876785593};\\\", \\\"{x:1521,y:782,t:1527876785610};\\\", \\\"{x:1521,y:780,t:1527876785625};\\\", \\\"{x:1520,y:779,t:1527876785643};\\\", \\\"{x:1520,y:778,t:1527876785660};\\\", \\\"{x:1520,y:776,t:1527876785677};\\\", \\\"{x:1520,y:775,t:1527876785698};\\\", \\\"{x:1519,y:774,t:1527876785711};\\\", \\\"{x:1519,y:773,t:1527876785727};\\\", \\\"{x:1519,y:771,t:1527876785743};\\\", \\\"{x:1518,y:769,t:1527876785760};\\\", \\\"{x:1518,y:765,t:1527876785777};\\\", \\\"{x:1518,y:762,t:1527876785792};\\\", \\\"{x:1517,y:758,t:1527876785810};\\\", \\\"{x:1517,y:757,t:1527876785828};\\\", \\\"{x:1517,y:756,t:1527876785842};\\\", \\\"{x:1517,y:755,t:1527876785866};\\\", \\\"{x:1516,y:754,t:1527876786082};\\\", \\\"{x:1516,y:753,t:1527876786106};\\\", \\\"{x:1515,y:753,t:1527876786138};\\\", \\\"{x:1514,y:752,t:1527876786146};\\\", \\\"{x:1513,y:750,t:1527876786178};\\\", \\\"{x:1512,y:750,t:1527876786210};\\\", \\\"{x:1511,y:749,t:1527876786234};\\\", \\\"{x:1510,y:749,t:1527876786249};\\\", \\\"{x:1510,y:747,t:1527876786265};\\\", \\\"{x:1508,y:747,t:1527876786282};\\\", \\\"{x:1507,y:746,t:1527876786458};\\\", \\\"{x:1506,y:745,t:1527876786466};\\\", \\\"{x:1505,y:743,t:1527876786478};\\\", \\\"{x:1502,y:738,t:1527876786494};\\\", \\\"{x:1501,y:736,t:1527876786510};\\\", \\\"{x:1501,y:735,t:1527876786530};\\\", \\\"{x:1500,y:733,t:1527876786544};\\\", \\\"{x:1499,y:733,t:1527876786562};\\\", \\\"{x:1499,y:732,t:1527876786578};\\\", \\\"{x:1498,y:731,t:1527876786602};\\\", \\\"{x:1498,y:730,t:1527876786626};\\\", \\\"{x:1497,y:726,t:1527876787187};\\\", \\\"{x:1495,y:723,t:1527876787195};\\\", \\\"{x:1491,y:714,t:1527876787212};\\\", \\\"{x:1486,y:705,t:1527876787229};\\\", \\\"{x:1481,y:695,t:1527876787245};\\\", \\\"{x:1479,y:689,t:1527876787262};\\\", \\\"{x:1474,y:680,t:1527876787279};\\\", \\\"{x:1467,y:666,t:1527876787295};\\\", \\\"{x:1459,y:650,t:1527876787312};\\\", \\\"{x:1454,y:638,t:1527876787328};\\\", \\\"{x:1449,y:626,t:1527876787345};\\\", \\\"{x:1446,y:616,t:1527876787363};\\\", \\\"{x:1444,y:613,t:1527876787378};\\\", \\\"{x:1443,y:608,t:1527876787396};\\\", \\\"{x:1441,y:604,t:1527876787412};\\\", \\\"{x:1441,y:601,t:1527876787429};\\\", \\\"{x:1439,y:599,t:1527876787445};\\\", \\\"{x:1437,y:594,t:1527876787462};\\\", \\\"{x:1434,y:591,t:1527876787479};\\\", \\\"{x:1433,y:588,t:1527876787496};\\\", \\\"{x:1430,y:586,t:1527876787512};\\\", \\\"{x:1426,y:583,t:1527876787529};\\\", \\\"{x:1421,y:580,t:1527876787546};\\\", \\\"{x:1418,y:577,t:1527876787561};\\\", \\\"{x:1417,y:576,t:1527876787579};\\\", \\\"{x:1414,y:573,t:1527876787596};\\\", \\\"{x:1413,y:572,t:1527876787612};\\\", \\\"{x:1412,y:571,t:1527876787629};\\\", \\\"{x:1412,y:570,t:1527876787646};\\\", \\\"{x:1412,y:569,t:1527876789266};\\\", \\\"{x:1412,y:568,t:1527876789282};\\\", \\\"{x:1414,y:566,t:1527876789298};\\\", \\\"{x:1415,y:566,t:1527876789315};\\\", \\\"{x:1415,y:565,t:1527876789337};\\\", \\\"{x:1416,y:564,t:1527876789466};\\\", \\\"{x:1414,y:568,t:1527876791906};\\\", \\\"{x:1411,y:572,t:1527876791919};\\\", \\\"{x:1406,y:578,t:1527876791935};\\\", \\\"{x:1404,y:580,t:1527876791951};\\\", \\\"{x:1404,y:581,t:1527876791978};\\\", \\\"{x:1404,y:582,t:1527876791994};\\\", \\\"{x:1404,y:583,t:1527876792002};\\\", \\\"{x:1403,y:584,t:1527876792018};\\\", \\\"{x:1402,y:586,t:1527876792035};\\\", \\\"{x:1402,y:587,t:1527876792051};\\\", \\\"{x:1402,y:590,t:1527876792068};\\\", \\\"{x:1401,y:592,t:1527876792085};\\\", \\\"{x:1401,y:597,t:1527876792102};\\\", \\\"{x:1400,y:600,t:1527876792118};\\\", \\\"{x:1398,y:609,t:1527876792135};\\\", \\\"{x:1394,y:620,t:1527876792152};\\\", \\\"{x:1391,y:633,t:1527876792168};\\\", \\\"{x:1387,y:646,t:1527876792186};\\\", \\\"{x:1375,y:682,t:1527876792201};\\\", \\\"{x:1360,y:718,t:1527876792218};\\\", \\\"{x:1349,y:743,t:1527876792235};\\\", \\\"{x:1342,y:761,t:1527876792252};\\\", \\\"{x:1340,y:766,t:1527876792268};\\\", \\\"{x:1338,y:769,t:1527876792285};\\\", \\\"{x:1335,y:775,t:1527876792302};\\\", \\\"{x:1332,y:780,t:1527876792319};\\\", \\\"{x:1330,y:784,t:1527876792335};\\\", \\\"{x:1327,y:788,t:1527876792353};\\\", \\\"{x:1324,y:794,t:1527876792370};\\\", \\\"{x:1319,y:803,t:1527876792385};\\\", \\\"{x:1307,y:819,t:1527876792402};\\\", \\\"{x:1303,y:824,t:1527876792419};\\\", \\\"{x:1297,y:830,t:1527876792435};\\\", \\\"{x:1294,y:836,t:1527876792452};\\\", \\\"{x:1290,y:840,t:1527876792469};\\\", \\\"{x:1286,y:845,t:1527876792485};\\\", \\\"{x:1282,y:850,t:1527876792502};\\\", \\\"{x:1277,y:859,t:1527876792519};\\\", \\\"{x:1273,y:864,t:1527876792535};\\\", \\\"{x:1270,y:869,t:1527876792552};\\\", \\\"{x:1268,y:875,t:1527876792569};\\\", \\\"{x:1262,y:891,t:1527876792586};\\\", \\\"{x:1259,y:898,t:1527876792602};\\\", \\\"{x:1254,y:908,t:1527876792620};\\\", \\\"{x:1249,y:919,t:1527876792637};\\\", \\\"{x:1245,y:926,t:1527876792652};\\\", \\\"{x:1241,y:931,t:1527876792669};\\\", \\\"{x:1239,y:935,t:1527876792686};\\\", \\\"{x:1237,y:939,t:1527876792702};\\\", \\\"{x:1235,y:945,t:1527876792719};\\\", \\\"{x:1232,y:949,t:1527876792736};\\\", \\\"{x:1228,y:954,t:1527876792752};\\\", \\\"{x:1226,y:957,t:1527876792769};\\\", \\\"{x:1220,y:963,t:1527876792786};\\\", \\\"{x:1219,y:964,t:1527876792802};\\\", \\\"{x:1218,y:965,t:1527876792819};\\\", \\\"{x:1218,y:966,t:1527876792842};\\\", \\\"{x:1219,y:966,t:1527876792994};\\\", \\\"{x:1225,y:963,t:1527876793003};\\\", \\\"{x:1241,y:952,t:1527876793020};\\\", \\\"{x:1263,y:943,t:1527876793036};\\\", \\\"{x:1277,y:938,t:1527876793053};\\\", \\\"{x:1282,y:937,t:1527876793070};\\\", \\\"{x:1283,y:937,t:1527876793086};\\\", \\\"{x:1283,y:938,t:1527876793130};\\\", \\\"{x:1283,y:941,t:1527876793138};\\\", \\\"{x:1284,y:945,t:1527876793153};\\\", \\\"{x:1285,y:954,t:1527876793170};\\\", \\\"{x:1286,y:957,t:1527876793186};\\\", \\\"{x:1286,y:962,t:1527876793203};\\\", \\\"{x:1286,y:967,t:1527876793220};\\\", \\\"{x:1286,y:970,t:1527876793237};\\\", \\\"{x:1286,y:972,t:1527876793253};\\\", \\\"{x:1286,y:973,t:1527876793270};\\\", \\\"{x:1287,y:973,t:1527876793298};\\\", \\\"{x:1291,y:970,t:1527876793313};\\\", \\\"{x:1291,y:968,t:1527876793322};\\\", \\\"{x:1293,y:965,t:1527876793336};\\\", \\\"{x:1301,y:956,t:1527876793354};\\\", \\\"{x:1308,y:950,t:1527876793369};\\\", \\\"{x:1314,y:948,t:1527876793387};\\\", \\\"{x:1318,y:947,t:1527876793403};\\\", \\\"{x:1323,y:947,t:1527876793420};\\\", \\\"{x:1326,y:947,t:1527876793437};\\\", \\\"{x:1329,y:947,t:1527876793453};\\\", \\\"{x:1330,y:947,t:1527876793470};\\\", \\\"{x:1332,y:947,t:1527876793487};\\\", \\\"{x:1333,y:950,t:1527876793503};\\\", \\\"{x:1333,y:955,t:1527876793520};\\\", \\\"{x:1334,y:957,t:1527876793537};\\\", \\\"{x:1336,y:959,t:1527876793554};\\\", \\\"{x:1338,y:966,t:1527876793570};\\\", \\\"{x:1338,y:970,t:1527876793587};\\\", \\\"{x:1340,y:973,t:1527876793604};\\\", \\\"{x:1340,y:974,t:1527876793682};\\\", \\\"{x:1342,y:974,t:1527876793690};\\\", \\\"{x:1345,y:973,t:1527876793704};\\\", \\\"{x:1353,y:968,t:1527876793720};\\\", \\\"{x:1364,y:962,t:1527876793738};\\\", \\\"{x:1389,y:953,t:1527876793754};\\\", \\\"{x:1401,y:950,t:1527876793770};\\\", \\\"{x:1408,y:948,t:1527876793787};\\\", \\\"{x:1411,y:948,t:1527876793804};\\\", \\\"{x:1412,y:948,t:1527876793866};\\\", \\\"{x:1414,y:949,t:1527876793873};\\\", \\\"{x:1414,y:950,t:1527876793890};\\\", \\\"{x:1414,y:953,t:1527876793905};\\\", \\\"{x:1414,y:955,t:1527876793921};\\\", \\\"{x:1414,y:958,t:1527876793937};\\\", \\\"{x:1414,y:960,t:1527876793954};\\\", \\\"{x:1414,y:961,t:1527876794010};\\\", \\\"{x:1414,y:962,t:1527876794074};\\\", \\\"{x:1416,y:962,t:1527876794155};\\\", \\\"{x:1424,y:958,t:1527876794171};\\\", \\\"{x:1434,y:952,t:1527876794188};\\\", \\\"{x:1446,y:949,t:1527876794204};\\\", \\\"{x:1456,y:946,t:1527876794221};\\\", \\\"{x:1462,y:946,t:1527876794238};\\\", \\\"{x:1465,y:946,t:1527876794254};\\\", \\\"{x:1466,y:946,t:1527876794271};\\\", \\\"{x:1468,y:947,t:1527876794289};\\\", \\\"{x:1469,y:947,t:1527876794306};\\\", \\\"{x:1469,y:948,t:1527876794321};\\\", \\\"{x:1469,y:949,t:1527876794338};\\\", \\\"{x:1470,y:952,t:1527876794355};\\\", \\\"{x:1471,y:954,t:1527876794371};\\\", \\\"{x:1472,y:957,t:1527876794388};\\\", \\\"{x:1473,y:958,t:1527876794405};\\\", \\\"{x:1473,y:959,t:1527876794421};\\\", \\\"{x:1475,y:961,t:1527876794438};\\\", \\\"{x:1476,y:963,t:1527876794482};\\\", \\\"{x:1478,y:963,t:1527876794778};\\\", \\\"{x:1479,y:963,t:1527876794788};\\\", \\\"{x:1486,y:962,t:1527876794806};\\\", \\\"{x:1492,y:959,t:1527876794822};\\\", \\\"{x:1500,y:953,t:1527876794838};\\\", \\\"{x:1508,y:949,t:1527876794855};\\\", \\\"{x:1518,y:944,t:1527876794872};\\\", \\\"{x:1525,y:942,t:1527876794889};\\\", \\\"{x:1526,y:942,t:1527876794905};\\\", \\\"{x:1527,y:942,t:1527876794921};\\\", \\\"{x:1528,y:942,t:1527876794945};\\\", \\\"{x:1529,y:942,t:1527876794955};\\\", \\\"{x:1530,y:942,t:1527876794972};\\\", \\\"{x:1536,y:948,t:1527876794989};\\\", \\\"{x:1538,y:951,t:1527876795005};\\\", \\\"{x:1541,y:956,t:1527876795022};\\\", \\\"{x:1542,y:958,t:1527876795039};\\\", \\\"{x:1544,y:961,t:1527876795056};\\\", \\\"{x:1545,y:963,t:1527876795072};\\\", \\\"{x:1545,y:964,t:1527876795098};\\\", \\\"{x:1545,y:965,t:1527876795139};\\\", \\\"{x:1545,y:966,t:1527876795155};\\\", \\\"{x:1545,y:967,t:1527876795172};\\\", \\\"{x:1546,y:967,t:1527876795250};\\\", \\\"{x:1547,y:966,t:1527876795258};\\\", \\\"{x:1548,y:965,t:1527876795272};\\\", \\\"{x:1553,y:958,t:1527876795289};\\\", \\\"{x:1568,y:949,t:1527876795305};\\\", \\\"{x:1583,y:941,t:1527876795322};\\\", \\\"{x:1603,y:932,t:1527876795340};\\\", \\\"{x:1618,y:928,t:1527876795356};\\\", \\\"{x:1629,y:925,t:1527876795373};\\\", \\\"{x:1631,y:924,t:1527876795389};\\\", \\\"{x:1623,y:924,t:1527876795425};\\\", \\\"{x:1600,y:924,t:1527876795439};\\\", \\\"{x:1471,y:904,t:1527876795457};\\\", \\\"{x:1410,y:889,t:1527876795473};\\\", \\\"{x:1294,y:860,t:1527876795489};\\\", \\\"{x:1134,y:813,t:1527876795506};\\\", \\\"{x:1031,y:783,t:1527876795523};\\\", \\\"{x:931,y:732,t:1527876795539};\\\", \\\"{x:824,y:674,t:1527876795556};\\\", \\\"{x:735,y:626,t:1527876795574};\\\", \\\"{x:660,y:592,t:1527876795590};\\\", \\\"{x:611,y:573,t:1527876795605};\\\", \\\"{x:576,y:561,t:1527876795633};\\\", \\\"{x:563,y:556,t:1527876795648};\\\", \\\"{x:541,y:546,t:1527876795667};\\\", \\\"{x:535,y:545,t:1527876795683};\\\", \\\"{x:525,y:543,t:1527876795700};\\\", \\\"{x:509,y:542,t:1527876795716};\\\", \\\"{x:490,y:542,t:1527876795734};\\\", \\\"{x:472,y:542,t:1527876795750};\\\", \\\"{x:453,y:542,t:1527876795766};\\\", \\\"{x:435,y:546,t:1527876795783};\\\", \\\"{x:417,y:551,t:1527876795800};\\\", \\\"{x:403,y:555,t:1527876795817};\\\", \\\"{x:382,y:559,t:1527876795834};\\\", \\\"{x:364,y:559,t:1527876795850};\\\", \\\"{x:341,y:559,t:1527876795866};\\\", \\\"{x:319,y:559,t:1527876795884};\\\", \\\"{x:300,y:559,t:1527876795901};\\\", \\\"{x:282,y:559,t:1527876795918};\\\", \\\"{x:266,y:559,t:1527876795933};\\\", \\\"{x:249,y:559,t:1527876795951};\\\", \\\"{x:237,y:559,t:1527876795968};\\\", \\\"{x:227,y:560,t:1527876795984};\\\", \\\"{x:224,y:560,t:1527876796001};\\\", \\\"{x:221,y:561,t:1527876796018};\\\", \\\"{x:220,y:561,t:1527876796034};\\\", \\\"{x:219,y:561,t:1527876796098};\\\", \\\"{x:217,y:560,t:1527876796105};\\\", \\\"{x:216,y:559,t:1527876796122};\\\", \\\"{x:213,y:558,t:1527876796135};\\\", \\\"{x:211,y:558,t:1527876796151};\\\", \\\"{x:208,y:558,t:1527876796168};\\\", \\\"{x:207,y:558,t:1527876796193};\\\", \\\"{x:213,y:561,t:1527876796201};\\\", \\\"{x:275,y:574,t:1527876796219};\\\", \\\"{x:385,y:584,t:1527876796234};\\\", \\\"{x:483,y:588,t:1527876796251};\\\", \\\"{x:547,y:588,t:1527876796268};\\\", \\\"{x:603,y:588,t:1527876796283};\\\", \\\"{x:630,y:588,t:1527876796300};\\\", \\\"{x:633,y:590,t:1527876796318};\\\", \\\"{x:635,y:590,t:1527876796385};\\\", \\\"{x:638,y:590,t:1527876796400};\\\", \\\"{x:647,y:587,t:1527876796417};\\\", \\\"{x:652,y:582,t:1527876796435};\\\", \\\"{x:660,y:576,t:1527876796451};\\\", \\\"{x:683,y:571,t:1527876796467};\\\", \\\"{x:721,y:565,t:1527876796484};\\\", \\\"{x:780,y:555,t:1527876796503};\\\", \\\"{x:845,y:545,t:1527876796518};\\\", \\\"{x:889,y:534,t:1527876796535};\\\", \\\"{x:908,y:529,t:1527876796550};\\\", \\\"{x:912,y:527,t:1527876796567};\\\", \\\"{x:913,y:527,t:1527876796583};\\\", \\\"{x:911,y:527,t:1527876796674};\\\", \\\"{x:907,y:527,t:1527876796684};\\\", \\\"{x:893,y:527,t:1527876796701};\\\", \\\"{x:876,y:527,t:1527876796718};\\\", \\\"{x:859,y:527,t:1527876796734};\\\", \\\"{x:847,y:530,t:1527876796752};\\\", \\\"{x:838,y:532,t:1527876796768};\\\", \\\"{x:836,y:533,t:1527876796785};\\\", \\\"{x:835,y:533,t:1527876796801};\\\", \\\"{x:834,y:533,t:1527876796818};\\\", \\\"{x:834,y:534,t:1527876796913};\\\", \\\"{x:834,y:535,t:1527876796937};\\\", \\\"{x:834,y:536,t:1527876796951};\\\", \\\"{x:834,y:537,t:1527876796968};\\\", \\\"{x:828,y:544,t:1527876797169};\\\", \\\"{x:819,y:551,t:1527876797185};\\\", \\\"{x:788,y:582,t:1527876797203};\\\", \\\"{x:762,y:600,t:1527876797218};\\\", \\\"{x:735,y:614,t:1527876797235};\\\", \\\"{x:715,y:629,t:1527876797253};\\\", \\\"{x:696,y:641,t:1527876797268};\\\", \\\"{x:687,y:647,t:1527876797284};\\\", \\\"{x:677,y:652,t:1527876797302};\\\", \\\"{x:669,y:657,t:1527876797317};\\\", \\\"{x:659,y:664,t:1527876797335};\\\", \\\"{x:646,y:672,t:1527876797351};\\\", \\\"{x:635,y:682,t:1527876797367};\\\", \\\"{x:626,y:688,t:1527876797384};\\\", \\\"{x:625,y:688,t:1527876797401};\\\", \\\"{x:624,y:689,t:1527876797425};\\\", \\\"{x:623,y:690,t:1527876797435};\\\", \\\"{x:615,y:697,t:1527876797452};\\\", \\\"{x:605,y:704,t:1527876797468};\\\", \\\"{x:590,y:712,t:1527876797485};\\\", \\\"{x:576,y:718,t:1527876797502};\\\", \\\"{x:561,y:724,t:1527876797520};\\\", \\\"{x:549,y:726,t:1527876797535};\\\", \\\"{x:544,y:727,t:1527876797552};\\\", \\\"{x:541,y:728,t:1527876797568};\\\", \\\"{x:534,y:729,t:1527876797585};\\\", \\\"{x:528,y:731,t:1527876797601};\\\", \\\"{x:514,y:737,t:1527876797618};\\\", \\\"{x:502,y:745,t:1527876797635};\\\", \\\"{x:493,y:751,t:1527876797652};\\\", \\\"{x:486,y:756,t:1527876797669};\\\", \\\"{x:486,y:755,t:1527876797978};\\\", \\\"{x:487,y:753,t:1527876797986};\\\", \\\"{x:489,y:749,t:1527876798002};\\\", \\\"{x:490,y:747,t:1527876798019};\\\", \\\"{x:491,y:747,t:1527876798305};\\\", \\\"{x:493,y:747,t:1527876798319};\\\", \\\"{x:494,y:747,t:1527876798336};\\\", \\\"{x:496,y:747,t:1527876798786};\\\", \\\"{x:511,y:734,t:1527876798803};\\\", \\\"{x:529,y:732,t:1527876798819};\\\", \\\"{x:555,y:732,t:1527876798836};\\\", \\\"{x:588,y:721,t:1527876798853};\\\", \\\"{x:619,y:714,t:1527876798869};\\\", \\\"{x:646,y:707,t:1527876798886};\\\", \\\"{x:671,y:698,t:1527876798903};\\\", \\\"{x:689,y:692,t:1527876798919};\\\", \\\"{x:709,y:685,t:1527876798936};\\\", \\\"{x:735,y:674,t:1527876798953};\\\", \\\"{x:752,y:669,t:1527876798970};\\\", \\\"{x:770,y:663,t:1527876798985};\\\", \\\"{x:789,y:658,t:1527876799003};\\\", \\\"{x:803,y:655,t:1527876799020};\\\", \\\"{x:818,y:655,t:1527876799036};\\\", \\\"{x:824,y:654,t:1527876799053};\\\", \\\"{x:832,y:653,t:1527876799070};\\\", \\\"{x:836,y:652,t:1527876799086};\\\", \\\"{x:838,y:652,t:1527876799103};\\\", \\\"{x:839,y:652,t:1527876799129};\\\", \\\"{x:840,y:652,t:1527876799161};\\\", \\\"{x:847,y:650,t:1527876799237};\\\", \\\"{x:849,y:649,t:1527876799252};\\\", \\\"{x:855,y:647,t:1527876799269};\\\", \\\"{x:864,y:644,t:1527876799286};\\\", \\\"{x:871,y:642,t:1527876799303};\\\" ] }, { \\\"rt\\\": 30546, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 442376, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -X -X -B -B -J -B -B -I -I -11 AM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:918,y:631,t:1527876799426};\\\", \\\"{x:920,y:630,t:1527876799435};\\\", \\\"{x:922,y:630,t:1527876799452};\\\", \\\"{x:923,y:629,t:1527876800105};\\\", \\\"{x:923,y:628,t:1527876800137};\\\", \\\"{x:913,y:625,t:1527876800154};\\\", \\\"{x:889,y:618,t:1527876800171};\\\", \\\"{x:872,y:614,t:1527876800187};\\\", \\\"{x:845,y:606,t:1527876800205};\\\", \\\"{x:823,y:599,t:1527876800221};\\\", \\\"{x:796,y:592,t:1527876800237};\\\", \\\"{x:765,y:582,t:1527876800253};\\\", \\\"{x:737,y:576,t:1527876800271};\\\", \\\"{x:699,y:568,t:1527876800287};\\\", \\\"{x:664,y:562,t:1527876800304};\\\", \\\"{x:620,y:551,t:1527876800321};\\\", \\\"{x:596,y:543,t:1527876800337};\\\", \\\"{x:575,y:538,t:1527876800354};\\\", \\\"{x:554,y:531,t:1527876800371};\\\", \\\"{x:533,y:525,t:1527876800386};\\\", \\\"{x:517,y:521,t:1527876800404};\\\", \\\"{x:505,y:516,t:1527876800421};\\\", \\\"{x:487,y:512,t:1527876800438};\\\", \\\"{x:471,y:506,t:1527876800453};\\\", \\\"{x:460,y:502,t:1527876800471};\\\", \\\"{x:441,y:497,t:1527876800487};\\\", \\\"{x:423,y:492,t:1527876800503};\\\", \\\"{x:405,y:487,t:1527876800520};\\\", \\\"{x:404,y:487,t:1527876800537};\\\", \\\"{x:403,y:486,t:1527876800603};\\\", \\\"{x:403,y:485,t:1527876800666};\\\", \\\"{x:403,y:484,t:1527876800673};\\\", \\\"{x:401,y:480,t:1527876800689};\\\", \\\"{x:400,y:480,t:1527876800704};\\\", \\\"{x:393,y:475,t:1527876800722};\\\", \\\"{x:387,y:471,t:1527876800738};\\\", \\\"{x:377,y:467,t:1527876800755};\\\", \\\"{x:368,y:463,t:1527876800771};\\\", \\\"{x:363,y:462,t:1527876800788};\\\", \\\"{x:357,y:459,t:1527876800804};\\\", \\\"{x:352,y:458,t:1527876800821};\\\", \\\"{x:349,y:457,t:1527876800839};\\\", \\\"{x:348,y:457,t:1527876800854};\\\", \\\"{x:347,y:457,t:1527876800871};\\\", \\\"{x:346,y:457,t:1527876800969};\\\", \\\"{x:348,y:457,t:1527876801578};\\\", \\\"{x:351,y:457,t:1527876801589};\\\", \\\"{x:356,y:457,t:1527876801605};\\\", \\\"{x:362,y:457,t:1527876801622};\\\", \\\"{x:363,y:457,t:1527876801639};\\\", \\\"{x:366,y:457,t:1527876801655};\\\", \\\"{x:370,y:457,t:1527876801672};\\\", \\\"{x:378,y:458,t:1527876801689};\\\", \\\"{x:379,y:459,t:1527876801705};\\\", \\\"{x:381,y:459,t:1527876801778};\\\", \\\"{x:385,y:460,t:1527876801789};\\\", \\\"{x:397,y:464,t:1527876801805};\\\", \\\"{x:410,y:465,t:1527876801822};\\\", \\\"{x:435,y:469,t:1527876801839};\\\", \\\"{x:459,y:471,t:1527876801855};\\\", \\\"{x:482,y:475,t:1527876801872};\\\", \\\"{x:503,y:479,t:1527876801889};\\\", \\\"{x:507,y:479,t:1527876801906};\\\", \\\"{x:509,y:479,t:1527876801977};\\\", \\\"{x:511,y:479,t:1527876801989};\\\", \\\"{x:519,y:479,t:1527876802006};\\\", \\\"{x:537,y:481,t:1527876802022};\\\", \\\"{x:557,y:483,t:1527876802039};\\\", \\\"{x:577,y:486,t:1527876802056};\\\", \\\"{x:587,y:487,t:1527876802073};\\\", \\\"{x:608,y:491,t:1527876802089};\\\", \\\"{x:613,y:491,t:1527876802105};\\\", \\\"{x:615,y:491,t:1527876802122};\\\", \\\"{x:611,y:491,t:1527876802458};\\\", \\\"{x:610,y:491,t:1527876802472};\\\", \\\"{x:600,y:491,t:1527876802489};\\\", \\\"{x:594,y:489,t:1527876802506};\\\", \\\"{x:589,y:489,t:1527876802522};\\\", \\\"{x:586,y:488,t:1527876802539};\\\", \\\"{x:582,y:486,t:1527876802556};\\\", \\\"{x:580,y:486,t:1527876802572};\\\", \\\"{x:578,y:486,t:1527876802588};\\\", \\\"{x:577,y:485,t:1527876802606};\\\", \\\"{x:573,y:484,t:1527876802622};\\\", \\\"{x:569,y:481,t:1527876802639};\\\", \\\"{x:566,y:481,t:1527876802656};\\\", \\\"{x:563,y:480,t:1527876802671};\\\", \\\"{x:561,y:479,t:1527876802689};\\\", \\\"{x:560,y:478,t:1527876802706};\\\", \\\"{x:559,y:478,t:1527876802729};\\\", \\\"{x:558,y:478,t:1527876802739};\\\", \\\"{x:557,y:478,t:1527876802756};\\\", \\\"{x:557,y:476,t:1527876803145};\\\", \\\"{x:561,y:473,t:1527876803156};\\\", \\\"{x:567,y:469,t:1527876803173};\\\", \\\"{x:568,y:467,t:1527876803190};\\\", \\\"{x:570,y:462,t:1527876803206};\\\", \\\"{x:572,y:459,t:1527876803223};\\\", \\\"{x:573,y:457,t:1527876803241};\\\", \\\"{x:573,y:456,t:1527876803257};\\\", \\\"{x:578,y:455,t:1527876803274};\\\", \\\"{x:588,y:451,t:1527876803289};\\\", \\\"{x:594,y:450,t:1527876803306};\\\", \\\"{x:603,y:449,t:1527876803323};\\\", \\\"{x:614,y:449,t:1527876803340};\\\", \\\"{x:618,y:449,t:1527876803356};\\\", \\\"{x:623,y:449,t:1527876803373};\\\", \\\"{x:630,y:450,t:1527876803390};\\\", \\\"{x:639,y:453,t:1527876803406};\\\", \\\"{x:655,y:457,t:1527876803423};\\\", \\\"{x:675,y:462,t:1527876803440};\\\", \\\"{x:688,y:465,t:1527876803457};\\\", \\\"{x:720,y:471,t:1527876803474};\\\", \\\"{x:743,y:475,t:1527876803490};\\\", \\\"{x:774,y:481,t:1527876803506};\\\", \\\"{x:810,y:485,t:1527876803523};\\\", \\\"{x:838,y:489,t:1527876803542};\\\", \\\"{x:861,y:492,t:1527876803556};\\\", \\\"{x:886,y:497,t:1527876803573};\\\", \\\"{x:912,y:500,t:1527876803589};\\\", \\\"{x:945,y:504,t:1527876803607};\\\", \\\"{x:979,y:505,t:1527876803623};\\\", \\\"{x:1035,y:511,t:1527876803640};\\\", \\\"{x:1154,y:532,t:1527876803656};\\\", \\\"{x:1242,y:553,t:1527876803672};\\\", \\\"{x:1338,y:576,t:1527876803690};\\\", \\\"{x:1427,y:587,t:1527876803707};\\\", \\\"{x:1492,y:603,t:1527876803722};\\\", \\\"{x:1534,y:613,t:1527876803739};\\\", \\\"{x:1561,y:621,t:1527876803757};\\\", \\\"{x:1577,y:630,t:1527876803774};\\\", \\\"{x:1593,y:638,t:1527876803791};\\\", \\\"{x:1598,y:644,t:1527876803806};\\\", \\\"{x:1600,y:648,t:1527876803823};\\\", \\\"{x:1601,y:654,t:1527876803840};\\\", \\\"{x:1601,y:658,t:1527876803856};\\\", \\\"{x:1601,y:662,t:1527876803873};\\\", \\\"{x:1601,y:666,t:1527876803890};\\\", \\\"{x:1601,y:672,t:1527876803907};\\\", \\\"{x:1601,y:675,t:1527876803923};\\\", \\\"{x:1600,y:677,t:1527876803941};\\\", \\\"{x:1597,y:680,t:1527876803957};\\\", \\\"{x:1592,y:683,t:1527876803973};\\\", \\\"{x:1584,y:684,t:1527876803990};\\\", \\\"{x:1581,y:685,t:1527876804007};\\\", \\\"{x:1577,y:685,t:1527876804024};\\\", \\\"{x:1574,y:685,t:1527876804041};\\\", \\\"{x:1565,y:685,t:1527876804057};\\\", \\\"{x:1559,y:685,t:1527876804073};\\\", \\\"{x:1554,y:685,t:1527876804091};\\\", \\\"{x:1546,y:683,t:1527876804107};\\\", \\\"{x:1536,y:681,t:1527876804123};\\\", \\\"{x:1521,y:674,t:1527876804141};\\\", \\\"{x:1507,y:667,t:1527876804158};\\\", \\\"{x:1498,y:664,t:1527876804174};\\\", \\\"{x:1493,y:662,t:1527876804191};\\\", \\\"{x:1491,y:662,t:1527876804290};\\\", \\\"{x:1489,y:662,t:1527876804312};\\\", \\\"{x:1488,y:662,t:1527876804322};\\\", \\\"{x:1486,y:664,t:1527876804340};\\\", \\\"{x:1485,y:668,t:1527876804356};\\\", \\\"{x:1483,y:674,t:1527876804373};\\\", \\\"{x:1483,y:683,t:1527876804389};\\\", \\\"{x:1483,y:695,t:1527876804407};\\\", \\\"{x:1483,y:706,t:1527876804424};\\\", \\\"{x:1483,y:715,t:1527876804440};\\\", \\\"{x:1484,y:726,t:1527876804457};\\\", \\\"{x:1484,y:730,t:1527876804474};\\\", \\\"{x:1484,y:733,t:1527876804489};\\\", \\\"{x:1484,y:739,t:1527876804507};\\\", \\\"{x:1484,y:748,t:1527876804524};\\\", \\\"{x:1484,y:757,t:1527876804540};\\\", \\\"{x:1484,y:765,t:1527876804557};\\\", \\\"{x:1484,y:770,t:1527876804574};\\\", \\\"{x:1483,y:775,t:1527876804590};\\\", \\\"{x:1479,y:783,t:1527876804608};\\\", \\\"{x:1478,y:789,t:1527876804624};\\\", \\\"{x:1477,y:792,t:1527876804641};\\\", \\\"{x:1475,y:804,t:1527876804656};\\\", \\\"{x:1475,y:810,t:1527876804674};\\\", \\\"{x:1475,y:815,t:1527876804690};\\\", \\\"{x:1475,y:820,t:1527876804707};\\\", \\\"{x:1475,y:824,t:1527876804724};\\\", \\\"{x:1479,y:829,t:1527876804740};\\\", \\\"{x:1486,y:833,t:1527876804757};\\\", \\\"{x:1493,y:837,t:1527876804774};\\\", \\\"{x:1501,y:839,t:1527876804789};\\\", \\\"{x:1507,y:840,t:1527876804807};\\\", \\\"{x:1516,y:842,t:1527876804824};\\\", \\\"{x:1520,y:843,t:1527876804840};\\\", \\\"{x:1528,y:843,t:1527876804857};\\\", \\\"{x:1530,y:843,t:1527876804874};\\\", \\\"{x:1531,y:843,t:1527876805226};\\\", \\\"{x:1531,y:842,t:1527876805386};\\\", \\\"{x:1532,y:841,t:1527876805401};\\\", \\\"{x:1532,y:839,t:1527876806058};\\\", \\\"{x:1531,y:832,t:1527876806075};\\\", \\\"{x:1523,y:824,t:1527876806092};\\\", \\\"{x:1518,y:815,t:1527876806107};\\\", \\\"{x:1515,y:812,t:1527876806124};\\\", \\\"{x:1512,y:806,t:1527876806142};\\\", \\\"{x:1509,y:800,t:1527876806157};\\\", \\\"{x:1509,y:795,t:1527876806175};\\\", \\\"{x:1509,y:787,t:1527876806192};\\\", \\\"{x:1509,y:785,t:1527876806207};\\\", \\\"{x:1505,y:781,t:1527876808606};\\\", \\\"{x:1501,y:777,t:1527876808613};\\\", \\\"{x:1479,y:765,t:1527876808629};\\\", \\\"{x:1455,y:753,t:1527876808646};\\\", \\\"{x:1437,y:745,t:1527876808662};\\\", \\\"{x:1414,y:739,t:1527876808679};\\\", \\\"{x:1381,y:732,t:1527876808696};\\\", \\\"{x:1347,y:728,t:1527876808712};\\\", \\\"{x:1330,y:728,t:1527876808729};\\\", \\\"{x:1323,y:731,t:1527876808746};\\\", \\\"{x:1320,y:734,t:1527876808762};\\\", \\\"{x:1318,y:737,t:1527876808779};\\\", \\\"{x:1318,y:739,t:1527876808796};\\\", \\\"{x:1319,y:741,t:1527876808813};\\\", \\\"{x:1322,y:749,t:1527876808829};\\\", \\\"{x:1327,y:761,t:1527876808846};\\\", \\\"{x:1331,y:770,t:1527876808862};\\\", \\\"{x:1339,y:781,t:1527876808879};\\\", \\\"{x:1344,y:790,t:1527876808896};\\\", \\\"{x:1350,y:795,t:1527876808912};\\\", \\\"{x:1356,y:797,t:1527876808929};\\\", \\\"{x:1356,y:798,t:1527876808946};\\\", \\\"{x:1358,y:797,t:1527876809372};\\\", \\\"{x:1359,y:797,t:1527876809388};\\\", \\\"{x:1361,y:796,t:1527876809395};\\\", \\\"{x:1363,y:794,t:1527876809412};\\\", \\\"{x:1364,y:794,t:1527876809428};\\\", \\\"{x:1370,y:794,t:1527876809445};\\\", \\\"{x:1385,y:794,t:1527876809462};\\\", \\\"{x:1404,y:794,t:1527876809479};\\\", \\\"{x:1421,y:795,t:1527876809495};\\\", \\\"{x:1437,y:797,t:1527876809512};\\\", \\\"{x:1456,y:800,t:1527876809529};\\\", \\\"{x:1466,y:801,t:1527876809545};\\\", \\\"{x:1469,y:802,t:1527876809562};\\\", \\\"{x:1471,y:802,t:1527876809579};\\\", \\\"{x:1472,y:802,t:1527876809596};\\\", \\\"{x:1477,y:805,t:1527876809613};\\\", \\\"{x:1481,y:807,t:1527876809629};\\\", \\\"{x:1487,y:809,t:1527876809646};\\\", \\\"{x:1493,y:810,t:1527876809662};\\\", \\\"{x:1497,y:812,t:1527876809679};\\\", \\\"{x:1494,y:812,t:1527876809765};\\\", \\\"{x:1490,y:812,t:1527876809779};\\\", \\\"{x:1484,y:812,t:1527876809796};\\\", \\\"{x:1480,y:811,t:1527876809813};\\\", \\\"{x:1477,y:810,t:1527876809828};\\\", \\\"{x:1473,y:806,t:1527876809846};\\\", \\\"{x:1464,y:801,t:1527876809862};\\\", \\\"{x:1456,y:794,t:1527876809879};\\\", \\\"{x:1451,y:790,t:1527876809895};\\\", \\\"{x:1441,y:786,t:1527876809913};\\\", \\\"{x:1432,y:782,t:1527876809929};\\\", \\\"{x:1420,y:780,t:1527876809946};\\\", \\\"{x:1414,y:778,t:1527876809963};\\\", \\\"{x:1407,y:777,t:1527876809979};\\\", \\\"{x:1404,y:777,t:1527876809996};\\\", \\\"{x:1402,y:776,t:1527876810012};\\\", \\\"{x:1401,y:776,t:1527876810085};\\\", \\\"{x:1400,y:776,t:1527876810096};\\\", \\\"{x:1399,y:776,t:1527876810117};\\\", \\\"{x:1398,y:776,t:1527876810132};\\\", \\\"{x:1397,y:776,t:1527876810146};\\\", \\\"{x:1396,y:776,t:1527876810163};\\\", \\\"{x:1393,y:776,t:1527876810180};\\\", \\\"{x:1392,y:774,t:1527876810197};\\\", \\\"{x:1390,y:773,t:1527876810212};\\\", \\\"{x:1388,y:771,t:1527876810230};\\\", \\\"{x:1384,y:770,t:1527876810246};\\\", \\\"{x:1383,y:768,t:1527876810262};\\\", \\\"{x:1381,y:767,t:1527876810280};\\\", \\\"{x:1382,y:766,t:1527876810782};\\\", \\\"{x:1384,y:764,t:1527876810797};\\\", \\\"{x:1386,y:762,t:1527876810813};\\\", \\\"{x:1387,y:762,t:1527876811542};\\\", \\\"{x:1389,y:761,t:1527876811781};\\\", \\\"{x:1390,y:760,t:1527876811821};\\\", \\\"{x:1391,y:760,t:1527876811845};\\\", \\\"{x:1392,y:759,t:1527876811877};\\\", \\\"{x:1393,y:759,t:1527876811885};\\\", \\\"{x:1394,y:758,t:1527876812036};\\\", \\\"{x:1394,y:756,t:1527876812046};\\\", \\\"{x:1396,y:751,t:1527876812063};\\\", \\\"{x:1398,y:747,t:1527876812079};\\\", \\\"{x:1398,y:746,t:1527876812096};\\\", \\\"{x:1398,y:745,t:1527876812113};\\\", \\\"{x:1397,y:743,t:1527876812129};\\\", \\\"{x:1394,y:742,t:1527876812146};\\\", \\\"{x:1389,y:740,t:1527876812163};\\\", \\\"{x:1382,y:738,t:1527876812180};\\\", \\\"{x:1372,y:735,t:1527876812197};\\\", \\\"{x:1368,y:734,t:1527876812214};\\\", \\\"{x:1364,y:734,t:1527876812229};\\\", \\\"{x:1357,y:734,t:1527876812246};\\\", \\\"{x:1351,y:735,t:1527876812263};\\\", \\\"{x:1345,y:736,t:1527876812280};\\\", \\\"{x:1342,y:738,t:1527876812296};\\\", \\\"{x:1340,y:740,t:1527876812313};\\\", \\\"{x:1340,y:741,t:1527876812330};\\\", \\\"{x:1340,y:743,t:1527876812346};\\\", \\\"{x:1340,y:746,t:1527876812363};\\\", \\\"{x:1340,y:748,t:1527876812380};\\\", \\\"{x:1340,y:749,t:1527876812396};\\\", \\\"{x:1340,y:751,t:1527876812413};\\\", \\\"{x:1340,y:752,t:1527876812429};\\\", \\\"{x:1340,y:755,t:1527876812447};\\\", \\\"{x:1340,y:757,t:1527876812463};\\\", \\\"{x:1341,y:758,t:1527876812480};\\\", \\\"{x:1342,y:762,t:1527876812497};\\\", \\\"{x:1342,y:765,t:1527876812513};\\\", \\\"{x:1343,y:766,t:1527876812530};\\\", \\\"{x:1343,y:768,t:1527876812547};\\\", \\\"{x:1343,y:769,t:1527876812563};\\\", \\\"{x:1343,y:770,t:1527876812579};\\\", \\\"{x:1343,y:772,t:1527876812597};\\\", \\\"{x:1342,y:773,t:1527876812613};\\\", \\\"{x:1341,y:774,t:1527876812629};\\\", \\\"{x:1339,y:775,t:1527876812647};\\\", \\\"{x:1337,y:776,t:1527876812663};\\\", \\\"{x:1334,y:776,t:1527876812680};\\\", \\\"{x:1333,y:777,t:1527876812697};\\\", \\\"{x:1330,y:779,t:1527876812713};\\\", \\\"{x:1327,y:782,t:1527876812730};\\\", \\\"{x:1325,y:783,t:1527876812746};\\\", \\\"{x:1323,y:785,t:1527876812764};\\\", \\\"{x:1320,y:788,t:1527876812779};\\\", \\\"{x:1312,y:794,t:1527876812796};\\\", \\\"{x:1304,y:798,t:1527876812813};\\\", \\\"{x:1296,y:800,t:1527876812830};\\\", \\\"{x:1291,y:803,t:1527876812847};\\\", \\\"{x:1286,y:805,t:1527876812864};\\\", \\\"{x:1280,y:807,t:1527876812880};\\\", \\\"{x:1274,y:808,t:1527876812897};\\\", \\\"{x:1267,y:810,t:1527876812913};\\\", \\\"{x:1260,y:811,t:1527876812929};\\\", \\\"{x:1253,y:813,t:1527876812947};\\\", \\\"{x:1245,y:815,t:1527876812964};\\\", \\\"{x:1238,y:815,t:1527876812980};\\\", \\\"{x:1230,y:817,t:1527876812997};\\\", \\\"{x:1225,y:818,t:1527876813014};\\\", \\\"{x:1223,y:818,t:1527876813030};\\\", \\\"{x:1219,y:818,t:1527876813048};\\\", \\\"{x:1217,y:818,t:1527876813064};\\\", \\\"{x:1216,y:818,t:1527876813081};\\\", \\\"{x:1214,y:818,t:1527876813182};\\\", \\\"{x:1213,y:819,t:1527876813221};\\\", \\\"{x:1213,y:820,t:1527876813252};\\\", \\\"{x:1212,y:820,t:1527876815188};\\\", \\\"{x:1211,y:818,t:1527876815203};\\\", \\\"{x:1211,y:817,t:1527876815244};\\\", \\\"{x:1210,y:815,t:1527876815284};\\\", \\\"{x:1209,y:814,t:1527876815316};\\\", \\\"{x:1209,y:813,t:1527876815332};\\\", \\\"{x:1209,y:812,t:1527876815348};\\\", \\\"{x:1209,y:809,t:1527876815365};\\\", \\\"{x:1209,y:807,t:1527876815380};\\\", \\\"{x:1207,y:804,t:1527876815398};\\\", \\\"{x:1207,y:800,t:1527876815414};\\\", \\\"{x:1206,y:795,t:1527876815430};\\\", \\\"{x:1204,y:790,t:1527876815448};\\\", \\\"{x:1202,y:787,t:1527876815464};\\\", \\\"{x:1199,y:784,t:1527876815481};\\\", \\\"{x:1196,y:782,t:1527876815498};\\\", \\\"{x:1195,y:781,t:1527876815514};\\\", \\\"{x:1195,y:780,t:1527876815531};\\\", \\\"{x:1193,y:779,t:1527876815548};\\\", \\\"{x:1190,y:777,t:1527876815564};\\\", \\\"{x:1190,y:776,t:1527876815589};\\\", \\\"{x:1189,y:775,t:1527876815598};\\\", \\\"{x:1188,y:775,t:1527876815615};\\\", \\\"{x:1185,y:773,t:1527876815631};\\\", \\\"{x:1183,y:772,t:1527876815648};\\\", \\\"{x:1180,y:770,t:1527876815665};\\\", \\\"{x:1179,y:769,t:1527876815681};\\\", \\\"{x:1175,y:767,t:1527876815698};\\\", \\\"{x:1172,y:766,t:1527876815715};\\\", \\\"{x:1170,y:765,t:1527876815731};\\\", \\\"{x:1167,y:763,t:1527876815749};\\\", \\\"{x:1163,y:762,t:1527876815765};\\\", \\\"{x:1166,y:762,t:1527876819117};\\\", \\\"{x:1196,y:762,t:1527876819132};\\\", \\\"{x:1236,y:762,t:1527876819149};\\\", \\\"{x:1301,y:758,t:1527876819167};\\\", \\\"{x:1368,y:758,t:1527876819184};\\\", \\\"{x:1421,y:758,t:1527876819200};\\\", \\\"{x:1459,y:757,t:1527876819216};\\\", \\\"{x:1484,y:756,t:1527876819234};\\\", \\\"{x:1498,y:752,t:1527876819248};\\\", \\\"{x:1499,y:751,t:1527876819266};\\\", \\\"{x:1500,y:751,t:1527876819283};\\\", \\\"{x:1501,y:751,t:1527876819300};\\\", \\\"{x:1489,y:751,t:1527876819364};\\\", \\\"{x:1466,y:751,t:1527876819372};\\\", \\\"{x:1451,y:751,t:1527876819382};\\\", \\\"{x:1425,y:751,t:1527876819399};\\\", \\\"{x:1385,y:756,t:1527876819416};\\\", \\\"{x:1363,y:761,t:1527876819433};\\\", \\\"{x:1348,y:761,t:1527876819449};\\\", \\\"{x:1345,y:761,t:1527876819466};\\\", \\\"{x:1344,y:761,t:1527876819533};\\\", \\\"{x:1347,y:764,t:1527876819550};\\\", \\\"{x:1353,y:764,t:1527876819566};\\\", \\\"{x:1356,y:765,t:1527876819584};\\\", \\\"{x:1359,y:765,t:1527876819599};\\\", \\\"{x:1360,y:765,t:1527876819616};\\\", \\\"{x:1361,y:765,t:1527876819633};\\\", \\\"{x:1360,y:765,t:1527876819933};\\\", \\\"{x:1358,y:765,t:1527876819950};\\\", \\\"{x:1355,y:765,t:1527876819967};\\\", \\\"{x:1345,y:764,t:1527876819983};\\\", \\\"{x:1334,y:763,t:1527876820001};\\\", \\\"{x:1320,y:762,t:1527876820016};\\\", \\\"{x:1309,y:762,t:1527876820033};\\\", \\\"{x:1299,y:762,t:1527876820050};\\\", \\\"{x:1292,y:762,t:1527876820067};\\\", \\\"{x:1278,y:762,t:1527876820084};\\\", \\\"{x:1268,y:763,t:1527876820101};\\\", \\\"{x:1257,y:764,t:1527876820117};\\\", \\\"{x:1251,y:764,t:1527876820134};\\\", \\\"{x:1242,y:765,t:1527876820150};\\\", \\\"{x:1231,y:766,t:1527876820167};\\\", \\\"{x:1217,y:768,t:1527876820183};\\\", \\\"{x:1213,y:768,t:1527876820200};\\\", \\\"{x:1209,y:768,t:1527876820216};\\\", \\\"{x:1207,y:768,t:1527876820234};\\\", \\\"{x:1206,y:768,t:1527876820250};\\\", \\\"{x:1204,y:768,t:1527876820266};\\\", \\\"{x:1201,y:768,t:1527876820283};\\\", \\\"{x:1189,y:768,t:1527876820300};\\\", \\\"{x:1175,y:768,t:1527876820315};\\\", \\\"{x:1154,y:768,t:1527876820333};\\\", \\\"{x:1136,y:768,t:1527876820350};\\\", \\\"{x:1117,y:768,t:1527876820366};\\\", \\\"{x:1106,y:768,t:1527876820383};\\\", \\\"{x:1104,y:768,t:1527876820400};\\\", \\\"{x:1103,y:768,t:1527876820444};\\\", \\\"{x:1103,y:767,t:1527876820828};\\\", \\\"{x:1104,y:767,t:1527876820844};\\\", \\\"{x:1105,y:766,t:1527876820851};\\\", \\\"{x:1106,y:766,t:1527876822373};\\\", \\\"{x:1107,y:766,t:1527876822384};\\\", \\\"{x:1108,y:766,t:1527876822400};\\\", \\\"{x:1109,y:766,t:1527876822418};\\\", \\\"{x:1111,y:766,t:1527876823981};\\\", \\\"{x:1113,y:766,t:1527876824005};\\\", \\\"{x:1116,y:766,t:1527876824018};\\\", \\\"{x:1120,y:766,t:1527876824034};\\\", \\\"{x:1124,y:766,t:1527876824052};\\\", \\\"{x:1128,y:766,t:1527876824069};\\\", \\\"{x:1129,y:766,t:1527876824084};\\\", \\\"{x:1131,y:766,t:1527876824101};\\\", \\\"{x:1132,y:766,t:1527876824118};\\\", \\\"{x:1133,y:766,t:1527876824141};\\\", \\\"{x:1134,y:766,t:1527876824157};\\\", \\\"{x:1135,y:766,t:1527876824168};\\\", \\\"{x:1136,y:766,t:1527876824185};\\\", \\\"{x:1139,y:766,t:1527876824201};\\\", \\\"{x:1141,y:766,t:1527876824219};\\\", \\\"{x:1143,y:766,t:1527876824235};\\\", \\\"{x:1146,y:766,t:1527876824252};\\\", \\\"{x:1149,y:766,t:1527876824269};\\\", \\\"{x:1151,y:766,t:1527876824284};\\\", \\\"{x:1154,y:766,t:1527876824302};\\\", \\\"{x:1155,y:766,t:1527876824318};\\\", \\\"{x:1157,y:766,t:1527876824335};\\\", \\\"{x:1158,y:766,t:1527876824351};\\\", \\\"{x:1159,y:766,t:1527876824388};\\\", \\\"{x:1160,y:766,t:1527876824404};\\\", \\\"{x:1161,y:766,t:1527876824419};\\\", \\\"{x:1162,y:765,t:1527876824437};\\\", \\\"{x:1163,y:765,t:1527876824451};\\\", \\\"{x:1164,y:765,t:1527876824468};\\\", \\\"{x:1165,y:765,t:1527876824484};\\\", \\\"{x:1167,y:764,t:1527876824500};\\\", \\\"{x:1168,y:763,t:1527876824539};\\\", \\\"{x:1169,y:763,t:1527876824551};\\\", \\\"{x:1171,y:762,t:1527876824568};\\\", \\\"{x:1173,y:761,t:1527876824585};\\\", \\\"{x:1174,y:761,t:1527876824601};\\\", \\\"{x:1175,y:761,t:1527876824618};\\\", \\\"{x:1176,y:761,t:1527876824634};\\\", \\\"{x:1178,y:759,t:1527876824668};\\\", \\\"{x:1179,y:759,t:1527876824684};\\\", \\\"{x:1180,y:759,t:1527876824701};\\\", \\\"{x:1181,y:759,t:1527876824718};\\\", \\\"{x:1182,y:759,t:1527876824735};\\\", \\\"{x:1183,y:758,t:1527876824756};\\\", \\\"{x:1184,y:757,t:1527876825165};\\\", \\\"{x:1183,y:757,t:1527876825357};\\\", \\\"{x:1182,y:758,t:1527876825369};\\\", \\\"{x:1182,y:759,t:1527876825386};\\\", \\\"{x:1180,y:761,t:1527876825401};\\\", \\\"{x:1179,y:763,t:1527876825418};\\\", \\\"{x:1177,y:766,t:1527876825435};\\\", \\\"{x:1176,y:769,t:1527876825452};\\\", \\\"{x:1174,y:772,t:1527876825469};\\\", \\\"{x:1172,y:774,t:1527876825486};\\\", \\\"{x:1172,y:776,t:1527876825502};\\\", \\\"{x:1170,y:779,t:1527876825519};\\\", \\\"{x:1168,y:782,t:1527876825536};\\\", \\\"{x:1167,y:786,t:1527876825552};\\\", \\\"{x:1165,y:790,t:1527876825569};\\\", \\\"{x:1162,y:797,t:1527876825585};\\\", \\\"{x:1160,y:802,t:1527876825602};\\\", \\\"{x:1158,y:806,t:1527876825618};\\\", \\\"{x:1154,y:814,t:1527876825636};\\\", \\\"{x:1148,y:829,t:1527876825652};\\\", \\\"{x:1144,y:837,t:1527876825669};\\\", \\\"{x:1140,y:844,t:1527876825685};\\\", \\\"{x:1140,y:846,t:1527876825703};\\\", \\\"{x:1140,y:847,t:1527876825719};\\\", \\\"{x:1143,y:847,t:1527876825748};\\\", \\\"{x:1158,y:840,t:1527876825757};\\\", \\\"{x:1174,y:832,t:1527876825769};\\\", \\\"{x:1196,y:820,t:1527876825786};\\\", \\\"{x:1209,y:808,t:1527876825802};\\\", \\\"{x:1219,y:799,t:1527876825819};\\\", \\\"{x:1225,y:794,t:1527876825835};\\\", \\\"{x:1227,y:792,t:1527876825852};\\\", \\\"{x:1227,y:793,t:1527876826061};\\\", \\\"{x:1227,y:799,t:1527876826069};\\\", \\\"{x:1227,y:805,t:1527876826086};\\\", \\\"{x:1227,y:808,t:1527876826103};\\\", \\\"{x:1227,y:810,t:1527876826118};\\\", \\\"{x:1227,y:812,t:1527876826136};\\\", \\\"{x:1227,y:813,t:1527876826153};\\\", \\\"{x:1227,y:814,t:1527876826169};\\\", \\\"{x:1227,y:816,t:1527876826186};\\\", \\\"{x:1227,y:817,t:1527876826202};\\\", \\\"{x:1227,y:818,t:1527876826219};\\\", \\\"{x:1227,y:820,t:1527876826235};\\\", \\\"{x:1227,y:821,t:1527876826260};\\\", \\\"{x:1228,y:822,t:1527876826268};\\\", \\\"{x:1229,y:824,t:1527876826286};\\\", \\\"{x:1231,y:827,t:1527876826302};\\\", \\\"{x:1234,y:830,t:1527876826319};\\\", \\\"{x:1236,y:832,t:1527876826336};\\\", \\\"{x:1237,y:834,t:1527876826357};\\\", \\\"{x:1238,y:834,t:1527876826381};\\\", \\\"{x:1238,y:835,t:1527876826396};\\\", \\\"{x:1239,y:836,t:1527876826413};\\\", \\\"{x:1239,y:837,t:1527876826420};\\\", \\\"{x:1240,y:837,t:1527876826435};\\\", \\\"{x:1241,y:839,t:1527876826452};\\\", \\\"{x:1243,y:841,t:1527876826469};\\\", \\\"{x:1243,y:842,t:1527876826485};\\\", \\\"{x:1244,y:843,t:1527876826503};\\\", \\\"{x:1245,y:846,t:1527876826519};\\\", \\\"{x:1246,y:848,t:1527876826536};\\\", \\\"{x:1248,y:850,t:1527876826553};\\\", \\\"{x:1250,y:854,t:1527876826569};\\\", \\\"{x:1250,y:856,t:1527876826586};\\\", \\\"{x:1252,y:859,t:1527876826603};\\\", \\\"{x:1254,y:862,t:1527876826619};\\\", \\\"{x:1255,y:867,t:1527876826636};\\\", \\\"{x:1262,y:880,t:1527876826653};\\\", \\\"{x:1263,y:883,t:1527876826670};\\\", \\\"{x:1265,y:888,t:1527876826686};\\\", \\\"{x:1267,y:890,t:1527876826703};\\\", \\\"{x:1269,y:893,t:1527876826720};\\\", \\\"{x:1270,y:896,t:1527876826736};\\\", \\\"{x:1273,y:902,t:1527876826752};\\\", \\\"{x:1275,y:905,t:1527876826769};\\\", \\\"{x:1277,y:910,t:1527876826786};\\\", \\\"{x:1279,y:914,t:1527876826802};\\\", \\\"{x:1281,y:918,t:1527876826820};\\\", \\\"{x:1282,y:922,t:1527876826836};\\\", \\\"{x:1285,y:927,t:1527876826852};\\\", \\\"{x:1285,y:928,t:1527876826870};\\\", \\\"{x:1285,y:929,t:1527876826886};\\\", \\\"{x:1286,y:930,t:1527876826902};\\\", \\\"{x:1287,y:932,t:1527876826920};\\\", \\\"{x:1288,y:935,t:1527876826936};\\\", \\\"{x:1289,y:937,t:1527876826952};\\\", \\\"{x:1289,y:938,t:1527876826970};\\\", \\\"{x:1290,y:940,t:1527876826986};\\\", \\\"{x:1292,y:942,t:1527876827003};\\\", \\\"{x:1292,y:944,t:1527876827020};\\\", \\\"{x:1295,y:948,t:1527876827035};\\\", \\\"{x:1299,y:955,t:1527876827052};\\\", \\\"{x:1301,y:960,t:1527876827069};\\\", \\\"{x:1304,y:963,t:1527876827086};\\\", \\\"{x:1305,y:964,t:1527876827102};\\\", \\\"{x:1306,y:967,t:1527876827120};\\\", \\\"{x:1307,y:971,t:1527876827135};\\\", \\\"{x:1307,y:972,t:1527876827152};\\\", \\\"{x:1308,y:973,t:1527876827170};\\\", \\\"{x:1308,y:974,t:1527876827205};\\\", \\\"{x:1308,y:975,t:1527876827221};\\\", \\\"{x:1308,y:977,t:1527876827237};\\\", \\\"{x:1306,y:977,t:1527876827252};\\\", \\\"{x:1303,y:977,t:1527876827270};\\\", \\\"{x:1295,y:975,t:1527876827286};\\\", \\\"{x:1285,y:967,t:1527876827303};\\\", \\\"{x:1276,y:958,t:1527876827320};\\\", \\\"{x:1272,y:950,t:1527876827336};\\\", \\\"{x:1267,y:940,t:1527876827353};\\\", \\\"{x:1262,y:927,t:1527876827370};\\\", \\\"{x:1256,y:913,t:1527876827385};\\\", \\\"{x:1247,y:896,t:1527876827402};\\\", \\\"{x:1241,y:883,t:1527876827419};\\\", \\\"{x:1236,y:875,t:1527876827435};\\\", \\\"{x:1233,y:869,t:1527876827452};\\\", \\\"{x:1228,y:862,t:1527876827469};\\\", \\\"{x:1224,y:856,t:1527876827485};\\\", \\\"{x:1219,y:846,t:1527876827502};\\\", \\\"{x:1208,y:831,t:1527876827519};\\\", \\\"{x:1200,y:820,t:1527876827536};\\\", \\\"{x:1199,y:819,t:1527876827552};\\\", \\\"{x:1199,y:818,t:1527876827572};\\\", \\\"{x:1199,y:817,t:1527876827589};\\\", \\\"{x:1197,y:816,t:1527876827604};\\\", \\\"{x:1197,y:814,t:1527876827620};\\\", \\\"{x:1195,y:808,t:1527876827636};\\\", \\\"{x:1193,y:804,t:1527876827652};\\\", \\\"{x:1193,y:801,t:1527876827669};\\\", \\\"{x:1191,y:796,t:1527876827686};\\\", \\\"{x:1190,y:791,t:1527876827702};\\\", \\\"{x:1189,y:788,t:1527876827720};\\\", \\\"{x:1189,y:785,t:1527876827736};\\\", \\\"{x:1188,y:783,t:1527876827752};\\\", \\\"{x:1187,y:781,t:1527876827769};\\\", \\\"{x:1187,y:780,t:1527876827786};\\\", \\\"{x:1186,y:777,t:1527876827802};\\\", \\\"{x:1186,y:774,t:1527876827820};\\\", \\\"{x:1184,y:769,t:1527876827837};\\\", \\\"{x:1183,y:766,t:1527876827852};\\\", \\\"{x:1182,y:764,t:1527876827893};\\\", \\\"{x:1175,y:764,t:1527876828014};\\\", \\\"{x:1159,y:764,t:1527876828020};\\\", \\\"{x:1114,y:764,t:1527876828036};\\\", \\\"{x:1050,y:764,t:1527876828053};\\\", \\\"{x:961,y:764,t:1527876828069};\\\", \\\"{x:875,y:764,t:1527876828087};\\\", \\\"{x:789,y:764,t:1527876828103};\\\", \\\"{x:722,y:764,t:1527876828119};\\\", \\\"{x:671,y:757,t:1527876828137};\\\", \\\"{x:649,y:753,t:1527876828153};\\\", \\\"{x:632,y:749,t:1527876828170};\\\", \\\"{x:615,y:746,t:1527876828186};\\\", \\\"{x:603,y:744,t:1527876828203};\\\", \\\"{x:587,y:741,t:1527876828219};\\\", \\\"{x:564,y:729,t:1527876828238};\\\", \\\"{x:549,y:722,t:1527876828253};\\\", \\\"{x:531,y:713,t:1527876828269};\\\", \\\"{x:510,y:702,t:1527876828289};\\\", \\\"{x:488,y:684,t:1527876828306};\\\", \\\"{x:465,y:673,t:1527876828322};\\\", \\\"{x:441,y:665,t:1527876828339};\\\", \\\"{x:407,y:643,t:1527876828355};\\\", \\\"{x:381,y:623,t:1527876828380};\\\", \\\"{x:375,y:614,t:1527876828396};\\\", \\\"{x:370,y:602,t:1527876828413};\\\", \\\"{x:365,y:592,t:1527876828431};\\\", \\\"{x:365,y:585,t:1527876828446};\\\", \\\"{x:365,y:577,t:1527876828462};\\\", \\\"{x:366,y:572,t:1527876828479};\\\", \\\"{x:367,y:563,t:1527876828496};\\\", \\\"{x:367,y:557,t:1527876828514};\\\", \\\"{x:363,y:555,t:1527876828531};\\\", \\\"{x:354,y:553,t:1527876828546};\\\", \\\"{x:348,y:553,t:1527876828563};\\\", \\\"{x:315,y:553,t:1527876828579};\\\", \\\"{x:289,y:555,t:1527876828596};\\\", \\\"{x:268,y:558,t:1527876828614};\\\", \\\"{x:253,y:560,t:1527876828630};\\\", \\\"{x:240,y:561,t:1527876828646};\\\", \\\"{x:227,y:561,t:1527876828663};\\\", \\\"{x:211,y:561,t:1527876828680};\\\", \\\"{x:204,y:562,t:1527876828696};\\\", \\\"{x:200,y:563,t:1527876828715};\\\", \\\"{x:199,y:564,t:1527876828730};\\\", \\\"{x:194,y:565,t:1527876828746};\\\", \\\"{x:188,y:566,t:1527876828764};\\\", \\\"{x:174,y:566,t:1527876828779};\\\", \\\"{x:163,y:564,t:1527876828796};\\\", \\\"{x:154,y:555,t:1527876828814};\\\", \\\"{x:144,y:544,t:1527876828830};\\\", \\\"{x:138,y:532,t:1527876828847};\\\", \\\"{x:136,y:526,t:1527876828863};\\\", \\\"{x:136,y:522,t:1527876828880};\\\", \\\"{x:136,y:518,t:1527876828897};\\\", \\\"{x:136,y:517,t:1527876828916};\\\", \\\"{x:136,y:516,t:1527876828955};\\\", \\\"{x:136,y:514,t:1527876828963};\\\", \\\"{x:136,y:512,t:1527876828979};\\\", \\\"{x:138,y:510,t:1527876828997};\\\", \\\"{x:143,y:508,t:1527876829013};\\\", \\\"{x:146,y:507,t:1527876829030};\\\", \\\"{x:148,y:505,t:1527876829047};\\\", \\\"{x:151,y:504,t:1527876829063};\\\", \\\"{x:152,y:502,t:1527876829080};\\\", \\\"{x:152,y:501,t:1527876829097};\\\", \\\"{x:153,y:499,t:1527876829114};\\\", \\\"{x:155,y:499,t:1527876829130};\\\", \\\"{x:156,y:498,t:1527876829146};\\\", \\\"{x:158,y:497,t:1527876829164};\\\", \\\"{x:159,y:497,t:1527876829180};\\\", \\\"{x:161,y:497,t:1527876829404};\\\", \\\"{x:171,y:502,t:1527876829414};\\\", \\\"{x:189,y:515,t:1527876829430};\\\", \\\"{x:213,y:536,t:1527876829448};\\\", \\\"{x:247,y:568,t:1527876829465};\\\", \\\"{x:284,y:606,t:1527876829480};\\\", \\\"{x:338,y:660,t:1527876829497};\\\", \\\"{x:372,y:699,t:1527876829515};\\\", \\\"{x:399,y:725,t:1527876829531};\\\", \\\"{x:415,y:737,t:1527876829548};\\\", \\\"{x:432,y:747,t:1527876829564};\\\", \\\"{x:434,y:747,t:1527876829580};\\\", \\\"{x:440,y:750,t:1527876829597};\\\", \\\"{x:442,y:750,t:1527876829614};\\\", \\\"{x:445,y:751,t:1527876829630};\\\", \\\"{x:449,y:753,t:1527876829648};\\\", \\\"{x:452,y:753,t:1527876829666};\\\", \\\"{x:455,y:753,t:1527876829681};\\\", \\\"{x:457,y:753,t:1527876829698};\\\", \\\"{x:460,y:753,t:1527876829724};\\\", \\\"{x:461,y:753,t:1527876829732};\\\", \\\"{x:464,y:753,t:1527876829748};\\\", \\\"{x:486,y:743,t:1527876829764};\\\", \\\"{x:501,y:735,t:1527876829781};\\\", \\\"{x:511,y:729,t:1527876829798};\\\", \\\"{x:516,y:727,t:1527876829815};\\\", \\\"{x:518,y:726,t:1527876829832};\\\", \\\"{x:522,y:726,t:1527876830180};\\\", \\\"{x:523,y:726,t:1527876830195};\\\", \\\"{x:525,y:725,t:1527876830804};\\\", \\\"{x:526,y:723,t:1527876830814};\\\", \\\"{x:528,y:723,t:1527876830831};\\\", \\\"{x:532,y:721,t:1527876830848};\\\", \\\"{x:533,y:721,t:1527876830866};\\\", \\\"{x:536,y:719,t:1527876830881};\\\", \\\"{x:539,y:717,t:1527876830899};\\\", \\\"{x:541,y:716,t:1527876830915};\\\", \\\"{x:547,y:713,t:1527876830932};\\\", \\\"{x:556,y:709,t:1527876830948};\\\", \\\"{x:566,y:704,t:1527876830965};\\\", \\\"{x:577,y:703,t:1527876830981};\\\", \\\"{x:586,y:699,t:1527876831005};\\\", \\\"{x:587,y:698,t:1527876831015};\\\", \\\"{x:591,y:697,t:1527876831031};\\\", \\\"{x:594,y:696,t:1527876831047};\\\", \\\"{x:596,y:695,t:1527876831064};\\\", \\\"{x:600,y:693,t:1527876831082};\\\" ] }, { \\\"rt\\\": 15470, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 459126, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-M -C -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:620,y:687,t:1527876831254};\\\", \\\"{x:622,y:686,t:1527876831780};\\\", \\\"{x:624,y:682,t:1527876831787};\\\", \\\"{x:624,y:676,t:1527876831799};\\\", \\\"{x:628,y:665,t:1527876831814};\\\", \\\"{x:631,y:649,t:1527876831832};\\\", \\\"{x:636,y:642,t:1527876831849};\\\", \\\"{x:638,y:637,t:1527876831865};\\\", \\\"{x:639,y:634,t:1527876831882};\\\", \\\"{x:639,y:630,t:1527876831900};\\\", \\\"{x:639,y:624,t:1527876831915};\\\", \\\"{x:639,y:616,t:1527876831932};\\\", \\\"{x:639,y:611,t:1527876831949};\\\", \\\"{x:639,y:605,t:1527876831966};\\\", \\\"{x:639,y:602,t:1527876831982};\\\", \\\"{x:639,y:600,t:1527876832000};\\\", \\\"{x:641,y:599,t:1527876832684};\\\", \\\"{x:641,y:594,t:1527876832700};\\\", \\\"{x:641,y:590,t:1527876832718};\\\", \\\"{x:641,y:587,t:1527876832734};\\\", \\\"{x:641,y:584,t:1527876832750};\\\", \\\"{x:640,y:579,t:1527876832766};\\\", \\\"{x:636,y:571,t:1527876832783};\\\", \\\"{x:632,y:564,t:1527876832800};\\\", \\\"{x:629,y:557,t:1527876832816};\\\", \\\"{x:628,y:554,t:1527876832834};\\\", \\\"{x:626,y:549,t:1527876832849};\\\", \\\"{x:624,y:546,t:1527876832866};\\\", \\\"{x:622,y:542,t:1527876832883};\\\", \\\"{x:616,y:535,t:1527876832899};\\\", \\\"{x:610,y:527,t:1527876832916};\\\", \\\"{x:605,y:522,t:1527876832934};\\\", \\\"{x:601,y:517,t:1527876832951};\\\", \\\"{x:595,y:510,t:1527876832966};\\\", \\\"{x:590,y:504,t:1527876832983};\\\", \\\"{x:586,y:499,t:1527876833000};\\\", \\\"{x:582,y:495,t:1527876833016};\\\", \\\"{x:579,y:492,t:1527876833033};\\\", \\\"{x:578,y:490,t:1527876833051};\\\", \\\"{x:577,y:489,t:1527876833066};\\\", \\\"{x:577,y:487,t:1527876833084};\\\", \\\"{x:577,y:486,t:1527876833101};\\\", \\\"{x:577,y:484,t:1527876833116};\\\", \\\"{x:578,y:482,t:1527876833133};\\\", \\\"{x:583,y:480,t:1527876833150};\\\", \\\"{x:592,y:476,t:1527876833166};\\\", \\\"{x:601,y:475,t:1527876833183};\\\", \\\"{x:611,y:475,t:1527876833200};\\\", \\\"{x:625,y:475,t:1527876833217};\\\", \\\"{x:642,y:475,t:1527876833234};\\\", \\\"{x:681,y:481,t:1527876833250};\\\", \\\"{x:740,y:489,t:1527876833268};\\\", \\\"{x:813,y:498,t:1527876833283};\\\", \\\"{x:861,y:505,t:1527876833300};\\\", \\\"{x:902,y:515,t:1527876833317};\\\", \\\"{x:936,y:524,t:1527876833333};\\\", \\\"{x:965,y:534,t:1527876833350};\\\", \\\"{x:986,y:541,t:1527876833367};\\\", \\\"{x:1009,y:549,t:1527876833383};\\\", \\\"{x:1036,y:561,t:1527876833401};\\\", \\\"{x:1063,y:569,t:1527876833418};\\\", \\\"{x:1094,y:582,t:1527876833433};\\\", \\\"{x:1133,y:595,t:1527876833450};\\\", \\\"{x:1177,y:607,t:1527876833468};\\\", \\\"{x:1204,y:614,t:1527876833484};\\\", \\\"{x:1231,y:621,t:1527876833500};\\\", \\\"{x:1257,y:626,t:1527876833518};\\\", \\\"{x:1280,y:632,t:1527876833534};\\\", \\\"{x:1301,y:637,t:1527876833550};\\\", \\\"{x:1326,y:644,t:1527876833567};\\\", \\\"{x:1348,y:650,t:1527876833585};\\\", \\\"{x:1377,y:659,t:1527876833600};\\\", \\\"{x:1413,y:669,t:1527876833617};\\\", \\\"{x:1447,y:674,t:1527876833634};\\\", \\\"{x:1469,y:677,t:1527876833651};\\\", \\\"{x:1489,y:680,t:1527876833668};\\\", \\\"{x:1498,y:684,t:1527876833684};\\\", \\\"{x:1513,y:689,t:1527876833700};\\\", \\\"{x:1531,y:695,t:1527876833718};\\\", \\\"{x:1542,y:699,t:1527876833734};\\\", \\\"{x:1548,y:702,t:1527876833751};\\\", \\\"{x:1552,y:702,t:1527876833768};\\\", \\\"{x:1552,y:703,t:1527876833804};\\\", \\\"{x:1553,y:704,t:1527876833818};\\\", \\\"{x:1553,y:708,t:1527876833835};\\\", \\\"{x:1553,y:712,t:1527876833852};\\\", \\\"{x:1553,y:723,t:1527876833868};\\\", \\\"{x:1553,y:732,t:1527876833884};\\\", \\\"{x:1551,y:742,t:1527876833902};\\\", \\\"{x:1549,y:748,t:1527876833918};\\\", \\\"{x:1548,y:749,t:1527876833935};\\\", \\\"{x:1547,y:750,t:1527876833964};\\\", \\\"{x:1547,y:752,t:1527876833996};\\\", \\\"{x:1546,y:753,t:1527876834012};\\\", \\\"{x:1545,y:755,t:1527876834020};\\\", \\\"{x:1544,y:756,t:1527876834035};\\\", \\\"{x:1541,y:758,t:1527876834052};\\\", \\\"{x:1536,y:762,t:1527876834068};\\\", \\\"{x:1530,y:766,t:1527876834085};\\\", \\\"{x:1523,y:770,t:1527876834102};\\\", \\\"{x:1518,y:774,t:1527876834119};\\\", \\\"{x:1511,y:778,t:1527876834135};\\\", \\\"{x:1508,y:781,t:1527876834152};\\\", \\\"{x:1504,y:783,t:1527876834169};\\\", \\\"{x:1500,y:784,t:1527876834185};\\\", \\\"{x:1496,y:786,t:1527876834202};\\\", \\\"{x:1492,y:788,t:1527876834219};\\\", \\\"{x:1489,y:789,t:1527876834237};\\\", \\\"{x:1488,y:789,t:1527876834252};\\\", \\\"{x:1486,y:790,t:1527876834268};\\\", \\\"{x:1485,y:791,t:1527876834292};\\\", \\\"{x:1484,y:792,t:1527876834302};\\\", \\\"{x:1480,y:796,t:1527876834319};\\\", \\\"{x:1475,y:802,t:1527876834336};\\\", \\\"{x:1470,y:809,t:1527876834352};\\\", \\\"{x:1465,y:816,t:1527876834369};\\\", \\\"{x:1465,y:818,t:1527876834386};\\\", \\\"{x:1465,y:820,t:1527876834402};\\\", \\\"{x:1465,y:823,t:1527876834419};\\\", \\\"{x:1465,y:825,t:1527876834436};\\\", \\\"{x:1465,y:827,t:1527876834452};\\\", \\\"{x:1465,y:829,t:1527876834468};\\\", \\\"{x:1465,y:832,t:1527876834485};\\\", \\\"{x:1465,y:834,t:1527876834503};\\\", \\\"{x:1465,y:836,t:1527876834518};\\\", \\\"{x:1466,y:837,t:1527876834535};\\\", \\\"{x:1469,y:840,t:1527876834552};\\\", \\\"{x:1474,y:841,t:1527876834568};\\\", \\\"{x:1480,y:843,t:1527876834585};\\\", \\\"{x:1485,y:843,t:1527876834603};\\\", \\\"{x:1492,y:844,t:1527876834618};\\\", \\\"{x:1502,y:844,t:1527876834635};\\\", \\\"{x:1505,y:844,t:1527876834652};\\\", \\\"{x:1508,y:844,t:1527876834668};\\\", \\\"{x:1509,y:844,t:1527876834686};\\\", \\\"{x:1508,y:844,t:1527876834764};\\\", \\\"{x:1502,y:844,t:1527876834773};\\\", \\\"{x:1494,y:844,t:1527876834786};\\\", \\\"{x:1483,y:845,t:1527876834803};\\\", \\\"{x:1453,y:845,t:1527876834820};\\\", \\\"{x:1431,y:845,t:1527876834836};\\\", \\\"{x:1415,y:845,t:1527876834852};\\\", \\\"{x:1400,y:845,t:1527876834870};\\\", \\\"{x:1386,y:845,t:1527876834886};\\\", \\\"{x:1379,y:845,t:1527876834903};\\\", \\\"{x:1373,y:844,t:1527876834920};\\\", \\\"{x:1370,y:844,t:1527876834936};\\\", \\\"{x:1364,y:844,t:1527876834953};\\\", \\\"{x:1350,y:844,t:1527876834970};\\\", \\\"{x:1331,y:844,t:1527876834987};\\\", \\\"{x:1315,y:844,t:1527876835003};\\\", \\\"{x:1298,y:844,t:1527876835020};\\\", \\\"{x:1295,y:844,t:1527876835037};\\\", \\\"{x:1292,y:844,t:1527876835053};\\\", \\\"{x:1291,y:844,t:1527876835069};\\\", \\\"{x:1291,y:846,t:1527876835107};\\\", \\\"{x:1291,y:850,t:1527876835120};\\\", \\\"{x:1291,y:855,t:1527876835136};\\\", \\\"{x:1295,y:859,t:1527876835152};\\\", \\\"{x:1296,y:862,t:1527876835170};\\\", \\\"{x:1303,y:864,t:1527876835186};\\\", \\\"{x:1318,y:872,t:1527876835203};\\\", \\\"{x:1329,y:876,t:1527876835220};\\\", \\\"{x:1340,y:879,t:1527876835237};\\\", \\\"{x:1355,y:883,t:1527876835254};\\\", \\\"{x:1367,y:886,t:1527876835270};\\\", \\\"{x:1371,y:886,t:1527876835287};\\\", \\\"{x:1373,y:886,t:1527876835304};\\\", \\\"{x:1373,y:887,t:1527876835319};\\\", \\\"{x:1375,y:887,t:1527876835348};\\\", \\\"{x:1377,y:887,t:1527876835357};\\\", \\\"{x:1379,y:886,t:1527876835370};\\\", \\\"{x:1385,y:882,t:1527876835387};\\\", \\\"{x:1391,y:876,t:1527876835405};\\\", \\\"{x:1395,y:872,t:1527876835419};\\\", \\\"{x:1398,y:869,t:1527876835436};\\\", \\\"{x:1400,y:867,t:1527876835453};\\\", \\\"{x:1400,y:865,t:1527876835470};\\\", \\\"{x:1401,y:863,t:1527876835487};\\\", \\\"{x:1401,y:860,t:1527876835503};\\\", \\\"{x:1401,y:854,t:1527876835521};\\\", \\\"{x:1401,y:846,t:1527876835536};\\\", \\\"{x:1401,y:843,t:1527876835554};\\\", \\\"{x:1401,y:842,t:1527876835570};\\\", \\\"{x:1401,y:841,t:1527876835588};\\\", \\\"{x:1400,y:839,t:1527876835604};\\\", \\\"{x:1399,y:837,t:1527876835621};\\\", \\\"{x:1397,y:835,t:1527876835638};\\\", \\\"{x:1395,y:832,t:1527876835654};\\\", \\\"{x:1393,y:828,t:1527876835671};\\\", \\\"{x:1392,y:826,t:1527876835688};\\\", \\\"{x:1391,y:821,t:1527876835704};\\\", \\\"{x:1389,y:812,t:1527876835722};\\\", \\\"{x:1389,y:804,t:1527876835738};\\\", \\\"{x:1389,y:791,t:1527876835754};\\\", \\\"{x:1391,y:778,t:1527876835771};\\\", \\\"{x:1402,y:745,t:1527876835788};\\\", \\\"{x:1407,y:722,t:1527876835804};\\\", \\\"{x:1408,y:707,t:1527876835821};\\\", \\\"{x:1412,y:691,t:1527876835838};\\\", \\\"{x:1413,y:677,t:1527876835855};\\\", \\\"{x:1416,y:668,t:1527876835871};\\\", \\\"{x:1418,y:662,t:1527876835888};\\\", \\\"{x:1420,y:653,t:1527876835905};\\\", \\\"{x:1425,y:644,t:1527876835921};\\\", \\\"{x:1429,y:637,t:1527876835938};\\\", \\\"{x:1439,y:624,t:1527876835955};\\\", \\\"{x:1447,y:611,t:1527876835971};\\\", \\\"{x:1461,y:591,t:1527876835989};\\\", \\\"{x:1465,y:583,t:1527876836005};\\\", \\\"{x:1467,y:577,t:1527876836021};\\\", \\\"{x:1467,y:574,t:1527876836038};\\\", \\\"{x:1467,y:568,t:1527876836055};\\\", \\\"{x:1467,y:564,t:1527876836071};\\\", \\\"{x:1465,y:555,t:1527876836088};\\\", \\\"{x:1464,y:550,t:1527876836105};\\\", \\\"{x:1464,y:544,t:1527876836122};\\\", \\\"{x:1464,y:539,t:1527876836138};\\\", \\\"{x:1466,y:535,t:1527876836155};\\\", \\\"{x:1470,y:529,t:1527876836173};\\\", \\\"{x:1475,y:523,t:1527876836188};\\\", \\\"{x:1482,y:519,t:1527876836204};\\\", \\\"{x:1489,y:516,t:1527876836222};\\\", \\\"{x:1494,y:515,t:1527876836238};\\\", \\\"{x:1495,y:515,t:1527876836255};\\\", \\\"{x:1496,y:515,t:1527876836316};\\\", \\\"{x:1496,y:518,t:1527876836332};\\\", \\\"{x:1496,y:519,t:1527876836348};\\\", \\\"{x:1496,y:522,t:1527876836357};\\\", \\\"{x:1495,y:526,t:1527876836372};\\\", \\\"{x:1494,y:528,t:1527876836389};\\\", \\\"{x:1493,y:529,t:1527876836405};\\\", \\\"{x:1493,y:534,t:1527876838084};\\\", \\\"{x:1493,y:540,t:1527876838092};\\\", \\\"{x:1495,y:552,t:1527876838108};\\\", \\\"{x:1495,y:554,t:1527876838124};\\\", \\\"{x:1495,y:556,t:1527876838141};\\\", \\\"{x:1497,y:557,t:1527876838158};\\\", \\\"{x:1497,y:559,t:1527876838174};\\\", \\\"{x:1497,y:564,t:1527876838191};\\\", \\\"{x:1498,y:569,t:1527876838207};\\\", \\\"{x:1499,y:574,t:1527876838225};\\\", \\\"{x:1499,y:575,t:1527876838242};\\\", \\\"{x:1499,y:577,t:1527876838258};\\\", \\\"{x:1498,y:584,t:1527876838715};\\\", \\\"{x:1487,y:601,t:1527876838724};\\\", \\\"{x:1467,y:636,t:1527876838741};\\\", \\\"{x:1451,y:657,t:1527876838758};\\\", \\\"{x:1445,y:673,t:1527876838774};\\\", \\\"{x:1434,y:689,t:1527876838792};\\\", \\\"{x:1429,y:697,t:1527876838808};\\\", \\\"{x:1429,y:699,t:1527876838825};\\\", \\\"{x:1429,y:703,t:1527876838841};\\\", \\\"{x:1429,y:706,t:1527876838858};\\\", \\\"{x:1429,y:708,t:1527876838875};\\\", \\\"{x:1429,y:711,t:1527876838891};\\\", \\\"{x:1430,y:716,t:1527876838909};\\\", \\\"{x:1431,y:722,t:1527876838926};\\\", \\\"{x:1431,y:724,t:1527876838942};\\\", \\\"{x:1432,y:726,t:1527876838959};\\\", \\\"{x:1432,y:728,t:1527876838976};\\\", \\\"{x:1433,y:730,t:1527876838992};\\\", \\\"{x:1434,y:731,t:1527876839009};\\\", \\\"{x:1435,y:733,t:1527876839026};\\\", \\\"{x:1435,y:736,t:1527876839041};\\\", \\\"{x:1437,y:738,t:1527876839059};\\\", \\\"{x:1441,y:744,t:1527876839076};\\\", \\\"{x:1444,y:749,t:1527876839092};\\\", \\\"{x:1451,y:755,t:1527876839109};\\\", \\\"{x:1455,y:758,t:1527876839126};\\\", \\\"{x:1459,y:761,t:1527876839143};\\\", \\\"{x:1462,y:762,t:1527876839160};\\\", \\\"{x:1464,y:764,t:1527876839176};\\\", \\\"{x:1465,y:764,t:1527876839193};\\\", \\\"{x:1466,y:764,t:1527876839268};\\\", \\\"{x:1468,y:764,t:1527876839285};\\\", \\\"{x:1470,y:764,t:1527876839292};\\\", \\\"{x:1473,y:764,t:1527876839310};\\\", \\\"{x:1477,y:764,t:1527876839326};\\\", \\\"{x:1478,y:764,t:1527876839343};\\\", \\\"{x:1479,y:765,t:1527876839360};\\\", \\\"{x:1480,y:764,t:1527876839396};\\\", \\\"{x:1483,y:762,t:1527876839410};\\\", \\\"{x:1484,y:757,t:1527876839426};\\\", \\\"{x:1490,y:742,t:1527876839443};\\\", \\\"{x:1500,y:719,t:1527876839460};\\\", \\\"{x:1507,y:707,t:1527876839476};\\\", \\\"{x:1512,y:696,t:1527876839493};\\\", \\\"{x:1520,y:677,t:1527876839510};\\\", \\\"{x:1530,y:657,t:1527876839526};\\\", \\\"{x:1539,y:642,t:1527876839542};\\\", \\\"{x:1547,y:630,t:1527876839559};\\\", \\\"{x:1557,y:619,t:1527876839575};\\\", \\\"{x:1565,y:612,t:1527876839592};\\\", \\\"{x:1571,y:606,t:1527876839609};\\\", \\\"{x:1576,y:601,t:1527876839626};\\\", \\\"{x:1585,y:589,t:1527876839643};\\\", \\\"{x:1601,y:571,t:1527876839659};\\\", \\\"{x:1609,y:564,t:1527876839676};\\\", \\\"{x:1622,y:552,t:1527876839693};\\\", \\\"{x:1632,y:542,t:1527876839710};\\\", \\\"{x:1636,y:537,t:1527876839727};\\\", \\\"{x:1639,y:530,t:1527876839742};\\\", \\\"{x:1641,y:525,t:1527876839760};\\\", \\\"{x:1642,y:521,t:1527876839777};\\\", \\\"{x:1643,y:517,t:1527876839793};\\\", \\\"{x:1643,y:509,t:1527876839810};\\\", \\\"{x:1643,y:495,t:1527876839827};\\\", \\\"{x:1643,y:483,t:1527876839844};\\\", \\\"{x:1642,y:479,t:1527876839860};\\\", \\\"{x:1642,y:476,t:1527876839877};\\\", \\\"{x:1641,y:472,t:1527876839894};\\\", \\\"{x:1640,y:470,t:1527876839910};\\\", \\\"{x:1639,y:469,t:1527876839926};\\\", \\\"{x:1639,y:467,t:1527876839944};\\\", \\\"{x:1638,y:463,t:1527876839960};\\\", \\\"{x:1636,y:460,t:1527876839977};\\\", \\\"{x:1633,y:457,t:1527876839994};\\\", \\\"{x:1632,y:455,t:1527876840010};\\\", \\\"{x:1631,y:453,t:1527876840027};\\\", \\\"{x:1628,y:451,t:1527876840044};\\\", \\\"{x:1625,y:448,t:1527876840060};\\\", \\\"{x:1623,y:446,t:1527876840077};\\\", \\\"{x:1621,y:444,t:1527876840094};\\\", \\\"{x:1620,y:442,t:1527876840111};\\\", \\\"{x:1619,y:442,t:1527876840127};\\\", \\\"{x:1619,y:441,t:1527876840144};\\\", \\\"{x:1617,y:444,t:1527876840492};\\\", \\\"{x:1616,y:450,t:1527876840499};\\\", \\\"{x:1615,y:454,t:1527876840511};\\\", \\\"{x:1614,y:458,t:1527876840527};\\\", \\\"{x:1613,y:461,t:1527876840545};\\\", \\\"{x:1612,y:464,t:1527876840561};\\\", \\\"{x:1612,y:465,t:1527876840578};\\\", \\\"{x:1611,y:466,t:1527876840594};\\\", \\\"{x:1611,y:468,t:1527876840610};\\\", \\\"{x:1610,y:471,t:1527876840628};\\\", \\\"{x:1610,y:479,t:1527876840644};\\\", \\\"{x:1610,y:488,t:1527876840661};\\\", \\\"{x:1609,y:501,t:1527876840677};\\\", \\\"{x:1609,y:508,t:1527876840695};\\\", \\\"{x:1607,y:513,t:1527876840711};\\\", \\\"{x:1607,y:515,t:1527876840728};\\\", \\\"{x:1607,y:518,t:1527876840744};\\\", \\\"{x:1607,y:521,t:1527876840760};\\\", \\\"{x:1607,y:524,t:1527876840777};\\\", \\\"{x:1607,y:526,t:1527876840794};\\\", \\\"{x:1607,y:532,t:1527876840812};\\\", \\\"{x:1606,y:536,t:1527876840827};\\\", \\\"{x:1605,y:541,t:1527876840845};\\\", \\\"{x:1603,y:544,t:1527876840862};\\\", \\\"{x:1603,y:546,t:1527876840878};\\\", \\\"{x:1603,y:548,t:1527876840895};\\\", \\\"{x:1603,y:549,t:1527876840912};\\\", \\\"{x:1603,y:551,t:1527876840928};\\\", \\\"{x:1603,y:553,t:1527876840945};\\\", \\\"{x:1602,y:555,t:1527876840962};\\\", \\\"{x:1602,y:557,t:1527876840978};\\\", \\\"{x:1602,y:561,t:1527876840995};\\\", \\\"{x:1602,y:570,t:1527876841012};\\\", \\\"{x:1602,y:576,t:1527876841029};\\\", \\\"{x:1602,y:580,t:1527876841044};\\\", \\\"{x:1603,y:582,t:1527876841061};\\\", \\\"{x:1603,y:584,t:1527876841079};\\\", \\\"{x:1603,y:585,t:1527876841095};\\\", \\\"{x:1603,y:587,t:1527876841112};\\\", \\\"{x:1603,y:591,t:1527876841128};\\\", \\\"{x:1603,y:595,t:1527876841145};\\\", \\\"{x:1603,y:604,t:1527876841161};\\\", \\\"{x:1605,y:614,t:1527876841179};\\\", \\\"{x:1605,y:615,t:1527876841194};\\\", \\\"{x:1605,y:616,t:1527876841212};\\\", \\\"{x:1605,y:617,t:1527876841228};\\\", \\\"{x:1606,y:619,t:1527876841245};\\\", \\\"{x:1606,y:620,t:1527876841275};\\\", \\\"{x:1607,y:621,t:1527876841284};\\\", \\\"{x:1607,y:623,t:1527876841296};\\\", \\\"{x:1608,y:625,t:1527876841311};\\\", \\\"{x:1608,y:629,t:1527876841329};\\\", \\\"{x:1610,y:630,t:1527876841346};\\\", \\\"{x:1610,y:632,t:1527876841380};\\\", \\\"{x:1610,y:633,t:1527876841420};\\\", \\\"{x:1610,y:635,t:1527876841477};\\\", \\\"{x:1610,y:636,t:1527876841501};\\\", \\\"{x:1610,y:638,t:1527876841516};\\\", \\\"{x:1610,y:639,t:1527876841531};\\\", \\\"{x:1610,y:641,t:1527876841546};\\\", \\\"{x:1610,y:643,t:1527876841562};\\\", \\\"{x:1610,y:651,t:1527876841579};\\\", \\\"{x:1607,y:679,t:1527876841596};\\\", \\\"{x:1602,y:693,t:1527876841612};\\\", \\\"{x:1598,y:700,t:1527876841628};\\\", \\\"{x:1595,y:707,t:1527876841646};\\\", \\\"{x:1591,y:714,t:1527876841662};\\\", \\\"{x:1584,y:725,t:1527876841678};\\\", \\\"{x:1578,y:737,t:1527876841696};\\\", \\\"{x:1574,y:741,t:1527876841713};\\\", \\\"{x:1570,y:747,t:1527876841730};\\\", \\\"{x:1567,y:753,t:1527876841747};\\\", \\\"{x:1563,y:758,t:1527876841763};\\\", \\\"{x:1557,y:768,t:1527876841780};\\\", \\\"{x:1554,y:771,t:1527876841796};\\\", \\\"{x:1552,y:774,t:1527876841813};\\\", \\\"{x:1551,y:775,t:1527876841830};\\\", \\\"{x:1549,y:777,t:1527876841846};\\\", \\\"{x:1548,y:778,t:1527876841863};\\\", \\\"{x:1545,y:780,t:1527876841880};\\\", \\\"{x:1541,y:782,t:1527876841896};\\\", \\\"{x:1539,y:784,t:1527876841913};\\\", \\\"{x:1537,y:786,t:1527876841931};\\\", \\\"{x:1535,y:787,t:1527876841948};\\\", \\\"{x:1534,y:788,t:1527876841964};\\\", \\\"{x:1533,y:789,t:1527876841980};\\\", \\\"{x:1530,y:790,t:1527876841997};\\\", \\\"{x:1529,y:790,t:1527876842012};\\\", \\\"{x:1526,y:791,t:1527876842029};\\\", \\\"{x:1518,y:791,t:1527876842046};\\\", \\\"{x:1505,y:791,t:1527876842062};\\\", \\\"{x:1487,y:790,t:1527876842079};\\\", \\\"{x:1468,y:783,t:1527876842096};\\\", \\\"{x:1453,y:776,t:1527876842112};\\\", \\\"{x:1440,y:770,t:1527876842129};\\\", \\\"{x:1424,y:760,t:1527876842146};\\\", \\\"{x:1405,y:748,t:1527876842164};\\\", \\\"{x:1401,y:746,t:1527876842179};\\\", \\\"{x:1396,y:741,t:1527876842196};\\\", \\\"{x:1388,y:735,t:1527876842214};\\\", \\\"{x:1384,y:731,t:1527876842229};\\\", \\\"{x:1381,y:728,t:1527876842246};\\\", \\\"{x:1381,y:727,t:1527876842263};\\\", \\\"{x:1380,y:727,t:1527876842279};\\\", \\\"{x:1379,y:725,t:1527876842297};\\\", \\\"{x:1379,y:724,t:1527876842313};\\\", \\\"{x:1377,y:722,t:1527876842330};\\\", \\\"{x:1377,y:721,t:1527876842347};\\\", \\\"{x:1376,y:721,t:1527876842364};\\\", \\\"{x:1376,y:720,t:1527876842380};\\\", \\\"{x:1375,y:720,t:1527876842397};\\\", \\\"{x:1372,y:719,t:1527876842414};\\\", \\\"{x:1370,y:718,t:1527876842431};\\\", \\\"{x:1365,y:716,t:1527876842447};\\\", \\\"{x:1358,y:714,t:1527876842463};\\\", \\\"{x:1355,y:713,t:1527876842480};\\\", \\\"{x:1354,y:713,t:1527876842497};\\\", \\\"{x:1351,y:711,t:1527876842514};\\\", \\\"{x:1350,y:711,t:1527876842530};\\\", \\\"{x:1349,y:711,t:1527876842547};\\\", \\\"{x:1348,y:711,t:1527876843069};\\\", \\\"{x:1347,y:711,t:1527876843277};\\\", \\\"{x:1347,y:710,t:1527876843300};\\\", \\\"{x:1347,y:709,t:1527876843388};\\\", \\\"{x:1347,y:707,t:1527876843404};\\\", \\\"{x:1346,y:706,t:1527876843415};\\\", \\\"{x:1346,y:705,t:1527876843432};\\\", \\\"{x:1346,y:704,t:1527876843449};\\\", \\\"{x:1346,y:703,t:1527876843465};\\\", \\\"{x:1346,y:702,t:1527876843485};\\\", \\\"{x:1346,y:701,t:1527876843708};\\\", \\\"{x:1343,y:696,t:1527876843716};\\\", \\\"{x:1336,y:685,t:1527876843734};\\\", \\\"{x:1330,y:674,t:1527876843750};\\\", \\\"{x:1327,y:666,t:1527876843766};\\\", \\\"{x:1325,y:662,t:1527876843782};\\\", \\\"{x:1319,y:651,t:1527876843799};\\\", \\\"{x:1315,y:642,t:1527876843815};\\\", \\\"{x:1311,y:635,t:1527876843832};\\\", \\\"{x:1306,y:629,t:1527876843849};\\\", \\\"{x:1303,y:624,t:1527876843865};\\\", \\\"{x:1300,y:618,t:1527876843883};\\\", \\\"{x:1299,y:617,t:1527876843899};\\\", \\\"{x:1299,y:616,t:1527876843924};\\\", \\\"{x:1299,y:615,t:1527876843933};\\\", \\\"{x:1296,y:612,t:1527876843948};\\\", \\\"{x:1295,y:609,t:1527876843966};\\\", \\\"{x:1292,y:604,t:1527876843983};\\\", \\\"{x:1287,y:597,t:1527876843999};\\\", \\\"{x:1282,y:590,t:1527876844016};\\\", \\\"{x:1279,y:588,t:1527876844033};\\\", \\\"{x:1277,y:586,t:1527876844049};\\\", \\\"{x:1276,y:584,t:1527876844066};\\\", \\\"{x:1276,y:583,t:1527876844083};\\\", \\\"{x:1275,y:582,t:1527876844148};\\\", \\\"{x:1276,y:585,t:1527876844540};\\\", \\\"{x:1279,y:590,t:1527876844550};\\\", \\\"{x:1286,y:599,t:1527876844568};\\\", \\\"{x:1290,y:603,t:1527876844584};\\\", \\\"{x:1294,y:607,t:1527876844600};\\\", \\\"{x:1298,y:612,t:1527876844617};\\\", \\\"{x:1301,y:615,t:1527876844634};\\\", \\\"{x:1302,y:617,t:1527876844650};\\\", \\\"{x:1303,y:619,t:1527876844668};\\\", \\\"{x:1303,y:618,t:1527876844780};\\\", \\\"{x:1299,y:615,t:1527876844788};\\\", \\\"{x:1297,y:611,t:1527876844801};\\\", \\\"{x:1290,y:603,t:1527876844817};\\\", \\\"{x:1287,y:599,t:1527876844834};\\\", \\\"{x:1285,y:596,t:1527876844851};\\\", \\\"{x:1284,y:594,t:1527876844868};\\\", \\\"{x:1281,y:590,t:1527876844884};\\\", \\\"{x:1279,y:585,t:1527876844901};\\\", \\\"{x:1278,y:582,t:1527876844917};\\\", \\\"{x:1277,y:579,t:1527876844934};\\\", \\\"{x:1274,y:573,t:1527876844951};\\\", \\\"{x:1273,y:569,t:1527876844967};\\\", \\\"{x:1268,y:560,t:1527876844984};\\\", \\\"{x:1267,y:556,t:1527876845002};\\\", \\\"{x:1266,y:554,t:1527876845017};\\\", \\\"{x:1265,y:553,t:1527876845034};\\\", \\\"{x:1264,y:552,t:1527876845172};\\\", \\\"{x:1263,y:552,t:1527876845184};\\\", \\\"{x:1255,y:554,t:1527876845201};\\\", \\\"{x:1242,y:564,t:1527876845218};\\\", \\\"{x:1220,y:575,t:1527876845235};\\\", \\\"{x:1195,y:583,t:1527876845251};\\\", \\\"{x:1151,y:589,t:1527876845268};\\\", \\\"{x:1111,y:589,t:1527876845285};\\\", \\\"{x:1075,y:589,t:1527876845302};\\\", \\\"{x:1033,y:589,t:1527876845318};\\\", \\\"{x:979,y:589,t:1527876845335};\\\", \\\"{x:919,y:584,t:1527876845352};\\\", \\\"{x:865,y:582,t:1527876845367};\\\", \\\"{x:820,y:582,t:1527876845385};\\\", \\\"{x:765,y:582,t:1527876845409};\\\", \\\"{x:736,y:582,t:1527876845426};\\\", \\\"{x:706,y:581,t:1527876845443};\\\", \\\"{x:673,y:579,t:1527876845460};\\\", \\\"{x:658,y:577,t:1527876845477};\\\", \\\"{x:646,y:573,t:1527876845493};\\\", \\\"{x:637,y:567,t:1527876845510};\\\", \\\"{x:629,y:558,t:1527876845527};\\\", \\\"{x:621,y:547,t:1527876845544};\\\", \\\"{x:616,y:536,t:1527876845560};\\\", \\\"{x:614,y:530,t:1527876845577};\\\", \\\"{x:612,y:525,t:1527876845594};\\\", \\\"{x:612,y:520,t:1527876845610};\\\", \\\"{x:612,y:517,t:1527876845627};\\\", \\\"{x:612,y:515,t:1527876845644};\\\", \\\"{x:612,y:513,t:1527876845659};\\\", \\\"{x:612,y:512,t:1527876845683};\\\", \\\"{x:612,y:510,t:1527876845699};\\\", \\\"{x:612,y:509,t:1527876845709};\\\", \\\"{x:612,y:506,t:1527876845727};\\\", \\\"{x:612,y:502,t:1527876845744};\\\", \\\"{x:612,y:499,t:1527876845760};\\\", \\\"{x:612,y:498,t:1527876845779};\\\", \\\"{x:608,y:503,t:1527876846091};\\\", \\\"{x:605,y:509,t:1527876846099};\\\", \\\"{x:603,y:512,t:1527876846110};\\\", \\\"{x:599,y:520,t:1527876846127};\\\", \\\"{x:597,y:527,t:1527876846144};\\\", \\\"{x:595,y:536,t:1527876846160};\\\", \\\"{x:589,y:554,t:1527876846177};\\\", \\\"{x:584,y:572,t:1527876846194};\\\", \\\"{x:577,y:596,t:1527876846212};\\\", \\\"{x:569,y:621,t:1527876846227};\\\", \\\"{x:557,y:647,t:1527876846245};\\\", \\\"{x:552,y:656,t:1527876846261};\\\", \\\"{x:551,y:661,t:1527876846276};\\\", \\\"{x:548,y:668,t:1527876846294};\\\", \\\"{x:547,y:675,t:1527876846310};\\\", \\\"{x:547,y:680,t:1527876846327};\\\", \\\"{x:545,y:686,t:1527876846344};\\\", \\\"{x:543,y:695,t:1527876846360};\\\", \\\"{x:541,y:706,t:1527876846377};\\\", \\\"{x:538,y:714,t:1527876846394};\\\", \\\"{x:536,y:720,t:1527876846410};\\\", \\\"{x:535,y:723,t:1527876846427};\\\", \\\"{x:535,y:729,t:1527876846443};\\\", \\\"{x:534,y:730,t:1527876846461};\\\", \\\"{x:533,y:732,t:1527876846478};\\\", \\\"{x:532,y:733,t:1527876846493};\\\", \\\"{x:531,y:735,t:1527876846511};\\\", \\\"{x:529,y:739,t:1527876846527};\\\", \\\"{x:529,y:740,t:1527876846588};\\\", \\\"{x:529,y:738,t:1527876847083};\\\", \\\"{x:529,y:736,t:1527876847095};\\\", \\\"{x:532,y:731,t:1527876847111};\\\", \\\"{x:533,y:728,t:1527876847128};\\\", \\\"{x:535,y:725,t:1527876847145};\\\", \\\"{x:539,y:721,t:1527876847161};\\\", \\\"{x:549,y:714,t:1527876847177};\\\", \\\"{x:560,y:709,t:1527876847195};\\\", \\\"{x:578,y:701,t:1527876847211};\\\", \\\"{x:590,y:696,t:1527876847227};\\\", \\\"{x:604,y:690,t:1527876847245};\\\", \\\"{x:616,y:685,t:1527876847262};\\\", \\\"{x:626,y:681,t:1527876847277};\\\", \\\"{x:635,y:677,t:1527876847295};\\\", \\\"{x:637,y:676,t:1527876847312};\\\", \\\"{x:638,y:675,t:1527876847328};\\\" ] }, { \\\"rt\\\": 7811, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 468196, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-M -L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:639,y:672,t:1527876848411};\\\", \\\"{x:615,y:637,t:1527876848428};\\\", \\\"{x:595,y:619,t:1527876848445};\\\", \\\"{x:580,y:610,t:1527876848462};\\\", \\\"{x:570,y:603,t:1527876848479};\\\", \\\"{x:559,y:595,t:1527876848496};\\\", \\\"{x:552,y:590,t:1527876848512};\\\", \\\"{x:543,y:582,t:1527876848528};\\\", \\\"{x:536,y:578,t:1527876848546};\\\", \\\"{x:532,y:573,t:1527876848562};\\\", \\\"{x:529,y:566,t:1527876848578};\\\", \\\"{x:519,y:550,t:1527876848596};\\\", \\\"{x:516,y:544,t:1527876848613};\\\", \\\"{x:514,y:538,t:1527876848629};\\\", \\\"{x:506,y:527,t:1527876848646};\\\", \\\"{x:499,y:516,t:1527876848663};\\\", \\\"{x:495,y:508,t:1527876848680};\\\", \\\"{x:489,y:499,t:1527876848695};\\\", \\\"{x:486,y:496,t:1527876848713};\\\", \\\"{x:486,y:495,t:1527876848728};\\\", \\\"{x:486,y:493,t:1527876848745};\\\", \\\"{x:485,y:492,t:1527876848763};\\\", \\\"{x:485,y:489,t:1527876848779};\\\", \\\"{x:485,y:481,t:1527876848796};\\\", \\\"{x:485,y:476,t:1527876848813};\\\", \\\"{x:485,y:470,t:1527876848828};\\\", \\\"{x:485,y:467,t:1527876848846};\\\", \\\"{x:485,y:466,t:1527876848862};\\\", \\\"{x:485,y:464,t:1527876848879};\\\", \\\"{x:485,y:463,t:1527876848900};\\\", \\\"{x:486,y:461,t:1527876848912};\\\", \\\"{x:489,y:458,t:1527876848929};\\\", \\\"{x:495,y:456,t:1527876848946};\\\", \\\"{x:508,y:455,t:1527876848962};\\\", \\\"{x:517,y:455,t:1527876848980};\\\", \\\"{x:524,y:455,t:1527876848996};\\\", \\\"{x:528,y:455,t:1527876849012};\\\", \\\"{x:540,y:455,t:1527876849029};\\\", \\\"{x:554,y:457,t:1527876849046};\\\", \\\"{x:574,y:459,t:1527876849062};\\\", \\\"{x:607,y:464,t:1527876849080};\\\", \\\"{x:668,y:472,t:1527876849096};\\\", \\\"{x:735,y:480,t:1527876849112};\\\", \\\"{x:799,y:489,t:1527876849131};\\\", \\\"{x:880,y:500,t:1527876849146};\\\", \\\"{x:957,y:507,t:1527876849163};\\\", \\\"{x:1052,y:509,t:1527876849180};\\\", \\\"{x:1108,y:509,t:1527876849195};\\\", \\\"{x:1161,y:509,t:1527876849213};\\\", \\\"{x:1195,y:509,t:1527876849229};\\\", \\\"{x:1220,y:509,t:1527876849246};\\\", \\\"{x:1256,y:509,t:1527876849262};\\\", \\\"{x:1284,y:509,t:1527876849280};\\\", \\\"{x:1310,y:511,t:1527876849296};\\\", \\\"{x:1323,y:513,t:1527876849313};\\\", \\\"{x:1339,y:520,t:1527876849330};\\\", \\\"{x:1352,y:525,t:1527876849346};\\\", \\\"{x:1365,y:533,t:1527876849363};\\\", \\\"{x:1385,y:551,t:1527876849380};\\\", \\\"{x:1400,y:568,t:1527876849396};\\\", \\\"{x:1418,y:588,t:1527876849412};\\\", \\\"{x:1429,y:603,t:1527876849429};\\\", \\\"{x:1439,y:617,t:1527876849446};\\\", \\\"{x:1451,y:635,t:1527876849463};\\\", \\\"{x:1458,y:647,t:1527876849480};\\\", \\\"{x:1462,y:655,t:1527876849496};\\\", \\\"{x:1465,y:662,t:1527876849513};\\\", \\\"{x:1470,y:676,t:1527876849530};\\\", \\\"{x:1477,y:696,t:1527876849547};\\\", \\\"{x:1483,y:713,t:1527876849563};\\\", \\\"{x:1487,y:728,t:1527876849579};\\\", \\\"{x:1489,y:735,t:1527876849597};\\\", \\\"{x:1491,y:746,t:1527876849613};\\\", \\\"{x:1492,y:761,t:1527876849630};\\\", \\\"{x:1492,y:777,t:1527876849647};\\\", \\\"{x:1492,y:796,t:1527876849663};\\\", \\\"{x:1492,y:817,t:1527876849681};\\\", \\\"{x:1493,y:832,t:1527876849697};\\\", \\\"{x:1493,y:839,t:1527876849713};\\\", \\\"{x:1493,y:848,t:1527876849730};\\\", \\\"{x:1488,y:864,t:1527876849748};\\\", \\\"{x:1486,y:869,t:1527876849763};\\\", \\\"{x:1485,y:882,t:1527876849781};\\\", \\\"{x:1484,y:891,t:1527876849797};\\\", \\\"{x:1484,y:898,t:1527876849814};\\\", \\\"{x:1484,y:903,t:1527876849831};\\\", \\\"{x:1484,y:906,t:1527876849848};\\\", \\\"{x:1482,y:910,t:1527876849863};\\\", \\\"{x:1482,y:915,t:1527876849880};\\\", \\\"{x:1481,y:922,t:1527876849897};\\\", \\\"{x:1480,y:931,t:1527876849914};\\\", \\\"{x:1477,y:940,t:1527876849931};\\\", \\\"{x:1472,y:949,t:1527876849947};\\\", \\\"{x:1461,y:965,t:1527876849964};\\\", \\\"{x:1455,y:972,t:1527876849980};\\\", \\\"{x:1453,y:974,t:1527876849998};\\\", \\\"{x:1452,y:975,t:1527876850014};\\\", \\\"{x:1450,y:976,t:1527876850031};\\\", \\\"{x:1448,y:976,t:1527876850047};\\\", \\\"{x:1443,y:976,t:1527876850065};\\\", \\\"{x:1436,y:976,t:1527876850080};\\\", \\\"{x:1426,y:977,t:1527876850097};\\\", \\\"{x:1422,y:977,t:1527876850114};\\\", \\\"{x:1417,y:979,t:1527876850131};\\\", \\\"{x:1411,y:979,t:1527876850147};\\\", \\\"{x:1409,y:979,t:1527876850163};\\\", \\\"{x:1408,y:979,t:1527876850180};\\\", \\\"{x:1405,y:979,t:1527876850197};\\\", \\\"{x:1401,y:979,t:1527876850215};\\\", \\\"{x:1393,y:981,t:1527876850231};\\\", \\\"{x:1390,y:981,t:1527876850248};\\\", \\\"{x:1389,y:981,t:1527876850264};\\\", \\\"{x:1387,y:981,t:1527876850280};\\\", \\\"{x:1385,y:982,t:1527876850300};\\\", \\\"{x:1384,y:982,t:1527876850316};\\\", \\\"{x:1383,y:982,t:1527876850330};\\\", \\\"{x:1377,y:983,t:1527876850347};\\\", \\\"{x:1372,y:983,t:1527876850364};\\\", \\\"{x:1369,y:983,t:1527876850381};\\\", \\\"{x:1363,y:983,t:1527876850397};\\\", \\\"{x:1357,y:981,t:1527876850414};\\\", \\\"{x:1353,y:977,t:1527876850432};\\\", \\\"{x:1351,y:972,t:1527876850447};\\\", \\\"{x:1349,y:970,t:1527876850465};\\\", \\\"{x:1349,y:966,t:1527876850481};\\\", \\\"{x:1349,y:961,t:1527876850497};\\\", \\\"{x:1349,y:959,t:1527876850515};\\\", \\\"{x:1349,y:957,t:1527876850531};\\\", \\\"{x:1349,y:955,t:1527876850550};\\\", \\\"{x:1350,y:953,t:1527876850564};\\\", \\\"{x:1352,y:950,t:1527876850581};\\\", \\\"{x:1354,y:947,t:1527876850597};\\\", \\\"{x:1357,y:942,t:1527876850614};\\\", \\\"{x:1360,y:936,t:1527876850631};\\\", \\\"{x:1363,y:932,t:1527876850648};\\\", \\\"{x:1364,y:930,t:1527876850664};\\\", \\\"{x:1365,y:928,t:1527876850681};\\\", \\\"{x:1366,y:927,t:1527876850697};\\\", \\\"{x:1367,y:926,t:1527876850715};\\\", \\\"{x:1367,y:925,t:1527876850732};\\\", \\\"{x:1369,y:923,t:1527876850748};\\\", \\\"{x:1369,y:922,t:1527876850764};\\\", \\\"{x:1370,y:922,t:1527876850787};\\\", \\\"{x:1370,y:921,t:1527876850804};\\\", \\\"{x:1370,y:920,t:1527876850820};\\\", \\\"{x:1371,y:919,t:1527876850831};\\\", \\\"{x:1372,y:919,t:1527876850852};\\\", \\\"{x:1372,y:918,t:1527876850863};\\\", \\\"{x:1373,y:917,t:1527876850880};\\\", \\\"{x:1375,y:915,t:1527876850897};\\\", \\\"{x:1376,y:914,t:1527876850914};\\\", \\\"{x:1378,y:912,t:1527876850931};\\\", \\\"{x:1379,y:910,t:1527876850947};\\\", \\\"{x:1379,y:908,t:1527876850964};\\\", \\\"{x:1381,y:906,t:1527876850981};\\\", \\\"{x:1383,y:903,t:1527876850997};\\\", \\\"{x:1385,y:898,t:1527876851014};\\\", \\\"{x:1388,y:892,t:1527876851031};\\\", \\\"{x:1391,y:887,t:1527876851048};\\\", \\\"{x:1394,y:881,t:1527876851064};\\\", \\\"{x:1395,y:877,t:1527876851080};\\\", \\\"{x:1400,y:868,t:1527876851098};\\\", \\\"{x:1406,y:858,t:1527876851113};\\\", \\\"{x:1412,y:849,t:1527876851131};\\\", \\\"{x:1415,y:840,t:1527876851147};\\\", \\\"{x:1418,y:833,t:1527876851164};\\\", \\\"{x:1425,y:823,t:1527876851181};\\\", \\\"{x:1431,y:814,t:1527876851198};\\\", \\\"{x:1437,y:802,t:1527876851214};\\\", \\\"{x:1444,y:791,t:1527876851231};\\\", \\\"{x:1450,y:778,t:1527876851248};\\\", \\\"{x:1455,y:770,t:1527876851264};\\\", \\\"{x:1459,y:760,t:1527876851281};\\\", \\\"{x:1467,y:741,t:1527876851299};\\\", \\\"{x:1476,y:727,t:1527876851314};\\\", \\\"{x:1482,y:714,t:1527876851331};\\\", \\\"{x:1492,y:693,t:1527876851348};\\\", \\\"{x:1498,y:681,t:1527876851364};\\\", \\\"{x:1501,y:672,t:1527876851381};\\\", \\\"{x:1502,y:668,t:1527876851398};\\\", \\\"{x:1502,y:661,t:1527876851415};\\\", \\\"{x:1504,y:654,t:1527876851432};\\\", \\\"{x:1505,y:645,t:1527876851448};\\\", \\\"{x:1509,y:633,t:1527876851466};\\\", \\\"{x:1512,y:623,t:1527876851482};\\\", \\\"{x:1515,y:617,t:1527876851498};\\\", \\\"{x:1518,y:611,t:1527876851515};\\\", \\\"{x:1520,y:604,t:1527876851531};\\\", \\\"{x:1525,y:590,t:1527876851549};\\\", \\\"{x:1530,y:575,t:1527876851566};\\\", \\\"{x:1535,y:564,t:1527876851582};\\\", \\\"{x:1539,y:554,t:1527876851598};\\\", \\\"{x:1544,y:548,t:1527876851615};\\\", \\\"{x:1548,y:541,t:1527876851631};\\\", \\\"{x:1551,y:537,t:1527876851649};\\\", \\\"{x:1552,y:534,t:1527876851666};\\\", \\\"{x:1555,y:529,t:1527876851682};\\\", \\\"{x:1559,y:525,t:1527876851698};\\\", \\\"{x:1563,y:520,t:1527876851716};\\\", \\\"{x:1568,y:513,t:1527876851732};\\\", \\\"{x:1570,y:511,t:1527876851750};\\\", \\\"{x:1571,y:510,t:1527876851765};\\\", \\\"{x:1571,y:508,t:1527876851782};\\\", \\\"{x:1574,y:504,t:1527876851798};\\\", \\\"{x:1577,y:500,t:1527876851816};\\\", \\\"{x:1579,y:494,t:1527876851833};\\\", \\\"{x:1586,y:488,t:1527876851850};\\\", \\\"{x:1589,y:483,t:1527876851866};\\\", \\\"{x:1593,y:479,t:1527876851883};\\\", \\\"{x:1594,y:477,t:1527876851898};\\\", \\\"{x:1595,y:477,t:1527876851956};\\\", \\\"{x:1595,y:480,t:1527876852036};\\\", \\\"{x:1590,y:489,t:1527876852049};\\\", \\\"{x:1579,y:497,t:1527876852066};\\\", \\\"{x:1560,y:508,t:1527876852083};\\\", \\\"{x:1539,y:517,t:1527876852098};\\\", \\\"{x:1510,y:526,t:1527876852115};\\\", \\\"{x:1482,y:531,t:1527876852132};\\\", \\\"{x:1459,y:534,t:1527876852149};\\\", \\\"{x:1433,y:536,t:1527876852165};\\\", \\\"{x:1402,y:540,t:1527876852182};\\\", \\\"{x:1363,y:545,t:1527876852198};\\\", \\\"{x:1325,y:548,t:1527876852215};\\\", \\\"{x:1285,y:553,t:1527876852233};\\\", \\\"{x:1238,y:553,t:1527876852250};\\\", \\\"{x:1209,y:553,t:1527876852265};\\\", \\\"{x:1189,y:553,t:1527876852282};\\\", \\\"{x:1175,y:553,t:1527876852300};\\\", \\\"{x:1170,y:553,t:1527876852316};\\\", \\\"{x:1145,y:550,t:1527876852332};\\\", \\\"{x:1114,y:542,t:1527876852350};\\\", \\\"{x:1083,y:538,t:1527876852365};\\\", \\\"{x:1054,y:530,t:1527876852382};\\\", \\\"{x:1023,y:523,t:1527876852399};\\\", \\\"{x:993,y:520,t:1527876852416};\\\", \\\"{x:976,y:520,t:1527876852433};\\\", \\\"{x:961,y:522,t:1527876852450};\\\", \\\"{x:953,y:523,t:1527876852465};\\\", \\\"{x:951,y:524,t:1527876852483};\\\", \\\"{x:950,y:524,t:1527876852499};\\\", \\\"{x:949,y:525,t:1527876852534};\\\", \\\"{x:948,y:525,t:1527876852548};\\\", \\\"{x:947,y:525,t:1527876852565};\\\", \\\"{x:946,y:525,t:1527876852595};\\\", \\\"{x:945,y:526,t:1527876852651};\\\", \\\"{x:942,y:526,t:1527876852666};\\\", \\\"{x:935,y:530,t:1527876852682};\\\", \\\"{x:930,y:537,t:1527876852699};\\\", \\\"{x:928,y:540,t:1527876852715};\\\", \\\"{x:927,y:542,t:1527876852732};\\\", \\\"{x:926,y:545,t:1527876852749};\\\", \\\"{x:924,y:547,t:1527876852767};\\\", \\\"{x:924,y:549,t:1527876852782};\\\", \\\"{x:920,y:557,t:1527876852800};\\\", \\\"{x:918,y:562,t:1527876852816};\\\", \\\"{x:917,y:564,t:1527876852832};\\\", \\\"{x:916,y:568,t:1527876852849};\\\", \\\"{x:916,y:570,t:1527876852866};\\\", \\\"{x:916,y:571,t:1527876852882};\\\", \\\"{x:915,y:572,t:1527876852899};\\\", \\\"{x:915,y:574,t:1527876852916};\\\", \\\"{x:914,y:575,t:1527876852932};\\\", \\\"{x:913,y:577,t:1527876852948};\\\", \\\"{x:913,y:579,t:1527876852966};\\\", \\\"{x:910,y:583,t:1527876852983};\\\", \\\"{x:908,y:586,t:1527876852998};\\\", \\\"{x:905,y:590,t:1527876853016};\\\", \\\"{x:900,y:593,t:1527876853033};\\\", \\\"{x:895,y:595,t:1527876853049};\\\", \\\"{x:885,y:597,t:1527876853066};\\\", \\\"{x:865,y:598,t:1527876853082};\\\", \\\"{x:856,y:598,t:1527876853099};\\\", \\\"{x:843,y:598,t:1527876853116};\\\", \\\"{x:829,y:598,t:1527876853133};\\\", \\\"{x:813,y:598,t:1527876853149};\\\", \\\"{x:797,y:596,t:1527876853165};\\\", \\\"{x:779,y:594,t:1527876853183};\\\", \\\"{x:759,y:594,t:1527876853199};\\\", \\\"{x:738,y:590,t:1527876853216};\\\", \\\"{x:723,y:590,t:1527876853234};\\\", \\\"{x:707,y:590,t:1527876853249};\\\", \\\"{x:694,y:590,t:1527876853265};\\\", \\\"{x:672,y:587,t:1527876853282};\\\", \\\"{x:658,y:582,t:1527876853299};\\\", \\\"{x:646,y:577,t:1527876853315};\\\", \\\"{x:632,y:569,t:1527876853333};\\\", \\\"{x:614,y:561,t:1527876853349};\\\", \\\"{x:593,y:553,t:1527876853366};\\\", \\\"{x:575,y:548,t:1527876853382};\\\", \\\"{x:555,y:541,t:1527876853400};\\\", \\\"{x:541,y:537,t:1527876853416};\\\", \\\"{x:532,y:532,t:1527876853433};\\\", \\\"{x:524,y:525,t:1527876853449};\\\", \\\"{x:512,y:520,t:1527876853467};\\\", \\\"{x:496,y:514,t:1527876853483};\\\", \\\"{x:487,y:513,t:1527876853499};\\\", \\\"{x:479,y:513,t:1527876853516};\\\", \\\"{x:468,y:514,t:1527876853532};\\\", \\\"{x:457,y:518,t:1527876853549};\\\", \\\"{x:446,y:523,t:1527876853566};\\\", \\\"{x:434,y:528,t:1527876853583};\\\", \\\"{x:421,y:529,t:1527876853599};\\\", \\\"{x:414,y:532,t:1527876853616};\\\", \\\"{x:409,y:532,t:1527876853632};\\\", \\\"{x:408,y:532,t:1527876853649};\\\", \\\"{x:406,y:532,t:1527876853665};\\\", \\\"{x:399,y:534,t:1527876853683};\\\", \\\"{x:390,y:534,t:1527876853700};\\\", \\\"{x:378,y:534,t:1527876853716};\\\", \\\"{x:365,y:538,t:1527876853734};\\\", \\\"{x:358,y:540,t:1527876853749};\\\", \\\"{x:357,y:541,t:1527876853766};\\\", \\\"{x:360,y:541,t:1527876853988};\\\", \\\"{x:361,y:541,t:1527876854000};\\\", \\\"{x:365,y:541,t:1527876854018};\\\", \\\"{x:369,y:541,t:1527876854033};\\\", \\\"{x:374,y:541,t:1527876854050};\\\", \\\"{x:376,y:541,t:1527876854067};\\\", \\\"{x:377,y:542,t:1527876854411};\\\", \\\"{x:375,y:543,t:1527876854435};\\\", \\\"{x:373,y:543,t:1527876854468};\\\", \\\"{x:368,y:545,t:1527876854485};\\\", \\\"{x:361,y:546,t:1527876854501};\\\", \\\"{x:350,y:549,t:1527876854516};\\\", \\\"{x:341,y:554,t:1527876854533};\\\", \\\"{x:333,y:558,t:1527876854550};\\\", \\\"{x:327,y:559,t:1527876854567};\\\", \\\"{x:324,y:562,t:1527876854584};\\\", \\\"{x:320,y:563,t:1527876854601};\\\", \\\"{x:319,y:564,t:1527876854616};\\\", \\\"{x:318,y:565,t:1527876854635};\\\", \\\"{x:318,y:566,t:1527876854675};\\\", \\\"{x:320,y:566,t:1527876854691};\\\", \\\"{x:324,y:568,t:1527876854701};\\\", \\\"{x:332,y:571,t:1527876854717};\\\", \\\"{x:343,y:574,t:1527876854733};\\\", \\\"{x:360,y:579,t:1527876854750};\\\", \\\"{x:369,y:579,t:1527876854767};\\\", \\\"{x:378,y:580,t:1527876854784};\\\", \\\"{x:384,y:582,t:1527876854801};\\\", \\\"{x:389,y:583,t:1527876854817};\\\", \\\"{x:397,y:584,t:1527876854835};\\\", \\\"{x:409,y:589,t:1527876854851};\\\", \\\"{x:422,y:594,t:1527876854868};\\\", \\\"{x:438,y:598,t:1527876854884};\\\", \\\"{x:453,y:602,t:1527876854902};\\\", \\\"{x:463,y:603,t:1527876854917};\\\", \\\"{x:464,y:603,t:1527876854934};\\\", \\\"{x:465,y:604,t:1527876854971};\\\", \\\"{x:465,y:605,t:1527876854984};\\\", \\\"{x:451,y:612,t:1527876855001};\\\", \\\"{x:429,y:617,t:1527876855017};\\\", \\\"{x:411,y:619,t:1527876855035};\\\", \\\"{x:394,y:619,t:1527876855051};\\\", \\\"{x:393,y:619,t:1527876855067};\\\", \\\"{x:391,y:619,t:1527876855084};\\\", \\\"{x:395,y:623,t:1527876855379};\\\", \\\"{x:404,y:629,t:1527876855387};\\\", \\\"{x:414,y:637,t:1527876855401};\\\", \\\"{x:433,y:649,t:1527876855419};\\\", \\\"{x:452,y:662,t:1527876855434};\\\", \\\"{x:476,y:680,t:1527876855452};\\\", \\\"{x:482,y:690,t:1527876855468};\\\", \\\"{x:487,y:696,t:1527876855485};\\\", \\\"{x:491,y:705,t:1527876855501};\\\", \\\"{x:493,y:710,t:1527876855518};\\\", \\\"{x:496,y:715,t:1527876855534};\\\", \\\"{x:498,y:719,t:1527876855551};\\\", \\\"{x:500,y:724,t:1527876855569};\\\", \\\"{x:503,y:730,t:1527876855585};\\\", \\\"{x:503,y:732,t:1527876855601};\\\", \\\"{x:506,y:736,t:1527876855618};\\\", \\\"{x:507,y:737,t:1527876855636};\\\", \\\"{x:507,y:738,t:1527876855651};\\\", \\\"{x:508,y:739,t:1527876855906};\\\", \\\"{x:512,y:739,t:1527876855918};\\\", \\\"{x:528,y:739,t:1527876855935};\\\", \\\"{x:544,y:739,t:1527876855951};\\\", \\\"{x:573,y:739,t:1527876855967};\\\", \\\"{x:601,y:739,t:1527876855985};\\\", \\\"{x:631,y:739,t:1527876856001};\\\", \\\"{x:650,y:736,t:1527876856018};\\\", \\\"{x:681,y:726,t:1527876856035};\\\", \\\"{x:703,y:720,t:1527876856051};\\\", \\\"{x:728,y:713,t:1527876856068};\\\", \\\"{x:757,y:703,t:1527876856085};\\\", \\\"{x:788,y:695,t:1527876856102};\\\", \\\"{x:823,y:683,t:1527876856118};\\\", \\\"{x:847,y:674,t:1527876856135};\\\", \\\"{x:861,y:666,t:1527876856152};\\\", \\\"{x:867,y:662,t:1527876856168};\\\", \\\"{x:873,y:658,t:1527876856186};\\\", \\\"{x:876,y:656,t:1527876856202};\\\", \\\"{x:878,y:654,t:1527876856218};\\\", \\\"{x:880,y:653,t:1527876856235};\\\", \\\"{x:882,y:650,t:1527876856252};\\\", \\\"{x:886,y:648,t:1527876856268};\\\", \\\"{x:889,y:646,t:1527876856286};\\\", \\\"{x:891,y:643,t:1527876856303};\\\", \\\"{x:894,y:641,t:1527876856318};\\\", \\\"{x:896,y:639,t:1527876856335};\\\", \\\"{x:900,y:637,t:1527876856352};\\\", \\\"{x:903,y:636,t:1527876856368};\\\", \\\"{x:905,y:634,t:1527876856386};\\\", \\\"{x:907,y:633,t:1527876856402};\\\", \\\"{x:909,y:632,t:1527876856418};\\\", \\\"{x:910,y:631,t:1527876856435};\\\", \\\"{x:912,y:630,t:1527876856467};\\\" ] }, { \\\"rt\\\": 8521, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 477958, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:882,y:625,t:1527876857537};\\\", \\\"{x:823,y:614,t:1527876857552};\\\", \\\"{x:765,y:600,t:1527876857571};\\\", \\\"{x:696,y:588,t:1527876857588};\\\", \\\"{x:669,y:583,t:1527876857602};\\\", \\\"{x:645,y:577,t:1527876857619};\\\", \\\"{x:622,y:569,t:1527876857636};\\\", \\\"{x:604,y:563,t:1527876857653};\\\", \\\"{x:586,y:553,t:1527876857670};\\\", \\\"{x:571,y:545,t:1527876857686};\\\", \\\"{x:558,y:538,t:1527876857703};\\\", \\\"{x:546,y:530,t:1527876857720};\\\", \\\"{x:541,y:527,t:1527876857736};\\\", \\\"{x:538,y:524,t:1527876857753};\\\", \\\"{x:532,y:517,t:1527876857770};\\\", \\\"{x:527,y:512,t:1527876857785};\\\", \\\"{x:522,y:506,t:1527876857802};\\\", \\\"{x:515,y:497,t:1527876857820};\\\", \\\"{x:508,y:490,t:1527876857836};\\\", \\\"{x:501,y:481,t:1527876857853};\\\", \\\"{x:497,y:476,t:1527876857870};\\\", \\\"{x:496,y:474,t:1527876857886};\\\", \\\"{x:495,y:474,t:1527876857903};\\\", \\\"{x:495,y:473,t:1527876857920};\\\", \\\"{x:494,y:471,t:1527876857936};\\\", \\\"{x:493,y:471,t:1527876857953};\\\", \\\"{x:493,y:469,t:1527876857970};\\\", \\\"{x:490,y:466,t:1527876857987};\\\", \\\"{x:488,y:463,t:1527876858003};\\\", \\\"{x:485,y:461,t:1527876858019};\\\", \\\"{x:480,y:457,t:1527876858036};\\\", \\\"{x:473,y:455,t:1527876858053};\\\", \\\"{x:469,y:454,t:1527876858070};\\\", \\\"{x:467,y:454,t:1527876858086};\\\", \\\"{x:466,y:454,t:1527876858103};\\\", \\\"{x:465,y:454,t:1527876858120};\\\", \\\"{x:464,y:454,t:1527876858156};\\\", \\\"{x:463,y:453,t:1527876858180};\\\", \\\"{x:462,y:453,t:1527876858236};\\\", \\\"{x:461,y:453,t:1527876858300};\\\", \\\"{x:460,y:453,t:1527876858323};\\\", \\\"{x:460,y:454,t:1527876858337};\\\", \\\"{x:460,y:457,t:1527876858353};\\\", \\\"{x:463,y:462,t:1527876858371};\\\", \\\"{x:474,y:468,t:1527876858387};\\\", \\\"{x:478,y:470,t:1527876858404};\\\", \\\"{x:489,y:472,t:1527876858420};\\\", \\\"{x:504,y:475,t:1527876858437};\\\", \\\"{x:529,y:475,t:1527876858453};\\\", \\\"{x:562,y:475,t:1527876858470};\\\", \\\"{x:604,y:475,t:1527876858488};\\\", \\\"{x:626,y:475,t:1527876858504};\\\", \\\"{x:640,y:475,t:1527876858520};\\\", \\\"{x:648,y:476,t:1527876858537};\\\", \\\"{x:660,y:479,t:1527876858554};\\\", \\\"{x:674,y:481,t:1527876858571};\\\", \\\"{x:707,y:486,t:1527876858587};\\\", \\\"{x:736,y:488,t:1527876858606};\\\", \\\"{x:770,y:493,t:1527876858620};\\\", \\\"{x:828,y:501,t:1527876858639};\\\", \\\"{x:881,y:509,t:1527876858654};\\\", \\\"{x:932,y:518,t:1527876858670};\\\", \\\"{x:987,y:529,t:1527876858687};\\\", \\\"{x:1046,y:541,t:1527876858704};\\\", \\\"{x:1108,y:558,t:1527876858720};\\\", \\\"{x:1166,y:575,t:1527876858737};\\\", \\\"{x:1225,y:593,t:1527876858754};\\\", \\\"{x:1290,y:618,t:1527876858770};\\\", \\\"{x:1375,y:648,t:1527876858787};\\\", \\\"{x:1413,y:662,t:1527876858804};\\\", \\\"{x:1429,y:668,t:1527876858820};\\\", \\\"{x:1436,y:673,t:1527876858837};\\\", \\\"{x:1449,y:681,t:1527876858854};\\\", \\\"{x:1455,y:688,t:1527876858870};\\\", \\\"{x:1457,y:692,t:1527876858887};\\\", \\\"{x:1460,y:695,t:1527876858904};\\\", \\\"{x:1466,y:705,t:1527876858920};\\\", \\\"{x:1474,y:713,t:1527876858937};\\\", \\\"{x:1478,y:720,t:1527876858953};\\\", \\\"{x:1478,y:721,t:1527876858970};\\\", \\\"{x:1478,y:724,t:1527876858987};\\\", \\\"{x:1478,y:725,t:1527876859011};\\\", \\\"{x:1477,y:726,t:1527876859036};\\\", \\\"{x:1475,y:728,t:1527876859052};\\\", \\\"{x:1471,y:729,t:1527876859059};\\\", \\\"{x:1467,y:730,t:1527876859070};\\\", \\\"{x:1457,y:732,t:1527876859088};\\\", \\\"{x:1448,y:732,t:1527876859104};\\\", \\\"{x:1443,y:733,t:1527876859120};\\\", \\\"{x:1439,y:734,t:1527876859138};\\\", \\\"{x:1434,y:734,t:1527876859153};\\\", \\\"{x:1429,y:734,t:1527876859171};\\\", \\\"{x:1413,y:732,t:1527876859188};\\\", \\\"{x:1405,y:730,t:1527876859203};\\\", \\\"{x:1398,y:727,t:1527876859221};\\\", \\\"{x:1395,y:726,t:1527876859238};\\\", \\\"{x:1391,y:723,t:1527876859253};\\\", \\\"{x:1387,y:720,t:1527876859271};\\\", \\\"{x:1382,y:716,t:1527876859288};\\\", \\\"{x:1379,y:715,t:1527876859304};\\\", \\\"{x:1376,y:713,t:1527876859321};\\\", \\\"{x:1374,y:710,t:1527876859338};\\\", \\\"{x:1371,y:705,t:1527876859354};\\\", \\\"{x:1368,y:700,t:1527876859371};\\\", \\\"{x:1364,y:694,t:1527876859388};\\\", \\\"{x:1362,y:692,t:1527876859403};\\\", \\\"{x:1361,y:692,t:1527876859420};\\\", \\\"{x:1361,y:691,t:1527876859555};\\\", \\\"{x:1360,y:691,t:1527876859579};\\\", \\\"{x:1359,y:692,t:1527876859587};\\\", \\\"{x:1358,y:696,t:1527876859603};\\\", \\\"{x:1357,y:697,t:1527876859620};\\\", \\\"{x:1357,y:701,t:1527876859637};\\\", \\\"{x:1357,y:704,t:1527876859653};\\\", \\\"{x:1357,y:709,t:1527876859670};\\\", \\\"{x:1357,y:714,t:1527876859687};\\\", \\\"{x:1357,y:718,t:1527876859704};\\\", \\\"{x:1358,y:721,t:1527876859721};\\\", \\\"{x:1358,y:723,t:1527876859737};\\\", \\\"{x:1359,y:725,t:1527876859754};\\\", \\\"{x:1360,y:727,t:1527876859770};\\\", \\\"{x:1362,y:729,t:1527876859788};\\\", \\\"{x:1364,y:730,t:1527876859803};\\\", \\\"{x:1365,y:732,t:1527876859820};\\\", \\\"{x:1368,y:735,t:1527876859839};\\\", \\\"{x:1372,y:740,t:1527876859854};\\\", \\\"{x:1376,y:744,t:1527876859871};\\\", \\\"{x:1381,y:750,t:1527876859887};\\\", \\\"{x:1388,y:756,t:1527876859903};\\\", \\\"{x:1392,y:758,t:1527876859921};\\\", \\\"{x:1393,y:760,t:1527876859937};\\\", \\\"{x:1394,y:760,t:1527876859954};\\\", \\\"{x:1396,y:762,t:1527876859971};\\\", \\\"{x:1396,y:764,t:1527876860003};\\\", \\\"{x:1396,y:765,t:1527876860036};\\\", \\\"{x:1396,y:766,t:1527876860067};\\\", \\\"{x:1395,y:767,t:1527876860076};\\\", \\\"{x:1394,y:767,t:1527876860092};\\\", \\\"{x:1392,y:767,t:1527876860103};\\\", \\\"{x:1387,y:764,t:1527876860121};\\\", \\\"{x:1383,y:759,t:1527876860138};\\\", \\\"{x:1379,y:754,t:1527876860154};\\\", \\\"{x:1377,y:749,t:1527876860170};\\\", \\\"{x:1376,y:742,t:1527876860187};\\\", \\\"{x:1373,y:736,t:1527876860203};\\\", \\\"{x:1373,y:734,t:1527876860220};\\\", \\\"{x:1372,y:731,t:1527876860237};\\\", \\\"{x:1371,y:730,t:1527876860254};\\\", \\\"{x:1371,y:729,t:1527876860270};\\\", \\\"{x:1370,y:727,t:1527876860287};\\\", \\\"{x:1370,y:725,t:1527876860304};\\\", \\\"{x:1370,y:723,t:1527876860320};\\\", \\\"{x:1369,y:722,t:1527876860336};\\\", \\\"{x:1369,y:721,t:1527876860353};\\\", \\\"{x:1369,y:720,t:1527876860370};\\\", \\\"{x:1369,y:718,t:1527876860386};\\\", \\\"{x:1369,y:713,t:1527876860403};\\\", \\\"{x:1370,y:712,t:1527876860420};\\\", \\\"{x:1370,y:710,t:1527876860436};\\\", \\\"{x:1370,y:709,t:1527876860453};\\\", \\\"{x:1370,y:707,t:1527876860470};\\\", \\\"{x:1370,y:706,t:1527876860487};\\\", \\\"{x:1371,y:705,t:1527876860503};\\\", \\\"{x:1372,y:704,t:1527876860520};\\\", \\\"{x:1373,y:703,t:1527876860536};\\\", \\\"{x:1374,y:702,t:1527876860554};\\\", \\\"{x:1375,y:702,t:1527876860570};\\\", \\\"{x:1375,y:701,t:1527876860587};\\\", \\\"{x:1376,y:701,t:1527876860612};\\\", \\\"{x:1376,y:700,t:1527876860627};\\\", \\\"{x:1377,y:700,t:1527876860652};\\\", \\\"{x:1378,y:699,t:1527876860668};\\\", \\\"{x:1378,y:698,t:1527876860676};\\\", \\\"{x:1380,y:697,t:1527876860686};\\\", \\\"{x:1379,y:697,t:1527876860789};\\\", \\\"{x:1378,y:698,t:1527876860804};\\\", \\\"{x:1377,y:703,t:1527876860821};\\\", \\\"{x:1377,y:706,t:1527876860836};\\\", \\\"{x:1375,y:709,t:1527876860853};\\\", \\\"{x:1374,y:711,t:1527876860871};\\\", \\\"{x:1374,y:713,t:1527876860887};\\\", \\\"{x:1374,y:715,t:1527876860903};\\\", \\\"{x:1374,y:716,t:1527876860920};\\\", \\\"{x:1374,y:715,t:1527876861052};\\\", \\\"{x:1374,y:713,t:1527876861060};\\\", \\\"{x:1374,y:709,t:1527876861071};\\\", \\\"{x:1374,y:707,t:1527876861086};\\\", \\\"{x:1372,y:704,t:1527876861104};\\\", \\\"{x:1371,y:702,t:1527876861121};\\\", \\\"{x:1370,y:700,t:1527876861137};\\\", \\\"{x:1368,y:698,t:1527876861154};\\\", \\\"{x:1368,y:696,t:1527876861171};\\\", \\\"{x:1367,y:695,t:1527876861188};\\\", \\\"{x:1366,y:693,t:1527876861204};\\\", \\\"{x:1365,y:692,t:1527876861332};\\\", \\\"{x:1364,y:692,t:1527876861348};\\\", \\\"{x:1363,y:692,t:1527876861355};\\\", \\\"{x:1362,y:692,t:1527876861371};\\\", \\\"{x:1359,y:693,t:1527876861387};\\\", \\\"{x:1356,y:696,t:1527876861404};\\\", \\\"{x:1356,y:698,t:1527876861421};\\\", \\\"{x:1358,y:696,t:1527876861661};\\\", \\\"{x:1362,y:692,t:1527876861670};\\\", \\\"{x:1370,y:683,t:1527876861686};\\\", \\\"{x:1384,y:675,t:1527876861703};\\\", \\\"{x:1402,y:662,t:1527876861720};\\\", \\\"{x:1418,y:650,t:1527876861737};\\\", \\\"{x:1428,y:640,t:1527876861754};\\\", \\\"{x:1433,y:636,t:1527876861770};\\\", \\\"{x:1436,y:632,t:1527876861787};\\\", \\\"{x:1441,y:619,t:1527876861803};\\\", \\\"{x:1442,y:614,t:1527876861819};\\\", \\\"{x:1445,y:607,t:1527876861836};\\\", \\\"{x:1447,y:594,t:1527876861854};\\\", \\\"{x:1447,y:585,t:1527876861870};\\\", \\\"{x:1447,y:583,t:1527876861886};\\\", \\\"{x:1447,y:582,t:1527876861904};\\\", \\\"{x:1447,y:581,t:1527876861920};\\\", \\\"{x:1447,y:579,t:1527876861937};\\\", \\\"{x:1445,y:577,t:1527876861954};\\\", \\\"{x:1443,y:574,t:1527876861970};\\\", \\\"{x:1440,y:571,t:1527876861987};\\\", \\\"{x:1433,y:566,t:1527876862004};\\\", \\\"{x:1431,y:564,t:1527876862020};\\\", \\\"{x:1429,y:561,t:1527876862037};\\\", \\\"{x:1426,y:560,t:1527876862054};\\\", \\\"{x:1425,y:558,t:1527876862070};\\\", \\\"{x:1423,y:557,t:1527876862086};\\\", \\\"{x:1422,y:556,t:1527876862104};\\\", \\\"{x:1417,y:556,t:1527876862444};\\\", \\\"{x:1376,y:559,t:1527876862455};\\\", \\\"{x:1212,y:583,t:1527876862469};\\\", \\\"{x:1065,y:589,t:1527876862486};\\\", \\\"{x:1029,y:592,t:1527876862503};\\\", \\\"{x:950,y:591,t:1527876862520};\\\", \\\"{x:892,y:597,t:1527876862537};\\\", \\\"{x:798,y:595,t:1527876862556};\\\", \\\"{x:777,y:591,t:1527876862574};\\\", \\\"{x:775,y:590,t:1527876862590};\\\", \\\"{x:775,y:589,t:1527876862611};\\\", \\\"{x:775,y:588,t:1527876862623};\\\", \\\"{x:777,y:588,t:1527876862640};\\\", \\\"{x:779,y:587,t:1527876862657};\\\", \\\"{x:781,y:586,t:1527876862673};\\\", \\\"{x:782,y:585,t:1527876862690};\\\", \\\"{x:780,y:583,t:1527876862707};\\\", \\\"{x:761,y:579,t:1527876862724};\\\", \\\"{x:730,y:575,t:1527876862740};\\\", \\\"{x:679,y:575,t:1527876862758};\\\", \\\"{x:608,y:572,t:1527876862774};\\\", \\\"{x:539,y:561,t:1527876862790};\\\", \\\"{x:485,y:553,t:1527876862807};\\\", \\\"{x:435,y:546,t:1527876862823};\\\", \\\"{x:402,y:539,t:1527876862840};\\\", \\\"{x:374,y:535,t:1527876862857};\\\", \\\"{x:359,y:532,t:1527876862873};\\\", \\\"{x:350,y:529,t:1527876862891};\\\", \\\"{x:342,y:526,t:1527876862906};\\\", \\\"{x:337,y:524,t:1527876862925};\\\", \\\"{x:330,y:523,t:1527876862940};\\\", \\\"{x:319,y:523,t:1527876862957};\\\", \\\"{x:305,y:523,t:1527876862973};\\\", \\\"{x:288,y:523,t:1527876862990};\\\", \\\"{x:269,y:523,t:1527876863007};\\\", \\\"{x:246,y:525,t:1527876863023};\\\", \\\"{x:208,y:533,t:1527876863040};\\\", \\\"{x:177,y:542,t:1527876863058};\\\", \\\"{x:161,y:544,t:1527876863074};\\\", \\\"{x:156,y:545,t:1527876863090};\\\", \\\"{x:154,y:545,t:1527876863139};\\\", \\\"{x:153,y:547,t:1527876863147};\\\", \\\"{x:151,y:550,t:1527876863157};\\\", \\\"{x:148,y:555,t:1527876863174};\\\", \\\"{x:146,y:558,t:1527876863190};\\\", \\\"{x:146,y:561,t:1527876863207};\\\", \\\"{x:147,y:567,t:1527876863224};\\\", \\\"{x:151,y:573,t:1527876863241};\\\", \\\"{x:155,y:575,t:1527876863257};\\\", \\\"{x:158,y:577,t:1527876863274};\\\", \\\"{x:164,y:577,t:1527876863290};\\\", \\\"{x:179,y:577,t:1527876863307};\\\", \\\"{x:207,y:577,t:1527876863325};\\\", \\\"{x:236,y:577,t:1527876863342};\\\", \\\"{x:268,y:577,t:1527876863357};\\\", \\\"{x:293,y:577,t:1527876863376};\\\", \\\"{x:316,y:577,t:1527876863391};\\\", \\\"{x:342,y:578,t:1527876863408};\\\", \\\"{x:371,y:579,t:1527876863424};\\\", \\\"{x:407,y:579,t:1527876863441};\\\", \\\"{x:443,y:579,t:1527876863458};\\\", \\\"{x:488,y:579,t:1527876863474};\\\", \\\"{x:563,y:579,t:1527876863492};\\\", \\\"{x:616,y:579,t:1527876863508};\\\", \\\"{x:655,y:579,t:1527876863524};\\\", \\\"{x:682,y:579,t:1527876863541};\\\", \\\"{x:699,y:579,t:1527876863557};\\\", \\\"{x:709,y:579,t:1527876863574};\\\", \\\"{x:716,y:579,t:1527876863591};\\\", \\\"{x:724,y:578,t:1527876863608};\\\", \\\"{x:733,y:577,t:1527876863625};\\\", \\\"{x:742,y:575,t:1527876863642};\\\", \\\"{x:750,y:574,t:1527876863658};\\\", \\\"{x:759,y:573,t:1527876863674};\\\", \\\"{x:767,y:572,t:1527876863691};\\\", \\\"{x:769,y:572,t:1527876863708};\\\", \\\"{x:771,y:572,t:1527876863725};\\\", \\\"{x:772,y:572,t:1527876863741};\\\", \\\"{x:773,y:572,t:1527876863758};\\\", \\\"{x:776,y:572,t:1527876863775};\\\", \\\"{x:780,y:570,t:1527876863791};\\\", \\\"{x:783,y:570,t:1527876863808};\\\", \\\"{x:787,y:569,t:1527876863826};\\\", \\\"{x:789,y:569,t:1527876863842};\\\", \\\"{x:791,y:568,t:1527876863859};\\\", \\\"{x:794,y:567,t:1527876863876};\\\", \\\"{x:795,y:567,t:1527876863893};\\\", \\\"{x:796,y:566,t:1527876863909};\\\", \\\"{x:799,y:565,t:1527876863926};\\\", \\\"{x:804,y:565,t:1527876863942};\\\", \\\"{x:813,y:562,t:1527876863960};\\\", \\\"{x:821,y:562,t:1527876863977};\\\", \\\"{x:826,y:562,t:1527876863991};\\\", \\\"{x:832,y:562,t:1527876864008};\\\", \\\"{x:834,y:562,t:1527876864024};\\\", \\\"{x:836,y:563,t:1527876864042};\\\", \\\"{x:838,y:565,t:1527876864057};\\\", \\\"{x:840,y:567,t:1527876864074};\\\", \\\"{x:842,y:571,t:1527876864091};\\\", \\\"{x:842,y:572,t:1527876864108};\\\", \\\"{x:844,y:574,t:1527876864124};\\\", \\\"{x:844,y:575,t:1527876864146};\\\", \\\"{x:846,y:574,t:1527876864276};\\\", \\\"{x:847,y:570,t:1527876864291};\\\", \\\"{x:848,y:566,t:1527876864309};\\\", \\\"{x:849,y:563,t:1527876864325};\\\", \\\"{x:849,y:561,t:1527876864341};\\\", \\\"{x:849,y:560,t:1527876864358};\\\", \\\"{x:849,y:559,t:1527876864376};\\\", \\\"{x:849,y:557,t:1527876864716};\\\", \\\"{x:849,y:555,t:1527876864727};\\\", \\\"{x:849,y:551,t:1527876864742};\\\", \\\"{x:848,y:548,t:1527876864757};\\\", \\\"{x:848,y:547,t:1527876864774};\\\", \\\"{x:847,y:547,t:1527876864802};\\\", \\\"{x:842,y:547,t:1527876864987};\\\", \\\"{x:830,y:557,t:1527876864995};\\\", \\\"{x:816,y:567,t:1527876865010};\\\", \\\"{x:776,y:596,t:1527876865025};\\\", \\\"{x:730,y:624,t:1527876865043};\\\", \\\"{x:681,y:644,t:1527876865059};\\\", \\\"{x:661,y:657,t:1527876865075};\\\", \\\"{x:643,y:669,t:1527876865092};\\\", \\\"{x:631,y:680,t:1527876865108};\\\", \\\"{x:615,y:690,t:1527876865126};\\\", \\\"{x:605,y:699,t:1527876865142};\\\", \\\"{x:595,y:707,t:1527876865160};\\\", \\\"{x:584,y:716,t:1527876865175};\\\", \\\"{x:579,y:719,t:1527876865193};\\\", \\\"{x:577,y:719,t:1527876865300};\\\", \\\"{x:575,y:719,t:1527876865310};\\\", \\\"{x:572,y:719,t:1527876865326};\\\", \\\"{x:571,y:719,t:1527876865342};\\\", \\\"{x:559,y:723,t:1527876865361};\\\", \\\"{x:544,y:726,t:1527876865376};\\\", \\\"{x:530,y:730,t:1527876865392};\\\", \\\"{x:522,y:730,t:1527876865409};\\\", \\\"{x:520,y:730,t:1527876865426};\\\", \\\"{x:519,y:730,t:1527876865442};\\\", \\\"{x:521,y:730,t:1527876866315};\\\", \\\"{x:524,y:730,t:1527876866327};\\\", \\\"{x:531,y:725,t:1527876866343};\\\", \\\"{x:540,y:720,t:1527876866360};\\\", \\\"{x:550,y:714,t:1527876866377};\\\", \\\"{x:566,y:707,t:1527876866394};\\\", \\\"{x:586,y:698,t:1527876866410};\\\", \\\"{x:606,y:689,t:1527876866426};\\\", \\\"{x:640,y:678,t:1527876866443};\\\", \\\"{x:655,y:675,t:1527876866459};\\\", \\\"{x:663,y:673,t:1527876866476};\\\", \\\"{x:664,y:673,t:1527876866493};\\\", \\\"{x:666,y:672,t:1527876866511};\\\", \\\"{x:668,y:672,t:1527876866531};\\\", \\\"{x:672,y:671,t:1527876866544};\\\", \\\"{x:683,y:671,t:1527876866561};\\\", \\\"{x:696,y:668,t:1527876866585};\\\", \\\"{x:700,y:667,t:1527876866593};\\\", \\\"{x:705,y:666,t:1527876866610};\\\", \\\"{x:709,y:665,t:1527876866626};\\\", \\\"{x:712,y:663,t:1527876866643};\\\", \\\"{x:715,y:663,t:1527876866659};\\\" ] }, { \\\"rt\\\": 13240, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 492473, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -L -Z -Z -02 PM-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:745,y:649,t:1527876866832};\\\", \\\"{x:749,y:646,t:1527876866860};\\\", \\\"{x:749,y:645,t:1527876866876};\\\", \\\"{x:750,y:645,t:1527876866893};\\\", \\\"{x:752,y:644,t:1527876866922};\\\", \\\"{x:753,y:644,t:1527876866931};\\\", \\\"{x:753,y:643,t:1527876866947};\\\", \\\"{x:754,y:643,t:1527876867003};\\\", \\\"{x:755,y:642,t:1527876867059};\\\", \\\"{x:757,y:642,t:1527876867075};\\\", \\\"{x:760,y:641,t:1527876867083};\\\", \\\"{x:764,y:639,t:1527876867094};\\\", \\\"{x:775,y:637,t:1527876867110};\\\", \\\"{x:776,y:636,t:1527876867237};\\\", \\\"{x:776,y:635,t:1527876867250};\\\", \\\"{x:776,y:633,t:1527876867261};\\\", \\\"{x:776,y:632,t:1527876867277};\\\", \\\"{x:773,y:623,t:1527876867294};\\\", \\\"{x:765,y:616,t:1527876867310};\\\", \\\"{x:749,y:605,t:1527876867327};\\\", \\\"{x:724,y:591,t:1527876867344};\\\", \\\"{x:691,y:578,t:1527876867361};\\\", \\\"{x:650,y:562,t:1527876867378};\\\", \\\"{x:626,y:551,t:1527876867394};\\\", \\\"{x:608,y:541,t:1527876867411};\\\", \\\"{x:603,y:537,t:1527876867427};\\\", \\\"{x:600,y:535,t:1527876867444};\\\", \\\"{x:599,y:534,t:1527876867461};\\\", \\\"{x:598,y:534,t:1527876867507};\\\", \\\"{x:597,y:534,t:1527876867531};\\\", \\\"{x:595,y:533,t:1527876867545};\\\", \\\"{x:590,y:530,t:1527876867560};\\\", \\\"{x:579,y:524,t:1527876867578};\\\", \\\"{x:571,y:520,t:1527876867595};\\\", \\\"{x:555,y:511,t:1527876867611};\\\", \\\"{x:543,y:505,t:1527876867627};\\\", \\\"{x:527,y:495,t:1527876867648};\\\", \\\"{x:515,y:489,t:1527876867665};\\\", \\\"{x:509,y:485,t:1527876867682};\\\", \\\"{x:505,y:483,t:1527876867699};\\\", \\\"{x:499,y:480,t:1527876867715};\\\", \\\"{x:494,y:477,t:1527876867732};\\\", \\\"{x:482,y:470,t:1527876867749};\\\", \\\"{x:468,y:464,t:1527876867765};\\\", \\\"{x:458,y:459,t:1527876867782};\\\", \\\"{x:453,y:457,t:1527876867799};\\\", \\\"{x:442,y:453,t:1527876867815};\\\", \\\"{x:433,y:450,t:1527876867831};\\\", \\\"{x:429,y:450,t:1527876867849};\\\", \\\"{x:426,y:450,t:1527876867896};\\\", \\\"{x:425,y:450,t:1527876867903};\\\", \\\"{x:422,y:450,t:1527876867916};\\\", \\\"{x:419,y:450,t:1527876867932};\\\", \\\"{x:418,y:450,t:1527876867949};\\\", \\\"{x:412,y:452,t:1527876867966};\\\", \\\"{x:407,y:456,t:1527876867982};\\\", \\\"{x:404,y:457,t:1527876867999};\\\", \\\"{x:403,y:457,t:1527876868024};\\\", \\\"{x:403,y:458,t:1527876868152};\\\", \\\"{x:406,y:458,t:1527876868166};\\\", \\\"{x:418,y:459,t:1527876868182};\\\", \\\"{x:432,y:461,t:1527876868199};\\\", \\\"{x:453,y:463,t:1527876868216};\\\", \\\"{x:469,y:463,t:1527876868232};\\\", \\\"{x:483,y:463,t:1527876868249};\\\", \\\"{x:492,y:463,t:1527876868266};\\\", \\\"{x:497,y:464,t:1527876868283};\\\", \\\"{x:499,y:464,t:1527876868299};\\\", \\\"{x:503,y:465,t:1527876868316};\\\", \\\"{x:505,y:467,t:1527876868332};\\\", \\\"{x:512,y:467,t:1527876868349};\\\", \\\"{x:515,y:468,t:1527876868366};\\\", \\\"{x:519,y:468,t:1527876868382};\\\", \\\"{x:520,y:468,t:1527876868399};\\\", \\\"{x:521,y:468,t:1527876868416};\\\", \\\"{x:521,y:469,t:1527876868433};\\\", \\\"{x:522,y:469,t:1527876868633};\\\", \\\"{x:524,y:468,t:1527876868649};\\\", \\\"{x:526,y:467,t:1527876868666};\\\", \\\"{x:527,y:466,t:1527876868684};\\\", \\\"{x:530,y:465,t:1527876868699};\\\", \\\"{x:531,y:464,t:1527876868716};\\\", \\\"{x:533,y:463,t:1527876868733};\\\", \\\"{x:534,y:463,t:1527876868749};\\\", \\\"{x:539,y:461,t:1527876868767};\\\", \\\"{x:540,y:460,t:1527876868784};\\\", \\\"{x:544,y:459,t:1527876868800};\\\", \\\"{x:555,y:459,t:1527876868816};\\\", \\\"{x:561,y:459,t:1527876868833};\\\", \\\"{x:567,y:459,t:1527876868849};\\\", \\\"{x:573,y:459,t:1527876868866};\\\", \\\"{x:576,y:459,t:1527876868882};\\\", \\\"{x:578,y:459,t:1527876868900};\\\", \\\"{x:579,y:459,t:1527876868916};\\\", \\\"{x:581,y:459,t:1527876868932};\\\", \\\"{x:582,y:457,t:1527876868948};\\\", \\\"{x:589,y:457,t:1527876869432};\\\", \\\"{x:611,y:457,t:1527876869451};\\\", \\\"{x:633,y:457,t:1527876869466};\\\", \\\"{x:660,y:457,t:1527876869484};\\\", \\\"{x:683,y:457,t:1527876869500};\\\", \\\"{x:706,y:457,t:1527876869516};\\\", \\\"{x:735,y:457,t:1527876869533};\\\", \\\"{x:767,y:457,t:1527876869550};\\\", \\\"{x:826,y:457,t:1527876869567};\\\", \\\"{x:882,y:464,t:1527876869584};\\\", \\\"{x:928,y:469,t:1527876869600};\\\", \\\"{x:971,y:476,t:1527876869617};\\\", \\\"{x:1022,y:483,t:1527876869634};\\\", \\\"{x:1076,y:494,t:1527876869650};\\\", \\\"{x:1135,y:503,t:1527876869668};\\\", \\\"{x:1204,y:520,t:1527876869684};\\\", \\\"{x:1256,y:535,t:1527876869701};\\\", \\\"{x:1293,y:553,t:1527876869718};\\\", \\\"{x:1343,y:576,t:1527876869733};\\\", \\\"{x:1388,y:596,t:1527876869751};\\\", \\\"{x:1428,y:623,t:1527876869768};\\\", \\\"{x:1453,y:641,t:1527876869784};\\\", \\\"{x:1472,y:658,t:1527876869800};\\\", \\\"{x:1489,y:677,t:1527876869818};\\\", \\\"{x:1504,y:696,t:1527876869833};\\\", \\\"{x:1513,y:714,t:1527876869850};\\\", \\\"{x:1520,y:730,t:1527876869867};\\\", \\\"{x:1525,y:747,t:1527876869883};\\\", \\\"{x:1529,y:760,t:1527876869899};\\\", \\\"{x:1530,y:770,t:1527876869917};\\\", \\\"{x:1530,y:780,t:1527876869933};\\\", \\\"{x:1530,y:788,t:1527876869950};\\\", \\\"{x:1530,y:801,t:1527876869967};\\\", \\\"{x:1530,y:809,t:1527876869983};\\\", \\\"{x:1530,y:817,t:1527876870000};\\\", \\\"{x:1530,y:824,t:1527876870017};\\\", \\\"{x:1532,y:829,t:1527876870033};\\\", \\\"{x:1533,y:832,t:1527876870050};\\\", \\\"{x:1536,y:836,t:1527876870067};\\\", \\\"{x:1538,y:837,t:1527876870111};\\\", \\\"{x:1539,y:837,t:1527876870120};\\\", \\\"{x:1542,y:839,t:1527876870134};\\\", \\\"{x:1546,y:839,t:1527876870150};\\\", \\\"{x:1554,y:839,t:1527876870167};\\\", \\\"{x:1558,y:839,t:1527876870184};\\\", \\\"{x:1562,y:837,t:1527876870200};\\\", \\\"{x:1564,y:835,t:1527876870217};\\\", \\\"{x:1565,y:835,t:1527876870235};\\\", \\\"{x:1566,y:834,t:1527876870250};\\\", \\\"{x:1567,y:833,t:1527876870267};\\\", \\\"{x:1568,y:832,t:1527876870284};\\\", \\\"{x:1569,y:832,t:1527876870301};\\\", \\\"{x:1569,y:830,t:1527876870321};\\\", \\\"{x:1569,y:829,t:1527876870335};\\\", \\\"{x:1568,y:825,t:1527876870350};\\\", \\\"{x:1559,y:820,t:1527876870368};\\\", \\\"{x:1557,y:819,t:1527876870384};\\\", \\\"{x:1555,y:818,t:1527876870401};\\\", \\\"{x:1554,y:818,t:1527876870418};\\\", \\\"{x:1552,y:818,t:1527876870435};\\\", \\\"{x:1551,y:818,t:1527876870450};\\\", \\\"{x:1549,y:818,t:1527876870468};\\\", \\\"{x:1544,y:818,t:1527876870485};\\\", \\\"{x:1539,y:818,t:1527876870500};\\\", \\\"{x:1535,y:819,t:1527876870518};\\\", \\\"{x:1531,y:820,t:1527876870535};\\\", \\\"{x:1528,y:823,t:1527876870550};\\\", \\\"{x:1521,y:826,t:1527876870568};\\\", \\\"{x:1517,y:829,t:1527876870584};\\\", \\\"{x:1510,y:833,t:1527876870601};\\\", \\\"{x:1502,y:838,t:1527876870618};\\\", \\\"{x:1491,y:845,t:1527876870634};\\\", \\\"{x:1484,y:848,t:1527876870652};\\\", \\\"{x:1478,y:850,t:1527876870668};\\\", \\\"{x:1473,y:850,t:1527876870684};\\\", \\\"{x:1469,y:852,t:1527876870701};\\\", \\\"{x:1467,y:852,t:1527876870718};\\\", \\\"{x:1465,y:852,t:1527876870735};\\\", \\\"{x:1454,y:852,t:1527876870752};\\\", \\\"{x:1448,y:852,t:1527876870768};\\\", \\\"{x:1439,y:852,t:1527876870785};\\\", \\\"{x:1424,y:852,t:1527876870801};\\\", \\\"{x:1405,y:852,t:1527876870818};\\\", \\\"{x:1384,y:852,t:1527876870835};\\\", \\\"{x:1363,y:852,t:1527876870852};\\\", \\\"{x:1341,y:852,t:1527876870867};\\\", \\\"{x:1327,y:852,t:1527876870884};\\\", \\\"{x:1322,y:852,t:1527876870902};\\\", \\\"{x:1314,y:851,t:1527876870918};\\\", \\\"{x:1311,y:850,t:1527876870935};\\\", \\\"{x:1306,y:845,t:1527876870952};\\\", \\\"{x:1303,y:836,t:1527876870968};\\\", \\\"{x:1303,y:830,t:1527876870985};\\\", \\\"{x:1303,y:820,t:1527876871001};\\\", \\\"{x:1309,y:809,t:1527876871017};\\\", \\\"{x:1319,y:793,t:1527876871034};\\\", \\\"{x:1331,y:779,t:1527876871051};\\\", \\\"{x:1343,y:764,t:1527876871070};\\\", \\\"{x:1352,y:750,t:1527876871086};\\\", \\\"{x:1362,y:734,t:1527876871102};\\\", \\\"{x:1366,y:726,t:1527876871118};\\\", \\\"{x:1371,y:719,t:1527876871135};\\\", \\\"{x:1379,y:703,t:1527876871151};\\\", \\\"{x:1386,y:692,t:1527876871168};\\\", \\\"{x:1392,y:680,t:1527876871185};\\\", \\\"{x:1401,y:665,t:1527876871201};\\\", \\\"{x:1408,y:653,t:1527876871217};\\\", \\\"{x:1413,y:644,t:1527876871235};\\\", \\\"{x:1420,y:629,t:1527876871251};\\\", \\\"{x:1427,y:617,t:1527876871269};\\\", \\\"{x:1434,y:603,t:1527876871284};\\\", \\\"{x:1442,y:592,t:1527876871301};\\\", \\\"{x:1450,y:584,t:1527876871317};\\\", \\\"{x:1459,y:575,t:1527876871333};\\\", \\\"{x:1481,y:559,t:1527876871359};\\\", \\\"{x:1484,y:557,t:1527876871367};\\\", \\\"{x:1487,y:552,t:1527876871384};\\\", \\\"{x:1493,y:544,t:1527876871401};\\\", \\\"{x:1503,y:535,t:1527876871418};\\\", \\\"{x:1510,y:528,t:1527876871434};\\\", \\\"{x:1515,y:523,t:1527876871451};\\\", \\\"{x:1521,y:518,t:1527876871468};\\\", \\\"{x:1524,y:515,t:1527876871484};\\\", \\\"{x:1529,y:510,t:1527876871501};\\\", \\\"{x:1533,y:506,t:1527876871518};\\\", \\\"{x:1534,y:503,t:1527876871534};\\\", \\\"{x:1537,y:497,t:1527876871551};\\\", \\\"{x:1539,y:495,t:1527876871568};\\\", \\\"{x:1540,y:494,t:1527876871584};\\\", \\\"{x:1541,y:490,t:1527876871601};\\\", \\\"{x:1542,y:490,t:1527876871618};\\\", \\\"{x:1546,y:488,t:1527876871634};\\\", \\\"{x:1553,y:487,t:1527876871651};\\\", \\\"{x:1562,y:485,t:1527876871668};\\\", \\\"{x:1569,y:485,t:1527876871684};\\\", \\\"{x:1577,y:485,t:1527876871701};\\\", \\\"{x:1590,y:488,t:1527876871719};\\\", \\\"{x:1610,y:503,t:1527876871734};\\\", \\\"{x:1625,y:515,t:1527876871751};\\\", \\\"{x:1628,y:517,t:1527876871768};\\\", \\\"{x:1628,y:521,t:1527876871785};\\\", \\\"{x:1628,y:526,t:1527876871801};\\\", \\\"{x:1628,y:534,t:1527876871818};\\\", \\\"{x:1627,y:541,t:1527876871835};\\\", \\\"{x:1623,y:553,t:1527876871851};\\\", \\\"{x:1621,y:559,t:1527876871868};\\\", \\\"{x:1617,y:567,t:1527876871886};\\\", \\\"{x:1613,y:573,t:1527876871901};\\\", \\\"{x:1611,y:578,t:1527876871918};\\\", \\\"{x:1605,y:582,t:1527876871935};\\\", \\\"{x:1599,y:587,t:1527876871952};\\\", \\\"{x:1589,y:594,t:1527876871968};\\\", \\\"{x:1577,y:602,t:1527876871985};\\\", \\\"{x:1562,y:610,t:1527876872001};\\\", \\\"{x:1554,y:615,t:1527876872018};\\\", \\\"{x:1543,y:621,t:1527876872036};\\\", \\\"{x:1531,y:626,t:1527876872051};\\\", \\\"{x:1520,y:628,t:1527876872069};\\\", \\\"{x:1511,y:631,t:1527876872086};\\\", \\\"{x:1501,y:635,t:1527876872102};\\\", \\\"{x:1490,y:640,t:1527876872119};\\\", \\\"{x:1479,y:644,t:1527876872135};\\\", \\\"{x:1474,y:647,t:1527876872152};\\\", \\\"{x:1469,y:650,t:1527876872169};\\\", \\\"{x:1465,y:653,t:1527876872186};\\\", \\\"{x:1461,y:657,t:1527876872202};\\\", \\\"{x:1453,y:664,t:1527876872219};\\\", \\\"{x:1448,y:670,t:1527876872236};\\\", \\\"{x:1443,y:674,t:1527876872251};\\\", \\\"{x:1440,y:677,t:1527876872269};\\\", \\\"{x:1440,y:679,t:1527876872286};\\\", \\\"{x:1440,y:684,t:1527876872302};\\\", \\\"{x:1440,y:691,t:1527876872318};\\\", \\\"{x:1448,y:704,t:1527876872336};\\\", \\\"{x:1462,y:711,t:1527876872352};\\\", \\\"{x:1471,y:716,t:1527876872369};\\\", \\\"{x:1475,y:719,t:1527876872386};\\\", \\\"{x:1476,y:721,t:1527876872402};\\\", \\\"{x:1477,y:725,t:1527876872418};\\\", \\\"{x:1477,y:730,t:1527876872436};\\\", \\\"{x:1479,y:738,t:1527876872453};\\\", \\\"{x:1479,y:745,t:1527876872468};\\\", \\\"{x:1479,y:751,t:1527876872485};\\\", \\\"{x:1479,y:757,t:1527876872503};\\\", \\\"{x:1480,y:760,t:1527876872518};\\\", \\\"{x:1481,y:765,t:1527876872536};\\\", \\\"{x:1481,y:767,t:1527876872551};\\\", \\\"{x:1483,y:770,t:1527876872569};\\\", \\\"{x:1484,y:775,t:1527876872586};\\\", \\\"{x:1487,y:778,t:1527876872603};\\\", \\\"{x:1490,y:782,t:1527876872619};\\\", \\\"{x:1494,y:786,t:1527876872636};\\\", \\\"{x:1496,y:788,t:1527876872653};\\\", \\\"{x:1501,y:790,t:1527876872668};\\\", \\\"{x:1503,y:791,t:1527876872688};\\\", \\\"{x:1506,y:792,t:1527876872702};\\\", \\\"{x:1515,y:795,t:1527876872719};\\\", \\\"{x:1535,y:800,t:1527876872736};\\\", \\\"{x:1543,y:801,t:1527876872752};\\\", \\\"{x:1551,y:803,t:1527876872769};\\\", \\\"{x:1555,y:804,t:1527876872785};\\\", \\\"{x:1556,y:804,t:1527876872803};\\\", \\\"{x:1556,y:805,t:1527876872819};\\\", \\\"{x:1556,y:807,t:1527876872836};\\\", \\\"{x:1556,y:811,t:1527876872852};\\\", \\\"{x:1556,y:818,t:1527876872868};\\\", \\\"{x:1552,y:827,t:1527876872886};\\\", \\\"{x:1548,y:832,t:1527876872903};\\\", \\\"{x:1533,y:844,t:1527876872920};\\\", \\\"{x:1519,y:852,t:1527876872935};\\\", \\\"{x:1508,y:858,t:1527876872952};\\\", \\\"{x:1499,y:863,t:1527876872969};\\\", \\\"{x:1492,y:865,t:1527876872985};\\\", \\\"{x:1484,y:869,t:1527876873002};\\\", \\\"{x:1478,y:870,t:1527876873019};\\\", \\\"{x:1474,y:870,t:1527876873035};\\\", \\\"{x:1473,y:871,t:1527876873052};\\\", \\\"{x:1473,y:869,t:1527876873111};\\\", \\\"{x:1473,y:867,t:1527876873119};\\\", \\\"{x:1481,y:857,t:1527876873135};\\\", \\\"{x:1500,y:837,t:1527876873152};\\\", \\\"{x:1521,y:817,t:1527876873169};\\\", \\\"{x:1542,y:797,t:1527876873186};\\\", \\\"{x:1556,y:781,t:1527876873203};\\\", \\\"{x:1564,y:773,t:1527876873220};\\\", \\\"{x:1567,y:768,t:1527876873236};\\\", \\\"{x:1569,y:763,t:1527876873253};\\\", \\\"{x:1570,y:759,t:1527876873270};\\\", \\\"{x:1572,y:754,t:1527876873286};\\\", \\\"{x:1573,y:749,t:1527876873302};\\\", \\\"{x:1576,y:739,t:1527876873320};\\\", \\\"{x:1579,y:730,t:1527876873336};\\\", \\\"{x:1583,y:722,t:1527876873352};\\\", \\\"{x:1589,y:709,t:1527876873369};\\\", \\\"{x:1594,y:700,t:1527876873385};\\\", \\\"{x:1594,y:699,t:1527876873402};\\\", \\\"{x:1595,y:697,t:1527876873420};\\\", \\\"{x:1597,y:696,t:1527876873436};\\\", \\\"{x:1598,y:696,t:1527876873453};\\\", \\\"{x:1599,y:695,t:1527876873470};\\\", \\\"{x:1600,y:694,t:1527876873487};\\\", \\\"{x:1601,y:694,t:1527876873502};\\\", \\\"{x:1602,y:694,t:1527876873527};\\\", \\\"{x:1603,y:694,t:1527876873536};\\\", \\\"{x:1604,y:693,t:1527876873560};\\\", \\\"{x:1605,y:692,t:1527876873570};\\\", \\\"{x:1611,y:691,t:1527876873587};\\\", \\\"{x:1615,y:691,t:1527876873602};\\\", \\\"{x:1616,y:691,t:1527876873619};\\\", \\\"{x:1618,y:691,t:1527876873637};\\\", \\\"{x:1619,y:691,t:1527876873712};\\\", \\\"{x:1619,y:692,t:1527876873720};\\\", \\\"{x:1618,y:697,t:1527876873736};\\\", \\\"{x:1615,y:700,t:1527876873752};\\\", \\\"{x:1613,y:702,t:1527876873769};\\\", \\\"{x:1612,y:703,t:1527876873788};\\\", \\\"{x:1611,y:704,t:1527876873802};\\\", \\\"{x:1611,y:705,t:1527876873819};\\\", \\\"{x:1609,y:708,t:1527876873836};\\\", \\\"{x:1604,y:712,t:1527876873852};\\\", \\\"{x:1599,y:720,t:1527876873869};\\\", \\\"{x:1595,y:724,t:1527876873886};\\\", \\\"{x:1592,y:731,t:1527876873901};\\\", \\\"{x:1586,y:740,t:1527876873919};\\\", \\\"{x:1586,y:742,t:1527876873936};\\\", \\\"{x:1584,y:746,t:1527876873952};\\\", \\\"{x:1583,y:747,t:1527876873969};\\\", \\\"{x:1582,y:752,t:1527876873986};\\\", \\\"{x:1581,y:755,t:1527876874003};\\\", \\\"{x:1579,y:758,t:1527876874019};\\\", \\\"{x:1576,y:767,t:1527876874036};\\\", \\\"{x:1571,y:780,t:1527876874053};\\\", \\\"{x:1569,y:789,t:1527876874069};\\\", \\\"{x:1566,y:800,t:1527876874086};\\\", \\\"{x:1561,y:815,t:1527876874103};\\\", \\\"{x:1558,y:823,t:1527876874119};\\\", \\\"{x:1555,y:827,t:1527876874136};\\\", \\\"{x:1553,y:834,t:1527876874154};\\\", \\\"{x:1547,y:843,t:1527876874170};\\\", \\\"{x:1544,y:847,t:1527876874186};\\\", \\\"{x:1543,y:852,t:1527876874204};\\\", \\\"{x:1540,y:854,t:1527876874219};\\\", \\\"{x:1540,y:856,t:1527876874237};\\\", \\\"{x:1539,y:858,t:1527876874254};\\\", \\\"{x:1538,y:860,t:1527876874271};\\\", \\\"{x:1537,y:862,t:1527876874287};\\\", \\\"{x:1534,y:870,t:1527876874303};\\\", \\\"{x:1532,y:873,t:1527876874320};\\\", \\\"{x:1529,y:877,t:1527876874337};\\\", \\\"{x:1527,y:882,t:1527876874354};\\\", \\\"{x:1526,y:882,t:1527876874370};\\\", \\\"{x:1525,y:884,t:1527876874386};\\\", \\\"{x:1522,y:887,t:1527876874404};\\\", \\\"{x:1521,y:891,t:1527876874420};\\\", \\\"{x:1519,y:893,t:1527876874437};\\\", \\\"{x:1516,y:896,t:1527876874454};\\\", \\\"{x:1515,y:898,t:1527876874469};\\\", \\\"{x:1512,y:904,t:1527876874487};\\\", \\\"{x:1507,y:916,t:1527876874503};\\\", \\\"{x:1504,y:921,t:1527876874520};\\\", \\\"{x:1503,y:926,t:1527876874536};\\\", \\\"{x:1500,y:929,t:1527876874553};\\\", \\\"{x:1500,y:930,t:1527876874569};\\\", \\\"{x:1500,y:932,t:1527876874586};\\\", \\\"{x:1499,y:934,t:1527876874603};\\\", \\\"{x:1498,y:937,t:1527876874620};\\\", \\\"{x:1497,y:942,t:1527876874636};\\\", \\\"{x:1496,y:944,t:1527876874653};\\\", \\\"{x:1495,y:947,t:1527876874670};\\\", \\\"{x:1495,y:949,t:1527876874686};\\\", \\\"{x:1495,y:950,t:1527876874711};\\\", \\\"{x:1495,y:952,t:1527876874736};\\\", \\\"{x:1495,y:953,t:1527876874754};\\\", \\\"{x:1493,y:955,t:1527876874783};\\\", \\\"{x:1493,y:956,t:1527876874856};\\\", \\\"{x:1493,y:957,t:1527876874872};\\\", \\\"{x:1493,y:958,t:1527876874886};\\\", \\\"{x:1493,y:959,t:1527876874903};\\\", \\\"{x:1492,y:959,t:1527876875032};\\\", \\\"{x:1492,y:961,t:1527876875128};\\\", \\\"{x:1491,y:961,t:1527876875144};\\\", \\\"{x:1491,y:962,t:1527876875154};\\\", \\\"{x:1490,y:962,t:1527876875192};\\\", \\\"{x:1489,y:963,t:1527876875204};\\\", \\\"{x:1487,y:963,t:1527876875221};\\\", \\\"{x:1486,y:964,t:1527876875288};\\\", \\\"{x:1484,y:965,t:1527876875303};\\\", \\\"{x:1481,y:966,t:1527876875321};\\\", \\\"{x:1478,y:969,t:1527876875338};\\\", \\\"{x:1477,y:969,t:1527876875353};\\\", \\\"{x:1476,y:969,t:1527876875371};\\\", \\\"{x:1475,y:969,t:1527876875387};\\\", \\\"{x:1474,y:970,t:1527876875404};\\\", \\\"{x:1473,y:970,t:1527876875423};\\\", \\\"{x:1473,y:971,t:1527876875456};\\\", \\\"{x:1473,y:969,t:1527876875800};\\\", \\\"{x:1473,y:968,t:1527876875809};\\\", \\\"{x:1473,y:964,t:1527876875821};\\\", \\\"{x:1473,y:958,t:1527876875838};\\\", \\\"{x:1473,y:956,t:1527876875855};\\\", \\\"{x:1473,y:955,t:1527876875871};\\\", \\\"{x:1473,y:953,t:1527876875920};\\\", \\\"{x:1472,y:951,t:1527876875937};\\\", \\\"{x:1470,y:950,t:1527876875955};\\\", \\\"{x:1469,y:949,t:1527876875970};\\\", \\\"{x:1468,y:949,t:1527876875988};\\\", \\\"{x:1467,y:948,t:1527876876005};\\\", \\\"{x:1466,y:947,t:1527876876039};\\\", \\\"{x:1465,y:945,t:1527876876055};\\\", \\\"{x:1464,y:944,t:1527876876070};\\\", \\\"{x:1463,y:941,t:1527876876087};\\\", \\\"{x:1461,y:939,t:1527876876104};\\\", \\\"{x:1459,y:936,t:1527876876120};\\\", \\\"{x:1456,y:934,t:1527876876138};\\\", \\\"{x:1454,y:932,t:1527876876155};\\\", \\\"{x:1453,y:930,t:1527876876170};\\\", \\\"{x:1452,y:927,t:1527876876188};\\\", \\\"{x:1451,y:924,t:1527876876205};\\\", \\\"{x:1447,y:919,t:1527876876221};\\\", \\\"{x:1446,y:914,t:1527876876238};\\\", \\\"{x:1445,y:911,t:1527876876255};\\\", \\\"{x:1442,y:905,t:1527876876271};\\\", \\\"{x:1432,y:888,t:1527876876287};\\\", \\\"{x:1424,y:875,t:1527876876305};\\\", \\\"{x:1417,y:864,t:1527876876322};\\\", \\\"{x:1412,y:857,t:1527876876338};\\\", \\\"{x:1408,y:850,t:1527876876355};\\\", \\\"{x:1405,y:842,t:1527876876372};\\\", \\\"{x:1401,y:837,t:1527876876388};\\\", \\\"{x:1394,y:824,t:1527876876404};\\\", \\\"{x:1389,y:812,t:1527876876421};\\\", \\\"{x:1384,y:800,t:1527876876438};\\\", \\\"{x:1384,y:794,t:1527876876455};\\\", \\\"{x:1382,y:787,t:1527876876471};\\\", \\\"{x:1380,y:780,t:1527876876488};\\\", \\\"{x:1378,y:774,t:1527876876504};\\\", \\\"{x:1377,y:768,t:1527876876522};\\\", \\\"{x:1376,y:765,t:1527876876537};\\\", \\\"{x:1374,y:762,t:1527876876555};\\\", \\\"{x:1374,y:760,t:1527876876572};\\\", \\\"{x:1373,y:757,t:1527876876588};\\\", \\\"{x:1371,y:753,t:1527876876605};\\\", \\\"{x:1369,y:749,t:1527876876622};\\\", \\\"{x:1365,y:741,t:1527876876638};\\\", \\\"{x:1360,y:736,t:1527876876655};\\\", \\\"{x:1353,y:727,t:1527876876672};\\\", \\\"{x:1352,y:725,t:1527876876687};\\\", \\\"{x:1349,y:722,t:1527876876704};\\\", \\\"{x:1345,y:718,t:1527876876722};\\\", \\\"{x:1339,y:714,t:1527876876737};\\\", \\\"{x:1334,y:711,t:1527876876754};\\\", \\\"{x:1333,y:709,t:1527876876771};\\\", \\\"{x:1333,y:708,t:1527876876798};\\\", \\\"{x:1332,y:708,t:1527876876814};\\\", \\\"{x:1331,y:704,t:1527876877016};\\\", \\\"{x:1331,y:702,t:1527876877024};\\\", \\\"{x:1331,y:699,t:1527876877038};\\\", \\\"{x:1331,y:694,t:1527876877055};\\\", \\\"{x:1323,y:678,t:1527876877072};\\\", \\\"{x:1320,y:672,t:1527876877088};\\\", \\\"{x:1318,y:666,t:1527876877104};\\\", \\\"{x:1316,y:659,t:1527876877122};\\\", \\\"{x:1309,y:646,t:1527876877138};\\\", \\\"{x:1304,y:635,t:1527876877155};\\\", \\\"{x:1300,y:626,t:1527876877172};\\\", \\\"{x:1296,y:620,t:1527876877189};\\\", \\\"{x:1293,y:615,t:1527876877204};\\\", \\\"{x:1289,y:610,t:1527876877221};\\\", \\\"{x:1286,y:606,t:1527876877238};\\\", \\\"{x:1285,y:604,t:1527876877254};\\\", \\\"{x:1283,y:602,t:1527876877272};\\\", \\\"{x:1283,y:601,t:1527876877288};\\\", \\\"{x:1282,y:599,t:1527876877305};\\\", \\\"{x:1281,y:597,t:1527876877321};\\\", \\\"{x:1279,y:595,t:1527876877339};\\\", \\\"{x:1277,y:593,t:1527876877355};\\\", \\\"{x:1271,y:590,t:1527876877372};\\\", \\\"{x:1265,y:589,t:1527876877389};\\\", \\\"{x:1243,y:585,t:1527876877404};\\\", \\\"{x:1203,y:579,t:1527876877422};\\\", \\\"{x:1145,y:570,t:1527876877439};\\\", \\\"{x:1061,y:568,t:1527876877455};\\\", \\\"{x:911,y:567,t:1527876877472};\\\", \\\"{x:778,y:567,t:1527876877488};\\\", \\\"{x:640,y:583,t:1527876877505};\\\", \\\"{x:509,y:602,t:1527876877524};\\\", \\\"{x:410,y:611,t:1527876877540};\\\", \\\"{x:363,y:611,t:1527876877556};\\\", \\\"{x:346,y:611,t:1527876877573};\\\", \\\"{x:343,y:611,t:1527876877591};\\\", \\\"{x:343,y:609,t:1527876877727};\\\", \\\"{x:345,y:604,t:1527876877740};\\\", \\\"{x:351,y:599,t:1527876877758};\\\", \\\"{x:365,y:589,t:1527876877773};\\\", \\\"{x:383,y:572,t:1527876877791};\\\", \\\"{x:393,y:562,t:1527876877807};\\\", \\\"{x:397,y:555,t:1527876877823};\\\", \\\"{x:398,y:554,t:1527876877840};\\\", \\\"{x:398,y:551,t:1527876877856};\\\", \\\"{x:398,y:549,t:1527876877874};\\\", \\\"{x:398,y:545,t:1527876877890};\\\", \\\"{x:390,y:543,t:1527876877906};\\\", \\\"{x:375,y:540,t:1527876877923};\\\", \\\"{x:359,y:540,t:1527876877940};\\\", \\\"{x:345,y:540,t:1527876877956};\\\", \\\"{x:327,y:540,t:1527876877973};\\\", \\\"{x:304,y:539,t:1527876877991};\\\", \\\"{x:296,y:539,t:1527876878007};\\\", \\\"{x:283,y:539,t:1527876878023};\\\", \\\"{x:264,y:539,t:1527876878042};\\\", \\\"{x:247,y:539,t:1527876878057};\\\", \\\"{x:234,y:540,t:1527876878073};\\\", \\\"{x:228,y:541,t:1527876878090};\\\", \\\"{x:223,y:541,t:1527876878107};\\\", \\\"{x:222,y:541,t:1527876878124};\\\", \\\"{x:221,y:541,t:1527876878140};\\\", \\\"{x:224,y:541,t:1527876878199};\\\", \\\"{x:235,y:541,t:1527876878207};\\\", \\\"{x:261,y:538,t:1527876878224};\\\", \\\"{x:297,y:532,t:1527876878241};\\\", \\\"{x:358,y:532,t:1527876878257};\\\", \\\"{x:431,y:532,t:1527876878273};\\\", \\\"{x:495,y:532,t:1527876878290};\\\", \\\"{x:525,y:530,t:1527876878308};\\\", \\\"{x:541,y:530,t:1527876878324};\\\", \\\"{x:546,y:530,t:1527876878340};\\\", \\\"{x:549,y:530,t:1527876878357};\\\", \\\"{x:551,y:530,t:1527876878374};\\\", \\\"{x:552,y:529,t:1527876878390};\\\", \\\"{x:554,y:528,t:1527876878407};\\\", \\\"{x:557,y:526,t:1527876878424};\\\", \\\"{x:562,y:524,t:1527876878440};\\\", \\\"{x:566,y:521,t:1527876878457};\\\", \\\"{x:567,y:521,t:1527876878474};\\\", \\\"{x:569,y:519,t:1527876878491};\\\", \\\"{x:570,y:517,t:1527876878507};\\\", \\\"{x:573,y:517,t:1527876878524};\\\", \\\"{x:581,y:513,t:1527876878540};\\\", \\\"{x:592,y:508,t:1527876878558};\\\", \\\"{x:597,y:505,t:1527876878575};\\\", \\\"{x:600,y:504,t:1527876878592};\\\", \\\"{x:601,y:503,t:1527876878607};\\\", \\\"{x:601,y:502,t:1527876878623};\\\", \\\"{x:603,y:501,t:1527876878640};\\\", \\\"{x:604,y:500,t:1527876878657};\\\", \\\"{x:610,y:499,t:1527876878903};\\\", \\\"{x:619,y:499,t:1527876878911};\\\", \\\"{x:630,y:499,t:1527876878925};\\\", \\\"{x:664,y:499,t:1527876878941};\\\", \\\"{x:700,y:499,t:1527876878957};\\\", \\\"{x:723,y:499,t:1527876878974};\\\", \\\"{x:745,y:499,t:1527876878991};\\\", \\\"{x:747,y:499,t:1527876879009};\\\", \\\"{x:750,y:499,t:1527876879031};\\\", \\\"{x:753,y:499,t:1527876879041};\\\", \\\"{x:764,y:499,t:1527876879057};\\\", \\\"{x:779,y:499,t:1527876879074};\\\", \\\"{x:793,y:499,t:1527876879092};\\\", \\\"{x:795,y:499,t:1527876879108};\\\", \\\"{x:797,y:499,t:1527876879143};\\\", \\\"{x:804,y:499,t:1527876879158};\\\", \\\"{x:819,y:499,t:1527876879175};\\\", \\\"{x:835,y:499,t:1527876879193};\\\", \\\"{x:841,y:499,t:1527876879208};\\\", \\\"{x:842,y:499,t:1527876879295};\\\", \\\"{x:842,y:500,t:1527876879494};\\\", \\\"{x:835,y:511,t:1527876879508};\\\", \\\"{x:802,y:538,t:1527876879525};\\\", \\\"{x:766,y:567,t:1527876879541};\\\", \\\"{x:731,y:597,t:1527876879559};\\\", \\\"{x:698,y:619,t:1527876879574};\\\", \\\"{x:682,y:631,t:1527876879591};\\\", \\\"{x:667,y:645,t:1527876879609};\\\", \\\"{x:650,y:659,t:1527876879624};\\\", \\\"{x:639,y:669,t:1527876879641};\\\", \\\"{x:629,y:676,t:1527876879658};\\\", \\\"{x:618,y:683,t:1527876879675};\\\", \\\"{x:612,y:687,t:1527876879691};\\\", \\\"{x:605,y:691,t:1527876879709};\\\", \\\"{x:599,y:695,t:1527876879726};\\\", \\\"{x:593,y:698,t:1527876879743};\\\", \\\"{x:590,y:700,t:1527876879759};\\\", \\\"{x:583,y:703,t:1527876879775};\\\", \\\"{x:577,y:707,t:1527876879792};\\\", \\\"{x:570,y:713,t:1527876879808};\\\", \\\"{x:559,y:720,t:1527876879827};\\\", \\\"{x:547,y:725,t:1527876879842};\\\", \\\"{x:540,y:727,t:1527876879858};\\\", \\\"{x:531,y:732,t:1527876879875};\\\", \\\"{x:524,y:735,t:1527876879891};\\\", \\\"{x:519,y:736,t:1527876879908};\\\", \\\"{x:516,y:736,t:1527876879925};\\\", \\\"{x:515,y:737,t:1527876879951};\\\", \\\"{x:514,y:739,t:1527876880520};\\\", \\\"{x:512,y:741,t:1527876880527};\\\", \\\"{x:512,y:743,t:1527876880543};\\\", \\\"{x:509,y:748,t:1527876880559};\\\", \\\"{x:509,y:750,t:1527876880575};\\\", \\\"{x:507,y:753,t:1527876880592};\\\", \\\"{x:507,y:755,t:1527876880609};\\\", \\\"{x:507,y:758,t:1527876880626};\\\", \\\"{x:507,y:759,t:1527876880642};\\\", \\\"{x:507,y:761,t:1527876880660};\\\", \\\"{x:507,y:763,t:1527876880675};\\\", \\\"{x:507,y:765,t:1527876880692};\\\", \\\"{x:507,y:768,t:1527876880709};\\\", \\\"{x:506,y:773,t:1527876880725};\\\", \\\"{x:506,y:776,t:1527876880742};\\\", \\\"{x:505,y:780,t:1527876880760};\\\", \\\"{x:505,y:782,t:1527876880775};\\\", \\\"{x:505,y:783,t:1527876880792};\\\", \\\"{x:505,y:785,t:1527876880815};\\\", \\\"{x:505,y:786,t:1527876880825};\\\", \\\"{x:505,y:788,t:1527876880843};\\\", \\\"{x:505,y:789,t:1527876880859};\\\", \\\"{x:505,y:791,t:1527876880875};\\\", \\\"{x:505,y:792,t:1527876880896};\\\", \\\"{x:505,y:793,t:1527876880909};\\\", \\\"{x:505,y:796,t:1527876880926};\\\", \\\"{x:505,y:800,t:1527876880942};\\\", \\\"{x:505,y:803,t:1527876880959};\\\", \\\"{x:505,y:806,t:1527876880976};\\\", \\\"{x:505,y:808,t:1527876880992};\\\", \\\"{x:505,y:812,t:1527876881009};\\\", \\\"{x:505,y:815,t:1527876881027};\\\", \\\"{x:505,y:820,t:1527876881043};\\\", \\\"{x:505,y:822,t:1527876881060};\\\", \\\"{x:505,y:825,t:1527876881076};\\\", \\\"{x:504,y:826,t:1527876881109};\\\", \\\"{x:504,y:827,t:1527876881175};\\\" ] }, { \\\"rt\\\": 6929, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 500649, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:834,t:1527876881318};\\\", \\\"{x:505,y:836,t:1527876881768};\\\", \\\"{x:505,y:837,t:1527876881777};\\\", \\\"{x:506,y:838,t:1527876881799};\\\", \\\"{x:507,y:838,t:1527876881918};\\\", \\\"{x:508,y:838,t:1527876881990};\\\", \\\"{x:510,y:837,t:1527876881999};\\\", \\\"{x:511,y:836,t:1527876882010};\\\", \\\"{x:514,y:829,t:1527876882026};\\\", \\\"{x:518,y:823,t:1527876882043};\\\", \\\"{x:526,y:812,t:1527876882060};\\\", \\\"{x:532,y:800,t:1527876882076};\\\", \\\"{x:536,y:782,t:1527876882094};\\\", \\\"{x:542,y:761,t:1527876882110};\\\", \\\"{x:543,y:745,t:1527876882127};\\\", \\\"{x:544,y:725,t:1527876882143};\\\", \\\"{x:544,y:706,t:1527876882160};\\\", \\\"{x:545,y:700,t:1527876882177};\\\", \\\"{x:546,y:700,t:1527876882671};\\\", \\\"{x:546,y:699,t:1527876882679};\\\", \\\"{x:547,y:699,t:1527876882694};\\\", \\\"{x:549,y:696,t:1527876882711};\\\", \\\"{x:550,y:684,t:1527876882728};\\\", \\\"{x:548,y:672,t:1527876882744};\\\", \\\"{x:546,y:663,t:1527876882761};\\\", \\\"{x:543,y:659,t:1527876882778};\\\", \\\"{x:542,y:656,t:1527876882795};\\\", \\\"{x:540,y:652,t:1527876882811};\\\", \\\"{x:539,y:649,t:1527876882827};\\\", \\\"{x:537,y:642,t:1527876882844};\\\", \\\"{x:534,y:637,t:1527876882861};\\\", \\\"{x:530,y:626,t:1527876882878};\\\", \\\"{x:523,y:612,t:1527876882895};\\\", \\\"{x:514,y:598,t:1527876882911};\\\", \\\"{x:511,y:592,t:1527876882928};\\\", \\\"{x:510,y:588,t:1527876882944};\\\", \\\"{x:509,y:584,t:1527876882960};\\\", \\\"{x:508,y:579,t:1527876882977};\\\", \\\"{x:507,y:573,t:1527876882994};\\\", \\\"{x:507,y:569,t:1527876883010};\\\", \\\"{x:507,y:567,t:1527876883027};\\\", \\\"{x:507,y:565,t:1527876883044};\\\", \\\"{x:507,y:562,t:1527876883061};\\\", \\\"{x:512,y:556,t:1527876883078};\\\", \\\"{x:520,y:553,t:1527876883095};\\\", \\\"{x:533,y:546,t:1527876883111};\\\", \\\"{x:537,y:543,t:1527876883127};\\\", \\\"{x:541,y:543,t:1527876883151};\\\", \\\"{x:547,y:543,t:1527876883167};\\\", \\\"{x:549,y:543,t:1527876883178};\\\", \\\"{x:551,y:543,t:1527876883195};\\\", \\\"{x:556,y:543,t:1527876883639};\\\", \\\"{x:559,y:543,t:1527876883647};\\\", \\\"{x:565,y:544,t:1527876883661};\\\", \\\"{x:586,y:546,t:1527876883679};\\\", \\\"{x:614,y:548,t:1527876883695};\\\", \\\"{x:660,y:555,t:1527876883712};\\\", \\\"{x:686,y:558,t:1527876883729};\\\", \\\"{x:715,y:562,t:1527876883744};\\\", \\\"{x:752,y:567,t:1527876883762};\\\", \\\"{x:781,y:570,t:1527876883778};\\\", \\\"{x:804,y:573,t:1527876883795};\\\", \\\"{x:824,y:577,t:1527876883812};\\\", \\\"{x:843,y:578,t:1527876883828};\\\", \\\"{x:865,y:583,t:1527876883845};\\\", \\\"{x:907,y:590,t:1527876883862};\\\", \\\"{x:958,y:599,t:1527876883879};\\\", \\\"{x:1056,y:618,t:1527876883895};\\\", \\\"{x:1123,y:629,t:1527876883911};\\\", \\\"{x:1176,y:637,t:1527876883928};\\\", \\\"{x:1224,y:644,t:1527876883945};\\\", \\\"{x:1266,y:651,t:1527876883962};\\\", \\\"{x:1292,y:657,t:1527876883979};\\\", \\\"{x:1299,y:660,t:1527876883996};\\\", \\\"{x:1300,y:663,t:1527876884013};\\\", \\\"{x:1302,y:670,t:1527876884029};\\\", \\\"{x:1302,y:685,t:1527876884046};\\\", \\\"{x:1302,y:697,t:1527876884062};\\\", \\\"{x:1300,y:709,t:1527876884079};\\\", \\\"{x:1290,y:733,t:1527876884095};\\\", \\\"{x:1284,y:751,t:1527876884112};\\\", \\\"{x:1280,y:769,t:1527876884129};\\\", \\\"{x:1275,y:790,t:1527876884146};\\\", \\\"{x:1274,y:808,t:1527876884161};\\\", \\\"{x:1274,y:823,t:1527876884179};\\\", \\\"{x:1274,y:837,t:1527876884196};\\\", \\\"{x:1281,y:846,t:1527876884213};\\\", \\\"{x:1291,y:855,t:1527876884229};\\\", \\\"{x:1307,y:865,t:1527876884246};\\\", \\\"{x:1323,y:874,t:1527876884262};\\\", \\\"{x:1339,y:882,t:1527876884279};\\\", \\\"{x:1361,y:899,t:1527876884295};\\\", \\\"{x:1378,y:912,t:1527876884312};\\\", \\\"{x:1393,y:922,t:1527876884329};\\\", \\\"{x:1403,y:929,t:1527876884347};\\\", \\\"{x:1413,y:935,t:1527876884362};\\\", \\\"{x:1422,y:941,t:1527876884379};\\\", \\\"{x:1433,y:946,t:1527876884395};\\\", \\\"{x:1445,y:955,t:1527876884412};\\\", \\\"{x:1452,y:961,t:1527876884429};\\\", \\\"{x:1455,y:965,t:1527876884446};\\\", \\\"{x:1457,y:966,t:1527876884463};\\\", \\\"{x:1459,y:968,t:1527876884479};\\\", \\\"{x:1465,y:971,t:1527876884495};\\\", \\\"{x:1469,y:972,t:1527876884513};\\\", \\\"{x:1470,y:972,t:1527876884528};\\\", \\\"{x:1473,y:972,t:1527876884545};\\\", \\\"{x:1478,y:972,t:1527876884562};\\\", \\\"{x:1489,y:972,t:1527876884579};\\\", \\\"{x:1503,y:972,t:1527876884596};\\\", \\\"{x:1520,y:972,t:1527876884612};\\\", \\\"{x:1535,y:972,t:1527876884629};\\\", \\\"{x:1546,y:971,t:1527876884645};\\\", \\\"{x:1551,y:970,t:1527876884662};\\\", \\\"{x:1555,y:967,t:1527876884680};\\\", \\\"{x:1556,y:967,t:1527876884727};\\\", \\\"{x:1556,y:966,t:1527876884735};\\\", \\\"{x:1556,y:965,t:1527876884745};\\\", \\\"{x:1556,y:964,t:1527876884762};\\\", \\\"{x:1556,y:962,t:1527876884783};\\\", \\\"{x:1556,y:961,t:1527876884839};\\\", \\\"{x:1556,y:960,t:1527876884846};\\\", \\\"{x:1555,y:959,t:1527876884862};\\\", \\\"{x:1550,y:954,t:1527876884878};\\\", \\\"{x:1546,y:951,t:1527876884895};\\\", \\\"{x:1541,y:948,t:1527876884912};\\\", \\\"{x:1534,y:943,t:1527876884929};\\\", \\\"{x:1525,y:937,t:1527876884945};\\\", \\\"{x:1516,y:932,t:1527876884962};\\\", \\\"{x:1513,y:930,t:1527876884980};\\\", \\\"{x:1512,y:928,t:1527876884996};\\\", \\\"{x:1508,y:919,t:1527876885012};\\\", \\\"{x:1503,y:907,t:1527876885030};\\\", \\\"{x:1499,y:894,t:1527876885046};\\\", \\\"{x:1496,y:885,t:1527876885063};\\\", \\\"{x:1496,y:881,t:1527876885079};\\\", \\\"{x:1496,y:878,t:1527876885096};\\\", \\\"{x:1496,y:871,t:1527876885113};\\\", \\\"{x:1496,y:858,t:1527876885129};\\\", \\\"{x:1496,y:852,t:1527876885146};\\\", \\\"{x:1495,y:848,t:1527876885163};\\\", \\\"{x:1495,y:847,t:1527876885179};\\\", \\\"{x:1495,y:846,t:1527876885196};\\\", \\\"{x:1495,y:845,t:1527876885212};\\\", \\\"{x:1494,y:845,t:1527876885229};\\\", \\\"{x:1494,y:844,t:1527876885247};\\\", \\\"{x:1493,y:843,t:1527876885263};\\\", \\\"{x:1492,y:840,t:1527876885279};\\\", \\\"{x:1489,y:838,t:1527876885298};\\\", \\\"{x:1488,y:836,t:1527876885313};\\\", \\\"{x:1486,y:833,t:1527876885329};\\\", \\\"{x:1485,y:832,t:1527876885349};\\\", \\\"{x:1484,y:830,t:1527876885362};\\\", \\\"{x:1483,y:829,t:1527876885391};\\\", \\\"{x:1482,y:829,t:1527876885399};\\\", \\\"{x:1480,y:829,t:1527876885936};\\\", \\\"{x:1476,y:829,t:1527876885947};\\\", \\\"{x:1461,y:825,t:1527876885965};\\\", \\\"{x:1442,y:819,t:1527876885981};\\\", \\\"{x:1417,y:815,t:1527876885997};\\\", \\\"{x:1387,y:812,t:1527876886014};\\\", \\\"{x:1359,y:803,t:1527876886031};\\\", \\\"{x:1325,y:796,t:1527876886047};\\\", \\\"{x:1304,y:789,t:1527876886063};\\\", \\\"{x:1283,y:784,t:1527876886081};\\\", \\\"{x:1267,y:782,t:1527876886098};\\\", \\\"{x:1260,y:782,t:1527876886114};\\\", \\\"{x:1259,y:782,t:1527876886131};\\\", \\\"{x:1259,y:781,t:1527876886159};\\\", \\\"{x:1257,y:781,t:1527876886216};\\\", \\\"{x:1256,y:781,t:1527876886232};\\\", \\\"{x:1253,y:781,t:1527876886247};\\\", \\\"{x:1248,y:778,t:1527876886264};\\\", \\\"{x:1233,y:774,t:1527876886281};\\\", \\\"{x:1217,y:766,t:1527876886298};\\\", \\\"{x:1195,y:756,t:1527876886314};\\\", \\\"{x:1171,y:749,t:1527876886331};\\\", \\\"{x:1155,y:744,t:1527876886348};\\\", \\\"{x:1135,y:739,t:1527876886364};\\\", \\\"{x:1118,y:734,t:1527876886381};\\\", \\\"{x:1103,y:731,t:1527876886398};\\\", \\\"{x:1082,y:727,t:1527876886414};\\\", \\\"{x:1048,y:716,t:1527876886431};\\\", \\\"{x:1005,y:704,t:1527876886448};\\\", \\\"{x:993,y:697,t:1527876886464};\\\", \\\"{x:985,y:695,t:1527876886481};\\\", \\\"{x:971,y:690,t:1527876886498};\\\", \\\"{x:962,y:687,t:1527876886515};\\\", \\\"{x:955,y:683,t:1527876886530};\\\", \\\"{x:946,y:680,t:1527876886548};\\\", \\\"{x:931,y:675,t:1527876886565};\\\", \\\"{x:913,y:668,t:1527876886581};\\\", \\\"{x:895,y:661,t:1527876886598};\\\", \\\"{x:866,y:653,t:1527876886615};\\\", \\\"{x:822,y:645,t:1527876886632};\\\", \\\"{x:787,y:641,t:1527876886648};\\\", \\\"{x:763,y:635,t:1527876886664};\\\", \\\"{x:749,y:631,t:1527876886682};\\\", \\\"{x:744,y:630,t:1527876886697};\\\", \\\"{x:742,y:630,t:1527876886707};\\\", \\\"{x:737,y:630,t:1527876886723};\\\", \\\"{x:729,y:630,t:1527876886741};\\\", \\\"{x:723,y:630,t:1527876886758};\\\", \\\"{x:719,y:630,t:1527876886773};\\\", \\\"{x:704,y:636,t:1527876886790};\\\", \\\"{x:693,y:641,t:1527876886813};\\\", \\\"{x:671,y:655,t:1527876886830};\\\", \\\"{x:653,y:663,t:1527876886847};\\\", \\\"{x:637,y:673,t:1527876886863};\\\", \\\"{x:626,y:679,t:1527876886880};\\\", \\\"{x:620,y:683,t:1527876886897};\\\", \\\"{x:614,y:686,t:1527876886913};\\\", \\\"{x:608,y:688,t:1527876886930};\\\", \\\"{x:602,y:689,t:1527876886948};\\\", \\\"{x:600,y:689,t:1527876886963};\\\", \\\"{x:593,y:689,t:1527876886981};\\\", \\\"{x:584,y:688,t:1527876886997};\\\", \\\"{x:571,y:683,t:1527876887014};\\\", \\\"{x:553,y:673,t:1527876887030};\\\", \\\"{x:546,y:669,t:1527876887047};\\\", \\\"{x:542,y:662,t:1527876887064};\\\", \\\"{x:542,y:654,t:1527876887081};\\\", \\\"{x:543,y:642,t:1527876887098};\\\", \\\"{x:547,y:633,t:1527876887114};\\\", \\\"{x:556,y:618,t:1527876887131};\\\", \\\"{x:562,y:607,t:1527876887148};\\\", \\\"{x:566,y:601,t:1527876887164};\\\", \\\"{x:577,y:587,t:1527876887181};\\\", \\\"{x:583,y:578,t:1527876887197};\\\", \\\"{x:591,y:569,t:1527876887214};\\\", \\\"{x:594,y:565,t:1527876887230};\\\", \\\"{x:598,y:559,t:1527876887248};\\\", \\\"{x:598,y:558,t:1527876887264};\\\", \\\"{x:599,y:557,t:1527876887280};\\\", \\\"{x:600,y:556,t:1527876887303};\\\", \\\"{x:601,y:554,t:1527876887320};\\\", \\\"{x:601,y:553,t:1527876887334};\\\", \\\"{x:602,y:552,t:1527876887351};\\\", \\\"{x:602,y:554,t:1527876887446};\\\", \\\"{x:604,y:558,t:1527876887455};\\\", \\\"{x:604,y:560,t:1527876887465};\\\", \\\"{x:604,y:567,t:1527876887482};\\\", \\\"{x:605,y:576,t:1527876887497};\\\", \\\"{x:606,y:580,t:1527876887515};\\\", \\\"{x:608,y:582,t:1527876887531};\\\", \\\"{x:608,y:583,t:1527876887547};\\\", \\\"{x:609,y:583,t:1527876887564};\\\", \\\"{x:611,y:583,t:1527876887647};\\\", \\\"{x:611,y:589,t:1527876887814};\\\", \\\"{x:601,y:605,t:1527876887832};\\\", \\\"{x:588,y:627,t:1527876887848};\\\", \\\"{x:579,y:647,t:1527876887865};\\\", \\\"{x:576,y:660,t:1527876887881};\\\", \\\"{x:575,y:669,t:1527876887897};\\\", \\\"{x:572,y:680,t:1527876887914};\\\", \\\"{x:568,y:692,t:1527876887931};\\\", \\\"{x:565,y:699,t:1527876887948};\\\", \\\"{x:563,y:705,t:1527876887964};\\\", \\\"{x:560,y:710,t:1527876887982};\\\", \\\"{x:556,y:720,t:1527876887999};\\\", \\\"{x:554,y:722,t:1527876888014};\\\", \\\"{x:552,y:725,t:1527876888031};\\\", \\\"{x:551,y:727,t:1527876888048};\\\", \\\"{x:549,y:730,t:1527876888065};\\\", \\\"{x:548,y:732,t:1527876888081};\\\", \\\"{x:545,y:735,t:1527876888098};\\\", \\\"{x:554,y:735,t:1527876888415};\\\", \\\"{x:574,y:735,t:1527876888432};\\\", \\\"{x:597,y:735,t:1527876888449};\\\", \\\"{x:626,y:735,t:1527876888465};\\\", \\\"{x:664,y:735,t:1527876888481};\\\", \\\"{x:686,y:735,t:1527876888499};\\\", \\\"{x:706,y:735,t:1527876888516};\\\", \\\"{x:724,y:735,t:1527876888532};\\\", \\\"{x:731,y:735,t:1527876888549};\\\", \\\"{x:739,y:733,t:1527876888566};\\\", \\\"{x:743,y:731,t:1527876888582};\\\", \\\"{x:751,y:726,t:1527876888599};\\\", \\\"{x:758,y:724,t:1527876888615};\\\", \\\"{x:769,y:720,t:1527876888633};\\\", \\\"{x:787,y:712,t:1527876888648};\\\", \\\"{x:803,y:709,t:1527876888666};\\\", \\\"{x:816,y:705,t:1527876888683};\\\", \\\"{x:828,y:701,t:1527876888699};\\\", \\\"{x:837,y:699,t:1527876888716};\\\", \\\"{x:847,y:695,t:1527876888733};\\\", \\\"{x:854,y:692,t:1527876888748};\\\", \\\"{x:859,y:690,t:1527876888766};\\\", \\\"{x:863,y:688,t:1527876888783};\\\", \\\"{x:864,y:688,t:1527876888799};\\\", \\\"{x:865,y:688,t:1527876888904};\\\" ] }, { \\\"rt\\\": 21166, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 523033, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:859,y:690,t:1527876889983};\\\", \\\"{x:843,y:690,t:1527876889999};\\\", \\\"{x:832,y:690,t:1527876890016};\\\", \\\"{x:828,y:690,t:1527876890033};\\\", \\\"{x:824,y:688,t:1527876890049};\\\", \\\"{x:820,y:684,t:1527876890067};\\\", \\\"{x:815,y:680,t:1527876890082};\\\", \\\"{x:806,y:672,t:1527876890100};\\\", \\\"{x:791,y:660,t:1527876890116};\\\", \\\"{x:776,y:648,t:1527876890134};\\\", \\\"{x:761,y:634,t:1527876890150};\\\", \\\"{x:735,y:613,t:1527876890167};\\\", \\\"{x:720,y:598,t:1527876890184};\\\", \\\"{x:707,y:585,t:1527876890199};\\\", \\\"{x:693,y:572,t:1527876890217};\\\", \\\"{x:676,y:557,t:1527876890234};\\\", \\\"{x:656,y:541,t:1527876890249};\\\", \\\"{x:637,y:527,t:1527876890268};\\\", \\\"{x:615,y:512,t:1527876890284};\\\", \\\"{x:589,y:499,t:1527876890300};\\\", \\\"{x:563,y:486,t:1527876890316};\\\", \\\"{x:538,y:473,t:1527876890334};\\\", \\\"{x:524,y:466,t:1527876890349};\\\", \\\"{x:512,y:460,t:1527876890367};\\\", \\\"{x:502,y:455,t:1527876890383};\\\", \\\"{x:491,y:450,t:1527876890400};\\\", \\\"{x:480,y:447,t:1527876890417};\\\", \\\"{x:469,y:444,t:1527876890434};\\\", \\\"{x:458,y:441,t:1527876890450};\\\", \\\"{x:453,y:439,t:1527876890467};\\\", \\\"{x:446,y:436,t:1527876890484};\\\", \\\"{x:440,y:435,t:1527876890500};\\\", \\\"{x:436,y:433,t:1527876890517};\\\", \\\"{x:428,y:432,t:1527876890534};\\\", \\\"{x:421,y:431,t:1527876890550};\\\", \\\"{x:411,y:431,t:1527876890567};\\\", \\\"{x:403,y:431,t:1527876890583};\\\", \\\"{x:395,y:431,t:1527876890601};\\\", \\\"{x:391,y:431,t:1527876890617};\\\", \\\"{x:389,y:431,t:1527876890634};\\\", \\\"{x:388,y:431,t:1527876890655};\\\", \\\"{x:387,y:431,t:1527876890673};\\\", \\\"{x:386,y:431,t:1527876890683};\\\", \\\"{x:384,y:431,t:1527876890700};\\\", \\\"{x:381,y:432,t:1527876890717};\\\", \\\"{x:379,y:433,t:1527876890734};\\\", \\\"{x:374,y:436,t:1527876890751};\\\", \\\"{x:373,y:437,t:1527876890767};\\\", \\\"{x:373,y:438,t:1527876890784};\\\", \\\"{x:372,y:438,t:1527876890801};\\\", \\\"{x:371,y:439,t:1527876890824};\\\", \\\"{x:371,y:440,t:1527876890872};\\\", \\\"{x:371,y:442,t:1527876890934};\\\", \\\"{x:371,y:444,t:1527876890950};\\\", \\\"{x:371,y:446,t:1527876890966};\\\", \\\"{x:371,y:448,t:1527876890983};\\\", \\\"{x:371,y:449,t:1527876891001};\\\", \\\"{x:371,y:452,t:1527876891017};\\\", \\\"{x:372,y:453,t:1527876891038};\\\", \\\"{x:372,y:454,t:1527876891051};\\\", \\\"{x:372,y:455,t:1527876891066};\\\", \\\"{x:374,y:455,t:1527876891084};\\\", \\\"{x:375,y:456,t:1527876891100};\\\", \\\"{x:376,y:456,t:1527876891117};\\\", \\\"{x:377,y:457,t:1527876891134};\\\", \\\"{x:380,y:459,t:1527876891151};\\\", \\\"{x:382,y:460,t:1527876891175};\\\", \\\"{x:383,y:460,t:1527876891191};\\\", \\\"{x:384,y:460,t:1527876891207};\\\", \\\"{x:386,y:461,t:1527876891218};\\\", \\\"{x:389,y:461,t:1527876891234};\\\", \\\"{x:395,y:461,t:1527876891251};\\\", \\\"{x:411,y:461,t:1527876891267};\\\", \\\"{x:425,y:462,t:1527876891284};\\\", \\\"{x:438,y:462,t:1527876891301};\\\", \\\"{x:447,y:462,t:1527876891317};\\\", \\\"{x:455,y:463,t:1527876891334};\\\", \\\"{x:457,y:463,t:1527876891351};\\\", \\\"{x:458,y:463,t:1527876891367};\\\", \\\"{x:459,y:463,t:1527876891384};\\\", \\\"{x:463,y:464,t:1527876891401};\\\", \\\"{x:465,y:465,t:1527876891418};\\\", \\\"{x:466,y:466,t:1527876891434};\\\", \\\"{x:469,y:467,t:1527876891451};\\\", \\\"{x:472,y:468,t:1527876891468};\\\", \\\"{x:473,y:468,t:1527876891484};\\\", \\\"{x:474,y:469,t:1527876891501};\\\", \\\"{x:475,y:469,t:1527876891518};\\\", \\\"{x:476,y:469,t:1527876891543};\\\", \\\"{x:478,y:470,t:1527876891551};\\\", \\\"{x:483,y:471,t:1527876891567};\\\", \\\"{x:491,y:472,t:1527876891584};\\\", \\\"{x:495,y:473,t:1527876891601};\\\", \\\"{x:499,y:474,t:1527876891618};\\\", \\\"{x:502,y:474,t:1527876891634};\\\", \\\"{x:514,y:474,t:1527876891651};\\\", \\\"{x:524,y:474,t:1527876891668};\\\", \\\"{x:530,y:475,t:1527876891684};\\\", \\\"{x:548,y:477,t:1527876891701};\\\", \\\"{x:572,y:483,t:1527876891717};\\\", \\\"{x:606,y:493,t:1527876891735};\\\", \\\"{x:627,y:499,t:1527876891750};\\\", \\\"{x:652,y:503,t:1527876891768};\\\", \\\"{x:675,y:510,t:1527876891784};\\\", \\\"{x:701,y:517,t:1527876891801};\\\", \\\"{x:738,y:529,t:1527876891818};\\\", \\\"{x:804,y:545,t:1527876891835};\\\", \\\"{x:868,y:562,t:1527876891852};\\\", \\\"{x:937,y:582,t:1527876891867};\\\", \\\"{x:1012,y:602,t:1527876891885};\\\", \\\"{x:1068,y:620,t:1527876891901};\\\", \\\"{x:1117,y:637,t:1527876891917};\\\", \\\"{x:1206,y:664,t:1527876891934};\\\", \\\"{x:1244,y:678,t:1527876891952};\\\", \\\"{x:1270,y:686,t:1527876891967};\\\", \\\"{x:1290,y:692,t:1527876891984};\\\", \\\"{x:1301,y:697,t:1527876892002};\\\", \\\"{x:1307,y:700,t:1527876892018};\\\", \\\"{x:1309,y:702,t:1527876892035};\\\", \\\"{x:1312,y:704,t:1527876892052};\\\", \\\"{x:1316,y:708,t:1527876892068};\\\", \\\"{x:1326,y:716,t:1527876892084};\\\", \\\"{x:1338,y:727,t:1527876892102};\\\", \\\"{x:1354,y:740,t:1527876892117};\\\", \\\"{x:1364,y:753,t:1527876892134};\\\", \\\"{x:1369,y:760,t:1527876892151};\\\", \\\"{x:1373,y:765,t:1527876892168};\\\", \\\"{x:1381,y:776,t:1527876892185};\\\", \\\"{x:1387,y:784,t:1527876892202};\\\", \\\"{x:1390,y:790,t:1527876892218};\\\", \\\"{x:1392,y:796,t:1527876892234};\\\", \\\"{x:1395,y:806,t:1527876892252};\\\", \\\"{x:1400,y:818,t:1527876892268};\\\", \\\"{x:1402,y:831,t:1527876892285};\\\", \\\"{x:1404,y:838,t:1527876892302};\\\", \\\"{x:1406,y:847,t:1527876892319};\\\", \\\"{x:1410,y:859,t:1527876892335};\\\", \\\"{x:1413,y:869,t:1527876892352};\\\", \\\"{x:1415,y:880,t:1527876892369};\\\", \\\"{x:1418,y:891,t:1527876892384};\\\", \\\"{x:1422,y:900,t:1527876892402};\\\", \\\"{x:1425,y:912,t:1527876892419};\\\", \\\"{x:1430,y:925,t:1527876892435};\\\", \\\"{x:1437,y:937,t:1527876892452};\\\", \\\"{x:1442,y:947,t:1527876892469};\\\", \\\"{x:1446,y:953,t:1527876892485};\\\", \\\"{x:1450,y:957,t:1527876892501};\\\", \\\"{x:1456,y:966,t:1527876892519};\\\", \\\"{x:1459,y:969,t:1527876892535};\\\", \\\"{x:1461,y:969,t:1527876892847};\\\", \\\"{x:1462,y:969,t:1527876892879};\\\", \\\"{x:1463,y:969,t:1527876892935};\\\", \\\"{x:1464,y:970,t:1527876892952};\\\", \\\"{x:1469,y:973,t:1527876892969};\\\", \\\"{x:1477,y:980,t:1527876892986};\\\", \\\"{x:1481,y:982,t:1527876893002};\\\", \\\"{x:1483,y:984,t:1527876893019};\\\", \\\"{x:1484,y:985,t:1527876893056};\\\", \\\"{x:1485,y:987,t:1527876893073};\\\", \\\"{x:1486,y:988,t:1527876893086};\\\", \\\"{x:1488,y:992,t:1527876893102};\\\", \\\"{x:1490,y:995,t:1527876893119};\\\", \\\"{x:1490,y:996,t:1527876893224};\\\", \\\"{x:1490,y:997,t:1527876893236};\\\", \\\"{x:1491,y:997,t:1527876893343};\\\", \\\"{x:1491,y:994,t:1527876893367};\\\", \\\"{x:1492,y:990,t:1527876893375};\\\", \\\"{x:1492,y:985,t:1527876893386};\\\", \\\"{x:1492,y:974,t:1527876893403};\\\", \\\"{x:1492,y:966,t:1527876893419};\\\", \\\"{x:1492,y:961,t:1527876893436};\\\", \\\"{x:1492,y:959,t:1527876893453};\\\", \\\"{x:1492,y:953,t:1527876893469};\\\", \\\"{x:1492,y:946,t:1527876893487};\\\", \\\"{x:1492,y:938,t:1527876893503};\\\", \\\"{x:1492,y:932,t:1527876893519};\\\", \\\"{x:1492,y:927,t:1527876893537};\\\", \\\"{x:1492,y:921,t:1527876893553};\\\", \\\"{x:1491,y:913,t:1527876893570};\\\", \\\"{x:1491,y:905,t:1527876893586};\\\", \\\"{x:1491,y:898,t:1527876893603};\\\", \\\"{x:1491,y:894,t:1527876893621};\\\", \\\"{x:1491,y:891,t:1527876893636};\\\", \\\"{x:1491,y:890,t:1527876893653};\\\", \\\"{x:1491,y:887,t:1527876893670};\\\", \\\"{x:1491,y:884,t:1527876893686};\\\", \\\"{x:1491,y:877,t:1527876893703};\\\", \\\"{x:1490,y:872,t:1527876893720};\\\", \\\"{x:1489,y:865,t:1527876893736};\\\", \\\"{x:1488,y:859,t:1527876893753};\\\", \\\"{x:1488,y:854,t:1527876893771};\\\", \\\"{x:1487,y:850,t:1527876893786};\\\", \\\"{x:1487,y:848,t:1527876893803};\\\", \\\"{x:1486,y:846,t:1527876893820};\\\", \\\"{x:1486,y:845,t:1527876893839};\\\", \\\"{x:1486,y:844,t:1527876893853};\\\", \\\"{x:1486,y:843,t:1527876893870};\\\", \\\"{x:1486,y:840,t:1527876893888};\\\", \\\"{x:1485,y:837,t:1527876893903};\\\", \\\"{x:1485,y:836,t:1527876893921};\\\", \\\"{x:1484,y:836,t:1527876893943};\\\", \\\"{x:1484,y:839,t:1527876899641};\\\", \\\"{x:1484,y:848,t:1527876899659};\\\", \\\"{x:1484,y:854,t:1527876899676};\\\", \\\"{x:1484,y:861,t:1527876899691};\\\", \\\"{x:1484,y:870,t:1527876899709};\\\", \\\"{x:1485,y:876,t:1527876899725};\\\", \\\"{x:1485,y:885,t:1527876899742};\\\", \\\"{x:1485,y:889,t:1527876899758};\\\", \\\"{x:1485,y:899,t:1527876899775};\\\", \\\"{x:1485,y:905,t:1527876899792};\\\", \\\"{x:1485,y:908,t:1527876899808};\\\", \\\"{x:1485,y:912,t:1527876899825};\\\", \\\"{x:1485,y:915,t:1527876899841};\\\", \\\"{x:1485,y:921,t:1527876899858};\\\", \\\"{x:1484,y:926,t:1527876899876};\\\", \\\"{x:1483,y:931,t:1527876899891};\\\", \\\"{x:1483,y:932,t:1527876899908};\\\", \\\"{x:1483,y:933,t:1527876899925};\\\", \\\"{x:1482,y:934,t:1527876899942};\\\", \\\"{x:1482,y:935,t:1527876899958};\\\", \\\"{x:1482,y:938,t:1527876899976};\\\", \\\"{x:1482,y:939,t:1527876899993};\\\", \\\"{x:1482,y:940,t:1527876900023};\\\", \\\"{x:1482,y:941,t:1527876900039};\\\", \\\"{x:1482,y:942,t:1527876900047};\\\", \\\"{x:1482,y:944,t:1527876900058};\\\", \\\"{x:1482,y:948,t:1527876900075};\\\", \\\"{x:1482,y:951,t:1527876900092};\\\", \\\"{x:1482,y:957,t:1527876900108};\\\", \\\"{x:1481,y:960,t:1527876900125};\\\", \\\"{x:1481,y:964,t:1527876900142};\\\", \\\"{x:1481,y:965,t:1527876900158};\\\", \\\"{x:1481,y:966,t:1527876900174};\\\", \\\"{x:1481,y:964,t:1527876900288};\\\", \\\"{x:1480,y:957,t:1527876900295};\\\", \\\"{x:1473,y:938,t:1527876900309};\\\", \\\"{x:1451,y:881,t:1527876900325};\\\", \\\"{x:1432,y:846,t:1527876900342};\\\", \\\"{x:1401,y:819,t:1527876900360};\\\", \\\"{x:1369,y:810,t:1527876900375};\\\", \\\"{x:1306,y:803,t:1527876900392};\\\", \\\"{x:1244,y:803,t:1527876900410};\\\", \\\"{x:1178,y:803,t:1527876900425};\\\", \\\"{x:1127,y:802,t:1527876900442};\\\", \\\"{x:1069,y:795,t:1527876900460};\\\", \\\"{x:1011,y:782,t:1527876900475};\\\", \\\"{x:962,y:763,t:1527876900493};\\\", \\\"{x:928,y:747,t:1527876900509};\\\", \\\"{x:909,y:733,t:1527876900525};\\\", \\\"{x:899,y:726,t:1527876900543};\\\", \\\"{x:882,y:712,t:1527876900559};\\\", \\\"{x:858,y:702,t:1527876900576};\\\", \\\"{x:837,y:697,t:1527876900592};\\\", \\\"{x:815,y:691,t:1527876900609};\\\", \\\"{x:795,y:685,t:1527876900625};\\\", \\\"{x:771,y:680,t:1527876900642};\\\", \\\"{x:740,y:671,t:1527876900659};\\\", \\\"{x:708,y:665,t:1527876900675};\\\", \\\"{x:671,y:658,t:1527876900692};\\\", \\\"{x:620,y:650,t:1527876900709};\\\", \\\"{x:555,y:628,t:1527876900728};\\\", \\\"{x:490,y:616,t:1527876900743};\\\", \\\"{x:445,y:604,t:1527876900759};\\\", \\\"{x:435,y:601,t:1527876900773};\\\", \\\"{x:421,y:596,t:1527876900790};\\\", \\\"{x:421,y:595,t:1527876900815};\\\", \\\"{x:421,y:594,t:1527876900822};\\\", \\\"{x:422,y:591,t:1527876900839};\\\", \\\"{x:432,y:587,t:1527876900856};\\\", \\\"{x:449,y:583,t:1527876900873};\\\", \\\"{x:476,y:578,t:1527876900890};\\\", \\\"{x:497,y:578,t:1527876900907};\\\", \\\"{x:514,y:578,t:1527876900923};\\\", \\\"{x:526,y:578,t:1527876900939};\\\", \\\"{x:531,y:578,t:1527876900958};\\\", \\\"{x:535,y:580,t:1527876900975};\\\", \\\"{x:537,y:580,t:1527876900991};\\\", \\\"{x:542,y:582,t:1527876901008};\\\", \\\"{x:549,y:583,t:1527876901025};\\\", \\\"{x:555,y:587,t:1527876901042};\\\", \\\"{x:559,y:588,t:1527876901059};\\\", \\\"{x:561,y:590,t:1527876901075};\\\", \\\"{x:563,y:590,t:1527876901092};\\\", \\\"{x:566,y:592,t:1527876901109};\\\", \\\"{x:568,y:592,t:1527876901125};\\\", \\\"{x:571,y:593,t:1527876901142};\\\", \\\"{x:573,y:593,t:1527876901159};\\\", \\\"{x:580,y:593,t:1527876901175};\\\", \\\"{x:583,y:593,t:1527876901192};\\\", \\\"{x:587,y:593,t:1527876901209};\\\", \\\"{x:589,y:592,t:1527876901225};\\\", \\\"{x:591,y:592,t:1527876901242};\\\", \\\"{x:592,y:592,t:1527876901259};\\\", \\\"{x:593,y:592,t:1527876901275};\\\", \\\"{x:595,y:592,t:1527876901292};\\\", \\\"{x:596,y:591,t:1527876901309};\\\", \\\"{x:597,y:591,t:1527876901325};\\\", \\\"{x:599,y:590,t:1527876901343};\\\", \\\"{x:600,y:590,t:1527876901360};\\\", \\\"{x:602,y:590,t:1527876901375};\\\", \\\"{x:604,y:589,t:1527876901392};\\\", \\\"{x:605,y:589,t:1527876901409};\\\", \\\"{x:607,y:588,t:1527876901430};\\\", \\\"{x:608,y:588,t:1527876901446};\\\", \\\"{x:608,y:587,t:1527876901494};\\\", \\\"{x:609,y:586,t:1527876901509};\\\", \\\"{x:610,y:586,t:1527876901758};\\\", \\\"{x:622,y:593,t:1527876901776};\\\", \\\"{x:641,y:605,t:1527876901793};\\\", \\\"{x:663,y:617,t:1527876901809};\\\", \\\"{x:681,y:627,t:1527876901826};\\\", \\\"{x:714,y:641,t:1527876901842};\\\", \\\"{x:735,y:652,t:1527876901859};\\\", \\\"{x:755,y:661,t:1527876901875};\\\", \\\"{x:783,y:673,t:1527876901892};\\\", \\\"{x:815,y:689,t:1527876901909};\\\", \\\"{x:846,y:701,t:1527876901926};\\\", \\\"{x:933,y:740,t:1527876901943};\\\", \\\"{x:992,y:757,t:1527876901959};\\\", \\\"{x:1074,y:776,t:1527876901976};\\\", \\\"{x:1159,y:795,t:1527876901992};\\\", \\\"{x:1247,y:806,t:1527876902009};\\\", \\\"{x:1318,y:818,t:1527876902026};\\\", \\\"{x:1377,y:830,t:1527876902043};\\\", \\\"{x:1418,y:844,t:1527876902059};\\\", \\\"{x:1448,y:857,t:1527876902076};\\\", \\\"{x:1468,y:868,t:1527876902093};\\\", \\\"{x:1486,y:879,t:1527876902109};\\\", \\\"{x:1496,y:888,t:1527876902127};\\\", \\\"{x:1500,y:893,t:1527876902142};\\\", \\\"{x:1503,y:901,t:1527876902160};\\\", \\\"{x:1506,y:907,t:1527876902177};\\\", \\\"{x:1507,y:910,t:1527876902194};\\\", \\\"{x:1507,y:912,t:1527876902209};\\\", \\\"{x:1506,y:916,t:1527876902226};\\\", \\\"{x:1503,y:929,t:1527876902243};\\\", \\\"{x:1499,y:938,t:1527876902259};\\\", \\\"{x:1496,y:942,t:1527876902276};\\\", \\\"{x:1495,y:943,t:1527876902293};\\\", \\\"{x:1494,y:944,t:1527876902318};\\\", \\\"{x:1494,y:946,t:1527876902334};\\\", \\\"{x:1494,y:948,t:1527876902342};\\\", \\\"{x:1494,y:951,t:1527876902359};\\\", \\\"{x:1494,y:952,t:1527876902376};\\\", \\\"{x:1494,y:950,t:1527876902584};\\\", \\\"{x:1494,y:947,t:1527876902594};\\\", \\\"{x:1494,y:935,t:1527876902610};\\\", \\\"{x:1494,y:915,t:1527876902627};\\\", \\\"{x:1494,y:894,t:1527876902644};\\\", \\\"{x:1494,y:883,t:1527876902661};\\\", \\\"{x:1494,y:875,t:1527876902677};\\\", \\\"{x:1493,y:866,t:1527876902693};\\\", \\\"{x:1489,y:854,t:1527876902710};\\\", \\\"{x:1486,y:846,t:1527876902726};\\\", \\\"{x:1485,y:842,t:1527876902743};\\\", \\\"{x:1484,y:841,t:1527876902761};\\\", \\\"{x:1484,y:840,t:1527876902887};\\\", \\\"{x:1483,y:840,t:1527876902968};\\\", \\\"{x:1483,y:839,t:1527876902976};\\\", \\\"{x:1483,y:837,t:1527876902994};\\\", \\\"{x:1483,y:836,t:1527876903040};\\\", \\\"{x:1483,y:835,t:1527876903049};\\\", \\\"{x:1483,y:834,t:1527876903060};\\\", \\\"{x:1483,y:833,t:1527876903078};\\\", \\\"{x:1483,y:832,t:1527876903215};\\\", \\\"{x:1483,y:827,t:1527876904760};\\\", \\\"{x:1486,y:819,t:1527876904768};\\\", \\\"{x:1487,y:815,t:1527876904777};\\\", \\\"{x:1488,y:808,t:1527876904794};\\\", \\\"{x:1490,y:800,t:1527876904810};\\\", \\\"{x:1491,y:800,t:1527876904827};\\\", \\\"{x:1491,y:798,t:1527876904844};\\\", \\\"{x:1492,y:794,t:1527876904861};\\\", \\\"{x:1492,y:792,t:1527876904877};\\\", \\\"{x:1493,y:786,t:1527876904894};\\\", \\\"{x:1493,y:781,t:1527876904911};\\\", \\\"{x:1493,y:776,t:1527876904927};\\\", \\\"{x:1493,y:772,t:1527876904945};\\\", \\\"{x:1494,y:768,t:1527876904961};\\\", \\\"{x:1494,y:767,t:1527876904977};\\\", \\\"{x:1495,y:765,t:1527876904994};\\\", \\\"{x:1495,y:763,t:1527876905012};\\\", \\\"{x:1495,y:762,t:1527876905031};\\\", \\\"{x:1495,y:759,t:1527876905046};\\\", \\\"{x:1495,y:758,t:1527876905063};\\\", \\\"{x:1495,y:757,t:1527876905079};\\\", \\\"{x:1495,y:756,t:1527876905095};\\\", \\\"{x:1495,y:752,t:1527876905111};\\\", \\\"{x:1495,y:747,t:1527876905128};\\\", \\\"{x:1495,y:745,t:1527876905144};\\\", \\\"{x:1495,y:740,t:1527876905162};\\\", \\\"{x:1495,y:738,t:1527876905179};\\\", \\\"{x:1495,y:735,t:1527876905194};\\\", \\\"{x:1495,y:732,t:1527876905212};\\\", \\\"{x:1495,y:729,t:1527876905229};\\\", \\\"{x:1495,y:728,t:1527876905247};\\\", \\\"{x:1495,y:727,t:1527876905262};\\\", \\\"{x:1495,y:726,t:1527876905279};\\\", \\\"{x:1495,y:725,t:1527876905295};\\\", \\\"{x:1495,y:723,t:1527876905311};\\\", \\\"{x:1495,y:722,t:1527876905335};\\\", \\\"{x:1495,y:721,t:1527876905359};\\\", \\\"{x:1495,y:720,t:1527876905375};\\\", \\\"{x:1495,y:719,t:1527876905440};\\\", \\\"{x:1494,y:718,t:1527876905455};\\\", \\\"{x:1494,y:717,t:1527876905471};\\\", \\\"{x:1493,y:715,t:1527876905487};\\\", \\\"{x:1492,y:714,t:1527876905512};\\\", \\\"{x:1492,y:713,t:1527876905529};\\\", \\\"{x:1491,y:713,t:1527876905544};\\\", \\\"{x:1489,y:712,t:1527876905562};\\\", \\\"{x:1487,y:710,t:1527876905579};\\\", \\\"{x:1486,y:709,t:1527876905594};\\\", \\\"{x:1483,y:707,t:1527876905612};\\\", \\\"{x:1481,y:706,t:1527876905629};\\\", \\\"{x:1480,y:705,t:1527876905663};\\\", \\\"{x:1480,y:703,t:1527876905704};\\\", \\\"{x:1479,y:703,t:1527876905711};\\\", \\\"{x:1478,y:702,t:1527876905729};\\\", \\\"{x:1478,y:700,t:1527876905751};\\\", \\\"{x:1478,y:699,t:1527876905767};\\\", \\\"{x:1478,y:698,t:1527876905783};\\\", \\\"{x:1477,y:698,t:1527876905799};\\\", \\\"{x:1477,y:697,t:1527876905812};\\\", \\\"{x:1477,y:696,t:1527876905830};\\\", \\\"{x:1477,y:695,t:1527876905846};\\\", \\\"{x:1477,y:694,t:1527876905862};\\\", \\\"{x:1477,y:693,t:1527876905879};\\\", \\\"{x:1477,y:689,t:1527876906704};\\\", \\\"{x:1477,y:687,t:1527876906713};\\\", \\\"{x:1477,y:685,t:1527876906728};\\\", \\\"{x:1477,y:683,t:1527876906746};\\\", \\\"{x:1477,y:682,t:1527876906763};\\\", \\\"{x:1477,y:681,t:1527876907528};\\\", \\\"{x:1477,y:677,t:1527876907536};\\\", \\\"{x:1477,y:672,t:1527876907545};\\\", \\\"{x:1481,y:660,t:1527876907563};\\\", \\\"{x:1483,y:654,t:1527876907580};\\\", \\\"{x:1484,y:648,t:1527876907597};\\\", \\\"{x:1485,y:642,t:1527876907613};\\\", \\\"{x:1485,y:639,t:1527876907630};\\\", \\\"{x:1485,y:637,t:1527876907647};\\\", \\\"{x:1485,y:636,t:1527876907679};\\\", \\\"{x:1485,y:634,t:1527876907736};\\\", \\\"{x:1485,y:633,t:1527876907759};\\\", \\\"{x:1485,y:631,t:1527876907824};\\\", \\\"{x:1485,y:630,t:1527876907839};\\\", \\\"{x:1485,y:628,t:1527876907856};\\\", \\\"{x:1485,y:627,t:1527876907863};\\\", \\\"{x:1485,y:625,t:1527876907879};\\\", \\\"{x:1485,y:623,t:1527876907897};\\\", \\\"{x:1485,y:622,t:1527876907912};\\\", \\\"{x:1485,y:620,t:1527876907930};\\\", \\\"{x:1485,y:618,t:1527876907946};\\\", \\\"{x:1485,y:617,t:1527876907963};\\\", \\\"{x:1485,y:615,t:1527876907980};\\\", \\\"{x:1485,y:614,t:1527876907997};\\\", \\\"{x:1485,y:612,t:1527876908012};\\\", \\\"{x:1485,y:608,t:1527876908030};\\\", \\\"{x:1485,y:604,t:1527876908047};\\\", \\\"{x:1485,y:602,t:1527876908063};\\\", \\\"{x:1485,y:600,t:1527876908080};\\\", \\\"{x:1485,y:599,t:1527876908096};\\\", \\\"{x:1485,y:597,t:1527876908112};\\\", \\\"{x:1485,y:596,t:1527876908130};\\\", \\\"{x:1485,y:595,t:1527876908147};\\\", \\\"{x:1485,y:591,t:1527876908162};\\\", \\\"{x:1485,y:588,t:1527876908180};\\\", \\\"{x:1485,y:583,t:1527876908197};\\\", \\\"{x:1485,y:581,t:1527876908213};\\\", \\\"{x:1485,y:577,t:1527876908230};\\\", \\\"{x:1485,y:572,t:1527876908247};\\\", \\\"{x:1485,y:569,t:1527876908263};\\\", \\\"{x:1485,y:568,t:1527876908280};\\\", \\\"{x:1485,y:565,t:1527876908296};\\\", \\\"{x:1485,y:562,t:1527876908936};\\\", \\\"{x:1485,y:557,t:1527876908947};\\\", \\\"{x:1485,y:542,t:1527876908963};\\\", \\\"{x:1482,y:523,t:1527876908980};\\\", \\\"{x:1481,y:507,t:1527876908997};\\\", \\\"{x:1477,y:490,t:1527876909014};\\\", \\\"{x:1476,y:473,t:1527876909031};\\\", \\\"{x:1474,y:465,t:1527876909047};\\\", \\\"{x:1473,y:458,t:1527876909064};\\\", \\\"{x:1468,y:446,t:1527876909080};\\\", \\\"{x:1464,y:439,t:1527876909097};\\\", \\\"{x:1463,y:439,t:1527876909114};\\\", \\\"{x:1457,y:439,t:1527876909167};\\\", \\\"{x:1445,y:439,t:1527876909181};\\\", \\\"{x:1392,y:446,t:1527876909196};\\\", \\\"{x:1286,y:464,t:1527876909213};\\\", \\\"{x:1122,y:484,t:1527876909230};\\\", \\\"{x:1026,y:492,t:1527876909247};\\\", \\\"{x:961,y:493,t:1527876909264};\\\", \\\"{x:927,y:499,t:1527876909280};\\\", \\\"{x:924,y:500,t:1527876909296};\\\", \\\"{x:920,y:502,t:1527876909313};\\\", \\\"{x:915,y:504,t:1527876909330};\\\", \\\"{x:903,y:509,t:1527876909346};\\\", \\\"{x:891,y:516,t:1527876909358};\\\", \\\"{x:867,y:523,t:1527876909376};\\\", \\\"{x:843,y:526,t:1527876909392};\\\", \\\"{x:807,y:534,t:1527876909415};\\\", \\\"{x:779,y:542,t:1527876909432};\\\", \\\"{x:752,y:551,t:1527876909448};\\\", \\\"{x:719,y:559,t:1527876909465};\\\", \\\"{x:692,y:567,t:1527876909482};\\\", \\\"{x:674,y:572,t:1527876909498};\\\", \\\"{x:657,y:577,t:1527876909516};\\\", \\\"{x:646,y:581,t:1527876909532};\\\", \\\"{x:636,y:584,t:1527876909548};\\\", \\\"{x:620,y:587,t:1527876909565};\\\", \\\"{x:588,y:591,t:1527876909582};\\\", \\\"{x:569,y:596,t:1527876909598};\\\", \\\"{x:548,y:601,t:1527876909615};\\\", \\\"{x:526,y:603,t:1527876909632};\\\", \\\"{x:493,y:606,t:1527876909649};\\\", \\\"{x:462,y:606,t:1527876909665};\\\", \\\"{x:433,y:606,t:1527876909682};\\\", \\\"{x:406,y:606,t:1527876909698};\\\", \\\"{x:384,y:606,t:1527876909715};\\\", \\\"{x:367,y:605,t:1527876909732};\\\", \\\"{x:358,y:601,t:1527876909749};\\\", \\\"{x:355,y:600,t:1527876909765};\\\", \\\"{x:354,y:598,t:1527876909782};\\\", \\\"{x:354,y:595,t:1527876909798};\\\", \\\"{x:353,y:593,t:1527876909815};\\\", \\\"{x:355,y:593,t:1527876909887};\\\", \\\"{x:359,y:593,t:1527876909899};\\\", \\\"{x:365,y:593,t:1527876909916};\\\", \\\"{x:372,y:593,t:1527876909932};\\\", \\\"{x:379,y:592,t:1527876909950};\\\", \\\"{x:387,y:591,t:1527876909965};\\\", \\\"{x:391,y:591,t:1527876909982};\\\", \\\"{x:392,y:591,t:1527876910014};\\\", \\\"{x:393,y:591,t:1527876910046};\\\", \\\"{x:394,y:591,t:1527876910230};\\\", \\\"{x:401,y:600,t:1527876910238};\\\", \\\"{x:407,y:608,t:1527876910250};\\\", \\\"{x:415,y:619,t:1527876910266};\\\", \\\"{x:427,y:636,t:1527876910282};\\\", \\\"{x:446,y:657,t:1527876910299};\\\", \\\"{x:459,y:675,t:1527876910316};\\\", \\\"{x:469,y:690,t:1527876910333};\\\", \\\"{x:478,y:704,t:1527876910350};\\\", \\\"{x:488,y:717,t:1527876910366};\\\", \\\"{x:492,y:723,t:1527876910382};\\\", \\\"{x:496,y:728,t:1527876910399};\\\", \\\"{x:502,y:738,t:1527876910417};\\\", \\\"{x:507,y:747,t:1527876910433};\\\", \\\"{x:511,y:755,t:1527876910449};\\\", \\\"{x:513,y:758,t:1527876910467};\\\", \\\"{x:514,y:762,t:1527876910482};\\\", \\\"{x:515,y:763,t:1527876910499};\\\", \\\"{x:516,y:763,t:1527876910822};\\\", \\\"{x:519,y:763,t:1527876910833};\\\", \\\"{x:526,y:763,t:1527876910849};\\\", \\\"{x:535,y:763,t:1527876910867};\\\", \\\"{x:544,y:763,t:1527876910884};\\\", \\\"{x:545,y:763,t:1527876910911};\\\", \\\"{x:547,y:762,t:1527876911254};\\\", \\\"{x:548,y:759,t:1527876911266};\\\", \\\"{x:550,y:756,t:1527876911283};\\\", \\\"{x:556,y:750,t:1527876911300};\\\", \\\"{x:565,y:744,t:1527876911316};\\\", \\\"{x:573,y:736,t:1527876911333};\\\", \\\"{x:583,y:729,t:1527876911350};\\\", \\\"{x:592,y:723,t:1527876911366};\\\", \\\"{x:599,y:718,t:1527876911383};\\\", \\\"{x:605,y:712,t:1527876911400};\\\", \\\"{x:609,y:711,t:1527876911417};\\\", \\\"{x:610,y:709,t:1527876911433};\\\", \\\"{x:611,y:709,t:1527876911450};\\\" ] }, { \\\"rt\\\": 21301, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 545591, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You look at 12PM at the bottom, and then follow the horizontal line going to the right.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5841, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Malaysia\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 552435, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 12396, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 565844, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 2335, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 569266, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"202VN\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"202VN\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 149, dom: 673, initialDom: 754",
  "javascriptErrors": []
}