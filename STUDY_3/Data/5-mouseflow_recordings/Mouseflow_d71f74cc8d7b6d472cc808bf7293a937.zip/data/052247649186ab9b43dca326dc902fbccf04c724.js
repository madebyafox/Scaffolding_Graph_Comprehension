var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052247649186ab9b43dca326dc902fbccf04c724"] = {
  "startTime": "2018-05-22T21:15:47.5959948Z",
  "websitePageUrl": "/16",
  "visitTime": 214288,
  "engagementTime": 178247,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d71f74cc8d7b6d472cc808bf7293a937",
    "created": "2018-05-22T21:15:47.5959948+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=T5SHZ",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b4b3513708e54b05c8c485e0c93e908a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d71f74cc8d7b6d472cc808bf7293a937/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 192,
      "e": 192,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 777,
      "y": 739
    },
    {
      "t": 1457,
      "e": 1457,
      "ty": 6,
      "x": 537,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1472,
      "e": 1472,
      "ty": 7,
      "x": 439,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 345,
      "y": 475
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 27867,
      "y": 25870,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 209,
      "y": 440
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 185,
      "y": 514
    },
    {
      "t": 1707,
      "e": 1707,
      "ty": 6,
      "x": 182,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 9544,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 186,
      "y": 555
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 194,
      "y": 566
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 10893,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2103,
      "e": 2103,
      "ty": 3,
      "x": 194,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2104,
      "e": 2104,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2205,
      "e": 2205,
      "ty": 4,
      "x": 10893,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2206,
      "e": 2206,
      "ty": 5,
      "x": 194,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 7206,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15259,
      "e": 7206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15298,
      "e": 7245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15299,
      "e": 7246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15353,
      "e": 7300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 15401,
      "e": 7348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 15490,
      "e": 7437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15490,
      "e": 7437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15546,
      "e": 7493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15546,
      "e": 7493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15569,
      "e": 7516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fro"
    },
    {
      "t": 15682,
      "e": 7629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15682,
      "e": 7629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15762,
      "e": 7709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From"
    },
    {
      "t": 15842,
      "e": 7789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15842,
      "e": 7789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15850,
      "e": 7797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15913,
      "e": 7860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15913,
      "e": 7860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15929,
      "e": 7876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16025,
      "e": 7972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16025,
      "e": 7972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16025,
      "e": 7972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16097,
      "e": 8044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16177,
      "e": 8124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 16177,
      "e": 8124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16289,
      "e": 8236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 16322,
      "e": 8269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16322,
      "e": 8269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16410,
      "e": 8357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16746,
      "e": 8693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16747,
      "e": 8694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16809,
      "e": 8756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18306,
      "e": 10253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18306,
      "e": 10253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18394,
      "e": 10341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18418,
      "e": 10365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18419,
      "e": 10366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18489,
      "e": 10436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18490,
      "e": 10437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18521,
      "e": 10468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 18561,
      "e": 10508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 18561,
      "e": 10508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18585,
      "e": 10532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 18634,
      "e": 10581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18746,
      "e": 10693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18747,
      "e": 10694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18809,
      "e": 10756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19050,
      "e": 10997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19051,
      "e": 10998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19113,
      "e": 11060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19250,
      "e": 11197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19354,
      "e": 11301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 19356,
      "e": 11303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19385,
      "e": 11332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 19409,
      "e": 11356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19626,
      "e": 11573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19627,
      "e": 11574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19713,
      "e": 11660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19770,
      "e": 11717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19770,
      "e": 11717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19850,
      "e": 11797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19874,
      "e": 11821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19875,
      "e": 11822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 11948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20154,
      "e": 12101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20314,
      "e": 12261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 20315,
      "e": 12262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20321,
      "e": 12268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 20369,
      "e": 12316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20642,
      "e": 12589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 20643,
      "e": 12590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20713,
      "e": 12660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 21122,
      "e": 13069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21123,
      "e": 13070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21194,
      "e": 13141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23026,
      "e": 14973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 23027,
      "e": 14974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23098,
      "e": 15045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 23162,
      "e": 15109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23162,
      "e": 15109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23258,
      "e": 15205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 23259,
      "e": 15206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23306,
      "e": 15253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 23370,
      "e": 15317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23370,
      "e": 15317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23371,
      "e": 15318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23449,
      "e": 15396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23722,
      "e": 15669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23723,
      "e": 15670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23794,
      "e": 15741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23890,
      "e": 15837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23891,
      "e": 15838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23937,
      "e": 15884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24026,
      "e": 15973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24026,
      "e": 15973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24090,
      "e": 16037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24130,
      "e": 16077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 24131,
      "e": 16078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24241,
      "e": 16188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 24249,
      "e": 16196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24250,
      "e": 16197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24346,
      "e": 16293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24482,
      "e": 16429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24482,
      "e": 16429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24569,
      "e": 16516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24570,
      "e": 16517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24586,
      "e": 16533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 24649,
      "e": 16596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24690,
      "e": 16637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24690,
      "e": 16637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24753,
      "e": 16700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24762,
      "e": 16709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24763,
      "e": 16710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24825,
      "e": 16772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24850,
      "e": 16797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24850,
      "e": 16797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24906,
      "e": 16853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 24921,
      "e": 16868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24922,
      "e": 16869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25018,
      "e": 16965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25025,
      "e": 16972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25026,
      "e": 16973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25106,
      "e": 17053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25154,
      "e": 17101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25155,
      "e": 17102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25217,
      "e": 17164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25298,
      "e": 17245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25298,
      "e": 17245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25378,
      "e": 17325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25386,
      "e": 17333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25387,
      "e": 17334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25442,
      "e": 17335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25473,
      "e": 17366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25473,
      "e": 17366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25553,
      "e": 17446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25585,
      "e": 17478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25586,
      "e": 17479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25658,
      "e": 17551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25690,
      "e": 17583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25690,
      "e": 17583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25753,
      "e": 17646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25785,
      "e": 17678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25786,
      "e": 17679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25866,
      "e": 17759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25889,
      "e": 17782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25889,
      "e": 17782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25953,
      "e": 17846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25962,
      "e": 17855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25962,
      "e": 17855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26041,
      "e": 17934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26065,
      "e": 17958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26065,
      "e": 17958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26154,
      "e": 18047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26177,
      "e": 18070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26177,
      "e": 18070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26234,
      "e": 18127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26273,
      "e": 18166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26273,
      "e": 18166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26354,
      "e": 18247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26354,
      "e": 18247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26378,
      "e": 18271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 26458,
      "e": 18351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26466,
      "e": 18359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26467,
      "e": 18360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26545,
      "e": 18438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26593,
      "e": 18486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26594,
      "e": 18487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26673,
      "e": 18566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26690,
      "e": 18583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26690,
      "e": 18583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26762,
      "e": 18655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26770,
      "e": 18663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26770,
      "e": 18663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26858,
      "e": 18751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26882,
      "e": 18775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26883,
      "e": 18776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26945,
      "e": 18838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 26985,
      "e": 18878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26985,
      "e": 18878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27074,
      "e": 18967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27114,
      "e": 19007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27115,
      "e": 19008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27185,
      "e": 19078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27842,
      "e": 19735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 27843,
      "e": 19736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27905,
      "e": 19798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 28041,
      "e": 19934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28041,
      "e": 19934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28098,
      "e": 19991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28114,
      "e": 20007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28114,
      "e": 20007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28186,
      "e": 20079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 28282,
      "e": 20175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28282,
      "e": 20175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28329,
      "e": 20222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28330,
      "e": 20223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28354,
      "e": 20247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 28426,
      "e": 20319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28441,
      "e": 20334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28443,
      "e": 20336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28529,
      "e": 20422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28545,
      "e": 20438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28545,
      "e": 20438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28602,
      "e": 20495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28633,
      "e": 20526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28634,
      "e": 20527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28706,
      "e": 20599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28762,
      "e": 20655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 28763,
      "e": 20656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28817,
      "e": 20710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 29258,
      "e": 21151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29259,
      "e": 21152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29314,
      "e": 21207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29730,
      "e": 21623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29810,
      "e": 21703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29811,
      "e": 21704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29834,
      "e": 21727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 29906,
      "e": 21799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29946,
      "e": 21839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29947,
      "e": 21840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30002,
      "e": 21895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30042,
      "e": 21935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30043,
      "e": 21936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30113,
      "e": 22006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30129,
      "e": 22022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30129,
      "e": 22022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30193,
      "e": 22086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30498,
      "e": 22391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30499,
      "e": 22392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30537,
      "e": 22430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 30601,
      "e": 22494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30601,
      "e": 22494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30657,
      "e": 22550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30657,
      "e": 22550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30665,
      "e": 22558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ir"
    },
    {
      "t": 30714,
      "e": 22607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30809,
      "e": 22702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30811,
      "e": 22704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30849,
      "e": 22742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30850,
      "e": 22743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30905,
      "e": 22798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 30993,
      "e": 22886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31033,
      "e": 22926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31034,
      "e": 22927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31089,
      "e": 22982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31203,
      "e": 23096,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first "
    },
    {
      "t": 31753,
      "e": 23646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31754,
      "e": 23647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31865,
      "e": 23758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31865,
      "e": 23758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31873,
      "e": 23766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 31963,
      "e": 23768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31964,
      "e": 23769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31970,
      "e": 23775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32049,
      "e": 23854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32386,
      "e": 24191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32387,
      "e": 24192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32433,
      "e": 24238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32762,
      "e": 24567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32809,
      "e": 24614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first lin"
    },
    {
      "t": 32921,
      "e": 24726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32937,
      "e": 24742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first li"
    },
    {
      "t": 33386,
      "e": 25191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33441,
      "e": 25246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first l"
    },
    {
      "t": 33658,
      "e": 25463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33658,
      "e": 25463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33737,
      "e": 25542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33738,
      "e": 25543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33761,
      "e": 25566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ef"
    },
    {
      "t": 33833,
      "e": 25638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33930,
      "e": 25735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33931,
      "e": 25736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33985,
      "e": 25790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34033,
      "e": 25838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34033,
      "e": 25838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34097,
      "e": 25902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34203,
      "e": 26008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left "
    },
    {
      "t": 34297,
      "e": 26102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34297,
      "e": 26102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34402,
      "e": 26207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34425,
      "e": 26230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34425,
      "e": 26230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34505,
      "e": 26310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34505,
      "e": 26310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34513,
      "e": 26318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 34593,
      "e": 26398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34617,
      "e": 26422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34619,
      "e": 26424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34633,
      "e": 26438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34633,
      "e": 26438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34673,
      "e": 26478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| e"
    },
    {
      "t": 34713,
      "e": 26518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34793,
      "e": 26598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34793,
      "e": 26598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34857,
      "e": 26662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 35162,
      "e": 26967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35201,
      "e": 27006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left lin e"
    },
    {
      "t": 35289,
      "e": 27094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35329,
      "e": 27134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left lin "
    },
    {
      "t": 35425,
      "e": 27230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35466,
      "e": 27271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left lin"
    },
    {
      "t": 35529,
      "e": 27334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35530,
      "e": 27335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35594,
      "e": 27399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35625,
      "e": 27430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35626,
      "e": 27431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35723,
      "e": 27432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35729,
      "e": 27438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35729,
      "e": 27438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35785,
      "e": 27494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 35786,
      "e": 27495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35817,
      "e": 27526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 35866,
      "e": 27575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35922,
      "e": 27631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35923,
      "e": 27632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35993,
      "e": 27702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36001,
      "e": 27710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36002,
      "e": 27711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36081,
      "e": 27790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36089,
      "e": 27798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36090,
      "e": 27799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36146,
      "e": 27855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36170,
      "e": 27879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36171,
      "e": 27880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36241,
      "e": 27950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36241,
      "e": 27950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36249,
      "e": 27958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 36305,
      "e": 28014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36305,
      "e": 28014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36329,
      "e": 28038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36369,
      "e": 28078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36474,
      "e": 28183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36474,
      "e": 28183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36529,
      "e": 28238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36537,
      "e": 28246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36537,
      "e": 28246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36601,
      "e": 28310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36657,
      "e": 28366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36658,
      "e": 28367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36730,
      "e": 28439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36754,
      "e": 28463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36755,
      "e": 28464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36833,
      "e": 28542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36873,
      "e": 28582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36873,
      "e": 28582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36953,
      "e": 28662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 36962,
      "e": 28671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36963,
      "e": 28672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37049,
      "e": 28758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 37074,
      "e": 28783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37075,
      "e": 28784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37130,
      "e": 28839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37186,
      "e": 28895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37186,
      "e": 28895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37225,
      "e": 28934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37833,
      "e": 29542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37834,
      "e": 29543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37929,
      "e": 29638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37929,
      "e": 29638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37937,
      "e": 29646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 38017,
      "e": 29726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38018,
      "e": 29727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38025,
      "e": 29734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38081,
      "e": 29790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38169,
      "e": 29878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38170,
      "e": 29879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38217,
      "e": 29926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38265,
      "e": 29974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38266,
      "e": 29975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38329,
      "e": 30038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38353,
      "e": 30062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38353,
      "e": 30062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38418,
      "e": 30127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38682,
      "e": 30391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38682,
      "e": 30391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38745,
      "e": 30454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 38809,
      "e": 30518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38810,
      "e": 30519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38930,
      "e": 30639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 38931,
      "e": 30640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38961,
      "e": 30670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 39009,
      "e": 30718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39010,
      "e": 30719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39024,
      "e": 30733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39081,
      "e": 30790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39089,
      "e": 30798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39089,
      "e": 30798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39153,
      "e": 30862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39185,
      "e": 30894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39186,
      "e": 30895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39257,
      "e": 30966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39273,
      "e": 30982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39274,
      "e": 30983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39361,
      "e": 31070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39377,
      "e": 31086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39377,
      "e": 31086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39442,
      "e": 31151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40170,
      "e": 31879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40171,
      "e": 31880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40241,
      "e": 31950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40241,
      "e": 31950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40257,
      "e": 31966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 40313,
      "e": 32022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40578,
      "e": 32287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40625,
      "e": 32334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the s"
    },
    {
      "t": 41722,
      "e": 33431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41723,
      "e": 33432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41770,
      "e": 33479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41772,
      "e": 33481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41801,
      "e": 33510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 41865,
      "e": 33574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 41865,
      "e": 33574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41873,
      "e": 33582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 41929,
      "e": 33638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42050,
      "e": 33759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42050,
      "e": 33759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42129,
      "e": 33838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42258,
      "e": 33967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42258,
      "e": 33967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42329,
      "e": 34038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43282,
      "e": 34991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43283,
      "e": 34992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43379,
      "e": 34994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43381,
      "e": 34996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43409,
      "e": 35024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 43465,
      "e": 35080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43617,
      "e": 35232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43618,
      "e": 35233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43713,
      "e": 35328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 43714,
      "e": 35329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43753,
      "e": 35368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 43801,
      "e": 35416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44169,
      "e": 35784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44169,
      "e": 35784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44225,
      "e": 35840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44433,
      "e": 36048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44435,
      "e": 36050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44505,
      "e": 36120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44537,
      "e": 36152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44537,
      "e": 36152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44609,
      "e": 36224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44610,
      "e": 36225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44610,
      "e": 36225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44705,
      "e": 36320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44705,
      "e": 36320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44737,
      "e": 36352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||im"
    },
    {
      "t": 44825,
      "e": 36440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44866,
      "e": 36481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44866,
      "e": 36481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44954,
      "e": 36569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45002,
      "e": 36617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45002,
      "e": 36617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45057,
      "e": 36672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45137,
      "e": 36752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45137,
      "e": 36752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45186,
      "e": 36801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45330,
      "e": 36945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45330,
      "e": 36945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45385,
      "e": 37000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45442,
      "e": 37057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45442,
      "e": 37057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45513,
      "e": 37128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45521,
      "e": 37136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45522,
      "e": 37137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45577,
      "e": 37192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45633,
      "e": 37248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45634,
      "e": 37249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45689,
      "e": 37304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45689,
      "e": 37304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45697,
      "e": 37312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 45762,
      "e": 37377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45817,
      "e": 37432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45817,
      "e": 37432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45881,
      "e": 37496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45897,
      "e": 37512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45898,
      "e": 37513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45985,
      "e": 37600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46353,
      "e": 37968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46353,
      "e": 37968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46417,
      "e": 38032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46441,
      "e": 38056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46441,
      "e": 38056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46497,
      "e": 38112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46569,
      "e": 38184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46569,
      "e": 38184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46641,
      "e": 38256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 46666,
      "e": 38281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46666,
      "e": 38281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46729,
      "e": 38344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46769,
      "e": 38384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46769,
      "e": 38384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46850,
      "e": 38465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46858,
      "e": 38473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46858,
      "e": 38473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46930,
      "e": 38545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46978,
      "e": 38593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 46979,
      "e": 38594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47041,
      "e": 38656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47041,
      "e": 38656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47065,
      "e": 38680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 47153,
      "e": 38768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47177,
      "e": 38792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47178,
      "e": 38793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47281,
      "e": 38896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47338,
      "e": 38953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47338,
      "e": 38953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47402,
      "e": 39017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 47914,
      "e": 39529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47914,
      "e": 39529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47977,
      "e": 39592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48041,
      "e": 39656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48042,
      "e": 39657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48049,
      "e": 39664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48049,
      "e": 39664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48073,
      "e": 39688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 48121,
      "e": 39736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48609,
      "e": 40224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48649,
      "e": 40264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line f"
    },
    {
      "t": 48761,
      "e": 40376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48794,
      "e": 40377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line "
    },
    {
      "t": 49049,
      "e": 40632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49051,
      "e": 40634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49128,
      "e": 40711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49145,
      "e": 40728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49145,
      "e": 40728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49217,
      "e": 40800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 49249,
      "e": 40832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49249,
      "e": 40832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49329,
      "e": 40912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49353,
      "e": 40936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49354,
      "e": 40937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49425,
      "e": 41008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49433,
      "e": 41016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49433,
      "e": 41016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49497,
      "e": 41080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 49537,
      "e": 41120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49538,
      "e": 41121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49609,
      "e": 41192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49633,
      "e": 41216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49633,
      "e": 41216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49680,
      "e": 41263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49803,
      "e": 41386,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the "
    },
    {
      "t": 50610,
      "e": 42193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50665,
      "e": 42248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the"
    },
    {
      "t": 50801,
      "e": 42384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50833,
      "e": 42416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of th"
    },
    {
      "t": 51922,
      "e": 43505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51987,
      "e": 43506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of t"
    },
    {
      "t": 52162,
      "e": 43681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52218,
      "e": 43737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of "
    },
    {
      "t": 53434,
      "e": 44953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53434,
      "e": 44953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53530,
      "e": 45049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53537,
      "e": 45056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53538,
      "e": 45057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53632,
      "e": 45151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 53633,
      "e": 45152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53634,
      "e": 45153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53705,
      "e": 45224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 53713,
      "e": 45232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53714,
      "e": 45233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53802,
      "e": 45321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53898,
      "e": 45417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53898,
      "e": 45417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53969,
      "e": 45488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54065,
      "e": 45584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 54065,
      "e": 45584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54185,
      "e": 45704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 54202,
      "e": 45721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54202,
      "e": 45721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54257,
      "e": 45776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54281,
      "e": 45800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54281,
      "e": 45800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54386,
      "e": 45905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54681,
      "e": 46200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54682,
      "e": 46201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54737,
      "e": 46256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54817,
      "e": 46336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 54817,
      "e": 46336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54881,
      "e": 46400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 54929,
      "e": 46448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 54929,
      "e": 46448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55002,
      "e": 46521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 55017,
      "e": 46536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55019,
      "e": 46538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55096,
      "e": 46615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55137,
      "e": 46656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55137,
      "e": 46656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55209,
      "e": 46728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55523,
      "e": 47042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55523,
      "e": 47042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55569,
      "e": 47088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55570,
      "e": 47089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55593,
      "e": 47112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 55697,
      "e": 47216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55705,
      "e": 47224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55705,
      "e": 47224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55801,
      "e": 47320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55826,
      "e": 47345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55826,
      "e": 47345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55880,
      "e": 47399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 55969,
      "e": 47488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55969,
      "e": 47488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56025,
      "e": 47544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 56138,
      "e": 47657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56138,
      "e": 47657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56210,
      "e": 47729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56210,
      "e": 47729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56241,
      "e": 47760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 56321,
      "e": 47840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56385,
      "e": 47904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 56385,
      "e": 47904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56442,
      "e": 47961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 56449,
      "e": 47968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56449,
      "e": 47968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56529,
      "e": 48048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56577,
      "e": 48096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 56578,
      "e": 48097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56641,
      "e": 48160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 56682,
      "e": 48201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56682,
      "e": 48201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56777,
      "e": 48296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 56777,
      "e": 48296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56801,
      "e": 48320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 56865,
      "e": 48384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 56865,
      "e": 48384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56881,
      "e": 48400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 56954,
      "e": 48473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57359,
      "e": 48878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57398,
      "e": 48878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming fom"
    },
    {
      "t": 57623,
      "e": 49103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57679,
      "e": 49159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming fo"
    },
    {
      "t": 57801,
      "e": 49281,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming fo"
    },
    {
      "t": 57822,
      "e": 49302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57855,
      "e": 49335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming f"
    },
    {
      "t": 58001,
      "e": 49481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming f"
    },
    {
      "t": 58039,
      "e": 49519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 58040,
      "e": 49520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58119,
      "e": 49599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 58135,
      "e": 49615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58136,
      "e": 49616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58246,
      "e": 49726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 58246,
      "e": 49726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58294,
      "e": 49774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 58367,
      "e": 49847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58368,
      "e": 49848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58374,
      "e": 49854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58414,
      "e": 49894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58455,
      "e": 49935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58455,
      "e": 49935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58543,
      "e": 50023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 58559,
      "e": 50039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58560,
      "e": 50040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58630,
      "e": 50110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58679,
      "e": 50159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58679,
      "e": 50159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58742,
      "e": 50222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58775,
      "e": 50255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58776,
      "e": 50256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58847,
      "e": 50327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58911,
      "e": 50391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 58911,
      "e": 50391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58998,
      "e": 50478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58998,
      "e": 50478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59006,
      "e": 50486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||do"
    },
    {
      "t": 59078,
      "e": 50558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59102,
      "e": 50582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59104,
      "e": 50584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59199,
      "e": 50679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59240,
      "e": 50720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59240,
      "e": 50720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59303,
      "e": 50783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59343,
      "e": 50823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59344,
      "e": 50824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59415,
      "e": 50895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59479,
      "e": 50959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59480,
      "e": 50960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59567,
      "e": 51047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 59575,
      "e": 51055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59576,
      "e": 51056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59622,
      "e": 51102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 59711,
      "e": 51191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59711,
      "e": 51191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59775,
      "e": 51255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 59807,
      "e": 51287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59807,
      "e": 51287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59878,
      "e": 51358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59935,
      "e": 51415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59935,
      "e": 51415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59999,
      "e": 51479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60087,
      "e": 51567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 60088,
      "e": 51568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60190,
      "e": 51670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 60231,
      "e": 51711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60231,
      "e": 51711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60367,
      "e": 51847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 60367,
      "e": 51847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60398,
      "e": 51878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 60417,
      "e": 51897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60417,
      "e": 51897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60462,
      "e": 51942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60526,
      "e": 52006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60574,
      "e": 52054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60574,
      "e": 52054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60655,
      "e": 52135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60671,
      "e": 52151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60672,
      "e": 52152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60750,
      "e": 52230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60782,
      "e": 52262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60782,
      "e": 52262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60862,
      "e": 52342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60903,
      "e": 52383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60904,
      "e": 52384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60999,
      "e": 52479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62967,
      "e": 54447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62967,
      "e": 54447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63038,
      "e": 54518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63126,
      "e": 54606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63127,
      "e": 54607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63191,
      "e": 54671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 63215,
      "e": 54695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63215,
      "e": 54695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63303,
      "e": 54783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 63335,
      "e": 54815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 63336,
      "e": 54816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63408,
      "e": 54888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 63511,
      "e": 54991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63511,
      "e": 54991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63566,
      "e": 55046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63631,
      "e": 55111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63631,
      "e": 55111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63694,
      "e": 55174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63775,
      "e": 55255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63776,
      "e": 55256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63838,
      "e": 55318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63871,
      "e": 55351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63871,
      "e": 55351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63935,
      "e": 55415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 63967,
      "e": 55447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 63967,
      "e": 55447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64062,
      "e": 55542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 64095,
      "e": 55575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64095,
      "e": 55575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64167,
      "e": 55647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64167,
      "e": 55647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64175,
      "e": 55655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 64254,
      "e": 55734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64359,
      "e": 55839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 64359,
      "e": 55839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64462,
      "e": 55942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 64478,
      "e": 55958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 64479,
      "e": 55959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64558,
      "e": 56038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 64607,
      "e": 56087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 64607,
      "e": 56087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64671,
      "e": 56151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 64802,
      "e": 56152,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end tme."
    },
    {
      "t": 64999,
      "e": 56349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 65046,
      "e": 56396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end tme"
    },
    {
      "t": 65142,
      "e": 56492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 65175,
      "e": 56525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end tm"
    },
    {
      "t": 65271,
      "e": 56621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 65318,
      "e": 56668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end t"
    },
    {
      "t": 65831,
      "e": 57181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65832,
      "e": 57182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65886,
      "e": 57236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 66002,
      "e": 57237,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end ti"
    },
    {
      "t": 66047,
      "e": 57282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 66047,
      "e": 57282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66102,
      "e": 57337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 66239,
      "e": 57474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66239,
      "e": 57474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66302,
      "e": 57537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66336,
      "e": 57571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 66336,
      "e": 57571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66406,
      "e": 57641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 66567,
      "e": 57802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66567,
      "e": 57802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66638,
      "e": 57873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66822,
      "e": 58057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 67127,
      "e": 58362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67128,
      "e": 58363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67175,
      "e": 58410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 67223,
      "e": 58458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67343,
      "e": 58578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67344,
      "e": 58579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67414,
      "e": 58649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67751,
      "e": 58986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67752,
      "e": 58987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67798,
      "e": 59033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67935,
      "e": 59170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67935,
      "e": 59170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68007,
      "e": 59242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68023,
      "e": 59258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 68023,
      "e": 59258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68086,
      "e": 59321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 68182,
      "e": 59417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68183,
      "e": 59418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68247,
      "e": 59482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68319,
      "e": 59554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 68320,
      "e": 59555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68399,
      "e": 59634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 68502,
      "e": 59737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68502,
      "e": 59737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68558,
      "e": 59793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68559,
      "e": 59794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68582,
      "e": 59817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||et"
    },
    {
      "t": 68662,
      "e": 59897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68734,
      "e": 59969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68734,
      "e": 59969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68799,
      "e": 60034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 68799,
      "e": 60034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68823,
      "e": 60058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 68895,
      "e": 60130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68903,
      "e": 60138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 68904,
      "e": 60139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68959,
      "e": 60194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 69007,
      "e": 60242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69007,
      "e": 60242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69103,
      "e": 60338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69103,
      "e": 60338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69118,
      "e": 60353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 69206,
      "e": 60441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69214,
      "e": 60449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69214,
      "e": 60449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69303,
      "e": 60538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69327,
      "e": 60562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69328,
      "e": 60563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69398,
      "e": 60633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69430,
      "e": 60665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 69430,
      "e": 60665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69510,
      "e": 60745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 69551,
      "e": 60786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69551,
      "e": 60786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69646,
      "e": 60881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69654,
      "e": 60889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69654,
      "e": 60889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69710,
      "e": 60945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69750,
      "e": 60985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 69751,
      "e": 60986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69814,
      "e": 61049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 69855,
      "e": 61090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69856,
      "e": 61091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69934,
      "e": 61169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69975,
      "e": 61210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69975,
      "e": 61210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70014,
      "e": 61249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70014,
      "e": 61249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70030,
      "e": 61265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| e"
    },
    {
      "t": 70119,
      "e": 61354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70231,
      "e": 61466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 70231,
      "e": 61466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70294,
      "e": 61529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 70367,
      "e": 61602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70367,
      "e": 61602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70487,
      "e": 61722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 71351,
      "e": 62586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71398,
      "e": 62586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which ev"
    },
    {
      "t": 71502,
      "e": 62690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71542,
      "e": 62730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which e"
    },
    {
      "t": 71631,
      "e": 62819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71670,
      "e": 62858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which "
    },
    {
      "t": 71801,
      "e": 62859,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which "
    },
    {
      "t": 72014,
      "e": 63072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72014,
      "e": 63072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72063,
      "e": 63121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72063,
      "e": 63121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72086,
      "e": 63144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 72151,
      "e": 63209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72151,
      "e": 63209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72174,
      "e": 63232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72230,
      "e": 63288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 72230,
      "e": 63288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72262,
      "e": 63320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 72303,
      "e": 63361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72399,
      "e": 63457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72400,
      "e": 63458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72470,
      "e": 63528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72614,
      "e": 63672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72615,
      "e": 63673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72687,
      "e": 63745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 72800,
      "e": 63858,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts"
    },
    {
      "t": 72839,
      "e": 63897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72840,
      "e": 63898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72894,
      "e": 63952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73000,
      "e": 64058,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts "
    },
    {
      "t": 73111,
      "e": 64169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73112,
      "e": 64170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73206,
      "e": 64264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73206,
      "e": 64264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73230,
      "e": 64288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 73310,
      "e": 64368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73414,
      "e": 64472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73415,
      "e": 64473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73454,
      "e": 64512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 73455,
      "e": 64513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73494,
      "e": 64513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 73550,
      "e": 64569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73639,
      "e": 64658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73639,
      "e": 64658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73719,
      "e": 64738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73783,
      "e": 64802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73784,
      "e": 64803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73846,
      "e": 64865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73887,
      "e": 64906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73887,
      "e": 64906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73974,
      "e": 64993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73974,
      "e": 64993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73999,
      "e": 65018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 74095,
      "e": 65114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74135,
      "e": 65154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74135,
      "e": 65154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74207,
      "e": 65226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74303,
      "e": 65322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 74303,
      "e": 65322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74438,
      "e": 65457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 74438,
      "e": 65457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74463,
      "e": 65482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 74551,
      "e": 65570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74823,
      "e": 65842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 74823,
      "e": 65842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74879,
      "e": 65898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 75000,
      "e": 66019,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12p"
    },
    {
      "t": 75022,
      "e": 66041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 75022,
      "e": 66041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75030,
      "e": 66049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 75201,
      "e": 66220,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm"
    },
    {
      "t": 75255,
      "e": 66274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 75255,
      "e": 66274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75294,
      "e": 66313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 75400,
      "e": 66313,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm,"
    },
    {
      "t": 75559,
      "e": 66472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75559,
      "e": 66472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75606,
      "e": 66519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79271,
      "e": 70184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 79272,
      "e": 70185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79326,
      "e": 70239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 79559,
      "e": 70472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79606,
      "e": 70519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, "
    },
    {
      "t": 79895,
      "e": 70808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 79895,
      "e": 70808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79966,
      "e": 70879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 80079,
      "e": 70992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 80079,
      "e": 70992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80200,
      "e": 71113,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, yo"
    },
    {
      "t": 80206,
      "e": 71119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 80206,
      "e": 71119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80230,
      "e": 71143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 80310,
      "e": 71223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80326,
      "e": 71239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80328,
      "e": 71241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80414,
      "e": 71327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80647,
      "e": 71560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 80647,
      "e": 71560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80710,
      "e": 71623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 80814,
      "e": 71727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 80815,
      "e": 71728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80863,
      "e": 71729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 80951,
      "e": 71817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 80951,
      "e": 71817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81046,
      "e": 71912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 81110,
      "e": 71976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 81110,
      "e": 71976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81215,
      "e": 72081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 81223,
      "e": 72089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81223,
      "e": 72089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81318,
      "e": 72184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81463,
      "e": 72329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81463,
      "e": 72329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81534,
      "e": 72400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81534,
      "e": 72400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81550,
      "e": 72416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 81638,
      "e": 72504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 82071,
      "e": 72937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82072,
      "e": 72938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82134,
      "e": 73000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83478,
      "e": 74344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 83480,
      "e": 74346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83551,
      "e": 74417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 83583,
      "e": 74449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 83583,
      "e": 74449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83638,
      "e": 74504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 83671,
      "e": 74537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 83672,
      "e": 74538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83742,
      "e": 74608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83743,
      "e": 74609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83750,
      "e": 74616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 83830,
      "e": 74696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84078,
      "e": 74944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 84079,
      "e": 74945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84175,
      "e": 75041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 84182,
      "e": 75048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84183,
      "e": 75049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84238,
      "e": 75104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 84286,
      "e": 75152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84286,
      "e": 75152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84366,
      "e": 75232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 84398,
      "e": 75264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 84399,
      "e": 75265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84470,
      "e": 75336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 84711,
      "e": 75577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 84712,
      "e": 75578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84773,
      "e": 75639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 84943,
      "e": 75809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 84943,
      "e": 75809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84990,
      "e": 75856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 85094,
      "e": 75960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 85095,
      "e": 75961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85183,
      "e": 76049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 85254,
      "e": 76120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 85256,
      "e": 76122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85326,
      "e": 76192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 85518,
      "e": 76384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85518,
      "e": 76384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85566,
      "e": 76432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 85710,
      "e": 76576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 85711,
      "e": 76577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85806,
      "e": 76672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 85806,
      "e": 76672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85822,
      "e": 76688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 85918,
      "e": 76784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 85919,
      "e": 76785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85934,
      "e": 76800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 86022,
      "e": 76888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86023,
      "e": 76889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 86023,
      "e": 76889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86127,
      "e": 76993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 86127,
      "e": 76993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86174,
      "e": 77040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 86262,
      "e": 77128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86310,
      "e": 77176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86311,
      "e": 77177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86382,
      "e": 77248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87887,
      "e": 78753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87888,
      "e": 78754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87974,
      "e": 78840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 87991,
      "e": 78857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 87991,
      "e": 78857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88054,
      "e": 78920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 88079,
      "e": 78945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 88080,
      "e": 78946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88142,
      "e": 79008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88142,
      "e": 79008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88182,
      "e": 79048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 88230,
      "e": 79096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88231,
      "e": 79097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88262,
      "e": 79128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 88310,
      "e": 79176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88542,
      "e": 79408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88543,
      "e": 79409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88598,
      "e": 79464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 88598,
      "e": 79464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88638,
      "e": 79504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sl"
    },
    {
      "t": 88678,
      "e": 79544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88775,
      "e": 79641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 88775,
      "e": 79641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88830,
      "e": 79696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 88846,
      "e": 79712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 88847,
      "e": 79713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88910,
      "e": 79776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 88959,
      "e": 79825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88959,
      "e": 79825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89037,
      "e": 79903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89061,
      "e": 79927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89062,
      "e": 79928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89118,
      "e": 79984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89230,
      "e": 80096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89232,
      "e": 80098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89318,
      "e": 80184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89326,
      "e": 80192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 89327,
      "e": 80193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89398,
      "e": 80264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 89526,
      "e": 80392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 89526,
      "e": 80392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89671,
      "e": 80537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 89671,
      "e": 80537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89726,
      "e": 80592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 89734,
      "e": 80600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 89734,
      "e": 80600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89766,
      "e": 80632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 89847,
      "e": 80713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89959,
      "e": 80825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 89960,
      "e": 80826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89999,
      "e": 80865,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90086,
      "e": 80952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90086,
      "e": 80952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90094,
      "e": 80960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 90182,
      "e": 81048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90214,
      "e": 81080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90215,
      "e": 81081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90311,
      "e": 81177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90318,
      "e": 81184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90319,
      "e": 81185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90407,
      "e": 81273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90423,
      "e": 81289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 90423,
      "e": 81289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90495,
      "e": 81361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 90511,
      "e": 81377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90511,
      "e": 81377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90599,
      "e": 81465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 90639,
      "e": 81505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90640,
      "e": 81506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90718,
      "e": 81584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90974,
      "e": 81840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 90975,
      "e": 81841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91054,
      "e": 81920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 91070,
      "e": 81936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91070,
      "e": 81936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91151,
      "e": 82017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 91182,
      "e": 82048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 91183,
      "e": 82049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91262,
      "e": 82128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 91278,
      "e": 82144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 91278,
      "e": 82144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91342,
      "e": 82208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 91374,
      "e": 82240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 91375,
      "e": 82241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91446,
      "e": 82312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 91518,
      "e": 82384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 91518,
      "e": 82384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91599,
      "e": 82465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 91686,
      "e": 82552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91687,
      "e": 82553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91758,
      "e": 82624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91854,
      "e": 82720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91854,
      "e": 82720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91942,
      "e": 82808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 91943,
      "e": 82809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91958,
      "e": 82824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 92047,
      "e": 82913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92054,
      "e": 82920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 92054,
      "e": 82920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92110,
      "e": 82976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 92134,
      "e": 83000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 92135,
      "e": 83001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92190,
      "e": 83056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 92238,
      "e": 83104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 92238,
      "e": 83104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92311,
      "e": 83177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 92415,
      "e": 83281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 92415,
      "e": 83281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92486,
      "e": 83352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 92486,
      "e": 83352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92494,
      "e": 83360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 92583,
      "e": 83449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92670,
      "e": 83536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 92671,
      "e": 83537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92741,
      "e": 83607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 92742,
      "e": 83608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92750,
      "e": 83616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 92863,
      "e": 83729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92886,
      "e": 83752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 92887,
      "e": 83753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92934,
      "e": 83800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 92991,
      "e": 83857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92991,
      "e": 83857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93038,
      "e": 83904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93078,
      "e": 83944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93078,
      "e": 83944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93166,
      "e": 84032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 93166,
      "e": 84032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 93167,
      "e": 84033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93222,
      "e": 84088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 93262,
      "e": 84128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 93263,
      "e": 84129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93350,
      "e": 84216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 93359,
      "e": 84225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93359,
      "e": 84225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93421,
      "e": 84287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93461,
      "e": 84327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 93462,
      "e": 84328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93535,
      "e": 84401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93535,
      "e": 84401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93574,
      "e": 84440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 93639,
      "e": 84505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93710,
      "e": 84576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93711,
      "e": 84577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93774,
      "e": 84640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 93774,
      "e": 84640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93814,
      "e": 84680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 93854,
      "e": 84720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93950,
      "e": 84816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93951,
      "e": 84817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94022,
      "e": 84888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 94807,
      "e": 85673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94807,
      "e": 85673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94878,
      "e": 85744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94982,
      "e": 85848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94983,
      "e": 85849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95071,
      "e": 85937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 95071,
      "e": 85937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95078,
      "e": 85944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 95158,
      "e": 86024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95158,
      "e": 86024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 95158,
      "e": 86024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95270,
      "e": 86136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 95278,
      "e": 86144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95278,
      "e": 86144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95358,
      "e": 86224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 95447,
      "e": 86313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 95447,
      "e": 86313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95470,
      "e": 86336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 95601,
      "e": 86336,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right, indicating the start time."
    },
    {
      "t": 97670,
      "e": 88405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97670,
      "e": 88405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97710,
      "e": 88445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 100898,
      "e": 91633,
      "ty": 2,
      "x": 140,
      "y": 596
    },
    {
      "t": 100998,
      "e": 91733,
      "ty": 2,
      "x": 98,
      "y": 601
    },
    {
      "t": 100998,
      "e": 91733,
      "ty": 41,
      "x": 101,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101002,
      "e": 91737,
      "ty": 7,
      "x": 76,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101098,
      "e": 91833,
      "ty": 2,
      "x": 22,
      "y": 600
    },
    {
      "t": 101187,
      "e": 91922,
      "ty": 6,
      "x": 113,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101198,
      "e": 91933,
      "ty": 2,
      "x": 113,
      "y": 590
    },
    {
      "t": 101248,
      "e": 91983,
      "ty": 41,
      "x": 4261,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101298,
      "e": 92033,
      "ty": 2,
      "x": 153,
      "y": 577
    },
    {
      "t": 101398,
      "e": 92133,
      "ty": 2,
      "x": 195,
      "y": 582
    },
    {
      "t": 101454,
      "e": 92189,
      "ty": 7,
      "x": 247,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101498,
      "e": 92233,
      "ty": 2,
      "x": 262,
      "y": 615
    },
    {
      "t": 101499,
      "e": 92234,
      "ty": 41,
      "x": 18537,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 101598,
      "e": 92333,
      "ty": 2,
      "x": 295,
      "y": 637
    },
    {
      "t": 101698,
      "e": 92433,
      "ty": 2,
      "x": 297,
      "y": 620
    },
    {
      "t": 101749,
      "e": 92484,
      "ty": 41,
      "x": 22134,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 101754,
      "e": 92489,
      "ty": 6,
      "x": 294,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101798,
      "e": 92533,
      "ty": 2,
      "x": 293,
      "y": 600
    },
    {
      "t": 101898,
      "e": 92633,
      "ty": 2,
      "x": 293,
      "y": 594
    },
    {
      "t": 101999,
      "e": 92734,
      "ty": 2,
      "x": 281,
      "y": 594
    },
    {
      "t": 101999,
      "e": 92734,
      "ty": 41,
      "x": 20672,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102098,
      "e": 92833,
      "ty": 2,
      "x": 270,
      "y": 596
    },
    {
      "t": 102198,
      "e": 92933,
      "ty": 2,
      "x": 264,
      "y": 595
    },
    {
      "t": 102249,
      "e": 92984,
      "ty": 41,
      "x": 18761,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102564,
      "e": 93299,
      "ty": 3,
      "x": 264,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102682,
      "e": 93417,
      "ty": 4,
      "x": 18761,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102682,
      "e": 93417,
      "ty": 5,
      "x": 264,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102872,
      "e": 93607,
      "ty": 7,
      "x": 297,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102898,
      "e": 93633,
      "ty": 2,
      "x": 308,
      "y": 609
    },
    {
      "t": 102998,
      "e": 93733,
      "ty": 2,
      "x": 367,
      "y": 610
    },
    {
      "t": 102999,
      "e": 93734,
      "ty": 41,
      "x": 30340,
      "y": 64563,
      "ta": "#.strategy"
    },
    {
      "t": 103622,
      "e": 94357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 103711,
      "e": 94446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103950,
      "e": 94685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103951,
      "e": 94686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104014,
      "e": 94687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right , indicating the start time. "
    },
    {
      "t": 104198,
      "e": 94871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 104198,
      "e": 94871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104238,
      "e": 94911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right f, indicating the start time. "
    },
    {
      "t": 104591,
      "e": 95264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 104592,
      "e": 95265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104678,
      "e": 95265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right fr, indicating the start time. "
    },
    {
      "t": 104814,
      "e": 95401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 104814,
      "e": 95401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104910,
      "e": 95497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 104912,
      "e": 95499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104942,
      "e": 95529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from, indicating the start time. "
    },
    {
      "t": 105014,
      "e": 95601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105375,
      "e": 95962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105375,
      "e": 95962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105438,
      "e": 95963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from , indicating the start time. "
    },
    {
      "t": 105461,
      "e": 95986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 105462,
      "e": 95987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105549,
      "e": 96074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from t, indicating the start time. "
    },
    {
      "t": 105582,
      "e": 96107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 105582,
      "e": 96107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105662,
      "e": 96107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from th, indicating the start time. "
    },
    {
      "t": 105678,
      "e": 96123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 105678,
      "e": 96123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105749,
      "e": 96194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the, indicating the start time. "
    },
    {
      "t": 105799,
      "e": 96244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105799,
      "e": 96244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105870,
      "e": 96245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the , indicating the start time. "
    },
    {
      "t": 105998,
      "e": 96373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 105998,
      "e": 96373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106061,
      "e": 96436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 106062,
      "e": 96437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106086,
      "e": 96461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12, indicating the start time. "
    },
    {
      "t": 106182,
      "e": 96557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 106191,
      "e": 96566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 106191,
      "e": 96566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106311,
      "e": 96567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 , indicating the start time. "
    },
    {
      "t": 106366,
      "e": 96622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 106366,
      "e": 96622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106478,
      "e": 96734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 p, indicating the start time. "
    },
    {
      "t": 106486,
      "e": 96742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 106486,
      "e": 96742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106599,
      "e": 96742,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm, indicating the start time. "
    },
    {
      "t": 106638,
      "e": 96781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm, indicating the start time. "
    },
    {
      "t": 106830,
      "e": 96973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 106830,
      "e": 96973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106902,
      "e": 96974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm , indicating the start time. "
    },
    {
      "t": 106950,
      "e": 97022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 106950,
      "e": 97022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107038,
      "e": 97110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm t, indicating the start time. "
    },
    {
      "t": 107038,
      "e": 97110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 107038,
      "e": 97110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107102,
      "e": 97110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm ti, indicating the start time. "
    },
    {
      "t": 107199,
      "e": 97207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 107200,
      "e": 97208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107230,
      "e": 97238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 107230,
      "e": 97238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107270,
      "e": 97278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick, indicating the start time. "
    },
    {
      "t": 107358,
      "e": 97366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 107382,
      "e": 97390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 107382,
      "e": 97390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107455,
      "e": 97391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick , indicating the start time. "
    },
    {
      "t": 107487,
      "e": 97423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 107487,
      "e": 97423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107574,
      "e": 97510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick m, indicating the start time. "
    },
    {
      "t": 107597,
      "e": 97533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 107598,
      "e": 97534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107646,
      "e": 97582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 107646,
      "e": 97582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107679,
      "e": 97583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mar, indicating the start time. "
    },
    {
      "t": 107758,
      "e": 97662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 107838,
      "e": 97742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 107839,
      "e": 97743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107894,
      "e": 97798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mar,, indicating the start time. "
    },
    {
      "t": 108002,
      "e": 97799,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mar,, indicating the start time. "
    },
    {
      "t": 108286,
      "e": 98083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 108326,
      "e": 98123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mar, indicating the start time. "
    },
    {
      "t": 108734,
      "e": 98531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 108735,
      "e": 98532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108822,
      "e": 98532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark, indicating the start time. "
    },
    {
      "t": 108902,
      "e": 98612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 108902,
      "e": 98612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109006,
      "e": 98716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 109006,
      "e": 98716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109014,
      "e": 98724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark o, indicating the start time. "
    },
    {
      "t": 109103,
      "e": 98813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 109103,
      "e": 98813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109150,
      "e": 98813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on, indicating the start time. "
    },
    {
      "t": 109230,
      "e": 98893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109230,
      "e": 98893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109262,
      "e": 98925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on , indicating the start time. "
    },
    {
      "t": 109310,
      "e": 98973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 109311,
      "e": 98974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109318,
      "e": 98974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on t, indicating the start time. "
    },
    {
      "t": 109390,
      "e": 99046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 109390,
      "e": 99046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109398,
      "e": 99054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on th, indicating the start time. "
    },
    {
      "t": 109477,
      "e": 99133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 109486,
      "e": 99142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 109487,
      "e": 99143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109550,
      "e": 99206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109551,
      "e": 99207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109559,
      "e": 99208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the , indicating the start time. "
    },
    {
      "t": 109637,
      "e": 99286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 109669,
      "e": 99318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 109669,
      "e": 99318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109734,
      "e": 99383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the g, indicating the start time. "
    },
    {
      "t": 109831,
      "e": 99480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 109831,
      "e": 99480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109910,
      "e": 99559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 109910,
      "e": 99559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109966,
      "e": 99559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the gra, indicating the start time. "
    },
    {
      "t": 109989,
      "e": 99582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 109990,
      "e": 99583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110022,
      "e": 99615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the grap, indicating the start time. "
    },
    {
      "t": 110070,
      "e": 99663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 110071,
      "e": 99664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110142,
      "e": 99664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. "
    },
    {
      "t": 110174,
      "e": 99696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 110998,
      "e": 100520,
      "ty": 2,
      "x": 368,
      "y": 610
    },
    {
      "t": 110999,
      "e": 100521,
      "ty": 41,
      "x": 30452,
      "y": 64563,
      "ta": "#.strategy"
    },
    {
      "t": 111012,
      "e": 100534,
      "ty": 6,
      "x": 402,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111028,
      "e": 100550,
      "ty": 7,
      "x": 452,
      "y": 452,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111099,
      "e": 100621,
      "ty": 2,
      "x": 473,
      "y": 239
    },
    {
      "t": 111198,
      "e": 100720,
      "ty": 2,
      "x": 473,
      "y": 238
    },
    {
      "t": 111249,
      "e": 100771,
      "ty": 41,
      "x": 42255,
      "y": 12741,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 111379,
      "e": 100901,
      "ty": 6,
      "x": 540,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111395,
      "e": 100917,
      "ty": 7,
      "x": 609,
      "y": 749,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111399,
      "e": 100921,
      "ty": 2,
      "x": 609,
      "y": 749
    },
    {
      "t": 111498,
      "e": 101020,
      "ty": 2,
      "x": 906,
      "y": 929
    },
    {
      "t": 111499,
      "e": 101021,
      "ty": 41,
      "x": 8457,
      "y": 56653,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 111598,
      "e": 101120,
      "ty": 2,
      "x": 906,
      "y": 905
    },
    {
      "t": 111698,
      "e": 101220,
      "ty": 2,
      "x": 589,
      "y": 390
    },
    {
      "t": 111750,
      "e": 101272,
      "ty": 41,
      "x": 52597,
      "y": 19444,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 111799,
      "e": 101321,
      "ty": 2,
      "x": 565,
      "y": 357
    },
    {
      "t": 111898,
      "e": 101420,
      "ty": 2,
      "x": 612,
      "y": 411
    },
    {
      "t": 111997,
      "e": 101519,
      "ty": 6,
      "x": 658,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111999,
      "e": 101521,
      "ty": 2,
      "x": 658,
      "y": 523
    },
    {
      "t": 111999,
      "e": 101521,
      "ty": 41,
      "x": 63051,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112098,
      "e": 101620,
      "ty": 2,
      "x": 663,
      "y": 539
    },
    {
      "t": 112199,
      "e": 101721,
      "ty": 2,
      "x": 670,
      "y": 553
    },
    {
      "t": 112249,
      "e": 101771,
      "ty": 41,
      "x": 64400,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112299,
      "e": 101821,
      "ty": 2,
      "x": 670,
      "y": 564
    },
    {
      "t": 112398,
      "e": 101920,
      "ty": 2,
      "x": 670,
      "y": 565
    },
    {
      "t": 112498,
      "e": 102020,
      "ty": 2,
      "x": 670,
      "y": 574
    },
    {
      "t": 112499,
      "e": 102021,
      "ty": 41,
      "x": 64400,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112636,
      "e": 102158,
      "ty": 3,
      "x": 670,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112762,
      "e": 102284,
      "ty": 4,
      "x": 64400,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113043,
      "e": 102565,
      "ty": 3,
      "x": 670,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113155,
      "e": 102677,
      "ty": 4,
      "x": 64400,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116399,
      "e": 105921,
      "ty": 2,
      "x": 669,
      "y": 575
    },
    {
      "t": 116465,
      "e": 105987,
      "ty": 7,
      "x": 466,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116498,
      "e": 106020,
      "ty": 2,
      "x": 466,
      "y": 521
    },
    {
      "t": 116499,
      "e": 106021,
      "ty": 41,
      "x": 41468,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 116599,
      "e": 106121,
      "ty": 2,
      "x": 427,
      "y": 520
    },
    {
      "t": 116650,
      "e": 106172,
      "ty": 6,
      "x": 398,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116698,
      "e": 106220,
      "ty": 2,
      "x": 365,
      "y": 539
    },
    {
      "t": 116748,
      "e": 106270,
      "ty": 41,
      "x": 29328,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116798,
      "e": 106320,
      "ty": 2,
      "x": 344,
      "y": 555
    },
    {
      "t": 116898,
      "e": 106420,
      "ty": 2,
      "x": 335,
      "y": 569
    },
    {
      "t": 116998,
      "e": 106520,
      "ty": 2,
      "x": 326,
      "y": 590
    },
    {
      "t": 116998,
      "e": 106520,
      "ty": 41,
      "x": 25731,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117179,
      "e": 106701,
      "ty": 3,
      "x": 326,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117298,
      "e": 106820,
      "ty": 4,
      "x": 25731,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117298,
      "e": 106820,
      "ty": 5,
      "x": 326,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118052,
      "e": 107574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 118204,
      "e": 107726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 118205,
      "e": 107727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118235,
      "e": 107757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 118300,
      "e": 107822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118307,
      "e": 107829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 118307,
      "e": 107829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118427,
      "e": 107949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 118428,
      "e": 107950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118468,
      "e": 107990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 118524,
      "e": 108046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118524,
      "e": 108046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118547,
      "e": 108069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 118604,
      "e": 108126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 118604,
      "e": 108126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118611,
      "e": 108133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 118699,
      "e": 108221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 118700,
      "e": 108222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118724,
      "e": 108246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 118812,
      "e": 108334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 118812,
      "e": 108334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118827,
      "e": 108349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 118908,
      "e": 108430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118972,
      "e": 108494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118973,
      "e": 108495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119051,
      "e": 108573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119108,
      "e": 108630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 119108,
      "e": 108630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119204,
      "e": 108726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 119211,
      "e": 108733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 119211,
      "e": 108733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119268,
      "e": 108790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 119380,
      "e": 108902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 119381,
      "e": 108903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119436,
      "e": 108904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 119507,
      "e": 108975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 119507,
      "e": 108975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119563,
      "e": 109031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 119675,
      "e": 109143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 119676,
      "e": 109144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119724,
      "e": 109192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 119771,
      "e": 109239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 119771,
      "e": 109239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119828,
      "e": 109296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 119852,
      "e": 109320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 119852,
      "e": 109320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119916,
      "e": 109384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119948,
      "e": 109416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 119948,
      "e": 109416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120020,
      "e": 109488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 120020,
      "e": 109488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120028,
      "e": 109496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 120091,
      "e": 109559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120115,
      "e": 109583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120116,
      "e": 109584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120204,
      "e": 109672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 120235,
      "e": 109703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120236,
      "e": 109704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120315,
      "e": 109783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 120660,
      "e": 110128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 120660,
      "e": 110128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120724,
      "e": 110192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 120724,
      "e": 110192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120755,
      "e": 110223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 120811,
      "e": 110279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120844,
      "e": 110312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 120844,
      "e": 110312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120924,
      "e": 110392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 121772,
      "e": 111240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 121773,
      "e": 111241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121819,
      "e": 111287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 122132,
      "e": 111600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 122187,
      "e": 111655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the dia"
    },
    {
      "t": 122283,
      "e": 111751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 122332,
      "e": 111752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the di"
    },
    {
      "t": 122436,
      "e": 111856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 122483,
      "e": 111903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the d"
    },
    {
      "t": 122599,
      "e": 111904,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the d"
    },
    {
      "t": 122788,
      "e": 112093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 122835,
      "e": 112140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the "
    },
    {
      "t": 122948,
      "e": 112253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 122949,
      "e": 112254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123003,
      "e": 112308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 123051,
      "e": 112356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 123052,
      "e": 112357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123116,
      "e": 112421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 123140,
      "e": 112445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 123141,
      "e": 112446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123219,
      "e": 112524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 123252,
      "e": 112557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 123252,
      "e": 112557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123324,
      "e": 112629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 123348,
      "e": 112653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 123348,
      "e": 112653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123444,
      "e": 112749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 123908,
      "e": 113213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 123909,
      "e": 113214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123955,
      "e": 113260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 124091,
      "e": 113396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 124092,
      "e": 113397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124189,
      "e": 113399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 124204,
      "e": 113414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 124204,
      "e": 113414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124307,
      "e": 113517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 124315,
      "e": 113525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 124315,
      "e": 113525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124387,
      "e": 113597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 124412,
      "e": 113622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 124412,
      "e": 113622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124475,
      "e": 113685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 124579,
      "e": 113789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 124580,
      "e": 113790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124659,
      "e": 113869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 124683,
      "e": 113893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 124683,
      "e": 113893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124779,
      "e": 113989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 124780,
      "e": 113990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124811,
      "e": 114021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 124900,
      "e": 114110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 124900,
      "e": 114110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 124901,
      "e": 114111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125004,
      "e": 114214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 125036,
      "e": 114246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125036,
      "e": 114246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125108,
      "e": 114318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 125876,
      "e": 115086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 125876,
      "e": 115086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125979,
      "e": 115189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 126003,
      "e": 115213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 126004,
      "e": 115214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126092,
      "e": 115302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 126092,
      "e": 115302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126099,
      "e": 115309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ai"
    },
    {
      "t": 126156,
      "e": 115366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 126252,
      "e": 115462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 126252,
      "e": 115462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126339,
      "e": 115549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 126379,
      "e": 115589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 126379,
      "e": 115589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126460,
      "e": 115670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 126732,
      "e": 115942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 126779,
      "e": 115989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting daig"
    },
    {
      "t": 126867,
      "e": 116077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 126915,
      "e": 116077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting dai"
    },
    {
      "t": 127027,
      "e": 116189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 127067,
      "e": 116229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting da"
    },
    {
      "t": 127172,
      "e": 116334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 127203,
      "e": 116334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting d"
    },
    {
      "t": 127396,
      "e": 116527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 127396,
      "e": 116527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127476,
      "e": 116607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 127803,
      "e": 116934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 127805,
      "e": 116936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127915,
      "e": 117046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 128084,
      "e": 117215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 128085,
      "e": 117216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128148,
      "e": 117279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 128148,
      "e": 117279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128155,
      "e": 117286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 128276,
      "e": 117407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 128276,
      "e": 117407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128299,
      "e": 117430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 128364,
      "e": 117495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128397,
      "e": 117528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 128398,
      "e": 117529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128484,
      "e": 117615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 128484,
      "e": 117615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128491,
      "e": 117622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 128572,
      "e": 117703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128595,
      "e": 117726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 128595,
      "e": 117726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128699,
      "e": 117830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 128731,
      "e": 117862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 128732,
      "e": 117863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128851,
      "e": 117982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 128851,
      "e": 117982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128875,
      "e": 118006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 128963,
      "e": 118094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 128963,
      "e": 118094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128979,
      "e": 118110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 129044,
      "e": 118175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 129044,
      "e": 118175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129050,
      "e": 118181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 129123,
      "e": 118254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 129219,
      "e": 118350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 129219,
      "e": 118350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129291,
      "e": 118422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 129398,
      "e": 118422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting diagonal line "
    },
    {
      "t": 129403,
      "e": 118427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 129404,
      "e": 118428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129483,
      "e": 118507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 129523,
      "e": 118547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 129523,
      "e": 118547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129587,
      "e": 118611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 129651,
      "e": 118675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 129651,
      "e": 118675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129732,
      "e": 118756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 129748,
      "e": 118772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 129748,
      "e": 118772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129771,
      "e": 118795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 129771,
      "e": 118795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129835,
      "e": 118859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 129859,
      "e": 118883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 129939,
      "e": 118963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 129939,
      "e": 118963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130019,
      "e": 119043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 130028,
      "e": 119052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 130029,
      "e": 119053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130123,
      "e": 119147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 130180,
      "e": 119204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130180,
      "e": 119204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130252,
      "e": 119276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130380,
      "e": 119404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 130381,
      "e": 119405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130459,
      "e": 119483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 130459,
      "e": 119483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130491,
      "e": 119515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 130587,
      "e": 119611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 130588,
      "e": 119612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130603,
      "e": 119627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 130675,
      "e": 119699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 130693,
      "e": 119717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130693,
      "e": 119717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130763,
      "e": 119787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130819,
      "e": 119843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 130819,
      "e": 119843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130907,
      "e": 119931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 130915,
      "e": 119939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 130916,
      "e": 119940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130996,
      "e": 120020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 131035,
      "e": 120059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 131036,
      "e": 120060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131107,
      "e": 120131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 131107,
      "e": 120131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131115,
      "e": 120139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 131211,
      "e": 120235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 131211,
      "e": 120235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131235,
      "e": 120259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 131300,
      "e": 120324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131683,
      "e": 120707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 131684,
      "e": 120708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131739,
      "e": 120763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 131803,
      "e": 120827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 131803,
      "e": 120827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131916,
      "e": 120940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 132036,
      "e": 121060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 132037,
      "e": 121061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132139,
      "e": 121163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132579,
      "e": 121603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 132581,
      "e": 121605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132651,
      "e": 121675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 132683,
      "e": 121707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 132683,
      "e": 121707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132795,
      "e": 121819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 132804,
      "e": 121828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 132804,
      "e": 121828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132908,
      "e": 121932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132947,
      "e": 121971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 132948,
      "e": 121972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133012,
      "e": 122036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 133012,
      "e": 122036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133043,
      "e": 122036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 133107,
      "e": 122100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 133196,
      "e": 122189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 133196,
      "e": 122189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133268,
      "e": 122261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 133284,
      "e": 122277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 133284,
      "e": 122277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133347,
      "e": 122340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 133387,
      "e": 122380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 133387,
      "e": 122380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133467,
      "e": 122460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 133467,
      "e": 122460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133475,
      "e": 122468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 133540,
      "e": 122533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 133611,
      "e": 122604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 133611,
      "e": 122604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133715,
      "e": 122708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 134068,
      "e": 123061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 134107,
      "e": 123100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting diagonal line all the way through to see th"
    },
    {
      "t": 134203,
      "e": 123196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 134204,
      "e": 123197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134284,
      "e": 123277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 134284,
      "e": 123277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134315,
      "e": 123308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 134403,
      "e": 123396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134451,
      "e": 123444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 134452,
      "e": 123445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134539,
      "e": 123532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 135092,
      "e": 124085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 135093,
      "e": 124086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135171,
      "e": 124164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 135179,
      "e": 124172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 135181,
      "e": 124174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135268,
      "e": 124261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 135268,
      "e": 124261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135291,
      "e": 124284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 135323,
      "e": 124316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 135323,
      "e": 124316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135371,
      "e": 124364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 135395,
      "e": 124388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 135492,
      "e": 124485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 135492,
      "e": 124485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135579,
      "e": 124572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 135724,
      "e": 124717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 135724,
      "e": 124717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135811,
      "e": 124804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 135899,
      "e": 124892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 135900,
      "e": 124893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135963,
      "e": 124956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136028,
      "e": 125021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 136123,
      "e": 125116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 136124,
      "e": 125117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136172,
      "e": 125165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 136220,
      "e": 125213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 136372,
      "e": 125365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 136372,
      "e": 125365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136435,
      "e": 125428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136467,
      "e": 125460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 136468,
      "e": 125461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136547,
      "e": 125540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 136595,
      "e": 125588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 136596,
      "e": 125589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136675,
      "e": 125668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 136755,
      "e": 125748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 136756,
      "e": 125749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136843,
      "e": 125836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 137132,
      "e": 126125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 137133,
      "e": 126126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137187,
      "e": 126180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 138012,
      "e": 126181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 138099,
      "e": 126268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 138099,
      "e": 126268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138131,
      "e": 126300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 138195,
      "e": 126364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138339,
      "e": 126508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 138340,
      "e": 126509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138411,
      "e": 126580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 138556,
      "e": 126725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 138556,
      "e": 126725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138635,
      "e": 126804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 138636,
      "e": 126805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138675,
      "e": 126844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 138739,
      "e": 126908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138835,
      "e": 127004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 138835,
      "e": 127004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138875,
      "e": 127044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 138875,
      "e": 127044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138915,
      "e": 127084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 138954,
      "e": 127123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 139052,
      "e": 127221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 139052,
      "e": 127221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139115,
      "e": 127284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 139396,
      "e": 127565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 139396,
      "e": 127565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139452,
      "e": 127621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 140779,
      "e": 128948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 140780,
      "e": 128949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140843,
      "e": 129012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 140843,
      "e": 129012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140858,
      "e": 129027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 140964,
      "e": 129133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 141307,
      "e": 129476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 141308,
      "e": 129477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141387,
      "e": 129556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 141539,
      "e": 129708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 141540,
      "e": 129709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141603,
      "e": 129772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 141603,
      "e": 129772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141635,
      "e": 129804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 141723,
      "e": 129892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 141739,
      "e": 129908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 141740,
      "e": 129909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141819,
      "e": 129988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 141819,
      "e": 129988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141859,
      "e": 130028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 141995,
      "e": 130164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 142059,
      "e": 130228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 142060,
      "e": 130229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 142091,
      "e": 130260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 142197,
      "e": 130366,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting diagonal line all the way through to see that shifts M and L start at 12 pm"
    },
    {
      "t": 142716,
      "e": 130885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 142716,
      "e": 130885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 142763,
      "e": 130932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 143196,
      "e": 131365,
      "ty": 2,
      "x": 341,
      "y": 574
    },
    {
      "t": 143219,
      "e": 131388,
      "ty": 7,
      "x": 358,
      "y": 440,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143246,
      "e": 131415,
      "ty": 41,
      "x": 30677,
      "y": 18447,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 143295,
      "e": 131464,
      "ty": 2,
      "x": 458,
      "y": 170
    },
    {
      "t": 143496,
      "e": 131665,
      "ty": 2,
      "x": 424,
      "y": 229
    },
    {
      "t": 143497,
      "e": 131666,
      "ty": 41,
      "x": 36747,
      "y": 12242,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 143520,
      "e": 131689,
      "ty": 6,
      "x": 277,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143536,
      "e": 131705,
      "ty": 7,
      "x": 254,
      "y": 618,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143596,
      "e": 131765,
      "ty": 2,
      "x": 244,
      "y": 695
    },
    {
      "t": 143696,
      "e": 131865,
      "ty": 2,
      "x": 243,
      "y": 697
    },
    {
      "t": 143746,
      "e": 131915,
      "ty": 41,
      "x": 16401,
      "y": 38224,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 143796,
      "e": 131965,
      "ty": 2,
      "x": 284,
      "y": 695
    },
    {
      "t": 143896,
      "e": 132065,
      "ty": 2,
      "x": 303,
      "y": 695
    },
    {
      "t": 143996,
      "e": 132165,
      "ty": 41,
      "x": 23145,
      "y": 38057,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 144072,
      "e": 132166,
      "ty": 6,
      "x": 339,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 144096,
      "e": 132190,
      "ty": 2,
      "x": 340,
      "y": 676
    },
    {
      "t": 144195,
      "e": 132289,
      "ty": 2,
      "x": 343,
      "y": 674
    },
    {
      "t": 144246,
      "e": 132340,
      "ty": 41,
      "x": 2952,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 144296,
      "e": 132390,
      "ty": 2,
      "x": 344,
      "y": 673
    },
    {
      "t": 144393,
      "e": 132487,
      "ty": 3,
      "x": 344,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 144393,
      "e": 132487,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting diagonal line all the way through to see that shifts M and L start at 12 pm."
    },
    {
      "t": 144396,
      "e": 132490,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144396,
      "e": 132490,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 144495,
      "e": 132589,
      "ty": 4,
      "x": 2952,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 144508,
      "e": 132602,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 144509,
      "e": 132603,
      "ty": 5,
      "x": 344,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 144516,
      "e": 132610,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 144746,
      "e": 132840,
      "ty": 41,
      "x": 11605,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 144796,
      "e": 132890,
      "ty": 2,
      "x": 690,
      "y": 761
    },
    {
      "t": 144896,
      "e": 132990,
      "ty": 2,
      "x": 1531,
      "y": 1083
    },
    {
      "t": 144996,
      "e": 133090,
      "ty": 2,
      "x": 1529,
      "y": 1087
    },
    {
      "t": 144996,
      "e": 133090,
      "ty": 41,
      "x": 52379,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 145096,
      "e": 133190,
      "ty": 2,
      "x": 1518,
      "y": 1091
    },
    {
      "t": 145246,
      "e": 133340,
      "ty": 41,
      "x": 51932,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 145295,
      "e": 133389,
      "ty": 2,
      "x": 1515,
      "y": 1092
    },
    {
      "t": 145496,
      "e": 133590,
      "ty": 41,
      "x": 51897,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 145517,
      "e": 133611,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 146296,
      "e": 134390,
      "ty": 2,
      "x": 1468,
      "y": 1023
    },
    {
      "t": 146396,
      "e": 134490,
      "ty": 2,
      "x": 1358,
      "y": 841
    },
    {
      "t": 146496,
      "e": 134590,
      "ty": 2,
      "x": 1289,
      "y": 696
    },
    {
      "t": 146497,
      "e": 134591,
      "ty": 41,
      "x": 44114,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 146595,
      "e": 134689,
      "ty": 2,
      "x": 1086,
      "y": 529
    },
    {
      "t": 146696,
      "e": 134790,
      "ty": 2,
      "x": 1047,
      "y": 501
    },
    {
      "t": 146746,
      "e": 134840,
      "ty": 41,
      "x": 48232,
      "y": 11979,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 146796,
      "e": 134890,
      "ty": 2,
      "x": 1014,
      "y": 523
    },
    {
      "t": 146895,
      "e": 134989,
      "ty": 2,
      "x": 1013,
      "y": 550
    },
    {
      "t": 146907,
      "e": 135001,
      "ty": 6,
      "x": 1013,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146995,
      "e": 135089,
      "ty": 2,
      "x": 1013,
      "y": 570
    },
    {
      "t": 146996,
      "e": 135090,
      "ty": 41,
      "x": 44338,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147023,
      "e": 135117,
      "ty": 7,
      "x": 1013,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147096,
      "e": 135190,
      "ty": 2,
      "x": 1013,
      "y": 578
    },
    {
      "t": 147195,
      "e": 135289,
      "ty": 2,
      "x": 1013,
      "y": 576
    },
    {
      "t": 147223,
      "e": 135317,
      "ty": 6,
      "x": 1014,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147246,
      "e": 135340,
      "ty": 41,
      "x": 44555,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147296,
      "e": 135390,
      "ty": 2,
      "x": 1015,
      "y": 572
    },
    {
      "t": 147432,
      "e": 135526,
      "ty": 3,
      "x": 1015,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147433,
      "e": 135527,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147496,
      "e": 135590,
      "ty": 41,
      "x": 44771,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147534,
      "e": 135628,
      "ty": 4,
      "x": 44771,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147535,
      "e": 135629,
      "ty": 5,
      "x": 1015,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148316,
      "e": 136410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 148316,
      "e": 136410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148363,
      "e": 136457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 148475,
      "e": 136569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 148476,
      "e": 136570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148499,
      "e": 136593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 149246,
      "e": 137340,
      "ty": 41,
      "x": 44555,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149258,
      "e": 137352,
      "ty": 7,
      "x": 1012,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149296,
      "e": 137390,
      "ty": 2,
      "x": 1005,
      "y": 619
    },
    {
      "t": 149341,
      "e": 137435,
      "ty": 6,
      "x": 998,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149396,
      "e": 137490,
      "ty": 2,
      "x": 998,
      "y": 654
    },
    {
      "t": 149496,
      "e": 137590,
      "ty": 2,
      "x": 998,
      "y": 665
    },
    {
      "t": 149496,
      "e": 137590,
      "ty": 41,
      "x": 41094,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149697,
      "e": 137791,
      "ty": 2,
      "x": 999,
      "y": 665
    },
    {
      "t": 149747,
      "e": 137841,
      "ty": 41,
      "x": 42824,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149796,
      "e": 137890,
      "ty": 2,
      "x": 1009,
      "y": 657
    },
    {
      "t": 149863,
      "e": 137890,
      "ty": 3,
      "x": 1009,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149864,
      "e": 137891,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 149864,
      "e": 137891,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149864,
      "e": 137891,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149943,
      "e": 137970,
      "ty": 4,
      "x": 43473,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149944,
      "e": 137971,
      "ty": 5,
      "x": 1009,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149996,
      "e": 138023,
      "ty": 41,
      "x": 43473,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151324,
      "e": 139351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 151467,
      "e": 139494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 151467,
      "e": 139494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151539,
      "e": 139566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 151555,
      "e": 139582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 151555,
      "e": 139582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151619,
      "e": 139646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 151619,
      "e": 139646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151659,
      "e": 139686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 151708,
      "e": 139735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 151739,
      "e": 139766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 152478,
      "e": 140505,
      "ty": 7,
      "x": 1009,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152494,
      "e": 140521,
      "ty": 6,
      "x": 1005,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152496,
      "e": 140523,
      "ty": 2,
      "x": 1005,
      "y": 681
    },
    {
      "t": 152496,
      "e": 140523,
      "ty": 41,
      "x": 56217,
      "y": 9929,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152544,
      "e": 140571,
      "ty": 7,
      "x": 993,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152596,
      "e": 140623,
      "ty": 2,
      "x": 990,
      "y": 721
    },
    {
      "t": 152747,
      "e": 140774,
      "ty": 41,
      "x": 33817,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 152896,
      "e": 140923,
      "ty": 2,
      "x": 991,
      "y": 715
    },
    {
      "t": 152962,
      "e": 140989,
      "ty": 6,
      "x": 990,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152997,
      "e": 141024,
      "ty": 2,
      "x": 989,
      "y": 704
    },
    {
      "t": 152997,
      "e": 141024,
      "ty": 41,
      "x": 47971,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153097,
      "e": 141124,
      "ty": 2,
      "x": 987,
      "y": 702
    },
    {
      "t": 153192,
      "e": 141219,
      "ty": 3,
      "x": 985,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153193,
      "e": 141220,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 153193,
      "e": 141220,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153194,
      "e": 141221,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153197,
      "e": 141224,
      "ty": 2,
      "x": 985,
      "y": 701
    },
    {
      "t": 153247,
      "e": 141274,
      "ty": 41,
      "x": 45909,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153287,
      "e": 141314,
      "ty": 4,
      "x": 45909,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153289,
      "e": 141316,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153290,
      "e": 141317,
      "ty": 5,
      "x": 985,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153291,
      "e": 141318,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 154306,
      "e": 142333,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 155196,
      "e": 143223,
      "ty": 2,
      "x": 876,
      "y": 578
    },
    {
      "t": 155246,
      "e": 143273,
      "ty": 41,
      "x": 7217,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 155279,
      "e": 143306,
      "ty": 6,
      "x": 836,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 155295,
      "e": 143322,
      "ty": 7,
      "x": 834,
      "y": 406,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 155296,
      "e": 143323,
      "ty": 2,
      "x": 834,
      "y": 406
    },
    {
      "t": 155395,
      "e": 143422,
      "ty": 2,
      "x": 779,
      "y": 264
    },
    {
      "t": 155496,
      "e": 143523,
      "ty": 2,
      "x": 789,
      "y": 258
    },
    {
      "t": 155496,
      "e": 143523,
      "ty": 41,
      "x": 26895,
      "y": 13849,
      "ta": "html > body"
    },
    {
      "t": 155595,
      "e": 143622,
      "ty": 2,
      "x": 816,
      "y": 250
    },
    {
      "t": 155695,
      "e": 143722,
      "ty": 2,
      "x": 821,
      "y": 238
    },
    {
      "t": 155746,
      "e": 143773,
      "ty": 41,
      "x": 473,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 155796,
      "e": 143823,
      "ty": 2,
      "x": 822,
      "y": 235
    },
    {
      "t": 155934,
      "e": 143961,
      "ty": 6,
      "x": 827,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 155996,
      "e": 144023,
      "ty": 2,
      "x": 831,
      "y": 235
    },
    {
      "t": 155996,
      "e": 144023,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 156673,
      "e": 144700,
      "ty": 3,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 156675,
      "e": 144702,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 156767,
      "e": 144794,
      "ty": 4,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 156767,
      "e": 144794,
      "ty": 5,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 156767,
      "e": 144794,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 157114,
      "e": 145141,
      "ty": 7,
      "x": 831,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 157164,
      "e": 145191,
      "ty": 6,
      "x": 831,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157181,
      "e": 145208,
      "ty": 7,
      "x": 831,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157196,
      "e": 145223,
      "ty": 2,
      "x": 831,
      "y": 302
    },
    {
      "t": 157214,
      "e": 145241,
      "ty": 6,
      "x": 831,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 157247,
      "e": 145274,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 157297,
      "e": 145324,
      "ty": 2,
      "x": 832,
      "y": 327
    },
    {
      "t": 157299,
      "e": 145326,
      "ty": 7,
      "x": 832,
      "y": 333,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 157396,
      "e": 145423,
      "ty": 2,
      "x": 833,
      "y": 352
    },
    {
      "t": 157497,
      "e": 145524,
      "ty": 2,
      "x": 834,
      "y": 360
    },
    {
      "t": 157499,
      "e": 145526,
      "ty": 41,
      "x": 2985,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 157596,
      "e": 145623,
      "ty": 2,
      "x": 834,
      "y": 371
    },
    {
      "t": 157696,
      "e": 145723,
      "ty": 2,
      "x": 835,
      "y": 401
    },
    {
      "t": 157731,
      "e": 145758,
      "ty": 6,
      "x": 837,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 157747,
      "e": 145774,
      "ty": 41,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 157797,
      "e": 145824,
      "ty": 2,
      "x": 837,
      "y": 417
    },
    {
      "t": 157815,
      "e": 145842,
      "ty": 7,
      "x": 837,
      "y": 421,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 157896,
      "e": 145923,
      "ty": 2,
      "x": 837,
      "y": 424
    },
    {
      "t": 157996,
      "e": 146023,
      "ty": 2,
      "x": 836,
      "y": 428
    },
    {
      "t": 157997,
      "e": 146024,
      "ty": 41,
      "x": 3459,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 158096,
      "e": 146123,
      "ty": 2,
      "x": 830,
      "y": 433
    },
    {
      "t": 158247,
      "e": 146274,
      "ty": 41,
      "x": 6851,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 159634,
      "e": 147661,
      "ty": 6,
      "x": 830,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 159667,
      "e": 147694,
      "ty": 7,
      "x": 830,
      "y": 461,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 159696,
      "e": 147723,
      "ty": 2,
      "x": 830,
      "y": 484
    },
    {
      "t": 159700,
      "e": 147727,
      "ty": 6,
      "x": 830,
      "y": 503,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 159716,
      "e": 147743,
      "ty": 7,
      "x": 833,
      "y": 519,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 159734,
      "e": 147761,
      "ty": 6,
      "x": 837,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 159747,
      "e": 147774,
      "ty": 41,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 159766,
      "e": 147793,
      "ty": 7,
      "x": 841,
      "y": 534,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 159797,
      "e": 147824,
      "ty": 2,
      "x": 843,
      "y": 538
    },
    {
      "t": 159896,
      "e": 147923,
      "ty": 2,
      "x": 846,
      "y": 546
    },
    {
      "t": 159997,
      "e": 148024,
      "ty": 2,
      "x": 843,
      "y": 544
    },
    {
      "t": 159997,
      "e": 148024,
      "ty": 41,
      "x": 5121,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 160015,
      "e": 148042,
      "ty": 6,
      "x": 835,
      "y": 530,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 160096,
      "e": 148123,
      "ty": 2,
      "x": 835,
      "y": 525
    },
    {
      "t": 160197,
      "e": 148224,
      "ty": 2,
      "x": 830,
      "y": 525
    },
    {
      "t": 160246,
      "e": 148273,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 160251,
      "e": 148278,
      "ty": 7,
      "x": 827,
      "y": 535,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 160296,
      "e": 148323,
      "ty": 2,
      "x": 827,
      "y": 538
    },
    {
      "t": 160397,
      "e": 148424,
      "ty": 2,
      "x": 828,
      "y": 540
    },
    {
      "t": 160467,
      "e": 148494,
      "ty": 6,
      "x": 830,
      "y": 548,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 160497,
      "e": 148524,
      "ty": 2,
      "x": 831,
      "y": 551
    },
    {
      "t": 160497,
      "e": 148524,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 160592,
      "e": 148619,
      "ty": 7,
      "x": 835,
      "y": 563,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 160595,
      "e": 148622,
      "ty": 2,
      "x": 835,
      "y": 563
    },
    {
      "t": 160696,
      "e": 148723,
      "ty": 2,
      "x": 837,
      "y": 569
    },
    {
      "t": 160747,
      "e": 148774,
      "ty": 41,
      "x": 16457,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 160768,
      "e": 148795,
      "ty": 6,
      "x": 838,
      "y": 576,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 160796,
      "e": 148823,
      "ty": 2,
      "x": 838,
      "y": 577
    },
    {
      "t": 160897,
      "e": 148924,
      "ty": 2,
      "x": 836,
      "y": 582
    },
    {
      "t": 160996,
      "e": 149023,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 161097,
      "e": 149124,
      "ty": 2,
      "x": 827,
      "y": 581
    },
    {
      "t": 161196,
      "e": 149223,
      "ty": 2,
      "x": 826,
      "y": 580
    },
    {
      "t": 161246,
      "e": 149273,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 162913,
      "e": 149274,
      "ty": 3,
      "x": 826,
      "y": 580,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 162915,
      "e": 149276,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 162915,
      "e": 149276,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 163039,
      "e": 149400,
      "ty": 4,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 163039,
      "e": 149400,
      "ty": 5,
      "x": 827,
      "y": 580,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 163039,
      "e": 149400,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf",
      "v": "Other"
    },
    {
      "t": 163095,
      "e": 149456,
      "ty": 2,
      "x": 827,
      "y": 580
    },
    {
      "t": 163245,
      "e": 149606,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 163395,
      "e": 149756,
      "ty": 2,
      "x": 833,
      "y": 577
    },
    {
      "t": 163419,
      "e": 149780,
      "ty": 7,
      "x": 844,
      "y": 572,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 163495,
      "e": 149856,
      "ty": 2,
      "x": 897,
      "y": 585
    },
    {
      "t": 163496,
      "e": 149857,
      "ty": 41,
      "x": 17936,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 163596,
      "e": 149957,
      "ty": 2,
      "x": 1006,
      "y": 626
    },
    {
      "t": 163696,
      "e": 150057,
      "ty": 2,
      "x": 1014,
      "y": 641
    },
    {
      "t": 163746,
      "e": 150107,
      "ty": 41,
      "x": 44279,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 163796,
      "e": 150157,
      "ty": 2,
      "x": 1006,
      "y": 668
    },
    {
      "t": 163896,
      "e": 150257,
      "ty": 2,
      "x": 997,
      "y": 686
    },
    {
      "t": 163995,
      "e": 150356,
      "ty": 2,
      "x": 958,
      "y": 736
    },
    {
      "t": 163996,
      "e": 150357,
      "ty": 41,
      "x": 34279,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 164746,
      "e": 151107,
      "ty": 41,
      "x": 34028,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 164796,
      "e": 151157,
      "ty": 2,
      "x": 955,
      "y": 734
    },
    {
      "t": 164896,
      "e": 151257,
      "ty": 2,
      "x": 927,
      "y": 716
    },
    {
      "t": 164996,
      "e": 151357,
      "ty": 2,
      "x": 906,
      "y": 711
    },
    {
      "t": 164996,
      "e": 151357,
      "ty": 41,
      "x": 21312,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 165095,
      "e": 151456,
      "ty": 2,
      "x": 859,
      "y": 704
    },
    {
      "t": 165195,
      "e": 151556,
      "ty": 2,
      "x": 846,
      "y": 697
    },
    {
      "t": 165245,
      "e": 151606,
      "ty": 41,
      "x": 3645,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 165272,
      "e": 151633,
      "ty": 6,
      "x": 832,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165296,
      "e": 151657,
      "ty": 2,
      "x": 832,
      "y": 677
    },
    {
      "t": 165396,
      "e": 151757,
      "ty": 2,
      "x": 830,
      "y": 674
    },
    {
      "t": 165495,
      "e": 151856,
      "ty": 2,
      "x": 830,
      "y": 673
    },
    {
      "t": 165496,
      "e": 151857,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165632,
      "e": 151993,
      "ty": 3,
      "x": 830,
      "y": 673,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165633,
      "e": 151994,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 165634,
      "e": 151995,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165727,
      "e": 152088,
      "ty": 4,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165727,
      "e": 152088,
      "ty": 5,
      "x": 830,
      "y": 673,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 165728,
      "e": 152089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 166246,
      "e": 152607,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166296,
      "e": 152657,
      "ty": 2,
      "x": 829,
      "y": 674
    },
    {
      "t": 166496,
      "e": 152857,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166616,
      "e": 152977,
      "ty": 3,
      "x": 829,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166710,
      "e": 153071,
      "ty": 4,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166711,
      "e": 153072,
      "ty": 5,
      "x": 829,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166788,
      "e": 153149,
      "ty": 7,
      "x": 828,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 166795,
      "e": 153156,
      "ty": 2,
      "x": 828,
      "y": 683
    },
    {
      "t": 166805,
      "e": 153166,
      "ty": 6,
      "x": 828,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 166822,
      "e": 153183,
      "ty": 7,
      "x": 828,
      "y": 714,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 166895,
      "e": 153256,
      "ty": 2,
      "x": 828,
      "y": 723
    },
    {
      "t": 166929,
      "e": 153290,
      "ty": 6,
      "x": 828,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 166996,
      "e": 153357,
      "ty": 2,
      "x": 829,
      "y": 726
    },
    {
      "t": 166996,
      "e": 153357,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167160,
      "e": 153521,
      "ty": 3,
      "x": 829,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167162,
      "e": 153523,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 167162,
      "e": 153523,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167256,
      "e": 153617,
      "ty": 4,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167256,
      "e": 153617,
      "ty": 5,
      "x": 829,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167257,
      "e": 153617,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 167543,
      "e": 153903,
      "ty": 7,
      "x": 843,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 167596,
      "e": 153956,
      "ty": 2,
      "x": 986,
      "y": 778
    },
    {
      "t": 167696,
      "e": 154056,
      "ty": 2,
      "x": 1202,
      "y": 843
    },
    {
      "t": 167746,
      "e": 154106,
      "ty": 41,
      "x": 41118,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 167795,
      "e": 154155,
      "ty": 2,
      "x": 1202,
      "y": 845
    },
    {
      "t": 167896,
      "e": 154256,
      "ty": 2,
      "x": 1194,
      "y": 854
    },
    {
      "t": 167996,
      "e": 154356,
      "ty": 2,
      "x": 1193,
      "y": 855
    },
    {
      "t": 167996,
      "e": 154356,
      "ty": 41,
      "x": 40808,
      "y": 46921,
      "ta": "html > body"
    },
    {
      "t": 168095,
      "e": 154455,
      "ty": 2,
      "x": 1193,
      "y": 856
    },
    {
      "t": 168196,
      "e": 154556,
      "ty": 2,
      "x": 1165,
      "y": 870
    },
    {
      "t": 168246,
      "e": 154606,
      "ty": 41,
      "x": 39465,
      "y": 48417,
      "ta": "html > body"
    },
    {
      "t": 168295,
      "e": 154655,
      "ty": 2,
      "x": 1153,
      "y": 883
    },
    {
      "t": 168496,
      "e": 154856,
      "ty": 41,
      "x": 39431,
      "y": 48472,
      "ta": "html > body"
    },
    {
      "t": 168595,
      "e": 154955,
      "ty": 2,
      "x": 1150,
      "y": 884
    },
    {
      "t": 168746,
      "e": 155106,
      "ty": 41,
      "x": 39327,
      "y": 48528,
      "ta": "html > body"
    },
    {
      "t": 168896,
      "e": 155256,
      "ty": 2,
      "x": 1149,
      "y": 884
    },
    {
      "t": 168995,
      "e": 155355,
      "ty": 2,
      "x": 1128,
      "y": 879
    },
    {
      "t": 168995,
      "e": 155355,
      "ty": 41,
      "x": 38570,
      "y": 48251,
      "ta": "html > body"
    },
    {
      "t": 169096,
      "e": 155456,
      "ty": 2,
      "x": 1070,
      "y": 883
    },
    {
      "t": 169196,
      "e": 155556,
      "ty": 2,
      "x": 989,
      "y": 923
    },
    {
      "t": 169246,
      "e": 155606,
      "ty": 41,
      "x": 39295,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 169296,
      "e": 155656,
      "ty": 2,
      "x": 984,
      "y": 930
    },
    {
      "t": 169395,
      "e": 155755,
      "ty": 2,
      "x": 980,
      "y": 935
    },
    {
      "t": 169496,
      "e": 155856,
      "ty": 41,
      "x": 37634,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 169696,
      "e": 156056,
      "ty": 2,
      "x": 970,
      "y": 937
    },
    {
      "t": 169746,
      "e": 156106,
      "ty": 41,
      "x": 35261,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 169795,
      "e": 156155,
      "ty": 2,
      "x": 970,
      "y": 938
    },
    {
      "t": 174796,
      "e": 161155,
      "ty": 2,
      "x": 968,
      "y": 938
    },
    {
      "t": 174896,
      "e": 161255,
      "ty": 2,
      "x": 956,
      "y": 944
    },
    {
      "t": 174997,
      "e": 161356,
      "ty": 2,
      "x": 940,
      "y": 956
    },
    {
      "t": 174997,
      "e": 161356,
      "ty": 41,
      "x": 28141,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 175096,
      "e": 161455,
      "ty": 2,
      "x": 848,
      "y": 966
    },
    {
      "t": 175112,
      "e": 161471,
      "ty": 6,
      "x": 835,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175196,
      "e": 161555,
      "ty": 2,
      "x": 835,
      "y": 966
    },
    {
      "t": 175228,
      "e": 161587,
      "ty": 7,
      "x": 840,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175246,
      "e": 161605,
      "ty": 41,
      "x": 15028,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 175297,
      "e": 161656,
      "ty": 2,
      "x": 840,
      "y": 964
    },
    {
      "t": 175432,
      "e": 161791,
      "ty": 6,
      "x": 839,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175496,
      "e": 161855,
      "ty": 2,
      "x": 832,
      "y": 964
    },
    {
      "t": 175497,
      "e": 161856,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175632,
      "e": 161991,
      "ty": 3,
      "x": 832,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175633,
      "e": 161992,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 175634,
      "e": 161993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175734,
      "e": 162093,
      "ty": 4,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175735,
      "e": 162094,
      "ty": 5,
      "x": 832,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175735,
      "e": 162094,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 175880,
      "e": 162239,
      "ty": 7,
      "x": 842,
      "y": 975,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 175896,
      "e": 162255,
      "ty": 2,
      "x": 847,
      "y": 980
    },
    {
      "t": 175996,
      "e": 162355,
      "ty": 2,
      "x": 858,
      "y": 1000
    },
    {
      "t": 175997,
      "e": 162356,
      "ty": 41,
      "x": 36311,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 175998,
      "e": 162357,
      "ty": 6,
      "x": 861,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176096,
      "e": 162455,
      "ty": 2,
      "x": 869,
      "y": 1020
    },
    {
      "t": 176196,
      "e": 162555,
      "ty": 2,
      "x": 871,
      "y": 1028
    },
    {
      "t": 176246,
      "e": 162605,
      "ty": 41,
      "x": 21428,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176464,
      "e": 162823,
      "ty": 3,
      "x": 871,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176465,
      "e": 162824,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 176466,
      "e": 162825,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176550,
      "e": 162909,
      "ty": 4,
      "x": 21428,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176550,
      "e": 162909,
      "ty": 5,
      "x": 871,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176554,
      "e": 162913,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 176554,
      "e": 162913,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 176555,
      "e": 162914,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 176896,
      "e": 163255,
      "ty": 2,
      "x": 1054,
      "y": 933
    },
    {
      "t": 176997,
      "e": 163356,
      "ty": 2,
      "x": 1919,
      "y": 743
    },
    {
      "t": 177877,
      "e": 164236,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 179997,
      "e": 166356,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 204397,
      "e": 168356,
      "ty": 2,
      "x": 1910,
      "y": 749
    },
    {
      "t": 204497,
      "e": 168456,
      "ty": 2,
      "x": 1884,
      "y": 764
    },
    {
      "t": 204498,
      "e": 168457,
      "ty": 41,
      "x": 64605,
      "y": 41880,
      "ta": "> div.masterdiv"
    },
    {
      "t": 204597,
      "e": 168556,
      "ty": 2,
      "x": 1853,
      "y": 794
    },
    {
      "t": 204697,
      "e": 168656,
      "ty": 2,
      "x": 1822,
      "y": 812
    },
    {
      "t": 204747,
      "e": 168706,
      "ty": 41,
      "x": 61815,
      "y": 44871,
      "ta": "> div.masterdiv"
    },
    {
      "t": 204797,
      "e": 168756,
      "ty": 2,
      "x": 1743,
      "y": 829
    },
    {
      "t": 204897,
      "e": 168856,
      "ty": 2,
      "x": 1613,
      "y": 856
    },
    {
      "t": 204997,
      "e": 168956,
      "ty": 2,
      "x": 1440,
      "y": 919
    },
    {
      "t": 204998,
      "e": 168957,
      "ty": 41,
      "x": 56406,
      "y": 54892,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 206997,
      "e": 170956,
      "ty": 2,
      "x": 1440,
      "y": 921
    },
    {
      "t": 206998,
      "e": 170957,
      "ty": 41,
      "x": 56406,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207098,
      "e": 171057,
      "ty": 2,
      "x": 1432,
      "y": 926
    },
    {
      "t": 207197,
      "e": 171156,
      "ty": 2,
      "x": 1410,
      "y": 938
    },
    {
      "t": 207248,
      "e": 171207,
      "ty": 41,
      "x": 54094,
      "y": 56485,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207296,
      "e": 171255,
      "ty": 2,
      "x": 1381,
      "y": 946
    },
    {
      "t": 207396,
      "e": 171355,
      "ty": 2,
      "x": 1357,
      "y": 952
    },
    {
      "t": 207496,
      "e": 171455,
      "ty": 2,
      "x": 1311,
      "y": 963
    },
    {
      "t": 207497,
      "e": 171456,
      "ty": 41,
      "x": 50060,
      "y": 57939,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207596,
      "e": 171555,
      "ty": 2,
      "x": 1281,
      "y": 970
    },
    {
      "t": 207696,
      "e": 171655,
      "ty": 2,
      "x": 1255,
      "y": 979
    },
    {
      "t": 207747,
      "e": 171706,
      "ty": 41,
      "x": 46911,
      "y": 59185,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 207796,
      "e": 171755,
      "ty": 2,
      "x": 1240,
      "y": 984
    },
    {
      "t": 207896,
      "e": 171855,
      "ty": 2,
      "x": 1220,
      "y": 991
    },
    {
      "t": 207996,
      "e": 171955,
      "ty": 2,
      "x": 1194,
      "y": 998
    },
    {
      "t": 207997,
      "e": 171956,
      "ty": 41,
      "x": 44304,
      "y": 60363,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208096,
      "e": 172055,
      "ty": 2,
      "x": 1172,
      "y": 1003
    },
    {
      "t": 208196,
      "e": 172155,
      "ty": 2,
      "x": 1145,
      "y": 1009
    },
    {
      "t": 208247,
      "e": 172206,
      "ty": 41,
      "x": 41450,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208296,
      "e": 172255,
      "ty": 2,
      "x": 1132,
      "y": 1013
    },
    {
      "t": 208397,
      "e": 172356,
      "ty": 2,
      "x": 1108,
      "y": 1020
    },
    {
      "t": 208497,
      "e": 172456,
      "ty": 2,
      "x": 1092,
      "y": 1024
    },
    {
      "t": 208497,
      "e": 172456,
      "ty": 41,
      "x": 39286,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208597,
      "e": 172556,
      "ty": 2,
      "x": 1083,
      "y": 1027
    },
    {
      "t": 208696,
      "e": 172655,
      "ty": 2,
      "x": 1075,
      "y": 1030
    },
    {
      "t": 208747,
      "e": 172706,
      "ty": 41,
      "x": 38252,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 208796,
      "e": 172755,
      "ty": 2,
      "x": 1066,
      "y": 1031
    },
    {
      "t": 208896,
      "e": 172855,
      "ty": 2,
      "x": 1046,
      "y": 1044
    },
    {
      "t": 208997,
      "e": 172956,
      "ty": 2,
      "x": 1040,
      "y": 1049
    },
    {
      "t": 208997,
      "e": 172956,
      "ty": 41,
      "x": 36727,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209097,
      "e": 173056,
      "ty": 2,
      "x": 1031,
      "y": 1053
    },
    {
      "t": 209196,
      "e": 173155,
      "ty": 2,
      "x": 1027,
      "y": 1055
    },
    {
      "t": 209247,
      "e": 173206,
      "ty": 41,
      "x": 35842,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209296,
      "e": 173255,
      "ty": 2,
      "x": 1018,
      "y": 1058
    },
    {
      "t": 209397,
      "e": 173356,
      "ty": 2,
      "x": 1017,
      "y": 1058
    },
    {
      "t": 209496,
      "e": 173455,
      "ty": 2,
      "x": 1011,
      "y": 1061
    },
    {
      "t": 209497,
      "e": 173456,
      "ty": 41,
      "x": 35301,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209596,
      "e": 173555,
      "ty": 2,
      "x": 1006,
      "y": 1063
    },
    {
      "t": 209696,
      "e": 173655,
      "ty": 2,
      "x": 999,
      "y": 1065
    },
    {
      "t": 209747,
      "e": 173706,
      "ty": 41,
      "x": 34612,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 209796,
      "e": 173755,
      "ty": 2,
      "x": 994,
      "y": 1067
    },
    {
      "t": 209897,
      "e": 173856,
      "ty": 2,
      "x": 987,
      "y": 1071
    },
    {
      "t": 209953,
      "e": 173912,
      "ty": 6,
      "x": 986,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 209996,
      "e": 173955,
      "ty": 2,
      "x": 985,
      "y": 1073
    },
    {
      "t": 209996,
      "e": 173955,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 209997,
      "e": 173956,
      "ty": 41,
      "x": 41232,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 210097,
      "e": 174056,
      "ty": 2,
      "x": 983,
      "y": 1074
    },
    {
      "t": 210196,
      "e": 174155,
      "ty": 2,
      "x": 982,
      "y": 1074
    },
    {
      "t": 210247,
      "e": 174206,
      "ty": 41,
      "x": 39594,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 210296,
      "e": 174255,
      "ty": 2,
      "x": 979,
      "y": 1076
    },
    {
      "t": 210396,
      "e": 174355,
      "ty": 2,
      "x": 960,
      "y": 1079
    },
    {
      "t": 210497,
      "e": 174456,
      "ty": 2,
      "x": 939,
      "y": 1081
    },
    {
      "t": 210497,
      "e": 174456,
      "ty": 41,
      "x": 16110,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 210596,
      "e": 174555,
      "ty": 2,
      "x": 935,
      "y": 1083
    },
    {
      "t": 210747,
      "e": 174706,
      "ty": 41,
      "x": 13926,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 211889,
      "e": 175848,
      "ty": 3,
      "x": 935,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 211890,
      "e": 175849,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 212023,
      "e": 175982,
      "ty": 4,
      "x": 13926,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 212024,
      "e": 175983,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 212024,
      "e": 175983,
      "ty": 5,
      "x": 935,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 212024,
      "e": 175983,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 213052,
      "e": 177011,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 214288,
      "e": 178247,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 288833, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 288837, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3877, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 294033, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7261, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 302304, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 18538, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 321924, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16946, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 339872, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 66132, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 407364, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-11 AM-11 AM-O -11 AM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:959,y:1076,t:1527023248064};\\\", \\\"{x:949,y:1065,t:1527023248076};\\\", \\\"{x:935,y:1044,t:1527023248093};\\\", \\\"{x:915,y:1028,t:1527023248109};\\\", \\\"{x:902,y:1018,t:1527023248126};\\\", \\\"{x:893,y:1008,t:1527023248142};\\\", \\\"{x:883,y:996,t:1527023248159};\\\", \\\"{x:864,y:983,t:1527023248176};\\\", \\\"{x:845,y:977,t:1527023248192};\\\", \\\"{x:846,y:977,t:1527023249151};\\\", \\\"{x:855,y:977,t:1527023249161};\\\", \\\"{x:886,y:979,t:1527023249177};\\\", \\\"{x:919,y:988,t:1527023249193};\\\", \\\"{x:980,y:1003,t:1527023249210};\\\", \\\"{x:1001,y:1008,t:1527023249227};\\\", \\\"{x:1040,y:1014,t:1527023249244};\\\", \\\"{x:1075,y:1014,t:1527023249261};\\\", \\\"{x:1112,y:1013,t:1527023249276};\\\", \\\"{x:1138,y:1012,t:1527023249293};\\\", \\\"{x:1154,y:1012,t:1527023249311};\\\", \\\"{x:1161,y:1012,t:1527023249327};\\\", \\\"{x:1166,y:1011,t:1527023249343};\\\", \\\"{x:1166,y:1009,t:1527023249367};\\\", \\\"{x:1166,y:1008,t:1527023249377};\\\", \\\"{x:1166,y:1007,t:1527023249393};\\\", \\\"{x:1167,y:1007,t:1527023249856};\\\", \\\"{x:1168,y:1006,t:1527023249872};\\\", \\\"{x:1169,y:1006,t:1527023249894};\\\", \\\"{x:1170,y:1006,t:1527023249910};\\\", \\\"{x:1177,y:1006,t:1527023249927};\\\", \\\"{x:1190,y:1003,t:1527023249943};\\\", \\\"{x:1203,y:999,t:1527023249960};\\\", \\\"{x:1209,y:994,t:1527023249977};\\\", \\\"{x:1223,y:991,t:1527023249993};\\\", \\\"{x:1234,y:987,t:1527023250010};\\\", \\\"{x:1245,y:984,t:1527023250027};\\\", \\\"{x:1260,y:981,t:1527023250043};\\\", \\\"{x:1261,y:980,t:1527023250060};\\\", \\\"{x:1261,y:979,t:1527023250077};\\\", \\\"{x:1262,y:979,t:1527023250585};\\\", \\\"{x:1263,y:979,t:1527023250607};\\\", \\\"{x:1266,y:979,t:1527023250614};\\\", \\\"{x:1267,y:979,t:1527023250627};\\\", \\\"{x:1269,y:979,t:1527023250644};\\\", \\\"{x:1270,y:979,t:1527023250678};\\\", \\\"{x:1272,y:978,t:1527023250694};\\\", \\\"{x:1273,y:978,t:1527023250766};\\\", \\\"{x:1277,y:979,t:1527023250778};\\\", \\\"{x:1289,y:981,t:1527023250795};\\\", \\\"{x:1297,y:982,t:1527023250811};\\\", \\\"{x:1310,y:986,t:1527023250828};\\\", \\\"{x:1319,y:989,t:1527023250844};\\\", \\\"{x:1327,y:994,t:1527023250861};\\\", \\\"{x:1329,y:997,t:1527023250878};\\\", \\\"{x:1331,y:1000,t:1527023250895};\\\", \\\"{x:1334,y:1013,t:1527023250911};\\\", \\\"{x:1336,y:1018,t:1527023250927};\\\", \\\"{x:1334,y:1018,t:1527023251030};\\\", \\\"{x:1331,y:1017,t:1527023251044};\\\", \\\"{x:1318,y:1006,t:1527023251061};\\\", \\\"{x:1303,y:994,t:1527023251078};\\\", \\\"{x:1287,y:981,t:1527023251094};\\\", \\\"{x:1265,y:965,t:1527023251111};\\\", \\\"{x:1263,y:963,t:1527023251128};\\\", \\\"{x:1262,y:962,t:1527023251144};\\\", \\\"{x:1261,y:961,t:1527023251161};\\\", \\\"{x:1261,y:959,t:1527023251416};\\\", \\\"{x:1261,y:958,t:1527023251440};\\\", \\\"{x:1261,y:956,t:1527023251480};\\\", \\\"{x:1262,y:956,t:1527023251663};\\\", \\\"{x:1264,y:956,t:1527023251678};\\\", \\\"{x:1271,y:959,t:1527023251695};\\\", \\\"{x:1277,y:961,t:1527023251711};\\\", \\\"{x:1280,y:964,t:1527023251728};\\\", \\\"{x:1284,y:966,t:1527023251745};\\\", \\\"{x:1285,y:967,t:1527023251761};\\\", \\\"{x:1286,y:967,t:1527023251991};\\\", \\\"{x:1286,y:966,t:1527023252006};\\\", \\\"{x:1286,y:965,t:1527023252022};\\\", \\\"{x:1288,y:963,t:1527023252031};\\\", \\\"{x:1288,y:962,t:1527023252046};\\\", \\\"{x:1288,y:961,t:1527023252062};\\\", \\\"{x:1288,y:960,t:1527023252575};\\\", \\\"{x:1288,y:958,t:1527023252583};\\\", \\\"{x:1288,y:957,t:1527023252596};\\\", \\\"{x:1288,y:953,t:1527023252613};\\\", \\\"{x:1287,y:950,t:1527023252630};\\\", \\\"{x:1287,y:946,t:1527023252645};\\\", \\\"{x:1285,y:942,t:1527023252662};\\\", \\\"{x:1284,y:939,t:1527023252679};\\\", \\\"{x:1284,y:937,t:1527023252696};\\\", \\\"{x:1284,y:935,t:1527023252713};\\\", \\\"{x:1284,y:934,t:1527023252729};\\\", \\\"{x:1284,y:933,t:1527023252750};\\\", \\\"{x:1283,y:933,t:1527023252789};\\\", \\\"{x:1283,y:932,t:1527023253336};\\\", \\\"{x:1281,y:932,t:1527023253347};\\\", \\\"{x:1274,y:941,t:1527023253363};\\\", \\\"{x:1267,y:950,t:1527023253380};\\\", \\\"{x:1262,y:957,t:1527023253397};\\\", \\\"{x:1261,y:960,t:1527023253413};\\\", \\\"{x:1259,y:962,t:1527023253430};\\\", \\\"{x:1258,y:964,t:1527023253447};\\\", \\\"{x:1255,y:967,t:1527023253464};\\\", \\\"{x:1254,y:968,t:1527023253480};\\\", \\\"{x:1252,y:971,t:1527023253497};\\\", \\\"{x:1252,y:972,t:1527023253527};\\\", \\\"{x:1252,y:973,t:1527023253552};\\\", \\\"{x:1255,y:974,t:1527023253768};\\\", \\\"{x:1262,y:975,t:1527023253780};\\\", \\\"{x:1267,y:978,t:1527023253797};\\\", \\\"{x:1269,y:978,t:1527023253814};\\\", \\\"{x:1270,y:979,t:1527023255231};\\\", \\\"{x:1272,y:981,t:1527023255248};\\\", \\\"{x:1273,y:982,t:1527023255270};\\\", \\\"{x:1274,y:982,t:1527023255568};\\\", \\\"{x:1276,y:982,t:1527023255583};\\\", \\\"{x:1276,y:981,t:1527023255599};\\\", \\\"{x:1277,y:980,t:1527023255648};\\\", \\\"{x:1277,y:979,t:1527023255679};\\\", \\\"{x:1277,y:978,t:1527023255695};\\\", \\\"{x:1279,y:977,t:1527023255704};\\\", \\\"{x:1279,y:976,t:1527023255714};\\\", \\\"{x:1280,y:975,t:1527023255732};\\\", \\\"{x:1281,y:974,t:1527023255748};\\\", \\\"{x:1282,y:972,t:1527023255765};\\\", \\\"{x:1283,y:971,t:1527023255788};\\\", \\\"{x:1283,y:970,t:1527023255798};\\\", \\\"{x:1284,y:970,t:1527023255815};\\\", \\\"{x:1284,y:969,t:1527023255855};\\\", \\\"{x:1284,y:968,t:1527023255871};\\\", \\\"{x:1284,y:967,t:1527023255886};\\\", \\\"{x:1284,y:966,t:1527023255902};\\\", \\\"{x:1284,y:965,t:1527023255914};\\\", \\\"{x:1284,y:964,t:1527023255931};\\\", \\\"{x:1284,y:963,t:1527023256592};\\\", \\\"{x:1284,y:961,t:1527023257263};\\\", \\\"{x:1284,y:960,t:1527023257272};\\\", \\\"{x:1284,y:959,t:1527023257283};\\\", \\\"{x:1284,y:958,t:1527023257299};\\\", \\\"{x:1284,y:957,t:1527023257327};\\\", \\\"{x:1284,y:956,t:1527023257368};\\\", \\\"{x:1283,y:956,t:1527023260263};\\\", \\\"{x:1284,y:956,t:1527023260952};\\\", \\\"{x:1286,y:956,t:1527023260991};\\\", \\\"{x:1286,y:957,t:1527023262063};\\\", \\\"{x:1286,y:959,t:1527023262079};\\\", \\\"{x:1286,y:961,t:1527023262089};\\\", \\\"{x:1284,y:965,t:1527023262102};\\\", \\\"{x:1283,y:967,t:1527023262119};\\\", \\\"{x:1282,y:970,t:1527023262135};\\\", \\\"{x:1281,y:973,t:1527023262152};\\\", \\\"{x:1280,y:974,t:1527023262174};\\\", \\\"{x:1279,y:974,t:1527023262367};\\\", \\\"{x:1278,y:974,t:1527023262383};\\\", \\\"{x:1278,y:973,t:1527023262391};\\\", \\\"{x:1277,y:971,t:1527023262403};\\\", \\\"{x:1277,y:969,t:1527023262420};\\\", \\\"{x:1277,y:967,t:1527023262436};\\\", \\\"{x:1277,y:963,t:1527023262454};\\\", \\\"{x:1277,y:956,t:1527023262470};\\\", \\\"{x:1279,y:946,t:1527023262486};\\\", \\\"{x:1281,y:925,t:1527023262503};\\\", \\\"{x:1284,y:911,t:1527023262521};\\\", \\\"{x:1284,y:901,t:1527023262536};\\\", \\\"{x:1284,y:892,t:1527023262553};\\\", \\\"{x:1285,y:884,t:1527023262571};\\\", \\\"{x:1285,y:875,t:1527023262586};\\\", \\\"{x:1285,y:868,t:1527023262603};\\\", \\\"{x:1285,y:865,t:1527023262619};\\\", \\\"{x:1285,y:861,t:1527023262636};\\\", \\\"{x:1286,y:857,t:1527023262652};\\\", \\\"{x:1286,y:854,t:1527023262670};\\\", \\\"{x:1286,y:851,t:1527023262686};\\\", \\\"{x:1286,y:850,t:1527023262703};\\\", \\\"{x:1286,y:848,t:1527023262726};\\\", \\\"{x:1288,y:846,t:1527023262737};\\\", \\\"{x:1288,y:844,t:1527023262753};\\\", \\\"{x:1288,y:841,t:1527023262770};\\\", \\\"{x:1288,y:840,t:1527023262787};\\\", \\\"{x:1288,y:837,t:1527023262803};\\\", \\\"{x:1289,y:833,t:1527023262819};\\\", \\\"{x:1289,y:831,t:1527023262837};\\\", \\\"{x:1289,y:830,t:1527023262853};\\\", \\\"{x:1289,y:827,t:1527023262870};\\\", \\\"{x:1290,y:825,t:1527023262886};\\\", \\\"{x:1290,y:824,t:1527023262935};\\\", \\\"{x:1290,y:823,t:1527023263087};\\\", \\\"{x:1290,y:824,t:1527023264208};\\\", \\\"{x:1290,y:833,t:1527023264221};\\\", \\\"{x:1290,y:849,t:1527023264238};\\\", \\\"{x:1290,y:863,t:1527023264255};\\\", \\\"{x:1290,y:882,t:1527023264271};\\\", \\\"{x:1290,y:894,t:1527023264288};\\\", \\\"{x:1290,y:904,t:1527023264304};\\\", \\\"{x:1287,y:920,t:1527023264322};\\\", \\\"{x:1285,y:935,t:1527023264341};\\\", \\\"{x:1283,y:952,t:1527023264358};\\\", \\\"{x:1282,y:962,t:1527023264375};\\\", \\\"{x:1281,y:968,t:1527023264392};\\\", \\\"{x:1281,y:972,t:1527023264408};\\\", \\\"{x:1280,y:973,t:1527023264424};\\\", \\\"{x:1280,y:974,t:1527023264467};\\\", \\\"{x:1280,y:975,t:1527023264474};\\\", \\\"{x:1280,y:977,t:1527023264492};\\\", \\\"{x:1278,y:980,t:1527023264507};\\\", \\\"{x:1277,y:983,t:1527023264602};\\\", \\\"{x:1277,y:982,t:1527023265058};\\\", \\\"{x:1277,y:981,t:1527023265076};\\\", \\\"{x:1281,y:981,t:1527023267130};\\\", \\\"{x:1292,y:985,t:1527023267144};\\\", \\\"{x:1316,y:991,t:1527023267160};\\\", \\\"{x:1329,y:996,t:1527023267177};\\\", \\\"{x:1338,y:999,t:1527023267194};\\\", \\\"{x:1340,y:1001,t:1527023267210};\\\", \\\"{x:1339,y:1001,t:1527023281442};\\\", \\\"{x:1329,y:993,t:1527023281455};\\\", \\\"{x:1292,y:961,t:1527023281470};\\\", \\\"{x:1249,y:932,t:1527023281487};\\\", \\\"{x:1202,y:892,t:1527023281504};\\\", \\\"{x:1174,y:854,t:1527023281520};\\\", \\\"{x:1154,y:813,t:1527023281538};\\\", \\\"{x:1141,y:752,t:1527023281554};\\\", \\\"{x:1135,y:722,t:1527023281571};\\\", \\\"{x:1130,y:697,t:1527023281587};\\\", \\\"{x:1127,y:674,t:1527023281605};\\\", \\\"{x:1123,y:649,t:1527023281621};\\\", \\\"{x:1123,y:627,t:1527023281637};\\\", \\\"{x:1123,y:610,t:1527023281654};\\\", \\\"{x:1123,y:600,t:1527023281670};\\\", \\\"{x:1129,y:592,t:1527023281688};\\\", \\\"{x:1134,y:586,t:1527023281705};\\\", \\\"{x:1141,y:582,t:1527023281720};\\\", \\\"{x:1151,y:575,t:1527023281737};\\\", \\\"{x:1167,y:567,t:1527023281754};\\\", \\\"{x:1171,y:567,t:1527023281772};\\\", \\\"{x:1173,y:567,t:1527023281787};\\\", \\\"{x:1175,y:567,t:1527023281805};\\\", \\\"{x:1182,y:571,t:1527023281821};\\\", \\\"{x:1189,y:583,t:1527023281838};\\\", \\\"{x:1199,y:596,t:1527023281854};\\\", \\\"{x:1205,y:602,t:1527023281871};\\\", \\\"{x:1208,y:605,t:1527023281887};\\\", \\\"{x:1210,y:607,t:1527023281904};\\\", \\\"{x:1214,y:611,t:1527023281921};\\\", \\\"{x:1222,y:616,t:1527023281937};\\\", \\\"{x:1232,y:628,t:1527023281954};\\\", \\\"{x:1236,y:632,t:1527023281971};\\\", \\\"{x:1238,y:634,t:1527023281987};\\\", \\\"{x:1239,y:634,t:1527023282004};\\\", \\\"{x:1242,y:634,t:1527023282058};\\\", \\\"{x:1243,y:634,t:1527023282072};\\\", \\\"{x:1247,y:633,t:1527023282090};\\\", \\\"{x:1249,y:633,t:1527023282121};\\\", \\\"{x:1250,y:632,t:1527023282153};\\\", \\\"{x:1250,y:633,t:1527023282394};\\\", \\\"{x:1250,y:635,t:1527023282410};\\\", \\\"{x:1250,y:637,t:1527023282423};\\\", \\\"{x:1249,y:641,t:1527023282439};\\\", \\\"{x:1249,y:646,t:1527023282454};\\\", \\\"{x:1249,y:649,t:1527023282471};\\\", \\\"{x:1249,y:651,t:1527023282489};\\\", \\\"{x:1249,y:652,t:1527023282504};\\\", \\\"{x:1249,y:655,t:1527023282521};\\\", \\\"{x:1249,y:659,t:1527023282538};\\\", \\\"{x:1249,y:662,t:1527023282555};\\\", \\\"{x:1249,y:667,t:1527023282572};\\\", \\\"{x:1249,y:672,t:1527023282589};\\\", \\\"{x:1250,y:677,t:1527023282604};\\\", \\\"{x:1250,y:682,t:1527023282622};\\\", \\\"{x:1250,y:687,t:1527023282638};\\\", \\\"{x:1250,y:694,t:1527023282654};\\\", \\\"{x:1250,y:699,t:1527023282672};\\\", \\\"{x:1250,y:707,t:1527023282689};\\\", \\\"{x:1250,y:715,t:1527023282704};\\\", \\\"{x:1250,y:720,t:1527023282721};\\\", \\\"{x:1250,y:725,t:1527023282739};\\\", \\\"{x:1250,y:730,t:1527023282755};\\\", \\\"{x:1250,y:734,t:1527023282772};\\\", \\\"{x:1249,y:736,t:1527023282789};\\\", \\\"{x:1249,y:738,t:1527023282806};\\\", \\\"{x:1249,y:743,t:1527023282822};\\\", \\\"{x:1249,y:748,t:1527023282838};\\\", \\\"{x:1249,y:755,t:1527023282855};\\\", \\\"{x:1249,y:758,t:1527023282871};\\\", \\\"{x:1249,y:762,t:1527023282889};\\\", \\\"{x:1249,y:764,t:1527023282906};\\\", \\\"{x:1249,y:766,t:1527023282921};\\\", \\\"{x:1249,y:769,t:1527023282938};\\\", \\\"{x:1249,y:772,t:1527023282955};\\\", \\\"{x:1249,y:774,t:1527023282972};\\\", \\\"{x:1249,y:776,t:1527023282989};\\\", \\\"{x:1250,y:779,t:1527023283006};\\\", \\\"{x:1250,y:782,t:1527023283022};\\\", \\\"{x:1251,y:786,t:1527023283038};\\\", \\\"{x:1252,y:787,t:1527023283056};\\\", \\\"{x:1253,y:789,t:1527023283072};\\\", \\\"{x:1254,y:791,t:1527023283089};\\\", \\\"{x:1254,y:795,t:1527023283106};\\\", \\\"{x:1254,y:799,t:1527023283122};\\\", \\\"{x:1256,y:804,t:1527023283138};\\\", \\\"{x:1256,y:807,t:1527023283156};\\\", \\\"{x:1257,y:811,t:1527023283171};\\\", \\\"{x:1257,y:813,t:1527023283188};\\\", \\\"{x:1260,y:817,t:1527023283206};\\\", \\\"{x:1261,y:821,t:1527023283221};\\\", \\\"{x:1261,y:824,t:1527023283238};\\\", \\\"{x:1261,y:828,t:1527023283255};\\\", \\\"{x:1261,y:832,t:1527023283272};\\\", \\\"{x:1261,y:835,t:1527023283288};\\\", \\\"{x:1261,y:838,t:1527023283306};\\\", \\\"{x:1261,y:841,t:1527023283322};\\\", \\\"{x:1261,y:845,t:1527023283339};\\\", \\\"{x:1261,y:847,t:1527023283356};\\\", \\\"{x:1259,y:852,t:1527023283372};\\\", \\\"{x:1259,y:854,t:1527023283389};\\\", \\\"{x:1259,y:856,t:1527023283406};\\\", \\\"{x:1259,y:858,t:1527023283423};\\\", \\\"{x:1259,y:859,t:1527023283439};\\\", \\\"{x:1259,y:868,t:1527023283455};\\\", \\\"{x:1259,y:871,t:1527023283473};\\\", \\\"{x:1256,y:878,t:1527023283488};\\\", \\\"{x:1256,y:882,t:1527023283506};\\\", \\\"{x:1255,y:886,t:1527023283523};\\\", \\\"{x:1255,y:889,t:1527023283539};\\\", \\\"{x:1255,y:893,t:1527023283555};\\\", \\\"{x:1255,y:897,t:1527023283572};\\\", \\\"{x:1255,y:904,t:1527023283589};\\\", \\\"{x:1255,y:907,t:1527023283606};\\\", \\\"{x:1255,y:911,t:1527023283623};\\\", \\\"{x:1255,y:914,t:1527023283639};\\\", \\\"{x:1255,y:919,t:1527023283656};\\\", \\\"{x:1255,y:923,t:1527023283672};\\\", \\\"{x:1255,y:926,t:1527023283689};\\\", \\\"{x:1255,y:930,t:1527023283705};\\\", \\\"{x:1255,y:936,t:1527023283722};\\\", \\\"{x:1256,y:940,t:1527023283740};\\\", \\\"{x:1256,y:944,t:1527023283755};\\\", \\\"{x:1256,y:946,t:1527023283772};\\\", \\\"{x:1256,y:950,t:1527023283790};\\\", \\\"{x:1256,y:953,t:1527023283806};\\\", \\\"{x:1256,y:957,t:1527023283823};\\\", \\\"{x:1256,y:961,t:1527023283840};\\\", \\\"{x:1256,y:963,t:1527023283856};\\\", \\\"{x:1256,y:965,t:1527023283872};\\\", \\\"{x:1255,y:967,t:1527023283889};\\\", \\\"{x:1255,y:968,t:1527023283905};\\\", \\\"{x:1255,y:969,t:1527023283946};\\\", \\\"{x:1255,y:970,t:1527023283955};\\\", \\\"{x:1253,y:971,t:1527023284187};\\\", \\\"{x:1252,y:971,t:1527023284218};\\\", \\\"{x:1251,y:971,t:1527023284226};\\\", \\\"{x:1249,y:972,t:1527023284242};\\\", \\\"{x:1248,y:973,t:1527023284345};\\\", \\\"{x:1248,y:974,t:1527023284393};\\\", \\\"{x:1249,y:974,t:1527023284578};\\\", \\\"{x:1250,y:974,t:1527023284602};\\\", \\\"{x:1250,y:973,t:1527023284626};\\\", \\\"{x:1252,y:972,t:1527023285595};\\\", \\\"{x:1255,y:970,t:1527023285606};\\\", \\\"{x:1259,y:970,t:1527023285624};\\\", \\\"{x:1261,y:969,t:1527023285641};\\\", \\\"{x:1262,y:969,t:1527023285658};\\\", \\\"{x:1263,y:969,t:1527023285682};\\\", \\\"{x:1264,y:968,t:1527023285731};\\\", \\\"{x:1265,y:967,t:1527023285741};\\\", \\\"{x:1267,y:967,t:1527023285757};\\\", \\\"{x:1271,y:967,t:1527023285774};\\\", \\\"{x:1273,y:967,t:1527023285791};\\\", \\\"{x:1274,y:967,t:1527023285818};\\\", \\\"{x:1275,y:967,t:1527023285906};\\\", \\\"{x:1277,y:966,t:1527023285913};\\\", \\\"{x:1279,y:966,t:1527023285929};\\\", \\\"{x:1280,y:965,t:1527023285945};\\\", \\\"{x:1281,y:965,t:1527023292027};\\\", \\\"{x:1283,y:964,t:1527023292034};\\\", \\\"{x:1283,y:961,t:1527023292045};\\\", \\\"{x:1283,y:956,t:1527023292062};\\\", \\\"{x:1283,y:951,t:1527023292079};\\\", \\\"{x:1283,y:941,t:1527023292095};\\\", \\\"{x:1279,y:929,t:1527023292112};\\\", \\\"{x:1272,y:915,t:1527023292129};\\\", \\\"{x:1266,y:899,t:1527023292148};\\\", \\\"{x:1245,y:860,t:1527023292161};\\\", \\\"{x:1230,y:836,t:1527023292178};\\\", \\\"{x:1214,y:813,t:1527023292194};\\\", \\\"{x:1194,y:792,t:1527023292211};\\\", \\\"{x:1177,y:770,t:1527023292229};\\\", \\\"{x:1157,y:744,t:1527023292244};\\\", \\\"{x:1142,y:722,t:1527023292261};\\\", \\\"{x:1122,y:702,t:1527023292278};\\\", \\\"{x:1099,y:683,t:1527023292296};\\\", \\\"{x:1076,y:667,t:1527023292312};\\\", \\\"{x:1053,y:655,t:1527023292329};\\\", \\\"{x:1034,y:642,t:1527023292346};\\\", \\\"{x:1027,y:639,t:1527023292362};\\\", \\\"{x:1024,y:637,t:1527023292379};\\\", \\\"{x:1022,y:636,t:1527023292396};\\\", \\\"{x:1021,y:635,t:1527023292412};\\\", \\\"{x:1016,y:631,t:1527023292428};\\\", \\\"{x:1011,y:625,t:1527023292446};\\\", \\\"{x:1002,y:616,t:1527023292462};\\\", \\\"{x:986,y:605,t:1527023292479};\\\", \\\"{x:966,y:589,t:1527023292496};\\\", \\\"{x:949,y:577,t:1527023292511};\\\", \\\"{x:934,y:570,t:1527023292530};\\\", \\\"{x:912,y:561,t:1527023292545};\\\", \\\"{x:905,y:558,t:1527023292562};\\\", \\\"{x:901,y:557,t:1527023292582};\\\", \\\"{x:899,y:555,t:1527023292600};\\\", \\\"{x:898,y:555,t:1527023292616};\\\", \\\"{x:898,y:554,t:1527023292649};\\\", \\\"{x:898,y:553,t:1527023292673};\\\", \\\"{x:897,y:552,t:1527023292682};\\\", \\\"{x:896,y:551,t:1527023292699};\\\", \\\"{x:895,y:551,t:1527023292717};\\\", \\\"{x:894,y:550,t:1527023292733};\\\", \\\"{x:894,y:549,t:1527023294146};\\\", \\\"{x:895,y:552,t:1527023294178};\\\", \\\"{x:901,y:558,t:1527023294186};\\\", \\\"{x:903,y:562,t:1527023294201};\\\", \\\"{x:910,y:573,t:1527023294217};\\\", \\\"{x:912,y:576,t:1527023294235};\\\", \\\"{x:913,y:579,t:1527023294250};\\\", \\\"{x:913,y:583,t:1527023294268};\\\", \\\"{x:915,y:586,t:1527023294283};\\\", \\\"{x:916,y:588,t:1527023294300};\\\", \\\"{x:916,y:590,t:1527023294317};\\\", \\\"{x:917,y:590,t:1527023294334};\\\", \\\"{x:917,y:591,t:1527023294350};\\\", \\\"{x:918,y:593,t:1527023294367};\\\", \\\"{x:919,y:595,t:1527023294384};\\\", \\\"{x:923,y:599,t:1527023294401};\\\", \\\"{x:939,y:611,t:1527023294417};\\\", \\\"{x:952,y:615,t:1527023294435};\\\", \\\"{x:969,y:624,t:1527023294451};\\\", \\\"{x:985,y:630,t:1527023294468};\\\", \\\"{x:1001,y:635,t:1527023294485};\\\", \\\"{x:1009,y:637,t:1527023294500};\\\", \\\"{x:1020,y:638,t:1527023294517};\\\", \\\"{x:1022,y:639,t:1527023294534};\\\", \\\"{x:1014,y:643,t:1527023309106};\\\", \\\"{x:1009,y:645,t:1527023309114};\\\", \\\"{x:987,y:646,t:1527023309129};\\\", \\\"{x:963,y:646,t:1527023309146};\\\", \\\"{x:948,y:646,t:1527023309162};\\\", \\\"{x:938,y:646,t:1527023309179};\\\", \\\"{x:930,y:649,t:1527023309195};\\\", \\\"{x:925,y:652,t:1527023309212};\\\", \\\"{x:919,y:657,t:1527023309229};\\\", \\\"{x:915,y:660,t:1527023309246};\\\", \\\"{x:912,y:662,t:1527023309262};\\\", \\\"{x:909,y:665,t:1527023309279};\\\", \\\"{x:907,y:667,t:1527023309296};\\\", \\\"{x:899,y:669,t:1527023309313};\\\", \\\"{x:885,y:668,t:1527023309330};\\\", \\\"{x:867,y:662,t:1527023309346};\\\", \\\"{x:847,y:650,t:1527023309364};\\\", \\\"{x:830,y:638,t:1527023309380};\\\", \\\"{x:815,y:624,t:1527023309397};\\\", \\\"{x:808,y:614,t:1527023309414};\\\", \\\"{x:805,y:608,t:1527023309429};\\\", \\\"{x:805,y:606,t:1527023309446};\\\", \\\"{x:804,y:601,t:1527023309463};\\\", \\\"{x:804,y:598,t:1527023309480};\\\", \\\"{x:806,y:588,t:1527023309496};\\\", \\\"{x:811,y:576,t:1527023309514};\\\", \\\"{x:819,y:564,t:1527023309530};\\\", \\\"{x:823,y:556,t:1527023309546};\\\", \\\"{x:832,y:542,t:1527023309563};\\\", \\\"{x:836,y:535,t:1527023309580};\\\", \\\"{x:837,y:531,t:1527023309596};\\\", \\\"{x:838,y:526,t:1527023309613};\\\", \\\"{x:840,y:524,t:1527023309630};\\\", \\\"{x:843,y:520,t:1527023309646};\\\", \\\"{x:844,y:515,t:1527023309663};\\\", \\\"{x:846,y:510,t:1527023309680};\\\", \\\"{x:848,y:507,t:1527023309697};\\\", \\\"{x:847,y:506,t:1527023309874};\\\", \\\"{x:846,y:506,t:1527023309914};\\\", \\\"{x:845,y:507,t:1527023309930};\\\", \\\"{x:844,y:507,t:1527023309947};\\\", \\\"{x:844,y:508,t:1527023309978};\\\", \\\"{x:843,y:508,t:1527023309994};\\\", \\\"{x:842,y:510,t:1527023310019};\\\", \\\"{x:841,y:510,t:1527023310049};\\\", \\\"{x:840,y:512,t:1527023310715};\\\", \\\"{x:839,y:512,t:1527023310746};\\\", \\\"{x:838,y:512,t:1527023310754};\\\", \\\"{x:837,y:513,t:1527023311889};\\\", \\\"{x:837,y:517,t:1527023311899};\\\", \\\"{x:820,y:531,t:1527023311915};\\\", \\\"{x:795,y:551,t:1527023311932};\\\", \\\"{x:780,y:565,t:1527023311949};\\\", \\\"{x:770,y:573,t:1527023311965};\\\", \\\"{x:761,y:584,t:1527023311983};\\\", \\\"{x:742,y:600,t:1527023311998};\\\", \\\"{x:720,y:619,t:1527023312015};\\\", \\\"{x:706,y:632,t:1527023312033};\\\", \\\"{x:691,y:641,t:1527023312048};\\\", \\\"{x:674,y:654,t:1527023312065};\\\", \\\"{x:664,y:660,t:1527023312082};\\\", \\\"{x:647,y:668,t:1527023312098};\\\", \\\"{x:625,y:678,t:1527023312116};\\\", \\\"{x:609,y:684,t:1527023312131};\\\", \\\"{x:596,y:692,t:1527023312148};\\\", \\\"{x:586,y:697,t:1527023312165};\\\", \\\"{x:573,y:702,t:1527023312181};\\\", \\\"{x:557,y:711,t:1527023312199};\\\", \\\"{x:550,y:715,t:1527023312215};\\\", \\\"{x:546,y:719,t:1527023312232};\\\", \\\"{x:545,y:720,t:1527023312249};\\\", \\\"{x:545,y:718,t:1527023313066};\\\", \\\"{x:545,y:714,t:1527023313083};\\\", \\\"{x:545,y:709,t:1527023313099};\\\", \\\"{x:546,y:707,t:1527023313116};\\\", \\\"{x:546,y:706,t:1527023313137};\\\", \\\"{x:547,y:705,t:1527023313149};\\\", \\\"{x:548,y:704,t:1527023313166};\\\", \\\"{x:548,y:703,t:1527023313184};\\\", \\\"{x:548,y:701,t:1527023313199};\\\", \\\"{x:549,y:700,t:1527023313216};\\\", \\\"{x:549,y:699,t:1527023313249};\\\", \\\"{x:549,y:697,t:1527023313289};\\\", \\\"{x:549,y:696,t:1527023313409};\\\", \\\"{x:551,y:695,t:1527023313434};\\\", \\\"{x:551,y:694,t:1527023313458};\\\" ] }, { \\\"rt\\\": 124811, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 533807, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -K -D -D -D -J -D -H -U -U -02 PM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:693,t:1527023314962};\\\", \\\"{x:551,y:692,t:1527023315410};\\\", \\\"{x:552,y:692,t:1527023315433};\\\", \\\"{x:554,y:691,t:1527023315452};\\\", \\\"{x:557,y:689,t:1527023315468};\\\", \\\"{x:558,y:687,t:1527023315484};\\\", \\\"{x:563,y:683,t:1527023315501};\\\", \\\"{x:575,y:679,t:1527023315519};\\\", \\\"{x:592,y:677,t:1527023315535};\\\", \\\"{x:618,y:674,t:1527023315552};\\\", \\\"{x:645,y:672,t:1527023315569};\\\", \\\"{x:672,y:672,t:1527023315585};\\\", \\\"{x:755,y:679,t:1527023315601};\\\", \\\"{x:835,y:679,t:1527023315619};\\\", \\\"{x:931,y:684,t:1527023315635};\\\", \\\"{x:1019,y:692,t:1527023315652};\\\", \\\"{x:1102,y:701,t:1527023315669};\\\", \\\"{x:1166,y:711,t:1527023315684};\\\", \\\"{x:1225,y:721,t:1527023315701};\\\", \\\"{x:1292,y:732,t:1527023315718};\\\", \\\"{x:1342,y:746,t:1527023315734};\\\", \\\"{x:1401,y:762,t:1527023315751};\\\", \\\"{x:1429,y:772,t:1527023315768};\\\", \\\"{x:1444,y:778,t:1527023315785};\\\", \\\"{x:1465,y:788,t:1527023315801};\\\", \\\"{x:1470,y:792,t:1527023315818};\\\", \\\"{x:1472,y:794,t:1527023315835};\\\", \\\"{x:1473,y:795,t:1527023315866};\\\", \\\"{x:1474,y:797,t:1527023315937};\\\", \\\"{x:1475,y:797,t:1527023315953};\\\", \\\"{x:1475,y:798,t:1527023315969};\\\", \\\"{x:1476,y:799,t:1527023316001};\\\", \\\"{x:1477,y:802,t:1527023316050};\\\", \\\"{x:1478,y:803,t:1527023316058};\\\", \\\"{x:1479,y:805,t:1527023316073};\\\", \\\"{x:1480,y:807,t:1527023316085};\\\", \\\"{x:1483,y:810,t:1527023316101};\\\", \\\"{x:1487,y:813,t:1527023316118};\\\", \\\"{x:1492,y:817,t:1527023316135};\\\", \\\"{x:1494,y:818,t:1527023316152};\\\", \\\"{x:1498,y:822,t:1527023316169};\\\", \\\"{x:1501,y:824,t:1527023316186};\\\", \\\"{x:1502,y:824,t:1527023316250};\\\", \\\"{x:1502,y:825,t:1527023316273};\\\", \\\"{x:1503,y:825,t:1527023316306};\\\", \\\"{x:1503,y:826,t:1527023316354};\\\", \\\"{x:1504,y:827,t:1527023316370};\\\", \\\"{x:1505,y:827,t:1527023316426};\\\", \\\"{x:1506,y:828,t:1527023316441};\\\", \\\"{x:1506,y:829,t:1527023316506};\\\", \\\"{x:1507,y:830,t:1527023316538};\\\", \\\"{x:1508,y:831,t:1527023316642};\\\", \\\"{x:1509,y:831,t:1527023316698};\\\", \\\"{x:1509,y:833,t:1527023316722};\\\", \\\"{x:1510,y:833,t:1527023316737};\\\", \\\"{x:1511,y:833,t:1527023316753};\\\", \\\"{x:1513,y:834,t:1527023316769};\\\", \\\"{x:1514,y:835,t:1527023316793};\\\", \\\"{x:1515,y:836,t:1527023316803};\\\", \\\"{x:1516,y:837,t:1527023316849};\\\", \\\"{x:1516,y:838,t:1527023316874};\\\", \\\"{x:1517,y:839,t:1527023316886};\\\", \\\"{x:1518,y:840,t:1527023316906};\\\", \\\"{x:1519,y:841,t:1527023316929};\\\", \\\"{x:1520,y:841,t:1527023317018};\\\", \\\"{x:1521,y:843,t:1527023317642};\\\", \\\"{x:1523,y:844,t:1527023317659};\\\", \\\"{x:1524,y:845,t:1527023317670};\\\", \\\"{x:1527,y:847,t:1527023317687};\\\", \\\"{x:1529,y:848,t:1527023317703};\\\", \\\"{x:1530,y:849,t:1527023317722};\\\", \\\"{x:1531,y:850,t:1527023317737};\\\", \\\"{x:1533,y:850,t:1527023317753};\\\", \\\"{x:1536,y:852,t:1527023317770};\\\", \\\"{x:1536,y:853,t:1527023317787};\\\", \\\"{x:1537,y:853,t:1527023317804};\\\", \\\"{x:1537,y:855,t:1527023318090};\\\", \\\"{x:1534,y:857,t:1527023318104};\\\", \\\"{x:1530,y:860,t:1527023318121};\\\", \\\"{x:1528,y:864,t:1527023318137};\\\", \\\"{x:1526,y:866,t:1527023318154};\\\", \\\"{x:1525,y:866,t:1527023318170};\\\", \\\"{x:1524,y:867,t:1527023318187};\\\", \\\"{x:1522,y:868,t:1527023318204};\\\", \\\"{x:1520,y:870,t:1527023318220};\\\", \\\"{x:1518,y:871,t:1527023318237};\\\", \\\"{x:1516,y:873,t:1527023318254};\\\", \\\"{x:1515,y:873,t:1527023318271};\\\", \\\"{x:1514,y:875,t:1527023318287};\\\", \\\"{x:1513,y:875,t:1527023318303};\\\", \\\"{x:1516,y:876,t:1527023318449};\\\", \\\"{x:1519,y:876,t:1527023318458};\\\", \\\"{x:1523,y:876,t:1527023318470};\\\", \\\"{x:1537,y:876,t:1527023318487};\\\", \\\"{x:1543,y:876,t:1527023318504};\\\", \\\"{x:1554,y:876,t:1527023318521};\\\", \\\"{x:1561,y:876,t:1527023318537};\\\", \\\"{x:1568,y:876,t:1527023318554};\\\", \\\"{x:1572,y:876,t:1527023318571};\\\", \\\"{x:1575,y:876,t:1527023318587};\\\", \\\"{x:1576,y:876,t:1527023318604};\\\", \\\"{x:1579,y:876,t:1527023318621};\\\", \\\"{x:1580,y:876,t:1527023318637};\\\", \\\"{x:1581,y:876,t:1527023318654};\\\", \\\"{x:1581,y:875,t:1527023318671};\\\", \\\"{x:1581,y:874,t:1527023318786};\\\", \\\"{x:1582,y:873,t:1527023318793};\\\", \\\"{x:1583,y:873,t:1527023318826};\\\", \\\"{x:1583,y:871,t:1527023318970};\\\", \\\"{x:1585,y:869,t:1527023318988};\\\", \\\"{x:1585,y:864,t:1527023319004};\\\", \\\"{x:1585,y:859,t:1527023319021};\\\", \\\"{x:1583,y:854,t:1527023319038};\\\", \\\"{x:1581,y:850,t:1527023319054};\\\", \\\"{x:1576,y:842,t:1527023319071};\\\", \\\"{x:1571,y:835,t:1527023319087};\\\", \\\"{x:1566,y:829,t:1527023319104};\\\", \\\"{x:1560,y:824,t:1527023319121};\\\", \\\"{x:1553,y:817,t:1527023319138};\\\", \\\"{x:1549,y:816,t:1527023319154};\\\", \\\"{x:1545,y:812,t:1527023319171};\\\", \\\"{x:1542,y:812,t:1527023319188};\\\", \\\"{x:1540,y:811,t:1527023319205};\\\", \\\"{x:1538,y:810,t:1527023319221};\\\", \\\"{x:1533,y:809,t:1527023319238};\\\", \\\"{x:1527,y:808,t:1527023319255};\\\", \\\"{x:1521,y:807,t:1527023319271};\\\", \\\"{x:1507,y:801,t:1527023319288};\\\", \\\"{x:1491,y:796,t:1527023319305};\\\", \\\"{x:1479,y:792,t:1527023319322};\\\", \\\"{x:1461,y:787,t:1527023319338};\\\", \\\"{x:1445,y:782,t:1527023319355};\\\", \\\"{x:1431,y:779,t:1527023319371};\\\", \\\"{x:1415,y:773,t:1527023319388};\\\", \\\"{x:1404,y:768,t:1527023319405};\\\", \\\"{x:1389,y:761,t:1527023319421};\\\", \\\"{x:1377,y:754,t:1527023319438};\\\", \\\"{x:1369,y:750,t:1527023319456};\\\", \\\"{x:1357,y:747,t:1527023319472};\\\", \\\"{x:1352,y:746,t:1527023319488};\\\", \\\"{x:1348,y:745,t:1527023319505};\\\", \\\"{x:1348,y:744,t:1527023319521};\\\", \\\"{x:1347,y:744,t:1527023319538};\\\", \\\"{x:1347,y:742,t:1527023319659};\\\", \\\"{x:1348,y:742,t:1527023319671};\\\", \\\"{x:1356,y:738,t:1527023319688};\\\", \\\"{x:1367,y:733,t:1527023319705};\\\", \\\"{x:1413,y:701,t:1527023319722};\\\", \\\"{x:1435,y:683,t:1527023319738};\\\", \\\"{x:1485,y:646,t:1527023319755};\\\", \\\"{x:1516,y:624,t:1527023319772};\\\", \\\"{x:1529,y:608,t:1527023319788};\\\", \\\"{x:1545,y:590,t:1527023319805};\\\", \\\"{x:1568,y:569,t:1527023319822};\\\", \\\"{x:1583,y:554,t:1527023319838};\\\", \\\"{x:1592,y:547,t:1527023319855};\\\", \\\"{x:1598,y:541,t:1527023319872};\\\", \\\"{x:1604,y:533,t:1527023319888};\\\", \\\"{x:1605,y:527,t:1527023319904};\\\", \\\"{x:1609,y:520,t:1527023319920};\\\", \\\"{x:1611,y:518,t:1527023319938};\\\", \\\"{x:1611,y:517,t:1527023319954};\\\", \\\"{x:1612,y:516,t:1527023319971};\\\", \\\"{x:1612,y:514,t:1527023319988};\\\", \\\"{x:1615,y:510,t:1527023320004};\\\", \\\"{x:1616,y:505,t:1527023320021};\\\", \\\"{x:1616,y:501,t:1527023320038};\\\", \\\"{x:1616,y:498,t:1527023320055};\\\", \\\"{x:1618,y:491,t:1527023320071};\\\", \\\"{x:1618,y:487,t:1527023320088};\\\", \\\"{x:1619,y:486,t:1527023320105};\\\", \\\"{x:1619,y:481,t:1527023320330};\\\", \\\"{x:1619,y:476,t:1527023320339};\\\", \\\"{x:1619,y:470,t:1527023320355};\\\", \\\"{x:1622,y:463,t:1527023320372};\\\", \\\"{x:1628,y:455,t:1527023320389};\\\", \\\"{x:1631,y:451,t:1527023320405};\\\", \\\"{x:1631,y:449,t:1527023320422};\\\", \\\"{x:1632,y:449,t:1527023320514};\\\", \\\"{x:1632,y:448,t:1527023320529};\\\", \\\"{x:1632,y:447,t:1527023320545};\\\", \\\"{x:1632,y:446,t:1527023320561};\\\", \\\"{x:1632,y:445,t:1527023320578};\\\", \\\"{x:1632,y:443,t:1527023320602};\\\", \\\"{x:1632,y:441,t:1527023320618};\\\", \\\"{x:1631,y:441,t:1527023320634};\\\", \\\"{x:1630,y:440,t:1527023320659};\\\", \\\"{x:1630,y:439,t:1527023320673};\\\", \\\"{x:1629,y:438,t:1527023320698};\\\", \\\"{x:1628,y:437,t:1527023320722};\\\", \\\"{x:1627,y:437,t:1527023320739};\\\", \\\"{x:1626,y:436,t:1527023320756};\\\", \\\"{x:1625,y:436,t:1527023320772};\\\", \\\"{x:1624,y:435,t:1527023321018};\\\", \\\"{x:1622,y:435,t:1527023321025};\\\", \\\"{x:1621,y:435,t:1527023321039};\\\", \\\"{x:1619,y:435,t:1527023321056};\\\", \\\"{x:1618,y:435,t:1527023321073};\\\", \\\"{x:1616,y:435,t:1527023321100};\\\", \\\"{x:1615,y:435,t:1527023321123};\\\", \\\"{x:1613,y:435,t:1527023321330};\\\", \\\"{x:1612,y:435,t:1527023321354};\\\", \\\"{x:1610,y:434,t:1527023321379};\\\", \\\"{x:1609,y:434,t:1527023321402};\\\", \\\"{x:1607,y:434,t:1527023321450};\\\", \\\"{x:1607,y:433,t:1527023321465};\\\", \\\"{x:1607,y:432,t:1527023321978};\\\", \\\"{x:1607,y:431,t:1527023321993};\\\", \\\"{x:1608,y:430,t:1527023322006};\\\", \\\"{x:1610,y:430,t:1527023322024};\\\", \\\"{x:1611,y:430,t:1527023322106};\\\", \\\"{x:1612,y:429,t:1527023323450};\\\", \\\"{x:1612,y:431,t:1527023349301};\\\", \\\"{x:1612,y:433,t:1527023349693};\\\", \\\"{x:1612,y:436,t:1527023349702};\\\", \\\"{x:1612,y:440,t:1527023349714};\\\", \\\"{x:1611,y:447,t:1527023349731};\\\", \\\"{x:1611,y:455,t:1527023349747};\\\", \\\"{x:1611,y:460,t:1527023349765};\\\", \\\"{x:1609,y:467,t:1527023349781};\\\", \\\"{x:1609,y:471,t:1527023349797};\\\", \\\"{x:1609,y:475,t:1527023349814};\\\", \\\"{x:1609,y:481,t:1527023349831};\\\", \\\"{x:1609,y:486,t:1527023349847};\\\", \\\"{x:1609,y:497,t:1527023349864};\\\", \\\"{x:1609,y:503,t:1527023349881};\\\", \\\"{x:1608,y:507,t:1527023349898};\\\", \\\"{x:1608,y:513,t:1527023349914};\\\", \\\"{x:1608,y:517,t:1527023349931};\\\", \\\"{x:1608,y:523,t:1527023349948};\\\", \\\"{x:1607,y:527,t:1527023349964};\\\", \\\"{x:1606,y:533,t:1527023349981};\\\", \\\"{x:1606,y:536,t:1527023349998};\\\", \\\"{x:1606,y:537,t:1527023350029};\\\", \\\"{x:1606,y:538,t:1527023350069};\\\", \\\"{x:1606,y:539,t:1527023350081};\\\", \\\"{x:1606,y:541,t:1527023350098};\\\", \\\"{x:1606,y:544,t:1527023350114};\\\", \\\"{x:1606,y:545,t:1527023350131};\\\", \\\"{x:1606,y:548,t:1527023350148};\\\", \\\"{x:1606,y:549,t:1527023350165};\\\", \\\"{x:1607,y:551,t:1527023350181};\\\", \\\"{x:1608,y:554,t:1527023350198};\\\", \\\"{x:1610,y:559,t:1527023350214};\\\", \\\"{x:1611,y:560,t:1527023350231};\\\", \\\"{x:1611,y:562,t:1527023350248};\\\", \\\"{x:1612,y:563,t:1527023350265};\\\", \\\"{x:1613,y:565,t:1527023350317};\\\", \\\"{x:1615,y:566,t:1527023350331};\\\", \\\"{x:1616,y:568,t:1527023350348};\\\", \\\"{x:1617,y:570,t:1527023350364};\\\", \\\"{x:1618,y:570,t:1527023350478};\\\", \\\"{x:1618,y:563,t:1527023350542};\\\", \\\"{x:1619,y:559,t:1527023350549};\\\", \\\"{x:1621,y:544,t:1527023350565};\\\", \\\"{x:1623,y:530,t:1527023350581};\\\", \\\"{x:1624,y:514,t:1527023350598};\\\", \\\"{x:1624,y:503,t:1527023350615};\\\", \\\"{x:1624,y:495,t:1527023350631};\\\", \\\"{x:1624,y:489,t:1527023350648};\\\", \\\"{x:1624,y:487,t:1527023350665};\\\", \\\"{x:1623,y:484,t:1527023350681};\\\", \\\"{x:1623,y:483,t:1527023350698};\\\", \\\"{x:1622,y:482,t:1527023350717};\\\", \\\"{x:1622,y:481,t:1527023350731};\\\", \\\"{x:1620,y:478,t:1527023350748};\\\", \\\"{x:1619,y:476,t:1527023350765};\\\", \\\"{x:1618,y:474,t:1527023350781};\\\", \\\"{x:1617,y:471,t:1527023350798};\\\", \\\"{x:1617,y:468,t:1527023350816};\\\", \\\"{x:1616,y:463,t:1527023350831};\\\", \\\"{x:1614,y:457,t:1527023350848};\\\", \\\"{x:1613,y:450,t:1527023350866};\\\", \\\"{x:1613,y:443,t:1527023350883};\\\", \\\"{x:1612,y:438,t:1527023350898};\\\", \\\"{x:1612,y:436,t:1527023350915};\\\", \\\"{x:1612,y:435,t:1527023350933};\\\", \\\"{x:1612,y:434,t:1527023350948};\\\", \\\"{x:1611,y:434,t:1527023351237};\\\", \\\"{x:1611,y:436,t:1527023351254};\\\", \\\"{x:1611,y:437,t:1527023351265};\\\", \\\"{x:1611,y:440,t:1527023351282};\\\", \\\"{x:1611,y:444,t:1527023351298};\\\", \\\"{x:1611,y:449,t:1527023351315};\\\", \\\"{x:1611,y:455,t:1527023351333};\\\", \\\"{x:1612,y:463,t:1527023351348};\\\", \\\"{x:1612,y:467,t:1527023351365};\\\", \\\"{x:1614,y:469,t:1527023351382};\\\", \\\"{x:1614,y:470,t:1527023351399};\\\", \\\"{x:1614,y:473,t:1527023351415};\\\", \\\"{x:1614,y:475,t:1527023351432};\\\", \\\"{x:1614,y:477,t:1527023351449};\\\", \\\"{x:1615,y:479,t:1527023351465};\\\", \\\"{x:1615,y:480,t:1527023351482};\\\", \\\"{x:1615,y:482,t:1527023351508};\\\", \\\"{x:1615,y:483,t:1527023351517};\\\", \\\"{x:1617,y:485,t:1527023351532};\\\", \\\"{x:1618,y:487,t:1527023351549};\\\", \\\"{x:1618,y:490,t:1527023351565};\\\", \\\"{x:1618,y:492,t:1527023351597};\\\", \\\"{x:1618,y:493,t:1527023351613};\\\", \\\"{x:1619,y:494,t:1527023351620};\\\", \\\"{x:1619,y:495,t:1527023351632};\\\", \\\"{x:1620,y:498,t:1527023351649};\\\", \\\"{x:1620,y:499,t:1527023351665};\\\", \\\"{x:1622,y:502,t:1527023351682};\\\", \\\"{x:1622,y:503,t:1527023351701};\\\", \\\"{x:1622,y:504,t:1527023351773};\\\", \\\"{x:1622,y:505,t:1527023351789};\\\", \\\"{x:1622,y:506,t:1527023351799};\\\", \\\"{x:1622,y:508,t:1527023351816};\\\", \\\"{x:1622,y:509,t:1527023351837};\\\", \\\"{x:1622,y:511,t:1527023351893};\\\", \\\"{x:1622,y:512,t:1527023351909};\\\", \\\"{x:1622,y:514,t:1527023351925};\\\", \\\"{x:1622,y:516,t:1527023351932};\\\", \\\"{x:1622,y:518,t:1527023351948};\\\", \\\"{x:1622,y:520,t:1527023351966};\\\", \\\"{x:1621,y:526,t:1527023351981};\\\", \\\"{x:1621,y:527,t:1527023351998};\\\", \\\"{x:1621,y:528,t:1527023352016};\\\", \\\"{x:1620,y:532,t:1527023352031};\\\", \\\"{x:1620,y:533,t:1527023352068};\\\", \\\"{x:1620,y:535,t:1527023352081};\\\", \\\"{x:1620,y:538,t:1527023352098};\\\", \\\"{x:1620,y:541,t:1527023352115};\\\", \\\"{x:1621,y:543,t:1527023352131};\\\", \\\"{x:1621,y:545,t:1527023352149};\\\", \\\"{x:1621,y:548,t:1527023352166};\\\", \\\"{x:1622,y:549,t:1527023352205};\\\", \\\"{x:1623,y:549,t:1527023352221};\\\", \\\"{x:1623,y:551,t:1527023352245};\\\", \\\"{x:1623,y:553,t:1527023352263};\\\", \\\"{x:1623,y:555,t:1527023352285};\\\", \\\"{x:1624,y:555,t:1527023352301};\\\", \\\"{x:1624,y:556,t:1527023352316};\\\", \\\"{x:1624,y:559,t:1527023352333};\\\", \\\"{x:1624,y:560,t:1527023352365};\\\", \\\"{x:1626,y:562,t:1527023352396};\\\", \\\"{x:1627,y:565,t:1527023352420};\\\", \\\"{x:1628,y:566,t:1527023352444};\\\", \\\"{x:1628,y:569,t:1527023352468};\\\", \\\"{x:1629,y:569,t:1527023352483};\\\", \\\"{x:1629,y:570,t:1527023352499};\\\", \\\"{x:1630,y:572,t:1527023352516};\\\", \\\"{x:1630,y:573,t:1527023352533};\\\", \\\"{x:1630,y:574,t:1527023352549};\\\", \\\"{x:1630,y:575,t:1527023352566};\\\", \\\"{x:1631,y:576,t:1527023352583};\\\", \\\"{x:1633,y:579,t:1527023352605};\\\", \\\"{x:1634,y:580,t:1527023352629};\\\", \\\"{x:1634,y:582,t:1527023352637};\\\", \\\"{x:1634,y:583,t:1527023352653};\\\", \\\"{x:1634,y:584,t:1527023352666};\\\", \\\"{x:1634,y:585,t:1527023352683};\\\", \\\"{x:1634,y:586,t:1527023352699};\\\", \\\"{x:1634,y:588,t:1527023352716};\\\", \\\"{x:1635,y:591,t:1527023352733};\\\", \\\"{x:1635,y:594,t:1527023352749};\\\", \\\"{x:1636,y:596,t:1527023352766};\\\", \\\"{x:1636,y:598,t:1527023352783};\\\", \\\"{x:1636,y:600,t:1527023352800};\\\", \\\"{x:1636,y:604,t:1527023352816};\\\", \\\"{x:1637,y:608,t:1527023352833};\\\", \\\"{x:1637,y:615,t:1527023352851};\\\", \\\"{x:1637,y:618,t:1527023352867};\\\", \\\"{x:1638,y:621,t:1527023352883};\\\", \\\"{x:1640,y:623,t:1527023352900};\\\", \\\"{x:1640,y:629,t:1527023352916};\\\", \\\"{x:1640,y:634,t:1527023352933};\\\", \\\"{x:1640,y:636,t:1527023352951};\\\", \\\"{x:1641,y:638,t:1527023352981};\\\", \\\"{x:1641,y:639,t:1527023352989};\\\", \\\"{x:1641,y:640,t:1527023353000};\\\", \\\"{x:1641,y:645,t:1527023353016};\\\", \\\"{x:1644,y:647,t:1527023353033};\\\", \\\"{x:1644,y:651,t:1527023353050};\\\", \\\"{x:1644,y:656,t:1527023353066};\\\", \\\"{x:1644,y:662,t:1527023353083};\\\", \\\"{x:1645,y:665,t:1527023353101};\\\", \\\"{x:1645,y:669,t:1527023353116};\\\", \\\"{x:1647,y:675,t:1527023353133};\\\", \\\"{x:1647,y:680,t:1527023353150};\\\", \\\"{x:1647,y:687,t:1527023353167};\\\", \\\"{x:1649,y:694,t:1527023353183};\\\", \\\"{x:1652,y:704,t:1527023353200};\\\", \\\"{x:1652,y:709,t:1527023353217};\\\", \\\"{x:1652,y:713,t:1527023353233};\\\", \\\"{x:1652,y:716,t:1527023353250};\\\", \\\"{x:1653,y:718,t:1527023353267};\\\", \\\"{x:1653,y:722,t:1527023353284};\\\", \\\"{x:1653,y:726,t:1527023353300};\\\", \\\"{x:1655,y:734,t:1527023353317};\\\", \\\"{x:1655,y:738,t:1527023353333};\\\", \\\"{x:1655,y:744,t:1527023353350};\\\", \\\"{x:1655,y:750,t:1527023353367};\\\", \\\"{x:1655,y:753,t:1527023353383};\\\", \\\"{x:1655,y:755,t:1527023353400};\\\", \\\"{x:1655,y:756,t:1527023353417};\\\", \\\"{x:1655,y:759,t:1527023353433};\\\", \\\"{x:1655,y:762,t:1527023353450};\\\", \\\"{x:1656,y:766,t:1527023353467};\\\", \\\"{x:1656,y:768,t:1527023353483};\\\", \\\"{x:1656,y:770,t:1527023353500};\\\", \\\"{x:1658,y:775,t:1527023353517};\\\", \\\"{x:1658,y:776,t:1527023353533};\\\", \\\"{x:1659,y:778,t:1527023353550};\\\", \\\"{x:1660,y:779,t:1527023353568};\\\", \\\"{x:1660,y:780,t:1527023353583};\\\", \\\"{x:1661,y:782,t:1527023353600};\\\", \\\"{x:1661,y:783,t:1527023353663};\\\", \\\"{x:1662,y:785,t:1527023353677};\\\", \\\"{x:1662,y:786,t:1527023353700};\\\", \\\"{x:1662,y:787,t:1527023353725};\\\", \\\"{x:1662,y:788,t:1527023353764};\\\", \\\"{x:1662,y:789,t:1527023353797};\\\", \\\"{x:1662,y:790,t:1527023353837};\\\", \\\"{x:1662,y:791,t:1527023353885};\\\", \\\"{x:1662,y:792,t:1527023353917};\\\", \\\"{x:1662,y:794,t:1527023353941};\\\", \\\"{x:1662,y:795,t:1527023353973};\\\", \\\"{x:1662,y:797,t:1527023353989};\\\", \\\"{x:1662,y:799,t:1527023354004};\\\", \\\"{x:1662,y:800,t:1527023354018};\\\", \\\"{x:1662,y:802,t:1527023354035};\\\", \\\"{x:1662,y:805,t:1527023354051};\\\", \\\"{x:1660,y:808,t:1527023354067};\\\", \\\"{x:1660,y:810,t:1527023354084};\\\", \\\"{x:1660,y:813,t:1527023354100};\\\", \\\"{x:1659,y:816,t:1527023354117};\\\", \\\"{x:1659,y:818,t:1527023354134};\\\", \\\"{x:1659,y:821,t:1527023354150};\\\", \\\"{x:1659,y:823,t:1527023354167};\\\", \\\"{x:1659,y:824,t:1527023354184};\\\", \\\"{x:1659,y:826,t:1527023354201};\\\", \\\"{x:1658,y:830,t:1527023354217};\\\", \\\"{x:1658,y:831,t:1527023354235};\\\", \\\"{x:1658,y:834,t:1527023354251};\\\", \\\"{x:1658,y:837,t:1527023354267};\\\", \\\"{x:1658,y:839,t:1527023354284};\\\", \\\"{x:1658,y:840,t:1527023354301};\\\", \\\"{x:1657,y:841,t:1527023354318};\\\", \\\"{x:1656,y:844,t:1527023354334};\\\", \\\"{x:1655,y:845,t:1527023354365};\\\", \\\"{x:1655,y:846,t:1527023354381};\\\", \\\"{x:1655,y:847,t:1527023354397};\\\", \\\"{x:1655,y:848,t:1527023354413};\\\", \\\"{x:1655,y:849,t:1527023354421};\\\", \\\"{x:1654,y:849,t:1527023354437};\\\", \\\"{x:1653,y:851,t:1527023354638};\\\", \\\"{x:1652,y:851,t:1527023354710};\\\", \\\"{x:1651,y:851,t:1527023364517};\\\", \\\"{x:1649,y:851,t:1527023364524};\\\", \\\"{x:1647,y:846,t:1527023364541};\\\", \\\"{x:1644,y:842,t:1527023364559};\\\", \\\"{x:1641,y:838,t:1527023364575};\\\", \\\"{x:1640,y:837,t:1527023364591};\\\", \\\"{x:1640,y:836,t:1527023364608};\\\", \\\"{x:1640,y:835,t:1527023364625};\\\", \\\"{x:1639,y:833,t:1527023364642};\\\", \\\"{x:1638,y:833,t:1527023364659};\\\", \\\"{x:1638,y:832,t:1527023364675};\\\", \\\"{x:1638,y:831,t:1527023364693};\\\", \\\"{x:1637,y:831,t:1527023364709};\\\", \\\"{x:1636,y:830,t:1527023365878};\\\", \\\"{x:1634,y:829,t:1527023365966};\\\", \\\"{x:1633,y:829,t:1527023366021};\\\", \\\"{x:1632,y:829,t:1527023366029};\\\", \\\"{x:1631,y:828,t:1527023367325};\\\", \\\"{x:1629,y:828,t:1527023376829};\\\", \\\"{x:1628,y:828,t:1527023376837};\\\", \\\"{x:1626,y:828,t:1527023376852};\\\", \\\"{x:1624,y:827,t:1527023376867};\\\", \\\"{x:1623,y:827,t:1527023376892};\\\", \\\"{x:1622,y:826,t:1527023376990};\\\", \\\"{x:1620,y:825,t:1527023377245};\\\", \\\"{x:1618,y:825,t:1527023377253};\\\", \\\"{x:1615,y:825,t:1527023377268};\\\", \\\"{x:1611,y:824,t:1527023377284};\\\", \\\"{x:1609,y:823,t:1527023377309};\\\", \\\"{x:1605,y:822,t:1527023383461};\\\", \\\"{x:1599,y:820,t:1527023383473};\\\", \\\"{x:1572,y:814,t:1527023383490};\\\", \\\"{x:1478,y:788,t:1527023383505};\\\", \\\"{x:1351,y:752,t:1527023383523};\\\", \\\"{x:1211,y:698,t:1527023383538};\\\", \\\"{x:1091,y:656,t:1527023383555};\\\", \\\"{x:912,y:593,t:1527023383574};\\\", \\\"{x:783,y:558,t:1527023383589};\\\", \\\"{x:664,y:542,t:1527023383605};\\\", \\\"{x:478,y:540,t:1527023383628};\\\", \\\"{x:386,y:540,t:1527023383645};\\\", \\\"{x:307,y:544,t:1527023383662};\\\", \\\"{x:253,y:548,t:1527023383678};\\\", \\\"{x:200,y:555,t:1527023383695};\\\", \\\"{x:154,y:563,t:1527023383711};\\\", \\\"{x:118,y:572,t:1527023383728};\\\", \\\"{x:80,y:588,t:1527023383746};\\\", \\\"{x:61,y:594,t:1527023383760};\\\", \\\"{x:52,y:598,t:1527023383778};\\\", \\\"{x:48,y:601,t:1527023383795};\\\", \\\"{x:46,y:602,t:1527023383812};\\\", \\\"{x:45,y:602,t:1527023383828};\\\", \\\"{x:44,y:602,t:1527023383908};\\\", \\\"{x:42,y:602,t:1527023384061};\\\", \\\"{x:39,y:602,t:1527023384069};\\\", \\\"{x:39,y:603,t:1527023384084};\\\", \\\"{x:37,y:603,t:1527023384100};\\\", \\\"{x:37,y:604,t:1527023384111};\\\", \\\"{x:36,y:604,t:1527023384129};\\\", \\\"{x:35,y:604,t:1527023384155};\\\", \\\"{x:34,y:604,t:1527023384164};\\\", \\\"{x:32,y:604,t:1527023384179};\\\", \\\"{x:18,y:598,t:1527023384196};\\\", \\\"{x:9,y:593,t:1527023384212};\\\", \\\"{x:2,y:591,t:1527023384229};\\\", \\\"{x:0,y:587,t:1527023384247};\\\", \\\"{x:0,y:585,t:1527023384262};\\\", \\\"{x:0,y:586,t:1527023384316};\\\", \\\"{x:0,y:588,t:1527023384329};\\\", \\\"{x:0,y:592,t:1527023384347};\\\", \\\"{x:0,y:593,t:1527023384363};\\\", \\\"{x:0,y:594,t:1527023384381};\\\", \\\"{x:0,y:595,t:1527023384404};\\\", \\\"{x:0,y:597,t:1527023384412};\\\", \\\"{x:0,y:600,t:1527023384429};\\\", \\\"{x:0,y:605,t:1527023384447};\\\", \\\"{x:2,y:605,t:1527023385240};\\\", \\\"{x:4,y:605,t:1527023385250};\\\", \\\"{x:6,y:604,t:1527023385267};\\\", \\\"{x:7,y:604,t:1527023385283};\\\", \\\"{x:8,y:604,t:1527023385303};\\\", \\\"{x:9,y:603,t:1527023385359};\\\", \\\"{x:12,y:601,t:1527023385408};\\\", \\\"{x:13,y:600,t:1527023385417};\\\", \\\"{x:20,y:596,t:1527023385434};\\\", \\\"{x:26,y:594,t:1527023385450};\\\", \\\"{x:30,y:593,t:1527023385467};\\\", \\\"{x:34,y:592,t:1527023385484};\\\", \\\"{x:37,y:590,t:1527023385504};\\\", \\\"{x:39,y:589,t:1527023385519};\\\", \\\"{x:42,y:589,t:1527023385535};\\\", \\\"{x:45,y:588,t:1527023385552};\\\", \\\"{x:48,y:588,t:1527023385568};\\\", \\\"{x:50,y:588,t:1527023385583};\\\", \\\"{x:51,y:588,t:1527023385614};\\\", \\\"{x:53,y:587,t:1527023385630};\\\", \\\"{x:56,y:587,t:1527023390423};\\\", \\\"{x:70,y:584,t:1527023390436};\\\", \\\"{x:99,y:581,t:1527023390455};\\\", \\\"{x:164,y:579,t:1527023390470};\\\", \\\"{x:256,y:577,t:1527023390485};\\\", \\\"{x:379,y:563,t:1527023390504};\\\", \\\"{x:454,y:552,t:1527023390520};\\\", \\\"{x:489,y:540,t:1527023390537};\\\", \\\"{x:533,y:524,t:1527023390553};\\\", \\\"{x:561,y:504,t:1527023390571};\\\", \\\"{x:592,y:491,t:1527023390586};\\\", \\\"{x:668,y:451,t:1527023390603};\\\", \\\"{x:761,y:403,t:1527023390620};\\\", \\\"{x:883,y:343,t:1527023390637};\\\", \\\"{x:1015,y:282,t:1527023390653};\\\", \\\"{x:1148,y:217,t:1527023390670};\\\", \\\"{x:1356,y:102,t:1527023390686};\\\", \\\"{x:1497,y:43,t:1527023390702};\\\", \\\"{x:1625,y:0,t:1527023390720};\\\", \\\"{x:1731,y:0,t:1527023390737};\\\", \\\"{x:1801,y:0,t:1527023390753};\\\", \\\"{x:1830,y:0,t:1527023390771};\\\", \\\"{x:1845,y:4,t:1527023390787};\\\", \\\"{x:1849,y:7,t:1527023390803};\\\", \\\"{x:1894,y:22,t:1527023390821};\\\", \\\"{x:1911,y:32,t:1527023390838};\\\", \\\"{x:1919,y:47,t:1527023390853};\\\", \\\"{x:1919,y:55,t:1527023390870};\\\", \\\"{x:1915,y:84,t:1527023390886};\\\", \\\"{x:1908,y:107,t:1527023390903};\\\", \\\"{x:1894,y:130,t:1527023390920};\\\", \\\"{x:1882,y:145,t:1527023390937};\\\", \\\"{x:1868,y:167,t:1527023390954};\\\", \\\"{x:1849,y:184,t:1527023390970};\\\", \\\"{x:1848,y:185,t:1527023390987};\\\", \\\"{x:1842,y:200,t:1527023391004};\\\", \\\"{x:1822,y:217,t:1527023391020};\\\", \\\"{x:1801,y:231,t:1527023391037};\\\", \\\"{x:1787,y:241,t:1527023391054};\\\", \\\"{x:1776,y:249,t:1527023391071};\\\", \\\"{x:1736,y:276,t:1527023391087};\\\", \\\"{x:1725,y:282,t:1527023391105};\\\", \\\"{x:1715,y:288,t:1527023391121};\\\", \\\"{x:1703,y:297,t:1527023391138};\\\", \\\"{x:1685,y:308,t:1527023391155};\\\", \\\"{x:1672,y:315,t:1527023391170};\\\", \\\"{x:1654,y:325,t:1527023391187};\\\", \\\"{x:1637,y:331,t:1527023391205};\\\", \\\"{x:1612,y:346,t:1527023391220};\\\", \\\"{x:1583,y:359,t:1527023391237};\\\", \\\"{x:1574,y:363,t:1527023391255};\\\", \\\"{x:1565,y:368,t:1527023391271};\\\", \\\"{x:1555,y:369,t:1527023391288};\\\", \\\"{x:1552,y:370,t:1527023391304};\\\", \\\"{x:1538,y:376,t:1527023391321};\\\", \\\"{x:1526,y:384,t:1527023391338};\\\", \\\"{x:1518,y:389,t:1527023391355};\\\", \\\"{x:1511,y:394,t:1527023391371};\\\", \\\"{x:1502,y:398,t:1527023391387};\\\", \\\"{x:1493,y:403,t:1527023391404};\\\", \\\"{x:1480,y:411,t:1527023391421};\\\", \\\"{x:1469,y:421,t:1527023391437};\\\", \\\"{x:1458,y:429,t:1527023391454};\\\", \\\"{x:1450,y:434,t:1527023391470};\\\", \\\"{x:1444,y:437,t:1527023391487};\\\", \\\"{x:1442,y:439,t:1527023391504};\\\", \\\"{x:1436,y:440,t:1527023391521};\\\", \\\"{x:1432,y:440,t:1527023391537};\\\", \\\"{x:1429,y:440,t:1527023391554};\\\", \\\"{x:1424,y:439,t:1527023391571};\\\", \\\"{x:1416,y:438,t:1527023391587};\\\", \\\"{x:1413,y:436,t:1527023391605};\\\", \\\"{x:1412,y:436,t:1527023391991};\\\", \\\"{x:1412,y:435,t:1527023392176};\\\", \\\"{x:1412,y:434,t:1527023392188};\\\", \\\"{x:1414,y:432,t:1527023392205};\\\", \\\"{x:1417,y:432,t:1527023392222};\\\", \\\"{x:1417,y:431,t:1527023392238};\\\", \\\"{x:1421,y:429,t:1527023392256};\\\", \\\"{x:1423,y:428,t:1527023392271};\\\", \\\"{x:1428,y:426,t:1527023392287};\\\", \\\"{x:1431,y:425,t:1527023392305};\\\", \\\"{x:1439,y:425,t:1527023392321};\\\", \\\"{x:1445,y:424,t:1527023392338};\\\", \\\"{x:1455,y:424,t:1527023392355};\\\", \\\"{x:1466,y:424,t:1527023392371};\\\", \\\"{x:1484,y:424,t:1527023392388};\\\", \\\"{x:1503,y:424,t:1527023392405};\\\", \\\"{x:1527,y:424,t:1527023392421};\\\", \\\"{x:1552,y:424,t:1527023392438};\\\", \\\"{x:1583,y:424,t:1527023392455};\\\", \\\"{x:1600,y:424,t:1527023392471};\\\", \\\"{x:1615,y:424,t:1527023392488};\\\", \\\"{x:1623,y:422,t:1527023392506};\\\", \\\"{x:1629,y:421,t:1527023392521};\\\", \\\"{x:1631,y:420,t:1527023392538};\\\", \\\"{x:1633,y:420,t:1527023392568};\\\", \\\"{x:1632,y:420,t:1527023393600};\\\", \\\"{x:1629,y:420,t:1527023393607};\\\", \\\"{x:1621,y:420,t:1527023393622};\\\", \\\"{x:1589,y:422,t:1527023393639};\\\", \\\"{x:1534,y:422,t:1527023393657};\\\", \\\"{x:1451,y:414,t:1527023393673};\\\", \\\"{x:1344,y:404,t:1527023393689};\\\", \\\"{x:1232,y:384,t:1527023393706};\\\", \\\"{x:1100,y:369,t:1527023393722};\\\", \\\"{x:970,y:369,t:1527023393739};\\\", \\\"{x:878,y:369,t:1527023393756};\\\", \\\"{x:802,y:372,t:1527023393772};\\\", \\\"{x:735,y:382,t:1527023393789};\\\", \\\"{x:683,y:393,t:1527023393806};\\\", \\\"{x:677,y:395,t:1527023393822};\\\", \\\"{x:664,y:403,t:1527023393839};\\\", \\\"{x:661,y:406,t:1527023393856};\\\", \\\"{x:655,y:413,t:1527023393872};\\\", \\\"{x:648,y:424,t:1527023393889};\\\", \\\"{x:641,y:438,t:1527023393906};\\\", \\\"{x:634,y:449,t:1527023393922};\\\", \\\"{x:622,y:462,t:1527023393940};\\\", \\\"{x:614,y:480,t:1527023393956};\\\", \\\"{x:606,y:501,t:1527023393972};\\\", \\\"{x:600,y:525,t:1527023393990};\\\", \\\"{x:598,y:543,t:1527023394008};\\\", \\\"{x:597,y:548,t:1527023394022};\\\", \\\"{x:594,y:558,t:1527023394038};\\\", \\\"{x:593,y:564,t:1527023394056};\\\", \\\"{x:591,y:567,t:1527023394073};\\\", \\\"{x:589,y:570,t:1527023394089};\\\", \\\"{x:589,y:572,t:1527023394106};\\\", \\\"{x:589,y:573,t:1527023394123};\\\", \\\"{x:589,y:572,t:1527023394287};\\\", \\\"{x:589,y:571,t:1527023394311};\\\", \\\"{x:589,y:570,t:1527023394351};\\\", \\\"{x:589,y:568,t:1527023394367};\\\", \\\"{x:589,y:567,t:1527023394375};\\\", \\\"{x:589,y:566,t:1527023394407};\\\", \\\"{x:589,y:565,t:1527023394528};\\\", \\\"{x:588,y:565,t:1527023394541};\\\", \\\"{x:585,y:564,t:1527023394556};\\\", \\\"{x:581,y:564,t:1527023394573};\\\", \\\"{x:580,y:564,t:1527023394590};\\\", \\\"{x:577,y:564,t:1527023394606};\\\", \\\"{x:575,y:563,t:1527023394624};\\\", \\\"{x:573,y:563,t:1527023394815};\\\", \\\"{x:570,y:563,t:1527023394824};\\\", \\\"{x:566,y:566,t:1527023394841};\\\", \\\"{x:563,y:570,t:1527023394858};\\\", \\\"{x:560,y:575,t:1527023394874};\\\", \\\"{x:555,y:579,t:1527023394890};\\\", \\\"{x:553,y:581,t:1527023394908};\\\", \\\"{x:552,y:582,t:1527023394925};\\\", \\\"{x:551,y:582,t:1527023395551};\\\", \\\"{x:545,y:584,t:1527023395559};\\\", \\\"{x:529,y:586,t:1527023395575};\\\", \\\"{x:506,y:590,t:1527023395590};\\\", \\\"{x:491,y:592,t:1527023395609};\\\", \\\"{x:478,y:593,t:1527023395624};\\\", \\\"{x:464,y:595,t:1527023395641};\\\", \\\"{x:461,y:595,t:1527023395657};\\\", \\\"{x:460,y:595,t:1527023395718};\\\", \\\"{x:459,y:595,t:1527023395775};\\\", \\\"{x:463,y:593,t:1527023395791};\\\", \\\"{x:485,y:590,t:1527023395808};\\\", \\\"{x:508,y:585,t:1527023395826};\\\", \\\"{x:531,y:583,t:1527023395841};\\\", \\\"{x:546,y:582,t:1527023395857};\\\", \\\"{x:572,y:582,t:1527023395874};\\\", \\\"{x:635,y:582,t:1527023395891};\\\", \\\"{x:680,y:582,t:1527023395907};\\\", \\\"{x:708,y:582,t:1527023395924};\\\", \\\"{x:727,y:582,t:1527023395942};\\\", \\\"{x:734,y:580,t:1527023395958};\\\", \\\"{x:736,y:580,t:1527023396072};\\\", \\\"{x:736,y:579,t:1527023396079};\\\", \\\"{x:737,y:578,t:1527023396092};\\\", \\\"{x:741,y:574,t:1527023396110};\\\", \\\"{x:743,y:571,t:1527023396124};\\\", \\\"{x:745,y:570,t:1527023396141};\\\", \\\"{x:759,y:559,t:1527023396158};\\\", \\\"{x:765,y:558,t:1527023396174};\\\", \\\"{x:772,y:554,t:1527023396191};\\\", \\\"{x:779,y:553,t:1527023396208};\\\", \\\"{x:784,y:553,t:1527023396224};\\\", \\\"{x:786,y:552,t:1527023396241};\\\", \\\"{x:787,y:552,t:1527023396336};\\\", \\\"{x:789,y:552,t:1527023396351};\\\", \\\"{x:790,y:552,t:1527023396359};\\\", \\\"{x:791,y:552,t:1527023396375};\\\", \\\"{x:794,y:552,t:1527023396391};\\\", \\\"{x:799,y:552,t:1527023396408};\\\", \\\"{x:801,y:552,t:1527023396426};\\\", \\\"{x:804,y:552,t:1527023396441};\\\", \\\"{x:805,y:552,t:1527023396459};\\\", \\\"{x:807,y:552,t:1527023396476};\\\", \\\"{x:811,y:552,t:1527023396491};\\\", \\\"{x:812,y:552,t:1527023396508};\\\", \\\"{x:813,y:552,t:1527023396526};\\\", \\\"{x:814,y:552,t:1527023396542};\\\", \\\"{x:815,y:552,t:1527023396600};\\\", \\\"{x:816,y:552,t:1527023396615};\\\", \\\"{x:817,y:552,t:1527023396631};\\\", \\\"{x:819,y:552,t:1527023396642};\\\", \\\"{x:820,y:552,t:1527023396679};\\\", \\\"{x:821,y:552,t:1527023396692};\\\", \\\"{x:822,y:552,t:1527023396709};\\\", \\\"{x:823,y:552,t:1527023396726};\\\", \\\"{x:825,y:552,t:1527023396743};\\\", \\\"{x:826,y:552,t:1527023396767};\\\", \\\"{x:827,y:552,t:1527023396784};\\\", \\\"{x:828,y:552,t:1527023396798};\\\", \\\"{x:829,y:552,t:1527023396830};\\\", \\\"{x:830,y:552,t:1527023396927};\\\", \\\"{x:831,y:552,t:1527023396991};\\\", \\\"{x:832,y:552,t:1527023397063};\\\", \\\"{x:833,y:552,t:1527023397103};\\\", \\\"{x:834,y:552,t:1527023397111};\\\", \\\"{x:835,y:552,t:1527023397239};\\\", \\\"{x:836,y:552,t:1527023397271};\\\", \\\"{x:837,y:552,t:1527023397303};\\\", \\\"{x:838,y:552,t:1527023397359};\\\", \\\"{x:839,y:552,t:1527023397391};\\\", \\\"{x:840,y:552,t:1527023397407};\\\", \\\"{x:841,y:552,t:1527023397439};\\\", \\\"{x:843,y:552,t:1527023398080};\\\", \\\"{x:844,y:552,t:1527023398175};\\\", \\\"{x:847,y:550,t:1527023413415};\\\", \\\"{x:849,y:550,t:1527023413423};\\\", \\\"{x:853,y:547,t:1527023413434};\\\", \\\"{x:870,y:542,t:1527023413451};\\\", \\\"{x:887,y:531,t:1527023413469};\\\", \\\"{x:920,y:513,t:1527023413489};\\\", \\\"{x:936,y:498,t:1527023413505};\\\", \\\"{x:949,y:487,t:1527023413522};\\\", \\\"{x:955,y:479,t:1527023413538};\\\", \\\"{x:959,y:476,t:1527023413555};\\\", \\\"{x:966,y:469,t:1527023413572};\\\", \\\"{x:970,y:466,t:1527023413589};\\\", \\\"{x:977,y:456,t:1527023413605};\\\", \\\"{x:1006,y:438,t:1527023413623};\\\", \\\"{x:1044,y:430,t:1527023413638};\\\", \\\"{x:1128,y:427,t:1527023413655};\\\", \\\"{x:1231,y:427,t:1527023413672};\\\", \\\"{x:1345,y:430,t:1527023413690};\\\", \\\"{x:1457,y:450,t:1527023413706};\\\", \\\"{x:1586,y:484,t:1527023413722};\\\", \\\"{x:1693,y:525,t:1527023413739};\\\", \\\"{x:1772,y:552,t:1527023413755};\\\", \\\"{x:1827,y:568,t:1527023413772};\\\", \\\"{x:1864,y:584,t:1527023413789};\\\", \\\"{x:1879,y:590,t:1527023413806};\\\", \\\"{x:1880,y:590,t:1527023413839};\\\", \\\"{x:1880,y:591,t:1527023413856};\\\", \\\"{x:1879,y:592,t:1527023413872};\\\", \\\"{x:1874,y:596,t:1527023413888};\\\", \\\"{x:1867,y:596,t:1527023413905};\\\", \\\"{x:1854,y:594,t:1527023413922};\\\", \\\"{x:1837,y:588,t:1527023413938};\\\", \\\"{x:1826,y:580,t:1527023413955};\\\", \\\"{x:1810,y:567,t:1527023413973};\\\", \\\"{x:1791,y:544,t:1527023413988};\\\", \\\"{x:1770,y:515,t:1527023414005};\\\", \\\"{x:1751,y:480,t:1527023414021};\\\", \\\"{x:1716,y:435,t:1527023414039};\\\", \\\"{x:1708,y:423,t:1527023414056};\\\", \\\"{x:1706,y:421,t:1527023414071};\\\", \\\"{x:1704,y:421,t:1527023414184};\\\", \\\"{x:1699,y:421,t:1527023414191};\\\", \\\"{x:1692,y:427,t:1527023414205};\\\", \\\"{x:1675,y:442,t:1527023414221};\\\", \\\"{x:1652,y:463,t:1527023414238};\\\", \\\"{x:1635,y:484,t:1527023414255};\\\", \\\"{x:1619,y:507,t:1527023414271};\\\", \\\"{x:1608,y:531,t:1527023414289};\\\", \\\"{x:1600,y:547,t:1527023414305};\\\", \\\"{x:1592,y:568,t:1527023414321};\\\", \\\"{x:1585,y:584,t:1527023414338};\\\", \\\"{x:1581,y:602,t:1527023414354};\\\", \\\"{x:1578,y:614,t:1527023414371};\\\", \\\"{x:1574,y:625,t:1527023414388};\\\", \\\"{x:1571,y:631,t:1527023414404};\\\", \\\"{x:1570,y:635,t:1527023414422};\\\", \\\"{x:1566,y:648,t:1527023414439};\\\", \\\"{x:1563,y:658,t:1527023414454};\\\", \\\"{x:1555,y:674,t:1527023414471};\\\", \\\"{x:1547,y:690,t:1527023414488};\\\", \\\"{x:1544,y:695,t:1527023414504};\\\", \\\"{x:1539,y:705,t:1527023414521};\\\", \\\"{x:1532,y:714,t:1527023414539};\\\", \\\"{x:1520,y:725,t:1527023414554};\\\", \\\"{x:1511,y:738,t:1527023414572};\\\", \\\"{x:1493,y:762,t:1527023414589};\\\", \\\"{x:1474,y:784,t:1527023414604};\\\", \\\"{x:1453,y:807,t:1527023414621};\\\", \\\"{x:1437,y:826,t:1527023414637};\\\", \\\"{x:1422,y:843,t:1527023414655};\\\", \\\"{x:1419,y:850,t:1527023414671};\\\", \\\"{x:1418,y:854,t:1527023414688};\\\", \\\"{x:1416,y:857,t:1527023414705};\\\", \\\"{x:1415,y:860,t:1527023414722};\\\", \\\"{x:1413,y:864,t:1527023414737};\\\", \\\"{x:1409,y:869,t:1527023414755};\\\", \\\"{x:1403,y:877,t:1527023414771};\\\", \\\"{x:1396,y:892,t:1527023414787};\\\", \\\"{x:1389,y:900,t:1527023414804};\\\", \\\"{x:1384,y:910,t:1527023414822};\\\", \\\"{x:1380,y:921,t:1527023414838};\\\", \\\"{x:1376,y:929,t:1527023414855};\\\", \\\"{x:1373,y:933,t:1527023414871};\\\", \\\"{x:1369,y:939,t:1527023414888};\\\", \\\"{x:1367,y:942,t:1527023414905};\\\", \\\"{x:1366,y:944,t:1527023414921};\\\", \\\"{x:1365,y:946,t:1527023414937};\\\", \\\"{x:1364,y:947,t:1527023414954};\\\", \\\"{x:1363,y:949,t:1527023414971};\\\", \\\"{x:1362,y:951,t:1527023414988};\\\", \\\"{x:1361,y:952,t:1527023415023};\\\", \\\"{x:1361,y:953,t:1527023415071};\\\", \\\"{x:1360,y:955,t:1527023415087};\\\", \\\"{x:1359,y:956,t:1527023415111};\\\", \\\"{x:1358,y:957,t:1527023415120};\\\", \\\"{x:1357,y:958,t:1527023415138};\\\", \\\"{x:1356,y:960,t:1527023415154};\\\", \\\"{x:1355,y:961,t:1527023415171};\\\", \\\"{x:1353,y:962,t:1527023415187};\\\", \\\"{x:1352,y:963,t:1527023415207};\\\", \\\"{x:1351,y:964,t:1527023415255};\\\", \\\"{x:1348,y:964,t:1527023423168};\\\", \\\"{x:1323,y:961,t:1527023423179};\\\", \\\"{x:1250,y:936,t:1527023423196};\\\", \\\"{x:1144,y:897,t:1527023423211};\\\", \\\"{x:1003,y:862,t:1527023423227};\\\", \\\"{x:868,y:824,t:1527023423245};\\\", \\\"{x:747,y:797,t:1527023423261};\\\", \\\"{x:641,y:760,t:1527023423278};\\\", \\\"{x:555,y:737,t:1527023423295};\\\", \\\"{x:491,y:710,t:1527023423312};\\\", \\\"{x:460,y:702,t:1527023423327};\\\", \\\"{x:440,y:695,t:1527023423343};\\\", \\\"{x:428,y:685,t:1527023423358};\\\", \\\"{x:417,y:678,t:1527023423375};\\\", \\\"{x:411,y:675,t:1527023423392};\\\", \\\"{x:409,y:673,t:1527023423409};\\\", \\\"{x:407,y:671,t:1527023423424};\\\", \\\"{x:407,y:670,t:1527023423442};\\\", \\\"{x:407,y:668,t:1527023423478};\\\", \\\"{x:407,y:667,t:1527023423491};\\\", \\\"{x:407,y:666,t:1527023423508};\\\", \\\"{x:407,y:665,t:1527023423525};\\\", \\\"{x:407,y:664,t:1527023423559};\\\", \\\"{x:408,y:663,t:1527023423631};\\\", \\\"{x:409,y:663,t:1527023423665};\\\", \\\"{x:410,y:663,t:1527023423710};\\\", \\\"{x:412,y:661,t:1527023423725};\\\", \\\"{x:417,y:659,t:1527023423742};\\\", \\\"{x:423,y:658,t:1527023423758};\\\", \\\"{x:433,y:657,t:1527023423775};\\\", \\\"{x:449,y:656,t:1527023423792};\\\", \\\"{x:470,y:656,t:1527023423808};\\\", \\\"{x:504,y:656,t:1527023423826};\\\", \\\"{x:582,y:656,t:1527023423842};\\\", \\\"{x:675,y:664,t:1527023423859};\\\", \\\"{x:781,y:678,t:1527023423875};\\\", \\\"{x:886,y:678,t:1527023423893};\\\", \\\"{x:969,y:678,t:1527023423910};\\\", \\\"{x:1045,y:665,t:1527023423926};\\\", \\\"{x:1117,y:638,t:1527023423942};\\\", \\\"{x:1142,y:625,t:1527023423960};\\\", \\\"{x:1163,y:616,t:1527023423975};\\\", \\\"{x:1181,y:608,t:1527023423993};\\\", \\\"{x:1200,y:598,t:1527023424010};\\\", \\\"{x:1212,y:590,t:1527023424026};\\\", \\\"{x:1237,y:579,t:1527023424043};\\\", \\\"{x:1259,y:570,t:1527023424060};\\\", \\\"{x:1285,y:559,t:1527023424076};\\\", \\\"{x:1306,y:547,t:1527023424093};\\\", \\\"{x:1328,y:536,t:1527023424110};\\\", \\\"{x:1347,y:529,t:1527023424126};\\\", \\\"{x:1356,y:527,t:1527023424143};\\\", \\\"{x:1360,y:526,t:1527023424160};\\\", \\\"{x:1367,y:525,t:1527023424178};\\\", \\\"{x:1372,y:525,t:1527023424193};\\\", \\\"{x:1377,y:525,t:1527023424210};\\\", \\\"{x:1387,y:525,t:1527023424227};\\\", \\\"{x:1392,y:525,t:1527023424244};\\\", \\\"{x:1400,y:529,t:1527023424260};\\\", \\\"{x:1407,y:541,t:1527023424277};\\\", \\\"{x:1414,y:568,t:1527023424295};\\\", \\\"{x:1418,y:603,t:1527023424311};\\\", \\\"{x:1426,y:687,t:1527023424327};\\\", \\\"{x:1433,y:721,t:1527023424344};\\\", \\\"{x:1434,y:756,t:1527023424360};\\\", \\\"{x:1434,y:781,t:1527023424376};\\\", \\\"{x:1437,y:800,t:1527023424394};\\\", \\\"{x:1437,y:810,t:1527023424411};\\\", \\\"{x:1437,y:815,t:1527023424427};\\\", \\\"{x:1437,y:821,t:1527023424444};\\\", \\\"{x:1437,y:829,t:1527023424461};\\\", \\\"{x:1437,y:840,t:1527023424477};\\\", \\\"{x:1439,y:853,t:1527023424494};\\\", \\\"{x:1442,y:867,t:1527023424511};\\\", \\\"{x:1443,y:875,t:1527023424527};\\\", \\\"{x:1444,y:881,t:1527023424544};\\\", \\\"{x:1444,y:888,t:1527023424561};\\\", \\\"{x:1447,y:897,t:1527023424578};\\\", \\\"{x:1447,y:903,t:1527023424595};\\\", \\\"{x:1448,y:909,t:1527023424611};\\\", \\\"{x:1448,y:917,t:1527023424628};\\\", \\\"{x:1448,y:925,t:1527023424645};\\\", \\\"{x:1450,y:930,t:1527023424662};\\\", \\\"{x:1450,y:936,t:1527023424678};\\\", \\\"{x:1451,y:944,t:1527023424695};\\\", \\\"{x:1451,y:949,t:1527023424710};\\\", \\\"{x:1451,y:951,t:1527023424759};\\\", \\\"{x:1451,y:952,t:1527023424783};\\\", \\\"{x:1450,y:952,t:1527023424799};\\\", \\\"{x:1444,y:952,t:1527023424811};\\\", \\\"{x:1436,y:952,t:1527023424828};\\\", \\\"{x:1434,y:952,t:1527023424845};\\\", \\\"{x:1434,y:953,t:1527023425743};\\\", \\\"{x:1434,y:954,t:1527023425840};\\\", \\\"{x:1434,y:955,t:1527023425976};\\\", \\\"{x:1435,y:956,t:1527023425999};\\\", \\\"{x:1436,y:956,t:1527023426039};\\\", \\\"{x:1437,y:957,t:1527023426055};\\\", \\\"{x:1438,y:957,t:1527023426070};\\\", \\\"{x:1439,y:958,t:1527023426119};\\\", \\\"{x:1440,y:959,t:1527023426130};\\\", \\\"{x:1441,y:960,t:1527023426147};\\\", \\\"{x:1442,y:960,t:1527023426164};\\\", \\\"{x:1443,y:961,t:1527023426183};\\\", \\\"{x:1443,y:962,t:1527023426198};\\\", \\\"{x:1445,y:962,t:1527023426215};\\\", \\\"{x:1447,y:964,t:1527023426231};\\\", \\\"{x:1448,y:965,t:1527023426247};\\\", \\\"{x:1450,y:966,t:1527023426266};\\\", \\\"{x:1450,y:967,t:1527023426282};\\\", \\\"{x:1451,y:967,t:1527023426311};\\\", \\\"{x:1452,y:968,t:1527023426327};\\\", \\\"{x:1453,y:969,t:1527023426335};\\\", \\\"{x:1454,y:970,t:1527023426367};\\\", \\\"{x:1455,y:970,t:1527023426463};\\\", \\\"{x:1455,y:971,t:1527023426495};\\\", \\\"{x:1456,y:971,t:1527023426567};\\\", \\\"{x:1458,y:971,t:1527023426647};\\\", \\\"{x:1461,y:971,t:1527023426665};\\\", \\\"{x:1462,y:971,t:1527023426682};\\\", \\\"{x:1465,y:971,t:1527023426698};\\\", \\\"{x:1467,y:971,t:1527023426715};\\\", \\\"{x:1470,y:971,t:1527023426732};\\\", \\\"{x:1472,y:971,t:1527023426748};\\\", \\\"{x:1474,y:973,t:1527023426765};\\\", \\\"{x:1476,y:974,t:1527023426782};\\\", \\\"{x:1477,y:974,t:1527023426807};\\\", \\\"{x:1475,y:974,t:1527023426855};\\\", \\\"{x:1474,y:974,t:1527023426866};\\\", \\\"{x:1470,y:973,t:1527023426882};\\\", \\\"{x:1465,y:973,t:1527023426899};\\\", \\\"{x:1463,y:972,t:1527023426915};\\\", \\\"{x:1461,y:972,t:1527023426992};\\\", \\\"{x:1460,y:972,t:1527023426999};\\\", \\\"{x:1459,y:973,t:1527023427016};\\\", \\\"{x:1456,y:973,t:1527023427032};\\\", \\\"{x:1454,y:973,t:1527023427049};\\\", \\\"{x:1452,y:973,t:1527023427067};\\\", \\\"{x:1451,y:973,t:1527023427082};\\\", \\\"{x:1450,y:973,t:1527023427100};\\\", \\\"{x:1448,y:973,t:1527023427116};\\\", \\\"{x:1446,y:973,t:1527023427132};\\\", \\\"{x:1443,y:973,t:1527023427149};\\\", \\\"{x:1438,y:973,t:1527023427166};\\\", \\\"{x:1433,y:973,t:1527023427182};\\\", \\\"{x:1427,y:973,t:1527023427199};\\\", \\\"{x:1426,y:973,t:1527023427216};\\\", \\\"{x:1423,y:974,t:1527023427233};\\\", \\\"{x:1422,y:974,t:1527023427249};\\\", \\\"{x:1418,y:974,t:1527023427266};\\\", \\\"{x:1409,y:976,t:1527023427283};\\\", \\\"{x:1404,y:977,t:1527023427299};\\\", \\\"{x:1400,y:977,t:1527023427316};\\\", \\\"{x:1396,y:977,t:1527023427333};\\\", \\\"{x:1394,y:977,t:1527023427376};\\\", \\\"{x:1392,y:977,t:1527023427383};\\\", \\\"{x:1385,y:977,t:1527023427400};\\\", \\\"{x:1380,y:977,t:1527023427416};\\\", \\\"{x:1374,y:977,t:1527023427434};\\\", \\\"{x:1370,y:977,t:1527023427450};\\\", \\\"{x:1368,y:977,t:1527023427467};\\\", \\\"{x:1367,y:977,t:1527023427483};\\\", \\\"{x:1366,y:977,t:1527023427535};\\\", \\\"{x:1364,y:977,t:1527023427550};\\\", \\\"{x:1359,y:976,t:1527023427567};\\\", \\\"{x:1358,y:976,t:1527023427599};\\\", \\\"{x:1357,y:976,t:1527023427607};\\\", \\\"{x:1357,y:975,t:1527023427617};\\\", \\\"{x:1357,y:974,t:1527023427633};\\\", \\\"{x:1356,y:974,t:1527023427650};\\\", \\\"{x:1355,y:973,t:1527023427667};\\\", \\\"{x:1355,y:969,t:1527023427683};\\\", \\\"{x:1353,y:969,t:1527023427700};\\\", \\\"{x:1353,y:968,t:1527023427717};\\\", \\\"{x:1352,y:968,t:1527023427733};\\\", \\\"{x:1352,y:967,t:1527023427750};\\\", \\\"{x:1350,y:966,t:1527023427767};\\\", \\\"{x:1348,y:965,t:1527023427784};\\\", \\\"{x:1344,y:964,t:1527023427801};\\\", \\\"{x:1341,y:963,t:1527023427817};\\\", \\\"{x:1337,y:962,t:1527023427834};\\\", \\\"{x:1336,y:962,t:1527023427850};\\\", \\\"{x:1336,y:961,t:1527023427991};\\\", \\\"{x:1336,y:960,t:1527023428023};\\\", \\\"{x:1336,y:959,t:1527023428319};\\\", \\\"{x:1337,y:958,t:1527023428335};\\\", \\\"{x:1338,y:957,t:1527023428535};\\\", \\\"{x:1339,y:957,t:1527023428552};\\\", \\\"{x:1340,y:956,t:1527023428568};\\\", \\\"{x:1341,y:956,t:1527023428585};\\\", \\\"{x:1342,y:954,t:1527023428615};\\\", \\\"{x:1343,y:954,t:1527023428672};\\\", \\\"{x:1344,y:953,t:1527023428696};\\\", \\\"{x:1345,y:952,t:1527023428718};\\\", \\\"{x:1346,y:951,t:1527023428831};\\\", \\\"{x:1347,y:951,t:1527023428855};\\\", \\\"{x:1348,y:951,t:1527023428919};\\\", \\\"{x:1349,y:950,t:1527023428951};\\\", \\\"{x:1351,y:950,t:1527023429303};\\\", \\\"{x:1355,y:951,t:1527023429320};\\\", \\\"{x:1356,y:952,t:1527023429338};\\\", \\\"{x:1358,y:954,t:1527023429354};\\\", \\\"{x:1359,y:954,t:1527023429370};\\\", \\\"{x:1359,y:955,t:1527023429387};\\\", \\\"{x:1360,y:955,t:1527023429423};\\\", \\\"{x:1360,y:956,t:1527023429463};\\\", \\\"{x:1360,y:957,t:1527023429551};\\\", \\\"{x:1359,y:957,t:1527023429591};\\\", \\\"{x:1358,y:958,t:1527023429606};\\\", \\\"{x:1358,y:959,t:1527023429647};\\\", \\\"{x:1357,y:960,t:1527023429654};\\\", \\\"{x:1357,y:961,t:1527023429673};\\\", \\\"{x:1356,y:961,t:1527023429694};\\\", \\\"{x:1355,y:962,t:1527023429718};\\\", \\\"{x:1355,y:963,t:1527023429742};\\\", \\\"{x:1354,y:963,t:1527023429782};\\\", \\\"{x:1354,y:964,t:1527023429855};\\\", \\\"{x:1352,y:965,t:1527023430183};\\\", \\\"{x:1352,y:966,t:1527023430263};\\\", \\\"{x:1350,y:966,t:1527023430591};\\\", \\\"{x:1349,y:966,t:1527023430719};\\\", \\\"{x:1347,y:966,t:1527023430727};\\\", \\\"{x:1346,y:966,t:1527023430967};\\\", \\\"{x:1345,y:966,t:1527023430983};\\\", \\\"{x:1344,y:966,t:1527023431031};\\\", \\\"{x:1344,y:964,t:1527023431343};\\\", \\\"{x:1344,y:963,t:1527023431359};\\\", \\\"{x:1344,y:962,t:1527023433095};\\\", \\\"{x:1331,y:946,t:1527023433110};\\\", \\\"{x:1312,y:925,t:1527023433127};\\\", \\\"{x:1270,y:887,t:1527023433144};\\\", \\\"{x:1220,y:833,t:1527023433160};\\\", \\\"{x:1148,y:786,t:1527023433177};\\\", \\\"{x:1065,y:735,t:1527023433194};\\\", \\\"{x:1000,y:710,t:1527023433211};\\\", \\\"{x:945,y:687,t:1527023433228};\\\", \\\"{x:893,y:666,t:1527023433245};\\\", \\\"{x:855,y:653,t:1527023433261};\\\", \\\"{x:823,y:642,t:1527023433277};\\\", \\\"{x:802,y:635,t:1527023433295};\\\", \\\"{x:785,y:630,t:1527023433311};\\\", \\\"{x:771,y:626,t:1527023433327};\\\", \\\"{x:745,y:621,t:1527023433344};\\\", \\\"{x:725,y:615,t:1527023433361};\\\", \\\"{x:690,y:606,t:1527023433379};\\\", \\\"{x:632,y:603,t:1527023433394};\\\", \\\"{x:580,y:602,t:1527023433411};\\\", \\\"{x:574,y:599,t:1527023433438};\\\", \\\"{x:574,y:598,t:1527023433919};\\\", \\\"{x:565,y:594,t:1527023433926};\\\", \\\"{x:555,y:593,t:1527023433939};\\\", \\\"{x:546,y:589,t:1527023433957};\\\", \\\"{x:543,y:589,t:1527023433973};\\\", \\\"{x:538,y:589,t:1527023433990};\\\", \\\"{x:527,y:590,t:1527023434007};\\\", \\\"{x:518,y:593,t:1527023434023};\\\", \\\"{x:505,y:598,t:1527023434040};\\\", \\\"{x:495,y:598,t:1527023434058};\\\", \\\"{x:487,y:600,t:1527023434073};\\\", \\\"{x:481,y:602,t:1527023434089};\\\", \\\"{x:477,y:602,t:1527023434105};\\\", \\\"{x:470,y:605,t:1527023434123};\\\", \\\"{x:465,y:606,t:1527023434140};\\\", \\\"{x:457,y:609,t:1527023434155};\\\", \\\"{x:447,y:610,t:1527023434173};\\\", \\\"{x:429,y:611,t:1527023434190};\\\", \\\"{x:416,y:611,t:1527023434206};\\\", \\\"{x:412,y:611,t:1527023434223};\\\", \\\"{x:410,y:611,t:1527023434239};\\\", \\\"{x:408,y:611,t:1527023434295};\\\", \\\"{x:404,y:611,t:1527023434307};\\\", \\\"{x:398,y:611,t:1527023434323};\\\", \\\"{x:392,y:610,t:1527023434340};\\\", \\\"{x:391,y:610,t:1527023434358};\\\", \\\"{x:388,y:609,t:1527023434373};\\\", \\\"{x:385,y:605,t:1527023434391};\\\", \\\"{x:384,y:602,t:1527023434407};\\\", \\\"{x:383,y:600,t:1527023434423};\\\", \\\"{x:380,y:598,t:1527023434440};\\\", \\\"{x:380,y:597,t:1527023434455};\\\", \\\"{x:383,y:596,t:1527023438255};\\\", \\\"{x:386,y:599,t:1527023438262};\\\", \\\"{x:390,y:604,t:1527023438277};\\\", \\\"{x:400,y:612,t:1527023438294};\\\", \\\"{x:412,y:621,t:1527023438310};\\\", \\\"{x:416,y:625,t:1527023438326};\\\", \\\"{x:418,y:627,t:1527023438341};\\\", \\\"{x:424,y:639,t:1527023438358};\\\", \\\"{x:431,y:657,t:1527023438375};\\\", \\\"{x:436,y:672,t:1527023438393};\\\", \\\"{x:443,y:685,t:1527023438409};\\\", \\\"{x:447,y:693,t:1527023438426};\\\", \\\"{x:453,y:703,t:1527023438444};\\\", \\\"{x:459,y:709,t:1527023438460};\\\", \\\"{x:466,y:716,t:1527023438476};\\\", \\\"{x:471,y:723,t:1527023438493};\\\", \\\"{x:473,y:725,t:1527023438509};\\\", \\\"{x:475,y:727,t:1527023438526};\\\", \\\"{x:476,y:727,t:1527023438767};\\\", \\\"{x:477,y:727,t:1527023438847};\\\", \\\"{x:478,y:727,t:1527023438878};\\\", \\\"{x:479,y:727,t:1527023439358};\\\", \\\"{x:482,y:725,t:1527023439366};\\\", \\\"{x:482,y:713,t:1527023439377};\\\", \\\"{x:474,y:686,t:1527023439393};\\\", \\\"{x:461,y:651,t:1527023439410};\\\", \\\"{x:454,y:642,t:1527023439427};\\\", \\\"{x:453,y:642,t:1527023439462};\\\", \\\"{x:453,y:630,t:1527023439487};\\\", \\\"{x:457,y:611,t:1527023439494};\\\", \\\"{x:457,y:541,t:1527023439510};\\\", \\\"{x:450,y:503,t:1527023439527};\\\", \\\"{x:434,y:450,t:1527023439544};\\\", \\\"{x:425,y:401,t:1527023439561};\\\", \\\"{x:406,y:359,t:1527023439578};\\\", \\\"{x:383,y:314,t:1527023439595};\\\", \\\"{x:372,y:238,t:1527023439611};\\\", \\\"{x:371,y:218,t:1527023439627};\\\", \\\"{x:373,y:208,t:1527023440254};\\\", \\\"{x:373,y:155,t:1527023440262};\\\", \\\"{x:373,y:86,t:1527023440277};\\\", \\\"{x:377,y:0,t:1527023440295};\\\", \\\"{x:370,y:0,t:1527023440311};\\\", \\\"{x:357,y:0,t:1527023440328};\\\", \\\"{x:344,y:0,t:1527023440344};\\\", \\\"{x:327,y:0,t:1527023440361};\\\", \\\"{x:305,y:0,t:1527023440378};\\\", \\\"{x:268,y:0,t:1527023440394};\\\" ] }, { \\\"rt\\\": 17750, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 553114, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -G -C -11 AM-C -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:348,y:519,t:1527023440581};\\\", \\\"{x:548,y:659,t:1527023440611};\\\", \\\"{x:632,y:699,t:1527023440627};\\\", \\\"{x:689,y:730,t:1527023440644};\\\", \\\"{x:728,y:741,t:1527023440669};\\\", \\\"{x:730,y:741,t:1527023440678};\\\", \\\"{x:733,y:739,t:1527023441287};\\\", \\\"{x:734,y:739,t:1527023441302};\\\", \\\"{x:734,y:738,t:1527023441313};\\\", \\\"{x:738,y:737,t:1527023441330};\\\", \\\"{x:740,y:736,t:1527023441347};\\\", \\\"{x:741,y:734,t:1527023441364};\\\", \\\"{x:743,y:733,t:1527023441381};\\\", \\\"{x:748,y:729,t:1527023441397};\\\", \\\"{x:757,y:724,t:1527023441414};\\\", \\\"{x:770,y:716,t:1527023441431};\\\", \\\"{x:778,y:712,t:1527023441446};\\\", \\\"{x:783,y:712,t:1527023441463};\\\", \\\"{x:790,y:710,t:1527023441481};\\\", \\\"{x:799,y:705,t:1527023441497};\\\", \\\"{x:809,y:704,t:1527023441514};\\\", \\\"{x:829,y:701,t:1527023441531};\\\", \\\"{x:847,y:695,t:1527023441547};\\\", \\\"{x:870,y:690,t:1527023441564};\\\", \\\"{x:905,y:688,t:1527023441580};\\\", \\\"{x:930,y:682,t:1527023441597};\\\", \\\"{x:959,y:676,t:1527023441614};\\\", \\\"{x:991,y:672,t:1527023441631};\\\", \\\"{x:1009,y:672,t:1527023441648};\\\", \\\"{x:1028,y:672,t:1527023441665};\\\", \\\"{x:1037,y:672,t:1527023441680};\\\", \\\"{x:1038,y:672,t:1527023441703};\\\", \\\"{x:1039,y:672,t:1527023442239};\\\", \\\"{x:1040,y:672,t:1527023442327};\\\", \\\"{x:1042,y:672,t:1527023442367};\\\", \\\"{x:1043,y:672,t:1527023442407};\\\", \\\"{x:1043,y:671,t:1527023442416};\\\", \\\"{x:1044,y:670,t:1527023442433};\\\", \\\"{x:1045,y:669,t:1527023442478};\\\", \\\"{x:1046,y:668,t:1527023443135};\\\", \\\"{x:1047,y:667,t:1527023443151};\\\", \\\"{x:1050,y:665,t:1527023443167};\\\", \\\"{x:1054,y:662,t:1527023443184};\\\", \\\"{x:1056,y:662,t:1527023443201};\\\", \\\"{x:1058,y:661,t:1527023443218};\\\", \\\"{x:1060,y:660,t:1527023443235};\\\", \\\"{x:1062,y:660,t:1527023443254};\\\", \\\"{x:1064,y:660,t:1527023443268};\\\", \\\"{x:1066,y:660,t:1527023443285};\\\", \\\"{x:1071,y:660,t:1527023443302};\\\", \\\"{x:1083,y:660,t:1527023443318};\\\", \\\"{x:1093,y:660,t:1527023443335};\\\", \\\"{x:1100,y:657,t:1527023443991};\\\", \\\"{x:1111,y:652,t:1527023444003};\\\", \\\"{x:1135,y:637,t:1527023444020};\\\", \\\"{x:1157,y:630,t:1527023444038};\\\", \\\"{x:1174,y:621,t:1527023444054};\\\", \\\"{x:1196,y:618,t:1527023444070};\\\", \\\"{x:1230,y:612,t:1527023444086};\\\", \\\"{x:1245,y:609,t:1527023444103};\\\", \\\"{x:1267,y:603,t:1527023444119};\\\", \\\"{x:1283,y:598,t:1527023444136};\\\", \\\"{x:1300,y:594,t:1527023444153};\\\", \\\"{x:1327,y:591,t:1527023444169};\\\", \\\"{x:1360,y:588,t:1527023444186};\\\", \\\"{x:1421,y:589,t:1527023444203};\\\", \\\"{x:1456,y:594,t:1527023444220};\\\", \\\"{x:1501,y:596,t:1527023444236};\\\", \\\"{x:1537,y:596,t:1527023444253};\\\", \\\"{x:1561,y:598,t:1527023444271};\\\", \\\"{x:1566,y:601,t:1527023444287};\\\", \\\"{x:1568,y:602,t:1527023444303};\\\", \\\"{x:1568,y:607,t:1527023444321};\\\", \\\"{x:1566,y:611,t:1527023444337};\\\", \\\"{x:1557,y:626,t:1527023444354};\\\", \\\"{x:1541,y:644,t:1527023444371};\\\", \\\"{x:1525,y:663,t:1527023444387};\\\", \\\"{x:1517,y:672,t:1527023444404};\\\", \\\"{x:1497,y:686,t:1527023444421};\\\", \\\"{x:1481,y:695,t:1527023444438};\\\", \\\"{x:1462,y:700,t:1527023444454};\\\", \\\"{x:1450,y:710,t:1527023444471};\\\", \\\"{x:1442,y:712,t:1527023444488};\\\", \\\"{x:1435,y:713,t:1527023444505};\\\", \\\"{x:1426,y:715,t:1527023444521};\\\", \\\"{x:1417,y:715,t:1527023444538};\\\", \\\"{x:1407,y:715,t:1527023444555};\\\", \\\"{x:1389,y:719,t:1527023444571};\\\", \\\"{x:1377,y:727,t:1527023444588};\\\", \\\"{x:1361,y:735,t:1527023444605};\\\", \\\"{x:1354,y:739,t:1527023444622};\\\", \\\"{x:1345,y:742,t:1527023444638};\\\", \\\"{x:1331,y:744,t:1527023444655};\\\", \\\"{x:1325,y:746,t:1527023444676};\\\", \\\"{x:1321,y:746,t:1527023444691};\\\", \\\"{x:1320,y:747,t:1527023444713};\\\", \\\"{x:1319,y:747,t:1527023444726};\\\", \\\"{x:1318,y:747,t:1527023444745};\\\", \\\"{x:1316,y:747,t:1527023444758};\\\", \\\"{x:1308,y:747,t:1527023444775};\\\", \\\"{x:1297,y:747,t:1527023444792};\\\", \\\"{x:1291,y:747,t:1527023444808};\\\", \\\"{x:1285,y:746,t:1527023444825};\\\", \\\"{x:1284,y:744,t:1527023444842};\\\", \\\"{x:1282,y:742,t:1527023444865};\\\", \\\"{x:1281,y:741,t:1527023444875};\\\", \\\"{x:1277,y:736,t:1527023444892};\\\", \\\"{x:1279,y:735,t:1527023444930};\\\", \\\"{x:1281,y:733,t:1527023444943};\\\", \\\"{x:1286,y:729,t:1527023444959};\\\", \\\"{x:1290,y:726,t:1527023444976};\\\", \\\"{x:1299,y:720,t:1527023444992};\\\", \\\"{x:1309,y:711,t:1527023445009};\\\", \\\"{x:1319,y:697,t:1527023445026};\\\", \\\"{x:1326,y:685,t:1527023445042};\\\", \\\"{x:1333,y:674,t:1527023445060};\\\", \\\"{x:1337,y:664,t:1527023445076};\\\", \\\"{x:1344,y:647,t:1527023445092};\\\", \\\"{x:1349,y:628,t:1527023445110};\\\", \\\"{x:1359,y:603,t:1527023445126};\\\", \\\"{x:1364,y:555,t:1527023445142};\\\", \\\"{x:1370,y:529,t:1527023445159};\\\", \\\"{x:1373,y:518,t:1527023445176};\\\", \\\"{x:1377,y:508,t:1527023445194};\\\", \\\"{x:1381,y:500,t:1527023445209};\\\", \\\"{x:1391,y:480,t:1527023445226};\\\", \\\"{x:1399,y:468,t:1527023445244};\\\", \\\"{x:1407,y:458,t:1527023445260};\\\", \\\"{x:1416,y:448,t:1527023445276};\\\", \\\"{x:1434,y:436,t:1527023445293};\\\", \\\"{x:1453,y:424,t:1527023445309};\\\", \\\"{x:1468,y:414,t:1527023445327};\\\", \\\"{x:1478,y:407,t:1527023445344};\\\", \\\"{x:1483,y:406,t:1527023445361};\\\", \\\"{x:1487,y:406,t:1527023445377};\\\", \\\"{x:1488,y:406,t:1527023445394};\\\", \\\"{x:1496,y:406,t:1527023445410};\\\", \\\"{x:1499,y:406,t:1527023445427};\\\", \\\"{x:1506,y:407,t:1527023445444};\\\", \\\"{x:1511,y:411,t:1527023445461};\\\", \\\"{x:1529,y:419,t:1527023445478};\\\", \\\"{x:1552,y:432,t:1527023445494};\\\", \\\"{x:1572,y:445,t:1527023445511};\\\", \\\"{x:1599,y:463,t:1527023445528};\\\", \\\"{x:1620,y:475,t:1527023445544};\\\", \\\"{x:1637,y:484,t:1527023445561};\\\", \\\"{x:1649,y:493,t:1527023445578};\\\", \\\"{x:1665,y:512,t:1527023445594};\\\", \\\"{x:1667,y:543,t:1527023445610};\\\", \\\"{x:1667,y:613,t:1527023445628};\\\", \\\"{x:1650,y:671,t:1527023445645};\\\", \\\"{x:1647,y:711,t:1527023445661};\\\", \\\"{x:1647,y:737,t:1527023445678};\\\", \\\"{x:1651,y:759,t:1527023445697};\\\", \\\"{x:1655,y:779,t:1527023445712};\\\", \\\"{x:1655,y:793,t:1527023445727};\\\", \\\"{x:1654,y:808,t:1527023445744};\\\", \\\"{x:1654,y:823,t:1527023445761};\\\", \\\"{x:1653,y:833,t:1527023445777};\\\", \\\"{x:1653,y:848,t:1527023445794};\\\", \\\"{x:1654,y:860,t:1527023445811};\\\", \\\"{x:1654,y:865,t:1527023445827};\\\", \\\"{x:1654,y:868,t:1527023445844};\\\", \\\"{x:1655,y:870,t:1527023445861};\\\", \\\"{x:1656,y:873,t:1527023445878};\\\", \\\"{x:1656,y:877,t:1527023445895};\\\", \\\"{x:1656,y:884,t:1527023445911};\\\", \\\"{x:1655,y:892,t:1527023445929};\\\", \\\"{x:1654,y:894,t:1527023445944};\\\", \\\"{x:1651,y:897,t:1527023445961};\\\", \\\"{x:1650,y:897,t:1527023446011};\\\", \\\"{x:1646,y:900,t:1527023446029};\\\", \\\"{x:1635,y:909,t:1527023446046};\\\", \\\"{x:1613,y:920,t:1527023446061};\\\", \\\"{x:1590,y:929,t:1527023446079};\\\", \\\"{x:1566,y:932,t:1527023446096};\\\", \\\"{x:1550,y:937,t:1527023446111};\\\", \\\"{x:1539,y:938,t:1527023446129};\\\", \\\"{x:1535,y:938,t:1527023446146};\\\", \\\"{x:1532,y:938,t:1527023446164};\\\", \\\"{x:1529,y:938,t:1527023446210};\\\", \\\"{x:1526,y:938,t:1527023446218};\\\", \\\"{x:1524,y:938,t:1527023446229};\\\", \\\"{x:1515,y:939,t:1527023446246};\\\", \\\"{x:1507,y:940,t:1527023446263};\\\", \\\"{x:1496,y:942,t:1527023446279};\\\", \\\"{x:1490,y:943,t:1527023446296};\\\", \\\"{x:1484,y:943,t:1527023446312};\\\", \\\"{x:1481,y:943,t:1527023446329};\\\", \\\"{x:1479,y:943,t:1527023446346};\\\", \\\"{x:1477,y:943,t:1527023446362};\\\", \\\"{x:1474,y:943,t:1527023446379};\\\", \\\"{x:1471,y:943,t:1527023446395};\\\", \\\"{x:1467,y:943,t:1527023446412};\\\", \\\"{x:1465,y:943,t:1527023446429};\\\", \\\"{x:1460,y:943,t:1527023446445};\\\", \\\"{x:1453,y:941,t:1527023446463};\\\", \\\"{x:1448,y:940,t:1527023446481};\\\", \\\"{x:1443,y:939,t:1527023446496};\\\", \\\"{x:1441,y:938,t:1527023446513};\\\", \\\"{x:1439,y:938,t:1527023446530};\\\", \\\"{x:1437,y:937,t:1527023446547};\\\", \\\"{x:1434,y:936,t:1527023446562};\\\", \\\"{x:1433,y:935,t:1527023446595};\\\", \\\"{x:1432,y:934,t:1527023446603};\\\", \\\"{x:1431,y:932,t:1527023446613};\\\", \\\"{x:1427,y:929,t:1527023446630};\\\", \\\"{x:1420,y:923,t:1527023446647};\\\", \\\"{x:1412,y:919,t:1527023446664};\\\", \\\"{x:1404,y:913,t:1527023446681};\\\", \\\"{x:1393,y:906,t:1527023446697};\\\", \\\"{x:1382,y:898,t:1527023446714};\\\", \\\"{x:1364,y:891,t:1527023446731};\\\", \\\"{x:1354,y:888,t:1527023446747};\\\", \\\"{x:1344,y:883,t:1527023446764};\\\", \\\"{x:1337,y:878,t:1527023446781};\\\", \\\"{x:1329,y:876,t:1527023446797};\\\", \\\"{x:1321,y:874,t:1527023446814};\\\", \\\"{x:1319,y:874,t:1527023446830};\\\", \\\"{x:1312,y:872,t:1527023446847};\\\", \\\"{x:1306,y:872,t:1527023446864};\\\", \\\"{x:1301,y:871,t:1527023446881};\\\", \\\"{x:1292,y:867,t:1527023446898};\\\", \\\"{x:1286,y:865,t:1527023446914};\\\", \\\"{x:1283,y:863,t:1527023446931};\\\", \\\"{x:1283,y:862,t:1527023446978};\\\", \\\"{x:1282,y:860,t:1527023446986};\\\", \\\"{x:1278,y:858,t:1527023446998};\\\", \\\"{x:1269,y:854,t:1527023447015};\\\", \\\"{x:1257,y:848,t:1527023447031};\\\", \\\"{x:1245,y:844,t:1527023447047};\\\", \\\"{x:1236,y:841,t:1527023447064};\\\", \\\"{x:1232,y:840,t:1527023447081};\\\", \\\"{x:1231,y:840,t:1527023447146};\\\", \\\"{x:1229,y:840,t:1527023447218};\\\", \\\"{x:1228,y:840,t:1527023447250};\\\", \\\"{x:1226,y:840,t:1527023447266};\\\", \\\"{x:1225,y:840,t:1527023447291};\\\", \\\"{x:1223,y:838,t:1527023447307};\\\", \\\"{x:1222,y:838,t:1527023447315};\\\", \\\"{x:1221,y:837,t:1527023447331};\\\", \\\"{x:1220,y:836,t:1527023447354};\\\", \\\"{x:1220,y:835,t:1527023447394};\\\", \\\"{x:1217,y:834,t:1527023447402};\\\", \\\"{x:1214,y:832,t:1527023447415};\\\", \\\"{x:1212,y:831,t:1527023447432};\\\", \\\"{x:1211,y:830,t:1527023447449};\\\", \\\"{x:1210,y:830,t:1527023447474};\\\", \\\"{x:1209,y:830,t:1527023448226};\\\", \\\"{x:1210,y:838,t:1527023448235};\\\", \\\"{x:1221,y:859,t:1527023448251};\\\", \\\"{x:1234,y:882,t:1527023448267};\\\", \\\"{x:1245,y:902,t:1527023448284};\\\", \\\"{x:1256,y:920,t:1527023448301};\\\", \\\"{x:1265,y:933,t:1527023448318};\\\", \\\"{x:1273,y:944,t:1527023448334};\\\", \\\"{x:1280,y:955,t:1527023448351};\\\", \\\"{x:1285,y:961,t:1527023448368};\\\", \\\"{x:1287,y:965,t:1527023448384};\\\", \\\"{x:1290,y:970,t:1527023448401};\\\", \\\"{x:1293,y:973,t:1527023448418};\\\", \\\"{x:1293,y:976,t:1527023448435};\\\", \\\"{x:1295,y:976,t:1527023448451};\\\", \\\"{x:1295,y:977,t:1527023448467};\\\", \\\"{x:1296,y:978,t:1527023448485};\\\", \\\"{x:1294,y:978,t:1527023448602};\\\", \\\"{x:1293,y:978,t:1527023448618};\\\", \\\"{x:1292,y:978,t:1527023448635};\\\", \\\"{x:1292,y:976,t:1527023448674};\\\", \\\"{x:1292,y:974,t:1527023448685};\\\", \\\"{x:1292,y:972,t:1527023448702};\\\", \\\"{x:1291,y:971,t:1527023448719};\\\", \\\"{x:1290,y:968,t:1527023448736};\\\", \\\"{x:1287,y:965,t:1527023448752};\\\", \\\"{x:1285,y:963,t:1527023448769};\\\", \\\"{x:1284,y:961,t:1527023448785};\\\", \\\"{x:1282,y:960,t:1527023448811};\\\", \\\"{x:1281,y:959,t:1527023448819};\\\", \\\"{x:1281,y:958,t:1527023448875};\\\", \\\"{x:1281,y:956,t:1527023450458};\\\", \\\"{x:1276,y:954,t:1527023450474};\\\", \\\"{x:1248,y:941,t:1527023450490};\\\", \\\"{x:1197,y:916,t:1527023450506};\\\", \\\"{x:1150,y:897,t:1527023450522};\\\", \\\"{x:1070,y:863,t:1527023450540};\\\", \\\"{x:987,y:824,t:1527023450556};\\\", \\\"{x:908,y:778,t:1527023450573};\\\", \\\"{x:833,y:744,t:1527023450590};\\\", \\\"{x:771,y:714,t:1527023450606};\\\", \\\"{x:718,y:689,t:1527023450623};\\\", \\\"{x:702,y:675,t:1527023450639};\\\", \\\"{x:652,y:654,t:1527023450656};\\\", \\\"{x:593,y:634,t:1527023450674};\\\", \\\"{x:493,y:595,t:1527023450691};\\\", \\\"{x:440,y:570,t:1527023450707};\\\", \\\"{x:435,y:569,t:1527023450717};\\\", \\\"{x:434,y:569,t:1527023451043};\\\", \\\"{x:433,y:569,t:1527023451058};\\\", \\\"{x:431,y:567,t:1527023451082};\\\", \\\"{x:430,y:567,t:1527023451106};\\\", \\\"{x:429,y:566,t:1527023451122};\\\", \\\"{x:428,y:566,t:1527023451132};\\\", \\\"{x:424,y:565,t:1527023451150};\\\", \\\"{x:421,y:562,t:1527023451167};\\\", \\\"{x:419,y:562,t:1527023451183};\\\", \\\"{x:417,y:561,t:1527023451200};\\\", \\\"{x:416,y:561,t:1527023451235};\\\", \\\"{x:413,y:559,t:1527023451249};\\\", \\\"{x:407,y:559,t:1527023451274};\\\", \\\"{x:401,y:559,t:1527023451290};\\\", \\\"{x:398,y:559,t:1527023451308};\\\", \\\"{x:397,y:559,t:1527023451337};\\\", \\\"{x:399,y:560,t:1527023452275};\\\", \\\"{x:404,y:564,t:1527023452292};\\\", \\\"{x:410,y:569,t:1527023452309};\\\", \\\"{x:428,y:578,t:1527023452326};\\\", \\\"{x:452,y:596,t:1527023452342};\\\", \\\"{x:512,y:622,t:1527023452359};\\\", \\\"{x:610,y:656,t:1527023452375};\\\", \\\"{x:716,y:693,t:1527023452392};\\\", \\\"{x:833,y:728,t:1527023452409};\\\", \\\"{x:951,y:757,t:1527023452425};\\\", \\\"{x:1092,y:796,t:1527023452442};\\\", \\\"{x:1151,y:813,t:1527023452458};\\\", \\\"{x:1196,y:828,t:1527023452474};\\\", \\\"{x:1215,y:831,t:1527023452492};\\\", \\\"{x:1217,y:832,t:1527023452525};\\\", \\\"{x:1221,y:834,t:1527023452543};\\\", \\\"{x:1225,y:838,t:1527023452559};\\\", \\\"{x:1233,y:844,t:1527023452575};\\\", \\\"{x:1243,y:851,t:1527023452592};\\\", \\\"{x:1252,y:855,t:1527023452608};\\\", \\\"{x:1263,y:863,t:1527023452626};\\\", \\\"{x:1276,y:876,t:1527023452641};\\\", \\\"{x:1309,y:919,t:1527023452658};\\\", \\\"{x:1316,y:927,t:1527023452675};\\\", \\\"{x:1317,y:930,t:1527023452691};\\\", \\\"{x:1317,y:931,t:1527023452708};\\\", \\\"{x:1317,y:932,t:1527023452725};\\\", \\\"{x:1317,y:935,t:1527023452741};\\\", \\\"{x:1317,y:937,t:1527023452758};\\\", \\\"{x:1317,y:938,t:1527023452775};\\\", \\\"{x:1317,y:942,t:1527023452792};\\\", \\\"{x:1311,y:951,t:1527023452808};\\\", \\\"{x:1302,y:962,t:1527023452824};\\\", \\\"{x:1294,y:970,t:1527023452841};\\\", \\\"{x:1286,y:975,t:1527023452858};\\\", \\\"{x:1284,y:976,t:1527023452874};\\\", \\\"{x:1282,y:977,t:1527023452891};\\\", \\\"{x:1281,y:977,t:1527023453074};\\\", \\\"{x:1281,y:976,t:1527023453107};\\\", \\\"{x:1281,y:975,t:1527023453124};\\\", \\\"{x:1281,y:974,t:1527023453146};\\\", \\\"{x:1281,y:973,t:1527023453178};\\\", \\\"{x:1281,y:972,t:1527023453195};\\\", \\\"{x:1281,y:971,t:1527023453226};\\\", \\\"{x:1281,y:970,t:1527023453242};\\\", \\\"{x:1281,y:969,t:1527023453267};\\\", \\\"{x:1281,y:968,t:1527023453331};\\\", \\\"{x:1281,y:967,t:1527023453346};\\\", \\\"{x:1281,y:966,t:1527023453387};\\\", \\\"{x:1281,y:965,t:1527023453410};\\\", \\\"{x:1281,y:964,t:1527023453451};\\\", \\\"{x:1281,y:963,t:1527023453571};\\\", \\\"{x:1281,y:962,t:1527023453626};\\\", \\\"{x:1281,y:961,t:1527023453667};\\\", \\\"{x:1283,y:960,t:1527023457555};\\\", \\\"{x:1273,y:955,t:1527023457567};\\\", \\\"{x:1216,y:944,t:1527023457583};\\\", \\\"{x:1133,y:937,t:1527023457600};\\\", \\\"{x:1063,y:926,t:1527023457617};\\\", \\\"{x:1007,y:918,t:1527023457634};\\\", \\\"{x:950,y:905,t:1527023457650};\\\", \\\"{x:896,y:884,t:1527023457666};\\\", \\\"{x:859,y:872,t:1527023457683};\\\", \\\"{x:831,y:857,t:1527023457699};\\\", \\\"{x:794,y:841,t:1527023457716};\\\", \\\"{x:757,y:824,t:1527023457734};\\\", \\\"{x:715,y:804,t:1527023457750};\\\", \\\"{x:680,y:789,t:1527023457766};\\\", \\\"{x:654,y:776,t:1527023457783};\\\", \\\"{x:634,y:763,t:1527023457799};\\\", \\\"{x:617,y:749,t:1527023457816};\\\", \\\"{x:603,y:738,t:1527023457832};\\\", \\\"{x:592,y:727,t:1527023457849};\\\", \\\"{x:580,y:715,t:1527023457866};\\\", \\\"{x:576,y:708,t:1527023457882};\\\", \\\"{x:565,y:698,t:1527023457899};\\\", \\\"{x:546,y:692,t:1527023457917};\\\", \\\"{x:524,y:684,t:1527023457932};\\\", \\\"{x:512,y:682,t:1527023457950};\\\", \\\"{x:509,y:682,t:1527023457965};\\\", \\\"{x:507,y:682,t:1527023458010};\\\", \\\"{x:505,y:682,t:1527023458018};\\\", \\\"{x:503,y:689,t:1527023458033};\\\", \\\"{x:500,y:704,t:1527023458051};\\\", \\\"{x:498,y:720,t:1527023458065};\\\", \\\"{x:498,y:724,t:1527023458081};\\\", \\\"{x:498,y:725,t:1527023458092};\\\", \\\"{x:498,y:726,t:1527023458113};\\\", \\\"{x:499,y:727,t:1527023458602};\\\", \\\"{x:508,y:727,t:1527023458613};\\\", \\\"{x:531,y:727,t:1527023458630};\\\", \\\"{x:554,y:728,t:1527023458647};\\\", \\\"{x:579,y:730,t:1527023458664};\\\", \\\"{x:614,y:736,t:1527023458680};\\\", \\\"{x:671,y:746,t:1527023458697};\\\", \\\"{x:814,y:754,t:1527023458714};\\\", \\\"{x:916,y:766,t:1527023458729};\\\", \\\"{x:1018,y:773,t:1527023458747};\\\", \\\"{x:1104,y:785,t:1527023458764};\\\", \\\"{x:1186,y:792,t:1527023458780};\\\", \\\"{x:1222,y:799,t:1527023458797};\\\", \\\"{x:1249,y:805,t:1527023458814};\\\", \\\"{x:1271,y:811,t:1527023458830};\\\", \\\"{x:1292,y:816,t:1527023458847};\\\", \\\"{x:1302,y:818,t:1527023458864};\\\", \\\"{x:1305,y:818,t:1527023458880};\\\" ] }, { \\\"rt\\\": 15015, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 569434, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-03 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1306,y:819,t:1527023460970};\\\", \\\"{x:1314,y:819,t:1527023460988};\\\", \\\"{x:1318,y:819,t:1527023460999};\\\", \\\"{x:1322,y:819,t:1527023461015};\\\", \\\"{x:1325,y:819,t:1527023461032};\\\", \\\"{x:1331,y:819,t:1527023461049};\\\", \\\"{x:1352,y:823,t:1527023461065};\\\", \\\"{x:1419,y:843,t:1527023461081};\\\", \\\"{x:1454,y:851,t:1527023461099};\\\", \\\"{x:1473,y:861,t:1527023461115};\\\", \\\"{x:1497,y:870,t:1527023461132};\\\", \\\"{x:1516,y:879,t:1527023461149};\\\", \\\"{x:1521,y:882,t:1527023461165};\\\", \\\"{x:1524,y:887,t:1527023461182};\\\", \\\"{x:1529,y:892,t:1527023461199};\\\", \\\"{x:1533,y:902,t:1527023461215};\\\", \\\"{x:1538,y:913,t:1527023461232};\\\", \\\"{x:1542,y:920,t:1527023461249};\\\", \\\"{x:1544,y:929,t:1527023461265};\\\", \\\"{x:1547,y:933,t:1527023461282};\\\", \\\"{x:1547,y:939,t:1527023461299};\\\", \\\"{x:1548,y:944,t:1527023461317};\\\", \\\"{x:1548,y:948,t:1527023461333};\\\", \\\"{x:1548,y:953,t:1527023461349};\\\", \\\"{x:1548,y:955,t:1527023461367};\\\", \\\"{x:1548,y:957,t:1527023461382};\\\", \\\"{x:1548,y:959,t:1527023461400};\\\", \\\"{x:1548,y:961,t:1527023461416};\\\", \\\"{x:1545,y:966,t:1527023461433};\\\", \\\"{x:1544,y:971,t:1527023461450};\\\", \\\"{x:1538,y:979,t:1527023461466};\\\", \\\"{x:1538,y:985,t:1527023461484};\\\", \\\"{x:1534,y:990,t:1527023461500};\\\", \\\"{x:1532,y:998,t:1527023461517};\\\", \\\"{x:1529,y:1003,t:1527023461532};\\\", \\\"{x:1529,y:1005,t:1527023461550};\\\", \\\"{x:1529,y:1006,t:1527023461567};\\\", \\\"{x:1534,y:1006,t:1527023462098};\\\", \\\"{x:1542,y:1006,t:1527023462105};\\\", \\\"{x:1550,y:1002,t:1527023462115};\\\", \\\"{x:1567,y:998,t:1527023462132};\\\", \\\"{x:1568,y:997,t:1527023462347};\\\", \\\"{x:1569,y:996,t:1527023462354};\\\", \\\"{x:1570,y:995,t:1527023462378};\\\", \\\"{x:1571,y:994,t:1527023462385};\\\", \\\"{x:1572,y:992,t:1527023462402};\\\", \\\"{x:1573,y:992,t:1527023462417};\\\", \\\"{x:1575,y:991,t:1527023462433};\\\", \\\"{x:1580,y:988,t:1527023462450};\\\", \\\"{x:1583,y:987,t:1527023462466};\\\", \\\"{x:1587,y:985,t:1527023462484};\\\", \\\"{x:1591,y:982,t:1527023462501};\\\", \\\"{x:1593,y:981,t:1527023462518};\\\", \\\"{x:1596,y:980,t:1527023462533};\\\", \\\"{x:1597,y:979,t:1527023462550};\\\", \\\"{x:1598,y:978,t:1527023462567};\\\", \\\"{x:1599,y:977,t:1527023462594};\\\", \\\"{x:1600,y:976,t:1527023462602};\\\", \\\"{x:1601,y:975,t:1527023462617};\\\", \\\"{x:1603,y:973,t:1527023462634};\\\", \\\"{x:1603,y:972,t:1527023462658};\\\", \\\"{x:1604,y:972,t:1527023462691};\\\", \\\"{x:1604,y:971,t:1527023462701};\\\", \\\"{x:1605,y:970,t:1527023462717};\\\", \\\"{x:1608,y:968,t:1527023462734};\\\", \\\"{x:1608,y:966,t:1527023462751};\\\", \\\"{x:1609,y:965,t:1527023462787};\\\", \\\"{x:1609,y:963,t:1527023462939};\\\", \\\"{x:1609,y:962,t:1527023463203};\\\", \\\"{x:1609,y:960,t:1527023463226};\\\", \\\"{x:1609,y:959,t:1527023463379};\\\", \\\"{x:1609,y:958,t:1527023463410};\\\", \\\"{x:1608,y:958,t:1527023463418};\\\", \\\"{x:1608,y:957,t:1527023463435};\\\", \\\"{x:1607,y:956,t:1527023463451};\\\", \\\"{x:1606,y:955,t:1527023463468};\\\", \\\"{x:1604,y:953,t:1527023463539};\\\", \\\"{x:1603,y:952,t:1527023463594};\\\", \\\"{x:1602,y:952,t:1527023463651};\\\", \\\"{x:1602,y:951,t:1527023463698};\\\", \\\"{x:1601,y:950,t:1527023463730};\\\", \\\"{x:1600,y:949,t:1527023463810};\\\", \\\"{x:1600,y:948,t:1527023464395};\\\", \\\"{x:1599,y:945,t:1527023464402};\\\", \\\"{x:1597,y:940,t:1527023464418};\\\", \\\"{x:1595,y:935,t:1527023464436};\\\", \\\"{x:1590,y:927,t:1527023464452};\\\", \\\"{x:1587,y:921,t:1527023464468};\\\", \\\"{x:1582,y:914,t:1527023464486};\\\", \\\"{x:1578,y:909,t:1527023464502};\\\", \\\"{x:1578,y:903,t:1527023464519};\\\", \\\"{x:1575,y:899,t:1527023464536};\\\", \\\"{x:1570,y:892,t:1527023464551};\\\", \\\"{x:1567,y:886,t:1527023464569};\\\", \\\"{x:1564,y:880,t:1527023464586};\\\", \\\"{x:1559,y:872,t:1527023464601};\\\", \\\"{x:1553,y:858,t:1527023464618};\\\", \\\"{x:1548,y:848,t:1527023464636};\\\", \\\"{x:1545,y:836,t:1527023464652};\\\", \\\"{x:1542,y:828,t:1527023464669};\\\", \\\"{x:1536,y:820,t:1527023464686};\\\", \\\"{x:1533,y:814,t:1527023464702};\\\", \\\"{x:1529,y:808,t:1527023464719};\\\", \\\"{x:1527,y:804,t:1527023464736};\\\", \\\"{x:1526,y:800,t:1527023464753};\\\", \\\"{x:1523,y:797,t:1527023464769};\\\", \\\"{x:1522,y:794,t:1527023464786};\\\", \\\"{x:1519,y:786,t:1527023464803};\\\", \\\"{x:1514,y:778,t:1527023464819};\\\", \\\"{x:1510,y:772,t:1527023464836};\\\", \\\"{x:1507,y:765,t:1527023464853};\\\", \\\"{x:1505,y:760,t:1527023464868};\\\", \\\"{x:1501,y:751,t:1527023464886};\\\", \\\"{x:1498,y:745,t:1527023464903};\\\", \\\"{x:1496,y:736,t:1527023464918};\\\", \\\"{x:1495,y:730,t:1527023464936};\\\", \\\"{x:1491,y:719,t:1527023464952};\\\", \\\"{x:1488,y:713,t:1527023464969};\\\", \\\"{x:1483,y:699,t:1527023464985};\\\", \\\"{x:1474,y:682,t:1527023465002};\\\", \\\"{x:1470,y:672,t:1527023465019};\\\", \\\"{x:1465,y:662,t:1527023465035};\\\", \\\"{x:1463,y:655,t:1527023465052};\\\", \\\"{x:1459,y:648,t:1527023465069};\\\", \\\"{x:1452,y:640,t:1527023465086};\\\", \\\"{x:1449,y:632,t:1527023465103};\\\", \\\"{x:1445,y:624,t:1527023465119};\\\", \\\"{x:1441,y:617,t:1527023465136};\\\", \\\"{x:1436,y:610,t:1527023465153};\\\", \\\"{x:1432,y:600,t:1527023465169};\\\", \\\"{x:1427,y:594,t:1527023465186};\\\", \\\"{x:1419,y:582,t:1527023465202};\\\", \\\"{x:1415,y:575,t:1527023465220};\\\", \\\"{x:1409,y:566,t:1527023465236};\\\", \\\"{x:1405,y:560,t:1527023465252};\\\", \\\"{x:1401,y:554,t:1527023465269};\\\", \\\"{x:1397,y:551,t:1527023465285};\\\", \\\"{x:1395,y:545,t:1527023465303};\\\", \\\"{x:1393,y:541,t:1527023465320};\\\", \\\"{x:1390,y:534,t:1527023465336};\\\", \\\"{x:1385,y:528,t:1527023465353};\\\", \\\"{x:1384,y:525,t:1527023465370};\\\", \\\"{x:1381,y:521,t:1527023465385};\\\", \\\"{x:1378,y:514,t:1527023465402};\\\", \\\"{x:1376,y:512,t:1527023465420};\\\", \\\"{x:1375,y:509,t:1527023465436};\\\", \\\"{x:1374,y:507,t:1527023465453};\\\", \\\"{x:1372,y:507,t:1527023465469};\\\", \\\"{x:1368,y:505,t:1527023465485};\\\", \\\"{x:1364,y:504,t:1527023465502};\\\", \\\"{x:1364,y:503,t:1527023465519};\\\", \\\"{x:1361,y:500,t:1527023465778};\\\", \\\"{x:1358,y:497,t:1527023465786};\\\", \\\"{x:1346,y:496,t:1527023465803};\\\", \\\"{x:1340,y:496,t:1527023465819};\\\", \\\"{x:1338,y:496,t:1527023465836};\\\", \\\"{x:1329,y:496,t:1527023465853};\\\", \\\"{x:1304,y:499,t:1527023465870};\\\", \\\"{x:1275,y:504,t:1527023465886};\\\", \\\"{x:1202,y:516,t:1527023465903};\\\", \\\"{x:1104,y:530,t:1527023465920};\\\", \\\"{x:1000,y:540,t:1527023465937};\\\", \\\"{x:898,y:566,t:1527023465954};\\\", \\\"{x:761,y:595,t:1527023465970};\\\", \\\"{x:668,y:616,t:1527023465987};\\\", \\\"{x:567,y:638,t:1527023466004};\\\", \\\"{x:485,y:653,t:1527023466019};\\\", \\\"{x:416,y:673,t:1527023466037};\\\", \\\"{x:354,y:691,t:1527023466053};\\\", \\\"{x:325,y:702,t:1527023466069};\\\", \\\"{x:307,y:708,t:1527023466086};\\\", \\\"{x:293,y:709,t:1527023466103};\\\", \\\"{x:285,y:709,t:1527023466119};\\\", \\\"{x:280,y:709,t:1527023466136};\\\", \\\"{x:265,y:701,t:1527023466153};\\\", \\\"{x:260,y:695,t:1527023466170};\\\", \\\"{x:257,y:683,t:1527023466186};\\\", \\\"{x:256,y:670,t:1527023466203};\\\", \\\"{x:260,y:652,t:1527023466219};\\\", \\\"{x:270,y:636,t:1527023466238};\\\", \\\"{x:280,y:625,t:1527023466255};\\\", \\\"{x:284,y:621,t:1527023466270};\\\", \\\"{x:293,y:614,t:1527023466286};\\\", \\\"{x:294,y:613,t:1527023466303};\\\", \\\"{x:295,y:613,t:1527023466320};\\\", \\\"{x:295,y:612,t:1527023466346};\\\", \\\"{x:296,y:612,t:1527023466353};\\\", \\\"{x:297,y:612,t:1527023466377};\\\", \\\"{x:298,y:612,t:1527023466394};\\\", \\\"{x:299,y:612,t:1527023466403};\\\", \\\"{x:307,y:612,t:1527023466420};\\\", \\\"{x:325,y:612,t:1527023466436};\\\", \\\"{x:351,y:612,t:1527023466453};\\\", \\\"{x:375,y:612,t:1527023466469};\\\", \\\"{x:393,y:614,t:1527023466487};\\\", \\\"{x:400,y:615,t:1527023466504};\\\", \\\"{x:403,y:615,t:1527023466521};\\\", \\\"{x:405,y:615,t:1527023466536};\\\", \\\"{x:406,y:615,t:1527023466619};\\\", \\\"{x:412,y:615,t:1527023467203};\\\", \\\"{x:418,y:615,t:1527023467210};\\\", \\\"{x:428,y:614,t:1527023467221};\\\", \\\"{x:443,y:611,t:1527023467238};\\\", \\\"{x:457,y:608,t:1527023467254};\\\", \\\"{x:466,y:608,t:1527023467270};\\\", \\\"{x:470,y:607,t:1527023467287};\\\", \\\"{x:471,y:607,t:1527023467304};\\\", \\\"{x:473,y:607,t:1527023467329};\\\", \\\"{x:476,y:605,t:1527023467337};\\\", \\\"{x:481,y:603,t:1527023467354};\\\", \\\"{x:487,y:600,t:1527023467371};\\\", \\\"{x:492,y:599,t:1527023467387};\\\", \\\"{x:496,y:596,t:1527023467404};\\\", \\\"{x:500,y:595,t:1527023467422};\\\", \\\"{x:508,y:592,t:1527023467438};\\\", \\\"{x:515,y:591,t:1527023467454};\\\", \\\"{x:528,y:589,t:1527023467470};\\\", \\\"{x:541,y:587,t:1527023467487};\\\", \\\"{x:548,y:586,t:1527023467504};\\\", \\\"{x:554,y:584,t:1527023467521};\\\", \\\"{x:559,y:584,t:1527023467537};\\\", \\\"{x:564,y:584,t:1527023467554};\\\", \\\"{x:570,y:584,t:1527023467571};\\\", \\\"{x:572,y:582,t:1527023467588};\\\", \\\"{x:573,y:582,t:1527023467604};\\\", \\\"{x:576,y:581,t:1527023467622};\\\", \\\"{x:577,y:580,t:1527023467637};\\\", \\\"{x:580,y:578,t:1527023467654};\\\", \\\"{x:585,y:573,t:1527023467673};\\\", \\\"{x:588,y:568,t:1527023467687};\\\", \\\"{x:597,y:562,t:1527023467704};\\\", \\\"{x:611,y:551,t:1527023467721};\\\", \\\"{x:618,y:548,t:1527023467738};\\\", \\\"{x:621,y:546,t:1527023467756};\\\", \\\"{x:621,y:545,t:1527023467771};\\\", \\\"{x:622,y:545,t:1527023467787};\\\", \\\"{x:620,y:545,t:1527023468082};\\\", \\\"{x:619,y:545,t:1527023468098};\\\", \\\"{x:618,y:545,t:1527023468234};\\\", \\\"{x:617,y:546,t:1527023468290};\\\", \\\"{x:616,y:546,t:1527023468304};\\\", \\\"{x:612,y:555,t:1527023468321};\\\", \\\"{x:609,y:565,t:1527023468338};\\\", \\\"{x:608,y:570,t:1527023468354};\\\", \\\"{x:609,y:573,t:1527023469259};\\\", \\\"{x:626,y:577,t:1527023469273};\\\", \\\"{x:666,y:590,t:1527023469289};\\\", \\\"{x:742,y:613,t:1527023469306};\\\", \\\"{x:788,y:629,t:1527023469322};\\\", \\\"{x:826,y:644,t:1527023469339};\\\", \\\"{x:857,y:664,t:1527023469355};\\\", \\\"{x:887,y:682,t:1527023469373};\\\", \\\"{x:916,y:702,t:1527023469389};\\\", \\\"{x:942,y:721,t:1527023469406};\\\", \\\"{x:967,y:740,t:1527023469423};\\\", \\\"{x:1007,y:770,t:1527023469439};\\\", \\\"{x:1049,y:809,t:1527023469456};\\\", \\\"{x:1129,y:860,t:1527023469472};\\\", \\\"{x:1258,y:933,t:1527023469489};\\\", \\\"{x:1335,y:967,t:1527023469505};\\\", \\\"{x:1422,y:1000,t:1527023469522};\\\", \\\"{x:1479,y:1018,t:1527023469540};\\\", \\\"{x:1531,y:1023,t:1527023469555};\\\", \\\"{x:1572,y:1026,t:1527023469572};\\\", \\\"{x:1589,y:1026,t:1527023469589};\\\", \\\"{x:1616,y:1017,t:1527023469605};\\\", \\\"{x:1636,y:1005,t:1527023469623};\\\", \\\"{x:1641,y:996,t:1527023469640};\\\", \\\"{x:1644,y:993,t:1527023469657};\\\", \\\"{x:1644,y:992,t:1527023469673};\\\", \\\"{x:1645,y:991,t:1527023469690};\\\", \\\"{x:1645,y:989,t:1527023469787};\\\", \\\"{x:1645,y:987,t:1527023469794};\\\", \\\"{x:1643,y:982,t:1527023469807};\\\", \\\"{x:1638,y:972,t:1527023469822};\\\", \\\"{x:1624,y:966,t:1527023469840};\\\", \\\"{x:1615,y:962,t:1527023469857};\\\", \\\"{x:1614,y:961,t:1527023469874};\\\", \\\"{x:1613,y:961,t:1527023471818};\\\", \\\"{x:1612,y:961,t:1527023473498};\\\", \\\"{x:1611,y:961,t:1527023473514};\\\", \\\"{x:1610,y:961,t:1527023473546};\\\", \\\"{x:1610,y:962,t:1527023473602};\\\", \\\"{x:1608,y:962,t:1527023473610};\\\", \\\"{x:1605,y:963,t:1527023473626};\\\", \\\"{x:1597,y:967,t:1527023473643};\\\", \\\"{x:1588,y:969,t:1527023473660};\\\", \\\"{x:1583,y:973,t:1527023473675};\\\", \\\"{x:1562,y:980,t:1527023473694};\\\", \\\"{x:1537,y:984,t:1527023473710};\\\", \\\"{x:1501,y:986,t:1527023473726};\\\", \\\"{x:1445,y:986,t:1527023473743};\\\", \\\"{x:1380,y:982,t:1527023473760};\\\", \\\"{x:1282,y:969,t:1527023473776};\\\", \\\"{x:1177,y:957,t:1527023473794};\\\", \\\"{x:1067,y:941,t:1527023473810};\\\", \\\"{x:1023,y:932,t:1527023473827};\\\", \\\"{x:992,y:923,t:1527023473843};\\\", \\\"{x:964,y:915,t:1527023473860};\\\", \\\"{x:898,y:900,t:1527023473876};\\\", \\\"{x:814,y:875,t:1527023473893};\\\", \\\"{x:718,y:835,t:1527023473910};\\\", \\\"{x:609,y:796,t:1527023473926};\\\", \\\"{x:500,y:759,t:1527023473943};\\\", \\\"{x:390,y:732,t:1527023473961};\\\", \\\"{x:296,y:705,t:1527023473976};\\\", \\\"{x:241,y:692,t:1527023473993};\\\", \\\"{x:215,y:684,t:1527023474009};\\\", \\\"{x:204,y:682,t:1527023474026};\\\", \\\"{x:203,y:682,t:1527023474043};\\\", \\\"{x:203,y:681,t:1527023474106};\\\", \\\"{x:205,y:680,t:1527023474122};\\\", \\\"{x:206,y:680,t:1527023474138};\\\", \\\"{x:207,y:680,t:1527023474146};\\\", \\\"{x:209,y:680,t:1527023474160};\\\", \\\"{x:224,y:683,t:1527023474177};\\\", \\\"{x:242,y:690,t:1527023474193};\\\", \\\"{x:280,y:701,t:1527023474209};\\\", \\\"{x:321,y:713,t:1527023474227};\\\", \\\"{x:377,y:721,t:1527023474243};\\\", \\\"{x:428,y:724,t:1527023474261};\\\", \\\"{x:453,y:727,t:1527023474279};\\\", \\\"{x:464,y:727,t:1527023474293};\\\", \\\"{x:465,y:727,t:1527023474309};\\\", \\\"{x:467,y:726,t:1527023474401};\\\", \\\"{x:469,y:724,t:1527023474409};\\\", \\\"{x:471,y:723,t:1527023474421};\\\", \\\"{x:473,y:720,t:1527023474436};\\\", \\\"{x:474,y:720,t:1527023474453};\\\", \\\"{x:476,y:719,t:1527023474546};\\\", \\\"{x:478,y:718,t:1527023474570};\\\", \\\"{x:481,y:718,t:1527023474593};\\\", \\\"{x:481,y:718,t:1527023474669};\\\", \\\"{x:486,y:716,t:1527023474914};\\\", \\\"{x:501,y:716,t:1527023474927};\\\", \\\"{x:557,y:720,t:1527023474943};\\\", \\\"{x:641,y:747,t:1527023474961};\\\", \\\"{x:728,y:764,t:1527023474977};\\\", \\\"{x:848,y:788,t:1527023474993};\\\", \\\"{x:951,y:806,t:1527023475011};\\\", \\\"{x:1049,y:826,t:1527023475027};\\\", \\\"{x:1137,y:843,t:1527023475044};\\\", \\\"{x:1218,y:860,t:1527023475061};\\\", \\\"{x:1268,y:865,t:1527023475077};\\\", \\\"{x:1312,y:875,t:1527023475094};\\\", \\\"{x:1346,y:885,t:1527023475111};\\\", \\\"{x:1419,y:907,t:1527023475127};\\\", \\\"{x:1523,y:929,t:1527023475144};\\\", \\\"{x:1556,y:937,t:1527023475161};\\\", \\\"{x:1560,y:935,t:1527023475458};\\\", \\\"{x:1559,y:935,t:1527023475546};\\\", \\\"{x:1558,y:935,t:1527023475569};\\\", \\\"{x:1557,y:935,t:1527023475577};\\\", \\\"{x:1556,y:935,t:1527023475753};\\\" ] }, { \\\"rt\\\": 50223, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 620877, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-I -A -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1551,y:936,t:1527023475864};\\\", \\\"{x:1549,y:937,t:1527023475895};\\\", \\\"{x:1547,y:937,t:1527023480571};\\\", \\\"{x:1546,y:938,t:1527023481946};\\\", \\\"{x:1543,y:941,t:1527023481954};\\\", \\\"{x:1538,y:948,t:1527023481966};\\\", \\\"{x:1532,y:958,t:1527023481983};\\\", \\\"{x:1528,y:969,t:1527023482000};\\\", \\\"{x:1527,y:971,t:1527023482018};\\\", \\\"{x:1523,y:975,t:1527023482034};\\\", \\\"{x:1522,y:975,t:1527023482049};\\\", \\\"{x:1522,y:976,t:1527023484218};\\\", \\\"{x:1518,y:976,t:1527023484235};\\\", \\\"{x:1517,y:976,t:1527023484251};\\\", \\\"{x:1513,y:976,t:1527023484269};\\\", \\\"{x:1510,y:976,t:1527023484285};\\\", \\\"{x:1507,y:976,t:1527023484302};\\\", \\\"{x:1503,y:976,t:1527023484319};\\\", \\\"{x:1496,y:976,t:1527023484335};\\\", \\\"{x:1494,y:976,t:1527023484351};\\\", \\\"{x:1489,y:976,t:1527023484368};\\\", \\\"{x:1487,y:976,t:1527023484385};\\\", \\\"{x:1486,y:976,t:1527023484401};\\\", \\\"{x:1483,y:976,t:1527023484418};\\\", \\\"{x:1480,y:975,t:1527023484438};\\\", \\\"{x:1476,y:975,t:1527023484451};\\\", \\\"{x:1473,y:974,t:1527023484468};\\\", \\\"{x:1465,y:972,t:1527023484488};\\\", \\\"{x:1455,y:970,t:1527023484502};\\\", \\\"{x:1446,y:969,t:1527023484519};\\\", \\\"{x:1439,y:967,t:1527023484535};\\\", \\\"{x:1431,y:964,t:1527023484551};\\\", \\\"{x:1426,y:963,t:1527023484568};\\\", \\\"{x:1421,y:962,t:1527023484586};\\\", \\\"{x:1417,y:961,t:1527023484602};\\\", \\\"{x:1413,y:959,t:1527023484618};\\\", \\\"{x:1410,y:959,t:1527023484635};\\\", \\\"{x:1404,y:956,t:1527023484652};\\\", \\\"{x:1401,y:955,t:1527023484668};\\\", \\\"{x:1396,y:954,t:1527023484687};\\\", \\\"{x:1388,y:951,t:1527023484702};\\\", \\\"{x:1386,y:951,t:1527023484718};\\\", \\\"{x:1384,y:949,t:1527023484736};\\\", \\\"{x:1381,y:947,t:1527023484752};\\\", \\\"{x:1377,y:944,t:1527023484768};\\\", \\\"{x:1371,y:937,t:1527023484786};\\\", \\\"{x:1369,y:933,t:1527023484802};\\\", \\\"{x:1365,y:927,t:1527023484819};\\\", \\\"{x:1360,y:921,t:1527023484836};\\\", \\\"{x:1355,y:914,t:1527023484853};\\\", \\\"{x:1353,y:908,t:1527023484868};\\\", \\\"{x:1349,y:902,t:1527023484887};\\\", \\\"{x:1348,y:897,t:1527023484902};\\\", \\\"{x:1347,y:893,t:1527023484918};\\\", \\\"{x:1345,y:885,t:1527023484936};\\\", \\\"{x:1345,y:880,t:1527023484953};\\\", \\\"{x:1345,y:874,t:1527023484969};\\\", \\\"{x:1345,y:867,t:1527023484985};\\\", \\\"{x:1348,y:857,t:1527023485002};\\\", \\\"{x:1349,y:853,t:1527023485019};\\\", \\\"{x:1350,y:849,t:1527023485035};\\\", \\\"{x:1354,y:841,t:1527023485053};\\\", \\\"{x:1359,y:828,t:1527023485069};\\\", \\\"{x:1364,y:818,t:1527023485087};\\\", \\\"{x:1368,y:810,t:1527023485103};\\\", \\\"{x:1372,y:802,t:1527023485118};\\\", \\\"{x:1376,y:792,t:1527023485135};\\\", \\\"{x:1380,y:784,t:1527023485152};\\\", \\\"{x:1382,y:779,t:1527023485169};\\\", \\\"{x:1388,y:768,t:1527023485186};\\\", \\\"{x:1390,y:763,t:1527023485203};\\\", \\\"{x:1393,y:757,t:1527023485219};\\\", \\\"{x:1397,y:749,t:1527023485235};\\\", \\\"{x:1400,y:741,t:1527023485253};\\\", \\\"{x:1404,y:735,t:1527023485269};\\\", \\\"{x:1407,y:730,t:1527023485288};\\\", \\\"{x:1409,y:723,t:1527023485302};\\\", \\\"{x:1414,y:717,t:1527023485318};\\\", \\\"{x:1415,y:713,t:1527023485335};\\\", \\\"{x:1416,y:710,t:1527023485352};\\\", \\\"{x:1418,y:707,t:1527023485370};\\\", \\\"{x:1418,y:706,t:1527023485386};\\\", \\\"{x:1418,y:705,t:1527023485402};\\\", \\\"{x:1419,y:704,t:1527023485420};\\\", \\\"{x:1417,y:700,t:1527023485498};\\\", \\\"{x:1411,y:697,t:1527023485506};\\\", \\\"{x:1408,y:697,t:1527023485520};\\\", \\\"{x:1408,y:696,t:1527023485536};\\\", \\\"{x:1406,y:689,t:1527023485947};\\\", \\\"{x:1403,y:678,t:1527023485954};\\\", \\\"{x:1395,y:662,t:1527023485970};\\\", \\\"{x:1390,y:650,t:1527023485985};\\\", \\\"{x:1384,y:634,t:1527023486002};\\\", \\\"{x:1377,y:622,t:1527023486020};\\\", \\\"{x:1373,y:613,t:1527023486037};\\\", \\\"{x:1371,y:609,t:1527023486053};\\\", \\\"{x:1368,y:603,t:1527023486070};\\\", \\\"{x:1367,y:595,t:1527023486087};\\\", \\\"{x:1360,y:588,t:1527023486103};\\\", \\\"{x:1357,y:577,t:1527023486120};\\\", \\\"{x:1348,y:563,t:1527023486137};\\\", \\\"{x:1339,y:549,t:1527023486153};\\\", \\\"{x:1328,y:536,t:1527023486169};\\\", \\\"{x:1326,y:533,t:1527023486186};\\\", \\\"{x:1325,y:531,t:1527023486204};\\\", \\\"{x:1320,y:526,t:1527023486220};\\\", \\\"{x:1319,y:525,t:1527023486237};\\\", \\\"{x:1317,y:523,t:1527023486253};\\\", \\\"{x:1317,y:520,t:1527023486270};\\\", \\\"{x:1312,y:515,t:1527023486287};\\\", \\\"{x:1311,y:511,t:1527023486303};\\\", \\\"{x:1311,y:508,t:1527023486319};\\\", \\\"{x:1311,y:507,t:1527023486336};\\\", \\\"{x:1310,y:507,t:1527023486353};\\\", \\\"{x:1310,y:506,t:1527023486369};\\\", \\\"{x:1310,y:504,t:1527023486386};\\\", \\\"{x:1309,y:500,t:1527023486403};\\\", \\\"{x:1309,y:499,t:1527023486420};\\\", \\\"{x:1309,y:498,t:1527023486453};\\\", \\\"{x:1308,y:496,t:1527023486548};\\\", \\\"{x:1308,y:495,t:1527023486554};\\\", \\\"{x:1308,y:494,t:1527023486570};\\\", \\\"{x:1308,y:495,t:1527023488634};\\\", \\\"{x:1308,y:496,t:1527023488642};\\\", \\\"{x:1308,y:497,t:1527023488655};\\\", \\\"{x:1308,y:500,t:1527023488671};\\\", \\\"{x:1308,y:504,t:1527023488688};\\\", \\\"{x:1308,y:510,t:1527023488705};\\\", \\\"{x:1308,y:517,t:1527023488722};\\\", \\\"{x:1308,y:519,t:1527023488739};\\\", \\\"{x:1308,y:520,t:1527023488755};\\\", \\\"{x:1308,y:518,t:1527023488898};\\\", \\\"{x:1308,y:515,t:1527023488905};\\\", \\\"{x:1308,y:513,t:1527023488921};\\\", \\\"{x:1309,y:510,t:1527023488938};\\\", \\\"{x:1310,y:510,t:1527023488956};\\\", \\\"{x:1312,y:509,t:1527023489082};\\\", \\\"{x:1313,y:509,t:1527023489090};\\\", \\\"{x:1314,y:509,t:1527023489105};\\\", \\\"{x:1315,y:509,t:1527023489129};\\\", \\\"{x:1316,y:509,t:1527023489145};\\\", \\\"{x:1317,y:507,t:1527023489169};\\\", \\\"{x:1320,y:507,t:1527023489185};\\\", \\\"{x:1321,y:507,t:1527023489218};\\\", \\\"{x:1322,y:507,t:1527023489257};\\\", \\\"{x:1323,y:506,t:1527023489271};\\\", \\\"{x:1322,y:506,t:1527023489435};\\\", \\\"{x:1321,y:506,t:1527023489442};\\\", \\\"{x:1320,y:506,t:1527023489458};\\\", \\\"{x:1318,y:506,t:1527023489474};\\\", \\\"{x:1317,y:506,t:1527023489489};\\\", \\\"{x:1316,y:506,t:1527023489522};\\\", \\\"{x:1314,y:507,t:1527023489539};\\\", \\\"{x:1312,y:507,t:1527023489555};\\\", \\\"{x:1311,y:507,t:1527023489572};\\\", \\\"{x:1310,y:507,t:1527023489858};\\\", \\\"{x:1310,y:506,t:1527023489874};\\\", \\\"{x:1310,y:503,t:1527023489890};\\\", \\\"{x:1310,y:501,t:1527023489906};\\\", \\\"{x:1310,y:510,t:1527023503578};\\\", \\\"{x:1310,y:530,t:1527023503586};\\\", \\\"{x:1305,y:565,t:1527023503600};\\\", \\\"{x:1305,y:663,t:1527023503617};\\\", \\\"{x:1307,y:704,t:1527023503633};\\\", \\\"{x:1309,y:731,t:1527023503650};\\\", \\\"{x:1314,y:762,t:1527023503668};\\\", \\\"{x:1319,y:788,t:1527023503684};\\\", \\\"{x:1321,y:808,t:1527023503700};\\\", \\\"{x:1323,y:818,t:1527023503716};\\\", \\\"{x:1324,y:832,t:1527023503732};\\\", \\\"{x:1325,y:847,t:1527023503750};\\\", \\\"{x:1328,y:869,t:1527023503766};\\\", \\\"{x:1332,y:894,t:1527023503783};\\\", \\\"{x:1335,y:907,t:1527023503800};\\\", \\\"{x:1337,y:922,t:1527023503817};\\\", \\\"{x:1338,y:925,t:1527023503834};\\\", \\\"{x:1336,y:926,t:1527023503914};\\\", \\\"{x:1334,y:927,t:1527023503921};\\\", \\\"{x:1333,y:928,t:1527023503937};\\\", \\\"{x:1332,y:928,t:1527023503950};\\\", \\\"{x:1331,y:929,t:1527023503968};\\\", \\\"{x:1329,y:930,t:1527023503984};\\\", \\\"{x:1328,y:931,t:1527023504000};\\\", \\\"{x:1317,y:935,t:1527023504017};\\\", \\\"{x:1308,y:936,t:1527023504033};\\\", \\\"{x:1301,y:937,t:1527023504050};\\\", \\\"{x:1297,y:937,t:1527023504068};\\\", \\\"{x:1294,y:937,t:1527023504085};\\\", \\\"{x:1293,y:937,t:1527023504123};\\\", \\\"{x:1292,y:938,t:1527023504134};\\\", \\\"{x:1291,y:938,t:1527023504150};\\\", \\\"{x:1290,y:939,t:1527023504167};\\\", \\\"{x:1290,y:943,t:1527023504184};\\\", \\\"{x:1289,y:950,t:1527023504200};\\\", \\\"{x:1286,y:959,t:1527023504218};\\\", \\\"{x:1286,y:962,t:1527023504234};\\\", \\\"{x:1286,y:964,t:1527023504251};\\\", \\\"{x:1285,y:966,t:1527023504268};\\\", \\\"{x:1285,y:967,t:1527023504284};\\\", \\\"{x:1284,y:968,t:1527023504330};\\\", \\\"{x:1283,y:968,t:1527023504370};\\\", \\\"{x:1283,y:969,t:1527023504385};\\\", \\\"{x:1280,y:969,t:1527023504401};\\\", \\\"{x:1277,y:970,t:1527023504417};\\\", \\\"{x:1275,y:970,t:1527023504434};\\\", \\\"{x:1272,y:973,t:1527023504451};\\\", \\\"{x:1270,y:974,t:1527023504468};\\\", \\\"{x:1268,y:974,t:1527023504484};\\\", \\\"{x:1263,y:975,t:1527023504501};\\\", \\\"{x:1262,y:975,t:1527023504518};\\\", \\\"{x:1259,y:976,t:1527023504535};\\\", \\\"{x:1257,y:976,t:1527023504551};\\\", \\\"{x:1256,y:976,t:1527023504578};\\\", \\\"{x:1255,y:977,t:1527023504610};\\\", \\\"{x:1255,y:978,t:1527023504618};\\\", \\\"{x:1254,y:978,t:1527023504634};\\\", \\\"{x:1252,y:978,t:1527023504658};\\\", \\\"{x:1250,y:978,t:1527023504734};\\\", \\\"{x:1248,y:978,t:1527023504749};\\\", \\\"{x:1246,y:978,t:1527023504757};\\\", \\\"{x:1244,y:977,t:1527023504772};\\\", \\\"{x:1242,y:976,t:1527023504788};\\\", \\\"{x:1238,y:971,t:1527023504805};\\\", \\\"{x:1238,y:968,t:1527023504821};\\\", \\\"{x:1238,y:967,t:1527023504838};\\\", \\\"{x:1238,y:965,t:1527023504925};\\\", \\\"{x:1238,y:964,t:1527023504938};\\\", \\\"{x:1238,y:962,t:1527023504955};\\\", \\\"{x:1238,y:961,t:1527023504972};\\\", \\\"{x:1238,y:960,t:1527023504988};\\\", \\\"{x:1239,y:959,t:1527023505005};\\\", \\\"{x:1240,y:959,t:1527023505045};\\\", \\\"{x:1240,y:958,t:1527023505055};\\\", \\\"{x:1241,y:958,t:1527023505093};\\\", \\\"{x:1242,y:958,t:1527023505117};\\\", \\\"{x:1243,y:957,t:1527023505149};\\\", \\\"{x:1244,y:957,t:1527023505173};\\\", \\\"{x:1245,y:957,t:1527023505221};\\\", \\\"{x:1246,y:957,t:1527023505261};\\\", \\\"{x:1248,y:957,t:1527023505285};\\\", \\\"{x:1249,y:957,t:1527023505308};\\\", \\\"{x:1251,y:958,t:1527023505678};\\\", \\\"{x:1253,y:959,t:1527023505690};\\\", \\\"{x:1254,y:961,t:1527023505705};\\\", \\\"{x:1255,y:962,t:1527023505722};\\\", \\\"{x:1256,y:962,t:1527023506662};\\\", \\\"{x:1258,y:962,t:1527023506673};\\\", \\\"{x:1261,y:962,t:1527023506691};\\\", \\\"{x:1264,y:962,t:1527023506706};\\\", \\\"{x:1267,y:961,t:1527023506722};\\\", \\\"{x:1271,y:961,t:1527023506740};\\\", \\\"{x:1277,y:958,t:1527023506756};\\\", \\\"{x:1279,y:957,t:1527023506773};\\\", \\\"{x:1280,y:957,t:1527023506790};\\\", \\\"{x:1283,y:956,t:1527023506806};\\\", \\\"{x:1284,y:955,t:1527023506823};\\\", \\\"{x:1285,y:955,t:1527023506861};\\\", \\\"{x:1286,y:955,t:1527023506885};\\\", \\\"{x:1287,y:955,t:1527023506925};\\\", \\\"{x:1288,y:955,t:1527023506949};\\\", \\\"{x:1289,y:955,t:1527023506957};\\\", \\\"{x:1290,y:953,t:1527023506973};\\\", \\\"{x:1296,y:952,t:1527023506989};\\\", \\\"{x:1305,y:949,t:1527023507007};\\\", \\\"{x:1311,y:945,t:1527023507022};\\\", \\\"{x:1317,y:938,t:1527023507040};\\\", \\\"{x:1324,y:931,t:1527023507057};\\\", \\\"{x:1325,y:927,t:1527023507073};\\\", \\\"{x:1325,y:926,t:1527023507091};\\\", \\\"{x:1325,y:927,t:1527023507316};\\\", \\\"{x:1325,y:928,t:1527023507324};\\\", \\\"{x:1325,y:930,t:1527023507340};\\\", \\\"{x:1325,y:931,t:1527023507357};\\\", \\\"{x:1325,y:932,t:1527023507374};\\\", \\\"{x:1327,y:934,t:1527023507390};\\\", \\\"{x:1327,y:935,t:1527023507493};\\\", \\\"{x:1327,y:937,t:1527023507765};\\\", \\\"{x:1328,y:938,t:1527023507838};\\\", \\\"{x:1329,y:939,t:1527023507869};\\\", \\\"{x:1330,y:940,t:1527023507901};\\\", \\\"{x:1330,y:941,t:1527023507925};\\\", \\\"{x:1331,y:941,t:1527023507949};\\\", \\\"{x:1331,y:943,t:1527023507965};\\\", \\\"{x:1332,y:944,t:1527023508053};\\\", \\\"{x:1332,y:946,t:1527023508301};\\\", \\\"{x:1330,y:948,t:1527023508308};\\\", \\\"{x:1330,y:949,t:1527023508325};\\\", \\\"{x:1329,y:951,t:1527023508341};\\\", \\\"{x:1328,y:951,t:1527023508357};\\\", \\\"{x:1327,y:954,t:1527023508374};\\\", \\\"{x:1326,y:955,t:1527023508391};\\\", \\\"{x:1326,y:956,t:1527023508408};\\\", \\\"{x:1326,y:958,t:1527023508437};\\\", \\\"{x:1324,y:958,t:1527023508549};\\\", \\\"{x:1324,y:959,t:1527023508573};\\\", \\\"{x:1323,y:960,t:1527023508591};\\\", \\\"{x:1322,y:960,t:1527023508608};\\\", \\\"{x:1322,y:961,t:1527023508693};\\\", \\\"{x:1322,y:962,t:1527023508708};\\\", \\\"{x:1321,y:963,t:1527023508734};\\\", \\\"{x:1320,y:963,t:1527023508981};\\\", \\\"{x:1320,y:964,t:1527023508991};\\\", \\\"{x:1319,y:964,t:1527023509008};\\\", \\\"{x:1319,y:965,t:1527023509025};\\\", \\\"{x:1318,y:966,t:1527023509040};\\\", \\\"{x:1317,y:967,t:1527023509057};\\\", \\\"{x:1316,y:968,t:1527023509085};\\\", \\\"{x:1316,y:969,t:1527023509093};\\\", \\\"{x:1315,y:969,t:1527023509109};\\\", \\\"{x:1314,y:969,t:1527023509149};\\\", \\\"{x:1313,y:969,t:1527023523093};\\\", \\\"{x:1309,y:965,t:1527023523102};\\\", \\\"{x:1305,y:960,t:1527023523120};\\\", \\\"{x:1301,y:955,t:1527023523136};\\\", \\\"{x:1297,y:948,t:1527023523152};\\\", \\\"{x:1292,y:942,t:1527023523170};\\\", \\\"{x:1288,y:938,t:1527023523185};\\\", \\\"{x:1284,y:932,t:1527023523202};\\\", \\\"{x:1280,y:927,t:1527023523219};\\\", \\\"{x:1272,y:917,t:1527023523235};\\\", \\\"{x:1250,y:898,t:1527023523252};\\\", \\\"{x:1231,y:879,t:1527023523269};\\\", \\\"{x:1206,y:862,t:1527023523286};\\\", \\\"{x:1169,y:837,t:1527023523303};\\\", \\\"{x:1132,y:809,t:1527023523319};\\\", \\\"{x:1104,y:786,t:1527023523337};\\\", \\\"{x:1078,y:767,t:1527023523352};\\\", \\\"{x:1040,y:736,t:1527023523370};\\\", \\\"{x:1009,y:713,t:1527023523386};\\\", \\\"{x:983,y:694,t:1527023523403};\\\", \\\"{x:960,y:679,t:1527023523420};\\\", \\\"{x:910,y:657,t:1527023523436};\\\", \\\"{x:881,y:643,t:1527023523452};\\\", \\\"{x:858,y:629,t:1527023523469};\\\", \\\"{x:839,y:621,t:1527023523488};\\\", \\\"{x:814,y:609,t:1527023523503};\\\", \\\"{x:786,y:597,t:1527023523519};\\\", \\\"{x:753,y:590,t:1527023523536};\\\", \\\"{x:697,y:574,t:1527023523553};\\\", \\\"{x:647,y:559,t:1527023523570};\\\", \\\"{x:602,y:546,t:1527023523587};\\\", \\\"{x:542,y:530,t:1527023523603};\\\", \\\"{x:488,y:514,t:1527023523620};\\\", \\\"{x:451,y:507,t:1527023523636};\\\", \\\"{x:425,y:503,t:1527023523654};\\\", \\\"{x:407,y:502,t:1527023523670};\\\", \\\"{x:399,y:502,t:1527023523687};\\\", \\\"{x:395,y:502,t:1527023523703};\\\", \\\"{x:394,y:502,t:1527023523719};\\\", \\\"{x:392,y:501,t:1527023523737};\\\", \\\"{x:391,y:502,t:1527023523780};\\\", \\\"{x:390,y:502,t:1527023523788};\\\", \\\"{x:385,y:507,t:1527023523805};\\\", \\\"{x:381,y:513,t:1527023523821};\\\", \\\"{x:379,y:519,t:1527023523837};\\\", \\\"{x:378,y:520,t:1527023523856};\\\", \\\"{x:376,y:524,t:1527023523870};\\\", \\\"{x:375,y:526,t:1527023523888};\\\", \\\"{x:375,y:528,t:1527023523904};\\\", \\\"{x:375,y:529,t:1527023523921};\\\", \\\"{x:375,y:533,t:1527023523938};\\\", \\\"{x:375,y:535,t:1527023523954};\\\", \\\"{x:377,y:540,t:1527023524365};\\\", \\\"{x:388,y:556,t:1527023524373};\\\", \\\"{x:406,y:582,t:1527023524389};\\\", \\\"{x:434,y:612,t:1527023524405};\\\", \\\"{x:459,y:656,t:1527023524423};\\\", \\\"{x:495,y:695,t:1527023524438};\\\", \\\"{x:523,y:726,t:1527023524455};\\\", \\\"{x:540,y:746,t:1527023524470};\\\", \\\"{x:552,y:764,t:1527023524488};\\\", \\\"{x:556,y:771,t:1527023524505};\\\", \\\"{x:557,y:773,t:1527023524521};\\\", \\\"{x:558,y:774,t:1527023524537};\\\", \\\"{x:555,y:772,t:1527023524715};\\\", \\\"{x:552,y:766,t:1527023524723};\\\", \\\"{x:552,y:762,t:1527023524738};\\\", \\\"{x:547,y:755,t:1527023524754};\\\", \\\"{x:547,y:754,t:1527023524771};\\\", \\\"{x:546,y:751,t:1527023524788};\\\", \\\"{x:546,y:750,t:1527023524805};\\\", \\\"{x:545,y:747,t:1527023524821};\\\", \\\"{x:544,y:746,t:1527023524917};\\\", \\\"{x:543,y:746,t:1527023524925};\\\", \\\"{x:542,y:745,t:1527023524988};\\\", \\\"{x:541,y:745,t:1527023525013};\\\", \\\"{x:540,y:745,t:1527023525028};\\\", \\\"{x:540,y:744,t:1527023525244};\\\", \\\"{x:539,y:744,t:1527023525255};\\\", \\\"{x:538,y:744,t:1527023525272};\\\", \\\"{x:536,y:744,t:1527023525341};\\\", \\\"{x:534,y:743,t:1527023525355};\\\", \\\"{x:531,y:741,t:1527023525373};\\\", \\\"{x:530,y:741,t:1527023525388};\\\", \\\"{x:529,y:741,t:1527023525477};\\\", \\\"{x:528,y:741,t:1527023525500};\\\", \\\"{x:527,y:740,t:1527023525508};\\\", \\\"{x:525,y:740,t:1527023525613};\\\" ] }, { \\\"rt\\\": 8123, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 630283, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:738,t:1527023528236};\\\", \\\"{x:549,y:726,t:1527023528264};\\\", \\\"{x:563,y:719,t:1527023528276};\\\", \\\"{x:575,y:714,t:1527023528293};\\\", \\\"{x:579,y:712,t:1527023528307};\\\", \\\"{x:588,y:707,t:1527023528324};\\\", \\\"{x:605,y:696,t:1527023528341};\\\", \\\"{x:620,y:679,t:1527023528357};\\\", \\\"{x:649,y:671,t:1527023528375};\\\", \\\"{x:800,y:634,t:1527023528391};\\\", \\\"{x:992,y:623,t:1527023528407};\\\", \\\"{x:1213,y:616,t:1527023528424};\\\", \\\"{x:1399,y:611,t:1527023528441};\\\", \\\"{x:1497,y:607,t:1527023528457};\\\", \\\"{x:1536,y:597,t:1527023528474};\\\", \\\"{x:1557,y:589,t:1527023528492};\\\", \\\"{x:1571,y:582,t:1527023528508};\\\", \\\"{x:1571,y:580,t:1527023528709};\\\", \\\"{x:1571,y:568,t:1527023528724};\\\", \\\"{x:1565,y:556,t:1527023528741};\\\", \\\"{x:1566,y:538,t:1527023528758};\\\", \\\"{x:1571,y:525,t:1527023528775};\\\", \\\"{x:1574,y:521,t:1527023528792};\\\", \\\"{x:1575,y:521,t:1527023528809};\\\", \\\"{x:1571,y:521,t:1527023529597};\\\", \\\"{x:1562,y:524,t:1527023529609};\\\", \\\"{x:1529,y:531,t:1527023529625};\\\", \\\"{x:1484,y:543,t:1527023529643};\\\", \\\"{x:1441,y:552,t:1527023529659};\\\", \\\"{x:1397,y:561,t:1527023529676};\\\", \\\"{x:1348,y:567,t:1527023529693};\\\", \\\"{x:1322,y:572,t:1527023529709};\\\", \\\"{x:1304,y:572,t:1527023529728};\\\", \\\"{x:1289,y:573,t:1527023529743};\\\", \\\"{x:1280,y:575,t:1527023529758};\\\", \\\"{x:1269,y:576,t:1527023529776};\\\", \\\"{x:1246,y:577,t:1527023529793};\\\", \\\"{x:1212,y:577,t:1527023529809};\\\", \\\"{x:1156,y:570,t:1527023529825};\\\", \\\"{x:1110,y:562,t:1527023529843};\\\", \\\"{x:1082,y:555,t:1527023529859};\\\", \\\"{x:1059,y:545,t:1527023529877};\\\", \\\"{x:1032,y:527,t:1527023529893};\\\", \\\"{x:1029,y:525,t:1527023529909};\\\", \\\"{x:1025,y:522,t:1527023529927};\\\", \\\"{x:1027,y:519,t:1527023529943};\\\", \\\"{x:1034,y:514,t:1527023529959};\\\", \\\"{x:1042,y:504,t:1527023529976};\\\", \\\"{x:1046,y:497,t:1527023529993};\\\", \\\"{x:1051,y:481,t:1527023530010};\\\", \\\"{x:1059,y:461,t:1527023530026};\\\", \\\"{x:1073,y:437,t:1527023530043};\\\", \\\"{x:1088,y:416,t:1527023530060};\\\", \\\"{x:1098,y:406,t:1527023530076};\\\", \\\"{x:1107,y:401,t:1527023530092};\\\", \\\"{x:1110,y:400,t:1527023530109};\\\", \\\"{x:1114,y:399,t:1527023530127};\\\", \\\"{x:1116,y:399,t:1527023530157};\\\", \\\"{x:1118,y:400,t:1527023530172};\\\", \\\"{x:1119,y:402,t:1527023530181};\\\", \\\"{x:1120,y:406,t:1527023530193};\\\", \\\"{x:1126,y:419,t:1527023530210};\\\", \\\"{x:1133,y:434,t:1527023530226};\\\", \\\"{x:1136,y:455,t:1527023530243};\\\", \\\"{x:1136,y:475,t:1527023530260};\\\", \\\"{x:1136,y:498,t:1527023530276};\\\", \\\"{x:1136,y:537,t:1527023530293};\\\", \\\"{x:1136,y:557,t:1527023530310};\\\", \\\"{x:1136,y:572,t:1527023530327};\\\", \\\"{x:1136,y:579,t:1527023530343};\\\", \\\"{x:1136,y:583,t:1527023530359};\\\", \\\"{x:1136,y:584,t:1527023530377};\\\", \\\"{x:1136,y:587,t:1527023530393};\\\", \\\"{x:1135,y:591,t:1527023530410};\\\", \\\"{x:1129,y:599,t:1527023530427};\\\", \\\"{x:1125,y:611,t:1527023530443};\\\", \\\"{x:1121,y:624,t:1527023530460};\\\", \\\"{x:1106,y:649,t:1527023530477};\\\", \\\"{x:1099,y:658,t:1527023530492};\\\", \\\"{x:1096,y:659,t:1527023530510};\\\", \\\"{x:1096,y:660,t:1527023530541};\\\", \\\"{x:1095,y:660,t:1527023530580};\\\", \\\"{x:1094,y:660,t:1527023530593};\\\", \\\"{x:1091,y:660,t:1527023530609};\\\", \\\"{x:1090,y:660,t:1527023530629};\\\", \\\"{x:1089,y:660,t:1527023530643};\\\", \\\"{x:1088,y:660,t:1527023530659};\\\", \\\"{x:1086,y:660,t:1527023530677};\\\", \\\"{x:1086,y:655,t:1527023530693};\\\", \\\"{x:1084,y:646,t:1527023530709};\\\", \\\"{x:1084,y:636,t:1527023530727};\\\", \\\"{x:1083,y:628,t:1527023530743};\\\", \\\"{x:1082,y:623,t:1527023530760};\\\", \\\"{x:1080,y:615,t:1527023530777};\\\", \\\"{x:1080,y:610,t:1527023530793};\\\", \\\"{x:1079,y:606,t:1527023530809};\\\", \\\"{x:1079,y:601,t:1527023530827};\\\", \\\"{x:1078,y:596,t:1527023530843};\\\", \\\"{x:1078,y:590,t:1527023530860};\\\", \\\"{x:1078,y:588,t:1527023530877};\\\", \\\"{x:1078,y:587,t:1527023530894};\\\", \\\"{x:1078,y:586,t:1527023530916};\\\", \\\"{x:1078,y:585,t:1527023530927};\\\", \\\"{x:1080,y:579,t:1527023530944};\\\", \\\"{x:1088,y:572,t:1527023530960};\\\", \\\"{x:1100,y:563,t:1527023530977};\\\", \\\"{x:1120,y:557,t:1527023530994};\\\", \\\"{x:1135,y:551,t:1527023531010};\\\", \\\"{x:1156,y:548,t:1527023531027};\\\", \\\"{x:1177,y:547,t:1527023531044};\\\", \\\"{x:1196,y:547,t:1527023531060};\\\", \\\"{x:1218,y:546,t:1527023531076};\\\", \\\"{x:1223,y:546,t:1527023531094};\\\", \\\"{x:1225,y:546,t:1527023531110};\\\", \\\"{x:1226,y:545,t:1527023531133};\\\", \\\"{x:1227,y:545,t:1527023531144};\\\", \\\"{x:1229,y:545,t:1527023531160};\\\", \\\"{x:1236,y:545,t:1527023531177};\\\", \\\"{x:1242,y:545,t:1527023531193};\\\", \\\"{x:1256,y:545,t:1527023531210};\\\", \\\"{x:1271,y:545,t:1527023531227};\\\", \\\"{x:1285,y:545,t:1527023531243};\\\", \\\"{x:1310,y:550,t:1527023531259};\\\", \\\"{x:1334,y:550,t:1527023531277};\\\", \\\"{x:1351,y:550,t:1527023531294};\\\", \\\"{x:1366,y:551,t:1527023531311};\\\", \\\"{x:1372,y:553,t:1527023531327};\\\", \\\"{x:1378,y:553,t:1527023531344};\\\", \\\"{x:1383,y:553,t:1527023531361};\\\", \\\"{x:1387,y:551,t:1527023531377};\\\", \\\"{x:1392,y:551,t:1527023531394};\\\", \\\"{x:1401,y:551,t:1527023531411};\\\", \\\"{x:1410,y:551,t:1527023531427};\\\", \\\"{x:1422,y:551,t:1527023531445};\\\", \\\"{x:1433,y:551,t:1527023531461};\\\", \\\"{x:1434,y:551,t:1527023531477};\\\", \\\"{x:1432,y:552,t:1527023531645};\\\", \\\"{x:1408,y:560,t:1527023531660};\\\", \\\"{x:1368,y:573,t:1527023531676};\\\", \\\"{x:1301,y:592,t:1527023531694};\\\", \\\"{x:1216,y:613,t:1527023531711};\\\", \\\"{x:1118,y:631,t:1527023531727};\\\", \\\"{x:1033,y:650,t:1527023531744};\\\", \\\"{x:974,y:660,t:1527023531761};\\\", \\\"{x:937,y:665,t:1527023531776};\\\", \\\"{x:895,y:670,t:1527023531794};\\\", \\\"{x:864,y:670,t:1527023531811};\\\", \\\"{x:828,y:666,t:1527023531827};\\\", \\\"{x:778,y:654,t:1527023531844};\\\", \\\"{x:693,y:643,t:1527023531860};\\\", \\\"{x:645,y:627,t:1527023531879};\\\", \\\"{x:587,y:604,t:1527023531893};\\\", \\\"{x:525,y:570,t:1527023531910};\\\", \\\"{x:503,y:556,t:1527023531928};\\\", \\\"{x:487,y:548,t:1527023531945};\\\", \\\"{x:483,y:542,t:1527023531960};\\\", \\\"{x:483,y:539,t:1527023531977};\\\", \\\"{x:485,y:535,t:1527023531994};\\\", \\\"{x:491,y:532,t:1527023532011};\\\", \\\"{x:496,y:528,t:1527023532027};\\\", \\\"{x:502,y:523,t:1527023532044};\\\", \\\"{x:509,y:518,t:1527023532060};\\\", \\\"{x:521,y:517,t:1527023532079};\\\", \\\"{x:529,y:515,t:1527023532095};\\\", \\\"{x:534,y:515,t:1527023532111};\\\", \\\"{x:539,y:513,t:1527023532128};\\\", \\\"{x:541,y:512,t:1527023532147};\\\", \\\"{x:541,y:511,t:1527023532161};\\\", \\\"{x:543,y:510,t:1527023532178};\\\", \\\"{x:544,y:509,t:1527023532194};\\\", \\\"{x:545,y:508,t:1527023532228};\\\", \\\"{x:549,y:507,t:1527023532244};\\\", \\\"{x:555,y:504,t:1527023532261};\\\", \\\"{x:558,y:502,t:1527023532278};\\\", \\\"{x:560,y:501,t:1527023532295};\\\", \\\"{x:563,y:499,t:1527023532312};\\\", \\\"{x:566,y:498,t:1527023532327};\\\", \\\"{x:568,y:497,t:1527023532345};\\\", \\\"{x:569,y:497,t:1527023532361};\\\", \\\"{x:571,y:496,t:1527023532377};\\\", \\\"{x:573,y:496,t:1527023532395};\\\", \\\"{x:575,y:495,t:1527023532412};\\\", \\\"{x:576,y:495,t:1527023532427};\\\", \\\"{x:577,y:494,t:1527023532445};\\\", \\\"{x:579,y:494,t:1527023532462};\\\", \\\"{x:581,y:493,t:1527023532477};\\\", \\\"{x:583,y:492,t:1527023532495};\\\", \\\"{x:586,y:492,t:1527023532512};\\\", \\\"{x:589,y:491,t:1527023532529};\\\", \\\"{x:590,y:491,t:1527023532544};\\\", \\\"{x:593,y:491,t:1527023532561};\\\", \\\"{x:594,y:491,t:1527023532579};\\\", \\\"{x:596,y:491,t:1527023532594};\\\", \\\"{x:598,y:491,t:1527023532612};\\\", \\\"{x:599,y:491,t:1527023532693};\\\", \\\"{x:600,y:491,t:1527023532709};\\\", \\\"{x:602,y:491,t:1527023532732};\\\", \\\"{x:603,y:491,t:1527023532788};\\\", \\\"{x:603,y:491,t:1527023532873};\\\", \\\"{x:610,y:492,t:1527023532955};\\\", \\\"{x:621,y:496,t:1527023532963};\\\", \\\"{x:633,y:499,t:1527023532978};\\\", \\\"{x:659,y:506,t:1527023532995};\\\", \\\"{x:683,y:514,t:1527023533011};\\\", \\\"{x:719,y:526,t:1527023533029};\\\", \\\"{x:739,y:533,t:1527023533046};\\\", \\\"{x:751,y:537,t:1527023533061};\\\", \\\"{x:758,y:537,t:1527023533078};\\\", \\\"{x:763,y:539,t:1527023533094};\\\", \\\"{x:765,y:540,t:1527023533112};\\\", \\\"{x:771,y:540,t:1527023533128};\\\", \\\"{x:780,y:541,t:1527023533145};\\\", \\\"{x:785,y:543,t:1527023533161};\\\", \\\"{x:787,y:543,t:1527023533178};\\\", \\\"{x:788,y:543,t:1527023533196};\\\", \\\"{x:791,y:543,t:1527023533220};\\\", \\\"{x:792,y:543,t:1527023533228};\\\", \\\"{x:796,y:543,t:1527023533246};\\\", \\\"{x:802,y:543,t:1527023533261};\\\", \\\"{x:807,y:543,t:1527023533279};\\\", \\\"{x:812,y:543,t:1527023533296};\\\", \\\"{x:822,y:543,t:1527023533311};\\\", \\\"{x:828,y:543,t:1527023533329};\\\", \\\"{x:831,y:543,t:1527023533346};\\\", \\\"{x:832,y:543,t:1527023533361};\\\", \\\"{x:834,y:543,t:1527023533412};\\\", \\\"{x:835,y:543,t:1527023533540};\\\", \\\"{x:835,y:542,t:1527023533547};\\\", \\\"{x:835,y:542,t:1527023533608};\\\", \\\"{x:835,y:544,t:1527023533780};\\\", \\\"{x:834,y:545,t:1527023533795};\\\", \\\"{x:827,y:552,t:1527023533812};\\\", \\\"{x:820,y:561,t:1527023533829};\\\", \\\"{x:810,y:572,t:1527023533845};\\\", \\\"{x:795,y:590,t:1527023533862};\\\", \\\"{x:773,y:611,t:1527023533879};\\\", \\\"{x:749,y:628,t:1527023533895};\\\", \\\"{x:714,y:649,t:1527023533913};\\\", \\\"{x:694,y:661,t:1527023533928};\\\", \\\"{x:676,y:668,t:1527023533945};\\\", \\\"{x:653,y:677,t:1527023533963};\\\", \\\"{x:635,y:684,t:1527023533979};\\\", \\\"{x:619,y:690,t:1527023533996};\\\", \\\"{x:599,y:696,t:1527023534012};\\\", \\\"{x:592,y:699,t:1527023534030};\\\", \\\"{x:587,y:703,t:1527023534045};\\\", \\\"{x:579,y:708,t:1527023534062};\\\", \\\"{x:573,y:713,t:1527023534080};\\\", \\\"{x:568,y:717,t:1527023534097};\\\", \\\"{x:564,y:720,t:1527023534113};\\\", \\\"{x:556,y:724,t:1527023534131};\\\", \\\"{x:551,y:728,t:1527023534146};\\\", \\\"{x:549,y:730,t:1527023534162};\\\", \\\"{x:548,y:731,t:1527023534179};\\\", \\\"{x:546,y:731,t:1527023534235};\\\", \\\"{x:543,y:733,t:1527023534245};\\\", \\\"{x:538,y:735,t:1527023534262};\\\", \\\"{x:535,y:735,t:1527023534279};\\\", \\\"{x:531,y:736,t:1527023534297};\\\", \\\"{x:530,y:736,t:1527023534313};\\\", \\\"{x:531,y:736,t:1527023535837};\\\", \\\"{x:535,y:736,t:1527023535847};\\\", \\\"{x:548,y:734,t:1527023535864};\\\", \\\"{x:577,y:732,t:1527023535887};\\\", \\\"{x:618,y:728,t:1527023535913};\\\", \\\"{x:664,y:722,t:1527023535930};\\\", \\\"{x:812,y:719,t:1527023535947};\\\", \\\"{x:900,y:713,t:1527023535963};\\\", \\\"{x:975,y:713,t:1527023535981};\\\", \\\"{x:1030,y:707,t:1527023535997};\\\", \\\"{x:1059,y:703,t:1527023536014};\\\", \\\"{x:1070,y:702,t:1527023536030};\\\", \\\"{x:1071,y:702,t:1527023536047};\\\" ] }, { \\\"rt\\\": 30573, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 662128, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -F -O -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1073,y:699,t:1527023547005};\\\", \\\"{x:1080,y:688,t:1527023547024};\\\", \\\"{x:1091,y:667,t:1527023547047};\\\", \\\"{x:1093,y:660,t:1527023547056};\\\", \\\"{x:1098,y:648,t:1527023547073};\\\", \\\"{x:1101,y:634,t:1527023547090};\\\", \\\"{x:1102,y:624,t:1527023547106};\\\", \\\"{x:1102,y:611,t:1527023547123};\\\", \\\"{x:1092,y:593,t:1527023547139};\\\", \\\"{x:1079,y:580,t:1527023547156};\\\", \\\"{x:1068,y:572,t:1527023547173};\\\", \\\"{x:1064,y:567,t:1527023547190};\\\", \\\"{x:1064,y:565,t:1527023547206};\\\", \\\"{x:1064,y:564,t:1527023547224};\\\", \\\"{x:1064,y:563,t:1527023547341};\\\", \\\"{x:1067,y:563,t:1527023547357};\\\", \\\"{x:1068,y:563,t:1527023547374};\\\", \\\"{x:1071,y:563,t:1527023547390};\\\", \\\"{x:1072,y:563,t:1527023547407};\\\", \\\"{x:1077,y:562,t:1527023547424};\\\", \\\"{x:1084,y:562,t:1527023547441};\\\", \\\"{x:1087,y:562,t:1527023547457};\\\", \\\"{x:1096,y:563,t:1527023547473};\\\", \\\"{x:1104,y:564,t:1527023547491};\\\", \\\"{x:1115,y:566,t:1527023547508};\\\", \\\"{x:1124,y:570,t:1527023547524};\\\", \\\"{x:1133,y:574,t:1527023547540};\\\", \\\"{x:1135,y:575,t:1527023547557};\\\", \\\"{x:1137,y:577,t:1527023547573};\\\", \\\"{x:1139,y:582,t:1527023547590};\\\", \\\"{x:1140,y:589,t:1527023547607};\\\", \\\"{x:1142,y:598,t:1527023547624};\\\", \\\"{x:1142,y:607,t:1527023547640};\\\", \\\"{x:1142,y:613,t:1527023547657};\\\", \\\"{x:1142,y:621,t:1527023547673};\\\", \\\"{x:1142,y:625,t:1527023547690};\\\", \\\"{x:1142,y:631,t:1527023547707};\\\", \\\"{x:1142,y:636,t:1527023547724};\\\", \\\"{x:1140,y:640,t:1527023547740};\\\", \\\"{x:1139,y:641,t:1527023547758};\\\", \\\"{x:1139,y:643,t:1527023547774};\\\", \\\"{x:1138,y:643,t:1527023547820};\\\", \\\"{x:1139,y:643,t:1527023547885};\\\", \\\"{x:1142,y:642,t:1527023547892};\\\", \\\"{x:1145,y:641,t:1527023547907};\\\", \\\"{x:1155,y:638,t:1527023547924};\\\", \\\"{x:1158,y:637,t:1527023547941};\\\", \\\"{x:1160,y:635,t:1527023547957};\\\", \\\"{x:1162,y:635,t:1527023547974};\\\", \\\"{x:1164,y:634,t:1527023547990};\\\", \\\"{x:1166,y:633,t:1527023548008};\\\", \\\"{x:1171,y:632,t:1527023548025};\\\", \\\"{x:1175,y:630,t:1527023548041};\\\", \\\"{x:1180,y:630,t:1527023548057};\\\", \\\"{x:1192,y:629,t:1527023548075};\\\", \\\"{x:1206,y:627,t:1527023548091};\\\", \\\"{x:1223,y:627,t:1527023548108};\\\", \\\"{x:1268,y:627,t:1527023548125};\\\", \\\"{x:1308,y:627,t:1527023548141};\\\", \\\"{x:1340,y:630,t:1527023548158};\\\", \\\"{x:1362,y:634,t:1527023548175};\\\", \\\"{x:1376,y:635,t:1527023548191};\\\", \\\"{x:1379,y:635,t:1527023548207};\\\", \\\"{x:1380,y:636,t:1527023548225};\\\", \\\"{x:1381,y:637,t:1527023548244};\\\", \\\"{x:1383,y:637,t:1527023548308};\\\", \\\"{x:1387,y:637,t:1527023548323};\\\", \\\"{x:1391,y:637,t:1527023548341};\\\", \\\"{x:1394,y:637,t:1527023548357};\\\", \\\"{x:1396,y:637,t:1527023548374};\\\", \\\"{x:1398,y:637,t:1527023548391};\\\", \\\"{x:1401,y:637,t:1527023548407};\\\", \\\"{x:1403,y:637,t:1527023548424};\\\", \\\"{x:1407,y:636,t:1527023548441};\\\", \\\"{x:1410,y:635,t:1527023548457};\\\", \\\"{x:1415,y:635,t:1527023548475};\\\", \\\"{x:1417,y:635,t:1527023548491};\\\", \\\"{x:1422,y:634,t:1527023548507};\\\", \\\"{x:1430,y:633,t:1527023548524};\\\", \\\"{x:1438,y:633,t:1527023548541};\\\", \\\"{x:1447,y:633,t:1527023548559};\\\", \\\"{x:1455,y:633,t:1527023548575};\\\", \\\"{x:1463,y:633,t:1527023548591};\\\", \\\"{x:1467,y:633,t:1527023548607};\\\", \\\"{x:1469,y:633,t:1527023548624};\\\", \\\"{x:1470,y:633,t:1527023548641};\\\", \\\"{x:1471,y:633,t:1527023548657};\\\", \\\"{x:1472,y:633,t:1527023548674};\\\", \\\"{x:1473,y:633,t:1527023548691};\\\", \\\"{x:1474,y:633,t:1527023548707};\\\", \\\"{x:1477,y:633,t:1527023548724};\\\", \\\"{x:1480,y:633,t:1527023548742};\\\", \\\"{x:1483,y:633,t:1527023548758};\\\", \\\"{x:1485,y:633,t:1527023548775};\\\", \\\"{x:1488,y:633,t:1527023548792};\\\", \\\"{x:1489,y:633,t:1527023548809};\\\", \\\"{x:1490,y:633,t:1527023548825};\\\", \\\"{x:1491,y:633,t:1527023549173};\\\", \\\"{x:1492,y:634,t:1527023549629};\\\", \\\"{x:1492,y:636,t:1527023549652};\\\", \\\"{x:1492,y:639,t:1527023549668};\\\", \\\"{x:1492,y:640,t:1527023549693};\\\", \\\"{x:1492,y:641,t:1527023549708};\\\", \\\"{x:1492,y:642,t:1527023549725};\\\", \\\"{x:1491,y:644,t:1527023549742};\\\", \\\"{x:1489,y:646,t:1527023549759};\\\", \\\"{x:1489,y:647,t:1527023549775};\\\", \\\"{x:1487,y:649,t:1527023549792};\\\", \\\"{x:1486,y:650,t:1527023549809};\\\", \\\"{x:1485,y:651,t:1527023549828};\\\", \\\"{x:1484,y:652,t:1527023549843};\\\", \\\"{x:1483,y:653,t:1527023549859};\\\", \\\"{x:1480,y:655,t:1527023549875};\\\", \\\"{x:1477,y:657,t:1527023549893};\\\", \\\"{x:1474,y:657,t:1527023549908};\\\", \\\"{x:1471,y:660,t:1527023549926};\\\", \\\"{x:1469,y:660,t:1527023549942};\\\", \\\"{x:1468,y:660,t:1527023549958};\\\", \\\"{x:1467,y:660,t:1527023549988};\\\", \\\"{x:1467,y:661,t:1527023550004};\\\", \\\"{x:1465,y:661,t:1527023550028};\\\", \\\"{x:1464,y:662,t:1527023550043};\\\", \\\"{x:1461,y:663,t:1527023550059};\\\", \\\"{x:1455,y:664,t:1527023550076};\\\", \\\"{x:1446,y:666,t:1527023550093};\\\", \\\"{x:1442,y:668,t:1527023550110};\\\", \\\"{x:1439,y:669,t:1527023550126};\\\", \\\"{x:1438,y:669,t:1527023550143};\\\", \\\"{x:1437,y:670,t:1527023550159};\\\", \\\"{x:1435,y:671,t:1527023550175};\\\", \\\"{x:1433,y:671,t:1527023550192};\\\", \\\"{x:1431,y:672,t:1527023550213};\\\", \\\"{x:1429,y:673,t:1527023550236};\\\", \\\"{x:1428,y:674,t:1527023550245};\\\", \\\"{x:1426,y:674,t:1527023550260};\\\", \\\"{x:1424,y:677,t:1527023550276};\\\", \\\"{x:1418,y:680,t:1527023550293};\\\", \\\"{x:1411,y:684,t:1527023550309};\\\", \\\"{x:1402,y:689,t:1527023550326};\\\", \\\"{x:1390,y:693,t:1527023550342};\\\", \\\"{x:1379,y:698,t:1527023550360};\\\", \\\"{x:1370,y:700,t:1527023550376};\\\", \\\"{x:1359,y:703,t:1527023550393};\\\", \\\"{x:1343,y:706,t:1527023550410};\\\", \\\"{x:1330,y:709,t:1527023550427};\\\", \\\"{x:1319,y:711,t:1527023550443};\\\", \\\"{x:1309,y:711,t:1527023550460};\\\", \\\"{x:1299,y:713,t:1527023550476};\\\", \\\"{x:1296,y:713,t:1527023550492};\\\", \\\"{x:1296,y:712,t:1527023550621};\\\", \\\"{x:1296,y:711,t:1527023550629};\\\", \\\"{x:1296,y:709,t:1527023550642};\\\", \\\"{x:1298,y:708,t:1527023550660};\\\", \\\"{x:1301,y:706,t:1527023550676};\\\", \\\"{x:1301,y:705,t:1527023550709};\\\", \\\"{x:1303,y:704,t:1527023550726};\\\", \\\"{x:1305,y:703,t:1527023550743};\\\", \\\"{x:1308,y:699,t:1527023550760};\\\", \\\"{x:1310,y:697,t:1527023550780};\\\", \\\"{x:1311,y:697,t:1527023550796};\\\", \\\"{x:1311,y:696,t:1527023550813};\\\", \\\"{x:1312,y:696,t:1527023550827};\\\", \\\"{x:1314,y:695,t:1527023550853};\\\", \\\"{x:1315,y:695,t:1527023550868};\\\", \\\"{x:1316,y:694,t:1527023550876};\\\", \\\"{x:1317,y:694,t:1527023550893};\\\", \\\"{x:1320,y:693,t:1527023550910};\\\", \\\"{x:1322,y:692,t:1527023550927};\\\", \\\"{x:1323,y:691,t:1527023550943};\\\", \\\"{x:1325,y:691,t:1527023550959};\\\", \\\"{x:1327,y:690,t:1527023550981};\\\", \\\"{x:1329,y:690,t:1527023550997};\\\", \\\"{x:1330,y:690,t:1527023551010};\\\", \\\"{x:1333,y:690,t:1527023551027};\\\", \\\"{x:1337,y:690,t:1527023551044};\\\", \\\"{x:1339,y:690,t:1527023551059};\\\", \\\"{x:1341,y:690,t:1527023551133};\\\", \\\"{x:1342,y:690,t:1527023552693};\\\", \\\"{x:1343,y:690,t:1527023552709};\\\", \\\"{x:1345,y:690,t:1527023552716};\\\", \\\"{x:1346,y:691,t:1527023552727};\\\", \\\"{x:1347,y:693,t:1527023552989};\\\", \\\"{x:1348,y:695,t:1527023553012};\\\", \\\"{x:1349,y:696,t:1527023553028};\\\", \\\"{x:1349,y:697,t:1527023553045};\\\", \\\"{x:1350,y:701,t:1527023553062};\\\", \\\"{x:1352,y:707,t:1527023553079};\\\", \\\"{x:1358,y:715,t:1527023553095};\\\", \\\"{x:1363,y:724,t:1527023553111};\\\", \\\"{x:1372,y:734,t:1527023553127};\\\", \\\"{x:1380,y:743,t:1527023553145};\\\", \\\"{x:1393,y:750,t:1527023553162};\\\", \\\"{x:1407,y:757,t:1527023553178};\\\", \\\"{x:1423,y:763,t:1527023553196};\\\", \\\"{x:1435,y:767,t:1527023553212};\\\", \\\"{x:1445,y:773,t:1527023553228};\\\", \\\"{x:1452,y:774,t:1527023553245};\\\", \\\"{x:1456,y:775,t:1527023553262};\\\", \\\"{x:1459,y:776,t:1527023553279};\\\", \\\"{x:1463,y:776,t:1527023553295};\\\", \\\"{x:1465,y:776,t:1527023553312};\\\", \\\"{x:1470,y:776,t:1527023553329};\\\", \\\"{x:1477,y:776,t:1527023553345};\\\", \\\"{x:1485,y:776,t:1527023553361};\\\", \\\"{x:1489,y:776,t:1527023553379};\\\", \\\"{x:1490,y:776,t:1527023553395};\\\", \\\"{x:1492,y:776,t:1527023553428};\\\", \\\"{x:1493,y:775,t:1527023553445};\\\", \\\"{x:1494,y:775,t:1527023553462};\\\", \\\"{x:1496,y:775,t:1527023553479};\\\", \\\"{x:1498,y:773,t:1527023553495};\\\", \\\"{x:1503,y:773,t:1527023553512};\\\", \\\"{x:1505,y:773,t:1527023553529};\\\", \\\"{x:1506,y:773,t:1527023553545};\\\", \\\"{x:1507,y:773,t:1527023553565};\\\", \\\"{x:1509,y:772,t:1527023553653};\\\", \\\"{x:1509,y:771,t:1527023553668};\\\", \\\"{x:1511,y:770,t:1527023553733};\\\", \\\"{x:1512,y:769,t:1527023553764};\\\", \\\"{x:1514,y:769,t:1527023553779};\\\", \\\"{x:1516,y:767,t:1527023553795};\\\", \\\"{x:1517,y:766,t:1527023553811};\\\", \\\"{x:1517,y:765,t:1527023553828};\\\", \\\"{x:1519,y:764,t:1527023553931};\\\", \\\"{x:1519,y:768,t:1527023555342};\\\", \\\"{x:1519,y:772,t:1527023555348};\\\", \\\"{x:1519,y:778,t:1527023555363};\\\", \\\"{x:1519,y:783,t:1527023555381};\\\", \\\"{x:1519,y:788,t:1527023555397};\\\", \\\"{x:1519,y:790,t:1527023555428};\\\", \\\"{x:1518,y:792,t:1527023555477};\\\", \\\"{x:1517,y:794,t:1527023555484};\\\", \\\"{x:1516,y:798,t:1527023555497};\\\", \\\"{x:1512,y:803,t:1527023555514};\\\", \\\"{x:1509,y:808,t:1527023555530};\\\", \\\"{x:1506,y:810,t:1527023555547};\\\", \\\"{x:1505,y:811,t:1527023555566};\\\", \\\"{x:1505,y:812,t:1527023555580};\\\", \\\"{x:1503,y:813,t:1527023555597};\\\", \\\"{x:1501,y:817,t:1527023555614};\\\", \\\"{x:1496,y:821,t:1527023555630};\\\", \\\"{x:1492,y:823,t:1527023555647};\\\", \\\"{x:1487,y:826,t:1527023555664};\\\", \\\"{x:1482,y:828,t:1527023555680};\\\", \\\"{x:1472,y:834,t:1527023555698};\\\", \\\"{x:1454,y:840,t:1527023555714};\\\", \\\"{x:1437,y:846,t:1527023555730};\\\", \\\"{x:1403,y:850,t:1527023555747};\\\", \\\"{x:1331,y:849,t:1527023555766};\\\", \\\"{x:1273,y:850,t:1527023555780};\\\", \\\"{x:1252,y:848,t:1527023555797};\\\", \\\"{x:1246,y:847,t:1527023555814};\\\", \\\"{x:1243,y:846,t:1527023555830};\\\", \\\"{x:1241,y:845,t:1527023555941};\\\", \\\"{x:1237,y:844,t:1527023555948};\\\", \\\"{x:1233,y:841,t:1527023555966};\\\", \\\"{x:1225,y:838,t:1527023555980};\\\", \\\"{x:1221,y:836,t:1527023555997};\\\", \\\"{x:1213,y:836,t:1527023556014};\\\", \\\"{x:1209,y:834,t:1527023556031};\\\", \\\"{x:1206,y:833,t:1527023556047};\\\", \\\"{x:1198,y:830,t:1527023557366};\\\", \\\"{x:1185,y:825,t:1527023557382};\\\", \\\"{x:1162,y:817,t:1527023557398};\\\", \\\"{x:1138,y:804,t:1527023557415};\\\", \\\"{x:1099,y:792,t:1527023557432};\\\", \\\"{x:1064,y:779,t:1527023557449};\\\", \\\"{x:1034,y:762,t:1527023557466};\\\", \\\"{x:1003,y:752,t:1527023557482};\\\", \\\"{x:980,y:741,t:1527023557498};\\\", \\\"{x:957,y:727,t:1527023557515};\\\", \\\"{x:926,y:708,t:1527023557532};\\\", \\\"{x:902,y:695,t:1527023557548};\\\", \\\"{x:888,y:687,t:1527023557568};\\\", \\\"{x:867,y:674,t:1527023557581};\\\", \\\"{x:845,y:662,t:1527023557599};\\\", \\\"{x:824,y:650,t:1527023557615};\\\", \\\"{x:798,y:639,t:1527023557631};\\\", \\\"{x:776,y:630,t:1527023557649};\\\", \\\"{x:754,y:623,t:1527023557664};\\\", \\\"{x:734,y:616,t:1527023557681};\\\", \\\"{x:715,y:610,t:1527023557699};\\\", \\\"{x:690,y:603,t:1527023557715};\\\", \\\"{x:673,y:602,t:1527023557731};\\\", \\\"{x:662,y:601,t:1527023557749};\\\", \\\"{x:659,y:601,t:1527023557766};\\\", \\\"{x:656,y:601,t:1527023557781};\\\", \\\"{x:655,y:601,t:1527023557798};\\\", \\\"{x:654,y:601,t:1527023557851};\\\", \\\"{x:653,y:602,t:1527023557865};\\\", \\\"{x:650,y:602,t:1527023557881};\\\", \\\"{x:647,y:602,t:1527023557898};\\\", \\\"{x:644,y:601,t:1527023557916};\\\", \\\"{x:642,y:599,t:1527023557934};\\\", \\\"{x:640,y:598,t:1527023557956};\\\", \\\"{x:644,y:598,t:1527023558012};\\\", \\\"{x:648,y:598,t:1527023558019};\\\", \\\"{x:656,y:598,t:1527023558031};\\\", \\\"{x:676,y:597,t:1527023558048};\\\", \\\"{x:690,y:593,t:1527023558066};\\\", \\\"{x:696,y:589,t:1527023558081};\\\", \\\"{x:699,y:588,t:1527023558099};\\\", \\\"{x:699,y:587,t:1527023558116};\\\", \\\"{x:699,y:586,t:1527023558148};\\\", \\\"{x:698,y:586,t:1527023558155};\\\", \\\"{x:697,y:586,t:1527023558165};\\\", \\\"{x:691,y:586,t:1527023558182};\\\", \\\"{x:686,y:586,t:1527023558199};\\\", \\\"{x:678,y:587,t:1527023558216};\\\", \\\"{x:670,y:588,t:1527023558233};\\\", \\\"{x:662,y:588,t:1527023558250};\\\", \\\"{x:652,y:588,t:1527023558265};\\\", \\\"{x:637,y:588,t:1527023558285};\\\", \\\"{x:625,y:588,t:1527023558299};\\\", \\\"{x:619,y:587,t:1527023558315};\\\", \\\"{x:617,y:586,t:1527023558332};\\\", \\\"{x:618,y:586,t:1527023558649};\\\", \\\"{x:625,y:586,t:1527023558667};\\\", \\\"{x:627,y:584,t:1527023558682};\\\", \\\"{x:628,y:583,t:1527023558699};\\\", \\\"{x:632,y:583,t:1527023558716};\\\", \\\"{x:641,y:583,t:1527023558733};\\\", \\\"{x:651,y:583,t:1527023558749};\\\", \\\"{x:670,y:583,t:1527023558767};\\\", \\\"{x:683,y:582,t:1527023558782};\\\", \\\"{x:691,y:580,t:1527023558800};\\\", \\\"{x:705,y:578,t:1527023558817};\\\", \\\"{x:714,y:577,t:1527023558833};\\\", \\\"{x:725,y:577,t:1527023558850};\\\", \\\"{x:735,y:575,t:1527023558866};\\\", \\\"{x:745,y:575,t:1527023558883};\\\", \\\"{x:763,y:575,t:1527023558900};\\\", \\\"{x:771,y:576,t:1527023558917};\\\", \\\"{x:775,y:577,t:1527023558932};\\\", \\\"{x:785,y:579,t:1527023558949};\\\", \\\"{x:794,y:579,t:1527023558966};\\\", \\\"{x:801,y:580,t:1527023558983};\\\", \\\"{x:803,y:582,t:1527023559000};\\\", \\\"{x:804,y:582,t:1527023559017};\\\", \\\"{x:805,y:583,t:1527023559034};\\\", \\\"{x:806,y:583,t:1527023559100};\\\", \\\"{x:808,y:583,t:1527023559117};\\\", \\\"{x:810,y:583,t:1527023559134};\\\", \\\"{x:812,y:583,t:1527023559150};\\\", \\\"{x:814,y:583,t:1527023559166};\\\", \\\"{x:815,y:583,t:1527023559183};\\\", \\\"{x:817,y:583,t:1527023559200};\\\", \\\"{x:818,y:583,t:1527023559217};\\\", \\\"{x:818,y:582,t:1527023559236};\\\", \\\"{x:820,y:582,t:1527023559781};\\\", \\\"{x:823,y:582,t:1527023559788};\\\", \\\"{x:825,y:583,t:1527023559802};\\\", \\\"{x:827,y:584,t:1527023560317};\\\", \\\"{x:832,y:585,t:1527023560324};\\\", \\\"{x:836,y:589,t:1527023560334};\\\", \\\"{x:843,y:592,t:1527023560352};\\\", \\\"{x:846,y:593,t:1527023560367};\\\", \\\"{x:851,y:595,t:1527023560385};\\\", \\\"{x:855,y:596,t:1527023560400};\\\", \\\"{x:866,y:601,t:1527023560418};\\\", \\\"{x:875,y:605,t:1527023560434};\\\", \\\"{x:886,y:610,t:1527023560450};\\\", \\\"{x:913,y:623,t:1527023560467};\\\", \\\"{x:933,y:631,t:1527023560484};\\\", \\\"{x:952,y:642,t:1527023560501};\\\", \\\"{x:973,y:655,t:1527023560518};\\\", \\\"{x:1006,y:670,t:1527023560535};\\\", \\\"{x:1046,y:690,t:1527023560551};\\\", \\\"{x:1084,y:704,t:1527023560567};\\\", \\\"{x:1108,y:714,t:1527023560585};\\\", \\\"{x:1142,y:724,t:1527023560601};\\\", \\\"{x:1179,y:743,t:1527023560618};\\\", \\\"{x:1224,y:764,t:1527023560635};\\\", \\\"{x:1262,y:784,t:1527023560651};\\\", \\\"{x:1334,y:821,t:1527023560668};\\\", \\\"{x:1392,y:847,t:1527023560685};\\\", \\\"{x:1437,y:868,t:1527023560701};\\\", \\\"{x:1486,y:887,t:1527023560718};\\\", \\\"{x:1546,y:909,t:1527023560735};\\\", \\\"{x:1611,y:919,t:1527023560751};\\\", \\\"{x:1653,y:919,t:1527023560768};\\\", \\\"{x:1669,y:919,t:1527023560785};\\\", \\\"{x:1671,y:919,t:1527023560802};\\\", \\\"{x:1671,y:918,t:1527023560818};\\\", \\\"{x:1671,y:915,t:1527023560835};\\\", \\\"{x:1671,y:910,t:1527023560852};\\\", \\\"{x:1668,y:907,t:1527023560868};\\\", \\\"{x:1661,y:897,t:1527023560885};\\\", \\\"{x:1650,y:889,t:1527023560902};\\\", \\\"{x:1637,y:883,t:1527023560918};\\\", \\\"{x:1610,y:873,t:1527023560935};\\\", \\\"{x:1581,y:867,t:1527023560953};\\\", \\\"{x:1560,y:866,t:1527023560968};\\\", \\\"{x:1542,y:866,t:1527023560986};\\\", \\\"{x:1534,y:866,t:1527023561002};\\\", \\\"{x:1530,y:866,t:1527023561018};\\\", \\\"{x:1529,y:867,t:1527023561035};\\\", \\\"{x:1528,y:867,t:1527023561052};\\\", \\\"{x:1527,y:867,t:1527023561133};\\\", \\\"{x:1526,y:867,t:1527023561149};\\\", \\\"{x:1524,y:866,t:1527023561156};\\\", \\\"{x:1523,y:861,t:1527023561168};\\\", \\\"{x:1515,y:850,t:1527023561185};\\\", \\\"{x:1503,y:839,t:1527023561202};\\\", \\\"{x:1488,y:831,t:1527023561218};\\\", \\\"{x:1483,y:829,t:1527023561235};\\\", \\\"{x:1480,y:827,t:1527023561252};\\\", \\\"{x:1479,y:825,t:1527023561789};\\\", \\\"{x:1479,y:824,t:1527023561803};\\\", \\\"{x:1480,y:823,t:1527023561819};\\\", \\\"{x:1480,y:822,t:1527023561835};\\\", \\\"{x:1482,y:819,t:1527023561852};\\\", \\\"{x:1483,y:818,t:1527023561869};\\\", \\\"{x:1484,y:816,t:1527023561885};\\\", \\\"{x:1484,y:815,t:1527023561908};\\\", \\\"{x:1486,y:814,t:1527023561924};\\\", \\\"{x:1486,y:813,t:1527023561948};\\\", \\\"{x:1487,y:812,t:1527023562052};\\\", \\\"{x:1489,y:812,t:1527023562069};\\\", \\\"{x:1490,y:810,t:1527023562086};\\\", \\\"{x:1492,y:809,t:1527023562102};\\\", \\\"{x:1495,y:807,t:1527023562119};\\\", \\\"{x:1497,y:805,t:1527023562136};\\\", \\\"{x:1498,y:805,t:1527023562156};\\\", \\\"{x:1498,y:804,t:1527023562169};\\\", \\\"{x:1499,y:803,t:1527023562195};\\\", \\\"{x:1501,y:802,t:1527023562203};\\\", \\\"{x:1503,y:800,t:1527023562218};\\\", \\\"{x:1505,y:797,t:1527023562235};\\\", \\\"{x:1508,y:795,t:1527023562251};\\\", \\\"{x:1510,y:793,t:1527023562268};\\\", \\\"{x:1512,y:791,t:1527023562286};\\\", \\\"{x:1514,y:787,t:1527023562302};\\\", \\\"{x:1516,y:786,t:1527023562319};\\\", \\\"{x:1517,y:785,t:1527023562348};\\\", \\\"{x:1518,y:785,t:1527023562355};\\\", \\\"{x:1519,y:784,t:1527023562379};\\\", \\\"{x:1520,y:783,t:1527023562388};\\\", \\\"{x:1522,y:781,t:1527023562429};\\\", \\\"{x:1524,y:779,t:1527023562468};\\\", \\\"{x:1524,y:778,t:1527023562516};\\\", \\\"{x:1523,y:778,t:1527023562885};\\\", \\\"{x:1522,y:780,t:1527023562892};\\\", \\\"{x:1520,y:783,t:1527023562903};\\\", \\\"{x:1519,y:784,t:1527023562920};\\\", \\\"{x:1517,y:787,t:1527023562936};\\\", \\\"{x:1515,y:790,t:1527023562953};\\\", \\\"{x:1513,y:792,t:1527023562972};\\\", \\\"{x:1513,y:793,t:1527023562986};\\\", \\\"{x:1510,y:797,t:1527023563003};\\\", \\\"{x:1507,y:802,t:1527023563019};\\\", \\\"{x:1501,y:812,t:1527023563036};\\\", \\\"{x:1496,y:819,t:1527023563053};\\\", \\\"{x:1492,y:824,t:1527023563069};\\\", \\\"{x:1489,y:828,t:1527023563086};\\\", \\\"{x:1487,y:830,t:1527023563103};\\\", \\\"{x:1484,y:835,t:1527023563119};\\\", \\\"{x:1481,y:839,t:1527023563137};\\\", \\\"{x:1477,y:843,t:1527023563154};\\\", \\\"{x:1475,y:843,t:1527023563170};\\\", \\\"{x:1471,y:846,t:1527023563186};\\\", \\\"{x:1470,y:847,t:1527023563203};\\\", \\\"{x:1466,y:850,t:1527023563220};\\\", \\\"{x:1461,y:854,t:1527023563237};\\\", \\\"{x:1448,y:864,t:1527023563254};\\\", \\\"{x:1436,y:872,t:1527023563271};\\\", \\\"{x:1428,y:877,t:1527023563287};\\\", \\\"{x:1424,y:880,t:1527023563303};\\\", \\\"{x:1423,y:882,t:1527023563321};\\\", \\\"{x:1421,y:882,t:1527023563381};\\\", \\\"{x:1421,y:884,t:1527023563389};\\\", \\\"{x:1420,y:884,t:1527023563404};\\\", \\\"{x:1417,y:888,t:1527023563420};\\\", \\\"{x:1414,y:889,t:1527023563436};\\\", \\\"{x:1410,y:893,t:1527023563454};\\\", \\\"{x:1406,y:896,t:1527023563471};\\\", \\\"{x:1402,y:897,t:1527023563487};\\\", \\\"{x:1399,y:899,t:1527023563504};\\\", \\\"{x:1394,y:901,t:1527023563520};\\\", \\\"{x:1390,y:903,t:1527023563537};\\\", \\\"{x:1385,y:906,t:1527023563554};\\\", \\\"{x:1381,y:908,t:1527023563570};\\\", \\\"{x:1375,y:911,t:1527023563586};\\\", \\\"{x:1371,y:913,t:1527023563604};\\\", \\\"{x:1363,y:918,t:1527023563620};\\\", \\\"{x:1357,y:920,t:1527023563636};\\\", \\\"{x:1352,y:922,t:1527023563654};\\\", \\\"{x:1350,y:923,t:1527023563676};\\\", \\\"{x:1349,y:923,t:1527023564317};\\\", \\\"{x:1347,y:923,t:1527023564333};\\\", \\\"{x:1346,y:924,t:1527023564366};\\\", \\\"{x:1345,y:924,t:1527023564437};\\\", \\\"{x:1344,y:924,t:1527023564454};\\\", \\\"{x:1343,y:925,t:1527023564471};\\\", \\\"{x:1335,y:925,t:1527023566584};\\\", \\\"{x:1324,y:925,t:1527023566591};\\\", \\\"{x:1294,y:925,t:1527023566608};\\\", \\\"{x:1232,y:925,t:1527023566624};\\\", \\\"{x:1144,y:917,t:1527023566641};\\\", \\\"{x:1044,y:901,t:1527023566658};\\\", \\\"{x:936,y:885,t:1527023566676};\\\", \\\"{x:877,y:873,t:1527023566691};\\\", \\\"{x:823,y:861,t:1527023566708};\\\", \\\"{x:772,y:852,t:1527023566724};\\\", \\\"{x:747,y:847,t:1527023566740};\\\", \\\"{x:723,y:846,t:1527023566757};\\\", \\\"{x:701,y:846,t:1527023566774};\\\", \\\"{x:687,y:846,t:1527023566790};\\\", \\\"{x:673,y:844,t:1527023566807};\\\", \\\"{x:660,y:842,t:1527023566824};\\\", \\\"{x:646,y:840,t:1527023566841};\\\", \\\"{x:641,y:838,t:1527023566858};\\\", \\\"{x:633,y:833,t:1527023566875};\\\", \\\"{x:630,y:829,t:1527023566891};\\\", \\\"{x:622,y:822,t:1527023566907};\\\", \\\"{x:611,y:804,t:1527023566924};\\\", \\\"{x:594,y:788,t:1527023566941};\\\", \\\"{x:579,y:774,t:1527023566957};\\\", \\\"{x:562,y:759,t:1527023566975};\\\", \\\"{x:546,y:750,t:1527023566992};\\\", \\\"{x:533,y:743,t:1527023567007};\\\", \\\"{x:521,y:740,t:1527023567024};\\\", \\\"{x:515,y:738,t:1527023567043};\\\", \\\"{x:512,y:738,t:1527023567059};\\\", \\\"{x:511,y:738,t:1527023567078};\\\", \\\"{x:510,y:737,t:1527023567118};\\\", \\\"{x:509,y:736,t:1527023567159};\\\", \\\"{x:508,y:735,t:1527023567182};\\\", \\\"{x:509,y:733,t:1527023567270};\\\", \\\"{x:509,y:733,t:1527023567367};\\\", \\\"{x:511,y:732,t:1527023567639};\\\", \\\"{x:516,y:733,t:1527023567647};\\\", \\\"{x:521,y:734,t:1527023567659};\\\", \\\"{x:526,y:736,t:1527023567676};\\\", \\\"{x:533,y:739,t:1527023567693};\\\", \\\"{x:542,y:744,t:1527023567710};\\\", \\\"{x:564,y:750,t:1527023567726};\\\", \\\"{x:587,y:759,t:1527023567743};\\\", \\\"{x:617,y:770,t:1527023567760};\\\", \\\"{x:663,y:780,t:1527023567777};\\\", \\\"{x:715,y:793,t:1527023567793};\\\", \\\"{x:763,y:801,t:1527023567810};\\\", \\\"{x:817,y:810,t:1527023567827};\\\", \\\"{x:834,y:814,t:1527023567843};\\\", \\\"{x:857,y:817,t:1527023567859};\\\", \\\"{x:876,y:818,t:1527023567877};\\\", \\\"{x:897,y:818,t:1527023567893};\\\", \\\"{x:913,y:818,t:1527023567910};\\\", \\\"{x:935,y:820,t:1527023567926};\\\", \\\"{x:955,y:821,t:1527023567944};\\\", \\\"{x:964,y:821,t:1527023567960};\\\", \\\"{x:970,y:822,t:1527023567976};\\\", \\\"{x:974,y:822,t:1527023567993};\\\", \\\"{x:975,y:822,t:1527023568010};\\\", \\\"{x:977,y:822,t:1527023568026};\\\", \\\"{x:978,y:822,t:1527023568044};\\\", \\\"{x:980,y:823,t:1527023568060};\\\" ] }, { \\\"rt\\\": 40701, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 704052, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -C -C -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:980,y:826,t:1527023569455};\\\", \\\"{x:980,y:828,t:1527023569475};\\\", \\\"{x:982,y:828,t:1527023570023};\\\", \\\"{x:985,y:828,t:1527023570031};\\\", \\\"{x:989,y:827,t:1527023570045};\\\", \\\"{x:991,y:826,t:1527023570062};\\\", \\\"{x:1003,y:820,t:1527023570079};\\\", \\\"{x:1020,y:813,t:1527023570095};\\\", \\\"{x:1041,y:808,t:1527023570112};\\\", \\\"{x:1063,y:799,t:1527023570129};\\\", \\\"{x:1114,y:776,t:1527023570145};\\\", \\\"{x:1145,y:763,t:1527023570163};\\\", \\\"{x:1184,y:746,t:1527023570180};\\\", \\\"{x:1207,y:737,t:1527023570195};\\\", \\\"{x:1217,y:729,t:1527023570212};\\\", \\\"{x:1221,y:725,t:1527023570229};\\\", \\\"{x:1224,y:723,t:1527023570245};\\\", \\\"{x:1224,y:722,t:1527023570271};\\\", \\\"{x:1227,y:717,t:1527023570279};\\\", \\\"{x:1227,y:703,t:1527023570296};\\\", \\\"{x:1230,y:682,t:1527023570312};\\\", \\\"{x:1231,y:660,t:1527023570329};\\\", \\\"{x:1232,y:641,t:1527023570346};\\\", \\\"{x:1228,y:623,t:1527023570362};\\\", \\\"{x:1218,y:607,t:1527023570380};\\\", \\\"{x:1212,y:596,t:1527023570396};\\\", \\\"{x:1206,y:580,t:1527023570412};\\\", \\\"{x:1197,y:557,t:1527023570429};\\\", \\\"{x:1190,y:538,t:1527023570446};\\\", \\\"{x:1181,y:518,t:1527023570463};\\\", \\\"{x:1173,y:497,t:1527023570478};\\\", \\\"{x:1171,y:493,t:1527023570496};\\\", \\\"{x:1172,y:490,t:1527023570512};\\\", \\\"{x:1172,y:488,t:1527023570529};\\\", \\\"{x:1172,y:487,t:1527023570546};\\\", \\\"{x:1172,y:485,t:1527023570562};\\\", \\\"{x:1174,y:484,t:1527023570579};\\\", \\\"{x:1177,y:484,t:1527023570839};\\\", \\\"{x:1182,y:484,t:1527023570847};\\\", \\\"{x:1183,y:484,t:1527023570862};\\\", \\\"{x:1194,y:484,t:1527023570879};\\\", \\\"{x:1200,y:485,t:1527023570897};\\\", \\\"{x:1211,y:489,t:1527023570912};\\\", \\\"{x:1222,y:490,t:1527023570930};\\\", \\\"{x:1233,y:490,t:1527023570947};\\\", \\\"{x:1240,y:490,t:1527023570963};\\\", \\\"{x:1246,y:491,t:1527023570979};\\\", \\\"{x:1251,y:491,t:1527023570997};\\\", \\\"{x:1255,y:491,t:1527023571014};\\\", \\\"{x:1258,y:491,t:1527023571029};\\\", \\\"{x:1261,y:490,t:1527023571046};\\\", \\\"{x:1264,y:490,t:1527023571063};\\\", \\\"{x:1267,y:489,t:1527023571080};\\\", \\\"{x:1268,y:489,t:1527023571097};\\\", \\\"{x:1270,y:489,t:1527023571113};\\\", \\\"{x:1271,y:489,t:1527023571130};\\\", \\\"{x:1272,y:488,t:1527023571240};\\\", \\\"{x:1274,y:488,t:1527023571703};\\\", \\\"{x:1277,y:488,t:1527023571713};\\\", \\\"{x:1279,y:488,t:1527023571731};\\\", \\\"{x:1280,y:488,t:1527023571746};\\\", \\\"{x:1282,y:488,t:1527023571764};\\\", \\\"{x:1283,y:488,t:1527023571781};\\\", \\\"{x:1284,y:488,t:1527023571797};\\\", \\\"{x:1286,y:488,t:1527023571815};\\\", \\\"{x:1288,y:489,t:1527023571830};\\\", \\\"{x:1290,y:489,t:1527023571846};\\\", \\\"{x:1292,y:490,t:1527023571863};\\\", \\\"{x:1296,y:490,t:1527023571881};\\\", \\\"{x:1298,y:491,t:1527023571897};\\\", \\\"{x:1299,y:491,t:1527023571914};\\\", \\\"{x:1300,y:491,t:1527023571951};\\\", \\\"{x:1301,y:491,t:1527023571967};\\\", \\\"{x:1302,y:491,t:1527023571983};\\\", \\\"{x:1303,y:491,t:1527023572015};\\\", \\\"{x:1304,y:491,t:1527023572030};\\\", \\\"{x:1305,y:491,t:1527023572048};\\\", \\\"{x:1306,y:491,t:1527023572064};\\\", \\\"{x:1308,y:491,t:1527023572080};\\\", \\\"{x:1311,y:493,t:1527023572097};\\\", \\\"{x:1312,y:493,t:1527023572113};\\\", \\\"{x:1315,y:493,t:1527023572130};\\\", \\\"{x:1318,y:494,t:1527023572147};\\\", \\\"{x:1320,y:495,t:1527023572164};\\\", \\\"{x:1321,y:495,t:1527023572190};\\\", \\\"{x:1322,y:495,t:1527023572206};\\\", \\\"{x:1323,y:495,t:1527023572222};\\\", \\\"{x:1323,y:496,t:1527023572246};\\\", \\\"{x:1324,y:496,t:1527023572262};\\\", \\\"{x:1325,y:496,t:1527023572270};\\\", \\\"{x:1326,y:496,t:1527023572343};\\\", \\\"{x:1327,y:496,t:1527023572367};\\\", \\\"{x:1328,y:496,t:1527023572382};\\\", \\\"{x:1329,y:497,t:1527023572400};\\\", \\\"{x:1330,y:497,t:1527023572423};\\\", \\\"{x:1331,y:497,t:1527023572439};\\\", \\\"{x:1334,y:498,t:1527023572455};\\\", \\\"{x:1335,y:498,t:1527023572503};\\\", \\\"{x:1336,y:498,t:1527023572519};\\\", \\\"{x:1339,y:498,t:1527023572535};\\\", \\\"{x:1339,y:499,t:1527023572559};\\\", \\\"{x:1340,y:499,t:1527023572575};\\\", \\\"{x:1340,y:500,t:1527023572583};\\\", \\\"{x:1341,y:500,t:1527023572597};\\\", \\\"{x:1344,y:500,t:1527023572614};\\\", \\\"{x:1345,y:501,t:1527023572630};\\\", \\\"{x:1346,y:501,t:1527023572647};\\\", \\\"{x:1349,y:502,t:1527023572664};\\\", \\\"{x:1350,y:502,t:1527023572686};\\\", \\\"{x:1351,y:503,t:1527023572751};\\\", \\\"{x:1352,y:503,t:1527023572766};\\\", \\\"{x:1353,y:503,t:1527023572814};\\\", \\\"{x:1355,y:504,t:1527023572838};\\\", \\\"{x:1356,y:504,t:1527023572870};\\\", \\\"{x:1357,y:504,t:1527023572881};\\\", \\\"{x:1358,y:504,t:1527023572897};\\\", \\\"{x:1360,y:504,t:1527023572914};\\\", \\\"{x:1362,y:504,t:1527023573039};\\\", \\\"{x:1363,y:504,t:1527023573063};\\\", \\\"{x:1364,y:506,t:1527023573071};\\\", \\\"{x:1365,y:506,t:1527023573095};\\\", \\\"{x:1366,y:506,t:1527023573103};\\\", \\\"{x:1367,y:506,t:1527023573115};\\\", \\\"{x:1368,y:506,t:1527023573131};\\\", \\\"{x:1369,y:507,t:1527023573148};\\\", \\\"{x:1370,y:507,t:1527023573164};\\\", \\\"{x:1371,y:507,t:1527023573182};\\\", \\\"{x:1373,y:507,t:1527023573199};\\\", \\\"{x:1375,y:507,t:1527023573214};\\\", \\\"{x:1376,y:507,t:1527023573895};\\\", \\\"{x:1378,y:507,t:1527023573936};\\\", \\\"{x:1380,y:507,t:1527023573948};\\\", \\\"{x:1385,y:507,t:1527023573965};\\\", \\\"{x:1390,y:507,t:1527023573982};\\\", \\\"{x:1396,y:507,t:1527023573999};\\\", \\\"{x:1404,y:507,t:1527023574015};\\\", \\\"{x:1406,y:507,t:1527023574031};\\\", \\\"{x:1408,y:507,t:1527023574048};\\\", \\\"{x:1409,y:507,t:1527023574066};\\\", \\\"{x:1411,y:507,t:1527023574083};\\\", \\\"{x:1412,y:507,t:1527023574151};\\\", \\\"{x:1413,y:507,t:1527023574165};\\\", \\\"{x:1415,y:507,t:1527023574183};\\\", \\\"{x:1417,y:507,t:1527023574199};\\\", \\\"{x:1418,y:507,t:1527023574215};\\\", \\\"{x:1420,y:507,t:1527023574233};\\\", \\\"{x:1423,y:509,t:1527023574249};\\\", \\\"{x:1424,y:509,t:1527023574266};\\\", \\\"{x:1427,y:509,t:1527023574283};\\\", \\\"{x:1428,y:509,t:1527023574299};\\\", \\\"{x:1430,y:510,t:1527023574316};\\\", \\\"{x:1433,y:510,t:1527023574332};\\\", \\\"{x:1435,y:511,t:1527023574348};\\\", \\\"{x:1437,y:512,t:1527023574366};\\\", \\\"{x:1437,y:513,t:1527023575583};\\\", \\\"{x:1435,y:513,t:1527023576415};\\\", \\\"{x:1432,y:513,t:1527023576559};\\\", \\\"{x:1428,y:513,t:1527023576567};\\\", \\\"{x:1422,y:513,t:1527023576584};\\\", \\\"{x:1415,y:513,t:1527023576601};\\\", \\\"{x:1411,y:513,t:1527023576618};\\\", \\\"{x:1410,y:513,t:1527023576634};\\\", \\\"{x:1408,y:513,t:1527023576727};\\\", \\\"{x:1406,y:513,t:1527023576734};\\\", \\\"{x:1403,y:513,t:1527023576750};\\\", \\\"{x:1399,y:514,t:1527023576767};\\\", \\\"{x:1398,y:520,t:1527023577944};\\\", \\\"{x:1396,y:530,t:1527023577951};\\\", \\\"{x:1390,y:562,t:1527023577968};\\\", \\\"{x:1383,y:596,t:1527023577985};\\\", \\\"{x:1379,y:630,t:1527023578002};\\\", \\\"{x:1377,y:660,t:1527023578019};\\\", \\\"{x:1378,y:685,t:1527023578035};\\\", \\\"{x:1379,y:711,t:1527023578052};\\\", \\\"{x:1379,y:738,t:1527023578069};\\\", \\\"{x:1379,y:749,t:1527023578086};\\\", \\\"{x:1375,y:763,t:1527023578102};\\\", \\\"{x:1368,y:774,t:1527023578119};\\\", \\\"{x:1365,y:778,t:1527023578135};\\\", \\\"{x:1365,y:779,t:1527023578152};\\\", \\\"{x:1364,y:779,t:1527023578247};\\\", \\\"{x:1362,y:779,t:1527023578375};\\\", \\\"{x:1360,y:779,t:1527023578390};\\\", \\\"{x:1359,y:779,t:1527023578401};\\\", \\\"{x:1357,y:778,t:1527023578418};\\\", \\\"{x:1356,y:778,t:1527023578435};\\\", \\\"{x:1355,y:776,t:1527023578453};\\\", \\\"{x:1353,y:775,t:1527023578494};\\\", \\\"{x:1353,y:774,t:1527023578534};\\\", \\\"{x:1352,y:773,t:1527023578551};\\\", \\\"{x:1351,y:771,t:1527023578558};\\\", \\\"{x:1351,y:770,t:1527023578568};\\\", \\\"{x:1350,y:769,t:1527023578586};\\\", \\\"{x:1349,y:767,t:1527023578604};\\\", \\\"{x:1349,y:766,t:1527023578646};\\\", \\\"{x:1349,y:765,t:1527023578711};\\\", \\\"{x:1349,y:764,t:1527023578742};\\\", \\\"{x:1349,y:763,t:1527023578775};\\\", \\\"{x:1349,y:762,t:1527023578798};\\\", \\\"{x:1348,y:761,t:1527023578831};\\\", \\\"{x:1345,y:763,t:1527023579615};\\\", \\\"{x:1343,y:765,t:1527023579623};\\\", \\\"{x:1342,y:768,t:1527023579638};\\\", \\\"{x:1339,y:772,t:1527023579653};\\\", \\\"{x:1339,y:773,t:1527023579669};\\\", \\\"{x:1337,y:775,t:1527023579687};\\\", \\\"{x:1337,y:776,t:1527023579710};\\\", \\\"{x:1336,y:777,t:1527023579720};\\\", \\\"{x:1335,y:779,t:1527023579736};\\\", \\\"{x:1334,y:780,t:1527023579753};\\\", \\\"{x:1333,y:782,t:1527023579770};\\\", \\\"{x:1332,y:783,t:1527023579787};\\\", \\\"{x:1327,y:786,t:1527023579804};\\\", \\\"{x:1327,y:788,t:1527023579820};\\\", \\\"{x:1326,y:792,t:1527023579837};\\\", \\\"{x:1322,y:798,t:1527023579854};\\\", \\\"{x:1321,y:803,t:1527023579870};\\\", \\\"{x:1318,y:808,t:1527023579887};\\\", \\\"{x:1315,y:813,t:1527023579903};\\\", \\\"{x:1311,y:818,t:1527023579920};\\\", \\\"{x:1309,y:825,t:1527023579936};\\\", \\\"{x:1306,y:833,t:1527023579953};\\\", \\\"{x:1305,y:835,t:1527023579998};\\\", \\\"{x:1303,y:838,t:1527023580006};\\\", \\\"{x:1302,y:841,t:1527023580019};\\\", \\\"{x:1300,y:848,t:1527023580036};\\\", \\\"{x:1297,y:854,t:1527023580053};\\\", \\\"{x:1294,y:862,t:1527023580069};\\\", \\\"{x:1288,y:871,t:1527023580086};\\\", \\\"{x:1285,y:875,t:1527023580104};\\\", \\\"{x:1282,y:881,t:1527023580120};\\\", \\\"{x:1280,y:889,t:1527023580137};\\\", \\\"{x:1279,y:893,t:1527023580154};\\\", \\\"{x:1279,y:897,t:1527023580170};\\\", \\\"{x:1279,y:900,t:1527023580187};\\\", \\\"{x:1276,y:905,t:1527023580204};\\\", \\\"{x:1274,y:909,t:1527023580221};\\\", \\\"{x:1272,y:916,t:1527023580237};\\\", \\\"{x:1270,y:924,t:1527023580254};\\\", \\\"{x:1268,y:932,t:1527023580271};\\\", \\\"{x:1266,y:935,t:1527023580287};\\\", \\\"{x:1265,y:937,t:1527023580304};\\\", \\\"{x:1265,y:939,t:1527023580321};\\\", \\\"{x:1265,y:942,t:1527023580337};\\\", \\\"{x:1265,y:943,t:1527023580353};\\\", \\\"{x:1263,y:946,t:1527023580371};\\\", \\\"{x:1263,y:947,t:1527023580386};\\\", \\\"{x:1263,y:949,t:1527023580404};\\\", \\\"{x:1262,y:950,t:1527023580438};\\\", \\\"{x:1261,y:951,t:1527023580453};\\\", \\\"{x:1260,y:951,t:1527023580471};\\\", \\\"{x:1259,y:952,t:1527023580487};\\\", \\\"{x:1258,y:953,t:1527023580504};\\\", \\\"{x:1257,y:954,t:1527023580527};\\\", \\\"{x:1256,y:955,t:1527023580537};\\\", \\\"{x:1255,y:955,t:1527023580554};\\\", \\\"{x:1255,y:957,t:1527023580574};\\\", \\\"{x:1254,y:957,t:1527023580586};\\\", \\\"{x:1254,y:958,t:1527023580607};\\\", \\\"{x:1253,y:959,t:1527023580631};\\\", \\\"{x:1252,y:959,t:1527023580655};\\\", \\\"{x:1252,y:960,t:1527023580671};\\\", \\\"{x:1248,y:958,t:1527023588376};\\\", \\\"{x:1239,y:950,t:1527023588382};\\\", \\\"{x:1215,y:930,t:1527023588393};\\\", \\\"{x:1156,y:894,t:1527023588410};\\\", \\\"{x:1108,y:857,t:1527023588426};\\\", \\\"{x:1024,y:812,t:1527023588443};\\\", \\\"{x:930,y:770,t:1527023588459};\\\", \\\"{x:838,y:729,t:1527023588476};\\\", \\\"{x:785,y:704,t:1527023588493};\\\", \\\"{x:736,y:678,t:1527023588510};\\\", \\\"{x:721,y:666,t:1527023588526};\\\", \\\"{x:712,y:657,t:1527023588543};\\\", \\\"{x:707,y:651,t:1527023588560};\\\", \\\"{x:701,y:644,t:1527023588576};\\\", \\\"{x:689,y:637,t:1527023588592};\\\", \\\"{x:677,y:624,t:1527023588611};\\\", \\\"{x:666,y:611,t:1527023588626};\\\", \\\"{x:651,y:597,t:1527023588643};\\\", \\\"{x:637,y:582,t:1527023588656};\\\", \\\"{x:620,y:564,t:1527023588673};\\\", \\\"{x:600,y:552,t:1527023588689};\\\", \\\"{x:580,y:540,t:1527023588710};\\\", \\\"{x:569,y:535,t:1527023588727};\\\", \\\"{x:558,y:529,t:1527023588744};\\\", \\\"{x:546,y:526,t:1527023588761};\\\", \\\"{x:531,y:524,t:1527023588779};\\\", \\\"{x:519,y:521,t:1527023588793};\\\", \\\"{x:511,y:520,t:1527023588810};\\\", \\\"{x:503,y:518,t:1527023588828};\\\", \\\"{x:500,y:516,t:1527023588844};\\\", \\\"{x:490,y:513,t:1527023588861};\\\", \\\"{x:478,y:508,t:1527023588877};\\\", \\\"{x:473,y:508,t:1527023588893};\\\", \\\"{x:472,y:508,t:1527023588918};\\\", \\\"{x:471,y:508,t:1527023588933};\\\", \\\"{x:470,y:508,t:1527023588949};\\\", \\\"{x:469,y:508,t:1527023588961};\\\", \\\"{x:464,y:510,t:1527023588978};\\\", \\\"{x:457,y:514,t:1527023588995};\\\", \\\"{x:447,y:518,t:1527023589011};\\\", \\\"{x:435,y:522,t:1527023589028};\\\", \\\"{x:425,y:527,t:1527023589045};\\\", \\\"{x:412,y:534,t:1527023589061};\\\", \\\"{x:400,y:543,t:1527023589078};\\\", \\\"{x:395,y:545,t:1527023589093};\\\", \\\"{x:394,y:546,t:1527023589110};\\\", \\\"{x:390,y:549,t:1527023589127};\\\", \\\"{x:385,y:552,t:1527023589144};\\\", \\\"{x:381,y:558,t:1527023589161};\\\", \\\"{x:379,y:561,t:1527023589178};\\\", \\\"{x:375,y:565,t:1527023589195};\\\", \\\"{x:371,y:568,t:1527023589211};\\\", \\\"{x:363,y:574,t:1527023589228};\\\", \\\"{x:358,y:577,t:1527023589243};\\\", \\\"{x:353,y:578,t:1527023589261};\\\", \\\"{x:345,y:581,t:1527023589277};\\\", \\\"{x:341,y:581,t:1527023589294};\\\", \\\"{x:336,y:582,t:1527023589311};\\\", \\\"{x:334,y:583,t:1527023589328};\\\", \\\"{x:333,y:584,t:1527023589344};\\\", \\\"{x:332,y:585,t:1527023589361};\\\", \\\"{x:328,y:585,t:1527023589380};\\\", \\\"{x:322,y:585,t:1527023589394};\\\", \\\"{x:314,y:586,t:1527023589411};\\\", \\\"{x:305,y:588,t:1527023589428};\\\", \\\"{x:293,y:589,t:1527023589444};\\\", \\\"{x:282,y:591,t:1527023589461};\\\", \\\"{x:266,y:595,t:1527023589478};\\\", \\\"{x:247,y:599,t:1527023589494};\\\", \\\"{x:237,y:601,t:1527023589512};\\\", \\\"{x:231,y:605,t:1527023589527};\\\", \\\"{x:228,y:606,t:1527023589544};\\\", \\\"{x:226,y:608,t:1527023589561};\\\", \\\"{x:225,y:609,t:1527023589578};\\\", \\\"{x:224,y:610,t:1527023589595};\\\", \\\"{x:223,y:611,t:1527023589610};\\\", \\\"{x:221,y:615,t:1527023589627};\\\", \\\"{x:219,y:620,t:1527023589645};\\\", \\\"{x:219,y:623,t:1527023589660};\\\", \\\"{x:223,y:629,t:1527023589677};\\\", \\\"{x:230,y:629,t:1527023589695};\\\", \\\"{x:247,y:632,t:1527023589713};\\\", \\\"{x:263,y:636,t:1527023589728};\\\", \\\"{x:294,y:640,t:1527023589747};\\\", \\\"{x:367,y:653,t:1527023589762};\\\", \\\"{x:426,y:656,t:1527023589778};\\\", \\\"{x:465,y:656,t:1527023589795};\\\", \\\"{x:497,y:656,t:1527023589812};\\\", \\\"{x:517,y:650,t:1527023589829};\\\", \\\"{x:534,y:645,t:1527023589845};\\\", \\\"{x:539,y:641,t:1527023589862};\\\", \\\"{x:542,y:640,t:1527023589878};\\\", \\\"{x:544,y:637,t:1527023589894};\\\", \\\"{x:548,y:633,t:1527023589911};\\\", \\\"{x:550,y:627,t:1527023589928};\\\", \\\"{x:550,y:623,t:1527023589944};\\\", \\\"{x:552,y:618,t:1527023589961};\\\", \\\"{x:553,y:613,t:1527023589978};\\\", \\\"{x:553,y:609,t:1527023589994};\\\", \\\"{x:553,y:603,t:1527023590012};\\\", \\\"{x:546,y:592,t:1527023590029};\\\", \\\"{x:533,y:580,t:1527023590044};\\\", \\\"{x:509,y:565,t:1527023590062};\\\", \\\"{x:496,y:558,t:1527023590079};\\\", \\\"{x:484,y:555,t:1527023590095};\\\", \\\"{x:480,y:554,t:1527023590112};\\\", \\\"{x:473,y:554,t:1527023590128};\\\", \\\"{x:465,y:554,t:1527023590145};\\\", \\\"{x:451,y:559,t:1527023590163};\\\", \\\"{x:439,y:568,t:1527023590180};\\\", \\\"{x:427,y:573,t:1527023590194};\\\", \\\"{x:421,y:576,t:1527023590211};\\\", \\\"{x:416,y:578,t:1527023590230};\\\", \\\"{x:415,y:579,t:1527023590245};\\\", \\\"{x:414,y:581,t:1527023590262};\\\", \\\"{x:413,y:585,t:1527023590278};\\\", \\\"{x:413,y:593,t:1527023590295};\\\", \\\"{x:412,y:601,t:1527023590312};\\\", \\\"{x:413,y:608,t:1527023590328};\\\", \\\"{x:416,y:611,t:1527023590345};\\\", \\\"{x:422,y:613,t:1527023590362};\\\", \\\"{x:433,y:617,t:1527023590379};\\\", \\\"{x:454,y:624,t:1527023590395};\\\", \\\"{x:484,y:630,t:1527023590412};\\\", \\\"{x:505,y:633,t:1527023590429};\\\", \\\"{x:545,y:628,t:1527023590446};\\\", \\\"{x:578,y:618,t:1527023590462};\\\", \\\"{x:593,y:608,t:1527023590478};\\\", \\\"{x:605,y:599,t:1527023590496};\\\", \\\"{x:615,y:590,t:1527023590512};\\\", \\\"{x:625,y:580,t:1527023590529};\\\", \\\"{x:630,y:572,t:1527023590545};\\\", \\\"{x:632,y:568,t:1527023590561};\\\", \\\"{x:633,y:566,t:1527023590579};\\\", \\\"{x:633,y:564,t:1527023590596};\\\", \\\"{x:635,y:562,t:1527023590704};\\\", \\\"{x:637,y:561,t:1527023590719};\\\", \\\"{x:639,y:561,t:1527023590729};\\\", \\\"{x:644,y:559,t:1527023590747};\\\", \\\"{x:661,y:556,t:1527023590762};\\\", \\\"{x:679,y:552,t:1527023590780};\\\", \\\"{x:702,y:547,t:1527023590795};\\\", \\\"{x:726,y:544,t:1527023590813};\\\", \\\"{x:761,y:536,t:1527023590829};\\\", \\\"{x:787,y:524,t:1527023590846};\\\", \\\"{x:802,y:520,t:1527023590863};\\\", \\\"{x:817,y:515,t:1527023590879};\\\", \\\"{x:823,y:511,t:1527023590896};\\\", \\\"{x:825,y:508,t:1527023590912};\\\", \\\"{x:826,y:507,t:1527023590929};\\\", \\\"{x:827,y:506,t:1527023590949};\\\", \\\"{x:828,y:505,t:1527023591196};\\\", \\\"{x:831,y:504,t:1527023591213};\\\", \\\"{x:832,y:504,t:1527023591229};\\\", \\\"{x:832,y:504,t:1527023591307};\\\", \\\"{x:838,y:507,t:1527023591615};\\\", \\\"{x:856,y:535,t:1527023591632};\\\", \\\"{x:878,y:558,t:1527023591646};\\\", \\\"{x:896,y:574,t:1527023591663};\\\", \\\"{x:918,y:590,t:1527023591680};\\\", \\\"{x:941,y:607,t:1527023591697};\\\", \\\"{x:967,y:625,t:1527023591713};\\\", \\\"{x:998,y:640,t:1527023591729};\\\", \\\"{x:1031,y:651,t:1527023591746};\\\", \\\"{x:1075,y:661,t:1527023591762};\\\", \\\"{x:1084,y:668,t:1527023591780};\\\", \\\"{x:1101,y:670,t:1527023591797};\\\", \\\"{x:1122,y:674,t:1527023591813};\\\", \\\"{x:1144,y:675,t:1527023591829};\\\", \\\"{x:1150,y:675,t:1527023591846};\\\", \\\"{x:1156,y:675,t:1527023591863};\\\", \\\"{x:1162,y:675,t:1527023591880};\\\", \\\"{x:1172,y:674,t:1527023591897};\\\", \\\"{x:1185,y:674,t:1527023591913};\\\", \\\"{x:1196,y:674,t:1527023591930};\\\", \\\"{x:1206,y:674,t:1527023591947};\\\", \\\"{x:1219,y:674,t:1527023591964};\\\", \\\"{x:1235,y:674,t:1527023591980};\\\", \\\"{x:1256,y:676,t:1527023591997};\\\", \\\"{x:1306,y:690,t:1527023592013};\\\", \\\"{x:1340,y:701,t:1527023592031};\\\", \\\"{x:1368,y:707,t:1527023592047};\\\", \\\"{x:1387,y:712,t:1527023592065};\\\", \\\"{x:1409,y:722,t:1527023592080};\\\", \\\"{x:1425,y:730,t:1527023592098};\\\", \\\"{x:1435,y:735,t:1527023592114};\\\", \\\"{x:1440,y:739,t:1527023592131};\\\", \\\"{x:1438,y:739,t:1527023592567};\\\", \\\"{x:1437,y:740,t:1527023592582};\\\", \\\"{x:1422,y:746,t:1527023592599};\\\", \\\"{x:1413,y:750,t:1527023592615};\\\", \\\"{x:1400,y:755,t:1527023592631};\\\", \\\"{x:1391,y:761,t:1527023592648};\\\", \\\"{x:1386,y:764,t:1527023592664};\\\", \\\"{x:1377,y:768,t:1527023592681};\\\", \\\"{x:1375,y:768,t:1527023592698};\\\", \\\"{x:1374,y:769,t:1527023592714};\\\", \\\"{x:1372,y:769,t:1527023592880};\\\", \\\"{x:1369,y:768,t:1527023592887};\\\", \\\"{x:1366,y:765,t:1527023592898};\\\", \\\"{x:1360,y:759,t:1527023592916};\\\", \\\"{x:1354,y:755,t:1527023592932};\\\", \\\"{x:1345,y:751,t:1527023592949};\\\", \\\"{x:1341,y:751,t:1527023592966};\\\", \\\"{x:1339,y:751,t:1527023592982};\\\", \\\"{x:1338,y:751,t:1527023593071};\\\", \\\"{x:1337,y:751,t:1527023593143};\\\", \\\"{x:1335,y:751,t:1527023593183};\\\", \\\"{x:1335,y:752,t:1527023593327};\\\", \\\"{x:1338,y:752,t:1527023593342};\\\", \\\"{x:1339,y:753,t:1527023593351};\\\", \\\"{x:1340,y:753,t:1527023593366};\\\", \\\"{x:1342,y:754,t:1527023593382};\\\", \\\"{x:1343,y:754,t:1527023595511};\\\", \\\"{x:1344,y:755,t:1527023596287};\\\", \\\"{x:1344,y:756,t:1527023596599};\\\", \\\"{x:1344,y:757,t:1527023596663};\\\", \\\"{x:1345,y:758,t:1527023596695};\\\", \\\"{x:1345,y:759,t:1527023596726};\\\", \\\"{x:1345,y:760,t:1527023597326};\\\", \\\"{x:1344,y:760,t:1527023597358};\\\", \\\"{x:1340,y:760,t:1527023597371};\\\", \\\"{x:1332,y:758,t:1527023597386};\\\", \\\"{x:1316,y:754,t:1527023597403};\\\", \\\"{x:1293,y:747,t:1527023597421};\\\", \\\"{x:1274,y:743,t:1527023597438};\\\", \\\"{x:1258,y:734,t:1527023597454};\\\", \\\"{x:1241,y:728,t:1527023597471};\\\", \\\"{x:1228,y:723,t:1527023597487};\\\", \\\"{x:1216,y:718,t:1527023597504};\\\", \\\"{x:1192,y:711,t:1527023597520};\\\", \\\"{x:1155,y:695,t:1527023597538};\\\", \\\"{x:1080,y:673,t:1527023597554};\\\", \\\"{x:1001,y:647,t:1527023597570};\\\", \\\"{x:951,y:633,t:1527023597587};\\\", \\\"{x:860,y:607,t:1527023597604};\\\", \\\"{x:802,y:586,t:1527023597621};\\\", \\\"{x:738,y:567,t:1527023597650};\\\", \\\"{x:733,y:566,t:1527023597668};\\\", \\\"{x:732,y:566,t:1527023597684};\\\", \\\"{x:731,y:566,t:1527023597725};\\\", \\\"{x:729,y:566,t:1527023597733};\\\", \\\"{x:723,y:566,t:1527023597751};\\\", \\\"{x:717,y:566,t:1527023597768};\\\", \\\"{x:711,y:565,t:1527023597784};\\\", \\\"{x:706,y:565,t:1527023597801};\\\", \\\"{x:698,y:561,t:1527023597818};\\\", \\\"{x:681,y:556,t:1527023597834};\\\", \\\"{x:664,y:552,t:1527023597852};\\\", \\\"{x:641,y:546,t:1527023597869};\\\", \\\"{x:623,y:542,t:1527023597885};\\\", \\\"{x:602,y:539,t:1527023597901};\\\", \\\"{x:577,y:533,t:1527023597919};\\\", \\\"{x:563,y:531,t:1527023597935};\\\", \\\"{x:556,y:530,t:1527023597952};\\\", \\\"{x:546,y:530,t:1527023597968};\\\", \\\"{x:535,y:528,t:1527023597985};\\\", \\\"{x:523,y:527,t:1527023598002};\\\", \\\"{x:518,y:527,t:1527023598018};\\\", \\\"{x:509,y:527,t:1527023598035};\\\", \\\"{x:505,y:527,t:1527023598053};\\\", \\\"{x:495,y:528,t:1527023598070};\\\", \\\"{x:476,y:533,t:1527023598085};\\\", \\\"{x:460,y:543,t:1527023598102};\\\", \\\"{x:448,y:552,t:1527023598117};\\\", \\\"{x:446,y:553,t:1527023598135};\\\", \\\"{x:437,y:560,t:1527023598154};\\\", \\\"{x:433,y:562,t:1527023598168};\\\", \\\"{x:429,y:564,t:1527023598185};\\\", \\\"{x:426,y:567,t:1527023598202};\\\", \\\"{x:422,y:572,t:1527023598218};\\\", \\\"{x:416,y:583,t:1527023598235};\\\", \\\"{x:409,y:595,t:1527023598252};\\\", \\\"{x:404,y:602,t:1527023598269};\\\", \\\"{x:403,y:604,t:1527023598286};\\\", \\\"{x:402,y:605,t:1527023598302};\\\", \\\"{x:400,y:606,t:1527023598318};\\\", \\\"{x:390,y:608,t:1527023598335};\\\", \\\"{x:383,y:609,t:1527023598352};\\\", \\\"{x:369,y:609,t:1527023598368};\\\", \\\"{x:353,y:609,t:1527023598385};\\\", \\\"{x:339,y:609,t:1527023598402};\\\", \\\"{x:329,y:608,t:1527023598418};\\\", \\\"{x:316,y:606,t:1527023598435};\\\", \\\"{x:305,y:604,t:1527023598452};\\\", \\\"{x:297,y:603,t:1527023598468};\\\", \\\"{x:290,y:602,t:1527023598485};\\\", \\\"{x:283,y:600,t:1527023598502};\\\", \\\"{x:266,y:600,t:1527023598518};\\\", \\\"{x:252,y:600,t:1527023598535};\\\", \\\"{x:244,y:600,t:1527023598553};\\\", \\\"{x:240,y:600,t:1527023598569};\\\", \\\"{x:239,y:600,t:1527023598585};\\\", \\\"{x:237,y:600,t:1527023598603};\\\", \\\"{x:234,y:600,t:1527023598619};\\\", \\\"{x:229,y:600,t:1527023598635};\\\", \\\"{x:222,y:600,t:1527023598652};\\\", \\\"{x:216,y:600,t:1527023598669};\\\", \\\"{x:204,y:600,t:1527023598686};\\\", \\\"{x:201,y:600,t:1527023598702};\\\", \\\"{x:200,y:600,t:1527023598720};\\\", \\\"{x:198,y:600,t:1527023598737};\\\", \\\"{x:198,y:602,t:1527023598753};\\\", \\\"{x:200,y:604,t:1527023598769};\\\", \\\"{x:201,y:604,t:1527023598785};\\\", \\\"{x:204,y:604,t:1527023598802};\\\", \\\"{x:212,y:604,t:1527023598819};\\\", \\\"{x:230,y:604,t:1527023598835};\\\", \\\"{x:257,y:604,t:1527023598852};\\\", \\\"{x:313,y:604,t:1527023598870};\\\", \\\"{x:377,y:604,t:1527023598886};\\\", \\\"{x:507,y:613,t:1527023598903};\\\", \\\"{x:604,y:613,t:1527023598919};\\\", \\\"{x:672,y:614,t:1527023598935};\\\", \\\"{x:751,y:620,t:1527023598952};\\\", \\\"{x:790,y:620,t:1527023598969};\\\", \\\"{x:822,y:619,t:1527023598985};\\\", \\\"{x:834,y:618,t:1527023599002};\\\", \\\"{x:847,y:618,t:1527023599019};\\\", \\\"{x:856,y:618,t:1527023599035};\\\", \\\"{x:865,y:618,t:1527023599052};\\\", \\\"{x:869,y:618,t:1527023599070};\\\", \\\"{x:870,y:617,t:1527023599085};\\\", \\\"{x:872,y:616,t:1527023599142};\\\", \\\"{x:873,y:614,t:1527023599152};\\\", \\\"{x:875,y:608,t:1527023599169};\\\", \\\"{x:877,y:599,t:1527023599188};\\\", \\\"{x:878,y:587,t:1527023599203};\\\", \\\"{x:875,y:572,t:1527023599219};\\\", \\\"{x:870,y:556,t:1527023599236};\\\", \\\"{x:869,y:544,t:1527023599253};\\\", \\\"{x:866,y:540,t:1527023599269};\\\", \\\"{x:865,y:536,t:1527023599286};\\\", \\\"{x:864,y:534,t:1527023599302};\\\", \\\"{x:863,y:534,t:1527023599422};\\\", \\\"{x:861,y:534,t:1527023599447};\\\", \\\"{x:860,y:534,t:1527023599454};\\\", \\\"{x:859,y:534,t:1527023599469};\\\", \\\"{x:855,y:534,t:1527023599486};\\\", \\\"{x:855,y:533,t:1527023599511};\\\", \\\"{x:854,y:533,t:1527023599519};\\\", \\\"{x:853,y:533,t:1527023599551};\\\", \\\"{x:852,y:533,t:1527023599606};\\\", \\\"{x:851,y:533,t:1527023599622};\\\", \\\"{x:850,y:533,t:1527023599775};\\\", \\\"{x:849,y:533,t:1527023599790};\\\", \\\"{x:848,y:533,t:1527023599847};\\\", \\\"{x:847,y:533,t:1527023599863};\\\", \\\"{x:845,y:533,t:1527023599870};\\\", \\\"{x:842,y:534,t:1527023599974};\\\", \\\"{x:840,y:534,t:1527023599985};\\\", \\\"{x:835,y:536,t:1527023600002};\\\", \\\"{x:834,y:536,t:1527023600020};\\\", \\\"{x:832,y:536,t:1527023600036};\\\", \\\"{x:831,y:536,t:1527023600054};\\\", \\\"{x:831,y:537,t:1527023600070};\\\", \\\"{x:830,y:538,t:1527023600174};\\\", \\\"{x:829,y:538,t:1527023600186};\\\", \\\"{x:828,y:538,t:1527023600203};\\\", \\\"{x:826,y:540,t:1527023600220};\\\", \\\"{x:825,y:540,t:1527023600262};\\\", \\\"{x:827,y:539,t:1527023600646};\\\", \\\"{x:832,y:538,t:1527023600654};\\\", \\\"{x:850,y:538,t:1527023600670};\\\", \\\"{x:878,y:538,t:1527023600689};\\\", \\\"{x:907,y:538,t:1527023600705};\\\", \\\"{x:942,y:544,t:1527023600720};\\\", \\\"{x:983,y:548,t:1527023600738};\\\", \\\"{x:1048,y:556,t:1527023600754};\\\", \\\"{x:1122,y:563,t:1527023600770};\\\", \\\"{x:1183,y:581,t:1527023600787};\\\", \\\"{x:1221,y:587,t:1527023600804};\\\", \\\"{x:1263,y:594,t:1527023600820};\\\", \\\"{x:1303,y:602,t:1527023600837};\\\", \\\"{x:1336,y:608,t:1527023600854};\\\", \\\"{x:1357,y:609,t:1527023600871};\\\", \\\"{x:1374,y:613,t:1527023600887};\\\", \\\"{x:1389,y:617,t:1527023600904};\\\", \\\"{x:1401,y:618,t:1527023600922};\\\", \\\"{x:1413,y:619,t:1527023600937};\\\", \\\"{x:1421,y:621,t:1527023600954};\\\", \\\"{x:1422,y:621,t:1527023600971};\\\", \\\"{x:1423,y:621,t:1527023600987};\\\", \\\"{x:1424,y:621,t:1527023601004};\\\", \\\"{x:1424,y:618,t:1527023601070};\\\", \\\"{x:1424,y:614,t:1527023601078};\\\", \\\"{x:1424,y:611,t:1527023601087};\\\", \\\"{x:1422,y:602,t:1527023601104};\\\", \\\"{x:1420,y:599,t:1527023601122};\\\", \\\"{x:1419,y:598,t:1527023601159};\\\", \\\"{x:1419,y:596,t:1527023601174};\\\", \\\"{x:1419,y:595,t:1527023601188};\\\", \\\"{x:1419,y:594,t:1527023601205};\\\", \\\"{x:1418,y:593,t:1527023601222};\\\", \\\"{x:1418,y:592,t:1527023601246};\\\", \\\"{x:1418,y:591,t:1527023601270};\\\", \\\"{x:1418,y:590,t:1527023601289};\\\", \\\"{x:1418,y:587,t:1527023601305};\\\", \\\"{x:1418,y:585,t:1527023601321};\\\", \\\"{x:1417,y:585,t:1527023601339};\\\", \\\"{x:1417,y:584,t:1527023601355};\\\", \\\"{x:1417,y:583,t:1527023601372};\\\", \\\"{x:1416,y:582,t:1527023601389};\\\", \\\"{x:1415,y:580,t:1527023601405};\\\", \\\"{x:1412,y:576,t:1527023601421};\\\", \\\"{x:1403,y:568,t:1527023601439};\\\", \\\"{x:1402,y:567,t:1527023601455};\\\", \\\"{x:1402,y:568,t:1527023601687};\\\", \\\"{x:1402,y:570,t:1527023601703};\\\", \\\"{x:1402,y:571,t:1527023601710};\\\", \\\"{x:1402,y:573,t:1527023601722};\\\", \\\"{x:1405,y:576,t:1527023601739};\\\", \\\"{x:1405,y:577,t:1527023601755};\\\", \\\"{x:1408,y:580,t:1527023601772};\\\", \\\"{x:1410,y:582,t:1527023601789};\\\", \\\"{x:1412,y:584,t:1527023601806};\\\", \\\"{x:1413,y:585,t:1527023601822};\\\", \\\"{x:1415,y:588,t:1527023601839};\\\", \\\"{x:1416,y:591,t:1527023601856};\\\", \\\"{x:1419,y:594,t:1527023601873};\\\", \\\"{x:1420,y:596,t:1527023601889};\\\", \\\"{x:1421,y:598,t:1527023601906};\\\", \\\"{x:1423,y:599,t:1527023601923};\\\", \\\"{x:1424,y:601,t:1527023601939};\\\", \\\"{x:1427,y:602,t:1527023601956};\\\", \\\"{x:1428,y:604,t:1527023601973};\\\", \\\"{x:1431,y:607,t:1527023601988};\\\", \\\"{x:1433,y:610,t:1527023602006};\\\", \\\"{x:1436,y:613,t:1527023602022};\\\", \\\"{x:1438,y:616,t:1527023602039};\\\", \\\"{x:1439,y:618,t:1527023602056};\\\", \\\"{x:1442,y:622,t:1527023602073};\\\", \\\"{x:1443,y:624,t:1527023602089};\\\", \\\"{x:1444,y:628,t:1527023602106};\\\", \\\"{x:1445,y:629,t:1527023602123};\\\", \\\"{x:1447,y:630,t:1527023602138};\\\", \\\"{x:1447,y:633,t:1527023602156};\\\", \\\"{x:1448,y:634,t:1527023602173};\\\", \\\"{x:1448,y:635,t:1527023602230};\\\", \\\"{x:1448,y:644,t:1527023602951};\\\", \\\"{x:1445,y:653,t:1527023602958};\\\", \\\"{x:1439,y:661,t:1527023602974};\\\", \\\"{x:1426,y:682,t:1527023602990};\\\", \\\"{x:1399,y:715,t:1527023603006};\\\", \\\"{x:1391,y:723,t:1527023603024};\\\", \\\"{x:1383,y:734,t:1527023603040};\\\", \\\"{x:1381,y:737,t:1527023603057};\\\", \\\"{x:1380,y:739,t:1527023603074};\\\", \\\"{x:1379,y:740,t:1527023603090};\\\", \\\"{x:1379,y:741,t:1527023603271};\\\", \\\"{x:1376,y:742,t:1527023603278};\\\", \\\"{x:1374,y:744,t:1527023603291};\\\", \\\"{x:1372,y:746,t:1527023603307};\\\", \\\"{x:1368,y:749,t:1527023603324};\\\", \\\"{x:1364,y:751,t:1527023603341};\\\", \\\"{x:1363,y:751,t:1527023603357};\\\", \\\"{x:1359,y:754,t:1527023603374};\\\", \\\"{x:1354,y:757,t:1527023603390};\\\", \\\"{x:1353,y:758,t:1527023603406};\\\", \\\"{x:1352,y:758,t:1527023603470};\\\", \\\"{x:1349,y:759,t:1527023603583};\\\", \\\"{x:1347,y:759,t:1527023603590};\\\", \\\"{x:1338,y:761,t:1527023603609};\\\", \\\"{x:1313,y:769,t:1527023603624};\\\", \\\"{x:1307,y:772,t:1527023603641};\\\", \\\"{x:1306,y:772,t:1527023603662};\\\", \\\"{x:1307,y:772,t:1527023603766};\\\", \\\"{x:1308,y:772,t:1527023603774};\\\", \\\"{x:1310,y:772,t:1527023603791};\\\", \\\"{x:1311,y:772,t:1527023603809};\\\", \\\"{x:1313,y:772,t:1527023603825};\\\", \\\"{x:1315,y:772,t:1527023603846};\\\", \\\"{x:1316,y:772,t:1527023603857};\\\", \\\"{x:1320,y:771,t:1527023603875};\\\", \\\"{x:1322,y:770,t:1527023604015};\\\", \\\"{x:1323,y:770,t:1527023604024};\\\", \\\"{x:1326,y:768,t:1527023604041};\\\", \\\"{x:1327,y:768,t:1527023604078};\\\", \\\"{x:1326,y:768,t:1527023604310};\\\", \\\"{x:1324,y:768,t:1527023604325};\\\", \\\"{x:1323,y:768,t:1527023604342};\\\", \\\"{x:1321,y:768,t:1527023604357};\\\", \\\"{x:1320,y:767,t:1527023604375};\\\", \\\"{x:1319,y:766,t:1527023604392};\\\", \\\"{x:1318,y:766,t:1527023604423};\\\", \\\"{x:1320,y:766,t:1527023605399};\\\", \\\"{x:1324,y:766,t:1527023605410};\\\", \\\"{x:1327,y:767,t:1527023605426};\\\", \\\"{x:1332,y:768,t:1527023605443};\\\", \\\"{x:1339,y:771,t:1527023605460};\\\", \\\"{x:1342,y:774,t:1527023605476};\\\", \\\"{x:1348,y:779,t:1527023605493};\\\", \\\"{x:1357,y:783,t:1527023605509};\\\", \\\"{x:1362,y:785,t:1527023605526};\\\", \\\"{x:1366,y:791,t:1527023605543};\\\", \\\"{x:1372,y:794,t:1527023605560};\\\", \\\"{x:1375,y:798,t:1527023605576};\\\", \\\"{x:1383,y:802,t:1527023605593};\\\", \\\"{x:1390,y:805,t:1527023605610};\\\", \\\"{x:1395,y:808,t:1527023605626};\\\", \\\"{x:1397,y:809,t:1527023605643};\\\", \\\"{x:1398,y:809,t:1527023605799};\\\", \\\"{x:1398,y:810,t:1527023605919};\\\", \\\"{x:1395,y:810,t:1527023605967};\\\", \\\"{x:1392,y:810,t:1527023605977};\\\", \\\"{x:1381,y:809,t:1527023605994};\\\", \\\"{x:1369,y:805,t:1527023606010};\\\", \\\"{x:1356,y:804,t:1527023606027};\\\", \\\"{x:1335,y:800,t:1527023606044};\\\", \\\"{x:1326,y:800,t:1527023606060};\\\", \\\"{x:1325,y:799,t:1527023606087};\\\", \\\"{x:1324,y:799,t:1527023606215};\\\", \\\"{x:1322,y:798,t:1527023606227};\\\", \\\"{x:1321,y:797,t:1527023606254};\\\", \\\"{x:1319,y:797,t:1527023606278};\\\", \\\"{x:1318,y:796,t:1527023606294};\\\", \\\"{x:1315,y:796,t:1527023606311};\\\", \\\"{x:1313,y:795,t:1527023606327};\\\", \\\"{x:1312,y:795,t:1527023606344};\\\", \\\"{x:1308,y:794,t:1527023606361};\\\", \\\"{x:1307,y:794,t:1527023606527};\\\", \\\"{x:1305,y:794,t:1527023606895};\\\", \\\"{x:1303,y:794,t:1527023606950};\\\", \\\"{x:1302,y:793,t:1527023606974};\\\", \\\"{x:1301,y:793,t:1527023606998};\\\", \\\"{x:1300,y:792,t:1527023607015};\\\", \\\"{x:1299,y:792,t:1527023607039};\\\", \\\"{x:1297,y:792,t:1527023607046};\\\", \\\"{x:1296,y:792,t:1527023607061};\\\", \\\"{x:1293,y:791,t:1527023607086};\\\", \\\"{x:1292,y:790,t:1527023607095};\\\", \\\"{x:1290,y:790,t:1527023607111};\\\", \\\"{x:1289,y:790,t:1527023607128};\\\", \\\"{x:1288,y:790,t:1527023607145};\\\", \\\"{x:1287,y:790,t:1527023607167};\\\", \\\"{x:1286,y:790,t:1527023607222};\\\", \\\"{x:1284,y:790,t:1527023607229};\\\", \\\"{x:1282,y:790,t:1527023607245};\\\", \\\"{x:1277,y:790,t:1527023607262};\\\", \\\"{x:1275,y:791,t:1527023607278};\\\", \\\"{x:1274,y:792,t:1527023607295};\\\", \\\"{x:1273,y:792,t:1527023607312};\\\", \\\"{x:1269,y:793,t:1527023607328};\\\", \\\"{x:1267,y:793,t:1527023607344};\\\", \\\"{x:1262,y:794,t:1527023607361};\\\", \\\"{x:1260,y:794,t:1527023607378};\\\", \\\"{x:1256,y:794,t:1527023607395};\\\", \\\"{x:1252,y:794,t:1527023607412};\\\", \\\"{x:1247,y:793,t:1527023607428};\\\", \\\"{x:1244,y:791,t:1527023607445};\\\", \\\"{x:1243,y:789,t:1527023607462};\\\", \\\"{x:1242,y:789,t:1527023607479};\\\", \\\"{x:1240,y:787,t:1527023607495};\\\", \\\"{x:1239,y:787,t:1527023607512};\\\", \\\"{x:1235,y:787,t:1527023607528};\\\", \\\"{x:1230,y:784,t:1527023607545};\\\", \\\"{x:1226,y:784,t:1527023607562};\\\", \\\"{x:1223,y:784,t:1527023607579};\\\", \\\"{x:1222,y:784,t:1527023607595};\\\", \\\"{x:1221,y:784,t:1527023607612};\\\", \\\"{x:1220,y:784,t:1527023607702};\\\", \\\"{x:1220,y:785,t:1527023607799};\\\", \\\"{x:1220,y:787,t:1527023607823};\\\", \\\"{x:1220,y:788,t:1527023607831};\\\", \\\"{x:1220,y:789,t:1527023607846};\\\", \\\"{x:1220,y:790,t:1527023607862};\\\", \\\"{x:1220,y:791,t:1527023607895};\\\", \\\"{x:1220,y:792,t:1527023607942};\\\", \\\"{x:1220,y:793,t:1527023607958};\\\", \\\"{x:1220,y:794,t:1527023608015};\\\", \\\"{x:1217,y:797,t:1527023608453};\\\", \\\"{x:1205,y:803,t:1527023608463};\\\", \\\"{x:1171,y:808,t:1527023608479};\\\", \\\"{x:1166,y:811,t:1527023608495};\\\", \\\"{x:1157,y:811,t:1527023608513};\\\", \\\"{x:1111,y:802,t:1527023608530};\\\", \\\"{x:1011,y:787,t:1527023608546};\\\", \\\"{x:921,y:783,t:1527023608563};\\\", \\\"{x:822,y:778,t:1527023608580};\\\", \\\"{x:791,y:779,t:1527023608595};\\\", \\\"{x:775,y:782,t:1527023608613};\\\", \\\"{x:767,y:782,t:1527023608630};\\\", \\\"{x:766,y:782,t:1527023608646};\\\", \\\"{x:766,y:781,t:1527023608686};\\\", \\\"{x:765,y:778,t:1527023608734};\\\", \\\"{x:756,y:776,t:1527023608746};\\\", \\\"{x:726,y:768,t:1527023608763};\\\", \\\"{x:706,y:760,t:1527023608780};\\\", \\\"{x:687,y:754,t:1527023608796};\\\", \\\"{x:677,y:750,t:1527023608813};\\\", \\\"{x:654,y:744,t:1527023608830};\\\", \\\"{x:640,y:741,t:1527023608846};\\\", \\\"{x:619,y:738,t:1527023608863};\\\", \\\"{x:608,y:738,t:1527023608879};\\\", \\\"{x:595,y:736,t:1527023608897};\\\", \\\"{x:587,y:736,t:1527023608913};\\\", \\\"{x:578,y:736,t:1527023608930};\\\", \\\"{x:574,y:736,t:1527023608947};\\\", \\\"{x:572,y:736,t:1527023608983};\\\", \\\"{x:571,y:736,t:1527023608997};\\\", \\\"{x:568,y:736,t:1527023609013};\\\", \\\"{x:555,y:737,t:1527023609032};\\\", \\\"{x:545,y:740,t:1527023609047};\\\", \\\"{x:539,y:740,t:1527023609064};\\\", \\\"{x:538,y:740,t:1527023609080};\\\" ] }, { \\\"rt\\\": 22232, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 727573, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -B -B -B -2-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:739,t:1527023611239};\\\", \\\"{x:664,y:735,t:1527023611265};\\\", \\\"{x:781,y:735,t:1527023611280};\\\", \\\"{x:903,y:731,t:1527023611296};\\\", \\\"{x:1013,y:740,t:1527023611313};\\\", \\\"{x:1076,y:756,t:1527023611329};\\\", \\\"{x:1077,y:756,t:1527023612127};\\\", \\\"{x:1078,y:756,t:1527023612143};\\\", \\\"{x:1080,y:756,t:1527023612158};\\\", \\\"{x:1081,y:755,t:1527023612174};\\\", \\\"{x:1083,y:755,t:1527023612182};\\\", \\\"{x:1084,y:754,t:1527023612197};\\\", \\\"{x:1100,y:747,t:1527023612214};\\\", \\\"{x:1106,y:745,t:1527023612229};\\\", \\\"{x:1113,y:743,t:1527023612246};\\\", \\\"{x:1126,y:741,t:1527023612263};\\\", \\\"{x:1144,y:734,t:1527023612280};\\\", \\\"{x:1163,y:730,t:1527023612297};\\\", \\\"{x:1175,y:730,t:1527023612313};\\\", \\\"{x:1215,y:746,t:1527023612330};\\\", \\\"{x:1326,y:760,t:1527023612347};\\\", \\\"{x:1431,y:771,t:1527023612364};\\\", \\\"{x:1523,y:791,t:1527023612379};\\\", \\\"{x:1596,y:814,t:1527023612397};\\\", \\\"{x:1603,y:820,t:1527023612414};\\\", \\\"{x:1603,y:818,t:1527023612799};\\\", \\\"{x:1603,y:815,t:1527023612823};\\\", \\\"{x:1603,y:813,t:1527023612831};\\\", \\\"{x:1599,y:807,t:1527023612847};\\\", \\\"{x:1579,y:800,t:1527023612864};\\\", \\\"{x:1557,y:789,t:1527023612881};\\\", \\\"{x:1534,y:782,t:1527023612897};\\\", \\\"{x:1506,y:772,t:1527023612914};\\\", \\\"{x:1472,y:770,t:1527023612931};\\\", \\\"{x:1418,y:762,t:1527023612947};\\\", \\\"{x:1349,y:755,t:1527023612964};\\\", \\\"{x:1331,y:751,t:1527023612982};\\\", \\\"{x:1316,y:746,t:1527023612997};\\\", \\\"{x:1265,y:739,t:1527023613014};\\\", \\\"{x:1257,y:739,t:1527023613031};\\\", \\\"{x:1256,y:739,t:1527023613047};\\\", \\\"{x:1257,y:746,t:1527023613064};\\\", \\\"{x:1263,y:755,t:1527023613081};\\\", \\\"{x:1277,y:766,t:1527023613098};\\\", \\\"{x:1289,y:776,t:1527023613115};\\\", \\\"{x:1308,y:790,t:1527023613131};\\\", \\\"{x:1346,y:806,t:1527023613149};\\\", \\\"{x:1402,y:823,t:1527023613164};\\\", \\\"{x:1455,y:839,t:1527023613181};\\\", \\\"{x:1497,y:850,t:1527023613198};\\\", \\\"{x:1556,y:857,t:1527023613214};\\\", \\\"{x:1572,y:863,t:1527023613232};\\\", \\\"{x:1577,y:864,t:1527023613249};\\\", \\\"{x:1577,y:867,t:1527023613311};\\\", \\\"{x:1562,y:869,t:1527023613319};\\\", \\\"{x:1548,y:873,t:1527023613331};\\\", \\\"{x:1528,y:873,t:1527023613349};\\\", \\\"{x:1438,y:871,t:1527023613365};\\\", \\\"{x:1384,y:867,t:1527023613382};\\\", \\\"{x:1299,y:862,t:1527023613398};\\\", \\\"{x:1274,y:857,t:1527023613414};\\\", \\\"{x:1254,y:855,t:1527023613432};\\\", \\\"{x:1244,y:851,t:1527023613448};\\\", \\\"{x:1239,y:849,t:1527023613464};\\\", \\\"{x:1231,y:847,t:1527023613481};\\\", \\\"{x:1218,y:846,t:1527023613499};\\\", \\\"{x:1209,y:846,t:1527023613515};\\\", \\\"{x:1198,y:847,t:1527023613531};\\\", \\\"{x:1184,y:854,t:1527023613548};\\\", \\\"{x:1168,y:865,t:1527023613565};\\\", \\\"{x:1163,y:870,t:1527023613582};\\\", \\\"{x:1160,y:873,t:1527023613598};\\\", \\\"{x:1160,y:872,t:1527023613662};\\\", \\\"{x:1160,y:870,t:1527023613670};\\\", \\\"{x:1160,y:868,t:1527023613681};\\\", \\\"{x:1164,y:864,t:1527023613698};\\\", \\\"{x:1170,y:860,t:1527023613716};\\\", \\\"{x:1175,y:857,t:1527023613731};\\\", \\\"{x:1176,y:856,t:1527023613749};\\\", \\\"{x:1178,y:854,t:1527023613766};\\\", \\\"{x:1179,y:854,t:1527023613782};\\\", \\\"{x:1185,y:850,t:1527023613798};\\\", \\\"{x:1194,y:844,t:1527023613815};\\\", \\\"{x:1199,y:841,t:1527023613832};\\\", \\\"{x:1202,y:840,t:1527023613849};\\\", \\\"{x:1205,y:839,t:1527023613865};\\\", \\\"{x:1206,y:838,t:1527023613895};\\\", \\\"{x:1206,y:837,t:1527023613935};\\\", \\\"{x:1207,y:837,t:1527023613948};\\\", \\\"{x:1208,y:837,t:1527023613982};\\\", \\\"{x:1208,y:836,t:1527023614095};\\\", \\\"{x:1209,y:834,t:1527023614103};\\\", \\\"{x:1210,y:834,t:1527023614118};\\\", \\\"{x:1211,y:834,t:1527023614135};\\\", \\\"{x:1214,y:831,t:1527023619853};\\\", \\\"{x:1225,y:825,t:1527023619869};\\\", \\\"{x:1272,y:805,t:1527023619886};\\\", \\\"{x:1293,y:795,t:1527023619903};\\\", \\\"{x:1310,y:789,t:1527023619919};\\\", \\\"{x:1320,y:788,t:1527023619936};\\\", \\\"{x:1326,y:786,t:1527023619953};\\\", \\\"{x:1327,y:785,t:1527023619983};\\\", \\\"{x:1329,y:785,t:1527023619998};\\\", \\\"{x:1329,y:782,t:1527023620006};\\\", \\\"{x:1331,y:780,t:1527023620019};\\\", \\\"{x:1333,y:778,t:1527023620037};\\\", \\\"{x:1335,y:775,t:1527023620053};\\\", \\\"{x:1335,y:774,t:1527023620070};\\\", \\\"{x:1337,y:772,t:1527023620087};\\\", \\\"{x:1338,y:772,t:1527023620231};\\\", \\\"{x:1338,y:771,t:1527023620238};\\\", \\\"{x:1338,y:770,t:1527023620254};\\\", \\\"{x:1340,y:769,t:1527023620271};\\\", \\\"{x:1342,y:767,t:1527023620341};\\\", \\\"{x:1343,y:766,t:1527023620353};\\\", \\\"{x:1344,y:765,t:1527023620370};\\\", \\\"{x:1345,y:763,t:1527023620386};\\\", \\\"{x:1348,y:760,t:1527023620405};\\\", \\\"{x:1350,y:758,t:1527023620421};\\\", \\\"{x:1351,y:758,t:1527023620437};\\\", \\\"{x:1352,y:756,t:1527023620453};\\\", \\\"{x:1353,y:754,t:1527023620470};\\\", \\\"{x:1355,y:752,t:1527023620486};\\\", \\\"{x:1355,y:751,t:1527023620504};\\\", \\\"{x:1356,y:750,t:1527023620550};\\\", \\\"{x:1355,y:751,t:1527023620710};\\\", \\\"{x:1353,y:754,t:1527023620721};\\\", \\\"{x:1351,y:756,t:1527023620737};\\\", \\\"{x:1350,y:756,t:1527023620754};\\\", \\\"{x:1350,y:757,t:1527023620774};\\\", \\\"{x:1350,y:759,t:1527023620831};\\\", \\\"{x:1350,y:761,t:1527023620853};\\\", \\\"{x:1349,y:762,t:1527023620870};\\\", \\\"{x:1346,y:765,t:1527023620888};\\\", \\\"{x:1343,y:771,t:1527023620904};\\\", \\\"{x:1341,y:778,t:1527023620921};\\\", \\\"{x:1340,y:782,t:1527023620937};\\\", \\\"{x:1339,y:785,t:1527023620954};\\\", \\\"{x:1339,y:786,t:1527023620974};\\\", \\\"{x:1338,y:787,t:1527023620998};\\\", \\\"{x:1338,y:788,t:1527023621103};\\\", \\\"{x:1335,y:798,t:1527023621120};\\\", \\\"{x:1332,y:807,t:1527023621138};\\\", \\\"{x:1330,y:815,t:1527023621155};\\\", \\\"{x:1327,y:823,t:1527023621171};\\\", \\\"{x:1325,y:829,t:1527023621188};\\\", \\\"{x:1322,y:838,t:1527023621204};\\\", \\\"{x:1321,y:846,t:1527023621221};\\\", \\\"{x:1317,y:855,t:1527023621238};\\\", \\\"{x:1313,y:864,t:1527023621254};\\\", \\\"{x:1309,y:871,t:1527023621270};\\\", \\\"{x:1307,y:875,t:1527023621287};\\\", \\\"{x:1305,y:879,t:1527023621304};\\\", \\\"{x:1301,y:886,t:1527023621321};\\\", \\\"{x:1296,y:893,t:1527023621337};\\\", \\\"{x:1292,y:897,t:1527023621354};\\\", \\\"{x:1287,y:902,t:1527023621370};\\\", \\\"{x:1283,y:910,t:1527023621388};\\\", \\\"{x:1275,y:920,t:1527023621405};\\\", \\\"{x:1270,y:927,t:1527023621421};\\\", \\\"{x:1266,y:932,t:1527023621438};\\\", \\\"{x:1262,y:941,t:1527023621455};\\\", \\\"{x:1258,y:945,t:1527023621472};\\\", \\\"{x:1256,y:949,t:1527023621488};\\\", \\\"{x:1251,y:954,t:1527023621504};\\\", \\\"{x:1248,y:958,t:1527023621522};\\\", \\\"{x:1245,y:964,t:1527023621538};\\\", \\\"{x:1244,y:968,t:1527023621554};\\\", \\\"{x:1241,y:971,t:1527023621572};\\\", \\\"{x:1239,y:971,t:1527023622167};\\\", \\\"{x:1236,y:970,t:1527023622174};\\\", \\\"{x:1230,y:964,t:1527023622189};\\\", \\\"{x:1206,y:949,t:1527023622205};\\\", \\\"{x:1159,y:929,t:1527023622221};\\\", \\\"{x:1081,y:898,t:1527023622237};\\\", \\\"{x:991,y:881,t:1527023622254};\\\", \\\"{x:889,y:857,t:1527023622271};\\\", \\\"{x:805,y:844,t:1527023622288};\\\", \\\"{x:760,y:835,t:1527023622304};\\\", \\\"{x:723,y:830,t:1527023622321};\\\", \\\"{x:698,y:822,t:1527023622338};\\\", \\\"{x:670,y:816,t:1527023622355};\\\", \\\"{x:643,y:805,t:1527023622371};\\\", \\\"{x:619,y:791,t:1527023622388};\\\", \\\"{x:586,y:772,t:1527023622406};\\\", \\\"{x:558,y:751,t:1527023622423};\\\", \\\"{x:527,y:729,t:1527023622437};\\\", \\\"{x:513,y:717,t:1527023622456};\\\", \\\"{x:507,y:709,t:1527023622472};\\\", \\\"{x:504,y:704,t:1527023622488};\\\", \\\"{x:503,y:697,t:1527023622505};\\\", \\\"{x:503,y:683,t:1527023622522};\\\", \\\"{x:503,y:665,t:1527023622538};\\\", \\\"{x:506,y:648,t:1527023622554};\\\", \\\"{x:514,y:630,t:1527023622573};\\\", \\\"{x:523,y:612,t:1527023622588};\\\", \\\"{x:531,y:599,t:1527023622606};\\\", \\\"{x:540,y:583,t:1527023622622};\\\", \\\"{x:546,y:575,t:1527023622638};\\\", \\\"{x:552,y:567,t:1527023622655};\\\", \\\"{x:555,y:563,t:1527023622672};\\\", \\\"{x:561,y:558,t:1527023622690};\\\", \\\"{x:566,y:554,t:1527023622706};\\\", \\\"{x:570,y:552,t:1527023622722};\\\", \\\"{x:571,y:551,t:1527023622738};\\\", \\\"{x:571,y:550,t:1527023622755};\\\", \\\"{x:567,y:550,t:1527023622781};\\\", \\\"{x:560,y:550,t:1527023622789};\\\", \\\"{x:549,y:550,t:1527023622805};\\\", \\\"{x:512,y:557,t:1527023622822};\\\", \\\"{x:490,y:558,t:1527023622839};\\\", \\\"{x:468,y:561,t:1527023622855};\\\", \\\"{x:450,y:561,t:1527023622872};\\\", \\\"{x:435,y:561,t:1527023622889};\\\", \\\"{x:417,y:561,t:1527023622906};\\\", \\\"{x:405,y:561,t:1527023622922};\\\", \\\"{x:399,y:561,t:1527023622939};\\\", \\\"{x:395,y:561,t:1527023622955};\\\", \\\"{x:393,y:562,t:1527023622973};\\\", \\\"{x:392,y:559,t:1527023623022};\\\", \\\"{x:391,y:550,t:1527023623041};\\\", \\\"{x:387,y:543,t:1527023623056};\\\", \\\"{x:384,y:539,t:1527023623072};\\\", \\\"{x:384,y:536,t:1527023623089};\\\", \\\"{x:384,y:535,t:1527023623105};\\\", \\\"{x:384,y:534,t:1527023623122};\\\", \\\"{x:384,y:532,t:1527023623149};\\\", \\\"{x:386,y:531,t:1527023623157};\\\", \\\"{x:388,y:531,t:1527023623172};\\\", \\\"{x:402,y:531,t:1527023623189};\\\", \\\"{x:446,y:537,t:1527023623206};\\\", \\\"{x:498,y:547,t:1527023623222};\\\", \\\"{x:565,y:557,t:1527023623240};\\\", \\\"{x:601,y:563,t:1527023623255};\\\", \\\"{x:609,y:567,t:1527023623273};\\\", \\\"{x:610,y:567,t:1527023623289};\\\", \\\"{x:610,y:568,t:1527023623309};\\\", \\\"{x:608,y:569,t:1527023623322};\\\", \\\"{x:600,y:570,t:1527023623339};\\\", \\\"{x:582,y:572,t:1527023623357};\\\", \\\"{x:547,y:575,t:1527023623372};\\\", \\\"{x:483,y:575,t:1527023623390};\\\", \\\"{x:335,y:554,t:1527023623406};\\\", \\\"{x:213,y:536,t:1527023623423};\\\", \\\"{x:118,y:520,t:1527023623440};\\\", \\\"{x:76,y:514,t:1527023623458};\\\", \\\"{x:48,y:511,t:1527023623472};\\\", \\\"{x:34,y:509,t:1527023623489};\\\", \\\"{x:26,y:508,t:1527023623506};\\\", \\\"{x:25,y:508,t:1527023623522};\\\", \\\"{x:24,y:508,t:1527023623597};\\\", \\\"{x:25,y:506,t:1527023623662};\\\", \\\"{x:27,y:506,t:1527023623673};\\\", \\\"{x:32,y:503,t:1527023623689};\\\", \\\"{x:41,y:502,t:1527023623706};\\\", \\\"{x:57,y:502,t:1527023623724};\\\", \\\"{x:70,y:502,t:1527023623740};\\\", \\\"{x:83,y:502,t:1527023623757};\\\", \\\"{x:91,y:503,t:1527023623773};\\\", \\\"{x:93,y:504,t:1527023623789};\\\", \\\"{x:95,y:504,t:1527023623838};\\\", \\\"{x:97,y:504,t:1527023623846};\\\", \\\"{x:100,y:504,t:1527023623857};\\\", \\\"{x:106,y:504,t:1527023623873};\\\", \\\"{x:110,y:504,t:1527023623889};\\\", \\\"{x:118,y:504,t:1527023623906};\\\", \\\"{x:124,y:504,t:1527023623922};\\\", \\\"{x:131,y:504,t:1527023623939};\\\", \\\"{x:136,y:504,t:1527023623956};\\\", \\\"{x:139,y:504,t:1527023623972};\\\", \\\"{x:143,y:504,t:1527023623990};\\\", \\\"{x:153,y:504,t:1527023624007};\\\", \\\"{x:156,y:504,t:1527023624023};\\\", \\\"{x:158,y:504,t:1527023624040};\\\", \\\"{x:159,y:504,t:1527023624057};\\\", \\\"{x:160,y:504,t:1527023624078};\\\", \\\"{x:161,y:504,t:1527023624151};\\\", \\\"{x:166,y:504,t:1527023624518};\\\", \\\"{x:180,y:504,t:1527023624526};\\\", \\\"{x:207,y:504,t:1527023624541};\\\", \\\"{x:388,y:529,t:1527023624559};\\\", \\\"{x:463,y:536,t:1527023624574};\\\", \\\"{x:769,y:586,t:1527023624592};\\\", \\\"{x:978,y:638,t:1527023624608};\\\", \\\"{x:1179,y:686,t:1527023624624};\\\", \\\"{x:1345,y:738,t:1527023624641};\\\", \\\"{x:1476,y:780,t:1527023624658};\\\", \\\"{x:1572,y:818,t:1527023624674};\\\", \\\"{x:1608,y:839,t:1527023624690};\\\", \\\"{x:1617,y:845,t:1527023624707};\\\", \\\"{x:1618,y:848,t:1527023624724};\\\", \\\"{x:1618,y:850,t:1527023624740};\\\", \\\"{x:1618,y:855,t:1527023624758};\\\", \\\"{x:1610,y:874,t:1527023624775};\\\", \\\"{x:1593,y:893,t:1527023624791};\\\", \\\"{x:1575,y:909,t:1527023624809};\\\", \\\"{x:1556,y:922,t:1527023624825};\\\", \\\"{x:1543,y:931,t:1527023624841};\\\", \\\"{x:1532,y:932,t:1527023624858};\\\", \\\"{x:1518,y:932,t:1527023624875};\\\", \\\"{x:1493,y:932,t:1527023624892};\\\", \\\"{x:1449,y:920,t:1527023624908};\\\", \\\"{x:1372,y:900,t:1527023624925};\\\", \\\"{x:1267,y:874,t:1527023624943};\\\", \\\"{x:1166,y:854,t:1527023624958};\\\", \\\"{x:1103,y:838,t:1527023624975};\\\", \\\"{x:1065,y:826,t:1527023624992};\\\", \\\"{x:1062,y:824,t:1527023625008};\\\", \\\"{x:1062,y:823,t:1527023625030};\\\", \\\"{x:1062,y:821,t:1527023625043};\\\", \\\"{x:1062,y:819,t:1527023625059};\\\", \\\"{x:1062,y:818,t:1527023625135};\\\", \\\"{x:1062,y:816,t:1527023625159};\\\", \\\"{x:1063,y:816,t:1527023625175};\\\", \\\"{x:1067,y:815,t:1527023625192};\\\", \\\"{x:1072,y:813,t:1527023625208};\\\", \\\"{x:1074,y:812,t:1527023625226};\\\", \\\"{x:1079,y:811,t:1527023625242};\\\", \\\"{x:1084,y:809,t:1527023625259};\\\", \\\"{x:1091,y:808,t:1527023625276};\\\", \\\"{x:1097,y:807,t:1527023625292};\\\", \\\"{x:1102,y:806,t:1527023625309};\\\", \\\"{x:1106,y:805,t:1527023625326};\\\", \\\"{x:1108,y:804,t:1527023625399};\\\", \\\"{x:1109,y:804,t:1527023625409};\\\", \\\"{x:1110,y:804,t:1527023625426};\\\", \\\"{x:1112,y:804,t:1527023625443};\\\", \\\"{x:1113,y:804,t:1527023625459};\\\", \\\"{x:1117,y:804,t:1527023625476};\\\", \\\"{x:1123,y:802,t:1527023625493};\\\", \\\"{x:1130,y:802,t:1527023625510};\\\", \\\"{x:1134,y:802,t:1527023625527};\\\", \\\"{x:1140,y:802,t:1527023625543};\\\", \\\"{x:1145,y:802,t:1527023625560};\\\", \\\"{x:1149,y:801,t:1527023625576};\\\", \\\"{x:1153,y:801,t:1527023625593};\\\", \\\"{x:1158,y:801,t:1527023625610};\\\", \\\"{x:1163,y:801,t:1527023625626};\\\", \\\"{x:1165,y:801,t:1527023625643};\\\", \\\"{x:1166,y:800,t:1527023625660};\\\", \\\"{x:1167,y:800,t:1527023625678};\\\", \\\"{x:1168,y:799,t:1527023625711};\\\", \\\"{x:1169,y:798,t:1527023625991};\\\", \\\"{x:1170,y:798,t:1527023626015};\\\", \\\"{x:1171,y:797,t:1527023626151};\\\", \\\"{x:1171,y:796,t:1527023626359};\\\", \\\"{x:1173,y:794,t:1527023626383};\\\", \\\"{x:1175,y:793,t:1527023626398};\\\", \\\"{x:1177,y:792,t:1527023626411};\\\", \\\"{x:1179,y:790,t:1527023626428};\\\", \\\"{x:1181,y:789,t:1527023626454};\\\", \\\"{x:1181,y:788,t:1527023626527};\\\", \\\"{x:1182,y:788,t:1527023626558};\\\", \\\"{x:1183,y:787,t:1527023626566};\\\", \\\"{x:1184,y:786,t:1527023626582};\\\", \\\"{x:1184,y:785,t:1527023626599};\\\", \\\"{x:1185,y:785,t:1527023626623};\\\", \\\"{x:1185,y:784,t:1527023626631};\\\", \\\"{x:1186,y:784,t:1527023626645};\\\", \\\"{x:1189,y:782,t:1527023626663};\\\", \\\"{x:1190,y:782,t:1527023626679};\\\", \\\"{x:1193,y:782,t:1527023626695};\\\", \\\"{x:1196,y:782,t:1527023626712};\\\", \\\"{x:1203,y:788,t:1527023626729};\\\", \\\"{x:1214,y:809,t:1527023626746};\\\", \\\"{x:1226,y:832,t:1527023626762};\\\", \\\"{x:1236,y:847,t:1527023626779};\\\", \\\"{x:1238,y:849,t:1527023626797};\\\", \\\"{x:1239,y:849,t:1527023626967};\\\", \\\"{x:1239,y:847,t:1527023626979};\\\", \\\"{x:1238,y:844,t:1527023626996};\\\", \\\"{x:1235,y:838,t:1527023627013};\\\", \\\"{x:1232,y:834,t:1527023627029};\\\", \\\"{x:1228,y:831,t:1527023627046};\\\", \\\"{x:1227,y:829,t:1527023627062};\\\", \\\"{x:1226,y:827,t:1527023627081};\\\", \\\"{x:1225,y:825,t:1527023627097};\\\", \\\"{x:1223,y:823,t:1527023627113};\\\", \\\"{x:1222,y:823,t:1527023627143};\\\", \\\"{x:1217,y:819,t:1527023627895};\\\", \\\"{x:1211,y:816,t:1527023627903};\\\", \\\"{x:1210,y:814,t:1527023627915};\\\", \\\"{x:1206,y:810,t:1527023627931};\\\", \\\"{x:1203,y:807,t:1527023627948};\\\", \\\"{x:1203,y:806,t:1527023627964};\\\", \\\"{x:1201,y:803,t:1527023627981};\\\", \\\"{x:1209,y:780,t:1527023627997};\\\", \\\"{x:1222,y:766,t:1527023628014};\\\", \\\"{x:1233,y:748,t:1527023628032};\\\", \\\"{x:1239,y:735,t:1527023628047};\\\", \\\"{x:1245,y:721,t:1527023628065};\\\", \\\"{x:1253,y:709,t:1527023628081};\\\", \\\"{x:1257,y:698,t:1527023628098};\\\", \\\"{x:1261,y:684,t:1527023628115};\\\", \\\"{x:1268,y:672,t:1527023628131};\\\", \\\"{x:1270,y:661,t:1527023628148};\\\", \\\"{x:1271,y:658,t:1527023628165};\\\", \\\"{x:1272,y:650,t:1527023628182};\\\", \\\"{x:1272,y:649,t:1527023628199};\\\", \\\"{x:1272,y:646,t:1527023628215};\\\", \\\"{x:1272,y:643,t:1527023628232};\\\", \\\"{x:1272,y:639,t:1527023628249};\\\", \\\"{x:1271,y:634,t:1527023628265};\\\", \\\"{x:1269,y:629,t:1527023628282};\\\", \\\"{x:1268,y:624,t:1527023628299};\\\", \\\"{x:1267,y:617,t:1527023628316};\\\", \\\"{x:1265,y:608,t:1527023628331};\\\", \\\"{x:1265,y:603,t:1527023628348};\\\", \\\"{x:1264,y:597,t:1527023628365};\\\", \\\"{x:1264,y:594,t:1527023628382};\\\", \\\"{x:1265,y:590,t:1527023628398};\\\", \\\"{x:1265,y:588,t:1527023628415};\\\", \\\"{x:1265,y:587,t:1527023628432};\\\", \\\"{x:1267,y:584,t:1527023628449};\\\", \\\"{x:1267,y:583,t:1527023631926};\\\", \\\"{x:1267,y:584,t:1527023631958};\\\", \\\"{x:1262,y:593,t:1527023631973};\\\", \\\"{x:1217,y:648,t:1527023631990};\\\", \\\"{x:1153,y:704,t:1527023632007};\\\", \\\"{x:1114,y:737,t:1527023632023};\\\", \\\"{x:1038,y:783,t:1527023632040};\\\", \\\"{x:958,y:815,t:1527023632057};\\\", \\\"{x:912,y:832,t:1527023632074};\\\", \\\"{x:884,y:839,t:1527023632090};\\\", \\\"{x:867,y:842,t:1527023632107};\\\", \\\"{x:846,y:846,t:1527023632124};\\\", \\\"{x:820,y:853,t:1527023632140};\\\", \\\"{x:799,y:855,t:1527023632157};\\\", \\\"{x:753,y:855,t:1527023632174};\\\", \\\"{x:715,y:858,t:1527023632190};\\\", \\\"{x:667,y:859,t:1527023632207};\\\", \\\"{x:636,y:860,t:1527023632224};\\\", \\\"{x:590,y:857,t:1527023632241};\\\", \\\"{x:562,y:850,t:1527023632257};\\\", \\\"{x:548,y:843,t:1527023632274};\\\", \\\"{x:541,y:836,t:1527023632291};\\\", \\\"{x:536,y:832,t:1527023632307};\\\", \\\"{x:530,y:827,t:1527023632323};\\\", \\\"{x:523,y:822,t:1527023632340};\\\", \\\"{x:515,y:815,t:1527023632357};\\\", \\\"{x:507,y:806,t:1527023632374};\\\", \\\"{x:502,y:797,t:1527023632390};\\\", \\\"{x:500,y:786,t:1527023632408};\\\", \\\"{x:500,y:778,t:1527023632424};\\\", \\\"{x:506,y:762,t:1527023632440};\\\", \\\"{x:510,y:753,t:1527023632459};\\\", \\\"{x:511,y:749,t:1527023632473};\\\", \\\"{x:511,y:747,t:1527023632490};\\\", \\\"{x:512,y:744,t:1527023632514};\\\", \\\"{x:512,y:743,t:1527023632531};\\\", \\\"{x:513,y:741,t:1527023632547};\\\", \\\"{x:514,y:737,t:1527023632564};\\\", \\\"{x:518,y:730,t:1527023632581};\\\", \\\"{x:519,y:727,t:1527023632596};\\\", \\\"{x:521,y:725,t:1527023632613};\\\" ] }, { \\\"rt\\\": 13000, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 741830, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:725,t:1527023634150};\\\", \\\"{x:523,y:726,t:1527023634165};\\\", \\\"{x:529,y:729,t:1527023634181};\\\", \\\"{x:531,y:730,t:1527023634203};\\\", \\\"{x:532,y:730,t:1527023634215};\\\", \\\"{x:535,y:730,t:1527023634302};\\\", \\\"{x:539,y:730,t:1527023635454};\\\", \\\"{x:541,y:730,t:1527023635469};\\\", \\\"{x:548,y:727,t:1527023635485};\\\", \\\"{x:591,y:705,t:1527023635503};\\\", \\\"{x:622,y:686,t:1527023635519};\\\", \\\"{x:652,y:668,t:1527023635534};\\\", \\\"{x:692,y:649,t:1527023635549};\\\", \\\"{x:739,y:631,t:1527023635567};\\\", \\\"{x:798,y:615,t:1527023635582};\\\", \\\"{x:902,y:609,t:1527023635599};\\\", \\\"{x:1022,y:605,t:1527023635616};\\\", \\\"{x:1157,y:605,t:1527023635633};\\\", \\\"{x:1287,y:605,t:1527023635650};\\\", \\\"{x:1432,y:610,t:1527023635665};\\\", \\\"{x:1499,y:618,t:1527023635683};\\\", \\\"{x:1571,y:628,t:1527023635700};\\\", \\\"{x:1595,y:632,t:1527023635716};\\\", \\\"{x:1610,y:634,t:1527023635733};\\\", \\\"{x:1613,y:634,t:1527023635750};\\\", \\\"{x:1614,y:634,t:1527023636022};\\\", \\\"{x:1614,y:636,t:1527023636033};\\\", \\\"{x:1595,y:649,t:1527023636050};\\\", \\\"{x:1579,y:664,t:1527023636066};\\\", \\\"{x:1564,y:676,t:1527023636083};\\\", \\\"{x:1551,y:685,t:1527023636100};\\\", \\\"{x:1540,y:692,t:1527023636116};\\\", \\\"{x:1522,y:697,t:1527023636133};\\\", \\\"{x:1499,y:701,t:1527023636150};\\\", \\\"{x:1488,y:703,t:1527023636166};\\\", \\\"{x:1467,y:706,t:1527023636183};\\\", \\\"{x:1443,y:708,t:1527023636200};\\\", \\\"{x:1425,y:709,t:1527023636217};\\\", \\\"{x:1405,y:709,t:1527023636233};\\\", \\\"{x:1387,y:709,t:1527023636251};\\\", \\\"{x:1371,y:707,t:1527023636267};\\\", \\\"{x:1354,y:707,t:1527023636283};\\\", \\\"{x:1330,y:707,t:1527023636301};\\\", \\\"{x:1313,y:707,t:1527023636317};\\\", \\\"{x:1302,y:708,t:1527023636334};\\\", \\\"{x:1298,y:711,t:1527023636350};\\\", \\\"{x:1300,y:711,t:1527023636479};\\\", \\\"{x:1302,y:709,t:1527023636486};\\\", \\\"{x:1305,y:707,t:1527023636500};\\\", \\\"{x:1311,y:704,t:1527023636517};\\\", \\\"{x:1318,y:702,t:1527023636534};\\\", \\\"{x:1327,y:700,t:1527023636551};\\\", \\\"{x:1329,y:700,t:1527023636566};\\\", \\\"{x:1331,y:700,t:1527023636584};\\\", \\\"{x:1331,y:699,t:1527023636614};\\\", \\\"{x:1332,y:699,t:1527023636639};\\\", \\\"{x:1333,y:699,t:1527023636751};\\\", \\\"{x:1334,y:698,t:1527023636775};\\\", \\\"{x:1335,y:698,t:1527023636783};\\\", \\\"{x:1337,y:698,t:1527023636806};\\\", \\\"{x:1340,y:697,t:1527023636830};\\\", \\\"{x:1342,y:695,t:1527023636840};\\\", \\\"{x:1345,y:694,t:1527023636866};\\\", \\\"{x:1347,y:693,t:1527023636883};\\\", \\\"{x:1349,y:692,t:1527023636900};\\\", \\\"{x:1351,y:692,t:1527023637358};\\\", \\\"{x:1352,y:692,t:1527023637615};\\\", \\\"{x:1353,y:692,t:1527023639439};\\\", \\\"{x:1353,y:693,t:1527023639518};\\\", \\\"{x:1353,y:694,t:1527023639567};\\\", \\\"{x:1352,y:695,t:1527023639584};\\\", \\\"{x:1349,y:698,t:1527023639622};\\\", \\\"{x:1349,y:699,t:1527023639679};\\\", \\\"{x:1349,y:700,t:1527023640279};\\\", \\\"{x:1352,y:709,t:1527023640287};\\\", \\\"{x:1362,y:726,t:1527023640301};\\\", \\\"{x:1379,y:758,t:1527023640318};\\\", \\\"{x:1402,y:789,t:1527023640334};\\\", \\\"{x:1418,y:803,t:1527023640351};\\\", \\\"{x:1432,y:818,t:1527023640367};\\\", \\\"{x:1440,y:826,t:1527023640384};\\\", \\\"{x:1443,y:829,t:1527023640401};\\\", \\\"{x:1445,y:831,t:1527023640418};\\\", \\\"{x:1446,y:835,t:1527023640435};\\\", \\\"{x:1449,y:840,t:1527023640451};\\\", \\\"{x:1451,y:849,t:1527023640468};\\\", \\\"{x:1455,y:857,t:1527023640485};\\\", \\\"{x:1457,y:860,t:1527023640501};\\\", \\\"{x:1460,y:865,t:1527023640518};\\\", \\\"{x:1463,y:878,t:1527023640535};\\\", \\\"{x:1465,y:886,t:1527023640551};\\\", \\\"{x:1466,y:896,t:1527023640568};\\\", \\\"{x:1470,y:905,t:1527023640585};\\\", \\\"{x:1470,y:916,t:1527023640601};\\\", \\\"{x:1470,y:929,t:1527023640618};\\\", \\\"{x:1470,y:943,t:1527023640635};\\\", \\\"{x:1470,y:953,t:1527023640651};\\\", \\\"{x:1470,y:960,t:1527023640668};\\\", \\\"{x:1470,y:963,t:1527023640685};\\\", \\\"{x:1470,y:965,t:1527023640701};\\\", \\\"{x:1460,y:965,t:1527023641070};\\\", \\\"{x:1434,y:965,t:1527023641084};\\\", \\\"{x:1354,y:958,t:1527023641100};\\\", \\\"{x:1262,y:943,t:1527023641117};\\\", \\\"{x:1184,y:904,t:1527023641134};\\\", \\\"{x:1180,y:893,t:1527023641151};\\\", \\\"{x:1179,y:892,t:1527023641168};\\\", \\\"{x:1172,y:882,t:1527023641185};\\\", \\\"{x:1165,y:873,t:1527023641200};\\\", \\\"{x:1155,y:859,t:1527023641218};\\\", \\\"{x:1140,y:837,t:1527023641235};\\\", \\\"{x:1121,y:813,t:1527023641251};\\\", \\\"{x:1108,y:802,t:1527023641268};\\\", \\\"{x:1098,y:792,t:1527023641284};\\\", \\\"{x:1095,y:791,t:1527023641599};\\\", \\\"{x:1077,y:780,t:1527023641606};\\\", \\\"{x:1054,y:771,t:1527023641617};\\\", \\\"{x:1019,y:752,t:1527023641635};\\\", \\\"{x:941,y:716,t:1527023641651};\\\", \\\"{x:825,y:666,t:1527023641668};\\\", \\\"{x:678,y:620,t:1527023641686};\\\", \\\"{x:503,y:558,t:1527023641701};\\\", \\\"{x:229,y:471,t:1527023641717};\\\", \\\"{x:103,y:446,t:1527023641737};\\\", \\\"{x:53,y:439,t:1527023641753};\\\", \\\"{x:48,y:437,t:1527023641770};\\\", \\\"{x:53,y:437,t:1527023641805};\\\", \\\"{x:60,y:439,t:1527023641821};\\\", \\\"{x:90,y:449,t:1527023641838};\\\", \\\"{x:115,y:455,t:1527023641853};\\\", \\\"{x:139,y:459,t:1527023641870};\\\", \\\"{x:168,y:464,t:1527023641888};\\\", \\\"{x:203,y:466,t:1527023641904};\\\", \\\"{x:228,y:470,t:1527023641921};\\\", \\\"{x:257,y:472,t:1527023641937};\\\", \\\"{x:276,y:475,t:1527023641953};\\\", \\\"{x:291,y:476,t:1527023641970};\\\", \\\"{x:310,y:478,t:1527023641988};\\\", \\\"{x:360,y:478,t:1527023642003};\\\", \\\"{x:416,y:479,t:1527023642021};\\\", \\\"{x:447,y:482,t:1527023642038};\\\", \\\"{x:448,y:481,t:1527023642053};\\\", \\\"{x:449,y:480,t:1527023642071};\\\", \\\"{x:450,y:480,t:1527023642093};\\\", \\\"{x:452,y:480,t:1527023642110};\\\", \\\"{x:457,y:480,t:1527023642120};\\\", \\\"{x:470,y:482,t:1527023642137};\\\", \\\"{x:501,y:483,t:1527023642154};\\\", \\\"{x:553,y:490,t:1527023642172};\\\", \\\"{x:602,y:498,t:1527023642189};\\\", \\\"{x:660,y:501,t:1527023642207};\\\", \\\"{x:680,y:501,t:1527023642221};\\\", \\\"{x:689,y:503,t:1527023642238};\\\", \\\"{x:693,y:504,t:1527023642255};\\\", \\\"{x:693,y:505,t:1527023642285};\\\", \\\"{x:678,y:509,t:1527023642414};\\\", \\\"{x:651,y:514,t:1527023642422};\\\", \\\"{x:578,y:517,t:1527023642438};\\\", \\\"{x:510,y:523,t:1527023642457};\\\", \\\"{x:478,y:530,t:1527023642473};\\\", \\\"{x:464,y:530,t:1527023642489};\\\", \\\"{x:466,y:530,t:1527023642574};\\\", \\\"{x:470,y:529,t:1527023642590};\\\", \\\"{x:481,y:525,t:1527023642606};\\\", \\\"{x:496,y:518,t:1527023642624};\\\", \\\"{x:516,y:514,t:1527023642640};\\\", \\\"{x:530,y:513,t:1527023642655};\\\", \\\"{x:544,y:513,t:1527023642672};\\\", \\\"{x:557,y:513,t:1527023642689};\\\", \\\"{x:562,y:513,t:1527023642705};\\\", \\\"{x:566,y:511,t:1527023642722};\\\", \\\"{x:567,y:511,t:1527023642805};\\\", \\\"{x:569,y:511,t:1527023642853};\\\", \\\"{x:570,y:509,t:1527023642861};\\\", \\\"{x:571,y:508,t:1527023642872};\\\", \\\"{x:577,y:504,t:1527023642889};\\\", \\\"{x:582,y:500,t:1527023642905};\\\", \\\"{x:584,y:498,t:1527023642922};\\\", \\\"{x:588,y:498,t:1527023642939};\\\", \\\"{x:590,y:496,t:1527023642955};\\\", \\\"{x:592,y:496,t:1527023642972};\\\", \\\"{x:597,y:496,t:1527023642990};\\\", \\\"{x:599,y:495,t:1527023643006};\\\", \\\"{x:599,y:494,t:1527023643023};\\\", \\\"{x:600,y:493,t:1527023643055};\\\", \\\"{x:603,y:492,t:1527023643073};\\\", \\\"{x:604,y:492,t:1527023643093};\\\", \\\"{x:609,y:493,t:1527023643542};\\\", \\\"{x:623,y:506,t:1527023643557};\\\", \\\"{x:707,y:552,t:1527023643576};\\\", \\\"{x:769,y:581,t:1527023643589};\\\", \\\"{x:841,y:612,t:1527023643607};\\\", \\\"{x:931,y:641,t:1527023643624};\\\", \\\"{x:1014,y:666,t:1527023643639};\\\", \\\"{x:1104,y:685,t:1527023643656};\\\", \\\"{x:1185,y:698,t:1527023643673};\\\", \\\"{x:1259,y:712,t:1527023643689};\\\", \\\"{x:1310,y:719,t:1527023643706};\\\", \\\"{x:1341,y:719,t:1527023643724};\\\", \\\"{x:1362,y:719,t:1527023643740};\\\", \\\"{x:1378,y:718,t:1527023643756};\\\", \\\"{x:1408,y:715,t:1527023643774};\\\", \\\"{x:1419,y:710,t:1527023643789};\\\", \\\"{x:1433,y:704,t:1527023643806};\\\", \\\"{x:1439,y:700,t:1527023643824};\\\", \\\"{x:1443,y:696,t:1527023643840};\\\", \\\"{x:1440,y:694,t:1527023643941};\\\", \\\"{x:1435,y:694,t:1527023643957};\\\", \\\"{x:1430,y:693,t:1527023643974};\\\", \\\"{x:1422,y:693,t:1527023643990};\\\", \\\"{x:1414,y:693,t:1527023644007};\\\", \\\"{x:1402,y:693,t:1527023644023};\\\", \\\"{x:1397,y:693,t:1527023644040};\\\", \\\"{x:1390,y:697,t:1527023644058};\\\", \\\"{x:1388,y:698,t:1527023644073};\\\", \\\"{x:1387,y:698,t:1527023644090};\\\", \\\"{x:1385,y:699,t:1527023644107};\\\", \\\"{x:1384,y:700,t:1527023644124};\\\", \\\"{x:1383,y:701,t:1527023644140};\\\", \\\"{x:1380,y:703,t:1527023644158};\\\", \\\"{x:1380,y:704,t:1527023644173};\\\", \\\"{x:1379,y:706,t:1527023644191};\\\", \\\"{x:1378,y:706,t:1527023644207};\\\", \\\"{x:1376,y:708,t:1527023644224};\\\", \\\"{x:1373,y:708,t:1527023644241};\\\", \\\"{x:1371,y:708,t:1527023644259};\\\", \\\"{x:1370,y:708,t:1527023644275};\\\", \\\"{x:1369,y:709,t:1527023644291};\\\", \\\"{x:1363,y:709,t:1527023644308};\\\", \\\"{x:1351,y:704,t:1527023644325};\\\", \\\"{x:1346,y:701,t:1527023644341};\\\", \\\"{x:1344,y:701,t:1527023644357};\\\", \\\"{x:1344,y:705,t:1527023644415};\\\", \\\"{x:1351,y:715,t:1527023644425};\\\", \\\"{x:1362,y:737,t:1527023644442};\\\", \\\"{x:1374,y:754,t:1527023644460};\\\", \\\"{x:1388,y:773,t:1527023644475};\\\", \\\"{x:1405,y:794,t:1527023644492};\\\", \\\"{x:1418,y:810,t:1527023644508};\\\", \\\"{x:1426,y:823,t:1527023644525};\\\", \\\"{x:1430,y:832,t:1527023644542};\\\", \\\"{x:1433,y:838,t:1527023644559};\\\", \\\"{x:1435,y:847,t:1527023644574};\\\", \\\"{x:1439,y:863,t:1527023644592};\\\", \\\"{x:1447,y:876,t:1527023644609};\\\", \\\"{x:1454,y:890,t:1527023644625};\\\", \\\"{x:1459,y:897,t:1527023644642};\\\", \\\"{x:1462,y:902,t:1527023644659};\\\", \\\"{x:1464,y:910,t:1527023644675};\\\", \\\"{x:1470,y:922,t:1527023644692};\\\", \\\"{x:1475,y:929,t:1527023644709};\\\", \\\"{x:1476,y:934,t:1527023644725};\\\", \\\"{x:1478,y:938,t:1527023644743};\\\", \\\"{x:1480,y:941,t:1527023644759};\\\", \\\"{x:1481,y:943,t:1527023644776};\\\", \\\"{x:1481,y:945,t:1527023644791};\\\", \\\"{x:1481,y:946,t:1527023644809};\\\", \\\"{x:1482,y:948,t:1527023644826};\\\", \\\"{x:1483,y:949,t:1527023644842};\\\", \\\"{x:1484,y:952,t:1527023644859};\\\", \\\"{x:1485,y:954,t:1527023644876};\\\", \\\"{x:1485,y:955,t:1527023644892};\\\", \\\"{x:1485,y:958,t:1527023644910};\\\", \\\"{x:1485,y:960,t:1527023644926};\\\", \\\"{x:1485,y:961,t:1527023645110};\\\", \\\"{x:1467,y:960,t:1527023645125};\\\", \\\"{x:1424,y:950,t:1527023645143};\\\", \\\"{x:1341,y:937,t:1527023645159};\\\", \\\"{x:1241,y:921,t:1527023645176};\\\", \\\"{x:1131,y:911,t:1527023645193};\\\", \\\"{x:1030,y:905,t:1527023645210};\\\", \\\"{x:1016,y:904,t:1527023645225};\\\", \\\"{x:1012,y:904,t:1527023645243};\\\", \\\"{x:1008,y:896,t:1527023645261};\\\", \\\"{x:992,y:886,t:1527023645277};\\\", \\\"{x:983,y:879,t:1527023645293};\\\", \\\"{x:976,y:875,t:1527023645310};\\\", \\\"{x:972,y:872,t:1527023645326};\\\", \\\"{x:961,y:868,t:1527023645343};\\\", \\\"{x:933,y:860,t:1527023645359};\\\", \\\"{x:888,y:842,t:1527023645377};\\\", \\\"{x:856,y:828,t:1527023645392};\\\", \\\"{x:813,y:820,t:1527023645410};\\\", \\\"{x:779,y:808,t:1527023645426};\\\", \\\"{x:760,y:800,t:1527023645443};\\\", \\\"{x:734,y:792,t:1527023645460};\\\", \\\"{x:708,y:784,t:1527023645477};\\\", \\\"{x:665,y:775,t:1527023645493};\\\", \\\"{x:642,y:775,t:1527023645510};\\\", \\\"{x:632,y:775,t:1527023645526};\\\", \\\"{x:624,y:775,t:1527023645544};\\\", \\\"{x:620,y:775,t:1527023645560};\\\", \\\"{x:613,y:775,t:1527023645576};\\\", \\\"{x:609,y:775,t:1527023645594};\\\", \\\"{x:604,y:774,t:1527023645609};\\\", \\\"{x:601,y:773,t:1527023645627};\\\", \\\"{x:598,y:771,t:1527023645644};\\\", \\\"{x:592,y:767,t:1527023645661};\\\", \\\"{x:580,y:760,t:1527023645677};\\\", \\\"{x:561,y:747,t:1527023645695};\\\", \\\"{x:550,y:739,t:1527023645710};\\\", \\\"{x:535,y:732,t:1527023645726};\\\", \\\"{x:523,y:726,t:1527023645741};\\\", \\\"{x:511,y:721,t:1527023645759};\\\", \\\"{x:509,y:720,t:1527023645775};\\\", \\\"{x:508,y:720,t:1527023645791};\\\", \\\"{x:507,y:720,t:1527023645965};\\\", \\\"{x:507,y:722,t:1527023645974};\\\", \\\"{x:507,y:723,t:1527023645991};\\\", \\\"{x:507,y:724,t:1527023646008};\\\", \\\"{x:507,y:726,t:1527023646030};\\\", \\\"{x:508,y:726,t:1527023646041};\\\", \\\"{x:508,y:727,t:1527023646058};\\\" ] }, { \\\"rt\\\": 15943, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 758988, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:727,t:1527023651366};\\\", \\\"{x:722,y:665,t:1527023651392};\\\", \\\"{x:813,y:647,t:1527023651397};\\\", \\\"{x:989,y:625,t:1527023651414};\\\", \\\"{x:1118,y:597,t:1527023651429};\\\", \\\"{x:1252,y:567,t:1527023651445};\\\", \\\"{x:1354,y:546,t:1527023651462};\\\", \\\"{x:1441,y:527,t:1527023651479};\\\", \\\"{x:1506,y:515,t:1527023651496};\\\", \\\"{x:1532,y:507,t:1527023651513};\\\", \\\"{x:1547,y:501,t:1527023651529};\\\", \\\"{x:1551,y:498,t:1527023651546};\\\", \\\"{x:1551,y:499,t:1527023651589};\\\", \\\"{x:1546,y:502,t:1527023651597};\\\", \\\"{x:1541,y:506,t:1527023651612};\\\", \\\"{x:1537,y:521,t:1527023651630};\\\", \\\"{x:1537,y:525,t:1527023651647};\\\", \\\"{x:1537,y:527,t:1527023651663};\\\", \\\"{x:1537,y:530,t:1527023651681};\\\", \\\"{x:1534,y:541,t:1527023651697};\\\", \\\"{x:1519,y:566,t:1527023651713};\\\", \\\"{x:1500,y:585,t:1527023651730};\\\", \\\"{x:1485,y:606,t:1527023651747};\\\", \\\"{x:1464,y:637,t:1527023651763};\\\", \\\"{x:1451,y:656,t:1527023651780};\\\", \\\"{x:1437,y:684,t:1527023651797};\\\", \\\"{x:1425,y:702,t:1527023651813};\\\", \\\"{x:1418,y:710,t:1527023651830};\\\", \\\"{x:1411,y:717,t:1527023651847};\\\", \\\"{x:1407,y:719,t:1527023651863};\\\", \\\"{x:1401,y:723,t:1527023651881};\\\", \\\"{x:1399,y:724,t:1527023651897};\\\", \\\"{x:1397,y:726,t:1527023651913};\\\", \\\"{x:1397,y:727,t:1527023651934};\\\", \\\"{x:1394,y:730,t:1527023651950};\\\", \\\"{x:1393,y:732,t:1527023651966};\\\", \\\"{x:1391,y:735,t:1527023651980};\\\", \\\"{x:1389,y:740,t:1527023651998};\\\", \\\"{x:1387,y:749,t:1527023652014};\\\", \\\"{x:1385,y:755,t:1527023652030};\\\", \\\"{x:1383,y:760,t:1527023652047};\\\", \\\"{x:1383,y:771,t:1527023652065};\\\", \\\"{x:1382,y:784,t:1527023652080};\\\", \\\"{x:1382,y:802,t:1527023652097};\\\", \\\"{x:1382,y:817,t:1527023652114};\\\", \\\"{x:1391,y:834,t:1527023652130};\\\", \\\"{x:1401,y:853,t:1527023652147};\\\", \\\"{x:1406,y:863,t:1527023652164};\\\", \\\"{x:1412,y:871,t:1527023652180};\\\", \\\"{x:1421,y:879,t:1527023652197};\\\", \\\"{x:1436,y:884,t:1527023652214};\\\", \\\"{x:1440,y:885,t:1527023652230};\\\", \\\"{x:1441,y:886,t:1527023652246};\\\", \\\"{x:1441,y:885,t:1527023654654};\\\", \\\"{x:1441,y:884,t:1527023654666};\\\", \\\"{x:1441,y:883,t:1527023654682};\\\", \\\"{x:1441,y:882,t:1527023654699};\\\", \\\"{x:1441,y:880,t:1527023654717};\\\", \\\"{x:1441,y:878,t:1527023654733};\\\", \\\"{x:1441,y:876,t:1527023654749};\\\", \\\"{x:1441,y:872,t:1527023654765};\\\", \\\"{x:1440,y:869,t:1527023654784};\\\", \\\"{x:1439,y:866,t:1527023654799};\\\", \\\"{x:1439,y:862,t:1527023654816};\\\", \\\"{x:1439,y:859,t:1527023654833};\\\", \\\"{x:1439,y:855,t:1527023654849};\\\", \\\"{x:1439,y:854,t:1527023654866};\\\", \\\"{x:1439,y:850,t:1527023654883};\\\", \\\"{x:1440,y:843,t:1527023654899};\\\", \\\"{x:1445,y:838,t:1527023654916};\\\", \\\"{x:1447,y:832,t:1527023654934};\\\", \\\"{x:1450,y:825,t:1527023654949};\\\", \\\"{x:1453,y:820,t:1527023654966};\\\", \\\"{x:1453,y:819,t:1527023654983};\\\", \\\"{x:1453,y:812,t:1527023655000};\\\", \\\"{x:1453,y:807,t:1527023655016};\\\", \\\"{x:1453,y:799,t:1527023655034};\\\", \\\"{x:1453,y:784,t:1527023655051};\\\", \\\"{x:1452,y:772,t:1527023655066};\\\", \\\"{x:1442,y:761,t:1527023655084};\\\", \\\"{x:1435,y:746,t:1527023655100};\\\", \\\"{x:1424,y:729,t:1527023655115};\\\", \\\"{x:1414,y:714,t:1527023655132};\\\", \\\"{x:1401,y:695,t:1527023655149};\\\", \\\"{x:1393,y:684,t:1527023655166};\\\", \\\"{x:1386,y:673,t:1527023655183};\\\", \\\"{x:1379,y:664,t:1527023655200};\\\", \\\"{x:1374,y:654,t:1527023655216};\\\", \\\"{x:1367,y:640,t:1527023655233};\\\", \\\"{x:1360,y:626,t:1527023655249};\\\", \\\"{x:1354,y:619,t:1527023655266};\\\", \\\"{x:1346,y:614,t:1527023655283};\\\", \\\"{x:1342,y:608,t:1527023655300};\\\", \\\"{x:1339,y:603,t:1527023655317};\\\", \\\"{x:1338,y:600,t:1527023655334};\\\", \\\"{x:1338,y:592,t:1527023655350};\\\", \\\"{x:1338,y:591,t:1527023655366};\\\", \\\"{x:1337,y:590,t:1527023655383};\\\", \\\"{x:1337,y:589,t:1527023655400};\\\", \\\"{x:1337,y:587,t:1527023655417};\\\", \\\"{x:1337,y:586,t:1527023655438};\\\", \\\"{x:1337,y:585,t:1527023655495};\\\", \\\"{x:1337,y:584,t:1527023655510};\\\", \\\"{x:1337,y:583,t:1527023655575};\\\", \\\"{x:1337,y:582,t:1527023655614};\\\", \\\"{x:1339,y:581,t:1527023655631};\\\", \\\"{x:1339,y:580,t:1527023655654};\\\", \\\"{x:1342,y:580,t:1527023655670};\\\", \\\"{x:1343,y:580,t:1527023655686};\\\", \\\"{x:1344,y:580,t:1527023655700};\\\", \\\"{x:1345,y:579,t:1527023655718};\\\", \\\"{x:1349,y:579,t:1527023655733};\\\", \\\"{x:1352,y:579,t:1527023655750};\\\", \\\"{x:1357,y:579,t:1527023655768};\\\", \\\"{x:1366,y:579,t:1527023655784};\\\", \\\"{x:1378,y:579,t:1527023655800};\\\", \\\"{x:1388,y:582,t:1527023655817};\\\", \\\"{x:1400,y:586,t:1527023655835};\\\", \\\"{x:1410,y:591,t:1527023655851};\\\", \\\"{x:1421,y:599,t:1527023655867};\\\", \\\"{x:1423,y:601,t:1527023655885};\\\", \\\"{x:1426,y:604,t:1527023655900};\\\", \\\"{x:1429,y:607,t:1527023655918};\\\", \\\"{x:1430,y:609,t:1527023655934};\\\", \\\"{x:1430,y:610,t:1527023655950};\\\", \\\"{x:1430,y:612,t:1527023655967};\\\", \\\"{x:1431,y:613,t:1527023655984};\\\", \\\"{x:1431,y:614,t:1527023656000};\\\", \\\"{x:1432,y:614,t:1527023656017};\\\", \\\"{x:1432,y:615,t:1527023656046};\\\", \\\"{x:1432,y:616,t:1527023656062};\\\", \\\"{x:1432,y:617,t:1527023656078};\\\", \\\"{x:1432,y:619,t:1527023656110};\\\", \\\"{x:1432,y:620,t:1527023656118};\\\", \\\"{x:1432,y:626,t:1527023656134};\\\", \\\"{x:1432,y:631,t:1527023656150};\\\", \\\"{x:1430,y:641,t:1527023656168};\\\", \\\"{x:1429,y:654,t:1527023656184};\\\", \\\"{x:1428,y:665,t:1527023656200};\\\", \\\"{x:1425,y:680,t:1527023656217};\\\", \\\"{x:1425,y:693,t:1527023656234};\\\", \\\"{x:1425,y:704,t:1527023656251};\\\", \\\"{x:1425,y:720,t:1527023656268};\\\", \\\"{x:1425,y:735,t:1527023656284};\\\", \\\"{x:1425,y:752,t:1527023656301};\\\", \\\"{x:1425,y:768,t:1527023656317};\\\", \\\"{x:1430,y:783,t:1527023656334};\\\", \\\"{x:1432,y:793,t:1527023656351};\\\", \\\"{x:1434,y:803,t:1527023656367};\\\", \\\"{x:1438,y:814,t:1527023656384};\\\", \\\"{x:1441,y:821,t:1527023656401};\\\", \\\"{x:1441,y:828,t:1527023656418};\\\", \\\"{x:1441,y:838,t:1527023656434};\\\", \\\"{x:1441,y:851,t:1527023656452};\\\", \\\"{x:1441,y:865,t:1527023656467};\\\", \\\"{x:1441,y:878,t:1527023656484};\\\", \\\"{x:1441,y:886,t:1527023656501};\\\", \\\"{x:1441,y:894,t:1527023656518};\\\", \\\"{x:1440,y:910,t:1527023656534};\\\", \\\"{x:1438,y:916,t:1527023656551};\\\", \\\"{x:1437,y:921,t:1527023656569};\\\", \\\"{x:1437,y:922,t:1527023656585};\\\", \\\"{x:1437,y:924,t:1527023656694};\\\", \\\"{x:1437,y:925,t:1527023656710};\\\", \\\"{x:1437,y:926,t:1527023656718};\\\", \\\"{x:1437,y:928,t:1527023656734};\\\", \\\"{x:1436,y:930,t:1527023656751};\\\", \\\"{x:1435,y:933,t:1527023656769};\\\", \\\"{x:1434,y:937,t:1527023656784};\\\", \\\"{x:1432,y:939,t:1527023656802};\\\", \\\"{x:1431,y:941,t:1527023656818};\\\", \\\"{x:1430,y:942,t:1527023656835};\\\", \\\"{x:1429,y:943,t:1527023656851};\\\", \\\"{x:1428,y:944,t:1527023656869};\\\", \\\"{x:1426,y:946,t:1527023656886};\\\", \\\"{x:1425,y:946,t:1527023656901};\\\", \\\"{x:1422,y:949,t:1527023656918};\\\", \\\"{x:1421,y:950,t:1527023656943};\\\", \\\"{x:1420,y:951,t:1527023656982};\\\", \\\"{x:1418,y:952,t:1527023656990};\\\", \\\"{x:1417,y:953,t:1527023657006};\\\", \\\"{x:1415,y:958,t:1527023657019};\\\", \\\"{x:1414,y:960,t:1527023657035};\\\", \\\"{x:1412,y:963,t:1527023657051};\\\", \\\"{x:1411,y:965,t:1527023657069};\\\", \\\"{x:1408,y:967,t:1527023657086};\\\", \\\"{x:1407,y:969,t:1527023657102};\\\", \\\"{x:1400,y:974,t:1527023657117};\\\", \\\"{x:1397,y:975,t:1527023657135};\\\", \\\"{x:1395,y:977,t:1527023657151};\\\", \\\"{x:1394,y:978,t:1527023657175};\\\", \\\"{x:1393,y:979,t:1527023657238};\\\", \\\"{x:1392,y:979,t:1527023657251};\\\", \\\"{x:1388,y:979,t:1527023657269};\\\", \\\"{x:1377,y:979,t:1527023657285};\\\", \\\"{x:1362,y:979,t:1527023657302};\\\", \\\"{x:1344,y:979,t:1527023657318};\\\", \\\"{x:1333,y:979,t:1527023657336};\\\", \\\"{x:1330,y:980,t:1527023657352};\\\", \\\"{x:1330,y:981,t:1527023657369};\\\", \\\"{x:1330,y:980,t:1527023657478};\\\", \\\"{x:1331,y:978,t:1527023657485};\\\", \\\"{x:1332,y:977,t:1527023657502};\\\", \\\"{x:1333,y:975,t:1527023657519};\\\", \\\"{x:1334,y:974,t:1527023657535};\\\", \\\"{x:1337,y:973,t:1527023657552};\\\", \\\"{x:1339,y:972,t:1527023657569};\\\", \\\"{x:1340,y:971,t:1527023657638};\\\", \\\"{x:1341,y:971,t:1527023657652};\\\", \\\"{x:1342,y:969,t:1527023657669};\\\", \\\"{x:1345,y:966,t:1527023657686};\\\", \\\"{x:1349,y:961,t:1527023657702};\\\", \\\"{x:1351,y:958,t:1527023657720};\\\", \\\"{x:1352,y:957,t:1527023657736};\\\", \\\"{x:1352,y:955,t:1527023657752};\\\", \\\"{x:1352,y:954,t:1527023657790};\\\", \\\"{x:1354,y:953,t:1527023657807};\\\", \\\"{x:1355,y:950,t:1527023657822};\\\", \\\"{x:1355,y:948,t:1527023657847};\\\", \\\"{x:1356,y:947,t:1527023657854};\\\", \\\"{x:1357,y:945,t:1527023657869};\\\", \\\"{x:1358,y:945,t:1527023657885};\\\", \\\"{x:1359,y:944,t:1527023657902};\\\", \\\"{x:1360,y:941,t:1527023657919};\\\", \\\"{x:1361,y:940,t:1527023657936};\\\", \\\"{x:1362,y:938,t:1527023657974};\\\", \\\"{x:1362,y:937,t:1527023657985};\\\", \\\"{x:1365,y:934,t:1527023658003};\\\", \\\"{x:1367,y:929,t:1527023658019};\\\", \\\"{x:1369,y:924,t:1527023658036};\\\", \\\"{x:1370,y:922,t:1527023658053};\\\", \\\"{x:1373,y:918,t:1527023658069};\\\", \\\"{x:1376,y:911,t:1527023658086};\\\", \\\"{x:1376,y:908,t:1527023658101};\\\", \\\"{x:1378,y:904,t:1527023658118};\\\", \\\"{x:1378,y:900,t:1527023658136};\\\", \\\"{x:1380,y:897,t:1527023658151};\\\", \\\"{x:1380,y:896,t:1527023658181};\\\", \\\"{x:1381,y:894,t:1527023658213};\\\", \\\"{x:1381,y:893,t:1527023658237};\\\", \\\"{x:1382,y:891,t:1527023658270};\\\", \\\"{x:1382,y:890,t:1527023658285};\\\", \\\"{x:1383,y:890,t:1527023658390};\\\", \\\"{x:1383,y:888,t:1527023658454};\\\", \\\"{x:1383,y:887,t:1527023658486};\\\", \\\"{x:1383,y:885,t:1527023658734};\\\", \\\"{x:1383,y:884,t:1527023658774};\\\", \\\"{x:1383,y:882,t:1527023658894};\\\", \\\"{x:1381,y:882,t:1527023659038};\\\", \\\"{x:1375,y:882,t:1527023659054};\\\", \\\"{x:1334,y:882,t:1527023659070};\\\", \\\"{x:1247,y:882,t:1527023659087};\\\", \\\"{x:1145,y:882,t:1527023659103};\\\", \\\"{x:1028,y:881,t:1527023659120};\\\", \\\"{x:916,y:875,t:1527023659136};\\\", \\\"{x:815,y:855,t:1527023659154};\\\", \\\"{x:711,y:831,t:1527023659170};\\\", \\\"{x:631,y:810,t:1527023659186};\\\", \\\"{x:587,y:792,t:1527023659204};\\\", \\\"{x:541,y:777,t:1527023659220};\\\", \\\"{x:514,y:763,t:1527023659237};\\\", \\\"{x:487,y:751,t:1527023659254};\\\", \\\"{x:476,y:744,t:1527023659270};\\\", \\\"{x:475,y:743,t:1527023659286};\\\", \\\"{x:475,y:742,t:1527023659325};\\\", \\\"{x:475,y:740,t:1527023659336};\\\", \\\"{x:475,y:733,t:1527023659352};\\\", \\\"{x:475,y:718,t:1527023659369};\\\", \\\"{x:475,y:700,t:1527023659386};\\\", \\\"{x:477,y:683,t:1527023659402};\\\", \\\"{x:477,y:662,t:1527023659419};\\\", \\\"{x:474,y:643,t:1527023659436};\\\", \\\"{x:466,y:632,t:1527023659453};\\\", \\\"{x:459,y:627,t:1527023659470};\\\", \\\"{x:457,y:625,t:1527023659486};\\\", \\\"{x:456,y:625,t:1527023659541};\\\", \\\"{x:453,y:625,t:1527023659553};\\\", \\\"{x:448,y:621,t:1527023659569};\\\", \\\"{x:440,y:615,t:1527023659585};\\\", \\\"{x:432,y:613,t:1527023659603};\\\", \\\"{x:424,y:609,t:1527023659620};\\\", \\\"{x:416,y:603,t:1527023659636};\\\", \\\"{x:411,y:598,t:1527023659654};\\\", \\\"{x:404,y:589,t:1527023659670};\\\", \\\"{x:400,y:584,t:1527023659686};\\\", \\\"{x:397,y:580,t:1527023659703};\\\", \\\"{x:394,y:577,t:1527023659720};\\\", \\\"{x:392,y:575,t:1527023659736};\\\", \\\"{x:390,y:574,t:1527023659753};\\\", \\\"{x:388,y:573,t:1527023659770};\\\", \\\"{x:387,y:571,t:1527023659786};\\\", \\\"{x:387,y:570,t:1527023660262};\\\", \\\"{x:387,y:569,t:1527023660270};\\\", \\\"{x:388,y:565,t:1527023660288};\\\", \\\"{x:388,y:564,t:1527023660303};\\\", \\\"{x:390,y:562,t:1527023660320};\\\", \\\"{x:390,y:560,t:1527023660357};\\\", \\\"{x:390,y:559,t:1527023660389};\\\", \\\"{x:390,y:557,t:1527023660405};\\\", \\\"{x:390,y:556,t:1527023660420};\\\", \\\"{x:390,y:554,t:1527023660446};\\\", \\\"{x:391,y:552,t:1527023660461};\\\", \\\"{x:391,y:551,t:1527023660471};\\\", \\\"{x:391,y:549,t:1527023660487};\\\", \\\"{x:392,y:547,t:1527023660503};\\\", \\\"{x:392,y:546,t:1527023660520};\\\", \\\"{x:392,y:543,t:1527023660537};\\\", \\\"{x:392,y:541,t:1527023660553};\\\", \\\"{x:392,y:540,t:1527023660590};\\\", \\\"{x:392,y:544,t:1527023660869};\\\", \\\"{x:392,y:547,t:1527023660893};\\\", \\\"{x:392,y:551,t:1527023660904};\\\", \\\"{x:392,y:558,t:1527023660921};\\\", \\\"{x:392,y:563,t:1527023660937};\\\", \\\"{x:392,y:566,t:1527023660955};\\\", \\\"{x:392,y:568,t:1527023660969};\\\", \\\"{x:392,y:570,t:1527023660987};\\\", \\\"{x:392,y:573,t:1527023661004};\\\", \\\"{x:392,y:579,t:1527023661020};\\\", \\\"{x:392,y:588,t:1527023661037};\\\", \\\"{x:392,y:590,t:1527023661055};\\\", \\\"{x:392,y:591,t:1527023661071};\\\", \\\"{x:392,y:593,t:1527023661109};\\\", \\\"{x:391,y:595,t:1527023661121};\\\", \\\"{x:391,y:597,t:1527023661137};\\\", \\\"{x:390,y:598,t:1527023661154};\\\", \\\"{x:390,y:600,t:1527023661223};\\\", \\\"{x:390,y:601,t:1527023661238};\\\", \\\"{x:390,y:603,t:1527023661254};\\\", \\\"{x:389,y:605,t:1527023661271};\\\", \\\"{x:389,y:606,t:1527023661317};\\\", \\\"{x:395,y:610,t:1527023661750};\\\", \\\"{x:405,y:614,t:1527023661758};\\\", \\\"{x:418,y:619,t:1527023661771};\\\", \\\"{x:461,y:626,t:1527023661788};\\\", \\\"{x:513,y:635,t:1527023661804};\\\", \\\"{x:618,y:653,t:1527023661821};\\\", \\\"{x:716,y:670,t:1527023661838};\\\", \\\"{x:822,y:688,t:1527023661854};\\\", \\\"{x:916,y:700,t:1527023661871};\\\", \\\"{x:1012,y:709,t:1527023661889};\\\", \\\"{x:1091,y:711,t:1527023661904};\\\", \\\"{x:1176,y:719,t:1527023661921};\\\", \\\"{x:1266,y:726,t:1527023661939};\\\", \\\"{x:1365,y:736,t:1527023661955};\\\", \\\"{x:1451,y:745,t:1527023661972};\\\", \\\"{x:1544,y:751,t:1527023661988};\\\", \\\"{x:1663,y:751,t:1527023662006};\\\", \\\"{x:1695,y:747,t:1527023662022};\\\", \\\"{x:1766,y:738,t:1527023662038};\\\", \\\"{x:1794,y:732,t:1527023662056};\\\", \\\"{x:1815,y:725,t:1527023662071};\\\", \\\"{x:1825,y:720,t:1527023662088};\\\", \\\"{x:1832,y:716,t:1527023662106};\\\", \\\"{x:1833,y:715,t:1527023662122};\\\", \\\"{x:1833,y:714,t:1527023662139};\\\", \\\"{x:1833,y:713,t:1527023662156};\\\", \\\"{x:1821,y:707,t:1527023662172};\\\", \\\"{x:1788,y:698,t:1527023662189};\\\", \\\"{x:1745,y:692,t:1527023662205};\\\", \\\"{x:1718,y:692,t:1527023662221};\\\", \\\"{x:1695,y:692,t:1527023662238};\\\", \\\"{x:1679,y:692,t:1527023662255};\\\", \\\"{x:1677,y:692,t:1527023662271};\\\", \\\"{x:1675,y:692,t:1527023662301};\\\", \\\"{x:1673,y:692,t:1527023662310};\\\", \\\"{x:1671,y:694,t:1527023662322};\\\", \\\"{x:1663,y:697,t:1527023662338};\\\", \\\"{x:1652,y:705,t:1527023662355};\\\", \\\"{x:1644,y:717,t:1527023662371};\\\", \\\"{x:1633,y:733,t:1527023662389};\\\", \\\"{x:1619,y:757,t:1527023662406};\\\", \\\"{x:1609,y:777,t:1527023662422};\\\", \\\"{x:1607,y:785,t:1527023662438};\\\", \\\"{x:1601,y:801,t:1527023662455};\\\", \\\"{x:1590,y:815,t:1527023662473};\\\", \\\"{x:1581,y:821,t:1527023662489};\\\", \\\"{x:1573,y:827,t:1527023662506};\\\", \\\"{x:1558,y:834,t:1527023662523};\\\", \\\"{x:1546,y:839,t:1527023662539};\\\", \\\"{x:1543,y:840,t:1527023662556};\\\", \\\"{x:1542,y:840,t:1527023662576};\\\", \\\"{x:1539,y:840,t:1527023662589};\\\", \\\"{x:1536,y:840,t:1527023662605};\\\", \\\"{x:1532,y:840,t:1527023662622};\\\", \\\"{x:1527,y:840,t:1527023662638};\\\", \\\"{x:1525,y:840,t:1527023662655};\\\", \\\"{x:1515,y:842,t:1527023662672};\\\", \\\"{x:1503,y:849,t:1527023662688};\\\", \\\"{x:1492,y:857,t:1527023662705};\\\", \\\"{x:1481,y:863,t:1527023662722};\\\", \\\"{x:1474,y:865,t:1527023662738};\\\", \\\"{x:1471,y:866,t:1527023662755};\\\", \\\"{x:1470,y:867,t:1527023662773};\\\", \\\"{x:1468,y:867,t:1527023662788};\\\", \\\"{x:1467,y:867,t:1527023662805};\\\", \\\"{x:1466,y:867,t:1527023662838};\\\", \\\"{x:1466,y:866,t:1527023662846};\\\", \\\"{x:1466,y:863,t:1527023662856};\\\", \\\"{x:1466,y:856,t:1527023662872};\\\", \\\"{x:1466,y:850,t:1527023662889};\\\", \\\"{x:1466,y:846,t:1527023662905};\\\", \\\"{x:1466,y:843,t:1527023662922};\\\", \\\"{x:1466,y:841,t:1527023662939};\\\", \\\"{x:1466,y:840,t:1527023662955};\\\", \\\"{x:1467,y:839,t:1527023662972};\\\", \\\"{x:1465,y:839,t:1527023663350};\\\", \\\"{x:1451,y:839,t:1527023663358};\\\", \\\"{x:1433,y:842,t:1527023663373};\\\", \\\"{x:1314,y:851,t:1527023663389};\\\", \\\"{x:1215,y:851,t:1527023663406};\\\", \\\"{x:1126,y:851,t:1527023663423};\\\", \\\"{x:1043,y:843,t:1527023663439};\\\", \\\"{x:979,y:826,t:1527023663457};\\\", \\\"{x:928,y:808,t:1527023663473};\\\", \\\"{x:875,y:792,t:1527023663489};\\\", \\\"{x:823,y:781,t:1527023663506};\\\", \\\"{x:793,y:776,t:1527023663523};\\\", \\\"{x:765,y:771,t:1527023663540};\\\", \\\"{x:749,y:769,t:1527023663557};\\\", \\\"{x:739,y:769,t:1527023663573};\\\", \\\"{x:727,y:766,t:1527023663589};\\\", \\\"{x:713,y:765,t:1527023663606};\\\", \\\"{x:701,y:762,t:1527023663623};\\\", \\\"{x:692,y:761,t:1527023663640};\\\", \\\"{x:686,y:758,t:1527023663656};\\\", \\\"{x:680,y:758,t:1527023663673};\\\", \\\"{x:671,y:758,t:1527023663690};\\\", \\\"{x:660,y:755,t:1527023663707};\\\", \\\"{x:653,y:752,t:1527023663723};\\\", \\\"{x:642,y:752,t:1527023663740};\\\", \\\"{x:630,y:748,t:1527023663756};\\\", \\\"{x:599,y:742,t:1527023663774};\\\", \\\"{x:581,y:741,t:1527023663790};\\\", \\\"{x:563,y:741,t:1527023663807};\\\", \\\"{x:558,y:741,t:1527023663823};\\\", \\\"{x:551,y:738,t:1527023663839};\\\", \\\"{x:550,y:737,t:1527023663856};\\\", \\\"{x:550,y:736,t:1527023664317};\\\", \\\"{x:551,y:735,t:1527023664341};\\\", \\\"{x:552,y:735,t:1527023664365};\\\", \\\"{x:553,y:734,t:1527023664381};\\\", \\\"{x:554,y:734,t:1527023664397};\\\", \\\"{x:556,y:733,t:1527023664422};\\\", \\\"{x:557,y:733,t:1527023664437};\\\", \\\"{x:560,y:731,t:1527023664445};\\\", \\\"{x:565,y:729,t:1527023664456};\\\", \\\"{x:575,y:725,t:1527023664473};\\\", \\\"{x:591,y:724,t:1527023664490};\\\", \\\"{x:606,y:721,t:1527023664507};\\\", \\\"{x:621,y:720,t:1527023664523};\\\", \\\"{x:634,y:719,t:1527023664541};\\\", \\\"{x:667,y:717,t:1527023664558};\\\", \\\"{x:691,y:717,t:1527023664574};\\\", \\\"{x:739,y:720,t:1527023664590};\\\", \\\"{x:802,y:725,t:1527023664607};\\\", \\\"{x:875,y:736,t:1527023664624};\\\", \\\"{x:952,y:745,t:1527023664640};\\\", \\\"{x:1068,y:757,t:1527023664657};\\\", \\\"{x:1194,y:766,t:1527023664674};\\\", \\\"{x:1321,y:766,t:1527023664691};\\\", \\\"{x:1415,y:773,t:1527023664707};\\\", \\\"{x:1509,y:773,t:1527023664723};\\\", \\\"{x:1559,y:773,t:1527023664740};\\\", \\\"{x:1607,y:773,t:1527023664758};\\\", \\\"{x:1623,y:773,t:1527023664774};\\\", \\\"{x:1629,y:772,t:1527023664790};\\\", \\\"{x:1631,y:772,t:1527023664808};\\\", \\\"{x:1633,y:772,t:1527023664823};\\\", \\\"{x:1635,y:772,t:1527023664841};\\\", \\\"{x:1639,y:772,t:1527023664857};\\\", \\\"{x:1644,y:772,t:1527023664873};\\\", \\\"{x:1648,y:772,t:1527023664890};\\\", \\\"{x:1658,y:772,t:1527023664908};\\\", \\\"{x:1666,y:772,t:1527023664923};\\\", \\\"{x:1669,y:772,t:1527023664941};\\\", \\\"{x:1674,y:772,t:1527023664957};\\\", \\\"{x:1677,y:772,t:1527023664974};\\\", \\\"{x:1680,y:772,t:1527023664991};\\\" ] }, { \\\"rt\\\": 12800, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 773082, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1676,y:766,t:1527023667167};\\\", \\\"{x:1668,y:761,t:1527023667176};\\\", \\\"{x:1643,y:739,t:1527023667204};\\\", \\\"{x:1635,y:732,t:1527023667209};\\\", \\\"{x:1623,y:721,t:1527023667225};\\\", \\\"{x:1608,y:712,t:1527023667242};\\\", \\\"{x:1599,y:705,t:1527023667260};\\\", \\\"{x:1595,y:701,t:1527023667275};\\\", \\\"{x:1594,y:697,t:1527023667292};\\\", \\\"{x:1588,y:690,t:1527023667309};\\\", \\\"{x:1587,y:688,t:1527023667325};\\\", \\\"{x:1586,y:685,t:1527023667342};\\\", \\\"{x:1584,y:684,t:1527023667360};\\\", \\\"{x:1583,y:683,t:1527023667376};\\\", \\\"{x:1581,y:683,t:1527023667393};\\\", \\\"{x:1579,y:681,t:1527023667410};\\\", \\\"{x:1577,y:681,t:1527023667426};\\\", \\\"{x:1576,y:681,t:1527023667443};\\\", \\\"{x:1573,y:681,t:1527023667460};\\\", \\\"{x:1567,y:681,t:1527023667476};\\\", \\\"{x:1560,y:681,t:1527023667493};\\\", \\\"{x:1547,y:681,t:1527023667510};\\\", \\\"{x:1536,y:682,t:1527023667526};\\\", \\\"{x:1528,y:683,t:1527023667543};\\\", \\\"{x:1521,y:684,t:1527023667560};\\\", \\\"{x:1513,y:686,t:1527023667577};\\\", \\\"{x:1510,y:687,t:1527023667593};\\\", \\\"{x:1507,y:690,t:1527023667610};\\\", \\\"{x:1500,y:699,t:1527023667627};\\\", \\\"{x:1500,y:702,t:1527023667643};\\\", \\\"{x:1500,y:699,t:1527023668110};\\\", \\\"{x:1501,y:694,t:1527023668127};\\\", \\\"{x:1502,y:691,t:1527023668144};\\\", \\\"{x:1503,y:689,t:1527023668160};\\\", \\\"{x:1502,y:693,t:1527023668303};\\\", \\\"{x:1499,y:696,t:1527023668310};\\\", \\\"{x:1495,y:703,t:1527023668327};\\\", \\\"{x:1485,y:711,t:1527023668343};\\\", \\\"{x:1470,y:721,t:1527023668359};\\\", \\\"{x:1458,y:728,t:1527023668376};\\\", \\\"{x:1446,y:732,t:1527023668394};\\\", \\\"{x:1440,y:737,t:1527023668410};\\\", \\\"{x:1436,y:741,t:1527023668426};\\\", \\\"{x:1431,y:745,t:1527023668443};\\\", \\\"{x:1427,y:747,t:1527023668461};\\\", \\\"{x:1425,y:750,t:1527023668477};\\\", \\\"{x:1422,y:752,t:1527023668493};\\\", \\\"{x:1421,y:752,t:1527023668511};\\\", \\\"{x:1419,y:753,t:1527023668527};\\\", \\\"{x:1418,y:753,t:1527023668544};\\\", \\\"{x:1416,y:753,t:1527023668566};\\\", \\\"{x:1414,y:753,t:1527023668577};\\\", \\\"{x:1406,y:747,t:1527023668594};\\\", \\\"{x:1392,y:738,t:1527023668611};\\\", \\\"{x:1378,y:732,t:1527023668626};\\\", \\\"{x:1364,y:724,t:1527023668644};\\\", \\\"{x:1356,y:719,t:1527023668661};\\\", \\\"{x:1348,y:714,t:1527023668677};\\\", \\\"{x:1343,y:709,t:1527023668694};\\\", \\\"{x:1342,y:708,t:1527023668718};\\\", \\\"{x:1342,y:707,t:1527023668750};\\\", \\\"{x:1342,y:706,t:1527023668762};\\\", \\\"{x:1341,y:704,t:1527023668778};\\\", \\\"{x:1340,y:702,t:1527023668794};\\\", \\\"{x:1340,y:701,t:1527023668811};\\\", \\\"{x:1340,y:700,t:1527023668828};\\\", \\\"{x:1340,y:699,t:1527023668843};\\\", \\\"{x:1340,y:698,t:1527023668861};\\\", \\\"{x:1340,y:697,t:1527023668878};\\\", \\\"{x:1340,y:695,t:1527023668991};\\\", \\\"{x:1342,y:695,t:1527023669008};\\\", \\\"{x:1345,y:695,t:1527023669028};\\\", \\\"{x:1346,y:695,t:1527023669043};\\\", \\\"{x:1347,y:695,t:1527023669060};\\\", \\\"{x:1348,y:695,t:1527023669078};\\\", \\\"{x:1339,y:695,t:1527023671655};\\\", \\\"{x:1331,y:695,t:1527023671663};\\\", \\\"{x:1309,y:694,t:1527023671680};\\\", \\\"{x:1287,y:694,t:1527023671696};\\\", \\\"{x:1253,y:694,t:1527023671713};\\\", \\\"{x:1172,y:696,t:1527023671730};\\\", \\\"{x:1055,y:696,t:1527023671746};\\\", \\\"{x:922,y:696,t:1527023671763};\\\", \\\"{x:801,y:696,t:1527023671779};\\\", \\\"{x:692,y:696,t:1527023671796};\\\", \\\"{x:598,y:696,t:1527023671812};\\\", \\\"{x:504,y:691,t:1527023671829};\\\", \\\"{x:475,y:687,t:1527023671846};\\\", \\\"{x:463,y:685,t:1527023671863};\\\", \\\"{x:457,y:683,t:1527023671879};\\\", \\\"{x:454,y:682,t:1527023671896};\\\", \\\"{x:450,y:680,t:1527023671913};\\\", \\\"{x:446,y:680,t:1527023671929};\\\", \\\"{x:446,y:676,t:1527023671958};\\\", \\\"{x:446,y:674,t:1527023671965};\\\", \\\"{x:445,y:672,t:1527023671980};\\\", \\\"{x:445,y:671,t:1527023671997};\\\", \\\"{x:444,y:668,t:1527023672014};\\\", \\\"{x:432,y:654,t:1527023672029};\\\", \\\"{x:427,y:646,t:1527023672046};\\\", \\\"{x:427,y:641,t:1527023672062};\\\", \\\"{x:427,y:637,t:1527023672080};\\\", \\\"{x:427,y:631,t:1527023672097};\\\", \\\"{x:424,y:625,t:1527023672113};\\\", \\\"{x:423,y:623,t:1527023672129};\\\", \\\"{x:422,y:622,t:1527023672147};\\\", \\\"{x:421,y:621,t:1527023672162};\\\", \\\"{x:417,y:620,t:1527023672179};\\\", \\\"{x:411,y:618,t:1527023672196};\\\", \\\"{x:400,y:614,t:1527023672213};\\\", \\\"{x:395,y:613,t:1527023672229};\\\", \\\"{x:394,y:611,t:1527023672247};\\\", \\\"{x:392,y:611,t:1527023672469};\\\", \\\"{x:385,y:611,t:1527023672480};\\\", \\\"{x:360,y:607,t:1527023672498};\\\", \\\"{x:331,y:604,t:1527023672513};\\\", \\\"{x:302,y:600,t:1527023672530};\\\", \\\"{x:265,y:595,t:1527023672546};\\\", \\\"{x:250,y:594,t:1527023672563};\\\", \\\"{x:241,y:594,t:1527023672580};\\\", \\\"{x:240,y:593,t:1527023672597};\\\", \\\"{x:239,y:593,t:1527023672613};\\\", \\\"{x:237,y:593,t:1527023672654};\\\", \\\"{x:235,y:593,t:1527023672670};\\\", \\\"{x:233,y:592,t:1527023672681};\\\", \\\"{x:228,y:589,t:1527023672697};\\\", \\\"{x:221,y:586,t:1527023672714};\\\", \\\"{x:215,y:585,t:1527023672731};\\\", \\\"{x:207,y:582,t:1527023672747};\\\", \\\"{x:203,y:582,t:1527023672764};\\\", \\\"{x:201,y:582,t:1527023672781};\\\", \\\"{x:201,y:581,t:1527023672806};\\\", \\\"{x:202,y:580,t:1527023672813};\\\", \\\"{x:213,y:579,t:1527023672831};\\\", \\\"{x:228,y:577,t:1527023672847};\\\", \\\"{x:255,y:576,t:1527023672864};\\\", \\\"{x:293,y:574,t:1527023672883};\\\", \\\"{x:368,y:574,t:1527023672897};\\\", \\\"{x:442,y:577,t:1527023672913};\\\", \\\"{x:539,y:581,t:1527023672931};\\\", \\\"{x:625,y:581,t:1527023672947};\\\", \\\"{x:701,y:582,t:1527023672963};\\\", \\\"{x:761,y:585,t:1527023672981};\\\", \\\"{x:798,y:585,t:1527023672997};\\\", \\\"{x:824,y:585,t:1527023673013};\\\", \\\"{x:840,y:585,t:1527023673030};\\\", \\\"{x:851,y:585,t:1527023673048};\\\", \\\"{x:852,y:584,t:1527023673064};\\\", \\\"{x:853,y:582,t:1527023673166};\\\", \\\"{x:855,y:581,t:1527023673180};\\\", \\\"{x:855,y:577,t:1527023673198};\\\", \\\"{x:849,y:571,t:1527023673215};\\\", \\\"{x:836,y:562,t:1527023673233};\\\", \\\"{x:834,y:560,t:1527023673248};\\\", \\\"{x:834,y:559,t:1527023673263};\\\", \\\"{x:834,y:557,t:1527023673280};\\\", \\\"{x:833,y:555,t:1527023673298};\\\", \\\"{x:833,y:553,t:1527023673349};\\\", \\\"{x:833,y:552,t:1527023673363};\\\", \\\"{x:833,y:550,t:1527023673382};\\\", \\\"{x:833,y:548,t:1527023673397};\\\", \\\"{x:833,y:547,t:1527023673421};\\\", \\\"{x:826,y:549,t:1527023673981};\\\", \\\"{x:796,y:577,t:1527023673998};\\\", \\\"{x:748,y:616,t:1527023674015};\\\", \\\"{x:678,y:651,t:1527023674033};\\\", \\\"{x:640,y:682,t:1527023674048};\\\", \\\"{x:619,y:695,t:1527023674065};\\\", \\\"{x:609,y:702,t:1527023674081};\\\", \\\"{x:604,y:705,t:1527023674098};\\\", \\\"{x:603,y:706,t:1527023674115};\\\", \\\"{x:602,y:706,t:1527023674132};\\\", \\\"{x:600,y:707,t:1527023674147};\\\", \\\"{x:594,y:711,t:1527023674164};\\\", \\\"{x:580,y:715,t:1527023674181};\\\", \\\"{x:567,y:722,t:1527023674197};\\\", \\\"{x:560,y:728,t:1527023674216};\\\", \\\"{x:554,y:730,t:1527023674232};\\\", \\\"{x:551,y:732,t:1527023674247};\\\" ] }, { \\\"rt\\\": 14631, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 788921, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -O -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:732,t:1527023682966};\\\", \\\"{x:568,y:732,t:1527023682980};\\\", \\\"{x:616,y:724,t:1527023682995};\\\", \\\"{x:685,y:719,t:1527023683010};\\\", \\\"{x:745,y:715,t:1527023683022};\\\", \\\"{x:827,y:719,t:1527023683039};\\\", \\\"{x:936,y:725,t:1527023683055};\\\", \\\"{x:1038,y:737,t:1527023683072};\\\", \\\"{x:1126,y:744,t:1527023683089};\\\", \\\"{x:1193,y:744,t:1527023683105};\\\", \\\"{x:1246,y:744,t:1527023683122};\\\", \\\"{x:1304,y:744,t:1527023683139};\\\", \\\"{x:1344,y:744,t:1527023683155};\\\", \\\"{x:1370,y:744,t:1527023683172};\\\", \\\"{x:1395,y:744,t:1527023683189};\\\", \\\"{x:1403,y:747,t:1527023683205};\\\", \\\"{x:1404,y:752,t:1527023683223};\\\", \\\"{x:1404,y:753,t:1527023683702};\\\", \\\"{x:1403,y:753,t:1527023683709};\\\", \\\"{x:1401,y:753,t:1527023683724};\\\", \\\"{x:1400,y:753,t:1527023683933};\\\", \\\"{x:1401,y:752,t:1527023683973};\\\", \\\"{x:1404,y:751,t:1527023683989};\\\", \\\"{x:1407,y:749,t:1527023684006};\\\", \\\"{x:1410,y:748,t:1527023684023};\\\", \\\"{x:1413,y:746,t:1527023684039};\\\", \\\"{x:1416,y:745,t:1527023684057};\\\", \\\"{x:1419,y:743,t:1527023684073};\\\", \\\"{x:1420,y:743,t:1527023684090};\\\", \\\"{x:1422,y:742,t:1527023684107};\\\", \\\"{x:1423,y:742,t:1527023684124};\\\", \\\"{x:1425,y:740,t:1527023684141};\\\", \\\"{x:1427,y:740,t:1527023684156};\\\", \\\"{x:1433,y:737,t:1527023684174};\\\", \\\"{x:1437,y:735,t:1527023684190};\\\", \\\"{x:1438,y:735,t:1527023684207};\\\", \\\"{x:1442,y:734,t:1527023684224};\\\", \\\"{x:1448,y:732,t:1527023684241};\\\", \\\"{x:1454,y:732,t:1527023684257};\\\", \\\"{x:1461,y:731,t:1527023684274};\\\", \\\"{x:1474,y:731,t:1527023684290};\\\", \\\"{x:1482,y:731,t:1527023684306};\\\", \\\"{x:1487,y:731,t:1527023684323};\\\", \\\"{x:1488,y:731,t:1527023684341};\\\", \\\"{x:1489,y:731,t:1527023684357};\\\", \\\"{x:1491,y:731,t:1527023684374};\\\", \\\"{x:1495,y:731,t:1527023684390};\\\", \\\"{x:1497,y:731,t:1527023684406};\\\", \\\"{x:1504,y:732,t:1527023684424};\\\", \\\"{x:1508,y:733,t:1527023684441};\\\", \\\"{x:1510,y:734,t:1527023684457};\\\", \\\"{x:1510,y:736,t:1527023684473};\\\", \\\"{x:1513,y:739,t:1527023684491};\\\", \\\"{x:1515,y:743,t:1527023684507};\\\", \\\"{x:1517,y:749,t:1527023684524};\\\", \\\"{x:1520,y:753,t:1527023684541};\\\", \\\"{x:1522,y:757,t:1527023684558};\\\", \\\"{x:1522,y:760,t:1527023684573};\\\", \\\"{x:1523,y:764,t:1527023684590};\\\", \\\"{x:1523,y:767,t:1527023684608};\\\", \\\"{x:1523,y:770,t:1527023684623};\\\", \\\"{x:1523,y:774,t:1527023684640};\\\", \\\"{x:1523,y:777,t:1527023684657};\\\", \\\"{x:1523,y:778,t:1527023684686};\\\", \\\"{x:1523,y:779,t:1527023684702};\\\", \\\"{x:1522,y:780,t:1527023684710};\\\", \\\"{x:1522,y:781,t:1527023684724};\\\", \\\"{x:1519,y:785,t:1527023684741};\\\", \\\"{x:1516,y:789,t:1527023684758};\\\", \\\"{x:1515,y:791,t:1527023684774};\\\", \\\"{x:1514,y:792,t:1527023684788};\\\", \\\"{x:1511,y:794,t:1527023684805};\\\", \\\"{x:1508,y:796,t:1527023684821};\\\", \\\"{x:1504,y:798,t:1527023684839};\\\", \\\"{x:1498,y:800,t:1527023684855};\\\", \\\"{x:1493,y:803,t:1527023684872};\\\", \\\"{x:1485,y:806,t:1527023684889};\\\", \\\"{x:1478,y:809,t:1527023684905};\\\", \\\"{x:1472,y:813,t:1527023684922};\\\", \\\"{x:1469,y:814,t:1527023684939};\\\", \\\"{x:1466,y:816,t:1527023684956};\\\", \\\"{x:1464,y:816,t:1527023684972};\\\", \\\"{x:1462,y:817,t:1527023684989};\\\", \\\"{x:1462,y:818,t:1527023685006};\\\", \\\"{x:1459,y:822,t:1527023685022};\\\", \\\"{x:1459,y:824,t:1527023685038};\\\", \\\"{x:1455,y:828,t:1527023685056};\\\", \\\"{x:1455,y:833,t:1527023685073};\\\", \\\"{x:1460,y:840,t:1527023685088};\\\", \\\"{x:1471,y:847,t:1527023685106};\\\", \\\"{x:1486,y:852,t:1527023685122};\\\", \\\"{x:1508,y:854,t:1527023685139};\\\", \\\"{x:1543,y:855,t:1527023685155};\\\", \\\"{x:1567,y:857,t:1527023685172};\\\", \\\"{x:1583,y:857,t:1527023685189};\\\", \\\"{x:1593,y:857,t:1527023685205};\\\", \\\"{x:1596,y:857,t:1527023685222};\\\", \\\"{x:1597,y:857,t:1527023685239};\\\", \\\"{x:1598,y:857,t:1527023685255};\\\", \\\"{x:1602,y:856,t:1527023685272};\\\", \\\"{x:1607,y:855,t:1527023685288};\\\", \\\"{x:1609,y:853,t:1527023685305};\\\", \\\"{x:1612,y:851,t:1527023685322};\\\", \\\"{x:1614,y:850,t:1527023685339};\\\", \\\"{x:1618,y:847,t:1527023685356};\\\", \\\"{x:1621,y:845,t:1527023685373};\\\", \\\"{x:1623,y:843,t:1527023685388};\\\", \\\"{x:1624,y:840,t:1527023685406};\\\", \\\"{x:1627,y:834,t:1527023685422};\\\", \\\"{x:1628,y:828,t:1527023685440};\\\", \\\"{x:1628,y:819,t:1527023685456};\\\", \\\"{x:1625,y:810,t:1527023685472};\\\", \\\"{x:1616,y:801,t:1527023685489};\\\", \\\"{x:1608,y:795,t:1527023685506};\\\", \\\"{x:1600,y:786,t:1527023685523};\\\", \\\"{x:1591,y:773,t:1527023685540};\\\", \\\"{x:1588,y:764,t:1527023685556};\\\", \\\"{x:1581,y:749,t:1527023685572};\\\", \\\"{x:1572,y:728,t:1527023685589};\\\", \\\"{x:1566,y:713,t:1527023685605};\\\", \\\"{x:1565,y:700,t:1527023685623};\\\", \\\"{x:1565,y:686,t:1527023685640};\\\", \\\"{x:1565,y:679,t:1527023685655};\\\", \\\"{x:1565,y:673,t:1527023685673};\\\", \\\"{x:1565,y:671,t:1527023685690};\\\", \\\"{x:1565,y:670,t:1527023685706};\\\", \\\"{x:1565,y:669,t:1527023685723};\\\", \\\"{x:1568,y:672,t:1527023685844};\\\", \\\"{x:1577,y:679,t:1527023685856};\\\", \\\"{x:1588,y:686,t:1527023685873};\\\", \\\"{x:1593,y:689,t:1527023685889};\\\", \\\"{x:1597,y:692,t:1527023685906};\\\", \\\"{x:1600,y:692,t:1527023685923};\\\", \\\"{x:1601,y:692,t:1527023686172};\\\", \\\"{x:1604,y:693,t:1527023686189};\\\", \\\"{x:1607,y:694,t:1527023686207};\\\", \\\"{x:1609,y:696,t:1527023686225};\\\", \\\"{x:1609,y:697,t:1527023686256};\\\", \\\"{x:1610,y:698,t:1527023686276};\\\", \\\"{x:1611,y:699,t:1527023686724};\\\", \\\"{x:1610,y:709,t:1527023686741};\\\", \\\"{x:1608,y:717,t:1527023686757};\\\", \\\"{x:1604,y:728,t:1527023686774};\\\", \\\"{x:1601,y:734,t:1527023686791};\\\", \\\"{x:1599,y:740,t:1527023686807};\\\", \\\"{x:1596,y:745,t:1527023686824};\\\", \\\"{x:1592,y:752,t:1527023686840};\\\", \\\"{x:1590,y:758,t:1527023686857};\\\", \\\"{x:1586,y:767,t:1527023686873};\\\", \\\"{x:1583,y:772,t:1527023686891};\\\", \\\"{x:1582,y:775,t:1527023686906};\\\", \\\"{x:1579,y:779,t:1527023686923};\\\", \\\"{x:1579,y:780,t:1527023686947};\\\", \\\"{x:1577,y:784,t:1527023686956};\\\", \\\"{x:1576,y:789,t:1527023686973};\\\", \\\"{x:1572,y:794,t:1527023686989};\\\", \\\"{x:1571,y:801,t:1527023687006};\\\", \\\"{x:1568,y:805,t:1527023687022};\\\", \\\"{x:1565,y:807,t:1527023687040};\\\", \\\"{x:1563,y:811,t:1527023687056};\\\", \\\"{x:1561,y:816,t:1527023687073};\\\", \\\"{x:1560,y:820,t:1527023687090};\\\", \\\"{x:1558,y:823,t:1527023687106};\\\", \\\"{x:1558,y:824,t:1527023687123};\\\", \\\"{x:1557,y:825,t:1527023687140};\\\", \\\"{x:1556,y:827,t:1527023687163};\\\", \\\"{x:1554,y:829,t:1527023687179};\\\", \\\"{x:1554,y:830,t:1527023687195};\\\", \\\"{x:1552,y:832,t:1527023687207};\\\", \\\"{x:1550,y:835,t:1527023687224};\\\", \\\"{x:1549,y:839,t:1527023687241};\\\", \\\"{x:1547,y:841,t:1527023687258};\\\", \\\"{x:1545,y:844,t:1527023687273};\\\", \\\"{x:1543,y:847,t:1527023687290};\\\", \\\"{x:1539,y:854,t:1527023687307};\\\", \\\"{x:1537,y:856,t:1527023687323};\\\", \\\"{x:1535,y:859,t:1527023687340};\\\", \\\"{x:1532,y:861,t:1527023687358};\\\", \\\"{x:1532,y:862,t:1527023687373};\\\", \\\"{x:1531,y:865,t:1527023687390};\\\", \\\"{x:1529,y:868,t:1527023687407};\\\", \\\"{x:1527,y:870,t:1527023687423};\\\", \\\"{x:1527,y:872,t:1527023687441};\\\", \\\"{x:1523,y:873,t:1527023687457};\\\", \\\"{x:1522,y:874,t:1527023687473};\\\", \\\"{x:1522,y:875,t:1527023687490};\\\", \\\"{x:1522,y:876,t:1527023687508};\\\", \\\"{x:1520,y:877,t:1527023688003};\\\", \\\"{x:1518,y:882,t:1527023688012};\\\", \\\"{x:1514,y:889,t:1527023688024};\\\", \\\"{x:1507,y:900,t:1527023688041};\\\", \\\"{x:1504,y:904,t:1527023688058};\\\", \\\"{x:1499,y:912,t:1527023688075};\\\", \\\"{x:1495,y:920,t:1527023688091};\\\", \\\"{x:1491,y:929,t:1527023688108};\\\", \\\"{x:1490,y:930,t:1527023688125};\\\", \\\"{x:1488,y:933,t:1527023688142};\\\", \\\"{x:1488,y:934,t:1527023688158};\\\", \\\"{x:1486,y:939,t:1527023688174};\\\", \\\"{x:1484,y:943,t:1527023688192};\\\", \\\"{x:1483,y:950,t:1527023688208};\\\", \\\"{x:1479,y:957,t:1527023688225};\\\", \\\"{x:1478,y:960,t:1527023688242};\\\", \\\"{x:1478,y:961,t:1527023688258};\\\", \\\"{x:1478,y:962,t:1527023688316};\\\", \\\"{x:1478,y:963,t:1527023688396};\\\", \\\"{x:1474,y:960,t:1527023689892};\\\", \\\"{x:1451,y:948,t:1527023689909};\\\", \\\"{x:1423,y:936,t:1527023689925};\\\", \\\"{x:1393,y:923,t:1527023689943};\\\", \\\"{x:1359,y:904,t:1527023689959};\\\", \\\"{x:1330,y:892,t:1527023689976};\\\", \\\"{x:1304,y:874,t:1527023689993};\\\", \\\"{x:1271,y:845,t:1527023690010};\\\", \\\"{x:1223,y:810,t:1527023690025};\\\", \\\"{x:1149,y:762,t:1527023690043};\\\", \\\"{x:1044,y:699,t:1527023690059};\\\", \\\"{x:1001,y:674,t:1527023690076};\\\", \\\"{x:953,y:651,t:1527023690093};\\\", \\\"{x:908,y:633,t:1527023690109};\\\", \\\"{x:862,y:617,t:1527023690127};\\\", \\\"{x:840,y:605,t:1527023690142};\\\", \\\"{x:823,y:600,t:1527023690160};\\\", \\\"{x:816,y:597,t:1527023690176};\\\", \\\"{x:807,y:595,t:1527023690192};\\\", \\\"{x:787,y:587,t:1527023690209};\\\", \\\"{x:762,y:578,t:1527023690226};\\\", \\\"{x:687,y:563,t:1527023690243};\\\", \\\"{x:583,y:547,t:1527023690260};\\\", \\\"{x:539,y:537,t:1527023690276};\\\", \\\"{x:511,y:530,t:1527023690292};\\\", \\\"{x:503,y:527,t:1527023690309};\\\", \\\"{x:502,y:526,t:1527023690326};\\\", \\\"{x:506,y:525,t:1527023690342};\\\", \\\"{x:513,y:523,t:1527023690359};\\\", \\\"{x:515,y:520,t:1527023690376};\\\", \\\"{x:518,y:518,t:1527023690393};\\\", \\\"{x:520,y:517,t:1527023690411};\\\", \\\"{x:522,y:516,t:1527023690426};\\\", \\\"{x:541,y:511,t:1527023690444};\\\", \\\"{x:565,y:508,t:1527023690460};\\\", \\\"{x:583,y:507,t:1527023690476};\\\", \\\"{x:597,y:503,t:1527023690494};\\\", \\\"{x:598,y:503,t:1527023690510};\\\", \\\"{x:601,y:503,t:1527023690732};\\\", \\\"{x:602,y:503,t:1527023690787};\\\", \\\"{x:602,y:503,t:1527023690795};\\\", \\\"{x:609,y:502,t:1527023690826};\\\", \\\"{x:632,y:502,t:1527023690843};\\\", \\\"{x:653,y:502,t:1527023690860};\\\", \\\"{x:681,y:501,t:1527023690876};\\\", \\\"{x:704,y:501,t:1527023690893};\\\", \\\"{x:725,y:501,t:1527023690911};\\\", \\\"{x:742,y:501,t:1527023690926};\\\", \\\"{x:750,y:501,t:1527023690943};\\\", \\\"{x:755,y:501,t:1527023690959};\\\", \\\"{x:761,y:501,t:1527023690976};\\\", \\\"{x:776,y:501,t:1527023690993};\\\", \\\"{x:797,y:501,t:1527023691010};\\\", \\\"{x:814,y:501,t:1527023691026};\\\", \\\"{x:819,y:501,t:1527023691044};\\\", \\\"{x:819,y:500,t:1527023691244};\\\", \\\"{x:821,y:499,t:1527023691260};\\\", \\\"{x:823,y:498,t:1527023691277};\\\", \\\"{x:824,y:498,t:1527023691294};\\\", \\\"{x:826,y:496,t:1527023691312};\\\", \\\"{x:827,y:495,t:1527023691327};\\\", \\\"{x:826,y:496,t:1527023691579};\\\", \\\"{x:818,y:502,t:1527023691594};\\\", \\\"{x:800,y:520,t:1527023691611};\\\", \\\"{x:776,y:554,t:1527023691627};\\\", \\\"{x:756,y:578,t:1527023691643};\\\", \\\"{x:743,y:598,t:1527023691661};\\\", \\\"{x:733,y:610,t:1527023691677};\\\", \\\"{x:723,y:621,t:1527023691695};\\\", \\\"{x:719,y:625,t:1527023691710};\\\", \\\"{x:718,y:626,t:1527023691727};\\\", \\\"{x:716,y:627,t:1527023691743};\\\", \\\"{x:713,y:629,t:1527023691760};\\\", \\\"{x:703,y:635,t:1527023691778};\\\", \\\"{x:688,y:644,t:1527023691793};\\\", \\\"{x:667,y:654,t:1527023691810};\\\", \\\"{x:637,y:673,t:1527023691827};\\\", \\\"{x:615,y:683,t:1527023691844};\\\", \\\"{x:605,y:693,t:1527023691861};\\\", \\\"{x:596,y:696,t:1527023691877};\\\", \\\"{x:586,y:697,t:1527023691895};\\\", \\\"{x:584,y:699,t:1527023691910};\\\", \\\"{x:584,y:700,t:1527023691927};\\\", \\\"{x:580,y:695,t:1527023691955};\\\", \\\"{x:578,y:685,t:1527023691964};\\\", \\\"{x:576,y:672,t:1527023691977};\\\", \\\"{x:575,y:646,t:1527023691994};\\\", \\\"{x:580,y:620,t:1527023692012};\\\", \\\"{x:601,y:583,t:1527023692028};\\\", \\\"{x:614,y:563,t:1527023692044};\\\", \\\"{x:618,y:550,t:1527023692063};\\\", \\\"{x:619,y:535,t:1527023692077};\\\", \\\"{x:619,y:531,t:1527023692094};\\\", \\\"{x:619,y:530,t:1527023692111};\\\", \\\"{x:619,y:527,t:1527023692165};\\\", \\\"{x:618,y:526,t:1527023692177};\\\", \\\"{x:617,y:521,t:1527023692195};\\\", \\\"{x:616,y:516,t:1527023692210};\\\", \\\"{x:615,y:511,t:1527023692227};\\\", \\\"{x:615,y:506,t:1527023692244};\\\", \\\"{x:614,y:505,t:1527023692261};\\\", \\\"{x:613,y:502,t:1527023692307};\\\", \\\"{x:613,y:501,t:1527023692315};\\\", \\\"{x:612,y:500,t:1527023692331};\\\", \\\"{x:611,y:498,t:1527023692403};\\\", \\\"{x:610,y:497,t:1527023692435};\\\", \\\"{x:609,y:496,t:1527023692445};\\\", \\\"{x:609,y:495,t:1527023692524};\\\", \\\"{x:608,y:493,t:1527023692531};\\\", \\\"{x:607,y:493,t:1527023692555};\\\", \\\"{x:607,y:492,t:1527023692612};\\\", \\\"{x:605,y:501,t:1527023693236};\\\", \\\"{x:600,y:517,t:1527023693246};\\\", \\\"{x:591,y:545,t:1527023693262};\\\", \\\"{x:574,y:588,t:1527023693278};\\\", \\\"{x:559,y:634,t:1527023693295};\\\", \\\"{x:551,y:655,t:1527023693311};\\\", \\\"{x:545,y:674,t:1527023693328};\\\", \\\"{x:543,y:684,t:1527023693345};\\\", \\\"{x:543,y:685,t:1527023693361};\\\", \\\"{x:543,y:688,t:1527023693378};\\\", \\\"{x:543,y:694,t:1527023693394};\\\", \\\"{x:545,y:699,t:1527023693412};\\\", \\\"{x:548,y:703,t:1527023693428};\\\", \\\"{x:549,y:708,t:1527023693445};\\\", \\\"{x:552,y:712,t:1527023693463};\\\", \\\"{x:553,y:713,t:1527023693478};\\\", \\\"{x:553,y:714,t:1527023693499};\\\", \\\"{x:554,y:715,t:1527023693513};\\\", \\\"{x:555,y:717,t:1527023693529};\\\", \\\"{x:555,y:719,t:1527023693545};\\\", \\\"{x:558,y:721,t:1527023693563};\\\", \\\"{x:558,y:723,t:1527023693578};\\\", \\\"{x:559,y:723,t:1527023693595};\\\", \\\"{x:559,y:728,t:1527023693611};\\\", \\\"{x:561,y:731,t:1527023693629};\\\", \\\"{x:561,y:734,t:1527023693644};\\\", \\\"{x:561,y:737,t:1527023693662};\\\", \\\"{x:561,y:738,t:1527023693678};\\\", \\\"{x:561,y:740,t:1527023693694};\\\", \\\"{x:561,y:744,t:1527023693712};\\\", \\\"{x:559,y:750,t:1527023693728};\\\", \\\"{x:552,y:758,t:1527023693745};\\\", \\\"{x:551,y:761,t:1527023693762};\\\", \\\"{x:550,y:761,t:1527023693819};\\\", \\\"{x:549,y:761,t:1527023693828};\\\", \\\"{x:544,y:759,t:1527023693845};\\\", \\\"{x:534,y:751,t:1527023693863};\\\", \\\"{x:520,y:740,t:1527023693879};\\\", \\\"{x:515,y:736,t:1527023693895};\\\", \\\"{x:516,y:735,t:1527023694347};\\\", \\\"{x:519,y:733,t:1527023694363};\\\", \\\"{x:522,y:732,t:1527023694379};\\\", \\\"{x:527,y:729,t:1527023694396};\\\", \\\"{x:530,y:728,t:1527023694413};\\\", \\\"{x:539,y:724,t:1527023694430};\\\", \\\"{x:550,y:722,t:1527023694447};\\\", \\\"{x:562,y:719,t:1527023694463};\\\", \\\"{x:578,y:715,t:1527023694479};\\\", \\\"{x:587,y:714,t:1527023694497};\\\", \\\"{x:599,y:711,t:1527023694513};\\\", \\\"{x:605,y:709,t:1527023694530};\\\", \\\"{x:608,y:708,t:1527023694546};\\\", \\\"{x:609,y:708,t:1527023694643};\\\" ] }, { \\\"rt\\\": 14071, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 804266, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:616,y:707,t:1527023696620};\\\", \\\"{x:628,y:705,t:1527023696632};\\\", \\\"{x:653,y:700,t:1527023696647};\\\", \\\"{x:675,y:698,t:1527023696665};\\\", \\\"{x:711,y:692,t:1527023696682};\\\", \\\"{x:789,y:683,t:1527023696699};\\\", \\\"{x:927,y:674,t:1527023696715};\\\", \\\"{x:1033,y:672,t:1527023696732};\\\", \\\"{x:1133,y:672,t:1527023696748};\\\", \\\"{x:1230,y:672,t:1527023696765};\\\", \\\"{x:1332,y:672,t:1527023696782};\\\", \\\"{x:1431,y:679,t:1527023696798};\\\", \\\"{x:1482,y:682,t:1527023696815};\\\", \\\"{x:1513,y:684,t:1527023696832};\\\", \\\"{x:1535,y:685,t:1527023696848};\\\", \\\"{x:1546,y:684,t:1527023696864};\\\", \\\"{x:1556,y:682,t:1527023696882};\\\", \\\"{x:1570,y:679,t:1527023696899};\\\", \\\"{x:1573,y:679,t:1527023696915};\\\", \\\"{x:1576,y:679,t:1527023696932};\\\", \\\"{x:1577,y:678,t:1527023696972};\\\", \\\"{x:1577,y:676,t:1527023696987};\\\", \\\"{x:1575,y:676,t:1527023697004};\\\", \\\"{x:1575,y:675,t:1527023697015};\\\", \\\"{x:1570,y:674,t:1527023697032};\\\", \\\"{x:1566,y:671,t:1527023697049};\\\", \\\"{x:1559,y:669,t:1527023697065};\\\", \\\"{x:1556,y:667,t:1527023697082};\\\", \\\"{x:1549,y:665,t:1527023697100};\\\", \\\"{x:1547,y:665,t:1527023697116};\\\", \\\"{x:1546,y:664,t:1527023697131};\\\", \\\"{x:1544,y:664,t:1527023697155};\\\", \\\"{x:1542,y:664,t:1527023697165};\\\", \\\"{x:1538,y:664,t:1527023697181};\\\", \\\"{x:1533,y:664,t:1527023697198};\\\", \\\"{x:1525,y:664,t:1527023697214};\\\", \\\"{x:1513,y:669,t:1527023697232};\\\", \\\"{x:1501,y:681,t:1527023697248};\\\", \\\"{x:1493,y:691,t:1527023697265};\\\", \\\"{x:1483,y:707,t:1527023697281};\\\", \\\"{x:1472,y:734,t:1527023697298};\\\", \\\"{x:1471,y:752,t:1527023697314};\\\", \\\"{x:1471,y:779,t:1527023697331};\\\", \\\"{x:1471,y:809,t:1527023697349};\\\", \\\"{x:1480,y:843,t:1527023697366};\\\", \\\"{x:1484,y:864,t:1527023697381};\\\", \\\"{x:1492,y:880,t:1527023697399};\\\", \\\"{x:1494,y:890,t:1527023697416};\\\", \\\"{x:1494,y:897,t:1527023697432};\\\", \\\"{x:1494,y:900,t:1527023697449};\\\", \\\"{x:1494,y:902,t:1527023697466};\\\", \\\"{x:1494,y:903,t:1527023697491};\\\", \\\"{x:1494,y:905,t:1527023697515};\\\", \\\"{x:1494,y:909,t:1527023697532};\\\", \\\"{x:1494,y:913,t:1527023697549};\\\", \\\"{x:1494,y:918,t:1527023697566};\\\", \\\"{x:1494,y:924,t:1527023697582};\\\", \\\"{x:1490,y:931,t:1527023697599};\\\", \\\"{x:1482,y:938,t:1527023697616};\\\", \\\"{x:1471,y:947,t:1527023697632};\\\", \\\"{x:1456,y:962,t:1527023697649};\\\", \\\"{x:1450,y:965,t:1527023697666};\\\", \\\"{x:1442,y:970,t:1527023697682};\\\", \\\"{x:1437,y:975,t:1527023697699};\\\", \\\"{x:1432,y:982,t:1527023697715};\\\", \\\"{x:1431,y:984,t:1527023697732};\\\", \\\"{x:1431,y:985,t:1527023697750};\\\", \\\"{x:1431,y:989,t:1527023697766};\\\", \\\"{x:1432,y:990,t:1527023697783};\\\", \\\"{x:1433,y:991,t:1527023697820};\\\", \\\"{x:1434,y:991,t:1527023698043};\\\", \\\"{x:1436,y:990,t:1527023698052};\\\", \\\"{x:1438,y:987,t:1527023698066};\\\", \\\"{x:1449,y:979,t:1527023698084};\\\", \\\"{x:1460,y:973,t:1527023698099};\\\", \\\"{x:1468,y:969,t:1527023698116};\\\", \\\"{x:1474,y:964,t:1527023698134};\\\", \\\"{x:1478,y:962,t:1527023698150};\\\", \\\"{x:1481,y:961,t:1527023698166};\\\", \\\"{x:1490,y:957,t:1527023698183};\\\", \\\"{x:1506,y:955,t:1527023698200};\\\", \\\"{x:1518,y:951,t:1527023698216};\\\", \\\"{x:1527,y:949,t:1527023698233};\\\", \\\"{x:1537,y:946,t:1527023698250};\\\", \\\"{x:1546,y:943,t:1527023698266};\\\", \\\"{x:1554,y:941,t:1527023698283};\\\", \\\"{x:1555,y:941,t:1527023698316};\\\", \\\"{x:1556,y:941,t:1527023698333};\\\", \\\"{x:1557,y:942,t:1527023698452};\\\", \\\"{x:1557,y:944,t:1527023698467};\\\", \\\"{x:1554,y:949,t:1527023698483};\\\", \\\"{x:1552,y:954,t:1527023698500};\\\", \\\"{x:1550,y:955,t:1527023698517};\\\", \\\"{x:1548,y:956,t:1527023698620};\\\", \\\"{x:1547,y:958,t:1527023698633};\\\", \\\"{x:1546,y:958,t:1527023698650};\\\", \\\"{x:1546,y:960,t:1527023699804};\\\", \\\"{x:1546,y:961,t:1527023699817};\\\", \\\"{x:1546,y:965,t:1527023699834};\\\", \\\"{x:1546,y:966,t:1527023699851};\\\", \\\"{x:1546,y:967,t:1527023700500};\\\", \\\"{x:1547,y:967,t:1527023700780};\\\", \\\"{x:1548,y:967,t:1527023702156};\\\", \\\"{x:1545,y:962,t:1527023702170};\\\", \\\"{x:1501,y:948,t:1527023702186};\\\", \\\"{x:1292,y:889,t:1527023702204};\\\", \\\"{x:1092,y:854,t:1527023702219};\\\", \\\"{x:899,y:829,t:1527023702236};\\\", \\\"{x:717,y:805,t:1527023702253};\\\", \\\"{x:577,y:775,t:1527023702269};\\\", \\\"{x:500,y:754,t:1527023702286};\\\", \\\"{x:478,y:744,t:1527023702302};\\\", \\\"{x:475,y:742,t:1527023702318};\\\", \\\"{x:473,y:741,t:1527023702335};\\\", \\\"{x:473,y:739,t:1527023702378};\\\", \\\"{x:473,y:737,t:1527023702386};\\\", \\\"{x:473,y:731,t:1527023702402};\\\", \\\"{x:473,y:726,t:1527023702419};\\\", \\\"{x:473,y:722,t:1527023702435};\\\", \\\"{x:473,y:716,t:1527023702453};\\\", \\\"{x:473,y:706,t:1527023702470};\\\", \\\"{x:473,y:699,t:1527023702486};\\\", \\\"{x:473,y:685,t:1527023702503};\\\", \\\"{x:468,y:669,t:1527023702520};\\\", \\\"{x:462,y:653,t:1527023702536};\\\", \\\"{x:451,y:637,t:1527023702554};\\\", \\\"{x:444,y:623,t:1527023702570};\\\", \\\"{x:434,y:603,t:1527023702585};\\\", \\\"{x:411,y:579,t:1527023702603};\\\", \\\"{x:399,y:563,t:1527023702620};\\\", \\\"{x:389,y:549,t:1527023702636};\\\", \\\"{x:379,y:534,t:1527023702653};\\\", \\\"{x:368,y:525,t:1527023702670};\\\", \\\"{x:355,y:515,t:1527023702688};\\\", \\\"{x:344,y:507,t:1527023702703};\\\", \\\"{x:342,y:506,t:1527023702719};\\\", \\\"{x:343,y:506,t:1527023702842};\\\", \\\"{x:348,y:508,t:1527023702853};\\\", \\\"{x:364,y:525,t:1527023702870};\\\", \\\"{x:388,y:548,t:1527023702887};\\\", \\\"{x:417,y:564,t:1527023702904};\\\", \\\"{x:437,y:576,t:1527023702920};\\\", \\\"{x:479,y:582,t:1527023702937};\\\", \\\"{x:556,y:591,t:1527023702954};\\\", \\\"{x:630,y:598,t:1527023702971};\\\", \\\"{x:713,y:606,t:1527023702986};\\\", \\\"{x:744,y:607,t:1527023703003};\\\", \\\"{x:766,y:609,t:1527023703020};\\\", \\\"{x:778,y:609,t:1527023703037};\\\", \\\"{x:780,y:609,t:1527023703052};\\\", \\\"{x:781,y:608,t:1527023703070};\\\", \\\"{x:782,y:607,t:1527023703086};\\\", \\\"{x:783,y:607,t:1527023703102};\\\", \\\"{x:785,y:606,t:1527023703119};\\\", \\\"{x:792,y:603,t:1527023703136};\\\", \\\"{x:809,y:600,t:1527023703153};\\\", \\\"{x:817,y:596,t:1527023703169};\\\", \\\"{x:831,y:588,t:1527023703187};\\\", \\\"{x:830,y:587,t:1527023703259};\\\", \\\"{x:825,y:587,t:1527023703270};\\\", \\\"{x:802,y:583,t:1527023703288};\\\", \\\"{x:768,y:580,t:1527023703304};\\\", \\\"{x:742,y:577,t:1527023703320};\\\", \\\"{x:718,y:575,t:1527023703339};\\\", \\\"{x:700,y:571,t:1527023703354};\\\", \\\"{x:686,y:571,t:1527023703369};\\\", \\\"{x:680,y:571,t:1527023703387};\\\", \\\"{x:678,y:571,t:1527023703435};\\\", \\\"{x:672,y:572,t:1527023703443};\\\", \\\"{x:666,y:573,t:1527023703454};\\\", \\\"{x:652,y:575,t:1527023703470};\\\", \\\"{x:641,y:577,t:1527023703487};\\\", \\\"{x:634,y:578,t:1527023703503};\\\", \\\"{x:633,y:578,t:1527023703520};\\\", \\\"{x:631,y:578,t:1527023703537};\\\", \\\"{x:629,y:579,t:1527023703553};\\\", \\\"{x:626,y:580,t:1527023703570};\\\", \\\"{x:622,y:582,t:1527023703587};\\\", \\\"{x:619,y:583,t:1527023703603};\\\", \\\"{x:617,y:583,t:1527023703619};\\\", \\\"{x:619,y:585,t:1527023704051};\\\", \\\"{x:628,y:586,t:1527023704058};\\\", \\\"{x:641,y:592,t:1527023704071};\\\", \\\"{x:667,y:599,t:1527023704088};\\\", \\\"{x:701,y:612,t:1527023704104};\\\", \\\"{x:768,y:629,t:1527023704121};\\\", \\\"{x:840,y:651,t:1527023704138};\\\", \\\"{x:925,y:672,t:1527023704154};\\\", \\\"{x:1077,y:710,t:1527023704171};\\\", \\\"{x:1177,y:740,t:1527023704187};\\\", \\\"{x:1265,y:761,t:1527023704204};\\\", \\\"{x:1350,y:784,t:1527023704221};\\\", \\\"{x:1418,y:798,t:1527023704238};\\\", \\\"{x:1441,y:804,t:1527023704254};\\\", \\\"{x:1458,y:810,t:1527023704271};\\\", \\\"{x:1474,y:814,t:1527023704288};\\\", \\\"{x:1485,y:818,t:1527023704304};\\\", \\\"{x:1490,y:819,t:1527023704322};\\\", \\\"{x:1498,y:820,t:1527023704338};\\\", \\\"{x:1510,y:822,t:1527023704355};\\\", \\\"{x:1527,y:823,t:1527023704372};\\\", \\\"{x:1543,y:824,t:1527023704388};\\\", \\\"{x:1549,y:824,t:1527023704405};\\\", \\\"{x:1550,y:824,t:1527023704421};\\\", \\\"{x:1551,y:824,t:1527023704467};\\\", \\\"{x:1551,y:823,t:1527023704475};\\\", \\\"{x:1550,y:823,t:1527023704489};\\\", \\\"{x:1549,y:823,t:1527023704505};\\\", \\\"{x:1548,y:823,t:1527023704521};\\\", \\\"{x:1534,y:823,t:1527023704539};\\\", \\\"{x:1526,y:825,t:1527023704555};\\\", \\\"{x:1515,y:831,t:1527023704571};\\\", \\\"{x:1508,y:834,t:1527023704601};\\\", \\\"{x:1505,y:834,t:1527023704604};\\\", \\\"{x:1500,y:835,t:1527023704651};\\\", \\\"{x:1498,y:836,t:1527023704658};\\\", \\\"{x:1497,y:837,t:1527023704671};\\\", \\\"{x:1494,y:838,t:1527023704687};\\\", \\\"{x:1493,y:838,t:1527023704704};\\\", \\\"{x:1493,y:840,t:1527023704723};\\\", \\\"{x:1493,y:843,t:1527023704747};\\\", \\\"{x:1493,y:847,t:1527023704754};\\\", \\\"{x:1493,y:857,t:1527023704771};\\\", \\\"{x:1493,y:872,t:1527023704788};\\\", \\\"{x:1493,y:887,t:1527023704804};\\\", \\\"{x:1497,y:904,t:1527023704821};\\\", \\\"{x:1504,y:924,t:1527023704838};\\\", \\\"{x:1509,y:935,t:1527023704855};\\\", \\\"{x:1515,y:946,t:1527023704871};\\\", \\\"{x:1519,y:949,t:1527023704888};\\\", \\\"{x:1521,y:952,t:1527023704905};\\\", \\\"{x:1523,y:953,t:1527023704921};\\\", \\\"{x:1524,y:957,t:1527023704938};\\\", \\\"{x:1527,y:961,t:1527023704955};\\\", \\\"{x:1528,y:963,t:1527023704972};\\\", \\\"{x:1530,y:964,t:1527023704988};\\\", \\\"{x:1532,y:966,t:1527023705028};\\\", \\\"{x:1533,y:966,t:1527023705043};\\\", \\\"{x:1533,y:967,t:1527023705060};\\\", \\\"{x:1534,y:967,t:1527023705076};\\\", \\\"{x:1535,y:968,t:1527023705091};\\\", \\\"{x:1536,y:968,t:1527023705115};\\\", \\\"{x:1536,y:969,t:1527023705876};\\\", \\\"{x:1531,y:969,t:1527023705888};\\\", \\\"{x:1528,y:969,t:1527023705904};\\\", \\\"{x:1519,y:964,t:1527023705922};\\\", \\\"{x:1482,y:956,t:1527023705938};\\\", \\\"{x:1451,y:941,t:1527023705955};\\\", \\\"{x:1436,y:933,t:1527023705972};\\\", \\\"{x:1422,y:927,t:1527023705988};\\\", \\\"{x:1406,y:923,t:1527023706006};\\\", \\\"{x:1362,y:911,t:1527023706022};\\\", \\\"{x:1346,y:904,t:1527023706038};\\\", \\\"{x:1333,y:894,t:1527023706055};\\\", \\\"{x:1317,y:890,t:1527023706073};\\\", \\\"{x:1309,y:884,t:1527023706088};\\\", \\\"{x:1286,y:876,t:1527023706106};\\\", \\\"{x:1273,y:871,t:1527023706123};\\\", \\\"{x:1257,y:866,t:1527023706139};\\\", \\\"{x:1221,y:854,t:1527023706155};\\\", \\\"{x:1195,y:847,t:1527023706172};\\\", \\\"{x:1165,y:842,t:1527023706188};\\\", \\\"{x:1124,y:832,t:1527023706205};\\\", \\\"{x:1071,y:826,t:1527023706223};\\\", \\\"{x:1040,y:820,t:1527023706239};\\\", \\\"{x:1005,y:811,t:1527023706255};\\\", \\\"{x:986,y:806,t:1527023706272};\\\", \\\"{x:967,y:801,t:1527023706289};\\\", \\\"{x:952,y:798,t:1527023706306};\\\", \\\"{x:939,y:797,t:1527023706323};\\\", \\\"{x:933,y:794,t:1527023706339};\\\", \\\"{x:917,y:792,t:1527023706355};\\\", \\\"{x:902,y:792,t:1527023706372};\\\", \\\"{x:888,y:792,t:1527023706388};\\\", \\\"{x:881,y:792,t:1527023706405};\\\", \\\"{x:875,y:792,t:1527023706423};\\\", \\\"{x:867,y:790,t:1527023706439};\\\", \\\"{x:863,y:790,t:1527023706455};\\\", \\\"{x:856,y:788,t:1527023706473};\\\", \\\"{x:854,y:788,t:1527023706489};\\\", \\\"{x:848,y:787,t:1527023706505};\\\", \\\"{x:847,y:787,t:1527023706523};\\\", \\\"{x:839,y:786,t:1527023706539};\\\", \\\"{x:835,y:785,t:1527023706555};\\\", \\\"{x:830,y:784,t:1527023706573};\\\", \\\"{x:821,y:784,t:1527023706590};\\\", \\\"{x:815,y:783,t:1527023706605};\\\", \\\"{x:806,y:781,t:1527023706622};\\\", \\\"{x:797,y:780,t:1527023706639};\\\", \\\"{x:792,y:778,t:1527023706655};\\\", \\\"{x:788,y:778,t:1527023706672};\\\", \\\"{x:786,y:777,t:1527023706689};\\\", \\\"{x:784,y:777,t:1527023706705};\\\", \\\"{x:783,y:777,t:1527023706722};\\\", \\\"{x:778,y:776,t:1527023706739};\\\", \\\"{x:775,y:774,t:1527023706755};\\\", \\\"{x:771,y:774,t:1527023706773};\\\", \\\"{x:767,y:773,t:1527023706789};\\\", \\\"{x:764,y:773,t:1527023706805};\\\", \\\"{x:759,y:772,t:1527023706823};\\\", \\\"{x:755,y:771,t:1527023706839};\\\", \\\"{x:753,y:771,t:1527023706855};\\\", \\\"{x:752,y:771,t:1527023706872};\\\", \\\"{x:750,y:770,t:1527023706890};\\\", \\\"{x:749,y:770,t:1527023706907};\\\", \\\"{x:747,y:770,t:1527023706931};\\\", \\\"{x:746,y:770,t:1527023706947};\\\", \\\"{x:743,y:770,t:1527023706955};\\\", \\\"{x:741,y:769,t:1527023706973};\\\", \\\"{x:739,y:769,t:1527023706989};\\\", \\\"{x:737,y:769,t:1527023707005};\\\", \\\"{x:736,y:769,t:1527023707023};\\\", \\\"{x:735,y:768,t:1527023707059};\\\", \\\"{x:734,y:768,t:1527023707075};\\\", \\\"{x:724,y:768,t:1527023708868};\\\", \\\"{x:713,y:768,t:1527023708875};\\\", \\\"{x:701,y:768,t:1527023708890};\\\", \\\"{x:667,y:766,t:1527023708906};\\\", \\\"{x:622,y:762,t:1527023708923};\\\", \\\"{x:604,y:760,t:1527023708940};\\\", \\\"{x:603,y:759,t:1527023708957};\\\", \\\"{x:602,y:759,t:1527023708973};\\\", \\\"{x:601,y:759,t:1527023709060};\\\", \\\"{x:600,y:759,t:1527023709123};\\\", \\\"{x:598,y:759,t:1527023709140};\\\", \\\"{x:584,y:759,t:1527023709156};\\\", \\\"{x:566,y:755,t:1527023709173};\\\", \\\"{x:550,y:749,t:1527023709192};\\\", \\\"{x:531,y:744,t:1527023709206};\\\", \\\"{x:522,y:743,t:1527023709223};\\\", \\\"{x:520,y:741,t:1527023709242};\\\", \\\"{x:520,y:740,t:1527023709258};\\\", \\\"{x:519,y:740,t:1527023709275};\\\", \\\"{x:519,y:739,t:1527023709291};\\\", \\\"{x:518,y:739,t:1527023709308};\\\", \\\"{x:517,y:738,t:1527023709325};\\\", \\\"{x:518,y:734,t:1527023709682};\\\", \\\"{x:521,y:733,t:1527023709692};\\\", \\\"{x:532,y:729,t:1527023709709};\\\", \\\"{x:548,y:724,t:1527023709726};\\\", \\\"{x:571,y:722,t:1527023709742};\\\", \\\"{x:601,y:722,t:1527023709759};\\\", \\\"{x:637,y:722,t:1527023709775};\\\", \\\"{x:688,y:722,t:1527023709793};\\\", \\\"{x:755,y:722,t:1527023709809};\\\", \\\"{x:833,y:732,t:1527023709825};\\\", \\\"{x:916,y:745,t:1527023709842};\\\", \\\"{x:988,y:755,t:1527023709859};\\\", \\\"{x:1010,y:756,t:1527023709875};\\\", \\\"{x:1019,y:758,t:1527023709892};\\\", \\\"{x:1019,y:759,t:1527023709909};\\\" ] }, { \\\"rt\\\": 35897, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 841423, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -12 PM-12 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1022,y:759,t:1527023713355};\\\", \\\"{x:1023,y:759,t:1527023713363};\\\", \\\"{x:1023,y:758,t:1527023714027};\\\", \\\"{x:1023,y:756,t:1527023714042};\\\", \\\"{x:1022,y:755,t:1527023714049};\\\", \\\"{x:1022,y:753,t:1527023714062};\\\", \\\"{x:1016,y:742,t:1527023714079};\\\", \\\"{x:1007,y:727,t:1527023714095};\\\", \\\"{x:989,y:704,t:1527023714112};\\\", \\\"{x:947,y:657,t:1527023714129};\\\", \\\"{x:886,y:604,t:1527023714145};\\\", \\\"{x:802,y:528,t:1527023714163};\\\", \\\"{x:762,y:484,t:1527023714180};\\\", \\\"{x:731,y:425,t:1527023714196};\\\", \\\"{x:680,y:340,t:1527023714212};\\\", \\\"{x:652,y:251,t:1527023714229};\\\", \\\"{x:647,y:157,t:1527023714246};\\\", \\\"{x:677,y:54,t:1527023714262};\\\", \\\"{x:728,y:0,t:1527023714279};\\\", \\\"{x:777,y:0,t:1527023714296};\\\", \\\"{x:808,y:0,t:1527023714313};\\\", \\\"{x:841,y:0,t:1527023714330};\\\", \\\"{x:845,y:0,t:1527023714347};\\\", \\\"{x:852,y:0,t:1527023715443};\\\", \\\"{x:863,y:0,t:1527023715451};\\\", \\\"{x:883,y:0,t:1527023715463};\\\", \\\"{x:960,y:0,t:1527023715481};\\\", \\\"{x:1010,y:0,t:1527023715497};\\\", \\\"{x:1004,y:0,t:1527023715514};\\\", \\\"{x:988,y:0,t:1527023715530};\\\", \\\"{x:987,y:0,t:1527023715844};\\\", \\\"{x:986,y:0,t:1527023715851};\\\", \\\"{x:980,y:3,t:1527023715883};\\\", \\\"{x:980,y:4,t:1527023715907};\\\", \\\"{x:980,y:5,t:1527023715915};\\\", \\\"{x:980,y:6,t:1527023715931};\\\", \\\"{x:980,y:10,t:1527023715947};\\\", \\\"{x:985,y:15,t:1527023715964};\\\", \\\"{x:1003,y:27,t:1527023715980};\\\", \\\"{x:1023,y:37,t:1527023715998};\\\", \\\"{x:1031,y:42,t:1527023716014};\\\", \\\"{x:1036,y:46,t:1527023716030};\\\", \\\"{x:1046,y:55,t:1527023716048};\\\", \\\"{x:1057,y:73,t:1527023716065};\\\", \\\"{x:1085,y:108,t:1527023716081};\\\", \\\"{x:1132,y:177,t:1527023716099};\\\", \\\"{x:1245,y:269,t:1527023716115};\\\", \\\"{x:1298,y:292,t:1527023716130};\\\", \\\"{x:1464,y:320,t:1527023716149};\\\", \\\"{x:1590,y:345,t:1527023716165};\\\", \\\"{x:1686,y:365,t:1527023716180};\\\", \\\"{x:1743,y:388,t:1527023716197};\\\", \\\"{x:1765,y:404,t:1527023716214};\\\", \\\"{x:1769,y:411,t:1527023716230};\\\", \\\"{x:1769,y:418,t:1527023716247};\\\", \\\"{x:1764,y:430,t:1527023716265};\\\", \\\"{x:1758,y:446,t:1527023716280};\\\", \\\"{x:1749,y:465,t:1527023716297};\\\", \\\"{x:1729,y:490,t:1527023716315};\\\", \\\"{x:1715,y:503,t:1527023716330};\\\", \\\"{x:1706,y:518,t:1527023716349};\\\", \\\"{x:1701,y:525,t:1527023716364};\\\", \\\"{x:1699,y:530,t:1527023716381};\\\", \\\"{x:1697,y:532,t:1527023716398};\\\", \\\"{x:1695,y:536,t:1527023716415};\\\", \\\"{x:1686,y:554,t:1527023716432};\\\", \\\"{x:1670,y:594,t:1527023716448};\\\", \\\"{x:1654,y:674,t:1527023716464};\\\", \\\"{x:1649,y:718,t:1527023716481};\\\", \\\"{x:1663,y:741,t:1527023716497};\\\", \\\"{x:1681,y:777,t:1527023716515};\\\", \\\"{x:1687,y:803,t:1527023716531};\\\", \\\"{x:1687,y:825,t:1527023716549};\\\", \\\"{x:1683,y:842,t:1527023716565};\\\", \\\"{x:1674,y:853,t:1527023716582};\\\", \\\"{x:1670,y:858,t:1527023716598};\\\", \\\"{x:1653,y:861,t:1527023716615};\\\", \\\"{x:1643,y:861,t:1527023716632};\\\", \\\"{x:1643,y:859,t:1527023717027};\\\", \\\"{x:1643,y:858,t:1527023717036};\\\", \\\"{x:1642,y:858,t:1527023717049};\\\", \\\"{x:1640,y:856,t:1527023717065};\\\", \\\"{x:1638,y:854,t:1527023717082};\\\", \\\"{x:1635,y:853,t:1527023717099};\\\", \\\"{x:1631,y:849,t:1527023717115};\\\", \\\"{x:1629,y:846,t:1527023717132};\\\", \\\"{x:1625,y:841,t:1527023717150};\\\", \\\"{x:1621,y:836,t:1527023717165};\\\", \\\"{x:1611,y:829,t:1527023717182};\\\", \\\"{x:1598,y:822,t:1527023717199};\\\", \\\"{x:1583,y:814,t:1527023717215};\\\", \\\"{x:1568,y:806,t:1527023717232};\\\", \\\"{x:1559,y:799,t:1527023717249};\\\", \\\"{x:1541,y:791,t:1527023717265};\\\", \\\"{x:1529,y:786,t:1527023717282};\\\", \\\"{x:1514,y:781,t:1527023717298};\\\", \\\"{x:1505,y:778,t:1527023717316};\\\", \\\"{x:1491,y:776,t:1527023717331};\\\", \\\"{x:1470,y:773,t:1527023717349};\\\", \\\"{x:1447,y:772,t:1527023717365};\\\", \\\"{x:1422,y:771,t:1527023717382};\\\", \\\"{x:1411,y:771,t:1527023717398};\\\", \\\"{x:1397,y:771,t:1527023717415};\\\", \\\"{x:1384,y:771,t:1527023717432};\\\", \\\"{x:1380,y:771,t:1527023717449};\\\", \\\"{x:1376,y:771,t:1527023717620};\\\", \\\"{x:1373,y:771,t:1527023717632};\\\", \\\"{x:1361,y:769,t:1527023717649};\\\", \\\"{x:1352,y:767,t:1527023717668};\\\", \\\"{x:1344,y:764,t:1527023717682};\\\", \\\"{x:1333,y:763,t:1527023717699};\\\", \\\"{x:1325,y:762,t:1527023717715};\\\", \\\"{x:1317,y:759,t:1527023717732};\\\", \\\"{x:1313,y:759,t:1527023717748};\\\", \\\"{x:1310,y:759,t:1527023717766};\\\", \\\"{x:1307,y:760,t:1527023717783};\\\", \\\"{x:1306,y:760,t:1527023717798};\\\", \\\"{x:1305,y:760,t:1527023717815};\\\", \\\"{x:1304,y:760,t:1527023717833};\\\", \\\"{x:1306,y:760,t:1527023717939};\\\", \\\"{x:1307,y:760,t:1527023717948};\\\", \\\"{x:1310,y:758,t:1527023717966};\\\", \\\"{x:1313,y:758,t:1527023717983};\\\", \\\"{x:1315,y:758,t:1527023717999};\\\", \\\"{x:1315,y:757,t:1527023718016};\\\", \\\"{x:1316,y:757,t:1527023718067};\\\", \\\"{x:1318,y:756,t:1527023718083};\\\", \\\"{x:1323,y:755,t:1527023718099};\\\", \\\"{x:1327,y:751,t:1527023718116};\\\", \\\"{x:1330,y:751,t:1527023718133};\\\", \\\"{x:1334,y:749,t:1527023718149};\\\", \\\"{x:1336,y:747,t:1527023718165};\\\", \\\"{x:1339,y:745,t:1527023718183};\\\", \\\"{x:1340,y:745,t:1527023718199};\\\", \\\"{x:1340,y:744,t:1527023718216};\\\", \\\"{x:1342,y:742,t:1527023718233};\\\", \\\"{x:1344,y:740,t:1527023718250};\\\", \\\"{x:1347,y:734,t:1527023718265};\\\", \\\"{x:1348,y:727,t:1527023718284};\\\", \\\"{x:1350,y:724,t:1527023718299};\\\", \\\"{x:1351,y:719,t:1527023718316};\\\", \\\"{x:1351,y:718,t:1527023718333};\\\", \\\"{x:1351,y:716,t:1527023718350};\\\", \\\"{x:1352,y:713,t:1527023718366};\\\", \\\"{x:1352,y:710,t:1527023718383};\\\", \\\"{x:1353,y:708,t:1527023718400};\\\", \\\"{x:1354,y:708,t:1527023718628};\\\", \\\"{x:1354,y:711,t:1527023718635};\\\", \\\"{x:1355,y:717,t:1527023718650};\\\", \\\"{x:1364,y:740,t:1527023718667};\\\", \\\"{x:1372,y:761,t:1527023718683};\\\", \\\"{x:1380,y:780,t:1527023718700};\\\", \\\"{x:1388,y:802,t:1527023718717};\\\", \\\"{x:1397,y:822,t:1527023718733};\\\", \\\"{x:1402,y:838,t:1527023718750};\\\", \\\"{x:1404,y:848,t:1527023718767};\\\", \\\"{x:1404,y:863,t:1527023718783};\\\", \\\"{x:1404,y:882,t:1527023718800};\\\", \\\"{x:1399,y:907,t:1527023718817};\\\", \\\"{x:1391,y:928,t:1527023718833};\\\", \\\"{x:1388,y:940,t:1527023718850};\\\", \\\"{x:1386,y:947,t:1527023718867};\\\", \\\"{x:1385,y:949,t:1527023718891};\\\", \\\"{x:1385,y:950,t:1527023718947};\\\", \\\"{x:1385,y:951,t:1527023718979};\\\", \\\"{x:1382,y:954,t:1527023718988};\\\", \\\"{x:1380,y:954,t:1527023719000};\\\", \\\"{x:1375,y:956,t:1527023719017};\\\", \\\"{x:1372,y:959,t:1527023719033};\\\", \\\"{x:1369,y:959,t:1527023719050};\\\", \\\"{x:1360,y:963,t:1527023719067};\\\", \\\"{x:1355,y:967,t:1527023719083};\\\", \\\"{x:1349,y:967,t:1527023719101};\\\", \\\"{x:1344,y:968,t:1527023719117};\\\", \\\"{x:1341,y:970,t:1527023719133};\\\", \\\"{x:1338,y:970,t:1527023719150};\\\", \\\"{x:1335,y:971,t:1527023719167};\\\", \\\"{x:1334,y:972,t:1527023719219};\\\", \\\"{x:1332,y:972,t:1527023719235};\\\", \\\"{x:1331,y:973,t:1527023719249};\\\", \\\"{x:1323,y:974,t:1527023719266};\\\", \\\"{x:1316,y:975,t:1527023719284};\\\", \\\"{x:1313,y:975,t:1527023719300};\\\", \\\"{x:1311,y:975,t:1527023719317};\\\", \\\"{x:1308,y:975,t:1527023719334};\\\", \\\"{x:1307,y:976,t:1527023719350};\\\", \\\"{x:1305,y:978,t:1527023719367};\\\", \\\"{x:1304,y:978,t:1527023719384};\\\", \\\"{x:1303,y:977,t:1527023719515};\\\", \\\"{x:1302,y:977,t:1527023719523};\\\", \\\"{x:1302,y:976,t:1527023719534};\\\", \\\"{x:1306,y:973,t:1527023719551};\\\", \\\"{x:1310,y:970,t:1527023719567};\\\", \\\"{x:1313,y:970,t:1527023719584};\\\", \\\"{x:1327,y:970,t:1527023719601};\\\", \\\"{x:1348,y:970,t:1527023719617};\\\", \\\"{x:1368,y:970,t:1527023719634};\\\", \\\"{x:1404,y:970,t:1527023719652};\\\", \\\"{x:1419,y:970,t:1527023719667};\\\", \\\"{x:1427,y:970,t:1527023719684};\\\", \\\"{x:1431,y:970,t:1527023719701};\\\", \\\"{x:1432,y:970,t:1527023719717};\\\", \\\"{x:1434,y:970,t:1527023719734};\\\", \\\"{x:1436,y:970,t:1527023719751};\\\", \\\"{x:1437,y:970,t:1527023719766};\\\", \\\"{x:1442,y:970,t:1527023719784};\\\", \\\"{x:1448,y:969,t:1527023719801};\\\", \\\"{x:1454,y:967,t:1527023719817};\\\", \\\"{x:1462,y:967,t:1527023719834};\\\", \\\"{x:1471,y:966,t:1527023719851};\\\", \\\"{x:1475,y:965,t:1527023719867};\\\", \\\"{x:1478,y:965,t:1527023719884};\\\", \\\"{x:1484,y:963,t:1527023719901};\\\", \\\"{x:1486,y:963,t:1527023719916};\\\", \\\"{x:1488,y:963,t:1527023719933};\\\", \\\"{x:1489,y:963,t:1527023720002};\\\", \\\"{x:1490,y:963,t:1527023720171};\\\", \\\"{x:1491,y:963,t:1527023720184};\\\", \\\"{x:1492,y:966,t:1527023720201};\\\", \\\"{x:1492,y:971,t:1527023720219};\\\", \\\"{x:1491,y:974,t:1527023720234};\\\", \\\"{x:1489,y:979,t:1527023720251};\\\", \\\"{x:1488,y:980,t:1527023720268};\\\", \\\"{x:1487,y:981,t:1527023720284};\\\", \\\"{x:1486,y:981,t:1527023720324};\\\", \\\"{x:1485,y:981,t:1527023720334};\\\", \\\"{x:1481,y:984,t:1527023720351};\\\", \\\"{x:1477,y:984,t:1527023720368};\\\", \\\"{x:1475,y:984,t:1527023720384};\\\", \\\"{x:1473,y:984,t:1527023720401};\\\", \\\"{x:1471,y:984,t:1527023720419};\\\", \\\"{x:1470,y:983,t:1527023720459};\\\", \\\"{x:1470,y:982,t:1527023720475};\\\", \\\"{x:1470,y:981,t:1527023720499};\\\", \\\"{x:1470,y:980,t:1527023720515};\\\", \\\"{x:1470,y:979,t:1527023720523};\\\", \\\"{x:1470,y:978,t:1527023720571};\\\", \\\"{x:1470,y:977,t:1527023720586};\\\", \\\"{x:1472,y:976,t:1527023720602};\\\", \\\"{x:1472,y:975,t:1527023720617};\\\", \\\"{x:1472,y:974,t:1527023720634};\\\", \\\"{x:1474,y:972,t:1527023720650};\\\", \\\"{x:1476,y:970,t:1527023720667};\\\", \\\"{x:1477,y:970,t:1527023720714};\\\", \\\"{x:1478,y:969,t:1527023720722};\\\", \\\"{x:1479,y:969,t:1527023720739};\\\", \\\"{x:1479,y:968,t:1527023720751};\\\", \\\"{x:1480,y:967,t:1527023720767};\\\", \\\"{x:1482,y:967,t:1527023720785};\\\", \\\"{x:1483,y:965,t:1527023720801};\\\", \\\"{x:1484,y:965,t:1527023720818};\\\", \\\"{x:1485,y:964,t:1527023720835};\\\", \\\"{x:1485,y:965,t:1527023721316};\\\", \\\"{x:1485,y:966,t:1527023721372};\\\", \\\"{x:1484,y:966,t:1527023721787};\\\", \\\"{x:1483,y:965,t:1527023721827};\\\", \\\"{x:1482,y:965,t:1527023721860};\\\", \\\"{x:1481,y:965,t:1527023721892};\\\", \\\"{x:1480,y:965,t:1527023721903};\\\", \\\"{x:1479,y:964,t:1527023721919};\\\", \\\"{x:1479,y:963,t:1527023721947};\\\", \\\"{x:1478,y:963,t:1527023721963};\\\", \\\"{x:1477,y:963,t:1527023721980};\\\", \\\"{x:1475,y:963,t:1527023722020};\\\", \\\"{x:1475,y:962,t:1527023722131};\\\", \\\"{x:1475,y:961,t:1527023722596};\\\", \\\"{x:1476,y:960,t:1527023722619};\\\", \\\"{x:1478,y:958,t:1527023722637};\\\", \\\"{x:1481,y:956,t:1527023722654};\\\", \\\"{x:1483,y:955,t:1527023722671};\\\", \\\"{x:1485,y:955,t:1527023722988};\\\", \\\"{x:1485,y:956,t:1527023723107};\\\", \\\"{x:1485,y:957,t:1527023723140};\\\", \\\"{x:1485,y:958,t:1527023723188};\\\", \\\"{x:1485,y:959,t:1527023723203};\\\", \\\"{x:1485,y:960,t:1527023723220};\\\", \\\"{x:1483,y:961,t:1527023723237};\\\", \\\"{x:1483,y:962,t:1527023723267};\\\", \\\"{x:1482,y:962,t:1527023723275};\\\", \\\"{x:1482,y:963,t:1527023723288};\\\", \\\"{x:1482,y:964,t:1527023727284};\\\", \\\"{x:1482,y:965,t:1527023727291};\\\", \\\"{x:1481,y:965,t:1527023728187};\\\", \\\"{x:1481,y:964,t:1527023732875};\\\", \\\"{x:1480,y:964,t:1527023732923};\\\", \\\"{x:1479,y:964,t:1527023735484};\\\", \\\"{x:1466,y:959,t:1527023735497};\\\", \\\"{x:1388,y:934,t:1527023735514};\\\", \\\"{x:1281,y:893,t:1527023735530};\\\", \\\"{x:1102,y:804,t:1527023735547};\\\", \\\"{x:974,y:732,t:1527023735563};\\\", \\\"{x:863,y:657,t:1527023735580};\\\", \\\"{x:778,y:591,t:1527023735598};\\\", \\\"{x:718,y:540,t:1527023735614};\\\", \\\"{x:688,y:510,t:1527023735630};\\\", \\\"{x:672,y:495,t:1527023735647};\\\", \\\"{x:665,y:484,t:1527023735663};\\\", \\\"{x:663,y:476,t:1527023735680};\\\", \\\"{x:658,y:468,t:1527023735697};\\\", \\\"{x:650,y:458,t:1527023735713};\\\", \\\"{x:622,y:439,t:1527023735729};\\\", \\\"{x:609,y:435,t:1527023735748};\\\", \\\"{x:605,y:434,t:1527023735763};\\\", \\\"{x:603,y:440,t:1527023735818};\\\", \\\"{x:602,y:451,t:1527023735830};\\\", \\\"{x:587,y:488,t:1527023735848};\\\", \\\"{x:574,y:541,t:1527023735864};\\\", \\\"{x:566,y:579,t:1527023735881};\\\", \\\"{x:561,y:592,t:1527023735896};\\\", \\\"{x:559,y:594,t:1527023735914};\\\", \\\"{x:559,y:595,t:1527023735930};\\\", \\\"{x:557,y:596,t:1527023735962};\\\", \\\"{x:551,y:600,t:1527023735980};\\\", \\\"{x:535,y:611,t:1527023735998};\\\", \\\"{x:513,y:620,t:1527023736013};\\\", \\\"{x:495,y:629,t:1527023736031};\\\", \\\"{x:477,y:637,t:1527023736047};\\\", \\\"{x:475,y:638,t:1527023736064};\\\", \\\"{x:473,y:638,t:1527023736097};\\\", \\\"{x:468,y:638,t:1527023736114};\\\", \\\"{x:455,y:630,t:1527023736130};\\\", \\\"{x:437,y:621,t:1527023736147};\\\", \\\"{x:429,y:614,t:1527023736165};\\\", \\\"{x:425,y:607,t:1527023736180};\\\", \\\"{x:422,y:600,t:1527023736197};\\\", \\\"{x:422,y:599,t:1527023736214};\\\", \\\"{x:420,y:596,t:1527023736230};\\\", \\\"{x:419,y:593,t:1527023736247};\\\", \\\"{x:418,y:592,t:1527023736266};\\\", \\\"{x:416,y:592,t:1527023736291};\\\", \\\"{x:411,y:591,t:1527023736330};\\\", \\\"{x:406,y:591,t:1527023736348};\\\", \\\"{x:400,y:591,t:1527023736364};\\\", \\\"{x:386,y:592,t:1527023736381};\\\", \\\"{x:371,y:596,t:1527023736398};\\\", \\\"{x:349,y:599,t:1527023736414};\\\", \\\"{x:318,y:600,t:1527023736431};\\\", \\\"{x:295,y:600,t:1527023736447};\\\", \\\"{x:287,y:600,t:1527023736464};\\\", \\\"{x:280,y:600,t:1527023736480};\\\", \\\"{x:278,y:600,t:1527023736497};\\\", \\\"{x:276,y:600,t:1527023736515};\\\", \\\"{x:280,y:600,t:1527023736635};\\\", \\\"{x:282,y:600,t:1527023736647};\\\", \\\"{x:299,y:598,t:1527023736664};\\\", \\\"{x:326,y:598,t:1527023736681};\\\", \\\"{x:365,y:598,t:1527023736697};\\\", \\\"{x:447,y:602,t:1527023736714};\\\", \\\"{x:558,y:614,t:1527023736731};\\\", \\\"{x:673,y:626,t:1527023736748};\\\", \\\"{x:783,y:634,t:1527023736765};\\\", \\\"{x:850,y:634,t:1527023736781};\\\", \\\"{x:856,y:634,t:1527023736798};\\\", \\\"{x:864,y:633,t:1527023736814};\\\", \\\"{x:866,y:633,t:1527023736832};\\\", \\\"{x:867,y:633,t:1527023736875};\\\", \\\"{x:870,y:630,t:1527023736948};\\\", \\\"{x:851,y:624,t:1527023736964};\\\", \\\"{x:779,y:615,t:1527023736982};\\\", \\\"{x:725,y:611,t:1527023736998};\\\", \\\"{x:712,y:609,t:1527023737015};\\\", \\\"{x:708,y:607,t:1527023737031};\\\", \\\"{x:707,y:607,t:1527023737048};\\\", \\\"{x:705,y:607,t:1527023737178};\\\", \\\"{x:701,y:607,t:1527023737186};\\\", \\\"{x:700,y:607,t:1527023737198};\\\", \\\"{x:685,y:607,t:1527023737215};\\\", \\\"{x:668,y:607,t:1527023737232};\\\", \\\"{x:658,y:607,t:1527023737248};\\\", \\\"{x:657,y:608,t:1527023737266};\\\", \\\"{x:651,y:608,t:1527023737281};\\\", \\\"{x:649,y:608,t:1527023737298};\\\", \\\"{x:648,y:608,t:1527023737315};\\\", \\\"{x:646,y:608,t:1527023737332};\\\", \\\"{x:644,y:608,t:1527023737348};\\\", \\\"{x:643,y:608,t:1527023737379};\\\", \\\"{x:640,y:608,t:1527023737403};\\\", \\\"{x:636,y:609,t:1527023737415};\\\", \\\"{x:633,y:609,t:1527023737432};\\\", \\\"{x:632,y:609,t:1527023737449};\\\", \\\"{x:629,y:609,t:1527023737467};\\\", \\\"{x:628,y:609,t:1527023737482};\\\", \\\"{x:625,y:609,t:1527023737498};\\\", \\\"{x:620,y:607,t:1527023737516};\\\", \\\"{x:617,y:605,t:1527023737531};\\\", \\\"{x:614,y:604,t:1527023737548};\\\", \\\"{x:613,y:604,t:1527023737578};\\\", \\\"{x:612,y:604,t:1527023737650};\\\", \\\"{x:611,y:603,t:1527023737666};\\\", \\\"{x:610,y:601,t:1527023737723};\\\", \\\"{x:609,y:600,t:1527023737946};\\\", \\\"{x:609,y:599,t:1527023737953};\\\", \\\"{x:609,y:598,t:1527023737965};\\\", \\\"{x:608,y:598,t:1527023738291};\\\", \\\"{x:604,y:598,t:1527023738298};\\\", \\\"{x:590,y:597,t:1527023738316};\\\", \\\"{x:572,y:593,t:1527023738333};\\\", \\\"{x:548,y:591,t:1527023738349};\\\", \\\"{x:524,y:587,t:1527023738366};\\\", \\\"{x:507,y:583,t:1527023738382};\\\", \\\"{x:498,y:581,t:1527023738401};\\\", \\\"{x:489,y:580,t:1527023738415};\\\", \\\"{x:485,y:579,t:1527023738432};\\\", \\\"{x:482,y:579,t:1527023738449};\\\", \\\"{x:478,y:578,t:1527023738465};\\\", \\\"{x:473,y:578,t:1527023738482};\\\", \\\"{x:470,y:579,t:1527023738499};\\\", \\\"{x:466,y:582,t:1527023738516};\\\", \\\"{x:460,y:583,t:1527023738533};\\\", \\\"{x:449,y:588,t:1527023738549};\\\", \\\"{x:434,y:592,t:1527023738566};\\\", \\\"{x:419,y:598,t:1527023738582};\\\", \\\"{x:406,y:602,t:1527023738600};\\\", \\\"{x:402,y:602,t:1527023738617};\\\", \\\"{x:399,y:603,t:1527023738632};\\\", \\\"{x:399,y:604,t:1527023738650};\\\", \\\"{x:397,y:604,t:1527023738666};\\\", \\\"{x:396,y:604,t:1527023738683};\\\", \\\"{x:395,y:604,t:1527023738699};\\\", \\\"{x:394,y:605,t:1527023738717};\\\", \\\"{x:392,y:606,t:1527023738746};\\\", \\\"{x:390,y:606,t:1527023738787};\\\", \\\"{x:389,y:606,t:1527023738835};\\\", \\\"{x:388,y:606,t:1527023738891};\\\", \\\"{x:387,y:606,t:1527023738955};\\\", \\\"{x:386,y:606,t:1527023739547};\\\", \\\"{x:386,y:605,t:1527023739554};\\\", \\\"{x:385,y:605,t:1527023739570};\\\", \\\"{x:385,y:604,t:1527023739587};\\\", \\\"{x:385,y:603,t:1527023739602};\\\", \\\"{x:384,y:602,t:1527023739618};\\\", \\\"{x:384,y:606,t:1527023745880};\\\", \\\"{x:387,y:612,t:1527023745903};\\\", \\\"{x:396,y:628,t:1527023745918};\\\", \\\"{x:401,y:635,t:1527023745934};\\\", \\\"{x:406,y:643,t:1527023745952};\\\", \\\"{x:409,y:649,t:1527023745968};\\\", \\\"{x:410,y:652,t:1527023745985};\\\", \\\"{x:410,y:655,t:1527023746003};\\\", \\\"{x:411,y:658,t:1527023746019};\\\", \\\"{x:411,y:659,t:1527023746035};\\\", \\\"{x:411,y:660,t:1527023746052};\\\", \\\"{x:411,y:662,t:1527023746111};\\\", \\\"{x:411,y:665,t:1527023746118};\\\", \\\"{x:411,y:676,t:1527023746135};\\\", \\\"{x:411,y:691,t:1527023746153};\\\", \\\"{x:411,y:704,t:1527023746170};\\\", \\\"{x:413,y:715,t:1527023746185};\\\", \\\"{x:415,y:721,t:1527023746203};\\\", \\\"{x:421,y:729,t:1527023746220};\\\", \\\"{x:434,y:739,t:1527023746236};\\\", \\\"{x:435,y:741,t:1527023746253};\\\", \\\"{x:443,y:747,t:1527023746270};\\\", \\\"{x:463,y:752,t:1527023746287};\\\", \\\"{x:471,y:755,t:1527023746302};\\\", \\\"{x:473,y:757,t:1527023746319};\\\", \\\"{x:475,y:757,t:1527023746927};\\\", \\\"{x:482,y:757,t:1527023746937};\\\", \\\"{x:497,y:753,t:1527023746954};\\\", \\\"{x:523,y:748,t:1527023746969};\\\", \\\"{x:553,y:746,t:1527023746986};\\\", \\\"{x:584,y:742,t:1527023747004};\\\", \\\"{x:618,y:739,t:1527023747019};\\\", \\\"{x:659,y:738,t:1527023747036};\\\", \\\"{x:715,y:738,t:1527023747054};\\\", \\\"{x:753,y:738,t:1527023747069};\\\", \\\"{x:768,y:739,t:1527023747086};\\\", \\\"{x:772,y:741,t:1527023747104};\\\", \\\"{x:775,y:741,t:1527023747319};\\\", \\\"{x:780,y:739,t:1527023747337};\\\" ] }, { \\\"rt\\\": 144307, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 986945, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"From each shift (dot), you look at the triangle that forms under it. The first left line of the triangle tells you the shift start time and the right line of the triangle stemming from the dot tells you the shift end time. So to determine which shifts start at 12pm, you look at the diagonal lines that slant towards the right from the 12 pm tick mark on the graph, indicating the start time. You can follow the right-slanting diagonal line all the way through to see that shifts M and L start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7774, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 995727, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 22250, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1018991, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 34151, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1054461, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"T5SHZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"T5SHZ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 278, dom: 785, initialDom: 894",
  "javascriptErrors": []
}