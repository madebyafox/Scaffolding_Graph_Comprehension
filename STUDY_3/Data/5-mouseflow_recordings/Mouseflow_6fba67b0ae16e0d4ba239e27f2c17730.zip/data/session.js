var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6fba67b0ae16e0d4ba239e27f2c17730",
  "created": "2018-05-21T12:12:51.0296314-07:00",
  "lastActivity": "2018-05-21T12:13:49.2706314-07:00",
  "pageViews": [
    {
      "id": "0521516252a0b370f70283c843f27e5103907cd6",
      "startTime": "2018-05-21T12:12:51.0296314-07:00",
      "endTime": "2018-05-21T12:13:49.2706314-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 58241,
      "engagementTime": 54268,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 58241,
  "engagementTime": 54268,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J1JP6",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "97928338734dba4a566cf0769c9b0c33",
  "gdpr": false
}