var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "78dd7f3a2afa3f6c61abb975a3b2c02e",
  "created": "2018-05-22T16:08:28.4752765-07:00",
  "lastActivity": "2018-05-22T16:09:35.5112765-07:00",
  "pageViews": [
    {
      "id": "052228145757ad0617ba407be11e400e5925a5f0",
      "startTime": "2018-05-22T16:08:28.4752765-07:00",
      "endTime": "2018-05-22T16:09:35.5112765-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 67036,
      "engagementTime": 54838,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 67036,
  "engagementTime": 54838,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2LZ7W",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8949018bc5c31bed1e96b0d6fb07630f",
  "gdpr": false
}