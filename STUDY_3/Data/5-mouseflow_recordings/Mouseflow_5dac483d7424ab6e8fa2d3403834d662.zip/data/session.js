var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5dac483d7424ab6e8fa2d3403834d662",
  "created": "2018-05-24T12:12:50.3249879-07:00",
  "lastActivity": "2018-05-24T12:13:53.7739025-07:00",
  "pageViews": [
    {
      "id": "05245083c8241d8bd81e466705952404bb0508a3",
      "startTime": "2018-05-24T12:12:50.4477932-07:00",
      "endTime": "2018-05-24T12:13:53.7739025-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 63559,
      "engagementTime": 62977,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 63559,
  "engagementTime": 62977,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=XKNWZ",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "55edf0fca82ae9d278789e6cf999a2d5",
  "gdpr": false
}