var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05245083c8241d8bd81e466705952404bb0508a3"] = {
  "startTime": "2018-05-24T19:12:50.4477932Z",
  "websitePageUrl": "/16",
  "visitTime": 63559,
  "engagementTime": 62977,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5dac483d7424ab6e8fa2d3403834d662",
    "created": "2018-05-24T19:12:50.3249879+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=XKNWZ",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "55edf0fca82ae9d278789e6cf999a2d5",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5dac483d7424ab6e8fa2d3403834d662/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 208,
      "e": 208,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 464,
      "y": 736
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 41243,
      "y": 40329,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 463,
      "y": 734
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 41131,
      "y": 40218,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 463,
      "y": 681
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 41131,
      "y": 37282,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 463,
      "y": 616
    },
    {
      "t": 2621,
      "e": 2621,
      "ty": 6,
      "x": 463,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 458,
      "y": 580
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 40569,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 457,
      "y": 567
    },
    {
      "t": 2835,
      "e": 2835,
      "ty": 3,
      "x": 457,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2836,
      "e": 2836,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2931,
      "e": 2931,
      "ty": 4,
      "x": 40457,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2931,
      "e": 2931,
      "ty": 5,
      "x": 457,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 40457,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 670,
      "y": 571
    },
    {
      "t": 3605,
      "e": 3605,
      "ty": 7,
      "x": 724,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1078,
      "y": 555
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 24664,
      "y": 30153,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1177,
      "y": 562
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 27553,
      "y": 30368,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 27624,
      "y": 30368,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1178,
      "y": 562
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1198,
      "y": 673
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1234,
      "y": 766
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 33261,
      "y": 48775,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1265,
      "y": 831
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 33755,
      "y": 49634,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8247,
      "e": 8247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8384,
      "e": 8384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 8384,
      "e": 8384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8470,
      "e": 8470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 8478,
      "e": 8478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 8599,
      "e": 8599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8678,
      "e": 8678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 8734,
      "e": 8734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8735,
      "e": 8735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8798,
      "e": 8798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 8903,
      "e": 8903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8904,
      "e": 8904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9031,
      "e": 9031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 9047,
      "e": 9047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9047,
      "e": 9047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9182,
      "e": 9182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9230,
      "e": 9230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9230,
      "e": 9230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9403,
      "e": 9403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look o"
    },
    {
      "t": 9415,
      "e": 9415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 9438,
      "e": 9438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9439,
      "e": 9439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9566,
      "e": 9566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 9598,
      "e": 9598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9599,
      "e": 9599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9670,
      "e": 9670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9935,
      "e": 9935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9936,
      "e": 9936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10086,
      "e": 10086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10151,
      "e": 10151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10151,
      "e": 10151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10263,
      "e": 10263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10264,
      "e": 10264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 10375,
      "e": 10375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10375,
      "e": 10375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10430,
      "e": 10430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10486,
      "e": 10486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12943,
      "e": 12943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12944,
      "e": 12944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13055,
      "e": 13055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13055,
      "e": 13055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13158,
      "e": 13158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 13174,
      "e": 13174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13174,
      "e": 13174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13190,
      "e": 13190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 13271,
      "e": 13271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13278,
      "e": 13278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13280,
      "e": 13280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13403,
      "e": 13403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the hori"
    },
    {
      "t": 13422,
      "e": 13422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13479,
      "e": 13479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 13480,
      "e": 13480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13603,
      "e": 13603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the horiz"
    },
    {
      "t": 13606,
      "e": 13606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13718,
      "e": 13718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13719,
      "e": 13719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13766,
      "e": 13766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 13911,
      "e": 13911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13912,
      "e": 13912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13913,
      "e": 13913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13990,
      "e": 13990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13990,
      "e": 13990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14038,
      "e": 14038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 14078,
      "e": 14078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 14079,
      "e": 14079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14103,
      "e": 14103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 14174,
      "e": 14174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14176,
      "e": 14176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14198,
      "e": 14198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14254,
      "e": 14254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14503,
      "e": 14503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14503,
      "e": 14503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14604,
      "e": 14604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the horizontal a"
    },
    {
      "t": 14631,
      "e": 14631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15215,
      "e": 15215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15215,
      "e": 15215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15310,
      "e": 15310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15311,
      "e": 15311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15358,
      "e": 15358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 15431,
      "e": 15431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15431,
      "e": 15431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15438,
      "e": 15438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15511,
      "e": 15511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15543,
      "e": 15543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15544,
      "e": 15544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15598,
      "e": 15598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15599,
      "e": 15599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15646,
      "e": 15646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 15686,
      "e": 15686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15743,
      "e": 15743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15743,
      "e": 15743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15791,
      "e": 15791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15791,
      "e": 15791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15839,
      "e": 15839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 15911,
      "e": 15911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15943,
      "e": 15943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15944,
      "e": 15944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16007,
      "e": 16007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16679,
      "e": 16679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16679,
      "e": 16679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16790,
      "e": 16790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16790,
      "e": 16790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16798,
      "e": 16798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 16910,
      "e": 16910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16942,
      "e": 16942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16944,
      "e": 16944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17070,
      "e": 17070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17375,
      "e": 17375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 17376,
      "e": 17376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17462,
      "e": 17462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 17574,
      "e": 17574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17575,
      "e": 17575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17614,
      "e": 17614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17614,
      "e": 17614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17670,
      "e": 17670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 17686,
      "e": 17686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17758,
      "e": 17758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17759,
      "e": 17759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17839,
      "e": 17839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17854,
      "e": 17854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17854,
      "e": 17854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17967,
      "e": 17967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17975,
      "e": 17975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 17975,
      "e": 17975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18142,
      "e": 18142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 18150,
      "e": 18150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18151,
      "e": 18151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18279,
      "e": 18279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18495,
      "e": 18495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18574,
      "e": 18574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the horizontal axis and go vertic"
    },
    {
      "t": 18574,
      "e": 18574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18575,
      "e": 18575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18662,
      "e": 18662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19110,
      "e": 19110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19110,
      "e": 19110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19238,
      "e": 19238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 19294,
      "e": 19294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19294,
      "e": 19294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19402,
      "e": 19402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the horizontal axis and go vertical "
    },
    {
      "t": 19423,
      "e": 19423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20003,
      "e": 20003,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21202,
      "e": 21202,
      "ty": 2,
      "x": 1122,
      "y": 920
    },
    {
      "t": 21252,
      "e": 21252,
      "ty": 41,
      "x": 11557,
      "y": 64890,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 21300,
      "e": 21300,
      "ty": 2,
      "x": 944,
      "y": 1051
    },
    {
      "t": 21402,
      "e": 21402,
      "ty": 2,
      "x": 1135,
      "y": 1036
    },
    {
      "t": 21500,
      "e": 21500,
      "ty": 2,
      "x": 1111,
      "y": 545
    },
    {
      "t": 21501,
      "e": 21501,
      "ty": 41,
      "x": 22903,
      "y": 29150,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 21602,
      "e": 21602,
      "ty": 2,
      "x": 0,
      "y": 176
    },
    {
      "t": 21701,
      "e": 21701,
      "ty": 2,
      "x": 7,
      "y": 260
    },
    {
      "t": 21751,
      "e": 21751,
      "ty": 41,
      "x": 1549,
      "y": 22768,
      "ta": "> div.stimulus"
    },
    {
      "t": 21801,
      "e": 21801,
      "ty": 2,
      "x": 59,
      "y": 572
    },
    {
      "t": 21901,
      "e": 21901,
      "ty": 2,
      "x": 289,
      "y": 737
    },
    {
      "t": 22001,
      "e": 22001,
      "ty": 2,
      "x": 491,
      "y": 768
    },
    {
      "t": 22001,
      "e": 22001,
      "ty": 41,
      "x": 44278,
      "y": 42101,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 22101,
      "e": 22101,
      "ty": 2,
      "x": 488,
      "y": 695
    },
    {
      "t": 22119,
      "e": 22119,
      "ty": 6,
      "x": 457,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 22136,
      "e": 22136,
      "ty": 7,
      "x": 449,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 22200,
      "e": 22200,
      "ty": 2,
      "x": 439,
      "y": 647
    },
    {
      "t": 22251,
      "e": 22251,
      "ty": 41,
      "x": 54490,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 22270,
      "e": 22270,
      "ty": 6,
      "x": 429,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 22301,
      "e": 22301,
      "ty": 2,
      "x": 427,
      "y": 661
    },
    {
      "t": 22401,
      "e": 22401,
      "ty": 2,
      "x": 422,
      "y": 681
    },
    {
      "t": 22500,
      "e": 22500,
      "ty": 2,
      "x": 422,
      "y": 680
    },
    {
      "t": 22501,
      "e": 22501,
      "ty": 41,
      "x": 45550,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 22601,
      "e": 22601,
      "ty": 2,
      "x": 423,
      "y": 675
    },
    {
      "t": 22627,
      "e": 22627,
      "ty": 3,
      "x": 423,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 22628,
      "e": 22628,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look on the horizontal axis and go vertical "
    },
    {
      "t": 22630,
      "e": 22630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22630,
      "e": 22630,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 22706,
      "e": 22706,
      "ty": 4,
      "x": 46096,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 22716,
      "e": 22716,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 22717,
      "e": 22717,
      "ty": 5,
      "x": 423,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 22723,
      "e": 22723,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 22751,
      "e": 22751,
      "ty": 41,
      "x": 14291,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 22801,
      "e": 22801,
      "ty": 2,
      "x": 432,
      "y": 671
    },
    {
      "t": 22900,
      "e": 22900,
      "ty": 2,
      "x": 509,
      "y": 674
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 41,
      "x": 17253,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 23101,
      "e": 23101,
      "ty": 2,
      "x": 503,
      "y": 672
    },
    {
      "t": 23201,
      "e": 23201,
      "ty": 2,
      "x": 488,
      "y": 664
    },
    {
      "t": 23251,
      "e": 23251,
      "ty": 41,
      "x": 16530,
      "y": 36340,
      "ta": "html > body"
    },
    {
      "t": 23700,
      "e": 23700,
      "ty": 2,
      "x": 488,
      "y": 656
    },
    {
      "t": 23724,
      "e": 23724,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 23751,
      "e": 23751,
      "ty": 41,
      "x": 16495,
      "y": 35620,
      "ta": "html > body"
    },
    {
      "t": 23801,
      "e": 23801,
      "ty": 2,
      "x": 486,
      "y": 646
    },
    {
      "t": 23901,
      "e": 23901,
      "ty": 2,
      "x": 481,
      "y": 646
    },
    {
      "t": 24000,
      "e": 24000,
      "ty": 2,
      "x": 472,
      "y": 650
    },
    {
      "t": 24001,
      "e": 24001,
      "ty": 41,
      "x": 15979,
      "y": 35565,
      "ta": "html > body"
    },
    {
      "t": 24401,
      "e": 24401,
      "ty": 2,
      "x": 478,
      "y": 650
    },
    {
      "t": 24500,
      "e": 24500,
      "ty": 2,
      "x": 889,
      "y": 623
    },
    {
      "t": 24500,
      "e": 24500,
      "ty": 41,
      "x": 17519,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 24601,
      "e": 24601,
      "ty": 2,
      "x": 999,
      "y": 602
    },
    {
      "t": 24701,
      "e": 24701,
      "ty": 2,
      "x": 1000,
      "y": 584
    },
    {
      "t": 24751,
      "e": 24751,
      "ty": 41,
      "x": 41527,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 24800,
      "e": 24800,
      "ty": 2,
      "x": 1000,
      "y": 579
    },
    {
      "t": 24901,
      "e": 24901,
      "ty": 2,
      "x": 1000,
      "y": 578
    },
    {
      "t": 25001,
      "e": 25001,
      "ty": 41,
      "x": 41527,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 25089,
      "e": 25089,
      "ty": 6,
      "x": 1000,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25101,
      "e": 25101,
      "ty": 2,
      "x": 1000,
      "y": 573
    },
    {
      "t": 25195,
      "e": 25195,
      "ty": 3,
      "x": 1001,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25197,
      "e": 25197,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25201,
      "e": 25201,
      "ty": 2,
      "x": 1001,
      "y": 571
    },
    {
      "t": 25251,
      "e": 25251,
      "ty": 41,
      "x": 41743,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25291,
      "e": 25291,
      "ty": 4,
      "x": 41743,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25291,
      "e": 25291,
      "ty": 5,
      "x": 1001,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26006,
      "e": 26006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 26008,
      "e": 26008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26126,
      "e": 26126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 27535,
      "e": 27535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 27686,
      "e": 27686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 27718,
      "e": 27718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 27719,
      "e": 27719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27863,
      "e": 27863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 27870,
      "e": 27870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 27872,
      "e": 27872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27966,
      "e": 27966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 28691,
      "e": 28691,
      "ty": 7,
      "x": 994,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28701,
      "e": 28701,
      "ty": 2,
      "x": 994,
      "y": 586
    },
    {
      "t": 28752,
      "e": 28752,
      "ty": 41,
      "x": 35687,
      "y": 63194,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 28801,
      "e": 28801,
      "ty": 2,
      "x": 966,
      "y": 642
    },
    {
      "t": 28825,
      "e": 28825,
      "ty": 6,
      "x": 963,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28901,
      "e": 28901,
      "ty": 2,
      "x": 959,
      "y": 660
    },
    {
      "t": 29002,
      "e": 29002,
      "ty": 41,
      "x": 32659,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29011,
      "e": 29011,
      "ty": 3,
      "x": 959,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29012,
      "e": 29012,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 29013,
      "e": 29013,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29014,
      "e": 29014,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29098,
      "e": 29098,
      "ty": 4,
      "x": 32659,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29098,
      "e": 29098,
      "ty": 5,
      "x": 959,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29201,
      "e": 29201,
      "ty": 2,
      "x": 969,
      "y": 659
    },
    {
      "t": 29251,
      "e": 29251,
      "ty": 41,
      "x": 37633,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29301,
      "e": 29301,
      "ty": 2,
      "x": 987,
      "y": 651
    },
    {
      "t": 29502,
      "e": 29502,
      "ty": 41,
      "x": 38715,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29831,
      "e": 29831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 29999,
      "e": 29999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "86"
    },
    {
      "t": 29999,
      "e": 29999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30003,
      "e": 30003,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30030,
      "e": 30030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "V"
    },
    {
      "t": 30150,
      "e": 30150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "V"
    },
    {
      "t": 30238,
      "e": 30238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 30239,
      "e": 30239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30311,
      "e": 30311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 30311,
      "e": 30311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30334,
      "e": 30334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Vie"
    },
    {
      "t": 30398,
      "e": 30398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 30398,
      "e": 30398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30454,
      "e": 30454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Viet"
    },
    {
      "t": 30470,
      "e": 30470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 30470,
      "e": 30470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30486,
      "e": 30486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 30542,
      "e": 30542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 30583,
      "e": 30583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 30584,
      "e": 30584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30662,
      "e": 30662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 30967,
      "e": 30967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 30967,
      "e": 30967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31054,
      "e": 31054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 31677,
      "e": 31677,
      "ty": 7,
      "x": 977,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31694,
      "e": 31694,
      "ty": 6,
      "x": 973,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31702,
      "e": 31702,
      "ty": 2,
      "x": 973,
      "y": 680
    },
    {
      "t": 31751,
      "e": 31751,
      "ty": 41,
      "x": 37663,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31801,
      "e": 31801,
      "ty": 2,
      "x": 969,
      "y": 689
    },
    {
      "t": 31898,
      "e": 31898,
      "ty": 3,
      "x": 969,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31898,
      "e": 31898,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Vietnam"
    },
    {
      "t": 31898,
      "e": 31898,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31899,
      "e": 31899,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31962,
      "e": 31962,
      "ty": 4,
      "x": 37663,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31963,
      "e": 31963,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31963,
      "e": 31963,
      "ty": 5,
      "x": 969,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31963,
      "e": 31963,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 32001,
      "e": 32001,
      "ty": 41,
      "x": 33094,
      "y": 37725,
      "ta": "html > body"
    },
    {
      "t": 32101,
      "e": 32101,
      "ty": 2,
      "x": 980,
      "y": 684
    },
    {
      "t": 32201,
      "e": 32201,
      "ty": 2,
      "x": 1118,
      "y": 598
    },
    {
      "t": 32251,
      "e": 32251,
      "ty": 41,
      "x": 38501,
      "y": 31077,
      "ta": "html > body"
    },
    {
      "t": 32302,
      "e": 32302,
      "ty": 2,
      "x": 1104,
      "y": 542
    },
    {
      "t": 32402,
      "e": 32402,
      "ty": 2,
      "x": 1063,
      "y": 509
    },
    {
      "t": 32501,
      "e": 32501,
      "ty": 2,
      "x": 1041,
      "y": 483
    },
    {
      "t": 32501,
      "e": 32501,
      "ty": 41,
      "x": 35574,
      "y": 26313,
      "ta": "html > body"
    },
    {
      "t": 32601,
      "e": 32601,
      "ty": 2,
      "x": 1014,
      "y": 449
    },
    {
      "t": 32701,
      "e": 32701,
      "ty": 2,
      "x": 962,
      "y": 412
    },
    {
      "t": 32751,
      "e": 32751,
      "ty": 41,
      "x": 31992,
      "y": 21383,
      "ta": "html > body"
    },
    {
      "t": 32801,
      "e": 32801,
      "ty": 2,
      "x": 924,
      "y": 387
    },
    {
      "t": 32901,
      "e": 32901,
      "ty": 2,
      "x": 917,
      "y": 381
    },
    {
      "t": 32974,
      "e": 32974,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 2,
      "x": 912,
      "y": 377
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 41,
      "x": 21496,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 33101,
      "e": 33101,
      "ty": 2,
      "x": 908,
      "y": 373
    },
    {
      "t": 33201,
      "e": 33201,
      "ty": 2,
      "x": 907,
      "y": 371
    },
    {
      "t": 33251,
      "e": 33251,
      "ty": 41,
      "x": 20309,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 33501,
      "e": 33501,
      "ty": 2,
      "x": 899,
      "y": 361
    },
    {
      "t": 33501,
      "e": 33501,
      "ty": 41,
      "x": 18411,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 33601,
      "e": 33601,
      "ty": 2,
      "x": 836,
      "y": 220
    },
    {
      "t": 33701,
      "e": 33701,
      "ty": 2,
      "x": 826,
      "y": 189
    },
    {
      "t": 33752,
      "e": 33752,
      "ty": 41,
      "x": 849,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 33801,
      "e": 33801,
      "ty": 2,
      "x": 825,
      "y": 188
    },
    {
      "t": 33901,
      "e": 33901,
      "ty": 2,
      "x": 825,
      "y": 192
    },
    {
      "t": 33962,
      "e": 33962,
      "ty": 6,
      "x": 832,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 33996,
      "e": 33996,
      "ty": 7,
      "x": 836,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34001,
      "e": 34001,
      "ty": 2,
      "x": 836,
      "y": 247
    },
    {
      "t": 34002,
      "e": 34002,
      "ty": 41,
      "x": 11937,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 34201,
      "e": 34201,
      "ty": 2,
      "x": 831,
      "y": 248
    },
    {
      "t": 34252,
      "e": 34252,
      "ty": 41,
      "x": 2930,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 34301,
      "e": 34301,
      "ty": 2,
      "x": 825,
      "y": 247
    },
    {
      "t": 34397,
      "e": 34397,
      "ty": 6,
      "x": 833,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34401,
      "e": 34401,
      "ty": 2,
      "x": 833,
      "y": 239
    },
    {
      "t": 34502,
      "e": 34502,
      "ty": 2,
      "x": 836,
      "y": 238
    },
    {
      "t": 34502,
      "e": 34502,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34746,
      "e": 34746,
      "ty": 7,
      "x": 836,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34752,
      "e": 34752,
      "ty": 41,
      "x": 11937,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 34801,
      "e": 34801,
      "ty": 2,
      "x": 836,
      "y": 248
    },
    {
      "t": 34880,
      "e": 34880,
      "ty": 6,
      "x": 839,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 34902,
      "e": 34902,
      "ty": 2,
      "x": 839,
      "y": 265
    },
    {
      "t": 34930,
      "e": 34930,
      "ty": 7,
      "x": 839,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 35001,
      "e": 35001,
      "ty": 2,
      "x": 839,
      "y": 287
    },
    {
      "t": 35001,
      "e": 35001,
      "ty": 41,
      "x": 5508,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 35013,
      "e": 35001,
      "ty": 6,
      "x": 839,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 35046,
      "e": 35034,
      "ty": 7,
      "x": 839,
      "y": 308,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 35080,
      "e": 35068,
      "ty": 6,
      "x": 838,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35101,
      "e": 35089,
      "ty": 2,
      "x": 838,
      "y": 318
    },
    {
      "t": 35201,
      "e": 35189,
      "ty": 2,
      "x": 829,
      "y": 323
    },
    {
      "t": 35250,
      "e": 35238,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35291,
      "e": 35279,
      "ty": 7,
      "x": 825,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35301,
      "e": 35289,
      "ty": 2,
      "x": 825,
      "y": 323
    },
    {
      "t": 35371,
      "e": 35359,
      "ty": 3,
      "x": 825,
      "y": 323,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 35457,
      "e": 35445,
      "ty": 4,
      "x": 3552,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 35458,
      "e": 35446,
      "ty": 5,
      "x": 825,
      "y": 323,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 35458,
      "e": 35446,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35459,
      "e": 35447,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 35502,
      "e": 35490,
      "ty": 41,
      "x": 3552,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 35639,
      "e": 35627,
      "ty": 6,
      "x": 827,
      "y": 324,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35701,
      "e": 35689,
      "ty": 2,
      "x": 827,
      "y": 324
    },
    {
      "t": 35751,
      "e": 35739,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35764,
      "e": 35752,
      "ty": 7,
      "x": 839,
      "y": 331,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 35801,
      "e": 35789,
      "ty": 2,
      "x": 846,
      "y": 342
    },
    {
      "t": 35902,
      "e": 35890,
      "ty": 2,
      "x": 864,
      "y": 405
    },
    {
      "t": 36001,
      "e": 35989,
      "ty": 2,
      "x": 863,
      "y": 477
    },
    {
      "t": 36002,
      "e": 35990,
      "ty": 41,
      "x": 43948,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 36101,
      "e": 36089,
      "ty": 2,
      "x": 852,
      "y": 496
    },
    {
      "t": 36251,
      "e": 36239,
      "ty": 41,
      "x": 27445,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 36301,
      "e": 36289,
      "ty": 2,
      "x": 851,
      "y": 485
    },
    {
      "t": 36402,
      "e": 36390,
      "ty": 2,
      "x": 854,
      "y": 462
    },
    {
      "t": 36502,
      "e": 36490,
      "ty": 41,
      "x": 34435,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 37401,
      "e": 37389,
      "ty": 2,
      "x": 854,
      "y": 459
    },
    {
      "t": 37502,
      "e": 37490,
      "ty": 41,
      "x": 7731,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 38701,
      "e": 38689,
      "ty": 2,
      "x": 848,
      "y": 405
    },
    {
      "t": 38751,
      "e": 38739,
      "ty": 41,
      "x": 6307,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 38801,
      "e": 38789,
      "ty": 2,
      "x": 848,
      "y": 401
    },
    {
      "t": 39001,
      "e": 38989,
      "ty": 2,
      "x": 849,
      "y": 389
    },
    {
      "t": 39002,
      "e": 38990,
      "ty": 41,
      "x": 6544,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 39101,
      "e": 39089,
      "ty": 2,
      "x": 851,
      "y": 382
    },
    {
      "t": 39201,
      "e": 39189,
      "ty": 2,
      "x": 851,
      "y": 434
    },
    {
      "t": 39251,
      "e": 39239,
      "ty": 41,
      "x": 6307,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 39301,
      "e": 39289,
      "ty": 2,
      "x": 846,
      "y": 464
    },
    {
      "t": 39402,
      "e": 39390,
      "ty": 2,
      "x": 845,
      "y": 467
    },
    {
      "t": 39501,
      "e": 39489,
      "ty": 2,
      "x": 838,
      "y": 460
    },
    {
      "t": 39502,
      "e": 39490,
      "ty": 41,
      "x": 3934,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 39701,
      "e": 39689,
      "ty": 2,
      "x": 838,
      "y": 459
    },
    {
      "t": 39750,
      "e": 39738,
      "ty": 41,
      "x": 3934,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 39802,
      "e": 39790,
      "ty": 2,
      "x": 838,
      "y": 454
    },
    {
      "t": 39835,
      "e": 39823,
      "ty": 6,
      "x": 837,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 39901,
      "e": 39889,
      "ty": 2,
      "x": 836,
      "y": 445
    },
    {
      "t": 40003,
      "e": 39991,
      "ty": 2,
      "x": 835,
      "y": 444
    },
    {
      "t": 40003,
      "e": 39991,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40051,
      "e": 40039,
      "ty": 7,
      "x": 831,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 40102,
      "e": 40090,
      "ty": 2,
      "x": 830,
      "y": 450
    },
    {
      "t": 40251,
      "e": 40239,
      "ty": 41,
      "x": 1561,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 40303,
      "e": 40291,
      "ty": 2,
      "x": 827,
      "y": 461
    },
    {
      "t": 40372,
      "e": 40292,
      "ty": 6,
      "x": 827,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40401,
      "e": 40321,
      "ty": 2,
      "x": 827,
      "y": 464
    },
    {
      "t": 40502,
      "e": 40422,
      "ty": 41,
      "x": 2914,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40764,
      "e": 40684,
      "ty": 3,
      "x": 827,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40765,
      "e": 40685,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40765,
      "e": 40685,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40858,
      "e": 40778,
      "ty": 4,
      "x": 2914,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40858,
      "e": 40778,
      "ty": 5,
      "x": 827,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 40858,
      "e": 40778,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 41502,
      "e": 41422,
      "ty": 2,
      "x": 827,
      "y": 468
    },
    {
      "t": 41502,
      "e": 41422,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 41601,
      "e": 41521,
      "ty": 2,
      "x": 828,
      "y": 476
    },
    {
      "t": 41611,
      "e": 41531,
      "ty": 7,
      "x": 828,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 41702,
      "e": 41622,
      "ty": 2,
      "x": 828,
      "y": 482
    },
    {
      "t": 41751,
      "e": 41671,
      "ty": 41,
      "x": 1798,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 41770,
      "e": 41690,
      "ty": 6,
      "x": 829,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 41802,
      "e": 41722,
      "ty": 2,
      "x": 829,
      "y": 497
    },
    {
      "t": 41819,
      "e": 41739,
      "ty": 7,
      "x": 829,
      "y": 511,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 41852,
      "e": 41772,
      "ty": 6,
      "x": 830,
      "y": 523,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 41884,
      "e": 41804,
      "ty": 7,
      "x": 830,
      "y": 541,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 41902,
      "e": 41822,
      "ty": 2,
      "x": 830,
      "y": 541
    },
    {
      "t": 41902,
      "e": 41822,
      "ty": 6,
      "x": 830,
      "y": 552,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 41919,
      "e": 41839,
      "ty": 7,
      "x": 830,
      "y": 561,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 41952,
      "e": 41872,
      "ty": 6,
      "x": 830,
      "y": 578,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 41985,
      "e": 41905,
      "ty": 7,
      "x": 830,
      "y": 595,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 42001,
      "e": 41921,
      "ty": 2,
      "x": 830,
      "y": 595
    },
    {
      "t": 42002,
      "e": 41922,
      "ty": 41,
      "x": 2035,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 42101,
      "e": 42021,
      "ty": 2,
      "x": 829,
      "y": 636
    },
    {
      "t": 42169,
      "e": 42089,
      "ty": 6,
      "x": 829,
      "y": 670,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42201,
      "e": 42121,
      "ty": 2,
      "x": 829,
      "y": 673
    },
    {
      "t": 42251,
      "e": 42171,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42252,
      "e": 42172,
      "ty": 7,
      "x": 829,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42301,
      "e": 42221,
      "ty": 2,
      "x": 829,
      "y": 689
    },
    {
      "t": 42401,
      "e": 42321,
      "ty": 2,
      "x": 829,
      "y": 691
    },
    {
      "t": 42502,
      "e": 42422,
      "ty": 2,
      "x": 829,
      "y": 693
    },
    {
      "t": 42502,
      "e": 42422,
      "ty": 41,
      "x": 1909,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42519,
      "e": 42439,
      "ty": 6,
      "x": 830,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 42601,
      "e": 42521,
      "ty": 2,
      "x": 833,
      "y": 704
    },
    {
      "t": 42753,
      "e": 42522,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 42802,
      "e": 42571,
      "ty": 2,
      "x": 835,
      "y": 705
    },
    {
      "t": 42971,
      "e": 42740,
      "ty": 7,
      "x": 837,
      "y": 716,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 42987,
      "e": 42756,
      "ty": 6,
      "x": 839,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43002,
      "e": 42771,
      "ty": 2,
      "x": 839,
      "y": 724
    },
    {
      "t": 43002,
      "e": 42771,
      "ty": 41,
      "x": 63408,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43019,
      "e": 42788,
      "ty": 7,
      "x": 841,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43101,
      "e": 42870,
      "ty": 2,
      "x": 841,
      "y": 746
    },
    {
      "t": 43202,
      "e": 42971,
      "ty": 2,
      "x": 841,
      "y": 754
    },
    {
      "t": 43250,
      "e": 43019,
      "ty": 41,
      "x": 8169,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 43301,
      "e": 43070,
      "ty": 2,
      "x": 841,
      "y": 762
    },
    {
      "t": 43401,
      "e": 43170,
      "ty": 2,
      "x": 840,
      "y": 765
    },
    {
      "t": 43500,
      "e": 43269,
      "ty": 2,
      "x": 839,
      "y": 770
    },
    {
      "t": 43500,
      "e": 43269,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 43601,
      "e": 43370,
      "ty": 2,
      "x": 835,
      "y": 776
    },
    {
      "t": 43626,
      "e": 43395,
      "ty": 6,
      "x": 834,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 43701,
      "e": 43470,
      "ty": 2,
      "x": 833,
      "y": 782
    },
    {
      "t": 43751,
      "e": 43520,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 43801,
      "e": 43570,
      "ty": 2,
      "x": 833,
      "y": 788
    },
    {
      "t": 43837,
      "e": 43606,
      "ty": 7,
      "x": 833,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 43901,
      "e": 43670,
      "ty": 2,
      "x": 833,
      "y": 796
    },
    {
      "t": 44000,
      "e": 43769,
      "ty": 2,
      "x": 833,
      "y": 802
    },
    {
      "t": 44000,
      "e": 43769,
      "ty": 41,
      "x": 2747,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 44037,
      "e": 43806,
      "ty": 6,
      "x": 833,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 44101,
      "e": 43870,
      "ty": 2,
      "x": 833,
      "y": 810
    },
    {
      "t": 44155,
      "e": 43924,
      "ty": 7,
      "x": 834,
      "y": 803,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 44187,
      "e": 43956,
      "ty": 6,
      "x": 835,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 44201,
      "e": 43970,
      "ty": 2,
      "x": 835,
      "y": 792
    },
    {
      "t": 44250,
      "e": 44019,
      "ty": 41,
      "x": 53325,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 44287,
      "e": 44056,
      "ty": 7,
      "x": 839,
      "y": 775,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 44301,
      "e": 44070,
      "ty": 2,
      "x": 839,
      "y": 775
    },
    {
      "t": 44401,
      "e": 44170,
      "ty": 2,
      "x": 841,
      "y": 744
    },
    {
      "t": 44501,
      "e": 44270,
      "ty": 2,
      "x": 842,
      "y": 721
    },
    {
      "t": 44501,
      "e": 44270,
      "ty": 41,
      "x": 5164,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 44601,
      "e": 44370,
      "ty": 2,
      "x": 841,
      "y": 709
    },
    {
      "t": 44651,
      "e": 44420,
      "ty": 6,
      "x": 838,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44701,
      "e": 44470,
      "ty": 2,
      "x": 836,
      "y": 703
    },
    {
      "t": 44751,
      "e": 44520,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44882,
      "e": 44651,
      "ty": 3,
      "x": 836,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44882,
      "e": 44651,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 44882,
      "e": 44651,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44954,
      "e": 44723,
      "ty": 4,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44954,
      "e": 44723,
      "ty": 5,
      "x": 836,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 44955,
      "e": 44724,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 45239,
      "e": 45008,
      "ty": 7,
      "x": 835,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 45250,
      "e": 45019,
      "ty": 41,
      "x": 3222,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 45255,
      "e": 45024,
      "ty": 6,
      "x": 836,
      "y": 734,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 45271,
      "e": 45040,
      "ty": 7,
      "x": 836,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 45272,
      "e": 45041,
      "ty": 6,
      "x": 836,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 45288,
      "e": 45057,
      "ty": 7,
      "x": 837,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 45300,
      "e": 45069,
      "ty": 2,
      "x": 837,
      "y": 767
    },
    {
      "t": 45401,
      "e": 45170,
      "ty": 2,
      "x": 843,
      "y": 815
    },
    {
      "t": 45501,
      "e": 45270,
      "ty": 2,
      "x": 849,
      "y": 852
    },
    {
      "t": 45502,
      "e": 45271,
      "ty": 41,
      "x": 19430,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 45600,
      "e": 45369,
      "ty": 2,
      "x": 852,
      "y": 876
    },
    {
      "t": 45700,
      "e": 45469,
      "ty": 2,
      "x": 852,
      "y": 888
    },
    {
      "t": 45751,
      "e": 45520,
      "ty": 41,
      "x": 7019,
      "y": 16131,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 45801,
      "e": 45570,
      "ty": 2,
      "x": 846,
      "y": 916
    },
    {
      "t": 45871,
      "e": 45640,
      "ty": 6,
      "x": 839,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 45900,
      "e": 45669,
      "ty": 2,
      "x": 837,
      "y": 935
    },
    {
      "t": 45971,
      "e": 45740,
      "ty": 7,
      "x": 836,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 46000,
      "e": 45769,
      "ty": 2,
      "x": 836,
      "y": 943
    },
    {
      "t": 46001,
      "e": 45770,
      "ty": 41,
      "x": 15922,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 46100,
      "e": 45869,
      "ty": 2,
      "x": 834,
      "y": 951
    },
    {
      "t": 46201,
      "e": 45970,
      "ty": 2,
      "x": 833,
      "y": 954
    },
    {
      "t": 46251,
      "e": 46020,
      "ty": 41,
      "x": 9365,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46331,
      "e": 46100,
      "ty": 3,
      "x": 833,
      "y": 954,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46332,
      "e": 46101,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 46434,
      "e": 46203,
      "ty": 4,
      "x": 9365,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46435,
      "e": 46204,
      "ty": 5,
      "x": 833,
      "y": 954,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 46436,
      "e": 46205,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 46437,
      "e": 46206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 46610,
      "e": 46379,
      "ty": 6,
      "x": 833,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 46689,
      "e": 46458,
      "ty": 7,
      "x": 833,
      "y": 971,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 46701,
      "e": 46470,
      "ty": 2,
      "x": 833,
      "y": 971
    },
    {
      "t": 46722,
      "e": 46491,
      "ty": 6,
      "x": 833,
      "y": 990,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 46739,
      "e": 46508,
      "ty": 7,
      "x": 833,
      "y": 997,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 46751,
      "e": 46520,
      "ty": 41,
      "x": 11493,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 46773,
      "e": 46542,
      "ty": 6,
      "x": 832,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46800,
      "e": 46569,
      "ty": 2,
      "x": 832,
      "y": 1005
    },
    {
      "t": 47001,
      "e": 46770,
      "ty": 41,
      "x": 1328,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47027,
      "e": 46796,
      "ty": 3,
      "x": 832,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47027,
      "e": 46796,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 47027,
      "e": 46796,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47115,
      "e": 46884,
      "ty": 4,
      "x": 1328,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47115,
      "e": 46884,
      "ty": 5,
      "x": 832,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47121,
      "e": 46890,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 47123,
      "e": 46892,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 47126,
      "e": 46895,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 47401,
      "e": 47170,
      "ty": 2,
      "x": 827,
      "y": 971
    },
    {
      "t": 47501,
      "e": 47270,
      "ty": 2,
      "x": 822,
      "y": 941
    },
    {
      "t": 47501,
      "e": 47270,
      "ty": 41,
      "x": 28032,
      "y": 51685,
      "ta": "html > body"
    },
    {
      "t": 47601,
      "e": 47370,
      "ty": 2,
      "x": 821,
      "y": 935
    },
    {
      "t": 47701,
      "e": 47470,
      "ty": 2,
      "x": 816,
      "y": 920
    },
    {
      "t": 47751,
      "e": 47520,
      "ty": 41,
      "x": 27756,
      "y": 50300,
      "ta": "html > body"
    },
    {
      "t": 47801,
      "e": 47570,
      "ty": 2,
      "x": 811,
      "y": 909
    },
    {
      "t": 47902,
      "e": 47571,
      "ty": 2,
      "x": 807,
      "y": 898
    },
    {
      "t": 48001,
      "e": 47670,
      "ty": 2,
      "x": 805,
      "y": 896
    },
    {
      "t": 48001,
      "e": 47670,
      "ty": 41,
      "x": 27446,
      "y": 49192,
      "ta": "html > body"
    },
    {
      "t": 48220,
      "e": 47889,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 51708,
      "e": 51377,
      "ty": 2,
      "x": 850,
      "y": 917
    },
    {
      "t": 51759,
      "e": 51428,
      "ty": 41,
      "x": 29102,
      "y": 55654,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 51809,
      "e": 51478,
      "ty": 2,
      "x": 908,
      "y": 939
    },
    {
      "t": 51908,
      "e": 51577,
      "ty": 2,
      "x": 967,
      "y": 964
    },
    {
      "t": 52008,
      "e": 51677,
      "ty": 2,
      "x": 1019,
      "y": 993
    },
    {
      "t": 52008,
      "e": 51677,
      "ty": 41,
      "x": 35694,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 52108,
      "e": 51777,
      "ty": 2,
      "x": 1038,
      "y": 1017
    },
    {
      "t": 52208,
      "e": 51877,
      "ty": 2,
      "x": 1039,
      "y": 1027
    },
    {
      "t": 52259,
      "e": 51928,
      "ty": 41,
      "x": 36039,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 52308,
      "e": 51977,
      "ty": 2,
      "x": 1013,
      "y": 1036
    },
    {
      "t": 52408,
      "e": 52077,
      "ty": 2,
      "x": 954,
      "y": 1043
    },
    {
      "t": 52508,
      "e": 52177,
      "ty": 2,
      "x": 923,
      "y": 1054
    },
    {
      "t": 52509,
      "e": 52178,
      "ty": 41,
      "x": 30971,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 52609,
      "e": 52278,
      "ty": 2,
      "x": 922,
      "y": 1071
    },
    {
      "t": 52617,
      "e": 52286,
      "ty": 6,
      "x": 922,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 52708,
      "e": 52377,
      "ty": 2,
      "x": 922,
      "y": 1080
    },
    {
      "t": 52758,
      "e": 52427,
      "ty": 41,
      "x": 8464,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 52809,
      "e": 52478,
      "ty": 2,
      "x": 928,
      "y": 1088
    },
    {
      "t": 53008,
      "e": 52677,
      "ty": 41,
      "x": 10103,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 58259,
      "e": 57677,
      "ty": 41,
      "x": 17202,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 58309,
      "e": 57727,
      "ty": 2,
      "x": 954,
      "y": 1080
    },
    {
      "t": 58509,
      "e": 57927,
      "ty": 41,
      "x": 24302,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 58759,
      "e": 58177,
      "ty": 41,
      "x": 24302,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 58808,
      "e": 58226,
      "ty": 2,
      "x": 954,
      "y": 1084
    },
    {
      "t": 58908,
      "e": 58326,
      "ty": 2,
      "x": 954,
      "y": 1085
    },
    {
      "t": 59009,
      "e": 58427,
      "ty": 41,
      "x": 24302,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 60009,
      "e": 59427,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 61155,
      "e": 60573,
      "ty": 3,
      "x": 954,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 61157,
      "e": 60575,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 61273,
      "e": 60691,
      "ty": 4,
      "x": 24302,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 61274,
      "e": 60692,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 61274,
      "e": 60692,
      "ty": 5,
      "x": 954,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 61275,
      "e": 60693,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 62109,
      "e": 61527,
      "ty": 2,
      "x": 581,
      "y": 887
    },
    {
      "t": 62209,
      "e": 61627,
      "ty": 2,
      "x": 65,
      "y": 650
    },
    {
      "t": 62259,
      "e": 61677,
      "ty": 41,
      "x": 757,
      "y": 34124,
      "ta": "html > body"
    },
    {
      "t": 62307,
      "e": 61725,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 63007,
      "e": 62425,
      "ty": 2,
      "x": 27,
      "y": 620
    },
    {
      "t": 63007,
      "e": 62425,
      "ty": 41,
      "x": 654,
      "y": 33903,
      "ta": "html > body"
    },
    {
      "t": 63559,
      "e": 62977,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 62308, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 62311, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 4019, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 67659, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 9530, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\\n\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 78197, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15913, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 95194, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12042, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 108239, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 16907, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 126508, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-12 PM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:732,y:585,t:1527188729543};\\\", \\\"{x:716,y:576,t:1527188729575};\\\", \\\"{x:652,y:539,t:1527188729768};\\\", \\\"{x:646,y:535,t:1527188729796};\\\", \\\"{x:646,y:534,t:1527188729806};\\\", \\\"{x:644,y:533,t:1527188729820};\\\", \\\"{x:630,y:525,t:1527188729927};\\\", \\\"{x:629,y:525,t:1527188729937};\\\", \\\"{x:622,y:523,t:1527188729954};\\\", \\\"{x:613,y:518,t:1527188729970};\\\", \\\"{x:605,y:515,t:1527188729987};\\\", \\\"{x:597,y:512,t:1527188730004};\\\", \\\"{x:592,y:511,t:1527188730019};\\\", \\\"{x:589,y:511,t:1527188730037};\\\", \\\"{x:588,y:510,t:1527188730053};\\\", \\\"{x:587,y:510,t:1527188730069};\\\", \\\"{x:582,y:508,t:1527188730088};\\\", \\\"{x:574,y:508,t:1527188730104};\\\", \\\"{x:558,y:505,t:1527188730121};\\\", \\\"{x:540,y:502,t:1527188730137};\\\", \\\"{x:520,y:502,t:1527188730154};\\\", \\\"{x:495,y:502,t:1527188730171};\\\", \\\"{x:468,y:502,t:1527188730187};\\\", \\\"{x:416,y:502,t:1527188730204};\\\", \\\"{x:287,y:532,t:1527188730221};\\\", \\\"{x:238,y:541,t:1527188730238};\\\", \\\"{x:214,y:542,t:1527188730254};\\\", \\\"{x:201,y:542,t:1527188730271};\\\", \\\"{x:199,y:541,t:1527188730806};\\\", \\\"{x:193,y:539,t:1527188730821};\\\", \\\"{x:187,y:536,t:1527188730838};\\\", \\\"{x:185,y:536,t:1527188730853};\\\", \\\"{x:183,y:536,t:1527188730869};\\\", \\\"{x:181,y:536,t:1527188730886};\\\", \\\"{x:180,y:536,t:1527188730902};\\\", \\\"{x:178,y:536,t:1527188730964};\\\", \\\"{x:177,y:536,t:1527188731013};\\\", \\\"{x:181,y:539,t:1527188733983};\\\", \\\"{x:194,y:550,t:1527188734000};\\\", \\\"{x:222,y:572,t:1527188734023};\\\", \\\"{x:247,y:587,t:1527188734041};\\\", \\\"{x:286,y:611,t:1527188734058};\\\", \\\"{x:346,y:646,t:1527188734075};\\\", \\\"{x:433,y:693,t:1527188734091};\\\", \\\"{x:539,y:747,t:1527188734106};\\\", \\\"{x:648,y:791,t:1527188734123};\\\", \\\"{x:826,y:865,t:1527188734140};\\\", \\\"{x:935,y:902,t:1527188734157};\\\", \\\"{x:1042,y:928,t:1527188734173};\\\", \\\"{x:1134,y:955,t:1527188734190};\\\", \\\"{x:1206,y:975,t:1527188734207};\\\", \\\"{x:1240,y:986,t:1527188734224};\\\", \\\"{x:1256,y:987,t:1527188734240};\\\", \\\"{x:1268,y:990,t:1527188734257};\\\", \\\"{x:1282,y:993,t:1527188734273};\\\", \\\"{x:1299,y:998,t:1527188734290};\\\", \\\"{x:1317,y:1001,t:1527188734308};\\\", \\\"{x:1334,y:1003,t:1527188734323};\\\", \\\"{x:1359,y:1005,t:1527188734341};\\\", \\\"{x:1374,y:1005,t:1527188734357};\\\", \\\"{x:1387,y:1005,t:1527188734374};\\\", \\\"{x:1394,y:1005,t:1527188734390};\\\", \\\"{x:1397,y:1005,t:1527188734406};\\\", \\\"{x:1399,y:1005,t:1527188734423};\\\", \\\"{x:1399,y:1004,t:1527188734500};\\\", \\\"{x:1398,y:1004,t:1527188734508};\\\", \\\"{x:1397,y:1003,t:1527188734523};\\\", \\\"{x:1388,y:999,t:1527188734540};\\\", \\\"{x:1379,y:994,t:1527188734556};\\\", \\\"{x:1371,y:992,t:1527188734573};\\\", \\\"{x:1363,y:989,t:1527188734590};\\\", \\\"{x:1355,y:987,t:1527188734606};\\\", \\\"{x:1343,y:982,t:1527188734623};\\\", \\\"{x:1326,y:977,t:1527188734641};\\\", \\\"{x:1304,y:967,t:1527188734656};\\\", \\\"{x:1285,y:960,t:1527188734674};\\\", \\\"{x:1268,y:956,t:1527188734689};\\\", \\\"{x:1256,y:952,t:1527188734706};\\\", \\\"{x:1248,y:950,t:1527188734723};\\\", \\\"{x:1240,y:948,t:1527188734740};\\\", \\\"{x:1233,y:947,t:1527188734756};\\\", \\\"{x:1232,y:947,t:1527188734773};\\\", \\\"{x:1231,y:947,t:1527188734918};\\\", \\\"{x:1230,y:947,t:1527188734933};\\\", \\\"{x:1229,y:947,t:1527188734941};\\\", \\\"{x:1228,y:948,t:1527188734957};\\\", \\\"{x:1225,y:951,t:1527188734973};\\\", \\\"{x:1225,y:954,t:1527188734990};\\\", \\\"{x:1223,y:957,t:1527188735007};\\\", \\\"{x:1223,y:961,t:1527188735023};\\\", \\\"{x:1223,y:965,t:1527188735039};\\\", \\\"{x:1225,y:972,t:1527188735056};\\\", \\\"{x:1232,y:977,t:1527188735073};\\\", \\\"{x:1237,y:979,t:1527188735089};\\\", \\\"{x:1243,y:981,t:1527188735107};\\\", \\\"{x:1244,y:981,t:1527188735122};\\\", \\\"{x:1248,y:981,t:1527188735139};\\\", \\\"{x:1250,y:980,t:1527188735156};\\\", \\\"{x:1254,y:979,t:1527188735172};\\\", \\\"{x:1255,y:978,t:1527188735277};\\\", \\\"{x:1256,y:977,t:1527188735293};\\\", \\\"{x:1257,y:977,t:1527188735325};\\\", \\\"{x:1258,y:977,t:1527188735350};\\\", \\\"{x:1259,y:976,t:1527188735357};\\\", \\\"{x:1260,y:975,t:1527188735950};\\\", \\\"{x:1259,y:973,t:1527188735958};\\\", \\\"{x:1254,y:971,t:1527188735973};\\\", \\\"{x:1249,y:968,t:1527188735990};\\\", \\\"{x:1248,y:968,t:1527188736006};\\\", \\\"{x:1246,y:967,t:1527188736024};\\\", \\\"{x:1245,y:966,t:1527188736221};\\\", \\\"{x:1249,y:963,t:1527188736240};\\\", \\\"{x:1256,y:959,t:1527188736256};\\\", \\\"{x:1260,y:958,t:1527188736271};\\\", \\\"{x:1262,y:956,t:1527188736288};\\\", \\\"{x:1263,y:956,t:1527188736305};\\\", \\\"{x:1264,y:956,t:1527188736321};\\\", \\\"{x:1266,y:955,t:1527188736338};\\\", \\\"{x:1268,y:954,t:1527188736356};\\\", \\\"{x:1269,y:953,t:1527188736372};\\\", \\\"{x:1270,y:953,t:1527188736388};\\\", \\\"{x:1271,y:952,t:1527188736404};\\\", \\\"{x:1272,y:952,t:1527188736421};\\\", \\\"{x:1273,y:951,t:1527188736438};\\\", \\\"{x:1274,y:950,t:1527188736460};\\\", \\\"{x:1276,y:949,t:1527188736500};\\\", \\\"{x:1277,y:949,t:1527188736621};\\\", \\\"{x:1278,y:949,t:1527188736639};\\\", \\\"{x:1280,y:947,t:1527188736655};\\\", \\\"{x:1282,y:947,t:1527188736672};\\\", \\\"{x:1283,y:947,t:1527188736689};\\\", \\\"{x:1285,y:946,t:1527188736705};\\\", \\\"{x:1286,y:946,t:1527188736722};\\\", \\\"{x:1288,y:946,t:1527188736750};\\\", \\\"{x:1287,y:946,t:1527188737796};\\\", \\\"{x:1286,y:947,t:1527188737805};\\\", \\\"{x:1285,y:947,t:1527188737869};\\\", \\\"{x:1283,y:946,t:1527188738894};\\\", \\\"{x:1282,y:929,t:1527188738903};\\\", \\\"{x:1281,y:910,t:1527188738921};\\\", \\\"{x:1278,y:897,t:1527188738936};\\\", \\\"{x:1277,y:889,t:1527188738953};\\\", \\\"{x:1277,y:879,t:1527188738970};\\\", \\\"{x:1277,y:868,t:1527188738986};\\\", \\\"{x:1275,y:859,t:1527188739003};\\\", \\\"{x:1275,y:855,t:1527188739020};\\\", \\\"{x:1274,y:850,t:1527188739035};\\\", \\\"{x:1273,y:846,t:1527188739052};\\\", \\\"{x:1273,y:843,t:1527188739072};\\\", \\\"{x:1273,y:841,t:1527188739089};\\\", \\\"{x:1273,y:838,t:1527188739105};\\\", \\\"{x:1273,y:837,t:1527188739122};\\\", \\\"{x:1274,y:835,t:1527188739139};\\\", \\\"{x:1274,y:834,t:1527188739156};\\\", \\\"{x:1274,y:833,t:1527188739171};\\\", \\\"{x:1274,y:831,t:1527188744089};\\\", \\\"{x:1263,y:824,t:1527188744101};\\\", \\\"{x:1197,y:796,t:1527188744118};\\\", \\\"{x:1108,y:767,t:1527188744135};\\\", \\\"{x:999,y:732,t:1527188744152};\\\", \\\"{x:904,y:702,t:1527188744167};\\\", \\\"{x:749,y:656,t:1527188744184};\\\", \\\"{x:641,y:625,t:1527188744203};\\\", \\\"{x:522,y:594,t:1527188744218};\\\", \\\"{x:417,y:564,t:1527188744234};\\\", \\\"{x:316,y:530,t:1527188744252};\\\", \\\"{x:249,y:508,t:1527188744268};\\\", \\\"{x:207,y:495,t:1527188744285};\\\", \\\"{x:184,y:490,t:1527188744302};\\\", \\\"{x:173,y:486,t:1527188744319};\\\", \\\"{x:166,y:484,t:1527188744335};\\\", \\\"{x:163,y:484,t:1527188744352};\\\", \\\"{x:162,y:484,t:1527188744383};\\\", \\\"{x:165,y:485,t:1527188744447};\\\", \\\"{x:171,y:488,t:1527188744455};\\\", \\\"{x:178,y:493,t:1527188744468};\\\", \\\"{x:193,y:502,t:1527188744485};\\\", \\\"{x:204,y:508,t:1527188744503};\\\", \\\"{x:207,y:508,t:1527188744518};\\\", \\\"{x:207,y:510,t:1527188744544};\\\", \\\"{x:206,y:510,t:1527188744553};\\\", \\\"{x:200,y:514,t:1527188744569};\\\", \\\"{x:197,y:514,t:1527188744586};\\\", \\\"{x:192,y:516,t:1527188744604};\\\", \\\"{x:189,y:518,t:1527188744618};\\\", \\\"{x:188,y:518,t:1527188744635};\\\", \\\"{x:185,y:519,t:1527188744652};\\\", \\\"{x:185,y:520,t:1527188744695};\\\", \\\"{x:190,y:521,t:1527188744711};\\\", \\\"{x:207,y:521,t:1527188744720};\\\", \\\"{x:249,y:521,t:1527188744735};\\\", \\\"{x:298,y:509,t:1527188744752};\\\", \\\"{x:331,y:504,t:1527188744769};\\\", \\\"{x:347,y:500,t:1527188744786};\\\", \\\"{x:351,y:499,t:1527188744803};\\\", \\\"{x:352,y:499,t:1527188744945};\\\", \\\"{x:355,y:497,t:1527188744952};\\\", \\\"{x:356,y:497,t:1527188745016};\\\", \\\"{x:356,y:504,t:1527188745023};\\\", \\\"{x:356,y:515,t:1527188745037};\\\", \\\"{x:367,y:537,t:1527188745053};\\\", \\\"{x:377,y:551,t:1527188745069};\\\", \\\"{x:379,y:556,t:1527188745085};\\\", \\\"{x:381,y:557,t:1527188745103};\\\", \\\"{x:382,y:557,t:1527188745176};\\\", \\\"{x:384,y:557,t:1527188745186};\\\", \\\"{x:386,y:556,t:1527188745203};\\\", \\\"{x:388,y:555,t:1527188745218};\\\", \\\"{x:389,y:554,t:1527188745235};\\\", \\\"{x:390,y:553,t:1527188745351};\\\", \\\"{x:390,y:552,t:1527188745359};\\\", \\\"{x:390,y:551,t:1527188745369};\\\", \\\"{x:390,y:548,t:1527188745386};\\\", \\\"{x:393,y:545,t:1527188745403};\\\", \\\"{x:393,y:544,t:1527188745452};\\\", \\\"{x:393,y:543,t:1527188745538};\\\", \\\"{x:393,y:539,t:1527188745550};\\\", \\\"{x:393,y:537,t:1527188745570};\\\", \\\"{x:393,y:536,t:1527188745585};\\\", \\\"{x:393,y:534,t:1527188745602};\\\", \\\"{x:393,y:531,t:1527188745620};\\\", \\\"{x:393,y:530,t:1527188745639};\\\", \\\"{x:393,y:528,t:1527188745679};\\\", \\\"{x:393,y:527,t:1527188745695};\\\", \\\"{x:391,y:527,t:1527188745991};\\\", \\\"{x:391,y:528,t:1527188746003};\\\", \\\"{x:399,y:557,t:1527188746021};\\\", \\\"{x:422,y:598,t:1527188746037};\\\", \\\"{x:452,y:650,t:1527188746055};\\\", \\\"{x:479,y:685,t:1527188746070};\\\", \\\"{x:501,y:702,t:1527188746088};\\\", \\\"{x:513,y:708,t:1527188746102};\\\", \\\"{x:517,y:709,t:1527188746119};\\\", \\\"{x:518,y:710,t:1527188746137};\\\", \\\"{x:519,y:711,t:1527188746176};\\\", \\\"{x:519,y:712,t:1527188746712};\\\", \\\"{x:517,y:712,t:1527188746721};\\\", \\\"{x:515,y:712,t:1527188746737};\\\", \\\"{x:514,y:712,t:1527188746856};\\\", \\\"{x:514,y:710,t:1527188746871};\\\", \\\"{x:514,y:705,t:1527188746887};\\\", \\\"{x:525,y:692,t:1527188746904};\\\", \\\"{x:541,y:677,t:1527188746921};\\\", \\\"{x:566,y:662,t:1527188746937};\\\", \\\"{x:595,y:647,t:1527188746954};\\\", \\\"{x:619,y:636,t:1527188746971};\\\", \\\"{x:641,y:626,t:1527188746987};\\\", \\\"{x:651,y:620,t:1527188747004};\\\", \\\"{x:660,y:615,t:1527188747021};\\\", \\\"{x:666,y:613,t:1527188747037};\\\", \\\"{x:667,y:612,t:1527188747056};\\\", \\\"{x:666,y:612,t:1527188747168};\\\", \\\"{x:665,y:612,t:1527188747184};\\\", \\\"{x:664,y:612,t:1527188747192};\\\", \\\"{x:663,y:612,t:1527188747204};\\\", \\\"{x:661,y:612,t:1527188747221};\\\", \\\"{x:660,y:612,t:1527188747240};\\\", \\\"{x:659,y:612,t:1527188747254};\\\", \\\"{x:657,y:612,t:1527188747271};\\\", \\\"{x:653,y:611,t:1527188747288};\\\", \\\"{x:650,y:611,t:1527188747304};\\\", \\\"{x:648,y:611,t:1527188747321};\\\", \\\"{x:645,y:611,t:1527188747338};\\\", \\\"{x:644,y:611,t:1527188747354};\\\", \\\"{x:643,y:611,t:1527188747375};\\\", \\\"{x:642,y:611,t:1527188747399};\\\", \\\"{x:641,y:611,t:1527188747424};\\\", \\\"{x:640,y:611,t:1527188747463};\\\", \\\"{x:637,y:611,t:1527188747526};\\\", \\\"{x:636,y:611,t:1527188747537};\\\", \\\"{x:635,y:611,t:1527188747554};\\\" ] }, { \\\"rt\\\": 12470, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 140233, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-D -E -E -G -G \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:632,y:610,t:1527188747705};\\\", \\\"{x:631,y:610,t:1527188747775};\\\", \\\"{x:630,y:610,t:1527188747847};\\\", \\\"{x:629,y:610,t:1527188747919};\\\", \\\"{x:628,y:610,t:1527188747951};\\\", \\\"{x:626,y:610,t:1527188747975};\\\", \\\"{x:625,y:609,t:1527188748008};\\\", \\\"{x:624,y:609,t:1527188748031};\\\", \\\"{x:623,y:609,t:1527188748055};\\\", \\\"{x:622,y:609,t:1527188748206};\\\", \\\"{x:621,y:609,t:1527188748247};\\\", \\\"{x:620,y:609,t:1527188748295};\\\", \\\"{x:618,y:609,t:1527188748327};\\\", \\\"{x:617,y:609,t:1527188748343};\\\", \\\"{x:614,y:609,t:1527188748359};\\\", \\\"{x:613,y:609,t:1527188748423};\\\", \\\"{x:612,y:609,t:1527188748471};\\\", \\\"{x:611,y:609,t:1527188749200};\\\", \\\"{x:611,y:611,t:1527188749207};\\\", \\\"{x:611,y:614,t:1527188749223};\\\", \\\"{x:625,y:624,t:1527188749240};\\\", \\\"{x:656,y:640,t:1527188749273};\\\", \\\"{x:677,y:651,t:1527188749289};\\\", \\\"{x:704,y:657,t:1527188749305};\\\", \\\"{x:726,y:664,t:1527188749323};\\\", \\\"{x:743,y:670,t:1527188749339};\\\", \\\"{x:767,y:675,t:1527188749356};\\\", \\\"{x:800,y:684,t:1527188749373};\\\", \\\"{x:839,y:697,t:1527188749388};\\\", \\\"{x:879,y:708,t:1527188749406};\\\", \\\"{x:952,y:723,t:1527188749422};\\\", \\\"{x:977,y:730,t:1527188749439};\\\", \\\"{x:1032,y:739,t:1527188749456};\\\", \\\"{x:1066,y:745,t:1527188749473};\\\", \\\"{x:1090,y:750,t:1527188749488};\\\", \\\"{x:1103,y:753,t:1527188749506};\\\", \\\"{x:1110,y:755,t:1527188749523};\\\", \\\"{x:1114,y:755,t:1527188749539};\\\", \\\"{x:1119,y:757,t:1527188749556};\\\", \\\"{x:1125,y:759,t:1527188749573};\\\", \\\"{x:1136,y:762,t:1527188749589};\\\", \\\"{x:1146,y:767,t:1527188749606};\\\", \\\"{x:1170,y:774,t:1527188749623};\\\", \\\"{x:1211,y:787,t:1527188749638};\\\", \\\"{x:1251,y:798,t:1527188749656};\\\", \\\"{x:1289,y:806,t:1527188749673};\\\", \\\"{x:1327,y:818,t:1527188749690};\\\", \\\"{x:1367,y:828,t:1527188749706};\\\", \\\"{x:1409,y:839,t:1527188749723};\\\", \\\"{x:1460,y:848,t:1527188749740};\\\", \\\"{x:1497,y:856,t:1527188749756};\\\", \\\"{x:1542,y:862,t:1527188749773};\\\", \\\"{x:1576,y:867,t:1527188749790};\\\", \\\"{x:1604,y:872,t:1527188749806};\\\", \\\"{x:1622,y:874,t:1527188749823};\\\", \\\"{x:1628,y:874,t:1527188749839};\\\", \\\"{x:1630,y:874,t:1527188749856};\\\", \\\"{x:1630,y:876,t:1527188750080};\\\", \\\"{x:1630,y:877,t:1527188750095};\\\", \\\"{x:1629,y:878,t:1527188750107};\\\", \\\"{x:1624,y:880,t:1527188750123};\\\", \\\"{x:1615,y:885,t:1527188750141};\\\", \\\"{x:1604,y:890,t:1527188750157};\\\", \\\"{x:1592,y:899,t:1527188750174};\\\", \\\"{x:1580,y:905,t:1527188750191};\\\", \\\"{x:1566,y:911,t:1527188750207};\\\", \\\"{x:1557,y:916,t:1527188750224};\\\", \\\"{x:1542,y:921,t:1527188750240};\\\", \\\"{x:1533,y:924,t:1527188750258};\\\", \\\"{x:1526,y:925,t:1527188750273};\\\", \\\"{x:1520,y:926,t:1527188750290};\\\", \\\"{x:1516,y:926,t:1527188750307};\\\", \\\"{x:1514,y:927,t:1527188750323};\\\", \\\"{x:1512,y:927,t:1527188750340};\\\", \\\"{x:1511,y:927,t:1527188750360};\\\", \\\"{x:1510,y:927,t:1527188750384};\\\", \\\"{x:1509,y:927,t:1527188750425};\\\", \\\"{x:1508,y:927,t:1527188750464};\\\", \\\"{x:1507,y:927,t:1527188750480};\\\", \\\"{x:1506,y:927,t:1527188750491};\\\", \\\"{x:1504,y:927,t:1527188750528};\\\", \\\"{x:1503,y:927,t:1527188750720};\\\", \\\"{x:1502,y:926,t:1527188750809};\\\", \\\"{x:1501,y:926,t:1527188750832};\\\", \\\"{x:1500,y:926,t:1527188750856};\\\", \\\"{x:1499,y:925,t:1527188750896};\\\", \\\"{x:1497,y:925,t:1527188750920};\\\", \\\"{x:1496,y:924,t:1527188750976};\\\", \\\"{x:1495,y:924,t:1527188751016};\\\", \\\"{x:1494,y:923,t:1527188751031};\\\", \\\"{x:1493,y:923,t:1527188751080};\\\", \\\"{x:1492,y:922,t:1527188751103};\\\", \\\"{x:1491,y:922,t:1527188751143};\\\", \\\"{x:1490,y:921,t:1527188751199};\\\", \\\"{x:1489,y:921,t:1527188751207};\\\", \\\"{x:1488,y:921,t:1527188751224};\\\", \\\"{x:1485,y:921,t:1527188751241};\\\", \\\"{x:1484,y:919,t:1527188751257};\\\", \\\"{x:1483,y:919,t:1527188751279};\\\", \\\"{x:1482,y:919,t:1527188751296};\\\", \\\"{x:1481,y:919,t:1527188751320};\\\", \\\"{x:1480,y:919,t:1527188751376};\\\", \\\"{x:1478,y:918,t:1527188751391};\\\", \\\"{x:1477,y:918,t:1527188751415};\\\", \\\"{x:1476,y:918,t:1527188751424};\\\", \\\"{x:1475,y:918,t:1527188751448};\\\", \\\"{x:1474,y:917,t:1527188751472};\\\", \\\"{x:1474,y:916,t:1527188751479};\\\", \\\"{x:1472,y:916,t:1527188751492};\\\", \\\"{x:1471,y:916,t:1527188751508};\\\", \\\"{x:1469,y:916,t:1527188751524};\\\", \\\"{x:1468,y:915,t:1527188751541};\\\", \\\"{x:1467,y:915,t:1527188751558};\\\", \\\"{x:1466,y:915,t:1527188751574};\\\", \\\"{x:1463,y:914,t:1527188751591};\\\", \\\"{x:1463,y:913,t:1527188751607};\\\", \\\"{x:1461,y:913,t:1527188751624};\\\", \\\"{x:1458,y:911,t:1527188751641};\\\", \\\"{x:1455,y:910,t:1527188751658};\\\", \\\"{x:1452,y:909,t:1527188751674};\\\", \\\"{x:1449,y:908,t:1527188751691};\\\", \\\"{x:1445,y:907,t:1527188751708};\\\", \\\"{x:1442,y:905,t:1527188751724};\\\", \\\"{x:1437,y:903,t:1527188751741};\\\", \\\"{x:1436,y:903,t:1527188751758};\\\", \\\"{x:1432,y:901,t:1527188751774};\\\", \\\"{x:1430,y:901,t:1527188751791};\\\", \\\"{x:1427,y:899,t:1527188751807};\\\", \\\"{x:1424,y:898,t:1527188751825};\\\", \\\"{x:1421,y:897,t:1527188751842};\\\", \\\"{x:1419,y:895,t:1527188751858};\\\", \\\"{x:1418,y:895,t:1527188751875};\\\", \\\"{x:1416,y:894,t:1527188751891};\\\", \\\"{x:1416,y:893,t:1527188751908};\\\", \\\"{x:1416,y:892,t:1527188751926};\\\", \\\"{x:1416,y:889,t:1527188751941};\\\", \\\"{x:1415,y:884,t:1527188751959};\\\", \\\"{x:1415,y:874,t:1527188751975};\\\", \\\"{x:1415,y:869,t:1527188751991};\\\", \\\"{x:1415,y:863,t:1527188752008};\\\", \\\"{x:1415,y:860,t:1527188752025};\\\", \\\"{x:1416,y:857,t:1527188752041};\\\", \\\"{x:1419,y:851,t:1527188752058};\\\", \\\"{x:1420,y:844,t:1527188752075};\\\", \\\"{x:1421,y:835,t:1527188752091};\\\", \\\"{x:1425,y:824,t:1527188752108};\\\", \\\"{x:1429,y:814,t:1527188752126};\\\", \\\"{x:1431,y:805,t:1527188752141};\\\", \\\"{x:1435,y:797,t:1527188752158};\\\", \\\"{x:1438,y:789,t:1527188752175};\\\", \\\"{x:1439,y:784,t:1527188752191};\\\", \\\"{x:1442,y:781,t:1527188752208};\\\", \\\"{x:1442,y:778,t:1527188752226};\\\", \\\"{x:1442,y:776,t:1527188752241};\\\", \\\"{x:1442,y:775,t:1527188752259};\\\", \\\"{x:1442,y:774,t:1527188752279};\\\", \\\"{x:1442,y:773,t:1527188752292};\\\", \\\"{x:1442,y:771,t:1527188752308};\\\", \\\"{x:1442,y:768,t:1527188752325};\\\", \\\"{x:1442,y:766,t:1527188752352};\\\", \\\"{x:1442,y:765,t:1527188752368};\\\", \\\"{x:1441,y:765,t:1527188752633};\\\", \\\"{x:1437,y:765,t:1527188752642};\\\", \\\"{x:1424,y:770,t:1527188752659};\\\", \\\"{x:1411,y:772,t:1527188752675};\\\", \\\"{x:1396,y:772,t:1527188752692};\\\", \\\"{x:1382,y:771,t:1527188752708};\\\", \\\"{x:1370,y:771,t:1527188752726};\\\", \\\"{x:1361,y:771,t:1527188752742};\\\", \\\"{x:1354,y:771,t:1527188752759};\\\", \\\"{x:1346,y:770,t:1527188752776};\\\", \\\"{x:1342,y:770,t:1527188752792};\\\", \\\"{x:1341,y:770,t:1527188752809};\\\", \\\"{x:1340,y:771,t:1527188752848};\\\", \\\"{x:1340,y:773,t:1527188752864};\\\", \\\"{x:1342,y:775,t:1527188752876};\\\", \\\"{x:1356,y:779,t:1527188752893};\\\", \\\"{x:1378,y:784,t:1527188752910};\\\", \\\"{x:1405,y:786,t:1527188752925};\\\", \\\"{x:1437,y:786,t:1527188752943};\\\", \\\"{x:1497,y:779,t:1527188752960};\\\", \\\"{x:1539,y:773,t:1527188752976};\\\", \\\"{x:1575,y:769,t:1527188752992};\\\", \\\"{x:1620,y:769,t:1527188753009};\\\", \\\"{x:1659,y:769,t:1527188753026};\\\", \\\"{x:1687,y:772,t:1527188753042};\\\", \\\"{x:1711,y:785,t:1527188753060};\\\", \\\"{x:1727,y:798,t:1527188753075};\\\", \\\"{x:1736,y:804,t:1527188753092};\\\", \\\"{x:1738,y:806,t:1527188753110};\\\", \\\"{x:1738,y:807,t:1527188753125};\\\", \\\"{x:1738,y:803,t:1527188753200};\\\", \\\"{x:1738,y:793,t:1527188753210};\\\", \\\"{x:1726,y:766,t:1527188753226};\\\", \\\"{x:1709,y:729,t:1527188753242};\\\", \\\"{x:1690,y:692,t:1527188753259};\\\", \\\"{x:1680,y:670,t:1527188753276};\\\", \\\"{x:1674,y:644,t:1527188753292};\\\", \\\"{x:1669,y:624,t:1527188753310};\\\", \\\"{x:1666,y:611,t:1527188753327};\\\", \\\"{x:1664,y:603,t:1527188753342};\\\", \\\"{x:1664,y:597,t:1527188753360};\\\", \\\"{x:1664,y:593,t:1527188753376};\\\", \\\"{x:1664,y:587,t:1527188753393};\\\", \\\"{x:1664,y:581,t:1527188753409};\\\", \\\"{x:1664,y:575,t:1527188753426};\\\", \\\"{x:1661,y:571,t:1527188753442};\\\", \\\"{x:1657,y:567,t:1527188753459};\\\", \\\"{x:1655,y:565,t:1527188753477};\\\", \\\"{x:1650,y:562,t:1527188753492};\\\", \\\"{x:1640,y:554,t:1527188753510};\\\", \\\"{x:1620,y:543,t:1527188753527};\\\", \\\"{x:1613,y:539,t:1527188753543};\\\", \\\"{x:1582,y:530,t:1527188753559};\\\", \\\"{x:1567,y:527,t:1527188753576};\\\", \\\"{x:1551,y:523,t:1527188753592};\\\", \\\"{x:1539,y:518,t:1527188753609};\\\", \\\"{x:1531,y:514,t:1527188753626};\\\", \\\"{x:1527,y:511,t:1527188753643};\\\", \\\"{x:1527,y:510,t:1527188753660};\\\", \\\"{x:1527,y:509,t:1527188753676};\\\", \\\"{x:1536,y:502,t:1527188753694};\\\", \\\"{x:1546,y:495,t:1527188753710};\\\", \\\"{x:1556,y:486,t:1527188753728};\\\", \\\"{x:1568,y:469,t:1527188753744};\\\", \\\"{x:1572,y:462,t:1527188753760};\\\", \\\"{x:1576,y:457,t:1527188753776};\\\", \\\"{x:1578,y:454,t:1527188753794};\\\", \\\"{x:1580,y:452,t:1527188753809};\\\", \\\"{x:1582,y:449,t:1527188753826};\\\", \\\"{x:1585,y:447,t:1527188753843};\\\", \\\"{x:1594,y:443,t:1527188753860};\\\", \\\"{x:1601,y:441,t:1527188753877};\\\", \\\"{x:1604,y:439,t:1527188753893};\\\", \\\"{x:1606,y:439,t:1527188753960};\\\", \\\"{x:1609,y:439,t:1527188753976};\\\", \\\"{x:1612,y:439,t:1527188753993};\\\", \\\"{x:1613,y:438,t:1527188754009};\\\", \\\"{x:1613,y:437,t:1527188754200};\\\", \\\"{x:1613,y:435,t:1527188754213};\\\", \\\"{x:1613,y:434,t:1527188754225};\\\", \\\"{x:1613,y:432,t:1527188754243};\\\", \\\"{x:1613,y:431,t:1527188754263};\\\", \\\"{x:1613,y:430,t:1527188754352};\\\", \\\"{x:1613,y:429,t:1527188754360};\\\", \\\"{x:1613,y:428,t:1527188754528};\\\", \\\"{x:1611,y:428,t:1527188755361};\\\", \\\"{x:1609,y:431,t:1527188755377};\\\", \\\"{x:1608,y:434,t:1527188755396};\\\", \\\"{x:1608,y:439,t:1527188755411};\\\", \\\"{x:1607,y:444,t:1527188755428};\\\", \\\"{x:1607,y:452,t:1527188755445};\\\", \\\"{x:1607,y:460,t:1527188755462};\\\", \\\"{x:1607,y:468,t:1527188755477};\\\", \\\"{x:1607,y:472,t:1527188755494};\\\", \\\"{x:1607,y:480,t:1527188755512};\\\", \\\"{x:1607,y:487,t:1527188755528};\\\", \\\"{x:1607,y:497,t:1527188755544};\\\", \\\"{x:1607,y:505,t:1527188755562};\\\", \\\"{x:1609,y:513,t:1527188755578};\\\", \\\"{x:1609,y:517,t:1527188755595};\\\", \\\"{x:1609,y:522,t:1527188755612};\\\", \\\"{x:1610,y:524,t:1527188755627};\\\", \\\"{x:1610,y:529,t:1527188755645};\\\", \\\"{x:1611,y:535,t:1527188755662};\\\", \\\"{x:1612,y:541,t:1527188755677};\\\", \\\"{x:1613,y:544,t:1527188755695};\\\", \\\"{x:1614,y:550,t:1527188755712};\\\", \\\"{x:1614,y:554,t:1527188755728};\\\", \\\"{x:1617,y:557,t:1527188755744};\\\", \\\"{x:1617,y:558,t:1527188755762};\\\", \\\"{x:1617,y:560,t:1527188755778};\\\", \\\"{x:1618,y:561,t:1527188755795};\\\", \\\"{x:1618,y:562,t:1527188755848};\\\", \\\"{x:1618,y:563,t:1527188755862};\\\", \\\"{x:1618,y:564,t:1527188755878};\\\", \\\"{x:1618,y:565,t:1527188755895};\\\", \\\"{x:1619,y:569,t:1527188755913};\\\", \\\"{x:1620,y:572,t:1527188755927};\\\", \\\"{x:1620,y:576,t:1527188755944};\\\", \\\"{x:1621,y:578,t:1527188755961};\\\", \\\"{x:1621,y:579,t:1527188755978};\\\", \\\"{x:1621,y:581,t:1527188755994};\\\", \\\"{x:1622,y:583,t:1527188756011};\\\", \\\"{x:1624,y:588,t:1527188756028};\\\", \\\"{x:1627,y:594,t:1527188756043};\\\", \\\"{x:1628,y:598,t:1527188756061};\\\", \\\"{x:1630,y:603,t:1527188756078};\\\", \\\"{x:1631,y:607,t:1527188756095};\\\", \\\"{x:1635,y:618,t:1527188756111};\\\", \\\"{x:1636,y:627,t:1527188756128};\\\", \\\"{x:1637,y:637,t:1527188756144};\\\", \\\"{x:1639,y:647,t:1527188756162};\\\", \\\"{x:1639,y:658,t:1527188756178};\\\", \\\"{x:1639,y:668,t:1527188756194};\\\", \\\"{x:1639,y:679,t:1527188756211};\\\", \\\"{x:1639,y:693,t:1527188756228};\\\", \\\"{x:1641,y:708,t:1527188756244};\\\", \\\"{x:1642,y:729,t:1527188756261};\\\", \\\"{x:1644,y:745,t:1527188756278};\\\", \\\"{x:1646,y:762,t:1527188756295};\\\", \\\"{x:1646,y:767,t:1527188756311};\\\", \\\"{x:1646,y:771,t:1527188756329};\\\", \\\"{x:1646,y:776,t:1527188756345};\\\", \\\"{x:1646,y:779,t:1527188756361};\\\", \\\"{x:1646,y:783,t:1527188756378};\\\", \\\"{x:1646,y:791,t:1527188756395};\\\", \\\"{x:1646,y:799,t:1527188756411};\\\", \\\"{x:1646,y:806,t:1527188756428};\\\", \\\"{x:1646,y:820,t:1527188756445};\\\", \\\"{x:1646,y:838,t:1527188756461};\\\", \\\"{x:1646,y:853,t:1527188756478};\\\", \\\"{x:1646,y:872,t:1527188756495};\\\", \\\"{x:1646,y:883,t:1527188756510};\\\", \\\"{x:1644,y:890,t:1527188756528};\\\", \\\"{x:1642,y:893,t:1527188756545};\\\", \\\"{x:1640,y:894,t:1527188756561};\\\", \\\"{x:1637,y:893,t:1527188756578};\\\", \\\"{x:1616,y:879,t:1527188756595};\\\", \\\"{x:1565,y:839,t:1527188756611};\\\", \\\"{x:1486,y:797,t:1527188756628};\\\", \\\"{x:1399,y:750,t:1527188756645};\\\", \\\"{x:1321,y:710,t:1527188756661};\\\", \\\"{x:1217,y:673,t:1527188756678};\\\", \\\"{x:1047,y:617,t:1527188756695};\\\", \\\"{x:959,y:592,t:1527188756712};\\\", \\\"{x:905,y:582,t:1527188756729};\\\", \\\"{x:871,y:577,t:1527188756745};\\\", \\\"{x:834,y:572,t:1527188756762};\\\", \\\"{x:798,y:572,t:1527188756778};\\\", \\\"{x:746,y:575,t:1527188756796};\\\", \\\"{x:682,y:582,t:1527188756813};\\\", \\\"{x:615,y:584,t:1527188756827};\\\", \\\"{x:543,y:584,t:1527188756845};\\\", \\\"{x:479,y:584,t:1527188756862};\\\", \\\"{x:426,y:580,t:1527188756878};\\\", \\\"{x:382,y:574,t:1527188756895};\\\", \\\"{x:360,y:574,t:1527188756912};\\\", \\\"{x:345,y:571,t:1527188756928};\\\", \\\"{x:331,y:563,t:1527188756945};\\\", \\\"{x:321,y:559,t:1527188756962};\\\", \\\"{x:313,y:558,t:1527188756978};\\\", \\\"{x:309,y:558,t:1527188756995};\\\", \\\"{x:304,y:559,t:1527188757012};\\\", \\\"{x:301,y:561,t:1527188757028};\\\", \\\"{x:302,y:561,t:1527188757096};\\\", \\\"{x:324,y:564,t:1527188757112};\\\", \\\"{x:348,y:568,t:1527188757129};\\\", \\\"{x:366,y:569,t:1527188757145};\\\", \\\"{x:380,y:570,t:1527188757163};\\\", \\\"{x:389,y:571,t:1527188757180};\\\", \\\"{x:403,y:577,t:1527188757196};\\\", \\\"{x:422,y:584,t:1527188757212};\\\", \\\"{x:446,y:591,t:1527188757229};\\\", \\\"{x:465,y:597,t:1527188757245};\\\", \\\"{x:482,y:603,t:1527188757262};\\\", \\\"{x:506,y:615,t:1527188757280};\\\", \\\"{x:512,y:617,t:1527188757295};\\\", \\\"{x:513,y:619,t:1527188757311};\\\", \\\"{x:515,y:621,t:1527188757330};\\\", \\\"{x:521,y:622,t:1527188757346};\\\", \\\"{x:540,y:625,t:1527188757362};\\\", \\\"{x:563,y:625,t:1527188757379};\\\", \\\"{x:589,y:625,t:1527188757395};\\\", \\\"{x:613,y:623,t:1527188757412};\\\", \\\"{x:638,y:616,t:1527188757430};\\\", \\\"{x:665,y:611,t:1527188757446};\\\", \\\"{x:692,y:606,t:1527188757462};\\\", \\\"{x:727,y:597,t:1527188757480};\\\", \\\"{x:751,y:589,t:1527188757496};\\\", \\\"{x:772,y:587,t:1527188757512};\\\", \\\"{x:789,y:583,t:1527188757529};\\\", \\\"{x:802,y:581,t:1527188757546};\\\", \\\"{x:806,y:578,t:1527188757562};\\\", \\\"{x:808,y:578,t:1527188757579};\\\", \\\"{x:809,y:578,t:1527188757596};\\\", \\\"{x:810,y:577,t:1527188757671};\\\", \\\"{x:811,y:577,t:1527188757679};\\\", \\\"{x:814,y:575,t:1527188757696};\\\", \\\"{x:807,y:577,t:1527188757760};\\\", \\\"{x:797,y:582,t:1527188757767};\\\", \\\"{x:789,y:586,t:1527188757779};\\\", \\\"{x:775,y:591,t:1527188757796};\\\", \\\"{x:762,y:596,t:1527188757812};\\\", \\\"{x:750,y:602,t:1527188757829};\\\", \\\"{x:735,y:609,t:1527188757847};\\\", \\\"{x:726,y:612,t:1527188757864};\\\", \\\"{x:724,y:613,t:1527188757881};\\\", \\\"{x:721,y:614,t:1527188757896};\\\", \\\"{x:719,y:615,t:1527188757913};\\\", \\\"{x:717,y:615,t:1527188757929};\\\", \\\"{x:713,y:617,t:1527188757946};\\\", \\\"{x:707,y:618,t:1527188757963};\\\", \\\"{x:694,y:618,t:1527188757979};\\\", \\\"{x:675,y:618,t:1527188757996};\\\", \\\"{x:657,y:618,t:1527188758013};\\\", \\\"{x:637,y:618,t:1527188758029};\\\", \\\"{x:621,y:618,t:1527188758046};\\\", \\\"{x:587,y:618,t:1527188758063};\\\", \\\"{x:561,y:618,t:1527188758079};\\\", \\\"{x:532,y:618,t:1527188758096};\\\", \\\"{x:507,y:618,t:1527188758113};\\\", \\\"{x:481,y:618,t:1527188758129};\\\", \\\"{x:449,y:619,t:1527188758146};\\\", \\\"{x:418,y:623,t:1527188758164};\\\", \\\"{x:386,y:623,t:1527188758179};\\\", \\\"{x:357,y:624,t:1527188758197};\\\", \\\"{x:335,y:624,t:1527188758213};\\\", \\\"{x:323,y:624,t:1527188758229};\\\", \\\"{x:315,y:624,t:1527188758246};\\\", \\\"{x:307,y:624,t:1527188758263};\\\", \\\"{x:301,y:623,t:1527188758280};\\\", \\\"{x:296,y:620,t:1527188758297};\\\", \\\"{x:289,y:618,t:1527188758314};\\\", \\\"{x:280,y:613,t:1527188758330};\\\", \\\"{x:266,y:608,t:1527188758346};\\\", \\\"{x:257,y:605,t:1527188758363};\\\", \\\"{x:253,y:605,t:1527188758380};\\\", \\\"{x:252,y:605,t:1527188758407};\\\", \\\"{x:250,y:603,t:1527188758423};\\\", \\\"{x:250,y:602,t:1527188758431};\\\", \\\"{x:249,y:601,t:1527188758446};\\\", \\\"{x:246,y:598,t:1527188758462};\\\", \\\"{x:241,y:594,t:1527188758480};\\\", \\\"{x:233,y:592,t:1527188758496};\\\", \\\"{x:221,y:587,t:1527188758513};\\\", \\\"{x:207,y:581,t:1527188758531};\\\", \\\"{x:194,y:579,t:1527188758546};\\\", \\\"{x:180,y:576,t:1527188758563};\\\", \\\"{x:171,y:576,t:1527188758579};\\\", \\\"{x:168,y:576,t:1527188758596};\\\", \\\"{x:167,y:576,t:1527188758613};\\\", \\\"{x:164,y:577,t:1527188758655};\\\", \\\"{x:161,y:582,t:1527188758663};\\\", \\\"{x:159,y:588,t:1527188758679};\\\", \\\"{x:158,y:596,t:1527188758697};\\\", \\\"{x:158,y:601,t:1527188758713};\\\", \\\"{x:157,y:603,t:1527188758730};\\\", \\\"{x:157,y:604,t:1527188758747};\\\", \\\"{x:157,y:605,t:1527188758775};\\\", \\\"{x:157,y:606,t:1527188758783};\\\", \\\"{x:157,y:607,t:1527188758798};\\\", \\\"{x:157,y:608,t:1527188758839};\\\", \\\"{x:157,y:609,t:1527188758847};\\\", \\\"{x:157,y:611,t:1527188758863};\\\", \\\"{x:157,y:612,t:1527188758880};\\\", \\\"{x:157,y:613,t:1527188758898};\\\", \\\"{x:157,y:614,t:1527188758968};\\\", \\\"{x:157,y:616,t:1527188758981};\\\", \\\"{x:157,y:619,t:1527188758998};\\\", \\\"{x:157,y:622,t:1527188759015};\\\", \\\"{x:157,y:623,t:1527188759031};\\\", \\\"{x:157,y:624,t:1527188759104};\\\", \\\"{x:157,y:625,t:1527188759114};\\\", \\\"{x:157,y:626,t:1527188759135};\\\", \\\"{x:157,y:627,t:1527188759147};\\\", \\\"{x:164,y:630,t:1527188759399};\\\", \\\"{x:177,y:635,t:1527188759414};\\\", \\\"{x:214,y:644,t:1527188759430};\\\", \\\"{x:281,y:665,t:1527188759448};\\\", \\\"{x:335,y:681,t:1527188759465};\\\", \\\"{x:399,y:701,t:1527188759480};\\\", \\\"{x:474,y:723,t:1527188759500};\\\", \\\"{x:526,y:734,t:1527188759515};\\\", \\\"{x:560,y:739,t:1527188759530};\\\", \\\"{x:596,y:741,t:1527188759547};\\\", \\\"{x:627,y:745,t:1527188759564};\\\", \\\"{x:649,y:746,t:1527188759581};\\\", \\\"{x:664,y:744,t:1527188759597};\\\", \\\"{x:665,y:744,t:1527188759760};\\\", \\\"{x:663,y:741,t:1527188759768};\\\", \\\"{x:657,y:739,t:1527188759781};\\\", \\\"{x:644,y:733,t:1527188759797};\\\", \\\"{x:632,y:729,t:1527188759814};\\\", \\\"{x:614,y:728,t:1527188759831};\\\", \\\"{x:604,y:724,t:1527188759847};\\\", \\\"{x:597,y:724,t:1527188759864};\\\", \\\"{x:583,y:722,t:1527188759882};\\\", \\\"{x:568,y:720,t:1527188759898};\\\", \\\"{x:556,y:718,t:1527188759915};\\\", \\\"{x:550,y:717,t:1527188759931};\\\", \\\"{x:548,y:717,t:1527188759948};\\\", \\\"{x:546,y:717,t:1527188759964};\\\", \\\"{x:545,y:717,t:1527188760000};\\\", \\\"{x:544,y:717,t:1527188760015};\\\", \\\"{x:553,y:717,t:1527188760335};\\\", \\\"{x:559,y:717,t:1527188760348};\\\", \\\"{x:588,y:717,t:1527188760364};\\\", \\\"{x:623,y:717,t:1527188760381};\\\", \\\"{x:668,y:717,t:1527188760398};\\\", \\\"{x:724,y:717,t:1527188760415};\\\", \\\"{x:827,y:715,t:1527188760432};\\\", \\\"{x:897,y:715,t:1527188760448};\\\", \\\"{x:953,y:715,t:1527188760465};\\\", \\\"{x:998,y:715,t:1527188760481};\\\", \\\"{x:1026,y:715,t:1527188760499};\\\", \\\"{x:1052,y:715,t:1527188760514};\\\", \\\"{x:1071,y:715,t:1527188760532};\\\", \\\"{x:1085,y:715,t:1527188760549};\\\", \\\"{x:1088,y:715,t:1527188760566};\\\" ] }, { \\\"rt\\\": 12870, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 154361, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -10 AM-C -C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1089,y:714,t:1527188761883};\\\", \\\"{x:1089,y:713,t:1527188762007};\\\", \\\"{x:1089,y:712,t:1527188762095};\\\", \\\"{x:1088,y:712,t:1527188762167};\\\", \\\"{x:1093,y:712,t:1527188763904};\\\", \\\"{x:1097,y:712,t:1527188763918};\\\", \\\"{x:1111,y:714,t:1527188763935};\\\", \\\"{x:1128,y:719,t:1527188763951};\\\", \\\"{x:1159,y:727,t:1527188763968};\\\", \\\"{x:1184,y:732,t:1527188763985};\\\", \\\"{x:1208,y:739,t:1527188764001};\\\", \\\"{x:1230,y:746,t:1527188764017};\\\", \\\"{x:1242,y:749,t:1527188764034};\\\", \\\"{x:1248,y:751,t:1527188764050};\\\", \\\"{x:1253,y:752,t:1527188764067};\\\", \\\"{x:1259,y:755,t:1527188764084};\\\", \\\"{x:1264,y:755,t:1527188764100};\\\", \\\"{x:1266,y:756,t:1527188764117};\\\", \\\"{x:1267,y:756,t:1527188764134};\\\", \\\"{x:1269,y:757,t:1527188764150};\\\", \\\"{x:1272,y:761,t:1527188764167};\\\", \\\"{x:1276,y:764,t:1527188764185};\\\", \\\"{x:1279,y:770,t:1527188764202};\\\", \\\"{x:1281,y:772,t:1527188764218};\\\", \\\"{x:1282,y:773,t:1527188764235};\\\", \\\"{x:1282,y:775,t:1527188764251};\\\", \\\"{x:1282,y:776,t:1527188764267};\\\", \\\"{x:1282,y:782,t:1527188764284};\\\", \\\"{x:1282,y:788,t:1527188764302};\\\", \\\"{x:1282,y:795,t:1527188764318};\\\", \\\"{x:1277,y:804,t:1527188764335};\\\", \\\"{x:1268,y:815,t:1527188764351};\\\", \\\"{x:1261,y:819,t:1527188764368};\\\", \\\"{x:1254,y:823,t:1527188764385};\\\", \\\"{x:1249,y:823,t:1527188764401};\\\", \\\"{x:1243,y:823,t:1527188764417};\\\", \\\"{x:1239,y:824,t:1527188764435};\\\", \\\"{x:1235,y:826,t:1527188764451};\\\", \\\"{x:1229,y:827,t:1527188764468};\\\", \\\"{x:1224,y:828,t:1527188764484};\\\", \\\"{x:1215,y:828,t:1527188764503};\\\", \\\"{x:1204,y:830,t:1527188764518};\\\", \\\"{x:1193,y:830,t:1527188764534};\\\", \\\"{x:1186,y:830,t:1527188764551};\\\", \\\"{x:1184,y:830,t:1527188764567};\\\", \\\"{x:1182,y:830,t:1527188764585};\\\", \\\"{x:1181,y:830,t:1527188764602};\\\", \\\"{x:1180,y:830,t:1527188764618};\\\", \\\"{x:1179,y:830,t:1527188764634};\\\", \\\"{x:1178,y:830,t:1527188765408};\\\", \\\"{x:1179,y:830,t:1527188765776};\\\", \\\"{x:1181,y:830,t:1527188765792};\\\", \\\"{x:1182,y:830,t:1527188765803};\\\", \\\"{x:1183,y:830,t:1527188765819};\\\", \\\"{x:1189,y:830,t:1527188765836};\\\", \\\"{x:1196,y:830,t:1527188765853};\\\", \\\"{x:1201,y:830,t:1527188765869};\\\", \\\"{x:1204,y:830,t:1527188765886};\\\", \\\"{x:1207,y:830,t:1527188765903};\\\", \\\"{x:1208,y:830,t:1527188765919};\\\", \\\"{x:1210,y:830,t:1527188765937};\\\", \\\"{x:1211,y:830,t:1527188766016};\\\", \\\"{x:1213,y:830,t:1527188766048};\\\", \\\"{x:1215,y:830,t:1527188766424};\\\", \\\"{x:1217,y:831,t:1527188766436};\\\", \\\"{x:1218,y:835,t:1527188766454};\\\", \\\"{x:1218,y:837,t:1527188766470};\\\", \\\"{x:1219,y:839,t:1527188766486};\\\", \\\"{x:1220,y:842,t:1527188766503};\\\", \\\"{x:1220,y:848,t:1527188766520};\\\", \\\"{x:1221,y:851,t:1527188766536};\\\", \\\"{x:1221,y:854,t:1527188766554};\\\", \\\"{x:1221,y:856,t:1527188766570};\\\", \\\"{x:1221,y:858,t:1527188766586};\\\", \\\"{x:1221,y:861,t:1527188766603};\\\", \\\"{x:1221,y:862,t:1527188766620};\\\", \\\"{x:1221,y:864,t:1527188766637};\\\", \\\"{x:1221,y:869,t:1527188766654};\\\", \\\"{x:1221,y:872,t:1527188766671};\\\", \\\"{x:1221,y:879,t:1527188766687};\\\", \\\"{x:1220,y:886,t:1527188766703};\\\", \\\"{x:1220,y:894,t:1527188766720};\\\", \\\"{x:1219,y:899,t:1527188766737};\\\", \\\"{x:1218,y:905,t:1527188766753};\\\", \\\"{x:1217,y:909,t:1527188766770};\\\", \\\"{x:1216,y:913,t:1527188766787};\\\", \\\"{x:1215,y:916,t:1527188766803};\\\", \\\"{x:1215,y:917,t:1527188766824};\\\", \\\"{x:1215,y:919,t:1527188766839};\\\", \\\"{x:1215,y:921,t:1527188766853};\\\", \\\"{x:1215,y:926,t:1527188766870};\\\", \\\"{x:1216,y:931,t:1527188766887};\\\", \\\"{x:1217,y:939,t:1527188766903};\\\", \\\"{x:1217,y:948,t:1527188766920};\\\", \\\"{x:1217,y:952,t:1527188766937};\\\", \\\"{x:1217,y:957,t:1527188766952};\\\", \\\"{x:1217,y:960,t:1527188766970};\\\", \\\"{x:1218,y:965,t:1527188766987};\\\", \\\"{x:1218,y:967,t:1527188767002};\\\", \\\"{x:1218,y:969,t:1527188767020};\\\", \\\"{x:1220,y:970,t:1527188767037};\\\", \\\"{x:1220,y:974,t:1527188767053};\\\", \\\"{x:1220,y:975,t:1527188767069};\\\", \\\"{x:1220,y:976,t:1527188767086};\\\", \\\"{x:1220,y:977,t:1527188767103};\\\", \\\"{x:1220,y:974,t:1527188767279};\\\", \\\"{x:1220,y:969,t:1527188767287};\\\", \\\"{x:1220,y:957,t:1527188767304};\\\", \\\"{x:1220,y:950,t:1527188767320};\\\", \\\"{x:1220,y:944,t:1527188767338};\\\", \\\"{x:1220,y:942,t:1527188767354};\\\", \\\"{x:1220,y:938,t:1527188767370};\\\", \\\"{x:1220,y:930,t:1527188767387};\\\", \\\"{x:1220,y:921,t:1527188767404};\\\", \\\"{x:1220,y:914,t:1527188767420};\\\", \\\"{x:1220,y:908,t:1527188767437};\\\", \\\"{x:1220,y:902,t:1527188767454};\\\", \\\"{x:1220,y:897,t:1527188767470};\\\", \\\"{x:1220,y:889,t:1527188767487};\\\", \\\"{x:1220,y:875,t:1527188767503};\\\", \\\"{x:1219,y:867,t:1527188767520};\\\", \\\"{x:1219,y:859,t:1527188767537};\\\", \\\"{x:1218,y:850,t:1527188767554};\\\", \\\"{x:1216,y:842,t:1527188767570};\\\", \\\"{x:1215,y:835,t:1527188767588};\\\", \\\"{x:1215,y:834,t:1527188767604};\\\", \\\"{x:1215,y:832,t:1527188767621};\\\", \\\"{x:1215,y:831,t:1527188767656};\\\", \\\"{x:1214,y:829,t:1527188767671};\\\", \\\"{x:1214,y:828,t:1527188767687};\\\", \\\"{x:1214,y:826,t:1527188767711};\\\", \\\"{x:1214,y:825,t:1527188769400};\\\", \\\"{x:1217,y:824,t:1527188769409};\\\", \\\"{x:1220,y:821,t:1527188769422};\\\", \\\"{x:1225,y:820,t:1527188769437};\\\", \\\"{x:1231,y:817,t:1527188769455};\\\", \\\"{x:1235,y:816,t:1527188769471};\\\", \\\"{x:1236,y:814,t:1527188769488};\\\", \\\"{x:1237,y:814,t:1527188769505};\\\", \\\"{x:1239,y:814,t:1527188769522};\\\", \\\"{x:1241,y:814,t:1527188769538};\\\", \\\"{x:1242,y:813,t:1527188769554};\\\", \\\"{x:1246,y:812,t:1527188769571};\\\", \\\"{x:1249,y:812,t:1527188769589};\\\", \\\"{x:1255,y:812,t:1527188769605};\\\", \\\"{x:1261,y:812,t:1527188769622};\\\", \\\"{x:1271,y:816,t:1527188769640};\\\", \\\"{x:1275,y:816,t:1527188769655};\\\", \\\"{x:1278,y:819,t:1527188769672};\\\", \\\"{x:1280,y:820,t:1527188769689};\\\", \\\"{x:1282,y:822,t:1527188769705};\\\", \\\"{x:1285,y:824,t:1527188769722};\\\", \\\"{x:1287,y:826,t:1527188769739};\\\", \\\"{x:1286,y:826,t:1527188770080};\\\", \\\"{x:1286,y:827,t:1527188770096};\\\", \\\"{x:1285,y:827,t:1527188770122};\\\", \\\"{x:1284,y:828,t:1527188770159};\\\", \\\"{x:1283,y:828,t:1527188770172};\\\", \\\"{x:1283,y:829,t:1527188770189};\\\", \\\"{x:1281,y:829,t:1527188770206};\\\", \\\"{x:1280,y:831,t:1527188770223};\\\", \\\"{x:1279,y:831,t:1527188770247};\\\", \\\"{x:1278,y:831,t:1527188770264};\\\", \\\"{x:1277,y:832,t:1527188770279};\\\", \\\"{x:1276,y:832,t:1527188770319};\\\", \\\"{x:1275,y:833,t:1527188770345};\\\", \\\"{x:1274,y:833,t:1527188770367};\\\", \\\"{x:1273,y:833,t:1527188770400};\\\", \\\"{x:1272,y:834,t:1527188770519};\\\", \\\"{x:1265,y:833,t:1527188772304};\\\", \\\"{x:1252,y:825,t:1527188772312};\\\", \\\"{x:1232,y:813,t:1527188772325};\\\", \\\"{x:1169,y:784,t:1527188772340};\\\", \\\"{x:1081,y:747,t:1527188772358};\\\", \\\"{x:982,y:709,t:1527188772374};\\\", \\\"{x:890,y:682,t:1527188772391};\\\", \\\"{x:754,y:641,t:1527188772407};\\\", \\\"{x:663,y:613,t:1527188772424};\\\", \\\"{x:577,y:591,t:1527188772441};\\\", \\\"{x:519,y:576,t:1527188772457};\\\", \\\"{x:480,y:570,t:1527188772491};\\\", \\\"{x:473,y:569,t:1527188772508};\\\", \\\"{x:457,y:566,t:1527188772525};\\\", \\\"{x:437,y:561,t:1527188772542};\\\", \\\"{x:423,y:559,t:1527188772557};\\\", \\\"{x:404,y:558,t:1527188772575};\\\", \\\"{x:391,y:558,t:1527188772591};\\\", \\\"{x:376,y:558,t:1527188772608};\\\", \\\"{x:358,y:558,t:1527188772625};\\\", \\\"{x:339,y:558,t:1527188772642};\\\", \\\"{x:331,y:559,t:1527188772658};\\\", \\\"{x:326,y:561,t:1527188772674};\\\", \\\"{x:320,y:561,t:1527188772692};\\\", \\\"{x:314,y:561,t:1527188772708};\\\", \\\"{x:306,y:562,t:1527188772725};\\\", \\\"{x:298,y:562,t:1527188772742};\\\", \\\"{x:284,y:562,t:1527188772758};\\\", \\\"{x:259,y:562,t:1527188772775};\\\", \\\"{x:247,y:557,t:1527188772792};\\\", \\\"{x:244,y:555,t:1527188772808};\\\", \\\"{x:244,y:554,t:1527188772825};\\\", \\\"{x:244,y:552,t:1527188772841};\\\", \\\"{x:247,y:547,t:1527188772857};\\\", \\\"{x:253,y:544,t:1527188772875};\\\", \\\"{x:268,y:539,t:1527188772893};\\\", \\\"{x:287,y:531,t:1527188772909};\\\", \\\"{x:302,y:524,t:1527188772924};\\\", \\\"{x:308,y:521,t:1527188772941};\\\", \\\"{x:313,y:519,t:1527188772959};\\\", \\\"{x:315,y:518,t:1527188772975};\\\", \\\"{x:317,y:518,t:1527188772992};\\\", \\\"{x:322,y:518,t:1527188773009};\\\", \\\"{x:330,y:518,t:1527188773025};\\\", \\\"{x:338,y:518,t:1527188773042};\\\", \\\"{x:341,y:518,t:1527188773059};\\\", \\\"{x:342,y:517,t:1527188773075};\\\", \\\"{x:343,y:516,t:1527188773092};\\\", \\\"{x:345,y:516,t:1527188773109};\\\", \\\"{x:353,y:516,t:1527188773124};\\\", \\\"{x:360,y:516,t:1527188773142};\\\", \\\"{x:365,y:516,t:1527188773159};\\\", \\\"{x:367,y:515,t:1527188773175};\\\", \\\"{x:369,y:514,t:1527188773192};\\\", \\\"{x:370,y:514,t:1527188773223};\\\", \\\"{x:372,y:514,t:1527188773232};\\\", \\\"{x:372,y:513,t:1527188773242};\\\", \\\"{x:375,y:512,t:1527188773260};\\\", \\\"{x:378,y:512,t:1527188773275};\\\", \\\"{x:380,y:511,t:1527188773292};\\\", \\\"{x:381,y:511,t:1527188773334};\\\", \\\"{x:382,y:511,t:1527188773623};\\\", \\\"{x:388,y:512,t:1527188773632};\\\", \\\"{x:393,y:523,t:1527188773642};\\\", \\\"{x:419,y:553,t:1527188773660};\\\", \\\"{x:449,y:588,t:1527188773677};\\\", \\\"{x:489,y:629,t:1527188773693};\\\", \\\"{x:520,y:657,t:1527188773710};\\\", \\\"{x:554,y:688,t:1527188773726};\\\", \\\"{x:573,y:706,t:1527188773742};\\\", \\\"{x:599,y:728,t:1527188773759};\\\", \\\"{x:607,y:736,t:1527188773776};\\\", \\\"{x:604,y:736,t:1527188773983};\\\", \\\"{x:599,y:735,t:1527188773993};\\\", \\\"{x:590,y:730,t:1527188774009};\\\", \\\"{x:579,y:725,t:1527188774026};\\\", \\\"{x:571,y:722,t:1527188774043};\\\", \\\"{x:563,y:718,t:1527188774060};\\\", \\\"{x:557,y:715,t:1527188774076};\\\", \\\"{x:555,y:714,t:1527188774092};\\\", \\\"{x:554,y:713,t:1527188774108};\\\", \\\"{x:550,y:712,t:1527188774126};\\\", \\\"{x:552,y:709,t:1527188774519};\\\", \\\"{x:562,y:706,t:1527188774527};\\\", \\\"{x:576,y:700,t:1527188774543};\\\", \\\"{x:586,y:695,t:1527188774559};\\\", \\\"{x:594,y:692,t:1527188774576};\\\", \\\"{x:594,y:691,t:1527188775224};\\\" ] }, { \\\"rt\\\": 55995, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 211636, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -04 PM-04 PM-E -01 PM-01 PM-Z -Z -Z -Z -O -O -I -I -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:595,y:691,t:1527188776792};\\\", \\\"{x:608,y:694,t:1527188776809};\\\", \\\"{x:614,y:696,t:1527188776814};\\\", \\\"{x:620,y:696,t:1527188776828};\\\", \\\"{x:640,y:699,t:1527188776845};\\\", \\\"{x:671,y:707,t:1527188776861};\\\", \\\"{x:700,y:715,t:1527188776878};\\\", \\\"{x:750,y:726,t:1527188776895};\\\", \\\"{x:782,y:734,t:1527188776912};\\\", \\\"{x:809,y:738,t:1527188776928};\\\", \\\"{x:838,y:744,t:1527188776945};\\\", \\\"{x:864,y:746,t:1527188776962};\\\", \\\"{x:884,y:750,t:1527188776978};\\\", \\\"{x:905,y:753,t:1527188776995};\\\", \\\"{x:926,y:756,t:1527188777012};\\\", \\\"{x:944,y:762,t:1527188777028};\\\", \\\"{x:961,y:764,t:1527188777045};\\\", \\\"{x:982,y:768,t:1527188777063};\\\", \\\"{x:1004,y:773,t:1527188777078};\\\", \\\"{x:1041,y:778,t:1527188777095};\\\", \\\"{x:1069,y:782,t:1527188777113};\\\", \\\"{x:1096,y:785,t:1527188777129};\\\", \\\"{x:1132,y:790,t:1527188777146};\\\", \\\"{x:1159,y:795,t:1527188777163};\\\", \\\"{x:1181,y:797,t:1527188777178};\\\", \\\"{x:1206,y:801,t:1527188777195};\\\", \\\"{x:1228,y:803,t:1527188777212};\\\", \\\"{x:1248,y:808,t:1527188777229};\\\", \\\"{x:1264,y:809,t:1527188777246};\\\", \\\"{x:1281,y:812,t:1527188777263};\\\", \\\"{x:1297,y:817,t:1527188777279};\\\", \\\"{x:1319,y:822,t:1527188777295};\\\", \\\"{x:1330,y:824,t:1527188777312};\\\", \\\"{x:1337,y:825,t:1527188777328};\\\", \\\"{x:1340,y:827,t:1527188777345};\\\", \\\"{x:1343,y:827,t:1527188777362};\\\", \\\"{x:1344,y:828,t:1527188777383};\\\", \\\"{x:1345,y:828,t:1527188777395};\\\", \\\"{x:1346,y:829,t:1527188777423};\\\", \\\"{x:1346,y:830,t:1527188777480};\\\", \\\"{x:1346,y:832,t:1527188777496};\\\", \\\"{x:1346,y:833,t:1527188777519};\\\", \\\"{x:1346,y:835,t:1527188777536};\\\", \\\"{x:1345,y:837,t:1527188777552};\\\", \\\"{x:1343,y:841,t:1527188777567};\\\", \\\"{x:1343,y:844,t:1527188777580};\\\", \\\"{x:1341,y:850,t:1527188777596};\\\", \\\"{x:1340,y:857,t:1527188777612};\\\", \\\"{x:1339,y:861,t:1527188777629};\\\", \\\"{x:1337,y:866,t:1527188777646};\\\", \\\"{x:1336,y:872,t:1527188777662};\\\", \\\"{x:1332,y:884,t:1527188777680};\\\", \\\"{x:1328,y:892,t:1527188777696};\\\", \\\"{x:1327,y:895,t:1527188777713};\\\", \\\"{x:1325,y:899,t:1527188777729};\\\", \\\"{x:1324,y:900,t:1527188777746};\\\", \\\"{x:1323,y:901,t:1527188777762};\\\", \\\"{x:1323,y:903,t:1527188777779};\\\", \\\"{x:1322,y:904,t:1527188777795};\\\", \\\"{x:1321,y:904,t:1527188777812};\\\", \\\"{x:1321,y:906,t:1527188777829};\\\", \\\"{x:1320,y:907,t:1527188777847};\\\", \\\"{x:1318,y:910,t:1527188777863};\\\", \\\"{x:1316,y:913,t:1527188777880};\\\", \\\"{x:1315,y:915,t:1527188777896};\\\", \\\"{x:1314,y:917,t:1527188777913};\\\", \\\"{x:1314,y:918,t:1527188777930};\\\", \\\"{x:1317,y:919,t:1527188778120};\\\", \\\"{x:1322,y:920,t:1527188778129};\\\", \\\"{x:1335,y:924,t:1527188778148};\\\", \\\"{x:1355,y:926,t:1527188778162};\\\", \\\"{x:1376,y:932,t:1527188778179};\\\", \\\"{x:1394,y:937,t:1527188778196};\\\", \\\"{x:1415,y:941,t:1527188778212};\\\", \\\"{x:1437,y:943,t:1527188778229};\\\", \\\"{x:1460,y:947,t:1527188778246};\\\", \\\"{x:1498,y:954,t:1527188778262};\\\", \\\"{x:1516,y:957,t:1527188778279};\\\", \\\"{x:1528,y:957,t:1527188778296};\\\", \\\"{x:1538,y:957,t:1527188778312};\\\", \\\"{x:1548,y:957,t:1527188778329};\\\", \\\"{x:1561,y:955,t:1527188778346};\\\", \\\"{x:1572,y:954,t:1527188778364};\\\", \\\"{x:1580,y:951,t:1527188778379};\\\", \\\"{x:1585,y:950,t:1527188778397};\\\", \\\"{x:1592,y:947,t:1527188778413};\\\", \\\"{x:1597,y:947,t:1527188778430};\\\", \\\"{x:1600,y:946,t:1527188778446};\\\", \\\"{x:1604,y:944,t:1527188778463};\\\", \\\"{x:1605,y:944,t:1527188778487};\\\", \\\"{x:1606,y:944,t:1527188778496};\\\", \\\"{x:1607,y:944,t:1527188778728};\\\", \\\"{x:1607,y:945,t:1527188778735};\\\", \\\"{x:1608,y:947,t:1527188778751};\\\", \\\"{x:1608,y:948,t:1527188778776};\\\", \\\"{x:1608,y:949,t:1527188778784};\\\", \\\"{x:1608,y:950,t:1527188778797};\\\", \\\"{x:1608,y:953,t:1527188778816};\\\", \\\"{x:1609,y:954,t:1527188778831};\\\", \\\"{x:1610,y:955,t:1527188778847};\\\", \\\"{x:1610,y:956,t:1527188778864};\\\", \\\"{x:1610,y:957,t:1527188778880};\\\", \\\"{x:1611,y:959,t:1527188778897};\\\", \\\"{x:1611,y:961,t:1527188778914};\\\", \\\"{x:1611,y:960,t:1527188779216};\\\", \\\"{x:1611,y:959,t:1527188779304};\\\", \\\"{x:1611,y:958,t:1527188779314};\\\", \\\"{x:1611,y:957,t:1527188779331};\\\", \\\"{x:1611,y:953,t:1527188779349};\\\", \\\"{x:1611,y:950,t:1527188779363};\\\", \\\"{x:1610,y:946,t:1527188779380};\\\", \\\"{x:1610,y:944,t:1527188779398};\\\", \\\"{x:1610,y:943,t:1527188779413};\\\", \\\"{x:1610,y:941,t:1527188779431};\\\", \\\"{x:1609,y:941,t:1527188779447};\\\", \\\"{x:1609,y:939,t:1527188779464};\\\", \\\"{x:1608,y:938,t:1527188779480};\\\", \\\"{x:1608,y:936,t:1527188779497};\\\", \\\"{x:1607,y:934,t:1527188779514};\\\", \\\"{x:1607,y:933,t:1527188779536};\\\", \\\"{x:1606,y:933,t:1527188779548};\\\", \\\"{x:1605,y:931,t:1527188779564};\\\", \\\"{x:1605,y:929,t:1527188779592};\\\", \\\"{x:1605,y:928,t:1527188779600};\\\", \\\"{x:1604,y:927,t:1527188779615};\\\", \\\"{x:1603,y:926,t:1527188779631};\\\", \\\"{x:1603,y:925,t:1527188779648};\\\", \\\"{x:1603,y:924,t:1527188779672};\\\", \\\"{x:1602,y:924,t:1527188779681};\\\", \\\"{x:1601,y:922,t:1527188779697};\\\", \\\"{x:1600,y:921,t:1527188779714};\\\", \\\"{x:1600,y:918,t:1527188779731};\\\", \\\"{x:1600,y:916,t:1527188779748};\\\", \\\"{x:1599,y:915,t:1527188779765};\\\", \\\"{x:1597,y:910,t:1527188779781};\\\", \\\"{x:1597,y:909,t:1527188779797};\\\", \\\"{x:1596,y:907,t:1527188779815};\\\", \\\"{x:1596,y:906,t:1527188779830};\\\", \\\"{x:1596,y:905,t:1527188779863};\\\", \\\"{x:1595,y:905,t:1527188779880};\\\", \\\"{x:1594,y:904,t:1527188779903};\\\", \\\"{x:1594,y:899,t:1527188780920};\\\", \\\"{x:1593,y:894,t:1527188780932};\\\", \\\"{x:1590,y:888,t:1527188780949};\\\", \\\"{x:1590,y:884,t:1527188780965};\\\", \\\"{x:1589,y:881,t:1527188780982};\\\", \\\"{x:1588,y:879,t:1527188780999};\\\", \\\"{x:1588,y:878,t:1527188781015};\\\", \\\"{x:1588,y:876,t:1527188781072};\\\", \\\"{x:1588,y:875,t:1527188781082};\\\", \\\"{x:1587,y:874,t:1527188781098};\\\", \\\"{x:1586,y:874,t:1527188781115};\\\", \\\"{x:1586,y:873,t:1527188781159};\\\", \\\"{x:1585,y:872,t:1527188781239};\\\", \\\"{x:1585,y:871,t:1527188782328};\\\", \\\"{x:1584,y:869,t:1527188782335};\\\", \\\"{x:1583,y:868,t:1527188782350};\\\", \\\"{x:1583,y:867,t:1527188782367};\\\", \\\"{x:1583,y:866,t:1527188782382};\\\", \\\"{x:1583,y:864,t:1527188782399};\\\", \\\"{x:1583,y:863,t:1527188782416};\\\", \\\"{x:1582,y:862,t:1527188782432};\\\", \\\"{x:1580,y:859,t:1527188782449};\\\", \\\"{x:1579,y:857,t:1527188782466};\\\", \\\"{x:1579,y:856,t:1527188782482};\\\", \\\"{x:1578,y:855,t:1527188782936};\\\", \\\"{x:1577,y:855,t:1527188783240};\\\", \\\"{x:1576,y:857,t:1527188783255};\\\", \\\"{x:1575,y:860,t:1527188783267};\\\", \\\"{x:1575,y:864,t:1527188783284};\\\", \\\"{x:1575,y:868,t:1527188783300};\\\", \\\"{x:1575,y:876,t:1527188783317};\\\", \\\"{x:1575,y:882,t:1527188783334};\\\", \\\"{x:1577,y:891,t:1527188783351};\\\", \\\"{x:1578,y:897,t:1527188783366};\\\", \\\"{x:1581,y:909,t:1527188783384};\\\", \\\"{x:1586,y:921,t:1527188783401};\\\", \\\"{x:1588,y:931,t:1527188783417};\\\", \\\"{x:1592,y:939,t:1527188783434};\\\", \\\"{x:1593,y:947,t:1527188783451};\\\", \\\"{x:1594,y:950,t:1527188783467};\\\", \\\"{x:1597,y:957,t:1527188783483};\\\", \\\"{x:1600,y:961,t:1527188783501};\\\", \\\"{x:1601,y:962,t:1527188783517};\\\", \\\"{x:1602,y:962,t:1527188783533};\\\", \\\"{x:1603,y:962,t:1527188783551};\\\", \\\"{x:1605,y:962,t:1527188783568};\\\", \\\"{x:1611,y:962,t:1527188783584};\\\", \\\"{x:1620,y:961,t:1527188783601};\\\", \\\"{x:1629,y:958,t:1527188783618};\\\", \\\"{x:1635,y:955,t:1527188783634};\\\", \\\"{x:1637,y:955,t:1527188783651};\\\", \\\"{x:1637,y:954,t:1527188783668};\\\", \\\"{x:1636,y:954,t:1527188783832};\\\", \\\"{x:1633,y:954,t:1527188783839};\\\", \\\"{x:1631,y:954,t:1527188783851};\\\", \\\"{x:1628,y:952,t:1527188783868};\\\", \\\"{x:1625,y:952,t:1527188783884};\\\", \\\"{x:1621,y:952,t:1527188783901};\\\", \\\"{x:1619,y:952,t:1527188783918};\\\", \\\"{x:1616,y:952,t:1527188783934};\\\", \\\"{x:1613,y:952,t:1527188783950};\\\", \\\"{x:1611,y:952,t:1527188783968};\\\", \\\"{x:1608,y:952,t:1527188784496};\\\", \\\"{x:1605,y:952,t:1527188784503};\\\", \\\"{x:1604,y:952,t:1527188784518};\\\", \\\"{x:1601,y:952,t:1527188784535};\\\", \\\"{x:1599,y:952,t:1527188784552};\\\", \\\"{x:1598,y:951,t:1527188784752};\\\", \\\"{x:1602,y:948,t:1527188784768};\\\", \\\"{x:1604,y:948,t:1527188784785};\\\", \\\"{x:1606,y:948,t:1527188784802};\\\", \\\"{x:1607,y:948,t:1527188784819};\\\", \\\"{x:1609,y:948,t:1527188784835};\\\", \\\"{x:1610,y:948,t:1527188784912};\\\", \\\"{x:1612,y:948,t:1527188784920};\\\", \\\"{x:1614,y:948,t:1527188784935};\\\", \\\"{x:1618,y:948,t:1527188784952};\\\", \\\"{x:1619,y:948,t:1527188784969};\\\", \\\"{x:1620,y:949,t:1527188784985};\\\", \\\"{x:1620,y:947,t:1527188785192};\\\", \\\"{x:1620,y:941,t:1527188785202};\\\", \\\"{x:1620,y:929,t:1527188785219};\\\", \\\"{x:1620,y:921,t:1527188785234};\\\", \\\"{x:1620,y:911,t:1527188785251};\\\", \\\"{x:1620,y:905,t:1527188785269};\\\", \\\"{x:1618,y:897,t:1527188785285};\\\", \\\"{x:1618,y:894,t:1527188785302};\\\", \\\"{x:1617,y:891,t:1527188785320};\\\", \\\"{x:1616,y:887,t:1527188785335};\\\", \\\"{x:1614,y:882,t:1527188785352};\\\", \\\"{x:1613,y:878,t:1527188785368};\\\", \\\"{x:1611,y:874,t:1527188785385};\\\", \\\"{x:1609,y:870,t:1527188785401};\\\", \\\"{x:1606,y:867,t:1527188785418};\\\", \\\"{x:1606,y:865,t:1527188785435};\\\", \\\"{x:1604,y:861,t:1527188785451};\\\", \\\"{x:1601,y:856,t:1527188785469};\\\", \\\"{x:1599,y:853,t:1527188785486};\\\", \\\"{x:1598,y:852,t:1527188785502};\\\", \\\"{x:1598,y:855,t:1527188785720};\\\", \\\"{x:1598,y:869,t:1527188785735};\\\", \\\"{x:1598,y:886,t:1527188785751};\\\", \\\"{x:1600,y:897,t:1527188785768};\\\", \\\"{x:1601,y:903,t:1527188785785};\\\", \\\"{x:1602,y:910,t:1527188785803};\\\", \\\"{x:1602,y:918,t:1527188785819};\\\", \\\"{x:1604,y:926,t:1527188785835};\\\", \\\"{x:1606,y:934,t:1527188785852};\\\", \\\"{x:1607,y:939,t:1527188785868};\\\", \\\"{x:1607,y:943,t:1527188785885};\\\", \\\"{x:1608,y:948,t:1527188785903};\\\", \\\"{x:1608,y:949,t:1527188785919};\\\", \\\"{x:1609,y:953,t:1527188785936};\\\", \\\"{x:1610,y:959,t:1527188785953};\\\", \\\"{x:1610,y:963,t:1527188785969};\\\", \\\"{x:1610,y:966,t:1527188785986};\\\", \\\"{x:1612,y:970,t:1527188786003};\\\", \\\"{x:1614,y:975,t:1527188786019};\\\", \\\"{x:1616,y:981,t:1527188786035};\\\", \\\"{x:1616,y:983,t:1527188786053};\\\", \\\"{x:1617,y:983,t:1527188786069};\\\", \\\"{x:1617,y:984,t:1527188786086};\\\", \\\"{x:1617,y:985,t:1527188786121};\\\", \\\"{x:1617,y:982,t:1527188786224};\\\", \\\"{x:1617,y:976,t:1527188786236};\\\", \\\"{x:1617,y:965,t:1527188786254};\\\", \\\"{x:1617,y:957,t:1527188786269};\\\", \\\"{x:1617,y:954,t:1527188786286};\\\", \\\"{x:1617,y:952,t:1527188786303};\\\", \\\"{x:1617,y:951,t:1527188786319};\\\", \\\"{x:1617,y:950,t:1527188786336};\\\", \\\"{x:1617,y:949,t:1527188786353};\\\", \\\"{x:1617,y:948,t:1527188786369};\\\", \\\"{x:1617,y:945,t:1527188786386};\\\", \\\"{x:1617,y:944,t:1527188786403};\\\", \\\"{x:1617,y:942,t:1527188786420};\\\", \\\"{x:1617,y:939,t:1527188786436};\\\", \\\"{x:1617,y:936,t:1527188786453};\\\", \\\"{x:1617,y:932,t:1527188786470};\\\", \\\"{x:1617,y:928,t:1527188786486};\\\", \\\"{x:1617,y:921,t:1527188786503};\\\", \\\"{x:1617,y:919,t:1527188786520};\\\", \\\"{x:1616,y:914,t:1527188786535};\\\", \\\"{x:1616,y:911,t:1527188786552};\\\", \\\"{x:1616,y:907,t:1527188786569};\\\", \\\"{x:1616,y:901,t:1527188786585};\\\", \\\"{x:1615,y:891,t:1527188786602};\\\", \\\"{x:1614,y:881,t:1527188786619};\\\", \\\"{x:1612,y:873,t:1527188786635};\\\", \\\"{x:1610,y:865,t:1527188786652};\\\", \\\"{x:1609,y:858,t:1527188786669};\\\", \\\"{x:1608,y:853,t:1527188786686};\\\", \\\"{x:1606,y:848,t:1527188786703};\\\", \\\"{x:1606,y:844,t:1527188786720};\\\", \\\"{x:1605,y:839,t:1527188786737};\\\", \\\"{x:1604,y:836,t:1527188786752};\\\", \\\"{x:1604,y:833,t:1527188786770};\\\", \\\"{x:1604,y:831,t:1527188786787};\\\", \\\"{x:1604,y:826,t:1527188786803};\\\", \\\"{x:1604,y:819,t:1527188786820};\\\", \\\"{x:1605,y:814,t:1527188786837};\\\", \\\"{x:1605,y:812,t:1527188786853};\\\", \\\"{x:1605,y:811,t:1527188786879};\\\", \\\"{x:1607,y:806,t:1527188786887};\\\", \\\"{x:1607,y:793,t:1527188786902};\\\", \\\"{x:1607,y:790,t:1527188786920};\\\", \\\"{x:1607,y:789,t:1527188786937};\\\", \\\"{x:1607,y:787,t:1527188786953};\\\", \\\"{x:1607,y:786,t:1527188786970};\\\", \\\"{x:1607,y:785,t:1527188786991};\\\", \\\"{x:1607,y:784,t:1527188787003};\\\", \\\"{x:1607,y:780,t:1527188787020};\\\", \\\"{x:1607,y:776,t:1527188787036};\\\", \\\"{x:1607,y:773,t:1527188787053};\\\", \\\"{x:1607,y:769,t:1527188787070};\\\", \\\"{x:1607,y:767,t:1527188787087};\\\", \\\"{x:1607,y:766,t:1527188787103};\\\", \\\"{x:1607,y:764,t:1527188787120};\\\", \\\"{x:1607,y:761,t:1527188787137};\\\", \\\"{x:1607,y:757,t:1527188787152};\\\", \\\"{x:1607,y:752,t:1527188787170};\\\", \\\"{x:1608,y:749,t:1527188787187};\\\", \\\"{x:1609,y:745,t:1527188787204};\\\", \\\"{x:1611,y:741,t:1527188787220};\\\", \\\"{x:1612,y:736,t:1527188787237};\\\", \\\"{x:1612,y:731,t:1527188787254};\\\", \\\"{x:1613,y:724,t:1527188787270};\\\", \\\"{x:1614,y:713,t:1527188787287};\\\", \\\"{x:1615,y:708,t:1527188787303};\\\", \\\"{x:1617,y:702,t:1527188787320};\\\", \\\"{x:1617,y:699,t:1527188787337};\\\", \\\"{x:1618,y:692,t:1527188787354};\\\", \\\"{x:1618,y:686,t:1527188787369};\\\", \\\"{x:1618,y:679,t:1527188787387};\\\", \\\"{x:1618,y:672,t:1527188787403};\\\", \\\"{x:1618,y:667,t:1527188787420};\\\", \\\"{x:1618,y:661,t:1527188787436};\\\", \\\"{x:1618,y:656,t:1527188787454};\\\", \\\"{x:1617,y:650,t:1527188787469};\\\", \\\"{x:1617,y:644,t:1527188787486};\\\", \\\"{x:1615,y:639,t:1527188787504};\\\", \\\"{x:1613,y:634,t:1527188787519};\\\", \\\"{x:1612,y:631,t:1527188787537};\\\", \\\"{x:1612,y:627,t:1527188787553};\\\", \\\"{x:1612,y:623,t:1527188787570};\\\", \\\"{x:1611,y:618,t:1527188787586};\\\", \\\"{x:1610,y:612,t:1527188787604};\\\", \\\"{x:1609,y:607,t:1527188787621};\\\", \\\"{x:1607,y:603,t:1527188787637};\\\", \\\"{x:1607,y:599,t:1527188787654};\\\", \\\"{x:1606,y:597,t:1527188787671};\\\", \\\"{x:1605,y:595,t:1527188787687};\\\", \\\"{x:1603,y:593,t:1527188787704};\\\", \\\"{x:1603,y:590,t:1527188787720};\\\", \\\"{x:1603,y:588,t:1527188787736};\\\", \\\"{x:1603,y:587,t:1527188787754};\\\", \\\"{x:1603,y:585,t:1527188787771};\\\", \\\"{x:1603,y:584,t:1527188787800};\\\", \\\"{x:1603,y:582,t:1527188787847};\\\", \\\"{x:1603,y:581,t:1527188787871};\\\", \\\"{x:1603,y:580,t:1527188787904};\\\", \\\"{x:1604,y:579,t:1527188787921};\\\", \\\"{x:1605,y:578,t:1527188787938};\\\", \\\"{x:1607,y:577,t:1527188787960};\\\", \\\"{x:1608,y:575,t:1527188787976};\\\", \\\"{x:1609,y:575,t:1527188788024};\\\", \\\"{x:1610,y:574,t:1527188788088};\\\", \\\"{x:1612,y:574,t:1527188788432};\\\", \\\"{x:1613,y:572,t:1527188788440};\\\", \\\"{x:1614,y:571,t:1527188788454};\\\", \\\"{x:1616,y:571,t:1527188788471};\\\", \\\"{x:1617,y:570,t:1527188788648};\\\", \\\"{x:1617,y:569,t:1527188788712};\\\", \\\"{x:1617,y:568,t:1527188788730};\\\", \\\"{x:1617,y:567,t:1527188788766};\\\", \\\"{x:1617,y:566,t:1527188788815};\\\", \\\"{x:1617,y:565,t:1527188790895};\\\", \\\"{x:1617,y:564,t:1527188790911};\\\", \\\"{x:1616,y:562,t:1527188790923};\\\", \\\"{x:1615,y:562,t:1527188790944};\\\", \\\"{x:1614,y:562,t:1527188791040};\\\", \\\"{x:1607,y:562,t:1527188810904};\\\", \\\"{x:1562,y:572,t:1527188810921};\\\", \\\"{x:1501,y:587,t:1527188810938};\\\", \\\"{x:1386,y:609,t:1527188810955};\\\", \\\"{x:1248,y:631,t:1527188810971};\\\", \\\"{x:1077,y:651,t:1527188810988};\\\", \\\"{x:905,y:653,t:1527188811005};\\\", \\\"{x:722,y:649,t:1527188811022};\\\", \\\"{x:437,y:618,t:1527188811037};\\\", \\\"{x:122,y:572,t:1527188811072};\\\", \\\"{x:24,y:558,t:1527188811089};\\\", \\\"{x:0,y:550,t:1527188811104};\\\", \\\"{x:0,y:546,t:1527188811121};\\\", \\\"{x:1,y:547,t:1527188811221};\\\", \\\"{x:14,y:554,t:1527188811238};\\\", \\\"{x:27,y:559,t:1527188811255};\\\", \\\"{x:46,y:564,t:1527188811272};\\\", \\\"{x:75,y:564,t:1527188811289};\\\", \\\"{x:109,y:564,t:1527188811305};\\\", \\\"{x:141,y:564,t:1527188811321};\\\", \\\"{x:174,y:564,t:1527188811339};\\\", \\\"{x:220,y:571,t:1527188811355};\\\", \\\"{x:254,y:576,t:1527188811371};\\\", \\\"{x:287,y:581,t:1527188811388};\\\", \\\"{x:325,y:591,t:1527188811406};\\\", \\\"{x:347,y:595,t:1527188811421};\\\", \\\"{x:366,y:598,t:1527188811438};\\\", \\\"{x:374,y:599,t:1527188811456};\\\", \\\"{x:382,y:599,t:1527188811472};\\\", \\\"{x:389,y:601,t:1527188811488};\\\", \\\"{x:402,y:604,t:1527188811505};\\\", \\\"{x:415,y:608,t:1527188811522};\\\", \\\"{x:425,y:610,t:1527188811538};\\\", \\\"{x:432,y:610,t:1527188811555};\\\", \\\"{x:436,y:610,t:1527188811571};\\\", \\\"{x:440,y:610,t:1527188811588};\\\", \\\"{x:459,y:610,t:1527188811605};\\\", \\\"{x:475,y:610,t:1527188811622};\\\", \\\"{x:491,y:610,t:1527188811639};\\\", \\\"{x:510,y:610,t:1527188811656};\\\", \\\"{x:525,y:610,t:1527188811672};\\\", \\\"{x:536,y:610,t:1527188811688};\\\", \\\"{x:543,y:609,t:1527188811706};\\\", \\\"{x:546,y:608,t:1527188811722};\\\", \\\"{x:549,y:608,t:1527188811739};\\\", \\\"{x:553,y:607,t:1527188811755};\\\", \\\"{x:558,y:605,t:1527188811772};\\\", \\\"{x:562,y:604,t:1527188811788};\\\", \\\"{x:571,y:602,t:1527188811805};\\\", \\\"{x:572,y:602,t:1527188811822};\\\", \\\"{x:573,y:601,t:1527188811839};\\\", \\\"{x:575,y:600,t:1527188811878};\\\", \\\"{x:576,y:600,t:1527188811888};\\\", \\\"{x:582,y:597,t:1527188811905};\\\", \\\"{x:590,y:594,t:1527188811923};\\\", \\\"{x:592,y:593,t:1527188811939};\\\", \\\"{x:593,y:592,t:1527188811956};\\\", \\\"{x:601,y:593,t:1527188812311};\\\", \\\"{x:615,y:597,t:1527188812323};\\\", \\\"{x:667,y:611,t:1527188812339};\\\", \\\"{x:761,y:636,t:1527188812356};\\\", \\\"{x:861,y:662,t:1527188812372};\\\", \\\"{x:1032,y:710,t:1527188812389};\\\", \\\"{x:1179,y:733,t:1527188812405};\\\", \\\"{x:1318,y:757,t:1527188812422};\\\", \\\"{x:1441,y:784,t:1527188812439};\\\", \\\"{x:1562,y:809,t:1527188812457};\\\", \\\"{x:1667,y:825,t:1527188812472};\\\", \\\"{x:1752,y:844,t:1527188812489};\\\", \\\"{x:1825,y:856,t:1527188812506};\\\", \\\"{x:1877,y:867,t:1527188812523};\\\", \\\"{x:1912,y:875,t:1527188812540};\\\", \\\"{x:1919,y:881,t:1527188812556};\\\", \\\"{x:1919,y:882,t:1527188812573};\\\", \\\"{x:1919,y:883,t:1527188812590};\\\", \\\"{x:1915,y:882,t:1527188812646};\\\", \\\"{x:1905,y:874,t:1527188812657};\\\", \\\"{x:1880,y:853,t:1527188812673};\\\", \\\"{x:1842,y:822,t:1527188812689};\\\", \\\"{x:1815,y:802,t:1527188812706};\\\", \\\"{x:1795,y:790,t:1527188812723};\\\", \\\"{x:1782,y:780,t:1527188812739};\\\", \\\"{x:1769,y:772,t:1527188812756};\\\", \\\"{x:1749,y:761,t:1527188812773};\\\", \\\"{x:1737,y:754,t:1527188812789};\\\", \\\"{x:1725,y:749,t:1527188812806};\\\", \\\"{x:1715,y:743,t:1527188812823};\\\", \\\"{x:1710,y:740,t:1527188812840};\\\", \\\"{x:1699,y:735,t:1527188812856};\\\", \\\"{x:1688,y:729,t:1527188812874};\\\", \\\"{x:1675,y:721,t:1527188812889};\\\", \\\"{x:1664,y:715,t:1527188812906};\\\", \\\"{x:1651,y:709,t:1527188812924};\\\", \\\"{x:1640,y:703,t:1527188812940};\\\", \\\"{x:1624,y:694,t:1527188812957};\\\", \\\"{x:1604,y:684,t:1527188812973};\\\", \\\"{x:1596,y:680,t:1527188812989};\\\", \\\"{x:1594,y:679,t:1527188813007};\\\", \\\"{x:1592,y:679,t:1527188813024};\\\", \\\"{x:1592,y:678,t:1527188813040};\\\", \\\"{x:1589,y:677,t:1527188813057};\\\", \\\"{x:1584,y:675,t:1527188813073};\\\", \\\"{x:1580,y:673,t:1527188813090};\\\", \\\"{x:1576,y:670,t:1527188813106};\\\", \\\"{x:1573,y:670,t:1527188813124};\\\", \\\"{x:1570,y:669,t:1527188813140};\\\", \\\"{x:1568,y:668,t:1527188813157};\\\", \\\"{x:1567,y:667,t:1527188813174};\\\", \\\"{x:1566,y:667,t:1527188813358};\\\", \\\"{x:1564,y:666,t:1527188813373};\\\", \\\"{x:1561,y:665,t:1527188813391};\\\", \\\"{x:1556,y:662,t:1527188813407};\\\", \\\"{x:1550,y:658,t:1527188813424};\\\", \\\"{x:1545,y:657,t:1527188813441};\\\", \\\"{x:1543,y:655,t:1527188813457};\\\", \\\"{x:1541,y:654,t:1527188813474};\\\", \\\"{x:1540,y:654,t:1527188813490};\\\", \\\"{x:1539,y:653,t:1527188813507};\\\", \\\"{x:1538,y:653,t:1527188813742};\\\", \\\"{x:1516,y:698,t:1527188813757};\\\", \\\"{x:1489,y:769,t:1527188813773};\\\", \\\"{x:1470,y:830,t:1527188813790};\\\", \\\"{x:1455,y:883,t:1527188813808};\\\", \\\"{x:1443,y:930,t:1527188813824};\\\", \\\"{x:1427,y:964,t:1527188813840};\\\", \\\"{x:1421,y:981,t:1527188813858};\\\", \\\"{x:1418,y:989,t:1527188813874};\\\", \\\"{x:1418,y:988,t:1527188814014};\\\", \\\"{x:1417,y:980,t:1527188814024};\\\", \\\"{x:1411,y:959,t:1527188814042};\\\", \\\"{x:1404,y:939,t:1527188814058};\\\", \\\"{x:1395,y:921,t:1527188814075};\\\", \\\"{x:1385,y:906,t:1527188814091};\\\", \\\"{x:1380,y:901,t:1527188814108};\\\", \\\"{x:1378,y:898,t:1527188814125};\\\", \\\"{x:1377,y:897,t:1527188814141};\\\", \\\"{x:1375,y:893,t:1527188814158};\\\", \\\"{x:1374,y:890,t:1527188814175};\\\", \\\"{x:1370,y:884,t:1527188814191};\\\", \\\"{x:1369,y:878,t:1527188814208};\\\", \\\"{x:1368,y:869,t:1527188814226};\\\", \\\"{x:1364,y:860,t:1527188814241};\\\", \\\"{x:1360,y:847,t:1527188814258};\\\", \\\"{x:1358,y:839,t:1527188814275};\\\", \\\"{x:1355,y:831,t:1527188814291};\\\", \\\"{x:1355,y:828,t:1527188814308};\\\", \\\"{x:1355,y:827,t:1527188814325};\\\", \\\"{x:1353,y:827,t:1527188814399};\\\", \\\"{x:1352,y:832,t:1527188814408};\\\", \\\"{x:1350,y:844,t:1527188814425};\\\", \\\"{x:1347,y:856,t:1527188814441};\\\", \\\"{x:1345,y:866,t:1527188814457};\\\", \\\"{x:1343,y:875,t:1527188814474};\\\", \\\"{x:1343,y:884,t:1527188814491};\\\", \\\"{x:1343,y:888,t:1527188814508};\\\", \\\"{x:1343,y:894,t:1527188814525};\\\", \\\"{x:1343,y:898,t:1527188814541};\\\", \\\"{x:1343,y:900,t:1527188814557};\\\", \\\"{x:1343,y:902,t:1527188814575};\\\", \\\"{x:1343,y:905,t:1527188814592};\\\", \\\"{x:1343,y:909,t:1527188814607};\\\", \\\"{x:1343,y:912,t:1527188814624};\\\", \\\"{x:1343,y:914,t:1527188814642};\\\", \\\"{x:1343,y:913,t:1527188815046};\\\", \\\"{x:1343,y:912,t:1527188815059};\\\", \\\"{x:1343,y:908,t:1527188815075};\\\", \\\"{x:1343,y:901,t:1527188815092};\\\", \\\"{x:1343,y:899,t:1527188815109};\\\", \\\"{x:1343,y:897,t:1527188815125};\\\", \\\"{x:1343,y:896,t:1527188815142};\\\", \\\"{x:1343,y:895,t:1527188815159};\\\", \\\"{x:1343,y:890,t:1527188817598};\\\", \\\"{x:1342,y:883,t:1527188817611};\\\", \\\"{x:1338,y:870,t:1527188817627};\\\", \\\"{x:1336,y:864,t:1527188817643};\\\", \\\"{x:1336,y:859,t:1527188817660};\\\", \\\"{x:1334,y:856,t:1527188817677};\\\", \\\"{x:1333,y:849,t:1527188817694};\\\", \\\"{x:1332,y:838,t:1527188817711};\\\", \\\"{x:1327,y:816,t:1527188817728};\\\", \\\"{x:1323,y:792,t:1527188817744};\\\", \\\"{x:1318,y:778,t:1527188817761};\\\", \\\"{x:1316,y:763,t:1527188817778};\\\", \\\"{x:1313,y:752,t:1527188817794};\\\", \\\"{x:1309,y:739,t:1527188817810};\\\", \\\"{x:1308,y:725,t:1527188817828};\\\", \\\"{x:1307,y:715,t:1527188817844};\\\", \\\"{x:1307,y:705,t:1527188817861};\\\", \\\"{x:1307,y:694,t:1527188817878};\\\", \\\"{x:1307,y:688,t:1527188817894};\\\", \\\"{x:1308,y:685,t:1527188817911};\\\", \\\"{x:1309,y:681,t:1527188817928};\\\", \\\"{x:1311,y:677,t:1527188817944};\\\", \\\"{x:1314,y:673,t:1527188817961};\\\", \\\"{x:1317,y:668,t:1527188817978};\\\", \\\"{x:1320,y:664,t:1527188817994};\\\", \\\"{x:1324,y:659,t:1527188818012};\\\", \\\"{x:1325,y:656,t:1527188818028};\\\", \\\"{x:1327,y:655,t:1527188818044};\\\", \\\"{x:1327,y:653,t:1527188818061};\\\", \\\"{x:1328,y:649,t:1527188818078};\\\", \\\"{x:1328,y:646,t:1527188818094};\\\", \\\"{x:1328,y:643,t:1527188818111};\\\", \\\"{x:1328,y:638,t:1527188818128};\\\", \\\"{x:1327,y:635,t:1527188818146};\\\", \\\"{x:1325,y:633,t:1527188818161};\\\", \\\"{x:1323,y:631,t:1527188818178};\\\", \\\"{x:1322,y:629,t:1527188818195};\\\", \\\"{x:1320,y:627,t:1527188818211};\\\", \\\"{x:1318,y:625,t:1527188818228};\\\", \\\"{x:1316,y:624,t:1527188818246};\\\", \\\"{x:1315,y:624,t:1527188818702};\\\", \\\"{x:1314,y:624,t:1527188819342};\\\", \\\"{x:1313,y:624,t:1527188819350};\\\", \\\"{x:1310,y:622,t:1527188819362};\\\", \\\"{x:1305,y:621,t:1527188819380};\\\", \\\"{x:1300,y:621,t:1527188819396};\\\", \\\"{x:1296,y:621,t:1527188819412};\\\", \\\"{x:1293,y:621,t:1527188819429};\\\", \\\"{x:1290,y:620,t:1527188819446};\\\", \\\"{x:1292,y:620,t:1527188820486};\\\", \\\"{x:1295,y:620,t:1527188820497};\\\", \\\"{x:1298,y:620,t:1527188820514};\\\", \\\"{x:1299,y:620,t:1527188820531};\\\", \\\"{x:1300,y:620,t:1527188820546};\\\", \\\"{x:1302,y:620,t:1527188820563};\\\", \\\"{x:1303,y:621,t:1527188820579};\\\", \\\"{x:1304,y:621,t:1527188820661};\\\", \\\"{x:1305,y:621,t:1527188820669};\\\", \\\"{x:1306,y:621,t:1527188820680};\\\", \\\"{x:1308,y:621,t:1527188820697};\\\", \\\"{x:1309,y:622,t:1527188820713};\\\", \\\"{x:1309,y:623,t:1527188820950};\\\", \\\"{x:1309,y:624,t:1527188820963};\\\", \\\"{x:1308,y:627,t:1527188820980};\\\", \\\"{x:1307,y:630,t:1527188820997};\\\", \\\"{x:1307,y:638,t:1527188821013};\\\", \\\"{x:1306,y:642,t:1527188821031};\\\", \\\"{x:1304,y:647,t:1527188821048};\\\", \\\"{x:1304,y:648,t:1527188821086};\\\", \\\"{x:1304,y:649,t:1527188821102};\\\", \\\"{x:1304,y:650,t:1527188821150};\\\", \\\"{x:1304,y:651,t:1527188821206};\\\", \\\"{x:1304,y:652,t:1527188821238};\\\", \\\"{x:1304,y:653,t:1527188821359};\\\", \\\"{x:1305,y:653,t:1527188821366};\\\", \\\"{x:1307,y:652,t:1527188821381};\\\", \\\"{x:1311,y:651,t:1527188821397};\\\", \\\"{x:1312,y:652,t:1527188821494};\\\", \\\"{x:1311,y:655,t:1527188821502};\\\", \\\"{x:1311,y:657,t:1527188821515};\\\", \\\"{x:1310,y:665,t:1527188821532};\\\", \\\"{x:1310,y:671,t:1527188821548};\\\", \\\"{x:1310,y:675,t:1527188821564};\\\", \\\"{x:1310,y:684,t:1527188821580};\\\", \\\"{x:1310,y:692,t:1527188821597};\\\", \\\"{x:1310,y:701,t:1527188821614};\\\", \\\"{x:1310,y:709,t:1527188821631};\\\", \\\"{x:1310,y:716,t:1527188821647};\\\", \\\"{x:1311,y:723,t:1527188821664};\\\", \\\"{x:1311,y:727,t:1527188821681};\\\", \\\"{x:1312,y:733,t:1527188821697};\\\", \\\"{x:1312,y:737,t:1527188821714};\\\", \\\"{x:1314,y:741,t:1527188821731};\\\", \\\"{x:1315,y:744,t:1527188821748};\\\", \\\"{x:1315,y:748,t:1527188821764};\\\", \\\"{x:1315,y:758,t:1527188821780};\\\", \\\"{x:1316,y:765,t:1527188821798};\\\", \\\"{x:1318,y:774,t:1527188821813};\\\", \\\"{x:1319,y:780,t:1527188821830};\\\", \\\"{x:1320,y:789,t:1527188821847};\\\", \\\"{x:1320,y:797,t:1527188821863};\\\", \\\"{x:1323,y:809,t:1527188821881};\\\", \\\"{x:1324,y:820,t:1527188821898};\\\", \\\"{x:1328,y:831,t:1527188821914};\\\", \\\"{x:1330,y:837,t:1527188821931};\\\", \\\"{x:1330,y:843,t:1527188821947};\\\", \\\"{x:1330,y:853,t:1527188821964};\\\", \\\"{x:1330,y:873,t:1527188821980};\\\", \\\"{x:1334,y:885,t:1527188821997};\\\", \\\"{x:1335,y:895,t:1527188822014};\\\", \\\"{x:1337,y:903,t:1527188822031};\\\", \\\"{x:1337,y:909,t:1527188822048};\\\", \\\"{x:1337,y:915,t:1527188822064};\\\", \\\"{x:1337,y:923,t:1527188822081};\\\", \\\"{x:1338,y:930,t:1527188822098};\\\", \\\"{x:1338,y:936,t:1527188822114};\\\", \\\"{x:1338,y:940,t:1527188822131};\\\", \\\"{x:1338,y:942,t:1527188822148};\\\", \\\"{x:1338,y:944,t:1527188822163};\\\", \\\"{x:1338,y:945,t:1527188822182};\\\", \\\"{x:1338,y:946,t:1527188822222};\\\", \\\"{x:1338,y:947,t:1527188822238};\\\", \\\"{x:1338,y:948,t:1527188822254};\\\", \\\"{x:1338,y:949,t:1527188822265};\\\", \\\"{x:1338,y:952,t:1527188822281};\\\", \\\"{x:1336,y:955,t:1527188822298};\\\", \\\"{x:1335,y:959,t:1527188822315};\\\", \\\"{x:1333,y:961,t:1527188822332};\\\", \\\"{x:1332,y:964,t:1527188822348};\\\", \\\"{x:1330,y:966,t:1527188822365};\\\", \\\"{x:1330,y:967,t:1527188822381};\\\", \\\"{x:1330,y:964,t:1527188822622};\\\", \\\"{x:1329,y:960,t:1527188822632};\\\", \\\"{x:1328,y:953,t:1527188822648};\\\", \\\"{x:1326,y:945,t:1527188822665};\\\", \\\"{x:1326,y:937,t:1527188822681};\\\", \\\"{x:1325,y:928,t:1527188822698};\\\", \\\"{x:1325,y:917,t:1527188822715};\\\", \\\"{x:1325,y:902,t:1527188822733};\\\", \\\"{x:1325,y:885,t:1527188822749};\\\", \\\"{x:1325,y:854,t:1527188822765};\\\", \\\"{x:1325,y:832,t:1527188822781};\\\", \\\"{x:1325,y:813,t:1527188822797};\\\", \\\"{x:1325,y:795,t:1527188822815};\\\", \\\"{x:1325,y:776,t:1527188822832};\\\", \\\"{x:1321,y:758,t:1527188822848};\\\", \\\"{x:1320,y:742,t:1527188822865};\\\", \\\"{x:1320,y:723,t:1527188822882};\\\", \\\"{x:1320,y:705,t:1527188822898};\\\", \\\"{x:1320,y:691,t:1527188822915};\\\", \\\"{x:1319,y:677,t:1527188822932};\\\", \\\"{x:1316,y:663,t:1527188822948};\\\", \\\"{x:1312,y:648,t:1527188822965};\\\", \\\"{x:1310,y:639,t:1527188822981};\\\", \\\"{x:1307,y:633,t:1527188822998};\\\", \\\"{x:1305,y:629,t:1527188823015};\\\", \\\"{x:1304,y:626,t:1527188823032};\\\", \\\"{x:1303,y:625,t:1527188823048};\\\", \\\"{x:1303,y:622,t:1527188824167};\\\", \\\"{x:1303,y:598,t:1527188824184};\\\", \\\"{x:1304,y:581,t:1527188824200};\\\", \\\"{x:1304,y:565,t:1527188824216};\\\", \\\"{x:1304,y:550,t:1527188824233};\\\", \\\"{x:1304,y:536,t:1527188824249};\\\", \\\"{x:1304,y:519,t:1527188824266};\\\", \\\"{x:1304,y:507,t:1527188824283};\\\", \\\"{x:1304,y:500,t:1527188824299};\\\", \\\"{x:1304,y:495,t:1527188824316};\\\", \\\"{x:1304,y:492,t:1527188824333};\\\", \\\"{x:1304,y:491,t:1527188824350};\\\", \\\"{x:1305,y:489,t:1527188824382};\\\", \\\"{x:1306,y:488,t:1527188824398};\\\", \\\"{x:1307,y:486,t:1527188824430};\\\", \\\"{x:1308,y:484,t:1527188824437};\\\", \\\"{x:1310,y:481,t:1527188824450};\\\", \\\"{x:1313,y:475,t:1527188824467};\\\", \\\"{x:1316,y:468,t:1527188824484};\\\", \\\"{x:1317,y:467,t:1527188824501};\\\", \\\"{x:1317,y:466,t:1527188824516};\\\", \\\"{x:1316,y:466,t:1527188825527};\\\", \\\"{x:1314,y:467,t:1527188825542};\\\", \\\"{x:1313,y:468,t:1527188825574};\\\", \\\"{x:1312,y:468,t:1527188825606};\\\", \\\"{x:1311,y:469,t:1527188825678};\\\", \\\"{x:1310,y:469,t:1527188825694};\\\", \\\"{x:1309,y:470,t:1527188825702};\\\", \\\"{x:1308,y:470,t:1527188825789};\\\", \\\"{x:1306,y:470,t:1527188825861};\\\", \\\"{x:1303,y:470,t:1527188825868};\\\", \\\"{x:1300,y:472,t:1527188825883};\\\", \\\"{x:1295,y:474,t:1527188825901};\\\", \\\"{x:1287,y:477,t:1527188825918};\\\", \\\"{x:1261,y:488,t:1527188825934};\\\", \\\"{x:1196,y:509,t:1527188825951};\\\", \\\"{x:1092,y:528,t:1527188825968};\\\", \\\"{x:973,y:564,t:1527188825984};\\\", \\\"{x:863,y:595,t:1527188826001};\\\", \\\"{x:764,y:617,t:1527188826018};\\\", \\\"{x:696,y:629,t:1527188826034};\\\", \\\"{x:664,y:635,t:1527188826048};\\\", \\\"{x:646,y:638,t:1527188826065};\\\", \\\"{x:637,y:639,t:1527188826082};\\\", \\\"{x:635,y:640,t:1527188826098};\\\", \\\"{x:634,y:640,t:1527188826117};\\\", \\\"{x:633,y:640,t:1527188826134};\\\", \\\"{x:632,y:640,t:1527188826164};\\\", \\\"{x:634,y:635,t:1527188826221};\\\", \\\"{x:637,y:629,t:1527188826234};\\\", \\\"{x:641,y:619,t:1527188826251};\\\", \\\"{x:641,y:616,t:1527188826267};\\\", \\\"{x:641,y:613,t:1527188826284};\\\", \\\"{x:641,y:612,t:1527188826326};\\\", \\\"{x:639,y:612,t:1527188826334};\\\", \\\"{x:632,y:607,t:1527188826351};\\\", \\\"{x:623,y:604,t:1527188826367};\\\", \\\"{x:620,y:604,t:1527188826384};\\\", \\\"{x:620,y:603,t:1527188826405};\\\", \\\"{x:619,y:603,t:1527188826417};\\\", \\\"{x:617,y:603,t:1527188826434};\\\", \\\"{x:611,y:603,t:1527188826451};\\\", \\\"{x:609,y:602,t:1527188826467};\\\", \\\"{x:608,y:602,t:1527188826484};\\\", \\\"{x:615,y:598,t:1527188826725};\\\", \\\"{x:622,y:590,t:1527188826734};\\\", \\\"{x:645,y:578,t:1527188826751};\\\", \\\"{x:686,y:562,t:1527188826768};\\\", \\\"{x:747,y:534,t:1527188826784};\\\", \\\"{x:823,y:506,t:1527188826801};\\\", \\\"{x:904,y:478,t:1527188826818};\\\", \\\"{x:974,y:456,t:1527188826834};\\\", \\\"{x:1038,y:437,t:1527188826851};\\\", \\\"{x:1087,y:427,t:1527188826868};\\\", \\\"{x:1125,y:414,t:1527188826883};\\\", \\\"{x:1175,y:400,t:1527188826901};\\\", \\\"{x:1203,y:390,t:1527188826918};\\\", \\\"{x:1225,y:382,t:1527188826934};\\\", \\\"{x:1242,y:374,t:1527188826951};\\\", \\\"{x:1252,y:370,t:1527188826968};\\\", \\\"{x:1257,y:368,t:1527188826984};\\\", \\\"{x:1262,y:368,t:1527188827001};\\\", \\\"{x:1264,y:368,t:1527188827018};\\\", \\\"{x:1265,y:368,t:1527188827034};\\\", \\\"{x:1270,y:371,t:1527188827051};\\\", \\\"{x:1275,y:375,t:1527188827069};\\\", \\\"{x:1276,y:381,t:1527188827084};\\\", \\\"{x:1279,y:388,t:1527188827101};\\\", \\\"{x:1281,y:394,t:1527188827118};\\\", \\\"{x:1282,y:398,t:1527188827135};\\\", \\\"{x:1283,y:404,t:1527188827151};\\\", \\\"{x:1284,y:413,t:1527188827168};\\\", \\\"{x:1286,y:427,t:1527188827184};\\\", \\\"{x:1288,y:445,t:1527188827201};\\\", \\\"{x:1297,y:468,t:1527188827217};\\\", \\\"{x:1305,y:485,t:1527188827234};\\\", \\\"{x:1313,y:497,t:1527188827252};\\\", \\\"{x:1314,y:499,t:1527188827268};\\\", \\\"{x:1314,y:500,t:1527188827284};\\\", \\\"{x:1315,y:501,t:1527188827342};\\\", \\\"{x:1317,y:501,t:1527188827357};\\\", \\\"{x:1319,y:502,t:1527188827367};\\\", \\\"{x:1324,y:504,t:1527188827384};\\\", \\\"{x:1326,y:505,t:1527188827401};\\\", \\\"{x:1327,y:505,t:1527188827418};\\\", \\\"{x:1328,y:506,t:1527188827526};\\\", \\\"{x:1328,y:508,t:1527188827541};\\\", \\\"{x:1326,y:510,t:1527188827551};\\\", \\\"{x:1317,y:516,t:1527188827568};\\\", \\\"{x:1311,y:528,t:1527188827584};\\\", \\\"{x:1303,y:552,t:1527188827601};\\\", \\\"{x:1298,y:572,t:1527188827617};\\\", \\\"{x:1292,y:596,t:1527188827635};\\\", \\\"{x:1286,y:622,t:1527188827652};\\\", \\\"{x:1280,y:652,t:1527188827668};\\\", \\\"{x:1277,y:683,t:1527188827684};\\\", \\\"{x:1271,y:729,t:1527188827702};\\\", \\\"{x:1271,y:753,t:1527188827718};\\\", \\\"{x:1271,y:768,t:1527188827735};\\\", \\\"{x:1269,y:781,t:1527188827751};\\\", \\\"{x:1268,y:788,t:1527188827768};\\\", \\\"{x:1267,y:792,t:1527188827785};\\\", \\\"{x:1267,y:793,t:1527188827801};\\\", \\\"{x:1267,y:794,t:1527188827934};\\\", \\\"{x:1264,y:798,t:1527188827952};\\\", \\\"{x:1261,y:802,t:1527188827967};\\\", \\\"{x:1260,y:805,t:1527188827984};\\\", \\\"{x:1257,y:808,t:1527188828001};\\\", \\\"{x:1256,y:810,t:1527188828017};\\\", \\\"{x:1256,y:811,t:1527188828034};\\\", \\\"{x:1254,y:813,t:1527188828053};\\\", \\\"{x:1258,y:803,t:1527188828661};\\\", \\\"{x:1269,y:788,t:1527188828670};\\\", \\\"{x:1283,y:765,t:1527188828684};\\\", \\\"{x:1330,y:709,t:1527188828702};\\\", \\\"{x:1375,y:659,t:1527188828718};\\\", \\\"{x:1418,y:614,t:1527188828735};\\\", \\\"{x:1453,y:580,t:1527188828752};\\\", \\\"{x:1477,y:550,t:1527188828767};\\\", \\\"{x:1494,y:531,t:1527188828785};\\\", \\\"{x:1503,y:518,t:1527188828802};\\\", \\\"{x:1506,y:514,t:1527188828817};\\\", \\\"{x:1508,y:511,t:1527188828835};\\\", \\\"{x:1510,y:507,t:1527188828852};\\\", \\\"{x:1512,y:504,t:1527188828868};\\\", \\\"{x:1515,y:496,t:1527188828885};\\\", \\\"{x:1516,y:488,t:1527188828902};\\\", \\\"{x:1516,y:482,t:1527188828918};\\\", \\\"{x:1516,y:479,t:1527188828934};\\\", \\\"{x:1514,y:474,t:1527188828951};\\\", \\\"{x:1506,y:470,t:1527188828967};\\\", \\\"{x:1491,y:463,t:1527188828985};\\\", \\\"{x:1479,y:458,t:1527188829002};\\\", \\\"{x:1467,y:453,t:1527188829017};\\\", \\\"{x:1461,y:450,t:1527188829034};\\\", \\\"{x:1457,y:449,t:1527188829051};\\\", \\\"{x:1455,y:448,t:1527188829067};\\\", \\\"{x:1453,y:447,t:1527188829085};\\\", \\\"{x:1449,y:445,t:1527188829101};\\\", \\\"{x:1446,y:444,t:1527188829117};\\\", \\\"{x:1443,y:443,t:1527188829135};\\\", \\\"{x:1442,y:442,t:1527188829262};\\\", \\\"{x:1441,y:441,t:1527188829269};\\\", \\\"{x:1438,y:440,t:1527188829285};\\\", \\\"{x:1428,y:434,t:1527188829301};\\\", \\\"{x:1425,y:433,t:1527188829318};\\\", \\\"{x:1422,y:432,t:1527188829335};\\\", \\\"{x:1421,y:431,t:1527188829351};\\\", \\\"{x:1427,y:429,t:1527188829566};\\\", \\\"{x:1439,y:427,t:1527188829574};\\\", \\\"{x:1454,y:427,t:1527188829585};\\\", \\\"{x:1484,y:427,t:1527188829601};\\\", \\\"{x:1512,y:427,t:1527188829617};\\\", \\\"{x:1533,y:426,t:1527188829635};\\\", \\\"{x:1549,y:426,t:1527188829651};\\\", \\\"{x:1567,y:426,t:1527188829668};\\\", \\\"{x:1580,y:426,t:1527188829685};\\\", \\\"{x:1586,y:426,t:1527188829700};\\\", \\\"{x:1593,y:426,t:1527188829718};\\\", \\\"{x:1596,y:426,t:1527188829735};\\\", \\\"{x:1600,y:426,t:1527188829751};\\\", \\\"{x:1603,y:426,t:1527188829767};\\\", \\\"{x:1604,y:426,t:1527188829784};\\\", \\\"{x:1608,y:426,t:1527188829800};\\\", \\\"{x:1614,y:426,t:1527188829817};\\\", \\\"{x:1623,y:427,t:1527188829835};\\\", \\\"{x:1634,y:429,t:1527188829850};\\\", \\\"{x:1645,y:432,t:1527188829867};\\\", \\\"{x:1653,y:435,t:1527188829884};\\\", \\\"{x:1656,y:436,t:1527188829900};\\\", \\\"{x:1657,y:437,t:1527188829917};\\\", \\\"{x:1658,y:437,t:1527188829934};\\\", \\\"{x:1659,y:437,t:1527188829951};\\\", \\\"{x:1660,y:438,t:1527188830046};\\\", \\\"{x:1659,y:439,t:1527188830061};\\\", \\\"{x:1657,y:439,t:1527188830070};\\\", \\\"{x:1656,y:439,t:1527188830085};\\\", \\\"{x:1655,y:440,t:1527188830101};\\\", \\\"{x:1654,y:440,t:1527188830118};\\\", \\\"{x:1652,y:442,t:1527188830135};\\\", \\\"{x:1649,y:443,t:1527188830151};\\\", \\\"{x:1646,y:444,t:1527188830168};\\\", \\\"{x:1643,y:445,t:1527188830184};\\\", \\\"{x:1641,y:446,t:1527188830201};\\\", \\\"{x:1640,y:446,t:1527188830217};\\\", \\\"{x:1638,y:447,t:1527188830234};\\\", \\\"{x:1637,y:449,t:1527188830251};\\\", \\\"{x:1636,y:449,t:1527188830267};\\\", \\\"{x:1635,y:449,t:1527188830284};\\\", \\\"{x:1633,y:450,t:1527188830301};\\\", \\\"{x:1632,y:451,t:1527188830318};\\\", \\\"{x:1631,y:451,t:1527188830350};\\\", \\\"{x:1630,y:452,t:1527188830368};\\\", \\\"{x:1629,y:452,t:1527188830385};\\\", \\\"{x:1624,y:456,t:1527188830401};\\\", \\\"{x:1618,y:462,t:1527188830418};\\\", \\\"{x:1605,y:485,t:1527188830435};\\\", \\\"{x:1584,y:514,t:1527188830451};\\\", \\\"{x:1564,y:549,t:1527188830467};\\\", \\\"{x:1543,y:588,t:1527188830484};\\\", \\\"{x:1522,y:617,t:1527188830501};\\\", \\\"{x:1493,y:646,t:1527188830518};\\\", \\\"{x:1475,y:658,t:1527188830534};\\\", \\\"{x:1464,y:665,t:1527188830551};\\\", \\\"{x:1463,y:666,t:1527188830567};\\\", \\\"{x:1460,y:667,t:1527188830585};\\\", \\\"{x:1456,y:667,t:1527188830613};\\\", \\\"{x:1444,y:667,t:1527188830622};\\\", \\\"{x:1417,y:667,t:1527188830634};\\\", \\\"{x:1306,y:666,t:1527188830650};\\\", \\\"{x:1126,y:639,t:1527188830668};\\\", \\\"{x:893,y:597,t:1527188830685};\\\", \\\"{x:681,y:564,t:1527188830700};\\\", \\\"{x:428,y:509,t:1527188830722};\\\", \\\"{x:291,y:483,t:1527188830738};\\\", \\\"{x:182,y:473,t:1527188830754};\\\", \\\"{x:97,y:467,t:1527188830771};\\\", \\\"{x:41,y:467,t:1527188830787};\\\", \\\"{x:9,y:477,t:1527188830804};\\\", \\\"{x:3,y:481,t:1527188830821};\\\", \\\"{x:5,y:481,t:1527188830885};\\\", \\\"{x:10,y:481,t:1527188830894};\\\", \\\"{x:19,y:486,t:1527188830904};\\\", \\\"{x:47,y:499,t:1527188830921};\\\", \\\"{x:71,y:517,t:1527188830938};\\\", \\\"{x:117,y:542,t:1527188830954};\\\", \\\"{x:163,y:568,t:1527188830972};\\\", \\\"{x:206,y:591,t:1527188830989};\\\", \\\"{x:231,y:604,t:1527188831004};\\\", \\\"{x:268,y:622,t:1527188831022};\\\", \\\"{x:287,y:634,t:1527188831039};\\\", \\\"{x:298,y:644,t:1527188831054};\\\", \\\"{x:310,y:652,t:1527188831071};\\\", \\\"{x:329,y:664,t:1527188831087};\\\", \\\"{x:345,y:675,t:1527188831104};\\\", \\\"{x:365,y:682,t:1527188831121};\\\", \\\"{x:382,y:685,t:1527188831137};\\\", \\\"{x:398,y:688,t:1527188831154};\\\", \\\"{x:409,y:691,t:1527188831171};\\\", \\\"{x:416,y:692,t:1527188831188};\\\", \\\"{x:419,y:695,t:1527188831204};\\\", \\\"{x:425,y:696,t:1527188831222};\\\", \\\"{x:429,y:698,t:1527188831237};\\\", \\\"{x:430,y:698,t:1527188831277};\\\", \\\"{x:432,y:698,t:1527188831287};\\\", \\\"{x:441,y:704,t:1527188831304};\\\", \\\"{x:454,y:713,t:1527188831321};\\\", \\\"{x:460,y:717,t:1527188831337};\\\", \\\"{x:461,y:717,t:1527188831354};\\\", \\\"{x:453,y:707,t:1527188831789};\\\", \\\"{x:419,y:674,t:1527188831806};\\\", \\\"{x:382,y:637,t:1527188831821};\\\", \\\"{x:349,y:607,t:1527188831839};\\\", \\\"{x:322,y:587,t:1527188831855};\\\", \\\"{x:308,y:578,t:1527188831871};\\\", \\\"{x:303,y:575,t:1527188831888};\\\", \\\"{x:299,y:573,t:1527188831905};\\\", \\\"{x:298,y:571,t:1527188831921};\\\", \\\"{x:296,y:570,t:1527188831938};\\\", \\\"{x:294,y:568,t:1527188831955};\\\", \\\"{x:294,y:567,t:1527188831972};\\\", \\\"{x:293,y:567,t:1527188832013};\\\", \\\"{x:291,y:566,t:1527188832086};\\\", \\\"{x:290,y:564,t:1527188832101};\\\", \\\"{x:290,y:563,t:1527188832109};\\\", \\\"{x:287,y:561,t:1527188832122};\\\", \\\"{x:285,y:558,t:1527188832138};\\\", \\\"{x:283,y:554,t:1527188832155};\\\", \\\"{x:281,y:553,t:1527188832172};\\\", \\\"{x:281,y:552,t:1527188832188};\\\", \\\"{x:280,y:551,t:1527188832205};\\\", \\\"{x:279,y:550,t:1527188832262};\\\" ] }, { \\\"rt\\\": 58244, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 271138, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -7-H -J -I -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:279,y:549,t:1527188840846};\\\", \\\"{x:288,y:546,t:1527188840854};\\\", \\\"{x:309,y:544,t:1527188840868};\\\", \\\"{x:376,y:544,t:1527188840884};\\\", \\\"{x:523,y:544,t:1527188840902};\\\", \\\"{x:642,y:544,t:1527188840918};\\\", \\\"{x:830,y:557,t:1527188840942};\\\", \\\"{x:952,y:574,t:1527188840958};\\\", \\\"{x:1078,y:580,t:1527188840976};\\\", \\\"{x:1182,y:588,t:1527188840992};\\\", \\\"{x:1271,y:590,t:1527188841008};\\\", \\\"{x:1338,y:590,t:1527188841025};\\\", \\\"{x:1374,y:590,t:1527188841042};\\\", \\\"{x:1408,y:590,t:1527188841059};\\\", \\\"{x:1427,y:590,t:1527188841076};\\\", \\\"{x:1441,y:587,t:1527188841092};\\\", \\\"{x:1446,y:585,t:1527188841109};\\\", \\\"{x:1447,y:583,t:1527188841141};\\\", \\\"{x:1451,y:580,t:1527188841158};\\\", \\\"{x:1459,y:576,t:1527188841176};\\\", \\\"{x:1466,y:569,t:1527188841192};\\\", \\\"{x:1472,y:565,t:1527188841209};\\\", \\\"{x:1476,y:558,t:1527188841226};\\\", \\\"{x:1476,y:553,t:1527188841242};\\\", \\\"{x:1476,y:547,t:1527188841258};\\\", \\\"{x:1474,y:542,t:1527188841276};\\\", \\\"{x:1468,y:538,t:1527188841291};\\\", \\\"{x:1460,y:534,t:1527188841308};\\\", \\\"{x:1452,y:531,t:1527188841326};\\\", \\\"{x:1447,y:529,t:1527188841342};\\\", \\\"{x:1441,y:526,t:1527188841359};\\\", \\\"{x:1433,y:524,t:1527188841376};\\\", \\\"{x:1424,y:521,t:1527188841392};\\\", \\\"{x:1414,y:518,t:1527188841408};\\\", \\\"{x:1408,y:516,t:1527188841426};\\\", \\\"{x:1404,y:515,t:1527188841441};\\\", \\\"{x:1398,y:513,t:1527188841459};\\\", \\\"{x:1395,y:513,t:1527188841475};\\\", \\\"{x:1389,y:512,t:1527188841493};\\\", \\\"{x:1384,y:512,t:1527188841509};\\\", \\\"{x:1382,y:512,t:1527188841526};\\\", \\\"{x:1379,y:512,t:1527188841543};\\\", \\\"{x:1378,y:510,t:1527188841558};\\\", \\\"{x:1377,y:510,t:1527188841576};\\\", \\\"{x:1375,y:510,t:1527188841592};\\\", \\\"{x:1374,y:510,t:1527188841614};\\\", \\\"{x:1373,y:510,t:1527188841678};\\\", \\\"{x:1372,y:510,t:1527188841717};\\\", \\\"{x:1371,y:510,t:1527188841815};\\\", \\\"{x:1369,y:510,t:1527188841837};\\\", \\\"{x:1368,y:510,t:1527188841870};\\\", \\\"{x:1367,y:510,t:1527188841878};\\\", \\\"{x:1366,y:510,t:1527188841893};\\\", \\\"{x:1365,y:510,t:1527188841917};\\\", \\\"{x:1364,y:510,t:1527188841926};\\\", \\\"{x:1362,y:510,t:1527188841943};\\\", \\\"{x:1359,y:510,t:1527188841959};\\\", \\\"{x:1357,y:510,t:1527188841982};\\\", \\\"{x:1356,y:510,t:1527188841997};\\\", \\\"{x:1354,y:510,t:1527188842022};\\\", \\\"{x:1353,y:510,t:1527188842062};\\\", \\\"{x:1352,y:510,t:1527188842086};\\\", \\\"{x:1351,y:510,t:1527188842101};\\\", \\\"{x:1350,y:510,t:1527188842109};\\\", \\\"{x:1349,y:510,t:1527188842134};\\\", \\\"{x:1348,y:510,t:1527188842144};\\\", \\\"{x:1347,y:510,t:1527188842159};\\\", \\\"{x:1346,y:510,t:1527188842177};\\\", \\\"{x:1344,y:510,t:1527188842194};\\\", \\\"{x:1343,y:510,t:1527188842210};\\\", \\\"{x:1341,y:510,t:1527188842227};\\\", \\\"{x:1338,y:510,t:1527188842243};\\\", \\\"{x:1335,y:510,t:1527188842260};\\\", \\\"{x:1334,y:510,t:1527188842276};\\\", \\\"{x:1331,y:510,t:1527188842294};\\\", \\\"{x:1329,y:510,t:1527188842310};\\\", \\\"{x:1328,y:510,t:1527188842326};\\\", \\\"{x:1327,y:510,t:1527188842349};\\\", \\\"{x:1326,y:510,t:1527188842374};\\\", \\\"{x:1325,y:510,t:1527188842382};\\\", \\\"{x:1324,y:510,t:1527188842415};\\\", \\\"{x:1322,y:510,t:1527188842438};\\\", \\\"{x:1320,y:510,t:1527188842486};\\\", \\\"{x:1319,y:510,t:1527188842534};\\\", \\\"{x:1318,y:509,t:1527188842557};\\\", \\\"{x:1317,y:509,t:1527188842581};\\\", \\\"{x:1317,y:508,t:1527188846790};\\\", \\\"{x:1317,y:499,t:1527188846800};\\\", \\\"{x:1317,y:488,t:1527188846812};\\\", \\\"{x:1317,y:477,t:1527188846826};\\\", \\\"{x:1318,y:467,t:1527188846844};\\\", \\\"{x:1318,y:458,t:1527188846861};\\\", \\\"{x:1318,y:457,t:1527188846884};\\\", \\\"{x:1316,y:457,t:1527188847638};\\\", \\\"{x:1310,y:460,t:1527188847645};\\\", \\\"{x:1306,y:462,t:1527188847661};\\\", \\\"{x:1300,y:466,t:1527188847678};\\\", \\\"{x:1292,y:470,t:1527188847695};\\\", \\\"{x:1287,y:474,t:1527188847711};\\\", \\\"{x:1284,y:476,t:1527188847728};\\\", \\\"{x:1282,y:477,t:1527188847744};\\\", \\\"{x:1281,y:478,t:1527188847762};\\\", \\\"{x:1280,y:479,t:1527188847846};\\\", \\\"{x:1280,y:480,t:1527188847878};\\\", \\\"{x:1280,y:484,t:1527188847895};\\\", \\\"{x:1280,y:487,t:1527188847911};\\\", \\\"{x:1281,y:490,t:1527188847929};\\\", \\\"{x:1282,y:492,t:1527188847944};\\\", \\\"{x:1286,y:492,t:1527188847961};\\\", \\\"{x:1291,y:493,t:1527188847980};\\\", \\\"{x:1296,y:494,t:1527188847995};\\\", \\\"{x:1299,y:494,t:1527188848011};\\\", \\\"{x:1301,y:494,t:1527188848158};\\\", \\\"{x:1302,y:494,t:1527188848173};\\\", \\\"{x:1303,y:494,t:1527188848197};\\\", \\\"{x:1303,y:503,t:1527188864212};\\\", \\\"{x:1301,y:523,t:1527188864230};\\\", \\\"{x:1299,y:545,t:1527188864247};\\\", \\\"{x:1298,y:569,t:1527188864263};\\\", \\\"{x:1295,y:588,t:1527188864280};\\\", \\\"{x:1291,y:602,t:1527188864297};\\\", \\\"{x:1289,y:613,t:1527188864312};\\\", \\\"{x:1288,y:627,t:1527188864329};\\\", \\\"{x:1288,y:637,t:1527188864346};\\\", \\\"{x:1288,y:649,t:1527188864363};\\\", \\\"{x:1288,y:659,t:1527188864379};\\\", \\\"{x:1288,y:665,t:1527188864397};\\\", \\\"{x:1286,y:674,t:1527188864412};\\\", \\\"{x:1286,y:689,t:1527188864429};\\\", \\\"{x:1286,y:712,t:1527188864446};\\\", \\\"{x:1286,y:735,t:1527188864463};\\\", \\\"{x:1286,y:757,t:1527188864479};\\\", \\\"{x:1286,y:777,t:1527188864497};\\\", \\\"{x:1287,y:798,t:1527188864513};\\\", \\\"{x:1292,y:822,t:1527188864529};\\\", \\\"{x:1296,y:837,t:1527188864547};\\\", \\\"{x:1298,y:853,t:1527188864563};\\\", \\\"{x:1302,y:866,t:1527188864580};\\\", \\\"{x:1304,y:877,t:1527188864597};\\\", \\\"{x:1306,y:891,t:1527188864614};\\\", \\\"{x:1309,y:902,t:1527188864630};\\\", \\\"{x:1313,y:915,t:1527188864646};\\\", \\\"{x:1314,y:919,t:1527188864664};\\\", \\\"{x:1314,y:922,t:1527188864680};\\\", \\\"{x:1315,y:922,t:1527188864714};\\\", \\\"{x:1314,y:916,t:1527188867090};\\\", \\\"{x:1308,y:905,t:1527188867097};\\\", \\\"{x:1299,y:886,t:1527188867114};\\\", \\\"{x:1291,y:872,t:1527188867131};\\\", \\\"{x:1283,y:859,t:1527188867147};\\\", \\\"{x:1280,y:854,t:1527188867164};\\\", \\\"{x:1278,y:851,t:1527188867181};\\\", \\\"{x:1276,y:850,t:1527188867198};\\\", \\\"{x:1275,y:850,t:1527188867218};\\\", \\\"{x:1275,y:849,t:1527188867249};\\\", \\\"{x:1273,y:848,t:1527188867265};\\\", \\\"{x:1273,y:847,t:1527188867321};\\\", \\\"{x:1272,y:847,t:1527188867378};\\\", \\\"{x:1272,y:846,t:1527188867394};\\\", \\\"{x:1271,y:844,t:1527188867441};\\\", \\\"{x:1270,y:844,t:1527188867466};\\\", \\\"{x:1269,y:843,t:1527188867498};\\\", \\\"{x:1269,y:842,t:1527188867514};\\\", \\\"{x:1267,y:840,t:1527188867531};\\\", \\\"{x:1266,y:838,t:1527188867548};\\\", \\\"{x:1263,y:832,t:1527188867564};\\\", \\\"{x:1258,y:821,t:1527188867581};\\\", \\\"{x:1253,y:808,t:1527188867598};\\\", \\\"{x:1249,y:799,t:1527188867614};\\\", \\\"{x:1246,y:788,t:1527188867631};\\\", \\\"{x:1243,y:778,t:1527188867648};\\\", \\\"{x:1239,y:769,t:1527188867664};\\\", \\\"{x:1238,y:766,t:1527188867681};\\\", \\\"{x:1236,y:757,t:1527188867698};\\\", \\\"{x:1236,y:748,t:1527188867714};\\\", \\\"{x:1235,y:733,t:1527188867731};\\\", \\\"{x:1235,y:721,t:1527188867748};\\\", \\\"{x:1235,y:705,t:1527188867764};\\\", \\\"{x:1236,y:690,t:1527188867781};\\\", \\\"{x:1237,y:680,t:1527188867798};\\\", \\\"{x:1240,y:670,t:1527188867814};\\\", \\\"{x:1241,y:663,t:1527188867831};\\\", \\\"{x:1245,y:658,t:1527188867848};\\\", \\\"{x:1249,y:651,t:1527188867864};\\\", \\\"{x:1253,y:642,t:1527188867881};\\\", \\\"{x:1261,y:632,t:1527188867897};\\\", \\\"{x:1267,y:623,t:1527188867913};\\\", \\\"{x:1272,y:619,t:1527188867931};\\\", \\\"{x:1275,y:614,t:1527188867948};\\\", \\\"{x:1278,y:609,t:1527188867964};\\\", \\\"{x:1280,y:604,t:1527188867981};\\\", \\\"{x:1280,y:601,t:1527188867998};\\\", \\\"{x:1282,y:598,t:1527188868014};\\\", \\\"{x:1283,y:596,t:1527188868031};\\\", \\\"{x:1285,y:591,t:1527188868048};\\\", \\\"{x:1287,y:585,t:1527188868064};\\\", \\\"{x:1288,y:582,t:1527188868081};\\\", \\\"{x:1289,y:573,t:1527188868097};\\\", \\\"{x:1290,y:567,t:1527188868114};\\\", \\\"{x:1292,y:561,t:1527188868131};\\\", \\\"{x:1295,y:552,t:1527188868148};\\\", \\\"{x:1296,y:545,t:1527188868164};\\\", \\\"{x:1298,y:538,t:1527188868181};\\\", \\\"{x:1300,y:533,t:1527188868198};\\\", \\\"{x:1304,y:526,t:1527188868214};\\\", \\\"{x:1306,y:522,t:1527188868231};\\\", \\\"{x:1307,y:521,t:1527188868248};\\\", \\\"{x:1307,y:518,t:1527188868264};\\\", \\\"{x:1307,y:517,t:1527188868394};\\\", \\\"{x:1305,y:517,t:1527188868402};\\\", \\\"{x:1302,y:519,t:1527188868414};\\\", \\\"{x:1300,y:535,t:1527188868431};\\\", \\\"{x:1298,y:549,t:1527188868448};\\\", \\\"{x:1298,y:564,t:1527188868465};\\\", \\\"{x:1298,y:576,t:1527188868481};\\\", \\\"{x:1298,y:610,t:1527188868498};\\\", \\\"{x:1298,y:649,t:1527188868515};\\\", \\\"{x:1303,y:678,t:1527188868531};\\\", \\\"{x:1306,y:703,t:1527188868548};\\\", \\\"{x:1309,y:724,t:1527188868565};\\\", \\\"{x:1309,y:738,t:1527188868581};\\\", \\\"{x:1311,y:752,t:1527188868598};\\\", \\\"{x:1312,y:768,t:1527188868615};\\\", \\\"{x:1315,y:784,t:1527188868631};\\\", \\\"{x:1316,y:795,t:1527188868648};\\\", \\\"{x:1317,y:806,t:1527188868664};\\\", \\\"{x:1317,y:817,t:1527188868681};\\\", \\\"{x:1317,y:831,t:1527188868697};\\\", \\\"{x:1319,y:838,t:1527188868715};\\\", \\\"{x:1319,y:842,t:1527188868731};\\\", \\\"{x:1319,y:847,t:1527188868748};\\\", \\\"{x:1319,y:849,t:1527188868765};\\\", \\\"{x:1319,y:853,t:1527188868781};\\\", \\\"{x:1318,y:861,t:1527188868798};\\\", \\\"{x:1317,y:866,t:1527188868815};\\\", \\\"{x:1317,y:868,t:1527188868831};\\\", \\\"{x:1317,y:870,t:1527188868848};\\\", \\\"{x:1317,y:871,t:1527188868865};\\\", \\\"{x:1316,y:877,t:1527188868881};\\\", \\\"{x:1314,y:890,t:1527188868898};\\\", \\\"{x:1311,y:899,t:1527188868915};\\\", \\\"{x:1311,y:906,t:1527188868931};\\\", \\\"{x:1310,y:913,t:1527188868948};\\\", \\\"{x:1310,y:920,t:1527188868965};\\\", \\\"{x:1310,y:926,t:1527188868981};\\\", \\\"{x:1310,y:928,t:1527188868998};\\\", \\\"{x:1310,y:930,t:1527188869015};\\\", \\\"{x:1309,y:930,t:1527188869033};\\\", \\\"{x:1309,y:931,t:1527188869048};\\\", \\\"{x:1309,y:934,t:1527188869065};\\\", \\\"{x:1309,y:938,t:1527188869081};\\\", \\\"{x:1309,y:941,t:1527188869098};\\\", \\\"{x:1309,y:940,t:1527188869457};\\\", \\\"{x:1310,y:939,t:1527188869466};\\\", \\\"{x:1311,y:938,t:1527188869481};\\\", \\\"{x:1315,y:932,t:1527188869497};\\\", \\\"{x:1319,y:929,t:1527188869515};\\\", \\\"{x:1322,y:927,t:1527188869531};\\\", \\\"{x:1325,y:925,t:1527188869548};\\\", \\\"{x:1327,y:923,t:1527188869565};\\\", \\\"{x:1331,y:920,t:1527188869582};\\\", \\\"{x:1333,y:919,t:1527188869598};\\\", \\\"{x:1337,y:915,t:1527188869615};\\\", \\\"{x:1341,y:913,t:1527188869632};\\\", \\\"{x:1344,y:911,t:1527188869648};\\\", \\\"{x:1346,y:909,t:1527188869665};\\\", \\\"{x:1351,y:907,t:1527188869682};\\\", \\\"{x:1353,y:905,t:1527188869698};\\\", \\\"{x:1354,y:905,t:1527188870177};\\\", \\\"{x:1355,y:903,t:1527188870273};\\\", \\\"{x:1357,y:897,t:1527188870282};\\\", \\\"{x:1360,y:890,t:1527188870298};\\\", \\\"{x:1363,y:884,t:1527188870315};\\\", \\\"{x:1366,y:878,t:1527188870332};\\\", \\\"{x:1372,y:872,t:1527188870349};\\\", \\\"{x:1374,y:870,t:1527188870365};\\\", \\\"{x:1375,y:869,t:1527188870386};\\\", \\\"{x:1375,y:868,t:1527188870398};\\\", \\\"{x:1376,y:868,t:1527188870416};\\\", \\\"{x:1377,y:868,t:1527188870432};\\\", \\\"{x:1379,y:867,t:1527188870449};\\\", \\\"{x:1380,y:867,t:1527188870466};\\\", \\\"{x:1388,y:867,t:1527188870482};\\\", \\\"{x:1391,y:867,t:1527188870499};\\\", \\\"{x:1392,y:867,t:1527188870515};\\\", \\\"{x:1393,y:867,t:1527188870533};\\\", \\\"{x:1394,y:867,t:1527188870549};\\\", \\\"{x:1397,y:867,t:1527188870565};\\\", \\\"{x:1401,y:868,t:1527188870582};\\\", \\\"{x:1404,y:870,t:1527188870598};\\\", \\\"{x:1409,y:871,t:1527188870615};\\\", \\\"{x:1411,y:871,t:1527188870632};\\\", \\\"{x:1412,y:872,t:1527188870649};\\\", \\\"{x:1412,y:873,t:1527188870665};\\\", \\\"{x:1415,y:875,t:1527188870682};\\\", \\\"{x:1417,y:877,t:1527188870699};\\\", \\\"{x:1419,y:879,t:1527188870715};\\\", \\\"{x:1421,y:882,t:1527188870732};\\\", \\\"{x:1425,y:887,t:1527188870749};\\\", \\\"{x:1429,y:891,t:1527188870765};\\\", \\\"{x:1431,y:895,t:1527188870782};\\\", \\\"{x:1435,y:899,t:1527188870799};\\\", \\\"{x:1437,y:902,t:1527188870815};\\\", \\\"{x:1437,y:905,t:1527188870833};\\\", \\\"{x:1440,y:908,t:1527188870848};\\\", \\\"{x:1441,y:913,t:1527188870865};\\\", \\\"{x:1445,y:919,t:1527188870881};\\\", \\\"{x:1445,y:920,t:1527188870900};\\\", \\\"{x:1445,y:921,t:1527188870915};\\\", \\\"{x:1446,y:922,t:1527188870933};\\\", \\\"{x:1446,y:923,t:1527188870970};\\\", \\\"{x:1447,y:924,t:1527188870985};\\\", \\\"{x:1448,y:924,t:1527188871018};\\\", \\\"{x:1449,y:924,t:1527188871034};\\\", \\\"{x:1449,y:925,t:1527188871049};\\\", \\\"{x:1451,y:926,t:1527188871065};\\\", \\\"{x:1458,y:930,t:1527188871082};\\\", \\\"{x:1463,y:933,t:1527188871099};\\\", \\\"{x:1466,y:935,t:1527188871115};\\\", \\\"{x:1469,y:938,t:1527188871132};\\\", \\\"{x:1471,y:941,t:1527188871149};\\\", \\\"{x:1475,y:944,t:1527188871165};\\\", \\\"{x:1476,y:947,t:1527188871182};\\\", \\\"{x:1478,y:950,t:1527188871199};\\\", \\\"{x:1479,y:951,t:1527188871214};\\\", \\\"{x:1479,y:952,t:1527188871305};\\\", \\\"{x:1483,y:950,t:1527188871482};\\\", \\\"{x:1493,y:940,t:1527188871499};\\\", \\\"{x:1501,y:935,t:1527188871515};\\\", \\\"{x:1504,y:931,t:1527188871532};\\\", \\\"{x:1507,y:928,t:1527188871549};\\\", \\\"{x:1508,y:925,t:1527188871565};\\\", \\\"{x:1509,y:924,t:1527188871582};\\\", \\\"{x:1509,y:922,t:1527188871599};\\\", \\\"{x:1509,y:920,t:1527188871615};\\\", \\\"{x:1509,y:918,t:1527188871632};\\\", \\\"{x:1509,y:915,t:1527188871649};\\\", \\\"{x:1509,y:913,t:1527188871810};\\\", \\\"{x:1508,y:913,t:1527188871866};\\\", \\\"{x:1508,y:912,t:1527188871882};\\\", \\\"{x:1507,y:912,t:1527188871899};\\\", \\\"{x:1505,y:911,t:1527188871915};\\\", \\\"{x:1502,y:909,t:1527188871932};\\\", \\\"{x:1501,y:909,t:1527188871950};\\\", \\\"{x:1501,y:908,t:1527188871978};\\\", \\\"{x:1499,y:905,t:1527188871986};\\\", \\\"{x:1498,y:903,t:1527188872002};\\\", \\\"{x:1497,y:901,t:1527188872015};\\\", \\\"{x:1495,y:897,t:1527188872032};\\\", \\\"{x:1493,y:893,t:1527188872049};\\\", \\\"{x:1491,y:887,t:1527188872066};\\\", \\\"{x:1488,y:882,t:1527188872082};\\\", \\\"{x:1487,y:880,t:1527188872099};\\\", \\\"{x:1487,y:879,t:1527188872116};\\\", \\\"{x:1486,y:877,t:1527188872132};\\\", \\\"{x:1484,y:874,t:1527188872149};\\\", \\\"{x:1482,y:870,t:1527188872166};\\\", \\\"{x:1481,y:867,t:1527188872182};\\\", \\\"{x:1481,y:865,t:1527188872199};\\\", \\\"{x:1480,y:864,t:1527188872216};\\\", \\\"{x:1479,y:861,t:1527188872232};\\\", \\\"{x:1478,y:859,t:1527188872249};\\\", \\\"{x:1477,y:856,t:1527188872266};\\\", \\\"{x:1476,y:853,t:1527188872282};\\\", \\\"{x:1476,y:851,t:1527188872307};\\\", \\\"{x:1474,y:849,t:1527188872317};\\\", \\\"{x:1474,y:848,t:1527188872338};\\\", \\\"{x:1473,y:847,t:1527188872350};\\\", \\\"{x:1473,y:845,t:1527188872370};\\\", \\\"{x:1473,y:843,t:1527188873516};\\\", \\\"{x:1473,y:840,t:1527188873523};\\\", \\\"{x:1473,y:839,t:1527188873539};\\\", \\\"{x:1473,y:837,t:1527188873550};\\\", \\\"{x:1473,y:835,t:1527188873566};\\\", \\\"{x:1473,y:831,t:1527188873584};\\\", \\\"{x:1471,y:829,t:1527188873600};\\\", \\\"{x:1471,y:827,t:1527188873617};\\\", \\\"{x:1471,y:825,t:1527188874066};\\\", \\\"{x:1469,y:825,t:1527188874122};\\\", \\\"{x:1469,y:824,t:1527188874134};\\\", \\\"{x:1467,y:823,t:1527188874149};\\\", \\\"{x:1464,y:823,t:1527188874166};\\\", \\\"{x:1462,y:822,t:1527188874183};\\\", \\\"{x:1460,y:821,t:1527188874199};\\\", \\\"{x:1460,y:820,t:1527188874216};\\\", \\\"{x:1459,y:820,t:1527188874435};\\\", \\\"{x:1453,y:819,t:1527188874450};\\\", \\\"{x:1444,y:814,t:1527188874467};\\\", \\\"{x:1429,y:807,t:1527188874483};\\\", \\\"{x:1413,y:796,t:1527188874500};\\\", \\\"{x:1394,y:787,t:1527188874516};\\\", \\\"{x:1375,y:777,t:1527188874534};\\\", \\\"{x:1368,y:772,t:1527188874551};\\\", \\\"{x:1362,y:768,t:1527188874566};\\\", \\\"{x:1359,y:765,t:1527188874583};\\\", \\\"{x:1356,y:762,t:1527188874600};\\\", \\\"{x:1353,y:761,t:1527188874617};\\\", \\\"{x:1353,y:750,t:1527188874634};\\\", \\\"{x:1354,y:732,t:1527188874650};\\\", \\\"{x:1362,y:714,t:1527188874667};\\\", \\\"{x:1366,y:697,t:1527188874684};\\\", \\\"{x:1368,y:685,t:1527188874701};\\\", \\\"{x:1373,y:670,t:1527188874716};\\\", \\\"{x:1377,y:661,t:1527188874734};\\\", \\\"{x:1379,y:656,t:1527188874751};\\\", \\\"{x:1384,y:647,t:1527188874767};\\\", \\\"{x:1389,y:641,t:1527188874784};\\\", \\\"{x:1394,y:633,t:1527188874801};\\\", \\\"{x:1396,y:629,t:1527188874817};\\\", \\\"{x:1399,y:623,t:1527188874834};\\\", \\\"{x:1399,y:617,t:1527188874849};\\\", \\\"{x:1399,y:613,t:1527188874866};\\\", \\\"{x:1401,y:606,t:1527188874884};\\\", \\\"{x:1401,y:601,t:1527188874901};\\\", \\\"{x:1402,y:596,t:1527188874917};\\\", \\\"{x:1403,y:592,t:1527188874933};\\\", \\\"{x:1403,y:590,t:1527188874951};\\\", \\\"{x:1403,y:587,t:1527188874966};\\\", \\\"{x:1401,y:584,t:1527188874984};\\\", \\\"{x:1401,y:579,t:1527188875000};\\\", \\\"{x:1401,y:573,t:1527188875017};\\\", \\\"{x:1400,y:567,t:1527188875034};\\\", \\\"{x:1400,y:564,t:1527188875050};\\\", \\\"{x:1400,y:562,t:1527188875067};\\\", \\\"{x:1400,y:561,t:1527188875084};\\\", \\\"{x:1400,y:559,t:1527188875114};\\\", \\\"{x:1399,y:558,t:1527188875178};\\\", \\\"{x:1401,y:558,t:1527188875555};\\\", \\\"{x:1402,y:557,t:1527188875567};\\\", \\\"{x:1405,y:557,t:1527188876412};\\\", \\\"{x:1408,y:558,t:1527188876426};\\\", \\\"{x:1409,y:559,t:1527188876435};\\\", \\\"{x:1411,y:559,t:1527188876451};\\\", \\\"{x:1412,y:560,t:1527188876715};\\\", \\\"{x:1411,y:560,t:1527188879962};\\\", \\\"{x:1408,y:561,t:1527188879971};\\\", \\\"{x:1403,y:561,t:1527188879985};\\\", \\\"{x:1382,y:557,t:1527188880002};\\\", \\\"{x:1378,y:556,t:1527188880019};\\\", \\\"{x:1377,y:543,t:1527188880035};\\\", \\\"{x:1377,y:517,t:1527188880052};\\\", \\\"{x:1377,y:498,t:1527188880070};\\\", \\\"{x:1377,y:483,t:1527188880085};\\\", \\\"{x:1380,y:468,t:1527188880102};\\\", \\\"{x:1381,y:460,t:1527188880119};\\\", \\\"{x:1381,y:455,t:1527188880135};\\\", \\\"{x:1381,y:452,t:1527188880153};\\\", \\\"{x:1381,y:450,t:1527188880169};\\\", \\\"{x:1381,y:449,t:1527188880186};\\\", \\\"{x:1381,y:447,t:1527188880202};\\\", \\\"{x:1381,y:446,t:1527188880219};\\\", \\\"{x:1381,y:445,t:1527188880315};\\\", \\\"{x:1381,y:443,t:1527188880322};\\\", \\\"{x:1382,y:442,t:1527188880335};\\\", \\\"{x:1387,y:439,t:1527188880352};\\\", \\\"{x:1389,y:438,t:1527188880369};\\\", \\\"{x:1390,y:438,t:1527188880419};\\\", \\\"{x:1390,y:437,t:1527188880435};\\\", \\\"{x:1391,y:437,t:1527188880451};\\\", \\\"{x:1392,y:437,t:1527188880468};\\\", \\\"{x:1394,y:436,t:1527188880484};\\\", \\\"{x:1394,y:435,t:1527188880501};\\\", \\\"{x:1396,y:435,t:1527188880519};\\\", \\\"{x:1400,y:434,t:1527188880535};\\\", \\\"{x:1403,y:432,t:1527188880551};\\\", \\\"{x:1405,y:431,t:1527188880569};\\\", \\\"{x:1406,y:431,t:1527188880585};\\\", \\\"{x:1409,y:429,t:1527188880602};\\\", \\\"{x:1410,y:429,t:1527188880619};\\\", \\\"{x:1411,y:428,t:1527188880635};\\\", \\\"{x:1410,y:428,t:1527188880827};\\\", \\\"{x:1407,y:429,t:1527188880844};\\\", \\\"{x:1404,y:430,t:1527188880867};\\\", \\\"{x:1403,y:430,t:1527188880882};\\\", \\\"{x:1402,y:430,t:1527188880898};\\\", \\\"{x:1400,y:432,t:1527188880906};\\\", \\\"{x:1399,y:432,t:1527188880919};\\\", \\\"{x:1396,y:434,t:1527188880936};\\\", \\\"{x:1392,y:435,t:1527188880953};\\\", \\\"{x:1391,y:436,t:1527188880970};\\\", \\\"{x:1389,y:436,t:1527188880986};\\\", \\\"{x:1388,y:437,t:1527188881002};\\\", \\\"{x:1385,y:438,t:1527188881019};\\\", \\\"{x:1384,y:439,t:1527188881036};\\\", \\\"{x:1381,y:440,t:1527188881053};\\\", \\\"{x:1378,y:442,t:1527188881070};\\\", \\\"{x:1376,y:442,t:1527188881086};\\\", \\\"{x:1372,y:444,t:1527188881102};\\\", \\\"{x:1365,y:447,t:1527188881120};\\\", \\\"{x:1360,y:449,t:1527188881136};\\\", \\\"{x:1350,y:453,t:1527188881152};\\\", \\\"{x:1344,y:456,t:1527188881169};\\\", \\\"{x:1341,y:458,t:1527188881186};\\\", \\\"{x:1340,y:459,t:1527188881218};\\\", \\\"{x:1338,y:459,t:1527188881236};\\\", \\\"{x:1334,y:462,t:1527188881252};\\\", \\\"{x:1332,y:463,t:1527188881270};\\\", \\\"{x:1330,y:464,t:1527188881287};\\\", \\\"{x:1324,y:471,t:1527188881303};\\\", \\\"{x:1316,y:482,t:1527188881319};\\\", \\\"{x:1311,y:489,t:1527188881337};\\\", \\\"{x:1304,y:497,t:1527188881353};\\\", \\\"{x:1302,y:504,t:1527188881369};\\\", \\\"{x:1290,y:527,t:1527188881386};\\\", \\\"{x:1284,y:543,t:1527188881402};\\\", \\\"{x:1277,y:558,t:1527188881419};\\\", \\\"{x:1272,y:567,t:1527188881436};\\\", \\\"{x:1270,y:573,t:1527188881452};\\\", \\\"{x:1268,y:579,t:1527188881469};\\\", \\\"{x:1267,y:588,t:1527188881486};\\\", \\\"{x:1264,y:597,t:1527188881503};\\\", \\\"{x:1264,y:613,t:1527188881519};\\\", \\\"{x:1264,y:622,t:1527188881536};\\\", \\\"{x:1264,y:630,t:1527188881553};\\\", \\\"{x:1264,y:633,t:1527188881569};\\\", \\\"{x:1265,y:634,t:1527188881602};\\\", \\\"{x:1266,y:636,t:1527188881619};\\\", \\\"{x:1268,y:637,t:1527188881637};\\\", \\\"{x:1273,y:640,t:1527188881652};\\\", \\\"{x:1277,y:640,t:1527188881669};\\\", \\\"{x:1278,y:641,t:1527188881687};\\\", \\\"{x:1280,y:641,t:1527188881702};\\\", \\\"{x:1282,y:641,t:1527188881889};\\\", \\\"{x:1285,y:641,t:1527188881902};\\\", \\\"{x:1286,y:640,t:1527188881919};\\\", \\\"{x:1289,y:639,t:1527188881936};\\\", \\\"{x:1291,y:638,t:1527188881953};\\\", \\\"{x:1292,y:638,t:1527188881969};\\\", \\\"{x:1294,y:637,t:1527188882033};\\\", \\\"{x:1295,y:636,t:1527188882042};\\\", \\\"{x:1299,y:635,t:1527188882052};\\\", \\\"{x:1302,y:633,t:1527188882069};\\\", \\\"{x:1307,y:632,t:1527188882086};\\\", \\\"{x:1310,y:630,t:1527188882103};\\\", \\\"{x:1312,y:629,t:1527188882119};\\\", \\\"{x:1314,y:628,t:1527188882135};\\\", \\\"{x:1315,y:630,t:1527188882770};\\\", \\\"{x:1316,y:637,t:1527188882785};\\\", \\\"{x:1316,y:642,t:1527188882803};\\\", \\\"{x:1317,y:647,t:1527188882819};\\\", \\\"{x:1318,y:652,t:1527188882836};\\\", \\\"{x:1318,y:657,t:1527188882852};\\\", \\\"{x:1320,y:663,t:1527188882869};\\\", \\\"{x:1322,y:669,t:1527188882886};\\\", \\\"{x:1323,y:672,t:1527188882903};\\\", \\\"{x:1324,y:676,t:1527188882919};\\\", \\\"{x:1325,y:680,t:1527188882936};\\\", \\\"{x:1325,y:685,t:1527188882953};\\\", \\\"{x:1326,y:690,t:1527188882969};\\\", \\\"{x:1327,y:700,t:1527188882986};\\\", \\\"{x:1328,y:706,t:1527188883003};\\\", \\\"{x:1329,y:710,t:1527188883019};\\\", \\\"{x:1330,y:716,t:1527188883037};\\\", \\\"{x:1330,y:720,t:1527188883053};\\\", \\\"{x:1330,y:725,t:1527188883069};\\\", \\\"{x:1332,y:731,t:1527188883086};\\\", \\\"{x:1333,y:735,t:1527188883103};\\\", \\\"{x:1333,y:739,t:1527188883119};\\\", \\\"{x:1333,y:742,t:1527188883136};\\\", \\\"{x:1333,y:743,t:1527188883154};\\\", \\\"{x:1333,y:745,t:1527188883170};\\\", \\\"{x:1334,y:746,t:1527188883186};\\\", \\\"{x:1334,y:749,t:1527188883204};\\\", \\\"{x:1334,y:751,t:1527188883219};\\\", \\\"{x:1334,y:752,t:1527188883236};\\\", \\\"{x:1334,y:753,t:1527188883254};\\\", \\\"{x:1334,y:754,t:1527188883270};\\\", \\\"{x:1334,y:755,t:1527188883286};\\\", \\\"{x:1334,y:756,t:1527188883315};\\\", \\\"{x:1334,y:757,t:1527188883371};\\\", \\\"{x:1334,y:758,t:1527188883402};\\\", \\\"{x:1334,y:759,t:1527188883420};\\\", \\\"{x:1334,y:760,t:1527188883436};\\\", \\\"{x:1334,y:761,t:1527188883482};\\\", \\\"{x:1334,y:762,t:1527188883499};\\\", \\\"{x:1334,y:763,t:1527188883514};\\\", \\\"{x:1334,y:764,t:1527188883546};\\\", \\\"{x:1334,y:766,t:1527188883610};\\\", \\\"{x:1334,y:767,t:1527188883625};\\\", \\\"{x:1334,y:769,t:1527188883650};\\\", \\\"{x:1334,y:770,t:1527188883747};\\\", \\\"{x:1337,y:770,t:1527188885650};\\\", \\\"{x:1345,y:771,t:1527188885658};\\\", \\\"{x:1352,y:773,t:1527188885670};\\\", \\\"{x:1368,y:773,t:1527188885687};\\\", \\\"{x:1380,y:773,t:1527188885704};\\\", \\\"{x:1388,y:772,t:1527188885719};\\\", \\\"{x:1391,y:771,t:1527188885737};\\\", \\\"{x:1392,y:771,t:1527188885753};\\\", \\\"{x:1393,y:770,t:1527188886338};\\\", \\\"{x:1393,y:771,t:1527188886371};\\\", \\\"{x:1393,y:774,t:1527188886387};\\\", \\\"{x:1393,y:776,t:1527188886405};\\\", \\\"{x:1393,y:777,t:1527188886421};\\\", \\\"{x:1393,y:779,t:1527188886437};\\\", \\\"{x:1393,y:780,t:1527188886455};\\\", \\\"{x:1394,y:782,t:1527188886471};\\\", \\\"{x:1394,y:783,t:1527188886487};\\\", \\\"{x:1394,y:785,t:1527188886531};\\\", \\\"{x:1394,y:786,t:1527188886546};\\\", \\\"{x:1395,y:788,t:1527188886554};\\\", \\\"{x:1395,y:791,t:1527188886571};\\\", \\\"{x:1396,y:795,t:1527188886588};\\\", \\\"{x:1396,y:797,t:1527188886605};\\\", \\\"{x:1396,y:799,t:1527188886620};\\\", \\\"{x:1397,y:801,t:1527188886637};\\\", \\\"{x:1397,y:803,t:1527188886653};\\\", \\\"{x:1397,y:805,t:1527188886671};\\\", \\\"{x:1397,y:806,t:1527188886686};\\\", \\\"{x:1397,y:808,t:1527188886704};\\\", \\\"{x:1397,y:810,t:1527188886721};\\\", \\\"{x:1398,y:812,t:1527188886737};\\\", \\\"{x:1398,y:815,t:1527188886753};\\\", \\\"{x:1398,y:816,t:1527188886771};\\\", \\\"{x:1398,y:818,t:1527188886794};\\\", \\\"{x:1398,y:819,t:1527188886810};\\\", \\\"{x:1398,y:821,t:1527188886821};\\\", \\\"{x:1398,y:823,t:1527188886837};\\\", \\\"{x:1398,y:827,t:1527188886854};\\\", \\\"{x:1398,y:828,t:1527188886871};\\\", \\\"{x:1398,y:831,t:1527188886887};\\\", \\\"{x:1398,y:833,t:1527188886903};\\\", \\\"{x:1398,y:835,t:1527188886921};\\\", \\\"{x:1398,y:840,t:1527188886937};\\\", \\\"{x:1398,y:845,t:1527188886954};\\\", \\\"{x:1398,y:848,t:1527188886971};\\\", \\\"{x:1398,y:850,t:1527188886987};\\\", \\\"{x:1398,y:851,t:1527188887004};\\\", \\\"{x:1398,y:853,t:1527188887021};\\\", \\\"{x:1398,y:855,t:1527188887037};\\\", \\\"{x:1397,y:859,t:1527188887054};\\\", \\\"{x:1397,y:861,t:1527188887071};\\\", \\\"{x:1397,y:862,t:1527188887087};\\\", \\\"{x:1397,y:865,t:1527188887104};\\\", \\\"{x:1397,y:868,t:1527188887122};\\\", \\\"{x:1397,y:871,t:1527188887138};\\\", \\\"{x:1395,y:877,t:1527188887154};\\\", \\\"{x:1394,y:879,t:1527188887172};\\\", \\\"{x:1394,y:882,t:1527188887188};\\\", \\\"{x:1394,y:885,t:1527188887204};\\\", \\\"{x:1394,y:889,t:1527188887221};\\\", \\\"{x:1393,y:896,t:1527188887237};\\\", \\\"{x:1393,y:899,t:1527188887254};\\\", \\\"{x:1391,y:902,t:1527188887271};\\\", \\\"{x:1391,y:904,t:1527188887287};\\\", \\\"{x:1391,y:906,t:1527188887304};\\\", \\\"{x:1391,y:907,t:1527188887321};\\\", \\\"{x:1391,y:909,t:1527188887337};\\\", \\\"{x:1390,y:912,t:1527188887353};\\\", \\\"{x:1390,y:915,t:1527188887371};\\\", \\\"{x:1388,y:918,t:1527188887387};\\\", \\\"{x:1388,y:922,t:1527188887404};\\\", \\\"{x:1387,y:924,t:1527188887421};\\\", \\\"{x:1387,y:926,t:1527188887438};\\\", \\\"{x:1386,y:930,t:1527188887455};\\\", \\\"{x:1386,y:933,t:1527188887471};\\\", \\\"{x:1384,y:936,t:1527188887487};\\\", \\\"{x:1384,y:937,t:1527188887504};\\\", \\\"{x:1384,y:940,t:1527188887521};\\\", \\\"{x:1384,y:941,t:1527188887537};\\\", \\\"{x:1384,y:943,t:1527188887554};\\\", \\\"{x:1383,y:946,t:1527188887571};\\\", \\\"{x:1383,y:947,t:1527188887594};\\\", \\\"{x:1383,y:948,t:1527188887612};\\\", \\\"{x:1383,y:949,t:1527188887625};\\\", \\\"{x:1383,y:950,t:1527188887657};\\\", \\\"{x:1383,y:951,t:1527188887671};\\\", \\\"{x:1382,y:952,t:1527188887687};\\\", \\\"{x:1381,y:952,t:1527188887704};\\\", \\\"{x:1381,y:953,t:1527188887737};\\\", \\\"{x:1381,y:954,t:1527188887754};\\\", \\\"{x:1381,y:955,t:1527188887786};\\\", \\\"{x:1381,y:956,t:1527188887826};\\\", \\\"{x:1380,y:946,t:1527188888226};\\\", \\\"{x:1378,y:927,t:1527188888238};\\\", \\\"{x:1373,y:893,t:1527188888255};\\\", \\\"{x:1372,y:866,t:1527188888272};\\\", \\\"{x:1369,y:848,t:1527188888289};\\\", \\\"{x:1365,y:837,t:1527188888305};\\\", \\\"{x:1364,y:829,t:1527188888322};\\\", \\\"{x:1363,y:816,t:1527188888339};\\\", \\\"{x:1360,y:805,t:1527188888355};\\\", \\\"{x:1360,y:797,t:1527188888372};\\\", \\\"{x:1360,y:793,t:1527188888389};\\\", \\\"{x:1359,y:788,t:1527188888405};\\\", \\\"{x:1359,y:787,t:1527188888421};\\\", \\\"{x:1358,y:785,t:1527188888439};\\\", \\\"{x:1358,y:784,t:1527188888467};\\\", \\\"{x:1358,y:783,t:1527188888474};\\\", \\\"{x:1358,y:782,t:1527188888489};\\\", \\\"{x:1358,y:781,t:1527188888505};\\\", \\\"{x:1358,y:780,t:1527188888553};\\\", \\\"{x:1357,y:776,t:1527188888723};\\\", \\\"{x:1319,y:761,t:1527188888738};\\\", \\\"{x:1279,y:745,t:1527188888755};\\\", \\\"{x:1238,y:730,t:1527188888771};\\\", \\\"{x:1194,y:720,t:1527188888788};\\\", \\\"{x:1145,y:709,t:1527188888804};\\\", \\\"{x:1084,y:692,t:1527188888821};\\\", \\\"{x:1021,y:677,t:1527188888839};\\\", \\\"{x:965,y:671,t:1527188888855};\\\", \\\"{x:943,y:665,t:1527188888872};\\\", \\\"{x:937,y:664,t:1527188888888};\\\", \\\"{x:934,y:664,t:1527188888904};\\\", \\\"{x:925,y:664,t:1527188888921};\\\", \\\"{x:906,y:664,t:1527188888938};\\\", \\\"{x:891,y:664,t:1527188888954};\\\", \\\"{x:865,y:664,t:1527188888971};\\\", \\\"{x:841,y:663,t:1527188888988};\\\", \\\"{x:817,y:659,t:1527188889004};\\\", \\\"{x:773,y:650,t:1527188889021};\\\", \\\"{x:720,y:634,t:1527188889039};\\\", \\\"{x:650,y:615,t:1527188889055};\\\", \\\"{x:587,y:599,t:1527188889071};\\\", \\\"{x:557,y:591,t:1527188889081};\\\", \\\"{x:509,y:577,t:1527188889097};\\\", \\\"{x:439,y:556,t:1527188889115};\\\", \\\"{x:401,y:542,t:1527188889132};\\\", \\\"{x:368,y:527,t:1527188889149};\\\", \\\"{x:348,y:518,t:1527188889166};\\\", \\\"{x:344,y:517,t:1527188889182};\\\", \\\"{x:343,y:518,t:1527188889354};\\\", \\\"{x:343,y:525,t:1527188889366};\\\", \\\"{x:343,y:539,t:1527188889382};\\\", \\\"{x:343,y:550,t:1527188889399};\\\", \\\"{x:343,y:558,t:1527188889416};\\\", \\\"{x:343,y:565,t:1527188889432};\\\", \\\"{x:343,y:575,t:1527188889448};\\\", \\\"{x:345,y:600,t:1527188889466};\\\", \\\"{x:348,y:612,t:1527188889482};\\\", \\\"{x:351,y:618,t:1527188889499};\\\", \\\"{x:351,y:619,t:1527188889516};\\\", \\\"{x:353,y:619,t:1527188889553};\\\", \\\"{x:355,y:619,t:1527188889566};\\\", \\\"{x:368,y:616,t:1527188889583};\\\", \\\"{x:388,y:607,t:1527188889599};\\\", \\\"{x:403,y:601,t:1527188889617};\\\", \\\"{x:409,y:598,t:1527188889634};\\\", \\\"{x:412,y:598,t:1527188889649};\\\", \\\"{x:412,y:597,t:1527188889762};\\\", \\\"{x:412,y:596,t:1527188889778};\\\", \\\"{x:412,y:595,t:1527188889788};\\\", \\\"{x:410,y:594,t:1527188889799};\\\", \\\"{x:405,y:591,t:1527188889816};\\\", \\\"{x:401,y:590,t:1527188889833};\\\", \\\"{x:395,y:587,t:1527188889849};\\\", \\\"{x:393,y:586,t:1527188889866};\\\", \\\"{x:391,y:586,t:1527188889889};\\\", \\\"{x:390,y:586,t:1527188889905};\\\", \\\"{x:389,y:584,t:1527188889917};\\\", \\\"{x:390,y:584,t:1527188890250};\\\", \\\"{x:405,y:599,t:1527188890267};\\\", \\\"{x:420,y:615,t:1527188890284};\\\", \\\"{x:435,y:632,t:1527188890301};\\\", \\\"{x:450,y:652,t:1527188890317};\\\", \\\"{x:465,y:672,t:1527188890333};\\\", \\\"{x:481,y:689,t:1527188890350};\\\", \\\"{x:494,y:700,t:1527188890366};\\\", \\\"{x:500,y:706,t:1527188890383};\\\", \\\"{x:503,y:709,t:1527188890400};\\\", \\\"{x:505,y:712,t:1527188890416};\\\", \\\"{x:505,y:713,t:1527188890433};\\\", \\\"{x:506,y:715,t:1527188890866};\\\", \\\"{x:506,y:724,t:1527188890884};\\\", \\\"{x:506,y:732,t:1527188890900};\\\", \\\"{x:506,y:738,t:1527188890917};\\\", \\\"{x:503,y:744,t:1527188890934};\\\", \\\"{x:503,y:746,t:1527188890950};\\\", \\\"{x:503,y:747,t:1527188890968};\\\", \\\"{x:505,y:746,t:1527188891411};\\\", \\\"{x:512,y:741,t:1527188891418};\\\", \\\"{x:536,y:731,t:1527188891435};\\\", \\\"{x:567,y:717,t:1527188891451};\\\", \\\"{x:603,y:702,t:1527188891467};\\\", \\\"{x:643,y:689,t:1527188891484};\\\", \\\"{x:691,y:675,t:1527188891501};\\\", \\\"{x:734,y:665,t:1527188891517};\\\", \\\"{x:766,y:656,t:1527188891534};\\\", \\\"{x:784,y:651,t:1527188891551};\\\", \\\"{x:792,y:649,t:1527188891568};\\\", \\\"{x:793,y:648,t:1527188891585};\\\", \\\"{x:794,y:648,t:1527188891601};\\\", \\\"{x:795,y:648,t:1527188891683};\\\", \\\"{x:796,y:647,t:1527188891794};\\\", \\\"{x:796,y:646,t:1527188891809};\\\", \\\"{x:796,y:645,t:1527188891883};\\\", \\\"{x:796,y:644,t:1527188891898};\\\", \\\"{x:796,y:643,t:1527188891913};\\\", \\\"{x:795,y:643,t:1527188891946};\\\" ] }, { \\\"rt\\\": 7977, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 280332, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:795,y:642,t:1527188895322};\\\", \\\"{x:797,y:640,t:1527188895354};\\\", \\\"{x:815,y:623,t:1527188895372};\\\", \\\"{x:836,y:612,t:1527188895387};\\\", \\\"{x:859,y:602,t:1527188895405};\\\", \\\"{x:884,y:594,t:1527188895420};\\\", \\\"{x:906,y:588,t:1527188895436};\\\", \\\"{x:926,y:582,t:1527188895454};\\\", \\\"{x:939,y:579,t:1527188895470};\\\", \\\"{x:952,y:574,t:1527188895487};\\\", \\\"{x:963,y:573,t:1527188895504};\\\", \\\"{x:979,y:568,t:1527188895520};\\\", \\\"{x:1002,y:562,t:1527188895537};\\\", \\\"{x:1027,y:559,t:1527188895554};\\\", \\\"{x:1052,y:559,t:1527188895571};\\\", \\\"{x:1079,y:556,t:1527188895588};\\\", \\\"{x:1108,y:553,t:1527188895604};\\\", \\\"{x:1137,y:552,t:1527188895620};\\\", \\\"{x:1161,y:550,t:1527188895637};\\\", \\\"{x:1187,y:550,t:1527188895654};\\\", \\\"{x:1208,y:550,t:1527188895672};\\\", \\\"{x:1224,y:550,t:1527188895688};\\\", \\\"{x:1234,y:550,t:1527188895705};\\\", \\\"{x:1241,y:550,t:1527188895722};\\\", \\\"{x:1246,y:550,t:1527188895737};\\\", \\\"{x:1249,y:550,t:1527188895754};\\\", \\\"{x:1251,y:550,t:1527188895772};\\\", \\\"{x:1252,y:550,t:1527188895788};\\\", \\\"{x:1255,y:552,t:1527188895890};\\\", \\\"{x:1256,y:552,t:1527188895905};\\\", \\\"{x:1263,y:555,t:1527188895922};\\\", \\\"{x:1271,y:556,t:1527188895937};\\\", \\\"{x:1277,y:559,t:1527188895955};\\\", \\\"{x:1285,y:561,t:1527188895971};\\\", \\\"{x:1290,y:561,t:1527188895988};\\\", \\\"{x:1294,y:563,t:1527188896004};\\\", \\\"{x:1298,y:563,t:1527188896021};\\\", \\\"{x:1303,y:564,t:1527188896038};\\\", \\\"{x:1309,y:564,t:1527188896054};\\\", \\\"{x:1311,y:564,t:1527188896071};\\\", \\\"{x:1316,y:564,t:1527188896087};\\\", \\\"{x:1323,y:564,t:1527188896104};\\\", \\\"{x:1333,y:564,t:1527188896121};\\\", \\\"{x:1339,y:564,t:1527188896138};\\\", \\\"{x:1343,y:564,t:1527188896155};\\\", \\\"{x:1344,y:564,t:1527188896172};\\\", \\\"{x:1347,y:564,t:1527188896188};\\\", \\\"{x:1355,y:563,t:1527188896205};\\\", \\\"{x:1365,y:561,t:1527188896222};\\\", \\\"{x:1375,y:559,t:1527188896238};\\\", \\\"{x:1385,y:558,t:1527188896254};\\\", \\\"{x:1400,y:556,t:1527188896272};\\\", \\\"{x:1420,y:554,t:1527188896288};\\\", \\\"{x:1429,y:554,t:1527188896304};\\\", \\\"{x:1436,y:554,t:1527188896321};\\\", \\\"{x:1428,y:554,t:1527188896370};\\\", \\\"{x:1416,y:559,t:1527188896378};\\\", \\\"{x:1400,y:561,t:1527188896389};\\\", \\\"{x:1350,y:561,t:1527188896404};\\\", \\\"{x:1264,y:561,t:1527188896422};\\\", \\\"{x:1169,y:561,t:1527188896439};\\\", \\\"{x:1075,y:561,t:1527188896455};\\\", \\\"{x:988,y:567,t:1527188896472};\\\", \\\"{x:912,y:570,t:1527188896489};\\\", \\\"{x:845,y:570,t:1527188896505};\\\", \\\"{x:723,y:570,t:1527188896523};\\\", \\\"{x:658,y:572,t:1527188896538};\\\", \\\"{x:613,y:572,t:1527188896556};\\\", \\\"{x:585,y:572,t:1527188896572};\\\", \\\"{x:560,y:568,t:1527188896588};\\\", \\\"{x:534,y:562,t:1527188896606};\\\", \\\"{x:506,y:552,t:1527188896622};\\\", \\\"{x:475,y:542,t:1527188896638};\\\", \\\"{x:444,y:531,t:1527188896655};\\\", \\\"{x:420,y:525,t:1527188896671};\\\", \\\"{x:403,y:520,t:1527188896689};\\\", \\\"{x:391,y:520,t:1527188896705};\\\", \\\"{x:387,y:519,t:1527188896721};\\\", \\\"{x:391,y:519,t:1527188896825};\\\", \\\"{x:401,y:519,t:1527188896838};\\\", \\\"{x:430,y:516,t:1527188896856};\\\", \\\"{x:455,y:514,t:1527188896872};\\\", \\\"{x:481,y:508,t:1527188896889};\\\", \\\"{x:516,y:497,t:1527188896907};\\\", \\\"{x:537,y:492,t:1527188896922};\\\", \\\"{x:548,y:489,t:1527188896938};\\\", \\\"{x:552,y:488,t:1527188896955};\\\", \\\"{x:554,y:488,t:1527188896972};\\\", \\\"{x:555,y:487,t:1527188896989};\\\", \\\"{x:558,y:487,t:1527188897005};\\\", \\\"{x:561,y:484,t:1527188897023};\\\", \\\"{x:562,y:484,t:1527188897039};\\\", \\\"{x:564,y:484,t:1527188897055};\\\", \\\"{x:569,y:484,t:1527188897072};\\\", \\\"{x:584,y:484,t:1527188897089};\\\", \\\"{x:598,y:487,t:1527188897107};\\\", \\\"{x:602,y:487,t:1527188897123};\\\", \\\"{x:602,y:488,t:1527188897218};\\\", \\\"{x:606,y:490,t:1527188897491};\\\", \\\"{x:626,y:498,t:1527188897505};\\\", \\\"{x:643,y:507,t:1527188897523};\\\", \\\"{x:663,y:517,t:1527188897539};\\\", \\\"{x:676,y:524,t:1527188897556};\\\", \\\"{x:685,y:531,t:1527188897572};\\\", \\\"{x:695,y:535,t:1527188897589};\\\", \\\"{x:708,y:538,t:1527188897605};\\\", \\\"{x:715,y:541,t:1527188897623};\\\", \\\"{x:717,y:541,t:1527188897639};\\\", \\\"{x:720,y:541,t:1527188897656};\\\", \\\"{x:724,y:541,t:1527188897673};\\\", \\\"{x:743,y:539,t:1527188897689};\\\", \\\"{x:757,y:538,t:1527188897705};\\\", \\\"{x:761,y:536,t:1527188897722};\\\", \\\"{x:762,y:535,t:1527188897761};\\\", \\\"{x:767,y:532,t:1527188897772};\\\", \\\"{x:776,y:530,t:1527188897789};\\\", \\\"{x:780,y:527,t:1527188897807};\\\", \\\"{x:782,y:526,t:1527188897822};\\\", \\\"{x:785,y:526,t:1527188897839};\\\", \\\"{x:790,y:524,t:1527188897858};\\\", \\\"{x:797,y:523,t:1527188897873};\\\", \\\"{x:801,y:522,t:1527188897889};\\\", \\\"{x:803,y:522,t:1527188897906};\\\", \\\"{x:804,y:522,t:1527188897938};\\\", \\\"{x:806,y:522,t:1527188897962};\\\", \\\"{x:808,y:522,t:1527188897978};\\\", \\\"{x:810,y:522,t:1527188897990};\\\", \\\"{x:810,y:523,t:1527188898034};\\\", \\\"{x:809,y:524,t:1527188898042};\\\", \\\"{x:806,y:525,t:1527188898058};\\\", \\\"{x:799,y:526,t:1527188898072};\\\", \\\"{x:766,y:520,t:1527188898090};\\\", \\\"{x:728,y:505,t:1527188898106};\\\", \\\"{x:693,y:493,t:1527188898123};\\\", \\\"{x:675,y:490,t:1527188898139};\\\", \\\"{x:664,y:490,t:1527188898156};\\\", \\\"{x:649,y:490,t:1527188898173};\\\", \\\"{x:635,y:490,t:1527188898189};\\\", \\\"{x:625,y:490,t:1527188898207};\\\", \\\"{x:621,y:490,t:1527188898223};\\\", \\\"{x:620,y:490,t:1527188898297};\\\", \\\"{x:619,y:490,t:1527188898330};\\\", \\\"{x:619,y:491,t:1527188898339};\\\", \\\"{x:619,y:492,t:1527188898357};\\\", \\\"{x:619,y:494,t:1527188898378};\\\", \\\"{x:619,y:495,t:1527188898410};\\\", \\\"{x:619,y:498,t:1527188898425};\\\", \\\"{x:618,y:499,t:1527188898440};\\\", \\\"{x:618,y:500,t:1527188898457};\\\", \\\"{x:616,y:502,t:1527188898474};\\\", \\\"{x:616,y:504,t:1527188898490};\\\", \\\"{x:615,y:504,t:1527188898507};\\\", \\\"{x:615,y:504,t:1527188898560};\\\", \\\"{x:617,y:504,t:1527188898633};\\\", \\\"{x:623,y:504,t:1527188898642};\\\", \\\"{x:631,y:506,t:1527188898656};\\\", \\\"{x:655,y:512,t:1527188898674};\\\", \\\"{x:679,y:516,t:1527188898691};\\\", \\\"{x:711,y:521,t:1527188898707};\\\", \\\"{x:741,y:525,t:1527188898724};\\\", \\\"{x:765,y:529,t:1527188898740};\\\", \\\"{x:779,y:532,t:1527188898756};\\\", \\\"{x:782,y:533,t:1527188898774};\\\", \\\"{x:789,y:534,t:1527188898790};\\\", \\\"{x:807,y:537,t:1527188898806};\\\", \\\"{x:834,y:543,t:1527188898824};\\\", \\\"{x:863,y:546,t:1527188898840};\\\", \\\"{x:882,y:552,t:1527188898856};\\\", \\\"{x:892,y:554,t:1527188898873};\\\", \\\"{x:892,y:555,t:1527188898962};\\\", \\\"{x:891,y:555,t:1527188898974};\\\", \\\"{x:883,y:555,t:1527188898990};\\\", \\\"{x:872,y:554,t:1527188899006};\\\", \\\"{x:859,y:549,t:1527188899024};\\\", \\\"{x:852,y:547,t:1527188899040};\\\", \\\"{x:847,y:544,t:1527188899057};\\\", \\\"{x:846,y:544,t:1527188899074};\\\", \\\"{x:843,y:543,t:1527188899091};\\\", \\\"{x:837,y:541,t:1527188899108};\\\", \\\"{x:832,y:538,t:1527188899124};\\\", \\\"{x:827,y:538,t:1527188899418};\\\", \\\"{x:816,y:546,t:1527188899425};\\\", \\\"{x:804,y:557,t:1527188899441};\\\", \\\"{x:773,y:582,t:1527188899457};\\\", \\\"{x:749,y:601,t:1527188899475};\\\", \\\"{x:715,y:627,t:1527188899491};\\\", \\\"{x:677,y:649,t:1527188899508};\\\", \\\"{x:642,y:668,t:1527188899524};\\\", \\\"{x:615,y:681,t:1527188899540};\\\", \\\"{x:587,y:691,t:1527188899557};\\\", \\\"{x:563,y:694,t:1527188899575};\\\", \\\"{x:544,y:700,t:1527188899590};\\\", \\\"{x:532,y:704,t:1527188899607};\\\", \\\"{x:526,y:707,t:1527188899624};\\\", \\\"{x:523,y:708,t:1527188899641};\\\", \\\"{x:522,y:708,t:1527188899706};\\\", \\\"{x:519,y:710,t:1527188899714};\\\", \\\"{x:518,y:711,t:1527188899724};\\\", \\\"{x:514,y:715,t:1527188899741};\\\", \\\"{x:511,y:719,t:1527188899757};\\\", \\\"{x:508,y:725,t:1527188899775};\\\", \\\"{x:504,y:731,t:1527188899790};\\\", \\\"{x:499,y:744,t:1527188899807};\\\", \\\"{x:495,y:754,t:1527188899824};\\\", \\\"{x:493,y:759,t:1527188899842};\\\", \\\"{x:493,y:758,t:1527188900002};\\\", \\\"{x:493,y:757,t:1527188900010};\\\", \\\"{x:493,y:755,t:1527188900025};\\\", \\\"{x:493,y:753,t:1527188900043};\\\", \\\"{x:493,y:752,t:1527188900057};\\\", \\\"{x:493,y:751,t:1527188900105};\\\", \\\"{x:493,y:750,t:1527188900113};\\\", \\\"{x:492,y:748,t:1527188900538};\\\", \\\"{x:491,y:747,t:1527188900546};\\\", \\\"{x:489,y:746,t:1527188900559};\\\", \\\"{x:486,y:744,t:1527188900575};\\\", \\\"{x:483,y:742,t:1527188900592};\\\", \\\"{x:483,y:741,t:1527188900608};\\\", \\\"{x:480,y:740,t:1527188900624};\\\", \\\"{x:480,y:739,t:1527188900641};\\\", \\\"{x:479,y:738,t:1527188900690};\\\", \\\"{x:478,y:737,t:1527188900738};\\\", \\\"{x:477,y:736,t:1527188900754};\\\", \\\"{x:476,y:735,t:1527188900778};\\\", \\\"{x:476,y:734,t:1527188900792};\\\", \\\"{x:476,y:733,t:1527188900826};\\\", \\\"{x:475,y:732,t:1527188900842};\\\", \\\"{x:474,y:731,t:1527188900859};\\\", \\\"{x:474,y:730,t:1527188900875};\\\", \\\"{x:473,y:730,t:1527188900892};\\\", \\\"{x:473,y:729,t:1527188900930};\\\", \\\"{x:472,y:729,t:1527188900942};\\\", \\\"{x:472,y:728,t:1527188900962};\\\", \\\"{x:471,y:727,t:1527188900978};\\\", \\\"{x:471,y:726,t:1527188901002};\\\", \\\"{x:471,y:725,t:1527188901018};\\\", \\\"{x:470,y:724,t:1527188901026};\\\", \\\"{x:469,y:723,t:1527188901050};\\\", \\\"{x:468,y:722,t:1527188901059};\\\", \\\"{x:467,y:722,t:1527188901076};\\\", \\\"{x:467,y:721,t:1527188901092};\\\", \\\"{x:465,y:719,t:1527188901108};\\\", \\\"{x:464,y:719,t:1527188901125};\\\", \\\"{x:464,y:718,t:1527188901146};\\\", \\\"{x:463,y:717,t:1527188901178};\\\", \\\"{x:463,y:716,t:1527188901202};\\\", \\\"{x:462,y:716,t:1527188901258};\\\", \\\"{x:462,y:715,t:1527188901276};\\\", \\\"{x:461,y:714,t:1527188901314};\\\", \\\"{x:461,y:713,t:1527188901329};\\\", \\\"{x:460,y:712,t:1527188901345};\\\", \\\"{x:459,y:711,t:1527188901377};\\\" ] }, { \\\"rt\\\": 30572, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 312116, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -5-D -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:457,y:707,t:1527188901490};\\\", \\\"{x:457,y:706,t:1527188901526};\\\", \\\"{x:457,y:705,t:1527188902234};\\\", \\\"{x:455,y:702,t:1527188902257};\\\", \\\"{x:453,y:699,t:1527188902265};\\\", \\\"{x:450,y:695,t:1527188902277};\\\", \\\"{x:443,y:685,t:1527188902292};\\\", \\\"{x:435,y:677,t:1527188902310};\\\", \\\"{x:423,y:665,t:1527188902327};\\\", \\\"{x:413,y:656,t:1527188902343};\\\", \\\"{x:405,y:648,t:1527188902360};\\\", \\\"{x:401,y:643,t:1527188902376};\\\", \\\"{x:394,y:634,t:1527188902393};\\\", \\\"{x:390,y:627,t:1527188902410};\\\", \\\"{x:384,y:618,t:1527188902426};\\\", \\\"{x:376,y:604,t:1527188902444};\\\", \\\"{x:365,y:585,t:1527188902460};\\\", \\\"{x:354,y:566,t:1527188902476};\\\", \\\"{x:341,y:546,t:1527188902495};\\\", \\\"{x:329,y:526,t:1527188902509};\\\", \\\"{x:322,y:512,t:1527188902527};\\\", \\\"{x:317,y:504,t:1527188902544};\\\", \\\"{x:312,y:496,t:1527188902559};\\\", \\\"{x:310,y:493,t:1527188902577};\\\", \\\"{x:310,y:490,t:1527188902593};\\\", \\\"{x:309,y:488,t:1527188902610};\\\", \\\"{x:308,y:487,t:1527188902626};\\\", \\\"{x:308,y:483,t:1527188902645};\\\", \\\"{x:308,y:482,t:1527188902659};\\\", \\\"{x:307,y:479,t:1527188902677};\\\", \\\"{x:306,y:478,t:1527188902713};\\\", \\\"{x:316,y:478,t:1527188907466};\\\", \\\"{x:334,y:482,t:1527188907481};\\\", \\\"{x:372,y:492,t:1527188907499};\\\", \\\"{x:448,y:514,t:1527188907514};\\\", \\\"{x:526,y:540,t:1527188907530};\\\", \\\"{x:623,y:568,t:1527188907548};\\\", \\\"{x:736,y:592,t:1527188907564};\\\", \\\"{x:851,y:617,t:1527188907581};\\\", \\\"{x:964,y:631,t:1527188907598};\\\", \\\"{x:1071,y:639,t:1527188907614};\\\", \\\"{x:1177,y:641,t:1527188907631};\\\", \\\"{x:1276,y:641,t:1527188907648};\\\", \\\"{x:1379,y:643,t:1527188907664};\\\", \\\"{x:1454,y:643,t:1527188907681};\\\", \\\"{x:1521,y:647,t:1527188907697};\\\", \\\"{x:1539,y:647,t:1527188907715};\\\", \\\"{x:1543,y:647,t:1527188907731};\\\", \\\"{x:1544,y:647,t:1527188907748};\\\", \\\"{x:1542,y:647,t:1527188907923};\\\", \\\"{x:1539,y:647,t:1527188907932};\\\", \\\"{x:1537,y:647,t:1527188907949};\\\", \\\"{x:1533,y:647,t:1527188907966};\\\", \\\"{x:1532,y:647,t:1527188907983};\\\", \\\"{x:1531,y:647,t:1527188908003};\\\", \\\"{x:1530,y:646,t:1527188908016};\\\", \\\"{x:1528,y:646,t:1527188908033};\\\", \\\"{x:1524,y:645,t:1527188908050};\\\", \\\"{x:1521,y:645,t:1527188908066};\\\", \\\"{x:1520,y:645,t:1527188908082};\\\", \\\"{x:1519,y:645,t:1527188908099};\\\", \\\"{x:1518,y:645,t:1527188908122};\\\", \\\"{x:1516,y:645,t:1527188908133};\\\", \\\"{x:1514,y:645,t:1527188908149};\\\", \\\"{x:1509,y:645,t:1527188908166};\\\", \\\"{x:1508,y:645,t:1527188908183};\\\", \\\"{x:1507,y:645,t:1527188908200};\\\", \\\"{x:1506,y:645,t:1527188908217};\\\", \\\"{x:1505,y:645,t:1527188908234};\\\", \\\"{x:1502,y:645,t:1527188908249};\\\", \\\"{x:1497,y:646,t:1527188908266};\\\", \\\"{x:1493,y:648,t:1527188908284};\\\", \\\"{x:1488,y:651,t:1527188908300};\\\", \\\"{x:1481,y:657,t:1527188908317};\\\", \\\"{x:1472,y:667,t:1527188908333};\\\", \\\"{x:1463,y:677,t:1527188908350};\\\", \\\"{x:1453,y:687,t:1527188908366};\\\", \\\"{x:1442,y:696,t:1527188908384};\\\", \\\"{x:1432,y:703,t:1527188908401};\\\", \\\"{x:1423,y:707,t:1527188908417};\\\", \\\"{x:1414,y:707,t:1527188908434};\\\", \\\"{x:1402,y:708,t:1527188908450};\\\", \\\"{x:1394,y:708,t:1527188908467};\\\", \\\"{x:1389,y:708,t:1527188908483};\\\", \\\"{x:1384,y:708,t:1527188908501};\\\", \\\"{x:1382,y:708,t:1527188908518};\\\", \\\"{x:1380,y:708,t:1527188908535};\\\", \\\"{x:1378,y:708,t:1527188908550};\\\", \\\"{x:1376,y:708,t:1527188908567};\\\", \\\"{x:1373,y:708,t:1527188908585};\\\", \\\"{x:1371,y:708,t:1527188908602};\\\", \\\"{x:1369,y:707,t:1527188908617};\\\", \\\"{x:1367,y:707,t:1527188908635};\\\", \\\"{x:1363,y:706,t:1527188908652};\\\", \\\"{x:1363,y:705,t:1527188908667};\\\", \\\"{x:1361,y:705,t:1527188908685};\\\", \\\"{x:1356,y:702,t:1527188908701};\\\", \\\"{x:1353,y:701,t:1527188908719};\\\", \\\"{x:1343,y:695,t:1527188908735};\\\", \\\"{x:1336,y:692,t:1527188908751};\\\", \\\"{x:1333,y:690,t:1527188908767};\\\", \\\"{x:1331,y:689,t:1527188908783};\\\", \\\"{x:1330,y:689,t:1527188908809};\\\", \\\"{x:1329,y:688,t:1527188908825};\\\", \\\"{x:1328,y:688,t:1527188909938};\\\", \\\"{x:1328,y:687,t:1527188911819};\\\", \\\"{x:1331,y:687,t:1527188911827};\\\", \\\"{x:1341,y:687,t:1527188911845};\\\", \\\"{x:1350,y:687,t:1527188911862};\\\", \\\"{x:1359,y:688,t:1527188911877};\\\", \\\"{x:1362,y:691,t:1527188911895};\\\", \\\"{x:1363,y:691,t:1527188912097};\\\", \\\"{x:1363,y:692,t:1527188912129};\\\", \\\"{x:1362,y:694,t:1527188912145};\\\", \\\"{x:1362,y:695,t:1527188912161};\\\", \\\"{x:1360,y:695,t:1527188912178};\\\", \\\"{x:1358,y:696,t:1527188912196};\\\", \\\"{x:1357,y:696,t:1527188912212};\\\", \\\"{x:1356,y:697,t:1527188912228};\\\", \\\"{x:1356,y:698,t:1527188912245};\\\", \\\"{x:1355,y:698,t:1527188912262};\\\", \\\"{x:1353,y:700,t:1527188912279};\\\", \\\"{x:1351,y:700,t:1527188912296};\\\", \\\"{x:1351,y:701,t:1527188912312};\\\", \\\"{x:1340,y:698,t:1527188919230};\\\", \\\"{x:1298,y:683,t:1527188919237};\\\", \\\"{x:1194,y:663,t:1527188919254};\\\", \\\"{x:1077,y:642,t:1527188919270};\\\", \\\"{x:953,y:609,t:1527188919287};\\\", \\\"{x:831,y:575,t:1527188919305};\\\", \\\"{x:725,y:538,t:1527188919321};\\\", \\\"{x:639,y:513,t:1527188919337};\\\", \\\"{x:555,y:489,t:1527188919360};\\\", \\\"{x:540,y:482,t:1527188919376};\\\", \\\"{x:544,y:482,t:1527188919444};\\\", \\\"{x:554,y:484,t:1527188919458};\\\", \\\"{x:586,y:499,t:1527188919476};\\\", \\\"{x:618,y:508,t:1527188919493};\\\", \\\"{x:653,y:514,t:1527188919509};\\\", \\\"{x:680,y:516,t:1527188919526};\\\", \\\"{x:700,y:516,t:1527188919543};\\\", \\\"{x:719,y:516,t:1527188919560};\\\", \\\"{x:738,y:516,t:1527188919577};\\\", \\\"{x:755,y:516,t:1527188919592};\\\", \\\"{x:772,y:514,t:1527188919610};\\\", \\\"{x:782,y:510,t:1527188919626};\\\", \\\"{x:786,y:509,t:1527188919643};\\\", \\\"{x:792,y:507,t:1527188919660};\\\", \\\"{x:795,y:507,t:1527188919676};\\\", \\\"{x:800,y:504,t:1527188919693};\\\", \\\"{x:803,y:503,t:1527188919710};\\\", \\\"{x:804,y:502,t:1527188919731};\\\", \\\"{x:805,y:502,t:1527188919747};\\\", \\\"{x:807,y:501,t:1527188919760};\\\", \\\"{x:815,y:498,t:1527188919776};\\\", \\\"{x:820,y:496,t:1527188919793};\\\", \\\"{x:824,y:495,t:1527188919809};\\\", \\\"{x:825,y:495,t:1527188919826};\\\", \\\"{x:819,y:495,t:1527188920124};\\\", \\\"{x:809,y:499,t:1527188920132};\\\", \\\"{x:801,y:502,t:1527188920143};\\\", \\\"{x:788,y:510,t:1527188920160};\\\", \\\"{x:778,y:519,t:1527188920179};\\\", \\\"{x:767,y:528,t:1527188920194};\\\", \\\"{x:757,y:534,t:1527188920210};\\\", \\\"{x:745,y:545,t:1527188920227};\\\", \\\"{x:731,y:551,t:1527188920243};\\\", \\\"{x:709,y:561,t:1527188920260};\\\", \\\"{x:697,y:568,t:1527188920278};\\\", \\\"{x:687,y:575,t:1527188920294};\\\", \\\"{x:680,y:581,t:1527188920310};\\\", \\\"{x:673,y:586,t:1527188920327};\\\", \\\"{x:665,y:590,t:1527188920344};\\\", \\\"{x:655,y:594,t:1527188920360};\\\", \\\"{x:648,y:597,t:1527188920377};\\\", \\\"{x:644,y:597,t:1527188920394};\\\", \\\"{x:640,y:597,t:1527188920410};\\\", \\\"{x:634,y:597,t:1527188920427};\\\", \\\"{x:630,y:598,t:1527188920444};\\\", \\\"{x:630,y:599,t:1527188920461};\\\", \\\"{x:629,y:599,t:1527188920629};\\\", \\\"{x:621,y:599,t:1527188920645};\\\", \\\"{x:606,y:599,t:1527188920661};\\\", \\\"{x:591,y:599,t:1527188920679};\\\", \\\"{x:582,y:598,t:1527188920696};\\\", \\\"{x:581,y:597,t:1527188920717};\\\", \\\"{x:581,y:596,t:1527188920729};\\\", \\\"{x:590,y:586,t:1527188920745};\\\", \\\"{x:612,y:575,t:1527188920761};\\\", \\\"{x:648,y:560,t:1527188920777};\\\", \\\"{x:695,y:539,t:1527188920795};\\\", \\\"{x:736,y:522,t:1527188920811};\\\", \\\"{x:781,y:508,t:1527188920828};\\\", \\\"{x:813,y:503,t:1527188920843};\\\", \\\"{x:822,y:502,t:1527188920861};\\\", \\\"{x:824,y:501,t:1527188920877};\\\", \\\"{x:827,y:501,t:1527188921404};\\\", \\\"{x:828,y:501,t:1527188921413};\\\", \\\"{x:836,y:502,t:1527188921427};\\\", \\\"{x:839,y:504,t:1527188921445};\\\", \\\"{x:846,y:504,t:1527188921460};\\\", \\\"{x:844,y:503,t:1527188921819};\\\", \\\"{x:841,y:503,t:1527188921827};\\\", \\\"{x:836,y:503,t:1527188921845};\\\", \\\"{x:832,y:505,t:1527188921862};\\\", \\\"{x:830,y:506,t:1527188921878};\\\", \\\"{x:828,y:507,t:1527188921895};\\\", \\\"{x:824,y:508,t:1527188921913};\\\", \\\"{x:811,y:513,t:1527188921928};\\\", \\\"{x:789,y:516,t:1527188921945};\\\", \\\"{x:765,y:516,t:1527188921961};\\\", \\\"{x:736,y:516,t:1527188921978};\\\", \\\"{x:704,y:518,t:1527188921996};\\\", \\\"{x:668,y:522,t:1527188922011};\\\", \\\"{x:619,y:530,t:1527188922029};\\\", \\\"{x:572,y:540,t:1527188922045};\\\", \\\"{x:524,y:549,t:1527188922062};\\\", \\\"{x:493,y:554,t:1527188922078};\\\", \\\"{x:467,y:558,t:1527188922095};\\\", \\\"{x:442,y:559,t:1527188922112};\\\", \\\"{x:423,y:559,t:1527188922128};\\\", \\\"{x:411,y:559,t:1527188922145};\\\", \\\"{x:403,y:559,t:1527188922162};\\\", \\\"{x:399,y:559,t:1527188922178};\\\", \\\"{x:395,y:557,t:1527188922195};\\\", \\\"{x:392,y:554,t:1527188922212};\\\", \\\"{x:392,y:553,t:1527188922236};\\\", \\\"{x:391,y:550,t:1527188922246};\\\", \\\"{x:390,y:546,t:1527188922262};\\\", \\\"{x:389,y:541,t:1527188922278};\\\", \\\"{x:388,y:540,t:1527188922296};\\\", \\\"{x:386,y:540,t:1527188922372};\\\", \\\"{x:383,y:541,t:1527188922380};\\\", \\\"{x:377,y:544,t:1527188922395};\\\", \\\"{x:355,y:553,t:1527188922413};\\\", \\\"{x:342,y:556,t:1527188922430};\\\", \\\"{x:327,y:557,t:1527188922445};\\\", \\\"{x:308,y:557,t:1527188922462};\\\", \\\"{x:288,y:554,t:1527188922479};\\\", \\\"{x:271,y:547,t:1527188922495};\\\", \\\"{x:255,y:541,t:1527188922512};\\\", \\\"{x:238,y:536,t:1527188922529};\\\", \\\"{x:222,y:530,t:1527188922545};\\\", \\\"{x:206,y:526,t:1527188922562};\\\", \\\"{x:190,y:525,t:1527188922579};\\\", \\\"{x:182,y:523,t:1527188922596};\\\", \\\"{x:175,y:522,t:1527188922612};\\\", \\\"{x:173,y:522,t:1527188922628};\\\", \\\"{x:172,y:522,t:1527188922645};\\\", \\\"{x:172,y:523,t:1527188922662};\\\", \\\"{x:171,y:523,t:1527188922692};\\\", \\\"{x:171,y:524,t:1527188922700};\\\", \\\"{x:169,y:527,t:1527188922713};\\\", \\\"{x:165,y:535,t:1527188922729};\\\", \\\"{x:163,y:542,t:1527188922744};\\\", \\\"{x:162,y:544,t:1527188922762};\\\", \\\"{x:162,y:545,t:1527188922778};\\\", \\\"{x:161,y:546,t:1527188922794};\\\", \\\"{x:161,y:547,t:1527188923068};\\\", \\\"{x:169,y:545,t:1527188923079};\\\", \\\"{x:193,y:537,t:1527188923096};\\\", \\\"{x:228,y:532,t:1527188923112};\\\", \\\"{x:304,y:530,t:1527188923129};\\\", \\\"{x:398,y:530,t:1527188923146};\\\", \\\"{x:514,y:530,t:1527188923163};\\\", \\\"{x:630,y:542,t:1527188923179};\\\", \\\"{x:844,y:569,t:1527188923196};\\\", \\\"{x:1010,y:594,t:1527188923214};\\\", \\\"{x:1215,y:624,t:1527188923229};\\\", \\\"{x:1434,y:663,t:1527188923246};\\\", \\\"{x:1636,y:700,t:1527188923264};\\\", \\\"{x:1814,y:727,t:1527188923279};\\\", \\\"{x:1919,y:744,t:1527188923296};\\\", \\\"{x:1919,y:761,t:1527188923313};\\\", \\\"{x:1919,y:780,t:1527188923329};\\\", \\\"{x:1919,y:793,t:1527188923346};\\\", \\\"{x:1919,y:803,t:1527188923363};\\\", \\\"{x:1919,y:805,t:1527188923380};\\\", \\\"{x:1915,y:805,t:1527188923437};\\\", \\\"{x:1911,y:804,t:1527188923446};\\\", \\\"{x:1910,y:804,t:1527188923464};\\\", \\\"{x:1906,y:805,t:1527188923479};\\\", \\\"{x:1898,y:808,t:1527188923497};\\\", \\\"{x:1888,y:809,t:1527188923513};\\\", \\\"{x:1873,y:814,t:1527188923530};\\\", \\\"{x:1859,y:818,t:1527188923546};\\\", \\\"{x:1843,y:820,t:1527188923564};\\\", \\\"{x:1820,y:820,t:1527188923580};\\\", \\\"{x:1776,y:820,t:1527188923596};\\\", \\\"{x:1747,y:820,t:1527188923614};\\\", \\\"{x:1728,y:820,t:1527188923630};\\\", \\\"{x:1713,y:820,t:1527188923647};\\\", \\\"{x:1695,y:820,t:1527188923663};\\\", \\\"{x:1671,y:820,t:1527188923680};\\\", \\\"{x:1644,y:820,t:1527188923697};\\\", \\\"{x:1622,y:819,t:1527188923713};\\\", \\\"{x:1602,y:815,t:1527188923730};\\\", \\\"{x:1577,y:810,t:1527188923746};\\\", \\\"{x:1537,y:799,t:1527188923764};\\\", \\\"{x:1466,y:776,t:1527188923780};\\\", \\\"{x:1428,y:766,t:1527188923797};\\\", \\\"{x:1405,y:757,t:1527188923814};\\\", \\\"{x:1389,y:753,t:1527188923830};\\\", \\\"{x:1377,y:750,t:1527188923847};\\\", \\\"{x:1371,y:747,t:1527188923864};\\\", \\\"{x:1370,y:747,t:1527188923881};\\\", \\\"{x:1369,y:745,t:1527188924021};\\\", \\\"{x:1368,y:739,t:1527188924031};\\\", \\\"{x:1365,y:729,t:1527188924047};\\\", \\\"{x:1360,y:716,t:1527188924063};\\\", \\\"{x:1354,y:704,t:1527188924081};\\\", \\\"{x:1347,y:693,t:1527188924097};\\\", \\\"{x:1344,y:687,t:1527188924114};\\\", \\\"{x:1343,y:685,t:1527188924130};\\\", \\\"{x:1342,y:685,t:1527188924276};\\\", \\\"{x:1340,y:688,t:1527188924284};\\\", \\\"{x:1339,y:690,t:1527188924297};\\\", \\\"{x:1338,y:694,t:1527188924313};\\\", \\\"{x:1338,y:698,t:1527188924331};\\\", \\\"{x:1336,y:702,t:1527188924347};\\\", \\\"{x:1335,y:705,t:1527188924363};\\\", \\\"{x:1335,y:712,t:1527188924380};\\\", \\\"{x:1335,y:716,t:1527188924397};\\\", \\\"{x:1335,y:720,t:1527188924413};\\\", \\\"{x:1334,y:726,t:1527188924431};\\\", \\\"{x:1332,y:730,t:1527188924448};\\\", \\\"{x:1332,y:735,t:1527188924464};\\\", \\\"{x:1332,y:737,t:1527188924481};\\\", \\\"{x:1332,y:739,t:1527188924498};\\\", \\\"{x:1332,y:740,t:1527188924513};\\\", \\\"{x:1332,y:741,t:1527188924531};\\\", \\\"{x:1333,y:741,t:1527188928845};\\\", \\\"{x:1337,y:741,t:1527188928852};\\\", \\\"{x:1352,y:741,t:1527188928869};\\\", \\\"{x:1371,y:741,t:1527188928884};\\\", \\\"{x:1390,y:742,t:1527188928901};\\\", \\\"{x:1411,y:744,t:1527188928919};\\\", \\\"{x:1433,y:748,t:1527188928934};\\\", \\\"{x:1453,y:752,t:1527188928951};\\\", \\\"{x:1463,y:753,t:1527188928968};\\\", \\\"{x:1470,y:753,t:1527188928984};\\\", \\\"{x:1474,y:753,t:1527188929000};\\\", \\\"{x:1479,y:753,t:1527188929018};\\\", \\\"{x:1484,y:751,t:1527188929034};\\\", \\\"{x:1489,y:751,t:1527188929051};\\\", \\\"{x:1503,y:746,t:1527188929068};\\\", \\\"{x:1520,y:741,t:1527188929084};\\\", \\\"{x:1540,y:735,t:1527188929101};\\\", \\\"{x:1563,y:730,t:1527188929118};\\\", \\\"{x:1588,y:722,t:1527188929134};\\\", \\\"{x:1606,y:717,t:1527188929151};\\\", \\\"{x:1618,y:715,t:1527188929168};\\\", \\\"{x:1631,y:712,t:1527188929184};\\\", \\\"{x:1640,y:711,t:1527188929200};\\\", \\\"{x:1649,y:711,t:1527188929218};\\\", \\\"{x:1653,y:710,t:1527188929235};\\\", \\\"{x:1657,y:710,t:1527188929251};\\\", \\\"{x:1664,y:710,t:1527188929268};\\\", \\\"{x:1672,y:710,t:1527188929284};\\\", \\\"{x:1675,y:710,t:1527188929301};\\\", \\\"{x:1676,y:710,t:1527188929319};\\\", \\\"{x:1670,y:709,t:1527188929421};\\\", \\\"{x:1664,y:705,t:1527188929435};\\\", \\\"{x:1652,y:701,t:1527188929451};\\\", \\\"{x:1647,y:698,t:1527188929467};\\\", \\\"{x:1645,y:697,t:1527188929484};\\\", \\\"{x:1644,y:697,t:1527188929502};\\\", \\\"{x:1643,y:697,t:1527188929519};\\\", \\\"{x:1643,y:696,t:1527188929661};\\\", \\\"{x:1641,y:696,t:1527188929668};\\\", \\\"{x:1638,y:694,t:1527188929686};\\\", \\\"{x:1635,y:693,t:1527188929702};\\\", \\\"{x:1634,y:692,t:1527188929718};\\\", \\\"{x:1631,y:692,t:1527188929735};\\\", \\\"{x:1631,y:691,t:1527188929752};\\\", \\\"{x:1630,y:691,t:1527188929768};\\\", \\\"{x:1629,y:690,t:1527188929788};\\\", \\\"{x:1630,y:690,t:1527188930141};\\\", \\\"{x:1636,y:692,t:1527188930152};\\\", \\\"{x:1657,y:699,t:1527188930169};\\\", \\\"{x:1676,y:705,t:1527188930185};\\\", \\\"{x:1702,y:710,t:1527188930202};\\\", \\\"{x:1736,y:717,t:1527188930219};\\\", \\\"{x:1775,y:728,t:1527188930235};\\\", \\\"{x:1811,y:742,t:1527188930252};\\\", \\\"{x:1837,y:748,t:1527188930269};\\\", \\\"{x:1839,y:749,t:1527188930285};\\\", \\\"{x:1836,y:746,t:1527188930349};\\\", \\\"{x:1817,y:733,t:1527188930356};\\\", \\\"{x:1784,y:713,t:1527188930369};\\\", \\\"{x:1706,y:677,t:1527188930386};\\\", \\\"{x:1614,y:646,t:1527188930403};\\\", \\\"{x:1522,y:619,t:1527188930419};\\\", \\\"{x:1326,y:565,t:1527188930436};\\\", \\\"{x:1170,y:535,t:1527188930452};\\\", \\\"{x:1026,y:513,t:1527188930469};\\\", \\\"{x:887,y:487,t:1527188930488};\\\", \\\"{x:762,y:464,t:1527188930503};\\\", \\\"{x:638,y:433,t:1527188930519};\\\", \\\"{x:535,y:403,t:1527188930536};\\\", \\\"{x:468,y:381,t:1527188930552};\\\", \\\"{x:434,y:372,t:1527188930569};\\\", \\\"{x:420,y:369,t:1527188930586};\\\", \\\"{x:405,y:367,t:1527188930602};\\\", \\\"{x:391,y:366,t:1527188930619};\\\", \\\"{x:376,y:364,t:1527188930636};\\\", \\\"{x:369,y:364,t:1527188930652};\\\", \\\"{x:361,y:364,t:1527188930669};\\\", \\\"{x:352,y:365,t:1527188930686};\\\", \\\"{x:343,y:369,t:1527188930702};\\\", \\\"{x:332,y:376,t:1527188930718};\\\", \\\"{x:321,y:389,t:1527188930736};\\\", \\\"{x:316,y:410,t:1527188930752};\\\", \\\"{x:314,y:434,t:1527188930769};\\\", \\\"{x:311,y:456,t:1527188930787};\\\", \\\"{x:311,y:476,t:1527188930802};\\\", \\\"{x:312,y:493,t:1527188930820};\\\", \\\"{x:324,y:520,t:1527188930836};\\\", \\\"{x:333,y:531,t:1527188930853};\\\", \\\"{x:346,y:545,t:1527188930868};\\\", \\\"{x:368,y:557,t:1527188930886};\\\", \\\"{x:399,y:568,t:1527188930903};\\\", \\\"{x:427,y:583,t:1527188930919};\\\", \\\"{x:449,y:590,t:1527188930935};\\\", \\\"{x:456,y:595,t:1527188930952};\\\", \\\"{x:462,y:602,t:1527188930969};\\\", \\\"{x:465,y:615,t:1527188930985};\\\", \\\"{x:475,y:635,t:1527188931003};\\\", \\\"{x:480,y:648,t:1527188931019};\\\", \\\"{x:485,y:676,t:1527188931036};\\\", \\\"{x:485,y:684,t:1527188931052};\\\", \\\"{x:485,y:689,t:1527188931069};\\\", \\\"{x:484,y:698,t:1527188931085};\\\", \\\"{x:484,y:704,t:1527188931103};\\\", \\\"{x:482,y:709,t:1527188931119};\\\", \\\"{x:481,y:711,t:1527188931135};\\\", \\\"{x:480,y:712,t:1527188931152};\\\", \\\"{x:480,y:714,t:1527188931229};\\\", \\\"{x:480,y:718,t:1527188931236};\\\", \\\"{x:475,y:733,t:1527188931256};\\\", \\\"{x:464,y:766,t:1527188931270};\\\", \\\"{x:452,y:811,t:1527188931286};\\\", \\\"{x:448,y:824,t:1527188931303};\\\", \\\"{x:448,y:823,t:1527188931340};\\\", \\\"{x:448,y:820,t:1527188931353};\\\", \\\"{x:450,y:814,t:1527188931369};\\\", \\\"{x:453,y:806,t:1527188931386};\\\", \\\"{x:454,y:805,t:1527188931403};\\\", \\\"{x:456,y:802,t:1527188931419};\\\", \\\"{x:457,y:802,t:1527188931437};\\\", \\\"{x:460,y:800,t:1527188931452};\\\", \\\"{x:463,y:799,t:1527188931469};\\\", \\\"{x:467,y:797,t:1527188931486};\\\", \\\"{x:470,y:795,t:1527188931502};\\\", \\\"{x:474,y:793,t:1527188931520};\\\", \\\"{x:478,y:792,t:1527188931537};\\\", \\\"{x:482,y:788,t:1527188931552};\\\", \\\"{x:485,y:785,t:1527188931569};\\\", \\\"{x:488,y:781,t:1527188931586};\\\", \\\"{x:489,y:780,t:1527188931603};\\\", \\\"{x:490,y:777,t:1527188931619};\\\", \\\"{x:491,y:777,t:1527188931637};\\\", \\\"{x:491,y:776,t:1527188931653};\\\", \\\"{x:494,y:772,t:1527188931670};\\\", \\\"{x:501,y:767,t:1527188931687};\\\", \\\"{x:507,y:761,t:1527188931704};\\\", \\\"{x:510,y:758,t:1527188931719};\\\", \\\"{x:513,y:755,t:1527188931736};\\\", \\\"{x:513,y:754,t:1527188931754};\\\", \\\"{x:513,y:753,t:1527188931770};\\\", \\\"{x:514,y:752,t:1527188931787};\\\", \\\"{x:515,y:750,t:1527188931802};\\\", \\\"{x:517,y:748,t:1527188931820};\\\", \\\"{x:517,y:747,t:1527188931868};\\\", \\\"{x:517,y:746,t:1527188931900};\\\", \\\"{x:517,y:739,t:1527188933099};\\\", \\\"{x:512,y:732,t:1527188933121};\\\", \\\"{x:509,y:729,t:1527188933138};\\\", \\\"{x:506,y:727,t:1527188933153};\\\", \\\"{x:504,y:726,t:1527188933170};\\\" ] }, { \\\"rt\\\": 56000, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 369338, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\", \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -B -E -G -G -C -C -A -A -X -X -F -G -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:725,t:1527188933279};\\\", \\\"{x:503,y:725,t:1527188933347};\\\", \\\"{x:501,y:723,t:1527188933355};\\\", \\\"{x:500,y:721,t:1527188933370};\\\", \\\"{x:491,y:714,t:1527188933387};\\\", \\\"{x:474,y:702,t:1527188933406};\\\", \\\"{x:461,y:693,t:1527188933420};\\\", \\\"{x:451,y:687,t:1527188933437};\\\", \\\"{x:441,y:682,t:1527188933454};\\\", \\\"{x:433,y:678,t:1527188933470};\\\", \\\"{x:428,y:674,t:1527188933488};\\\", \\\"{x:425,y:672,t:1527188933504};\\\", \\\"{x:424,y:671,t:1527188933520};\\\", \\\"{x:423,y:671,t:1527188933537};\\\", \\\"{x:422,y:670,t:1527188933644};\\\", \\\"{x:421,y:670,t:1527188933659};\\\", \\\"{x:419,y:668,t:1527188933671};\\\", \\\"{x:409,y:660,t:1527188933768};\\\", \\\"{x:405,y:656,t:1527188933787};\\\", \\\"{x:396,y:650,t:1527188933806};\\\", \\\"{x:387,y:644,t:1527188933821};\\\", \\\"{x:374,y:637,t:1527188933838};\\\", \\\"{x:361,y:629,t:1527188933855};\\\", \\\"{x:345,y:619,t:1527188933872};\\\", \\\"{x:324,y:608,t:1527188933887};\\\", \\\"{x:301,y:593,t:1527188933905};\\\", \\\"{x:277,y:578,t:1527188933921};\\\", \\\"{x:252,y:564,t:1527188933938};\\\", \\\"{x:223,y:546,t:1527188933955};\\\", \\\"{x:189,y:526,t:1527188933971};\\\", \\\"{x:165,y:512,t:1527188933988};\\\", \\\"{x:145,y:501,t:1527188934004};\\\", \\\"{x:126,y:492,t:1527188934022};\\\", \\\"{x:114,y:485,t:1527188934038};\\\", \\\"{x:108,y:483,t:1527188934055};\\\", \\\"{x:101,y:479,t:1527188934072};\\\", \\\"{x:96,y:475,t:1527188934089};\\\", \\\"{x:86,y:470,t:1527188934104};\\\", \\\"{x:75,y:464,t:1527188934122};\\\", \\\"{x:66,y:458,t:1527188934139};\\\", \\\"{x:58,y:453,t:1527188934155};\\\", \\\"{x:39,y:445,t:1527188934171};\\\", \\\"{x:22,y:437,t:1527188934188};\\\", \\\"{x:5,y:427,t:1527188934204};\\\", \\\"{x:0,y:421,t:1527188934221};\\\", \\\"{x:0,y:415,t:1527188934239};\\\", \\\"{x:0,y:412,t:1527188934255};\\\", \\\"{x:0,y:410,t:1527188934271};\\\", \\\"{x:0,y:409,t:1527188934300};\\\", \\\"{x:13,y:413,t:1527188939141};\\\", \\\"{x:47,y:427,t:1527188939148};\\\", \\\"{x:82,y:444,t:1527188939163};\\\", \\\"{x:175,y:482,t:1527188939178};\\\", \\\"{x:278,y:514,t:1527188939197};\\\", \\\"{x:454,y:577,t:1527188939212};\\\", \\\"{x:675,y:661,t:1527188939238};\\\", \\\"{x:832,y:698,t:1527188939255};\\\", \\\"{x:986,y:740,t:1527188939272};\\\", \\\"{x:1126,y:775,t:1527188939288};\\\", \\\"{x:1235,y:791,t:1527188939305};\\\", \\\"{x:1315,y:802,t:1527188939322};\\\", \\\"{x:1355,y:802,t:1527188939338};\\\", \\\"{x:1375,y:802,t:1527188939355};\\\", \\\"{x:1377,y:801,t:1527188939371};\\\", \\\"{x:1377,y:794,t:1527188939596};\\\", \\\"{x:1377,y:789,t:1527188939605};\\\", \\\"{x:1369,y:776,t:1527188939621};\\\", \\\"{x:1359,y:766,t:1527188939638};\\\", \\\"{x:1346,y:756,t:1527188939656};\\\", \\\"{x:1340,y:751,t:1527188939671};\\\", \\\"{x:1339,y:749,t:1527188939689};\\\", \\\"{x:1339,y:752,t:1527188939981};\\\", \\\"{x:1342,y:757,t:1527188939989};\\\", \\\"{x:1348,y:766,t:1527188940007};\\\", \\\"{x:1356,y:774,t:1527188940022};\\\", \\\"{x:1356,y:777,t:1527188940038};\\\", \\\"{x:1357,y:778,t:1527188940060};\\\", \\\"{x:1355,y:776,t:1527188940325};\\\", \\\"{x:1351,y:775,t:1527188940338};\\\", \\\"{x:1341,y:770,t:1527188940356};\\\", \\\"{x:1336,y:767,t:1527188940372};\\\", \\\"{x:1325,y:760,t:1527188940388};\\\", \\\"{x:1321,y:757,t:1527188940406};\\\", \\\"{x:1316,y:750,t:1527188940422};\\\", \\\"{x:1312,y:742,t:1527188940439};\\\", \\\"{x:1309,y:728,t:1527188940455};\\\", \\\"{x:1305,y:708,t:1527188940472};\\\", \\\"{x:1298,y:687,t:1527188940488};\\\", \\\"{x:1295,y:673,t:1527188940506};\\\", \\\"{x:1294,y:664,t:1527188940522};\\\", \\\"{x:1294,y:659,t:1527188940538};\\\", \\\"{x:1294,y:655,t:1527188940555};\\\", \\\"{x:1294,y:648,t:1527188940571};\\\", \\\"{x:1294,y:635,t:1527188940588};\\\", \\\"{x:1294,y:627,t:1527188940606};\\\", \\\"{x:1288,y:612,t:1527188940622};\\\", \\\"{x:1285,y:603,t:1527188940639};\\\", \\\"{x:1282,y:595,t:1527188940656};\\\", \\\"{x:1281,y:591,t:1527188940671};\\\", \\\"{x:1280,y:589,t:1527188940688};\\\", \\\"{x:1280,y:586,t:1527188940706};\\\", \\\"{x:1280,y:585,t:1527188940722};\\\", \\\"{x:1279,y:584,t:1527188940738};\\\", \\\"{x:1279,y:583,t:1527188940755};\\\", \\\"{x:1278,y:586,t:1527188945781};\\\", \\\"{x:1281,y:597,t:1527188945788};\\\", \\\"{x:1291,y:613,t:1527188945804};\\\", \\\"{x:1296,y:625,t:1527188945822};\\\", \\\"{x:1301,y:635,t:1527188945839};\\\", \\\"{x:1305,y:643,t:1527188945855};\\\", \\\"{x:1313,y:653,t:1527188945871};\\\", \\\"{x:1317,y:659,t:1527188945888};\\\", \\\"{x:1319,y:662,t:1527188945904};\\\", \\\"{x:1321,y:664,t:1527188945921};\\\", \\\"{x:1323,y:670,t:1527188945938};\\\", \\\"{x:1331,y:678,t:1527188945954};\\\", \\\"{x:1345,y:696,t:1527188945971};\\\", \\\"{x:1352,y:704,t:1527188945988};\\\", \\\"{x:1358,y:710,t:1527188946004};\\\", \\\"{x:1360,y:713,t:1527188946021};\\\", \\\"{x:1361,y:715,t:1527188946038};\\\", \\\"{x:1362,y:716,t:1527188946147};\\\", \\\"{x:1362,y:717,t:1527188946172};\\\", \\\"{x:1362,y:720,t:1527188946187};\\\", \\\"{x:1361,y:722,t:1527188946204};\\\", \\\"{x:1359,y:728,t:1527188946221};\\\", \\\"{x:1357,y:734,t:1527188946238};\\\", \\\"{x:1356,y:739,t:1527188946254};\\\", \\\"{x:1355,y:745,t:1527188946271};\\\", \\\"{x:1354,y:750,t:1527188946289};\\\", \\\"{x:1354,y:752,t:1527188946324};\\\", \\\"{x:1353,y:753,t:1527188946348};\\\", \\\"{x:1352,y:755,t:1527188946364};\\\", \\\"{x:1352,y:756,t:1527188946372};\\\", \\\"{x:1351,y:757,t:1527188946389};\\\", \\\"{x:1351,y:758,t:1527188946405};\\\", \\\"{x:1350,y:758,t:1527188948725};\\\", \\\"{x:1349,y:758,t:1527188948738};\\\", \\\"{x:1343,y:758,t:1527188948756};\\\", \\\"{x:1336,y:758,t:1527188948772};\\\", \\\"{x:1331,y:758,t:1527188948788};\\\", \\\"{x:1330,y:758,t:1527188948804};\\\", \\\"{x:1329,y:758,t:1527188948861};\\\", \\\"{x:1328,y:758,t:1527188948877};\\\", \\\"{x:1327,y:758,t:1527188948888};\\\", \\\"{x:1325,y:758,t:1527188948905};\\\", \\\"{x:1323,y:758,t:1527188948922};\\\", \\\"{x:1321,y:758,t:1527188948938};\\\", \\\"{x:1320,y:757,t:1527188948955};\\\", \\\"{x:1318,y:757,t:1527188948972};\\\", \\\"{x:1317,y:757,t:1527188948996};\\\", \\\"{x:1315,y:757,t:1527188949012};\\\", \\\"{x:1314,y:756,t:1527188949022};\\\", \\\"{x:1312,y:756,t:1527188949038};\\\", \\\"{x:1310,y:756,t:1527188949055};\\\", \\\"{x:1307,y:755,t:1527188949072};\\\", \\\"{x:1303,y:755,t:1527188949088};\\\", \\\"{x:1298,y:755,t:1527188949105};\\\", \\\"{x:1295,y:755,t:1527188949122};\\\", \\\"{x:1291,y:755,t:1527188949137};\\\", \\\"{x:1288,y:755,t:1527188949155};\\\", \\\"{x:1284,y:755,t:1527188949171};\\\", \\\"{x:1279,y:755,t:1527188949187};\\\", \\\"{x:1272,y:755,t:1527188949204};\\\", \\\"{x:1265,y:755,t:1527188949221};\\\", \\\"{x:1261,y:755,t:1527188949238};\\\", \\\"{x:1257,y:755,t:1527188949254};\\\", \\\"{x:1253,y:755,t:1527188949272};\\\", \\\"{x:1250,y:755,t:1527188949287};\\\", \\\"{x:1246,y:755,t:1527188949304};\\\", \\\"{x:1244,y:755,t:1527188949324};\\\", \\\"{x:1242,y:755,t:1527188949340};\\\", \\\"{x:1241,y:755,t:1527188949355};\\\", \\\"{x:1237,y:755,t:1527188949372};\\\", \\\"{x:1234,y:755,t:1527188949387};\\\", \\\"{x:1230,y:755,t:1527188949405};\\\", \\\"{x:1227,y:755,t:1527188949422};\\\", \\\"{x:1222,y:755,t:1527188949437};\\\", \\\"{x:1219,y:756,t:1527188949454};\\\", \\\"{x:1215,y:756,t:1527188949472};\\\", \\\"{x:1212,y:756,t:1527188949488};\\\", \\\"{x:1207,y:756,t:1527188949504};\\\", \\\"{x:1204,y:756,t:1527188949522};\\\", \\\"{x:1202,y:756,t:1527188949537};\\\", \\\"{x:1201,y:756,t:1527188949555};\\\", \\\"{x:1205,y:756,t:1527188950060};\\\", \\\"{x:1215,y:758,t:1527188950072};\\\", \\\"{x:1232,y:766,t:1527188950088};\\\", \\\"{x:1244,y:769,t:1527188950105};\\\", \\\"{x:1255,y:771,t:1527188950122};\\\", \\\"{x:1264,y:772,t:1527188950138};\\\", \\\"{x:1269,y:772,t:1527188950155};\\\", \\\"{x:1279,y:773,t:1527188950172};\\\", \\\"{x:1282,y:773,t:1527188950188};\\\", \\\"{x:1283,y:773,t:1527188950260};\\\", \\\"{x:1284,y:771,t:1527188950302};\\\", \\\"{x:1284,y:766,t:1527188950308};\\\", \\\"{x:1285,y:755,t:1527188950322};\\\", \\\"{x:1285,y:728,t:1527188950338};\\\", \\\"{x:1285,y:703,t:1527188950355};\\\", \\\"{x:1285,y:678,t:1527188950372};\\\", \\\"{x:1285,y:659,t:1527188950388};\\\", \\\"{x:1285,y:637,t:1527188950405};\\\", \\\"{x:1284,y:620,t:1527188950422};\\\", \\\"{x:1283,y:607,t:1527188950438};\\\", \\\"{x:1280,y:595,t:1527188950455};\\\", \\\"{x:1280,y:588,t:1527188950472};\\\", \\\"{x:1280,y:585,t:1527188950488};\\\", \\\"{x:1280,y:584,t:1527188950516};\\\", \\\"{x:1280,y:583,t:1527188950532};\\\", \\\"{x:1281,y:582,t:1527188950549};\\\", \\\"{x:1281,y:581,t:1527188950564};\\\", \\\"{x:1281,y:580,t:1527188950572};\\\", \\\"{x:1281,y:579,t:1527188950588};\\\", \\\"{x:1281,y:578,t:1527188950612};\\\", \\\"{x:1281,y:577,t:1527188950622};\\\", \\\"{x:1281,y:576,t:1527188950638};\\\", \\\"{x:1281,y:575,t:1527188950655};\\\", \\\"{x:1281,y:572,t:1527188950672};\\\", \\\"{x:1281,y:570,t:1527188950688};\\\", \\\"{x:1281,y:569,t:1527188959053};\\\", \\\"{x:1256,y:567,t:1527188959073};\\\", \\\"{x:1210,y:560,t:1527188959087};\\\", \\\"{x:1151,y:552,t:1527188959104};\\\", \\\"{x:1064,y:535,t:1527188959121};\\\", \\\"{x:968,y:509,t:1527188959137};\\\", \\\"{x:874,y:486,t:1527188959154};\\\", \\\"{x:780,y:460,t:1527188959170};\\\", \\\"{x:708,y:441,t:1527188959186};\\\", \\\"{x:650,y:427,t:1527188959204};\\\", \\\"{x:632,y:422,t:1527188959221};\\\", \\\"{x:626,y:422,t:1527188959236};\\\", \\\"{x:621,y:422,t:1527188959254};\\\", \\\"{x:620,y:422,t:1527188959271};\\\", \\\"{x:618,y:422,t:1527188959287};\\\", \\\"{x:617,y:422,t:1527188959304};\\\", \\\"{x:614,y:423,t:1527188959321};\\\", \\\"{x:612,y:428,t:1527188959337};\\\", \\\"{x:608,y:434,t:1527188959354};\\\", \\\"{x:605,y:443,t:1527188959371};\\\", \\\"{x:605,y:460,t:1527188959388};\\\", \\\"{x:611,y:486,t:1527188959405};\\\", \\\"{x:618,y:496,t:1527188959423};\\\", \\\"{x:625,y:500,t:1527188959436};\\\", \\\"{x:628,y:503,t:1527188959454};\\\", \\\"{x:630,y:505,t:1527188959475};\\\", \\\"{x:628,y:505,t:1527188959701};\\\", \\\"{x:624,y:504,t:1527188959710};\\\", \\\"{x:620,y:502,t:1527188959726};\\\", \\\"{x:617,y:501,t:1527188959742};\\\", \\\"{x:616,y:500,t:1527188959759};\\\", \\\"{x:616,y:498,t:1527188960124};\\\", \\\"{x:620,y:497,t:1527188960132};\\\", \\\"{x:623,y:495,t:1527188960143};\\\", \\\"{x:631,y:492,t:1527188960160};\\\", \\\"{x:634,y:490,t:1527188960175};\\\", \\\"{x:637,y:489,t:1527188960193};\\\", \\\"{x:638,y:489,t:1527188960211};\\\", \\\"{x:639,y:488,t:1527188960226};\\\", \\\"{x:644,y:488,t:1527188960243};\\\", \\\"{x:662,y:488,t:1527188960259};\\\", \\\"{x:680,y:488,t:1527188960276};\\\", \\\"{x:697,y:489,t:1527188960293};\\\", \\\"{x:706,y:490,t:1527188960310};\\\", \\\"{x:708,y:490,t:1527188960326};\\\", \\\"{x:710,y:490,t:1527188960372};\\\", \\\"{x:713,y:492,t:1527188960380};\\\", \\\"{x:721,y:494,t:1527188960393};\\\", \\\"{x:747,y:501,t:1527188960412};\\\", \\\"{x:794,y:514,t:1527188960425};\\\", \\\"{x:861,y:532,t:1527188960443};\\\", \\\"{x:979,y:548,t:1527188960460};\\\", \\\"{x:1060,y:561,t:1527188960477};\\\", \\\"{x:1144,y:574,t:1527188960492};\\\", \\\"{x:1224,y:585,t:1527188960510};\\\", \\\"{x:1307,y:595,t:1527188960526};\\\", \\\"{x:1363,y:603,t:1527188960543};\\\", \\\"{x:1390,y:605,t:1527188960560};\\\", \\\"{x:1409,y:605,t:1527188960577};\\\", \\\"{x:1422,y:605,t:1527188960593};\\\", \\\"{x:1425,y:605,t:1527188960610};\\\", \\\"{x:1426,y:605,t:1527188960627};\\\", \\\"{x:1428,y:605,t:1527188960643};\\\", \\\"{x:1430,y:605,t:1527188960660};\\\", \\\"{x:1431,y:605,t:1527188960677};\\\", \\\"{x:1430,y:604,t:1527188960740};\\\", \\\"{x:1424,y:602,t:1527188960749};\\\", \\\"{x:1412,y:596,t:1527188960760};\\\", \\\"{x:1385,y:584,t:1527188960777};\\\", \\\"{x:1365,y:575,t:1527188960793};\\\", \\\"{x:1348,y:568,t:1527188960810};\\\", \\\"{x:1340,y:564,t:1527188960827};\\\", \\\"{x:1337,y:563,t:1527188960843};\\\", \\\"{x:1334,y:561,t:1527188960860};\\\", \\\"{x:1332,y:561,t:1527188960877};\\\", \\\"{x:1330,y:561,t:1527188960893};\\\", \\\"{x:1329,y:561,t:1527188960915};\\\", \\\"{x:1328,y:561,t:1527188960971};\\\", \\\"{x:1327,y:561,t:1527188960995};\\\", \\\"{x:1326,y:561,t:1527188961010};\\\", \\\"{x:1327,y:561,t:1527188961068};\\\", \\\"{x:1331,y:560,t:1527188961078};\\\", \\\"{x:1348,y:556,t:1527188961093};\\\", \\\"{x:1375,y:552,t:1527188961110};\\\", \\\"{x:1411,y:548,t:1527188961127};\\\", \\\"{x:1442,y:548,t:1527188961144};\\\", \\\"{x:1460,y:548,t:1527188961160};\\\", \\\"{x:1469,y:548,t:1527188961177};\\\", \\\"{x:1470,y:549,t:1527188961307};\\\", \\\"{x:1469,y:549,t:1527188961323};\\\", \\\"{x:1467,y:550,t:1527188961331};\\\", \\\"{x:1465,y:550,t:1527188961343};\\\", \\\"{x:1460,y:553,t:1527188961359};\\\", \\\"{x:1448,y:558,t:1527188961377};\\\", \\\"{x:1433,y:564,t:1527188961394};\\\", \\\"{x:1421,y:569,t:1527188961410};\\\", \\\"{x:1414,y:573,t:1527188961427};\\\", \\\"{x:1410,y:575,t:1527188961443};\\\", \\\"{x:1409,y:575,t:1527188961468};\\\", \\\"{x:1407,y:575,t:1527188961501};\\\", \\\"{x:1406,y:576,t:1527188961589};\\\", \\\"{x:1403,y:577,t:1527188961604};\\\", \\\"{x:1402,y:577,t:1527188961620};\\\", \\\"{x:1402,y:575,t:1527188966605};\\\", \\\"{x:1402,y:571,t:1527188966615};\\\", \\\"{x:1404,y:566,t:1527188966632};\\\", \\\"{x:1404,y:565,t:1527188966648};\\\", \\\"{x:1404,y:564,t:1527188966665};\\\", \\\"{x:1404,y:563,t:1527188968732};\\\", \\\"{x:1384,y:559,t:1527188968751};\\\", \\\"{x:1347,y:553,t:1527188968767};\\\", \\\"{x:1307,y:553,t:1527188968783};\\\", \\\"{x:1235,y:552,t:1527188968800};\\\", \\\"{x:1157,y:541,t:1527188968817};\\\", \\\"{x:1077,y:533,t:1527188968832};\\\", \\\"{x:1013,y:532,t:1527188968850};\\\", \\\"{x:970,y:532,t:1527188968867};\\\", \\\"{x:945,y:532,t:1527188968884};\\\", \\\"{x:922,y:532,t:1527188968899};\\\", \\\"{x:917,y:532,t:1527188968916};\\\", \\\"{x:916,y:532,t:1527188968930};\\\", \\\"{x:915,y:532,t:1527188968946};\\\", \\\"{x:914,y:533,t:1527188968962};\\\", \\\"{x:912,y:534,t:1527188968987};\\\", \\\"{x:910,y:534,t:1527188969003};\\\", \\\"{x:908,y:536,t:1527188969012};\\\", \\\"{x:900,y:540,t:1527188969029};\\\", \\\"{x:897,y:544,t:1527188969046};\\\", \\\"{x:892,y:550,t:1527188969063};\\\", \\\"{x:889,y:555,t:1527188969079};\\\", \\\"{x:887,y:557,t:1527188969097};\\\", \\\"{x:885,y:557,t:1527188969113};\\\", \\\"{x:882,y:558,t:1527188969133};\\\", \\\"{x:880,y:558,t:1527188969172};\\\", \\\"{x:879,y:558,t:1527188969184};\\\", \\\"{x:877,y:558,t:1527188969200};\\\", \\\"{x:875,y:557,t:1527188969217};\\\", \\\"{x:870,y:555,t:1527188969234};\\\", \\\"{x:865,y:552,t:1527188969251};\\\", \\\"{x:856,y:547,t:1527188969268};\\\", \\\"{x:851,y:544,t:1527188969283};\\\", \\\"{x:849,y:543,t:1527188969300};\\\", \\\"{x:848,y:542,t:1527188969948};\\\", \\\"{x:850,y:540,t:1527188969956};\\\", \\\"{x:859,y:535,t:1527188969968};\\\", \\\"{x:873,y:530,t:1527188969986};\\\", \\\"{x:892,y:526,t:1527188970002};\\\", \\\"{x:913,y:526,t:1527188970017};\\\", \\\"{x:941,y:526,t:1527188970034};\\\", \\\"{x:965,y:526,t:1527188970051};\\\", \\\"{x:1000,y:525,t:1527188970067};\\\", \\\"{x:1025,y:524,t:1527188970084};\\\", \\\"{x:1045,y:522,t:1527188970100};\\\", \\\"{x:1063,y:522,t:1527188970117};\\\", \\\"{x:1078,y:522,t:1527188970134};\\\", \\\"{x:1093,y:522,t:1527188970152};\\\", \\\"{x:1115,y:522,t:1527188970167};\\\", \\\"{x:1140,y:520,t:1527188970184};\\\", \\\"{x:1164,y:518,t:1527188970201};\\\", \\\"{x:1193,y:517,t:1527188970218};\\\", \\\"{x:1216,y:517,t:1527188970235};\\\", \\\"{x:1247,y:517,t:1527188970252};\\\", \\\"{x:1266,y:517,t:1527188970267};\\\", \\\"{x:1280,y:517,t:1527188970284};\\\", \\\"{x:1296,y:517,t:1527188970302};\\\", \\\"{x:1307,y:519,t:1527188970317};\\\", \\\"{x:1316,y:520,t:1527188970334};\\\", \\\"{x:1324,y:520,t:1527188970352};\\\", \\\"{x:1334,y:521,t:1527188970367};\\\", \\\"{x:1341,y:524,t:1527188970385};\\\", \\\"{x:1347,y:525,t:1527188970402};\\\", \\\"{x:1356,y:528,t:1527188970417};\\\", \\\"{x:1369,y:532,t:1527188970434};\\\", \\\"{x:1391,y:540,t:1527188970451};\\\", \\\"{x:1399,y:543,t:1527188970468};\\\", \\\"{x:1402,y:544,t:1527188970485};\\\", \\\"{x:1402,y:545,t:1527188970515};\\\", \\\"{x:1402,y:546,t:1527188970524};\\\", \\\"{x:1402,y:547,t:1527188970539};\\\", \\\"{x:1402,y:548,t:1527188970552};\\\", \\\"{x:1402,y:549,t:1527188970568};\\\", \\\"{x:1403,y:550,t:1527188970587};\\\", \\\"{x:1403,y:551,t:1527188970611};\\\", \\\"{x:1403,y:552,t:1527188970620};\\\", \\\"{x:1403,y:553,t:1527188970643};\\\", \\\"{x:1403,y:554,t:1527188970651};\\\", \\\"{x:1404,y:556,t:1527188970668};\\\", \\\"{x:1404,y:558,t:1527188970700};\\\", \\\"{x:1404,y:559,t:1527188970716};\\\", \\\"{x:1406,y:562,t:1527188970723};\\\", \\\"{x:1407,y:563,t:1527188970735};\\\", \\\"{x:1410,y:567,t:1527188970752};\\\", \\\"{x:1410,y:569,t:1527188970785};\\\", \\\"{x:1411,y:569,t:1527188970802};\\\", \\\"{x:1411,y:570,t:1527188970820};\\\", \\\"{x:1412,y:570,t:1527188970835};\\\", \\\"{x:1413,y:571,t:1527188970851};\\\", \\\"{x:1414,y:572,t:1527188970956};\\\", \\\"{x:1415,y:573,t:1527188970968};\\\", \\\"{x:1417,y:576,t:1527188970986};\\\", \\\"{x:1421,y:578,t:1527188971001};\\\", \\\"{x:1429,y:582,t:1527188971019};\\\", \\\"{x:1440,y:588,t:1527188971036};\\\", \\\"{x:1445,y:590,t:1527188971051};\\\", \\\"{x:1447,y:592,t:1527188971069};\\\", \\\"{x:1448,y:592,t:1527188971086};\\\", \\\"{x:1450,y:594,t:1527188971102};\\\", \\\"{x:1453,y:596,t:1527188971118};\\\", \\\"{x:1456,y:599,t:1527188971136};\\\", \\\"{x:1458,y:600,t:1527188971152};\\\", \\\"{x:1458,y:601,t:1527188971168};\\\", \\\"{x:1459,y:602,t:1527188971185};\\\", \\\"{x:1459,y:604,t:1527188971201};\\\", \\\"{x:1461,y:608,t:1527188971218};\\\", \\\"{x:1464,y:613,t:1527188971235};\\\", \\\"{x:1466,y:616,t:1527188971252};\\\", \\\"{x:1466,y:619,t:1527188971268};\\\", \\\"{x:1466,y:620,t:1527188971348};\\\", \\\"{x:1466,y:622,t:1527188971356};\\\", \\\"{x:1466,y:623,t:1527188971388};\\\", \\\"{x:1465,y:624,t:1527188971402};\\\", \\\"{x:1464,y:624,t:1527188971419};\\\", \\\"{x:1462,y:626,t:1527188971436};\\\", \\\"{x:1460,y:626,t:1527188971453};\\\", \\\"{x:1457,y:626,t:1527188971469};\\\", \\\"{x:1456,y:626,t:1527188971486};\\\", \\\"{x:1453,y:626,t:1527188971502};\\\", \\\"{x:1452,y:626,t:1527188971519};\\\", \\\"{x:1451,y:625,t:1527188971535};\\\", \\\"{x:1449,y:624,t:1527188971553};\\\", \\\"{x:1446,y:623,t:1527188971568};\\\", \\\"{x:1444,y:622,t:1527188971585};\\\", \\\"{x:1441,y:621,t:1527188971602};\\\", \\\"{x:1436,y:619,t:1527188971618};\\\", \\\"{x:1432,y:615,t:1527188971635};\\\", \\\"{x:1427,y:612,t:1527188971652};\\\", \\\"{x:1419,y:605,t:1527188971669};\\\", \\\"{x:1411,y:598,t:1527188971686};\\\", \\\"{x:1401,y:591,t:1527188971702};\\\", \\\"{x:1394,y:585,t:1527188971718};\\\", \\\"{x:1384,y:577,t:1527188971735};\\\", \\\"{x:1376,y:571,t:1527188971753};\\\", \\\"{x:1366,y:563,t:1527188971769};\\\", \\\"{x:1358,y:558,t:1527188971786};\\\", \\\"{x:1353,y:553,t:1527188971803};\\\", \\\"{x:1352,y:553,t:1527188972027};\\\", \\\"{x:1352,y:549,t:1527188972484};\\\", \\\"{x:1356,y:542,t:1527188972492};\\\", \\\"{x:1359,y:539,t:1527188972503};\\\", \\\"{x:1365,y:533,t:1527188972519};\\\", \\\"{x:1369,y:528,t:1527188972536};\\\", \\\"{x:1370,y:525,t:1527188972552};\\\", \\\"{x:1372,y:522,t:1527188972570};\\\", \\\"{x:1374,y:517,t:1527188972586};\\\", \\\"{x:1378,y:512,t:1527188972602};\\\", \\\"{x:1384,y:506,t:1527188972619};\\\", \\\"{x:1387,y:503,t:1527188972636};\\\", \\\"{x:1390,y:500,t:1527188972653};\\\", \\\"{x:1391,y:499,t:1527188972669};\\\", \\\"{x:1392,y:496,t:1527188972686};\\\", \\\"{x:1394,y:494,t:1527188972702};\\\", \\\"{x:1395,y:493,t:1527188972720};\\\", \\\"{x:1395,y:491,t:1527188972736};\\\", \\\"{x:1395,y:488,t:1527188972753};\\\", \\\"{x:1395,y:484,t:1527188972770};\\\", \\\"{x:1396,y:473,t:1527188972786};\\\", \\\"{x:1401,y:460,t:1527188972803};\\\", \\\"{x:1409,y:436,t:1527188972820};\\\", \\\"{x:1411,y:425,t:1527188972837};\\\", \\\"{x:1413,y:419,t:1527188972854};\\\", \\\"{x:1413,y:417,t:1527188972869};\\\", \\\"{x:1413,y:415,t:1527188972886};\\\", \\\"{x:1412,y:415,t:1527188973317};\\\", \\\"{x:1411,y:415,t:1527188973324};\\\", \\\"{x:1410,y:415,t:1527188973337};\\\", \\\"{x:1410,y:416,t:1527188973356};\\\", \\\"{x:1408,y:417,t:1527188973372};\\\", \\\"{x:1407,y:418,t:1527188973388};\\\", \\\"{x:1407,y:419,t:1527188973404};\\\", \\\"{x:1404,y:421,t:1527188973421};\\\", \\\"{x:1403,y:422,t:1527188973437};\\\", \\\"{x:1402,y:423,t:1527188973454};\\\", \\\"{x:1401,y:423,t:1527188973471};\\\", \\\"{x:1400,y:424,t:1527188973487};\\\", \\\"{x:1398,y:425,t:1527188973932};\\\", \\\"{x:1392,y:425,t:1527188973940};\\\", \\\"{x:1384,y:429,t:1527188973954};\\\", \\\"{x:1361,y:436,t:1527188973971};\\\", \\\"{x:1326,y:446,t:1527188973988};\\\", \\\"{x:1298,y:453,t:1527188974004};\\\", \\\"{x:1263,y:465,t:1527188974021};\\\", \\\"{x:1216,y:486,t:1527188974038};\\\", \\\"{x:1169,y:506,t:1527188974054};\\\", \\\"{x:1103,y:535,t:1527188974071};\\\", \\\"{x:990,y:583,t:1527188974088};\\\", \\\"{x:866,y:617,t:1527188974106};\\\", \\\"{x:747,y:648,t:1527188974121};\\\", \\\"{x:657,y:667,t:1527188974137};\\\", \\\"{x:609,y:675,t:1527188974154};\\\", \\\"{x:571,y:683,t:1527188974170};\\\", \\\"{x:539,y:688,t:1527188974187};\\\", \\\"{x:530,y:688,t:1527188974204};\\\", \\\"{x:527,y:688,t:1527188974220};\\\", \\\"{x:525,y:688,t:1527188974238};\\\", \\\"{x:524,y:688,t:1527188974254};\\\", \\\"{x:522,y:688,t:1527188974270};\\\", \\\"{x:515,y:688,t:1527188974288};\\\", \\\"{x:501,y:688,t:1527188974304};\\\", \\\"{x:484,y:688,t:1527188974320};\\\", \\\"{x:478,y:688,t:1527188974338};\\\", \\\"{x:477,y:688,t:1527188974355};\\\", \\\"{x:476,y:688,t:1527188974395};\\\", \\\"{x:475,y:688,t:1527188974405};\\\", \\\"{x:473,y:694,t:1527188974421};\\\", \\\"{x:470,y:702,t:1527188974438};\\\", \\\"{x:470,y:708,t:1527188974455};\\\", \\\"{x:470,y:714,t:1527188974471};\\\", \\\"{x:470,y:719,t:1527188974487};\\\", \\\"{x:470,y:726,t:1527188974505};\\\", \\\"{x:470,y:734,t:1527188974520};\\\", \\\"{x:470,y:738,t:1527188974537};\\\", \\\"{x:470,y:740,t:1527188974555};\\\", \\\"{x:471,y:744,t:1527188974571};\\\", \\\"{x:471,y:747,t:1527188974589};\\\", \\\"{x:473,y:749,t:1527188974605};\\\", \\\"{x:475,y:751,t:1527188974622};\\\", \\\"{x:475,y:752,t:1527188974639};\\\", \\\"{x:476,y:752,t:1527188975108};\\\", \\\"{x:478,y:751,t:1527188975635};\\\", \\\"{x:483,y:750,t:1527188975643};\\\", \\\"{x:491,y:745,t:1527188975657};\\\", \\\"{x:512,y:739,t:1527188975673};\\\", \\\"{x:567,y:725,t:1527188975690};\\\", \\\"{x:709,y:694,t:1527188975708};\\\", \\\"{x:766,y:684,t:1527188975722};\\\", \\\"{x:874,y:672,t:1527188975738};\\\", \\\"{x:1015,y:648,t:1527188975755};\\\", \\\"{x:1109,y:637,t:1527188975773};\\\", \\\"{x:1175,y:630,t:1527188975788};\\\", \\\"{x:1231,y:630,t:1527188975806};\\\", \\\"{x:1265,y:630,t:1527188975822};\\\", \\\"{x:1286,y:630,t:1527188975839};\\\", \\\"{x:1299,y:627,t:1527188975856};\\\", \\\"{x:1304,y:625,t:1527188975872};\\\", \\\"{x:1308,y:624,t:1527188975889};\\\", \\\"{x:1313,y:624,t:1527188975906};\\\", \\\"{x:1320,y:623,t:1527188975922};\\\", \\\"{x:1325,y:621,t:1527188975939};\\\", \\\"{x:1328,y:620,t:1527188975955};\\\", \\\"{x:1334,y:620,t:1527188975972};\\\", \\\"{x:1346,y:617,t:1527188975988};\\\", \\\"{x:1362,y:615,t:1527188976005};\\\", \\\"{x:1376,y:614,t:1527188976023};\\\", \\\"{x:1382,y:614,t:1527188976040};\\\", \\\"{x:1383,y:614,t:1527188976055};\\\", \\\"{x:1384,y:614,t:1527188976196};\\\", \\\"{x:1384,y:616,t:1527188976219};\\\", \\\"{x:1389,y:619,t:1527188976228};\\\", \\\"{x:1391,y:621,t:1527188976240};\\\", \\\"{x:1400,y:626,t:1527188976256};\\\", \\\"{x:1412,y:633,t:1527188976273};\\\", \\\"{x:1423,y:639,t:1527188976290};\\\", \\\"{x:1431,y:642,t:1527188976307};\\\", \\\"{x:1437,y:644,t:1527188976323};\\\", \\\"{x:1446,y:645,t:1527188976339};\\\", \\\"{x:1450,y:645,t:1527188976356};\\\", \\\"{x:1452,y:645,t:1527188976388};\\\", \\\"{x:1453,y:645,t:1527188976436};\\\", \\\"{x:1455,y:645,t:1527188976460};\\\", \\\"{x:1456,y:644,t:1527188976474};\\\", \\\"{x:1457,y:643,t:1527188976501};\\\", \\\"{x:1457,y:642,t:1527188976556};\\\", \\\"{x:1457,y:641,t:1527188976573};\\\", \\\"{x:1457,y:640,t:1527188976660};\\\", \\\"{x:1456,y:640,t:1527188976676};\\\", \\\"{x:1453,y:639,t:1527188976690};\\\", \\\"{x:1448,y:636,t:1527188976708};\\\", \\\"{x:1441,y:633,t:1527188976723};\\\", \\\"{x:1436,y:631,t:1527188976739};\\\", \\\"{x:1434,y:630,t:1527188976758};\\\", \\\"{x:1432,y:629,t:1527188976773};\\\", \\\"{x:1431,y:629,t:1527188976790};\\\", \\\"{x:1430,y:629,t:1527188976891};\\\", \\\"{x:1430,y:632,t:1527188976906};\\\", \\\"{x:1430,y:641,t:1527188976923};\\\", \\\"{x:1430,y:651,t:1527188976940};\\\", \\\"{x:1430,y:662,t:1527188976957};\\\", \\\"{x:1431,y:673,t:1527188976974};\\\", \\\"{x:1436,y:689,t:1527188976989};\\\", \\\"{x:1440,y:703,t:1527188977007};\\\", \\\"{x:1442,y:712,t:1527188977023};\\\", \\\"{x:1445,y:722,t:1527188977040};\\\", \\\"{x:1445,y:731,t:1527188977057};\\\", \\\"{x:1449,y:742,t:1527188977074};\\\", \\\"{x:1451,y:756,t:1527188977091};\\\", \\\"{x:1454,y:771,t:1527188977107};\\\", \\\"{x:1456,y:788,t:1527188977123};\\\", \\\"{x:1460,y:801,t:1527188977140};\\\", \\\"{x:1461,y:815,t:1527188977157};\\\", \\\"{x:1465,y:830,t:1527188977174};\\\", \\\"{x:1468,y:846,t:1527188977190};\\\", \\\"{x:1471,y:862,t:1527188977207};\\\", \\\"{x:1473,y:876,t:1527188977224};\\\", \\\"{x:1474,y:883,t:1527188977240};\\\", \\\"{x:1474,y:888,t:1527188977257};\\\", \\\"{x:1475,y:891,t:1527188977274};\\\", \\\"{x:1476,y:895,t:1527188977291};\\\", \\\"{x:1476,y:898,t:1527188977307};\\\", \\\"{x:1476,y:903,t:1527188977324};\\\", \\\"{x:1476,y:906,t:1527188977341};\\\", \\\"{x:1476,y:909,t:1527188977358};\\\", \\\"{x:1476,y:913,t:1527188977375};\\\", \\\"{x:1476,y:916,t:1527188977391};\\\", \\\"{x:1476,y:918,t:1527188977407};\\\", \\\"{x:1478,y:918,t:1527188977916};\\\", \\\"{x:1479,y:916,t:1527188977924};\\\", \\\"{x:1484,y:909,t:1527188977941};\\\", \\\"{x:1491,y:904,t:1527188977958};\\\", \\\"{x:1495,y:901,t:1527188977974};\\\", \\\"{x:1499,y:897,t:1527188977991};\\\", \\\"{x:1501,y:893,t:1527188978008};\\\", \\\"{x:1501,y:892,t:1527188978024};\\\", \\\"{x:1502,y:890,t:1527188978041};\\\", \\\"{x:1503,y:889,t:1527188978058};\\\", \\\"{x:1504,y:888,t:1527188978074};\\\", \\\"{x:1504,y:885,t:1527188978090};\\\", \\\"{x:1504,y:877,t:1527188978107};\\\", \\\"{x:1504,y:868,t:1527188978125};\\\", \\\"{x:1504,y:857,t:1527188978141};\\\", \\\"{x:1502,y:848,t:1527188978158};\\\", \\\"{x:1498,y:837,t:1527188978175};\\\", \\\"{x:1495,y:833,t:1527188978191};\\\", \\\"{x:1494,y:831,t:1527188978208};\\\", \\\"{x:1493,y:830,t:1527188978228};\\\", \\\"{x:1491,y:828,t:1527188978253};\\\", \\\"{x:1490,y:825,t:1527188978260};\\\", \\\"{x:1489,y:825,t:1527188978275};\\\", \\\"{x:1488,y:822,t:1527188978292};\\\", \\\"{x:1487,y:822,t:1527188978324};\\\", \\\"{x:1487,y:821,t:1527188978348};\\\", \\\"{x:1486,y:821,t:1527188978564};\\\", \\\"{x:1484,y:821,t:1527188978596};\\\", \\\"{x:1483,y:821,t:1527188978612};\\\", \\\"{x:1482,y:822,t:1527188978628};\\\", \\\"{x:1480,y:826,t:1527188979213};\\\", \\\"{x:1480,y:827,t:1527188979225};\\\", \\\"{x:1479,y:834,t:1527188979251};\\\", \\\"{x:1479,y:837,t:1527188979269};\\\", \\\"{x:1479,y:838,t:1527188979284};\\\", \\\"{x:1477,y:839,t:1527188979389};\\\", \\\"{x:1471,y:837,t:1527188979401};\\\", \\\"{x:1448,y:815,t:1527188979417};\\\", \\\"{x:1410,y:785,t:1527188979435};\\\", \\\"{x:1360,y:753,t:1527188979451};\\\", \\\"{x:1313,y:731,t:1527188979468};\\\", \\\"{x:1258,y:704,t:1527188979484};\\\", \\\"{x:1229,y:691,t:1527188979500};\\\", \\\"{x:1208,y:680,t:1527188979518};\\\", \\\"{x:1197,y:676,t:1527188979534};\\\", \\\"{x:1196,y:675,t:1527188979551};\\\", \\\"{x:1195,y:675,t:1527188979568};\\\", \\\"{x:1190,y:675,t:1527188979621};\\\", \\\"{x:1182,y:674,t:1527188979634};\\\", \\\"{x:1152,y:669,t:1527188979651};\\\", \\\"{x:1104,y:653,t:1527188979668};\\\", \\\"{x:990,y:624,t:1527188979684};\\\", \\\"{x:907,y:600,t:1527188979701};\\\", \\\"{x:827,y:577,t:1527188979719};\\\", \\\"{x:763,y:560,t:1527188979735};\\\", \\\"{x:694,y:544,t:1527188979751};\\\", \\\"{x:641,y:528,t:1527188979768};\\\", \\\"{x:608,y:521,t:1527188979784};\\\", \\\"{x:594,y:516,t:1527188979801};\\\", \\\"{x:593,y:516,t:1527188979817};\\\", \\\"{x:597,y:519,t:1527188979988};\\\", \\\"{x:605,y:526,t:1527188980000};\\\", \\\"{x:621,y:537,t:1527188980018};\\\", \\\"{x:636,y:545,t:1527188980034};\\\", \\\"{x:661,y:556,t:1527188980052};\\\", \\\"{x:676,y:562,t:1527188980067};\\\", \\\"{x:696,y:568,t:1527188980085};\\\", \\\"{x:720,y:576,t:1527188980101};\\\", \\\"{x:750,y:585,t:1527188980117};\\\", \\\"{x:787,y:591,t:1527188980134};\\\", \\\"{x:837,y:597,t:1527188980152};\\\", \\\"{x:900,y:601,t:1527188980167};\\\", \\\"{x:985,y:610,t:1527188980185};\\\", \\\"{x:1076,y:619,t:1527188980202};\\\", \\\"{x:1160,y:634,t:1527188980217};\\\", \\\"{x:1229,y:652,t:1527188980234};\\\", \\\"{x:1286,y:664,t:1527188980252};\\\", \\\"{x:1313,y:667,t:1527188980268};\\\", \\\"{x:1329,y:668,t:1527188980285};\\\", \\\"{x:1335,y:668,t:1527188980301};\\\", \\\"{x:1336,y:668,t:1527188980318};\\\", \\\"{x:1338,y:669,t:1527188980396};\\\", \\\"{x:1339,y:672,t:1527188980404};\\\", \\\"{x:1340,y:674,t:1527188980418};\\\", \\\"{x:1348,y:684,t:1527188980436};\\\", \\\"{x:1352,y:689,t:1527188980452};\\\", \\\"{x:1356,y:693,t:1527188980469};\\\", \\\"{x:1361,y:698,t:1527188980486};\\\", \\\"{x:1366,y:704,t:1527188980502};\\\", \\\"{x:1370,y:708,t:1527188980518};\\\", \\\"{x:1374,y:715,t:1527188980536};\\\", \\\"{x:1379,y:719,t:1527188980551};\\\", \\\"{x:1381,y:723,t:1527188980569};\\\", \\\"{x:1385,y:728,t:1527188980585};\\\", \\\"{x:1387,y:731,t:1527188980603};\\\", \\\"{x:1392,y:733,t:1527188980619};\\\", \\\"{x:1397,y:736,t:1527188980636};\\\", \\\"{x:1402,y:737,t:1527188980652};\\\", \\\"{x:1403,y:737,t:1527188980668};\\\", \\\"{x:1404,y:737,t:1527188980685};\\\", \\\"{x:1404,y:736,t:1527188980703};\\\", \\\"{x:1404,y:720,t:1527188980719};\\\", \\\"{x:1405,y:705,t:1527188980736};\\\", \\\"{x:1406,y:699,t:1527188980753};\\\", \\\"{x:1413,y:686,t:1527188980769};\\\", \\\"{x:1418,y:677,t:1527188980786};\\\", \\\"{x:1419,y:666,t:1527188980803};\\\", \\\"{x:1420,y:649,t:1527188980820};\\\", \\\"{x:1420,y:638,t:1527188980836};\\\", \\\"{x:1417,y:626,t:1527188980853};\\\", \\\"{x:1415,y:619,t:1527188980870};\\\", \\\"{x:1413,y:613,t:1527188980887};\\\", \\\"{x:1413,y:608,t:1527188980903};\\\", \\\"{x:1413,y:600,t:1527188980920};\\\", \\\"{x:1416,y:590,t:1527188980936};\\\", \\\"{x:1419,y:577,t:1527188980953};\\\", \\\"{x:1419,y:567,t:1527188980970};\\\", \\\"{x:1419,y:557,t:1527188980987};\\\", \\\"{x:1419,y:554,t:1527188981003};\\\", \\\"{x:1419,y:552,t:1527188981020};\\\", \\\"{x:1419,y:551,t:1527188981044};\\\", \\\"{x:1419,y:552,t:1527188981253};\\\", \\\"{x:1419,y:556,t:1527188981271};\\\", \\\"{x:1418,y:562,t:1527188981288};\\\", \\\"{x:1418,y:567,t:1527188981304};\\\", \\\"{x:1418,y:573,t:1527188981322};\\\", \\\"{x:1418,y:577,t:1527188981338};\\\", \\\"{x:1417,y:578,t:1527188981354};\\\", \\\"{x:1417,y:579,t:1527188982349};\\\", \\\"{x:1415,y:581,t:1527188982356};\\\", \\\"{x:1413,y:595,t:1527188982373};\\\", \\\"{x:1412,y:604,t:1527188982390};\\\", \\\"{x:1412,y:610,t:1527188982407};\\\", \\\"{x:1411,y:615,t:1527188982423};\\\", \\\"{x:1411,y:619,t:1527188982440};\\\", \\\"{x:1411,y:624,t:1527188982457};\\\", \\\"{x:1411,y:630,t:1527188982474};\\\", \\\"{x:1411,y:635,t:1527188982490};\\\", \\\"{x:1411,y:642,t:1527188982507};\\\", \\\"{x:1411,y:650,t:1527188982524};\\\", \\\"{x:1411,y:656,t:1527188982540};\\\", \\\"{x:1411,y:660,t:1527188982557};\\\", \\\"{x:1410,y:665,t:1527188982574};\\\", \\\"{x:1409,y:672,t:1527188982590};\\\", \\\"{x:1409,y:677,t:1527188982607};\\\", \\\"{x:1409,y:682,t:1527188982624};\\\", \\\"{x:1409,y:684,t:1527188982641};\\\", \\\"{x:1409,y:686,t:1527188982658};\\\", \\\"{x:1409,y:687,t:1527188982674};\\\", \\\"{x:1409,y:689,t:1527188982691};\\\", \\\"{x:1409,y:692,t:1527188982707};\\\", \\\"{x:1409,y:702,t:1527188982724};\\\", \\\"{x:1410,y:711,t:1527188982741};\\\", \\\"{x:1411,y:717,t:1527188982757};\\\", \\\"{x:1412,y:724,t:1527188982774};\\\", \\\"{x:1412,y:734,t:1527188982791};\\\", \\\"{x:1415,y:747,t:1527188982808};\\\", \\\"{x:1416,y:760,t:1527188982824};\\\", \\\"{x:1417,y:770,t:1527188982841};\\\", \\\"{x:1418,y:777,t:1527188982858};\\\", \\\"{x:1418,y:771,t:1527188982925};\\\", \\\"{x:1418,y:744,t:1527188982941};\\\", \\\"{x:1420,y:717,t:1527188982958};\\\", \\\"{x:1427,y:696,t:1527188982975};\\\", \\\"{x:1432,y:687,t:1527188982991};\\\", \\\"{x:1435,y:684,t:1527188983008};\\\", \\\"{x:1437,y:681,t:1527188983025};\\\", \\\"{x:1438,y:678,t:1527188983041};\\\", \\\"{x:1438,y:677,t:1527188983058};\\\", \\\"{x:1438,y:674,t:1527188983075};\\\", \\\"{x:1438,y:673,t:1527188983092};\\\", \\\"{x:1438,y:671,t:1527188983181};\\\", \\\"{x:1437,y:668,t:1527188983192};\\\", \\\"{x:1417,y:657,t:1527188983209};\\\", \\\"{x:1380,y:640,t:1527188983225};\\\", \\\"{x:1344,y:631,t:1527188983242};\\\", \\\"{x:1326,y:630,t:1527188983259};\\\", \\\"{x:1310,y:628,t:1527188983276};\\\", \\\"{x:1286,y:628,t:1527188983292};\\\", \\\"{x:1269,y:627,t:1527188983309};\\\", \\\"{x:1250,y:627,t:1527188983326};\\\", \\\"{x:1236,y:627,t:1527188983343};\\\", \\\"{x:1225,y:627,t:1527188983358};\\\", \\\"{x:1219,y:627,t:1527188983376};\\\", \\\"{x:1215,y:627,t:1527188983392};\\\", \\\"{x:1206,y:627,t:1527188983410};\\\", \\\"{x:1191,y:627,t:1527188983426};\\\", \\\"{x:1177,y:627,t:1527188983442};\\\", \\\"{x:1168,y:627,t:1527188983459};\\\", \\\"{x:1160,y:627,t:1527188983477};\\\", \\\"{x:1154,y:628,t:1527188983492};\\\", \\\"{x:1151,y:628,t:1527188983509};\\\", \\\"{x:1148,y:629,t:1527188983526};\\\", \\\"{x:1147,y:629,t:1527188983549};\\\", \\\"{x:1145,y:630,t:1527188983565};\\\", \\\"{x:1145,y:631,t:1527188983581};\\\", \\\"{x:1143,y:631,t:1527188983593};\\\", \\\"{x:1141,y:632,t:1527188983609};\\\", \\\"{x:1139,y:632,t:1527188983627};\\\", \\\"{x:1133,y:634,t:1527188983643};\\\", \\\"{x:1120,y:635,t:1527188983660};\\\", \\\"{x:1104,y:635,t:1527188983676};\\\", \\\"{x:1082,y:635,t:1527188983693};\\\", \\\"{x:1053,y:631,t:1527188983710};\\\", \\\"{x:1028,y:629,t:1527188983726};\\\", \\\"{x:997,y:629,t:1527188983743};\\\", \\\"{x:967,y:629,t:1527188983760};\\\", \\\"{x:936,y:629,t:1527188983778};\\\", \\\"{x:909,y:627,t:1527188983793};\\\", \\\"{x:884,y:622,t:1527188983805};\\\", \\\"{x:862,y:618,t:1527188983821};\\\", \\\"{x:845,y:612,t:1527188983837};\\\", \\\"{x:832,y:609,t:1527188983855};\\\", \\\"{x:828,y:608,t:1527188983871};\\\", \\\"{x:827,y:608,t:1527188983887};\\\", \\\"{x:824,y:606,t:1527188983904};\\\", \\\"{x:822,y:606,t:1527188983921};\\\", \\\"{x:817,y:603,t:1527188983937};\\\", \\\"{x:810,y:600,t:1527188983955};\\\", \\\"{x:805,y:598,t:1527188983970};\\\", \\\"{x:793,y:592,t:1527188983988};\\\", \\\"{x:776,y:584,t:1527188984005};\\\", \\\"{x:751,y:574,t:1527188984020};\\\", \\\"{x:721,y:565,t:1527188984038};\\\", \\\"{x:706,y:560,t:1527188984055};\\\", \\\"{x:695,y:555,t:1527188984071};\\\", \\\"{x:692,y:553,t:1527188984088};\\\", \\\"{x:687,y:552,t:1527188984105};\\\", \\\"{x:679,y:548,t:1527188984120};\\\", \\\"{x:666,y:544,t:1527188984138};\\\", \\\"{x:658,y:544,t:1527188984155};\\\", \\\"{x:647,y:544,t:1527188984170};\\\", \\\"{x:637,y:544,t:1527188984188};\\\", \\\"{x:629,y:545,t:1527188984205};\\\", \\\"{x:626,y:547,t:1527188984221};\\\", \\\"{x:618,y:551,t:1527188984238};\\\", \\\"{x:606,y:553,t:1527188984255};\\\", \\\"{x:597,y:558,t:1527188984272};\\\", \\\"{x:592,y:562,t:1527188984287};\\\", \\\"{x:591,y:564,t:1527188984304};\\\", \\\"{x:588,y:571,t:1527188984322};\\\", \\\"{x:585,y:575,t:1527188984338};\\\", \\\"{x:581,y:580,t:1527188984354};\\\", \\\"{x:575,y:583,t:1527188984371};\\\", \\\"{x:568,y:586,t:1527188984388};\\\", \\\"{x:563,y:586,t:1527188984404};\\\", \\\"{x:558,y:586,t:1527188984421};\\\", \\\"{x:549,y:586,t:1527188984437};\\\", \\\"{x:539,y:586,t:1527188984454};\\\", \\\"{x:520,y:586,t:1527188984472};\\\", \\\"{x:503,y:586,t:1527188984487};\\\", \\\"{x:479,y:586,t:1527188984506};\\\", \\\"{x:455,y:581,t:1527188984522};\\\", \\\"{x:432,y:577,t:1527188984537};\\\", \\\"{x:419,y:577,t:1527188984555};\\\", \\\"{x:414,y:577,t:1527188984573};\\\", \\\"{x:411,y:577,t:1527188984588};\\\", \\\"{x:408,y:577,t:1527188984604};\\\", \\\"{x:404,y:577,t:1527188984622};\\\", \\\"{x:403,y:577,t:1527188984637};\\\", \\\"{x:398,y:579,t:1527188984654};\\\", \\\"{x:396,y:581,t:1527188984672};\\\", \\\"{x:392,y:584,t:1527188984689};\\\", \\\"{x:386,y:586,t:1527188984705};\\\", \\\"{x:369,y:592,t:1527188984723};\\\", \\\"{x:342,y:597,t:1527188984739};\\\", \\\"{x:319,y:601,t:1527188984754};\\\", \\\"{x:288,y:603,t:1527188984771};\\\", \\\"{x:275,y:603,t:1527188984788};\\\", \\\"{x:257,y:601,t:1527188984806};\\\", \\\"{x:244,y:599,t:1527188984822};\\\", \\\"{x:235,y:598,t:1527188984837};\\\", \\\"{x:230,y:596,t:1527188984854};\\\", \\\"{x:229,y:596,t:1527188984872};\\\", \\\"{x:227,y:596,t:1527188984888};\\\", \\\"{x:225,y:596,t:1527188984905};\\\", \\\"{x:222,y:597,t:1527188984922};\\\", \\\"{x:220,y:599,t:1527188984937};\\\", \\\"{x:219,y:600,t:1527188984955};\\\", \\\"{x:218,y:600,t:1527188984971};\\\", \\\"{x:217,y:600,t:1527188985052};\\\", \\\"{x:216,y:600,t:1527188985059};\\\", \\\"{x:214,y:600,t:1527188985072};\\\", \\\"{x:207,y:600,t:1527188985088};\\\", \\\"{x:190,y:593,t:1527188985106};\\\", \\\"{x:164,y:580,t:1527188985121};\\\", \\\"{x:142,y:570,t:1527188985139};\\\", \\\"{x:126,y:561,t:1527188985156};\\\", \\\"{x:125,y:559,t:1527188985172};\\\", \\\"{x:124,y:559,t:1527188985188};\\\", \\\"{x:123,y:559,t:1527188985429};\\\", \\\"{x:126,y:559,t:1527188985445};\\\", \\\"{x:129,y:559,t:1527188985456};\\\", \\\"{x:133,y:561,t:1527188985472};\\\", \\\"{x:137,y:562,t:1527188985490};\\\", \\\"{x:139,y:563,t:1527188985509};\\\", \\\"{x:140,y:564,t:1527188985522};\\\", \\\"{x:143,y:566,t:1527188985539};\\\", \\\"{x:145,y:567,t:1527188985555};\\\", \\\"{x:147,y:570,t:1527188985573};\\\", \\\"{x:150,y:572,t:1527188985589};\\\", \\\"{x:152,y:575,t:1527188985605};\\\", \\\"{x:155,y:579,t:1527188985622};\\\", \\\"{x:156,y:579,t:1527188985639};\\\", \\\"{x:158,y:579,t:1527188988317};\\\", \\\"{x:162,y:581,t:1527188988324};\\\", \\\"{x:172,y:582,t:1527188988341};\\\", \\\"{x:178,y:584,t:1527188988357};\\\", \\\"{x:187,y:586,t:1527188988374};\\\", \\\"{x:192,y:588,t:1527188988391};\\\", \\\"{x:197,y:591,t:1527188988409};\\\", \\\"{x:205,y:595,t:1527188988424};\\\", \\\"{x:221,y:604,t:1527188988441};\\\", \\\"{x:237,y:612,t:1527188988458};\\\", \\\"{x:252,y:619,t:1527188988474};\\\", \\\"{x:266,y:625,t:1527188988490};\\\", \\\"{x:288,y:638,t:1527188988509};\\\", \\\"{x:297,y:644,t:1527188988525};\\\", \\\"{x:308,y:650,t:1527188988541};\\\", \\\"{x:314,y:655,t:1527188988557};\\\", \\\"{x:321,y:660,t:1527188988575};\\\", \\\"{x:326,y:663,t:1527188988590};\\\", \\\"{x:330,y:666,t:1527188988608};\\\", \\\"{x:336,y:671,t:1527188988625};\\\", \\\"{x:342,y:676,t:1527188988641};\\\", \\\"{x:350,y:683,t:1527188988657};\\\", \\\"{x:358,y:692,t:1527188988675};\\\", \\\"{x:371,y:705,t:1527188988691};\\\", \\\"{x:381,y:712,t:1527188988707};\\\", \\\"{x:392,y:720,t:1527188988724};\\\", \\\"{x:399,y:723,t:1527188988741};\\\", \\\"{x:406,y:725,t:1527188988757};\\\", \\\"{x:411,y:726,t:1527188988775};\\\", \\\"{x:416,y:726,t:1527188988791};\\\", \\\"{x:423,y:726,t:1527188988807};\\\", \\\"{x:432,y:726,t:1527188988825};\\\", \\\"{x:439,y:726,t:1527188988842};\\\", \\\"{x:443,y:728,t:1527188988858};\\\", \\\"{x:447,y:728,t:1527188988876};\\\", \\\"{x:453,y:727,t:1527188988891};\\\", \\\"{x:457,y:725,t:1527188988908};\\\", \\\"{x:462,y:724,t:1527188988925};\\\", \\\"{x:466,y:724,t:1527188988942};\\\", \\\"{x:467,y:724,t:1527188988958};\\\", \\\"{x:471,y:724,t:1527188988974};\\\", \\\"{x:474,y:724,t:1527188988992};\\\", \\\"{x:475,y:724,t:1527188989007};\\\", \\\"{x:477,y:724,t:1527188989025};\\\", \\\"{x:478,y:724,t:1527188989041};\\\", \\\"{x:479,y:724,t:1527188989099};\\\", \\\"{x:480,y:724,t:1527188989108};\\\", \\\"{x:480,y:721,t:1527188989396};\\\", \\\"{x:478,y:715,t:1527188989409};\\\", \\\"{x:476,y:708,t:1527188989424};\\\", \\\"{x:473,y:703,t:1527188989442};\\\", \\\"{x:468,y:696,t:1527188989458};\\\", \\\"{x:460,y:686,t:1527188989475};\\\", \\\"{x:440,y:660,t:1527188989492};\\\", \\\"{x:423,y:639,t:1527188989509};\\\", \\\"{x:394,y:605,t:1527188989524};\\\", \\\"{x:360,y:564,t:1527188989542};\\\", \\\"{x:328,y:528,t:1527188989559};\\\", \\\"{x:303,y:500,t:1527188989576};\\\", \\\"{x:287,y:481,t:1527188989592};\\\", \\\"{x:274,y:464,t:1527188989608};\\\", \\\"{x:262,y:451,t:1527188989625};\\\", \\\"{x:254,y:443,t:1527188989642};\\\", \\\"{x:250,y:438,t:1527188989658};\\\", \\\"{x:247,y:433,t:1527188989676};\\\" ] }, { \\\"rt\\\": 40289, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 410987, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:246,y:432,t:1527188990643};\\\", \\\"{x:246,y:426,t:1527188992237};\\\", \\\"{x:246,y:421,t:1527188992244};\\\", \\\"{x:246,y:408,t:1527188992261};\\\", \\\"{x:246,y:393,t:1527188992278};\\\", \\\"{x:246,y:386,t:1527188992294};\\\", \\\"{x:246,y:383,t:1527188992311};\\\", \\\"{x:246,y:381,t:1527188992328};\\\", \\\"{x:246,y:378,t:1527188992344};\\\", \\\"{x:246,y:376,t:1527188992388};\\\", \\\"{x:246,y:374,t:1527188992469};\\\", \\\"{x:246,y:371,t:1527188992478};\\\", \\\"{x:247,y:366,t:1527188992495};\\\", \\\"{x:249,y:359,t:1527188992512};\\\", \\\"{x:252,y:354,t:1527188992529};\\\", \\\"{x:255,y:348,t:1527188992545};\\\", \\\"{x:257,y:342,t:1527188992561};\\\", \\\"{x:259,y:337,t:1527188992579};\\\", \\\"{x:263,y:327,t:1527188992594};\\\", \\\"{x:264,y:319,t:1527188992612};\\\", \\\"{x:268,y:314,t:1527188992628};\\\", \\\"{x:268,y:313,t:1527188993404};\\\", \\\"{x:272,y:313,t:1527188993420};\\\", \\\"{x:276,y:313,t:1527188993428};\\\", \\\"{x:290,y:318,t:1527188993445};\\\", \\\"{x:305,y:326,t:1527188993462};\\\", \\\"{x:322,y:332,t:1527188993478};\\\", \\\"{x:341,y:342,t:1527188993495};\\\", \\\"{x:360,y:350,t:1527188993513};\\\", \\\"{x:372,y:357,t:1527188993528};\\\", \\\"{x:388,y:364,t:1527188993546};\\\", \\\"{x:397,y:368,t:1527188993562};\\\", \\\"{x:405,y:370,t:1527188993579};\\\", \\\"{x:410,y:373,t:1527188993596};\\\", \\\"{x:417,y:376,t:1527188993612};\\\", \\\"{x:420,y:377,t:1527188993629};\\\", \\\"{x:423,y:378,t:1527188993646};\\\", \\\"{x:423,y:379,t:1527188996309};\\\", \\\"{x:428,y:379,t:1527188997453};\\\", \\\"{x:449,y:379,t:1527188997466};\\\", \\\"{x:533,y:398,t:1527188997482};\\\", \\\"{x:633,y:424,t:1527188997499};\\\", \\\"{x:743,y:454,t:1527188997516};\\\", \\\"{x:837,y:480,t:1527188997532};\\\", \\\"{x:920,y:499,t:1527188997550};\\\", \\\"{x:959,y:512,t:1527188997566};\\\", \\\"{x:980,y:522,t:1527188997582};\\\", \\\"{x:1019,y:537,t:1527188997598};\\\", \\\"{x:1061,y:555,t:1527188997615};\\\", \\\"{x:1115,y:575,t:1527188997632};\\\", \\\"{x:1192,y:595,t:1527188997649};\\\", \\\"{x:1300,y:623,t:1527188997665};\\\", \\\"{x:1415,y:648,t:1527188997682};\\\", \\\"{x:1515,y:678,t:1527188997699};\\\", \\\"{x:1641,y:722,t:1527188997715};\\\", \\\"{x:1691,y:744,t:1527188997732};\\\", \\\"{x:1733,y:764,t:1527188997748};\\\", \\\"{x:1755,y:768,t:1527188997765};\\\", \\\"{x:1757,y:768,t:1527188997782};\\\", \\\"{x:1757,y:769,t:1527188997803};\\\", \\\"{x:1754,y:771,t:1527188997816};\\\", \\\"{x:1745,y:773,t:1527188997832};\\\", \\\"{x:1737,y:777,t:1527188997849};\\\", \\\"{x:1730,y:777,t:1527188997866};\\\", \\\"{x:1718,y:755,t:1527188997882};\\\", \\\"{x:1717,y:755,t:1527188997900};\\\", \\\"{x:1715,y:755,t:1527189001101};\\\", \\\"{x:1709,y:754,t:1527189001119};\\\", \\\"{x:1701,y:754,t:1527189001135};\\\", \\\"{x:1694,y:753,t:1527189001152};\\\", \\\"{x:1689,y:753,t:1527189001169};\\\", \\\"{x:1681,y:753,t:1527189001185};\\\", \\\"{x:1672,y:753,t:1527189001201};\\\", \\\"{x:1664,y:753,t:1527189001219};\\\", \\\"{x:1653,y:753,t:1527189001235};\\\", \\\"{x:1648,y:753,t:1527189001253};\\\", \\\"{x:1637,y:753,t:1527189001268};\\\", \\\"{x:1633,y:753,t:1527189001285};\\\", \\\"{x:1627,y:753,t:1527189001302};\\\", \\\"{x:1620,y:753,t:1527189001319};\\\", \\\"{x:1613,y:753,t:1527189001335};\\\", \\\"{x:1604,y:753,t:1527189001352};\\\", \\\"{x:1596,y:753,t:1527189001369};\\\", \\\"{x:1587,y:753,t:1527189001386};\\\", \\\"{x:1579,y:753,t:1527189001402};\\\", \\\"{x:1565,y:753,t:1527189001419};\\\", \\\"{x:1543,y:753,t:1527189001436};\\\", \\\"{x:1524,y:753,t:1527189001452};\\\", \\\"{x:1502,y:754,t:1527189001469};\\\", \\\"{x:1477,y:757,t:1527189001486};\\\", \\\"{x:1452,y:760,t:1527189001502};\\\", \\\"{x:1431,y:760,t:1527189001519};\\\", \\\"{x:1408,y:760,t:1527189001536};\\\", \\\"{x:1386,y:761,t:1527189001552};\\\", \\\"{x:1363,y:761,t:1527189001569};\\\", \\\"{x:1346,y:761,t:1527189001589};\\\", \\\"{x:1335,y:761,t:1527189001602};\\\", \\\"{x:1329,y:763,t:1527189001618};\\\", \\\"{x:1324,y:763,t:1527189001635};\\\", \\\"{x:1322,y:764,t:1527189001651};\\\", \\\"{x:1320,y:764,t:1527189001668};\\\", \\\"{x:1319,y:764,t:1527189001686};\\\", \\\"{x:1317,y:766,t:1527189001703};\\\", \\\"{x:1316,y:766,t:1527189001718};\\\", \\\"{x:1314,y:767,t:1527189001735};\\\", \\\"{x:1313,y:768,t:1527189001753};\\\", \\\"{x:1311,y:768,t:1527189001788};\\\", \\\"{x:1310,y:769,t:1527189001884};\\\", \\\"{x:1307,y:771,t:1527189002004};\\\", \\\"{x:1302,y:775,t:1527189002019};\\\", \\\"{x:1274,y:791,t:1527189002036};\\\", \\\"{x:1245,y:806,t:1527189002052};\\\", \\\"{x:1218,y:824,t:1527189002069};\\\", \\\"{x:1187,y:844,t:1527189002086};\\\", \\\"{x:1165,y:860,t:1527189002104};\\\", \\\"{x:1146,y:870,t:1527189002119};\\\", \\\"{x:1137,y:872,t:1527189002136};\\\", \\\"{x:1134,y:875,t:1527189002153};\\\", \\\"{x:1133,y:875,t:1527189002203};\\\", \\\"{x:1132,y:874,t:1527189002493};\\\", \\\"{x:1132,y:871,t:1527189002503};\\\", \\\"{x:1131,y:868,t:1527189002520};\\\", \\\"{x:1131,y:865,t:1527189002536};\\\", \\\"{x:1131,y:864,t:1527189002553};\\\", \\\"{x:1131,y:863,t:1527189002604};\\\", \\\"{x:1130,y:863,t:1527189002620};\\\", \\\"{x:1131,y:858,t:1527189003925};\\\", \\\"{x:1133,y:852,t:1527189003937};\\\", \\\"{x:1137,y:845,t:1527189003954};\\\", \\\"{x:1140,y:839,t:1527189003970};\\\", \\\"{x:1144,y:830,t:1527189003987};\\\", \\\"{x:1148,y:823,t:1527189004004};\\\", \\\"{x:1151,y:819,t:1527189004021};\\\", \\\"{x:1155,y:814,t:1527189004037};\\\", \\\"{x:1155,y:813,t:1527189004054};\\\", \\\"{x:1158,y:809,t:1527189004070};\\\", \\\"{x:1159,y:807,t:1527189004087};\\\", \\\"{x:1159,y:805,t:1527189004103};\\\", \\\"{x:1162,y:802,t:1527189004121};\\\", \\\"{x:1164,y:800,t:1527189004138};\\\", \\\"{x:1166,y:799,t:1527189004154};\\\", \\\"{x:1168,y:797,t:1527189004171};\\\", \\\"{x:1169,y:795,t:1527189004188};\\\", \\\"{x:1170,y:792,t:1527189004204};\\\", \\\"{x:1171,y:790,t:1527189004220};\\\", \\\"{x:1172,y:788,t:1527189004238};\\\", \\\"{x:1173,y:786,t:1527189004253};\\\", \\\"{x:1174,y:783,t:1527189004270};\\\", \\\"{x:1176,y:781,t:1527189004287};\\\", \\\"{x:1177,y:779,t:1527189004304};\\\", \\\"{x:1178,y:778,t:1527189004321};\\\", \\\"{x:1179,y:776,t:1527189004337};\\\", \\\"{x:1179,y:775,t:1527189004354};\\\", \\\"{x:1181,y:773,t:1527189004370};\\\", \\\"{x:1182,y:767,t:1527189004388};\\\", \\\"{x:1183,y:765,t:1527189004403};\\\", \\\"{x:1183,y:763,t:1527189004421};\\\", \\\"{x:1184,y:762,t:1527189004437};\\\", \\\"{x:1184,y:761,t:1527189004454};\\\", \\\"{x:1184,y:760,t:1527189004471};\\\", \\\"{x:1184,y:759,t:1527189004516};\\\", \\\"{x:1175,y:752,t:1527189028588};\\\", \\\"{x:1150,y:749,t:1527189028595};\\\", \\\"{x:1120,y:742,t:1527189028606};\\\", \\\"{x:1048,y:722,t:1527189028623};\\\", \\\"{x:962,y:697,t:1527189028640};\\\", \\\"{x:862,y:670,t:1527189028656};\\\", \\\"{x:745,y:627,t:1527189028674};\\\", \\\"{x:620,y:589,t:1527189028690};\\\", \\\"{x:493,y:538,t:1527189028703};\\\", \\\"{x:387,y:497,t:1527189028719};\\\", \\\"{x:345,y:476,t:1527189028736};\\\", \\\"{x:341,y:474,t:1527189028757};\\\", \\\"{x:339,y:473,t:1527189028827};\\\", \\\"{x:333,y:471,t:1527189028840};\\\", \\\"{x:312,y:466,t:1527189028857};\\\", \\\"{x:260,y:453,t:1527189028874};\\\", \\\"{x:184,y:440,t:1527189028891};\\\", \\\"{x:43,y:399,t:1527189028907};\\\", \\\"{x:0,y:369,t:1527189028924};\\\", \\\"{x:0,y:347,t:1527189028941};\\\", \\\"{x:0,y:336,t:1527189028957};\\\", \\\"{x:0,y:334,t:1527189028973};\\\", \\\"{x:0,y:333,t:1527189028995};\\\", \\\"{x:1,y:333,t:1527189029059};\\\", \\\"{x:4,y:334,t:1527189029074};\\\", \\\"{x:10,y:336,t:1527189029091};\\\", \\\"{x:23,y:342,t:1527189029107};\\\", \\\"{x:35,y:347,t:1527189029124};\\\", \\\"{x:49,y:354,t:1527189029140};\\\", \\\"{x:61,y:359,t:1527189029158};\\\", \\\"{x:68,y:362,t:1527189029174};\\\", \\\"{x:70,y:363,t:1527189029191};\\\", \\\"{x:74,y:364,t:1527189029207};\\\", \\\"{x:78,y:368,t:1527189029225};\\\", \\\"{x:81,y:371,t:1527189029240};\\\", \\\"{x:87,y:376,t:1527189029258};\\\", \\\"{x:90,y:378,t:1527189029275};\\\", \\\"{x:90,y:380,t:1527189029290};\\\", \\\"{x:90,y:385,t:1527189029308};\\\", \\\"{x:91,y:397,t:1527189029324};\\\", \\\"{x:94,y:415,t:1527189029341};\\\", \\\"{x:95,y:432,t:1527189029357};\\\", \\\"{x:96,y:440,t:1527189029374};\\\", \\\"{x:96,y:447,t:1527189029391};\\\", \\\"{x:97,y:455,t:1527189029407};\\\", \\\"{x:98,y:460,t:1527189029424};\\\", \\\"{x:100,y:468,t:1527189029440};\\\", \\\"{x:103,y:477,t:1527189029458};\\\", \\\"{x:107,y:488,t:1527189029475};\\\", \\\"{x:108,y:491,t:1527189029490};\\\", \\\"{x:109,y:494,t:1527189029506};\\\", \\\"{x:109,y:495,t:1527189029539};\\\", \\\"{x:109,y:496,t:1527189029547};\\\", \\\"{x:110,y:498,t:1527189029563};\\\", \\\"{x:112,y:499,t:1527189029573};\\\", \\\"{x:118,y:502,t:1527189029590};\\\", \\\"{x:121,y:503,t:1527189029607};\\\", \\\"{x:122,y:503,t:1527189029624};\\\", \\\"{x:124,y:503,t:1527189029640};\\\", \\\"{x:125,y:503,t:1527189029667};\\\", \\\"{x:126,y:503,t:1527189029675};\\\", \\\"{x:128,y:503,t:1527189029690};\\\", \\\"{x:129,y:503,t:1527189029706};\\\", \\\"{x:133,y:502,t:1527189029723};\\\", \\\"{x:134,y:502,t:1527189029740};\\\", \\\"{x:135,y:501,t:1527189029757};\\\", \\\"{x:136,y:501,t:1527189029774};\\\", \\\"{x:140,y:500,t:1527189029789};\\\", \\\"{x:145,y:497,t:1527189029806};\\\", \\\"{x:149,y:496,t:1527189029824};\\\", \\\"{x:151,y:495,t:1527189029840};\\\", \\\"{x:153,y:493,t:1527189029857};\\\", \\\"{x:156,y:493,t:1527189030107};\\\", \\\"{x:173,y:502,t:1527189030124};\\\", \\\"{x:196,y:518,t:1527189030142};\\\", \\\"{x:220,y:532,t:1527189030158};\\\", \\\"{x:236,y:541,t:1527189030175};\\\", \\\"{x:252,y:548,t:1527189030191};\\\", \\\"{x:264,y:554,t:1527189030209};\\\", \\\"{x:273,y:561,t:1527189030224};\\\", \\\"{x:285,y:568,t:1527189030242};\\\", \\\"{x:295,y:577,t:1527189030258};\\\", \\\"{x:310,y:588,t:1527189030275};\\\", \\\"{x:348,y:615,t:1527189030292};\\\", \\\"{x:383,y:637,t:1527189030309};\\\", \\\"{x:412,y:651,t:1527189030326};\\\", \\\"{x:437,y:663,t:1527189030342};\\\", \\\"{x:458,y:673,t:1527189030359};\\\", \\\"{x:473,y:679,t:1527189030374};\\\", \\\"{x:495,y:691,t:1527189030391};\\\", \\\"{x:518,y:703,t:1527189030409};\\\", \\\"{x:537,y:714,t:1527189030425};\\\", \\\"{x:549,y:719,t:1527189030441};\\\", \\\"{x:553,y:722,t:1527189030459};\\\", \\\"{x:555,y:722,t:1527189030475};\\\", \\\"{x:555,y:723,t:1527189030515};\\\", \\\"{x:557,y:727,t:1527189030525};\\\", \\\"{x:559,y:736,t:1527189030541};\\\", \\\"{x:559,y:743,t:1527189030559};\\\", \\\"{x:559,y:746,t:1527189030576};\\\", \\\"{x:561,y:748,t:1527189030591};\\\", \\\"{x:556,y:745,t:1527189031395};\\\", \\\"{x:547,y:739,t:1527189031410};\\\", \\\"{x:535,y:732,t:1527189031425};\\\", \\\"{x:523,y:723,t:1527189031442};\\\", \\\"{x:505,y:711,t:1527189031460};\\\", \\\"{x:498,y:705,t:1527189031477};\\\", \\\"{x:491,y:700,t:1527189031493};\\\", \\\"{x:485,y:696,t:1527189031509};\\\", \\\"{x:480,y:692,t:1527189031526};\\\", \\\"{x:472,y:686,t:1527189031542};\\\", \\\"{x:467,y:682,t:1527189031560};\\\", \\\"{x:457,y:677,t:1527189031577};\\\", \\\"{x:445,y:670,t:1527189031593};\\\", \\\"{x:433,y:664,t:1527189031610};\\\", \\\"{x:422,y:658,t:1527189031627};\\\", \\\"{x:413,y:652,t:1527189031642};\\\", \\\"{x:404,y:647,t:1527189031659};\\\", \\\"{x:401,y:646,t:1527189031677};\\\", \\\"{x:399,y:645,t:1527189031693};\\\", \\\"{x:398,y:645,t:1527189031709};\\\", \\\"{x:397,y:645,t:1527189031726};\\\", \\\"{x:396,y:644,t:1527189031755};\\\", \\\"{x:395,y:643,t:1527189031803};\\\" ] }, { \\\"rt\\\": 8598, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 420823, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:395,y:642,t:1527189032266};\\\", \\\"{x:410,y:645,t:1527189033795};\\\", \\\"{x:459,y:654,t:1527189033803};\\\", \\\"{x:517,y:665,t:1527189033814};\\\", \\\"{x:837,y:751,t:1527189033845};\\\", \\\"{x:1021,y:792,t:1527189033861};\\\", \\\"{x:1202,y:837,t:1527189033878};\\\", \\\"{x:1383,y:869,t:1527189033894};\\\", \\\"{x:1535,y:891,t:1527189033911};\\\", \\\"{x:1646,y:909,t:1527189033927};\\\", \\\"{x:1695,y:912,t:1527189033945};\\\", \\\"{x:1711,y:915,t:1527189033962};\\\", \\\"{x:1713,y:915,t:1527189033978};\\\", \\\"{x:1714,y:912,t:1527189034044};\\\", \\\"{x:1713,y:908,t:1527189034051};\\\", \\\"{x:1709,y:898,t:1527189034063};\\\", \\\"{x:1704,y:881,t:1527189034080};\\\", \\\"{x:1689,y:856,t:1527189034095};\\\", \\\"{x:1672,y:831,t:1527189034112};\\\", \\\"{x:1653,y:808,t:1527189034128};\\\", \\\"{x:1635,y:791,t:1527189034145};\\\", \\\"{x:1617,y:777,t:1527189034162};\\\", \\\"{x:1592,y:756,t:1527189034179};\\\", \\\"{x:1575,y:744,t:1527189034195};\\\", \\\"{x:1560,y:734,t:1527189034212};\\\", \\\"{x:1547,y:726,t:1527189034229};\\\", \\\"{x:1531,y:720,t:1527189034245};\\\", \\\"{x:1514,y:712,t:1527189034262};\\\", \\\"{x:1500,y:708,t:1527189034279};\\\", \\\"{x:1495,y:706,t:1527189034296};\\\", \\\"{x:1491,y:705,t:1527189034312};\\\", \\\"{x:1489,y:704,t:1527189034329};\\\", \\\"{x:1488,y:702,t:1527189034436};\\\", \\\"{x:1486,y:699,t:1527189034446};\\\", \\\"{x:1478,y:691,t:1527189034462};\\\", \\\"{x:1465,y:683,t:1527189034480};\\\", \\\"{x:1447,y:675,t:1527189034496};\\\", \\\"{x:1419,y:666,t:1527189034512};\\\", \\\"{x:1396,y:660,t:1527189034530};\\\", \\\"{x:1380,y:658,t:1527189034547};\\\", \\\"{x:1373,y:658,t:1527189034562};\\\", \\\"{x:1368,y:658,t:1527189034580};\\\", \\\"{x:1365,y:659,t:1527189034596};\\\", \\\"{x:1364,y:661,t:1527189034613};\\\", \\\"{x:1364,y:665,t:1527189034629};\\\", \\\"{x:1365,y:671,t:1527189034647};\\\", \\\"{x:1370,y:674,t:1527189034663};\\\", \\\"{x:1377,y:676,t:1527189034679};\\\", \\\"{x:1380,y:677,t:1527189034697};\\\", \\\"{x:1384,y:678,t:1527189034713};\\\", \\\"{x:1391,y:679,t:1527189034730};\\\", \\\"{x:1396,y:679,t:1527189034747};\\\", \\\"{x:1405,y:679,t:1527189034763};\\\", \\\"{x:1406,y:679,t:1527189034779};\\\", \\\"{x:1406,y:678,t:1527189034804};\\\", \\\"{x:1404,y:678,t:1527189035044};\\\", \\\"{x:1398,y:678,t:1527189035052};\\\", \\\"{x:1394,y:678,t:1527189035063};\\\", \\\"{x:1385,y:677,t:1527189035081};\\\", \\\"{x:1381,y:676,t:1527189035097};\\\", \\\"{x:1380,y:676,t:1527189035113};\\\", \\\"{x:1379,y:676,t:1527189035211};\\\", \\\"{x:1378,y:676,t:1527189035219};\\\", \\\"{x:1377,y:676,t:1527189035230};\\\", \\\"{x:1372,y:678,t:1527189035247};\\\", \\\"{x:1367,y:683,t:1527189035263};\\\", \\\"{x:1362,y:690,t:1527189035280};\\\", \\\"{x:1357,y:696,t:1527189035297};\\\", \\\"{x:1352,y:700,t:1527189035314};\\\", \\\"{x:1348,y:705,t:1527189035331};\\\", \\\"{x:1342,y:709,t:1527189035347};\\\", \\\"{x:1339,y:712,t:1527189035363};\\\", \\\"{x:1335,y:713,t:1527189035380};\\\", \\\"{x:1334,y:714,t:1527189035397};\\\", \\\"{x:1334,y:715,t:1527189035420};\\\", \\\"{x:1333,y:715,t:1527189035843};\\\", \\\"{x:1333,y:714,t:1527189035891};\\\", \\\"{x:1334,y:712,t:1527189035907};\\\", \\\"{x:1336,y:709,t:1527189035915};\\\", \\\"{x:1336,y:708,t:1527189035931};\\\", \\\"{x:1337,y:706,t:1527189035947};\\\", \\\"{x:1339,y:704,t:1527189035979};\\\", \\\"{x:1340,y:704,t:1527189036004};\\\", \\\"{x:1341,y:704,t:1527189036027};\\\", \\\"{x:1342,y:704,t:1527189036051};\\\", \\\"{x:1343,y:704,t:1527189036085};\\\", \\\"{x:1343,y:705,t:1527189036581};\\\", \\\"{x:1343,y:706,t:1527189036587};\\\", \\\"{x:1343,y:708,t:1527189036603};\\\", \\\"{x:1343,y:710,t:1527189036652};\\\", \\\"{x:1343,y:711,t:1527189036860};\\\", \\\"{x:1343,y:714,t:1527189036868};\\\", \\\"{x:1343,y:717,t:1527189036883};\\\", \\\"{x:1346,y:725,t:1527189036900};\\\", \\\"{x:1347,y:733,t:1527189036916};\\\", \\\"{x:1350,y:740,t:1527189036933};\\\", \\\"{x:1350,y:747,t:1527189036949};\\\", \\\"{x:1351,y:750,t:1527189036966};\\\", \\\"{x:1351,y:751,t:1527189036982};\\\", \\\"{x:1351,y:752,t:1527189037067};\\\", \\\"{x:1351,y:753,t:1527189037082};\\\", \\\"{x:1350,y:755,t:1527189037301};\\\", \\\"{x:1350,y:756,t:1527189037316};\\\", \\\"{x:1349,y:757,t:1527189037333};\\\", \\\"{x:1349,y:759,t:1527189038037};\\\", \\\"{x:1347,y:761,t:1527189038050};\\\", \\\"{x:1343,y:768,t:1527189038069};\\\", \\\"{x:1342,y:769,t:1527189038084};\\\", \\\"{x:1341,y:770,t:1527189038101};\\\", \\\"{x:1341,y:771,t:1527189038118};\\\", \\\"{x:1339,y:771,t:1527189038228};\\\", \\\"{x:1333,y:771,t:1527189038236};\\\", \\\"{x:1320,y:765,t:1527189038251};\\\", \\\"{x:1264,y:729,t:1527189038268};\\\", \\\"{x:1205,y:698,t:1527189038284};\\\", \\\"{x:1136,y:669,t:1527189038301};\\\", \\\"{x:1054,y:637,t:1527189038318};\\\", \\\"{x:976,y:613,t:1527189038335};\\\", \\\"{x:899,y:581,t:1527189038352};\\\", \\\"{x:826,y:555,t:1527189038368};\\\", \\\"{x:754,y:524,t:1527189038384};\\\", \\\"{x:666,y:491,t:1527189038408};\\\", \\\"{x:639,y:486,t:1527189038426};\\\", \\\"{x:612,y:482,t:1527189038449};\\\", \\\"{x:599,y:480,t:1527189038465};\\\", \\\"{x:595,y:480,t:1527189038482};\\\", \\\"{x:594,y:480,t:1527189038499};\\\", \\\"{x:591,y:480,t:1527189038547};\\\", \\\"{x:586,y:480,t:1527189038555};\\\", \\\"{x:578,y:480,t:1527189038566};\\\", \\\"{x:559,y:482,t:1527189038582};\\\", \\\"{x:540,y:486,t:1527189038599};\\\", \\\"{x:525,y:488,t:1527189038617};\\\", \\\"{x:513,y:492,t:1527189038632};\\\", \\\"{x:496,y:496,t:1527189038649};\\\", \\\"{x:478,y:500,t:1527189038665};\\\", \\\"{x:460,y:504,t:1527189038682};\\\", \\\"{x:440,y:509,t:1527189038699};\\\", \\\"{x:430,y:512,t:1527189038714};\\\", \\\"{x:425,y:514,t:1527189038732};\\\", \\\"{x:420,y:516,t:1527189038749};\\\", \\\"{x:412,y:519,t:1527189038766};\\\", \\\"{x:400,y:522,t:1527189038783};\\\", \\\"{x:386,y:526,t:1527189038800};\\\", \\\"{x:370,y:530,t:1527189038816};\\\", \\\"{x:354,y:534,t:1527189038832};\\\", \\\"{x:340,y:536,t:1527189038849};\\\", \\\"{x:330,y:537,t:1527189038866};\\\", \\\"{x:321,y:541,t:1527189038882};\\\", \\\"{x:311,y:545,t:1527189038899};\\\", \\\"{x:302,y:549,t:1527189038915};\\\", \\\"{x:294,y:553,t:1527189038932};\\\", \\\"{x:286,y:555,t:1527189038949};\\\", \\\"{x:272,y:559,t:1527189038967};\\\", \\\"{x:252,y:566,t:1527189038983};\\\", \\\"{x:225,y:578,t:1527189038999};\\\", \\\"{x:188,y:589,t:1527189039016};\\\", \\\"{x:130,y:605,t:1527189039032};\\\", \\\"{x:69,y:622,t:1527189039049};\\\", \\\"{x:16,y:635,t:1527189039065};\\\", \\\"{x:0,y:643,t:1527189039082};\\\", \\\"{x:0,y:645,t:1527189039099};\\\", \\\"{x:0,y:643,t:1527189039163};\\\", \\\"{x:0,y:640,t:1527189039171};\\\", \\\"{x:0,y:637,t:1527189039187};\\\", \\\"{x:2,y:636,t:1527189039199};\\\", \\\"{x:6,y:631,t:1527189039216};\\\", \\\"{x:12,y:627,t:1527189039232};\\\", \\\"{x:18,y:623,t:1527189039249};\\\", \\\"{x:25,y:618,t:1527189039276};\\\", \\\"{x:32,y:614,t:1527189039292};\\\", \\\"{x:47,y:605,t:1527189039309};\\\", \\\"{x:62,y:599,t:1527189039326};\\\", \\\"{x:74,y:592,t:1527189039343};\\\", \\\"{x:85,y:588,t:1527189039359};\\\", \\\"{x:93,y:584,t:1527189039376};\\\", \\\"{x:99,y:582,t:1527189039393};\\\", \\\"{x:106,y:578,t:1527189039409};\\\", \\\"{x:117,y:574,t:1527189039426};\\\", \\\"{x:126,y:569,t:1527189039443};\\\", \\\"{x:131,y:566,t:1527189039459};\\\", \\\"{x:133,y:565,t:1527189039476};\\\", \\\"{x:134,y:564,t:1527189039493};\\\", \\\"{x:135,y:564,t:1527189039534};\\\", \\\"{x:135,y:562,t:1527189039615};\\\", \\\"{x:136,y:562,t:1527189039626};\\\", \\\"{x:138,y:560,t:1527189039643};\\\", \\\"{x:143,y:557,t:1527189039659};\\\", \\\"{x:152,y:552,t:1527189039676};\\\", \\\"{x:161,y:549,t:1527189039693};\\\", \\\"{x:166,y:545,t:1527189039709};\\\", \\\"{x:167,y:545,t:1527189039726};\\\", \\\"{x:168,y:545,t:1527189039743};\\\", \\\"{x:169,y:544,t:1527189039758};\\\", \\\"{x:171,y:544,t:1527189039776};\\\", \\\"{x:179,y:544,t:1527189040141};\\\", \\\"{x:190,y:547,t:1527189040149};\\\", \\\"{x:203,y:553,t:1527189040160};\\\", \\\"{x:232,y:566,t:1527189040178};\\\", \\\"{x:270,y:588,t:1527189040193};\\\", \\\"{x:305,y:606,t:1527189040211};\\\", \\\"{x:337,y:623,t:1527189040227};\\\", \\\"{x:375,y:646,t:1527189040244};\\\", \\\"{x:407,y:665,t:1527189040260};\\\", \\\"{x:439,y:682,t:1527189040278};\\\", \\\"{x:456,y:692,t:1527189040293};\\\", \\\"{x:462,y:695,t:1527189040310};\\\", \\\"{x:463,y:695,t:1527189040326};\\\", \\\"{x:464,y:696,t:1527189040357};\\\", \\\"{x:464,y:698,t:1527189040373};\\\", \\\"{x:464,y:699,t:1527189040381};\\\", \\\"{x:465,y:702,t:1527189040393};\\\", \\\"{x:470,y:707,t:1527189040410};\\\", \\\"{x:472,y:711,t:1527189040426};\\\", \\\"{x:474,y:716,t:1527189040443};\\\", \\\"{x:478,y:720,t:1527189040461};\\\", \\\"{x:478,y:721,t:1527189040476};\\\", \\\"{x:480,y:724,t:1527189040493};\\\", \\\"{x:484,y:727,t:1527189040511};\\\", \\\"{x:488,y:732,t:1527189040527};\\\", \\\"{x:491,y:734,t:1527189040544};\\\", \\\"{x:493,y:736,t:1527189040560};\\\", \\\"{x:494,y:736,t:1527189040577};\\\", \\\"{x:495,y:737,t:1527189040594};\\\", \\\"{x:496,y:738,t:1527189040611};\\\", \\\"{x:498,y:740,t:1527189040627};\\\", \\\"{x:507,y:740,t:1527189040989};\\\", \\\"{x:527,y:740,t:1527189040997};\\\", \\\"{x:563,y:734,t:1527189041011};\\\", \\\"{x:651,y:725,t:1527189041027};\\\", \\\"{x:748,y:711,t:1527189041045};\\\", \\\"{x:875,y:692,t:1527189041061};\\\", \\\"{x:939,y:684,t:1527189041077};\\\", \\\"{x:975,y:680,t:1527189041094};\\\", \\\"{x:998,y:679,t:1527189041110};\\\", \\\"{x:1013,y:679,t:1527189041127};\\\", \\\"{x:1017,y:679,t:1527189041144};\\\" ] }, { \\\"rt\\\": 10569, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 432643, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1028,y:686,t:1527189045062};\\\", \\\"{x:1077,y:729,t:1527189045081};\\\", \\\"{x:1135,y:764,t:1527189045098};\\\", \\\"{x:1183,y:790,t:1527189045114};\\\", \\\"{x:1236,y:813,t:1527189045131};\\\", \\\"{x:1302,y:841,t:1527189045148};\\\", \\\"{x:1376,y:869,t:1527189045164};\\\", \\\"{x:1442,y:888,t:1527189045181};\\\", \\\"{x:1513,y:912,t:1527189045198};\\\", \\\"{x:1533,y:920,t:1527189045214};\\\", \\\"{x:1538,y:922,t:1527189045231};\\\", \\\"{x:1539,y:922,t:1527189045294};\\\", \\\"{x:1539,y:924,t:1527189045318};\\\", \\\"{x:1538,y:925,t:1527189045330};\\\", \\\"{x:1533,y:928,t:1527189045348};\\\", \\\"{x:1527,y:938,t:1527189045364};\\\", \\\"{x:1514,y:957,t:1527189045381};\\\", \\\"{x:1481,y:996,t:1527189045398};\\\", \\\"{x:1452,y:1019,t:1527189045414};\\\", \\\"{x:1422,y:1037,t:1527189045432};\\\", \\\"{x:1401,y:1046,t:1527189045447};\\\", \\\"{x:1385,y:1050,t:1527189045464};\\\", \\\"{x:1375,y:1051,t:1527189045480};\\\", \\\"{x:1372,y:1051,t:1527189045497};\\\", \\\"{x:1368,y:1051,t:1527189045514};\\\", \\\"{x:1366,y:1051,t:1527189045530};\\\", \\\"{x:1365,y:1051,t:1527189045547};\\\", \\\"{x:1364,y:1050,t:1527189045564};\\\", \\\"{x:1362,y:1045,t:1527189045581};\\\", \\\"{x:1356,y:1031,t:1527189045597};\\\", \\\"{x:1347,y:1014,t:1527189045615};\\\", \\\"{x:1344,y:1000,t:1527189045631};\\\", \\\"{x:1341,y:986,t:1527189045647};\\\", \\\"{x:1341,y:970,t:1527189045665};\\\", \\\"{x:1342,y:952,t:1527189045681};\\\", \\\"{x:1344,y:934,t:1527189045698};\\\", \\\"{x:1348,y:916,t:1527189045715};\\\", \\\"{x:1349,y:893,t:1527189045731};\\\", \\\"{x:1352,y:868,t:1527189045748};\\\", \\\"{x:1352,y:846,t:1527189045765};\\\", \\\"{x:1352,y:829,t:1527189045781};\\\", \\\"{x:1347,y:808,t:1527189045798};\\\", \\\"{x:1344,y:799,t:1527189045815};\\\", \\\"{x:1341,y:793,t:1527189045831};\\\", \\\"{x:1338,y:788,t:1527189045848};\\\", \\\"{x:1334,y:783,t:1527189045865};\\\", \\\"{x:1330,y:778,t:1527189045882};\\\", \\\"{x:1329,y:776,t:1527189045898};\\\", \\\"{x:1328,y:773,t:1527189045914};\\\", \\\"{x:1327,y:771,t:1527189045932};\\\", \\\"{x:1327,y:766,t:1527189045948};\\\", \\\"{x:1323,y:756,t:1527189045965};\\\", \\\"{x:1321,y:747,t:1527189045982};\\\", \\\"{x:1319,y:740,t:1527189045998};\\\", \\\"{x:1319,y:735,t:1527189046015};\\\", \\\"{x:1319,y:730,t:1527189046032};\\\", \\\"{x:1318,y:728,t:1527189046047};\\\", \\\"{x:1317,y:724,t:1527189046064};\\\", \\\"{x:1317,y:721,t:1527189046082};\\\", \\\"{x:1315,y:715,t:1527189046098};\\\", \\\"{x:1311,y:707,t:1527189046114};\\\", \\\"{x:1306,y:696,t:1527189046132};\\\", \\\"{x:1303,y:690,t:1527189046147};\\\", \\\"{x:1300,y:684,t:1527189046165};\\\", \\\"{x:1291,y:673,t:1527189046181};\\\", \\\"{x:1281,y:666,t:1527189046198};\\\", \\\"{x:1265,y:655,t:1527189046215};\\\", \\\"{x:1244,y:638,t:1527189046232};\\\", \\\"{x:1213,y:615,t:1527189046248};\\\", \\\"{x:1169,y:584,t:1527189046264};\\\", \\\"{x:1133,y:555,t:1527189046282};\\\", \\\"{x:1088,y:523,t:1527189046297};\\\", \\\"{x:1035,y:487,t:1527189046315};\\\", \\\"{x:967,y:450,t:1527189046332};\\\", \\\"{x:896,y:411,t:1527189046348};\\\", \\\"{x:826,y:376,t:1527189046365};\\\", \\\"{x:733,y:332,t:1527189046381};\\\", \\\"{x:685,y:308,t:1527189046398};\\\", \\\"{x:644,y:292,t:1527189046415};\\\", \\\"{x:617,y:283,t:1527189046432};\\\", \\\"{x:597,y:277,t:1527189046449};\\\", \\\"{x:577,y:274,t:1527189046465};\\\", \\\"{x:565,y:272,t:1527189046482};\\\", \\\"{x:556,y:271,t:1527189046498};\\\", \\\"{x:553,y:271,t:1527189046515};\\\", \\\"{x:549,y:271,t:1527189046531};\\\", \\\"{x:547,y:273,t:1527189046548};\\\", \\\"{x:543,y:276,t:1527189046564};\\\", \\\"{x:538,y:280,t:1527189046581};\\\", \\\"{x:530,y:288,t:1527189046599};\\\", \\\"{x:524,y:298,t:1527189046615};\\\", \\\"{x:514,y:312,t:1527189046632};\\\", \\\"{x:499,y:332,t:1527189046649};\\\", \\\"{x:486,y:353,t:1527189046665};\\\", \\\"{x:475,y:370,t:1527189046682};\\\", \\\"{x:463,y:385,t:1527189046698};\\\", \\\"{x:451,y:397,t:1527189046715};\\\", \\\"{x:439,y:409,t:1527189046731};\\\", \\\"{x:427,y:422,t:1527189046750};\\\", \\\"{x:417,y:435,t:1527189046765};\\\", \\\"{x:408,y:446,t:1527189046782};\\\", \\\"{x:406,y:450,t:1527189046799};\\\", \\\"{x:403,y:455,t:1527189046815};\\\", \\\"{x:401,y:459,t:1527189046832};\\\", \\\"{x:399,y:464,t:1527189046849};\\\", \\\"{x:396,y:470,t:1527189046866};\\\", \\\"{x:395,y:476,t:1527189046882};\\\", \\\"{x:395,y:478,t:1527189046899};\\\", \\\"{x:395,y:481,t:1527189046916};\\\", \\\"{x:395,y:484,t:1527189046932};\\\", \\\"{x:395,y:490,t:1527189046951};\\\", \\\"{x:399,y:498,t:1527189046965};\\\", \\\"{x:402,y:505,t:1527189046981};\\\", \\\"{x:402,y:508,t:1527189046996};\\\", \\\"{x:402,y:509,t:1527189047013};\\\", \\\"{x:402,y:510,t:1527189047109};\\\", \\\"{x:402,y:512,t:1527189047134};\\\", \\\"{x:402,y:513,t:1527189047147};\\\", \\\"{x:402,y:522,t:1527189047166};\\\", \\\"{x:402,y:532,t:1527189047183};\\\", \\\"{x:402,y:540,t:1527189047199};\\\", \\\"{x:401,y:548,t:1527189047215};\\\", \\\"{x:400,y:554,t:1527189047232};\\\", \\\"{x:399,y:556,t:1527189047250};\\\", \\\"{x:399,y:557,t:1527189047293};\\\", \\\"{x:399,y:558,t:1527189047309};\\\", \\\"{x:399,y:559,t:1527189047325};\\\", \\\"{x:399,y:560,t:1527189047341};\\\", \\\"{x:399,y:561,t:1527189047357};\\\", \\\"{x:398,y:562,t:1527189047373};\\\", \\\"{x:397,y:562,t:1527189047382};\\\", \\\"{x:397,y:564,t:1527189047401};\\\", \\\"{x:397,y:567,t:1527189047417};\\\", \\\"{x:398,y:567,t:1527189047477};\\\", \\\"{x:402,y:567,t:1527189047485};\\\", \\\"{x:405,y:567,t:1527189047500};\\\", \\\"{x:421,y:565,t:1527189047517};\\\", \\\"{x:444,y:560,t:1527189047533};\\\", \\\"{x:483,y:554,t:1527189047549};\\\", \\\"{x:505,y:550,t:1527189047568};\\\", \\\"{x:527,y:547,t:1527189047583};\\\", \\\"{x:543,y:542,t:1527189047599};\\\", \\\"{x:559,y:537,t:1527189047617};\\\", \\\"{x:574,y:535,t:1527189047632};\\\", \\\"{x:595,y:534,t:1527189047650};\\\", \\\"{x:616,y:534,t:1527189047667};\\\", \\\"{x:637,y:531,t:1527189047683};\\\", \\\"{x:655,y:529,t:1527189047700};\\\", \\\"{x:676,y:529,t:1527189047717};\\\", \\\"{x:715,y:529,t:1527189047732};\\\", \\\"{x:742,y:529,t:1527189047751};\\\", \\\"{x:764,y:529,t:1527189047767};\\\", \\\"{x:774,y:529,t:1527189047782};\\\", \\\"{x:777,y:530,t:1527189047799};\\\", \\\"{x:777,y:531,t:1527189047846};\\\", \\\"{x:777,y:532,t:1527189047854};\\\", \\\"{x:777,y:533,t:1527189047867};\\\", \\\"{x:765,y:538,t:1527189047883};\\\", \\\"{x:751,y:539,t:1527189047900};\\\", \\\"{x:726,y:539,t:1527189047917};\\\", \\\"{x:692,y:534,t:1527189047935};\\\", \\\"{x:629,y:520,t:1527189047950};\\\", \\\"{x:587,y:513,t:1527189047967};\\\", \\\"{x:548,y:513,t:1527189047982};\\\", \\\"{x:519,y:513,t:1527189047999};\\\", \\\"{x:490,y:514,t:1527189048017};\\\", \\\"{x:463,y:522,t:1527189048033};\\\", \\\"{x:439,y:529,t:1527189048050};\\\", \\\"{x:422,y:535,t:1527189048066};\\\", \\\"{x:406,y:540,t:1527189048083};\\\", \\\"{x:389,y:543,t:1527189048099};\\\", \\\"{x:377,y:545,t:1527189048116};\\\", \\\"{x:370,y:546,t:1527189048132};\\\", \\\"{x:362,y:548,t:1527189048149};\\\", \\\"{x:356,y:549,t:1527189048166};\\\", \\\"{x:345,y:551,t:1527189048184};\\\", \\\"{x:327,y:554,t:1527189048200};\\\", \\\"{x:315,y:555,t:1527189048216};\\\", \\\"{x:303,y:556,t:1527189048234};\\\", \\\"{x:294,y:556,t:1527189048249};\\\", \\\"{x:282,y:557,t:1527189048267};\\\", \\\"{x:276,y:557,t:1527189048284};\\\", \\\"{x:272,y:557,t:1527189048300};\\\", \\\"{x:267,y:557,t:1527189048317};\\\", \\\"{x:252,y:555,t:1527189048334};\\\", \\\"{x:233,y:550,t:1527189048350};\\\", \\\"{x:219,y:548,t:1527189048367};\\\", \\\"{x:204,y:545,t:1527189048383};\\\", \\\"{x:188,y:544,t:1527189048402};\\\", \\\"{x:176,y:542,t:1527189048417};\\\", \\\"{x:166,y:540,t:1527189048434};\\\", \\\"{x:157,y:539,t:1527189048449};\\\", \\\"{x:153,y:538,t:1527189048467};\\\", \\\"{x:152,y:538,t:1527189048484};\\\", \\\"{x:151,y:538,t:1527189048499};\\\", \\\"{x:147,y:538,t:1527189048517};\\\", \\\"{x:144,y:539,t:1527189048534};\\\", \\\"{x:146,y:538,t:1527189048918};\\\", \\\"{x:148,y:538,t:1527189048933};\\\", \\\"{x:151,y:536,t:1527189048951};\\\", \\\"{x:153,y:536,t:1527189048968};\\\", \\\"{x:155,y:535,t:1527189048984};\\\", \\\"{x:159,y:533,t:1527189049000};\\\", \\\"{x:162,y:532,t:1527189049016};\\\", \\\"{x:164,y:531,t:1527189049034};\\\", \\\"{x:166,y:531,t:1527189049061};\\\", \\\"{x:168,y:530,t:1527189049077};\\\", \\\"{x:169,y:529,t:1527189049086};\\\", \\\"{x:170,y:529,t:1527189049100};\\\", \\\"{x:171,y:529,t:1527189049116};\\\", \\\"{x:172,y:528,t:1527189049133};\\\", \\\"{x:174,y:527,t:1527189049173};\\\", \\\"{x:177,y:526,t:1527189049189};\\\", \\\"{x:178,y:526,t:1527189049200};\\\", \\\"{x:184,y:526,t:1527189049217};\\\", \\\"{x:186,y:526,t:1527189049233};\\\", \\\"{x:187,y:526,t:1527189049250};\\\", \\\"{x:185,y:527,t:1527189049446};\\\", \\\"{x:184,y:527,t:1527189049454};\\\", \\\"{x:181,y:528,t:1527189049469};\\\", \\\"{x:181,y:529,t:1527189049485};\\\", \\\"{x:179,y:530,t:1527189049501};\\\", \\\"{x:177,y:531,t:1527189049517};\\\", \\\"{x:176,y:532,t:1527189049534};\\\", \\\"{x:174,y:533,t:1527189049551};\\\", \\\"{x:173,y:533,t:1527189049567};\\\", \\\"{x:171,y:534,t:1527189049584};\\\", \\\"{x:171,y:535,t:1527189049601};\\\", \\\"{x:170,y:535,t:1527189049617};\\\", \\\"{x:169,y:536,t:1527189049635};\\\", \\\"{x:170,y:536,t:1527189050159};\\\", \\\"{x:177,y:536,t:1527189050168};\\\", \\\"{x:193,y:539,t:1527189050185};\\\", \\\"{x:211,y:544,t:1527189050202};\\\", \\\"{x:229,y:547,t:1527189050218};\\\", \\\"{x:244,y:552,t:1527189050235};\\\", \\\"{x:252,y:556,t:1527189050253};\\\", \\\"{x:264,y:561,t:1527189050268};\\\", \\\"{x:275,y:565,t:1527189050286};\\\", \\\"{x:285,y:570,t:1527189050301};\\\", \\\"{x:290,y:572,t:1527189050318};\\\", \\\"{x:292,y:573,t:1527189050413};\\\", \\\"{x:294,y:573,t:1527189050437};\\\", \\\"{x:298,y:574,t:1527189050451};\\\", \\\"{x:306,y:577,t:1527189050468};\\\", \\\"{x:325,y:582,t:1527189050485};\\\", \\\"{x:362,y:586,t:1527189050502};\\\", \\\"{x:389,y:586,t:1527189050519};\\\", \\\"{x:416,y:586,t:1527189050535};\\\", \\\"{x:442,y:586,t:1527189050552};\\\", \\\"{x:463,y:586,t:1527189050568};\\\", \\\"{x:481,y:586,t:1527189050585};\\\", \\\"{x:500,y:586,t:1527189050603};\\\", \\\"{x:517,y:586,t:1527189050619};\\\", \\\"{x:534,y:586,t:1527189050636};\\\", \\\"{x:553,y:586,t:1527189050652};\\\", \\\"{x:567,y:586,t:1527189050669};\\\", \\\"{x:585,y:586,t:1527189050685};\\\", \\\"{x:595,y:586,t:1527189050702};\\\", \\\"{x:607,y:586,t:1527189050719};\\\", \\\"{x:625,y:586,t:1527189050736};\\\", \\\"{x:649,y:582,t:1527189050752};\\\", \\\"{x:672,y:578,t:1527189050768};\\\", \\\"{x:686,y:576,t:1527189050785};\\\", \\\"{x:700,y:574,t:1527189050801};\\\", \\\"{x:717,y:571,t:1527189050818};\\\", \\\"{x:730,y:570,t:1527189050837};\\\", \\\"{x:743,y:565,t:1527189050851};\\\", \\\"{x:768,y:561,t:1527189050868};\\\", \\\"{x:788,y:559,t:1527189050884};\\\", \\\"{x:803,y:556,t:1527189050902};\\\", \\\"{x:819,y:553,t:1527189050919};\\\", \\\"{x:831,y:549,t:1527189050936};\\\", \\\"{x:845,y:544,t:1527189050952};\\\", \\\"{x:857,y:541,t:1527189050969};\\\", \\\"{x:862,y:538,t:1527189050985};\\\", \\\"{x:866,y:536,t:1527189051002};\\\", \\\"{x:869,y:535,t:1527189051018};\\\", \\\"{x:871,y:533,t:1527189051036};\\\", \\\"{x:872,y:532,t:1527189051053};\\\", \\\"{x:873,y:531,t:1527189051069};\\\", \\\"{x:874,y:527,t:1527189051085};\\\", \\\"{x:874,y:523,t:1527189051103};\\\", \\\"{x:874,y:516,t:1527189051119};\\\", \\\"{x:874,y:510,t:1527189051136};\\\", \\\"{x:874,y:504,t:1527189051152};\\\", \\\"{x:874,y:501,t:1527189051169};\\\", \\\"{x:873,y:497,t:1527189051186};\\\", \\\"{x:869,y:493,t:1527189051203};\\\", \\\"{x:864,y:490,t:1527189051219};\\\", \\\"{x:859,y:488,t:1527189051236};\\\", \\\"{x:856,y:487,t:1527189051251};\\\", \\\"{x:852,y:485,t:1527189051269};\\\", \\\"{x:851,y:485,t:1527189051341};\\\", \\\"{x:850,y:485,t:1527189051477};\\\", \\\"{x:849,y:485,t:1527189051510};\\\", \\\"{x:848,y:485,t:1527189051534};\\\", \\\"{x:847,y:486,t:1527189051550};\\\", \\\"{x:845,y:486,t:1527189051565};\\\", \\\"{x:845,y:488,t:1527189051574};\\\", \\\"{x:844,y:488,t:1527189051589};\\\", \\\"{x:844,y:489,t:1527189051602};\\\", \\\"{x:842,y:492,t:1527189051619};\\\", \\\"{x:842,y:494,t:1527189051636};\\\", \\\"{x:841,y:495,t:1527189051653};\\\", \\\"{x:840,y:495,t:1527189051677};\\\", \\\"{x:840,y:496,t:1527189051702};\\\", \\\"{x:838,y:497,t:1527189051710};\\\", \\\"{x:838,y:498,t:1527189051719};\\\", \\\"{x:837,y:498,t:1527189051735};\\\", \\\"{x:836,y:500,t:1527189051753};\\\", \\\"{x:835,y:501,t:1527189051773};\\\", \\\"{x:835,y:502,t:1527189051789};\\\", \\\"{x:835,y:503,t:1527189051798};\\\", \\\"{x:832,y:505,t:1527189052029};\\\", \\\"{x:831,y:505,t:1527189052037};\\\", \\\"{x:825,y:508,t:1527189052054};\\\", \\\"{x:815,y:516,t:1527189052069};\\\", \\\"{x:799,y:529,t:1527189052087};\\\", \\\"{x:773,y:548,t:1527189052102};\\\", \\\"{x:739,y:572,t:1527189052120};\\\", \\\"{x:700,y:599,t:1527189052137};\\\", \\\"{x:650,y:629,t:1527189052153};\\\", \\\"{x:602,y:656,t:1527189052171};\\\", \\\"{x:560,y:676,t:1527189052186};\\\", \\\"{x:535,y:689,t:1527189052203};\\\", \\\"{x:513,y:701,t:1527189052219};\\\", \\\"{x:490,y:713,t:1527189052237};\\\", \\\"{x:483,y:718,t:1527189052253};\\\", \\\"{x:480,y:721,t:1527189052270};\\\", \\\"{x:480,y:722,t:1527189052286};\\\", \\\"{x:480,y:723,t:1527189052309};\\\", \\\"{x:480,y:724,t:1527189052320};\\\", \\\"{x:480,y:726,t:1527189052337};\\\", \\\"{x:480,y:729,t:1527189052352};\\\", \\\"{x:480,y:732,t:1527189052370};\\\", \\\"{x:480,y:734,t:1527189052387};\\\", \\\"{x:481,y:735,t:1527189052725};\\\", \\\"{x:488,y:733,t:1527189052736};\\\", \\\"{x:499,y:729,t:1527189052753};\\\", \\\"{x:517,y:723,t:1527189052770};\\\", \\\"{x:540,y:717,t:1527189052787};\\\", \\\"{x:569,y:713,t:1527189052804};\\\", \\\"{x:592,y:710,t:1527189052820};\\\", \\\"{x:613,y:707,t:1527189052837};\\\", \\\"{x:631,y:704,t:1527189052853};\\\", \\\"{x:633,y:703,t:1527189052870};\\\", \\\"{x:634,y:703,t:1527189052886};\\\", \\\"{x:635,y:702,t:1527189052904};\\\", \\\"{x:637,y:702,t:1527189052934};\\\", \\\"{x:638,y:702,t:1527189052973};\\\", \\\"{x:640,y:701,t:1527189053013};\\\", \\\"{x:640,y:700,t:1527189053038};\\\", \\\"{x:641,y:700,t:1527189053077};\\\", \\\"{x:641,y:699,t:1527189053093};\\\", \\\"{x:642,y:699,t:1527189053126};\\\", \\\"{x:644,y:699,t:1527189053254};\\\", \\\"{x:645,y:697,t:1527189053271};\\\", \\\"{x:646,y:697,t:1527189053287};\\\", \\\"{x:647,y:697,t:1527189053304};\\\", \\\"{x:648,y:696,t:1527189053321};\\\" ] }, { \\\"rt\\\": 5323, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 439211, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:644,y:692,t:1527189056046};\\\", \\\"{x:634,y:685,t:1527189056057};\\\", \\\"{x:600,y:663,t:1527189056079};\\\", \\\"{x:587,y:656,t:1527189056090};\\\", \\\"{x:561,y:642,t:1527189056106};\\\", \\\"{x:539,y:629,t:1527189056123};\\\", \\\"{x:519,y:617,t:1527189056140};\\\", \\\"{x:509,y:608,t:1527189056156};\\\", \\\"{x:500,y:602,t:1527189056171};\\\", \\\"{x:494,y:597,t:1527189056188};\\\", \\\"{x:487,y:590,t:1527189056205};\\\", \\\"{x:482,y:586,t:1527189056223};\\\", \\\"{x:477,y:581,t:1527189056240};\\\", \\\"{x:469,y:576,t:1527189056256};\\\", \\\"{x:455,y:567,t:1527189056273};\\\", \\\"{x:440,y:558,t:1527189056291};\\\", \\\"{x:421,y:549,t:1527189056306};\\\", \\\"{x:408,y:542,t:1527189056323};\\\", \\\"{x:403,y:541,t:1527189056339};\\\", \\\"{x:397,y:537,t:1527189056357};\\\", \\\"{x:395,y:537,t:1527189056372};\\\", \\\"{x:388,y:535,t:1527189056390};\\\", \\\"{x:382,y:533,t:1527189056407};\\\", \\\"{x:378,y:533,t:1527189056422};\\\", \\\"{x:377,y:533,t:1527189056440};\\\", \\\"{x:377,y:532,t:1527189056493};\\\", \\\"{x:379,y:531,t:1527189056507};\\\", \\\"{x:392,y:528,t:1527189056523};\\\", \\\"{x:407,y:528,t:1527189056540};\\\", \\\"{x:434,y:524,t:1527189056557};\\\", \\\"{x:451,y:521,t:1527189056573};\\\", \\\"{x:462,y:520,t:1527189056589};\\\", \\\"{x:480,y:519,t:1527189056606};\\\", \\\"{x:499,y:519,t:1527189056623};\\\", \\\"{x:516,y:519,t:1527189056639};\\\", \\\"{x:536,y:519,t:1527189056656};\\\", \\\"{x:553,y:518,t:1527189056672};\\\", \\\"{x:571,y:513,t:1527189056690};\\\", \\\"{x:588,y:512,t:1527189056706};\\\", \\\"{x:604,y:510,t:1527189056723};\\\", \\\"{x:619,y:510,t:1527189056739};\\\", \\\"{x:633,y:510,t:1527189056757};\\\", \\\"{x:640,y:509,t:1527189056773};\\\", \\\"{x:643,y:509,t:1527189056790};\\\", \\\"{x:645,y:509,t:1527189056806};\\\", \\\"{x:641,y:510,t:1527189056885};\\\", \\\"{x:636,y:512,t:1527189056892};\\\", \\\"{x:631,y:515,t:1527189056907};\\\", \\\"{x:625,y:516,t:1527189056923};\\\", \\\"{x:619,y:520,t:1527189056941};\\\", \\\"{x:609,y:525,t:1527189056957};\\\", \\\"{x:606,y:527,t:1527189056974};\\\", \\\"{x:603,y:528,t:1527189056990};\\\", \\\"{x:596,y:532,t:1527189057007};\\\", \\\"{x:588,y:535,t:1527189057024};\\\", \\\"{x:576,y:540,t:1527189057040};\\\", \\\"{x:564,y:545,t:1527189057056};\\\", \\\"{x:553,y:547,t:1527189057074};\\\", \\\"{x:542,y:551,t:1527189057090};\\\", \\\"{x:527,y:558,t:1527189057108};\\\", \\\"{x:512,y:562,t:1527189057124};\\\", \\\"{x:496,y:567,t:1527189057141};\\\", \\\"{x:472,y:572,t:1527189057157};\\\", \\\"{x:459,y:576,t:1527189057173};\\\", \\\"{x:450,y:577,t:1527189057190};\\\", \\\"{x:442,y:580,t:1527189057207};\\\", \\\"{x:434,y:581,t:1527189057224};\\\", \\\"{x:417,y:582,t:1527189057241};\\\", \\\"{x:390,y:586,t:1527189057257};\\\", \\\"{x:359,y:588,t:1527189057274};\\\", \\\"{x:327,y:592,t:1527189057291};\\\", \\\"{x:301,y:595,t:1527189057308};\\\", \\\"{x:271,y:595,t:1527189057324};\\\", \\\"{x:220,y:595,t:1527189057340};\\\", \\\"{x:190,y:595,t:1527189057356};\\\", \\\"{x:168,y:593,t:1527189057375};\\\", \\\"{x:156,y:591,t:1527189057390};\\\", \\\"{x:154,y:591,t:1527189057407};\\\", \\\"{x:153,y:591,t:1527189057424};\\\", \\\"{x:152,y:591,t:1527189057441};\\\", \\\"{x:151,y:591,t:1527189057457};\\\", \\\"{x:149,y:591,t:1527189057473};\\\", \\\"{x:148,y:592,t:1527189057491};\\\", \\\"{x:146,y:592,t:1527189057507};\\\", \\\"{x:144,y:593,t:1527189057524};\\\", \\\"{x:141,y:594,t:1527189057541};\\\", \\\"{x:138,y:596,t:1527189057556};\\\", \\\"{x:135,y:599,t:1527189057574};\\\", \\\"{x:132,y:606,t:1527189057592};\\\", \\\"{x:131,y:610,t:1527189057608};\\\", \\\"{x:129,y:616,t:1527189057624};\\\", \\\"{x:129,y:617,t:1527189057641};\\\", \\\"{x:129,y:618,t:1527189057657};\\\", \\\"{x:132,y:618,t:1527189057673};\\\", \\\"{x:134,y:617,t:1527189057690};\\\", \\\"{x:136,y:616,t:1527189057707};\\\", \\\"{x:139,y:615,t:1527189057724};\\\", \\\"{x:144,y:610,t:1527189057741};\\\", \\\"{x:148,y:606,t:1527189057758};\\\", \\\"{x:153,y:602,t:1527189057774};\\\", \\\"{x:155,y:595,t:1527189057791};\\\", \\\"{x:157,y:588,t:1527189057809};\\\", \\\"{x:158,y:581,t:1527189057824};\\\", \\\"{x:159,y:575,t:1527189057840};\\\", \\\"{x:161,y:572,t:1527189057858};\\\", \\\"{x:162,y:568,t:1527189057874};\\\", \\\"{x:162,y:567,t:1527189057891};\\\", \\\"{x:162,y:565,t:1527189057909};\\\", \\\"{x:162,y:564,t:1527189057933};\\\", \\\"{x:162,y:562,t:1527189057983};\\\", \\\"{x:162,y:561,t:1527189057991};\\\", \\\"{x:162,y:559,t:1527189058008};\\\", \\\"{x:163,y:557,t:1527189058025};\\\", \\\"{x:163,y:554,t:1527189058042};\\\", \\\"{x:163,y:552,t:1527189058058};\\\", \\\"{x:163,y:551,t:1527189058075};\\\", \\\"{x:163,y:548,t:1527189058091};\\\", \\\"{x:163,y:547,t:1527189058108};\\\", \\\"{x:163,y:546,t:1527189058124};\\\", \\\"{x:166,y:545,t:1527189058421};\\\", \\\"{x:180,y:549,t:1527189058429};\\\", \\\"{x:189,y:553,t:1527189058441};\\\", \\\"{x:216,y:565,t:1527189058458};\\\", \\\"{x:241,y:580,t:1527189058475};\\\", \\\"{x:264,y:592,t:1527189058492};\\\", \\\"{x:287,y:604,t:1527189058509};\\\", \\\"{x:323,y:623,t:1527189058524};\\\", \\\"{x:343,y:638,t:1527189058542};\\\", \\\"{x:358,y:645,t:1527189058559};\\\", \\\"{x:373,y:652,t:1527189058575};\\\", \\\"{x:383,y:656,t:1527189058592};\\\", \\\"{x:389,y:659,t:1527189058608};\\\", \\\"{x:395,y:661,t:1527189058625};\\\", \\\"{x:402,y:664,t:1527189058643};\\\", \\\"{x:409,y:670,t:1527189058660};\\\", \\\"{x:414,y:672,t:1527189058675};\\\", \\\"{x:417,y:674,t:1527189058734};\\\", \\\"{x:419,y:675,t:1527189058742};\\\", \\\"{x:424,y:680,t:1527189058759};\\\", \\\"{x:428,y:684,t:1527189058774};\\\", \\\"{x:431,y:689,t:1527189058792};\\\", \\\"{x:437,y:693,t:1527189058809};\\\", \\\"{x:440,y:695,t:1527189058825};\\\", \\\"{x:445,y:699,t:1527189058842};\\\", \\\"{x:453,y:703,t:1527189058858};\\\", \\\"{x:463,y:708,t:1527189058875};\\\", \\\"{x:472,y:713,t:1527189058892};\\\", \\\"{x:493,y:727,t:1527189058910};\\\", \\\"{x:499,y:730,t:1527189058924};\\\", \\\"{x:500,y:730,t:1527189058942};\\\", \\\"{x:500,y:731,t:1527189059030};\\\", \\\"{x:501,y:731,t:1527189059117};\\\", \\\"{x:501,y:731,t:1527189059172};\\\", \\\"{x:504,y:729,t:1527189059317};\\\", \\\"{x:504,y:725,t:1527189059325};\\\", \\\"{x:504,y:711,t:1527189059342};\\\", \\\"{x:504,y:695,t:1527189059359};\\\", \\\"{x:503,y:677,t:1527189059374};\\\", \\\"{x:494,y:659,t:1527189059391};\\\", \\\"{x:484,y:646,t:1527189059409};\\\", \\\"{x:472,y:633,t:1527189059425};\\\", \\\"{x:459,y:621,t:1527189059442};\\\", \\\"{x:444,y:611,t:1527189059459};\\\", \\\"{x:437,y:604,t:1527189059476};\\\", \\\"{x:427,y:595,t:1527189059492};\\\", \\\"{x:422,y:588,t:1527189059509};\\\", \\\"{x:418,y:586,t:1527189059525};\\\", \\\"{x:416,y:584,t:1527189059542};\\\", \\\"{x:414,y:583,t:1527189059559};\\\", \\\"{x:412,y:582,t:1527189059575};\\\", \\\"{x:411,y:581,t:1527189059605};\\\", \\\"{x:410,y:581,t:1527189059733};\\\", \\\"{x:410,y:580,t:1527189059742};\\\", \\\"{x:408,y:578,t:1527189059759};\\\", \\\"{x:406,y:577,t:1527189059775};\\\", \\\"{x:405,y:576,t:1527189059792};\\\", \\\"{x:404,y:575,t:1527189059809};\\\", \\\"{x:404,y:574,t:1527189059829};\\\", \\\"{x:403,y:574,t:1527189059926};\\\" ] }, { \\\"rt\\\": 39420, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 479855, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -F -E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:402,y:574,t:1527189060733};\\\", \\\"{x:404,y:571,t:1527189063118};\\\", \\\"{x:407,y:567,t:1527189063126};\\\", \\\"{x:413,y:561,t:1527189063143};\\\", \\\"{x:427,y:550,t:1527189063158};\\\", \\\"{x:441,y:540,t:1527189063175};\\\", \\\"{x:451,y:532,t:1527189063195};\\\", \\\"{x:459,y:525,t:1527189063212};\\\", \\\"{x:472,y:513,t:1527189063230};\\\", \\\"{x:484,y:504,t:1527189063245};\\\", \\\"{x:496,y:496,t:1527189063262};\\\", \\\"{x:508,y:487,t:1527189063280};\\\", \\\"{x:517,y:480,t:1527189063295};\\\", \\\"{x:526,y:473,t:1527189063313};\\\", \\\"{x:538,y:465,t:1527189063329};\\\", \\\"{x:551,y:456,t:1527189063345};\\\", \\\"{x:564,y:447,t:1527189063362};\\\", \\\"{x:577,y:437,t:1527189063379};\\\", \\\"{x:593,y:426,t:1527189063395};\\\", \\\"{x:608,y:418,t:1527189063412};\\\", \\\"{x:638,y:402,t:1527189063429};\\\", \\\"{x:661,y:392,t:1527189063445};\\\", \\\"{x:685,y:382,t:1527189063462};\\\", \\\"{x:706,y:373,t:1527189063480};\\\", \\\"{x:728,y:364,t:1527189063495};\\\", \\\"{x:747,y:356,t:1527189063512};\\\", \\\"{x:766,y:347,t:1527189063530};\\\", \\\"{x:782,y:341,t:1527189063545};\\\", \\\"{x:793,y:337,t:1527189063563};\\\", \\\"{x:804,y:332,t:1527189063579};\\\", \\\"{x:816,y:327,t:1527189063595};\\\", \\\"{x:827,y:322,t:1527189063612};\\\", \\\"{x:843,y:317,t:1527189063629};\\\", \\\"{x:857,y:312,t:1527189063646};\\\", \\\"{x:872,y:308,t:1527189063663};\\\", \\\"{x:886,y:305,t:1527189063680};\\\", \\\"{x:900,y:301,t:1527189063696};\\\", \\\"{x:913,y:297,t:1527189063712};\\\", \\\"{x:928,y:293,t:1527189063730};\\\", \\\"{x:944,y:289,t:1527189063746};\\\", \\\"{x:955,y:285,t:1527189063762};\\\", \\\"{x:968,y:283,t:1527189063779};\\\", \\\"{x:977,y:280,t:1527189063796};\\\", \\\"{x:987,y:278,t:1527189063812};\\\", \\\"{x:1002,y:275,t:1527189063829};\\\", \\\"{x:1014,y:272,t:1527189063847};\\\", \\\"{x:1022,y:272,t:1527189063862};\\\", \\\"{x:1032,y:271,t:1527189063880};\\\", \\\"{x:1040,y:269,t:1527189063896};\\\", \\\"{x:1049,y:268,t:1527189063913};\\\", \\\"{x:1056,y:266,t:1527189063929};\\\", \\\"{x:1068,y:264,t:1527189063947};\\\", \\\"{x:1082,y:263,t:1527189063962};\\\", \\\"{x:1093,y:262,t:1527189063979};\\\", \\\"{x:1107,y:259,t:1527189063997};\\\", \\\"{x:1128,y:257,t:1527189064012};\\\", \\\"{x:1138,y:256,t:1527189064029};\\\", \\\"{x:1147,y:256,t:1527189064046};\\\", \\\"{x:1158,y:256,t:1527189064062};\\\", \\\"{x:1166,y:256,t:1527189064080};\\\", \\\"{x:1179,y:256,t:1527189064096};\\\", \\\"{x:1185,y:256,t:1527189064112};\\\", \\\"{x:1195,y:256,t:1527189064129};\\\", \\\"{x:1201,y:256,t:1527189064147};\\\", \\\"{x:1207,y:256,t:1527189064163};\\\", \\\"{x:1212,y:256,t:1527189064179};\\\", \\\"{x:1219,y:256,t:1527189064196};\\\", \\\"{x:1233,y:256,t:1527189064213};\\\", \\\"{x:1244,y:259,t:1527189064229};\\\", \\\"{x:1257,y:260,t:1527189064246};\\\", \\\"{x:1267,y:263,t:1527189064263};\\\", \\\"{x:1278,y:266,t:1527189064279};\\\", \\\"{x:1283,y:268,t:1527189064297};\\\", \\\"{x:1292,y:270,t:1527189064314};\\\", \\\"{x:1305,y:273,t:1527189064329};\\\", \\\"{x:1321,y:278,t:1527189064346};\\\", \\\"{x:1339,y:284,t:1527189064363};\\\", \\\"{x:1357,y:288,t:1527189064380};\\\", \\\"{x:1376,y:291,t:1527189064397};\\\", \\\"{x:1409,y:303,t:1527189064413};\\\", \\\"{x:1430,y:308,t:1527189064429};\\\", \\\"{x:1445,y:312,t:1527189064447};\\\", \\\"{x:1454,y:315,t:1527189064463};\\\", \\\"{x:1462,y:318,t:1527189064480};\\\", \\\"{x:1468,y:320,t:1527189064497};\\\", \\\"{x:1472,y:322,t:1527189064514};\\\", \\\"{x:1476,y:322,t:1527189064529};\\\", \\\"{x:1477,y:323,t:1527189064547};\\\", \\\"{x:1478,y:324,t:1527189064564};\\\", \\\"{x:1479,y:324,t:1527189065022};\\\", \\\"{x:1479,y:326,t:1527189065334};\\\", \\\"{x:1479,y:335,t:1527189065348};\\\", \\\"{x:1479,y:354,t:1527189065364};\\\", \\\"{x:1479,y:376,t:1527189065381};\\\", \\\"{x:1479,y:415,t:1527189065397};\\\", \\\"{x:1479,y:451,t:1527189065415};\\\", \\\"{x:1478,y:486,t:1527189065431};\\\", \\\"{x:1478,y:518,t:1527189065448};\\\", \\\"{x:1478,y:541,t:1527189065465};\\\", \\\"{x:1478,y:556,t:1527189065481};\\\", \\\"{x:1479,y:569,t:1527189065499};\\\", \\\"{x:1482,y:575,t:1527189065515};\\\", \\\"{x:1483,y:580,t:1527189065530};\\\", \\\"{x:1487,y:586,t:1527189065548};\\\", \\\"{x:1490,y:590,t:1527189065564};\\\", \\\"{x:1494,y:597,t:1527189065581};\\\", \\\"{x:1503,y:605,t:1527189065598};\\\", \\\"{x:1512,y:610,t:1527189065615};\\\", \\\"{x:1523,y:617,t:1527189065631};\\\", \\\"{x:1539,y:623,t:1527189065648};\\\", \\\"{x:1559,y:634,t:1527189065665};\\\", \\\"{x:1577,y:642,t:1527189065681};\\\", \\\"{x:1591,y:648,t:1527189065698};\\\", \\\"{x:1602,y:654,t:1527189065715};\\\", \\\"{x:1608,y:659,t:1527189065730};\\\", \\\"{x:1612,y:663,t:1527189065748};\\\", \\\"{x:1614,y:665,t:1527189065765};\\\", \\\"{x:1614,y:667,t:1527189065781};\\\", \\\"{x:1614,y:668,t:1527189065798};\\\", \\\"{x:1614,y:670,t:1527189065815};\\\", \\\"{x:1614,y:675,t:1527189065831};\\\", \\\"{x:1614,y:680,t:1527189065848};\\\", \\\"{x:1614,y:686,t:1527189065865};\\\", \\\"{x:1614,y:690,t:1527189065881};\\\", \\\"{x:1614,y:697,t:1527189065901};\\\", \\\"{x:1614,y:702,t:1527189065914};\\\", \\\"{x:1614,y:706,t:1527189065932};\\\", \\\"{x:1614,y:710,t:1527189065947};\\\", \\\"{x:1614,y:711,t:1527189065964};\\\", \\\"{x:1614,y:712,t:1527189065981};\\\", \\\"{x:1614,y:713,t:1527189066005};\\\", \\\"{x:1614,y:714,t:1527189066020};\\\", \\\"{x:1614,y:715,t:1527189066036};\\\", \\\"{x:1614,y:716,t:1527189066085};\\\", \\\"{x:1614,y:718,t:1527189066098};\\\", \\\"{x:1614,y:722,t:1527189066115};\\\", \\\"{x:1615,y:724,t:1527189066132};\\\", \\\"{x:1617,y:728,t:1527189066148};\\\", \\\"{x:1618,y:732,t:1527189066165};\\\", \\\"{x:1618,y:735,t:1527189066182};\\\", \\\"{x:1618,y:737,t:1527189066198};\\\", \\\"{x:1618,y:739,t:1527189066215};\\\", \\\"{x:1620,y:742,t:1527189066232};\\\", \\\"{x:1620,y:746,t:1527189066247};\\\", \\\"{x:1621,y:749,t:1527189066265};\\\", \\\"{x:1621,y:753,t:1527189066282};\\\", \\\"{x:1621,y:760,t:1527189066298};\\\", \\\"{x:1622,y:765,t:1527189066315};\\\", \\\"{x:1624,y:770,t:1527189066332};\\\", \\\"{x:1624,y:776,t:1527189066348};\\\", \\\"{x:1624,y:784,t:1527189066365};\\\", \\\"{x:1625,y:793,t:1527189066382};\\\", \\\"{x:1625,y:797,t:1527189066399};\\\", \\\"{x:1626,y:802,t:1527189066415};\\\", \\\"{x:1626,y:806,t:1527189066432};\\\", \\\"{x:1626,y:808,t:1527189066449};\\\", \\\"{x:1628,y:811,t:1527189066465};\\\", \\\"{x:1628,y:813,t:1527189066482};\\\", \\\"{x:1628,y:816,t:1527189066498};\\\", \\\"{x:1628,y:818,t:1527189066515};\\\", \\\"{x:1628,y:820,t:1527189066532};\\\", \\\"{x:1628,y:824,t:1527189066549};\\\", \\\"{x:1628,y:826,t:1527189066565};\\\", \\\"{x:1628,y:831,t:1527189066582};\\\", \\\"{x:1628,y:834,t:1527189066599};\\\", \\\"{x:1628,y:837,t:1527189066615};\\\", \\\"{x:1628,y:839,t:1527189066631};\\\", \\\"{x:1628,y:840,t:1527189066649};\\\", \\\"{x:1628,y:839,t:1527189066814};\\\", \\\"{x:1628,y:832,t:1527189066821};\\\", \\\"{x:1628,y:826,t:1527189066832};\\\", \\\"{x:1628,y:813,t:1527189066849};\\\", \\\"{x:1628,y:796,t:1527189066866};\\\", \\\"{x:1628,y:781,t:1527189066882};\\\", \\\"{x:1628,y:773,t:1527189066899};\\\", \\\"{x:1630,y:763,t:1527189066916};\\\", \\\"{x:1630,y:755,t:1527189066932};\\\", \\\"{x:1632,y:747,t:1527189066949};\\\", \\\"{x:1632,y:738,t:1527189066966};\\\", \\\"{x:1632,y:735,t:1527189066981};\\\", \\\"{x:1632,y:733,t:1527189066999};\\\", \\\"{x:1633,y:729,t:1527189067016};\\\", \\\"{x:1633,y:726,t:1527189067032};\\\", \\\"{x:1633,y:722,t:1527189067049};\\\", \\\"{x:1632,y:717,t:1527189067066};\\\", \\\"{x:1632,y:714,t:1527189067082};\\\", \\\"{x:1632,y:713,t:1527189067099};\\\", \\\"{x:1632,y:711,t:1527189067116};\\\", \\\"{x:1632,y:708,t:1527189067132};\\\", \\\"{x:1632,y:705,t:1527189067149};\\\", \\\"{x:1632,y:702,t:1527189067165};\\\", \\\"{x:1632,y:706,t:1527189067317};\\\", \\\"{x:1632,y:716,t:1527189067332};\\\", \\\"{x:1628,y:746,t:1527189067348};\\\", \\\"{x:1625,y:771,t:1527189067365};\\\", \\\"{x:1621,y:794,t:1527189067382};\\\", \\\"{x:1616,y:817,t:1527189067399};\\\", \\\"{x:1613,y:835,t:1527189067416};\\\", \\\"{x:1609,y:849,t:1527189067433};\\\", \\\"{x:1609,y:863,t:1527189067449};\\\", \\\"{x:1609,y:873,t:1527189067466};\\\", \\\"{x:1609,y:878,t:1527189067483};\\\", \\\"{x:1609,y:880,t:1527189067499};\\\", \\\"{x:1609,y:882,t:1527189067516};\\\", \\\"{x:1609,y:883,t:1527189067533};\\\", \\\"{x:1608,y:888,t:1527189067549};\\\", \\\"{x:1608,y:901,t:1527189067566};\\\", \\\"{x:1608,y:911,t:1527189067583};\\\", \\\"{x:1608,y:920,t:1527189067599};\\\", \\\"{x:1608,y:924,t:1527189067616};\\\", \\\"{x:1608,y:928,t:1527189067633};\\\", \\\"{x:1608,y:929,t:1527189067649};\\\", \\\"{x:1608,y:930,t:1527189067666};\\\", \\\"{x:1608,y:929,t:1527189067742};\\\", \\\"{x:1608,y:922,t:1527189067750};\\\", \\\"{x:1612,y:890,t:1527189067766};\\\", \\\"{x:1618,y:852,t:1527189067783};\\\", \\\"{x:1624,y:834,t:1527189067800};\\\", \\\"{x:1629,y:821,t:1527189067816};\\\", \\\"{x:1633,y:810,t:1527189067833};\\\", \\\"{x:1634,y:803,t:1527189067850};\\\", \\\"{x:1634,y:794,t:1527189067866};\\\", \\\"{x:1634,y:790,t:1527189067884};\\\", \\\"{x:1633,y:787,t:1527189067900};\\\", \\\"{x:1633,y:786,t:1527189067942};\\\", \\\"{x:1633,y:785,t:1527189067991};\\\", \\\"{x:1633,y:784,t:1527189068005};\\\", \\\"{x:1633,y:782,t:1527189068029};\\\", \\\"{x:1631,y:782,t:1527189068198};\\\", \\\"{x:1630,y:782,t:1527189068222};\\\", \\\"{x:1627,y:782,t:1527189068233};\\\", \\\"{x:1622,y:786,t:1527189068251};\\\", \\\"{x:1616,y:789,t:1527189068267};\\\", \\\"{x:1608,y:794,t:1527189068283};\\\", \\\"{x:1601,y:798,t:1527189068300};\\\", \\\"{x:1591,y:802,t:1527189068317};\\\", \\\"{x:1578,y:804,t:1527189068333};\\\", \\\"{x:1562,y:807,t:1527189068350};\\\", \\\"{x:1549,y:807,t:1527189068367};\\\", \\\"{x:1538,y:806,t:1527189068383};\\\", \\\"{x:1525,y:801,t:1527189068400};\\\", \\\"{x:1514,y:796,t:1527189068417};\\\", \\\"{x:1508,y:793,t:1527189068433};\\\", \\\"{x:1506,y:792,t:1527189068451};\\\", \\\"{x:1503,y:791,t:1527189068467};\\\", \\\"{x:1503,y:789,t:1527189068483};\\\", \\\"{x:1502,y:789,t:1527189068501};\\\", \\\"{x:1502,y:788,t:1527189068573};\\\", \\\"{x:1502,y:786,t:1527189068582};\\\", \\\"{x:1502,y:785,t:1527189068605};\\\", \\\"{x:1502,y:784,t:1527189068617};\\\", \\\"{x:1502,y:783,t:1527189068633};\\\", \\\"{x:1502,y:782,t:1527189068650};\\\", \\\"{x:1502,y:780,t:1527189068667};\\\", \\\"{x:1502,y:779,t:1527189068684};\\\", \\\"{x:1502,y:778,t:1527189068700};\\\", \\\"{x:1502,y:776,t:1527189068716};\\\", \\\"{x:1502,y:775,t:1527189068757};\\\", \\\"{x:1503,y:774,t:1527189068774};\\\", \\\"{x:1504,y:773,t:1527189068798};\\\", \\\"{x:1504,y:771,t:1527189068813};\\\", \\\"{x:1504,y:770,t:1527189068822};\\\", \\\"{x:1506,y:769,t:1527189069350};\\\", \\\"{x:1508,y:767,t:1527189069389};\\\", \\\"{x:1505,y:770,t:1527189069957};\\\", \\\"{x:1503,y:772,t:1527189069968};\\\", \\\"{x:1496,y:780,t:1527189069985};\\\", \\\"{x:1487,y:787,t:1527189070001};\\\", \\\"{x:1480,y:794,t:1527189070018};\\\", \\\"{x:1472,y:800,t:1527189070035};\\\", \\\"{x:1462,y:806,t:1527189070051};\\\", \\\"{x:1452,y:814,t:1527189070068};\\\", \\\"{x:1439,y:823,t:1527189070085};\\\", \\\"{x:1433,y:829,t:1527189070101};\\\", \\\"{x:1428,y:833,t:1527189070118};\\\", \\\"{x:1424,y:837,t:1527189070135};\\\", \\\"{x:1420,y:841,t:1527189070151};\\\", \\\"{x:1416,y:844,t:1527189070168};\\\", \\\"{x:1415,y:847,t:1527189070185};\\\", \\\"{x:1412,y:851,t:1527189070201};\\\", \\\"{x:1409,y:854,t:1527189070218};\\\", \\\"{x:1408,y:860,t:1527189070234};\\\", \\\"{x:1405,y:865,t:1527189070251};\\\", \\\"{x:1401,y:872,t:1527189070268};\\\", \\\"{x:1398,y:879,t:1527189070285};\\\", \\\"{x:1394,y:885,t:1527189070301};\\\", \\\"{x:1392,y:888,t:1527189070318};\\\", \\\"{x:1391,y:891,t:1527189070335};\\\", \\\"{x:1390,y:894,t:1527189070352};\\\", \\\"{x:1388,y:896,t:1527189070368};\\\", \\\"{x:1388,y:898,t:1527189070385};\\\", \\\"{x:1388,y:899,t:1527189070401};\\\", \\\"{x:1388,y:900,t:1527189070418};\\\", \\\"{x:1388,y:901,t:1527189070435};\\\", \\\"{x:1387,y:903,t:1527189070478};\\\", \\\"{x:1387,y:904,t:1527189070494};\\\", \\\"{x:1387,y:905,t:1527189070501};\\\", \\\"{x:1387,y:906,t:1527189070518};\\\", \\\"{x:1387,y:908,t:1527189070535};\\\", \\\"{x:1387,y:910,t:1527189070553};\\\", \\\"{x:1387,y:912,t:1527189070568};\\\", \\\"{x:1387,y:915,t:1527189070585};\\\", \\\"{x:1387,y:919,t:1527189070602};\\\", \\\"{x:1387,y:922,t:1527189070618};\\\", \\\"{x:1386,y:925,t:1527189070634};\\\", \\\"{x:1386,y:927,t:1527189070654};\\\", \\\"{x:1386,y:928,t:1527189070668};\\\", \\\"{x:1386,y:931,t:1527189070685};\\\", \\\"{x:1386,y:937,t:1527189070701};\\\", \\\"{x:1386,y:939,t:1527189070718};\\\", \\\"{x:1386,y:941,t:1527189070735};\\\", \\\"{x:1386,y:942,t:1527189070782};\\\", \\\"{x:1386,y:943,t:1527189070806};\\\", \\\"{x:1386,y:944,t:1527189070829};\\\", \\\"{x:1386,y:945,t:1527189070862};\\\", \\\"{x:1387,y:946,t:1527189070902};\\\", \\\"{x:1388,y:947,t:1527189070966};\\\", \\\"{x:1389,y:948,t:1527189070982};\\\", \\\"{x:1390,y:948,t:1527189070998};\\\", \\\"{x:1392,y:948,t:1527189071006};\\\", \\\"{x:1392,y:949,t:1527189071020};\\\", \\\"{x:1394,y:950,t:1527189071035};\\\", \\\"{x:1395,y:951,t:1527189071052};\\\", \\\"{x:1396,y:951,t:1527189071070};\\\", \\\"{x:1397,y:952,t:1527189071093};\\\", \\\"{x:1400,y:954,t:1527189071102};\\\", \\\"{x:1403,y:956,t:1527189071119};\\\", \\\"{x:1406,y:957,t:1527189071136};\\\", \\\"{x:1407,y:957,t:1527189071152};\\\", \\\"{x:1409,y:958,t:1527189071222};\\\", \\\"{x:1410,y:958,t:1527189071262};\\\", \\\"{x:1410,y:959,t:1527189071269};\\\", \\\"{x:1412,y:960,t:1527189071294};\\\", \\\"{x:1413,y:960,t:1527189071302};\\\", \\\"{x:1413,y:961,t:1527189071358};\\\", \\\"{x:1413,y:963,t:1527189071398};\\\", \\\"{x:1414,y:963,t:1527189071599};\\\", \\\"{x:1415,y:963,t:1527189071621};\\\", \\\"{x:1416,y:963,t:1527189071637};\\\", \\\"{x:1417,y:961,t:1527189071654};\\\", \\\"{x:1418,y:959,t:1527189071669};\\\", \\\"{x:1418,y:958,t:1527189071686};\\\", \\\"{x:1418,y:957,t:1527189071702};\\\", \\\"{x:1419,y:955,t:1527189071719};\\\", \\\"{x:1419,y:954,t:1527189071737};\\\", \\\"{x:1419,y:952,t:1527189071754};\\\", \\\"{x:1420,y:951,t:1527189071769};\\\", \\\"{x:1420,y:948,t:1527189071786};\\\", \\\"{x:1420,y:944,t:1527189071803};\\\", \\\"{x:1420,y:936,t:1527189071819};\\\", \\\"{x:1420,y:926,t:1527189071836};\\\", \\\"{x:1420,y:915,t:1527189071854};\\\", \\\"{x:1420,y:914,t:1527189071870};\\\", \\\"{x:1420,y:912,t:1527189071887};\\\", \\\"{x:1420,y:911,t:1527189071904};\\\", \\\"{x:1419,y:910,t:1527189071919};\\\", \\\"{x:1419,y:909,t:1527189071937};\\\", \\\"{x:1419,y:905,t:1527189071953};\\\", \\\"{x:1419,y:901,t:1527189071970};\\\", \\\"{x:1417,y:897,t:1527189071987};\\\", \\\"{x:1417,y:895,t:1527189072003};\\\", \\\"{x:1416,y:893,t:1527189072019};\\\", \\\"{x:1416,y:890,t:1527189072036};\\\", \\\"{x:1414,y:886,t:1527189072053};\\\", \\\"{x:1414,y:885,t:1527189072069};\\\", \\\"{x:1414,y:884,t:1527189072086};\\\", \\\"{x:1413,y:884,t:1527189072494};\\\", \\\"{x:1412,y:884,t:1527189072518};\\\", \\\"{x:1411,y:884,t:1527189072526};\\\", \\\"{x:1409,y:884,t:1527189072537};\\\", \\\"{x:1408,y:885,t:1527189072553};\\\", \\\"{x:1406,y:888,t:1527189072571};\\\", \\\"{x:1403,y:893,t:1527189072587};\\\", \\\"{x:1401,y:897,t:1527189072603};\\\", \\\"{x:1398,y:901,t:1527189072621};\\\", \\\"{x:1393,y:906,t:1527189072638};\\\", \\\"{x:1390,y:909,t:1527189072654};\\\", \\\"{x:1389,y:911,t:1527189072670};\\\", \\\"{x:1388,y:913,t:1527189072687};\\\", \\\"{x:1387,y:913,t:1527189072703};\\\", \\\"{x:1386,y:915,t:1527189072720};\\\", \\\"{x:1385,y:917,t:1527189072742};\\\", \\\"{x:1384,y:917,t:1527189072753};\\\", \\\"{x:1383,y:919,t:1527189072770};\\\", \\\"{x:1383,y:921,t:1527189072788};\\\", \\\"{x:1382,y:923,t:1527189072803};\\\", \\\"{x:1380,y:926,t:1527189072820};\\\", \\\"{x:1377,y:930,t:1527189072838};\\\", \\\"{x:1373,y:936,t:1527189072853};\\\", \\\"{x:1369,y:941,t:1527189072870};\\\", \\\"{x:1366,y:945,t:1527189072887};\\\", \\\"{x:1364,y:946,t:1527189072904};\\\", \\\"{x:1363,y:947,t:1527189072921};\\\", \\\"{x:1363,y:944,t:1527189073326};\\\", \\\"{x:1363,y:941,t:1527189073337};\\\", \\\"{x:1364,y:933,t:1527189073354};\\\", \\\"{x:1365,y:925,t:1527189073370};\\\", \\\"{x:1367,y:918,t:1527189073387};\\\", \\\"{x:1367,y:915,t:1527189073405};\\\", \\\"{x:1367,y:912,t:1527189073422};\\\", \\\"{x:1367,y:911,t:1527189073437};\\\", \\\"{x:1367,y:910,t:1527189073455};\\\", \\\"{x:1367,y:908,t:1527189073471};\\\", \\\"{x:1367,y:907,t:1527189073487};\\\", \\\"{x:1367,y:906,t:1527189073504};\\\", \\\"{x:1367,y:905,t:1527189073522};\\\", \\\"{x:1367,y:904,t:1527189073538};\\\", \\\"{x:1367,y:903,t:1527189073558};\\\", \\\"{x:1367,y:902,t:1527189073571};\\\", \\\"{x:1367,y:901,t:1527189073587};\\\", \\\"{x:1367,y:897,t:1527189073604};\\\", \\\"{x:1362,y:885,t:1527189073621};\\\", \\\"{x:1361,y:879,t:1527189073638};\\\", \\\"{x:1361,y:876,t:1527189073654};\\\", \\\"{x:1360,y:876,t:1527189073958};\\\", \\\"{x:1359,y:876,t:1527189073971};\\\", \\\"{x:1357,y:877,t:1527189073988};\\\", \\\"{x:1356,y:879,t:1527189074004};\\\", \\\"{x:1353,y:886,t:1527189074022};\\\", \\\"{x:1351,y:889,t:1527189074037};\\\", \\\"{x:1349,y:896,t:1527189074054};\\\", \\\"{x:1348,y:899,t:1527189074072};\\\", \\\"{x:1346,y:903,t:1527189074089};\\\", \\\"{x:1344,y:909,t:1527189074104};\\\", \\\"{x:1343,y:912,t:1527189074121};\\\", \\\"{x:1340,y:917,t:1527189074138};\\\", \\\"{x:1339,y:922,t:1527189074155};\\\", \\\"{x:1337,y:928,t:1527189074172};\\\", \\\"{x:1336,y:933,t:1527189074189};\\\", \\\"{x:1335,y:939,t:1527189074204};\\\", \\\"{x:1333,y:949,t:1527189074221};\\\", \\\"{x:1333,y:953,t:1527189074238};\\\", \\\"{x:1333,y:957,t:1527189074255};\\\", \\\"{x:1333,y:959,t:1527189074271};\\\", \\\"{x:1333,y:961,t:1527189074289};\\\", \\\"{x:1333,y:962,t:1527189074326};\\\", \\\"{x:1332,y:962,t:1527189074374};\\\", \\\"{x:1331,y:962,t:1527189074388};\\\", \\\"{x:1331,y:961,t:1527189074405};\\\", \\\"{x:1331,y:955,t:1527189074421};\\\", \\\"{x:1331,y:948,t:1527189074438};\\\", \\\"{x:1331,y:937,t:1527189074456};\\\", \\\"{x:1331,y:922,t:1527189074471};\\\", \\\"{x:1331,y:904,t:1527189074488};\\\", \\\"{x:1331,y:893,t:1527189074505};\\\", \\\"{x:1331,y:887,t:1527189074522};\\\", \\\"{x:1331,y:884,t:1527189074538};\\\", \\\"{x:1331,y:880,t:1527189074555};\\\", \\\"{x:1331,y:875,t:1527189074571};\\\", \\\"{x:1330,y:869,t:1527189074589};\\\", \\\"{x:1328,y:859,t:1527189074606};\\\", \\\"{x:1328,y:858,t:1527189074646};\\\", \\\"{x:1328,y:857,t:1527189074655};\\\", \\\"{x:1328,y:855,t:1527189074671};\\\", \\\"{x:1328,y:851,t:1527189074688};\\\", \\\"{x:1327,y:844,t:1527189074705};\\\", \\\"{x:1327,y:839,t:1527189074721};\\\", \\\"{x:1327,y:835,t:1527189074738};\\\", \\\"{x:1327,y:832,t:1527189074755};\\\", \\\"{x:1327,y:828,t:1527189074773};\\\", \\\"{x:1327,y:822,t:1527189074788};\\\", \\\"{x:1327,y:814,t:1527189074806};\\\", \\\"{x:1327,y:807,t:1527189074821};\\\", \\\"{x:1326,y:799,t:1527189074838};\\\", \\\"{x:1326,y:788,t:1527189074855};\\\", \\\"{x:1326,y:776,t:1527189074873};\\\", \\\"{x:1326,y:767,t:1527189074888};\\\", \\\"{x:1326,y:761,t:1527189074905};\\\", \\\"{x:1326,y:753,t:1527189074922};\\\", \\\"{x:1326,y:747,t:1527189074938};\\\", \\\"{x:1326,y:742,t:1527189074955};\\\", \\\"{x:1326,y:733,t:1527189074972};\\\", \\\"{x:1326,y:727,t:1527189074988};\\\", \\\"{x:1325,y:717,t:1527189075005};\\\", \\\"{x:1325,y:713,t:1527189075022};\\\", \\\"{x:1324,y:711,t:1527189075039};\\\", \\\"{x:1324,y:709,t:1527189075055};\\\", \\\"{x:1324,y:708,t:1527189075073};\\\", \\\"{x:1324,y:706,t:1527189075158};\\\", \\\"{x:1326,y:705,t:1527189075172};\\\", \\\"{x:1333,y:703,t:1527189075190};\\\", \\\"{x:1341,y:699,t:1527189075205};\\\", \\\"{x:1345,y:698,t:1527189075222};\\\", \\\"{x:1347,y:696,t:1527189075238};\\\", \\\"{x:1349,y:696,t:1527189075255};\\\", \\\"{x:1350,y:695,t:1527189075271};\\\", \\\"{x:1350,y:694,t:1527189075550};\\\", \\\"{x:1342,y:694,t:1527189075559};\\\", \\\"{x:1331,y:692,t:1527189075572};\\\", \\\"{x:1290,y:681,t:1527189075589};\\\", \\\"{x:1252,y:673,t:1527189075606};\\\", \\\"{x:1211,y:664,t:1527189075621};\\\", \\\"{x:1148,y:647,t:1527189075639};\\\", \\\"{x:1063,y:628,t:1527189075656};\\\", \\\"{x:962,y:594,t:1527189075672};\\\", \\\"{x:863,y:570,t:1527189075689};\\\", \\\"{x:779,y:553,t:1527189075706};\\\", \\\"{x:721,y:547,t:1527189075722};\\\", \\\"{x:667,y:546,t:1527189075738};\\\", \\\"{x:614,y:538,t:1527189075756};\\\", \\\"{x:575,y:529,t:1527189075772};\\\", \\\"{x:559,y:525,t:1527189075789};\\\", \\\"{x:558,y:524,t:1527189075926};\\\", \\\"{x:561,y:522,t:1527189075949};\\\", \\\"{x:566,y:522,t:1527189075957};\\\", \\\"{x:575,y:522,t:1527189075973};\\\", \\\"{x:591,y:524,t:1527189075991};\\\", \\\"{x:606,y:528,t:1527189076006};\\\", \\\"{x:621,y:529,t:1527189076023};\\\", \\\"{x:638,y:529,t:1527189076039};\\\", \\\"{x:660,y:525,t:1527189076056};\\\", \\\"{x:682,y:522,t:1527189076073};\\\", \\\"{x:708,y:518,t:1527189076089};\\\", \\\"{x:731,y:518,t:1527189076106};\\\", \\\"{x:752,y:518,t:1527189076123};\\\", \\\"{x:761,y:517,t:1527189076140};\\\", \\\"{x:767,y:515,t:1527189076155};\\\", \\\"{x:770,y:514,t:1527189076173};\\\", \\\"{x:772,y:513,t:1527189076196};\\\", \\\"{x:773,y:513,t:1527189076212};\\\", \\\"{x:774,y:512,t:1527189076223};\\\", \\\"{x:779,y:511,t:1527189076240};\\\", \\\"{x:780,y:511,t:1527189076255};\\\", \\\"{x:784,y:510,t:1527189076273};\\\", \\\"{x:790,y:510,t:1527189076289};\\\", \\\"{x:800,y:510,t:1527189076305};\\\", \\\"{x:809,y:508,t:1527189076323};\\\", \\\"{x:821,y:505,t:1527189076339};\\\", \\\"{x:826,y:504,t:1527189076356};\\\", \\\"{x:827,y:503,t:1527189076373};\\\", \\\"{x:828,y:503,t:1527189076397};\\\", \\\"{x:830,y:503,t:1527189076413};\\\", \\\"{x:831,y:501,t:1527189076438};\\\", \\\"{x:832,y:501,t:1527189076445};\\\", \\\"{x:838,y:501,t:1527189076741};\\\", \\\"{x:860,y:513,t:1527189076757};\\\", \\\"{x:883,y:525,t:1527189076773};\\\", \\\"{x:906,y:538,t:1527189076790};\\\", \\\"{x:933,y:556,t:1527189076807};\\\", \\\"{x:959,y:575,t:1527189076823};\\\", \\\"{x:987,y:595,t:1527189076840};\\\", \\\"{x:1008,y:610,t:1527189076857};\\\", \\\"{x:1027,y:624,t:1527189076873};\\\", \\\"{x:1041,y:635,t:1527189076890};\\\", \\\"{x:1057,y:649,t:1527189076907};\\\", \\\"{x:1075,y:666,t:1527189076923};\\\", \\\"{x:1094,y:687,t:1527189076940};\\\", \\\"{x:1120,y:711,t:1527189076956};\\\", \\\"{x:1128,y:721,t:1527189076973};\\\", \\\"{x:1142,y:735,t:1527189076991};\\\", \\\"{x:1156,y:753,t:1527189077006};\\\", \\\"{x:1167,y:769,t:1527189077023};\\\", \\\"{x:1175,y:779,t:1527189077040};\\\", \\\"{x:1181,y:786,t:1527189077057};\\\", \\\"{x:1184,y:789,t:1527189077073};\\\", \\\"{x:1186,y:791,t:1527189077090};\\\", \\\"{x:1189,y:792,t:1527189077107};\\\", \\\"{x:1190,y:793,t:1527189077123};\\\", \\\"{x:1192,y:793,t:1527189077174};\\\", \\\"{x:1199,y:790,t:1527189077191};\\\", \\\"{x:1206,y:785,t:1527189077207};\\\", \\\"{x:1215,y:779,t:1527189077224};\\\", \\\"{x:1228,y:765,t:1527189077240};\\\", \\\"{x:1240,y:748,t:1527189077258};\\\", \\\"{x:1249,y:731,t:1527189077274};\\\", \\\"{x:1258,y:708,t:1527189077290};\\\", \\\"{x:1265,y:686,t:1527189077307};\\\", \\\"{x:1271,y:667,t:1527189077323};\\\", \\\"{x:1276,y:658,t:1527189077341};\\\", \\\"{x:1279,y:655,t:1527189077357};\\\", \\\"{x:1280,y:655,t:1527189077470};\\\", \\\"{x:1282,y:654,t:1527189077478};\\\", \\\"{x:1283,y:653,t:1527189077491};\\\", \\\"{x:1286,y:652,t:1527189077507};\\\", \\\"{x:1288,y:652,t:1527189077524};\\\", \\\"{x:1289,y:651,t:1527189077557};\\\", \\\"{x:1289,y:642,t:1527189080566};\\\", \\\"{x:1285,y:629,t:1527189080574};\\\", \\\"{x:1275,y:609,t:1527189080591};\\\", \\\"{x:1267,y:587,t:1527189080608};\\\", \\\"{x:1263,y:578,t:1527189080624};\\\", \\\"{x:1263,y:577,t:1527189080641};\\\", \\\"{x:1263,y:576,t:1527189080814};\\\", \\\"{x:1263,y:574,t:1527189080837};\\\", \\\"{x:1264,y:573,t:1527189080845};\\\", \\\"{x:1265,y:572,t:1527189080861};\\\", \\\"{x:1267,y:572,t:1527189080877};\\\", \\\"{x:1268,y:572,t:1527189080893};\\\", \\\"{x:1269,y:571,t:1527189080910};\\\", \\\"{x:1270,y:571,t:1527189080925};\\\", \\\"{x:1271,y:570,t:1527189080941};\\\", \\\"{x:1273,y:570,t:1527189080958};\\\", \\\"{x:1274,y:570,t:1527189080992};\\\", \\\"{x:1275,y:569,t:1527189081008};\\\", \\\"{x:1276,y:569,t:1527189081025};\\\", \\\"{x:1277,y:569,t:1527189081046};\\\", \\\"{x:1279,y:567,t:1527189081070};\\\", \\\"{x:1280,y:567,t:1527189082142};\\\", \\\"{x:1280,y:571,t:1527189082158};\\\", \\\"{x:1280,y:575,t:1527189082175};\\\", \\\"{x:1280,y:578,t:1527189082192};\\\", \\\"{x:1280,y:580,t:1527189082208};\\\", \\\"{x:1280,y:581,t:1527189082224};\\\", \\\"{x:1280,y:582,t:1527189082260};\\\", \\\"{x:1280,y:583,t:1527189082381};\\\", \\\"{x:1280,y:584,t:1527189085870};\\\", \\\"{x:1287,y:592,t:1527189085877};\\\", \\\"{x:1296,y:599,t:1527189085892};\\\", \\\"{x:1312,y:611,t:1527189085908};\\\", \\\"{x:1326,y:619,t:1527189085925};\\\", \\\"{x:1339,y:629,t:1527189085942};\\\", \\\"{x:1342,y:631,t:1527189085958};\\\", \\\"{x:1345,y:633,t:1527189085975};\\\", \\\"{x:1347,y:636,t:1527189085992};\\\", \\\"{x:1352,y:643,t:1527189086007};\\\", \\\"{x:1355,y:653,t:1527189086025};\\\", \\\"{x:1361,y:667,t:1527189086041};\\\", \\\"{x:1366,y:681,t:1527189086058};\\\", \\\"{x:1372,y:699,t:1527189086074};\\\", \\\"{x:1374,y:716,t:1527189086091};\\\", \\\"{x:1377,y:734,t:1527189086108};\\\", \\\"{x:1378,y:753,t:1527189086125};\\\", \\\"{x:1384,y:786,t:1527189086141};\\\", \\\"{x:1386,y:806,t:1527189086158};\\\", \\\"{x:1386,y:825,t:1527189086175};\\\", \\\"{x:1386,y:844,t:1527189086191};\\\", \\\"{x:1386,y:859,t:1527189086208};\\\", \\\"{x:1388,y:869,t:1527189086225};\\\", \\\"{x:1388,y:874,t:1527189086241};\\\", \\\"{x:1388,y:876,t:1527189086258};\\\", \\\"{x:1388,y:875,t:1527189086662};\\\", \\\"{x:1389,y:874,t:1527189086675};\\\", \\\"{x:1389,y:872,t:1527189086694};\\\", \\\"{x:1389,y:871,t:1527189086710};\\\", \\\"{x:1389,y:870,t:1527189086734};\\\", \\\"{x:1389,y:869,t:1527189086741};\\\", \\\"{x:1389,y:868,t:1527189086765};\\\", \\\"{x:1389,y:866,t:1527189086791};\\\", \\\"{x:1389,y:864,t:1527189086809};\\\", \\\"{x:1389,y:858,t:1527189086825};\\\", \\\"{x:1389,y:853,t:1527189086842};\\\", \\\"{x:1389,y:844,t:1527189086859};\\\", \\\"{x:1389,y:827,t:1527189086875};\\\", \\\"{x:1389,y:794,t:1527189086892};\\\", \\\"{x:1394,y:740,t:1527189086909};\\\", \\\"{x:1402,y:681,t:1527189086924};\\\", \\\"{x:1408,y:634,t:1527189086942};\\\", \\\"{x:1410,y:617,t:1527189086959};\\\", \\\"{x:1410,y:601,t:1527189086975};\\\", \\\"{x:1410,y:593,t:1527189086992};\\\", \\\"{x:1410,y:592,t:1527189087013};\\\", \\\"{x:1410,y:591,t:1527189087046};\\\", \\\"{x:1410,y:590,t:1527189087059};\\\", \\\"{x:1410,y:589,t:1527189087078};\\\", \\\"{x:1410,y:588,t:1527189087150};\\\", \\\"{x:1411,y:588,t:1527189087159};\\\", \\\"{x:1411,y:587,t:1527189087197};\\\", \\\"{x:1411,y:586,t:1527189087209};\\\", \\\"{x:1412,y:583,t:1527189087225};\\\", \\\"{x:1413,y:581,t:1527189087242};\\\", \\\"{x:1413,y:579,t:1527189087259};\\\", \\\"{x:1414,y:575,t:1527189087274};\\\", \\\"{x:1414,y:572,t:1527189087291};\\\", \\\"{x:1416,y:567,t:1527189087308};\\\", \\\"{x:1416,y:564,t:1527189087324};\\\", \\\"{x:1416,y:561,t:1527189087341};\\\", \\\"{x:1416,y:559,t:1527189087359};\\\", \\\"{x:1417,y:557,t:1527189087375};\\\", \\\"{x:1413,y:557,t:1527189093791};\\\", \\\"{x:1405,y:557,t:1527189093798};\\\", \\\"{x:1394,y:557,t:1527189093808};\\\", \\\"{x:1364,y:557,t:1527189093825};\\\", \\\"{x:1311,y:557,t:1527189093842};\\\", \\\"{x:1230,y:557,t:1527189093859};\\\", \\\"{x:1138,y:557,t:1527189093875};\\\", \\\"{x:1008,y:557,t:1527189093893};\\\", \\\"{x:927,y:557,t:1527189093909};\\\", \\\"{x:847,y:546,t:1527189093926};\\\", \\\"{x:776,y:532,t:1527189093943};\\\", \\\"{x:727,y:523,t:1527189093959};\\\", \\\"{x:671,y:505,t:1527189093988};\\\", \\\"{x:651,y:499,t:1527189094004};\\\", \\\"{x:633,y:491,t:1527189094021};\\\", \\\"{x:627,y:489,t:1527189094038};\\\", \\\"{x:626,y:489,t:1527189094060};\\\", \\\"{x:624,y:489,t:1527189094076};\\\", \\\"{x:622,y:490,t:1527189094088};\\\", \\\"{x:616,y:490,t:1527189094103};\\\", \\\"{x:600,y:495,t:1527189094121};\\\", \\\"{x:582,y:498,t:1527189094138};\\\", \\\"{x:567,y:500,t:1527189094154};\\\", \\\"{x:551,y:502,t:1527189094171};\\\", \\\"{x:537,y:505,t:1527189094187};\\\", \\\"{x:520,y:507,t:1527189094203};\\\", \\\"{x:481,y:516,t:1527189094221};\\\", \\\"{x:460,y:522,t:1527189094238};\\\", \\\"{x:430,y:530,t:1527189094254};\\\", \\\"{x:407,y:541,t:1527189094271};\\\", \\\"{x:386,y:551,t:1527189094288};\\\", \\\"{x:369,y:560,t:1527189094304};\\\", \\\"{x:356,y:566,t:1527189094321};\\\", \\\"{x:348,y:570,t:1527189094337};\\\", \\\"{x:345,y:572,t:1527189094354};\\\", \\\"{x:344,y:572,t:1527189094381};\\\", \\\"{x:343,y:572,t:1527189094404};\\\", \\\"{x:341,y:574,t:1527189094420};\\\", \\\"{x:340,y:574,t:1527189094437};\\\", \\\"{x:339,y:575,t:1527189094455};\\\", \\\"{x:337,y:577,t:1527189094470};\\\", \\\"{x:337,y:578,t:1527189094487};\\\", \\\"{x:337,y:582,t:1527189094504};\\\", \\\"{x:344,y:592,t:1527189094520};\\\", \\\"{x:361,y:605,t:1527189094539};\\\", \\\"{x:379,y:618,t:1527189094555};\\\", \\\"{x:397,y:628,t:1527189094571};\\\", \\\"{x:418,y:640,t:1527189094589};\\\", \\\"{x:451,y:664,t:1527189094604};\\\", \\\"{x:485,y:687,t:1527189094621};\\\", \\\"{x:512,y:704,t:1527189094638};\\\", \\\"{x:530,y:711,t:1527189094655};\\\", \\\"{x:542,y:716,t:1527189094670};\\\", \\\"{x:544,y:716,t:1527189094688};\\\", \\\"{x:545,y:714,t:1527189094758};\\\", \\\"{x:545,y:709,t:1527189094771};\\\", \\\"{x:531,y:690,t:1527189094789};\\\", \\\"{x:501,y:659,t:1527189094804};\\\", \\\"{x:451,y:619,t:1527189094821};\\\", \\\"{x:415,y:602,t:1527189094838};\\\", \\\"{x:372,y:587,t:1527189094856};\\\", \\\"{x:331,y:577,t:1527189094872};\\\", \\\"{x:296,y:570,t:1527189094888};\\\", \\\"{x:251,y:556,t:1527189094905};\\\", \\\"{x:208,y:541,t:1527189094922};\\\", \\\"{x:172,y:533,t:1527189094938};\\\", \\\"{x:143,y:525,t:1527189094955};\\\", \\\"{x:122,y:522,t:1527189094972};\\\", \\\"{x:111,y:521,t:1527189094987};\\\", \\\"{x:101,y:521,t:1527189095004};\\\", \\\"{x:99,y:521,t:1527189095020};\\\", \\\"{x:98,y:521,t:1527189095085};\\\", \\\"{x:99,y:521,t:1527189095125};\\\", \\\"{x:104,y:522,t:1527189095138};\\\", \\\"{x:119,y:529,t:1527189095156};\\\", \\\"{x:136,y:537,t:1527189095170};\\\", \\\"{x:154,y:545,t:1527189095188};\\\", \\\"{x:168,y:551,t:1527189095203};\\\", \\\"{x:182,y:558,t:1527189095222};\\\", \\\"{x:195,y:566,t:1527189095239};\\\", \\\"{x:216,y:578,t:1527189095255};\\\", \\\"{x:245,y:595,t:1527189095272};\\\", \\\"{x:274,y:603,t:1527189095288};\\\", \\\"{x:307,y:610,t:1527189095305};\\\", \\\"{x:336,y:619,t:1527189095321};\\\", \\\"{x:382,y:634,t:1527189095339};\\\", \\\"{x:422,y:641,t:1527189095355};\\\", \\\"{x:452,y:644,t:1527189095372};\\\", \\\"{x:487,y:647,t:1527189095388};\\\", \\\"{x:511,y:648,t:1527189095405};\\\", \\\"{x:538,y:648,t:1527189095421};\\\", \\\"{x:560,y:650,t:1527189095439};\\\", \\\"{x:576,y:650,t:1527189095455};\\\", \\\"{x:586,y:650,t:1527189095471};\\\", \\\"{x:590,y:650,t:1527189095488};\\\", \\\"{x:591,y:648,t:1527189095504};\\\", \\\"{x:594,y:646,t:1527189095522};\\\", \\\"{x:595,y:645,t:1527189095537};\\\", \\\"{x:602,y:643,t:1527189095555};\\\", \\\"{x:608,y:640,t:1527189095572};\\\", \\\"{x:614,y:636,t:1527189095588};\\\", \\\"{x:625,y:625,t:1527189095606};\\\", \\\"{x:628,y:619,t:1527189095621};\\\", \\\"{x:630,y:616,t:1527189095639};\\\", \\\"{x:633,y:613,t:1527189095655};\\\", \\\"{x:635,y:612,t:1527189095671};\\\", \\\"{x:637,y:611,t:1527189095689};\\\", \\\"{x:639,y:609,t:1527189095706};\\\", \\\"{x:640,y:609,t:1527189095724};\\\", \\\"{x:640,y:608,t:1527189095756};\\\", \\\"{x:640,y:607,t:1527189095773};\\\", \\\"{x:641,y:605,t:1527189095789};\\\", \\\"{x:642,y:604,t:1527189095806};\\\", \\\"{x:643,y:600,t:1527189095823};\\\", \\\"{x:644,y:599,t:1527189095839};\\\", \\\"{x:644,y:593,t:1527189095857};\\\", \\\"{x:639,y:586,t:1527189095872};\\\", \\\"{x:627,y:580,t:1527189095889};\\\", \\\"{x:618,y:576,t:1527189095907};\\\", \\\"{x:613,y:573,t:1527189095922};\\\", \\\"{x:611,y:572,t:1527189095939};\\\", \\\"{x:609,y:571,t:1527189095956};\\\", \\\"{x:606,y:574,t:1527189099157};\\\", \\\"{x:600,y:586,t:1527189099175};\\\", \\\"{x:595,y:603,t:1527189099194};\\\", \\\"{x:586,y:623,t:1527189099208};\\\", \\\"{x:575,y:647,t:1527189099225};\\\", \\\"{x:560,y:674,t:1527189099241};\\\", \\\"{x:545,y:697,t:1527189099258};\\\", \\\"{x:538,y:708,t:1527189099283};\\\", \\\"{x:534,y:715,t:1527189099299};\\\", \\\"{x:533,y:716,t:1527189099550};\\\", \\\"{x:525,y:724,t:1527189099569};\\\", \\\"{x:520,y:730,t:1527189099582};\\\", \\\"{x:517,y:733,t:1527189099600};\\\", \\\"{x:517,y:734,t:1527189099616};\\\", \\\"{x:516,y:734,t:1527189099633};\\\", \\\"{x:515,y:734,t:1527189099703};\\\", \\\"{x:515,y:733,t:1527189100062};\\\", \\\"{x:515,y:730,t:1527189100077};\\\", \\\"{x:514,y:730,t:1527189100085};\\\", \\\"{x:514,y:729,t:1527189100101};\\\", \\\"{x:514,y:727,t:1527189100118};\\\", \\\"{x:514,y:726,t:1527189100135};\\\", \\\"{x:512,y:723,t:1527189100151};\\\", \\\"{x:512,y:721,t:1527189100199};\\\", \\\"{x:511,y:721,t:1527189100230};\\\", \\\"{x:511,y:720,t:1527189100278};\\\", \\\"{x:511,y:719,t:1527189100335};\\\", \\\"{x:511,y:718,t:1527189100461};\\\" ] }, { \\\"rt\\\": 23282, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 504478, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:718,t:1527189105567};\\\", \\\"{x:535,y:723,t:1527189105575};\\\", \\\"{x:597,y:735,t:1527189105590};\\\", \\\"{x:670,y:749,t:1527189105605};\\\", \\\"{x:738,y:761,t:1527189105621};\\\", \\\"{x:805,y:772,t:1527189105639};\\\", \\\"{x:874,y:787,t:1527189105656};\\\", \\\"{x:930,y:806,t:1527189105672};\\\", \\\"{x:980,y:820,t:1527189105689};\\\", \\\"{x:1012,y:830,t:1527189105706};\\\", \\\"{x:1032,y:833,t:1527189105722};\\\", \\\"{x:1038,y:836,t:1527189105739};\\\", \\\"{x:1048,y:840,t:1527189105756};\\\", \\\"{x:1061,y:846,t:1527189105772};\\\", \\\"{x:1079,y:857,t:1527189105789};\\\", \\\"{x:1089,y:860,t:1527189105805};\\\", \\\"{x:1096,y:862,t:1527189105822};\\\", \\\"{x:1109,y:866,t:1527189105840};\\\", \\\"{x:1135,y:873,t:1527189105857};\\\", \\\"{x:1176,y:878,t:1527189105872};\\\", \\\"{x:1223,y:883,t:1527189105890};\\\", \\\"{x:1263,y:884,t:1527189105906};\\\", \\\"{x:1299,y:881,t:1527189105924};\\\", \\\"{x:1328,y:871,t:1527189105939};\\\", \\\"{x:1361,y:857,t:1527189105956};\\\", \\\"{x:1402,y:839,t:1527189105973};\\\", \\\"{x:1426,y:830,t:1527189105989};\\\", \\\"{x:1440,y:822,t:1527189106006};\\\", \\\"{x:1450,y:816,t:1527189106023};\\\", \\\"{x:1459,y:811,t:1527189106039};\\\", \\\"{x:1463,y:807,t:1527189106056};\\\", \\\"{x:1468,y:804,t:1527189106074};\\\", \\\"{x:1471,y:800,t:1527189106089};\\\", \\\"{x:1472,y:798,t:1527189106106};\\\", \\\"{x:1473,y:795,t:1527189106123};\\\", \\\"{x:1476,y:792,t:1527189106139};\\\", \\\"{x:1477,y:790,t:1527189106156};\\\", \\\"{x:1479,y:787,t:1527189106173};\\\", \\\"{x:1479,y:786,t:1527189106190};\\\", \\\"{x:1480,y:784,t:1527189106207};\\\", \\\"{x:1481,y:784,t:1527189106224};\\\", \\\"{x:1488,y:781,t:1527189106239};\\\", \\\"{x:1495,y:778,t:1527189106256};\\\", \\\"{x:1501,y:775,t:1527189106274};\\\", \\\"{x:1508,y:772,t:1527189106289};\\\", \\\"{x:1511,y:771,t:1527189106306};\\\", \\\"{x:1513,y:770,t:1527189106324};\\\", \\\"{x:1511,y:770,t:1527189107166};\\\", \\\"{x:1510,y:770,t:1527189107174};\\\", \\\"{x:1505,y:772,t:1527189107190};\\\", \\\"{x:1502,y:772,t:1527189107208};\\\", \\\"{x:1498,y:776,t:1527189107225};\\\", \\\"{x:1493,y:781,t:1527189107241};\\\", \\\"{x:1485,y:790,t:1527189107258};\\\", \\\"{x:1476,y:799,t:1527189107275};\\\", \\\"{x:1470,y:808,t:1527189107290};\\\", \\\"{x:1460,y:818,t:1527189107308};\\\", \\\"{x:1447,y:831,t:1527189107324};\\\", \\\"{x:1438,y:841,t:1527189107341};\\\", \\\"{x:1424,y:855,t:1527189107357};\\\", \\\"{x:1417,y:861,t:1527189107374};\\\", \\\"{x:1409,y:870,t:1527189107390};\\\", \\\"{x:1403,y:877,t:1527189107407};\\\", \\\"{x:1396,y:887,t:1527189107424};\\\", \\\"{x:1389,y:895,t:1527189107440};\\\", \\\"{x:1384,y:903,t:1527189107457};\\\", \\\"{x:1382,y:909,t:1527189107474};\\\", \\\"{x:1378,y:914,t:1527189107490};\\\", \\\"{x:1375,y:918,t:1527189107508};\\\", \\\"{x:1375,y:923,t:1527189107524};\\\", \\\"{x:1374,y:926,t:1527189107541};\\\", \\\"{x:1373,y:926,t:1527189107557};\\\", \\\"{x:1373,y:927,t:1527189107622};\\\", \\\"{x:1373,y:928,t:1527189107630};\\\", \\\"{x:1373,y:929,t:1527189107642};\\\", \\\"{x:1374,y:931,t:1527189107658};\\\", \\\"{x:1376,y:934,t:1527189107674};\\\", \\\"{x:1378,y:936,t:1527189107691};\\\", \\\"{x:1379,y:937,t:1527189107708};\\\", \\\"{x:1381,y:938,t:1527189107724};\\\", \\\"{x:1383,y:940,t:1527189107742};\\\", \\\"{x:1384,y:940,t:1527189107758};\\\", \\\"{x:1386,y:941,t:1527189107775};\\\", \\\"{x:1388,y:941,t:1527189107935};\\\", \\\"{x:1389,y:941,t:1527189107974};\\\", \\\"{x:1395,y:941,t:1527189107992};\\\", \\\"{x:1397,y:941,t:1527189108008};\\\", \\\"{x:1398,y:941,t:1527189108025};\\\", \\\"{x:1400,y:941,t:1527189108042};\\\", \\\"{x:1401,y:941,t:1527189108262};\\\", \\\"{x:1401,y:940,t:1527189108551};\\\", \\\"{x:1401,y:939,t:1527189108559};\\\", \\\"{x:1401,y:938,t:1527189108582};\\\", \\\"{x:1400,y:938,t:1527189108592};\\\", \\\"{x:1399,y:937,t:1527189108609};\\\", \\\"{x:1397,y:936,t:1527189108626};\\\", \\\"{x:1395,y:935,t:1527189108642};\\\", \\\"{x:1392,y:934,t:1527189108659};\\\", \\\"{x:1390,y:934,t:1527189108676};\\\", \\\"{x:1389,y:933,t:1527189108692};\\\", \\\"{x:1385,y:931,t:1527189108709};\\\", \\\"{x:1379,y:927,t:1527189108726};\\\", \\\"{x:1374,y:925,t:1527189108742};\\\", \\\"{x:1371,y:923,t:1527189108758};\\\", \\\"{x:1368,y:922,t:1527189108776};\\\", \\\"{x:1365,y:919,t:1527189108792};\\\", \\\"{x:1363,y:919,t:1527189108809};\\\", \\\"{x:1363,y:918,t:1527189108826};\\\", \\\"{x:1361,y:917,t:1527189108846};\\\", \\\"{x:1360,y:916,t:1527189108862};\\\", \\\"{x:1360,y:914,t:1527189109022};\\\", \\\"{x:1359,y:910,t:1527189109030};\\\", \\\"{x:1357,y:906,t:1527189109043};\\\", \\\"{x:1357,y:902,t:1527189109059};\\\", \\\"{x:1356,y:896,t:1527189109076};\\\", \\\"{x:1356,y:893,t:1527189109092};\\\", \\\"{x:1356,y:886,t:1527189109108};\\\", \\\"{x:1356,y:884,t:1527189109125};\\\", \\\"{x:1356,y:883,t:1527189109142};\\\", \\\"{x:1356,y:882,t:1527189109822};\\\", \\\"{x:1356,y:881,t:1527189109830};\\\", \\\"{x:1356,y:880,t:1527189109842};\\\", \\\"{x:1355,y:879,t:1527189109869};\\\", \\\"{x:1354,y:879,t:1527189109941};\\\", \\\"{x:1354,y:878,t:1527189109949};\\\", \\\"{x:1353,y:877,t:1527189110046};\\\", \\\"{x:1353,y:876,t:1527189110111};\\\", \\\"{x:1352,y:874,t:1527189110134};\\\", \\\"{x:1351,y:874,t:1527189110144};\\\", \\\"{x:1351,y:873,t:1527189110160};\\\", \\\"{x:1350,y:872,t:1527189110182};\\\", \\\"{x:1349,y:872,t:1527189110214};\\\", \\\"{x:1349,y:871,t:1527189110607};\\\", \\\"{x:1349,y:870,t:1527189110615};\\\", \\\"{x:1347,y:865,t:1527189110627};\\\", \\\"{x:1346,y:858,t:1527189110644};\\\", \\\"{x:1343,y:850,t:1527189110661};\\\", \\\"{x:1341,y:843,t:1527189110677};\\\", \\\"{x:1338,y:835,t:1527189110694};\\\", \\\"{x:1338,y:831,t:1527189110710};\\\", \\\"{x:1338,y:830,t:1527189110727};\\\", \\\"{x:1338,y:827,t:1527189110744};\\\", \\\"{x:1337,y:825,t:1527189110761};\\\", \\\"{x:1335,y:821,t:1527189110777};\\\", \\\"{x:1335,y:818,t:1527189110794};\\\", \\\"{x:1334,y:813,t:1527189110811};\\\", \\\"{x:1333,y:809,t:1527189110827};\\\", \\\"{x:1332,y:805,t:1527189110844};\\\", \\\"{x:1332,y:799,t:1527189110861};\\\", \\\"{x:1331,y:795,t:1527189110877};\\\", \\\"{x:1330,y:791,t:1527189110893};\\\", \\\"{x:1330,y:789,t:1527189110910};\\\", \\\"{x:1330,y:788,t:1527189110927};\\\", \\\"{x:1330,y:787,t:1527189110944};\\\", \\\"{x:1330,y:785,t:1527189110960};\\\", \\\"{x:1330,y:784,t:1527189110977};\\\", \\\"{x:1330,y:781,t:1527189110993};\\\", \\\"{x:1330,y:780,t:1527189111010};\\\", \\\"{x:1330,y:779,t:1527189111027};\\\", \\\"{x:1330,y:777,t:1527189111043};\\\", \\\"{x:1330,y:776,t:1527189111060};\\\", \\\"{x:1330,y:775,t:1527189111078};\\\", \\\"{x:1330,y:773,t:1527189111093};\\\", \\\"{x:1330,y:772,t:1527189111110};\\\", \\\"{x:1330,y:770,t:1527189111127};\\\", \\\"{x:1330,y:769,t:1527189111143};\\\", \\\"{x:1330,y:768,t:1527189111160};\\\", \\\"{x:1330,y:767,t:1527189111177};\\\", \\\"{x:1330,y:766,t:1527189111194};\\\", \\\"{x:1330,y:765,t:1527189111213};\\\", \\\"{x:1330,y:764,t:1527189111229};\\\", \\\"{x:1330,y:763,t:1527189111253};\\\", \\\"{x:1331,y:762,t:1527189111261};\\\", \\\"{x:1331,y:761,t:1527189111310};\\\", \\\"{x:1332,y:761,t:1527189111342};\\\", \\\"{x:1332,y:760,t:1527189111399};\\\", \\\"{x:1332,y:759,t:1527189111414};\\\", \\\"{x:1331,y:759,t:1527189111799};\\\", \\\"{x:1327,y:759,t:1527189111812};\\\", \\\"{x:1318,y:759,t:1527189111828};\\\", \\\"{x:1305,y:759,t:1527189111845};\\\", \\\"{x:1280,y:759,t:1527189111862};\\\", \\\"{x:1254,y:755,t:1527189111877};\\\", \\\"{x:1215,y:743,t:1527189111894};\\\", \\\"{x:1162,y:726,t:1527189111912};\\\", \\\"{x:1094,y:703,t:1527189111927};\\\", \\\"{x:1031,y:688,t:1527189111944};\\\", \\\"{x:968,y:674,t:1527189111961};\\\", \\\"{x:914,y:663,t:1527189111977};\\\", \\\"{x:859,y:648,t:1527189111994};\\\", \\\"{x:829,y:644,t:1527189112012};\\\", \\\"{x:807,y:640,t:1527189112028};\\\", \\\"{x:788,y:637,t:1527189112044};\\\", \\\"{x:760,y:636,t:1527189112061};\\\", \\\"{x:738,y:635,t:1527189112077};\\\", \\\"{x:722,y:633,t:1527189112094};\\\", \\\"{x:708,y:632,t:1527189112111};\\\", \\\"{x:692,y:630,t:1527189112130};\\\", \\\"{x:674,y:627,t:1527189112144};\\\", \\\"{x:656,y:620,t:1527189112162};\\\", \\\"{x:637,y:611,t:1527189112178};\\\", \\\"{x:609,y:602,t:1527189112194};\\\", \\\"{x:560,y:575,t:1527189112211};\\\", \\\"{x:500,y:551,t:1527189112227};\\\", \\\"{x:459,y:533,t:1527189112245};\\\", \\\"{x:406,y:515,t:1527189112261};\\\", \\\"{x:381,y:503,t:1527189112278};\\\", \\\"{x:360,y:495,t:1527189112294};\\\", \\\"{x:348,y:489,t:1527189112311};\\\", \\\"{x:344,y:487,t:1527189112327};\\\", \\\"{x:343,y:486,t:1527189112365};\\\", \\\"{x:343,y:485,t:1527189112421};\\\", \\\"{x:344,y:485,t:1527189112437};\\\", \\\"{x:345,y:484,t:1527189112445};\\\", \\\"{x:348,y:483,t:1527189112461};\\\", \\\"{x:350,y:483,t:1527189112478};\\\", \\\"{x:351,y:483,t:1527189112495};\\\", \\\"{x:352,y:481,t:1527189112512};\\\", \\\"{x:353,y:481,t:1527189112534};\\\", \\\"{x:354,y:481,t:1527189112558};\\\", \\\"{x:355,y:481,t:1527189112566};\\\", \\\"{x:357,y:480,t:1527189112578};\\\", \\\"{x:360,y:480,t:1527189112595};\\\", \\\"{x:363,y:480,t:1527189112612};\\\", \\\"{x:366,y:480,t:1527189112629};\\\", \\\"{x:368,y:480,t:1527189112645};\\\", \\\"{x:370,y:480,t:1527189112662};\\\", \\\"{x:370,y:481,t:1527189112814};\\\", \\\"{x:370,y:482,t:1527189112828};\\\", \\\"{x:366,y:484,t:1527189112845};\\\", \\\"{x:362,y:487,t:1527189112863};\\\", \\\"{x:357,y:491,t:1527189112878};\\\", \\\"{x:352,y:495,t:1527189112895};\\\", \\\"{x:347,y:497,t:1527189112911};\\\", \\\"{x:339,y:500,t:1527189112928};\\\", \\\"{x:327,y:505,t:1527189112944};\\\", \\\"{x:313,y:510,t:1527189112961};\\\", \\\"{x:300,y:515,t:1527189112978};\\\", \\\"{x:291,y:520,t:1527189112995};\\\", \\\"{x:280,y:529,t:1527189113012};\\\", \\\"{x:271,y:535,t:1527189113029};\\\", \\\"{x:262,y:541,t:1527189113044};\\\", \\\"{x:253,y:549,t:1527189113061};\\\", \\\"{x:249,y:554,t:1527189113079};\\\", \\\"{x:243,y:561,t:1527189113096};\\\", \\\"{x:242,y:564,t:1527189113112};\\\", \\\"{x:242,y:567,t:1527189113128};\\\", \\\"{x:242,y:571,t:1527189113144};\\\", \\\"{x:242,y:574,t:1527189113162};\\\", \\\"{x:244,y:579,t:1527189113179};\\\", \\\"{x:248,y:582,t:1527189113195};\\\", \\\"{x:251,y:583,t:1527189113212};\\\", \\\"{x:259,y:587,t:1527189113228};\\\", \\\"{x:272,y:593,t:1527189113245};\\\", \\\"{x:301,y:607,t:1527189113263};\\\", \\\"{x:323,y:613,t:1527189113279};\\\", \\\"{x:341,y:619,t:1527189113295};\\\", \\\"{x:362,y:623,t:1527189113312};\\\", \\\"{x:382,y:625,t:1527189113330};\\\", \\\"{x:407,y:625,t:1527189113345};\\\", \\\"{x:433,y:625,t:1527189113361};\\\", \\\"{x:456,y:625,t:1527189113378};\\\", \\\"{x:478,y:625,t:1527189113395};\\\", \\\"{x:502,y:621,t:1527189113413};\\\", \\\"{x:533,y:613,t:1527189113429};\\\", \\\"{x:576,y:603,t:1527189113445};\\\", \\\"{x:610,y:598,t:1527189113462};\\\", \\\"{x:635,y:591,t:1527189113479};\\\", \\\"{x:652,y:586,t:1527189113496};\\\", \\\"{x:666,y:580,t:1527189113513};\\\", \\\"{x:671,y:577,t:1527189113529};\\\", \\\"{x:675,y:576,t:1527189113545};\\\", \\\"{x:677,y:574,t:1527189113562};\\\", \\\"{x:681,y:573,t:1527189113578};\\\", \\\"{x:684,y:572,t:1527189113596};\\\", \\\"{x:687,y:570,t:1527189113612};\\\", \\\"{x:693,y:568,t:1527189113629};\\\", \\\"{x:710,y:562,t:1527189113647};\\\", \\\"{x:727,y:556,t:1527189113663};\\\", \\\"{x:749,y:550,t:1527189113681};\\\", \\\"{x:760,y:546,t:1527189113695};\\\", \\\"{x:767,y:544,t:1527189113712};\\\", \\\"{x:768,y:543,t:1527189113728};\\\", \\\"{x:768,y:542,t:1527189113765};\\\", \\\"{x:764,y:537,t:1527189113779};\\\", \\\"{x:749,y:529,t:1527189113796};\\\", \\\"{x:729,y:517,t:1527189113813};\\\", \\\"{x:702,y:503,t:1527189113830};\\\", \\\"{x:691,y:498,t:1527189113845};\\\", \\\"{x:687,y:496,t:1527189113862};\\\", \\\"{x:684,y:495,t:1527189113878};\\\", \\\"{x:682,y:493,t:1527189113896};\\\", \\\"{x:678,y:492,t:1527189113912};\\\", \\\"{x:676,y:491,t:1527189113928};\\\", \\\"{x:673,y:491,t:1527189113945};\\\", \\\"{x:671,y:490,t:1527189113963};\\\", \\\"{x:669,y:490,t:1527189113979};\\\", \\\"{x:667,y:490,t:1527189113995};\\\", \\\"{x:663,y:490,t:1527189114013};\\\", \\\"{x:655,y:494,t:1527189114028};\\\", \\\"{x:638,y:498,t:1527189114047};\\\", \\\"{x:623,y:503,t:1527189114063};\\\", \\\"{x:609,y:508,t:1527189114080};\\\", \\\"{x:592,y:511,t:1527189114096};\\\", \\\"{x:572,y:515,t:1527189114112};\\\", \\\"{x:553,y:520,t:1527189114130};\\\", \\\"{x:529,y:524,t:1527189114145};\\\", \\\"{x:507,y:526,t:1527189114163};\\\", \\\"{x:495,y:527,t:1527189114180};\\\", \\\"{x:477,y:527,t:1527189114195};\\\", \\\"{x:461,y:530,t:1527189114213};\\\", \\\"{x:443,y:532,t:1527189114229};\\\", \\\"{x:437,y:534,t:1527189114245};\\\", \\\"{x:430,y:535,t:1527189114263};\\\", \\\"{x:425,y:536,t:1527189114280};\\\", \\\"{x:421,y:538,t:1527189114295};\\\", \\\"{x:417,y:539,t:1527189114313};\\\", \\\"{x:411,y:541,t:1527189114329};\\\", \\\"{x:406,y:543,t:1527189114346};\\\", \\\"{x:400,y:547,t:1527189114362};\\\", \\\"{x:392,y:550,t:1527189114380};\\\", \\\"{x:385,y:554,t:1527189114396};\\\", \\\"{x:380,y:558,t:1527189114413};\\\", \\\"{x:370,y:563,t:1527189114431};\\\", \\\"{x:366,y:565,t:1527189114446};\\\", \\\"{x:362,y:567,t:1527189114462};\\\", \\\"{x:358,y:569,t:1527189114480};\\\", \\\"{x:354,y:572,t:1527189114496};\\\", \\\"{x:352,y:572,t:1527189114512};\\\", \\\"{x:349,y:574,t:1527189114529};\\\", \\\"{x:345,y:574,t:1527189114546};\\\", \\\"{x:341,y:574,t:1527189114563};\\\", \\\"{x:337,y:574,t:1527189114580};\\\", \\\"{x:332,y:574,t:1527189114596};\\\", \\\"{x:326,y:574,t:1527189114612};\\\", \\\"{x:317,y:574,t:1527189114629};\\\", \\\"{x:306,y:574,t:1527189114646};\\\", \\\"{x:293,y:574,t:1527189114662};\\\", \\\"{x:282,y:572,t:1527189114680};\\\", \\\"{x:271,y:570,t:1527189114698};\\\", \\\"{x:260,y:569,t:1527189114712};\\\", \\\"{x:251,y:567,t:1527189114729};\\\", \\\"{x:244,y:566,t:1527189114747};\\\", \\\"{x:238,y:565,t:1527189114763};\\\", \\\"{x:229,y:564,t:1527189114780};\\\", \\\"{x:220,y:561,t:1527189114798};\\\", \\\"{x:216,y:560,t:1527189114813};\\\", \\\"{x:215,y:560,t:1527189114829};\\\", \\\"{x:213,y:560,t:1527189114846};\\\", \\\"{x:208,y:558,t:1527189114863};\\\", \\\"{x:203,y:557,t:1527189114879};\\\", \\\"{x:193,y:553,t:1527189114897};\\\", \\\"{x:187,y:552,t:1527189114914};\\\", \\\"{x:180,y:550,t:1527189114930};\\\", \\\"{x:173,y:548,t:1527189114947};\\\", \\\"{x:166,y:546,t:1527189114963};\\\", \\\"{x:158,y:544,t:1527189114979};\\\", \\\"{x:149,y:539,t:1527189114996};\\\", \\\"{x:144,y:537,t:1527189115014};\\\", \\\"{x:142,y:535,t:1527189115030};\\\", \\\"{x:141,y:535,t:1527189115061};\\\", \\\"{x:140,y:535,t:1527189115077};\\\", \\\"{x:141,y:534,t:1527189115934};\\\", \\\"{x:143,y:534,t:1527189115947};\\\", \\\"{x:147,y:534,t:1527189115964};\\\", \\\"{x:151,y:535,t:1527189115980};\\\", \\\"{x:153,y:536,t:1527189115996};\\\", \\\"{x:156,y:536,t:1527189116237};\\\", \\\"{x:161,y:536,t:1527189116247};\\\", \\\"{x:177,y:535,t:1527189116264};\\\", \\\"{x:200,y:535,t:1527189116280};\\\", \\\"{x:220,y:535,t:1527189116298};\\\", \\\"{x:246,y:535,t:1527189116315};\\\", \\\"{x:276,y:541,t:1527189116331};\\\", \\\"{x:323,y:553,t:1527189116348};\\\", \\\"{x:379,y:570,t:1527189116366};\\\", \\\"{x:455,y:588,t:1527189116381};\\\", \\\"{x:579,y:630,t:1527189116399};\\\", \\\"{x:681,y:660,t:1527189116415};\\\", \\\"{x:789,y:690,t:1527189116430};\\\", \\\"{x:913,y:722,t:1527189116447};\\\", \\\"{x:1032,y:755,t:1527189116465};\\\", \\\"{x:1159,y:789,t:1527189116482};\\\", \\\"{x:1283,y:823,t:1527189116498};\\\", \\\"{x:1403,y:863,t:1527189116515};\\\", \\\"{x:1535,y:897,t:1527189116532};\\\", \\\"{x:1648,y:924,t:1527189116549};\\\", \\\"{x:1740,y:937,t:1527189116565};\\\", \\\"{x:1843,y:958,t:1527189116581};\\\", \\\"{x:1875,y:960,t:1527189116599};\\\", \\\"{x:1881,y:961,t:1527189116615};\\\", \\\"{x:1882,y:961,t:1527189116702};\\\", \\\"{x:1883,y:961,t:1527189116716};\\\", \\\"{x:1885,y:958,t:1527189116732};\\\", \\\"{x:1885,y:951,t:1527189116749};\\\", \\\"{x:1885,y:944,t:1527189116766};\\\", \\\"{x:1885,y:940,t:1527189116783};\\\", \\\"{x:1885,y:937,t:1527189116799};\\\", \\\"{x:1882,y:932,t:1527189116816};\\\", \\\"{x:1875,y:923,t:1527189116833};\\\", \\\"{x:1866,y:910,t:1527189116850};\\\", \\\"{x:1852,y:901,t:1527189116867};\\\", \\\"{x:1838,y:890,t:1527189116883};\\\", \\\"{x:1823,y:882,t:1527189116900};\\\", \\\"{x:1806,y:873,t:1527189116916};\\\", \\\"{x:1789,y:863,t:1527189116933};\\\", \\\"{x:1753,y:846,t:1527189116950};\\\", \\\"{x:1732,y:836,t:1527189116967};\\\", \\\"{x:1715,y:832,t:1527189116983};\\\", \\\"{x:1702,y:828,t:1527189117000};\\\", \\\"{x:1689,y:825,t:1527189117017};\\\", \\\"{x:1677,y:821,t:1527189117033};\\\", \\\"{x:1665,y:818,t:1527189117051};\\\", \\\"{x:1652,y:815,t:1527189117068};\\\", \\\"{x:1645,y:813,t:1527189117084};\\\", \\\"{x:1642,y:812,t:1527189117100};\\\", \\\"{x:1638,y:811,t:1527189117117};\\\", \\\"{x:1630,y:808,t:1527189117134};\\\", \\\"{x:1623,y:807,t:1527189117151};\\\", \\\"{x:1614,y:804,t:1527189117167};\\\", \\\"{x:1602,y:802,t:1527189117184};\\\", \\\"{x:1589,y:799,t:1527189117201};\\\", \\\"{x:1575,y:798,t:1527189117217};\\\", \\\"{x:1557,y:795,t:1527189117234};\\\", \\\"{x:1542,y:793,t:1527189117251};\\\", \\\"{x:1524,y:789,t:1527189117269};\\\", \\\"{x:1507,y:788,t:1527189117283};\\\", \\\"{x:1492,y:787,t:1527189117300};\\\", \\\"{x:1475,y:787,t:1527189117316};\\\", \\\"{x:1467,y:787,t:1527189117334};\\\", \\\"{x:1460,y:787,t:1527189117350};\\\", \\\"{x:1457,y:787,t:1527189117368};\\\", \\\"{x:1453,y:788,t:1527189117384};\\\", \\\"{x:1451,y:789,t:1527189117401};\\\", \\\"{x:1446,y:791,t:1527189117418};\\\", \\\"{x:1441,y:794,t:1527189117435};\\\", \\\"{x:1434,y:798,t:1527189117451};\\\", \\\"{x:1426,y:807,t:1527189117468};\\\", \\\"{x:1413,y:816,t:1527189117485};\\\", \\\"{x:1390,y:828,t:1527189117502};\\\", \\\"{x:1374,y:837,t:1527189117518};\\\", \\\"{x:1359,y:844,t:1527189117535};\\\", \\\"{x:1348,y:850,t:1527189117552};\\\", \\\"{x:1343,y:853,t:1527189117569};\\\", \\\"{x:1340,y:857,t:1527189117585};\\\", \\\"{x:1336,y:859,t:1527189117602};\\\", \\\"{x:1335,y:860,t:1527189117751};\\\", \\\"{x:1334,y:861,t:1527189117758};\\\", \\\"{x:1333,y:861,t:1527189117769};\\\", \\\"{x:1328,y:861,t:1527189117786};\\\", \\\"{x:1324,y:861,t:1527189117803};\\\", \\\"{x:1317,y:861,t:1527189117820};\\\", \\\"{x:1308,y:861,t:1527189117836};\\\", \\\"{x:1302,y:861,t:1527189117853};\\\", \\\"{x:1294,y:861,t:1527189117870};\\\", \\\"{x:1293,y:861,t:1527189117886};\\\", \\\"{x:1292,y:861,t:1527189117903};\\\", \\\"{x:1291,y:861,t:1527189117934};\\\", \\\"{x:1290,y:860,t:1527189117942};\\\", \\\"{x:1289,y:860,t:1527189117953};\\\", \\\"{x:1288,y:860,t:1527189117970};\\\", \\\"{x:1286,y:860,t:1527189117988};\\\", \\\"{x:1281,y:858,t:1527189118003};\\\", \\\"{x:1274,y:856,t:1527189118020};\\\", \\\"{x:1265,y:852,t:1527189118037};\\\", \\\"{x:1255,y:850,t:1527189118054};\\\", \\\"{x:1243,y:847,t:1527189118070};\\\", \\\"{x:1239,y:846,t:1527189118087};\\\", \\\"{x:1236,y:844,t:1527189118104};\\\", \\\"{x:1234,y:843,t:1527189118120};\\\", \\\"{x:1232,y:843,t:1527189118137};\\\", \\\"{x:1231,y:843,t:1527189118494};\\\", \\\"{x:1231,y:841,t:1527189118506};\\\", \\\"{x:1230,y:840,t:1527189118523};\\\", \\\"{x:1228,y:839,t:1527189118538};\\\", \\\"{x:1226,y:837,t:1527189118555};\\\", \\\"{x:1226,y:836,t:1527189118572};\\\", \\\"{x:1224,y:835,t:1527189118590};\\\", \\\"{x:1223,y:835,t:1527189118605};\\\", \\\"{x:1223,y:834,t:1527189118622};\\\", \\\"{x:1222,y:834,t:1527189118640};\\\", \\\"{x:1222,y:833,t:1527189118655};\\\", \\\"{x:1220,y:832,t:1527189118678};\\\", \\\"{x:1220,y:831,t:1527189118692};\\\", \\\"{x:1219,y:831,t:1527189118721};\\\", \\\"{x:1218,y:830,t:1527189119006};\\\", \\\"{x:1217,y:829,t:1527189119494};\\\", \\\"{x:1216,y:827,t:1527189119510};\\\", \\\"{x:1214,y:825,t:1527189119533};\\\", \\\"{x:1214,y:824,t:1527189119552};\\\", \\\"{x:1213,y:824,t:1527189119566};\\\", \\\"{x:1213,y:821,t:1527189120454};\\\", \\\"{x:1212,y:819,t:1527189120461};\\\", \\\"{x:1212,y:818,t:1527189120479};\\\", \\\"{x:1211,y:816,t:1527189120495};\\\", \\\"{x:1211,y:814,t:1527189120511};\\\", \\\"{x:1210,y:813,t:1527189120528};\\\", \\\"{x:1210,y:812,t:1527189120546};\\\", \\\"{x:1210,y:811,t:1527189120562};\\\", \\\"{x:1209,y:811,t:1527189120579};\\\", \\\"{x:1209,y:810,t:1527189120630};\\\", \\\"{x:1209,y:808,t:1527189120662};\\\", \\\"{x:1209,y:806,t:1527189120710};\\\", \\\"{x:1207,y:805,t:1527189120726};\\\", \\\"{x:1207,y:803,t:1527189120742};\\\", \\\"{x:1207,y:802,t:1527189120758};\\\", \\\"{x:1207,y:801,t:1527189120766};\\\", \\\"{x:1207,y:799,t:1527189120779};\\\", \\\"{x:1207,y:798,t:1527189120796};\\\", \\\"{x:1206,y:796,t:1527189120812};\\\", \\\"{x:1206,y:794,t:1527189120829};\\\", \\\"{x:1206,y:793,t:1527189120846};\\\", \\\"{x:1205,y:791,t:1527189120864};\\\", \\\"{x:1205,y:790,t:1527189120879};\\\", \\\"{x:1205,y:789,t:1527189120901};\\\", \\\"{x:1204,y:788,t:1527189120913};\\\", \\\"{x:1204,y:787,t:1527189120973};\\\", \\\"{x:1204,y:786,t:1527189120996};\\\", \\\"{x:1204,y:785,t:1527189121021};\\\", \\\"{x:1204,y:784,t:1527189121302};\\\", \\\"{x:1204,y:783,t:1527189121314};\\\", \\\"{x:1204,y:772,t:1527189121331};\\\", \\\"{x:1204,y:761,t:1527189121348};\\\", \\\"{x:1207,y:747,t:1527189121364};\\\", \\\"{x:1215,y:728,t:1527189121381};\\\", \\\"{x:1227,y:701,t:1527189121397};\\\", \\\"{x:1231,y:691,t:1527189121415};\\\", \\\"{x:1235,y:679,t:1527189121431};\\\", \\\"{x:1238,y:673,t:1527189121448};\\\", \\\"{x:1242,y:668,t:1527189121466};\\\", \\\"{x:1245,y:665,t:1527189121481};\\\", \\\"{x:1247,y:662,t:1527189121499};\\\", \\\"{x:1251,y:658,t:1527189121516};\\\", \\\"{x:1258,y:651,t:1527189121532};\\\", \\\"{x:1268,y:643,t:1527189121548};\\\", \\\"{x:1272,y:637,t:1527189121566};\\\", \\\"{x:1281,y:627,t:1527189121582};\\\", \\\"{x:1284,y:623,t:1527189121598};\\\", \\\"{x:1287,y:616,t:1527189121616};\\\", \\\"{x:1289,y:611,t:1527189121633};\\\", \\\"{x:1291,y:608,t:1527189121650};\\\", \\\"{x:1293,y:603,t:1527189121665};\\\", \\\"{x:1295,y:600,t:1527189121682};\\\", \\\"{x:1296,y:598,t:1527189121699};\\\", \\\"{x:1296,y:597,t:1527189121716};\\\", \\\"{x:1297,y:595,t:1527189121733};\\\", \\\"{x:1297,y:592,t:1527189121750};\\\", \\\"{x:1298,y:583,t:1527189121766};\\\", \\\"{x:1298,y:579,t:1527189121783};\\\", \\\"{x:1298,y:573,t:1527189121799};\\\", \\\"{x:1298,y:569,t:1527189121817};\\\", \\\"{x:1298,y:565,t:1527189121832};\\\", \\\"{x:1298,y:564,t:1527189121849};\\\", \\\"{x:1297,y:561,t:1527189121867};\\\", \\\"{x:1297,y:559,t:1527189121886};\\\", \\\"{x:1295,y:558,t:1527189121902};\\\", \\\"{x:1291,y:557,t:1527189123638};\\\", \\\"{x:1246,y:552,t:1527189123656};\\\", \\\"{x:1187,y:542,t:1527189123673};\\\", \\\"{x:1112,y:533,t:1527189123688};\\\", \\\"{x:1034,y:518,t:1527189123705};\\\", \\\"{x:956,y:507,t:1527189123722};\\\", \\\"{x:892,y:499,t:1527189123739};\\\", \\\"{x:844,y:499,t:1527189123755};\\\", \\\"{x:805,y:499,t:1527189123771};\\\", \\\"{x:775,y:505,t:1527189123787};\\\", \\\"{x:752,y:514,t:1527189123804};\\\", \\\"{x:724,y:529,t:1527189123820};\\\", \\\"{x:692,y:552,t:1527189123837};\\\", \\\"{x:673,y:566,t:1527189123854};\\\", \\\"{x:659,y:580,t:1527189123870};\\\", \\\"{x:643,y:592,t:1527189123886};\\\", \\\"{x:633,y:604,t:1527189123905};\\\", \\\"{x:623,y:616,t:1527189123920};\\\", \\\"{x:613,y:631,t:1527189123937};\\\", \\\"{x:604,y:642,t:1527189123954};\\\", \\\"{x:596,y:655,t:1527189123971};\\\", \\\"{x:591,y:669,t:1527189123987};\\\", \\\"{x:586,y:684,t:1527189124004};\\\", \\\"{x:581,y:700,t:1527189124021};\\\", \\\"{x:576,y:709,t:1527189124037};\\\", \\\"{x:571,y:721,t:1527189124054};\\\", \\\"{x:568,y:728,t:1527189124071};\\\", \\\"{x:567,y:733,t:1527189124087};\\\", \\\"{x:564,y:737,t:1527189124104};\\\", \\\"{x:562,y:739,t:1527189124121};\\\", \\\"{x:561,y:740,t:1527189124137};\\\", \\\"{x:560,y:741,t:1527189124154};\\\", \\\"{x:560,y:742,t:1527189124171};\\\", \\\"{x:559,y:743,t:1527189124187};\\\", \\\"{x:558,y:743,t:1527189124204};\\\", \\\"{x:557,y:744,t:1527189124221};\\\", \\\"{x:556,y:744,t:1527189124337};\\\", \\\"{x:556,y:744,t:1527189124442};\\\", \\\"{x:563,y:743,t:1527189124661};\\\", \\\"{x:574,y:739,t:1527189124671};\\\", \\\"{x:597,y:737,t:1527189124688};\\\", \\\"{x:623,y:735,t:1527189124704};\\\", \\\"{x:653,y:734,t:1527189124721};\\\", \\\"{x:693,y:734,t:1527189124738};\\\", \\\"{x:730,y:734,t:1527189124755};\\\", \\\"{x:772,y:734,t:1527189124771};\\\", \\\"{x:812,y:734,t:1527189124788};\\\", \\\"{x:834,y:737,t:1527189124805};\\\", \\\"{x:848,y:737,t:1527189124821};\\\", \\\"{x:852,y:737,t:1527189124838};\\\" ] }, { \\\"rt\\\": 43772, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 549509, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-04 PM-C -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:850,y:734,t:1527189127934};\\\", \\\"{x:841,y:725,t:1527189127942};\\\", \\\"{x:827,y:713,t:1527189127957};\\\", \\\"{x:813,y:704,t:1527189127974};\\\", \\\"{x:804,y:697,t:1527189127990};\\\", \\\"{x:799,y:694,t:1527189128007};\\\", \\\"{x:797,y:692,t:1527189128024};\\\", \\\"{x:794,y:692,t:1527189128040};\\\", \\\"{x:794,y:691,t:1527189128057};\\\", \\\"{x:793,y:691,t:1527189128085};\\\", \\\"{x:792,y:690,t:1527189128101};\\\", \\\"{x:791,y:689,t:1527189128144};\\\", \\\"{x:790,y:689,t:1527189128157};\\\", \\\"{x:789,y:688,t:1527189128174};\\\", \\\"{x:788,y:688,t:1527189128221};\\\", \\\"{x:788,y:687,t:1527189128229};\\\", \\\"{x:787,y:686,t:1527189128245};\\\", \\\"{x:786,y:685,t:1527189128294};\\\", \\\"{x:785,y:685,t:1527189128309};\\\", \\\"{x:785,y:684,t:1527189128333};\\\", \\\"{x:784,y:684,t:1527189128365};\\\", \\\"{x:783,y:684,t:1527189128406};\\\", \\\"{x:782,y:684,t:1527189128414};\\\", \\\"{x:782,y:683,t:1527189128424};\\\", \\\"{x:781,y:682,t:1527189128441};\\\", \\\"{x:781,y:681,t:1527189128502};\\\", \\\"{x:780,y:681,t:1527189128574};\\\", \\\"{x:779,y:680,t:1527189133126};\\\", \\\"{x:779,y:679,t:1527189133398};\\\", \\\"{x:784,y:679,t:1527189133411};\\\", \\\"{x:820,y:700,t:1527189133428};\\\", \\\"{x:885,y:732,t:1527189133445};\\\", \\\"{x:1019,y:791,t:1527189133461};\\\", \\\"{x:1117,y:829,t:1527189133479};\\\", \\\"{x:1215,y:861,t:1527189133494};\\\", \\\"{x:1317,y:902,t:1527189133511};\\\", \\\"{x:1423,y:943,t:1527189133528};\\\", \\\"{x:1513,y:976,t:1527189133544};\\\", \\\"{x:1598,y:1007,t:1527189133561};\\\", \\\"{x:1661,y:1031,t:1527189133578};\\\", \\\"{x:1689,y:1044,t:1527189133595};\\\", \\\"{x:1701,y:1049,t:1527189133611};\\\", \\\"{x:1703,y:1050,t:1527189133629};\\\", \\\"{x:1703,y:1048,t:1527189133742};\\\", \\\"{x:1697,y:1038,t:1527189133749};\\\", \\\"{x:1684,y:1027,t:1527189133762};\\\", \\\"{x:1665,y:1010,t:1527189133778};\\\", \\\"{x:1651,y:1000,t:1527189133796};\\\", \\\"{x:1642,y:994,t:1527189133812};\\\", \\\"{x:1630,y:989,t:1527189133829};\\\", \\\"{x:1614,y:984,t:1527189133846};\\\", \\\"{x:1604,y:982,t:1527189133861};\\\", \\\"{x:1596,y:980,t:1527189133879};\\\", \\\"{x:1590,y:980,t:1527189133896};\\\", \\\"{x:1585,y:980,t:1527189133912};\\\", \\\"{x:1583,y:980,t:1527189133929};\\\", \\\"{x:1578,y:981,t:1527189133946};\\\", \\\"{x:1572,y:985,t:1527189133962};\\\", \\\"{x:1566,y:989,t:1527189133979};\\\", \\\"{x:1559,y:993,t:1527189133996};\\\", \\\"{x:1551,y:998,t:1527189134012};\\\", \\\"{x:1542,y:1002,t:1527189134029};\\\", \\\"{x:1533,y:1007,t:1527189134045};\\\", \\\"{x:1528,y:1009,t:1527189134063};\\\", \\\"{x:1524,y:1010,t:1527189134079};\\\", \\\"{x:1520,y:1010,t:1527189134096};\\\", \\\"{x:1516,y:1010,t:1527189134113};\\\", \\\"{x:1509,y:1010,t:1527189134129};\\\", \\\"{x:1503,y:1010,t:1527189134146};\\\", \\\"{x:1496,y:1010,t:1527189134163};\\\", \\\"{x:1484,y:1004,t:1527189134179};\\\", \\\"{x:1472,y:999,t:1527189134196};\\\", \\\"{x:1464,y:993,t:1527189134213};\\\", \\\"{x:1453,y:986,t:1527189134229};\\\", \\\"{x:1444,y:984,t:1527189134245};\\\", \\\"{x:1443,y:982,t:1527189134263};\\\", \\\"{x:1442,y:981,t:1527189134285};\\\", \\\"{x:1441,y:981,t:1527189134295};\\\", \\\"{x:1441,y:980,t:1527189134313};\\\", \\\"{x:1440,y:979,t:1527189134328};\\\", \\\"{x:1440,y:978,t:1527189134429};\\\", \\\"{x:1440,y:976,t:1527189134446};\\\", \\\"{x:1440,y:974,t:1527189134463};\\\", \\\"{x:1440,y:973,t:1527189134480};\\\", \\\"{x:1440,y:972,t:1527189134496};\\\", \\\"{x:1440,y:971,t:1527189134513};\\\", \\\"{x:1440,y:969,t:1527189134530};\\\", \\\"{x:1440,y:968,t:1527189134614};\\\", \\\"{x:1440,y:967,t:1527189134638};\\\", \\\"{x:1440,y:966,t:1527189134646};\\\", \\\"{x:1440,y:965,t:1527189134678};\\\", \\\"{x:1440,y:964,t:1527189134694};\\\", \\\"{x:1440,y:963,t:1527189134702};\\\", \\\"{x:1440,y:962,t:1527189134726};\\\", \\\"{x:1440,y:961,t:1527189134750};\\\", \\\"{x:1440,y:960,t:1527189134799};\\\", \\\"{x:1439,y:959,t:1527189134813};\\\", \\\"{x:1439,y:958,t:1527189134830};\\\", \\\"{x:1438,y:956,t:1527189134846};\\\", \\\"{x:1438,y:955,t:1527189134863};\\\", \\\"{x:1437,y:954,t:1527189134880};\\\", \\\"{x:1437,y:952,t:1527189134896};\\\", \\\"{x:1436,y:949,t:1527189134913};\\\", \\\"{x:1436,y:948,t:1527189134930};\\\", \\\"{x:1436,y:946,t:1527189134947};\\\", \\\"{x:1434,y:943,t:1527189134963};\\\", \\\"{x:1434,y:941,t:1527189134980};\\\", \\\"{x:1433,y:938,t:1527189134997};\\\", \\\"{x:1432,y:934,t:1527189135013};\\\", \\\"{x:1429,y:923,t:1527189135030};\\\", \\\"{x:1428,y:916,t:1527189135047};\\\", \\\"{x:1427,y:909,t:1527189135063};\\\", \\\"{x:1426,y:901,t:1527189135080};\\\", \\\"{x:1425,y:894,t:1527189135097};\\\", \\\"{x:1424,y:890,t:1527189135113};\\\", \\\"{x:1424,y:886,t:1527189135130};\\\", \\\"{x:1424,y:880,t:1527189135148};\\\", \\\"{x:1424,y:874,t:1527189135163};\\\", \\\"{x:1423,y:869,t:1527189135180};\\\", \\\"{x:1422,y:865,t:1527189135197};\\\", \\\"{x:1422,y:861,t:1527189135213};\\\", \\\"{x:1422,y:853,t:1527189135230};\\\", \\\"{x:1422,y:849,t:1527189135247};\\\", \\\"{x:1422,y:844,t:1527189135262};\\\", \\\"{x:1422,y:841,t:1527189135279};\\\", \\\"{x:1422,y:837,t:1527189135297};\\\", \\\"{x:1422,y:834,t:1527189135313};\\\", \\\"{x:1422,y:830,t:1527189135330};\\\", \\\"{x:1422,y:827,t:1527189135346};\\\", \\\"{x:1422,y:826,t:1527189135362};\\\", \\\"{x:1422,y:825,t:1527189135380};\\\", \\\"{x:1421,y:823,t:1527189135446};\\\", \\\"{x:1421,y:822,t:1527189135485};\\\", \\\"{x:1421,y:821,t:1527189135501};\\\", \\\"{x:1420,y:820,t:1527189135513};\\\", \\\"{x:1420,y:819,t:1527189135533};\\\", \\\"{x:1420,y:818,t:1527189135547};\\\", \\\"{x:1419,y:817,t:1527189135563};\\\", \\\"{x:1419,y:816,t:1527189135580};\\\", \\\"{x:1419,y:815,t:1527189135597};\\\", \\\"{x:1419,y:812,t:1527189135613};\\\", \\\"{x:1419,y:810,t:1527189135630};\\\", \\\"{x:1418,y:807,t:1527189135647};\\\", \\\"{x:1418,y:806,t:1527189135664};\\\", \\\"{x:1418,y:803,t:1527189135680};\\\", \\\"{x:1418,y:800,t:1527189135697};\\\", \\\"{x:1418,y:799,t:1527189135713};\\\", \\\"{x:1416,y:795,t:1527189135729};\\\", \\\"{x:1416,y:791,t:1527189135746};\\\", \\\"{x:1416,y:789,t:1527189135764};\\\", \\\"{x:1416,y:787,t:1527189135780};\\\", \\\"{x:1416,y:783,t:1527189135797};\\\", \\\"{x:1416,y:780,t:1527189135813};\\\", \\\"{x:1416,y:778,t:1527189135831};\\\", \\\"{x:1416,y:776,t:1527189135846};\\\", \\\"{x:1416,y:773,t:1527189135864};\\\", \\\"{x:1416,y:771,t:1527189135881};\\\", \\\"{x:1416,y:769,t:1527189135897};\\\", \\\"{x:1416,y:766,t:1527189135914};\\\", \\\"{x:1416,y:763,t:1527189135931};\\\", \\\"{x:1416,y:759,t:1527189135947};\\\", \\\"{x:1416,y:753,t:1527189135964};\\\", \\\"{x:1416,y:749,t:1527189135981};\\\", \\\"{x:1416,y:745,t:1527189135997};\\\", \\\"{x:1416,y:739,t:1527189136013};\\\", \\\"{x:1416,y:737,t:1527189136031};\\\", \\\"{x:1416,y:735,t:1527189136047};\\\", \\\"{x:1416,y:733,t:1527189136064};\\\", \\\"{x:1417,y:731,t:1527189136081};\\\", \\\"{x:1417,y:729,t:1527189136097};\\\", \\\"{x:1417,y:728,t:1527189136114};\\\", \\\"{x:1417,y:727,t:1527189136131};\\\", \\\"{x:1418,y:725,t:1527189136147};\\\", \\\"{x:1418,y:723,t:1527189137030};\\\", \\\"{x:1426,y:713,t:1527189137048};\\\", \\\"{x:1435,y:706,t:1527189137064};\\\", \\\"{x:1447,y:697,t:1527189137081};\\\", \\\"{x:1462,y:686,t:1527189137098};\\\", \\\"{x:1473,y:677,t:1527189137114};\\\", \\\"{x:1484,y:670,t:1527189137131};\\\", \\\"{x:1492,y:664,t:1527189137148};\\\", \\\"{x:1495,y:662,t:1527189137165};\\\", \\\"{x:1497,y:660,t:1527189137182};\\\", \\\"{x:1497,y:659,t:1527189137270};\\\", \\\"{x:1496,y:658,t:1527189137286};\\\", \\\"{x:1494,y:657,t:1527189137302};\\\", \\\"{x:1493,y:657,t:1527189137318};\\\", \\\"{x:1491,y:655,t:1527189137332};\\\", \\\"{x:1487,y:654,t:1527189137348};\\\", \\\"{x:1484,y:652,t:1527189137365};\\\", \\\"{x:1481,y:650,t:1527189137382};\\\", \\\"{x:1478,y:648,t:1527189137399};\\\", \\\"{x:1475,y:647,t:1527189137415};\\\", \\\"{x:1471,y:645,t:1527189137432};\\\", \\\"{x:1469,y:644,t:1527189137448};\\\", \\\"{x:1468,y:644,t:1527189137465};\\\", \\\"{x:1466,y:643,t:1527189137483};\\\", \\\"{x:1465,y:642,t:1527189137498};\\\", \\\"{x:1464,y:642,t:1527189137518};\\\", \\\"{x:1463,y:641,t:1527189138414};\\\", \\\"{x:1460,y:641,t:1527189138438};\\\", \\\"{x:1459,y:639,t:1527189138449};\\\", \\\"{x:1453,y:638,t:1527189138466};\\\", \\\"{x:1450,y:638,t:1527189138482};\\\", \\\"{x:1447,y:638,t:1527189138499};\\\", \\\"{x:1446,y:638,t:1527189138516};\\\", \\\"{x:1443,y:637,t:1527189138533};\\\", \\\"{x:1441,y:636,t:1527189145054};\\\", \\\"{x:1435,y:634,t:1527189145071};\\\", \\\"{x:1431,y:631,t:1527189145087};\\\", \\\"{x:1429,y:631,t:1527189145104};\\\", \\\"{x:1428,y:630,t:1527189145121};\\\", \\\"{x:1428,y:629,t:1527189146799};\\\", \\\"{x:1428,y:628,t:1527189146806};\\\", \\\"{x:1432,y:627,t:1527189146823};\\\", \\\"{x:1433,y:625,t:1527189146840};\\\", \\\"{x:1434,y:625,t:1527189146856};\\\", \\\"{x:1435,y:624,t:1527189146872};\\\", \\\"{x:1436,y:624,t:1527189146941};\\\", \\\"{x:1436,y:623,t:1527189152998};\\\", \\\"{x:1406,y:618,t:1527189153011};\\\", \\\"{x:1294,y:596,t:1527189153028};\\\", \\\"{x:1159,y:566,t:1527189153044};\\\", \\\"{x:1020,y:542,t:1527189153061};\\\", \\\"{x:855,y:501,t:1527189153079};\\\", \\\"{x:823,y:496,t:1527189153094};\\\", \\\"{x:818,y:496,t:1527189153110};\\\", \\\"{x:816,y:496,t:1527189153127};\\\", \\\"{x:814,y:496,t:1527189153180};\\\", \\\"{x:805,y:505,t:1527189153195};\\\", \\\"{x:773,y:529,t:1527189153212};\\\", \\\"{x:728,y:562,t:1527189153228};\\\", \\\"{x:692,y:591,t:1527189153245};\\\", \\\"{x:660,y:631,t:1527189153262};\\\", \\\"{x:654,y:638,t:1527189153278};\\\", \\\"{x:654,y:639,t:1527189153308};\\\", \\\"{x:656,y:639,t:1527189153317};\\\", \\\"{x:660,y:639,t:1527189153327};\\\", \\\"{x:669,y:636,t:1527189153344};\\\", \\\"{x:678,y:634,t:1527189153361};\\\", \\\"{x:696,y:626,t:1527189153377};\\\", \\\"{x:713,y:619,t:1527189153394};\\\", \\\"{x:724,y:613,t:1527189153412};\\\", \\\"{x:733,y:608,t:1527189153428};\\\", \\\"{x:738,y:607,t:1527189153446};\\\", \\\"{x:741,y:604,t:1527189153461};\\\", \\\"{x:742,y:603,t:1527189153478};\\\", \\\"{x:743,y:601,t:1527189153495};\\\", \\\"{x:745,y:598,t:1527189153511};\\\", \\\"{x:748,y:592,t:1527189153529};\\\", \\\"{x:751,y:586,t:1527189153545};\\\", \\\"{x:755,y:579,t:1527189153562};\\\", \\\"{x:757,y:576,t:1527189153580};\\\", \\\"{x:761,y:572,t:1527189153594};\\\", \\\"{x:770,y:569,t:1527189153612};\\\", \\\"{x:781,y:565,t:1527189153628};\\\", \\\"{x:796,y:558,t:1527189153644};\\\", \\\"{x:803,y:554,t:1527189153661};\\\", \\\"{x:809,y:551,t:1527189153678};\\\", \\\"{x:812,y:548,t:1527189153695};\\\", \\\"{x:813,y:547,t:1527189153712};\\\", \\\"{x:814,y:546,t:1527189153729};\\\", \\\"{x:816,y:545,t:1527189153746};\\\", \\\"{x:817,y:545,t:1527189153761};\\\", \\\"{x:817,y:544,t:1527189153778};\\\", \\\"{x:819,y:543,t:1527189153795};\\\", \\\"{x:821,y:542,t:1527189153811};\\\", \\\"{x:822,y:541,t:1527189153829};\\\", \\\"{x:822,y:539,t:1527189153845};\\\", \\\"{x:823,y:538,t:1527189153862};\\\", \\\"{x:823,y:534,t:1527189153878};\\\", \\\"{x:823,y:531,t:1527189153895};\\\", \\\"{x:823,y:529,t:1527189153911};\\\", \\\"{x:823,y:528,t:1527189153928};\\\", \\\"{x:824,y:526,t:1527189153946};\\\", \\\"{x:825,y:525,t:1527189153961};\\\", \\\"{x:825,y:524,t:1527189153979};\\\", \\\"{x:825,y:522,t:1527189153996};\\\", \\\"{x:826,y:521,t:1527189154012};\\\", \\\"{x:827,y:520,t:1527189154028};\\\", \\\"{x:831,y:520,t:1527189154541};\\\", \\\"{x:844,y:530,t:1527189154550};\\\", \\\"{x:858,y:539,t:1527189154563};\\\", \\\"{x:887,y:558,t:1527189154578};\\\", \\\"{x:935,y:586,t:1527189154596};\\\", \\\"{x:1000,y:618,t:1527189154613};\\\", \\\"{x:1072,y:649,t:1527189154629};\\\", \\\"{x:1172,y:692,t:1527189154645};\\\", \\\"{x:1238,y:717,t:1527189154662};\\\", \\\"{x:1295,y:741,t:1527189154678};\\\", \\\"{x:1352,y:752,t:1527189154696};\\\", \\\"{x:1398,y:768,t:1527189154713};\\\", \\\"{x:1427,y:780,t:1527189154729};\\\", \\\"{x:1448,y:785,t:1527189154746};\\\", \\\"{x:1464,y:789,t:1527189154763};\\\", \\\"{x:1473,y:794,t:1527189154778};\\\", \\\"{x:1478,y:796,t:1527189154796};\\\", \\\"{x:1479,y:797,t:1527189154846};\\\", \\\"{x:1479,y:798,t:1527189154950};\\\", \\\"{x:1478,y:798,t:1527189154973};\\\", \\\"{x:1477,y:799,t:1527189154997};\\\", \\\"{x:1476,y:799,t:1527189155014};\\\", \\\"{x:1474,y:799,t:1527189155029};\\\", \\\"{x:1472,y:799,t:1527189155046};\\\", \\\"{x:1471,y:799,t:1527189155062};\\\", \\\"{x:1470,y:799,t:1527189155086};\\\", \\\"{x:1469,y:799,t:1527189155101};\\\", \\\"{x:1468,y:799,t:1527189155112};\\\", \\\"{x:1466,y:799,t:1527189155134};\\\", \\\"{x:1465,y:799,t:1527189155158};\\\", \\\"{x:1463,y:799,t:1527189155181};\\\", \\\"{x:1462,y:799,t:1527189155214};\\\", \\\"{x:1460,y:799,t:1527189155230};\\\", \\\"{x:1457,y:799,t:1527189155244};\\\", \\\"{x:1455,y:799,t:1527189155261};\\\", \\\"{x:1452,y:799,t:1527189155278};\\\", \\\"{x:1446,y:802,t:1527189155295};\\\", \\\"{x:1441,y:804,t:1527189155311};\\\", \\\"{x:1435,y:808,t:1527189155328};\\\", \\\"{x:1430,y:811,t:1527189155345};\\\", \\\"{x:1423,y:816,t:1527189155361};\\\", \\\"{x:1417,y:821,t:1527189155379};\\\", \\\"{x:1412,y:824,t:1527189155396};\\\", \\\"{x:1407,y:828,t:1527189155412};\\\", \\\"{x:1402,y:832,t:1527189155428};\\\", \\\"{x:1396,y:837,t:1527189155446};\\\", \\\"{x:1393,y:839,t:1527189155462};\\\", \\\"{x:1390,y:843,t:1527189155478};\\\", \\\"{x:1388,y:845,t:1527189155495};\\\", \\\"{x:1385,y:849,t:1527189155511};\\\", \\\"{x:1381,y:854,t:1527189155529};\\\", \\\"{x:1380,y:858,t:1527189155545};\\\", \\\"{x:1377,y:863,t:1527189155561};\\\", \\\"{x:1374,y:868,t:1527189155578};\\\", \\\"{x:1371,y:874,t:1527189155595};\\\", \\\"{x:1370,y:878,t:1527189155611};\\\", \\\"{x:1368,y:886,t:1527189155629};\\\", \\\"{x:1366,y:891,t:1527189155644};\\\", \\\"{x:1365,y:899,t:1527189155662};\\\", \\\"{x:1365,y:904,t:1527189155679};\\\", \\\"{x:1365,y:905,t:1527189155695};\\\", \\\"{x:1365,y:906,t:1527189155712};\\\", \\\"{x:1365,y:907,t:1527189155728};\\\", \\\"{x:1365,y:908,t:1527189155951};\\\", \\\"{x:1365,y:910,t:1527189155962};\\\", \\\"{x:1367,y:912,t:1527189155980};\\\", \\\"{x:1371,y:917,t:1527189155995};\\\", \\\"{x:1379,y:926,t:1527189156012};\\\", \\\"{x:1390,y:937,t:1527189156028};\\\", \\\"{x:1398,y:944,t:1527189156044};\\\", \\\"{x:1404,y:949,t:1527189156061};\\\", \\\"{x:1406,y:950,t:1527189156078};\\\", \\\"{x:1406,y:951,t:1527189156124};\\\", \\\"{x:1407,y:952,t:1527189156284};\\\", \\\"{x:1408,y:952,t:1527189156301};\\\", \\\"{x:1410,y:953,t:1527189156312};\\\", \\\"{x:1413,y:955,t:1527189156327};\\\", \\\"{x:1414,y:956,t:1527189156345};\\\", \\\"{x:1416,y:956,t:1527189156361};\\\", \\\"{x:1416,y:957,t:1527189156377};\\\", \\\"{x:1417,y:958,t:1527189156395};\\\", \\\"{x:1419,y:959,t:1527189156412};\\\", \\\"{x:1421,y:963,t:1527189156428};\\\", \\\"{x:1423,y:966,t:1527189156444};\\\", \\\"{x:1424,y:967,t:1527189156461};\\\", \\\"{x:1425,y:967,t:1527189156821};\\\", \\\"{x:1425,y:965,t:1527189156829};\\\", \\\"{x:1425,y:962,t:1527189156844};\\\", \\\"{x:1425,y:957,t:1527189156860};\\\", \\\"{x:1425,y:951,t:1527189156878};\\\", \\\"{x:1425,y:948,t:1527189156894};\\\", \\\"{x:1425,y:947,t:1527189156911};\\\", \\\"{x:1425,y:945,t:1527189156928};\\\", \\\"{x:1425,y:943,t:1527189156945};\\\", \\\"{x:1425,y:941,t:1527189156961};\\\", \\\"{x:1425,y:940,t:1527189156977};\\\", \\\"{x:1425,y:938,t:1527189156994};\\\", \\\"{x:1425,y:937,t:1527189157021};\\\", \\\"{x:1425,y:936,t:1527189157029};\\\", \\\"{x:1425,y:935,t:1527189157045};\\\", \\\"{x:1425,y:934,t:1527189157061};\\\", \\\"{x:1425,y:932,t:1527189157078};\\\", \\\"{x:1425,y:929,t:1527189157094};\\\", \\\"{x:1425,y:927,t:1527189157111};\\\", \\\"{x:1425,y:925,t:1527189157128};\\\", \\\"{x:1425,y:922,t:1527189157144};\\\", \\\"{x:1425,y:921,t:1527189157161};\\\", \\\"{x:1424,y:918,t:1527189157178};\\\", \\\"{x:1424,y:917,t:1527189157194};\\\", \\\"{x:1423,y:917,t:1527189157211};\\\", \\\"{x:1423,y:916,t:1527189157228};\\\", \\\"{x:1423,y:915,t:1527189157758};\\\", \\\"{x:1423,y:913,t:1527189158894};\\\", \\\"{x:1423,y:911,t:1527189158910};\\\", \\\"{x:1420,y:908,t:1527189158926};\\\", \\\"{x:1420,y:907,t:1527189158943};\\\", \\\"{x:1418,y:903,t:1527189158961};\\\", \\\"{x:1418,y:902,t:1527189158976};\\\", \\\"{x:1417,y:901,t:1527189158993};\\\", \\\"{x:1416,y:900,t:1527189159014};\\\", \\\"{x:1415,y:899,t:1527189162582};\\\", \\\"{x:1414,y:904,t:1527189162590};\\\", \\\"{x:1414,y:911,t:1527189162600};\\\", \\\"{x:1424,y:923,t:1527189162616};\\\", \\\"{x:1428,y:928,t:1527189162632};\\\", \\\"{x:1432,y:932,t:1527189162650};\\\", \\\"{x:1433,y:934,t:1527189162665};\\\", \\\"{x:1435,y:935,t:1527189162683};\\\", \\\"{x:1436,y:939,t:1527189162814};\\\", \\\"{x:1437,y:944,t:1527189162833};\\\", \\\"{x:1439,y:949,t:1527189162849};\\\", \\\"{x:1439,y:950,t:1527189162871};\\\", \\\"{x:1439,y:951,t:1527189162883};\\\", \\\"{x:1439,y:954,t:1527189162899};\\\", \\\"{x:1440,y:959,t:1527189162916};\\\", \\\"{x:1441,y:965,t:1527189162933};\\\", \\\"{x:1443,y:970,t:1527189162948};\\\", \\\"{x:1443,y:973,t:1527189162966};\\\", \\\"{x:1444,y:973,t:1527189163319};\\\", \\\"{x:1444,y:972,t:1527189163332};\\\", \\\"{x:1445,y:963,t:1527189163349};\\\", \\\"{x:1447,y:949,t:1527189163367};\\\", \\\"{x:1448,y:937,t:1527189163382};\\\", \\\"{x:1449,y:927,t:1527189163399};\\\", \\\"{x:1449,y:918,t:1527189163417};\\\", \\\"{x:1449,y:908,t:1527189163432};\\\", \\\"{x:1449,y:894,t:1527189163449};\\\", \\\"{x:1449,y:886,t:1527189163465};\\\", \\\"{x:1449,y:881,t:1527189163481};\\\", \\\"{x:1449,y:877,t:1527189163499};\\\", \\\"{x:1449,y:873,t:1527189163515};\\\", \\\"{x:1449,y:866,t:1527189163532};\\\", \\\"{x:1449,y:856,t:1527189163549};\\\", \\\"{x:1449,y:845,t:1527189163566};\\\", \\\"{x:1449,y:842,t:1527189163581};\\\", \\\"{x:1449,y:840,t:1527189163598};\\\", \\\"{x:1449,y:837,t:1527189163615};\\\", \\\"{x:1448,y:833,t:1527189163632};\\\", \\\"{x:1447,y:828,t:1527189163649};\\\", \\\"{x:1447,y:819,t:1527189163666};\\\", \\\"{x:1444,y:811,t:1527189163681};\\\", \\\"{x:1442,y:798,t:1527189163699};\\\", \\\"{x:1439,y:777,t:1527189163716};\\\", \\\"{x:1438,y:763,t:1527189163732};\\\", \\\"{x:1436,y:754,t:1527189163749};\\\", \\\"{x:1436,y:747,t:1527189163765};\\\", \\\"{x:1434,y:739,t:1527189163782};\\\", \\\"{x:1434,y:734,t:1527189163798};\\\", \\\"{x:1434,y:731,t:1527189163815};\\\", \\\"{x:1434,y:723,t:1527189163831};\\\", \\\"{x:1433,y:718,t:1527189163849};\\\", \\\"{x:1432,y:705,t:1527189163865};\\\", \\\"{x:1428,y:695,t:1527189163882};\\\", \\\"{x:1425,y:686,t:1527189163899};\\\", \\\"{x:1422,y:677,t:1527189163915};\\\", \\\"{x:1420,y:669,t:1527189163932};\\\", \\\"{x:1419,y:661,t:1527189163949};\\\", \\\"{x:1418,y:655,t:1527189163965};\\\", \\\"{x:1416,y:649,t:1527189163982};\\\", \\\"{x:1416,y:645,t:1527189163998};\\\", \\\"{x:1415,y:641,t:1527189164015};\\\", \\\"{x:1415,y:640,t:1527189164038};\\\", \\\"{x:1415,y:639,t:1527189164055};\\\", \\\"{x:1415,y:638,t:1527189164078};\\\", \\\"{x:1416,y:637,t:1527189164303};\\\", \\\"{x:1418,y:636,t:1527189164316};\\\", \\\"{x:1421,y:635,t:1527189164333};\\\", \\\"{x:1423,y:634,t:1527189164348};\\\", \\\"{x:1424,y:634,t:1527189164367};\\\", \\\"{x:1427,y:633,t:1527189164382};\\\", \\\"{x:1428,y:632,t:1527189164398};\\\", \\\"{x:1429,y:631,t:1527189164415};\\\", \\\"{x:1432,y:631,t:1527189164432};\\\", \\\"{x:1434,y:629,t:1527189164448};\\\", \\\"{x:1435,y:629,t:1527189164471};\\\", \\\"{x:1436,y:629,t:1527189164482};\\\", \\\"{x:1437,y:629,t:1527189164687};\\\", \\\"{x:1439,y:628,t:1527189164710};\\\", \\\"{x:1441,y:627,t:1527189164743};\\\", \\\"{x:1442,y:627,t:1527189164783};\\\", \\\"{x:1444,y:627,t:1527189164921};\\\", \\\"{x:1445,y:627,t:1527189164931};\\\", \\\"{x:1451,y:636,t:1527189164948};\\\", \\\"{x:1456,y:649,t:1527189164965};\\\", \\\"{x:1461,y:662,t:1527189164981};\\\", \\\"{x:1466,y:684,t:1527189164997};\\\", \\\"{x:1470,y:697,t:1527189165014};\\\", \\\"{x:1471,y:711,t:1527189165031};\\\", \\\"{x:1472,y:723,t:1527189165047};\\\", \\\"{x:1474,y:735,t:1527189165064};\\\", \\\"{x:1474,y:748,t:1527189165080};\\\", \\\"{x:1476,y:764,t:1527189165098};\\\", \\\"{x:1476,y:776,t:1527189165115};\\\", \\\"{x:1477,y:788,t:1527189165131};\\\", \\\"{x:1477,y:796,t:1527189165148};\\\", \\\"{x:1477,y:803,t:1527189165165};\\\", \\\"{x:1477,y:809,t:1527189165181};\\\", \\\"{x:1477,y:822,t:1527189165198};\\\", \\\"{x:1477,y:827,t:1527189165215};\\\", \\\"{x:1477,y:829,t:1527189165231};\\\", \\\"{x:1477,y:830,t:1527189165248};\\\", \\\"{x:1477,y:831,t:1527189165264};\\\", \\\"{x:1477,y:835,t:1527189165558};\\\", \\\"{x:1477,y:841,t:1527189165565};\\\", \\\"{x:1477,y:848,t:1527189165581};\\\", \\\"{x:1477,y:871,t:1527189165598};\\\", \\\"{x:1477,y:890,t:1527189165614};\\\", \\\"{x:1477,y:908,t:1527189165630};\\\", \\\"{x:1477,y:927,t:1527189165648};\\\", \\\"{x:1477,y:942,t:1527189165664};\\\", \\\"{x:1477,y:952,t:1527189165681};\\\", \\\"{x:1477,y:959,t:1527189165698};\\\", \\\"{x:1477,y:964,t:1527189165714};\\\", \\\"{x:1477,y:961,t:1527189167951};\\\", \\\"{x:1474,y:954,t:1527189167964};\\\", \\\"{x:1472,y:946,t:1527189167980};\\\", \\\"{x:1469,y:936,t:1527189167997};\\\", \\\"{x:1465,y:927,t:1527189168014};\\\", \\\"{x:1460,y:916,t:1527189168030};\\\", \\\"{x:1457,y:907,t:1527189168046};\\\", \\\"{x:1456,y:905,t:1527189168064};\\\", \\\"{x:1456,y:903,t:1527189168078};\\\", \\\"{x:1455,y:902,t:1527189168096};\\\", \\\"{x:1455,y:901,t:1527189168117};\\\", \\\"{x:1454,y:901,t:1527189168129};\\\", \\\"{x:1453,y:900,t:1527189168149};\\\", \\\"{x:1453,y:899,t:1527189168162};\\\", \\\"{x:1452,y:898,t:1527189168181};\\\", \\\"{x:1452,y:896,t:1527189168198};\\\", \\\"{x:1451,y:896,t:1527189168212};\\\", \\\"{x:1450,y:895,t:1527189168229};\\\", \\\"{x:1449,y:892,t:1527189168245};\\\", \\\"{x:1446,y:890,t:1527189168262};\\\", \\\"{x:1439,y:884,t:1527189168279};\\\", \\\"{x:1433,y:878,t:1527189168296};\\\", \\\"{x:1423,y:869,t:1527189168312};\\\", \\\"{x:1414,y:862,t:1527189168329};\\\", \\\"{x:1401,y:854,t:1527189168346};\\\", \\\"{x:1384,y:843,t:1527189168362};\\\", \\\"{x:1373,y:835,t:1527189168379};\\\", \\\"{x:1350,y:818,t:1527189168396};\\\", \\\"{x:1324,y:805,t:1527189168412};\\\", \\\"{x:1288,y:788,t:1527189168430};\\\", \\\"{x:1213,y:760,t:1527189168446};\\\", \\\"{x:1163,y:737,t:1527189168462};\\\", \\\"{x:1112,y:721,t:1527189168479};\\\", \\\"{x:1063,y:702,t:1527189168496};\\\", \\\"{x:1016,y:682,t:1527189168513};\\\", \\\"{x:961,y:661,t:1527189168529};\\\", \\\"{x:913,y:645,t:1527189168547};\\\", \\\"{x:878,y:633,t:1527189168562};\\\", \\\"{x:849,y:624,t:1527189168579};\\\", \\\"{x:811,y:610,t:1527189168598};\\\", \\\"{x:787,y:604,t:1527189168615};\\\", \\\"{x:761,y:597,t:1527189168632};\\\", \\\"{x:738,y:592,t:1527189168649};\\\", \\\"{x:724,y:589,t:1527189168666};\\\", \\\"{x:708,y:589,t:1527189168684};\\\", \\\"{x:691,y:589,t:1527189168698};\\\", \\\"{x:679,y:589,t:1527189168715};\\\", \\\"{x:668,y:593,t:1527189168733};\\\", \\\"{x:658,y:598,t:1527189168749};\\\", \\\"{x:638,y:613,t:1527189168766};\\\", \\\"{x:620,y:623,t:1527189168784};\\\", \\\"{x:603,y:632,t:1527189168799};\\\", \\\"{x:581,y:644,t:1527189168817};\\\", \\\"{x:566,y:650,t:1527189168833};\\\", \\\"{x:552,y:660,t:1527189168850};\\\", \\\"{x:539,y:667,t:1527189168866};\\\", \\\"{x:531,y:672,t:1527189168882};\\\", \\\"{x:522,y:677,t:1527189168899};\\\", \\\"{x:513,y:683,t:1527189168916};\\\", \\\"{x:506,y:687,t:1527189168933};\\\", \\\"{x:494,y:697,t:1527189168949};\\\", \\\"{x:486,y:705,t:1527189168966};\\\", \\\"{x:480,y:709,t:1527189168983};\\\", \\\"{x:477,y:710,t:1527189169000};\\\", \\\"{x:473,y:712,t:1527189169016};\\\", \\\"{x:472,y:714,t:1527189169033};\\\", \\\"{x:472,y:715,t:1527189169054};\\\", \\\"{x:471,y:717,t:1527189169066};\\\", \\\"{x:470,y:720,t:1527189169083};\\\", \\\"{x:470,y:722,t:1527189169100};\\\", \\\"{x:468,y:725,t:1527189169116};\\\", \\\"{x:466,y:727,t:1527189169133};\\\", \\\"{x:466,y:729,t:1527189169150};\\\", \\\"{x:466,y:730,t:1527189169174};\\\", \\\"{x:466,y:732,t:1527189169199};\\\", \\\"{x:466,y:733,t:1527189169206};\\\", \\\"{x:466,y:735,t:1527189169218};\\\", \\\"{x:466,y:740,t:1527189169232};\\\", \\\"{x:466,y:744,t:1527189169249};\\\", \\\"{x:466,y:746,t:1527189169266};\\\" ] }, { \\\"rt\\\": 22502, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 573245, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look on the horizontal axis and go vertical \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8239, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Vietnam\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 582491, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14145, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 597650, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 13063, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 611802, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"XKNWZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"XKNWZ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 155, dom: 1428, initialDom: 1502",
  "javascriptErrors": []
}