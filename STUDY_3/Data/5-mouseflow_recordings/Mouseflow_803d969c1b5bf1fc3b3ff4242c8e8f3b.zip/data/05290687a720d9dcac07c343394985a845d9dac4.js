var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05290687a720d9dcac07c343394985a845d9dac4"] = {
  "startTime": "2018-05-29T17:02:06.6053202Z",
  "websitePageUrl": "/",
  "visitTime": 165204,
  "engagementTime": 71214,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "803d969c1b5bf1fc3b3ff4242c8e8f3b",
    "created": "2018-05-29T17:02:06.5633843+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6d8204847ddbaed6e7159eeb38e54340",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/803d969c1b5bf1fc3b3ff4242c8e8f3b/play"
  },
  "events": [
    {
      "t": 7,
      "e": 7,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 2299,
      "e": 2299,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 912,
      "y": 598
    },
    {
      "t": 2950,
      "e": 2950,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 909,
      "y": 1049
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 31028,
      "y": 63344,
      "ta": "html > body"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 1083,
      "y": 1000
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 38966,
      "y": 56810,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 1063,
      "y": 807
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 1062,
      "y": 806
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 1054,
      "y": 814
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 37928,
      "y": 54680,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 1053,
      "y": 815
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 37873,
      "y": 54762,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 8750,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 16700,
      "e": 8750,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 16750,
      "e": 8800,
      "ty": 41,
      "x": 37873,
      "y": 55827,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16800,
      "e": 8850,
      "ty": 2,
      "x": 1053,
      "y": 881
    },
    {
      "t": 29999,
      "e": 13850,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34116,
      "e": 13850,
      "ty": 3,
      "x": 1053,
      "y": 881,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34213,
      "e": 13947,
      "ty": 4,
      "x": 37873,
      "y": 55827,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34213,
      "e": 13947,
      "ty": 5,
      "x": 1053,
      "y": 881,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 35199,
      "e": 14933,
      "ty": 1,
      "x": 0,
      "y": 3
    },
    {
      "t": 35300,
      "e": 15034,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 36700,
      "e": 16434,
      "ty": 2,
      "x": 514,
      "y": 236
    },
    {
      "t": 36750,
      "e": 16484,
      "ty": 41,
      "x": 15496,
      "y": 6093,
      "ta": "html > body"
    },
    {
      "t": 36800,
      "e": 16534,
      "ty": 2,
      "x": 456,
      "y": 85
    },
    {
      "t": 36900,
      "e": 16634,
      "ty": 2,
      "x": 667,
      "y": 459
    },
    {
      "t": 37000,
      "e": 16734,
      "ty": 2,
      "x": 976,
      "y": 955
    },
    {
      "t": 37000,
      "e": 16734,
      "ty": 41,
      "x": 33668,
      "y": 61889,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37100,
      "e": 16834,
      "ty": 2,
      "x": 1081,
      "y": 1067
    },
    {
      "t": 37200,
      "e": 16934,
      "ty": 2,
      "x": 942,
      "y": 899
    },
    {
      "t": 37250,
      "e": 16984,
      "ty": 41,
      "x": 27606,
      "y": 45178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37300,
      "e": 17034,
      "ty": 2,
      "x": 833,
      "y": 660
    },
    {
      "t": 37400,
      "e": 17134,
      "ty": 2,
      "x": 825,
      "y": 532
    },
    {
      "t": 37500,
      "e": 17234,
      "ty": 2,
      "x": 818,
      "y": 521
    },
    {
      "t": 37500,
      "e": 17234,
      "ty": 41,
      "x": 25039,
      "y": 26336,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37533,
      "e": 17267,
      "ty": 3,
      "x": 818,
      "y": 521,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37620,
      "e": 17354,
      "ty": 4,
      "x": 25039,
      "y": 26336,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37620,
      "e": 17354,
      "ty": 5,
      "x": 818,
      "y": 521,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37700,
      "e": 17434,
      "ty": 2,
      "x": 738,
      "y": 526
    },
    {
      "t": 37750,
      "e": 17484,
      "ty": 41,
      "x": 1720,
      "y": 26828,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37800,
      "e": 17534,
      "ty": 2,
      "x": 346,
      "y": 533
    },
    {
      "t": 37900,
      "e": 17634,
      "ty": 2,
      "x": 347,
      "y": 535
    },
    {
      "t": 38000,
      "e": 17734,
      "ty": 2,
      "x": 543,
      "y": 626
    },
    {
      "t": 38001,
      "e": 17735,
      "ty": 41,
      "x": 10021,
      "y": 34938,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38100,
      "e": 17834,
      "ty": 2,
      "x": 710,
      "y": 647
    },
    {
      "t": 38150,
      "e": 17884,
      "ty": 3,
      "x": 711,
      "y": 647,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38200,
      "e": 17934,
      "ty": 2,
      "x": 711,
      "y": 647
    },
    {
      "t": 38229,
      "e": 17963,
      "ty": 4,
      "x": 19196,
      "y": 36658,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38229,
      "e": 17963,
      "ty": 5,
      "x": 711,
      "y": 647,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38251,
      "e": 17985,
      "ty": 41,
      "x": 19196,
      "y": 36658,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38401,
      "e": 18135,
      "ty": 2,
      "x": 1050,
      "y": 647
    },
    {
      "t": 38500,
      "e": 18234,
      "ty": 2,
      "x": 1665,
      "y": 622
    },
    {
      "t": 38500,
      "e": 18234,
      "ty": 41,
      "x": 57063,
      "y": 34013,
      "ta": "html > body"
    },
    {
      "t": 38600,
      "e": 18334,
      "ty": 2,
      "x": 1674,
      "y": 614
    },
    {
      "t": 38699,
      "e": 18433,
      "ty": 2,
      "x": 1485,
      "y": 648
    },
    {
      "t": 38750,
      "e": 18484,
      "ty": 41,
      "x": 45683,
      "y": 37068,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 38800,
      "e": 18534,
      "ty": 2,
      "x": 1136,
      "y": 652
    },
    {
      "t": 38900,
      "e": 18634,
      "ty": 2,
      "x": 1124,
      "y": 653
    },
    {
      "t": 39000,
      "e": 18734,
      "ty": 41,
      "x": 41751,
      "y": 37150,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39084,
      "e": 18818,
      "ty": 3,
      "x": 1124,
      "y": 653,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39180,
      "e": 18914,
      "ty": 4,
      "x": 41751,
      "y": 37150,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39180,
      "e": 18914,
      "ty": 5,
      "x": 1124,
      "y": 653,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39250,
      "e": 18984,
      "ty": 41,
      "x": 41860,
      "y": 37150,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39300,
      "e": 19034,
      "ty": 2,
      "x": 1215,
      "y": 661
    },
    {
      "t": 39399,
      "e": 19133,
      "ty": 2,
      "x": 1424,
      "y": 666
    },
    {
      "t": 39500,
      "e": 19234,
      "ty": 2,
      "x": 1427,
      "y": 663
    },
    {
      "t": 39500,
      "e": 19234,
      "ty": 41,
      "x": 58298,
      "y": 37969,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39557,
      "e": 19291,
      "ty": 3,
      "x": 1435,
      "y": 654,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39600,
      "e": 19334,
      "ty": 2,
      "x": 1436,
      "y": 654
    },
    {
      "t": 39620,
      "e": 19354,
      "ty": 4,
      "x": 58790,
      "y": 37232,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39620,
      "e": 19354,
      "ty": 5,
      "x": 1436,
      "y": 654,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39700,
      "e": 19434,
      "ty": 2,
      "x": 1263,
      "y": 663
    },
    {
      "t": 39750,
      "e": 19484,
      "ty": 41,
      "x": 16137,
      "y": 38378,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 39800,
      "e": 19534,
      "ty": 2,
      "x": 159,
      "y": 618
    },
    {
      "t": 39901,
      "e": 19635,
      "ty": 2,
      "x": 0,
      "y": 584
    },
    {
      "t": 40000,
      "e": 19734,
      "ty": 41,
      "x": 0,
      "y": 32352,
      "ta": "html"
    },
    {
      "t": 40000,
      "e": 19734,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40100,
      "e": 19834,
      "ty": 2,
      "x": 467,
      "y": 626
    },
    {
      "t": 40200,
      "e": 19934,
      "ty": 2,
      "x": 556,
      "y": 625
    },
    {
      "t": 40250,
      "e": 19984,
      "ty": 41,
      "x": 10731,
      "y": 34856,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40324,
      "e": 20058,
      "ty": 3,
      "x": 556,
      "y": 625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40404,
      "e": 20138,
      "ty": 4,
      "x": 10731,
      "y": 34856,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40404,
      "e": 20138,
      "ty": 5,
      "x": 556,
      "y": 625,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 41200,
      "e": 20934,
      "ty": 1,
      "x": 1,
      "y": 16
    },
    {
      "t": 41300,
      "e": 21034,
      "ty": 1,
      "x": 8,
      "y": 16
    },
    {
      "t": 42100,
      "e": 21834,
      "ty": 1,
      "x": 5,
      "y": 16
    },
    {
      "t": 42200,
      "e": 21934,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 42708,
      "e": 22442,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 43813,
      "e": 23547,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48100,
      "e": 26934,
      "ty": 2,
      "x": 600,
      "y": 675
    },
    {
      "t": 48200,
      "e": 27034,
      "ty": 2,
      "x": 1038,
      "y": 1075
    },
    {
      "t": 48250,
      "e": 27084,
      "ty": 41,
      "x": 36848,
      "y": 59884,
      "ta": "> div.masterdiv"
    },
    {
      "t": 48300,
      "e": 27134,
      "ty": 2,
      "x": 1081,
      "y": 1079
    },
    {
      "t": 48400,
      "e": 27234,
      "ty": 2,
      "x": 923,
      "y": 832
    },
    {
      "t": 48500,
      "e": 27334,
      "ty": 2,
      "x": 756,
      "y": 771
    },
    {
      "t": 48501,
      "e": 27335,
      "ty": 41,
      "x": 22755,
      "y": 45881,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 48600,
      "e": 27434,
      "ty": 2,
      "x": 723,
      "y": 853
    },
    {
      "t": 48701,
      "e": 27535,
      "ty": 2,
      "x": 752,
      "y": 871
    },
    {
      "t": 48750,
      "e": 27584,
      "ty": 41,
      "x": 23149,
      "y": 55020,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 48800,
      "e": 27634,
      "ty": 2,
      "x": 764,
      "y": 878
    },
    {
      "t": 48900,
      "e": 27734,
      "ty": 2,
      "x": 776,
      "y": 914
    },
    {
      "t": 49000,
      "e": 27834,
      "ty": 2,
      "x": 777,
      "y": 914
    },
    {
      "t": 49000,
      "e": 27834,
      "ty": 41,
      "x": 23789,
      "y": 20373,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 49201,
      "e": 28035,
      "ty": 2,
      "x": 779,
      "y": 914
    },
    {
      "t": 49251,
      "e": 28085,
      "ty": 41,
      "x": 24182,
      "y": 20373,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 49300,
      "e": 28134,
      "ty": 2,
      "x": 788,
      "y": 914
    },
    {
      "t": 49400,
      "e": 28234,
      "ty": 2,
      "x": 795,
      "y": 914
    },
    {
      "t": 49501,
      "e": 28335,
      "ty": 2,
      "x": 797,
      "y": 914
    },
    {
      "t": 49501,
      "e": 28335,
      "ty": 41,
      "x": 24772,
      "y": 20373,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 49700,
      "e": 28534,
      "ty": 2,
      "x": 804,
      "y": 915
    },
    {
      "t": 49751,
      "e": 28585,
      "ty": 41,
      "x": 24780,
      "y": 22988,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49801,
      "e": 28635,
      "ty": 2,
      "x": 815,
      "y": 919
    },
    {
      "t": 50001,
      "e": 28835,
      "ty": 41,
      "x": 37887,
      "y": 26265,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 50001,
      "e": 28835,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50190,
      "e": 29024,
      "ty": 3,
      "x": 815,
      "y": 919,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 50250,
      "e": 29084,
      "ty": 41,
      "x": 37887,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 50252,
      "e": 29086,
      "ty": 4,
      "x": 37887,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 50253,
      "e": 29087,
      "ty": 5,
      "x": 815,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 50254,
      "e": 29088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 50259,
      "e": 29093,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 50299,
      "e": 29133,
      "ty": 2,
      "x": 815,
      "y": 920
    },
    {
      "t": 50876,
      "e": 29710,
      "ty": 6,
      "x": 988,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 50892,
      "e": 29726,
      "ty": 7,
      "x": 1039,
      "y": 1136,
      "ta": "#start"
    },
    {
      "t": 50900,
      "e": 29734,
      "ty": 2,
      "x": 1039,
      "y": 1136
    },
    {
      "t": 50999,
      "e": 29833,
      "ty": 2,
      "x": 1119,
      "y": 1205
    },
    {
      "t": 51100,
      "e": 29934,
      "ty": 2,
      "x": 1120,
      "y": 1205
    },
    {
      "t": 51200,
      "e": 30034,
      "ty": 2,
      "x": 1111,
      "y": 1185
    },
    {
      "t": 51250,
      "e": 30084,
      "ty": 41,
      "x": 36297,
      "y": 61878,
      "ta": "> div.masterdiv"
    },
    {
      "t": 51259,
      "e": 30093,
      "ty": 6,
      "x": 1028,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 51276,
      "e": 30110,
      "ty": 7,
      "x": 1000,
      "y": 1064,
      "ta": "#start"
    },
    {
      "t": 51300,
      "e": 30134,
      "ty": 2,
      "x": 976,
      "y": 1046
    },
    {
      "t": 51399,
      "e": 30233,
      "ty": 2,
      "x": 965,
      "y": 1038
    },
    {
      "t": 51501,
      "e": 30335,
      "ty": 41,
      "x": 33038,
      "y": 63132,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 52800,
      "e": 31634,
      "ty": 2,
      "x": 964,
      "y": 1056
    },
    {
      "t": 52899,
      "e": 31733,
      "ty": 2,
      "x": 967,
      "y": 1063
    },
    {
      "t": 52999,
      "e": 31833,
      "ty": 41,
      "x": 33136,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 53100,
      "e": 31934,
      "ty": 2,
      "x": 967,
      "y": 1071
    },
    {
      "t": 53110,
      "e": 31944,
      "ty": 6,
      "x": 967,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 53200,
      "e": 32034,
      "ty": 2,
      "x": 967,
      "y": 1078
    },
    {
      "t": 53250,
      "e": 32084,
      "ty": 41,
      "x": 31402,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 59999,
      "e": 37084,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 86250,
      "e": 37084,
      "ty": 3,
      "x": 967,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 86250,
      "e": 37084,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 86250,
      "e": 37084,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 86321,
      "e": 37155,
      "ty": 4,
      "x": 31402,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 86322,
      "e": 37156,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 86323,
      "e": 37157,
      "ty": 5,
      "x": 967,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 86324,
      "e": 37158,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 86898,
      "e": 37732,
      "ty": 2,
      "x": 967,
      "y": 1070
    },
    {
      "t": 86998,
      "e": 37832,
      "ty": 2,
      "x": 1024,
      "y": 385
    },
    {
      "t": 86999,
      "e": 37833,
      "ty": 41,
      "x": 34988,
      "y": 20884,
      "ta": "html > body"
    },
    {
      "t": 87098,
      "e": 37932,
      "ty": 2,
      "x": 1055,
      "y": 196
    },
    {
      "t": 87249,
      "e": 38083,
      "ty": 41,
      "x": 36056,
      "y": 10414,
      "ta": "html > body"
    },
    {
      "t": 87332,
      "e": 38166,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 87598,
      "e": 38432,
      "ty": 2,
      "x": 1064,
      "y": 196
    },
    {
      "t": 87749,
      "e": 38583,
      "ty": 41,
      "x": 36366,
      "y": 10414,
      "ta": "html > body"
    },
    {
      "t": 87998,
      "e": 38832,
      "ty": 2,
      "x": 1064,
      "y": 248
    },
    {
      "t": 87999,
      "e": 38833,
      "ty": 41,
      "x": 36366,
      "y": 13295,
      "ta": "html > body"
    },
    {
      "t": 88098,
      "e": 38932,
      "ty": 2,
      "x": 1088,
      "y": 410
    },
    {
      "t": 88199,
      "e": 39033,
      "ty": 2,
      "x": 1051,
      "y": 517
    },
    {
      "t": 88248,
      "e": 39082,
      "ty": 41,
      "x": 47150,
      "y": 32767,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 88298,
      "e": 39132,
      "ty": 2,
      "x": 1014,
      "y": 573
    },
    {
      "t": 88321,
      "e": 39155,
      "ty": 6,
      "x": 1004,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88355,
      "e": 39189,
      "ty": 7,
      "x": 995,
      "y": 617,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88398,
      "e": 39232,
      "ty": 2,
      "x": 995,
      "y": 618
    },
    {
      "t": 88498,
      "e": 39332,
      "ty": 41,
      "x": 40445,
      "y": 2114,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 88698,
      "e": 39532,
      "ty": 2,
      "x": 998,
      "y": 609
    },
    {
      "t": 88706,
      "e": 39540,
      "ty": 6,
      "x": 1001,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88748,
      "e": 39582,
      "ty": 41,
      "x": 42175,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88798,
      "e": 39632,
      "ty": 2,
      "x": 1003,
      "y": 596
    },
    {
      "t": 88882,
      "e": 39716,
      "ty": 3,
      "x": 1003,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88884,
      "e": 39718,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88986,
      "e": 39820,
      "ty": 4,
      "x": 42175,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88986,
      "e": 39820,
      "ty": 5,
      "x": 1003,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89098,
      "e": 39932,
      "ty": 2,
      "x": 1003,
      "y": 595
    },
    {
      "t": 89199,
      "e": 40033,
      "ty": 2,
      "x": 1014,
      "y": 591
    },
    {
      "t": 89248,
      "e": 40082,
      "ty": 41,
      "x": 44555,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92221,
      "e": 43055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 92302,
      "e": 43136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 92302,
      "e": 43136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92382,
      "e": 43216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 92383,
      "e": 43217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92494,
      "e": 43328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OS"
    },
    {
      "t": 92510,
      "e": 43344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OS"
    },
    {
      "t": 92525,
      "e": 43359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 92526,
      "e": 43360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92646,
      "e": 43480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 92646,
      "e": 43480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92710,
      "e": 43544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSCA"
    },
    {
      "t": 92790,
      "e": 43624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 92846,
      "e": 43680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 92847,
      "e": 43681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92949,
      "e": 43783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 93038,
      "e": 43872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 93103,
      "e": 43937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 93104,
      "e": 43938,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSCAR"
    },
    {
      "t": 93104,
      "e": 43938,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93106,
      "e": 43940,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93173,
      "e": 44007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 94405,
      "e": 45239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 94407,
      "e": 45241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94470,
      "e": 45304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 94550,
      "e": 45384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 94551,
      "e": 45385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94694,
      "e": 45528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 95830,
      "e": 46664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 95831,
      "e": 46665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95894,
      "e": 46728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 96004,
      "e": 46838,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 99999,
      "e": 50833,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 102249,
      "e": 51838,
      "ty": 41,
      "x": 43906,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102249,
      "e": 51838,
      "ty": 7,
      "x": 1003,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102298,
      "e": 51887,
      "ty": 2,
      "x": 993,
      "y": 626
    },
    {
      "t": 102399,
      "e": 51988,
      "ty": 2,
      "x": 985,
      "y": 661
    },
    {
      "t": 102417,
      "e": 52006,
      "ty": 6,
      "x": 979,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102450,
      "e": 52039,
      "ty": 7,
      "x": 977,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102467,
      "e": 52056,
      "ty": 6,
      "x": 975,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102499,
      "e": 52088,
      "ty": 2,
      "x": 974,
      "y": 721
    },
    {
      "t": 102499,
      "e": 52088,
      "ty": 41,
      "x": 40240,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102599,
      "e": 52188,
      "ty": 2,
      "x": 974,
      "y": 734
    },
    {
      "t": 102616,
      "e": 52205,
      "ty": 7,
      "x": 974,
      "y": 741,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102698,
      "e": 52287,
      "ty": 2,
      "x": 972,
      "y": 753
    },
    {
      "t": 102748,
      "e": 52337,
      "ty": 41,
      "x": 33163,
      "y": 41381,
      "ta": "html > body"
    },
    {
      "t": 102799,
      "e": 52388,
      "ty": 2,
      "x": 971,
      "y": 756
    },
    {
      "t": 102899,
      "e": 52488,
      "ty": 2,
      "x": 971,
      "y": 752
    },
    {
      "t": 102917,
      "e": 52506,
      "ty": 6,
      "x": 971,
      "y": 739,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102968,
      "e": 52557,
      "ty": 7,
      "x": 959,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102985,
      "e": 52574,
      "ty": 6,
      "x": 948,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102999,
      "e": 52588,
      "ty": 2,
      "x": 948,
      "y": 685
    },
    {
      "t": 103000,
      "e": 52589,
      "ty": 41,
      "x": 30280,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103000,
      "e": 52589,
      "ty": 7,
      "x": 935,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103050,
      "e": 52639,
      "ty": 6,
      "x": 888,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103083,
      "e": 52672,
      "ty": 7,
      "x": 862,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103099,
      "e": 52688,
      "ty": 2,
      "x": 862,
      "y": 578
    },
    {
      "t": 103198,
      "e": 52787,
      "ty": 2,
      "x": 832,
      "y": 541
    },
    {
      "t": 103249,
      "e": 52838,
      "ty": 41,
      "x": 4758,
      "y": 2340,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 103298,
      "e": 52887,
      "ty": 2,
      "x": 829,
      "y": 541
    },
    {
      "t": 103499,
      "e": 53088,
      "ty": 41,
      "x": 4542,
      "y": 2340,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 103599,
      "e": 53188,
      "ty": 2,
      "x": 829,
      "y": 545
    },
    {
      "t": 103699,
      "e": 53288,
      "ty": 2,
      "x": 851,
      "y": 576
    },
    {
      "t": 103701,
      "e": 53290,
      "ty": 6,
      "x": 866,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103734,
      "e": 53323,
      "ty": 7,
      "x": 891,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103749,
      "e": 53338,
      "ty": 41,
      "x": 17951,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 103799,
      "e": 53388,
      "ty": 2,
      "x": 918,
      "y": 627
    },
    {
      "t": 103899,
      "e": 53488,
      "ty": 2,
      "x": 890,
      "y": 669
    },
    {
      "t": 103901,
      "e": 53490,
      "ty": 6,
      "x": 868,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103917,
      "e": 53506,
      "ty": 7,
      "x": 853,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103999,
      "e": 53588,
      "ty": 2,
      "x": 808,
      "y": 781
    },
    {
      "t": 103999,
      "e": 53588,
      "ty": 41,
      "x": 27550,
      "y": 42822,
      "ta": "html > body"
    },
    {
      "t": 104099,
      "e": 53688,
      "ty": 2,
      "x": 798,
      "y": 842
    },
    {
      "t": 104250,
      "e": 53839,
      "ty": 41,
      "x": 27205,
      "y": 46201,
      "ta": "html > body"
    },
    {
      "t": 104499,
      "e": 54088,
      "ty": 2,
      "x": 859,
      "y": 868
    },
    {
      "t": 104499,
      "e": 54088,
      "ty": 41,
      "x": 29306,
      "y": 47641,
      "ta": "html > body"
    },
    {
      "t": 104599,
      "e": 54188,
      "ty": 2,
      "x": 939,
      "y": 902
    },
    {
      "t": 104699,
      "e": 54288,
      "ty": 2,
      "x": 966,
      "y": 906
    },
    {
      "t": 104750,
      "e": 54339,
      "ty": 41,
      "x": 33507,
      "y": 49746,
      "ta": "html > body"
    },
    {
      "t": 104799,
      "e": 54388,
      "ty": 2,
      "x": 987,
      "y": 907
    },
    {
      "t": 104999,
      "e": 54588,
      "ty": 2,
      "x": 989,
      "y": 904
    },
    {
      "t": 104999,
      "e": 54588,
      "ty": 41,
      "x": 33783,
      "y": 49635,
      "ta": "html > body"
    },
    {
      "t": 105099,
      "e": 54688,
      "ty": 2,
      "x": 968,
      "y": 856
    },
    {
      "t": 105187,
      "e": 54776,
      "ty": 6,
      "x": 914,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105199,
      "e": 54788,
      "ty": 2,
      "x": 914,
      "y": 728
    },
    {
      "t": 105202,
      "e": 54791,
      "ty": 7,
      "x": 910,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105219,
      "e": 54808,
      "ty": 6,
      "x": 910,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105249,
      "e": 54838,
      "ty": 41,
      "x": 22061,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105268,
      "e": 54857,
      "ty": 7,
      "x": 911,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105299,
      "e": 54888,
      "ty": 2,
      "x": 911,
      "y": 674
    },
    {
      "t": 105399,
      "e": 54988,
      "ty": 2,
      "x": 914,
      "y": 670
    },
    {
      "t": 105453,
      "e": 55042,
      "ty": 6,
      "x": 929,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105498,
      "e": 55087,
      "ty": 2,
      "x": 943,
      "y": 699
    },
    {
      "t": 105498,
      "e": 55087,
      "ty": 41,
      "x": 29198,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105503,
      "e": 55092,
      "ty": 7,
      "x": 950,
      "y": 706,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105520,
      "e": 55109,
      "ty": 6,
      "x": 954,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105599,
      "e": 55188,
      "ty": 2,
      "x": 968,
      "y": 729
    },
    {
      "t": 105699,
      "e": 55288,
      "ty": 2,
      "x": 970,
      "y": 732
    },
    {
      "t": 105749,
      "e": 55338,
      "ty": 41,
      "x": 38179,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105999,
      "e": 55588,
      "ty": 2,
      "x": 975,
      "y": 732
    },
    {
      "t": 105999,
      "e": 55588,
      "ty": 41,
      "x": 40756,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106099,
      "e": 55688,
      "ty": 2,
      "x": 978,
      "y": 731
    },
    {
      "t": 106248,
      "e": 55837,
      "ty": 41,
      "x": 42302,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106593,
      "e": 56182,
      "ty": 3,
      "x": 978,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106594,
      "e": 56183,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 106594,
      "e": 56183,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106595,
      "e": 56184,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106665,
      "e": 56254,
      "ty": 4,
      "x": 42302,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106667,
      "e": 56256,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106667,
      "e": 56256,
      "ty": 5,
      "x": 978,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106668,
      "e": 56257,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 108017,
      "e": 57606,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 108046,
      "e": 57635,
      "ty": 6,
      "x": 978,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 109998,
      "e": 59587,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 151168,
      "e": 62635,
      "ty": 7,
      "x": 982,
      "y": 799,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 151196,
      "e": 62663,
      "ty": 2,
      "x": 986,
      "y": 839
    },
    {
      "t": 151246,
      "e": 62713,
      "ty": 41,
      "x": 34120,
      "y": 52884,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 151296,
      "e": 62763,
      "ty": 2,
      "x": 993,
      "y": 984
    },
    {
      "t": 151396,
      "e": 62863,
      "ty": 2,
      "x": 985,
      "y": 1050
    },
    {
      "t": 151451,
      "e": 62918,
      "ty": 6,
      "x": 990,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 151484,
      "e": 62951,
      "ty": 7,
      "x": 998,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 151497,
      "e": 62964,
      "ty": 2,
      "x": 998,
      "y": 1107
    },
    {
      "t": 151497,
      "e": 62964,
      "ty": 41,
      "x": 50789,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 151597,
      "e": 63064,
      "ty": 2,
      "x": 1002,
      "y": 1115
    },
    {
      "t": 151747,
      "e": 63214,
      "ty": 41,
      "x": 52662,
      "y": 23440,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 151796,
      "e": 63263,
      "ty": 2,
      "x": 1004,
      "y": 1111
    },
    {
      "t": 151896,
      "e": 63363,
      "ty": 2,
      "x": 1007,
      "y": 1108
    },
    {
      "t": 151997,
      "e": 63464,
      "ty": 41,
      "x": 55002,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 152297,
      "e": 63764,
      "ty": 2,
      "x": 1007,
      "y": 1107
    },
    {
      "t": 152305,
      "e": 63772,
      "ty": 6,
      "x": 1007,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 152397,
      "e": 63864,
      "ty": 2,
      "x": 1007,
      "y": 1105
    },
    {
      "t": 152496,
      "e": 63963,
      "ty": 2,
      "x": 1007,
      "y": 1103
    },
    {
      "t": 152497,
      "e": 63964,
      "ty": 41,
      "x": 53247,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 152596,
      "e": 64063,
      "ty": 2,
      "x": 1007,
      "y": 1101
    },
    {
      "t": 152747,
      "e": 64214,
      "ty": 41,
      "x": 53247,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 153196,
      "e": 64663,
      "ty": 2,
      "x": 1007,
      "y": 1100
    },
    {
      "t": 153247,
      "e": 64714,
      "ty": 41,
      "x": 53247,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 153296,
      "e": 64763,
      "ty": 2,
      "x": 1006,
      "y": 1096
    },
    {
      "t": 153397,
      "e": 64864,
      "ty": 2,
      "x": 1000,
      "y": 1083
    },
    {
      "t": 153497,
      "e": 64964,
      "ty": 41,
      "x": 49424,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 153697,
      "e": 65164,
      "ty": 3,
      "x": 1000,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 153698,
      "e": 65165,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153790,
      "e": 65257,
      "ty": 4,
      "x": 49424,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 153791,
      "e": 65258,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153792,
      "e": 65259,
      "ty": 5,
      "x": 1000,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 153792,
      "e": 65259,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 154497,
      "e": 65964,
      "ty": 2,
      "x": 745,
      "y": 703
    },
    {
      "t": 154497,
      "e": 65964,
      "ty": 41,
      "x": 25380,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 154597,
      "e": 66064,
      "ty": 2,
      "x": 582,
      "y": 416
    },
    {
      "t": 154697,
      "e": 66164,
      "ty": 2,
      "x": 582,
      "y": 406
    },
    {
      "t": 154747,
      "e": 66214,
      "ty": 41,
      "x": 19767,
      "y": 22048,
      "ta": "html > body"
    },
    {
      "t": 154794,
      "e": 66261,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 159996,
      "e": 71214,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 164197,
      "e": 71214,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 165204,
      "e": 71214,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 190, dom: 861, initialDom: 869",
  "javascriptErrors": []
}