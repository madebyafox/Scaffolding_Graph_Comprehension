var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "803d969c1b5bf1fc3b3ff4242c8e8f3b",
  "created": "2018-05-29T10:02:06.5633843-07:00",
  "lastActivity": "2018-05-29T10:04:51.7935802-07:00",
  "pageViews": [
    {
      "id": "05290687a720d9dcac07c343394985a845d9dac4",
      "startTime": "2018-05-29T10:02:06.6053202-07:00",
      "endTime": "2018-05-29T10:04:51.7935802-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 165204,
      "engagementTime": 71214,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 165204,
  "engagementTime": 71214,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6d8204847ddbaed6e7159eeb38e54340",
  "gdpr": false
}