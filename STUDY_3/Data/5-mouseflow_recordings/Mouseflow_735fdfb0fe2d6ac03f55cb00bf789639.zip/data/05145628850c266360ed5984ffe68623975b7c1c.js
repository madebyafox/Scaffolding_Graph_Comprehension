var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05145628850c266360ed5984ffe68623975b7c1c"] = {
  "startTime": "2018-05-14T20:14:56.6604699Z",
  "websitePageUrl": "/15",
  "visitTime": 171057,
  "engagementTime": 68949,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "735fdfb0fe2d6ac03f55cb00bf789639",
    "created": "2018-05-14T20:14:56.6604699+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.170",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=9393C",
      "CONDITION=121",
      "ORTH_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "61d596a4c14fcba30fe02b9e115cca37",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/735fdfb0fe2d6ac03f55cb00bf789639/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 106,
      "e": 106,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 723,
      "e": 723,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 529,
      "y": 751
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 64715,
      "y": 53789,
      "ta": "#start"
    },
    {
      "t": 1261,
      "e": 1261,
      "ty": 7,
      "x": 575,
      "y": 767,
      "ta": "#start"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 613,
      "y": 788
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 752,
      "y": 830
    },
    {
      "t": 1509,
      "e": 1509,
      "ty": 2,
      "x": 762,
      "y": 830
    },
    {
      "t": 1509,
      "e": 1509,
      "ty": 41,
      "x": 50784,
      "y": 45536,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1608,
      "e": 1608,
      "ty": 2,
      "x": 767,
      "y": 827
    },
    {
      "t": 1765,
      "e": 1765,
      "ty": 41,
      "x": 51121,
      "y": 45370,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10013,
      "e": 6765,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13001,
      "e": 6765,
      "ty": 2,
      "x": 807,
      "y": 827
    },
    {
      "t": 13002,
      "e": 6766,
      "ty": 41,
      "x": 53815,
      "y": 45370,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 13102,
      "e": 6866,
      "ty": 2,
      "x": 1644,
      "y": 1080
    },
    {
      "t": 13201,
      "e": 6965,
      "ty": 2,
      "x": 1919,
      "y": 1139
    },
    {
      "t": 13301,
      "e": 7065,
      "ty": 2,
      "x": 1861,
      "y": 954
    },
    {
      "t": 13402,
      "e": 7166,
      "ty": 2,
      "x": 1324,
      "y": 680
    },
    {
      "t": 13505,
      "e": 7269,
      "ty": 2,
      "x": 1202,
      "y": 633
    },
    {
      "t": 13505,
      "e": 7269,
      "ty": 41,
      "x": 15573,
      "y": 35453,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13601,
      "e": 7365,
      "ty": 2,
      "x": 1248,
      "y": 793
    },
    {
      "t": 13701,
      "e": 7465,
      "ty": 2,
      "x": 1435,
      "y": 893
    },
    {
      "t": 13752,
      "e": 7516,
      "ty": 41,
      "x": 31992,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13901,
      "e": 7665,
      "ty": 2,
      "x": 1448,
      "y": 890
    },
    {
      "t": 14001,
      "e": 7765,
      "ty": 2,
      "x": 1498,
      "y": 886
    },
    {
      "t": 14003,
      "e": 7767,
      "ty": 41,
      "x": 36431,
      "y": 53573,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20015,
      "e": 12767,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 38703,
      "e": 12767,
      "ty": 2,
      "x": 1020,
      "y": 846
    },
    {
      "t": 38753,
      "e": 12817,
      "ty": 41,
      "x": 54758,
      "y": 42489,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 38803,
      "e": 12867,
      "ty": 2,
      "x": 619,
      "y": 696
    },
    {
      "t": 38843,
      "e": 12907,
      "ty": 6,
      "x": 373,
      "y": 627,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 38859,
      "e": 12923,
      "ty": 7,
      "x": 292,
      "y": 612,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 38876,
      "e": 12940,
      "ty": 6,
      "x": 236,
      "y": 604,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 38903,
      "e": 12967,
      "ty": 2,
      "x": 160,
      "y": 587
    },
    {
      "t": 38943,
      "e": 13007,
      "ty": 7,
      "x": 93,
      "y": 564,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 38943,
      "e": 13007,
      "ty": 6,
      "x": 93,
      "y": 564,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39003,
      "e": 13067,
      "ty": 2,
      "x": 58,
      "y": 548
    },
    {
      "t": 39003,
      "e": 13067,
      "ty": 41,
      "x": 2905,
      "y": 19455,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39043,
      "e": 13107,
      "ty": 7,
      "x": 44,
      "y": 545,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39110,
      "e": 13174,
      "ty": 2,
      "x": 42,
      "y": 544
    },
    {
      "t": 39196,
      "e": 13260,
      "ty": 6,
      "x": 53,
      "y": 547,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39203,
      "e": 13267,
      "ty": 2,
      "x": 53,
      "y": 547
    },
    {
      "t": 39254,
      "e": 13318,
      "ty": 41,
      "x": 10458,
      "y": 39116,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39303,
      "e": 13367,
      "ty": 2,
      "x": 112,
      "y": 566
    },
    {
      "t": 39342,
      "e": 13406,
      "ty": 7,
      "x": 124,
      "y": 570,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 39403,
      "e": 13467,
      "ty": 2,
      "x": 130,
      "y": 572
    },
    {
      "t": 39443,
      "e": 13507,
      "ty": 6,
      "x": 152,
      "y": 578,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 39504,
      "e": 13568,
      "ty": 2,
      "x": 198,
      "y": 583
    },
    {
      "t": 39504,
      "e": 13568,
      "ty": 41,
      "x": 43575,
      "y": 12902,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 39560,
      "e": 13624,
      "ty": 7,
      "x": 292,
      "y": 584,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 39560,
      "e": 13624,
      "ty": 6,
      "x": 292,
      "y": 584,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 39603,
      "e": 13667,
      "ty": 2,
      "x": 315,
      "y": 584
    },
    {
      "t": 39708,
      "e": 13772,
      "ty": 2,
      "x": 322,
      "y": 584
    },
    {
      "t": 39755,
      "e": 13819,
      "ty": 41,
      "x": 15805,
      "y": 15086,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 39803,
      "e": 13867,
      "ty": 2,
      "x": 345,
      "y": 584
    },
    {
      "t": 39903,
      "e": 13967,
      "ty": 2,
      "x": 452,
      "y": 584
    },
    {
      "t": 40003,
      "e": 14067,
      "ty": 2,
      "x": 489,
      "y": 584
    },
    {
      "t": 40003,
      "e": 14067,
      "ty": 41,
      "x": 62575,
      "y": 15086,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 40043,
      "e": 14107,
      "ty": 7,
      "x": 505,
      "y": 585,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 40043,
      "e": 14107,
      "ty": 6,
      "x": 505,
      "y": 585,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 40103,
      "e": 14167,
      "ty": 2,
      "x": 549,
      "y": 588
    },
    {
      "t": 40203,
      "e": 14267,
      "ty": 2,
      "x": 663,
      "y": 590
    },
    {
      "t": 40253,
      "e": 14317,
      "ty": 41,
      "x": 59498,
      "y": 26009,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 40303,
      "e": 14367,
      "ty": 2,
      "x": 712,
      "y": 586
    },
    {
      "t": 40378,
      "e": 14442,
      "ty": 7,
      "x": 726,
      "y": 578,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 40379,
      "e": 14443,
      "ty": 6,
      "x": 726,
      "y": 578,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 40394,
      "e": 14458,
      "ty": 7,
      "x": 732,
      "y": 574,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 40403,
      "e": 14467,
      "ty": 2,
      "x": 732,
      "y": 574
    },
    {
      "t": 40427,
      "e": 14491,
      "ty": 6,
      "x": 745,
      "y": 567,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 40503,
      "e": 14567,
      "ty": 2,
      "x": 770,
      "y": 557
    },
    {
      "t": 40503,
      "e": 14567,
      "ty": 41,
      "x": 13136,
      "y": 39116,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 40603,
      "e": 14667,
      "ty": 2,
      "x": 782,
      "y": 551
    },
    {
      "t": 40703,
      "e": 14767,
      "ty": 2,
      "x": 795,
      "y": 543
    },
    {
      "t": 40726,
      "e": 14790,
      "ty": 7,
      "x": 803,
      "y": 537,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 40754,
      "e": 14818,
      "ty": 41,
      "x": 53950,
      "y": 29200,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 40778,
      "e": 14842,
      "ty": 6,
      "x": 816,
      "y": 530,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 40803,
      "e": 14867,
      "ty": 2,
      "x": 816,
      "y": 529
    },
    {
      "t": 40903,
      "e": 14967,
      "ty": 2,
      "x": 830,
      "y": 523
    },
    {
      "t": 41008,
      "e": 15072,
      "ty": 2,
      "x": 831,
      "y": 522
    },
    {
      "t": 41008,
      "e": 15072,
      "ty": 41,
      "x": 14847,
      "y": 48844,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 41117,
      "e": 15181,
      "ty": 3,
      "x": 831,
      "y": 522,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 41276,
      "e": 15340,
      "ty": 4,
      "x": 14847,
      "y": 48844,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 41277,
      "e": 15341,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 41286,
      "e": 15350,
      "ty": 5,
      "x": 831,
      "y": 522,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 41286,
      "e": 15350,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input",
      "v": "F"
    },
    {
      "t": 41595,
      "e": 15659,
      "ty": 7,
      "x": 864,
      "y": 565,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 41595,
      "e": 15659,
      "ty": 6,
      "x": 864,
      "y": 565,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 41603,
      "e": 15667,
      "ty": 2,
      "x": 864,
      "y": 565
    },
    {
      "t": 41611,
      "e": 15675,
      "ty": 7,
      "x": 894,
      "y": 598,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 41612,
      "e": 15676,
      "ty": 6,
      "x": 894,
      "y": 598,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 41627,
      "e": 15691,
      "ty": 7,
      "x": 936,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 41627,
      "e": 15691,
      "ty": 6,
      "x": 936,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 41644,
      "e": 15708,
      "ty": 7,
      "x": 992,
      "y": 695,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 41703,
      "e": 15767,
      "ty": 2,
      "x": 1129,
      "y": 834
    },
    {
      "t": 41753,
      "e": 15817,
      "ty": 41,
      "x": 58945,
      "y": 33023,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[5] > text"
    },
    {
      "t": 41803,
      "e": 15867,
      "ty": 2,
      "x": 1265,
      "y": 1130
    },
    {
      "t": 41912,
      "e": 15976,
      "ty": 2,
      "x": 1298,
      "y": 1170
    },
    {
      "t": 42007,
      "e": 16071,
      "ty": 41,
      "x": 44424,
      "y": 64371,
      "ta": "> div.stimulus"
    },
    {
      "t": 50012,
      "e": 21071,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92204,
      "e": 21071,
      "ty": 2,
      "x": 1328,
      "y": 1175
    },
    {
      "t": 92254,
      "e": 21121,
      "ty": 41,
      "x": 45871,
      "y": 64759,
      "ta": "> div.stimulus"
    },
    {
      "t": 92304,
      "e": 21171,
      "ty": 2,
      "x": 1348,
      "y": 1180
    },
    {
      "t": 92404,
      "e": 21271,
      "ty": 2,
      "x": 1393,
      "y": 1199
    },
    {
      "t": 92505,
      "e": 21372,
      "ty": 2,
      "x": 1400,
      "y": 1199
    },
    {
      "t": 92904,
      "e": 21771,
      "ty": 2,
      "x": 1394,
      "y": 1197
    },
    {
      "t": 93003,
      "e": 21870,
      "ty": 2,
      "x": 1356,
      "y": 1194
    },
    {
      "t": 93104,
      "e": 21971,
      "ty": 2,
      "x": 1321,
      "y": 1143
    },
    {
      "t": 93203,
      "e": 22070,
      "ty": 2,
      "x": 1292,
      "y": 1027
    },
    {
      "t": 93254,
      "e": 22121,
      "ty": 41,
      "x": 23183,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 93303,
      "e": 22170,
      "ty": 2,
      "x": 1363,
      "y": 942
    },
    {
      "t": 93404,
      "e": 22271,
      "ty": 2,
      "x": 1436,
      "y": 969
    },
    {
      "t": 93519,
      "e": 22386,
      "ty": 2,
      "x": 1454,
      "y": 980
    },
    {
      "t": 93520,
      "e": 22387,
      "ty": 41,
      "x": 33331,
      "y": 60306,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 93706,
      "e": 22573,
      "ty": 2,
      "x": 1459,
      "y": 979
    },
    {
      "t": 93754,
      "e": 22621,
      "ty": 41,
      "x": 34529,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 93808,
      "e": 22675,
      "ty": 2,
      "x": 1471,
      "y": 972
    },
    {
      "t": 98756,
      "e": 27623,
      "ty": 41,
      "x": 30371,
      "y": 53430,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 98804,
      "e": 27671,
      "ty": 2,
      "x": 1030,
      "y": 667
    },
    {
      "t": 98817,
      "e": 27684,
      "ty": 6,
      "x": 862,
      "y": 599,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 98833,
      "e": 27700,
      "ty": 7,
      "x": 729,
      "y": 553,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 98834,
      "e": 27701,
      "ty": 6,
      "x": 729,
      "y": 553,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 98850,
      "e": 27717,
      "ty": 7,
      "x": 581,
      "y": 505,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 98850,
      "e": 27717,
      "ty": 6,
      "x": 581,
      "y": 505,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 98875,
      "e": 27742,
      "ty": 7,
      "x": 521,
      "y": 483,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 98904,
      "e": 27771,
      "ty": 2,
      "x": 513,
      "y": 478
    },
    {
      "t": 99010,
      "e": 27877,
      "ty": 2,
      "x": 503,
      "y": 471
    },
    {
      "t": 99010,
      "e": 27877,
      "ty": 41,
      "x": 33340,
      "y": 51382,
      "ta": "#bigset.midpoint > p"
    },
    {
      "t": 99076,
      "e": 27943,
      "ty": 6,
      "x": 574,
      "y": 508,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 99104,
      "e": 27971,
      "ty": 2,
      "x": 580,
      "y": 514
    },
    {
      "t": 99206,
      "e": 28073,
      "ty": 2,
      "x": 581,
      "y": 515
    },
    {
      "t": 99254,
      "e": 28121,
      "ty": 41,
      "x": 24638,
      "y": 32562,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 99304,
      "e": 28171,
      "ty": 2,
      "x": 591,
      "y": 515
    },
    {
      "t": 99405,
      "e": 28272,
      "ty": 2,
      "x": 611,
      "y": 509
    },
    {
      "t": 99504,
      "e": 28371,
      "ty": 41,
      "x": 35020,
      "y": 6246,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 99531,
      "e": 28398,
      "ty": 3,
      "x": 611,
      "y": 509,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 99532,
      "e": 28399,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 99635,
      "e": 28502,
      "ty": 4,
      "x": 35020,
      "y": 6246,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 99636,
      "e": 28503,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 99641,
      "e": 28508,
      "ty": 5,
      "x": 611,
      "y": 509,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 99641,
      "e": 28508,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input",
      "v": "E"
    },
    {
      "t": 99709,
      "e": 28576,
      "ty": 2,
      "x": 606,
      "y": 521
    },
    {
      "t": 99710,
      "e": 28577,
      "ty": 7,
      "x": 599,
      "y": 537,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 99743,
      "e": 28610,
      "ty": 6,
      "x": 566,
      "y": 602,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 99754,
      "e": 28621,
      "ty": 41,
      "x": 19409,
      "y": 54407,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 99760,
      "e": 28627,
      "ty": 7,
      "x": 547,
      "y": 641,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 99760,
      "e": 28627,
      "ty": 6,
      "x": 547,
      "y": 641,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 99777,
      "e": 28644,
      "ty": 7,
      "x": 533,
      "y": 672,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 99804,
      "e": 28671,
      "ty": 2,
      "x": 517,
      "y": 703
    },
    {
      "t": 99826,
      "e": 28693,
      "ty": 6,
      "x": 489,
      "y": 752,
      "ta": "#start"
    },
    {
      "t": 99877,
      "e": 28744,
      "ty": 7,
      "x": 483,
      "y": 771,
      "ta": "#start"
    },
    {
      "t": 99904,
      "e": 28771,
      "ty": 2,
      "x": 483,
      "y": 772
    },
    {
      "t": 99994,
      "e": 28861,
      "ty": 6,
      "x": 488,
      "y": 768,
      "ta": "#start"
    },
    {
      "t": 100006,
      "e": 28873,
      "ty": 2,
      "x": 488,
      "y": 768
    },
    {
      "t": 100006,
      "e": 28873,
      "ty": 41,
      "x": 23756,
      "y": 65354,
      "ta": "#start"
    },
    {
      "t": 100007,
      "e": 28874,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100104,
      "e": 28971,
      "ty": 2,
      "x": 512,
      "y": 748
    },
    {
      "t": 100235,
      "e": 29102,
      "ty": 3,
      "x": 512,
      "y": 748,
      "ta": "#start"
    },
    {
      "t": 100236,
      "e": 29103,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 100236,
      "e": 29103,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100253,
      "e": 29120,
      "ty": 41,
      "x": 36863,
      "y": 26804,
      "ta": "#start"
    },
    {
      "t": 100354,
      "e": 29221,
      "ty": 4,
      "x": 36863,
      "y": 26804,
      "ta": "#start"
    },
    {
      "t": 100363,
      "e": 29230,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100364,
      "e": 29231,
      "ty": 5,
      "x": 512,
      "y": 748,
      "ta": "#start"
    },
    {
      "t": 100373,
      "e": 29240,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 100611,
      "e": 29478,
      "ty": 2,
      "x": 509,
      "y": 744
    },
    {
      "t": 100769,
      "e": 29636,
      "ty": 41,
      "x": 17253,
      "y": 40772,
      "ta": "html > body"
    },
    {
      "t": 101386,
      "e": 30253,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 102106,
      "e": 30973,
      "ty": 2,
      "x": 509,
      "y": 742
    },
    {
      "t": 102204,
      "e": 31071,
      "ty": 2,
      "x": 673,
      "y": 683
    },
    {
      "t": 102254,
      "e": 31121,
      "ty": 41,
      "x": 25518,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 102304,
      "e": 31171,
      "ty": 2,
      "x": 766,
      "y": 651
    },
    {
      "t": 102404,
      "e": 31271,
      "ty": 2,
      "x": 770,
      "y": 644
    },
    {
      "t": 102504,
      "e": 31371,
      "ty": 2,
      "x": 827,
      "y": 593
    },
    {
      "t": 102504,
      "e": 31371,
      "ty": 41,
      "x": 4109,
      "y": 7046,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 102545,
      "e": 31412,
      "ty": 6,
      "x": 859,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102610,
      "e": 31477,
      "ty": 2,
      "x": 859,
      "y": 573
    },
    {
      "t": 102704,
      "e": 31571,
      "ty": 2,
      "x": 864,
      "y": 569
    },
    {
      "t": 102761,
      "e": 31628,
      "ty": 41,
      "x": 12112,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102851,
      "e": 31718,
      "ty": 3,
      "x": 864,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102852,
      "e": 31719,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103010,
      "e": 31877,
      "ty": 2,
      "x": 866,
      "y": 568
    },
    {
      "t": 103010,
      "e": 31877,
      "ty": 4,
      "x": 12544,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103012,
      "e": 31879,
      "ty": 5,
      "x": 866,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103013,
      "e": 31880,
      "ty": 41,
      "x": 12544,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 104015,
      "e": 32882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 104016,
      "e": 32883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 104118,
      "e": 32985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 104270,
      "e": 33137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 104271,
      "e": 33138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 104381,
      "e": 33248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 105010,
      "e": 33877,
      "ty": 2,
      "x": 865,
      "y": 568
    },
    {
      "t": 105010,
      "e": 33877,
      "ty": 41,
      "x": 12328,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105148,
      "e": 34015,
      "ty": 7,
      "x": 869,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105203,
      "e": 34070,
      "ty": 2,
      "x": 869,
      "y": 596
    },
    {
      "t": 105253,
      "e": 34120,
      "ty": 41,
      "x": 14274,
      "y": 44470,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 105303,
      "e": 34170,
      "ty": 2,
      "x": 874,
      "y": 635
    },
    {
      "t": 105404,
      "e": 34271,
      "ty": 2,
      "x": 874,
      "y": 643
    },
    {
      "t": 105513,
      "e": 34380,
      "ty": 2,
      "x": 873,
      "y": 646
    },
    {
      "t": 105513,
      "e": 34380,
      "ty": 41,
      "x": 14058,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 105548,
      "e": 34415,
      "ty": 6,
      "x": 872,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105604,
      "e": 34471,
      "ty": 2,
      "x": 869,
      "y": 648
    },
    {
      "t": 105704,
      "e": 34571,
      "ty": 2,
      "x": 860,
      "y": 657
    },
    {
      "t": 105764,
      "e": 34631,
      "ty": 41,
      "x": 11030,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105811,
      "e": 34678,
      "ty": 2,
      "x": 859,
      "y": 659
    },
    {
      "t": 105904,
      "e": 34771,
      "ty": 2,
      "x": 859,
      "y": 660
    },
    {
      "t": 105954,
      "e": 34821,
      "ty": 3,
      "x": 859,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105954,
      "e": 34821,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 105954,
      "e": 34821,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105954,
      "e": 34821,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106014,
      "e": 34881,
      "ty": 41,
      "x": 11030,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106105,
      "e": 34972,
      "ty": 4,
      "x": 11030,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106106,
      "e": 34973,
      "ty": 5,
      "x": 859,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107527,
      "e": 36394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 107527,
      "e": 36394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107693,
      "e": 36560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 107798,
      "e": 36665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 107799,
      "e": 36666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107950,
      "e": 36817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "un"
    },
    {
      "t": 107958,
      "e": 36825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 107958,
      "e": 36825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108110,
      "e": 36977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uni"
    },
    {
      "t": 108278,
      "e": 37145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 108279,
      "e": 37146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108411,
      "e": 37278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unit"
    },
    {
      "t": 108414,
      "e": 37281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unit"
    },
    {
      "t": 108414,
      "e": 37281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 108414,
      "e": 37281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108542,
      "e": 37409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 108623,
      "e": 37490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 108623,
      "e": 37490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108758,
      "e": 37625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 108758,
      "e": 37625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108781,
      "e": 37648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 108885,
      "e": 37752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 108885,
      "e": 37752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108893,
      "e": 37760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 109008,
      "e": 37875,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united s"
    },
    {
      "t": 109013,
      "e": 37880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 109053,
      "e": 37920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 109053,
      "e": 37920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109126,
      "e": 37993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 109126,
      "e": 37993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109182,
      "e": 38049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 109271,
      "e": 38138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 109302,
      "e": 38169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 109303,
      "e": 38170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109382,
      "e": 38249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 109422,
      "e": 38289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 109422,
      "e": 38289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109590,
      "e": 38457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 109701,
      "e": 38568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 109702,
      "e": 38569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109818,
      "e": 38685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united states"
    },
    {
      "t": 109855,
      "e": 38722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 110008,
      "e": 38875,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110409,
      "e": 39276,
      "ty": 2,
      "x": 859,
      "y": 661
    },
    {
      "t": 110452,
      "e": 39319,
      "ty": 7,
      "x": 859,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110504,
      "e": 39371,
      "ty": 2,
      "x": 872,
      "y": 678
    },
    {
      "t": 110504,
      "e": 39371,
      "ty": 41,
      "x": 29754,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 110603,
      "e": 39470,
      "ty": 6,
      "x": 898,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 110604,
      "e": 39471,
      "ty": 2,
      "x": 898,
      "y": 681
    },
    {
      "t": 110704,
      "e": 39571,
      "ty": 2,
      "x": 920,
      "y": 686
    },
    {
      "t": 110753,
      "e": 39620,
      "ty": 41,
      "x": 17563,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 110804,
      "e": 39671,
      "ty": 2,
      "x": 934,
      "y": 692
    },
    {
      "t": 110917,
      "e": 39784,
      "ty": 2,
      "x": 935,
      "y": 692
    },
    {
      "t": 110995,
      "e": 39862,
      "ty": 3,
      "x": 935,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 110996,
      "e": 39863,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united states"
    },
    {
      "t": 110998,
      "e": 39865,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110999,
      "e": 39866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111004,
      "e": 39871,
      "ty": 41,
      "x": 20140,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111089,
      "e": 39956,
      "ty": 4,
      "x": 20140,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111091,
      "e": 39958,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111091,
      "e": 39958,
      "ty": 5,
      "x": 935,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111091,
      "e": 39958,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 112112,
      "e": 40979,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 112904,
      "e": 41771,
      "ty": 2,
      "x": 917,
      "y": 694
    },
    {
      "t": 113005,
      "e": 41872,
      "ty": 2,
      "x": 853,
      "y": 476
    },
    {
      "t": 113005,
      "e": 41872,
      "ty": 41,
      "x": 33378,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 113104,
      "e": 41971,
      "ty": 2,
      "x": 818,
      "y": 307
    },
    {
      "t": 113204,
      "e": 42071,
      "ty": 2,
      "x": 810,
      "y": 231
    },
    {
      "t": 113255,
      "e": 42122,
      "ty": 41,
      "x": 27619,
      "y": 11799,
      "ta": "html > body"
    },
    {
      "t": 113305,
      "e": 42172,
      "ty": 2,
      "x": 811,
      "y": 218
    },
    {
      "t": 113404,
      "e": 42271,
      "ty": 2,
      "x": 827,
      "y": 223
    },
    {
      "t": 113422,
      "e": 42289,
      "ty": 6,
      "x": 836,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 113454,
      "e": 42321,
      "ty": 7,
      "x": 841,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 113504,
      "e": 42371,
      "ty": 2,
      "x": 844,
      "y": 241
    },
    {
      "t": 113504,
      "e": 42371,
      "ty": 41,
      "x": 18488,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 113616,
      "e": 42483,
      "ty": 2,
      "x": 844,
      "y": 243
    },
    {
      "t": 113705,
      "e": 42572,
      "ty": 2,
      "x": 841,
      "y": 246
    },
    {
      "t": 113767,
      "e": 42634,
      "ty": 41,
      "x": 16031,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 113809,
      "e": 42676,
      "ty": 2,
      "x": 840,
      "y": 245
    },
    {
      "t": 113810,
      "e": 42677,
      "ty": 6,
      "x": 838,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 113904,
      "e": 42771,
      "ty": 2,
      "x": 837,
      "y": 242
    },
    {
      "t": 114017,
      "e": 42884,
      "ty": 2,
      "x": 836,
      "y": 241
    },
    {
      "t": 114018,
      "e": 42885,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114275,
      "e": 43142,
      "ty": 3,
      "x": 836,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114275,
      "e": 43142,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114402,
      "e": 43269,
      "ty": 4,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114402,
      "e": 43269,
      "ty": 5,
      "x": 836,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114402,
      "e": 43269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 114763,
      "e": 43630,
      "ty": 7,
      "x": 834,
      "y": 250,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114764,
      "e": 43631,
      "ty": 41,
      "x": 2985,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 114804,
      "e": 43671,
      "ty": 2,
      "x": 831,
      "y": 258
    },
    {
      "t": 114806,
      "e": 43673,
      "ty": 6,
      "x": 831,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 114889,
      "e": 43756,
      "ty": 7,
      "x": 829,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 114903,
      "e": 43770,
      "ty": 2,
      "x": 829,
      "y": 275
    },
    {
      "t": 114939,
      "e": 43806,
      "ty": 6,
      "x": 826,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 114955,
      "e": 43822,
      "ty": 7,
      "x": 825,
      "y": 304,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 115003,
      "e": 43870,
      "ty": 2,
      "x": 823,
      "y": 319
    },
    {
      "t": 115004,
      "e": 43871,
      "ty": 41,
      "x": 1566,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 115104,
      "e": 43971,
      "ty": 2,
      "x": 823,
      "y": 350
    },
    {
      "t": 115204,
      "e": 44071,
      "ty": 2,
      "x": 821,
      "y": 373
    },
    {
      "t": 115253,
      "e": 44120,
      "ty": 41,
      "x": 0,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 115303,
      "e": 44170,
      "ty": 2,
      "x": 823,
      "y": 396
    },
    {
      "t": 115405,
      "e": 44170,
      "ty": 2,
      "x": 825,
      "y": 400
    },
    {
      "t": 115514,
      "e": 44279,
      "ty": 41,
      "x": 849,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115903,
      "e": 44668,
      "ty": 2,
      "x": 824,
      "y": 412
    },
    {
      "t": 116007,
      "e": 44772,
      "ty": 2,
      "x": 824,
      "y": 418
    },
    {
      "t": 116007,
      "e": 44772,
      "ty": 41,
      "x": 3017,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 116104,
      "e": 44869,
      "ty": 2,
      "x": 824,
      "y": 427
    },
    {
      "t": 116191,
      "e": 44956,
      "ty": 6,
      "x": 827,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116204,
      "e": 44969,
      "ty": 2,
      "x": 827,
      "y": 436
    },
    {
      "t": 116256,
      "e": 45021,
      "ty": 41,
      "x": 2914,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116305,
      "e": 45070,
      "ty": 2,
      "x": 827,
      "y": 439
    },
    {
      "t": 116404,
      "e": 45169,
      "ty": 2,
      "x": 828,
      "y": 445
    },
    {
      "t": 116504,
      "e": 45269,
      "ty": 2,
      "x": 830,
      "y": 445
    },
    {
      "t": 116504,
      "e": 45269,
      "ty": 41,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116605,
      "e": 45370,
      "ty": 2,
      "x": 834,
      "y": 443
    },
    {
      "t": 116691,
      "e": 45456,
      "ty": 3,
      "x": 834,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116692,
      "e": 45457,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 116692,
      "e": 45457,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116757,
      "e": 45522,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116794,
      "e": 45559,
      "ty": 4,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116794,
      "e": 45559,
      "ty": 5,
      "x": 834,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116794,
      "e": 45559,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 117058,
      "e": 45823,
      "ty": 7,
      "x": 826,
      "y": 452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 117104,
      "e": 45869,
      "ty": 2,
      "x": 822,
      "y": 461
    },
    {
      "t": 117204,
      "e": 45969,
      "ty": 2,
      "x": 807,
      "y": 489
    },
    {
      "t": 117254,
      "e": 46019,
      "ty": 41,
      "x": 27377,
      "y": 27643,
      "ta": "html > body"
    },
    {
      "t": 117304,
      "e": 46069,
      "ty": 2,
      "x": 803,
      "y": 530
    },
    {
      "t": 117404,
      "e": 46169,
      "ty": 2,
      "x": 818,
      "y": 570
    },
    {
      "t": 117505,
      "e": 46270,
      "ty": 2,
      "x": 835,
      "y": 606
    },
    {
      "t": 117505,
      "e": 46270,
      "ty": 41,
      "x": 3222,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 117604,
      "e": 46369,
      "ty": 2,
      "x": 841,
      "y": 629
    },
    {
      "t": 117704,
      "e": 46469,
      "ty": 2,
      "x": 841,
      "y": 644
    },
    {
      "t": 117754,
      "e": 46519,
      "ty": 41,
      "x": 4646,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 117806,
      "e": 46571,
      "ty": 2,
      "x": 841,
      "y": 647
    },
    {
      "t": 117903,
      "e": 46668,
      "ty": 2,
      "x": 836,
      "y": 652
    },
    {
      "t": 118003,
      "e": 46768,
      "ty": 2,
      "x": 823,
      "y": 668
    },
    {
      "t": 118003,
      "e": 46768,
      "ty": 41,
      "x": 423,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 118103,
      "e": 46868,
      "ty": 2,
      "x": 812,
      "y": 693
    },
    {
      "t": 118203,
      "e": 46968,
      "ty": 2,
      "x": 807,
      "y": 717
    },
    {
      "t": 118258,
      "e": 47023,
      "ty": 41,
      "x": 27481,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 118305,
      "e": 47070,
      "ty": 2,
      "x": 806,
      "y": 717
    },
    {
      "t": 119003,
      "e": 47768,
      "ty": 2,
      "x": 811,
      "y": 713
    },
    {
      "t": 119004,
      "e": 47769,
      "ty": 41,
      "x": 27653,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 119104,
      "e": 47869,
      "ty": 2,
      "x": 821,
      "y": 708
    },
    {
      "t": 119212,
      "e": 47977,
      "ty": 2,
      "x": 825,
      "y": 705
    },
    {
      "t": 119259,
      "e": 48024,
      "ty": 41,
      "x": 901,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 119275,
      "e": 48040,
      "ty": 6,
      "x": 826,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119304,
      "e": 48069,
      "ty": 2,
      "x": 827,
      "y": 704
    },
    {
      "t": 119409,
      "e": 48174,
      "ty": 2,
      "x": 830,
      "y": 702
    },
    {
      "t": 119508,
      "e": 48273,
      "ty": 2,
      "x": 833,
      "y": 701
    },
    {
      "t": 119509,
      "e": 48274,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121244,
      "e": 50009,
      "ty": 3,
      "x": 833,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121245,
      "e": 50010,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 121246,
      "e": 50011,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121386,
      "e": 50151,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121386,
      "e": 50151,
      "ty": 5,
      "x": 833,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121386,
      "e": 50151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 123162,
      "e": 51927,
      "ty": 7,
      "x": 829,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 123205,
      "e": 51970,
      "ty": 2,
      "x": 823,
      "y": 736
    },
    {
      "t": 123254,
      "e": 52019,
      "ty": 41,
      "x": 27928,
      "y": 42268,
      "ta": "html > body"
    },
    {
      "t": 123305,
      "e": 52070,
      "ty": 2,
      "x": 819,
      "y": 814
    },
    {
      "t": 123404,
      "e": 52169,
      "ty": 2,
      "x": 821,
      "y": 888
    },
    {
      "t": 123504,
      "e": 52269,
      "ty": 2,
      "x": 821,
      "y": 905
    },
    {
      "t": 123504,
      "e": 52269,
      "ty": 41,
      "x": 0,
      "y": 15123,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 123603,
      "e": 52368,
      "ty": 2,
      "x": 825,
      "y": 922
    },
    {
      "t": 123629,
      "e": 52369,
      "ty": 6,
      "x": 827,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 123678,
      "e": 52418,
      "ty": 7,
      "x": 831,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 123704,
      "e": 52444,
      "ty": 2,
      "x": 833,
      "y": 947
    },
    {
      "t": 123754,
      "e": 52494,
      "ty": 41,
      "x": 11792,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 123811,
      "e": 52551,
      "ty": 2,
      "x": 836,
      "y": 955
    },
    {
      "t": 123834,
      "e": 52574,
      "ty": 6,
      "x": 836,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 123903,
      "e": 52643,
      "ty": 2,
      "x": 832,
      "y": 961
    },
    {
      "t": 124017,
      "e": 52757,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124138,
      "e": 52878,
      "ty": 3,
      "x": 832,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124139,
      "e": 52879,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 124139,
      "e": 52879,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124242,
      "e": 52982,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124243,
      "e": 52983,
      "ty": 5,
      "x": 832,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124243,
      "e": 52983,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 124346,
      "e": 53086,
      "ty": 7,
      "x": 831,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 124380,
      "e": 53120,
      "ty": 6,
      "x": 833,
      "y": 986,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 124404,
      "e": 53144,
      "ty": 2,
      "x": 834,
      "y": 994
    },
    {
      "t": 124413,
      "e": 53153,
      "ty": 7,
      "x": 838,
      "y": 1004,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 124430,
      "e": 53170,
      "ty": 6,
      "x": 839,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 124504,
      "e": 53244,
      "ty": 2,
      "x": 843,
      "y": 1022
    },
    {
      "t": 124504,
      "e": 53244,
      "ty": 41,
      "x": 6998,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 124604,
      "e": 53344,
      "ty": 2,
      "x": 852,
      "y": 1024
    },
    {
      "t": 124704,
      "e": 53444,
      "ty": 2,
      "x": 861,
      "y": 1021
    },
    {
      "t": 124754,
      "e": 53494,
      "ty": 41,
      "x": 18336,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 124814,
      "e": 53554,
      "ty": 2,
      "x": 865,
      "y": 1020
    },
    {
      "t": 125003,
      "e": 53743,
      "ty": 2,
      "x": 869,
      "y": 1019
    },
    {
      "t": 125003,
      "e": 53743,
      "ty": 41,
      "x": 20398,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125114,
      "e": 53854,
      "ty": 2,
      "x": 872,
      "y": 1018
    },
    {
      "t": 125234,
      "e": 53974,
      "ty": 3,
      "x": 872,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125235,
      "e": 53975,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 125236,
      "e": 53976,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125255,
      "e": 53995,
      "ty": 41,
      "x": 21944,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125353,
      "e": 54093,
      "ty": 4,
      "x": 21944,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125353,
      "e": 54093,
      "ty": 5,
      "x": 872,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125356,
      "e": 54096,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 125357,
      "e": 54097,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 125358,
      "e": 54098,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 126506,
      "e": 55246,
      "ty": 2,
      "x": 873,
      "y": 1018
    },
    {
      "t": 126506,
      "e": 55246,
      "ty": 41,
      "x": 29788,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 126604,
      "e": 55344,
      "ty": 2,
      "x": 864,
      "y": 1011
    },
    {
      "t": 126705,
      "e": 55445,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 126715,
      "e": 55455,
      "ty": 2,
      "x": 862,
      "y": 1010
    },
    {
      "t": 126753,
      "e": 55493,
      "ty": 41,
      "x": 27970,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127104,
      "e": 55844,
      "ty": 2,
      "x": 855,
      "y": 1004
    },
    {
      "t": 127210,
      "e": 55950,
      "ty": 2,
      "x": 848,
      "y": 1001
    },
    {
      "t": 127255,
      "e": 55995,
      "ty": 41,
      "x": 27183,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127304,
      "e": 56044,
      "ty": 2,
      "x": 844,
      "y": 998
    },
    {
      "t": 127410,
      "e": 56150,
      "ty": 2,
      "x": 838,
      "y": 993
    },
    {
      "t": 127504,
      "e": 56244,
      "ty": 2,
      "x": 811,
      "y": 984
    },
    {
      "t": 127505,
      "e": 56245,
      "ty": 41,
      "x": 25461,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127604,
      "e": 56344,
      "ty": 2,
      "x": 768,
      "y": 970
    },
    {
      "t": 127704,
      "e": 56444,
      "ty": 2,
      "x": 661,
      "y": 946
    },
    {
      "t": 127754,
      "e": 56494,
      "ty": 41,
      "x": 14294,
      "y": 56762,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127804,
      "e": 56544,
      "ty": 2,
      "x": 503,
      "y": 946
    },
    {
      "t": 127905,
      "e": 56645,
      "ty": 2,
      "x": 327,
      "y": 921
    },
    {
      "t": 128004,
      "e": 56744,
      "ty": 2,
      "x": 266,
      "y": 906
    },
    {
      "t": 128004,
      "e": 56744,
      "ty": 41,
      "x": 8884,
      "y": 49746,
      "ta": "> div.masterdiv"
    },
    {
      "t": 128105,
      "e": 56845,
      "ty": 2,
      "x": 249,
      "y": 900
    },
    {
      "t": 128204,
      "e": 56944,
      "ty": 2,
      "x": 194,
      "y": 871
    },
    {
      "t": 128255,
      "e": 56995,
      "ty": 41,
      "x": 5613,
      "y": 47198,
      "ta": "> div.masterdiv"
    },
    {
      "t": 128305,
      "e": 57045,
      "ty": 2,
      "x": 164,
      "y": 859
    },
    {
      "t": 128409,
      "e": 57149,
      "ty": 2,
      "x": 161,
      "y": 858
    },
    {
      "t": 128504,
      "e": 57244,
      "ty": 2,
      "x": 148,
      "y": 843
    },
    {
      "t": 128505,
      "e": 57245,
      "ty": 41,
      "x": 4821,
      "y": 46256,
      "ta": "> div.masterdiv"
    },
    {
      "t": 128616,
      "e": 57356,
      "ty": 2,
      "x": 142,
      "y": 840
    },
    {
      "t": 128754,
      "e": 57494,
      "ty": 41,
      "x": 4614,
      "y": 46090,
      "ta": "> div.masterdiv"
    },
    {
      "t": 129215,
      "e": 57955,
      "ty": 2,
      "x": 134,
      "y": 839
    },
    {
      "t": 129261,
      "e": 58001,
      "ty": 41,
      "x": 4339,
      "y": 46035,
      "ta": "> div.masterdiv"
    },
    {
      "t": 130010,
      "e": 58750,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 165109,
      "e": 63001,
      "ty": 2,
      "x": 143,
      "y": 838
    },
    {
      "t": 165209,
      "e": 63101,
      "ty": 2,
      "x": 233,
      "y": 871
    },
    {
      "t": 165259,
      "e": 63151,
      "ty": 41,
      "x": 272,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 165308,
      "e": 63200,
      "ty": 2,
      "x": 373,
      "y": 912
    },
    {
      "t": 165409,
      "e": 63301,
      "ty": 2,
      "x": 570,
      "y": 935
    },
    {
      "t": 165508,
      "e": 63400,
      "ty": 2,
      "x": 712,
      "y": 966
    },
    {
      "t": 165508,
      "e": 63400,
      "ty": 41,
      "x": 20591,
      "y": 58147,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165608,
      "e": 63500,
      "ty": 2,
      "x": 772,
      "y": 991
    },
    {
      "t": 165708,
      "e": 63600,
      "ty": 2,
      "x": 791,
      "y": 999
    },
    {
      "t": 165759,
      "e": 63651,
      "ty": 41,
      "x": 25068,
      "y": 60709,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165808,
      "e": 63700,
      "ty": 2,
      "x": 825,
      "y": 1007
    },
    {
      "t": 165908,
      "e": 63800,
      "ty": 2,
      "x": 840,
      "y": 1010
    },
    {
      "t": 166008,
      "e": 63900,
      "ty": 2,
      "x": 851,
      "y": 1011
    },
    {
      "t": 166009,
      "e": 63901,
      "ty": 41,
      "x": 27429,
      "y": 61263,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166108,
      "e": 64000,
      "ty": 2,
      "x": 870,
      "y": 1018
    },
    {
      "t": 166209,
      "e": 64101,
      "ty": 2,
      "x": 885,
      "y": 1029
    },
    {
      "t": 166258,
      "e": 64150,
      "ty": 41,
      "x": 29249,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166308,
      "e": 64200,
      "ty": 2,
      "x": 892,
      "y": 1036
    },
    {
      "t": 166408,
      "e": 64300,
      "ty": 2,
      "x": 904,
      "y": 1045
    },
    {
      "t": 166508,
      "e": 64400,
      "ty": 2,
      "x": 919,
      "y": 1054
    },
    {
      "t": 166509,
      "e": 64401,
      "ty": 41,
      "x": 30775,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166608,
      "e": 64500,
      "ty": 2,
      "x": 932,
      "y": 1060
    },
    {
      "t": 166708,
      "e": 64600,
      "ty": 2,
      "x": 941,
      "y": 1065
    },
    {
      "t": 166758,
      "e": 64650,
      "ty": 41,
      "x": 32004,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166808,
      "e": 64700,
      "ty": 2,
      "x": 947,
      "y": 1068
    },
    {
      "t": 166908,
      "e": 64800,
      "ty": 2,
      "x": 950,
      "y": 1069
    },
    {
      "t": 166966,
      "e": 64858,
      "ty": 6,
      "x": 952,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 167008,
      "e": 64900,
      "ty": 2,
      "x": 956,
      "y": 1075
    },
    {
      "t": 167008,
      "e": 64900,
      "ty": 41,
      "x": 25394,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 167109,
      "e": 65001,
      "ty": 2,
      "x": 960,
      "y": 1076
    },
    {
      "t": 167209,
      "e": 65101,
      "ty": 2,
      "x": 971,
      "y": 1077
    },
    {
      "t": 167259,
      "e": 65151,
      "ty": 41,
      "x": 35771,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 167320,
      "e": 65212,
      "ty": 2,
      "x": 976,
      "y": 1077
    },
    {
      "t": 167523,
      "e": 65415,
      "ty": 41,
      "x": 36317,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 167708,
      "e": 65600,
      "ty": 2,
      "x": 978,
      "y": 1083
    },
    {
      "t": 167759,
      "e": 65651,
      "ty": 41,
      "x": 37409,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 167818,
      "e": 65710,
      "ty": 2,
      "x": 978,
      "y": 1088
    },
    {
      "t": 168527,
      "e": 66419,
      "ty": 3,
      "x": 978,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 168528,
      "e": 66420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 168645,
      "e": 66537,
      "ty": 4,
      "x": 37409,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 168645,
      "e": 66537,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 168646,
      "e": 66538,
      "ty": 5,
      "x": 978,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 168646,
      "e": 66538,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 169692,
      "e": 67584,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 170407,
      "e": 68299,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 171057,
      "e": 68949,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2291},\"parentNode\":{\"id\":2289}},{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2300},\"parentNode\":{\"id\":2289}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2301},\"parentNode\":{\"id\":2289}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2289}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2303},\"parentNode\":{\"id\":2289}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2305},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2306},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2307},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2308},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2309},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2310},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2315},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2306}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2306}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2307}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2307}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2308}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2308}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2309}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2309}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2310}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2310}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2344},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2346},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2348},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2350},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2352},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2354},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2356},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2358},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2360},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2362},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2364},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2366},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2368},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2370},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2372},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2374},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2376},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2378},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2380},\"parentNode\":{\"id\":2330}},{\"nodeType\":3,\"id\":2382,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2333}},{\"nodeType\":3,\"id\":2383,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2335}},{\"nodeType\":3,\"id\":2384,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2337}},{\"nodeType\":3,\"id\":2385,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2339}},{\"nodeType\":3,\"id\":2386,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2387,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2343}},{\"nodeType\":3,\"id\":2388,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2345}},{\"nodeType\":3,\"id\":2389,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2347}},{\"nodeType\":3,\"id\":2390,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2349}},{\"nodeType\":3,\"id\":2391,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2351}},{\"nodeType\":3,\"id\":2392,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2353}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2355}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2357}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2359}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2361}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2363}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2365}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2367}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2369}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2371}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2373}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2375}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2377}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2379}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2381}},{\"nodeType\":1,\"id\":2407,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2407}},{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2409},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2410},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2411},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2412},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2414,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2413},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2414},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2415},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2416},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2417},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2418},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2419},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2446},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2436}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2438}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2438}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2439}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2439}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2440}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2460},\"parentNode\":{\"id\":2440}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2441}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2462},\"parentNode\":{\"id\":2441}},{\"nodeType\":1,\"id\":2464,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2442}},{\"nodeType\":1,\"id\":2465,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2464},\"parentNode\":{\"id\":2442}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2443}},{\"nodeType\":1,\"id\":2467,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2466},\"parentNode\":{\"id\":2443}},{\"nodeType\":1,\"id\":2468,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2444}},{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2468},\"parentNode\":{\"id\":2444}},{\"nodeType\":1,\"id\":2470,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2445}},{\"nodeType\":1,\"id\":2471,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2470},\"parentNode\":{\"id\":2445}},{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2446}},{\"nodeType\":1,\"id\":2473,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2472},\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"0\",\"parentNode\":{\"id\":2449}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"1\",\"parentNode\":{\"id\":2451}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"2\",\"parentNode\":{\"id\":2453}},{\"nodeType\":3,\"id\":2477,\"textContent\":\"3\",\"parentNode\":{\"id\":2455}},{\"nodeType\":3,\"id\":2478,\"textContent\":\"4\",\"parentNode\":{\"id\":2457}},{\"nodeType\":3,\"id\":2479,\"textContent\":\"5\",\"parentNode\":{\"id\":2459}},{\"nodeType\":3,\"id\":2480,\"textContent\":\"6\",\"parentNode\":{\"id\":2461}},{\"nodeType\":3,\"id\":2481,\"textContent\":\"7\",\"parentNode\":{\"id\":2463}},{\"nodeType\":3,\"id\":2482,\"textContent\":\"8\",\"parentNode\":{\"id\":2465}},{\"nodeType\":3,\"id\":2483,\"textContent\":\"9\",\"parentNode\":{\"id\":2467}},{\"nodeType\":3,\"id\":2484,\"textContent\":\"10\",\"parentNode\":{\"id\":2469}},{\"nodeType\":3,\"id\":2485,\"textContent\":\"11\",\"parentNode\":{\"id\":2471}},{\"nodeType\":3,\"id\":2486,\"textContent\":\"12\",\"parentNode\":{\"id\":2473}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2447}},{\"nodeType\":3,\"id\":2488,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2489},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2490},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2491},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2492},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2493},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2494},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2495},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2496},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2497},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2498},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2499},\"parentNode\":{\"id\":2303}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2489}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2490}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2491}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2492}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2493}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2494}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2495}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2496}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2497}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2498}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2499}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2500}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2304}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2513}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2513}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2514}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2514}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2515}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2515}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2516}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2516}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2517}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2517}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2518}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2518}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2519}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2519}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2520}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2520}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2521}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2521}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2522}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2522}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2523}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2551},\"parentNode\":{\"id\":2523}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2553},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2557},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2559},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2530}},{\"nodeType\":3,\"id\":2567,\"textContent\":\"A \",\"parentNode\":{\"id\":2532}},{\"nodeType\":3,\"id\":2568,\"textContent\":\"B \",\"parentNode\":{\"id\":2534}},{\"nodeType\":3,\"id\":2569,\"textContent\":\"C \",\"parentNode\":{\"id\":2536}},{\"nodeType\":3,\"id\":2570,\"textContent\":\"D \",\"parentNode\":{\"id\":2538}},{\"nodeType\":3,\"id\":2571,\"textContent\":\"E \",\"parentNode\":{\"id\":2540}},{\"nodeType\":3,\"id\":2572,\"textContent\":\"F \",\"parentNode\":{\"id\":2542}},{\"nodeType\":3,\"id\":2573,\"textContent\":\"G \",\"parentNode\":{\"id\":2544}},{\"nodeType\":3,\"id\":2574,\"textContent\":\"H \",\"parentNode\":{\"id\":2546}},{\"nodeType\":3,\"id\":2575,\"textContent\":\"I \",\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2576,\"textContent\":\"J \",\"parentNode\":{\"id\":2550}},{\"nodeType\":3,\"id\":2577,\"textContent\":\"K \",\"parentNode\":{\"id\":2552}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"L \",\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"M \",\"parentNode\":{\"id\":2556}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"N \",\"parentNode\":{\"id\":2558}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"O \",\"parentNode\":{\"id\":2560}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"P \",\"parentNode\":{\"id\":2562}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \",\"parentNode\":{\"id\":2564}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"X \",\"parentNode\":{\"id\":2566}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2300},{\"id\":2305},{\"id\":2306},{\"id\":2332},{\"id\":2333},{\"id\":2382},{\"id\":2307},{\"id\":2334},{\"id\":2335},{\"id\":2383},{\"id\":2308},{\"id\":2336},{\"id\":2337},{\"id\":2384},{\"id\":2309},{\"id\":2338},{\"id\":2339},{\"id\":2385},{\"id\":2310},{\"id\":2340},{\"id\":2341},{\"id\":2386},{\"id\":2311},{\"id\":2342},{\"id\":2343},{\"id\":2387},{\"id\":2312},{\"id\":2344},{\"id\":2345},{\"id\":2388},{\"id\":2313},{\"id\":2346},{\"id\":2347},{\"id\":2389},{\"id\":2314},{\"id\":2348},{\"id\":2349},{\"id\":2390},{\"id\":2315},{\"id\":2350},{\"id\":2351},{\"id\":2391},{\"id\":2316},{\"id\":2352},{\"id\":2353},{\"id\":2392},{\"id\":2317},{\"id\":2354},{\"id\":2355},{\"id\":2393},{\"id\":2318},{\"id\":2356},{\"id\":2357},{\"id\":2394},{\"id\":2319},{\"id\":2358},{\"id\":2359},{\"id\":2395},{\"id\":2320},{\"id\":2360},{\"id\":2361},{\"id\":2396},{\"id\":2321},{\"id\":2362},{\"id\":2363},{\"id\":2397},{\"id\":2322},{\"id\":2364},{\"id\":2365},{\"id\":2398},{\"id\":2323},{\"id\":2366},{\"id\":2367},{\"id\":2399},{\"id\":2324},{\"id\":2368},{\"id\":2369},{\"id\":2400},{\"id\":2325},{\"id\":2370},{\"id\":2371},{\"id\":2401},{\"id\":2326},{\"id\":2372},{\"id\":2373},{\"id\":2402},{\"id\":2327},{\"id\":2374},{\"id\":2375},{\"id\":2403},{\"id\":2328},{\"id\":2376},{\"id\":2377},{\"id\":2404},{\"id\":2329},{\"id\":2378},{\"id\":2379},{\"id\":2405},{\"id\":2330},{\"id\":2380},{\"id\":2381},{\"id\":2406},{\"id\":2331},{\"id\":2407},{\"id\":2408},{\"id\":2301},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2302},{\"id\":2433},{\"id\":2434},{\"id\":2448},{\"id\":2449},{\"id\":2474},{\"id\":2435},{\"id\":2450},{\"id\":2451},{\"id\":2475},{\"id\":2436},{\"id\":2452},{\"id\":2453},{\"id\":2476},{\"id\":2437},{\"id\":2454},{\"id\":2455},{\"id\":2477},{\"id\":2438},{\"id\":2456},{\"id\":2457},{\"id\":2478},{\"id\":2439},{\"id\":2458},{\"id\":2459},{\"id\":2479},{\"id\":2440},{\"id\":2460},{\"id\":2461},{\"id\":2480},{\"id\":2441},{\"id\":2462},{\"id\":2463},{\"id\":2481},{\"id\":2442},{\"id\":2464},{\"id\":2465},{\"id\":2482},{\"id\":2443},{\"id\":2466},{\"id\":2467},{\"id\":2483},{\"id\":2444},{\"id\":2468},{\"id\":2469},{\"id\":2484},{\"id\":2445},{\"id\":2470},{\"id\":2471},{\"id\":2485},{\"id\":2446},{\"id\":2472},{\"id\":2473},{\"id\":2486},{\"id\":2447},{\"id\":2487},{\"id\":2488},{\"id\":2303},{\"id\":2489},{\"id\":2501},{\"id\":2490},{\"id\":2502},{\"id\":2491},{\"id\":2503},{\"id\":2492},{\"id\":2504},{\"id\":2493},{\"id\":2505},{\"id\":2494},{\"id\":2506},{\"id\":2495},{\"id\":2507},{\"id\":2496},{\"id\":2508},{\"id\":2497},{\"id\":2509},{\"id\":2498},{\"id\":2510},{\"id\":2499},{\"id\":2511},{\"id\":2500},{\"id\":2512},{\"id\":2304},{\"id\":2513},{\"id\":2531},{\"id\":2532},{\"id\":2567},{\"id\":2514},{\"id\":2533},{\"id\":2534},{\"id\":2568},{\"id\":2515},{\"id\":2535},{\"id\":2536},{\"id\":2569},{\"id\":2516},{\"id\":2537},{\"id\":2538},{\"id\":2570},{\"id\":2517},{\"id\":2539},{\"id\":2540},{\"id\":2571},{\"id\":2518},{\"id\":2541},{\"id\":2542},{\"id\":2572},{\"id\":2519},{\"id\":2543},{\"id\":2544},{\"id\":2573},{\"id\":2520},{\"id\":2545},{\"id\":2546},{\"id\":2574},{\"id\":2521},{\"id\":2547},{\"id\":2548},{\"id\":2575},{\"id\":2522},{\"id\":2549},{\"id\":2550},{\"id\":2576},{\"id\":2523},{\"id\":2551},{\"id\":2552},{\"id\":2577},{\"id\":2524},{\"id\":2553},{\"id\":2554},{\"id\":2578},{\"id\":2525},{\"id\":2555},{\"id\":2556},{\"id\":2579},{\"id\":2526},{\"id\":2557},{\"id\":2558},{\"id\":2580},{\"id\":2527},{\"id\":2559},{\"id\":2560},{\"id\":2581},{\"id\":2528},{\"id\":2561},{\"id\":2562},{\"id\":2582},{\"id\":2529},{\"id\":2563},{\"id\":2564},{\"id\":2583},{\"id\":2530},{\"id\":2565},{\"id\":2566},{\"id\":2584},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"nodeType\":3,\"id\":2585,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2297},{\"id\":2298},{\"nodeType\":3,\"id\":2586,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2299}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2588,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2587},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2589,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2588},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2589},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2591,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2588}},{\"nodeType\":1,\"id\":2592,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2591},\"parentNode\":{\"id\":2588}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2591}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2589}},{\"nodeType\":1,\"id\":2595,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2594},\"parentNode\":{\"id\":2589}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2594}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2590}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2587},{\"id\":2588},{\"id\":2591},{\"id\":2593},{\"id\":2592},{\"id\":2589},{\"id\":2594},{\"id\":2596},{\"id\":2595},{\"id\":2590},{\"id\":2597}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2610,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2614,\"textContent\":\"English\",\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2617,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":3,\"id\":2620,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2623,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2624,\"textContent\":\"*\",\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2635}},{\"nodeType\":3,\"id\":2637,\"textContent\":\"First\",\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2635}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":3,\"id\":2640,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":3,\"id\":2646,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"*\",\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2667}},{\"nodeType\":3,\"id\":2669,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2667}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":3,\"id\":2672,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":3,\"id\":2678,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"*\",\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2603}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"*\",\"parentNode\":{\"id\":2694}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"id\":2605},{\"id\":2610},{\"id\":2611},{\"id\":2624},{\"id\":2606},{\"id\":2612},{\"id\":2613},{\"id\":2614},{\"id\":2607},{\"id\":2615},{\"id\":2616},{\"id\":2617},{\"id\":2608},{\"id\":2618},{\"id\":2619},{\"id\":2620},{\"id\":2609},{\"id\":2621},{\"id\":2622},{\"id\":2623},{\"id\":2601},{\"id\":2625},{\"id\":2633},{\"id\":2634},{\"id\":2656},{\"id\":2626},{\"id\":2635},{\"id\":2636},{\"id\":2637},{\"id\":2627},{\"id\":2638},{\"id\":2639},{\"id\":2640},{\"id\":2628},{\"id\":2641},{\"id\":2642},{\"id\":2643},{\"id\":2629},{\"id\":2644},{\"id\":2645},{\"id\":2646},{\"id\":2630},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2631},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2632},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2602},{\"id\":2657},{\"id\":2665},{\"id\":2666},{\"id\":2688},{\"id\":2658},{\"id\":2667},{\"id\":2668},{\"id\":2669},{\"id\":2659},{\"id\":2670},{\"id\":2671},{\"id\":2672},{\"id\":2660},{\"id\":2673},{\"id\":2674},{\"id\":2675},{\"id\":2661},{\"id\":2676},{\"id\":2677},{\"id\":2678},{\"id\":2662},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2663},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2664},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2603},{\"id\":2689},{\"id\":2693},{\"id\":2694},{\"id\":2704},{\"id\":2690},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2691},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2692},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2604}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2706,\"textContent\":\" \",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2707,\"textContent\":\" \",\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2709,\"textContent\":\" \",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2711,\"textContent\":\" \",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2713,\"textContent\":\" \",\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2714,\"textContent\":\" \",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2716,\"textContent\":\" \",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"parentNode\":{\"id\":2715}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2720,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2725,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2728,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2732,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2725}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2740,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"parentNode\":{\"id\":2728}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2744,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2742}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2732}},{\"nodeType\":3,\"id\":2749,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"parentNode\":{\"id\":2712}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2753,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2751}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2705},{\"id\":2707},{\"id\":2708},{\"id\":2714},{\"id\":2715},{\"id\":2717},{\"id\":2718},{\"id\":2720},{\"id\":2719},{\"id\":2716},{\"id\":2709},{\"id\":2710},{\"id\":2721},{\"id\":2722},{\"id\":2724},{\"id\":2725},{\"id\":2736},{\"id\":2726},{\"id\":2737},{\"id\":2738},{\"id\":2740},{\"id\":2739},{\"id\":2727},{\"id\":2728},{\"id\":2741},{\"id\":2742},{\"id\":2744},{\"id\":2743},{\"id\":2729},{\"id\":2730},{\"id\":2745},{\"id\":2747},{\"id\":2746},{\"id\":2731},{\"id\":2732},{\"id\":2748},{\"id\":2733},{\"id\":2734},{\"id\":2749},{\"id\":2735},{\"id\":2723},{\"id\":2711},{\"id\":2712},{\"id\":2750},{\"id\":2751},{\"id\":2753},{\"id\":2752},{\"id\":2713},{\"id\":2706}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2754,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"[ { \\\"rt\\\": 107310, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 107318, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10451, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 119130, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10508, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"TOO\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 130642, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25972, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 157708, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10061, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 168782, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 50148, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 220286, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:909,y:1046,t:1526328316270};\\\", \\\"{x:902,y:1046,t:1526328316513};\\\", \\\"{x:901,y:1046,t:1526328316636};\\\", \\\"{x:900,y:1046,t:1526328316651};\\\", \\\"{x:900,y:1045,t:1526328316668};\\\", \\\"{x:898,y:1045,t:1526328316684};\\\", \\\"{x:898,y:1043,t:1526328316694};\\\", \\\"{x:895,y:1039,t:1526328316710};\\\", \\\"{x:894,y:1038,t:1526328316727};\\\", \\\"{x:893,y:1037,t:1526328316745};\\\", \\\"{x:893,y:1035,t:1526328316761};\\\", \\\"{x:890,y:1032,t:1526328316777};\\\", \\\"{x:889,y:1030,t:1526328316794};\\\", \\\"{x:888,y:1028,t:1526328316811};\\\", \\\"{x:887,y:1026,t:1526328316829};\\\", \\\"{x:886,y:1025,t:1526328316844};\\\", \\\"{x:883,y:1021,t:1526328316862};\\\", \\\"{x:879,y:1016,t:1526328316878};\\\", \\\"{x:875,y:1012,t:1526328316895};\\\", \\\"{x:872,y:1009,t:1526328316912};\\\", \\\"{x:869,y:1007,t:1526328316928};\\\", \\\"{x:864,y:1003,t:1526328316946};\\\", \\\"{x:858,y:999,t:1526328316961};\\\", \\\"{x:852,y:997,t:1526328316978};\\\", \\\"{x:842,y:992,t:1526328316995};\\\", \\\"{x:833,y:987,t:1526328317012};\\\", \\\"{x:822,y:980,t:1526328317028};\\\", \\\"{x:810,y:975,t:1526328317045};\\\", \\\"{x:801,y:971,t:1526328317062};\\\", \\\"{x:798,y:969,t:1526328317078};\\\", \\\"{x:791,y:967,t:1526328317094};\\\", \\\"{x:783,y:961,t:1526328317112};\\\", \\\"{x:771,y:955,t:1526328317128};\\\", \\\"{x:756,y:948,t:1526328317147};\\\", \\\"{x:741,y:942,t:1526328317162};\\\", \\\"{x:730,y:940,t:1526328317178};\\\", \\\"{x:724,y:936,t:1526328317195};\\\", \\\"{x:721,y:936,t:1526328317212};\\\", \\\"{x:719,y:934,t:1526328317229};\\\", \\\"{x:718,y:934,t:1526328317253};\\\", \\\"{x:716,y:933,t:1526328317263};\\\", \\\"{x:715,y:933,t:1526328317280};\\\", \\\"{x:712,y:933,t:1526328317295};\\\", \\\"{x:710,y:933,t:1526328317312};\\\", \\\"{x:706,y:932,t:1526328317329};\\\", \\\"{x:702,y:932,t:1526328317346};\\\", \\\"{x:695,y:932,t:1526328317362};\\\", \\\"{x:689,y:932,t:1526328317379};\\\", \\\"{x:682,y:934,t:1526328317395};\\\", \\\"{x:674,y:935,t:1526328317412};\\\", \\\"{x:668,y:938,t:1526328317429};\\\", \\\"{x:665,y:938,t:1526328317445};\\\", \\\"{x:662,y:939,t:1526328317462};\\\", \\\"{x:658,y:941,t:1526328317479};\\\", \\\"{x:654,y:943,t:1526328317495};\\\", \\\"{x:650,y:944,t:1526328317512};\\\", \\\"{x:649,y:945,t:1526328317530};\\\", \\\"{x:647,y:946,t:1526328317548};\\\", \\\"{x:646,y:947,t:1526328317561};\\\", \\\"{x:644,y:948,t:1526328317579};\\\", \\\"{x:641,y:949,t:1526328317594};\\\", \\\"{x:638,y:950,t:1526328317611};\\\", \\\"{x:634,y:952,t:1526328317628};\\\", \\\"{x:632,y:952,t:1526328317644};\\\", \\\"{x:631,y:952,t:1526328317668};\\\", \\\"{x:630,y:953,t:1526328317679};\\\", \\\"{x:628,y:954,t:1526328317695};\\\", \\\"{x:627,y:955,t:1526328317712};\\\", \\\"{x:625,y:955,t:1526328317729};\\\", \\\"{x:624,y:956,t:1526328317749};\\\", \\\"{x:623,y:956,t:1526328317761};\\\", \\\"{x:622,y:957,t:1526328317779};\\\", \\\"{x:621,y:957,t:1526328317796};\\\", \\\"{x:620,y:957,t:1526328318037};\\\", \\\"{x:619,y:957,t:1526328318060};\\\", \\\"{x:618,y:957,t:1526328318068};\\\", \\\"{x:616,y:957,t:1526328318079};\\\", \\\"{x:614,y:957,t:1526328318095};\\\", \\\"{x:609,y:956,t:1526328318112};\\\", \\\"{x:606,y:955,t:1526328318129};\\\", \\\"{x:606,y:954,t:1526328318146};\\\", \\\"{x:607,y:954,t:1526328318310};\\\", \\\"{x:609,y:954,t:1526328318317};\\\", \\\"{x:614,y:954,t:1526328318333};\\\", \\\"{x:618,y:954,t:1526328318346};\\\", \\\"{x:631,y:954,t:1526328318362};\\\", \\\"{x:646,y:954,t:1526328318379};\\\", \\\"{x:680,y:954,t:1526328318396};\\\", \\\"{x:707,y:954,t:1526328318412};\\\", \\\"{x:740,y:954,t:1526328318428};\\\", \\\"{x:772,y:954,t:1526328318446};\\\", \\\"{x:812,y:954,t:1526328318462};\\\", \\\"{x:852,y:954,t:1526328318479};\\\", \\\"{x:888,y:954,t:1526328318496};\\\", \\\"{x:919,y:954,t:1526328318512};\\\", \\\"{x:946,y:954,t:1526328318529};\\\", \\\"{x:969,y:954,t:1526328318546};\\\", \\\"{x:993,y:954,t:1526328318562};\\\", \\\"{x:1012,y:954,t:1526328318579};\\\", \\\"{x:1042,y:954,t:1526328318596};\\\", \\\"{x:1064,y:953,t:1526328318612};\\\", \\\"{x:1087,y:953,t:1526328318629};\\\", \\\"{x:1112,y:953,t:1526328318647};\\\", \\\"{x:1137,y:949,t:1526328318663};\\\", \\\"{x:1161,y:949,t:1526328318679};\\\", \\\"{x:1185,y:948,t:1526328318697};\\\", \\\"{x:1210,y:948,t:1526328318714};\\\", \\\"{x:1232,y:948,t:1526328318729};\\\", \\\"{x:1251,y:948,t:1526328318747};\\\", \\\"{x:1266,y:948,t:1526328318762};\\\", \\\"{x:1278,y:948,t:1526328318780};\\\", \\\"{x:1283,y:948,t:1526328318796};\\\", \\\"{x:1283,y:949,t:1526328319070};\\\", \\\"{x:1283,y:951,t:1526328319082};\\\", \\\"{x:1283,y:952,t:1526328319098};\\\", \\\"{x:1283,y:953,t:1526328319114};\\\", \\\"{x:1283,y:954,t:1526328319130};\\\", \\\"{x:1283,y:955,t:1526328319148};\\\", \\\"{x:1283,y:957,t:1526328319163};\\\", \\\"{x:1283,y:958,t:1526328319180};\\\", \\\"{x:1283,y:962,t:1526328319197};\\\", \\\"{x:1283,y:965,t:1526328319213};\\\", \\\"{x:1283,y:967,t:1526328319230};\\\", \\\"{x:1283,y:968,t:1526328319248};\\\", \\\"{x:1283,y:970,t:1526328319333};\\\", \\\"{x:1283,y:969,t:1526328320934};\\\", \\\"{x:1283,y:967,t:1526328321429};\\\", \\\"{x:1283,y:965,t:1526328321446};\\\", \\\"{x:1283,y:964,t:1526328321453};\\\", \\\"{x:1283,y:962,t:1526328321478};\\\", \\\"{x:1283,y:961,t:1526328321638};\\\", \\\"{x:1283,y:959,t:1526328321654};\\\", \\\"{x:1283,y:958,t:1526328321665};\\\", \\\"{x:1283,y:955,t:1526328321683};\\\", \\\"{x:1283,y:952,t:1526328321698};\\\", \\\"{x:1283,y:950,t:1526328321716};\\\", \\\"{x:1283,y:948,t:1526328321732};\\\", \\\"{x:1283,y:946,t:1526328321749};\\\", \\\"{x:1283,y:945,t:1526328321766};\\\", \\\"{x:1283,y:943,t:1526328321783};\\\", \\\"{x:1283,y:942,t:1526328321799};\\\", \\\"{x:1283,y:939,t:1526328321815};\\\", \\\"{x:1283,y:937,t:1526328321833};\\\", \\\"{x:1283,y:934,t:1526328321849};\\\", \\\"{x:1283,y:930,t:1526328321866};\\\", \\\"{x:1283,y:926,t:1526328321883};\\\", \\\"{x:1283,y:923,t:1526328321898};\\\", \\\"{x:1283,y:919,t:1526328321916};\\\", \\\"{x:1283,y:915,t:1526328321932};\\\", \\\"{x:1283,y:909,t:1526328321948};\\\", \\\"{x:1283,y:900,t:1526328321965};\\\", \\\"{x:1283,y:895,t:1526328321982};\\\", \\\"{x:1283,y:891,t:1526328322000};\\\", \\\"{x:1283,y:889,t:1526328322015};\\\", \\\"{x:1283,y:886,t:1526328322033};\\\", \\\"{x:1283,y:884,t:1526328322049};\\\", \\\"{x:1283,y:882,t:1526328322066};\\\", \\\"{x:1283,y:880,t:1526328322083};\\\", \\\"{x:1283,y:877,t:1526328322099};\\\", \\\"{x:1283,y:876,t:1526328322115};\\\", \\\"{x:1283,y:874,t:1526328322132};\\\", \\\"{x:1283,y:871,t:1526328322149};\\\", \\\"{x:1283,y:868,t:1526328322165};\\\", \\\"{x:1283,y:867,t:1526328322183};\\\", \\\"{x:1283,y:865,t:1526328322200};\\\", \\\"{x:1283,y:863,t:1526328322216};\\\", \\\"{x:1283,y:861,t:1526328322232};\\\", \\\"{x:1283,y:859,t:1526328322250};\\\", \\\"{x:1283,y:857,t:1526328322265};\\\", \\\"{x:1282,y:855,t:1526328322282};\\\", \\\"{x:1282,y:854,t:1526328322299};\\\", \\\"{x:1282,y:851,t:1526328322316};\\\", \\\"{x:1281,y:847,t:1526328322332};\\\", \\\"{x:1281,y:843,t:1526328322350};\\\", \\\"{x:1280,y:841,t:1526328322366};\\\", \\\"{x:1279,y:837,t:1526328322383};\\\", \\\"{x:1279,y:835,t:1526328322399};\\\", \\\"{x:1278,y:833,t:1526328322416};\\\", \\\"{x:1278,y:831,t:1526328322433};\\\", \\\"{x:1278,y:829,t:1526328322449};\\\", \\\"{x:1278,y:828,t:1526328322466};\\\", \\\"{x:1278,y:827,t:1526328322483};\\\", \\\"{x:1278,y:826,t:1526328322501};\\\", \\\"{x:1277,y:825,t:1526328322516};\\\", \\\"{x:1277,y:824,t:1526328322541};\\\", \\\"{x:1277,y:823,t:1526328322557};\\\", \\\"{x:1277,y:822,t:1526328322573};\\\", \\\"{x:1277,y:821,t:1526328322589};\\\", \\\"{x:1277,y:820,t:1526328322600};\\\", \\\"{x:1277,y:819,t:1526328322616};\\\", \\\"{x:1277,y:817,t:1526328322633};\\\", \\\"{x:1277,y:815,t:1526328322649};\\\", \\\"{x:1277,y:813,t:1526328322666};\\\", \\\"{x:1277,y:810,t:1526328322682};\\\", \\\"{x:1277,y:808,t:1526328322700};\\\", \\\"{x:1277,y:803,t:1526328322717};\\\", \\\"{x:1277,y:800,t:1526328322733};\\\", \\\"{x:1277,y:794,t:1526328322750};\\\", \\\"{x:1277,y:789,t:1526328322765};\\\", \\\"{x:1277,y:785,t:1526328322781};\\\", \\\"{x:1277,y:780,t:1526328322799};\\\", \\\"{x:1277,y:774,t:1526328322816};\\\", \\\"{x:1277,y:769,t:1526328322832};\\\", \\\"{x:1278,y:765,t:1526328322849};\\\", \\\"{x:1279,y:761,t:1526328322866};\\\", \\\"{x:1279,y:757,t:1526328322882};\\\", \\\"{x:1279,y:754,t:1526328322899};\\\", \\\"{x:1280,y:750,t:1526328322916};\\\", \\\"{x:1282,y:745,t:1526328322933};\\\", \\\"{x:1282,y:741,t:1526328322949};\\\", \\\"{x:1283,y:739,t:1526328322966};\\\", \\\"{x:1284,y:736,t:1526328322983};\\\", \\\"{x:1284,y:733,t:1526328322999};\\\", \\\"{x:1285,y:730,t:1526328323016};\\\", \\\"{x:1285,y:728,t:1526328323033};\\\", \\\"{x:1285,y:726,t:1526328323049};\\\", \\\"{x:1285,y:724,t:1526328323066};\\\", \\\"{x:1285,y:721,t:1526328323084};\\\", \\\"{x:1285,y:718,t:1526328323099};\\\", \\\"{x:1285,y:715,t:1526328323116};\\\", \\\"{x:1285,y:711,t:1526328323133};\\\", \\\"{x:1285,y:709,t:1526328323150};\\\", \\\"{x:1285,y:707,t:1526328323166};\\\", \\\"{x:1285,y:703,t:1526328323184};\\\", \\\"{x:1285,y:702,t:1526328323199};\\\", \\\"{x:1285,y:700,t:1526328323216};\\\", \\\"{x:1285,y:697,t:1526328323234};\\\", \\\"{x:1285,y:694,t:1526328323249};\\\", \\\"{x:1285,y:690,t:1526328323266};\\\", \\\"{x:1285,y:688,t:1526328323283};\\\", \\\"{x:1285,y:684,t:1526328323299};\\\", \\\"{x:1285,y:681,t:1526328323317};\\\", \\\"{x:1285,y:675,t:1526328323333};\\\", \\\"{x:1285,y:671,t:1526328323350};\\\", \\\"{x:1285,y:666,t:1526328323367};\\\", \\\"{x:1285,y:662,t:1526328323383};\\\", \\\"{x:1282,y:657,t:1526328323401};\\\", \\\"{x:1282,y:652,t:1526328323417};\\\", \\\"{x:1282,y:648,t:1526328323434};\\\", \\\"{x:1281,y:643,t:1526328323451};\\\", \\\"{x:1280,y:637,t:1526328323466};\\\", \\\"{x:1279,y:632,t:1526328323484};\\\", \\\"{x:1278,y:624,t:1526328323501};\\\", \\\"{x:1276,y:614,t:1526328323517};\\\", \\\"{x:1274,y:607,t:1526328323533};\\\", \\\"{x:1273,y:602,t:1526328323550};\\\", \\\"{x:1272,y:597,t:1526328323567};\\\", \\\"{x:1272,y:591,t:1526328323584};\\\", \\\"{x:1270,y:585,t:1526328323601};\\\", \\\"{x:1270,y:579,t:1526328323617};\\\", \\\"{x:1270,y:574,t:1526328323634};\\\", \\\"{x:1270,y:570,t:1526328323650};\\\", \\\"{x:1270,y:568,t:1526328323666};\\\", \\\"{x:1270,y:566,t:1526328323684};\\\", \\\"{x:1270,y:565,t:1526328323700};\\\", \\\"{x:1270,y:564,t:1526328323837};\\\", \\\"{x:1271,y:563,t:1526328323878};\\\", \\\"{x:1272,y:563,t:1526328323893};\\\", \\\"{x:1273,y:563,t:1526328323909};\\\", \\\"{x:1274,y:562,t:1526328323974};\\\", \\\"{x:1275,y:561,t:1526328323989};\\\", \\\"{x:1276,y:561,t:1526328324001};\\\", \\\"{x:1277,y:560,t:1526328324037};\\\", \\\"{x:1278,y:560,t:1526328324051};\\\", \\\"{x:1279,y:560,t:1526328324077};\\\", \\\"{x:1279,y:562,t:1526328326201};\\\", \\\"{x:1279,y:563,t:1526328327778};\\\", \\\"{x:1279,y:564,t:1526328327791};\\\", \\\"{x:1276,y:566,t:1526328331818};\\\", \\\"{x:1265,y:571,t:1526328331833};\\\", \\\"{x:1260,y:573,t:1526328331843};\\\", \\\"{x:1250,y:573,t:1526328331860};\\\", \\\"{x:1244,y:576,t:1526328331876};\\\", \\\"{x:1243,y:577,t:1526328331893};\\\", \\\"{x:1241,y:577,t:1526328331961};\\\", \\\"{x:1238,y:582,t:1526328331976};\\\", \\\"{x:1236,y:587,t:1526328331993};\\\", \\\"{x:1235,y:593,t:1526328332010};\\\", \\\"{x:1235,y:600,t:1526328332027};\\\", \\\"{x:1235,y:607,t:1526328332043};\\\", \\\"{x:1238,y:614,t:1526328332060};\\\", \\\"{x:1238,y:619,t:1526328332077};\\\", \\\"{x:1238,y:621,t:1526328332093};\\\", \\\"{x:1238,y:627,t:1526328332110};\\\", \\\"{x:1241,y:632,t:1526328332127};\\\", \\\"{x:1241,y:635,t:1526328332144};\\\", \\\"{x:1242,y:639,t:1526328332161};\\\", \\\"{x:1242,y:640,t:1526328332217};\\\", \\\"{x:1243,y:641,t:1526328332233};\\\", \\\"{x:1244,y:641,t:1526328332244};\\\", \\\"{x:1245,y:641,t:1526328332260};\\\", \\\"{x:1247,y:638,t:1526328332277};\\\", \\\"{x:1248,y:635,t:1526328332296};\\\", \\\"{x:1250,y:632,t:1526328332310};\\\", \\\"{x:1250,y:630,t:1526328332327};\\\", \\\"{x:1250,y:629,t:1526328332345};\\\", \\\"{x:1250,y:628,t:1526328332376};\\\", \\\"{x:1250,y:627,t:1526328332417};\\\", \\\"{x:1250,y:625,t:1526328332433};\\\", \\\"{x:1249,y:625,t:1526328332729};\\\", \\\"{x:1249,y:626,t:1526328332745};\\\", \\\"{x:1249,y:629,t:1526328332761};\\\", \\\"{x:1249,y:631,t:1526328332778};\\\", \\\"{x:1249,y:634,t:1526328332793};\\\", \\\"{x:1249,y:636,t:1526328332810};\\\", \\\"{x:1249,y:638,t:1526328332828};\\\", \\\"{x:1250,y:641,t:1526328332844};\\\", \\\"{x:1250,y:642,t:1526328332861};\\\", \\\"{x:1251,y:645,t:1526328332877};\\\", \\\"{x:1252,y:649,t:1526328332894};\\\", \\\"{x:1253,y:652,t:1526328332911};\\\", \\\"{x:1254,y:655,t:1526328332928};\\\", \\\"{x:1254,y:656,t:1526328332944};\\\", \\\"{x:1255,y:661,t:1526328332961};\\\", \\\"{x:1255,y:665,t:1526328332978};\\\", \\\"{x:1256,y:667,t:1526328332994};\\\", \\\"{x:1256,y:669,t:1526328333010};\\\", \\\"{x:1256,y:671,t:1526328333027};\\\", \\\"{x:1256,y:672,t:1526328333045};\\\", \\\"{x:1257,y:675,t:1526328333061};\\\", \\\"{x:1257,y:678,t:1526328333078};\\\", \\\"{x:1257,y:681,t:1526328333095};\\\", \\\"{x:1257,y:685,t:1526328333110};\\\", \\\"{x:1257,y:688,t:1526328333128};\\\", \\\"{x:1257,y:695,t:1526328333145};\\\", \\\"{x:1257,y:698,t:1526328333161};\\\", \\\"{x:1257,y:702,t:1526328333178};\\\", \\\"{x:1256,y:706,t:1526328333195};\\\", \\\"{x:1255,y:710,t:1526328333211};\\\", \\\"{x:1254,y:713,t:1526328333228};\\\", \\\"{x:1254,y:716,t:1526328333245};\\\", \\\"{x:1254,y:720,t:1526328333261};\\\", \\\"{x:1253,y:723,t:1526328333277};\\\", \\\"{x:1253,y:728,t:1526328333294};\\\", \\\"{x:1250,y:733,t:1526328333311};\\\", \\\"{x:1250,y:737,t:1526328333328};\\\", \\\"{x:1247,y:745,t:1526328333345};\\\", \\\"{x:1246,y:750,t:1526328333361};\\\", \\\"{x:1246,y:752,t:1526328333378};\\\", \\\"{x:1245,y:754,t:1526328333395};\\\", \\\"{x:1245,y:757,t:1526328333411};\\\", \\\"{x:1245,y:759,t:1526328333428};\\\", \\\"{x:1243,y:762,t:1526328333445};\\\", \\\"{x:1243,y:764,t:1526328333461};\\\", \\\"{x:1243,y:766,t:1526328333479};\\\", \\\"{x:1243,y:767,t:1526328333495};\\\", \\\"{x:1242,y:769,t:1526328333512};\\\", \\\"{x:1242,y:771,t:1526328333528};\\\", \\\"{x:1242,y:774,t:1526328333545};\\\", \\\"{x:1242,y:776,t:1526328333563};\\\", \\\"{x:1242,y:778,t:1526328333578};\\\", \\\"{x:1242,y:779,t:1526328333596};\\\", \\\"{x:1242,y:780,t:1526328333612};\\\", \\\"{x:1242,y:782,t:1526328333628};\\\", \\\"{x:1242,y:784,t:1526328333646};\\\", \\\"{x:1243,y:786,t:1526328333662};\\\", \\\"{x:1244,y:791,t:1526328333678};\\\", \\\"{x:1245,y:794,t:1526328333695};\\\", \\\"{x:1246,y:794,t:1526328333712};\\\", \\\"{x:1246,y:797,t:1526328333728};\\\", \\\"{x:1248,y:801,t:1526328333745};\\\", \\\"{x:1249,y:804,t:1526328333763};\\\", \\\"{x:1250,y:806,t:1526328333778};\\\", \\\"{x:1250,y:807,t:1526328333795};\\\", \\\"{x:1251,y:809,t:1526328333812};\\\", \\\"{x:1251,y:812,t:1526328333828};\\\", \\\"{x:1253,y:815,t:1526328333845};\\\", \\\"{x:1253,y:817,t:1526328333862};\\\", \\\"{x:1253,y:820,t:1526328333878};\\\", \\\"{x:1254,y:823,t:1526328333895};\\\", \\\"{x:1254,y:828,t:1526328333913};\\\", \\\"{x:1255,y:835,t:1526328333929};\\\", \\\"{x:1255,y:842,t:1526328333945};\\\", \\\"{x:1255,y:847,t:1526328333962};\\\", \\\"{x:1255,y:850,t:1526328333979};\\\", \\\"{x:1255,y:854,t:1526328333995};\\\", \\\"{x:1255,y:858,t:1526328334012};\\\", \\\"{x:1255,y:863,t:1526328334029};\\\", \\\"{x:1255,y:867,t:1526328334046};\\\", \\\"{x:1255,y:871,t:1526328334063};\\\", \\\"{x:1254,y:876,t:1526328334079};\\\", \\\"{x:1254,y:878,t:1526328334095};\\\", \\\"{x:1253,y:882,t:1526328334113};\\\", \\\"{x:1252,y:885,t:1526328334130};\\\", \\\"{x:1252,y:886,t:1526328334145};\\\", \\\"{x:1252,y:887,t:1526328334177};\\\", \\\"{x:1252,y:888,t:1526328334193};\\\", \\\"{x:1252,y:889,t:1526328334218};\\\", \\\"{x:1251,y:889,t:1526328334230};\\\", \\\"{x:1250,y:890,t:1526328334246};\\\", \\\"{x:1250,y:891,t:1526328334264};\\\", \\\"{x:1249,y:892,t:1526328334278};\\\", \\\"{x:1249,y:894,t:1526328334295};\\\", \\\"{x:1249,y:896,t:1526328334312};\\\", \\\"{x:1247,y:900,t:1526328334328};\\\", \\\"{x:1246,y:904,t:1526328334345};\\\", \\\"{x:1245,y:907,t:1526328334362};\\\", \\\"{x:1243,y:912,t:1526328334379};\\\", \\\"{x:1241,y:915,t:1526328334394};\\\", \\\"{x:1240,y:918,t:1526328334412};\\\", \\\"{x:1240,y:920,t:1526328334429};\\\", \\\"{x:1240,y:923,t:1526328334445};\\\", \\\"{x:1240,y:925,t:1526328334462};\\\", \\\"{x:1239,y:926,t:1526328334479};\\\", \\\"{x:1239,y:928,t:1526328334496};\\\", \\\"{x:1238,y:930,t:1526328334512};\\\", \\\"{x:1236,y:932,t:1526328345282};\\\", \\\"{x:1236,y:933,t:1526328345288};\\\", \\\"{x:1235,y:934,t:1526328345310};\\\", \\\"{x:1232,y:937,t:1526328345321};\\\", \\\"{x:1231,y:939,t:1526328345338};\\\", \\\"{x:1229,y:942,t:1526328345353};\\\", \\\"{x:1229,y:944,t:1526328345369};\\\", \\\"{x:1229,y:946,t:1526328345387};\\\", \\\"{x:1229,y:947,t:1526328345456};\\\", \\\"{x:1231,y:947,t:1526328345504};\\\", \\\"{x:1232,y:947,t:1526328345520};\\\", \\\"{x:1234,y:947,t:1526328345537};\\\", \\\"{x:1235,y:947,t:1526328345553};\\\", \\\"{x:1236,y:947,t:1526328345571};\\\", \\\"{x:1237,y:947,t:1526328345587};\\\", \\\"{x:1238,y:947,t:1526328345603};\\\", \\\"{x:1239,y:947,t:1526328345620};\\\", \\\"{x:1241,y:947,t:1526328345637};\\\", \\\"{x:1242,y:947,t:1526328345656};\\\", \\\"{x:1243,y:947,t:1526328345670};\\\", \\\"{x:1244,y:947,t:1526328345704};\\\", \\\"{x:1245,y:947,t:1526328345729};\\\", \\\"{x:1246,y:947,t:1526328345737};\\\", \\\"{x:1247,y:947,t:1526328345753};\\\", \\\"{x:1250,y:947,t:1526328345771};\\\", \\\"{x:1251,y:947,t:1526328345787};\\\", \\\"{x:1254,y:950,t:1526328345804};\\\", \\\"{x:1256,y:950,t:1526328345820};\\\", \\\"{x:1257,y:950,t:1526328345838};\\\", \\\"{x:1258,y:950,t:1526328345853};\\\", \\\"{x:1259,y:951,t:1526328345871};\\\", \\\"{x:1260,y:951,t:1526328345888};\\\", \\\"{x:1261,y:952,t:1526328345904};\\\", \\\"{x:1263,y:953,t:1526328345921};\\\", \\\"{x:1264,y:954,t:1526328345937};\\\", \\\"{x:1264,y:955,t:1526328345985};\\\", \\\"{x:1265,y:955,t:1526328345993};\\\", \\\"{x:1266,y:956,t:1526328346008};\\\", \\\"{x:1267,y:957,t:1526328346025};\\\", \\\"{x:1269,y:957,t:1526328346049};\\\", \\\"{x:1269,y:958,t:1526328346065};\\\", \\\"{x:1270,y:958,t:1526328346072};\\\", \\\"{x:1272,y:959,t:1526328346096};\\\", \\\"{x:1273,y:959,t:1526328346112};\\\", \\\"{x:1273,y:960,t:1526328346120};\\\", \\\"{x:1276,y:960,t:1526328346137};\\\", \\\"{x:1278,y:961,t:1526328346153};\\\", \\\"{x:1280,y:961,t:1526328346171};\\\", \\\"{x:1281,y:962,t:1526328346187};\\\", \\\"{x:1282,y:962,t:1526328346203};\\\", \\\"{x:1283,y:961,t:1526328359929};\\\", \\\"{x:1283,y:957,t:1526328359936};\\\", \\\"{x:1283,y:951,t:1526328359954};\\\", \\\"{x:1282,y:949,t:1526328359963};\\\", \\\"{x:1281,y:944,t:1526328359981};\\\", \\\"{x:1280,y:939,t:1526328359996};\\\", \\\"{x:1278,y:936,t:1526328360014};\\\", \\\"{x:1278,y:935,t:1526328360031};\\\", \\\"{x:1277,y:933,t:1526328360048};\\\", \\\"{x:1276,y:933,t:1526328360087};\\\", \\\"{x:1276,y:932,t:1526328360160};\\\", \\\"{x:1276,y:930,t:1526328360168};\\\", \\\"{x:1276,y:929,t:1526328360181};\\\", \\\"{x:1276,y:925,t:1526328360197};\\\", \\\"{x:1276,y:922,t:1526328360214};\\\", \\\"{x:1276,y:916,t:1526328360231};\\\", \\\"{x:1276,y:912,t:1526328360247};\\\", \\\"{x:1276,y:908,t:1526328360264};\\\", \\\"{x:1276,y:906,t:1526328360281};\\\", \\\"{x:1276,y:904,t:1526328360297};\\\", \\\"{x:1276,y:901,t:1526328360314};\\\", \\\"{x:1276,y:899,t:1526328360331};\\\", \\\"{x:1276,y:895,t:1526328360347};\\\", \\\"{x:1276,y:892,t:1526328360364};\\\", \\\"{x:1276,y:888,t:1526328360381};\\\", \\\"{x:1276,y:884,t:1526328360397};\\\", \\\"{x:1276,y:878,t:1526328360414};\\\", \\\"{x:1276,y:869,t:1526328360431};\\\", \\\"{x:1276,y:862,t:1526328360446};\\\", \\\"{x:1278,y:856,t:1526328360464};\\\", \\\"{x:1278,y:850,t:1526328360481};\\\", \\\"{x:1278,y:844,t:1526328360498};\\\", \\\"{x:1278,y:840,t:1526328360514};\\\", \\\"{x:1278,y:835,t:1526328360531};\\\", \\\"{x:1278,y:834,t:1526328360549};\\\", \\\"{x:1279,y:832,t:1526328360564};\\\", \\\"{x:1280,y:831,t:1526328360581};\\\", \\\"{x:1280,y:829,t:1526328360598};\\\", \\\"{x:1280,y:828,t:1526328360614};\\\", \\\"{x:1280,y:826,t:1526328360631};\\\", \\\"{x:1280,y:825,t:1526328360648};\\\", \\\"{x:1280,y:823,t:1526328360664};\\\", \\\"{x:1280,y:822,t:1526328360935};\\\", \\\"{x:1280,y:818,t:1526328360951};\\\", \\\"{x:1280,y:816,t:1526328360966};\\\", \\\"{x:1278,y:811,t:1526328360981};\\\", \\\"{x:1278,y:805,t:1526328360998};\\\", \\\"{x:1278,y:800,t:1526328361014};\\\", \\\"{x:1278,y:792,t:1526328361031};\\\", \\\"{x:1278,y:789,t:1526328361048};\\\", \\\"{x:1278,y:783,t:1526328361064};\\\", \\\"{x:1278,y:778,t:1526328361081};\\\", \\\"{x:1277,y:774,t:1526328361099};\\\", \\\"{x:1277,y:767,t:1526328361114};\\\", \\\"{x:1277,y:762,t:1526328361131};\\\", \\\"{x:1277,y:756,t:1526328361148};\\\", \\\"{x:1277,y:751,t:1526328361164};\\\", \\\"{x:1276,y:745,t:1526328361181};\\\", \\\"{x:1275,y:739,t:1526328361198};\\\", \\\"{x:1275,y:735,t:1526328361214};\\\", \\\"{x:1274,y:729,t:1526328361231};\\\", \\\"{x:1273,y:725,t:1526328361248};\\\", \\\"{x:1273,y:721,t:1526328361265};\\\", \\\"{x:1273,y:717,t:1526328361281};\\\", \\\"{x:1272,y:712,t:1526328361298};\\\", \\\"{x:1272,y:708,t:1526328361316};\\\", \\\"{x:1272,y:705,t:1526328361331};\\\", \\\"{x:1272,y:703,t:1526328361348};\\\", \\\"{x:1272,y:700,t:1526328361365};\\\", \\\"{x:1272,y:698,t:1526328361381};\\\", \\\"{x:1272,y:697,t:1526328361398};\\\", \\\"{x:1272,y:694,t:1526328361415};\\\", \\\"{x:1272,y:692,t:1526328361431};\\\", \\\"{x:1272,y:691,t:1526328361448};\\\", \\\"{x:1272,y:689,t:1526328361465};\\\", \\\"{x:1272,y:688,t:1526328361487};\\\", \\\"{x:1272,y:687,t:1526328361591};\\\", \\\"{x:1272,y:686,t:1526328361607};\\\", \\\"{x:1272,y:685,t:1526328361639};\\\", \\\"{x:1272,y:684,t:1526328361649};\\\", \\\"{x:1272,y:682,t:1526328361665};\\\", \\\"{x:1273,y:679,t:1526328361682};\\\", \\\"{x:1273,y:676,t:1526328361698};\\\", \\\"{x:1274,y:671,t:1526328361714};\\\", \\\"{x:1275,y:667,t:1526328361732};\\\", \\\"{x:1275,y:662,t:1526328361749};\\\", \\\"{x:1275,y:656,t:1526328361765};\\\", \\\"{x:1275,y:649,t:1526328361781};\\\", \\\"{x:1276,y:641,t:1526328361799};\\\", \\\"{x:1277,y:636,t:1526328361815};\\\", \\\"{x:1278,y:630,t:1526328361831};\\\", \\\"{x:1278,y:626,t:1526328361849};\\\", \\\"{x:1279,y:623,t:1526328361864};\\\", \\\"{x:1279,y:621,t:1526328361881};\\\", \\\"{x:1279,y:617,t:1526328361898};\\\", \\\"{x:1281,y:612,t:1526328361915};\\\", \\\"{x:1281,y:609,t:1526328361932};\\\", \\\"{x:1281,y:605,t:1526328361949};\\\", \\\"{x:1282,y:600,t:1526328361965};\\\", \\\"{x:1282,y:594,t:1526328361981};\\\", \\\"{x:1282,y:587,t:1526328361999};\\\", \\\"{x:1282,y:582,t:1526328362015};\\\", \\\"{x:1282,y:578,t:1526328362031};\\\", \\\"{x:1282,y:574,t:1526328362049};\\\", \\\"{x:1282,y:572,t:1526328362065};\\\", \\\"{x:1282,y:570,t:1526328362081};\\\", \\\"{x:1282,y:569,t:1526328362098};\\\", \\\"{x:1282,y:568,t:1526328362119};\\\", \\\"{x:1281,y:568,t:1526328363200};\\\", \\\"{x:1280,y:568,t:1526328363231};\\\", \\\"{x:1279,y:568,t:1526328363247};\\\", \\\"{x:1279,y:569,t:1526328363311};\\\", \\\"{x:1278,y:570,t:1526328363326};\\\", \\\"{x:1278,y:571,t:1526328363335};\\\", \\\"{x:1278,y:572,t:1526328363349};\\\", \\\"{x:1277,y:572,t:1526328363366};\\\", \\\"{x:1277,y:574,t:1526328363383};\\\", \\\"{x:1277,y:576,t:1526328363439};\\\", \\\"{x:1276,y:576,t:1526328363471};\\\", \\\"{x:1276,y:577,t:1526328363486};\\\", \\\"{x:1276,y:578,t:1526328363502};\\\", \\\"{x:1275,y:580,t:1526328363517};\\\", \\\"{x:1274,y:582,t:1526328363532};\\\", \\\"{x:1271,y:585,t:1526328363549};\\\", \\\"{x:1268,y:590,t:1526328363567};\\\", \\\"{x:1257,y:601,t:1526328363583};\\\", \\\"{x:1242,y:612,t:1526328363600};\\\", \\\"{x:1224,y:621,t:1526328363616};\\\", \\\"{x:1185,y:639,t:1526328363633};\\\", \\\"{x:1117,y:655,t:1526328363649};\\\", \\\"{x:1018,y:664,t:1526328363667};\\\", \\\"{x:907,y:666,t:1526328363684};\\\", \\\"{x:785,y:666,t:1526328363700};\\\", \\\"{x:655,y:666,t:1526328363717};\\\", \\\"{x:525,y:666,t:1526328363733};\\\", \\\"{x:422,y:666,t:1526328363750};\\\", \\\"{x:341,y:666,t:1526328363766};\\\", \\\"{x:278,y:666,t:1526328363784};\\\", \\\"{x:262,y:666,t:1526328363800};\\\", \\\"{x:260,y:666,t:1526328363817};\\\", \\\"{x:265,y:663,t:1526328363880};\\\", \\\"{x:268,y:661,t:1526328363888};\\\", \\\"{x:272,y:660,t:1526328363901};\\\", \\\"{x:277,y:655,t:1526328363917};\\\", \\\"{x:283,y:653,t:1526328363933};\\\", \\\"{x:290,y:648,t:1526328363952};\\\", \\\"{x:298,y:643,t:1526328363966};\\\", \\\"{x:310,y:637,t:1526328363983};\\\", \\\"{x:316,y:634,t:1526328364003};\\\", \\\"{x:323,y:632,t:1526328364021};\\\", \\\"{x:324,y:630,t:1526328364037};\\\", \\\"{x:329,y:627,t:1526328364055};\\\", \\\"{x:339,y:624,t:1526328364071};\\\", \\\"{x:371,y:616,t:1526328364087};\\\", \\\"{x:404,y:606,t:1526328364106};\\\", \\\"{x:448,y:597,t:1526328364121};\\\", \\\"{x:498,y:589,t:1526328364137};\\\", \\\"{x:548,y:583,t:1526328364154};\\\", \\\"{x:591,y:576,t:1526328364171};\\\", \\\"{x:638,y:572,t:1526328364187};\\\", \\\"{x:669,y:568,t:1526328364205};\\\", \\\"{x:702,y:563,t:1526328364220};\\\", \\\"{x:727,y:559,t:1526328364239};\\\", \\\"{x:749,y:556,t:1526328364253};\\\", \\\"{x:763,y:553,t:1526328364271};\\\", \\\"{x:775,y:552,t:1526328364287};\\\", \\\"{x:777,y:551,t:1526328364305};\\\", \\\"{x:778,y:551,t:1526328364353};\\\", \\\"{x:778,y:550,t:1526328364376};\\\", \\\"{x:779,y:549,t:1526328364389};\\\", \\\"{x:781,y:545,t:1526328364405};\\\", \\\"{x:787,y:539,t:1526328364422};\\\", \\\"{x:796,y:533,t:1526328364438};\\\", \\\"{x:800,y:530,t:1526328364454};\\\", \\\"{x:804,y:527,t:1526328364471};\\\", \\\"{x:807,y:524,t:1526328364487};\\\", \\\"{x:808,y:522,t:1526328364511};\\\", \\\"{x:809,y:522,t:1526328364521};\\\", \\\"{x:813,y:519,t:1526328364538};\\\", \\\"{x:819,y:516,t:1526328364554};\\\", \\\"{x:824,y:514,t:1526328364571};\\\", \\\"{x:828,y:512,t:1526328364588};\\\", \\\"{x:826,y:514,t:1526328365127};\\\", \\\"{x:822,y:518,t:1526328365138};\\\", \\\"{x:814,y:527,t:1526328365154};\\\", \\\"{x:805,y:540,t:1526328365172};\\\", \\\"{x:793,y:557,t:1526328365189};\\\", \\\"{x:780,y:576,t:1526328365205};\\\", \\\"{x:764,y:596,t:1526328365223};\\\", \\\"{x:749,y:614,t:1526328365239};\\\", \\\"{x:738,y:628,t:1526328365254};\\\", \\\"{x:723,y:644,t:1526328365273};\\\", \\\"{x:714,y:655,t:1526328365289};\\\", \\\"{x:703,y:666,t:1526328365305};\\\", \\\"{x:692,y:676,t:1526328365322};\\\", \\\"{x:680,y:685,t:1526328365339};\\\", \\\"{x:665,y:695,t:1526328365354};\\\", \\\"{x:647,y:702,t:1526328365371};\\\", \\\"{x:630,y:707,t:1526328365387};\\\", \\\"{x:609,y:712,t:1526328365405};\\\", \\\"{x:591,y:715,t:1526328365422};\\\", \\\"{x:575,y:717,t:1526328365438};\\\", \\\"{x:560,y:717,t:1526328365455};\\\", \\\"{x:539,y:716,t:1526328365471};\\\", \\\"{x:526,y:713,t:1526328365489};\\\", \\\"{x:517,y:709,t:1526328365505};\\\", \\\"{x:513,y:709,t:1526328365522};\\\", \\\"{x:512,y:707,t:1526328365539};\\\", \\\"{x:512,y:706,t:1526328365555};\\\", \\\"{x:510,y:705,t:1526328365572};\\\", \\\"{x:509,y:705,t:1526328365625};\\\", \\\"{x:507,y:705,t:1526328365648};\\\", \\\"{x:506,y:705,t:1526328365656};\\\", \\\"{x:504,y:705,t:1526328365672};\\\", \\\"{x:502,y:706,t:1526328365688};\\\", \\\"{x:501,y:707,t:1526328365705};\\\", \\\"{x:500,y:707,t:1526328365722};\\\", \\\"{x:500,y:709,t:1526328365738};\\\", \\\"{x:499,y:710,t:1526328365767};\\\", \\\"{x:499,y:712,t:1526328365856};\\\", \\\"{x:499,y:713,t:1526328365872};\\\", \\\"{x:499,y:715,t:1526328365890};\\\", \\\"{x:499,y:716,t:1526328365906};\\\", \\\"{x:499,y:717,t:1526328365922};\\\", \\\"{x:499,y:718,t:1526328365940};\\\", \\\"{x:498,y:720,t:1526328367296};\\\" ] }, { \\\"rt\\\": 111385, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 333002, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:723,t:1526328368697};\\\", \\\"{x:494,y:725,t:1526328368710};\\\", \\\"{x:494,y:727,t:1526328368727};\\\", \\\"{x:490,y:734,t:1526328368743};\\\", \\\"{x:490,y:736,t:1526328368761};\\\", \\\"{x:490,y:740,t:1526328368777};\\\", \\\"{x:489,y:742,t:1526328368791};\\\", \\\"{x:489,y:744,t:1526328368808};\\\", \\\"{x:489,y:748,t:1526328368824};\\\", \\\"{x:490,y:752,t:1526328368840};\\\", \\\"{x:491,y:755,t:1526328368858};\\\", \\\"{x:494,y:759,t:1526328368875};\\\", \\\"{x:496,y:764,t:1526328368891};\\\", \\\"{x:502,y:770,t:1526328368908};\\\", \\\"{x:509,y:779,t:1526328368925};\\\", \\\"{x:516,y:787,t:1526328368941};\\\", \\\"{x:523,y:795,t:1526328368958};\\\", \\\"{x:530,y:803,t:1526328368975};\\\", \\\"{x:535,y:807,t:1526328368991};\\\", \\\"{x:551,y:818,t:1526328369008};\\\", \\\"{x:561,y:826,t:1526328369025};\\\", \\\"{x:574,y:834,t:1526328369041};\\\", \\\"{x:589,y:843,t:1526328369058};\\\", \\\"{x:603,y:850,t:1526328369075};\\\", \\\"{x:615,y:857,t:1526328369091};\\\", \\\"{x:626,y:862,t:1526328369109};\\\", \\\"{x:636,y:869,t:1526328369126};\\\", \\\"{x:650,y:874,t:1526328369141};\\\", \\\"{x:662,y:879,t:1526328369158};\\\", \\\"{x:679,y:885,t:1526328369176};\\\", \\\"{x:689,y:890,t:1526328369191};\\\", \\\"{x:699,y:894,t:1526328369209};\\\", \\\"{x:714,y:898,t:1526328369225};\\\", \\\"{x:736,y:903,t:1526328369241};\\\", \\\"{x:774,y:908,t:1526328369259};\\\", \\\"{x:834,y:913,t:1526328369275};\\\", \\\"{x:876,y:913,t:1526328369291};\\\", \\\"{x:893,y:919,t:1526328369308};\\\", \\\"{x:895,y:921,t:1526328369326};\\\", \\\"{x:896,y:921,t:1526328370088};\\\", \\\"{x:897,y:920,t:1526328370104};\\\", \\\"{x:898,y:920,t:1526328370112};\\\", \\\"{x:899,y:920,t:1526328370126};\\\", \\\"{x:899,y:919,t:1526328370167};\\\", \\\"{x:899,y:918,t:1526328370199};\\\", \\\"{x:899,y:917,t:1526328370264};\\\", \\\"{x:900,y:917,t:1526328370280};\\\", \\\"{x:900,y:916,t:1526328370295};\\\", \\\"{x:901,y:915,t:1526328370309};\\\", \\\"{x:901,y:914,t:1526328370325};\\\", \\\"{x:902,y:913,t:1526328370343};\\\", \\\"{x:902,y:912,t:1526328370359};\\\", \\\"{x:902,y:911,t:1526328370384};\\\", \\\"{x:903,y:910,t:1526328370392};\\\", \\\"{x:903,y:909,t:1526328370409};\\\", \\\"{x:903,y:908,t:1526328370426};\\\", \\\"{x:904,y:906,t:1526328370443};\\\", \\\"{x:904,y:904,t:1526328370459};\\\", \\\"{x:905,y:902,t:1526328370476};\\\", \\\"{x:905,y:900,t:1526328370504};\\\", \\\"{x:905,y:899,t:1526328370545};\\\", \\\"{x:905,y:897,t:1526328370567};\\\", \\\"{x:905,y:896,t:1526328370608};\\\", \\\"{x:905,y:895,t:1526328370880};\\\", \\\"{x:905,y:894,t:1526328371872};\\\", \\\"{x:905,y:893,t:1526328371912};\\\", \\\"{x:906,y:893,t:1526328371936};\\\", \\\"{x:907,y:892,t:1526328372080};\\\", \\\"{x:907,y:891,t:1526328377551};\\\", \\\"{x:909,y:890,t:1526328377567};\\\", \\\"{x:910,y:889,t:1526328377580};\\\", \\\"{x:911,y:889,t:1526328377597};\\\", \\\"{x:911,y:888,t:1526328377614};\\\", \\\"{x:912,y:888,t:1526328377726};\\\", \\\"{x:914,y:886,t:1526328377751};\\\", \\\"{x:915,y:886,t:1526328377765};\\\", \\\"{x:923,y:882,t:1526328377781};\\\", \\\"{x:943,y:872,t:1526328377798};\\\", \\\"{x:976,y:859,t:1526328377814};\\\", \\\"{x:1139,y:817,t:1526328377831};\\\", \\\"{x:1285,y:775,t:1526328377848};\\\", \\\"{x:1428,y:718,t:1526328377864};\\\", \\\"{x:1568,y:661,t:1526328377881};\\\", \\\"{x:1717,y:601,t:1526328377898};\\\", \\\"{x:1846,y:543,t:1526328377915};\\\", \\\"{x:1919,y:491,t:1526328377931};\\\", \\\"{x:1919,y:426,t:1526328377948};\\\", \\\"{x:1919,y:368,t:1526328377965};\\\", \\\"{x:1919,y:314,t:1526328377982};\\\", \\\"{x:1919,y:245,t:1526328377999};\\\", \\\"{x:1919,y:217,t:1526328378014};\\\", \\\"{x:1919,y:201,t:1526328378032};\\\", \\\"{x:1919,y:189,t:1526328378048};\\\", \\\"{x:1919,y:186,t:1526328378065};\\\", \\\"{x:1919,y:185,t:1526328378082};\\\", \\\"{x:1916,y:185,t:1526328378099};\\\", \\\"{x:1906,y:185,t:1526328378115};\\\", \\\"{x:1888,y:187,t:1526328378132};\\\", \\\"{x:1870,y:190,t:1526328378149};\\\", \\\"{x:1846,y:193,t:1526328378165};\\\", \\\"{x:1824,y:195,t:1526328378182};\\\", \\\"{x:1802,y:200,t:1526328378198};\\\", \\\"{x:1793,y:200,t:1526328378216};\\\", \\\"{x:1784,y:202,t:1526328378232};\\\", \\\"{x:1776,y:202,t:1526328378249};\\\", \\\"{x:1769,y:202,t:1526328378266};\\\", \\\"{x:1762,y:202,t:1526328378282};\\\", \\\"{x:1758,y:204,t:1526328378299};\\\", \\\"{x:1758,y:205,t:1526328378315};\\\", \\\"{x:1758,y:209,t:1526328378332};\\\", \\\"{x:1757,y:215,t:1526328378349};\\\", \\\"{x:1754,y:227,t:1526328378366};\\\", \\\"{x:1750,y:241,t:1526328378382};\\\", \\\"{x:1745,y:255,t:1526328378398};\\\", \\\"{x:1743,y:258,t:1526328378416};\\\", \\\"{x:1741,y:259,t:1526328378432};\\\", \\\"{x:1740,y:260,t:1526328378449};\\\", \\\"{x:1737,y:261,t:1526328378466};\\\", \\\"{x:1730,y:267,t:1526328378482};\\\", \\\"{x:1723,y:277,t:1526328378499};\\\", \\\"{x:1712,y:292,t:1526328378516};\\\", \\\"{x:1702,y:306,t:1526328378532};\\\", \\\"{x:1689,y:321,t:1526328378549};\\\", \\\"{x:1681,y:331,t:1526328378566};\\\", \\\"{x:1675,y:339,t:1526328378582};\\\", \\\"{x:1671,y:347,t:1526328378598};\\\", \\\"{x:1668,y:351,t:1526328378616};\\\", \\\"{x:1665,y:355,t:1526328378632};\\\", \\\"{x:1660,y:361,t:1526328378649};\\\", \\\"{x:1656,y:367,t:1526328378666};\\\", \\\"{x:1653,y:374,t:1526328378683};\\\", \\\"{x:1652,y:379,t:1526328378699};\\\", \\\"{x:1650,y:385,t:1526328378716};\\\", \\\"{x:1649,y:391,t:1526328378733};\\\", \\\"{x:1647,y:397,t:1526328378749};\\\", \\\"{x:1645,y:404,t:1526328378766};\\\", \\\"{x:1642,y:410,t:1526328378782};\\\", \\\"{x:1640,y:418,t:1526328378798};\\\", \\\"{x:1632,y:438,t:1526328378816};\\\", \\\"{x:1627,y:464,t:1526328378833};\\\", \\\"{x:1623,y:489,t:1526328378849};\\\", \\\"{x:1621,y:502,t:1526328378866};\\\", \\\"{x:1621,y:507,t:1526328378883};\\\", \\\"{x:1621,y:511,t:1526328378899};\\\", \\\"{x:1621,y:512,t:1526328378916};\\\", \\\"{x:1621,y:513,t:1526328378933};\\\", \\\"{x:1621,y:516,t:1526328378949};\\\", \\\"{x:1620,y:519,t:1526328378966};\\\", \\\"{x:1619,y:524,t:1526328378982};\\\", \\\"{x:1619,y:526,t:1526328378998};\\\", \\\"{x:1618,y:529,t:1526328379016};\\\", \\\"{x:1617,y:533,t:1526328379033};\\\", \\\"{x:1617,y:534,t:1526328379049};\\\", \\\"{x:1617,y:537,t:1526328379066};\\\", \\\"{x:1617,y:540,t:1526328379083};\\\", \\\"{x:1617,y:548,t:1526328379099};\\\", \\\"{x:1618,y:554,t:1526328379116};\\\", \\\"{x:1619,y:561,t:1526328379133};\\\", \\\"{x:1619,y:564,t:1526328379150};\\\", \\\"{x:1619,y:568,t:1526328379166};\\\", \\\"{x:1621,y:574,t:1526328379183};\\\", \\\"{x:1622,y:578,t:1526328379200};\\\", \\\"{x:1623,y:582,t:1526328379216};\\\", \\\"{x:1625,y:587,t:1526328379233};\\\", \\\"{x:1626,y:590,t:1526328379250};\\\", \\\"{x:1626,y:593,t:1526328379266};\\\", \\\"{x:1627,y:595,t:1526328379283};\\\", \\\"{x:1628,y:599,t:1526328379300};\\\", \\\"{x:1629,y:601,t:1526328379316};\\\", \\\"{x:1629,y:604,t:1526328379333};\\\", \\\"{x:1630,y:610,t:1526328379350};\\\", \\\"{x:1630,y:615,t:1526328379365};\\\", \\\"{x:1633,y:623,t:1526328379382};\\\", \\\"{x:1634,y:629,t:1526328379400};\\\", \\\"{x:1634,y:634,t:1526328379416};\\\", \\\"{x:1636,y:639,t:1526328379433};\\\", \\\"{x:1636,y:645,t:1526328379450};\\\", \\\"{x:1636,y:653,t:1526328379466};\\\", \\\"{x:1636,y:663,t:1526328379483};\\\", \\\"{x:1636,y:670,t:1526328379499};\\\", \\\"{x:1635,y:676,t:1526328379516};\\\", \\\"{x:1631,y:685,t:1526328379533};\\\", \\\"{x:1628,y:691,t:1526328379550};\\\", \\\"{x:1628,y:703,t:1526328379567};\\\", \\\"{x:1627,y:709,t:1526328379583};\\\", \\\"{x:1627,y:714,t:1526328379600};\\\", \\\"{x:1626,y:718,t:1526328379616};\\\", \\\"{x:1626,y:722,t:1526328379633};\\\", \\\"{x:1626,y:727,t:1526328379650};\\\", \\\"{x:1626,y:735,t:1526328379667};\\\", \\\"{x:1626,y:742,t:1526328379683};\\\", \\\"{x:1626,y:749,t:1526328379700};\\\", \\\"{x:1626,y:756,t:1526328379717};\\\", \\\"{x:1626,y:763,t:1526328379734};\\\", \\\"{x:1626,y:769,t:1526328379750};\\\", \\\"{x:1626,y:781,t:1526328379766};\\\", \\\"{x:1626,y:788,t:1526328379783};\\\", \\\"{x:1626,y:795,t:1526328379800};\\\", \\\"{x:1628,y:803,t:1526328379817};\\\", \\\"{x:1628,y:810,t:1526328379833};\\\", \\\"{x:1628,y:820,t:1526328379850};\\\", \\\"{x:1628,y:831,t:1526328379867};\\\", \\\"{x:1628,y:843,t:1526328379883};\\\", \\\"{x:1626,y:856,t:1526328379900};\\\", \\\"{x:1624,y:869,t:1526328379918};\\\", \\\"{x:1623,y:882,t:1526328379933};\\\", \\\"{x:1621,y:893,t:1526328379950};\\\", \\\"{x:1619,y:906,t:1526328379967};\\\", \\\"{x:1617,y:912,t:1526328379984};\\\", \\\"{x:1617,y:917,t:1526328380000};\\\", \\\"{x:1615,y:922,t:1526328380017};\\\", \\\"{x:1615,y:925,t:1526328380034};\\\", \\\"{x:1615,y:927,t:1526328380050};\\\", \\\"{x:1615,y:928,t:1526328380067};\\\", \\\"{x:1615,y:931,t:1526328380084};\\\", \\\"{x:1615,y:933,t:1526328380100};\\\", \\\"{x:1615,y:936,t:1526328380117};\\\", \\\"{x:1615,y:938,t:1526328380134};\\\", \\\"{x:1616,y:941,t:1526328380151};\\\", \\\"{x:1617,y:944,t:1526328380167};\\\", \\\"{x:1618,y:945,t:1526328380184};\\\", \\\"{x:1618,y:946,t:1526328380200};\\\", \\\"{x:1618,y:947,t:1526328380217};\\\", \\\"{x:1619,y:948,t:1526328380234};\\\", \\\"{x:1619,y:949,t:1526328380263};\\\", \\\"{x:1619,y:950,t:1526328380270};\\\", \\\"{x:1619,y:951,t:1526328380287};\\\", \\\"{x:1619,y:953,t:1526328380300};\\\", \\\"{x:1621,y:954,t:1526328380317};\\\", \\\"{x:1621,y:956,t:1526328380334};\\\", \\\"{x:1621,y:958,t:1526328380350};\\\", \\\"{x:1621,y:961,t:1526328380367};\\\", \\\"{x:1621,y:963,t:1526328380384};\\\", \\\"{x:1621,y:965,t:1526328380400};\\\", \\\"{x:1622,y:966,t:1526328380417};\\\", \\\"{x:1622,y:967,t:1526328380455};\\\", \\\"{x:1622,y:966,t:1526328381015};\\\", \\\"{x:1621,y:962,t:1526328381367};\\\", \\\"{x:1620,y:961,t:1526328381374};\\\", \\\"{x:1619,y:960,t:1526328381423};\\\", \\\"{x:1618,y:959,t:1526328381439};\\\", \\\"{x:1616,y:959,t:1526328381455};\\\", \\\"{x:1615,y:959,t:1526328381479};\\\", \\\"{x:1614,y:959,t:1526328381607};\\\", \\\"{x:1613,y:959,t:1526328381638};\\\", \\\"{x:1613,y:960,t:1526328382264};\\\", \\\"{x:1613,y:961,t:1526328385080};\\\", \\\"{x:1613,y:963,t:1526328385103};\\\", \\\"{x:1613,y:964,t:1526328389150};\\\", \\\"{x:1612,y:964,t:1526328389165};\\\", \\\"{x:1611,y:964,t:1526328389180};\\\", \\\"{x:1609,y:964,t:1526328389197};\\\", \\\"{x:1607,y:964,t:1526328389213};\\\", \\\"{x:1606,y:962,t:1526328389230};\\\", \\\"{x:1605,y:961,t:1526328389247};\\\", \\\"{x:1604,y:960,t:1526328389264};\\\", \\\"{x:1602,y:959,t:1526328389280};\\\", \\\"{x:1601,y:958,t:1526328390277};\\\", \\\"{x:1600,y:956,t:1526328390285};\\\", \\\"{x:1599,y:955,t:1526328390303};\\\", \\\"{x:1598,y:954,t:1526328390315};\\\", \\\"{x:1597,y:953,t:1526328390333};\\\", \\\"{x:1597,y:952,t:1526328390356};\\\", \\\"{x:1596,y:952,t:1526328390365};\\\", \\\"{x:1596,y:951,t:1526328390396};\\\", \\\"{x:1596,y:949,t:1526328390605};\\\", \\\"{x:1596,y:946,t:1526328390620};\\\", \\\"{x:1596,y:939,t:1526328390635};\\\", \\\"{x:1596,y:927,t:1526328390648};\\\", \\\"{x:1597,y:902,t:1526328390665};\\\", \\\"{x:1604,y:876,t:1526328390681};\\\", \\\"{x:1619,y:825,t:1526328390698};\\\", \\\"{x:1644,y:744,t:1526328390715};\\\", \\\"{x:1664,y:667,t:1526328390732};\\\", \\\"{x:1691,y:593,t:1526328390748};\\\", \\\"{x:1726,y:500,t:1526328390764};\\\", \\\"{x:1744,y:433,t:1526328390781};\\\", \\\"{x:1755,y:382,t:1526328390798};\\\", \\\"{x:1764,y:359,t:1526328390816};\\\", \\\"{x:1768,y:342,t:1526328390831};\\\", \\\"{x:1773,y:324,t:1526328390848};\\\", \\\"{x:1775,y:312,t:1526328390865};\\\", \\\"{x:1775,y:305,t:1526328390881};\\\", \\\"{x:1775,y:301,t:1526328390899};\\\", \\\"{x:1775,y:298,t:1526328390915};\\\", \\\"{x:1775,y:297,t:1526328390931};\\\", \\\"{x:1774,y:297,t:1526328390948};\\\", \\\"{x:1767,y:297,t:1526328390964};\\\", \\\"{x:1760,y:298,t:1526328390981};\\\", \\\"{x:1752,y:304,t:1526328390998};\\\", \\\"{x:1745,y:312,t:1526328391015};\\\", \\\"{x:1737,y:328,t:1526328391031};\\\", \\\"{x:1729,y:347,t:1526328391048};\\\", \\\"{x:1720,y:367,t:1526328391065};\\\", \\\"{x:1711,y:387,t:1526328391082};\\\", \\\"{x:1701,y:406,t:1526328391098};\\\", \\\"{x:1689,y:426,t:1526328391115};\\\", \\\"{x:1683,y:437,t:1526328391132};\\\", \\\"{x:1679,y:442,t:1526328391148};\\\", \\\"{x:1676,y:448,t:1526328391165};\\\", \\\"{x:1673,y:451,t:1526328391182};\\\", \\\"{x:1672,y:452,t:1526328391198};\\\", \\\"{x:1670,y:453,t:1526328391215};\\\", \\\"{x:1669,y:454,t:1526328391232};\\\", \\\"{x:1667,y:455,t:1526328391252};\\\", \\\"{x:1666,y:455,t:1526328391268};\\\", \\\"{x:1662,y:453,t:1526328391282};\\\", \\\"{x:1654,y:449,t:1526328391298};\\\", \\\"{x:1640,y:440,t:1526328391315};\\\", \\\"{x:1624,y:434,t:1526328391333};\\\", \\\"{x:1624,y:433,t:1526328391348};\\\", \\\"{x:1618,y:430,t:1526328391366};\\\", \\\"{x:1616,y:428,t:1526328391382};\\\", \\\"{x:1615,y:428,t:1526328391981};\\\", \\\"{x:1615,y:430,t:1526328392244};\\\", \\\"{x:1615,y:431,t:1526328392260};\\\", \\\"{x:1615,y:433,t:1526328392284};\\\", \\\"{x:1615,y:434,t:1526328392301};\\\", \\\"{x:1615,y:435,t:1526328392316};\\\", \\\"{x:1615,y:437,t:1526328392333};\\\", \\\"{x:1615,y:440,t:1526328392349};\\\", \\\"{x:1615,y:441,t:1526328392372};\\\", \\\"{x:1615,y:442,t:1526328392383};\\\", \\\"{x:1615,y:446,t:1526328392399};\\\", \\\"{x:1615,y:449,t:1526328392416};\\\", \\\"{x:1615,y:453,t:1526328392434};\\\", \\\"{x:1615,y:454,t:1526328392449};\\\", \\\"{x:1615,y:458,t:1526328392466};\\\", \\\"{x:1615,y:461,t:1526328392484};\\\", \\\"{x:1615,y:466,t:1526328392499};\\\", \\\"{x:1616,y:474,t:1526328392516};\\\", \\\"{x:1619,y:479,t:1526328392532};\\\", \\\"{x:1620,y:485,t:1526328392549};\\\", \\\"{x:1620,y:491,t:1526328392566};\\\", \\\"{x:1621,y:498,t:1526328392583};\\\", \\\"{x:1624,y:508,t:1526328392599};\\\", \\\"{x:1625,y:514,t:1526328392616};\\\", \\\"{x:1625,y:520,t:1526328392633};\\\", \\\"{x:1625,y:524,t:1526328392649};\\\", \\\"{x:1625,y:528,t:1526328392666};\\\", \\\"{x:1625,y:534,t:1526328392683};\\\", \\\"{x:1625,y:539,t:1526328392700};\\\", \\\"{x:1625,y:543,t:1526328392716};\\\", \\\"{x:1627,y:548,t:1526328392733};\\\", \\\"{x:1627,y:549,t:1526328392750};\\\", \\\"{x:1628,y:551,t:1526328392765};\\\", \\\"{x:1628,y:553,t:1526328392783};\\\", \\\"{x:1628,y:557,t:1526328392800};\\\", \\\"{x:1628,y:559,t:1526328392816};\\\", \\\"{x:1628,y:561,t:1526328392833};\\\", \\\"{x:1628,y:563,t:1526328392850};\\\", \\\"{x:1628,y:565,t:1526328392866};\\\", \\\"{x:1628,y:568,t:1526328392883};\\\", \\\"{x:1628,y:569,t:1526328392899};\\\", \\\"{x:1628,y:572,t:1526328392916};\\\", \\\"{x:1628,y:574,t:1526328392933};\\\", \\\"{x:1628,y:575,t:1526328392950};\\\", \\\"{x:1628,y:577,t:1526328392966};\\\", \\\"{x:1628,y:579,t:1526328392983};\\\", \\\"{x:1628,y:580,t:1526328393000};\\\", \\\"{x:1628,y:583,t:1526328393016};\\\", \\\"{x:1627,y:585,t:1526328393033};\\\", \\\"{x:1626,y:589,t:1526328393050};\\\", \\\"{x:1626,y:592,t:1526328393066};\\\", \\\"{x:1624,y:598,t:1526328393083};\\\", \\\"{x:1622,y:603,t:1526328393100};\\\", \\\"{x:1620,y:607,t:1526328393116};\\\", \\\"{x:1619,y:610,t:1526328393133};\\\", \\\"{x:1619,y:613,t:1526328393150};\\\", \\\"{x:1616,y:617,t:1526328393166};\\\", \\\"{x:1615,y:620,t:1526328393183};\\\", \\\"{x:1614,y:624,t:1526328393200};\\\", \\\"{x:1613,y:627,t:1526328393216};\\\", \\\"{x:1612,y:630,t:1526328393234};\\\", \\\"{x:1611,y:633,t:1526328393250};\\\", \\\"{x:1609,y:638,t:1526328393267};\\\", \\\"{x:1608,y:643,t:1526328393284};\\\", \\\"{x:1605,y:652,t:1526328393301};\\\", \\\"{x:1604,y:658,t:1526328393317};\\\", \\\"{x:1600,y:670,t:1526328393334};\\\", \\\"{x:1597,y:679,t:1526328393351};\\\", \\\"{x:1597,y:685,t:1526328393368};\\\", \\\"{x:1596,y:691,t:1526328393383};\\\", \\\"{x:1596,y:696,t:1526328393401};\\\", \\\"{x:1596,y:701,t:1526328393418};\\\", \\\"{x:1596,y:704,t:1526328393434};\\\", \\\"{x:1596,y:710,t:1526328393451};\\\", \\\"{x:1596,y:719,t:1526328393467};\\\", \\\"{x:1596,y:726,t:1526328393484};\\\", \\\"{x:1599,y:736,t:1526328393501};\\\", \\\"{x:1600,y:741,t:1526328393517};\\\", \\\"{x:1602,y:747,t:1526328393533};\\\", \\\"{x:1604,y:753,t:1526328393551};\\\", \\\"{x:1606,y:759,t:1526328393568};\\\", \\\"{x:1608,y:765,t:1526328393584};\\\", \\\"{x:1610,y:767,t:1526328393601};\\\", \\\"{x:1610,y:770,t:1526328393617};\\\", \\\"{x:1610,y:771,t:1526328393634};\\\", \\\"{x:1611,y:772,t:1526328393651};\\\", \\\"{x:1612,y:773,t:1526328393668};\\\", \\\"{x:1613,y:774,t:1526328393684};\\\", \\\"{x:1613,y:775,t:1526328393702};\\\", \\\"{x:1613,y:776,t:1526328393751};\\\", \\\"{x:1614,y:777,t:1526328393774};\\\", \\\"{x:1614,y:778,t:1526328393784};\\\", \\\"{x:1615,y:779,t:1526328393801};\\\", \\\"{x:1616,y:780,t:1526328393817};\\\", \\\"{x:1616,y:781,t:1526328393834};\\\", \\\"{x:1616,y:782,t:1526328393851};\\\", \\\"{x:1616,y:783,t:1526328393868};\\\", \\\"{x:1616,y:784,t:1526328393884};\\\", \\\"{x:1616,y:785,t:1526328393901};\\\", \\\"{x:1616,y:787,t:1526328393918};\\\", \\\"{x:1617,y:790,t:1526328393934};\\\", \\\"{x:1617,y:791,t:1526328393952};\\\", \\\"{x:1618,y:795,t:1526328393968};\\\", \\\"{x:1619,y:797,t:1526328393985};\\\", \\\"{x:1619,y:801,t:1526328394002};\\\", \\\"{x:1619,y:805,t:1526328394018};\\\", \\\"{x:1619,y:811,t:1526328394035};\\\", \\\"{x:1620,y:819,t:1526328394051};\\\", \\\"{x:1620,y:827,t:1526328394069};\\\", \\\"{x:1620,y:844,t:1526328394086};\\\", \\\"{x:1623,y:855,t:1526328394101};\\\", \\\"{x:1623,y:863,t:1526328394117};\\\", \\\"{x:1624,y:873,t:1526328394135};\\\", \\\"{x:1626,y:879,t:1526328394151};\\\", \\\"{x:1627,y:884,t:1526328394168};\\\", \\\"{x:1628,y:891,t:1526328394185};\\\", \\\"{x:1628,y:896,t:1526328394201};\\\", \\\"{x:1630,y:902,t:1526328394218};\\\", \\\"{x:1630,y:907,t:1526328394235};\\\", \\\"{x:1630,y:909,t:1526328394251};\\\", \\\"{x:1630,y:912,t:1526328394268};\\\", \\\"{x:1630,y:917,t:1526328394286};\\\", \\\"{x:1630,y:920,t:1526328394301};\\\", \\\"{x:1631,y:924,t:1526328394319};\\\", \\\"{x:1631,y:927,t:1526328394336};\\\", \\\"{x:1631,y:932,t:1526328394352};\\\", \\\"{x:1631,y:935,t:1526328394368};\\\", \\\"{x:1631,y:939,t:1526328394385};\\\", \\\"{x:1631,y:941,t:1526328394403};\\\", \\\"{x:1631,y:944,t:1526328394419};\\\", \\\"{x:1631,y:945,t:1526328394435};\\\", \\\"{x:1631,y:947,t:1526328394452};\\\", \\\"{x:1631,y:948,t:1526328394468};\\\", \\\"{x:1631,y:949,t:1526328394485};\\\", \\\"{x:1630,y:950,t:1526328394503};\\\", \\\"{x:1630,y:951,t:1526328394518};\\\", \\\"{x:1629,y:952,t:1526328394549};\\\", \\\"{x:1629,y:953,t:1526328394566};\\\", \\\"{x:1627,y:954,t:1526328394573};\\\", \\\"{x:1626,y:955,t:1526328394614};\\\", \\\"{x:1625,y:955,t:1526328394629};\\\", \\\"{x:1624,y:956,t:1526328394670};\\\", \\\"{x:1624,y:957,t:1526328394693};\\\", \\\"{x:1623,y:957,t:1526328394773};\\\", \\\"{x:1622,y:957,t:1526328394798};\\\", \\\"{x:1621,y:958,t:1526328394837};\\\", \\\"{x:1620,y:958,t:1526328394877};\\\", \\\"{x:1621,y:957,t:1526328408422};\\\", \\\"{x:1623,y:956,t:1526328408429};\\\", \\\"{x:1625,y:955,t:1526328408446};\\\", \\\"{x:1627,y:955,t:1526328408463};\\\", \\\"{x:1629,y:953,t:1526328408479};\\\", \\\"{x:1633,y:952,t:1526328408496};\\\", \\\"{x:1635,y:951,t:1526328408513};\\\", \\\"{x:1637,y:950,t:1526328408529};\\\", \\\"{x:1637,y:949,t:1526328408546};\\\", \\\"{x:1634,y:949,t:1526328409334};\\\", \\\"{x:1620,y:949,t:1526328409347};\\\", \\\"{x:1601,y:940,t:1526328409363};\\\", \\\"{x:1573,y:920,t:1526328409380};\\\", \\\"{x:1534,y:888,t:1526328409397};\\\", \\\"{x:1508,y:868,t:1526328409414};\\\", \\\"{x:1459,y:843,t:1526328409430};\\\", \\\"{x:1417,y:811,t:1526328409447};\\\", \\\"{x:1389,y:788,t:1526328409463};\\\", \\\"{x:1377,y:770,t:1526328409480};\\\", \\\"{x:1374,y:757,t:1526328409498};\\\", \\\"{x:1374,y:742,t:1526328409514};\\\", \\\"{x:1374,y:731,t:1526328409530};\\\", \\\"{x:1374,y:722,t:1526328409548};\\\", \\\"{x:1374,y:717,t:1526328409564};\\\", \\\"{x:1372,y:713,t:1526328409581};\\\", \\\"{x:1372,y:711,t:1526328409598};\\\", \\\"{x:1371,y:711,t:1526328409654};\\\", \\\"{x:1373,y:711,t:1526328409726};\\\", \\\"{x:1375,y:711,t:1526328409733};\\\", \\\"{x:1378,y:711,t:1526328409748};\\\", \\\"{x:1382,y:714,t:1526328409764};\\\", \\\"{x:1387,y:725,t:1526328409780};\\\", \\\"{x:1394,y:745,t:1526328409797};\\\", \\\"{x:1395,y:747,t:1526328409815};\\\", \\\"{x:1395,y:746,t:1526328411237};\\\", \\\"{x:1394,y:745,t:1526328411261};\\\", \\\"{x:1394,y:744,t:1526328411269};\\\", \\\"{x:1393,y:744,t:1526328411281};\\\", \\\"{x:1387,y:744,t:1526328411298};\\\", \\\"{x:1372,y:743,t:1526328411316};\\\", \\\"{x:1359,y:740,t:1526328411331};\\\", \\\"{x:1345,y:738,t:1526328411349};\\\", \\\"{x:1313,y:731,t:1526328411365};\\\", \\\"{x:1290,y:726,t:1526328411382};\\\", \\\"{x:1263,y:722,t:1526328411399};\\\", \\\"{x:1239,y:721,t:1526328411415};\\\", \\\"{x:1212,y:717,t:1526328411432};\\\", \\\"{x:1177,y:715,t:1526328411448};\\\", \\\"{x:1147,y:715,t:1526328411465};\\\", \\\"{x:1120,y:715,t:1526328411482};\\\", \\\"{x:1102,y:715,t:1526328411498};\\\", \\\"{x:1092,y:714,t:1526328411515};\\\", \\\"{x:1085,y:713,t:1526328411532};\\\", \\\"{x:1083,y:713,t:1526328411547};\\\", \\\"{x:1082,y:713,t:1526328411565};\\\", \\\"{x:1083,y:712,t:1526328474904};\\\", \\\"{x:1094,y:711,t:1526328474918};\\\", \\\"{x:1101,y:711,t:1526328474935};\\\", \\\"{x:1112,y:712,t:1526328474953};\\\", \\\"{x:1119,y:713,t:1526328474968};\\\", \\\"{x:1130,y:714,t:1526328474985};\\\", \\\"{x:1150,y:719,t:1526328475003};\\\", \\\"{x:1176,y:723,t:1526328475019};\\\", \\\"{x:1206,y:728,t:1526328475036};\\\", \\\"{x:1238,y:728,t:1526328475052};\\\", \\\"{x:1267,y:729,t:1526328475068};\\\", \\\"{x:1293,y:729,t:1526328475086};\\\", \\\"{x:1326,y:729,t:1526328475102};\\\", \\\"{x:1339,y:729,t:1526328475119};\\\", \\\"{x:1344,y:729,t:1526328475136};\\\", \\\"{x:1343,y:728,t:1526328475206};\\\", \\\"{x:1324,y:723,t:1526328475222};\\\", \\\"{x:1313,y:721,t:1526328475236};\\\", \\\"{x:1280,y:715,t:1526328475251};\\\", \\\"{x:1213,y:706,t:1526328475269};\\\", \\\"{x:1081,y:688,t:1526328475285};\\\", \\\"{x:984,y:672,t:1526328475302};\\\", \\\"{x:884,y:658,t:1526328475318};\\\", \\\"{x:784,y:643,t:1526328475335};\\\", \\\"{x:701,y:632,t:1526328475353};\\\", \\\"{x:634,y:623,t:1526328475368};\\\", \\\"{x:583,y:615,t:1526328475386};\\\", \\\"{x:559,y:612,t:1526328475403};\\\", \\\"{x:544,y:609,t:1526328475420};\\\", \\\"{x:541,y:607,t:1526328475438};\\\", \\\"{x:541,y:606,t:1526328475477};\\\", \\\"{x:542,y:603,t:1526328475487};\\\", \\\"{x:545,y:602,t:1526328475503};\\\", \\\"{x:550,y:598,t:1526328475521};\\\", \\\"{x:559,y:594,t:1526328475537};\\\", \\\"{x:572,y:591,t:1526328475553};\\\", \\\"{x:590,y:589,t:1526328475570};\\\", \\\"{x:609,y:586,t:1526328475587};\\\", \\\"{x:625,y:585,t:1526328475603};\\\", \\\"{x:641,y:585,t:1526328475620};\\\", \\\"{x:657,y:585,t:1526328475637};\\\", \\\"{x:686,y:585,t:1526328475652};\\\", \\\"{x:703,y:585,t:1526328475670};\\\", \\\"{x:719,y:586,t:1526328475688};\\\", \\\"{x:736,y:588,t:1526328475704};\\\", \\\"{x:749,y:591,t:1526328475720};\\\", \\\"{x:759,y:593,t:1526328475737};\\\", \\\"{x:766,y:595,t:1526328475753};\\\", \\\"{x:771,y:597,t:1526328475771};\\\", \\\"{x:781,y:600,t:1526328475787};\\\", \\\"{x:783,y:600,t:1526328475805};\\\", \\\"{x:788,y:600,t:1526328475821};\\\", \\\"{x:794,y:601,t:1526328475837};\\\", \\\"{x:798,y:601,t:1526328475854};\\\", \\\"{x:801,y:603,t:1526328475870};\\\", \\\"{x:804,y:603,t:1526328475888};\\\", \\\"{x:805,y:603,t:1526328475904};\\\", \\\"{x:806,y:603,t:1526328475965};\\\", \\\"{x:809,y:603,t:1526328475973};\\\", \\\"{x:813,y:603,t:1526328475987};\\\", \\\"{x:822,y:603,t:1526328476004};\\\", \\\"{x:832,y:603,t:1526328476021};\\\", \\\"{x:835,y:603,t:1526328476038};\\\", \\\"{x:836,y:603,t:1526328476054};\\\", \\\"{x:837,y:603,t:1526328476070};\\\", \\\"{x:838,y:603,t:1526328476088};\\\", \\\"{x:839,y:603,t:1526328476134};\\\", \\\"{x:840,y:603,t:1526328476166};\\\", \\\"{x:841,y:603,t:1526328476174};\\\", \\\"{x:840,y:603,t:1526328477125};\\\", \\\"{x:839,y:603,t:1526328477238};\\\", \\\"{x:837,y:603,t:1526328477334};\\\", \\\"{x:837,y:604,t:1526328477350};\\\", \\\"{x:836,y:604,t:1526328477382};\\\", \\\"{x:835,y:605,t:1526328477405};\\\", \\\"{x:834,y:605,t:1526328477438};\\\", \\\"{x:833,y:606,t:1526328477495};\\\", \\\"{x:831,y:606,t:1526328477574};\\\", \\\"{x:831,y:607,t:1526328477663};\\\", \\\"{x:830,y:608,t:1526328477686};\\\", \\\"{x:828,y:608,t:1526328477703};\\\", \\\"{x:827,y:609,t:1526328477711};\\\", \\\"{x:826,y:610,t:1526328477725};\\\", \\\"{x:825,y:610,t:1526328477738};\\\", \\\"{x:822,y:612,t:1526328477756};\\\", \\\"{x:818,y:613,t:1526328477772};\\\", \\\"{x:807,y:616,t:1526328477789};\\\", \\\"{x:790,y:620,t:1526328477805};\\\", \\\"{x:775,y:622,t:1526328477823};\\\", \\\"{x:758,y:624,t:1526328477838};\\\", \\\"{x:741,y:627,t:1526328477855};\\\", \\\"{x:727,y:629,t:1526328477872};\\\", \\\"{x:714,y:630,t:1526328477889};\\\", \\\"{x:700,y:633,t:1526328477905};\\\", \\\"{x:685,y:634,t:1526328477923};\\\", \\\"{x:665,y:637,t:1526328477939};\\\", \\\"{x:653,y:639,t:1526328477956};\\\", \\\"{x:637,y:642,t:1526328477972};\\\", \\\"{x:616,y:643,t:1526328477989};\\\", \\\"{x:602,y:645,t:1526328478005};\\\", \\\"{x:587,y:649,t:1526328478023};\\\", \\\"{x:573,y:651,t:1526328478040};\\\", \\\"{x:564,y:653,t:1526328478056};\\\", \\\"{x:560,y:655,t:1526328478073};\\\", \\\"{x:555,y:656,t:1526328478090};\\\", \\\"{x:549,y:658,t:1526328478105};\\\", \\\"{x:540,y:662,t:1526328478122};\\\", \\\"{x:534,y:663,t:1526328478139};\\\", \\\"{x:529,y:666,t:1526328478155};\\\", \\\"{x:525,y:669,t:1526328478173};\\\", \\\"{x:521,y:671,t:1526328478189};\\\", \\\"{x:518,y:673,t:1526328478205};\\\", \\\"{x:513,y:677,t:1526328478223};\\\", \\\"{x:509,y:682,t:1526328478240};\\\", \\\"{x:507,y:687,t:1526328478255};\\\", \\\"{x:504,y:692,t:1526328478273};\\\", \\\"{x:501,y:697,t:1526328478290};\\\", \\\"{x:501,y:699,t:1526328478305};\\\", \\\"{x:498,y:703,t:1526328478324};\\\", \\\"{x:496,y:709,t:1526328478340};\\\", \\\"{x:494,y:714,t:1526328478356};\\\", \\\"{x:491,y:719,t:1526328478373};\\\", \\\"{x:490,y:724,t:1526328478389};\\\", \\\"{x:490,y:727,t:1526328478407};\\\", \\\"{x:489,y:730,t:1526328478423};\\\", \\\"{x:489,y:731,t:1526328478440};\\\", \\\"{x:489,y:733,t:1526328478457};\\\", \\\"{x:486,y:733,t:1526328478662};\\\", \\\"{x:486,y:730,t:1526328478677};\\\", \\\"{x:485,y:728,t:1526328478691};\\\", \\\"{x:483,y:724,t:1526328478708};\\\", \\\"{x:481,y:720,t:1526328478724};\\\", \\\"{x:481,y:718,t:1526328478741};\\\", \\\"{x:481,y:717,t:1526328478758};\\\", \\\"{x:481,y:716,t:1526328478775};\\\", \\\"{x:481,y:714,t:1526328478806};\\\", \\\"{x:481,y:713,t:1526328478846};\\\" ] }, { \\\"rt\\\": 33557, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 368147, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -11:30-12 PM-11 AM-11 AM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:713,t:1526328481982};\\\", \\\"{x:470,y:713,t:1526328481998};\\\", \\\"{x:465,y:714,t:1526328482009};\\\", \\\"{x:452,y:715,t:1526328482026};\\\", \\\"{x:439,y:717,t:1526328482044};\\\", \\\"{x:432,y:717,t:1526328482059};\\\", \\\"{x:418,y:717,t:1526328482077};\\\", \\\"{x:405,y:717,t:1526328482092};\\\", \\\"{x:392,y:717,t:1526328482109};\\\", \\\"{x:374,y:717,t:1526328482125};\\\", \\\"{x:366,y:717,t:1526328482142};\\\", \\\"{x:357,y:717,t:1526328482159};\\\", \\\"{x:350,y:717,t:1526328482176};\\\", \\\"{x:343,y:717,t:1526328482192};\\\", \\\"{x:338,y:717,t:1526328482209};\\\", \\\"{x:334,y:717,t:1526328482226};\\\", \\\"{x:328,y:717,t:1526328482242};\\\", \\\"{x:324,y:717,t:1526328482260};\\\", \\\"{x:320,y:717,t:1526328482276};\\\", \\\"{x:313,y:717,t:1526328482293};\\\", \\\"{x:306,y:717,t:1526328482309};\\\", \\\"{x:299,y:717,t:1526328482326};\\\", \\\"{x:295,y:717,t:1526328482343};\\\", \\\"{x:291,y:717,t:1526328482359};\\\", \\\"{x:283,y:717,t:1526328482385};\\\", \\\"{x:282,y:717,t:1526328482393};\\\", \\\"{x:277,y:717,t:1526328482408};\\\", \\\"{x:273,y:717,t:1526328482425};\\\", \\\"{x:269,y:717,t:1526328482442};\\\", \\\"{x:265,y:717,t:1526328482459};\\\", \\\"{x:262,y:717,t:1526328482476};\\\", \\\"{x:259,y:717,t:1526328482492};\\\", \\\"{x:258,y:717,t:1526328482509};\\\", \\\"{x:257,y:717,t:1526328482541};\\\", \\\"{x:256,y:717,t:1526328482606};\\\", \\\"{x:255,y:717,t:1526328483663};\\\", \\\"{x:255,y:716,t:1526328483678};\\\", \\\"{x:257,y:710,t:1526328483694};\\\", \\\"{x:264,y:705,t:1526328483710};\\\", \\\"{x:267,y:702,t:1526328483727};\\\", \\\"{x:269,y:699,t:1526328483744};\\\", \\\"{x:272,y:697,t:1526328483760};\\\", \\\"{x:277,y:694,t:1526328483777};\\\", \\\"{x:282,y:691,t:1526328483794};\\\", \\\"{x:288,y:689,t:1526328483811};\\\", \\\"{x:297,y:685,t:1526328483827};\\\", \\\"{x:306,y:681,t:1526328483844};\\\", \\\"{x:315,y:677,t:1526328483861};\\\", \\\"{x:327,y:675,t:1526328483877};\\\", \\\"{x:348,y:671,t:1526328483894};\\\", \\\"{x:360,y:668,t:1526328483910};\\\", \\\"{x:375,y:667,t:1526328483926};\\\", \\\"{x:393,y:666,t:1526328483944};\\\", \\\"{x:409,y:665,t:1526328483961};\\\", \\\"{x:426,y:663,t:1526328483976};\\\", \\\"{x:441,y:663,t:1526328483993};\\\", \\\"{x:456,y:663,t:1526328484010};\\\", \\\"{x:477,y:663,t:1526328484027};\\\", \\\"{x:491,y:663,t:1526328484044};\\\", \\\"{x:502,y:663,t:1526328484061};\\\", \\\"{x:510,y:663,t:1526328484076};\\\", \\\"{x:517,y:663,t:1526328484093};\\\", \\\"{x:518,y:663,t:1526328484110};\\\", \\\"{x:520,y:663,t:1526328484141};\\\", \\\"{x:522,y:663,t:1526328484149};\\\", \\\"{x:525,y:663,t:1526328484160};\\\", \\\"{x:533,y:663,t:1526328484177};\\\", \\\"{x:548,y:663,t:1526328484193};\\\", \\\"{x:571,y:663,t:1526328484210};\\\", \\\"{x:597,y:663,t:1526328484226};\\\", \\\"{x:631,y:668,t:1526328484243};\\\", \\\"{x:673,y:673,t:1526328484260};\\\", \\\"{x:733,y:680,t:1526328484277};\\\", \\\"{x:824,y:693,t:1526328484293};\\\", \\\"{x:880,y:701,t:1526328484311};\\\", \\\"{x:929,y:706,t:1526328484326};\\\", \\\"{x:985,y:713,t:1526328484344};\\\", \\\"{x:1045,y:725,t:1526328484360};\\\", \\\"{x:1105,y:730,t:1526328484377};\\\", \\\"{x:1166,y:737,t:1526328484393};\\\", \\\"{x:1223,y:741,t:1526328484411};\\\", \\\"{x:1275,y:752,t:1526328484428};\\\", \\\"{x:1349,y:768,t:1526328484444};\\\", \\\"{x:1442,y:788,t:1526328484461};\\\", \\\"{x:1564,y:810,t:1526328484478};\\\", \\\"{x:1588,y:816,t:1526328484493};\\\", \\\"{x:1609,y:822,t:1526328484511};\\\", \\\"{x:1621,y:828,t:1526328484527};\\\", \\\"{x:1626,y:831,t:1526328484544};\\\", \\\"{x:1627,y:832,t:1526328484560};\\\", \\\"{x:1628,y:834,t:1526328484578};\\\", \\\"{x:1632,y:838,t:1526328484594};\\\", \\\"{x:1632,y:839,t:1526328484610};\\\", \\\"{x:1627,y:844,t:1526328484627};\\\", \\\"{x:1620,y:846,t:1526328484644};\\\", \\\"{x:1611,y:849,t:1526328484661};\\\", \\\"{x:1597,y:850,t:1526328484679};\\\", \\\"{x:1588,y:850,t:1526328484693};\\\", \\\"{x:1576,y:852,t:1526328484710};\\\", \\\"{x:1568,y:852,t:1526328484727};\\\", \\\"{x:1556,y:852,t:1526328484743};\\\", \\\"{x:1544,y:850,t:1526328484760};\\\", \\\"{x:1528,y:848,t:1526328484777};\\\", \\\"{x:1512,y:846,t:1526328484794};\\\", \\\"{x:1499,y:843,t:1526328484811};\\\", \\\"{x:1485,y:843,t:1526328484828};\\\", \\\"{x:1467,y:841,t:1526328484844};\\\", \\\"{x:1451,y:838,t:1526328484861};\\\", \\\"{x:1428,y:836,t:1526328484877};\\\", \\\"{x:1414,y:835,t:1526328484893};\\\", \\\"{x:1402,y:832,t:1526328484911};\\\", \\\"{x:1393,y:831,t:1526328484927};\\\", \\\"{x:1383,y:830,t:1526328484945};\\\", \\\"{x:1374,y:827,t:1526328484961};\\\", \\\"{x:1367,y:826,t:1526328484978};\\\", \\\"{x:1361,y:826,t:1526328484994};\\\", \\\"{x:1354,y:826,t:1526328485010};\\\", \\\"{x:1347,y:826,t:1526328485027};\\\", \\\"{x:1341,y:826,t:1526328485044};\\\", \\\"{x:1336,y:826,t:1526328485060};\\\", \\\"{x:1326,y:826,t:1526328485078};\\\", \\\"{x:1316,y:826,t:1526328485093};\\\", \\\"{x:1309,y:826,t:1526328485110};\\\", \\\"{x:1304,y:826,t:1526328485128};\\\", \\\"{x:1297,y:826,t:1526328485145};\\\", \\\"{x:1293,y:826,t:1526328485161};\\\", \\\"{x:1285,y:826,t:1526328485178};\\\", \\\"{x:1276,y:826,t:1526328485194};\\\", \\\"{x:1267,y:826,t:1526328485210};\\\", \\\"{x:1257,y:826,t:1526328485227};\\\", \\\"{x:1252,y:826,t:1526328485245};\\\", \\\"{x:1245,y:826,t:1526328485261};\\\", \\\"{x:1240,y:826,t:1526328485278};\\\", \\\"{x:1236,y:826,t:1526328485294};\\\", \\\"{x:1234,y:826,t:1526328485310};\\\", \\\"{x:1231,y:826,t:1526328485327};\\\", \\\"{x:1228,y:826,t:1526328485462};\\\", \\\"{x:1226,y:826,t:1526328485478};\\\", \\\"{x:1225,y:826,t:1526328485495};\\\", \\\"{x:1222,y:827,t:1526328485511};\\\", \\\"{x:1218,y:827,t:1526328485530};\\\", \\\"{x:1215,y:827,t:1526328485544};\\\", \\\"{x:1211,y:827,t:1526328485561};\\\", \\\"{x:1209,y:828,t:1526328485577};\\\", \\\"{x:1204,y:828,t:1526328485595};\\\", \\\"{x:1202,y:829,t:1526328485611};\\\", \\\"{x:1203,y:829,t:1526328486862};\\\", \\\"{x:1204,y:829,t:1526328486942};\\\", \\\"{x:1205,y:828,t:1526328486974};\\\", \\\"{x:1207,y:827,t:1526328487039};\\\", \\\"{x:1208,y:827,t:1526328487126};\\\", \\\"{x:1209,y:827,t:1526328487167};\\\", \\\"{x:1210,y:826,t:1526328487180};\\\", \\\"{x:1211,y:826,t:1526328487350};\\\", \\\"{x:1212,y:825,t:1526328492102};\\\", \\\"{x:1213,y:825,t:1526328492125};\\\", \\\"{x:1214,y:825,t:1526328492131};\\\", \\\"{x:1216,y:827,t:1526328492148};\\\", \\\"{x:1216,y:828,t:1526328492164};\\\", \\\"{x:1217,y:831,t:1526328492182};\\\", \\\"{x:1217,y:832,t:1526328492198};\\\", \\\"{x:1217,y:834,t:1526328492214};\\\", \\\"{x:1218,y:837,t:1526328492231};\\\", \\\"{x:1219,y:839,t:1526328492248};\\\", \\\"{x:1220,y:842,t:1526328492265};\\\", \\\"{x:1220,y:843,t:1526328492282};\\\", \\\"{x:1221,y:845,t:1526328492298};\\\", \\\"{x:1221,y:847,t:1526328492315};\\\", \\\"{x:1223,y:850,t:1526328492331};\\\", \\\"{x:1223,y:853,t:1526328492348};\\\", \\\"{x:1225,y:860,t:1526328492365};\\\", \\\"{x:1226,y:864,t:1526328492382};\\\", \\\"{x:1227,y:869,t:1526328492399};\\\", \\\"{x:1227,y:875,t:1526328492415};\\\", \\\"{x:1227,y:881,t:1526328492431};\\\", \\\"{x:1227,y:888,t:1526328492448};\\\", \\\"{x:1227,y:893,t:1526328492466};\\\", \\\"{x:1227,y:900,t:1526328492482};\\\", \\\"{x:1228,y:907,t:1526328492499};\\\", \\\"{x:1230,y:913,t:1526328492516};\\\", \\\"{x:1234,y:919,t:1526328492531};\\\", \\\"{x:1237,y:923,t:1526328492548};\\\", \\\"{x:1240,y:926,t:1526328492565};\\\", \\\"{x:1242,y:929,t:1526328492582};\\\", \\\"{x:1243,y:931,t:1526328492599};\\\", \\\"{x:1245,y:934,t:1526328492616};\\\", \\\"{x:1248,y:938,t:1526328492632};\\\", \\\"{x:1251,y:941,t:1526328492649};\\\", \\\"{x:1259,y:944,t:1526328492666};\\\", \\\"{x:1265,y:947,t:1526328492683};\\\", \\\"{x:1272,y:952,t:1526328492699};\\\", \\\"{x:1281,y:955,t:1526328492715};\\\", \\\"{x:1285,y:956,t:1526328492732};\\\", \\\"{x:1289,y:958,t:1526328492749};\\\", \\\"{x:1294,y:959,t:1526328492766};\\\", \\\"{x:1300,y:959,t:1526328492782};\\\", \\\"{x:1303,y:960,t:1526328492799};\\\", \\\"{x:1306,y:960,t:1526328492816};\\\", \\\"{x:1310,y:960,t:1526328492832};\\\", \\\"{x:1314,y:960,t:1526328492849};\\\", \\\"{x:1318,y:960,t:1526328492867};\\\", \\\"{x:1320,y:960,t:1526328492894};\\\", \\\"{x:1321,y:960,t:1526328492902};\\\", \\\"{x:1322,y:961,t:1526328492916};\\\", \\\"{x:1323,y:961,t:1526328492934};\\\", \\\"{x:1324,y:961,t:1526328492949};\\\", \\\"{x:1325,y:961,t:1526328492966};\\\", \\\"{x:1326,y:961,t:1526328492984};\\\", \\\"{x:1327,y:961,t:1526328493014};\\\", \\\"{x:1329,y:960,t:1526328493054};\\\", \\\"{x:1330,y:960,t:1526328493070};\\\", \\\"{x:1330,y:959,t:1526328493083};\\\", \\\"{x:1331,y:959,t:1526328493099};\\\", \\\"{x:1336,y:958,t:1526328493116};\\\", \\\"{x:1338,y:958,t:1526328493133};\\\", \\\"{x:1342,y:958,t:1526328493149};\\\", \\\"{x:1346,y:958,t:1526328493166};\\\", \\\"{x:1348,y:958,t:1526328493184};\\\", \\\"{x:1349,y:958,t:1526328493200};\\\", \\\"{x:1350,y:958,t:1526328493543};\\\", \\\"{x:1350,y:957,t:1526328493663};\\\", \\\"{x:1350,y:956,t:1526328493678};\\\", \\\"{x:1350,y:955,t:1526328493702};\\\", \\\"{x:1350,y:954,t:1526328493717};\\\", \\\"{x:1350,y:950,t:1526328493733};\\\", \\\"{x:1350,y:946,t:1526328493749};\\\", \\\"{x:1350,y:943,t:1526328493766};\\\", \\\"{x:1350,y:941,t:1526328493783};\\\", \\\"{x:1350,y:938,t:1526328493798};\\\", \\\"{x:1350,y:931,t:1526328493816};\\\", \\\"{x:1350,y:923,t:1526328493833};\\\", \\\"{x:1350,y:919,t:1526328493849};\\\", \\\"{x:1350,y:912,t:1526328493866};\\\", \\\"{x:1350,y:905,t:1526328493883};\\\", \\\"{x:1350,y:896,t:1526328493900};\\\", \\\"{x:1350,y:884,t:1526328493917};\\\", \\\"{x:1350,y:862,t:1526328493933};\\\", \\\"{x:1350,y:848,t:1526328493949};\\\", \\\"{x:1350,y:834,t:1526328493966};\\\", \\\"{x:1350,y:826,t:1526328493983};\\\", \\\"{x:1350,y:817,t:1526328493999};\\\", \\\"{x:1350,y:811,t:1526328494016};\\\", \\\"{x:1350,y:803,t:1526328494033};\\\", \\\"{x:1350,y:799,t:1526328494050};\\\", \\\"{x:1349,y:795,t:1526328494066};\\\", \\\"{x:1349,y:791,t:1526328494083};\\\", \\\"{x:1348,y:789,t:1526328494099};\\\", \\\"{x:1348,y:788,t:1526328494116};\\\", \\\"{x:1348,y:786,t:1526328494134};\\\", \\\"{x:1348,y:785,t:1526328494150};\\\", \\\"{x:1347,y:783,t:1526328494167};\\\", \\\"{x:1347,y:780,t:1526328494184};\\\", \\\"{x:1346,y:779,t:1526328494201};\\\", \\\"{x:1346,y:776,t:1526328494216};\\\", \\\"{x:1346,y:775,t:1526328494234};\\\", \\\"{x:1346,y:772,t:1526328494250};\\\", \\\"{x:1346,y:771,t:1526328494266};\\\", \\\"{x:1346,y:769,t:1526328494283};\\\", \\\"{x:1346,y:767,t:1526328494301};\\\", \\\"{x:1346,y:766,t:1526328494317};\\\", \\\"{x:1346,y:764,t:1526328494333};\\\", \\\"{x:1346,y:763,t:1526328494365};\\\", \\\"{x:1346,y:759,t:1526328497575};\\\", \\\"{x:1348,y:750,t:1526328497589};\\\", \\\"{x:1349,y:739,t:1526328497603};\\\", \\\"{x:1349,y:734,t:1526328497618};\\\", \\\"{x:1349,y:730,t:1526328497634};\\\", \\\"{x:1349,y:728,t:1526328497652};\\\", \\\"{x:1349,y:723,t:1526328497669};\\\", \\\"{x:1349,y:719,t:1526328497685};\\\", \\\"{x:1349,y:714,t:1526328497702};\\\", \\\"{x:1349,y:707,t:1526328497719};\\\", \\\"{x:1345,y:692,t:1526328497736};\\\", \\\"{x:1344,y:682,t:1526328497752};\\\", \\\"{x:1344,y:678,t:1526328497768};\\\", \\\"{x:1343,y:672,t:1526328497786};\\\", \\\"{x:1342,y:666,t:1526328497801};\\\", \\\"{x:1341,y:660,t:1526328497818};\\\", \\\"{x:1340,y:655,t:1526328497836};\\\", \\\"{x:1339,y:649,t:1526328497852};\\\", \\\"{x:1337,y:643,t:1526328497869};\\\", \\\"{x:1337,y:637,t:1526328497885};\\\", \\\"{x:1337,y:632,t:1526328497902};\\\", \\\"{x:1337,y:629,t:1526328497919};\\\", \\\"{x:1335,y:622,t:1526328497936};\\\", \\\"{x:1335,y:618,t:1526328497953};\\\", \\\"{x:1334,y:612,t:1526328497969};\\\", \\\"{x:1334,y:605,t:1526328497986};\\\", \\\"{x:1334,y:602,t:1526328498002};\\\", \\\"{x:1334,y:598,t:1526328498019};\\\", \\\"{x:1334,y:596,t:1526328498036};\\\", \\\"{x:1334,y:590,t:1526328498052};\\\", \\\"{x:1334,y:581,t:1526328498070};\\\", \\\"{x:1336,y:575,t:1526328498085};\\\", \\\"{x:1338,y:569,t:1526328498102};\\\", \\\"{x:1339,y:564,t:1526328498119};\\\", \\\"{x:1340,y:557,t:1526328498136};\\\", \\\"{x:1342,y:547,t:1526328498152};\\\", \\\"{x:1344,y:541,t:1526328498169};\\\", \\\"{x:1347,y:530,t:1526328498186};\\\", \\\"{x:1350,y:520,t:1526328498202};\\\", \\\"{x:1351,y:513,t:1526328498219};\\\", \\\"{x:1351,y:507,t:1526328498236};\\\", \\\"{x:1352,y:498,t:1526328498253};\\\", \\\"{x:1352,y:493,t:1526328498269};\\\", \\\"{x:1352,y:475,t:1526328498286};\\\", \\\"{x:1351,y:464,t:1526328498302};\\\", \\\"{x:1351,y:456,t:1526328498319};\\\", \\\"{x:1350,y:444,t:1526328498336};\\\", \\\"{x:1346,y:435,t:1526328498352};\\\", \\\"{x:1344,y:429,t:1526328498369};\\\", \\\"{x:1343,y:425,t:1526328498386};\\\", \\\"{x:1342,y:420,t:1526328498403};\\\", \\\"{x:1339,y:414,t:1526328498419};\\\", \\\"{x:1339,y:411,t:1526328498435};\\\", \\\"{x:1339,y:407,t:1526328498453};\\\", \\\"{x:1338,y:406,t:1526328498646};\\\", \\\"{x:1336,y:406,t:1526328498654};\\\", \\\"{x:1336,y:409,t:1526328498669};\\\", \\\"{x:1335,y:412,t:1526328498686};\\\", \\\"{x:1335,y:414,t:1526328498703};\\\", \\\"{x:1334,y:417,t:1526328498719};\\\", \\\"{x:1334,y:420,t:1526328498736};\\\", \\\"{x:1334,y:421,t:1526328498753};\\\", \\\"{x:1334,y:425,t:1526328498769};\\\", \\\"{x:1334,y:430,t:1526328498786};\\\", \\\"{x:1332,y:436,t:1526328498803};\\\", \\\"{x:1332,y:444,t:1526328498819};\\\", \\\"{x:1332,y:452,t:1526328498836};\\\", \\\"{x:1331,y:465,t:1526328498853};\\\", \\\"{x:1331,y:471,t:1526328498869};\\\", \\\"{x:1331,y:477,t:1526328498885};\\\", \\\"{x:1331,y:482,t:1526328498903};\\\", \\\"{x:1331,y:487,t:1526328498919};\\\", \\\"{x:1331,y:497,t:1526328498936};\\\", \\\"{x:1332,y:505,t:1526328498953};\\\", \\\"{x:1332,y:514,t:1526328498969};\\\", \\\"{x:1333,y:527,t:1526328498986};\\\", \\\"{x:1336,y:542,t:1526328499003};\\\", \\\"{x:1337,y:552,t:1526328499019};\\\", \\\"{x:1338,y:566,t:1526328499036};\\\", \\\"{x:1339,y:601,t:1526328499053};\\\", \\\"{x:1342,y:638,t:1526328499069};\\\", \\\"{x:1342,y:680,t:1526328499086};\\\", \\\"{x:1342,y:719,t:1526328499103};\\\", \\\"{x:1342,y:754,t:1526328499119};\\\", \\\"{x:1337,y:788,t:1526328499136};\\\", \\\"{x:1334,y:819,t:1526328499153};\\\", \\\"{x:1330,y:860,t:1526328499169};\\\", \\\"{x:1326,y:896,t:1526328499187};\\\", \\\"{x:1320,y:934,t:1526328499203};\\\", \\\"{x:1314,y:974,t:1526328499220};\\\", \\\"{x:1309,y:997,t:1526328499236};\\\", \\\"{x:1304,y:1022,t:1526328499253};\\\", \\\"{x:1304,y:1030,t:1526328499269};\\\", \\\"{x:1304,y:1035,t:1526328499286};\\\", \\\"{x:1303,y:1039,t:1526328499303};\\\", \\\"{x:1301,y:1043,t:1526328499321};\\\", \\\"{x:1301,y:1045,t:1526328499336};\\\", \\\"{x:1301,y:1046,t:1526328499353};\\\", \\\"{x:1301,y:1047,t:1526328499478};\\\", \\\"{x:1302,y:1046,t:1526328499510};\\\", \\\"{x:1304,y:1043,t:1526328499521};\\\", \\\"{x:1308,y:1037,t:1526328499537};\\\", \\\"{x:1310,y:1032,t:1526328499553};\\\", \\\"{x:1315,y:1028,t:1526328499569};\\\", \\\"{x:1318,y:1024,t:1526328499586};\\\", \\\"{x:1321,y:1021,t:1526328499603};\\\", \\\"{x:1323,y:1018,t:1526328499619};\\\", \\\"{x:1323,y:1017,t:1526328499636};\\\", \\\"{x:1325,y:1016,t:1526328499653};\\\", \\\"{x:1325,y:1015,t:1526328499669};\\\", \\\"{x:1326,y:1014,t:1526328499686};\\\", \\\"{x:1327,y:1014,t:1526328499704};\\\", \\\"{x:1328,y:1013,t:1526328499719};\\\", \\\"{x:1329,y:1012,t:1526328499736};\\\", \\\"{x:1330,y:1011,t:1526328499753};\\\", \\\"{x:1331,y:1010,t:1526328499770};\\\", \\\"{x:1332,y:1010,t:1526328499787};\\\", \\\"{x:1333,y:1009,t:1526328499804};\\\", \\\"{x:1334,y:1008,t:1526328499821};\\\", \\\"{x:1335,y:1008,t:1526328499845};\\\", \\\"{x:1336,y:1008,t:1526328499854};\\\", \\\"{x:1337,y:1008,t:1526328499877};\\\", \\\"{x:1337,y:1007,t:1526328499887};\\\", \\\"{x:1339,y:1006,t:1526328499904};\\\", \\\"{x:1339,y:1005,t:1526328499920};\\\", \\\"{x:1341,y:1005,t:1526328499936};\\\", \\\"{x:1342,y:1004,t:1526328499953};\\\", \\\"{x:1343,y:1003,t:1526328499973};\\\", \\\"{x:1343,y:1002,t:1526328500013};\\\", \\\"{x:1342,y:1002,t:1526328503470};\\\", \\\"{x:1339,y:999,t:1526328503477};\\\", \\\"{x:1331,y:996,t:1526328503493};\\\", \\\"{x:1328,y:994,t:1526328503507};\\\", \\\"{x:1320,y:991,t:1526328503523};\\\", \\\"{x:1317,y:989,t:1526328503539};\\\", \\\"{x:1312,y:986,t:1526328503556};\\\", \\\"{x:1306,y:984,t:1526328503572};\\\", \\\"{x:1302,y:982,t:1526328503590};\\\", \\\"{x:1297,y:977,t:1526328503606};\\\", \\\"{x:1290,y:971,t:1526328503623};\\\", \\\"{x:1285,y:970,t:1526328503640};\\\", \\\"{x:1281,y:967,t:1526328503657};\\\", \\\"{x:1277,y:965,t:1526328503673};\\\", \\\"{x:1274,y:964,t:1526328503689};\\\", \\\"{x:1272,y:963,t:1526328503706};\\\", \\\"{x:1270,y:963,t:1526328503722};\\\", \\\"{x:1268,y:963,t:1526328503739};\\\", \\\"{x:1267,y:963,t:1526328503756};\\\", \\\"{x:1265,y:963,t:1526328503772};\\\", \\\"{x:1264,y:963,t:1526328503789};\\\", \\\"{x:1262,y:963,t:1526328503806};\\\", \\\"{x:1261,y:963,t:1526328503823};\\\", \\\"{x:1257,y:963,t:1526328503840};\\\", \\\"{x:1251,y:963,t:1526328503856};\\\", \\\"{x:1246,y:963,t:1526328503873};\\\", \\\"{x:1239,y:963,t:1526328503889};\\\", \\\"{x:1235,y:963,t:1526328503906};\\\", \\\"{x:1229,y:962,t:1526328503924};\\\", \\\"{x:1224,y:960,t:1526328503939};\\\", \\\"{x:1221,y:959,t:1526328503957};\\\", \\\"{x:1218,y:958,t:1526328503973};\\\", \\\"{x:1216,y:957,t:1526328503990};\\\", \\\"{x:1215,y:956,t:1526328504006};\\\", \\\"{x:1214,y:956,t:1526328504118};\\\", \\\"{x:1212,y:956,t:1526328504166};\\\", \\\"{x:1211,y:957,t:1526328504192};\\\", \\\"{x:1209,y:957,t:1526328504208};\\\", \\\"{x:1208,y:957,t:1526328504245};\\\", \\\"{x:1207,y:957,t:1526328504262};\\\", \\\"{x:1206,y:957,t:1526328504274};\\\", \\\"{x:1205,y:957,t:1526328504309};\\\", \\\"{x:1205,y:955,t:1526328504324};\\\", \\\"{x:1205,y:949,t:1526328504339};\\\", \\\"{x:1204,y:942,t:1526328504356};\\\", \\\"{x:1204,y:925,t:1526328504375};\\\", \\\"{x:1204,y:906,t:1526328504389};\\\", \\\"{x:1204,y:877,t:1526328504406};\\\", \\\"{x:1203,y:845,t:1526328504423};\\\", \\\"{x:1203,y:826,t:1526328504439};\\\", \\\"{x:1203,y:811,t:1526328504456};\\\", \\\"{x:1203,y:803,t:1526328504472};\\\", \\\"{x:1203,y:797,t:1526328504490};\\\", \\\"{x:1203,y:793,t:1526328504506};\\\", \\\"{x:1203,y:792,t:1526328504523};\\\", \\\"{x:1202,y:791,t:1526328504541};\\\", \\\"{x:1201,y:791,t:1526328504798};\\\", \\\"{x:1201,y:792,t:1526328504809};\\\", \\\"{x:1201,y:794,t:1526328504825};\\\", \\\"{x:1201,y:798,t:1526328504840};\\\", \\\"{x:1200,y:806,t:1526328504857};\\\", \\\"{x:1198,y:813,t:1526328504873};\\\", \\\"{x:1195,y:821,t:1526328504890};\\\", \\\"{x:1194,y:826,t:1526328504906};\\\", \\\"{x:1193,y:827,t:1526328504924};\\\", \\\"{x:1193,y:829,t:1526328504940};\\\", \\\"{x:1192,y:831,t:1526328504957};\\\", \\\"{x:1192,y:832,t:1526328505014};\\\", \\\"{x:1192,y:833,t:1526328505053};\\\", \\\"{x:1192,y:834,t:1526328505174};\\\", \\\"{x:1192,y:835,t:1526328505246};\\\", \\\"{x:1192,y:836,t:1526328505272};\\\", \\\"{x:1192,y:837,t:1526328505301};\\\", \\\"{x:1192,y:838,t:1526328505331};\\\", \\\"{x:1192,y:839,t:1526328505500};\\\", \\\"{x:1191,y:839,t:1526328505515};\\\", \\\"{x:1190,y:840,t:1526328506428};\\\", \\\"{x:1190,y:841,t:1526328506434};\\\", \\\"{x:1189,y:846,t:1526328506450};\\\", \\\"{x:1189,y:850,t:1526328506462};\\\", \\\"{x:1189,y:854,t:1526328506480};\\\", \\\"{x:1188,y:859,t:1526328506495};\\\", \\\"{x:1188,y:861,t:1526328506512};\\\", \\\"{x:1188,y:863,t:1526328506530};\\\", \\\"{x:1187,y:865,t:1526328506546};\\\", \\\"{x:1187,y:866,t:1526328506562};\\\", \\\"{x:1187,y:867,t:1526328506594};\\\", \\\"{x:1187,y:869,t:1526328506634};\\\", \\\"{x:1187,y:870,t:1526328506650};\\\", \\\"{x:1187,y:873,t:1526328506662};\\\", \\\"{x:1191,y:879,t:1526328506679};\\\", \\\"{x:1196,y:887,t:1526328506697};\\\", \\\"{x:1201,y:896,t:1526328506712};\\\", \\\"{x:1206,y:904,t:1526328506730};\\\", \\\"{x:1213,y:914,t:1526328506747};\\\", \\\"{x:1220,y:925,t:1526328506763};\\\", \\\"{x:1225,y:934,t:1526328506779};\\\", \\\"{x:1234,y:942,t:1526328506796};\\\", \\\"{x:1243,y:950,t:1526328506812};\\\", \\\"{x:1251,y:958,t:1526328506829};\\\", \\\"{x:1259,y:964,t:1526328506847};\\\", \\\"{x:1261,y:965,t:1526328506862};\\\", \\\"{x:1263,y:966,t:1526328506879};\\\", \\\"{x:1264,y:966,t:1526328506898};\\\", \\\"{x:1264,y:967,t:1526328506913};\\\", \\\"{x:1267,y:967,t:1526328506929};\\\", \\\"{x:1274,y:967,t:1526328506946};\\\", \\\"{x:1279,y:967,t:1526328506964};\\\", \\\"{x:1282,y:967,t:1526328506980};\\\", \\\"{x:1287,y:967,t:1526328506996};\\\", \\\"{x:1293,y:967,t:1526328507013};\\\", \\\"{x:1299,y:967,t:1526328507030};\\\", \\\"{x:1311,y:967,t:1526328507046};\\\", \\\"{x:1325,y:969,t:1526328507063};\\\", \\\"{x:1338,y:970,t:1526328507079};\\\", \\\"{x:1348,y:970,t:1526328507096};\\\", \\\"{x:1355,y:971,t:1526328507114};\\\", \\\"{x:1360,y:973,t:1526328507130};\\\", \\\"{x:1363,y:973,t:1526328507146};\\\", \\\"{x:1359,y:972,t:1526328507371};\\\", \\\"{x:1356,y:970,t:1526328507384};\\\", \\\"{x:1354,y:969,t:1526328507402};\\\", \\\"{x:1352,y:969,t:1526328507412};\\\", \\\"{x:1350,y:969,t:1526328507430};\\\", \\\"{x:1348,y:969,t:1526328507447};\\\", \\\"{x:1347,y:969,t:1526328507562};\\\", \\\"{x:1346,y:969,t:1526328510545};\\\", \\\"{x:1337,y:965,t:1526328510554};\\\", \\\"{x:1313,y:960,t:1526328510570};\\\", \\\"{x:1298,y:957,t:1526328510582};\\\", \\\"{x:1261,y:947,t:1526328510598};\\\", \\\"{x:1199,y:934,t:1526328510616};\\\", \\\"{x:1117,y:918,t:1526328510633};\\\", \\\"{x:1020,y:906,t:1526328510648};\\\", \\\"{x:928,y:891,t:1526328510665};\\\", \\\"{x:761,y:852,t:1526328510681};\\\", \\\"{x:650,y:819,t:1526328510698};\\\", \\\"{x:542,y:789,t:1526328510715};\\\", \\\"{x:436,y:758,t:1526328510733};\\\", \\\"{x:342,y:731,t:1526328510749};\\\", \\\"{x:262,y:708,t:1526328510765};\\\", \\\"{x:192,y:685,t:1526328510782};\\\", \\\"{x:131,y:657,t:1526328510799};\\\", \\\"{x:83,y:626,t:1526328510816};\\\", \\\"{x:40,y:601,t:1526328510832};\\\", \\\"{x:10,y:577,t:1526328510848};\\\", \\\"{x:0,y:555,t:1526328510871};\\\", \\\"{x:0,y:553,t:1526328510888};\\\", \\\"{x:0,y:550,t:1526328510904};\\\", \\\"{x:0,y:546,t:1526328510921};\\\", \\\"{x:3,y:536,t:1526328510938};\\\", \\\"{x:11,y:530,t:1526328510954};\\\", \\\"{x:24,y:524,t:1526328510971};\\\", \\\"{x:48,y:521,t:1526328510989};\\\", \\\"{x:80,y:519,t:1526328511005};\\\", \\\"{x:122,y:519,t:1526328511021};\\\", \\\"{x:172,y:519,t:1526328511037};\\\", \\\"{x:209,y:519,t:1526328511055};\\\", \\\"{x:251,y:519,t:1526328511071};\\\", \\\"{x:299,y:520,t:1526328511089};\\\", \\\"{x:335,y:524,t:1526328511105};\\\", \\\"{x:362,y:527,t:1526328511121};\\\", \\\"{x:386,y:532,t:1526328511138};\\\", \\\"{x:388,y:532,t:1526328511155};\\\", \\\"{x:389,y:532,t:1526328511186};\\\", \\\"{x:388,y:532,t:1526328511507};\\\", \\\"{x:385,y:532,t:1526328511522};\\\", \\\"{x:383,y:533,t:1526328511540};\\\", \\\"{x:382,y:531,t:1526328512412};\\\", \\\"{x:382,y:529,t:1526328512426};\\\", \\\"{x:382,y:528,t:1526328512442};\\\", \\\"{x:382,y:527,t:1526328512455};\\\", \\\"{x:382,y:526,t:1526328512472};\\\", \\\"{x:382,y:527,t:1526328513617};\\\", \\\"{x:382,y:530,t:1526328513626};\\\", \\\"{x:383,y:535,t:1526328513640};\\\", \\\"{x:389,y:547,t:1526328513657};\\\", \\\"{x:403,y:570,t:1526328513674};\\\", \\\"{x:415,y:584,t:1526328513690};\\\", \\\"{x:425,y:597,t:1526328513707};\\\", \\\"{x:435,y:610,t:1526328513722};\\\", \\\"{x:448,y:624,t:1526328513741};\\\", \\\"{x:457,y:635,t:1526328513757};\\\", \\\"{x:468,y:650,t:1526328513773};\\\", \\\"{x:475,y:661,t:1526328513791};\\\", \\\"{x:481,y:673,t:1526328513807};\\\", \\\"{x:488,y:681,t:1526328513823};\\\", \\\"{x:494,y:692,t:1526328513840};\\\", \\\"{x:499,y:703,t:1526328513858};\\\", \\\"{x:502,y:710,t:1526328513873};\\\", \\\"{x:502,y:711,t:1526328513914};\\\", \\\"{x:502,y:712,t:1526328513924};\\\", \\\"{x:503,y:714,t:1526328513940};\\\", \\\"{x:504,y:716,t:1526328513957};\\\", \\\"{x:504,y:718,t:1526328513973};\\\" ] }, { \\\"rt\\\": 53985, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 423364, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-04 PM-04 PM-04 PM-04 PM-03 PM-03 PM-03:30\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:719,t:1526328516882};\\\", \\\"{x:509,y:723,t:1526328516898};\\\", \\\"{x:509,y:724,t:1526328516911};\\\", \\\"{x:511,y:726,t:1526328516928};\\\", \\\"{x:512,y:727,t:1526328516955};\\\", \\\"{x:513,y:727,t:1526328516963};\\\", \\\"{x:513,y:728,t:1526328516978};\\\", \\\"{x:516,y:729,t:1526328516994};\\\", \\\"{x:517,y:731,t:1526328517010};\\\", \\\"{x:519,y:732,t:1526328517027};\\\", \\\"{x:523,y:733,t:1526328517044};\\\", \\\"{x:525,y:735,t:1526328517060};\\\", \\\"{x:528,y:735,t:1526328517077};\\\", \\\"{x:529,y:736,t:1526328517094};\\\", \\\"{x:531,y:737,t:1526328517110};\\\", \\\"{x:533,y:737,t:1526328517127};\\\", \\\"{x:534,y:738,t:1526328517143};\\\", \\\"{x:536,y:738,t:1526328517159};\\\", \\\"{x:538,y:739,t:1526328517176};\\\", \\\"{x:542,y:741,t:1526328517193};\\\", \\\"{x:547,y:742,t:1526328517209};\\\", \\\"{x:553,y:744,t:1526328517227};\\\", \\\"{x:562,y:746,t:1526328517243};\\\", \\\"{x:571,y:750,t:1526328517259};\\\", \\\"{x:590,y:757,t:1526328517276};\\\", \\\"{x:620,y:764,t:1526328517294};\\\", \\\"{x:676,y:780,t:1526328517310};\\\", \\\"{x:762,y:805,t:1526328517326};\\\", \\\"{x:873,y:837,t:1526328517343};\\\", \\\"{x:1004,y:878,t:1526328517359};\\\", \\\"{x:1150,y:915,t:1526328517376};\\\", \\\"{x:1378,y:977,t:1526328517393};\\\", \\\"{x:1522,y:1018,t:1526328517409};\\\", \\\"{x:1668,y:1053,t:1526328517425};\\\", \\\"{x:1801,y:1074,t:1526328517443};\\\", \\\"{x:1905,y:1094,t:1526328517461};\\\", \\\"{x:1919,y:1113,t:1526328517476};\\\", \\\"{x:1919,y:1121,t:1526328517493};\\\", \\\"{x:1919,y:1124,t:1526328517510};\\\", \\\"{x:1919,y:1125,t:1526328517526};\\\", \\\"{x:1919,y:1120,t:1526328517626};\\\", \\\"{x:1917,y:1115,t:1526328517633};\\\", \\\"{x:1905,y:1093,t:1526328517649};\\\", \\\"{x:1895,y:1082,t:1526328517660};\\\", \\\"{x:1876,y:1063,t:1526328517677};\\\", \\\"{x:1865,y:1055,t:1526328517693};\\\", \\\"{x:1854,y:1048,t:1526328517710};\\\", \\\"{x:1839,y:1042,t:1526328517727};\\\", \\\"{x:1825,y:1037,t:1526328517743};\\\", \\\"{x:1812,y:1033,t:1526328517760};\\\", \\\"{x:1799,y:1029,t:1526328517777};\\\", \\\"{x:1789,y:1027,t:1526328517793};\\\", \\\"{x:1767,y:1020,t:1526328517810};\\\", \\\"{x:1753,y:1019,t:1526328517827};\\\", \\\"{x:1746,y:1018,t:1526328517843};\\\", \\\"{x:1743,y:1018,t:1526328517860};\\\", \\\"{x:1738,y:1017,t:1526328517877};\\\", \\\"{x:1734,y:1017,t:1526328517894};\\\", \\\"{x:1726,y:1017,t:1526328517909};\\\", \\\"{x:1716,y:1017,t:1526328517927};\\\", \\\"{x:1699,y:1014,t:1526328517944};\\\", \\\"{x:1684,y:1013,t:1526328517960};\\\", \\\"{x:1666,y:1010,t:1526328517977};\\\", \\\"{x:1639,y:1008,t:1526328517994};\\\", \\\"{x:1620,y:1004,t:1526328518010};\\\", \\\"{x:1601,y:1002,t:1526328518028};\\\", \\\"{x:1581,y:999,t:1526328518044};\\\", \\\"{x:1567,y:997,t:1526328518061};\\\", \\\"{x:1559,y:996,t:1526328518077};\\\", \\\"{x:1553,y:996,t:1526328518094};\\\", \\\"{x:1552,y:994,t:1526328518111};\\\", \\\"{x:1551,y:994,t:1526328518129};\\\", \\\"{x:1551,y:993,t:1526328518210};\\\", \\\"{x:1555,y:992,t:1526328518234};\\\", \\\"{x:1556,y:991,t:1526328518244};\\\", \\\"{x:1562,y:989,t:1526328518261};\\\", \\\"{x:1566,y:986,t:1526328518277};\\\", \\\"{x:1570,y:985,t:1526328518296};\\\", \\\"{x:1573,y:983,t:1526328518311};\\\", \\\"{x:1577,y:982,t:1526328518327};\\\", \\\"{x:1582,y:979,t:1526328518344};\\\", \\\"{x:1584,y:978,t:1526328518361};\\\", \\\"{x:1588,y:977,t:1526328518377};\\\", \\\"{x:1593,y:974,t:1526328518393};\\\", \\\"{x:1595,y:974,t:1526328518411};\\\", \\\"{x:1598,y:972,t:1526328518427};\\\", \\\"{x:1600,y:971,t:1526328518466};\\\", \\\"{x:1601,y:970,t:1526328518479};\\\", \\\"{x:1602,y:970,t:1526328518603};\\\", \\\"{x:1603,y:969,t:1526328518624};\\\", \\\"{x:1604,y:968,t:1526328518627};\\\", \\\"{x:1605,y:968,t:1526328518644};\\\", \\\"{x:1609,y:966,t:1526328518661};\\\", \\\"{x:1613,y:964,t:1526328518678};\\\", \\\"{x:1616,y:961,t:1526328518695};\\\", \\\"{x:1615,y:961,t:1526328518987};\\\", \\\"{x:1614,y:962,t:1526328519002};\\\", \\\"{x:1612,y:962,t:1526328519018};\\\", \\\"{x:1609,y:961,t:1526328519697};\\\", \\\"{x:1608,y:957,t:1526328519714};\\\", \\\"{x:1607,y:955,t:1526328519728};\\\", \\\"{x:1605,y:952,t:1526328519745};\\\", \\\"{x:1604,y:950,t:1526328519762};\\\", \\\"{x:1603,y:947,t:1526328519778};\\\", \\\"{x:1602,y:946,t:1526328519795};\\\", \\\"{x:1601,y:945,t:1526328519849};\\\", \\\"{x:1601,y:944,t:1526328520001};\\\", \\\"{x:1601,y:943,t:1526328520022};\\\", \\\"{x:1601,y:942,t:1526328520028};\\\", \\\"{x:1602,y:941,t:1526328520045};\\\", \\\"{x:1603,y:939,t:1526328520062};\\\", \\\"{x:1605,y:938,t:1526328520078};\\\", \\\"{x:1608,y:937,t:1526328520095};\\\", \\\"{x:1610,y:935,t:1526328520112};\\\", \\\"{x:1611,y:935,t:1526328520128};\\\", \\\"{x:1612,y:934,t:1526328520145};\\\", \\\"{x:1613,y:934,t:1526328520162};\\\", \\\"{x:1614,y:934,t:1526328520209};\\\", \\\"{x:1615,y:934,t:1526328520218};\\\", \\\"{x:1615,y:935,t:1526328520228};\\\", \\\"{x:1615,y:942,t:1526328520245};\\\", \\\"{x:1615,y:948,t:1526328520262};\\\", \\\"{x:1615,y:953,t:1526328520278};\\\", \\\"{x:1615,y:956,t:1526328520296};\\\", \\\"{x:1615,y:961,t:1526328520313};\\\", \\\"{x:1615,y:963,t:1526328520328};\\\", \\\"{x:1612,y:965,t:1526328520346};\\\", \\\"{x:1611,y:965,t:1526328520361};\\\", \\\"{x:1609,y:967,t:1526328520378};\\\", \\\"{x:1608,y:967,t:1526328520396};\\\", \\\"{x:1608,y:966,t:1526328520585};\\\", \\\"{x:1609,y:964,t:1526328520601};\\\", \\\"{x:1610,y:964,t:1526328520612};\\\", \\\"{x:1611,y:961,t:1526328520629};\\\", \\\"{x:1612,y:961,t:1526328520646};\\\", \\\"{x:1613,y:959,t:1526328520662};\\\", \\\"{x:1617,y:956,t:1526328520679};\\\", \\\"{x:1622,y:954,t:1526328520695};\\\", \\\"{x:1627,y:952,t:1526328520712};\\\", \\\"{x:1635,y:948,t:1526328520728};\\\", \\\"{x:1644,y:945,t:1526328520745};\\\", \\\"{x:1646,y:944,t:1526328520761};\\\", \\\"{x:1647,y:944,t:1526328520779};\\\", \\\"{x:1648,y:944,t:1526328520795};\\\", \\\"{x:1647,y:944,t:1526328520913};\\\", \\\"{x:1642,y:944,t:1526328520929};\\\", \\\"{x:1637,y:948,t:1526328520945};\\\", \\\"{x:1631,y:956,t:1526328520962};\\\", \\\"{x:1626,y:963,t:1526328520979};\\\", \\\"{x:1623,y:967,t:1526328520995};\\\", \\\"{x:1622,y:968,t:1526328521012};\\\", \\\"{x:1621,y:969,t:1526328521033};\\\", \\\"{x:1620,y:970,t:1526328521130};\\\", \\\"{x:1619,y:971,t:1526328521169};\\\", \\\"{x:1618,y:971,t:1526328521209};\\\", \\\"{x:1615,y:969,t:1526328521218};\\\", \\\"{x:1615,y:966,t:1526328521230};\\\", \\\"{x:1611,y:959,t:1526328521246};\\\", \\\"{x:1608,y:952,t:1526328521262};\\\", \\\"{x:1606,y:947,t:1526328521279};\\\", \\\"{x:1605,y:942,t:1526328521296};\\\", \\\"{x:1604,y:940,t:1526328521312};\\\", \\\"{x:1603,y:935,t:1526328521330};\\\", \\\"{x:1603,y:930,t:1526328521345};\\\", \\\"{x:1602,y:924,t:1526328521362};\\\", \\\"{x:1602,y:919,t:1526328521380};\\\", \\\"{x:1602,y:914,t:1526328521395};\\\", \\\"{x:1602,y:910,t:1526328521412};\\\", \\\"{x:1602,y:907,t:1526328521429};\\\", \\\"{x:1602,y:903,t:1526328521447};\\\", \\\"{x:1602,y:900,t:1526328521463};\\\", \\\"{x:1602,y:894,t:1526328521479};\\\", \\\"{x:1602,y:888,t:1526328521497};\\\", \\\"{x:1602,y:884,t:1526328521512};\\\", \\\"{x:1602,y:879,t:1526328521530};\\\", \\\"{x:1602,y:876,t:1526328521546};\\\", \\\"{x:1602,y:870,t:1526328521563};\\\", \\\"{x:1602,y:864,t:1526328521579};\\\", \\\"{x:1602,y:857,t:1526328521597};\\\", \\\"{x:1602,y:851,t:1526328521612};\\\", \\\"{x:1602,y:846,t:1526328521630};\\\", \\\"{x:1600,y:842,t:1526328521647};\\\", \\\"{x:1599,y:837,t:1526328521662};\\\", \\\"{x:1599,y:834,t:1526328521679};\\\", \\\"{x:1598,y:831,t:1526328521696};\\\", \\\"{x:1598,y:828,t:1526328521712};\\\", \\\"{x:1598,y:824,t:1526328521730};\\\", \\\"{x:1596,y:820,t:1526328521746};\\\", \\\"{x:1596,y:816,t:1526328521763};\\\", \\\"{x:1596,y:811,t:1526328521779};\\\", \\\"{x:1596,y:808,t:1526328521796};\\\", \\\"{x:1596,y:802,t:1526328521814};\\\", \\\"{x:1596,y:797,t:1526328521830};\\\", \\\"{x:1596,y:792,t:1526328521847};\\\", \\\"{x:1597,y:787,t:1526328521863};\\\", \\\"{x:1598,y:783,t:1526328521880};\\\", \\\"{x:1598,y:779,t:1526328521896};\\\", \\\"{x:1600,y:774,t:1526328521913};\\\", \\\"{x:1601,y:770,t:1526328521930};\\\", \\\"{x:1601,y:766,t:1526328521947};\\\", \\\"{x:1601,y:763,t:1526328521964};\\\", \\\"{x:1601,y:761,t:1526328521980};\\\", \\\"{x:1603,y:758,t:1526328521996};\\\", \\\"{x:1603,y:755,t:1526328522013};\\\", \\\"{x:1603,y:750,t:1526328522029};\\\", \\\"{x:1604,y:745,t:1526328522047};\\\", \\\"{x:1604,y:740,t:1526328522064};\\\", \\\"{x:1604,y:734,t:1526328522080};\\\", \\\"{x:1604,y:729,t:1526328522096};\\\", \\\"{x:1604,y:722,t:1526328522113};\\\", \\\"{x:1604,y:718,t:1526328522129};\\\", \\\"{x:1604,y:714,t:1526328522147};\\\", \\\"{x:1604,y:711,t:1526328522164};\\\", \\\"{x:1604,y:707,t:1526328522179};\\\", \\\"{x:1604,y:706,t:1526328522196};\\\", \\\"{x:1604,y:704,t:1526328522214};\\\", \\\"{x:1604,y:702,t:1526328522230};\\\", \\\"{x:1604,y:700,t:1526328522247};\\\", \\\"{x:1604,y:698,t:1526328522264};\\\", \\\"{x:1604,y:696,t:1526328522279};\\\", \\\"{x:1604,y:692,t:1526328522297};\\\", \\\"{x:1604,y:689,t:1526328522313};\\\", \\\"{x:1604,y:688,t:1526328522331};\\\", \\\"{x:1604,y:686,t:1526328522347};\\\", \\\"{x:1604,y:683,t:1526328522364};\\\", \\\"{x:1605,y:681,t:1526328522381};\\\", \\\"{x:1605,y:679,t:1526328522396};\\\", \\\"{x:1605,y:676,t:1526328522414};\\\", \\\"{x:1606,y:675,t:1526328522430};\\\", \\\"{x:1606,y:672,t:1526328522447};\\\", \\\"{x:1607,y:669,t:1526328522463};\\\", \\\"{x:1607,y:667,t:1526328522481};\\\", \\\"{x:1607,y:666,t:1526328522496};\\\", \\\"{x:1607,y:662,t:1526328522513};\\\", \\\"{x:1607,y:660,t:1526328522531};\\\", \\\"{x:1607,y:657,t:1526328522547};\\\", \\\"{x:1607,y:654,t:1526328522564};\\\", \\\"{x:1607,y:652,t:1526328522580};\\\", \\\"{x:1607,y:649,t:1526328522597};\\\", \\\"{x:1607,y:646,t:1526328522614};\\\", \\\"{x:1607,y:643,t:1526328522631};\\\", \\\"{x:1607,y:639,t:1526328522647};\\\", \\\"{x:1607,y:636,t:1526328522663};\\\", \\\"{x:1607,y:633,t:1526328522681};\\\", \\\"{x:1607,y:630,t:1526328522697};\\\", \\\"{x:1607,y:627,t:1526328522714};\\\", \\\"{x:1607,y:623,t:1526328522731};\\\", \\\"{x:1607,y:621,t:1526328522747};\\\", \\\"{x:1607,y:616,t:1526328522764};\\\", \\\"{x:1607,y:612,t:1526328522780};\\\", \\\"{x:1607,y:608,t:1526328522796};\\\", \\\"{x:1607,y:600,t:1526328522814};\\\", \\\"{x:1607,y:593,t:1526328522831};\\\", \\\"{x:1608,y:588,t:1526328522848};\\\", \\\"{x:1608,y:584,t:1526328522863};\\\", \\\"{x:1608,y:581,t:1526328522880};\\\", \\\"{x:1609,y:576,t:1526328522897};\\\", \\\"{x:1609,y:574,t:1526328522914};\\\", \\\"{x:1609,y:571,t:1526328522930};\\\", \\\"{x:1609,y:569,t:1526328522948};\\\", \\\"{x:1609,y:566,t:1526328522964};\\\", \\\"{x:1609,y:564,t:1526328522981};\\\", \\\"{x:1609,y:558,t:1526328522998};\\\", \\\"{x:1609,y:554,t:1526328523013};\\\", \\\"{x:1611,y:547,t:1526328523031};\\\", \\\"{x:1611,y:542,t:1526328523048};\\\", \\\"{x:1611,y:538,t:1526328523064};\\\", \\\"{x:1611,y:532,t:1526328523081};\\\", \\\"{x:1612,y:524,t:1526328523098};\\\", \\\"{x:1612,y:520,t:1526328523114};\\\", \\\"{x:1613,y:515,t:1526328523131};\\\", \\\"{x:1614,y:510,t:1526328523147};\\\", \\\"{x:1614,y:506,t:1526328523164};\\\", \\\"{x:1614,y:502,t:1526328523180};\\\", \\\"{x:1614,y:497,t:1526328523197};\\\", \\\"{x:1614,y:493,t:1526328523214};\\\", \\\"{x:1614,y:488,t:1526328523231};\\\", \\\"{x:1614,y:485,t:1526328523248};\\\", \\\"{x:1614,y:481,t:1526328523263};\\\", \\\"{x:1614,y:478,t:1526328523280};\\\", \\\"{x:1614,y:474,t:1526328523298};\\\", \\\"{x:1614,y:473,t:1526328523315};\\\", \\\"{x:1614,y:471,t:1526328523330};\\\", \\\"{x:1614,y:470,t:1526328523347};\\\", \\\"{x:1614,y:468,t:1526328523365};\\\", \\\"{x:1614,y:466,t:1526328523381};\\\", \\\"{x:1614,y:465,t:1526328523398};\\\", \\\"{x:1614,y:464,t:1526328523414};\\\", \\\"{x:1614,y:463,t:1526328523430};\\\", \\\"{x:1614,y:462,t:1526328523450};\\\", \\\"{x:1614,y:463,t:1526328527634};\\\", \\\"{x:1614,y:475,t:1526328527653};\\\", \\\"{x:1612,y:495,t:1526328527668};\\\", \\\"{x:1610,y:513,t:1526328527683};\\\", \\\"{x:1608,y:532,t:1526328527700};\\\", \\\"{x:1607,y:554,t:1526328527719};\\\", \\\"{x:1607,y:574,t:1526328527734};\\\", \\\"{x:1607,y:591,t:1526328527751};\\\", \\\"{x:1607,y:611,t:1526328527767};\\\", \\\"{x:1610,y:637,t:1526328527784};\\\", \\\"{x:1612,y:692,t:1526328527801};\\\", \\\"{x:1612,y:830,t:1526328527817};\\\", \\\"{x:1612,y:911,t:1526328527833};\\\", \\\"{x:1612,y:989,t:1526328527851};\\\", \\\"{x:1621,y:1072,t:1526328527868};\\\", \\\"{x:1632,y:1155,t:1526328527883};\\\", \\\"{x:1632,y:1199,t:1526328527900};\\\", \\\"{x:1635,y:1199,t:1526328527918};\\\", \\\"{x:1636,y:1199,t:1526328527961};\\\", \\\"{x:1637,y:1199,t:1526328527977};\\\", \\\"{x:1639,y:1199,t:1526328527985};\\\", \\\"{x:1645,y:1199,t:1526328528001};\\\", \\\"{x:1650,y:1199,t:1526328528019};\\\", \\\"{x:1653,y:1199,t:1526328528034};\\\", \\\"{x:1638,y:1199,t:1526328541324};\\\", \\\"{x:1587,y:1199,t:1526328541338};\\\", \\\"{x:1553,y:1199,t:1526328541354};\\\", \\\"{x:1544,y:1199,t:1526328541367};\\\", \\\"{x:1541,y:1199,t:1526328541385};\\\", \\\"{x:1540,y:1199,t:1526328541402};\\\", \\\"{x:1538,y:1199,t:1526328541417};\\\", \\\"{x:1537,y:1199,t:1526328541434};\\\", \\\"{x:1533,y:1199,t:1526328541451};\\\", \\\"{x:1530,y:1199,t:1526328541467};\\\", \\\"{x:1528,y:1199,t:1526328541484};\\\", \\\"{x:1527,y:1197,t:1526328541537};\\\", \\\"{x:1527,y:1190,t:1526328541552};\\\", \\\"{x:1533,y:1169,t:1526328541569};\\\", \\\"{x:1534,y:1139,t:1526328541584};\\\", \\\"{x:1534,y:1123,t:1526328541596};\\\", \\\"{x:1534,y:1124,t:1526328542738};\\\", \\\"{x:1540,y:1132,t:1526328542754};\\\", \\\"{x:1542,y:1134,t:1526328542765};\\\", \\\"{x:1543,y:1141,t:1526328542780};\\\", \\\"{x:1548,y:1150,t:1526328542797};\\\", \\\"{x:1553,y:1159,t:1526328542814};\\\", \\\"{x:1556,y:1166,t:1526328542830};\\\", \\\"{x:1559,y:1175,t:1526328542847};\\\", \\\"{x:1560,y:1180,t:1526328542864};\\\", \\\"{x:1562,y:1184,t:1526328542880};\\\", \\\"{x:1562,y:1191,t:1526328542897};\\\", \\\"{x:1564,y:1193,t:1526328542914};\\\", \\\"{x:1564,y:1194,t:1526328542930};\\\", \\\"{x:1564,y:1196,t:1526328543073};\\\", \\\"{x:1568,y:1193,t:1526328543658};\\\", \\\"{x:1571,y:1185,t:1526328543665};\\\", \\\"{x:1587,y:1160,t:1526328543682};\\\", \\\"{x:1604,y:1134,t:1526328543698};\\\", \\\"{x:1613,y:1124,t:1526328543714};\\\", \\\"{x:1615,y:1120,t:1526328543731};\\\", \\\"{x:1618,y:1112,t:1526328543748};\\\", \\\"{x:1623,y:1104,t:1526328543765};\\\", \\\"{x:1625,y:1098,t:1526328543781};\\\", \\\"{x:1627,y:1095,t:1526328543798};\\\", \\\"{x:1627,y:1093,t:1526328543814};\\\", \\\"{x:1627,y:1089,t:1526328543831};\\\", \\\"{x:1629,y:1083,t:1526328543848};\\\", \\\"{x:1629,y:1077,t:1526328543865};\\\", \\\"{x:1629,y:1068,t:1526328543881};\\\", \\\"{x:1629,y:1062,t:1526328543898};\\\", \\\"{x:1629,y:1060,t:1526328543916};\\\", \\\"{x:1629,y:1057,t:1526328543931};\\\", \\\"{x:1629,y:1051,t:1526328543948};\\\", \\\"{x:1629,y:1046,t:1526328543965};\\\", \\\"{x:1628,y:1037,t:1526328543981};\\\", \\\"{x:1625,y:1031,t:1526328543999};\\\", \\\"{x:1624,y:1027,t:1526328544016};\\\", \\\"{x:1621,y:1022,t:1526328544031};\\\", \\\"{x:1621,y:1019,t:1526328544048};\\\", \\\"{x:1621,y:1016,t:1526328544066};\\\", \\\"{x:1621,y:1013,t:1526328544082};\\\", \\\"{x:1621,y:1008,t:1526328544099};\\\", \\\"{x:1620,y:1006,t:1526328544116};\\\", \\\"{x:1620,y:1005,t:1526328544131};\\\", \\\"{x:1619,y:1004,t:1526328544149};\\\", \\\"{x:1619,y:1002,t:1526328544166};\\\", \\\"{x:1618,y:1000,t:1526328544182};\\\", \\\"{x:1618,y:997,t:1526328544199};\\\", \\\"{x:1617,y:993,t:1526328544216};\\\", \\\"{x:1615,y:990,t:1526328544232};\\\", \\\"{x:1614,y:985,t:1526328544249};\\\", \\\"{x:1610,y:977,t:1526328544267};\\\", \\\"{x:1610,y:974,t:1526328544282};\\\", \\\"{x:1610,y:969,t:1526328544299};\\\", \\\"{x:1609,y:966,t:1526328544315};\\\", \\\"{x:1609,y:964,t:1526328544332};\\\", \\\"{x:1608,y:962,t:1526328544349};\\\", \\\"{x:1608,y:959,t:1526328544365};\\\", \\\"{x:1606,y:957,t:1526328544382};\\\", \\\"{x:1606,y:955,t:1526328544399};\\\", \\\"{x:1606,y:954,t:1526328544416};\\\", \\\"{x:1606,y:952,t:1526328544433};\\\", \\\"{x:1606,y:951,t:1526328544448};\\\", \\\"{x:1605,y:950,t:1526328544466};\\\", \\\"{x:1605,y:949,t:1526328544482};\\\", \\\"{x:1607,y:949,t:1526328544786};\\\", \\\"{x:1609,y:950,t:1526328544802};\\\", \\\"{x:1610,y:951,t:1526328544817};\\\", \\\"{x:1613,y:954,t:1526328544833};\\\", \\\"{x:1615,y:955,t:1526328544849};\\\", \\\"{x:1618,y:956,t:1526328544866};\\\", \\\"{x:1618,y:957,t:1526328544883};\\\", \\\"{x:1619,y:957,t:1526328544899};\\\", \\\"{x:1620,y:959,t:1526328544916};\\\", \\\"{x:1621,y:960,t:1526328544946};\\\", \\\"{x:1621,y:961,t:1526328545002};\\\", \\\"{x:1622,y:961,t:1526328545033};\\\", \\\"{x:1622,y:962,t:1526328545882};\\\", \\\"{x:1622,y:963,t:1526328545890};\\\", \\\"{x:1622,y:967,t:1526328545906};\\\", \\\"{x:1622,y:968,t:1526328545917};\\\", \\\"{x:1622,y:970,t:1526328545933};\\\", \\\"{x:1621,y:973,t:1526328545951};\\\", \\\"{x:1621,y:975,t:1526328545967};\\\", \\\"{x:1621,y:977,t:1526328545983};\\\", \\\"{x:1621,y:978,t:1526328546026};\\\", \\\"{x:1620,y:978,t:1526328546411};\\\", \\\"{x:1619,y:976,t:1526328546450};\\\", \\\"{x:1616,y:971,t:1526328556090};\\\", \\\"{x:1616,y:968,t:1526328556108};\\\", \\\"{x:1616,y:966,t:1526328556124};\\\", \\\"{x:1615,y:965,t:1526328556142};\\\", \\\"{x:1615,y:964,t:1526328556169};\\\", \\\"{x:1615,y:963,t:1526328556185};\\\", \\\"{x:1615,y:962,t:1526328556241};\\\", \\\"{x:1611,y:959,t:1526328561137};\\\", \\\"{x:1598,y:954,t:1526328561151};\\\", \\\"{x:1555,y:941,t:1526328561167};\\\", \\\"{x:1466,y:918,t:1526328561180};\\\", \\\"{x:1368,y:898,t:1526328561196};\\\", \\\"{x:1263,y:870,t:1526328561213};\\\", \\\"{x:1158,y:840,t:1526328561229};\\\", \\\"{x:1069,y:817,t:1526328561246};\\\", \\\"{x:1017,y:802,t:1526328561262};\\\", \\\"{x:997,y:797,t:1526328561279};\\\", \\\"{x:991,y:793,t:1526328561296};\\\", \\\"{x:990,y:793,t:1526328561354};\\\", \\\"{x:990,y:792,t:1526328561362};\\\", \\\"{x:989,y:789,t:1526328561379};\\\", \\\"{x:988,y:782,t:1526328561396};\\\", \\\"{x:986,y:772,t:1526328561412};\\\", \\\"{x:985,y:761,t:1526328561429};\\\", \\\"{x:979,y:741,t:1526328561447};\\\", \\\"{x:974,y:727,t:1526328561462};\\\", \\\"{x:964,y:707,t:1526328561479};\\\", \\\"{x:956,y:687,t:1526328561496};\\\", \\\"{x:948,y:670,t:1526328561512};\\\", \\\"{x:938,y:644,t:1526328561530};\\\", \\\"{x:933,y:627,t:1526328561547};\\\", \\\"{x:927,y:611,t:1526328561564};\\\", \\\"{x:921,y:599,t:1526328561579};\\\", \\\"{x:914,y:588,t:1526328561595};\\\", \\\"{x:906,y:577,t:1526328561612};\\\", \\\"{x:898,y:564,t:1526328561629};\\\", \\\"{x:892,y:554,t:1526328561645};\\\", \\\"{x:886,y:542,t:1526328561663};\\\", \\\"{x:881,y:534,t:1526328561679};\\\", \\\"{x:877,y:528,t:1526328561695};\\\", \\\"{x:870,y:520,t:1526328561712};\\\", \\\"{x:867,y:517,t:1526328561729};\\\", \\\"{x:866,y:516,t:1526328561746};\\\", \\\"{x:865,y:516,t:1526328561841};\\\", \\\"{x:863,y:516,t:1526328561873};\\\", \\\"{x:862,y:516,t:1526328561889};\\\", \\\"{x:861,y:517,t:1526328561897};\\\", \\\"{x:857,y:519,t:1526328561913};\\\", \\\"{x:850,y:523,t:1526328561929};\\\", \\\"{x:845,y:525,t:1526328561946};\\\", \\\"{x:843,y:526,t:1526328561964};\\\", \\\"{x:843,y:527,t:1526328562457};\\\", \\\"{x:843,y:528,t:1526328562465};\\\", \\\"{x:847,y:535,t:1526328562481};\\\", \\\"{x:853,y:542,t:1526328562497};\\\", \\\"{x:862,y:552,t:1526328562513};\\\", \\\"{x:874,y:564,t:1526328562530};\\\", \\\"{x:885,y:578,t:1526328562547};\\\", \\\"{x:901,y:590,t:1526328562564};\\\", \\\"{x:916,y:602,t:1526328562580};\\\", \\\"{x:927,y:612,t:1526328562596};\\\", \\\"{x:941,y:625,t:1526328562613};\\\", \\\"{x:953,y:635,t:1526328562631};\\\", \\\"{x:966,y:644,t:1526328562647};\\\", \\\"{x:980,y:650,t:1526328562663};\\\", \\\"{x:999,y:659,t:1526328562681};\\\", \\\"{x:1038,y:677,t:1526328562696};\\\", \\\"{x:1072,y:691,t:1526328562713};\\\", \\\"{x:1102,y:704,t:1526328562731};\\\", \\\"{x:1141,y:715,t:1526328562748};\\\", \\\"{x:1186,y:729,t:1526328562764};\\\", \\\"{x:1216,y:737,t:1526328562780};\\\", \\\"{x:1241,y:743,t:1526328562798};\\\", \\\"{x:1262,y:749,t:1526328562814};\\\", \\\"{x:1278,y:754,t:1526328562831};\\\", \\\"{x:1288,y:758,t:1526328562848};\\\", \\\"{x:1307,y:765,t:1526328562864};\\\", \\\"{x:1325,y:775,t:1526328562881};\\\", \\\"{x:1339,y:786,t:1526328562898};\\\", \\\"{x:1355,y:797,t:1526328562915};\\\", \\\"{x:1383,y:816,t:1526328562931};\\\", \\\"{x:1412,y:837,t:1526328562948};\\\", \\\"{x:1442,y:863,t:1526328562964};\\\", \\\"{x:1462,y:881,t:1526328562981};\\\", \\\"{x:1481,y:895,t:1526328562998};\\\", \\\"{x:1495,y:908,t:1526328563014};\\\", \\\"{x:1508,y:919,t:1526328563030};\\\", \\\"{x:1516,y:927,t:1526328563047};\\\", \\\"{x:1519,y:931,t:1526328563065};\\\", \\\"{x:1520,y:932,t:1526328563081};\\\", \\\"{x:1522,y:934,t:1526328563098};\\\", \\\"{x:1523,y:936,t:1526328563114};\\\", \\\"{x:1525,y:939,t:1526328563131};\\\", \\\"{x:1526,y:941,t:1526328563147};\\\", \\\"{x:1526,y:942,t:1526328563177};\\\", \\\"{x:1528,y:945,t:1526328563193};\\\", \\\"{x:1530,y:948,t:1526328563202};\\\", \\\"{x:1532,y:950,t:1526328563214};\\\", \\\"{x:1539,y:961,t:1526328563232};\\\", \\\"{x:1549,y:978,t:1526328563248};\\\", \\\"{x:1557,y:996,t:1526328563265};\\\", \\\"{x:1562,y:1003,t:1526328563282};\\\", \\\"{x:1564,y:1007,t:1526328563297};\\\", \\\"{x:1565,y:1009,t:1526328563314};\\\", \\\"{x:1566,y:1010,t:1526328563332};\\\", \\\"{x:1566,y:1008,t:1526328563523};\\\", \\\"{x:1566,y:1002,t:1526328563538};\\\", \\\"{x:1566,y:998,t:1526328563548};\\\", \\\"{x:1566,y:992,t:1526328563565};\\\", \\\"{x:1567,y:986,t:1526328563582};\\\", \\\"{x:1572,y:981,t:1526328563599};\\\", \\\"{x:1574,y:979,t:1526328563616};\\\", \\\"{x:1575,y:978,t:1526328563632};\\\", \\\"{x:1576,y:978,t:1526328563681};\\\", \\\"{x:1576,y:977,t:1526328563698};\\\", \\\"{x:1578,y:977,t:1526328563715};\\\", \\\"{x:1581,y:975,t:1526328563732};\\\", \\\"{x:1585,y:974,t:1526328563749};\\\", \\\"{x:1589,y:972,t:1526328563765};\\\", \\\"{x:1590,y:971,t:1526328563781};\\\", \\\"{x:1591,y:971,t:1526328563799};\\\", \\\"{x:1592,y:971,t:1526328563816};\\\", \\\"{x:1593,y:971,t:1526328563832};\\\", \\\"{x:1594,y:970,t:1526328563849};\\\", \\\"{x:1595,y:970,t:1526328563866};\\\", \\\"{x:1596,y:969,t:1526328563923};\\\", \\\"{x:1597,y:968,t:1526328563985};\\\", \\\"{x:1600,y:967,t:1526328564001};\\\", \\\"{x:1602,y:967,t:1526328564018};\\\", \\\"{x:1603,y:966,t:1526328564033};\\\", \\\"{x:1604,y:965,t:1526328564098};\\\", \\\"{x:1605,y:965,t:1526328564121};\\\", \\\"{x:1598,y:962,t:1526328568254};\\\", \\\"{x:1579,y:960,t:1526328568261};\\\", \\\"{x:1507,y:943,t:1526328568277};\\\", \\\"{x:1459,y:940,t:1526328568291};\\\", \\\"{x:1277,y:909,t:1526328568309};\\\", \\\"{x:1125,y:887,t:1526328568324};\\\", \\\"{x:954,y:865,t:1526328568341};\\\", \\\"{x:811,y:852,t:1526328568358};\\\", \\\"{x:671,y:841,t:1526328568374};\\\", \\\"{x:527,y:824,t:1526328568391};\\\", \\\"{x:409,y:814,t:1526328568408};\\\", \\\"{x:307,y:800,t:1526328568424};\\\", \\\"{x:215,y:784,t:1526328568441};\\\", \\\"{x:140,y:776,t:1526328568458};\\\", \\\"{x:108,y:771,t:1526328568474};\\\", \\\"{x:89,y:765,t:1526328568491};\\\", \\\"{x:78,y:759,t:1526328568507};\\\", \\\"{x:75,y:756,t:1526328568525};\\\", \\\"{x:70,y:754,t:1526328568541};\\\", \\\"{x:66,y:750,t:1526328568557};\\\", \\\"{x:58,y:744,t:1526328568575};\\\", \\\"{x:56,y:739,t:1526328568591};\\\", \\\"{x:56,y:733,t:1526328568608};\\\", \\\"{x:65,y:725,t:1526328568625};\\\", \\\"{x:78,y:719,t:1526328568641};\\\", \\\"{x:95,y:715,t:1526328568657};\\\", \\\"{x:117,y:709,t:1526328568675};\\\", \\\"{x:157,y:704,t:1526328568691};\\\", \\\"{x:216,y:703,t:1526328568708};\\\", \\\"{x:250,y:702,t:1526328568725};\\\", \\\"{x:291,y:699,t:1526328568741};\\\", \\\"{x:325,y:696,t:1526328568758};\\\", \\\"{x:358,y:695,t:1526328568775};\\\", \\\"{x:383,y:692,t:1526328568792};\\\", \\\"{x:402,y:692,t:1526328568808};\\\", \\\"{x:412,y:692,t:1526328568825};\\\", \\\"{x:417,y:691,t:1526328568842};\\\", \\\"{x:419,y:691,t:1526328568909};\\\", \\\"{x:423,y:690,t:1526328568930};\\\", \\\"{x:432,y:690,t:1526328568941};\\\", \\\"{x:440,y:690,t:1526328568958};\\\", \\\"{x:446,y:690,t:1526328568974};\\\", \\\"{x:449,y:690,t:1526328568992};\\\", \\\"{x:450,y:690,t:1526328569009};\\\", \\\"{x:453,y:692,t:1526328569025};\\\", \\\"{x:456,y:695,t:1526328569042};\\\", \\\"{x:458,y:696,t:1526328569058};\\\", \\\"{x:461,y:699,t:1526328569074};\\\", \\\"{x:466,y:702,t:1526328569092};\\\", \\\"{x:470,y:705,t:1526328569108};\\\", \\\"{x:475,y:708,t:1526328569125};\\\", \\\"{x:480,y:711,t:1526328569139};\\\", \\\"{x:489,y:716,t:1526328569156};\\\", \\\"{x:495,y:720,t:1526328569171};\\\", \\\"{x:496,y:721,t:1526328569189};\\\" ] }, { \\\"rt\\\": 75085, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 499680, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-03 PM-H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:722,t:1526328571645};\\\", \\\"{x:497,y:727,t:1526328571664};\\\", \\\"{x:498,y:733,t:1526328571676};\\\", \\\"{x:499,y:735,t:1526328571690};\\\", \\\"{x:502,y:741,t:1526328571707};\\\", \\\"{x:504,y:745,t:1526328571725};\\\", \\\"{x:506,y:748,t:1526328571740};\\\", \\\"{x:507,y:750,t:1526328571758};\\\", \\\"{x:508,y:752,t:1526328571775};\\\", \\\"{x:509,y:753,t:1526328571791};\\\", \\\"{x:509,y:754,t:1526328571808};\\\", \\\"{x:510,y:754,t:1526328572973};\\\", \\\"{x:507,y:754,t:1526328572988};\\\", \\\"{x:504,y:756,t:1526328572996};\\\", \\\"{x:501,y:756,t:1526328573009};\\\", \\\"{x:498,y:758,t:1526328573026};\\\", \\\"{x:498,y:759,t:1526328573043};\\\", \\\"{x:497,y:759,t:1526328573059};\\\", \\\"{x:496,y:759,t:1526328573645};\\\", \\\"{x:492,y:759,t:1526328573661};\\\", \\\"{x:486,y:759,t:1526328573676};\\\", \\\"{x:483,y:759,t:1526328573693};\\\", \\\"{x:478,y:760,t:1526328573710};\\\", \\\"{x:476,y:760,t:1526328573727};\\\", \\\"{x:470,y:762,t:1526328573743};\\\", \\\"{x:466,y:762,t:1526328573759};\\\", \\\"{x:459,y:762,t:1526328573776};\\\", \\\"{x:450,y:764,t:1526328573793};\\\", \\\"{x:442,y:764,t:1526328573809};\\\", \\\"{x:434,y:766,t:1526328573827};\\\", \\\"{x:426,y:767,t:1526328573844};\\\", \\\"{x:419,y:767,t:1526328573860};\\\", \\\"{x:413,y:768,t:1526328573877};\\\", \\\"{x:409,y:770,t:1526328573892};\\\", \\\"{x:407,y:770,t:1526328573909};\\\", \\\"{x:406,y:771,t:1526328574405};\\\", \\\"{x:405,y:771,t:1526328574412};\\\", \\\"{x:404,y:771,t:1526328574429};\\\", \\\"{x:402,y:773,t:1526328574461};\\\", \\\"{x:401,y:773,t:1526328574477};\\\", \\\"{x:399,y:774,t:1526328574494};\\\", \\\"{x:398,y:775,t:1526328574510};\\\", \\\"{x:397,y:776,t:1526328574527};\\\", \\\"{x:396,y:777,t:1526328574544};\\\", \\\"{x:394,y:778,t:1526328574560};\\\", \\\"{x:392,y:780,t:1526328576109};\\\", \\\"{x:390,y:781,t:1526328576116};\\\", \\\"{x:389,y:782,t:1526328576128};\\\", \\\"{x:387,y:782,t:1526328576144};\\\", \\\"{x:386,y:783,t:1526328576162};\\\", \\\"{x:385,y:784,t:1526328576178};\\\", \\\"{x:384,y:785,t:1526328576194};\\\", \\\"{x:381,y:785,t:1526328576211};\\\", \\\"{x:381,y:786,t:1526328576244};\\\", \\\"{x:380,y:786,t:1526328576277};\\\", \\\"{x:379,y:787,t:1526328576325};\\\", \\\"{x:381,y:787,t:1526328578588};\\\", \\\"{x:391,y:787,t:1526328578597};\\\", \\\"{x:410,y:787,t:1526328578613};\\\", \\\"{x:422,y:787,t:1526328578631};\\\", \\\"{x:437,y:787,t:1526328578646};\\\", \\\"{x:455,y:787,t:1526328578663};\\\", \\\"{x:477,y:787,t:1526328578681};\\\", \\\"{x:515,y:777,t:1526328578696};\\\", \\\"{x:554,y:767,t:1526328578713};\\\", \\\"{x:596,y:754,t:1526328578731};\\\", \\\"{x:643,y:742,t:1526328578746};\\\", \\\"{x:689,y:733,t:1526328578763};\\\", \\\"{x:765,y:724,t:1526328578780};\\\", \\\"{x:821,y:716,t:1526328578797};\\\", \\\"{x:892,y:702,t:1526328578813};\\\", \\\"{x:952,y:690,t:1526328578830};\\\", \\\"{x:1005,y:680,t:1526328578847};\\\", \\\"{x:1047,y:670,t:1526328578864};\\\", \\\"{x:1079,y:667,t:1526328578880};\\\", \\\"{x:1116,y:662,t:1526328578898};\\\", \\\"{x:1145,y:655,t:1526328578913};\\\", \\\"{x:1173,y:649,t:1526328578931};\\\", \\\"{x:1202,y:643,t:1526328578946};\\\", \\\"{x:1234,y:633,t:1526328578964};\\\", \\\"{x:1269,y:621,t:1526328578980};\\\", \\\"{x:1290,y:615,t:1526328578998};\\\", \\\"{x:1303,y:611,t:1526328579014};\\\", \\\"{x:1312,y:609,t:1526328579031};\\\", \\\"{x:1318,y:607,t:1526328579047};\\\", \\\"{x:1321,y:607,t:1526328579063};\\\", \\\"{x:1323,y:606,t:1526328579080};\\\", \\\"{x:1323,y:605,t:1526328579123};\\\", \\\"{x:1323,y:603,t:1526328579132};\\\", \\\"{x:1324,y:601,t:1526328579147};\\\", \\\"{x:1324,y:600,t:1526328579164};\\\", \\\"{x:1325,y:595,t:1526328579180};\\\", \\\"{x:1325,y:588,t:1526328579197};\\\", \\\"{x:1320,y:582,t:1526328579213};\\\", \\\"{x:1313,y:574,t:1526328579231};\\\", \\\"{x:1308,y:570,t:1526328579248};\\\", \\\"{x:1305,y:567,t:1526328579263};\\\", \\\"{x:1301,y:564,t:1526328579280};\\\", \\\"{x:1298,y:563,t:1526328579298};\\\", \\\"{x:1297,y:562,t:1526328579357};\\\", \\\"{x:1296,y:562,t:1526328579388};\\\", \\\"{x:1296,y:561,t:1526328579398};\\\", \\\"{x:1295,y:561,t:1526328579413};\\\", \\\"{x:1295,y:560,t:1526328579431};\\\", \\\"{x:1295,y:559,t:1526328579447};\\\", \\\"{x:1295,y:557,t:1526328579463};\\\", \\\"{x:1295,y:555,t:1526328579481};\\\", \\\"{x:1295,y:554,t:1526328579497};\\\", \\\"{x:1295,y:551,t:1526328579513};\\\", \\\"{x:1295,y:549,t:1526328579530};\\\", \\\"{x:1295,y:545,t:1526328579547};\\\", \\\"{x:1295,y:542,t:1526328579563};\\\", \\\"{x:1296,y:541,t:1526328579580};\\\", \\\"{x:1296,y:540,t:1526328579597};\\\", \\\"{x:1299,y:537,t:1526328579614};\\\", \\\"{x:1301,y:534,t:1526328579631};\\\", \\\"{x:1302,y:533,t:1526328579652};\\\", \\\"{x:1303,y:533,t:1526328579664};\\\", \\\"{x:1304,y:531,t:1526328579680};\\\", \\\"{x:1305,y:530,t:1526328579700};\\\", \\\"{x:1306,y:530,t:1526328579716};\\\", \\\"{x:1306,y:529,t:1526328579732};\\\", \\\"{x:1306,y:528,t:1526328579748};\\\", \\\"{x:1307,y:527,t:1526328579765};\\\", \\\"{x:1308,y:525,t:1526328579796};\\\", \\\"{x:1309,y:525,t:1526328579828};\\\", \\\"{x:1309,y:524,t:1526328579877};\\\", \\\"{x:1308,y:523,t:1526328579908};\\\", \\\"{x:1308,y:522,t:1526328579916};\\\", \\\"{x:1307,y:522,t:1526328579932};\\\", \\\"{x:1305,y:520,t:1526328579949};\\\", \\\"{x:1304,y:519,t:1526328579973};\\\", \\\"{x:1303,y:519,t:1526328579988};\\\", \\\"{x:1302,y:519,t:1526328579999};\\\", \\\"{x:1300,y:516,t:1526328580014};\\\", \\\"{x:1298,y:516,t:1526328580036};\\\", \\\"{x:1297,y:515,t:1526328580049};\\\", \\\"{x:1296,y:514,t:1526328580132};\\\", \\\"{x:1296,y:513,t:1526328580396};\\\", \\\"{x:1297,y:513,t:1526328580404};\\\", \\\"{x:1299,y:512,t:1526328580416};\\\", \\\"{x:1300,y:510,t:1526328580432};\\\", \\\"{x:1302,y:510,t:1526328580448};\\\", \\\"{x:1304,y:509,t:1526328580465};\\\", \\\"{x:1305,y:508,t:1526328580484};\\\", \\\"{x:1306,y:508,t:1526328580549};\\\", \\\"{x:1307,y:507,t:1526328580572};\\\", \\\"{x:1308,y:506,t:1526328580668};\\\", \\\"{x:1309,y:506,t:1526328580708};\\\", \\\"{x:1310,y:506,t:1526328580715};\\\", \\\"{x:1311,y:506,t:1526328580923};\\\", \\\"{x:1310,y:506,t:1526328584437};\\\", \\\"{x:1308,y:506,t:1526328584452};\\\", \\\"{x:1307,y:508,t:1526328584468};\\\", \\\"{x:1304,y:512,t:1526328584485};\\\", \\\"{x:1304,y:515,t:1526328584501};\\\", \\\"{x:1303,y:518,t:1526328584518};\\\", \\\"{x:1302,y:520,t:1526328584535};\\\", \\\"{x:1301,y:522,t:1526328584551};\\\", \\\"{x:1301,y:524,t:1526328584567};\\\", \\\"{x:1301,y:529,t:1526328584585};\\\", \\\"{x:1301,y:535,t:1526328584602};\\\", \\\"{x:1301,y:545,t:1526328584617};\\\", \\\"{x:1301,y:560,t:1526328584634};\\\", \\\"{x:1308,y:585,t:1526328584651};\\\", \\\"{x:1314,y:600,t:1526328584668};\\\", \\\"{x:1319,y:612,t:1526328584685};\\\", \\\"{x:1323,y:625,t:1526328584702};\\\", \\\"{x:1328,y:637,t:1526328584718};\\\", \\\"{x:1334,y:648,t:1526328584735};\\\", \\\"{x:1336,y:659,t:1526328584752};\\\", \\\"{x:1338,y:670,t:1526328584768};\\\", \\\"{x:1342,y:681,t:1526328584785};\\\", \\\"{x:1345,y:690,t:1526328584803};\\\", \\\"{x:1345,y:698,t:1526328584819};\\\", \\\"{x:1345,y:704,t:1526328584835};\\\", \\\"{x:1345,y:713,t:1526328584852};\\\", \\\"{x:1345,y:723,t:1526328584868};\\\", \\\"{x:1345,y:735,t:1526328584885};\\\", \\\"{x:1345,y:749,t:1526328584903};\\\", \\\"{x:1345,y:759,t:1526328584918};\\\", \\\"{x:1344,y:768,t:1526328584936};\\\", \\\"{x:1341,y:778,t:1526328584953};\\\", \\\"{x:1339,y:787,t:1526328584969};\\\", \\\"{x:1336,y:795,t:1526328584985};\\\", \\\"{x:1334,y:804,t:1526328585002};\\\", \\\"{x:1332,y:813,t:1526328585019};\\\", \\\"{x:1330,y:819,t:1526328585035};\\\", \\\"{x:1328,y:826,t:1526328585052};\\\", \\\"{x:1328,y:833,t:1526328585068};\\\", \\\"{x:1328,y:843,t:1526328585085};\\\", \\\"{x:1328,y:855,t:1526328585102};\\\", \\\"{x:1327,y:866,t:1526328585120};\\\", \\\"{x:1327,y:879,t:1526328585135};\\\", \\\"{x:1327,y:891,t:1526328585152};\\\", \\\"{x:1326,y:908,t:1526328585170};\\\", \\\"{x:1326,y:924,t:1526328585186};\\\", \\\"{x:1326,y:941,t:1526328585203};\\\", \\\"{x:1326,y:956,t:1526328585219};\\\", \\\"{x:1326,y:964,t:1526328585236};\\\", \\\"{x:1324,y:973,t:1526328585253};\\\", \\\"{x:1323,y:976,t:1526328585269};\\\", \\\"{x:1322,y:980,t:1526328585285};\\\", \\\"{x:1320,y:983,t:1526328585302};\\\", \\\"{x:1320,y:985,t:1526328585319};\\\", \\\"{x:1320,y:986,t:1526328585336};\\\", \\\"{x:1319,y:986,t:1526328585352};\\\", \\\"{x:1318,y:984,t:1526328586533};\\\", \\\"{x:1316,y:975,t:1526328586542};\\\", \\\"{x:1313,y:956,t:1526328586557};\\\", \\\"{x:1311,y:943,t:1526328586570};\\\", \\\"{x:1307,y:917,t:1526328586586};\\\", \\\"{x:1304,y:877,t:1526328586603};\\\", \\\"{x:1304,y:820,t:1526328586620};\\\", \\\"{x:1321,y:754,t:1526328586637};\\\", \\\"{x:1352,y:670,t:1526328586654};\\\", \\\"{x:1391,y:586,t:1526328586671};\\\", \\\"{x:1427,y:504,t:1526328586687};\\\", \\\"{x:1455,y:455,t:1526328586703};\\\", \\\"{x:1472,y:435,t:1526328586720};\\\", \\\"{x:1484,y:422,t:1526328586737};\\\", \\\"{x:1488,y:414,t:1526328586753};\\\", \\\"{x:1497,y:405,t:1526328586770};\\\", \\\"{x:1521,y:391,t:1526328586788};\\\", \\\"{x:1531,y:387,t:1526328586803};\\\", \\\"{x:1555,y:377,t:1526328586821};\\\", \\\"{x:1568,y:373,t:1526328586837};\\\", \\\"{x:1581,y:370,t:1526328586853};\\\", \\\"{x:1594,y:369,t:1526328586870};\\\", \\\"{x:1609,y:369,t:1526328586887};\\\", \\\"{x:1624,y:369,t:1526328586903};\\\", \\\"{x:1639,y:376,t:1526328586920};\\\", \\\"{x:1652,y:381,t:1526328586937};\\\", \\\"{x:1665,y:388,t:1526328586954};\\\", \\\"{x:1682,y:399,t:1526328586970};\\\", \\\"{x:1698,y:410,t:1526328586987};\\\", \\\"{x:1709,y:420,t:1526328587004};\\\", \\\"{x:1713,y:427,t:1526328587020};\\\", \\\"{x:1714,y:434,t:1526328587038};\\\", \\\"{x:1714,y:439,t:1526328587054};\\\", \\\"{x:1714,y:443,t:1526328587069};\\\", \\\"{x:1714,y:445,t:1526328587086};\\\", \\\"{x:1712,y:447,t:1526328587104};\\\", \\\"{x:1710,y:451,t:1526328587120};\\\", \\\"{x:1704,y:457,t:1526328587137};\\\", \\\"{x:1701,y:460,t:1526328587154};\\\", \\\"{x:1697,y:464,t:1526328587170};\\\", \\\"{x:1691,y:468,t:1526328587187};\\\", \\\"{x:1684,y:473,t:1526328587203};\\\", \\\"{x:1680,y:477,t:1526328587220};\\\", \\\"{x:1677,y:480,t:1526328587237};\\\", \\\"{x:1669,y:486,t:1526328587253};\\\", \\\"{x:1661,y:490,t:1526328587269};\\\", \\\"{x:1658,y:494,t:1526328587288};\\\", \\\"{x:1656,y:495,t:1526328587304};\\\", \\\"{x:1656,y:496,t:1526328587324};\\\", \\\"{x:1655,y:497,t:1526328587373};\\\", \\\"{x:1654,y:497,t:1526328587852};\\\", \\\"{x:1653,y:498,t:1526328587861};\\\", \\\"{x:1653,y:499,t:1526328587996};\\\", \\\"{x:1651,y:500,t:1526328588742};\\\", \\\"{x:1645,y:510,t:1526328588756};\\\", \\\"{x:1635,y:525,t:1526328588772};\\\", \\\"{x:1624,y:538,t:1526328588788};\\\", \\\"{x:1611,y:553,t:1526328588806};\\\", \\\"{x:1592,y:570,t:1526328588822};\\\", \\\"{x:1570,y:587,t:1526328588838};\\\", \\\"{x:1542,y:607,t:1526328588855};\\\", \\\"{x:1509,y:622,t:1526328588872};\\\", \\\"{x:1483,y:634,t:1526328588889};\\\", \\\"{x:1462,y:643,t:1526328588905};\\\", \\\"{x:1449,y:647,t:1526328588922};\\\", \\\"{x:1435,y:648,t:1526328588939};\\\", \\\"{x:1418,y:651,t:1526328588955};\\\", \\\"{x:1399,y:652,t:1526328588972};\\\", \\\"{x:1385,y:652,t:1526328588988};\\\", \\\"{x:1368,y:647,t:1526328589005};\\\", \\\"{x:1345,y:640,t:1526328589022};\\\", \\\"{x:1328,y:634,t:1526328589039};\\\", \\\"{x:1315,y:630,t:1526328589055};\\\", \\\"{x:1308,y:625,t:1526328589072};\\\", \\\"{x:1295,y:618,t:1526328589089};\\\", \\\"{x:1281,y:610,t:1526328589105};\\\", \\\"{x:1267,y:603,t:1526328589122};\\\", \\\"{x:1254,y:596,t:1526328589140};\\\", \\\"{x:1252,y:595,t:1526328589156};\\\", \\\"{x:1249,y:592,t:1526328589172};\\\", \\\"{x:1249,y:591,t:1526328589188};\\\", \\\"{x:1249,y:584,t:1526328589205};\\\", \\\"{x:1253,y:571,t:1526328589222};\\\", \\\"{x:1267,y:557,t:1526328589239};\\\", \\\"{x:1279,y:546,t:1526328589255};\\\", \\\"{x:1290,y:538,t:1526328589273};\\\", \\\"{x:1301,y:531,t:1526328589289};\\\", \\\"{x:1312,y:523,t:1526328589305};\\\", \\\"{x:1319,y:519,t:1526328589322};\\\", \\\"{x:1323,y:516,t:1526328589340};\\\", \\\"{x:1325,y:514,t:1526328589357};\\\", \\\"{x:1325,y:513,t:1526328589932};\\\", \\\"{x:1325,y:512,t:1526328589950};\\\", \\\"{x:1325,y:511,t:1526328589964};\\\", \\\"{x:1325,y:510,t:1526328589980};\\\", \\\"{x:1325,y:509,t:1526328590820};\\\", \\\"{x:1325,y:508,t:1526328590835};\\\", \\\"{x:1325,y:507,t:1526328590860};\\\", \\\"{x:1325,y:506,t:1526328590892};\\\", \\\"{x:1325,y:513,t:1526328598244};\\\", \\\"{x:1343,y:570,t:1526328598252};\\\", \\\"{x:1365,y:647,t:1526328598263};\\\", \\\"{x:1412,y:826,t:1526328598279};\\\", \\\"{x:1459,y:987,t:1526328598296};\\\", \\\"{x:1483,y:1083,t:1526328598313};\\\", \\\"{x:1486,y:1110,t:1526328598329};\\\", \\\"{x:1489,y:1121,t:1526328598346};\\\", \\\"{x:1490,y:1129,t:1526328598363};\\\", \\\"{x:1495,y:1137,t:1526328598379};\\\", \\\"{x:1501,y:1145,t:1526328598396};\\\", \\\"{x:1503,y:1147,t:1526328598413};\\\", \\\"{x:1505,y:1148,t:1526328598429};\\\", \\\"{x:1505,y:1149,t:1526328598446};\\\", \\\"{x:1510,y:1153,t:1526328598463};\\\", \\\"{x:1514,y:1156,t:1526328598479};\\\", \\\"{x:1516,y:1157,t:1526328598496};\\\", \\\"{x:1518,y:1151,t:1526328598531};\\\", \\\"{x:1523,y:1131,t:1526328598547};\\\", \\\"{x:1527,y:1120,t:1526328598562};\\\", \\\"{x:1539,y:1085,t:1526328598579};\\\", \\\"{x:1546,y:1059,t:1526328598596};\\\", \\\"{x:1550,y:1036,t:1526328598612};\\\", \\\"{x:1550,y:1020,t:1526328598630};\\\", \\\"{x:1550,y:1017,t:1526328598646};\\\", \\\"{x:1551,y:1016,t:1526328598662};\\\", \\\"{x:1551,y:1014,t:1526328598756};\\\", \\\"{x:1551,y:1009,t:1526328598876};\\\", \\\"{x:1553,y:1005,t:1526328598884};\\\", \\\"{x:1555,y:996,t:1526328598899};\\\", \\\"{x:1556,y:991,t:1526328598913};\\\", \\\"{x:1556,y:987,t:1526328598929};\\\", \\\"{x:1558,y:982,t:1526328598946};\\\", \\\"{x:1558,y:979,t:1526328598964};\\\", \\\"{x:1559,y:977,t:1526328598979};\\\", \\\"{x:1559,y:976,t:1526328599020};\\\", \\\"{x:1559,y:974,t:1526328599031};\\\", \\\"{x:1560,y:968,t:1526328599047};\\\", \\\"{x:1562,y:960,t:1526328599063};\\\", \\\"{x:1562,y:954,t:1526328599080};\\\", \\\"{x:1563,y:948,t:1526328599096};\\\", \\\"{x:1565,y:943,t:1526328599113};\\\", \\\"{x:1567,y:936,t:1526328599130};\\\", \\\"{x:1571,y:928,t:1526328599147};\\\", \\\"{x:1572,y:923,t:1526328599164};\\\", \\\"{x:1572,y:918,t:1526328599179};\\\", \\\"{x:1574,y:914,t:1526328599197};\\\", \\\"{x:1574,y:913,t:1526328599214};\\\", \\\"{x:1574,y:919,t:1526328599461};\\\", \\\"{x:1575,y:929,t:1526328599468};\\\", \\\"{x:1577,y:942,t:1526328599483};\\\", \\\"{x:1583,y:969,t:1526328599497};\\\", \\\"{x:1589,y:995,t:1526328599513};\\\", \\\"{x:1591,y:1010,t:1526328599531};\\\", \\\"{x:1591,y:1017,t:1526328599547};\\\", \\\"{x:1591,y:1022,t:1526328599564};\\\", \\\"{x:1591,y:1023,t:1526328599588};\\\", \\\"{x:1590,y:1021,t:1526328599764};\\\", \\\"{x:1587,y:1017,t:1526328599780};\\\", \\\"{x:1586,y:1011,t:1526328599797};\\\", \\\"{x:1583,y:1005,t:1526328599813};\\\", \\\"{x:1582,y:997,t:1526328599829};\\\", \\\"{x:1580,y:990,t:1526328599847};\\\", \\\"{x:1578,y:984,t:1526328599863};\\\", \\\"{x:1577,y:979,t:1526328599880};\\\", \\\"{x:1576,y:977,t:1526328599897};\\\", \\\"{x:1576,y:976,t:1526328599914};\\\", \\\"{x:1576,y:974,t:1526328599929};\\\", \\\"{x:1574,y:970,t:1526328599946};\\\", \\\"{x:1574,y:964,t:1526328599963};\\\", \\\"{x:1574,y:958,t:1526328599981};\\\", \\\"{x:1574,y:953,t:1526328599997};\\\", \\\"{x:1574,y:946,t:1526328600014};\\\", \\\"{x:1574,y:936,t:1526328600031};\\\", \\\"{x:1574,y:931,t:1526328600047};\\\", \\\"{x:1576,y:926,t:1526328600064};\\\", \\\"{x:1576,y:919,t:1526328600081};\\\", \\\"{x:1577,y:913,t:1526328600097};\\\", \\\"{x:1577,y:909,t:1526328600114};\\\", \\\"{x:1577,y:906,t:1526328600131};\\\", \\\"{x:1577,y:903,t:1526328600148};\\\", \\\"{x:1577,y:900,t:1526328600164};\\\", \\\"{x:1577,y:896,t:1526328600182};\\\", \\\"{x:1577,y:895,t:1526328600197};\\\", \\\"{x:1577,y:892,t:1526328600214};\\\", \\\"{x:1577,y:889,t:1526328600232};\\\", \\\"{x:1577,y:888,t:1526328600247};\\\", \\\"{x:1577,y:884,t:1526328600264};\\\", \\\"{x:1577,y:877,t:1526328600281};\\\", \\\"{x:1577,y:871,t:1526328600297};\\\", \\\"{x:1578,y:869,t:1526328600314};\\\", \\\"{x:1578,y:866,t:1526328600331};\\\", \\\"{x:1578,y:860,t:1526328600347};\\\", \\\"{x:1578,y:856,t:1526328600364};\\\", \\\"{x:1578,y:849,t:1526328600382};\\\", \\\"{x:1578,y:839,t:1526328600398};\\\", \\\"{x:1578,y:830,t:1526328600415};\\\", \\\"{x:1578,y:821,t:1526328600431};\\\", \\\"{x:1578,y:813,t:1526328600447};\\\", \\\"{x:1578,y:803,t:1526328600464};\\\", \\\"{x:1578,y:794,t:1526328600481};\\\", \\\"{x:1580,y:788,t:1526328600498};\\\", \\\"{x:1580,y:780,t:1526328600515};\\\", \\\"{x:1580,y:771,t:1526328600532};\\\", \\\"{x:1581,y:761,t:1526328600547};\\\", \\\"{x:1581,y:755,t:1526328600564};\\\", \\\"{x:1581,y:748,t:1526328600581};\\\", \\\"{x:1581,y:738,t:1526328600598};\\\", \\\"{x:1581,y:727,t:1526328600613};\\\", \\\"{x:1582,y:716,t:1526328600630};\\\", \\\"{x:1584,y:709,t:1526328600647};\\\", \\\"{x:1584,y:702,t:1526328600664};\\\", \\\"{x:1584,y:695,t:1526328600681};\\\", \\\"{x:1584,y:691,t:1526328600698};\\\", \\\"{x:1584,y:687,t:1526328600714};\\\", \\\"{x:1583,y:675,t:1526328600731};\\\", \\\"{x:1583,y:669,t:1526328600747};\\\", \\\"{x:1582,y:664,t:1526328600764};\\\", \\\"{x:1582,y:662,t:1526328600781};\\\", \\\"{x:1582,y:658,t:1526328600798};\\\", \\\"{x:1582,y:656,t:1526328600814};\\\", \\\"{x:1582,y:651,t:1526328600831};\\\", \\\"{x:1581,y:646,t:1526328600848};\\\", \\\"{x:1581,y:640,t:1526328600864};\\\", \\\"{x:1581,y:634,t:1526328600881};\\\", \\\"{x:1581,y:628,t:1526328600898};\\\", \\\"{x:1580,y:622,t:1526328600915};\\\", \\\"{x:1579,y:617,t:1526328600931};\\\", \\\"{x:1579,y:608,t:1526328600948};\\\", \\\"{x:1578,y:604,t:1526328600965};\\\", \\\"{x:1578,y:599,t:1526328600981};\\\", \\\"{x:1578,y:592,t:1526328600998};\\\", \\\"{x:1577,y:585,t:1526328601015};\\\", \\\"{x:1577,y:580,t:1526328601032};\\\", \\\"{x:1577,y:572,t:1526328601049};\\\", \\\"{x:1577,y:564,t:1526328601065};\\\", \\\"{x:1577,y:554,t:1526328601080};\\\", \\\"{x:1577,y:546,t:1526328601098};\\\", \\\"{x:1577,y:536,t:1526328601115};\\\", \\\"{x:1577,y:532,t:1526328601130};\\\", \\\"{x:1577,y:528,t:1526328601147};\\\", \\\"{x:1577,y:523,t:1526328601165};\\\", \\\"{x:1577,y:516,t:1526328601180};\\\", \\\"{x:1578,y:509,t:1526328601197};\\\", \\\"{x:1578,y:504,t:1526328601215};\\\", \\\"{x:1580,y:500,t:1526328601231};\\\", \\\"{x:1580,y:497,t:1526328601248};\\\", \\\"{x:1580,y:494,t:1526328601265};\\\", \\\"{x:1581,y:490,t:1526328601281};\\\", \\\"{x:1581,y:487,t:1526328601298};\\\", \\\"{x:1581,y:482,t:1526328601315};\\\", \\\"{x:1582,y:478,t:1526328601331};\\\", \\\"{x:1583,y:475,t:1526328601348};\\\", \\\"{x:1583,y:473,t:1526328601364};\\\", \\\"{x:1584,y:472,t:1526328601382};\\\", \\\"{x:1584,y:470,t:1526328601398};\\\", \\\"{x:1584,y:469,t:1526328601415};\\\", \\\"{x:1584,y:468,t:1526328601432};\\\", \\\"{x:1584,y:467,t:1526328601448};\\\", \\\"{x:1584,y:470,t:1526328601844};\\\", \\\"{x:1584,y:471,t:1526328601852};\\\", \\\"{x:1581,y:478,t:1526328601868};\\\", \\\"{x:1580,y:481,t:1526328601884};\\\", \\\"{x:1579,y:482,t:1526328601899};\\\", \\\"{x:1578,y:489,t:1526328601915};\\\", \\\"{x:1578,y:495,t:1526328601932};\\\", \\\"{x:1576,y:499,t:1526328601950};\\\", \\\"{x:1576,y:503,t:1526328601965};\\\", \\\"{x:1575,y:506,t:1526328601982};\\\", \\\"{x:1575,y:511,t:1526328601999};\\\", \\\"{x:1574,y:512,t:1526328602015};\\\", \\\"{x:1574,y:514,t:1526328602033};\\\", \\\"{x:1573,y:518,t:1526328602049};\\\", \\\"{x:1573,y:520,t:1526328602068};\\\", \\\"{x:1573,y:521,t:1526328602082};\\\", \\\"{x:1573,y:525,t:1526328602099};\\\", \\\"{x:1572,y:528,t:1526328602116};\\\", \\\"{x:1571,y:532,t:1526328602133};\\\", \\\"{x:1571,y:537,t:1526328602149};\\\", \\\"{x:1569,y:544,t:1526328602165};\\\", \\\"{x:1569,y:549,t:1526328602183};\\\", \\\"{x:1568,y:555,t:1526328602199};\\\", \\\"{x:1568,y:561,t:1526328602216};\\\", \\\"{x:1568,y:567,t:1526328602233};\\\", \\\"{x:1568,y:574,t:1526328602249};\\\", \\\"{x:1568,y:582,t:1526328602267};\\\", \\\"{x:1568,y:592,t:1526328602283};\\\", \\\"{x:1568,y:603,t:1526328602300};\\\", \\\"{x:1568,y:622,t:1526328602317};\\\", \\\"{x:1568,y:632,t:1526328602332};\\\", \\\"{x:1568,y:643,t:1526328602349};\\\", \\\"{x:1568,y:653,t:1526328602366};\\\", \\\"{x:1568,y:665,t:1526328602382};\\\", \\\"{x:1568,y:678,t:1526328602400};\\\", \\\"{x:1568,y:689,t:1526328602417};\\\", \\\"{x:1568,y:699,t:1526328602432};\\\", \\\"{x:1568,y:710,t:1526328602450};\\\", \\\"{x:1568,y:722,t:1526328602466};\\\", \\\"{x:1568,y:737,t:1526328602482};\\\", \\\"{x:1568,y:751,t:1526328602500};\\\", \\\"{x:1566,y:777,t:1526328602516};\\\", \\\"{x:1566,y:790,t:1526328602532};\\\", \\\"{x:1564,y:805,t:1526328602549};\\\", \\\"{x:1564,y:818,t:1526328602566};\\\", \\\"{x:1564,y:831,t:1526328602582};\\\", \\\"{x:1564,y:845,t:1526328602599};\\\", \\\"{x:1564,y:856,t:1526328602615};\\\", \\\"{x:1564,y:869,t:1526328602634};\\\", \\\"{x:1564,y:884,t:1526328602650};\\\", \\\"{x:1564,y:902,t:1526328602666};\\\", \\\"{x:1564,y:922,t:1526328602684};\\\", \\\"{x:1564,y:929,t:1526328602700};\\\", \\\"{x:1564,y:945,t:1526328602715};\\\", \\\"{x:1564,y:952,t:1526328602733};\\\", \\\"{x:1564,y:955,t:1526328602749};\\\", \\\"{x:1564,y:957,t:1526328602766};\\\", \\\"{x:1564,y:959,t:1526328602782};\\\", \\\"{x:1564,y:961,t:1526328602799};\\\", \\\"{x:1564,y:962,t:1526328602816};\\\", \\\"{x:1564,y:964,t:1526328602833};\\\", \\\"{x:1564,y:965,t:1526328602849};\\\", \\\"{x:1564,y:967,t:1526328602866};\\\", \\\"{x:1564,y:968,t:1526328602882};\\\", \\\"{x:1563,y:969,t:1526328603068};\\\", \\\"{x:1559,y:972,t:1526328603084};\\\", \\\"{x:1556,y:973,t:1526328603100};\\\", \\\"{x:1553,y:975,t:1526328603117};\\\", \\\"{x:1548,y:978,t:1526328603134};\\\", \\\"{x:1545,y:979,t:1526328603150};\\\", \\\"{x:1542,y:980,t:1526328603167};\\\", \\\"{x:1540,y:981,t:1526328603182};\\\", \\\"{x:1539,y:981,t:1526328603204};\\\", \\\"{x:1539,y:982,t:1526328603217};\\\", \\\"{x:1537,y:982,t:1526328603233};\\\", \\\"{x:1536,y:982,t:1526328603250};\\\", \\\"{x:1535,y:983,t:1526328603276};\\\", \\\"{x:1534,y:982,t:1526328603532};\\\", \\\"{x:1533,y:978,t:1526328603552};\\\", \\\"{x:1532,y:976,t:1526328603566};\\\", \\\"{x:1532,y:974,t:1526328603583};\\\", \\\"{x:1532,y:971,t:1526328603600};\\\", \\\"{x:1532,y:969,t:1526328603616};\\\", \\\"{x:1532,y:965,t:1526328603633};\\\", \\\"{x:1532,y:963,t:1526328603650};\\\", \\\"{x:1532,y:958,t:1526328603666};\\\", \\\"{x:1532,y:953,t:1526328603683};\\\", \\\"{x:1532,y:951,t:1526328603700};\\\", \\\"{x:1533,y:948,t:1526328603716};\\\", \\\"{x:1534,y:943,t:1526328603733};\\\", \\\"{x:1536,y:939,t:1526328603750};\\\", \\\"{x:1537,y:935,t:1526328603767};\\\", \\\"{x:1540,y:927,t:1526328603783};\\\", \\\"{x:1540,y:923,t:1526328603800};\\\", \\\"{x:1542,y:918,t:1526328603817};\\\", \\\"{x:1543,y:914,t:1526328603833};\\\", \\\"{x:1546,y:907,t:1526328603850};\\\", \\\"{x:1548,y:900,t:1526328603867};\\\", \\\"{x:1550,y:892,t:1526328603884};\\\", \\\"{x:1551,y:885,t:1526328603900};\\\", \\\"{x:1552,y:879,t:1526328603917};\\\", \\\"{x:1554,y:868,t:1526328603933};\\\", \\\"{x:1554,y:863,t:1526328603950};\\\", \\\"{x:1556,y:858,t:1526328603967};\\\", \\\"{x:1556,y:852,t:1526328603984};\\\", \\\"{x:1556,y:848,t:1526328604000};\\\", \\\"{x:1557,y:844,t:1526328604017};\\\", \\\"{x:1558,y:838,t:1526328604034};\\\", \\\"{x:1558,y:835,t:1526328604050};\\\", \\\"{x:1559,y:830,t:1526328604068};\\\", \\\"{x:1559,y:826,t:1526328604084};\\\", \\\"{x:1559,y:823,t:1526328604100};\\\", \\\"{x:1559,y:819,t:1526328604117};\\\", \\\"{x:1559,y:817,t:1526328604133};\\\", \\\"{x:1560,y:814,t:1526328604150};\\\", \\\"{x:1561,y:811,t:1526328604167};\\\", \\\"{x:1561,y:806,t:1526328604184};\\\", \\\"{x:1561,y:803,t:1526328604201};\\\", \\\"{x:1561,y:797,t:1526328604218};\\\", \\\"{x:1561,y:791,t:1526328604235};\\\", \\\"{x:1561,y:783,t:1526328604251};\\\", \\\"{x:1561,y:765,t:1526328604268};\\\", \\\"{x:1561,y:754,t:1526328604283};\\\", \\\"{x:1561,y:746,t:1526328604300};\\\", \\\"{x:1560,y:738,t:1526328604318};\\\", \\\"{x:1559,y:728,t:1526328604335};\\\", \\\"{x:1558,y:721,t:1526328604350};\\\", \\\"{x:1558,y:715,t:1526328604368};\\\", \\\"{x:1558,y:708,t:1526328604385};\\\", \\\"{x:1556,y:702,t:1526328604400};\\\", \\\"{x:1556,y:698,t:1526328604417};\\\", \\\"{x:1555,y:693,t:1526328604434};\\\", \\\"{x:1555,y:691,t:1526328604451};\\\", \\\"{x:1555,y:687,t:1526328604468};\\\", \\\"{x:1554,y:683,t:1526328604485};\\\", \\\"{x:1554,y:681,t:1526328604501};\\\", \\\"{x:1552,y:676,t:1526328604518};\\\", \\\"{x:1552,y:671,t:1526328604535};\\\", \\\"{x:1552,y:668,t:1526328604551};\\\", \\\"{x:1551,y:664,t:1526328604567};\\\", \\\"{x:1551,y:661,t:1526328604583};\\\", \\\"{x:1551,y:658,t:1526328604601};\\\", \\\"{x:1550,y:654,t:1526328604617};\\\", \\\"{x:1549,y:651,t:1526328604634};\\\", \\\"{x:1549,y:639,t:1526328604651};\\\", \\\"{x:1548,y:636,t:1526328604667};\\\", \\\"{x:1547,y:632,t:1526328604685};\\\", \\\"{x:1547,y:628,t:1526328604701};\\\", \\\"{x:1547,y:624,t:1526328604717};\\\", \\\"{x:1547,y:617,t:1526328604734};\\\", \\\"{x:1547,y:612,t:1526328604751};\\\", \\\"{x:1547,y:605,t:1526328604768};\\\", \\\"{x:1547,y:596,t:1526328604784};\\\", \\\"{x:1547,y:589,t:1526328604801};\\\", \\\"{x:1547,y:582,t:1526328604817};\\\", \\\"{x:1547,y:578,t:1526328604835};\\\", \\\"{x:1547,y:571,t:1526328604851};\\\", \\\"{x:1547,y:569,t:1526328604867};\\\", \\\"{x:1547,y:566,t:1526328604884};\\\", \\\"{x:1547,y:565,t:1526328604902};\\\", \\\"{x:1547,y:563,t:1526328604918};\\\", \\\"{x:1547,y:562,t:1526328604935};\\\", \\\"{x:1547,y:561,t:1526328604952};\\\", \\\"{x:1547,y:560,t:1526328604968};\\\", \\\"{x:1547,y:559,t:1526328604985};\\\", \\\"{x:1547,y:558,t:1526328605002};\\\", \\\"{x:1547,y:557,t:1526328605017};\\\", \\\"{x:1547,y:560,t:1526328606116};\\\", \\\"{x:1547,y:562,t:1526328606124};\\\", \\\"{x:1547,y:564,t:1526328606142};\\\", \\\"{x:1545,y:566,t:1526328606153};\\\", \\\"{x:1545,y:567,t:1526328606169};\\\", \\\"{x:1544,y:568,t:1526328606186};\\\", \\\"{x:1543,y:568,t:1526328607397};\\\", \\\"{x:1542,y:566,t:1526328607404};\\\", \\\"{x:1540,y:560,t:1526328607420};\\\", \\\"{x:1537,y:551,t:1526328607437};\\\", \\\"{x:1536,y:545,t:1526328607454};\\\", \\\"{x:1533,y:539,t:1526328607470};\\\", \\\"{x:1529,y:530,t:1526328607487};\\\", \\\"{x:1524,y:519,t:1526328607504};\\\", \\\"{x:1515,y:504,t:1526328607519};\\\", \\\"{x:1501,y:491,t:1526328607537};\\\", \\\"{x:1490,y:478,t:1526328607554};\\\", \\\"{x:1484,y:469,t:1526328607570};\\\", \\\"{x:1480,y:464,t:1526328607586};\\\", \\\"{x:1478,y:463,t:1526328607604};\\\", \\\"{x:1476,y:463,t:1526328608628};\\\", \\\"{x:1471,y:466,t:1526328608637};\\\", \\\"{x:1464,y:472,t:1526328608655};\\\", \\\"{x:1454,y:480,t:1526328608671};\\\", \\\"{x:1450,y:484,t:1526328608688};\\\", \\\"{x:1447,y:484,t:1526328608704};\\\", \\\"{x:1444,y:487,t:1526328608721};\\\", \\\"{x:1441,y:489,t:1526328608739};\\\", \\\"{x:1440,y:490,t:1526328608754};\\\", \\\"{x:1437,y:492,t:1526328608771};\\\", \\\"{x:1436,y:496,t:1526328608788};\\\", \\\"{x:1434,y:498,t:1526328608805};\\\", \\\"{x:1434,y:501,t:1526328608821};\\\", \\\"{x:1433,y:503,t:1526328608838};\\\", \\\"{x:1430,y:506,t:1526328608855};\\\", \\\"{x:1427,y:513,t:1526328608871};\\\", \\\"{x:1423,y:519,t:1526328608888};\\\", \\\"{x:1417,y:527,t:1526328608905};\\\", \\\"{x:1412,y:535,t:1526328608921};\\\", \\\"{x:1401,y:549,t:1526328608939};\\\", \\\"{x:1398,y:554,t:1526328608955};\\\", \\\"{x:1389,y:571,t:1526328608971};\\\", \\\"{x:1387,y:580,t:1526328608988};\\\", \\\"{x:1382,y:586,t:1526328609005};\\\", \\\"{x:1381,y:589,t:1526328609022};\\\", \\\"{x:1381,y:590,t:1526328609038};\\\", \\\"{x:1381,y:593,t:1526328609055};\\\", \\\"{x:1381,y:594,t:1526328609075};\\\", \\\"{x:1382,y:594,t:1526328640982};\\\", \\\"{x:1387,y:594,t:1526328641005};\\\", \\\"{x:1390,y:594,t:1526328641016};\\\", \\\"{x:1393,y:594,t:1526328641033};\\\", \\\"{x:1391,y:594,t:1526328641438};\\\", \\\"{x:1385,y:590,t:1526328641454};\\\", \\\"{x:1383,y:588,t:1526328641466};\\\", \\\"{x:1379,y:584,t:1526328641484};\\\", \\\"{x:1374,y:579,t:1526328641499};\\\", \\\"{x:1369,y:574,t:1526328641517};\\\", \\\"{x:1362,y:569,t:1526328641533};\\\", \\\"{x:1358,y:566,t:1526328641550};\\\", \\\"{x:1352,y:563,t:1526328641566};\\\", \\\"{x:1351,y:562,t:1526328641583};\\\", \\\"{x:1350,y:562,t:1526328641599};\\\", \\\"{x:1350,y:560,t:1526328642310};\\\", \\\"{x:1355,y:559,t:1526328642317};\\\", \\\"{x:1361,y:555,t:1526328642334};\\\", \\\"{x:1367,y:552,t:1526328642351};\\\", \\\"{x:1370,y:550,t:1526328642367};\\\", \\\"{x:1372,y:549,t:1526328642385};\\\", \\\"{x:1374,y:549,t:1526328642606};\\\", \\\"{x:1375,y:549,t:1526328642636};\\\", \\\"{x:1377,y:549,t:1526328642653};\\\", \\\"{x:1378,y:549,t:1526328642677};\\\", \\\"{x:1380,y:549,t:1526328642692};\\\", \\\"{x:1381,y:549,t:1526328642708};\\\", \\\"{x:1383,y:549,t:1526328642716};\\\", \\\"{x:1385,y:549,t:1526328642734};\\\", \\\"{x:1390,y:549,t:1526328642750};\\\", \\\"{x:1392,y:549,t:1526328642767};\\\", \\\"{x:1394,y:549,t:1526328642784};\\\", \\\"{x:1396,y:549,t:1526328642800};\\\", \\\"{x:1397,y:550,t:1526328642817};\\\", \\\"{x:1399,y:550,t:1526328642837};\\\", \\\"{x:1400,y:550,t:1526328642852};\\\", \\\"{x:1401,y:550,t:1526328642867};\\\", \\\"{x:1402,y:550,t:1526328642885};\\\", \\\"{x:1403,y:549,t:1526328643743};\\\", \\\"{x:1411,y:544,t:1526328643758};\\\", \\\"{x:1413,y:544,t:1526328643768};\\\", \\\"{x:1419,y:544,t:1526328643785};\\\", \\\"{x:1422,y:544,t:1526328643802};\\\", \\\"{x:1411,y:544,t:1526328643910};\\\", \\\"{x:1388,y:545,t:1526328643922};\\\", \\\"{x:1299,y:557,t:1526328643938};\\\", \\\"{x:1204,y:572,t:1526328643952};\\\", \\\"{x:1116,y:584,t:1526328643968};\\\", \\\"{x:1043,y:594,t:1526328643985};\\\", \\\"{x:998,y:596,t:1526328644001};\\\", \\\"{x:934,y:596,t:1526328644020};\\\", \\\"{x:861,y:596,t:1526328644034};\\\", \\\"{x:804,y:599,t:1526328644051};\\\", \\\"{x:755,y:599,t:1526328644068};\\\", \\\"{x:736,y:599,t:1526328644086};\\\", \\\"{x:721,y:599,t:1526328644103};\\\", \\\"{x:707,y:599,t:1526328644119};\\\", \\\"{x:697,y:599,t:1526328644136};\\\", \\\"{x:689,y:598,t:1526328644153};\\\", \\\"{x:685,y:597,t:1526328644169};\\\", \\\"{x:681,y:595,t:1526328644187};\\\", \\\"{x:678,y:595,t:1526328644202};\\\", \\\"{x:665,y:590,t:1526328644220};\\\", \\\"{x:651,y:586,t:1526328644236};\\\", \\\"{x:635,y:583,t:1526328644253};\\\", \\\"{x:629,y:581,t:1526328644270};\\\", \\\"{x:623,y:580,t:1526328644286};\\\", \\\"{x:617,y:579,t:1526328644303};\\\", \\\"{x:611,y:576,t:1526328644320};\\\", \\\"{x:606,y:576,t:1526328644336};\\\", \\\"{x:597,y:573,t:1526328644355};\\\", \\\"{x:590,y:572,t:1526328644369};\\\", \\\"{x:593,y:571,t:1526328644525};\\\", \\\"{x:598,y:570,t:1526328644541};\\\", \\\"{x:603,y:570,t:1526328644553};\\\", \\\"{x:609,y:570,t:1526328644570};\\\", \\\"{x:612,y:572,t:1526328644587};\\\", \\\"{x:613,y:572,t:1526328644604};\\\", \\\"{x:614,y:573,t:1526328644621};\\\", \\\"{x:614,y:577,t:1526328644908};\\\", \\\"{x:613,y:584,t:1526328644919};\\\", \\\"{x:604,y:605,t:1526328644937};\\\", \\\"{x:593,y:632,t:1526328644954};\\\", \\\"{x:580,y:655,t:1526328644970};\\\", \\\"{x:564,y:682,t:1526328644986};\\\", \\\"{x:549,y:700,t:1526328645003};\\\", \\\"{x:538,y:710,t:1526328645019};\\\", \\\"{x:532,y:718,t:1526328645036};\\\", \\\"{x:531,y:719,t:1526328645053};\\\", \\\"{x:531,y:717,t:1526328645229};\\\", \\\"{x:531,y:712,t:1526328645238};\\\", \\\"{x:532,y:706,t:1526328645261};\\\", \\\"{x:534,y:703,t:1526328645270};\\\", \\\"{x:536,y:700,t:1526328645288};\\\", \\\"{x:538,y:697,t:1526328645303};\\\", \\\"{x:538,y:699,t:1526328645445};\\\", \\\"{x:538,y:700,t:1526328645455};\\\", \\\"{x:537,y:705,t:1526328645471};\\\", \\\"{x:533,y:711,t:1526328645486};\\\", \\\"{x:531,y:716,t:1526328645504};\\\", \\\"{x:529,y:718,t:1526328645521};\\\", \\\"{x:528,y:719,t:1526328645537};\\\", \\\"{x:527,y:720,t:1526328645554};\\\", \\\"{x:526,y:721,t:1526328645570};\\\", \\\"{x:526,y:722,t:1526328646198};\\\", \\\"{x:526,y:725,t:1526328646205};\\\", \\\"{x:526,y:728,t:1526328646221};\\\", \\\"{x:526,y:731,t:1526328646238};\\\", \\\"{x:526,y:732,t:1526328646254};\\\", \\\"{x:527,y:735,t:1526328646272};\\\" ] }, { \\\"rt\\\": 8185, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 509404, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:736,t:1526328648142};\\\", \\\"{x:532,y:736,t:1526328648158};\\\", \\\"{x:535,y:736,t:1526328648174};\\\", \\\"{x:536,y:735,t:1526328648191};\\\", \\\"{x:537,y:734,t:1526328648221};\\\", \\\"{x:538,y:734,t:1526328648253};\\\", \\\"{x:539,y:734,t:1526328648261};\\\", \\\"{x:540,y:733,t:1526328648284};\\\", \\\"{x:543,y:732,t:1526328648293};\\\", \\\"{x:544,y:731,t:1526328648307};\\\", \\\"{x:546,y:731,t:1526328648324};\\\", \\\"{x:550,y:729,t:1526328648340};\\\", \\\"{x:558,y:729,t:1526328648358};\\\", \\\"{x:573,y:729,t:1526328648375};\\\", \\\"{x:589,y:730,t:1526328648390};\\\", \\\"{x:610,y:735,t:1526328648406};\\\", \\\"{x:631,y:737,t:1526328648423};\\\", \\\"{x:654,y:742,t:1526328648440};\\\", \\\"{x:677,y:746,t:1526328648457};\\\", \\\"{x:700,y:753,t:1526328648472};\\\", \\\"{x:720,y:758,t:1526328648490};\\\", \\\"{x:737,y:764,t:1526328648506};\\\", \\\"{x:751,y:768,t:1526328648523};\\\", \\\"{x:762,y:773,t:1526328648540};\\\", \\\"{x:771,y:776,t:1526328648557};\\\", \\\"{x:773,y:777,t:1526328648573};\\\", \\\"{x:774,y:778,t:1526328648590};\\\", \\\"{x:777,y:781,t:1526328648607};\\\", \\\"{x:781,y:784,t:1526328648623};\\\", \\\"{x:786,y:788,t:1526328648640};\\\", \\\"{x:791,y:792,t:1526328648657};\\\", \\\"{x:793,y:794,t:1526328648672};\\\", \\\"{x:793,y:796,t:1526328648690};\\\", \\\"{x:793,y:795,t:1526328649341};\\\", \\\"{x:793,y:793,t:1526328649357};\\\", \\\"{x:793,y:791,t:1526328649373};\\\", \\\"{x:793,y:790,t:1526328649391};\\\", \\\"{x:793,y:788,t:1526328649408};\\\", \\\"{x:793,y:786,t:1526328649424};\\\", \\\"{x:794,y:786,t:1526328649441};\\\", \\\"{x:794,y:785,t:1526328649458};\\\", \\\"{x:794,y:783,t:1526328649473};\\\", \\\"{x:794,y:782,t:1526328649491};\\\", \\\"{x:796,y:780,t:1526328649507};\\\", \\\"{x:796,y:779,t:1526328649524};\\\", \\\"{x:797,y:778,t:1526328649540};\\\", \\\"{x:798,y:777,t:1526328649557};\\\", \\\"{x:799,y:776,t:1526328649575};\\\", \\\"{x:800,y:775,t:1526328649590};\\\", \\\"{x:800,y:774,t:1526328649613};\\\", \\\"{x:801,y:774,t:1526328649629};\\\", \\\"{x:802,y:773,t:1526328649653};\\\", \\\"{x:803,y:773,t:1526328649894};\\\", \\\"{x:806,y:772,t:1526328649909};\\\", \\\"{x:809,y:770,t:1526328649924};\\\", \\\"{x:818,y:764,t:1526328649941};\\\", \\\"{x:833,y:757,t:1526328649958};\\\", \\\"{x:845,y:749,t:1526328649974};\\\", \\\"{x:857,y:741,t:1526328649991};\\\", \\\"{x:872,y:732,t:1526328650007};\\\", \\\"{x:890,y:722,t:1526328650025};\\\", \\\"{x:905,y:714,t:1526328650041};\\\", \\\"{x:919,y:706,t:1526328650058};\\\", \\\"{x:934,y:701,t:1526328650075};\\\", \\\"{x:951,y:696,t:1526328650092};\\\", \\\"{x:967,y:688,t:1526328650108};\\\", \\\"{x:993,y:680,t:1526328650126};\\\", \\\"{x:1014,y:670,t:1526328650141};\\\", \\\"{x:1032,y:664,t:1526328650159};\\\", \\\"{x:1053,y:658,t:1526328650175};\\\", \\\"{x:1076,y:651,t:1526328650192};\\\", \\\"{x:1098,y:645,t:1526328650208};\\\", \\\"{x:1125,y:641,t:1526328650225};\\\", \\\"{x:1159,y:637,t:1526328650242};\\\", \\\"{x:1189,y:635,t:1526328650258};\\\", \\\"{x:1225,y:635,t:1526328650275};\\\", \\\"{x:1260,y:634,t:1526328650292};\\\", \\\"{x:1288,y:634,t:1526328650307};\\\", \\\"{x:1307,y:631,t:1526328650325};\\\", \\\"{x:1327,y:629,t:1526328650342};\\\", \\\"{x:1329,y:629,t:1526328650359};\\\", \\\"{x:1330,y:629,t:1526328650526};\\\", \\\"{x:1333,y:628,t:1526328650549};\\\", \\\"{x:1333,y:627,t:1526328650564};\\\", \\\"{x:1334,y:626,t:1526328650581};\\\", \\\"{x:1335,y:626,t:1526328650592};\\\", \\\"{x:1336,y:626,t:1526328650609};\\\", \\\"{x:1336,y:625,t:1526328650637};\\\", \\\"{x:1336,y:624,t:1526328650652};\\\", \\\"{x:1336,y:621,t:1526328650668};\\\", \\\"{x:1336,y:618,t:1526328650677};\\\", \\\"{x:1336,y:613,t:1526328650691};\\\", \\\"{x:1330,y:597,t:1526328650709};\\\", \\\"{x:1324,y:584,t:1526328650724};\\\", \\\"{x:1321,y:578,t:1526328650741};\\\", \\\"{x:1318,y:574,t:1526328650759};\\\", \\\"{x:1312,y:570,t:1526328650774};\\\", \\\"{x:1301,y:564,t:1526328650791};\\\", \\\"{x:1291,y:558,t:1526328650809};\\\", \\\"{x:1277,y:554,t:1526328650825};\\\", \\\"{x:1261,y:551,t:1526328650842};\\\", \\\"{x:1232,y:546,t:1526328650858};\\\", \\\"{x:1204,y:544,t:1526328650876};\\\", \\\"{x:1176,y:544,t:1526328650892};\\\", \\\"{x:1139,y:544,t:1526328650909};\\\", \\\"{x:1123,y:544,t:1526328650925};\\\", \\\"{x:1108,y:544,t:1526328650942};\\\", \\\"{x:1091,y:544,t:1526328650959};\\\", \\\"{x:1071,y:544,t:1526328650975};\\\", \\\"{x:1054,y:544,t:1526328650991};\\\", \\\"{x:1031,y:545,t:1526328651008};\\\", \\\"{x:1009,y:548,t:1526328651026};\\\", \\\"{x:978,y:552,t:1526328651041};\\\", \\\"{x:944,y:552,t:1526328651060};\\\", \\\"{x:907,y:552,t:1526328651075};\\\", \\\"{x:868,y:552,t:1526328651091};\\\", \\\"{x:809,y:552,t:1526328651108};\\\", \\\"{x:781,y:552,t:1526328651124};\\\", \\\"{x:759,y:552,t:1526328651141};\\\", \\\"{x:745,y:552,t:1526328651159};\\\", \\\"{x:737,y:552,t:1526328651175};\\\", \\\"{x:732,y:552,t:1526328651192};\\\", \\\"{x:728,y:553,t:1526328651209};\\\", \\\"{x:724,y:553,t:1526328651225};\\\", \\\"{x:717,y:554,t:1526328651242};\\\", \\\"{x:715,y:556,t:1526328651259};\\\", \\\"{x:714,y:556,t:1526328651276};\\\", \\\"{x:712,y:556,t:1526328651301};\\\", \\\"{x:710,y:556,t:1526328651309};\\\", \\\"{x:703,y:556,t:1526328651325};\\\", \\\"{x:695,y:556,t:1526328651343};\\\", \\\"{x:684,y:551,t:1526328651359};\\\", \\\"{x:673,y:544,t:1526328651376};\\\", \\\"{x:658,y:533,t:1526328651392};\\\", \\\"{x:642,y:526,t:1526328651408};\\\", \\\"{x:628,y:518,t:1526328651426};\\\", \\\"{x:622,y:515,t:1526328651442};\\\", \\\"{x:609,y:510,t:1526328651459};\\\", \\\"{x:601,y:505,t:1526328651475};\\\", \\\"{x:598,y:502,t:1526328651494};\\\", \\\"{x:597,y:501,t:1526328651510};\\\", \\\"{x:595,y:500,t:1526328651525};\\\", \\\"{x:596,y:500,t:1526328651701};\\\", \\\"{x:597,y:500,t:1526328651717};\\\", \\\"{x:598,y:500,t:1526328651725};\\\", \\\"{x:599,y:501,t:1526328651742};\\\", \\\"{x:600,y:502,t:1526328651759};\\\", \\\"{x:604,y:503,t:1526328651776};\\\", \\\"{x:606,y:504,t:1526328651792};\\\", \\\"{x:607,y:504,t:1526328653100};\\\", \\\"{x:613,y:507,t:1526328653116};\\\", \\\"{x:621,y:511,t:1526328653127};\\\", \\\"{x:637,y:519,t:1526328653143};\\\", \\\"{x:664,y:530,t:1526328653160};\\\", \\\"{x:686,y:541,t:1526328653177};\\\", \\\"{x:707,y:548,t:1526328653193};\\\", \\\"{x:723,y:552,t:1526328653210};\\\", \\\"{x:737,y:555,t:1526328653228};\\\", \\\"{x:751,y:557,t:1526328653244};\\\", \\\"{x:767,y:557,t:1526328653260};\\\", \\\"{x:776,y:557,t:1526328653277};\\\", \\\"{x:782,y:557,t:1526328653294};\\\", \\\"{x:786,y:557,t:1526328653311};\\\", \\\"{x:787,y:557,t:1526328653340};\\\", \\\"{x:789,y:556,t:1526328653373};\\\", \\\"{x:790,y:555,t:1526328653382};\\\", \\\"{x:792,y:554,t:1526328653394};\\\", \\\"{x:796,y:552,t:1526328653410};\\\", \\\"{x:797,y:551,t:1526328653426};\\\", \\\"{x:799,y:551,t:1526328653443};\\\", \\\"{x:800,y:550,t:1526328653460};\\\", \\\"{x:803,y:548,t:1526328653476};\\\", \\\"{x:811,y:546,t:1526328653493};\\\", \\\"{x:815,y:546,t:1526328653510};\\\", \\\"{x:817,y:545,t:1526328653526};\\\", \\\"{x:821,y:543,t:1526328653543};\\\", \\\"{x:822,y:543,t:1526328653565};\\\", \\\"{x:823,y:543,t:1526328653637};\\\", \\\"{x:824,y:542,t:1526328653645};\\\", \\\"{x:825,y:541,t:1526328653659};\\\", \\\"{x:829,y:539,t:1526328653677};\\\", \\\"{x:830,y:538,t:1526328653901};\\\", \\\"{x:831,y:538,t:1526328653916};\\\", \\\"{x:832,y:538,t:1526328653931};\\\", \\\"{x:830,y:538,t:1526328654276};\\\", \\\"{x:829,y:539,t:1526328654285};\\\", \\\"{x:821,y:543,t:1526328654300};\\\", \\\"{x:818,y:546,t:1526328654311};\\\", \\\"{x:809,y:556,t:1526328654327};\\\", \\\"{x:799,y:568,t:1526328654345};\\\", \\\"{x:786,y:581,t:1526328654361};\\\", \\\"{x:775,y:596,t:1526328654377};\\\", \\\"{x:760,y:607,t:1526328654395};\\\", \\\"{x:747,y:614,t:1526328654411};\\\", \\\"{x:724,y:628,t:1526328654428};\\\", \\\"{x:712,y:634,t:1526328654445};\\\", \\\"{x:705,y:638,t:1526328654461};\\\", \\\"{x:697,y:643,t:1526328654478};\\\", \\\"{x:688,y:648,t:1526328654494};\\\", \\\"{x:680,y:652,t:1526328654511};\\\", \\\"{x:672,y:656,t:1526328654527};\\\", \\\"{x:665,y:659,t:1526328654544};\\\", \\\"{x:659,y:660,t:1526328654562};\\\", \\\"{x:656,y:661,t:1526328654578};\\\", \\\"{x:655,y:661,t:1526328654595};\\\", \\\"{x:652,y:662,t:1526328654612};\\\", \\\"{x:649,y:664,t:1526328654629};\\\", \\\"{x:645,y:667,t:1526328654645};\\\", \\\"{x:640,y:670,t:1526328654661};\\\", \\\"{x:633,y:672,t:1526328654679};\\\", \\\"{x:623,y:677,t:1526328654694};\\\", \\\"{x:604,y:685,t:1526328654711};\\\", \\\"{x:587,y:691,t:1526328654729};\\\", \\\"{x:571,y:695,t:1526328654744};\\\", \\\"{x:556,y:698,t:1526328654762};\\\", \\\"{x:535,y:702,t:1526328654779};\\\", \\\"{x:518,y:703,t:1526328654795};\\\", \\\"{x:504,y:704,t:1526328654812};\\\", \\\"{x:492,y:707,t:1526328654829};\\\", \\\"{x:489,y:707,t:1526328654844};\\\", \\\"{x:486,y:708,t:1526328654877};\\\", \\\"{x:486,y:709,t:1526328654901};\\\", \\\"{x:485,y:711,t:1526328654950};\\\", \\\"{x:485,y:712,t:1526328654962};\\\", \\\"{x:485,y:714,t:1526328654979};\\\", \\\"{x:483,y:719,t:1526328654996};\\\", \\\"{x:483,y:723,t:1526328655012};\\\", \\\"{x:483,y:726,t:1526328655028};\\\", \\\"{x:483,y:729,t:1526328655044};\\\", \\\"{x:483,y:730,t:1526328655061};\\\", \\\"{x:483,y:733,t:1526328655078};\\\", \\\"{x:484,y:735,t:1526328655109};\\\", \\\"{x:484,y:734,t:1526328656238};\\\", \\\"{x:484,y:733,t:1526328656269};\\\", \\\"{x:484,y:731,t:1526328656445};\\\", \\\"{x:484,y:730,t:1526328656493};\\\", \\\"{x:484,y:728,t:1526328656581};\\\" ] }, { \\\"rt\\\": 13905, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 524554, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:727,t:1526328656774};\\\", \\\"{x:484,y:725,t:1526328656800};\\\", \\\"{x:484,y:724,t:1526328656828};\\\", \\\"{x:484,y:722,t:1526328656844};\\\", \\\"{x:484,y:721,t:1526328656900};\\\", \\\"{x:484,y:720,t:1526328657069};\\\", \\\"{x:485,y:719,t:1526328657124};\\\", \\\"{x:486,y:718,t:1526328657141};\\\", \\\"{x:490,y:715,t:1526328657242};\\\", \\\"{x:490,y:714,t:1526328657262};\\\", \\\"{x:492,y:713,t:1526328657277};\\\", \\\"{x:492,y:712,t:1526328657292};\\\", \\\"{x:493,y:712,t:1526328657316};\\\", \\\"{x:494,y:710,t:1526328657330};\\\", \\\"{x:496,y:708,t:1526328657346};\\\", \\\"{x:498,y:707,t:1526328657364};\\\", \\\"{x:502,y:702,t:1526328657380};\\\", \\\"{x:504,y:699,t:1526328657396};\\\", \\\"{x:507,y:696,t:1526328657413};\\\", \\\"{x:511,y:692,t:1526328657430};\\\", \\\"{x:515,y:687,t:1526328657447};\\\", \\\"{x:518,y:683,t:1526328657463};\\\", \\\"{x:522,y:677,t:1526328657480};\\\", \\\"{x:524,y:674,t:1526328657496};\\\", \\\"{x:527,y:667,t:1526328657513};\\\", \\\"{x:532,y:660,t:1526328657530};\\\", \\\"{x:537,y:651,t:1526328657546};\\\", \\\"{x:540,y:648,t:1526328657563};\\\", \\\"{x:545,y:638,t:1526328657581};\\\", \\\"{x:548,y:631,t:1526328657598};\\\", \\\"{x:549,y:625,t:1526328657614};\\\", \\\"{x:551,y:617,t:1526328657631};\\\", \\\"{x:551,y:608,t:1526328657647};\\\", \\\"{x:551,y:599,t:1526328657665};\\\", \\\"{x:551,y:590,t:1526328657680};\\\", \\\"{x:551,y:580,t:1526328657697};\\\", \\\"{x:551,y:572,t:1526328657714};\\\", \\\"{x:551,y:563,t:1526328657730};\\\", \\\"{x:547,y:555,t:1526328657748};\\\", \\\"{x:537,y:538,t:1526328657764};\\\", \\\"{x:530,y:525,t:1526328657780};\\\", \\\"{x:523,y:515,t:1526328657798};\\\", \\\"{x:516,y:508,t:1526328657813};\\\", \\\"{x:506,y:502,t:1526328657830};\\\", \\\"{x:498,y:496,t:1526328657848};\\\", \\\"{x:488,y:492,t:1526328657863};\\\", \\\"{x:478,y:491,t:1526328657881};\\\", \\\"{x:464,y:487,t:1526328657898};\\\", \\\"{x:451,y:485,t:1526328657915};\\\", \\\"{x:440,y:483,t:1526328657931};\\\", \\\"{x:430,y:481,t:1526328657947};\\\", \\\"{x:415,y:479,t:1526328657965};\\\", \\\"{x:407,y:477,t:1526328657980};\\\", \\\"{x:400,y:476,t:1526328657997};\\\", \\\"{x:398,y:476,t:1526328658015};\\\", \\\"{x:397,y:476,t:1526328658031};\\\", \\\"{x:396,y:476,t:1526328658101};\\\", \\\"{x:395,y:476,t:1526328658125};\\\", \\\"{x:394,y:476,t:1526328658149};\\\", \\\"{x:393,y:475,t:1526328658165};\\\", \\\"{x:392,y:475,t:1526328658212};\\\", \\\"{x:391,y:475,t:1526328658316};\\\", \\\"{x:390,y:475,t:1526328658342};\\\", \\\"{x:390,y:474,t:1526328658669};\\\", \\\"{x:393,y:474,t:1526328658693};\\\", \\\"{x:394,y:474,t:1526328658701};\\\", \\\"{x:396,y:474,t:1526328658715};\\\", \\\"{x:397,y:474,t:1526328658732};\\\", \\\"{x:399,y:474,t:1526328658749};\\\", \\\"{x:400,y:474,t:1526328658765};\\\", \\\"{x:401,y:474,t:1526328658782};\\\", \\\"{x:402,y:474,t:1526328658799};\\\", \\\"{x:404,y:474,t:1526328658816};\\\", \\\"{x:406,y:474,t:1526328658831};\\\", \\\"{x:407,y:474,t:1526328658849};\\\", \\\"{x:408,y:473,t:1526328658864};\\\", \\\"{x:409,y:473,t:1526328658882};\\\", \\\"{x:410,y:473,t:1526328658917};\\\", \\\"{x:411,y:473,t:1526328658933};\\\", \\\"{x:412,y:473,t:1526328658948};\\\", \\\"{x:413,y:473,t:1526328658965};\\\", \\\"{x:414,y:473,t:1526328658982};\\\", \\\"{x:415,y:473,t:1526328658998};\\\", \\\"{x:416,y:473,t:1526328659014};\\\", \\\"{x:417,y:473,t:1526328659032};\\\", \\\"{x:418,y:473,t:1526328659048};\\\", \\\"{x:419,y:473,t:1526328659065};\\\", \\\"{x:420,y:473,t:1526328659081};\\\", \\\"{x:421,y:473,t:1526328659099};\\\", \\\"{x:422,y:473,t:1526328659115};\\\", \\\"{x:423,y:473,t:1526328659132};\\\", \\\"{x:425,y:473,t:1526328659149};\\\", \\\"{x:427,y:473,t:1526328659165};\\\", \\\"{x:430,y:473,t:1526328659182};\\\", \\\"{x:433,y:473,t:1526328659199};\\\", \\\"{x:436,y:473,t:1526328659215};\\\", \\\"{x:440,y:473,t:1526328659232};\\\", \\\"{x:443,y:473,t:1526328659249};\\\", \\\"{x:445,y:473,t:1526328659264};\\\", \\\"{x:447,y:473,t:1526328659282};\\\", \\\"{x:448,y:473,t:1526328659299};\\\", \\\"{x:451,y:473,t:1526328659315};\\\", \\\"{x:453,y:473,t:1526328659332};\\\", \\\"{x:460,y:474,t:1526328659349};\\\", \\\"{x:465,y:474,t:1526328659365};\\\", \\\"{x:471,y:474,t:1526328659382};\\\", \\\"{x:476,y:474,t:1526328659399};\\\", \\\"{x:480,y:475,t:1526328659415};\\\", \\\"{x:484,y:475,t:1526328659433};\\\", \\\"{x:490,y:477,t:1526328659448};\\\", \\\"{x:495,y:478,t:1526328659466};\\\", \\\"{x:498,y:478,t:1526328659482};\\\", \\\"{x:499,y:478,t:1526328659499};\\\", \\\"{x:501,y:478,t:1526328659516};\\\", \\\"{x:502,y:478,t:1526328659540};\\\", \\\"{x:504,y:478,t:1526328659556};\\\", \\\"{x:505,y:478,t:1526328659572};\\\", \\\"{x:507,y:478,t:1526328659589};\\\", \\\"{x:509,y:478,t:1526328659599};\\\", \\\"{x:512,y:478,t:1526328659616};\\\", \\\"{x:517,y:478,t:1526328659632};\\\", \\\"{x:521,y:478,t:1526328659649};\\\", \\\"{x:524,y:478,t:1526328659667};\\\", \\\"{x:529,y:477,t:1526328659682};\\\", \\\"{x:532,y:477,t:1526328659699};\\\", \\\"{x:536,y:476,t:1526328659716};\\\", \\\"{x:538,y:476,t:1526328659733};\\\", \\\"{x:544,y:474,t:1526328659749};\\\", \\\"{x:548,y:474,t:1526328659766};\\\", \\\"{x:553,y:474,t:1526328659783};\\\", \\\"{x:557,y:473,t:1526328659799};\\\", \\\"{x:561,y:473,t:1526328659817};\\\", \\\"{x:564,y:473,t:1526328659833};\\\", \\\"{x:567,y:473,t:1526328659849};\\\", \\\"{x:569,y:473,t:1526328659866};\\\", \\\"{x:571,y:473,t:1526328659883};\\\", \\\"{x:575,y:473,t:1526328659900};\\\", \\\"{x:576,y:473,t:1526328659916};\\\", \\\"{x:578,y:472,t:1526328659933};\\\", \\\"{x:581,y:472,t:1526328659949};\\\", \\\"{x:583,y:472,t:1526328659973};\\\", \\\"{x:584,y:472,t:1526328659988};\\\", \\\"{x:586,y:472,t:1526328659999};\\\", \\\"{x:587,y:472,t:1526328660021};\\\", \\\"{x:589,y:472,t:1526328660045};\\\", \\\"{x:590,y:472,t:1526328660061};\\\", \\\"{x:592,y:472,t:1526328660093};\\\", \\\"{x:593,y:472,t:1526328660142};\\\", \\\"{x:595,y:472,t:1526328660165};\\\", \\\"{x:596,y:472,t:1526328660188};\\\", \\\"{x:598,y:472,t:1526328660228};\\\", \\\"{x:600,y:472,t:1526328660902};\\\", \\\"{x:605,y:474,t:1526328660917};\\\", \\\"{x:612,y:477,t:1526328660935};\\\", \\\"{x:620,y:481,t:1526328660951};\\\", \\\"{x:633,y:489,t:1526328660969};\\\", \\\"{x:647,y:498,t:1526328660984};\\\", \\\"{x:664,y:508,t:1526328661000};\\\", \\\"{x:683,y:519,t:1526328661016};\\\", \\\"{x:698,y:532,t:1526328661034};\\\", \\\"{x:719,y:544,t:1526328661049};\\\", \\\"{x:746,y:561,t:1526328661066};\\\", \\\"{x:770,y:574,t:1526328661084};\\\", \\\"{x:791,y:587,t:1526328661100};\\\", \\\"{x:836,y:608,t:1526328661116};\\\", \\\"{x:872,y:624,t:1526328661134};\\\", \\\"{x:898,y:637,t:1526328661150};\\\", \\\"{x:921,y:648,t:1526328661166};\\\", \\\"{x:944,y:659,t:1526328661182};\\\", \\\"{x:973,y:671,t:1526328661200};\\\", \\\"{x:1004,y:683,t:1526328661217};\\\", \\\"{x:1033,y:691,t:1526328661234};\\\", \\\"{x:1058,y:699,t:1526328661250};\\\", \\\"{x:1080,y:701,t:1526328661267};\\\", \\\"{x:1100,y:706,t:1526328661284};\\\", \\\"{x:1108,y:706,t:1526328661300};\\\", \\\"{x:1115,y:706,t:1526328661317};\\\", \\\"{x:1118,y:706,t:1526328661334};\\\", \\\"{x:1122,y:706,t:1526328661350};\\\", \\\"{x:1125,y:706,t:1526328661367};\\\", \\\"{x:1129,y:706,t:1526328661384};\\\", \\\"{x:1136,y:706,t:1526328661401};\\\", \\\"{x:1149,y:709,t:1526328661417};\\\", \\\"{x:1162,y:709,t:1526328661434};\\\", \\\"{x:1182,y:710,t:1526328661451};\\\", \\\"{x:1201,y:710,t:1526328661467};\\\", \\\"{x:1218,y:710,t:1526328661484};\\\", \\\"{x:1242,y:710,t:1526328661500};\\\", \\\"{x:1254,y:710,t:1526328661517};\\\", \\\"{x:1260,y:710,t:1526328661535};\\\", \\\"{x:1263,y:710,t:1526328661551};\\\", \\\"{x:1265,y:709,t:1526328661569};\\\", \\\"{x:1265,y:708,t:1526328661584};\\\", \\\"{x:1266,y:708,t:1526328661601};\\\", \\\"{x:1268,y:707,t:1526328661618};\\\", \\\"{x:1271,y:704,t:1526328661635};\\\", \\\"{x:1275,y:699,t:1526328661651};\\\", \\\"{x:1278,y:695,t:1526328661668};\\\", \\\"{x:1282,y:691,t:1526328661685};\\\", \\\"{x:1286,y:686,t:1526328661702};\\\", \\\"{x:1289,y:682,t:1526328661719};\\\", \\\"{x:1291,y:681,t:1526328661736};\\\", \\\"{x:1293,y:679,t:1526328661752};\\\", \\\"{x:1295,y:676,t:1526328661768};\\\", \\\"{x:1296,y:674,t:1526328661785};\\\", \\\"{x:1299,y:671,t:1526328661801};\\\", \\\"{x:1300,y:669,t:1526328661818};\\\", \\\"{x:1304,y:666,t:1526328661835};\\\", \\\"{x:1306,y:664,t:1526328661851};\\\", \\\"{x:1308,y:663,t:1526328661868};\\\", \\\"{x:1313,y:659,t:1526328661884};\\\", \\\"{x:1316,y:658,t:1526328661902};\\\", \\\"{x:1322,y:653,t:1526328661918};\\\", \\\"{x:1329,y:648,t:1526328661936};\\\", \\\"{x:1335,y:644,t:1526328661952};\\\", \\\"{x:1340,y:641,t:1526328661968};\\\", \\\"{x:1346,y:637,t:1526328661986};\\\", \\\"{x:1350,y:635,t:1526328662002};\\\", \\\"{x:1352,y:634,t:1526328662020};\\\", \\\"{x:1356,y:632,t:1526328662036};\\\", \\\"{x:1359,y:632,t:1526328662052};\\\", \\\"{x:1360,y:631,t:1526328662070};\\\", \\\"{x:1362,y:630,t:1526328662086};\\\", \\\"{x:1364,y:629,t:1526328662109};\\\", \\\"{x:1365,y:629,t:1526328662134};\\\", \\\"{x:1367,y:629,t:1526328662141};\\\", \\\"{x:1368,y:629,t:1526328662153};\\\", \\\"{x:1376,y:629,t:1526328662169};\\\", \\\"{x:1380,y:629,t:1526328662187};\\\", \\\"{x:1383,y:629,t:1526328662202};\\\", \\\"{x:1388,y:629,t:1526328662220};\\\", \\\"{x:1394,y:629,t:1526328662237};\\\", \\\"{x:1397,y:629,t:1526328662252};\\\", \\\"{x:1404,y:629,t:1526328662269};\\\", \\\"{x:1408,y:629,t:1526328662287};\\\", \\\"{x:1413,y:630,t:1526328662303};\\\", \\\"{x:1417,y:630,t:1526328662319};\\\", \\\"{x:1423,y:630,t:1526328662337};\\\", \\\"{x:1427,y:631,t:1526328662354};\\\", \\\"{x:1432,y:631,t:1526328662370};\\\", \\\"{x:1439,y:631,t:1526328662386};\\\", \\\"{x:1443,y:631,t:1526328662406};\\\", \\\"{x:1447,y:631,t:1526328662419};\\\", \\\"{x:1454,y:631,t:1526328662436};\\\", \\\"{x:1458,y:633,t:1526328662453};\\\", \\\"{x:1460,y:633,t:1526328662476};\\\", \\\"{x:1458,y:634,t:1526328664325};\\\", \\\"{x:1452,y:637,t:1526328664340};\\\", \\\"{x:1448,y:638,t:1526328664357};\\\", \\\"{x:1441,y:642,t:1526328664374};\\\", \\\"{x:1433,y:647,t:1526328664391};\\\", \\\"{x:1426,y:651,t:1526328664407};\\\", \\\"{x:1420,y:654,t:1526328664424};\\\", \\\"{x:1415,y:658,t:1526328664441};\\\", \\\"{x:1410,y:661,t:1526328664457};\\\", \\\"{x:1402,y:668,t:1526328664474};\\\", \\\"{x:1393,y:676,t:1526328664491};\\\", \\\"{x:1383,y:684,t:1526328664507};\\\", \\\"{x:1375,y:691,t:1526328664524};\\\", \\\"{x:1365,y:697,t:1526328664540};\\\", \\\"{x:1360,y:701,t:1526328664558};\\\", \\\"{x:1354,y:705,t:1526328664574};\\\", \\\"{x:1349,y:707,t:1526328664591};\\\", \\\"{x:1345,y:708,t:1526328664608};\\\", \\\"{x:1342,y:709,t:1526328664624};\\\", \\\"{x:1340,y:709,t:1526328664641};\\\", \\\"{x:1339,y:709,t:1526328664658};\\\", \\\"{x:1339,y:710,t:1526328664675};\\\", \\\"{x:1338,y:710,t:1526328664750};\\\", \\\"{x:1338,y:714,t:1526328665310};\\\", \\\"{x:1335,y:735,t:1526328665333};\\\", \\\"{x:1335,y:742,t:1526328665344};\\\", \\\"{x:1331,y:758,t:1526328665359};\\\", \\\"{x:1327,y:771,t:1526328665377};\\\", \\\"{x:1325,y:786,t:1526328665394};\\\", \\\"{x:1322,y:796,t:1526328665409};\\\", \\\"{x:1320,y:802,t:1526328665427};\\\", \\\"{x:1319,y:806,t:1526328665443};\\\", \\\"{x:1317,y:808,t:1526328665460};\\\", \\\"{x:1316,y:808,t:1526328665477};\\\", \\\"{x:1314,y:808,t:1526328665534};\\\", \\\"{x:1310,y:808,t:1526328665544};\\\", \\\"{x:1287,y:808,t:1526328665561};\\\", \\\"{x:1233,y:794,t:1526328665578};\\\", \\\"{x:1132,y:757,t:1526328665593};\\\", \\\"{x:992,y:721,t:1526328665609};\\\", \\\"{x:823,y:676,t:1526328665627};\\\", \\\"{x:678,y:645,t:1526328665644};\\\", \\\"{x:539,y:622,t:1526328665660};\\\", \\\"{x:363,y:593,t:1526328665677};\\\", \\\"{x:266,y:581,t:1526328665694};\\\", \\\"{x:219,y:570,t:1526328665704};\\\", \\\"{x:154,y:558,t:1526328665721};\\\", \\\"{x:110,y:546,t:1526328665738};\\\", \\\"{x:88,y:541,t:1526328665753};\\\", \\\"{x:80,y:538,t:1526328665770};\\\", \\\"{x:81,y:536,t:1526328665796};\\\", \\\"{x:84,y:535,t:1526328665804};\\\", \\\"{x:87,y:533,t:1526328665820};\\\", \\\"{x:88,y:533,t:1526328665838};\\\", \\\"{x:90,y:531,t:1526328665853};\\\", \\\"{x:97,y:529,t:1526328665870};\\\", \\\"{x:108,y:524,t:1526328665888};\\\", \\\"{x:130,y:517,t:1526328665904};\\\", \\\"{x:152,y:509,t:1526328665920};\\\", \\\"{x:170,y:504,t:1526328665938};\\\", \\\"{x:183,y:503,t:1526328665953};\\\", \\\"{x:190,y:502,t:1526328665971};\\\", \\\"{x:200,y:502,t:1526328665987};\\\", \\\"{x:210,y:502,t:1526328666004};\\\", \\\"{x:222,y:502,t:1526328666020};\\\", \\\"{x:229,y:502,t:1526328666038};\\\", \\\"{x:234,y:502,t:1526328666053};\\\", \\\"{x:235,y:503,t:1526328666071};\\\", \\\"{x:236,y:503,t:1526328666093};\\\", \\\"{x:237,y:504,t:1526328666116};\\\", \\\"{x:237,y:505,t:1526328666132};\\\", \\\"{x:236,y:506,t:1526328666141};\\\", \\\"{x:234,y:507,t:1526328666154};\\\", \\\"{x:229,y:508,t:1526328666171};\\\", \\\"{x:225,y:510,t:1526328666188};\\\", \\\"{x:219,y:513,t:1526328666205};\\\", \\\"{x:214,y:516,t:1526328666221};\\\", \\\"{x:212,y:518,t:1526328666239};\\\", \\\"{x:210,y:519,t:1526328666255};\\\", \\\"{x:206,y:521,t:1526328666271};\\\", \\\"{x:203,y:523,t:1526328666288};\\\", \\\"{x:200,y:523,t:1526328666304};\\\", \\\"{x:198,y:525,t:1526328666321};\\\", \\\"{x:197,y:525,t:1526328666337};\\\", \\\"{x:195,y:526,t:1526328666355};\\\", \\\"{x:192,y:527,t:1526328666371};\\\", \\\"{x:190,y:529,t:1526328666388};\\\", \\\"{x:188,y:530,t:1526328666405};\\\", \\\"{x:186,y:530,t:1526328666421};\\\", \\\"{x:185,y:530,t:1526328666437};\\\", \\\"{x:181,y:532,t:1526328666455};\\\", \\\"{x:179,y:532,t:1526328666471};\\\", \\\"{x:176,y:532,t:1526328666487};\\\", \\\"{x:173,y:532,t:1526328666505};\\\", \\\"{x:170,y:533,t:1526328666521};\\\", \\\"{x:170,y:534,t:1526328666537};\\\", \\\"{x:168,y:535,t:1526328666555};\\\", \\\"{x:167,y:536,t:1526328666571};\\\", \\\"{x:166,y:536,t:1526328666588};\\\", \\\"{x:165,y:537,t:1526328666605};\\\", \\\"{x:163,y:538,t:1526328666621};\\\", \\\"{x:161,y:539,t:1526328666653};\\\", \\\"{x:162,y:539,t:1526328667317};\\\", \\\"{x:163,y:539,t:1526328667325};\\\", \\\"{x:165,y:538,t:1526328667340};\\\", \\\"{x:166,y:538,t:1526328667355};\\\", \\\"{x:171,y:536,t:1526328667372};\\\", \\\"{x:172,y:536,t:1526328667388};\\\", \\\"{x:176,y:536,t:1526328667405};\\\", \\\"{x:181,y:536,t:1526328667422};\\\", \\\"{x:186,y:536,t:1526328667438};\\\", \\\"{x:192,y:536,t:1526328667456};\\\", \\\"{x:200,y:537,t:1526328667472};\\\", \\\"{x:207,y:537,t:1526328667488};\\\", \\\"{x:218,y:539,t:1526328667505};\\\", \\\"{x:231,y:541,t:1526328667522};\\\", \\\"{x:241,y:542,t:1526328667538};\\\", \\\"{x:253,y:544,t:1526328667555};\\\", \\\"{x:275,y:544,t:1526328667573};\\\", \\\"{x:287,y:544,t:1526328667588};\\\", \\\"{x:304,y:545,t:1526328667605};\\\", \\\"{x:320,y:545,t:1526328667622};\\\", \\\"{x:337,y:545,t:1526328667639};\\\", \\\"{x:354,y:545,t:1526328667655};\\\", \\\"{x:373,y:545,t:1526328667672};\\\", \\\"{x:391,y:545,t:1526328667690};\\\", \\\"{x:416,y:545,t:1526328667706};\\\", \\\"{x:441,y:545,t:1526328667723};\\\", \\\"{x:470,y:545,t:1526328667740};\\\", \\\"{x:503,y:545,t:1526328667756};\\\", \\\"{x:555,y:545,t:1526328667772};\\\", \\\"{x:603,y:545,t:1526328667789};\\\", \\\"{x:643,y:545,t:1526328667805};\\\", \\\"{x:673,y:545,t:1526328667822};\\\", \\\"{x:702,y:545,t:1526328667839};\\\", \\\"{x:729,y:545,t:1526328667855};\\\", \\\"{x:748,y:545,t:1526328667872};\\\", \\\"{x:758,y:545,t:1526328667889};\\\", \\\"{x:760,y:545,t:1526328667905};\\\", \\\"{x:762,y:545,t:1526328668045};\\\", \\\"{x:769,y:545,t:1526328668060};\\\", \\\"{x:771,y:544,t:1526328668072};\\\", \\\"{x:780,y:540,t:1526328668089};\\\", \\\"{x:786,y:536,t:1526328668106};\\\", \\\"{x:792,y:533,t:1526328668123};\\\", \\\"{x:797,y:531,t:1526328668139};\\\", \\\"{x:803,y:528,t:1526328668157};\\\", \\\"{x:805,y:527,t:1526328668173};\\\", \\\"{x:806,y:527,t:1526328668190};\\\", \\\"{x:807,y:527,t:1526328668285};\\\", \\\"{x:810,y:525,t:1526328668292};\\\", \\\"{x:812,y:524,t:1526328668307};\\\", \\\"{x:817,y:520,t:1526328668322};\\\", \\\"{x:826,y:516,t:1526328668339};\\\", \\\"{x:833,y:511,t:1526328668356};\\\", \\\"{x:837,y:508,t:1526328668372};\\\", \\\"{x:838,y:507,t:1526328668388};\\\", \\\"{x:839,y:506,t:1526328668406};\\\", \\\"{x:840,y:506,t:1526328668423};\\\", \\\"{x:841,y:504,t:1526328668439};\\\", \\\"{x:843,y:504,t:1526328668456};\\\", \\\"{x:845,y:502,t:1526328668472};\\\", \\\"{x:845,y:501,t:1526328668489};\\\", \\\"{x:843,y:502,t:1526328669661};\\\", \\\"{x:840,y:504,t:1526328669676};\\\", \\\"{x:835,y:507,t:1526328669692};\\\", \\\"{x:828,y:511,t:1526328669707};\\\", \\\"{x:820,y:516,t:1526328669732};\\\", \\\"{x:815,y:519,t:1526328669740};\\\", \\\"{x:809,y:523,t:1526328669757};\\\", \\\"{x:803,y:527,t:1526328669774};\\\", \\\"{x:797,y:532,t:1526328669790};\\\", \\\"{x:791,y:537,t:1526328669807};\\\", \\\"{x:783,y:544,t:1526328669823};\\\", \\\"{x:777,y:552,t:1526328669839};\\\", \\\"{x:770,y:559,t:1526328669857};\\\", \\\"{x:756,y:571,t:1526328669875};\\\", \\\"{x:741,y:582,t:1526328669889};\\\", \\\"{x:723,y:593,t:1526328669908};\\\", \\\"{x:697,y:608,t:1526328669924};\\\", \\\"{x:674,y:619,t:1526328669940};\\\", \\\"{x:649,y:626,t:1526328669957};\\\", \\\"{x:623,y:635,t:1526328669975};\\\", \\\"{x:599,y:641,t:1526328669991};\\\", \\\"{x:572,y:649,t:1526328670006};\\\", \\\"{x:548,y:654,t:1526328670024};\\\", \\\"{x:530,y:658,t:1526328670041};\\\", \\\"{x:514,y:660,t:1526328670057};\\\", \\\"{x:512,y:661,t:1526328670074};\\\", \\\"{x:508,y:661,t:1526328670091};\\\", \\\"{x:507,y:662,t:1526328670107};\\\", \\\"{x:506,y:666,t:1526328670124};\\\", \\\"{x:506,y:671,t:1526328670140};\\\", \\\"{x:506,y:678,t:1526328670157};\\\", \\\"{x:506,y:685,t:1526328670175};\\\", \\\"{x:506,y:691,t:1526328670191};\\\", \\\"{x:506,y:699,t:1526328670208};\\\", \\\"{x:506,y:712,t:1526328670224};\\\", \\\"{x:509,y:723,t:1526328670242};\\\", \\\"{x:509,y:732,t:1526328670257};\\\", \\\"{x:509,y:738,t:1526328670274};\\\", \\\"{x:509,y:741,t:1526328670291};\\\", \\\"{x:509,y:742,t:1526328670308};\\\", \\\"{x:508,y:742,t:1526328671141};\\\", \\\"{x:507,y:744,t:1526328671165};\\\", \\\"{x:507,y:745,t:1526328671175};\\\" ] }, { \\\"rt\\\": 37540, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 563323, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -B -B -B -E -E -G -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:747,t:1526328672175};\\\", \\\"{x:510,y:747,t:1526328672428};\\\", \\\"{x:511,y:747,t:1526328672443};\\\", \\\"{x:512,y:746,t:1526328672460};\\\", \\\"{x:513,y:746,t:1526328672476};\\\", \\\"{x:514,y:746,t:1526328672493};\\\", \\\"{x:516,y:745,t:1526328672644};\\\", \\\"{x:521,y:743,t:1526328672660};\\\", \\\"{x:523,y:740,t:1526328672678};\\\", \\\"{x:525,y:740,t:1526328672694};\\\", \\\"{x:526,y:739,t:1526328672711};\\\", \\\"{x:527,y:738,t:1526328672728};\\\", \\\"{x:529,y:737,t:1526328672748};\\\", \\\"{x:525,y:742,t:1526328672925};\\\", \\\"{x:521,y:745,t:1526328672934};\\\", \\\"{x:513,y:753,t:1526328672948};\\\", \\\"{x:509,y:757,t:1526328672961};\\\", \\\"{x:506,y:760,t:1526328672978};\\\", \\\"{x:504,y:763,t:1526328672993};\\\", \\\"{x:502,y:769,t:1526328673009};\\\", \\\"{x:501,y:771,t:1526328673026};\\\", \\\"{x:501,y:773,t:1526328673043};\\\", \\\"{x:501,y:776,t:1526328673059};\\\", \\\"{x:501,y:777,t:1526328673076};\\\", \\\"{x:501,y:779,t:1526328673093};\\\", \\\"{x:501,y:780,t:1526328673109};\\\", \\\"{x:501,y:783,t:1526328673126};\\\", \\\"{x:501,y:786,t:1526328673143};\\\", \\\"{x:501,y:789,t:1526328673159};\\\", \\\"{x:501,y:793,t:1526328673175};\\\", \\\"{x:501,y:800,t:1526328673193};\\\", \\\"{x:501,y:805,t:1526328673210};\\\", \\\"{x:500,y:815,t:1526328673226};\\\", \\\"{x:497,y:826,t:1526328673243};\\\", \\\"{x:492,y:842,t:1526328673260};\\\", \\\"{x:489,y:853,t:1526328673276};\\\", \\\"{x:487,y:864,t:1526328673294};\\\", \\\"{x:485,y:870,t:1526328673310};\\\", \\\"{x:481,y:878,t:1526328673326};\\\", \\\"{x:479,y:883,t:1526328673344};\\\", \\\"{x:478,y:886,t:1526328673360};\\\", \\\"{x:478,y:890,t:1526328673376};\\\", \\\"{x:477,y:893,t:1526328673394};\\\", \\\"{x:476,y:896,t:1526328673410};\\\", \\\"{x:475,y:899,t:1526328673426};\\\", \\\"{x:473,y:903,t:1526328673443};\\\", \\\"{x:469,y:910,t:1526328673461};\\\", \\\"{x:463,y:918,t:1526328673477};\\\", \\\"{x:462,y:921,t:1526328673494};\\\", \\\"{x:460,y:926,t:1526328673510};\\\", \\\"{x:458,y:929,t:1526328673526};\\\", \\\"{x:456,y:933,t:1526328673544};\\\", \\\"{x:454,y:938,t:1526328673561};\\\", \\\"{x:451,y:940,t:1526328673576};\\\", \\\"{x:448,y:943,t:1526328673593};\\\", \\\"{x:447,y:944,t:1526328673621};\\\", \\\"{x:447,y:945,t:1526328673763};\\\", \\\"{x:447,y:948,t:1526328673780};\\\", \\\"{x:448,y:951,t:1526328673793};\\\", \\\"{x:457,y:960,t:1526328673809};\\\", \\\"{x:469,y:970,t:1526328673826};\\\", \\\"{x:479,y:978,t:1526328673843};\\\", \\\"{x:485,y:986,t:1526328673860};\\\", \\\"{x:487,y:992,t:1526328673876};\\\", \\\"{x:488,y:992,t:1526328674397};\\\", \\\"{x:490,y:992,t:1526328674421};\\\", \\\"{x:490,y:990,t:1526328674461};\\\", \\\"{x:490,y:988,t:1526328674477};\\\", \\\"{x:490,y:986,t:1526328674495};\\\", \\\"{x:491,y:985,t:1526328674510};\\\", \\\"{x:491,y:984,t:1526328674527};\\\", \\\"{x:492,y:982,t:1526328674544};\\\", \\\"{x:492,y:980,t:1526328674561};\\\", \\\"{x:492,y:977,t:1526328674577};\\\", \\\"{x:492,y:976,t:1526328674594};\\\", \\\"{x:491,y:974,t:1526328674611};\\\", \\\"{x:491,y:973,t:1526328674628};\\\", \\\"{x:490,y:973,t:1526328674644};\\\", \\\"{x:490,y:971,t:1526328674660};\\\", \\\"{x:489,y:969,t:1526328676765};\\\", \\\"{x:481,y:965,t:1526328676780};\\\", \\\"{x:474,y:962,t:1526328676795};\\\", \\\"{x:456,y:955,t:1526328676812};\\\", \\\"{x:423,y:943,t:1526328676829};\\\", \\\"{x:393,y:931,t:1526328676846};\\\", \\\"{x:363,y:915,t:1526328676862};\\\", \\\"{x:336,y:897,t:1526328676879};\\\", \\\"{x:311,y:876,t:1526328676896};\\\", \\\"{x:294,y:854,t:1526328676912};\\\", \\\"{x:274,y:825,t:1526328676930};\\\", \\\"{x:253,y:789,t:1526328676946};\\\", \\\"{x:235,y:757,t:1526328676962};\\\", \\\"{x:223,y:732,t:1526328676979};\\\", \\\"{x:215,y:714,t:1526328676996};\\\", \\\"{x:210,y:695,t:1526328677012};\\\", \\\"{x:208,y:670,t:1526328677029};\\\", \\\"{x:208,y:655,t:1526328677047};\\\", \\\"{x:208,y:640,t:1526328677061};\\\", \\\"{x:211,y:625,t:1526328677079};\\\", \\\"{x:218,y:610,t:1526328677096};\\\", \\\"{x:224,y:595,t:1526328677113};\\\", \\\"{x:233,y:578,t:1526328677130};\\\", \\\"{x:236,y:570,t:1526328677146};\\\", \\\"{x:243,y:559,t:1526328677163};\\\", \\\"{x:256,y:543,t:1526328677180};\\\", \\\"{x:271,y:532,t:1526328677197};\\\", \\\"{x:289,y:521,t:1526328677214};\\\", \\\"{x:312,y:512,t:1526328677230};\\\", \\\"{x:333,y:503,t:1526328677246};\\\", \\\"{x:365,y:496,t:1526328677263};\\\", \\\"{x:394,y:490,t:1526328677281};\\\", \\\"{x:434,y:484,t:1526328677297};\\\", \\\"{x:486,y:480,t:1526328677313};\\\", \\\"{x:559,y:478,t:1526328677329};\\\", \\\"{x:653,y:478,t:1526328677346};\\\", \\\"{x:772,y:478,t:1526328677364};\\\", \\\"{x:946,y:478,t:1526328677380};\\\", \\\"{x:1063,y:478,t:1526328677396};\\\", \\\"{x:1165,y:478,t:1526328677414};\\\", \\\"{x:1279,y:478,t:1526328677430};\\\", \\\"{x:1381,y:478,t:1526328677446};\\\", \\\"{x:1501,y:478,t:1526328677464};\\\", \\\"{x:1620,y:478,t:1526328677481};\\\", \\\"{x:1714,y:478,t:1526328677497};\\\", \\\"{x:1784,y:478,t:1526328677513};\\\", \\\"{x:1826,y:478,t:1526328677531};\\\", \\\"{x:1850,y:478,t:1526328677547};\\\", \\\"{x:1861,y:478,t:1526328677563};\\\", \\\"{x:1863,y:478,t:1526328677581};\\\", \\\"{x:1864,y:478,t:1526328677596};\\\", \\\"{x:1862,y:478,t:1526328677628};\\\", \\\"{x:1859,y:479,t:1526328677636};\\\", \\\"{x:1856,y:480,t:1526328677646};\\\", \\\"{x:1848,y:480,t:1526328677663};\\\", \\\"{x:1835,y:483,t:1526328677681};\\\", \\\"{x:1817,y:483,t:1526328677696};\\\", \\\"{x:1795,y:483,t:1526328677714};\\\", \\\"{x:1772,y:483,t:1526328677730};\\\", \\\"{x:1744,y:483,t:1526328677747};\\\", \\\"{x:1722,y:483,t:1526328677764};\\\", \\\"{x:1691,y:483,t:1526328677780};\\\", \\\"{x:1673,y:483,t:1526328677798};\\\", \\\"{x:1655,y:483,t:1526328677814};\\\", \\\"{x:1635,y:483,t:1526328677830};\\\", \\\"{x:1609,y:487,t:1526328677848};\\\", \\\"{x:1581,y:490,t:1526328677863};\\\", \\\"{x:1554,y:490,t:1526328677882};\\\", \\\"{x:1526,y:490,t:1526328677898};\\\", \\\"{x:1499,y:493,t:1526328677914};\\\", \\\"{x:1474,y:493,t:1526328677930};\\\", \\\"{x:1455,y:493,t:1526328677948};\\\", \\\"{x:1439,y:493,t:1526328677964};\\\", \\\"{x:1411,y:493,t:1526328677980};\\\", \\\"{x:1396,y:493,t:1526328677998};\\\", \\\"{x:1387,y:493,t:1526328678013};\\\", \\\"{x:1384,y:493,t:1526328678031};\\\", \\\"{x:1383,y:494,t:1526328678709};\\\", \\\"{x:1383,y:496,t:1526328678765};\\\", \\\"{x:1383,y:500,t:1526328680782};\\\", \\\"{x:1382,y:504,t:1526328680789};\\\", \\\"{x:1380,y:509,t:1526328680800};\\\", \\\"{x:1378,y:514,t:1526328680817};\\\", \\\"{x:1376,y:522,t:1526328680833};\\\", \\\"{x:1374,y:529,t:1526328680850};\\\", \\\"{x:1370,y:542,t:1526328680867};\\\", \\\"{x:1369,y:555,t:1526328680883};\\\", \\\"{x:1369,y:572,t:1526328680900};\\\", \\\"{x:1369,y:610,t:1526328680916};\\\", \\\"{x:1369,y:654,t:1526328680949};\\\", \\\"{x:1368,y:665,t:1526328680956};\\\", \\\"{x:1366,y:674,t:1526328680966};\\\", \\\"{x:1364,y:687,t:1526328680982};\\\", \\\"{x:1363,y:701,t:1526328681000};\\\", \\\"{x:1361,y:716,t:1526328681016};\\\", \\\"{x:1360,y:733,t:1526328681032};\\\", \\\"{x:1359,y:748,t:1526328681049};\\\", \\\"{x:1356,y:759,t:1526328681066};\\\", \\\"{x:1353,y:767,t:1526328681083};\\\", \\\"{x:1351,y:772,t:1526328681099};\\\", \\\"{x:1345,y:778,t:1526328681116};\\\", \\\"{x:1343,y:780,t:1526328681133};\\\", \\\"{x:1343,y:781,t:1526328681149};\\\", \\\"{x:1342,y:781,t:1526328681166};\\\", \\\"{x:1343,y:781,t:1526328681324};\\\", \\\"{x:1346,y:779,t:1526328681341};\\\", \\\"{x:1348,y:779,t:1526328681351};\\\", \\\"{x:1349,y:777,t:1526328681367};\\\", \\\"{x:1350,y:775,t:1526328681383};\\\", \\\"{x:1350,y:774,t:1526328681401};\\\", \\\"{x:1351,y:772,t:1526328681417};\\\", \\\"{x:1351,y:771,t:1526328681451};\\\", \\\"{x:1351,y:769,t:1526328681812};\\\", \\\"{x:1350,y:768,t:1526328681837};\\\", \\\"{x:1349,y:768,t:1526328682334};\\\", \\\"{x:1347,y:768,t:1526328685060};\\\", \\\"{x:1344,y:768,t:1526328685076};\\\", \\\"{x:1339,y:769,t:1526328685090};\\\", \\\"{x:1333,y:769,t:1526328685102};\\\", \\\"{x:1329,y:769,t:1526328685119};\\\", \\\"{x:1325,y:769,t:1526328685136};\\\", \\\"{x:1320,y:768,t:1526328685153};\\\", \\\"{x:1316,y:768,t:1526328685169};\\\", \\\"{x:1314,y:768,t:1526328685186};\\\", \\\"{x:1313,y:768,t:1526328685203};\\\", \\\"{x:1311,y:768,t:1526328685220};\\\", \\\"{x:1309,y:768,t:1526328685236};\\\", \\\"{x:1306,y:768,t:1526328685254};\\\", \\\"{x:1303,y:768,t:1526328685269};\\\", \\\"{x:1299,y:768,t:1526328685287};\\\", \\\"{x:1295,y:767,t:1526328685303};\\\", \\\"{x:1294,y:767,t:1526328685319};\\\", \\\"{x:1290,y:767,t:1526328685337};\\\", \\\"{x:1287,y:767,t:1526328685354};\\\", \\\"{x:1284,y:767,t:1526328685370};\\\", \\\"{x:1281,y:766,t:1526328685387};\\\", \\\"{x:1280,y:766,t:1526328685404};\\\", \\\"{x:1279,y:766,t:1526328685419};\\\", \\\"{x:1277,y:766,t:1526328685436};\\\", \\\"{x:1276,y:766,t:1526328685454};\\\", \\\"{x:1275,y:766,t:1526328685485};\\\", \\\"{x:1274,y:766,t:1526328685525};\\\", \\\"{x:1273,y:766,t:1526328685537};\\\", \\\"{x:1272,y:766,t:1526328685530};\\\", \\\"{x:1271,y:766,t:1526328685547};\\\", \\\"{x:1270,y:766,t:1526328685563};\\\", \\\"{x:1269,y:766,t:1526328685579};\\\", \\\"{x:1267,y:766,t:1526328685597};\\\", \\\"{x:1266,y:766,t:1526328685613};\\\", \\\"{x:1265,y:766,t:1526328685630};\\\", \\\"{x:1263,y:766,t:1526328685647};\\\", \\\"{x:1261,y:767,t:1526328685663};\\\", \\\"{x:1260,y:767,t:1526328685693};\\\", \\\"{x:1259,y:767,t:1526328685733};\\\", \\\"{x:1257,y:767,t:1526328685757};\\\", \\\"{x:1257,y:768,t:1526328685765};\\\", \\\"{x:1256,y:768,t:1526328685789};\\\", \\\"{x:1255,y:769,t:1526328685797};\\\", \\\"{x:1256,y:769,t:1526328686430};\\\", \\\"{x:1258,y:769,t:1526328686677};\\\", \\\"{x:1260,y:769,t:1526328686684};\\\", \\\"{x:1261,y:767,t:1526328686700};\\\", \\\"{x:1263,y:767,t:1526328686716};\\\", \\\"{x:1264,y:767,t:1526328686740};\\\", \\\"{x:1264,y:766,t:1526328686748};\\\", \\\"{x:1266,y:766,t:1526328686764};\\\", \\\"{x:1267,y:766,t:1526328686796};\\\", \\\"{x:1268,y:765,t:1526328686804};\\\", \\\"{x:1269,y:764,t:1526328686814};\\\", \\\"{x:1270,y:764,t:1526328686830};\\\", \\\"{x:1271,y:763,t:1526328686847};\\\", \\\"{x:1274,y:762,t:1526328686865};\\\", \\\"{x:1275,y:762,t:1526328686881};\\\", \\\"{x:1276,y:761,t:1526328686897};\\\", \\\"{x:1275,y:761,t:1526328687045};\\\", \\\"{x:1273,y:761,t:1526328687053};\\\", \\\"{x:1270,y:762,t:1526328687069};\\\", \\\"{x:1268,y:764,t:1526328687081};\\\", \\\"{x:1265,y:765,t:1526328687098};\\\", \\\"{x:1261,y:765,t:1526328687113};\\\", \\\"{x:1258,y:765,t:1526328687130};\\\", \\\"{x:1255,y:765,t:1526328687147};\\\", \\\"{x:1253,y:765,t:1526328687164};\\\", \\\"{x:1252,y:765,t:1526328687180};\\\", \\\"{x:1251,y:765,t:1526328687197};\\\", \\\"{x:1250,y:765,t:1526328687213};\\\", \\\"{x:1249,y:765,t:1526328687269};\\\", \\\"{x:1250,y:764,t:1526328689789};\\\", \\\"{x:1252,y:763,t:1526328689805};\\\", \\\"{x:1253,y:762,t:1526328689817};\\\", \\\"{x:1255,y:761,t:1526328689834};\\\", \\\"{x:1256,y:760,t:1526328689851};\\\", \\\"{x:1258,y:759,t:1526328689867};\\\", \\\"{x:1259,y:759,t:1526328689884};\\\", \\\"{x:1260,y:758,t:1526328689901};\\\", \\\"{x:1261,y:758,t:1526328689917};\\\", \\\"{x:1262,y:758,t:1526328689941};\\\", \\\"{x:1262,y:757,t:1526328689950};\\\", \\\"{x:1263,y:757,t:1526328689966};\\\", \\\"{x:1266,y:756,t:1526328689984};\\\", \\\"{x:1267,y:755,t:1526328690000};\\\", \\\"{x:1268,y:755,t:1526328690017};\\\", \\\"{x:1270,y:755,t:1526328690033};\\\", \\\"{x:1271,y:754,t:1526328690051};\\\", \\\"{x:1272,y:754,t:1526328690067};\\\", \\\"{x:1273,y:754,t:1526328690083};\\\", \\\"{x:1277,y:754,t:1526328690101};\\\", \\\"{x:1278,y:754,t:1526328690133};\\\", \\\"{x:1281,y:754,t:1526328690151};\\\", \\\"{x:1287,y:754,t:1526328690167};\\\", \\\"{x:1297,y:757,t:1526328690184};\\\", \\\"{x:1306,y:758,t:1526328690201};\\\", \\\"{x:1311,y:758,t:1526328690217};\\\", \\\"{x:1315,y:758,t:1526328690234};\\\", \\\"{x:1316,y:758,t:1526328690250};\\\", \\\"{x:1317,y:759,t:1526328690477};\\\", \\\"{x:1317,y:760,t:1526328690492};\\\", \\\"{x:1317,y:761,t:1526328690501};\\\", \\\"{x:1317,y:762,t:1526328690517};\\\", \\\"{x:1317,y:764,t:1526328690534};\\\", \\\"{x:1317,y:765,t:1526328690551};\\\", \\\"{x:1317,y:766,t:1526328690589};\\\", \\\"{x:1317,y:767,t:1526328690637};\\\", \\\"{x:1317,y:768,t:1526328690665};\\\", \\\"{x:1317,y:769,t:1526328690668};\\\", \\\"{x:1317,y:770,t:1526328690683};\\\", \\\"{x:1317,y:771,t:1526328690700};\\\", \\\"{x:1318,y:771,t:1526328691037};\\\", \\\"{x:1319,y:770,t:1526328691061};\\\", \\\"{x:1319,y:769,t:1526328691068};\\\", \\\"{x:1320,y:769,t:1526328691084};\\\", \\\"{x:1323,y:765,t:1526328691101};\\\", \\\"{x:1324,y:765,t:1526328691117};\\\", \\\"{x:1327,y:763,t:1526328691134};\\\", \\\"{x:1330,y:762,t:1526328691151};\\\", \\\"{x:1331,y:760,t:1526328691168};\\\", \\\"{x:1333,y:758,t:1526328691184};\\\", \\\"{x:1336,y:757,t:1526328691201};\\\", \\\"{x:1337,y:756,t:1526328691219};\\\", \\\"{x:1341,y:755,t:1526328691234};\\\", \\\"{x:1342,y:755,t:1526328691252};\\\", \\\"{x:1343,y:753,t:1526328691269};\\\", \\\"{x:1344,y:753,t:1526328691284};\\\", \\\"{x:1347,y:752,t:1526328691301};\\\", \\\"{x:1349,y:752,t:1526328691318};\\\", \\\"{x:1352,y:750,t:1526328691334};\\\", \\\"{x:1354,y:749,t:1526328691351};\\\", \\\"{x:1357,y:749,t:1526328691369};\\\", \\\"{x:1358,y:748,t:1526328691385};\\\", \\\"{x:1360,y:748,t:1526328691454};\\\", \\\"{x:1363,y:748,t:1526328691469};\\\", \\\"{x:1368,y:750,t:1526328691484};\\\", \\\"{x:1374,y:750,t:1526328691501};\\\", \\\"{x:1377,y:751,t:1526328691518};\\\", \\\"{x:1379,y:751,t:1526328691534};\\\", \\\"{x:1380,y:751,t:1526328691789};\\\", \\\"{x:1381,y:752,t:1526328691804};\\\", \\\"{x:1382,y:752,t:1526328691821};\\\", \\\"{x:1382,y:753,t:1526328691844};\\\", \\\"{x:1384,y:754,t:1526328691884};\\\", \\\"{x:1384,y:756,t:1526328692165};\\\", \\\"{x:1384,y:757,t:1526328692172};\\\", \\\"{x:1384,y:758,t:1526328692186};\\\", \\\"{x:1385,y:761,t:1526328692201};\\\", \\\"{x:1386,y:764,t:1526328692219};\\\", \\\"{x:1386,y:766,t:1526328692235};\\\", \\\"{x:1387,y:768,t:1526328692251};\\\", \\\"{x:1387,y:769,t:1526328692268};\\\", \\\"{x:1387,y:770,t:1526328692286};\\\", \\\"{x:1387,y:771,t:1526328692301};\\\", \\\"{x:1387,y:772,t:1526328692319};\\\", \\\"{x:1387,y:773,t:1526328692341};\\\", \\\"{x:1387,y:774,t:1526328692357};\\\", \\\"{x:1387,y:775,t:1526328692369};\\\", \\\"{x:1387,y:776,t:1526328692405};\\\", \\\"{x:1387,y:777,t:1526328692421};\\\", \\\"{x:1387,y:775,t:1526328695790};\\\", \\\"{x:1387,y:769,t:1526328695805};\\\", \\\"{x:1387,y:765,t:1526328695822};\\\", \\\"{x:1387,y:760,t:1526328695837};\\\", \\\"{x:1387,y:755,t:1526328695855};\\\", \\\"{x:1387,y:751,t:1526328695872};\\\", \\\"{x:1387,y:747,t:1526328695888};\\\", \\\"{x:1386,y:742,t:1526328695905};\\\", \\\"{x:1386,y:738,t:1526328695922};\\\", \\\"{x:1384,y:734,t:1526328695938};\\\", \\\"{x:1384,y:732,t:1526328695955};\\\", \\\"{x:1384,y:729,t:1526328695971};\\\", \\\"{x:1384,y:728,t:1526328695988};\\\", \\\"{x:1384,y:726,t:1526328696005};\\\", \\\"{x:1384,y:724,t:1526328696021};\\\", \\\"{x:1384,y:723,t:1526328696038};\\\", \\\"{x:1384,y:722,t:1526328696061};\\\", \\\"{x:1384,y:721,t:1526328696076};\\\", \\\"{x:1382,y:722,t:1526328697133};\\\", \\\"{x:1380,y:724,t:1526328697141};\\\", \\\"{x:1376,y:728,t:1526328697155};\\\", \\\"{x:1366,y:739,t:1526328697172};\\\", \\\"{x:1363,y:742,t:1526328697189};\\\", \\\"{x:1361,y:746,t:1526328697207};\\\", \\\"{x:1360,y:747,t:1526328697223};\\\", \\\"{x:1359,y:748,t:1526328697240};\\\", \\\"{x:1357,y:749,t:1526328697269};\\\", \\\"{x:1356,y:749,t:1526328697276};\\\", \\\"{x:1355,y:749,t:1526328697290};\\\", \\\"{x:1352,y:751,t:1526328697306};\\\", \\\"{x:1350,y:752,t:1526328697322};\\\", \\\"{x:1349,y:752,t:1526328697338};\\\", \\\"{x:1347,y:752,t:1526328697484};\\\", \\\"{x:1345,y:751,t:1526328697492};\\\", \\\"{x:1341,y:738,t:1526328697508};\\\", \\\"{x:1337,y:729,t:1526328697522};\\\", \\\"{x:1333,y:706,t:1526328697539};\\\", \\\"{x:1330,y:685,t:1526328697556};\\\", \\\"{x:1327,y:658,t:1526328697572};\\\", \\\"{x:1325,y:651,t:1526328697590};\\\", \\\"{x:1324,y:646,t:1526328697606};\\\", \\\"{x:1321,y:639,t:1526328697622};\\\", \\\"{x:1321,y:636,t:1526328697639};\\\", \\\"{x:1320,y:633,t:1526328697657};\\\", \\\"{x:1320,y:632,t:1526328697673};\\\", \\\"{x:1319,y:631,t:1526328697689};\\\", \\\"{x:1319,y:630,t:1526328697797};\\\", \\\"{x:1319,y:629,t:1526328697813};\\\", \\\"{x:1320,y:628,t:1526328697824};\\\", \\\"{x:1321,y:626,t:1526328697839};\\\", \\\"{x:1322,y:623,t:1526328697856};\\\", \\\"{x:1322,y:620,t:1526328697873};\\\", \\\"{x:1323,y:616,t:1526328697889};\\\", \\\"{x:1323,y:611,t:1526328697906};\\\", \\\"{x:1323,y:603,t:1526328697922};\\\", \\\"{x:1323,y:595,t:1526328697938};\\\", \\\"{x:1323,y:586,t:1526328697956};\\\", \\\"{x:1322,y:575,t:1526328697973};\\\", \\\"{x:1319,y:567,t:1526328697989};\\\", \\\"{x:1315,y:560,t:1526328698006};\\\", \\\"{x:1307,y:552,t:1526328698023};\\\", \\\"{x:1303,y:547,t:1526328698040};\\\", \\\"{x:1301,y:546,t:1526328698056};\\\", \\\"{x:1299,y:544,t:1526328698073};\\\", \\\"{x:1297,y:544,t:1526328698090};\\\", \\\"{x:1296,y:544,t:1526328698124};\\\", \\\"{x:1294,y:544,t:1526328698148};\\\", \\\"{x:1293,y:544,t:1526328698157};\\\", \\\"{x:1289,y:545,t:1526328698173};\\\", \\\"{x:1286,y:550,t:1526328698190};\\\", \\\"{x:1285,y:555,t:1526328698207};\\\", \\\"{x:1283,y:559,t:1526328698223};\\\", \\\"{x:1282,y:563,t:1526328698240};\\\", \\\"{x:1281,y:566,t:1526328698256};\\\", \\\"{x:1279,y:569,t:1526328698275};\\\", \\\"{x:1279,y:570,t:1526328698292};\\\", \\\"{x:1278,y:571,t:1526328698306};\\\", \\\"{x:1277,y:572,t:1526328698324};\\\", \\\"{x:1277,y:573,t:1526328698341};\\\", \\\"{x:1276,y:573,t:1526328698869};\\\", \\\"{x:1276,y:572,t:1526328698893};\\\", \\\"{x:1276,y:571,t:1526328698917};\\\", \\\"{x:1276,y:570,t:1526328698933};\\\", \\\"{x:1276,y:569,t:1526328698965};\\\", \\\"{x:1276,y:567,t:1526328699021};\\\", \\\"{x:1277,y:566,t:1526328699045};\\\", \\\"{x:1279,y:565,t:1526328699075};\\\", \\\"{x:1280,y:564,t:1526328699090};\\\", \\\"{x:1281,y:562,t:1526328699108};\\\", \\\"{x:1283,y:561,t:1526328699124};\\\", \\\"{x:1285,y:560,t:1526328699525};\\\", \\\"{x:1287,y:558,t:1526328699542};\\\", \\\"{x:1290,y:557,t:1526328699557};\\\", \\\"{x:1292,y:556,t:1526328699574};\\\", \\\"{x:1294,y:556,t:1526328699591};\\\", \\\"{x:1295,y:555,t:1526328699608};\\\", \\\"{x:1297,y:554,t:1526328699624};\\\", \\\"{x:1299,y:553,t:1526328699641};\\\", \\\"{x:1301,y:553,t:1526328699659};\\\", \\\"{x:1301,y:552,t:1526328699676};\\\", \\\"{x:1302,y:552,t:1526328699691};\\\", \\\"{x:1306,y:552,t:1526328699707};\\\", \\\"{x:1307,y:552,t:1526328699723};\\\", \\\"{x:1308,y:552,t:1526328699741};\\\", \\\"{x:1309,y:552,t:1526328699758};\\\", \\\"{x:1312,y:552,t:1526328699774};\\\", \\\"{x:1317,y:552,t:1526328699791};\\\", \\\"{x:1322,y:552,t:1526328699808};\\\", \\\"{x:1326,y:552,t:1526328699824};\\\", \\\"{x:1333,y:552,t:1526328699841};\\\", \\\"{x:1339,y:554,t:1526328699858};\\\", \\\"{x:1347,y:555,t:1526328699875};\\\", \\\"{x:1356,y:556,t:1526328699891};\\\", \\\"{x:1367,y:558,t:1526328699908};\\\", \\\"{x:1368,y:558,t:1526328699932};\\\", \\\"{x:1369,y:559,t:1526328700036};\\\", \\\"{x:1369,y:560,t:1526328700045};\\\", \\\"{x:1368,y:562,t:1526328700059};\\\", \\\"{x:1363,y:563,t:1526328700076};\\\", \\\"{x:1357,y:565,t:1526328700092};\\\", \\\"{x:1353,y:567,t:1526328700108};\\\", \\\"{x:1352,y:568,t:1526328700124};\\\", \\\"{x:1353,y:568,t:1526328700349};\\\", \\\"{x:1355,y:567,t:1526328700363};\\\", \\\"{x:1361,y:564,t:1526328700378};\\\", \\\"{x:1365,y:561,t:1526328700391};\\\", \\\"{x:1367,y:559,t:1526328700408};\\\", \\\"{x:1369,y:559,t:1526328700425};\\\", \\\"{x:1370,y:558,t:1526328700441};\\\", \\\"{x:1371,y:558,t:1526328700458};\\\", \\\"{x:1373,y:557,t:1526328700476};\\\", \\\"{x:1374,y:556,t:1526328700500};\\\", \\\"{x:1376,y:556,t:1526328700516};\\\", \\\"{x:1377,y:556,t:1526328700525};\\\", \\\"{x:1378,y:555,t:1526328700548};\\\", \\\"{x:1378,y:554,t:1526328700573};\\\", \\\"{x:1379,y:554,t:1526328700581};\\\", \\\"{x:1380,y:554,t:1526328700592};\\\", \\\"{x:1383,y:554,t:1526328700608};\\\", \\\"{x:1385,y:553,t:1526328700626};\\\", \\\"{x:1387,y:553,t:1526328700642};\\\", \\\"{x:1389,y:552,t:1526328700658};\\\", \\\"{x:1391,y:552,t:1526328700675};\\\", \\\"{x:1397,y:552,t:1526328700692};\\\", \\\"{x:1403,y:552,t:1526328700708};\\\", \\\"{x:1410,y:552,t:1526328700725};\\\", \\\"{x:1412,y:552,t:1526328700742};\\\", \\\"{x:1414,y:552,t:1526328700758};\\\", \\\"{x:1417,y:552,t:1526328700775};\\\", \\\"{x:1418,y:552,t:1526328700792};\\\", \\\"{x:1419,y:552,t:1526328700861};\\\", \\\"{x:1419,y:553,t:1526328700877};\\\", \\\"{x:1421,y:555,t:1526328700893};\\\", \\\"{x:1421,y:556,t:1526328700916};\\\", \\\"{x:1421,y:558,t:1526328700925};\\\", \\\"{x:1421,y:561,t:1526328700942};\\\", \\\"{x:1421,y:564,t:1526328700960};\\\", \\\"{x:1421,y:565,t:1526328700976};\\\", \\\"{x:1420,y:568,t:1526328700992};\\\", \\\"{x:1420,y:569,t:1526328701020};\\\", \\\"{x:1420,y:568,t:1526328701157};\\\", \\\"{x:1422,y:566,t:1526328701165};\\\", \\\"{x:1426,y:563,t:1526328701180};\\\", \\\"{x:1427,y:563,t:1526328701193};\\\", \\\"{x:1431,y:560,t:1526328701209};\\\", \\\"{x:1433,y:559,t:1526328701226};\\\", \\\"{x:1437,y:557,t:1526328701243};\\\", \\\"{x:1439,y:556,t:1526328701259};\\\", \\\"{x:1440,y:556,t:1526328701276};\\\", \\\"{x:1441,y:555,t:1526328701293};\\\", \\\"{x:1443,y:555,t:1526328701309};\\\", \\\"{x:1444,y:554,t:1526328701325};\\\", \\\"{x:1445,y:553,t:1526328701342};\\\", \\\"{x:1446,y:553,t:1526328701397};\\\", \\\"{x:1448,y:553,t:1526328701409};\\\", \\\"{x:1452,y:553,t:1526328701426};\\\", \\\"{x:1456,y:553,t:1526328701442};\\\", \\\"{x:1460,y:553,t:1526328701459};\\\", \\\"{x:1463,y:553,t:1526328701476};\\\", \\\"{x:1466,y:553,t:1526328701492};\\\", \\\"{x:1468,y:554,t:1526328701509};\\\", \\\"{x:1472,y:554,t:1526328701526};\\\", \\\"{x:1474,y:555,t:1526328701543};\\\", \\\"{x:1479,y:557,t:1526328701559};\\\", \\\"{x:1486,y:558,t:1526328701576};\\\", \\\"{x:1490,y:558,t:1526328701592};\\\", \\\"{x:1491,y:559,t:1526328701676};\\\", \\\"{x:1491,y:560,t:1526328701716};\\\", \\\"{x:1491,y:561,t:1526328701739};\\\", \\\"{x:1491,y:563,t:1526328701756};\\\", \\\"{x:1490,y:564,t:1526328701772};\\\", \\\"{x:1488,y:565,t:1526328701787};\\\", \\\"{x:1487,y:565,t:1526328701795};\\\", \\\"{x:1486,y:565,t:1526328701809};\\\", \\\"{x:1485,y:566,t:1526328701826};\\\", \\\"{x:1486,y:566,t:1526328701964};\\\", \\\"{x:1491,y:565,t:1526328701980};\\\", \\\"{x:1493,y:564,t:1526328701993};\\\", \\\"{x:1496,y:562,t:1526328702010};\\\", \\\"{x:1501,y:561,t:1526328702027};\\\", \\\"{x:1504,y:559,t:1526328702043};\\\", \\\"{x:1505,y:559,t:1526328702061};\\\", \\\"{x:1506,y:559,t:1526328702077};\\\", \\\"{x:1507,y:559,t:1526328702124};\\\", \\\"{x:1508,y:559,t:1526328702132};\\\", \\\"{x:1509,y:559,t:1526328702143};\\\", \\\"{x:1510,y:559,t:1526328702160};\\\", \\\"{x:1514,y:559,t:1526328702177};\\\", \\\"{x:1520,y:559,t:1526328702193};\\\", \\\"{x:1526,y:559,t:1526328702211};\\\", \\\"{x:1532,y:560,t:1526328702227};\\\", \\\"{x:1541,y:561,t:1526328702243};\\\", \\\"{x:1552,y:561,t:1526328702260};\\\", \\\"{x:1561,y:564,t:1526328702277};\\\", \\\"{x:1566,y:564,t:1526328702293};\\\", \\\"{x:1569,y:564,t:1526328702309};\\\", \\\"{x:1570,y:564,t:1526328702380};\\\", \\\"{x:1570,y:565,t:1526328702460};\\\", \\\"{x:1568,y:565,t:1526328702476};\\\", \\\"{x:1565,y:565,t:1526328702494};\\\", \\\"{x:1559,y:565,t:1526328702510};\\\", \\\"{x:1555,y:565,t:1526328702526};\\\", \\\"{x:1553,y:566,t:1526328702544};\\\", \\\"{x:1554,y:567,t:1526328702853};\\\", \\\"{x:1559,y:567,t:1526328702859};\\\", \\\"{x:1567,y:566,t:1526328702877};\\\", \\\"{x:1578,y:565,t:1526328702894};\\\", \\\"{x:1584,y:563,t:1526328702910};\\\", \\\"{x:1586,y:563,t:1526328702926};\\\", \\\"{x:1587,y:563,t:1526328702988};\\\", \\\"{x:1589,y:563,t:1526328703004};\\\", \\\"{x:1590,y:563,t:1526328703012};\\\", \\\"{x:1591,y:563,t:1526328703027};\\\", \\\"{x:1593,y:563,t:1526328703044};\\\", \\\"{x:1595,y:564,t:1526328703125};\\\", \\\"{x:1598,y:564,t:1526328703132};\\\", \\\"{x:1609,y:568,t:1526328703149};\\\", \\\"{x:1617,y:569,t:1526328703161};\\\", \\\"{x:1626,y:569,t:1526328703178};\\\", \\\"{x:1633,y:570,t:1526328703194};\\\", \\\"{x:1635,y:570,t:1526328703211};\\\", \\\"{x:1638,y:570,t:1526328703437};\\\", \\\"{x:1640,y:570,t:1526328703444};\\\", \\\"{x:1646,y:568,t:1526328703461};\\\", \\\"{x:1655,y:566,t:1526328703478};\\\", \\\"{x:1665,y:561,t:1526328703494};\\\", \\\"{x:1675,y:557,t:1526328703511};\\\", \\\"{x:1682,y:554,t:1526328703528};\\\", \\\"{x:1683,y:554,t:1526328703544};\\\", \\\"{x:1684,y:554,t:1526328703636};\\\", \\\"{x:1685,y:553,t:1526328703652};\\\", \\\"{x:1685,y:554,t:1526328704605};\\\", \\\"{x:1683,y:555,t:1526328704613};\\\", \\\"{x:1682,y:556,t:1526328704632};\\\", \\\"{x:1678,y:557,t:1526328704646};\\\", \\\"{x:1675,y:558,t:1526328704662};\\\", \\\"{x:1671,y:560,t:1526328704679};\\\", \\\"{x:1670,y:561,t:1526328704695};\\\", \\\"{x:1667,y:562,t:1526328704712};\\\", \\\"{x:1665,y:562,t:1526328704728};\\\", \\\"{x:1662,y:563,t:1526328704745};\\\", \\\"{x:1658,y:565,t:1526328704762};\\\", \\\"{x:1652,y:567,t:1526328704778};\\\", \\\"{x:1645,y:569,t:1526328704795};\\\", \\\"{x:1623,y:570,t:1526328704812};\\\", \\\"{x:1606,y:573,t:1526328704828};\\\", \\\"{x:1584,y:575,t:1526328704845};\\\", \\\"{x:1559,y:579,t:1526328704862};\\\", \\\"{x:1532,y:581,t:1526328704878};\\\", \\\"{x:1507,y:583,t:1526328704895};\\\", \\\"{x:1480,y:583,t:1526328704912};\\\", \\\"{x:1450,y:583,t:1526328704928};\\\", \\\"{x:1423,y:583,t:1526328704945};\\\", \\\"{x:1393,y:583,t:1526328704962};\\\", \\\"{x:1370,y:583,t:1526328704978};\\\", \\\"{x:1346,y:583,t:1526328704995};\\\", \\\"{x:1312,y:584,t:1526328705012};\\\", \\\"{x:1295,y:584,t:1526328705028};\\\", \\\"{x:1282,y:585,t:1526328705045};\\\", \\\"{x:1271,y:585,t:1526328705062};\\\", \\\"{x:1263,y:585,t:1526328705078};\\\", \\\"{x:1257,y:585,t:1526328705096};\\\", \\\"{x:1254,y:585,t:1526328705112};\\\", \\\"{x:1253,y:585,t:1526328705129};\\\", \\\"{x:1252,y:585,t:1526328705236};\\\", \\\"{x:1261,y:577,t:1526328705252};\\\", \\\"{x:1269,y:572,t:1526328705262};\\\", \\\"{x:1283,y:565,t:1526328705279};\\\", \\\"{x:1290,y:562,t:1526328705297};\\\", \\\"{x:1293,y:560,t:1526328705311};\\\", \\\"{x:1290,y:560,t:1526328705516};\\\", \\\"{x:1286,y:561,t:1526328705532};\\\", \\\"{x:1285,y:562,t:1526328705546};\\\", \\\"{x:1278,y:565,t:1526328705562};\\\", \\\"{x:1274,y:566,t:1526328705579};\\\", \\\"{x:1273,y:567,t:1526328705596};\\\", \\\"{x:1272,y:567,t:1526328705612};\\\", \\\"{x:1271,y:569,t:1526328707237};\\\", \\\"{x:1254,y:569,t:1526328707252};\\\", \\\"{x:1239,y:569,t:1526328707264};\\\", \\\"{x:1201,y:569,t:1526328707281};\\\", \\\"{x:1148,y:569,t:1526328707297};\\\", \\\"{x:1067,y:569,t:1526328707314};\\\", \\\"{x:1000,y:569,t:1526328707331};\\\", \\\"{x:939,y:569,t:1526328707349};\\\", \\\"{x:861,y:569,t:1526328707364};\\\", \\\"{x:816,y:562,t:1526328707381};\\\", \\\"{x:785,y:560,t:1526328707398};\\\", \\\"{x:756,y:556,t:1526328707414};\\\", \\\"{x:738,y:553,t:1526328707431};\\\", \\\"{x:731,y:550,t:1526328707447};\\\", \\\"{x:728,y:548,t:1526328707465};\\\", \\\"{x:722,y:544,t:1526328707481};\\\", \\\"{x:716,y:540,t:1526328707498};\\\", \\\"{x:709,y:535,t:1526328707515};\\\", \\\"{x:703,y:527,t:1526328707530};\\\", \\\"{x:690,y:513,t:1526328707548};\\\", \\\"{x:675,y:507,t:1526328707565};\\\", \\\"{x:655,y:500,t:1526328707581};\\\", \\\"{x:635,y:496,t:1526328707597};\\\", \\\"{x:616,y:493,t:1526328707614};\\\", \\\"{x:603,y:491,t:1526328707632};\\\", \\\"{x:592,y:490,t:1526328707648};\\\", \\\"{x:589,y:489,t:1526328707664};\\\", \\\"{x:588,y:488,t:1526328707681};\\\", \\\"{x:589,y:489,t:1526328707853};\\\", \\\"{x:592,y:491,t:1526328707868};\\\", \\\"{x:594,y:492,t:1526328707882};\\\", \\\"{x:596,y:492,t:1526328707898};\\\", \\\"{x:599,y:494,t:1526328707915};\\\", \\\"{x:600,y:496,t:1526328707933};\\\", \\\"{x:601,y:496,t:1526328707956};\\\", \\\"{x:601,y:497,t:1526328708004};\\\", \\\"{x:602,y:498,t:1526328708044};\\\", \\\"{x:603,y:498,t:1526328708052};\\\", \\\"{x:603,y:500,t:1526328708076};\\\", \\\"{x:604,y:501,t:1526328708091};\\\", \\\"{x:606,y:502,t:1526328708107};\\\", \\\"{x:607,y:503,t:1526328708124};\\\", \\\"{x:608,y:503,t:1526328708147};\\\", \\\"{x:608,y:507,t:1526328708428};\\\", \\\"{x:608,y:514,t:1526328708436};\\\", \\\"{x:608,y:522,t:1526328708448};\\\", \\\"{x:606,y:536,t:1526328708465};\\\", \\\"{x:606,y:550,t:1526328708482};\\\", \\\"{x:606,y:564,t:1526328708498};\\\", \\\"{x:606,y:573,t:1526328708515};\\\", \\\"{x:603,y:585,t:1526328708531};\\\", \\\"{x:601,y:591,t:1526328708548};\\\", \\\"{x:601,y:595,t:1526328708565};\\\", \\\"{x:600,y:601,t:1526328708582};\\\", \\\"{x:599,y:606,t:1526328708599};\\\", \\\"{x:598,y:612,t:1526328708615};\\\", \\\"{x:596,y:620,t:1526328708631};\\\", \\\"{x:592,y:629,t:1526328708649};\\\", \\\"{x:589,y:638,t:1526328708665};\\\", \\\"{x:584,y:647,t:1526328708682};\\\", \\\"{x:580,y:653,t:1526328708699};\\\", \\\"{x:578,y:658,t:1526328708715};\\\", \\\"{x:574,y:664,t:1526328708732};\\\", \\\"{x:572,y:667,t:1526328708749};\\\", \\\"{x:571,y:670,t:1526328708765};\\\", \\\"{x:568,y:675,t:1526328708782};\\\", \\\"{x:565,y:679,t:1526328708799};\\\", \\\"{x:563,y:682,t:1526328708815};\\\", \\\"{x:560,y:688,t:1526328708832};\\\", \\\"{x:559,y:691,t:1526328708849};\\\", \\\"{x:556,y:694,t:1526328708866};\\\", \\\"{x:556,y:697,t:1526328708882};\\\", \\\"{x:555,y:700,t:1526328708899};\\\", \\\"{x:550,y:707,t:1526328708915};\\\", \\\"{x:546,y:712,t:1526328708932};\\\", \\\"{x:543,y:716,t:1526328708950};\\\", \\\"{x:538,y:720,t:1526328708967};\\\", \\\"{x:533,y:723,t:1526328708982};\\\", \\\"{x:529,y:725,t:1526328708999};\\\", \\\"{x:527,y:727,t:1526328709015};\\\", \\\"{x:524,y:728,t:1526328709032};\\\", \\\"{x:520,y:730,t:1526328709049};\\\", \\\"{x:517,y:731,t:1526328709064};\\\", \\\"{x:516,y:732,t:1526328709082};\\\", \\\"{x:513,y:733,t:1526328709099};\\\", \\\"{x:512,y:733,t:1526328709220};\\\", \\\"{x:512,y:732,t:1526328709660};\\\", \\\"{x:512,y:731,t:1526328709668};\\\", \\\"{x:512,y:730,t:1526328709692};\\\", \\\"{x:512,y:728,t:1526328709699};\\\", \\\"{x:512,y:726,t:1526328709715};\\\", \\\"{x:512,y:723,t:1526328709733};\\\", \\\"{x:512,y:722,t:1526328709748};\\\", \\\"{x:512,y:721,t:1526328710205};\\\", \\\"{x:509,y:721,t:1526328710220};\\\", \\\"{x:504,y:720,t:1526328710233};\\\", \\\"{x:487,y:718,t:1526328710249};\\\", \\\"{x:473,y:716,t:1526328710267};\\\", \\\"{x:467,y:715,t:1526328710283};\\\", \\\"{x:458,y:714,t:1526328710299};\\\", \\\"{x:455,y:713,t:1526328710317};\\\", \\\"{x:453,y:713,t:1526328710333};\\\", \\\"{x:452,y:712,t:1526328710453};\\\", \\\"{x:450,y:712,t:1526328710522};\\\" ] }, { \\\"rt\\\": 37000, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 601644, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -B -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:449,y:712,t:1526328710774};\\\", \\\"{x:448,y:712,t:1526328710802};\\\", \\\"{x:447,y:712,t:1526328711052};\\\", \\\"{x:445,y:712,t:1526328711075};\\\", \\\"{x:443,y:712,t:1526328711092};\\\", \\\"{x:439,y:713,t:1526328711190};\\\", \\\"{x:440,y:713,t:1526328712293};\\\", \\\"{x:442,y:713,t:1526328712304};\\\", \\\"{x:445,y:714,t:1526328712320};\\\", \\\"{x:446,y:714,t:1526328712334};\\\", \\\"{x:448,y:714,t:1526328712351};\\\", \\\"{x:450,y:715,t:1526328712368};\\\", \\\"{x:452,y:715,t:1526328712384};\\\", \\\"{x:459,y:716,t:1526328712401};\\\", \\\"{x:467,y:717,t:1526328712419};\\\", \\\"{x:477,y:718,t:1526328712435};\\\", \\\"{x:498,y:722,t:1526328712452};\\\", \\\"{x:511,y:725,t:1526328712469};\\\", \\\"{x:523,y:726,t:1526328712484};\\\", \\\"{x:534,y:728,t:1526328712501};\\\", \\\"{x:551,y:730,t:1526328712519};\\\", \\\"{x:569,y:732,t:1526328712535};\\\", \\\"{x:591,y:735,t:1526328712552};\\\", \\\"{x:612,y:737,t:1526328712569};\\\", \\\"{x:633,y:743,t:1526328712585};\\\", \\\"{x:653,y:746,t:1526328712602};\\\", \\\"{x:673,y:748,t:1526328712619};\\\", \\\"{x:705,y:753,t:1526328712636};\\\", \\\"{x:724,y:755,t:1526328712651};\\\", \\\"{x:742,y:758,t:1526328712669};\\\", \\\"{x:757,y:760,t:1526328712686};\\\", \\\"{x:769,y:760,t:1526328712702};\\\", \\\"{x:776,y:760,t:1526328712718};\\\", \\\"{x:780,y:760,t:1526328712735};\\\", \\\"{x:784,y:760,t:1526328712752};\\\", \\\"{x:786,y:760,t:1526328712769};\\\", \\\"{x:788,y:760,t:1526328712785};\\\", \\\"{x:787,y:760,t:1526328713476};\\\", \\\"{x:786,y:760,t:1526328713500};\\\", \\\"{x:785,y:760,t:1526328713507};\\\", \\\"{x:784,y:760,t:1526328713519};\\\", \\\"{x:783,y:760,t:1526328713536};\\\", \\\"{x:781,y:760,t:1526328713553};\\\", \\\"{x:780,y:760,t:1526328713571};\\\", \\\"{x:779,y:760,t:1526328713586};\\\", \\\"{x:778,y:760,t:1526328713602};\\\", \\\"{x:776,y:761,t:1526328713619};\\\", \\\"{x:775,y:761,t:1526328713635};\\\", \\\"{x:773,y:761,t:1526328713652};\\\", \\\"{x:771,y:762,t:1526328713669};\\\", \\\"{x:770,y:762,t:1526328713686};\\\", \\\"{x:768,y:762,t:1526328713703};\\\", \\\"{x:767,y:762,t:1526328713739};\\\", \\\"{x:770,y:763,t:1526328714965};\\\", \\\"{x:773,y:763,t:1526328714972};\\\", \\\"{x:786,y:766,t:1526328714988};\\\", \\\"{x:803,y:768,t:1526328715004};\\\", \\\"{x:823,y:771,t:1526328715020};\\\", \\\"{x:845,y:773,t:1526328715038};\\\", \\\"{x:867,y:778,t:1526328715054};\\\", \\\"{x:894,y:780,t:1526328715071};\\\", \\\"{x:925,y:785,t:1526328715087};\\\", \\\"{x:965,y:790,t:1526328715104};\\\", \\\"{x:1007,y:798,t:1526328715121};\\\", \\\"{x:1045,y:800,t:1526328715137};\\\", \\\"{x:1073,y:802,t:1526328715155};\\\", \\\"{x:1101,y:804,t:1526328715171};\\\", \\\"{x:1126,y:804,t:1526328715188};\\\", \\\"{x:1152,y:805,t:1526328715204};\\\", \\\"{x:1164,y:805,t:1526328715221};\\\", \\\"{x:1175,y:805,t:1526328715237};\\\", \\\"{x:1180,y:805,t:1526328715254};\\\", \\\"{x:1185,y:805,t:1526328715273};\\\", \\\"{x:1193,y:805,t:1526328715288};\\\", \\\"{x:1202,y:804,t:1526328715305};\\\", \\\"{x:1220,y:802,t:1526328715321};\\\", \\\"{x:1237,y:801,t:1526328715338};\\\", \\\"{x:1255,y:797,t:1526328715354};\\\", \\\"{x:1266,y:796,t:1526328715371};\\\", \\\"{x:1276,y:795,t:1526328715388};\\\", \\\"{x:1286,y:793,t:1526328715404};\\\", \\\"{x:1293,y:792,t:1526328715421};\\\", \\\"{x:1296,y:791,t:1526328715437};\\\", \\\"{x:1298,y:790,t:1526328715455};\\\", \\\"{x:1300,y:789,t:1526328715472};\\\", \\\"{x:1304,y:788,t:1526328715488};\\\", \\\"{x:1311,y:787,t:1526328715505};\\\", \\\"{x:1321,y:786,t:1526328715522};\\\", \\\"{x:1337,y:783,t:1526328715538};\\\", \\\"{x:1355,y:780,t:1526328715555};\\\", \\\"{x:1373,y:775,t:1526328715571};\\\", \\\"{x:1400,y:768,t:1526328715588};\\\", \\\"{x:1436,y:756,t:1526328715604};\\\", \\\"{x:1456,y:751,t:1526328715622};\\\", \\\"{x:1466,y:747,t:1526328715638};\\\", \\\"{x:1471,y:746,t:1526328715655};\\\", \\\"{x:1473,y:745,t:1526328715672};\\\", \\\"{x:1469,y:745,t:1526328715716};\\\", \\\"{x:1459,y:748,t:1526328715724};\\\", \\\"{x:1449,y:754,t:1526328715738};\\\", \\\"{x:1430,y:762,t:1526328715755};\\\", \\\"{x:1398,y:779,t:1526328715772};\\\", \\\"{x:1376,y:791,t:1526328715788};\\\", \\\"{x:1352,y:801,t:1526328715804};\\\", \\\"{x:1329,y:810,t:1526328715821};\\\", \\\"{x:1312,y:816,t:1526328715838};\\\", \\\"{x:1295,y:820,t:1526328715855};\\\", \\\"{x:1282,y:823,t:1526328715872};\\\", \\\"{x:1278,y:826,t:1526328715889};\\\", \\\"{x:1277,y:827,t:1526328715905};\\\", \\\"{x:1276,y:827,t:1526328715922};\\\", \\\"{x:1275,y:828,t:1526328715939};\\\", \\\"{x:1271,y:829,t:1526328715955};\\\", \\\"{x:1257,y:833,t:1526328715973};\\\", \\\"{x:1248,y:834,t:1526328715988};\\\", \\\"{x:1241,y:835,t:1526328716004};\\\", \\\"{x:1236,y:837,t:1526328716022};\\\", \\\"{x:1231,y:837,t:1526328716039};\\\", \\\"{x:1225,y:837,t:1526328716055};\\\", \\\"{x:1218,y:837,t:1526328716072};\\\", \\\"{x:1209,y:837,t:1526328716089};\\\", \\\"{x:1201,y:837,t:1526328716105};\\\", \\\"{x:1195,y:837,t:1526328716122};\\\", \\\"{x:1193,y:837,t:1526328716139};\\\", \\\"{x:1194,y:837,t:1526328716260};\\\", \\\"{x:1198,y:837,t:1526328716276};\\\", \\\"{x:1200,y:837,t:1526328716289};\\\", \\\"{x:1206,y:836,t:1526328716305};\\\", \\\"{x:1209,y:834,t:1526328716322};\\\", \\\"{x:1210,y:833,t:1526328716342};\\\", \\\"{x:1211,y:833,t:1526328716354};\\\", \\\"{x:1212,y:833,t:1526328716428};\\\", \\\"{x:1213,y:833,t:1526328716563};\\\", \\\"{x:1215,y:832,t:1526328717069};\\\", \\\"{x:1216,y:830,t:1526328717076};\\\", \\\"{x:1217,y:830,t:1526328717092};\\\", \\\"{x:1215,y:830,t:1526328718708};\\\", \\\"{x:1215,y:831,t:1526328718755};\\\", \\\"{x:1214,y:831,t:1526328718803};\\\", \\\"{x:1213,y:831,t:1526328721164};\\\", \\\"{x:1212,y:832,t:1526328723300};\\\", \\\"{x:1211,y:833,t:1526328723323};\\\", \\\"{x:1210,y:834,t:1526328723342};\\\", \\\"{x:1209,y:834,t:1526328723364};\\\", \\\"{x:1208,y:834,t:1526328723404};\\\", \\\"{x:1207,y:836,t:1526328723428};\\\", \\\"{x:1205,y:836,t:1526328723452};\\\", \\\"{x:1205,y:837,t:1526328723508};\\\", \\\"{x:1204,y:837,t:1526328723526};\\\", \\\"{x:1202,y:837,t:1526328723544};\\\", \\\"{x:1201,y:838,t:1526328723560};\\\", \\\"{x:1200,y:838,t:1526328723579};\\\", \\\"{x:1199,y:838,t:1526328723603};\\\", \\\"{x:1197,y:838,t:1526328723635};\\\", \\\"{x:1196,y:838,t:1526328724020};\\\", \\\"{x:1194,y:838,t:1526328725596};\\\", \\\"{x:1188,y:836,t:1526328725620};\\\", \\\"{x:1186,y:836,t:1526328725629};\\\", \\\"{x:1182,y:834,t:1526328725646};\\\", \\\"{x:1179,y:833,t:1526328725662};\\\", \\\"{x:1178,y:832,t:1526328725678};\\\", \\\"{x:1176,y:832,t:1526328725699};\\\", \\\"{x:1174,y:830,t:1526328725941};\\\", \\\"{x:1171,y:828,t:1526328725949};\\\", \\\"{x:1164,y:824,t:1526328725964};\\\", \\\"{x:1162,y:822,t:1526328725979};\\\", \\\"{x:1159,y:820,t:1526328725997};\\\", \\\"{x:1158,y:820,t:1526328726285};\\\", \\\"{x:1156,y:820,t:1526328726296};\\\", \\\"{x:1155,y:820,t:1526328726313};\\\", \\\"{x:1152,y:820,t:1526328726331};\\\", \\\"{x:1152,y:821,t:1526328726346};\\\", \\\"{x:1151,y:822,t:1526328726363};\\\", \\\"{x:1150,y:823,t:1526328726381};\\\", \\\"{x:1150,y:822,t:1526328735292};\\\", \\\"{x:1150,y:820,t:1526328735305};\\\", \\\"{x:1150,y:819,t:1526328735321};\\\", \\\"{x:1150,y:818,t:1526328735337};\\\", \\\"{x:1150,y:816,t:1526328735354};\\\", \\\"{x:1150,y:815,t:1526328735371};\\\", \\\"{x:1150,y:813,t:1526328735387};\\\", \\\"{x:1150,y:812,t:1526328735404};\\\", \\\"{x:1151,y:810,t:1526328735421};\\\", \\\"{x:1151,y:809,t:1526328735451};\\\", \\\"{x:1152,y:808,t:1526328735476};\\\", \\\"{x:1152,y:807,t:1526328735508};\\\", \\\"{x:1153,y:805,t:1526328735524};\\\", \\\"{x:1154,y:805,t:1526328735537};\\\", \\\"{x:1155,y:803,t:1526328735553};\\\", \\\"{x:1155,y:802,t:1526328735571};\\\", \\\"{x:1156,y:801,t:1526328735588};\\\", \\\"{x:1158,y:799,t:1526328735604};\\\", \\\"{x:1159,y:798,t:1526328735621};\\\", \\\"{x:1160,y:798,t:1526328735644};\\\", \\\"{x:1161,y:797,t:1526328735659};\\\", \\\"{x:1162,y:797,t:1526328735708};\\\", \\\"{x:1162,y:796,t:1526328736220};\\\", \\\"{x:1162,y:795,t:1526328736228};\\\", \\\"{x:1162,y:793,t:1526328736250};\\\", \\\"{x:1163,y:792,t:1526328736259};\\\", \\\"{x:1163,y:791,t:1526328736275};\\\", \\\"{x:1163,y:789,t:1526328736287};\\\", \\\"{x:1163,y:787,t:1526328736304};\\\", \\\"{x:1164,y:785,t:1526328736321};\\\", \\\"{x:1164,y:784,t:1526328736337};\\\", \\\"{x:1164,y:782,t:1526328736354};\\\", \\\"{x:1165,y:779,t:1526328736371};\\\", \\\"{x:1165,y:776,t:1526328736387};\\\", \\\"{x:1165,y:773,t:1526328736404};\\\", \\\"{x:1166,y:772,t:1526328736421};\\\", \\\"{x:1166,y:771,t:1526328736443};\\\", \\\"{x:1167,y:769,t:1526328736454};\\\", \\\"{x:1168,y:769,t:1526328736471};\\\", \\\"{x:1168,y:767,t:1526328736488};\\\", \\\"{x:1169,y:764,t:1526328736505};\\\", \\\"{x:1171,y:763,t:1526328736522};\\\", \\\"{x:1171,y:762,t:1526328736540};\\\", \\\"{x:1172,y:762,t:1526328736564};\\\", \\\"{x:1174,y:762,t:1526328736989};\\\", \\\"{x:1177,y:760,t:1526328737011};\\\", \\\"{x:1179,y:759,t:1526328737021};\\\", \\\"{x:1180,y:759,t:1526328737038};\\\", \\\"{x:1181,y:758,t:1526328737054};\\\", \\\"{x:1184,y:757,t:1526328737071};\\\", \\\"{x:1187,y:756,t:1526328737089};\\\", \\\"{x:1188,y:756,t:1526328737104};\\\", \\\"{x:1191,y:754,t:1526328737122};\\\", \\\"{x:1195,y:752,t:1526328737138};\\\", \\\"{x:1198,y:752,t:1526328737154};\\\", \\\"{x:1207,y:752,t:1526328737171};\\\", \\\"{x:1213,y:752,t:1526328737189};\\\", \\\"{x:1217,y:752,t:1526328737205};\\\", \\\"{x:1220,y:752,t:1526328737222};\\\", \\\"{x:1221,y:752,t:1526328737238};\\\", \\\"{x:1222,y:752,t:1526328737254};\\\", \\\"{x:1226,y:753,t:1526328737272};\\\", \\\"{x:1228,y:753,t:1526328737289};\\\", \\\"{x:1229,y:753,t:1526328737305};\\\", \\\"{x:1231,y:755,t:1526328737372};\\\", \\\"{x:1240,y:761,t:1526328737396};\\\", \\\"{x:1244,y:763,t:1526328737405};\\\", \\\"{x:1247,y:765,t:1526328737422};\\\", \\\"{x:1249,y:766,t:1526328737439};\\\", \\\"{x:1251,y:767,t:1526328737456};\\\", \\\"{x:1252,y:768,t:1526328737471};\\\", \\\"{x:1253,y:769,t:1526328737507};\\\", \\\"{x:1255,y:771,t:1526328737532};\\\", \\\"{x:1255,y:772,t:1526328737548};\\\", \\\"{x:1256,y:772,t:1526328737572};\\\", \\\"{x:1259,y:772,t:1526328737620};\\\", \\\"{x:1260,y:772,t:1526328737628};\\\", \\\"{x:1263,y:772,t:1526328737639};\\\", \\\"{x:1269,y:770,t:1526328737657};\\\", \\\"{x:1274,y:767,t:1526328737672};\\\", \\\"{x:1281,y:763,t:1526328737689};\\\", \\\"{x:1288,y:762,t:1526328737706};\\\", \\\"{x:1292,y:761,t:1526328737722};\\\", \\\"{x:1293,y:761,t:1526328737739};\\\", \\\"{x:1294,y:761,t:1526328737763};\\\", \\\"{x:1295,y:761,t:1526328737772};\\\", \\\"{x:1297,y:761,t:1526328737789};\\\", \\\"{x:1299,y:761,t:1526328737806};\\\", \\\"{x:1300,y:761,t:1526328737827};\\\", \\\"{x:1301,y:761,t:1526328737839};\\\", \\\"{x:1302,y:761,t:1526328737856};\\\", \\\"{x:1303,y:761,t:1526328737872};\\\", \\\"{x:1308,y:762,t:1526328737889};\\\", \\\"{x:1314,y:764,t:1526328737906};\\\", \\\"{x:1319,y:764,t:1526328737922};\\\", \\\"{x:1320,y:764,t:1526328737940};\\\", \\\"{x:1321,y:764,t:1526328737980};\\\", \\\"{x:1323,y:764,t:1526328738292};\\\", \\\"{x:1332,y:760,t:1526328738307};\\\", \\\"{x:1335,y:759,t:1526328738323};\\\", \\\"{x:1336,y:758,t:1526328738340};\\\", \\\"{x:1337,y:758,t:1526328738372};\\\", \\\"{x:1339,y:758,t:1526328738380};\\\", \\\"{x:1343,y:758,t:1526328738389};\\\", \\\"{x:1353,y:760,t:1526328738406};\\\", \\\"{x:1365,y:763,t:1526328738424};\\\", \\\"{x:1372,y:764,t:1526328738440};\\\", \\\"{x:1380,y:764,t:1526328738457};\\\", \\\"{x:1388,y:765,t:1526328738474};\\\", \\\"{x:1392,y:767,t:1526328738490};\\\", \\\"{x:1394,y:767,t:1526328738508};\\\", \\\"{x:1395,y:768,t:1526328738572};\\\", \\\"{x:1396,y:769,t:1526328739308};\\\", \\\"{x:1398,y:774,t:1526328739323};\\\", \\\"{x:1399,y:776,t:1526328739340};\\\", \\\"{x:1400,y:778,t:1526328739357};\\\", \\\"{x:1400,y:780,t:1526328739373};\\\", \\\"{x:1400,y:781,t:1526328739390};\\\", \\\"{x:1399,y:781,t:1526328739468};\\\", \\\"{x:1398,y:781,t:1526328739476};\\\", \\\"{x:1396,y:781,t:1526328739491};\\\", \\\"{x:1394,y:779,t:1526328739507};\\\", \\\"{x:1392,y:778,t:1526328739524};\\\", \\\"{x:1390,y:777,t:1526328739540};\\\", \\\"{x:1390,y:776,t:1526328739557};\\\", \\\"{x:1389,y:776,t:1526328739604};\\\", \\\"{x:1388,y:776,t:1526328739612};\\\", \\\"{x:1387,y:776,t:1526328739624};\\\", \\\"{x:1385,y:778,t:1526328739641};\\\", \\\"{x:1382,y:785,t:1526328739656};\\\", \\\"{x:1381,y:790,t:1526328739673};\\\", \\\"{x:1380,y:797,t:1526328739690};\\\", \\\"{x:1378,y:800,t:1526328739706};\\\", \\\"{x:1378,y:801,t:1526328739723};\\\", \\\"{x:1376,y:801,t:1526328739835};\\\", \\\"{x:1376,y:800,t:1526328739843};\\\", \\\"{x:1374,y:799,t:1526328739856};\\\", \\\"{x:1374,y:798,t:1526328739874};\\\", \\\"{x:1373,y:798,t:1526328739890};\\\", \\\"{x:1372,y:797,t:1526328739996};\\\", \\\"{x:1371,y:797,t:1526328740012};\\\", \\\"{x:1369,y:797,t:1526328740035};\\\", \\\"{x:1368,y:799,t:1526328740043};\\\", \\\"{x:1367,y:799,t:1526328740056};\\\", \\\"{x:1367,y:801,t:1526328740074};\\\", \\\"{x:1366,y:801,t:1526328740091};\\\", \\\"{x:1365,y:800,t:1526328740180};\\\", \\\"{x:1365,y:794,t:1526328740196};\\\", \\\"{x:1365,y:791,t:1526328740208};\\\", \\\"{x:1365,y:785,t:1526328740223};\\\", \\\"{x:1365,y:781,t:1526328740240};\\\", \\\"{x:1365,y:779,t:1526328740258};\\\", \\\"{x:1365,y:777,t:1526328740273};\\\", \\\"{x:1365,y:776,t:1526328740290};\\\", \\\"{x:1364,y:775,t:1526328740468};\\\", \\\"{x:1364,y:774,t:1526328740475};\\\", \\\"{x:1362,y:771,t:1526328740491};\\\", \\\"{x:1360,y:768,t:1526328740507};\\\", \\\"{x:1358,y:764,t:1526328740524};\\\", \\\"{x:1358,y:762,t:1526328740555};\\\", \\\"{x:1357,y:762,t:1526328742036};\\\", \\\"{x:1353,y:764,t:1526328743701};\\\", \\\"{x:1332,y:770,t:1526328743716};\\\", \\\"{x:1322,y:771,t:1526328743726};\\\", \\\"{x:1300,y:773,t:1526328743743};\\\", \\\"{x:1278,y:775,t:1526328743759};\\\", \\\"{x:1258,y:777,t:1526328743777};\\\", \\\"{x:1246,y:778,t:1526328743793};\\\", \\\"{x:1234,y:780,t:1526328743809};\\\", \\\"{x:1221,y:780,t:1526328743827};\\\", \\\"{x:1214,y:781,t:1526328743843};\\\", \\\"{x:1206,y:782,t:1526328743860};\\\", \\\"{x:1195,y:785,t:1526328743876};\\\", \\\"{x:1183,y:786,t:1526328743893};\\\", \\\"{x:1172,y:787,t:1526328743911};\\\", \\\"{x:1161,y:788,t:1526328743926};\\\", \\\"{x:1148,y:788,t:1526328743943};\\\", \\\"{x:1138,y:788,t:1526328743961};\\\", \\\"{x:1128,y:786,t:1526328743976};\\\", \\\"{x:1121,y:781,t:1526328743994};\\\", \\\"{x:1105,y:771,t:1526328744011};\\\", \\\"{x:1096,y:764,t:1526328744027};\\\", \\\"{x:1086,y:755,t:1526328744044};\\\", \\\"{x:1079,y:748,t:1526328744061};\\\", \\\"{x:1072,y:744,t:1526328744076};\\\", \\\"{x:1069,y:741,t:1526328744094};\\\", \\\"{x:1064,y:739,t:1526328744110};\\\", \\\"{x:1061,y:738,t:1526328744127};\\\", \\\"{x:1060,y:737,t:1526328744252};\\\", \\\"{x:1067,y:735,t:1526328744268};\\\", \\\"{x:1078,y:735,t:1526328744277};\\\", \\\"{x:1097,y:733,t:1526328744293};\\\", \\\"{x:1119,y:724,t:1526328744311};\\\", \\\"{x:1142,y:714,t:1526328744326};\\\", \\\"{x:1162,y:706,t:1526328744344};\\\", \\\"{x:1183,y:696,t:1526328744361};\\\", \\\"{x:1202,y:688,t:1526328744377};\\\", \\\"{x:1215,y:682,t:1526328744394};\\\", \\\"{x:1224,y:677,t:1526328744411};\\\", \\\"{x:1223,y:677,t:1526328744789};\\\", \\\"{x:1217,y:677,t:1526328744796};\\\", \\\"{x:1209,y:676,t:1526328744811};\\\", \\\"{x:1196,y:674,t:1526328744828};\\\", \\\"{x:1182,y:670,t:1526328744845};\\\", \\\"{x:1164,y:665,t:1526328744861};\\\", \\\"{x:1150,y:661,t:1526328744878};\\\", \\\"{x:1133,y:656,t:1526328744895};\\\", \\\"{x:1113,y:651,t:1526328744911};\\\", \\\"{x:1088,y:644,t:1526328744928};\\\", \\\"{x:1061,y:635,t:1526328744945};\\\", \\\"{x:1037,y:630,t:1526328744962};\\\", \\\"{x:1016,y:626,t:1526328744979};\\\", \\\"{x:993,y:625,t:1526328744996};\\\", \\\"{x:967,y:625,t:1526328745012};\\\", \\\"{x:951,y:625,t:1526328745028};\\\", \\\"{x:939,y:624,t:1526328745046};\\\", \\\"{x:931,y:624,t:1526328745061};\\\", \\\"{x:925,y:623,t:1526328745077};\\\", \\\"{x:920,y:622,t:1526328745093};\\\", \\\"{x:919,y:622,t:1526328745110};\\\", \\\"{x:917,y:622,t:1526328745126};\\\", \\\"{x:916,y:622,t:1526328745143};\\\", \\\"{x:911,y:622,t:1526328745160};\\\", \\\"{x:907,y:622,t:1526328745177};\\\", \\\"{x:903,y:622,t:1526328745193};\\\", \\\"{x:897,y:622,t:1526328745211};\\\", \\\"{x:891,y:622,t:1526328745226};\\\", \\\"{x:883,y:622,t:1526328745243};\\\", \\\"{x:875,y:622,t:1526328745260};\\\", \\\"{x:868,y:622,t:1526328745277};\\\", \\\"{x:863,y:622,t:1526328745294};\\\", \\\"{x:854,y:621,t:1526328745310};\\\", \\\"{x:849,y:619,t:1526328745328};\\\", \\\"{x:840,y:617,t:1526328745346};\\\", \\\"{x:828,y:613,t:1526328745362};\\\", \\\"{x:816,y:609,t:1526328745379};\\\", \\\"{x:806,y:609,t:1526328745394};\\\", \\\"{x:789,y:604,t:1526328745411};\\\", \\\"{x:769,y:601,t:1526328745429};\\\", \\\"{x:747,y:599,t:1526328745447};\\\", \\\"{x:725,y:595,t:1526328745461};\\\", \\\"{x:701,y:592,t:1526328745479};\\\", \\\"{x:679,y:590,t:1526328745495};\\\", \\\"{x:660,y:588,t:1526328745511};\\\", \\\"{x:643,y:588,t:1526328745529};\\\", \\\"{x:627,y:588,t:1526328745548};\\\", \\\"{x:615,y:588,t:1526328745564};\\\", \\\"{x:598,y:588,t:1526328745580};\\\", \\\"{x:585,y:588,t:1526328745598};\\\", \\\"{x:572,y:588,t:1526328745613};\\\", \\\"{x:555,y:588,t:1526328745631};\\\", \\\"{x:535,y:587,t:1526328745647};\\\", \\\"{x:518,y:586,t:1526328745665};\\\", \\\"{x:504,y:586,t:1526328745680};\\\", \\\"{x:493,y:586,t:1526328745699};\\\", \\\"{x:482,y:585,t:1526328745714};\\\", \\\"{x:476,y:585,t:1526328745730};\\\", \\\"{x:467,y:583,t:1526328745748};\\\", \\\"{x:460,y:582,t:1526328745765};\\\", \\\"{x:458,y:581,t:1526328745782};\\\", \\\"{x:454,y:581,t:1526328745797};\\\", \\\"{x:452,y:580,t:1526328745814};\\\", \\\"{x:448,y:578,t:1526328745832};\\\", \\\"{x:442,y:574,t:1526328745848};\\\", \\\"{x:436,y:572,t:1526328745865};\\\", \\\"{x:432,y:570,t:1526328745882};\\\", \\\"{x:429,y:569,t:1526328745899};\\\", \\\"{x:427,y:569,t:1526328745915};\\\", \\\"{x:424,y:569,t:1526328745932};\\\", \\\"{x:421,y:568,t:1526328745949};\\\", \\\"{x:415,y:567,t:1526328745966};\\\", \\\"{x:412,y:567,t:1526328745982};\\\", \\\"{x:406,y:564,t:1526328745998};\\\", \\\"{x:400,y:562,t:1526328746016};\\\", \\\"{x:393,y:558,t:1526328746030};\\\", \\\"{x:385,y:555,t:1526328746049};\\\", \\\"{x:375,y:551,t:1526328746065};\\\", \\\"{x:362,y:548,t:1526328746081};\\\", \\\"{x:345,y:544,t:1526328746098};\\\", \\\"{x:322,y:540,t:1526328746114};\\\", \\\"{x:299,y:537,t:1526328746132};\\\", \\\"{x:274,y:534,t:1526328746148};\\\", \\\"{x:241,y:528,t:1526328746165};\\\", \\\"{x:223,y:526,t:1526328746181};\\\", \\\"{x:209,y:524,t:1526328746198};\\\", \\\"{x:198,y:524,t:1526328746214};\\\", \\\"{x:188,y:524,t:1526328746231};\\\", \\\"{x:182,y:524,t:1526328746247};\\\", \\\"{x:179,y:524,t:1526328746265};\\\", \\\"{x:176,y:523,t:1526328746282};\\\", \\\"{x:173,y:523,t:1526328746297};\\\", \\\"{x:169,y:522,t:1526328746315};\\\", \\\"{x:165,y:522,t:1526328746332};\\\", \\\"{x:163,y:520,t:1526328746348};\\\", \\\"{x:162,y:519,t:1526328746494};\\\", \\\"{x:161,y:518,t:1526328746502};\\\", \\\"{x:161,y:517,t:1526328746527};\\\", \\\"{x:161,y:516,t:1526328746541};\\\", \\\"{x:161,y:514,t:1526328746549};\\\", \\\"{x:160,y:513,t:1526328746566};\\\", \\\"{x:160,y:511,t:1526328746604};\\\", \\\"{x:160,y:510,t:1526328746621};\\\", \\\"{x:160,y:508,t:1526328746632};\\\", \\\"{x:161,y:506,t:1526328746649};\\\", \\\"{x:161,y:502,t:1526328746665};\\\", \\\"{x:162,y:499,t:1526328746682};\\\", \\\"{x:162,y:498,t:1526328746699};\\\", \\\"{x:162,y:497,t:1526328746717};\\\", \\\"{x:167,y:496,t:1526328746932};\\\", \\\"{x:178,y:496,t:1526328746949};\\\", \\\"{x:188,y:499,t:1526328746966};\\\", \\\"{x:203,y:514,t:1526328746982};\\\", \\\"{x:233,y:549,t:1526328746999};\\\", \\\"{x:276,y:590,t:1526328747016};\\\", \\\"{x:334,y:641,t:1526328747034};\\\", \\\"{x:381,y:681,t:1526328747049};\\\", \\\"{x:414,y:709,t:1526328747065};\\\", \\\"{x:437,y:728,t:1526328747082};\\\", \\\"{x:453,y:737,t:1526328747099};\\\", \\\"{x:459,y:741,t:1526328747116};\\\", \\\"{x:461,y:741,t:1526328747133};\\\", \\\"{x:461,y:740,t:1526328747277};\\\", \\\"{x:461,y:739,t:1526328747285};\\\", \\\"{x:461,y:738,t:1526328747301};\\\", \\\"{x:461,y:737,t:1526328747333};\\\", \\\"{x:461,y:736,t:1526328747365};\\\", \\\"{x:461,y:735,t:1526328747383};\\\", \\\"{x:462,y:734,t:1526328747399};\\\", \\\"{x:463,y:734,t:1526328747518};\\\", \\\"{x:463,y:735,t:1526328747541};\\\", \\\"{x:464,y:735,t:1526328747558};\\\" ] }, { \\\"rt\\\": 25663, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 628604, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:465,y:736,t:1526328759662};\\\", \\\"{x:465,y:737,t:1526328759668};\\\", \\\"{x:464,y:738,t:1526328759685};\\\", \\\"{x:464,y:740,t:1526328759702};\\\", \\\"{x:463,y:740,t:1526328759719};\\\", \\\"{x:462,y:741,t:1526328759735};\\\", \\\"{x:461,y:742,t:1526328759757};\\\", \\\"{x:460,y:742,t:1526328760286};\\\", \\\"{x:459,y:743,t:1526328760318};\\\", \\\"{x:459,y:744,t:1526328760333};\\\", \\\"{x:459,y:745,t:1526328760349};\\\", \\\"{x:459,y:746,t:1526328760358};\\\", \\\"{x:459,y:747,t:1526328760390};\\\", \\\"{x:459,y:748,t:1526328760404};\\\", \\\"{x:459,y:749,t:1526328760419};\\\", \\\"{x:459,y:750,t:1526328760435};\\\", \\\"{x:459,y:753,t:1526328760452};\\\", \\\"{x:460,y:754,t:1526328760469};\\\", \\\"{x:461,y:756,t:1526328760486};\\\", \\\"{x:462,y:757,t:1526328760502};\\\", \\\"{x:464,y:761,t:1526328760519};\\\", \\\"{x:467,y:764,t:1526328760535};\\\", \\\"{x:474,y:770,t:1526328760560};\\\", \\\"{x:483,y:777,t:1526328760577};\\\", \\\"{x:491,y:783,t:1526328760593};\\\", \\\"{x:507,y:792,t:1526328760610};\\\", \\\"{x:530,y:802,t:1526328760627};\\\", \\\"{x:561,y:815,t:1526328760643};\\\", \\\"{x:599,y:823,t:1526328760660};\\\", \\\"{x:654,y:827,t:1526328760676};\\\", \\\"{x:702,y:827,t:1526328760693};\\\", \\\"{x:742,y:827,t:1526328760710};\\\", \\\"{x:782,y:820,t:1526328760727};\\\", \\\"{x:814,y:808,t:1526328760744};\\\", \\\"{x:844,y:797,t:1526328760761};\\\", \\\"{x:867,y:786,t:1526328760777};\\\", \\\"{x:890,y:776,t:1526328760794};\\\", \\\"{x:914,y:766,t:1526328760810};\\\", \\\"{x:936,y:756,t:1526328760827};\\\", \\\"{x:959,y:747,t:1526328760844};\\\", \\\"{x:980,y:738,t:1526328760860};\\\", \\\"{x:1006,y:727,t:1526328760878};\\\", \\\"{x:1016,y:723,t:1526328760895};\\\", \\\"{x:1025,y:719,t:1526328760910};\\\", \\\"{x:1035,y:715,t:1526328760928};\\\", \\\"{x:1046,y:711,t:1526328760945};\\\", \\\"{x:1057,y:706,t:1526328760960};\\\", \\\"{x:1066,y:704,t:1526328760977};\\\", \\\"{x:1071,y:702,t:1526328760994};\\\", \\\"{x:1077,y:702,t:1526328761011};\\\", \\\"{x:1082,y:702,t:1526328761027};\\\", \\\"{x:1092,y:702,t:1526328761045};\\\", \\\"{x:1116,y:702,t:1526328761061};\\\", \\\"{x:1137,y:702,t:1526328761077};\\\", \\\"{x:1155,y:705,t:1526328761094};\\\", \\\"{x:1176,y:708,t:1526328761111};\\\", \\\"{x:1191,y:712,t:1526328761127};\\\", \\\"{x:1206,y:715,t:1526328761144};\\\", \\\"{x:1214,y:716,t:1526328761162};\\\", \\\"{x:1222,y:718,t:1526328761177};\\\", \\\"{x:1224,y:720,t:1526328761195};\\\", \\\"{x:1227,y:720,t:1526328761211};\\\", \\\"{x:1229,y:720,t:1526328761228};\\\", \\\"{x:1230,y:720,t:1526328761284};\\\", \\\"{x:1234,y:720,t:1526328761294};\\\", \\\"{x:1247,y:720,t:1526328761310};\\\", \\\"{x:1258,y:720,t:1526328761328};\\\", \\\"{x:1270,y:720,t:1526328761344};\\\", \\\"{x:1280,y:720,t:1526328761361};\\\", \\\"{x:1287,y:720,t:1526328761377};\\\", \\\"{x:1293,y:720,t:1526328761395};\\\", \\\"{x:1299,y:718,t:1526328761411};\\\", \\\"{x:1304,y:717,t:1526328761428};\\\", \\\"{x:1306,y:715,t:1526328761445};\\\", \\\"{x:1308,y:715,t:1526328761582};\\\", \\\"{x:1309,y:714,t:1526328761599};\\\", \\\"{x:1310,y:714,t:1526328761612};\\\", \\\"{x:1311,y:713,t:1526328761627};\\\", \\\"{x:1313,y:712,t:1526328761645};\\\", \\\"{x:1314,y:712,t:1526328761662};\\\", \\\"{x:1316,y:711,t:1526328761678};\\\", \\\"{x:1317,y:711,t:1526328761695};\\\", \\\"{x:1319,y:710,t:1526328761712};\\\", \\\"{x:1323,y:708,t:1526328761729};\\\", \\\"{x:1326,y:706,t:1526328761745};\\\", \\\"{x:1328,y:705,t:1526328761761};\\\", \\\"{x:1329,y:705,t:1526328761779};\\\", \\\"{x:1330,y:705,t:1526328761848};\\\", \\\"{x:1331,y:704,t:1526328761877};\\\", \\\"{x:1332,y:704,t:1526328762006};\\\", \\\"{x:1334,y:703,t:1526328762021};\\\", \\\"{x:1334,y:702,t:1526328762030};\\\", \\\"{x:1335,y:702,t:1526328762045};\\\", \\\"{x:1336,y:702,t:1526328762086};\\\", \\\"{x:1337,y:701,t:1526328762097};\\\", \\\"{x:1338,y:701,t:1526328762117};\\\", \\\"{x:1340,y:700,t:1526328762173};\\\", \\\"{x:1341,y:700,t:1526328762222};\\\", \\\"{x:1342,y:699,t:1526328762230};\\\", \\\"{x:1343,y:699,t:1526328762247};\\\", \\\"{x:1345,y:698,t:1526328762279};\\\", \\\"{x:1346,y:697,t:1526328762296};\\\", \\\"{x:1347,y:696,t:1526328762694};\\\", \\\"{x:1350,y:696,t:1526328762701};\\\", \\\"{x:1354,y:693,t:1526328762719};\\\", \\\"{x:1356,y:693,t:1526328762731};\\\", \\\"{x:1359,y:692,t:1526328762747};\\\", \\\"{x:1363,y:690,t:1526328762763};\\\", \\\"{x:1363,y:689,t:1526328762781};\\\", \\\"{x:1364,y:689,t:1526328762796};\\\", \\\"{x:1366,y:688,t:1526328762813};\\\", \\\"{x:1367,y:688,t:1526328762852};\\\", \\\"{x:1368,y:688,t:1526328762868};\\\", \\\"{x:1369,y:688,t:1526328762881};\\\", \\\"{x:1370,y:688,t:1526328762896};\\\", \\\"{x:1372,y:688,t:1526328762913};\\\", \\\"{x:1375,y:688,t:1526328762930};\\\", \\\"{x:1377,y:689,t:1526328762946};\\\", \\\"{x:1383,y:690,t:1526328762963};\\\", \\\"{x:1390,y:693,t:1526328762980};\\\", \\\"{x:1398,y:695,t:1526328762997};\\\", \\\"{x:1400,y:695,t:1526328763013};\\\", \\\"{x:1403,y:696,t:1526328763031};\\\", \\\"{x:1405,y:697,t:1526328763048};\\\", \\\"{x:1406,y:697,t:1526328763078};\\\", \\\"{x:1408,y:698,t:1526328763093};\\\", \\\"{x:1409,y:698,t:1526328763109};\\\", \\\"{x:1411,y:698,t:1526328763126};\\\", \\\"{x:1412,y:698,t:1526328763430};\\\", \\\"{x:1414,y:698,t:1526328763438};\\\", \\\"{x:1416,y:698,t:1526328763448};\\\", \\\"{x:1421,y:697,t:1526328763464};\\\", \\\"{x:1423,y:697,t:1526328763480};\\\", \\\"{x:1425,y:697,t:1526328763497};\\\", \\\"{x:1426,y:696,t:1526328763515};\\\", \\\"{x:1428,y:696,t:1526328763530};\\\", \\\"{x:1429,y:695,t:1526328763548};\\\", \\\"{x:1435,y:695,t:1526328763564};\\\", \\\"{x:1441,y:695,t:1526328763580};\\\", \\\"{x:1447,y:695,t:1526328763598};\\\", \\\"{x:1451,y:695,t:1526328763614};\\\", \\\"{x:1454,y:695,t:1526328763630};\\\", \\\"{x:1455,y:695,t:1526328763648};\\\", \\\"{x:1459,y:695,t:1526328763665};\\\", \\\"{x:1465,y:695,t:1526328763680};\\\", \\\"{x:1473,y:695,t:1526328763698};\\\", \\\"{x:1482,y:695,t:1526328763714};\\\", \\\"{x:1488,y:695,t:1526328763732};\\\", \\\"{x:1490,y:695,t:1526328763747};\\\", \\\"{x:1491,y:695,t:1526328763765};\\\", \\\"{x:1492,y:695,t:1526328764150};\\\", \\\"{x:1497,y:692,t:1526328764166};\\\", \\\"{x:1500,y:692,t:1526328764182};\\\", \\\"{x:1502,y:691,t:1526328764198};\\\", \\\"{x:1506,y:690,t:1526328764216};\\\", \\\"{x:1510,y:690,t:1526328764233};\\\", \\\"{x:1513,y:690,t:1526328764249};\\\", \\\"{x:1514,y:690,t:1526328764277};\\\", \\\"{x:1515,y:690,t:1526328764293};\\\", \\\"{x:1516,y:690,t:1526328764301};\\\", \\\"{x:1517,y:690,t:1526328764325};\\\", \\\"{x:1518,y:690,t:1526328764357};\\\", \\\"{x:1519,y:690,t:1526328764365};\\\", \\\"{x:1524,y:691,t:1526328764383};\\\", \\\"{x:1539,y:694,t:1526328764399};\\\", \\\"{x:1550,y:696,t:1526328764416};\\\", \\\"{x:1559,y:699,t:1526328764433};\\\", \\\"{x:1564,y:699,t:1526328764450};\\\", \\\"{x:1567,y:699,t:1526328764466};\\\", \\\"{x:1564,y:699,t:1526328764686};\\\", \\\"{x:1563,y:699,t:1526328764700};\\\", \\\"{x:1558,y:699,t:1526328764716};\\\", \\\"{x:1556,y:699,t:1526328764733};\\\", \\\"{x:1554,y:699,t:1526328764750};\\\", \\\"{x:1554,y:698,t:1526328765093};\\\", \\\"{x:1555,y:696,t:1526328765117};\\\", \\\"{x:1557,y:696,t:1526328765133};\\\", \\\"{x:1558,y:696,t:1526328765205};\\\", \\\"{x:1562,y:695,t:1526328765230};\\\", \\\"{x:1563,y:695,t:1526328765237};\\\", \\\"{x:1566,y:695,t:1526328765251};\\\", \\\"{x:1570,y:695,t:1526328765266};\\\", \\\"{x:1574,y:695,t:1526328765283};\\\", \\\"{x:1581,y:696,t:1526328765300};\\\", \\\"{x:1585,y:696,t:1526328765317};\\\", \\\"{x:1587,y:696,t:1526328765333};\\\", \\\"{x:1588,y:696,t:1526328765364};\\\", \\\"{x:1589,y:697,t:1526328765380};\\\", \\\"{x:1590,y:697,t:1526328765389};\\\", \\\"{x:1591,y:697,t:1526328765401};\\\", \\\"{x:1596,y:697,t:1526328765416};\\\", \\\"{x:1600,y:697,t:1526328765433};\\\", \\\"{x:1601,y:697,t:1526328765450};\\\", \\\"{x:1602,y:697,t:1526328765710};\\\", \\\"{x:1603,y:697,t:1526328765766};\\\", \\\"{x:1604,y:697,t:1526328765990};\\\", \\\"{x:1605,y:697,t:1526328766004};\\\", \\\"{x:1606,y:697,t:1526328766019};\\\", \\\"{x:1608,y:697,t:1526328766125};\\\", \\\"{x:1610,y:697,t:1526328766142};\\\", \\\"{x:1608,y:697,t:1526328772895};\\\", \\\"{x:1590,y:697,t:1526328772913};\\\", \\\"{x:1563,y:697,t:1526328772928};\\\", \\\"{x:1530,y:697,t:1526328772944};\\\", \\\"{x:1485,y:697,t:1526328772961};\\\", \\\"{x:1430,y:702,t:1526328772978};\\\", \\\"{x:1376,y:706,t:1526328772993};\\\", \\\"{x:1298,y:706,t:1526328773010};\\\", \\\"{x:1212,y:706,t:1526328773027};\\\", \\\"{x:1117,y:707,t:1526328773044};\\\", \\\"{x:990,y:717,t:1526328773060};\\\", \\\"{x:907,y:717,t:1526328773077};\\\", \\\"{x:837,y:717,t:1526328773094};\\\", \\\"{x:772,y:722,t:1526328773111};\\\", \\\"{x:710,y:723,t:1526328773127};\\\", \\\"{x:667,y:725,t:1526328773145};\\\", \\\"{x:626,y:727,t:1526328773161};\\\", \\\"{x:599,y:727,t:1526328773177};\\\", \\\"{x:577,y:727,t:1526328773195};\\\", \\\"{x:560,y:727,t:1526328773211};\\\", \\\"{x:546,y:726,t:1526328773227};\\\", \\\"{x:525,y:714,t:1526328773244};\\\", \\\"{x:516,y:707,t:1526328773253};\\\", \\\"{x:494,y:693,t:1526328773271};\\\", \\\"{x:474,y:677,t:1526328773286};\\\", \\\"{x:466,y:665,t:1526328773304};\\\", \\\"{x:464,y:653,t:1526328773321};\\\", \\\"{x:464,y:643,t:1526328773336};\\\", \\\"{x:471,y:628,t:1526328773354};\\\", \\\"{x:481,y:614,t:1526328773370};\\\", \\\"{x:489,y:603,t:1526328773387};\\\", \\\"{x:495,y:598,t:1526328773404};\\\", \\\"{x:513,y:590,t:1526328773421};\\\", \\\"{x:528,y:586,t:1526328773437};\\\", \\\"{x:546,y:583,t:1526328773454};\\\", \\\"{x:558,y:582,t:1526328773470};\\\", \\\"{x:566,y:582,t:1526328773487};\\\", \\\"{x:576,y:583,t:1526328773503};\\\", \\\"{x:588,y:584,t:1526328773520};\\\", \\\"{x:601,y:585,t:1526328773538};\\\", \\\"{x:606,y:585,t:1526328773553};\\\", \\\"{x:607,y:587,t:1526328774004};\\\", \\\"{x:604,y:602,t:1526328774021};\\\", \\\"{x:598,y:623,t:1526328774038};\\\", \\\"{x:588,y:647,t:1526328774054};\\\", \\\"{x:568,y:679,t:1526328774070};\\\", \\\"{x:545,y:708,t:1526328774088};\\\", \\\"{x:526,y:732,t:1526328774104};\\\", \\\"{x:509,y:748,t:1526328774121};\\\", \\\"{x:499,y:758,t:1526328774138};\\\", \\\"{x:498,y:759,t:1526328774154};\\\", \\\"{x:496,y:759,t:1526328774170};\\\", \\\"{x:497,y:759,t:1526328774317};\\\", \\\"{x:497,y:758,t:1526328774332};\\\", \\\"{x:497,y:756,t:1526328774348};\\\", \\\"{x:498,y:755,t:1526328774356};\\\", \\\"{x:500,y:750,t:1526328774371};\\\", \\\"{x:503,y:746,t:1526328774388};\\\", \\\"{x:508,y:737,t:1526328774404};\\\", \\\"{x:510,y:735,t:1526328774421};\\\", \\\"{x:510,y:736,t:1526328775134};\\\", \\\"{x:510,y:738,t:1526328775148};\\\", \\\"{x:509,y:738,t:1526328775157};\\\", \\\"{x:509,y:739,t:1526328775180};\\\", \\\"{x:509,y:740,t:1526328775188};\\\", \\\"{x:509,y:741,t:1526328775205};\\\", \\\"{x:509,y:743,t:1526328775237};\\\", \\\"{x:509,y:744,t:1526328775245};\\\", \\\"{x:508,y:745,t:1526328775255};\\\", \\\"{x:508,y:746,t:1526328775285};\\\", \\\"{x:508,y:747,t:1526328775300};\\\", \\\"{x:508,y:748,t:1526328775333};\\\" ] }, { \\\"rt\\\": 7655, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 637571, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:748,t:1526328776742};\\\", \\\"{x:506,y:749,t:1526328776762};\\\", \\\"{x:509,y:753,t:1526328776774};\\\", \\\"{x:510,y:755,t:1526328776791};\\\", \\\"{x:513,y:760,t:1526328776807};\\\", \\\"{x:518,y:764,t:1526328776823};\\\", \\\"{x:521,y:767,t:1526328776840};\\\", \\\"{x:524,y:770,t:1526328776856};\\\", \\\"{x:528,y:772,t:1526328776873};\\\", \\\"{x:530,y:773,t:1526328776890};\\\", \\\"{x:536,y:777,t:1526328776906};\\\", \\\"{x:539,y:780,t:1526328776923};\\\", \\\"{x:546,y:781,t:1526328776940};\\\", \\\"{x:551,y:782,t:1526328776956};\\\", \\\"{x:553,y:783,t:1526328776973};\\\", \\\"{x:556,y:783,t:1526328776990};\\\", \\\"{x:560,y:784,t:1526328777007};\\\", \\\"{x:565,y:784,t:1526328777023};\\\", \\\"{x:568,y:785,t:1526328777040};\\\", \\\"{x:575,y:786,t:1526328777057};\\\", \\\"{x:581,y:786,t:1526328777073};\\\", \\\"{x:586,y:787,t:1526328777090};\\\", \\\"{x:592,y:788,t:1526328777107};\\\", \\\"{x:599,y:789,t:1526328777123};\\\", \\\"{x:613,y:789,t:1526328777140};\\\", \\\"{x:623,y:789,t:1526328777156};\\\", \\\"{x:630,y:789,t:1526328777173};\\\", \\\"{x:639,y:789,t:1526328777190};\\\", \\\"{x:645,y:789,t:1526328777207};\\\", \\\"{x:651,y:789,t:1526328777223};\\\", \\\"{x:657,y:789,t:1526328777240};\\\", \\\"{x:663,y:789,t:1526328777258};\\\", \\\"{x:669,y:789,t:1526328777273};\\\", \\\"{x:673,y:789,t:1526328777291};\\\", \\\"{x:678,y:789,t:1526328777308};\\\", \\\"{x:683,y:791,t:1526328777324};\\\", \\\"{x:687,y:791,t:1526328777341};\\\", \\\"{x:691,y:791,t:1526328777357};\\\", \\\"{x:695,y:792,t:1526328777373};\\\", \\\"{x:699,y:792,t:1526328777391};\\\", \\\"{x:702,y:792,t:1526328777408};\\\", \\\"{x:704,y:792,t:1526328777424};\\\", \\\"{x:705,y:792,t:1526328777441};\\\", \\\"{x:707,y:792,t:1526328777457};\\\", \\\"{x:708,y:793,t:1526328777484};\\\", \\\"{x:714,y:794,t:1526328778054};\\\", \\\"{x:728,y:802,t:1526328778061};\\\", \\\"{x:741,y:808,t:1526328778074};\\\", \\\"{x:776,y:824,t:1526328778091};\\\", \\\"{x:823,y:844,t:1526328778108};\\\", \\\"{x:861,y:858,t:1526328778125};\\\", \\\"{x:917,y:873,t:1526328778140};\\\", \\\"{x:959,y:886,t:1526328778158};\\\", \\\"{x:991,y:894,t:1526328778175};\\\", \\\"{x:1019,y:901,t:1526328778191};\\\", \\\"{x:1043,y:904,t:1526328778208};\\\", \\\"{x:1061,y:906,t:1526328778224};\\\", \\\"{x:1071,y:908,t:1526328778241};\\\", \\\"{x:1077,y:909,t:1526328778257};\\\", \\\"{x:1082,y:909,t:1526328778275};\\\", \\\"{x:1086,y:910,t:1526328778291};\\\", \\\"{x:1092,y:910,t:1526328778308};\\\", \\\"{x:1105,y:910,t:1526328778324};\\\", \\\"{x:1123,y:910,t:1526328778341};\\\", \\\"{x:1150,y:910,t:1526328778358};\\\", \\\"{x:1179,y:910,t:1526328778375};\\\", \\\"{x:1207,y:910,t:1526328778391};\\\", \\\"{x:1234,y:910,t:1526328778408};\\\", \\\"{x:1257,y:910,t:1526328778425};\\\", \\\"{x:1279,y:910,t:1526328778441};\\\", \\\"{x:1301,y:911,t:1526328778458};\\\", \\\"{x:1317,y:915,t:1526328778475};\\\", \\\"{x:1321,y:916,t:1526328778491};\\\", \\\"{x:1324,y:918,t:1526328778508};\\\", \\\"{x:1325,y:918,t:1526328778525};\\\", \\\"{x:1325,y:920,t:1526328778575};\\\", \\\"{x:1325,y:924,t:1526328778591};\\\", \\\"{x:1325,y:930,t:1526328778608};\\\", \\\"{x:1328,y:941,t:1526328778625};\\\", \\\"{x:1331,y:954,t:1526328778641};\\\", \\\"{x:1335,y:966,t:1526328778658};\\\", \\\"{x:1337,y:972,t:1526328778675};\\\", \\\"{x:1338,y:973,t:1526328778691};\\\", \\\"{x:1339,y:975,t:1526328778709};\\\", \\\"{x:1342,y:977,t:1526328778724};\\\", \\\"{x:1345,y:979,t:1526328778741};\\\", \\\"{x:1349,y:981,t:1526328778758};\\\", \\\"{x:1351,y:982,t:1526328778775};\\\", \\\"{x:1351,y:983,t:1526328778797};\\\", \\\"{x:1349,y:981,t:1526328780013};\\\", \\\"{x:1336,y:976,t:1526328780030};\\\", \\\"{x:1330,y:974,t:1526328780043};\\\", \\\"{x:1317,y:969,t:1526328780058};\\\", \\\"{x:1295,y:964,t:1526328780076};\\\", \\\"{x:1238,y:954,t:1526328780092};\\\", \\\"{x:1190,y:946,t:1526328780109};\\\", \\\"{x:1134,y:936,t:1526328780126};\\\", \\\"{x:1061,y:926,t:1526328780143};\\\", \\\"{x:978,y:915,t:1526328780158};\\\", \\\"{x:892,y:901,t:1526328780176};\\\", \\\"{x:806,y:890,t:1526328780192};\\\", \\\"{x:733,y:880,t:1526328780210};\\\", \\\"{x:656,y:870,t:1526328780225};\\\", \\\"{x:595,y:864,t:1526328780242};\\\", \\\"{x:551,y:854,t:1526328780259};\\\", \\\"{x:512,y:836,t:1526328780275};\\\", \\\"{x:460,y:798,t:1526328780292};\\\", \\\"{x:421,y:759,t:1526328780310};\\\", \\\"{x:381,y:712,t:1526328780325};\\\", \\\"{x:353,y:673,t:1526328780342};\\\", \\\"{x:336,y:641,t:1526328780360};\\\", \\\"{x:326,y:622,t:1526328780376};\\\", \\\"{x:321,y:606,t:1526328780392};\\\", \\\"{x:321,y:594,t:1526328780409};\\\", \\\"{x:321,y:585,t:1526328780426};\\\", \\\"{x:321,y:579,t:1526328780443};\\\", \\\"{x:326,y:571,t:1526328780460};\\\", \\\"{x:329,y:566,t:1526328780475};\\\", \\\"{x:330,y:563,t:1526328780492};\\\", \\\"{x:330,y:562,t:1526328780510};\\\", \\\"{x:329,y:562,t:1526328780628};\\\", \\\"{x:327,y:562,t:1526328780644};\\\", \\\"{x:321,y:564,t:1526328780661};\\\", \\\"{x:317,y:566,t:1526328780676};\\\", \\\"{x:310,y:569,t:1526328780693};\\\", \\\"{x:304,y:572,t:1526328780710};\\\", \\\"{x:301,y:573,t:1526328780726};\\\", \\\"{x:297,y:574,t:1526328780743};\\\", \\\"{x:294,y:576,t:1526328780760};\\\", \\\"{x:287,y:578,t:1526328780776};\\\", \\\"{x:283,y:579,t:1526328780793};\\\", \\\"{x:279,y:579,t:1526328780810};\\\", \\\"{x:275,y:579,t:1526328780826};\\\", \\\"{x:268,y:579,t:1526328780844};\\\", \\\"{x:260,y:579,t:1526328780860};\\\", \\\"{x:257,y:579,t:1526328780877};\\\", \\\"{x:253,y:579,t:1526328780893};\\\", \\\"{x:246,y:579,t:1526328780910};\\\", \\\"{x:242,y:579,t:1526328780927};\\\", \\\"{x:237,y:578,t:1526328780943};\\\", \\\"{x:231,y:575,t:1526328780960};\\\", \\\"{x:226,y:574,t:1526328780977};\\\", \\\"{x:222,y:571,t:1526328780993};\\\", \\\"{x:215,y:567,t:1526328781010};\\\", \\\"{x:209,y:564,t:1526328781027};\\\", \\\"{x:203,y:559,t:1526328781044};\\\", \\\"{x:192,y:552,t:1526328781061};\\\", \\\"{x:186,y:549,t:1526328781077};\\\", \\\"{x:182,y:547,t:1526328781092};\\\", \\\"{x:181,y:546,t:1526328781110};\\\", \\\"{x:179,y:546,t:1526328781127};\\\", \\\"{x:178,y:546,t:1526328781142};\\\", \\\"{x:176,y:546,t:1526328781164};\\\", \\\"{x:175,y:546,t:1526328781188};\\\", \\\"{x:174,y:546,t:1526328781244};\\\", \\\"{x:173,y:546,t:1526328781260};\\\", \\\"{x:172,y:546,t:1526328781284};\\\", \\\"{x:171,y:546,t:1526328781294};\\\", \\\"{x:169,y:547,t:1526328781311};\\\", \\\"{x:165,y:547,t:1526328781326};\\\", \\\"{x:164,y:547,t:1526328781344};\\\", \\\"{x:163,y:547,t:1526328781361};\\\", \\\"{x:162,y:547,t:1526328781376};\\\", \\\"{x:165,y:547,t:1526328781699};\\\", \\\"{x:169,y:546,t:1526328781710};\\\", \\\"{x:179,y:541,t:1526328781728};\\\", \\\"{x:187,y:537,t:1526328781743};\\\", \\\"{x:199,y:535,t:1526328781761};\\\", \\\"{x:214,y:530,t:1526328781777};\\\", \\\"{x:232,y:529,t:1526328781793};\\\", \\\"{x:253,y:526,t:1526328781810};\\\", \\\"{x:272,y:525,t:1526328781828};\\\", \\\"{x:294,y:525,t:1526328781845};\\\", \\\"{x:332,y:525,t:1526328781861};\\\", \\\"{x:368,y:525,t:1526328781878};\\\", \\\"{x:405,y:525,t:1526328781893};\\\", \\\"{x:444,y:525,t:1526328781910};\\\", \\\"{x:497,y:525,t:1526328781927};\\\", \\\"{x:553,y:525,t:1526328781946};\\\", \\\"{x:606,y:525,t:1526328781961};\\\", \\\"{x:667,y:525,t:1526328781977};\\\", \\\"{x:721,y:523,t:1526328781994};\\\", \\\"{x:751,y:520,t:1526328782011};\\\", \\\"{x:777,y:520,t:1526328782028};\\\", \\\"{x:793,y:518,t:1526328782043};\\\", \\\"{x:800,y:516,t:1526328782061};\\\", \\\"{x:801,y:516,t:1526328782077};\\\", \\\"{x:802,y:516,t:1526328782140};\\\", \\\"{x:803,y:516,t:1526328782156};\\\", \\\"{x:804,y:515,t:1526328782228};\\\", \\\"{x:807,y:513,t:1526328782253};\\\", \\\"{x:809,y:511,t:1526328782261};\\\", \\\"{x:818,y:505,t:1526328782279};\\\", \\\"{x:822,y:502,t:1526328782294};\\\", \\\"{x:825,y:501,t:1526328782311};\\\", \\\"{x:826,y:500,t:1526328782330};\\\", \\\"{x:826,y:501,t:1526328782748};\\\", \\\"{x:819,y:506,t:1526328782764};\\\", \\\"{x:816,y:508,t:1526328782777};\\\", \\\"{x:806,y:516,t:1526328782794};\\\", \\\"{x:796,y:525,t:1526328782813};\\\", \\\"{x:784,y:543,t:1526328782828};\\\", \\\"{x:774,y:555,t:1526328782845};\\\", \\\"{x:764,y:566,t:1526328782863};\\\", \\\"{x:751,y:578,t:1526328782878};\\\", \\\"{x:737,y:591,t:1526328782894};\\\", \\\"{x:725,y:601,t:1526328782912};\\\", \\\"{x:709,y:610,t:1526328782930};\\\", \\\"{x:695,y:617,t:1526328782945};\\\", \\\"{x:680,y:627,t:1526328782962};\\\", \\\"{x:664,y:639,t:1526328782979};\\\", \\\"{x:649,y:650,t:1526328782994};\\\", \\\"{x:640,y:659,t:1526328783012};\\\", \\\"{x:627,y:665,t:1526328783028};\\\", \\\"{x:619,y:668,t:1526328783044};\\\", \\\"{x:612,y:670,t:1526328783061};\\\", \\\"{x:604,y:671,t:1526328783078};\\\", \\\"{x:597,y:671,t:1526328783095};\\\", \\\"{x:591,y:672,t:1526328783112};\\\", \\\"{x:589,y:672,t:1526328783129};\\\", \\\"{x:588,y:672,t:1526328783145};\\\", \\\"{x:586,y:673,t:1526328783162};\\\", \\\"{x:584,y:674,t:1526328783179};\\\", \\\"{x:581,y:675,t:1526328783195};\\\", \\\"{x:576,y:678,t:1526328783212};\\\", \\\"{x:569,y:681,t:1526328783229};\\\", \\\"{x:558,y:687,t:1526328783246};\\\", \\\"{x:548,y:694,t:1526328783262};\\\", \\\"{x:537,y:703,t:1526328783279};\\\", \\\"{x:525,y:712,t:1526328783295};\\\", \\\"{x:518,y:717,t:1526328783312};\\\", \\\"{x:509,y:725,t:1526328783330};\\\", \\\"{x:502,y:730,t:1526328783345};\\\", \\\"{x:498,y:733,t:1526328783361};\\\", \\\"{x:496,y:734,t:1526328783379};\\\", \\\"{x:495,y:735,t:1526328783941};\\\", \\\"{x:493,y:735,t:1526328783972};\\\", \\\"{x:492,y:735,t:1526328783996};\\\", \\\"{x:490,y:735,t:1526328784012};\\\", \\\"{x:488,y:735,t:1526328784036};\\\", \\\"{x:487,y:735,t:1526328784052};\\\", \\\"{x:486,y:736,t:1526328784100};\\\", \\\"{x:485,y:736,t:1526328784132};\\\", \\\"{x:484,y:736,t:1526328784172};\\\", \\\"{x:483,y:737,t:1526328784237};\\\" ] }, { \\\"rt\\\": 11870, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 650730, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:482,y:739,t:1526328785620};\\\", \\\"{x:483,y:746,t:1526328785636};\\\", \\\"{x:484,y:747,t:1526328785646};\\\", \\\"{x:485,y:753,t:1526328785664};\\\", \\\"{x:488,y:759,t:1526328785680};\\\", \\\"{x:494,y:766,t:1526328785696};\\\", \\\"{x:497,y:769,t:1526328785714};\\\", \\\"{x:502,y:772,t:1526328785731};\\\", \\\"{x:506,y:773,t:1526328785747};\\\", \\\"{x:514,y:776,t:1526328785763};\\\", \\\"{x:519,y:778,t:1526328785781};\\\", \\\"{x:524,y:780,t:1526328785797};\\\", \\\"{x:530,y:781,t:1526328785814};\\\", \\\"{x:539,y:784,t:1526328785831};\\\", \\\"{x:547,y:786,t:1526328785847};\\\", \\\"{x:560,y:788,t:1526328785865};\\\", \\\"{x:575,y:790,t:1526328785881};\\\", \\\"{x:593,y:793,t:1526328785897};\\\", \\\"{x:611,y:793,t:1526328785914};\\\", \\\"{x:625,y:794,t:1526328785931};\\\", \\\"{x:647,y:799,t:1526328785948};\\\", \\\"{x:666,y:801,t:1526328785964};\\\", \\\"{x:682,y:805,t:1526328785981};\\\", \\\"{x:697,y:809,t:1526328785998};\\\", \\\"{x:711,y:814,t:1526328786014};\\\", \\\"{x:725,y:820,t:1526328786031};\\\", \\\"{x:738,y:826,t:1526328786048};\\\", \\\"{x:751,y:832,t:1526328786064};\\\", \\\"{x:766,y:838,t:1526328786081};\\\", \\\"{x:776,y:842,t:1526328786099};\\\", \\\"{x:788,y:846,t:1526328786114};\\\", \\\"{x:795,y:847,t:1526328786131};\\\", \\\"{x:806,y:851,t:1526328786148};\\\", \\\"{x:813,y:855,t:1526328786183};\\\", \\\"{x:820,y:860,t:1526328786198};\\\", \\\"{x:820,y:861,t:1526328786215};\\\", \\\"{x:820,y:862,t:1526328787069};\\\", \\\"{x:821,y:862,t:1526328787213};\\\", \\\"{x:823,y:862,t:1526328787244};\\\", \\\"{x:824,y:861,t:1526328787261};\\\", \\\"{x:825,y:861,t:1526328787268};\\\", \\\"{x:826,y:861,t:1526328787282};\\\", \\\"{x:827,y:861,t:1526328787299};\\\", \\\"{x:830,y:858,t:1526328787316};\\\", \\\"{x:831,y:858,t:1526328787332};\\\", \\\"{x:834,y:857,t:1526328787349};\\\", \\\"{x:835,y:857,t:1526328787366};\\\", \\\"{x:837,y:855,t:1526328787383};\\\", \\\"{x:838,y:855,t:1526328787400};\\\", \\\"{x:840,y:854,t:1526328787416};\\\", \\\"{x:841,y:853,t:1526328787433};\\\", \\\"{x:843,y:852,t:1526328787450};\\\", \\\"{x:844,y:852,t:1526328787466};\\\", \\\"{x:845,y:852,t:1526328787483};\\\", \\\"{x:847,y:851,t:1526328787499};\\\", \\\"{x:849,y:850,t:1526328787517};\\\", \\\"{x:851,y:848,t:1526328787533};\\\", \\\"{x:854,y:847,t:1526328787550};\\\", \\\"{x:857,y:846,t:1526328787566};\\\", \\\"{x:861,y:844,t:1526328787583};\\\", \\\"{x:864,y:842,t:1526328787600};\\\", \\\"{x:869,y:841,t:1526328787616};\\\", \\\"{x:873,y:838,t:1526328787634};\\\", \\\"{x:878,y:837,t:1526328787649};\\\", \\\"{x:884,y:835,t:1526328787667};\\\", \\\"{x:894,y:833,t:1526328787684};\\\", \\\"{x:920,y:833,t:1526328787700};\\\", \\\"{x:944,y:833,t:1526328787717};\\\", \\\"{x:978,y:833,t:1526328787733};\\\", \\\"{x:1016,y:833,t:1526328787751};\\\", \\\"{x:1053,y:831,t:1526328787767};\\\", \\\"{x:1090,y:826,t:1526328787783};\\\", \\\"{x:1125,y:821,t:1526328787800};\\\", \\\"{x:1165,y:812,t:1526328787816};\\\", \\\"{x:1205,y:800,t:1526328787833};\\\", \\\"{x:1240,y:786,t:1526328787850};\\\", \\\"{x:1264,y:779,t:1526328787866};\\\", \\\"{x:1281,y:774,t:1526328787883};\\\", \\\"{x:1303,y:767,t:1526328787901};\\\", \\\"{x:1314,y:763,t:1526328787917};\\\", \\\"{x:1319,y:761,t:1526328787934};\\\", \\\"{x:1320,y:760,t:1526328787950};\\\", \\\"{x:1321,y:759,t:1526328787972};\\\", \\\"{x:1322,y:758,t:1526328787989};\\\", \\\"{x:1322,y:757,t:1526328788013};\\\", \\\"{x:1323,y:755,t:1526328788021};\\\", \\\"{x:1325,y:754,t:1526328788033};\\\", \\\"{x:1325,y:751,t:1526328788050};\\\", \\\"{x:1326,y:748,t:1526328788068};\\\", \\\"{x:1327,y:745,t:1526328788083};\\\", \\\"{x:1329,y:740,t:1526328788100};\\\", \\\"{x:1330,y:735,t:1526328788117};\\\", \\\"{x:1330,y:731,t:1526328788134};\\\", \\\"{x:1330,y:727,t:1526328788151};\\\", \\\"{x:1333,y:721,t:1526328788167};\\\", \\\"{x:1333,y:719,t:1526328788184};\\\", \\\"{x:1334,y:716,t:1526328788200};\\\", \\\"{x:1334,y:715,t:1526328788217};\\\", \\\"{x:1334,y:714,t:1526328788234};\\\", \\\"{x:1335,y:712,t:1526328788251};\\\", \\\"{x:1335,y:710,t:1526328788565};\\\", \\\"{x:1337,y:709,t:1526328788581};\\\", \\\"{x:1337,y:708,t:1526328788597};\\\", \\\"{x:1338,y:708,t:1526328788605};\\\", \\\"{x:1339,y:708,t:1526328788637};\\\", \\\"{x:1340,y:707,t:1526328789743};\\\", \\\"{x:1342,y:706,t:1526328789757};\\\", \\\"{x:1343,y:705,t:1526328789770};\\\", \\\"{x:1344,y:705,t:1526328789786};\\\", \\\"{x:1345,y:704,t:1526328789805};\\\", \\\"{x:1345,y:705,t:1526328790252};\\\", \\\"{x:1345,y:706,t:1526328790276};\\\", \\\"{x:1345,y:707,t:1526328790285};\\\", \\\"{x:1345,y:708,t:1526328790308};\\\", \\\"{x:1345,y:709,t:1526328790549};\\\", \\\"{x:1345,y:710,t:1526328791365};\\\", \\\"{x:1345,y:711,t:1526328791373};\\\", \\\"{x:1346,y:712,t:1526328791388};\\\", \\\"{x:1347,y:714,t:1526328791404};\\\", \\\"{x:1350,y:720,t:1526328791420};\\\", \\\"{x:1353,y:723,t:1526328791437};\\\", \\\"{x:1356,y:727,t:1526328791454};\\\", \\\"{x:1357,y:729,t:1526328791470};\\\", \\\"{x:1358,y:732,t:1526328791488};\\\", \\\"{x:1359,y:735,t:1526328791503};\\\", \\\"{x:1360,y:737,t:1526328791520};\\\", \\\"{x:1360,y:740,t:1526328791538};\\\", \\\"{x:1361,y:743,t:1526328791554};\\\", \\\"{x:1361,y:746,t:1526328791571};\\\", \\\"{x:1361,y:747,t:1526328791588};\\\", \\\"{x:1361,y:750,t:1526328791604};\\\", \\\"{x:1361,y:752,t:1526328791621};\\\", \\\"{x:1361,y:754,t:1526328791638};\\\", \\\"{x:1361,y:757,t:1526328791654};\\\", \\\"{x:1359,y:760,t:1526328791671};\\\", \\\"{x:1359,y:762,t:1526328791687};\\\", \\\"{x:1358,y:763,t:1526328791705};\\\", \\\"{x:1356,y:765,t:1526328791722};\\\", \\\"{x:1355,y:767,t:1526328791738};\\\", \\\"{x:1353,y:768,t:1526328791757};\\\", \\\"{x:1353,y:769,t:1526328791796};\\\", \\\"{x:1352,y:770,t:1526328791845};\\\", \\\"{x:1351,y:770,t:1526328791860};\\\", \\\"{x:1350,y:770,t:1526328792308};\\\", \\\"{x:1346,y:770,t:1526328792324};\\\", \\\"{x:1342,y:770,t:1526328792340};\\\", \\\"{x:1331,y:770,t:1526328792355};\\\", \\\"{x:1319,y:768,t:1526328792371};\\\", \\\"{x:1298,y:767,t:1526328792388};\\\", \\\"{x:1283,y:767,t:1526328792405};\\\", \\\"{x:1263,y:766,t:1526328792421};\\\", \\\"{x:1239,y:762,t:1526328792438};\\\", \\\"{x:1213,y:759,t:1526328792456};\\\", \\\"{x:1168,y:752,t:1526328792471};\\\", \\\"{x:1117,y:745,t:1526328792488};\\\", \\\"{x:1046,y:727,t:1526328792505};\\\", \\\"{x:960,y:702,t:1526328792521};\\\", \\\"{x:870,y:671,t:1526328792539};\\\", \\\"{x:771,y:630,t:1526328792556};\\\", \\\"{x:632,y:585,t:1526328792573};\\\", \\\"{x:572,y:565,t:1526328792588};\\\", \\\"{x:547,y:557,t:1526328792602};\\\", \\\"{x:513,y:546,t:1526328792619};\\\", \\\"{x:488,y:539,t:1526328792637};\\\", \\\"{x:483,y:536,t:1526328792653};\\\", \\\"{x:480,y:535,t:1526328792669};\\\", \\\"{x:479,y:533,t:1526328792686};\\\", \\\"{x:478,y:533,t:1526328792804};\\\", \\\"{x:474,y:533,t:1526328792820};\\\", \\\"{x:470,y:533,t:1526328792836};\\\", \\\"{x:461,y:533,t:1526328792853};\\\", \\\"{x:446,y:538,t:1526328792870};\\\", \\\"{x:428,y:540,t:1526328792886};\\\", \\\"{x:404,y:543,t:1526328792904};\\\", \\\"{x:386,y:545,t:1526328792920};\\\", \\\"{x:370,y:545,t:1526328792937};\\\", \\\"{x:355,y:545,t:1526328792953};\\\", \\\"{x:346,y:546,t:1526328792969};\\\", \\\"{x:340,y:547,t:1526328792987};\\\", \\\"{x:337,y:548,t:1526328793004};\\\", \\\"{x:336,y:548,t:1526328793020};\\\", \\\"{x:334,y:549,t:1526328793036};\\\", \\\"{x:333,y:549,t:1526328793054};\\\", \\\"{x:331,y:550,t:1526328793070};\\\", \\\"{x:330,y:551,t:1526328793087};\\\", \\\"{x:325,y:551,t:1526328793104};\\\", \\\"{x:317,y:551,t:1526328793120};\\\", \\\"{x:307,y:551,t:1526328793137};\\\", \\\"{x:294,y:551,t:1526328793154};\\\", \\\"{x:277,y:551,t:1526328793170};\\\", \\\"{x:261,y:551,t:1526328793188};\\\", \\\"{x:247,y:551,t:1526328793203};\\\", \\\"{x:235,y:551,t:1526328793220};\\\", \\\"{x:228,y:551,t:1526328793237};\\\", \\\"{x:224,y:551,t:1526328793254};\\\", \\\"{x:223,y:551,t:1526328793270};\\\", \\\"{x:220,y:551,t:1526328793287};\\\", \\\"{x:216,y:550,t:1526328793304};\\\", \\\"{x:209,y:550,t:1526328793320};\\\", \\\"{x:203,y:549,t:1526328793337};\\\", \\\"{x:198,y:547,t:1526328793354};\\\", \\\"{x:189,y:547,t:1526328793370};\\\", \\\"{x:185,y:547,t:1526328793387};\\\", \\\"{x:177,y:547,t:1526328793403};\\\", \\\"{x:175,y:547,t:1526328793419};\\\", \\\"{x:171,y:547,t:1526328793436};\\\", \\\"{x:168,y:546,t:1526328793453};\\\", \\\"{x:166,y:544,t:1526328793471};\\\", \\\"{x:165,y:544,t:1526328793486};\\\", \\\"{x:165,y:546,t:1526328796077};\\\", \\\"{x:166,y:549,t:1526328796092};\\\", \\\"{x:168,y:550,t:1526328796106};\\\", \\\"{x:170,y:556,t:1526328796124};\\\", \\\"{x:176,y:563,t:1526328796140};\\\", \\\"{x:188,y:579,t:1526328796156};\\\", \\\"{x:198,y:590,t:1526328796172};\\\", \\\"{x:209,y:600,t:1526328796189};\\\", \\\"{x:219,y:609,t:1526328796206};\\\", \\\"{x:229,y:615,t:1526328796222};\\\", \\\"{x:240,y:625,t:1526328796238};\\\", \\\"{x:254,y:640,t:1526328796256};\\\", \\\"{x:265,y:652,t:1526328796273};\\\", \\\"{x:275,y:666,t:1526328796289};\\\", \\\"{x:291,y:680,t:1526328796306};\\\", \\\"{x:303,y:692,t:1526328796323};\\\", \\\"{x:315,y:699,t:1526328796339};\\\", \\\"{x:331,y:706,t:1526328796355};\\\", \\\"{x:348,y:709,t:1526328796372};\\\", \\\"{x:384,y:715,t:1526328796388};\\\", \\\"{x:423,y:725,t:1526328796405};\\\", \\\"{x:457,y:732,t:1526328796423};\\\", \\\"{x:479,y:735,t:1526328796438};\\\", \\\"{x:497,y:737,t:1526328796456};\\\", \\\"{x:509,y:739,t:1526328796472};\\\", \\\"{x:515,y:740,t:1526328796488};\\\", \\\"{x:521,y:740,t:1526328796505};\\\", \\\"{x:522,y:740,t:1526328796523};\\\" ] }, { \\\"rt\\\": 37148, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 689234, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -Z -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:740,t:1526328799483};\\\", \\\"{x:526,y:740,t:1526328799492};\\\", \\\"{x:530,y:739,t:1526328799506};\\\", \\\"{x:558,y:739,t:1526328799531};\\\", \\\"{x:563,y:739,t:1526328799539};\\\", \\\"{x:579,y:739,t:1526328799557};\\\", \\\"{x:594,y:738,t:1526328799573};\\\", \\\"{x:610,y:738,t:1526328799591};\\\", \\\"{x:624,y:738,t:1526328799608};\\\", \\\"{x:634,y:738,t:1526328799625};\\\", \\\"{x:648,y:738,t:1526328799642};\\\", \\\"{x:660,y:737,t:1526328799658};\\\", \\\"{x:671,y:737,t:1526328799675};\\\", \\\"{x:688,y:737,t:1526328799692};\\\", \\\"{x:694,y:737,t:1526328799709};\\\", \\\"{x:703,y:735,t:1526328799725};\\\", \\\"{x:710,y:735,t:1526328799742};\\\", \\\"{x:716,y:735,t:1526328799759};\\\", \\\"{x:720,y:735,t:1526328799775};\\\", \\\"{x:725,y:735,t:1526328799792};\\\", \\\"{x:733,y:733,t:1526328799809};\\\", \\\"{x:739,y:731,t:1526328799826};\\\", \\\"{x:747,y:730,t:1526328799843};\\\", \\\"{x:756,y:730,t:1526328799858};\\\", \\\"{x:764,y:729,t:1526328799876};\\\", \\\"{x:776,y:725,t:1526328799892};\\\", \\\"{x:781,y:725,t:1526328799908};\\\", \\\"{x:784,y:725,t:1526328799925};\\\", \\\"{x:788,y:725,t:1526328799942};\\\", \\\"{x:790,y:725,t:1526328799958};\\\", \\\"{x:791,y:725,t:1526328804284};\\\", \\\"{x:800,y:727,t:1526328804300};\\\", \\\"{x:804,y:729,t:1526328804312};\\\", \\\"{x:812,y:732,t:1526328804329};\\\", \\\"{x:822,y:734,t:1526328804346};\\\", \\\"{x:831,y:736,t:1526328804362};\\\", \\\"{x:844,y:738,t:1526328804379};\\\", \\\"{x:867,y:741,t:1526328804396};\\\", \\\"{x:883,y:745,t:1526328804412};\\\", \\\"{x:901,y:748,t:1526328804429};\\\", \\\"{x:917,y:749,t:1526328804446};\\\", \\\"{x:935,y:749,t:1526328804463};\\\", \\\"{x:962,y:749,t:1526328804479};\\\", \\\"{x:991,y:749,t:1526328804497};\\\", \\\"{x:1034,y:751,t:1526328804513};\\\", \\\"{x:1076,y:763,t:1526328804529};\\\", \\\"{x:1115,y:772,t:1526328804546};\\\", \\\"{x:1143,y:776,t:1526328804564};\\\", \\\"{x:1170,y:782,t:1526328804580};\\\", \\\"{x:1216,y:794,t:1526328804596};\\\", \\\"{x:1237,y:796,t:1526328804613};\\\", \\\"{x:1255,y:801,t:1526328804629};\\\", \\\"{x:1269,y:802,t:1526328804646};\\\", \\\"{x:1278,y:803,t:1526328804663};\\\", \\\"{x:1286,y:803,t:1526328804679};\\\", \\\"{x:1297,y:803,t:1526328804697};\\\", \\\"{x:1306,y:803,t:1526328804713};\\\", \\\"{x:1311,y:803,t:1526328804729};\\\", \\\"{x:1317,y:803,t:1526328804746};\\\", \\\"{x:1324,y:803,t:1526328804763};\\\", \\\"{x:1336,y:803,t:1526328804779};\\\", \\\"{x:1363,y:803,t:1526328804796};\\\", \\\"{x:1385,y:803,t:1526328804813};\\\", \\\"{x:1406,y:803,t:1526328804829};\\\", \\\"{x:1422,y:801,t:1526328804846};\\\", \\\"{x:1440,y:800,t:1526328804863};\\\", \\\"{x:1459,y:796,t:1526328804879};\\\", \\\"{x:1478,y:794,t:1526328804895};\\\", \\\"{x:1492,y:791,t:1526328804913};\\\", \\\"{x:1505,y:789,t:1526328804929};\\\", \\\"{x:1513,y:787,t:1526328804946};\\\", \\\"{x:1518,y:785,t:1526328804962};\\\", \\\"{x:1524,y:782,t:1526328804980};\\\", \\\"{x:1526,y:780,t:1526328804996};\\\", \\\"{x:1530,y:778,t:1526328805013};\\\", \\\"{x:1535,y:775,t:1526328805030};\\\", \\\"{x:1541,y:772,t:1526328805046};\\\", \\\"{x:1546,y:767,t:1526328805063};\\\", \\\"{x:1547,y:765,t:1526328805080};\\\", \\\"{x:1551,y:759,t:1526328805096};\\\", \\\"{x:1557,y:752,t:1526328805113};\\\", \\\"{x:1561,y:746,t:1526328805130};\\\", \\\"{x:1565,y:739,t:1526328805145};\\\", \\\"{x:1570,y:731,t:1526328805163};\\\", \\\"{x:1580,y:715,t:1526328805179};\\\", \\\"{x:1583,y:709,t:1526328805196};\\\", \\\"{x:1587,y:705,t:1526328805213};\\\", \\\"{x:1591,y:698,t:1526328805230};\\\", \\\"{x:1596,y:693,t:1526328805246};\\\", \\\"{x:1599,y:689,t:1526328805263};\\\", \\\"{x:1604,y:686,t:1526328805280};\\\", \\\"{x:1608,y:683,t:1526328805296};\\\", \\\"{x:1609,y:682,t:1526328805313};\\\", \\\"{x:1611,y:683,t:1526328805437};\\\", \\\"{x:1611,y:691,t:1526328805453};\\\", \\\"{x:1611,y:694,t:1526328805466};\\\", \\\"{x:1611,y:698,t:1526328805480};\\\", \\\"{x:1611,y:701,t:1526328805496};\\\", \\\"{x:1611,y:703,t:1526328805513};\\\", \\\"{x:1611,y:704,t:1526328805530};\\\", \\\"{x:1611,y:703,t:1526328805853};\\\", \\\"{x:1611,y:702,t:1526328805864};\\\", \\\"{x:1611,y:701,t:1526328805880};\\\", \\\"{x:1611,y:700,t:1526328805948};\\\", \\\"{x:1614,y:698,t:1526328813253};\\\", \\\"{x:1614,y:697,t:1526328813273};\\\", \\\"{x:1614,y:695,t:1526328813413};\\\", \\\"{x:1614,y:694,t:1526328813436};\\\", \\\"{x:1611,y:691,t:1526328813453};\\\", \\\"{x:1606,y:690,t:1526328813470};\\\", \\\"{x:1600,y:687,t:1526328813485};\\\", \\\"{x:1594,y:686,t:1526328813502};\\\", \\\"{x:1580,y:684,t:1526328813519};\\\", \\\"{x:1558,y:684,t:1526328813535};\\\", \\\"{x:1504,y:684,t:1526328813552};\\\", \\\"{x:1426,y:684,t:1526328813568};\\\", \\\"{x:1354,y:684,t:1526328813585};\\\", \\\"{x:1295,y:684,t:1526328813601};\\\", \\\"{x:1253,y:684,t:1526328813619};\\\", \\\"{x:1210,y:691,t:1526328813635};\\\", \\\"{x:1153,y:704,t:1526328813651};\\\", \\\"{x:1126,y:706,t:1526328813668};\\\", \\\"{x:1111,y:709,t:1526328813685};\\\", \\\"{x:1105,y:711,t:1526328813702};\\\", \\\"{x:1101,y:714,t:1526328813719};\\\", \\\"{x:1095,y:717,t:1526328813736};\\\", \\\"{x:1084,y:722,t:1526328813752};\\\", \\\"{x:1078,y:723,t:1526328813769};\\\", \\\"{x:1069,y:724,t:1526328813786};\\\", \\\"{x:1055,y:724,t:1526328813801};\\\", \\\"{x:1031,y:715,t:1526328813819};\\\", \\\"{x:960,y:692,t:1526328813836};\\\", \\\"{x:929,y:676,t:1526328813852};\\\", \\\"{x:906,y:661,t:1526328813869};\\\", \\\"{x:884,y:648,t:1526328813886};\\\", \\\"{x:865,y:632,t:1526328813902};\\\", \\\"{x:836,y:613,t:1526328813920};\\\", \\\"{x:795,y:598,t:1526328813936};\\\", \\\"{x:747,y:583,t:1526328813952};\\\", \\\"{x:715,y:577,t:1526328813969};\\\", \\\"{x:691,y:571,t:1526328813985};\\\", \\\"{x:665,y:565,t:1526328814002};\\\", \\\"{x:643,y:560,t:1526328814019};\\\", \\\"{x:628,y:555,t:1526328814035};\\\", \\\"{x:622,y:554,t:1526328814053};\\\", \\\"{x:614,y:554,t:1526328814069};\\\", \\\"{x:606,y:554,t:1526328814085};\\\", \\\"{x:600,y:554,t:1526328814103};\\\", \\\"{x:598,y:554,t:1526328814118};\\\", \\\"{x:596,y:555,t:1526328814135};\\\", \\\"{x:596,y:556,t:1526328814172};\\\", \\\"{x:596,y:557,t:1526328814187};\\\", \\\"{x:595,y:558,t:1526328814203};\\\", \\\"{x:595,y:559,t:1526328814218};\\\", \\\"{x:595,y:563,t:1526328814236};\\\", \\\"{x:596,y:566,t:1526328814252};\\\", \\\"{x:596,y:568,t:1526328814269};\\\", \\\"{x:596,y:571,t:1526328814286};\\\", \\\"{x:597,y:573,t:1526328814303};\\\", \\\"{x:597,y:574,t:1526328814319};\\\", \\\"{x:598,y:576,t:1526328814335};\\\", \\\"{x:599,y:576,t:1526328814356};\\\", \\\"{x:600,y:576,t:1526328814373};\\\", \\\"{x:602,y:576,t:1526328814420};\\\", \\\"{x:603,y:576,t:1526328814437};\\\", \\\"{x:605,y:575,t:1526328814611};\\\", \\\"{x:609,y:575,t:1526328814651};\\\", \\\"{x:614,y:575,t:1526328814660};\\\", \\\"{x:626,y:575,t:1526328814669};\\\", \\\"{x:686,y:581,t:1526328814686};\\\", \\\"{x:799,y:595,t:1526328814704};\\\", \\\"{x:927,y:616,t:1526328814720};\\\", \\\"{x:1057,y:632,t:1526328814736};\\\", \\\"{x:1207,y:654,t:1526328814753};\\\", \\\"{x:1347,y:669,t:1526328814770};\\\", \\\"{x:1476,y:679,t:1526328814786};\\\", \\\"{x:1589,y:689,t:1526328814803};\\\", \\\"{x:1728,y:691,t:1526328814819};\\\", \\\"{x:1787,y:691,t:1526328814836};\\\", \\\"{x:1842,y:691,t:1526328814853};\\\", \\\"{x:1878,y:691,t:1526328814870};\\\", \\\"{x:1901,y:691,t:1526328814886};\\\", \\\"{x:1915,y:691,t:1526328814904};\\\", \\\"{x:1919,y:692,t:1526328814920};\\\", \\\"{x:1918,y:690,t:1526328815020};\\\", \\\"{x:1909,y:685,t:1526328815037};\\\", \\\"{x:1891,y:676,t:1526328815052};\\\", \\\"{x:1873,y:669,t:1526328815069};\\\", \\\"{x:1853,y:664,t:1526328815087};\\\", \\\"{x:1816,y:659,t:1526328815104};\\\", \\\"{x:1769,y:653,t:1526328815120};\\\", \\\"{x:1731,y:650,t:1526328815137};\\\", \\\"{x:1691,y:650,t:1526328815153};\\\", \\\"{x:1655,y:650,t:1526328815170};\\\", \\\"{x:1624,y:650,t:1526328815187};\\\", \\\"{x:1579,y:650,t:1526328815203};\\\", \\\"{x:1557,y:652,t:1526328815220};\\\", \\\"{x:1550,y:653,t:1526328815237};\\\", \\\"{x:1548,y:653,t:1526328815253};\\\", \\\"{x:1547,y:654,t:1526328815420};\\\", \\\"{x:1546,y:654,t:1526328816012};\\\", \\\"{x:1545,y:654,t:1526328816029};\\\", \\\"{x:1543,y:654,t:1526328816085};\\\", \\\"{x:1542,y:655,t:1526328816092};\\\", \\\"{x:1540,y:656,t:1526328816116};\\\", \\\"{x:1538,y:656,t:1526328816132};\\\", \\\"{x:1536,y:656,t:1526328816140};\\\", \\\"{x:1535,y:657,t:1526328816155};\\\", \\\"{x:1532,y:657,t:1526328816171};\\\", \\\"{x:1531,y:658,t:1526328816189};\\\", \\\"{x:1529,y:659,t:1526328816205};\\\", \\\"{x:1527,y:660,t:1526328816222};\\\", \\\"{x:1525,y:660,t:1526328816239};\\\", \\\"{x:1523,y:662,t:1526328816256};\\\", \\\"{x:1522,y:662,t:1526328816271};\\\", \\\"{x:1520,y:663,t:1526328816289};\\\", \\\"{x:1519,y:663,t:1526328816309};\\\", \\\"{x:1519,y:664,t:1526328816973};\\\", \\\"{x:1519,y:666,t:1526328816996};\\\", \\\"{x:1519,y:667,t:1526328817006};\\\", \\\"{x:1519,y:668,t:1526328817023};\\\", \\\"{x:1520,y:671,t:1526328817039};\\\", \\\"{x:1520,y:672,t:1526328817067};\\\", \\\"{x:1521,y:673,t:1526328817076};\\\", \\\"{x:1523,y:673,t:1526328817092};\\\", \\\"{x:1526,y:673,t:1526328817106};\\\", \\\"{x:1530,y:673,t:1526328817123};\\\", \\\"{x:1539,y:675,t:1526328817140};\\\", \\\"{x:1544,y:676,t:1526328817155};\\\", \\\"{x:1546,y:678,t:1526328817172};\\\", \\\"{x:1550,y:681,t:1526328817190};\\\", \\\"{x:1551,y:683,t:1526328817207};\\\", \\\"{x:1556,y:687,t:1526328817223};\\\", \\\"{x:1561,y:691,t:1526328817240};\\\", \\\"{x:1569,y:696,t:1526328817257};\\\", \\\"{x:1584,y:701,t:1526328817274};\\\", \\\"{x:1593,y:705,t:1526328817289};\\\", \\\"{x:1597,y:708,t:1526328817307};\\\", \\\"{x:1598,y:709,t:1526328817325};\\\", \\\"{x:1599,y:709,t:1526328817556};\\\", \\\"{x:1601,y:709,t:1526328817574};\\\", \\\"{x:1603,y:706,t:1526328817590};\\\", \\\"{x:1604,y:705,t:1526328817607};\\\", \\\"{x:1604,y:704,t:1526328817624};\\\", \\\"{x:1605,y:703,t:1526328829829};\\\", \\\"{x:1607,y:701,t:1526328829844};\\\", \\\"{x:1608,y:701,t:1526328829860};\\\", \\\"{x:1608,y:700,t:1526328829873};\\\", \\\"{x:1608,y:699,t:1526328829890};\\\", \\\"{x:1608,y:698,t:1526328829906};\\\", \\\"{x:1602,y:697,t:1526328830397};\\\", \\\"{x:1591,y:697,t:1526328830411};\\\", \\\"{x:1564,y:697,t:1526328830427};\\\", \\\"{x:1530,y:696,t:1526328830441};\\\", \\\"{x:1496,y:696,t:1526328830456};\\\", \\\"{x:1457,y:696,t:1526328830474};\\\", \\\"{x:1401,y:696,t:1526328830490};\\\", \\\"{x:1324,y:696,t:1526328830507};\\\", \\\"{x:1191,y:689,t:1526328830525};\\\", \\\"{x:1101,y:681,t:1526328830540};\\\", \\\"{x:1017,y:681,t:1526328830557};\\\", \\\"{x:926,y:681,t:1526328830574};\\\", \\\"{x:826,y:681,t:1526328830591};\\\", \\\"{x:723,y:681,t:1526328830608};\\\", \\\"{x:624,y:681,t:1526328830623};\\\", \\\"{x:532,y:681,t:1526328830640};\\\", \\\"{x:492,y:681,t:1526328830658};\\\", \\\"{x:474,y:680,t:1526328830674};\\\", \\\"{x:461,y:678,t:1526328830691};\\\", \\\"{x:442,y:669,t:1526328830709};\\\", \\\"{x:426,y:660,t:1526328830723};\\\", \\\"{x:415,y:654,t:1526328830740};\\\", \\\"{x:400,y:644,t:1526328830763};\\\", \\\"{x:392,y:637,t:1526328830780};\\\", \\\"{x:385,y:631,t:1526328830796};\\\", \\\"{x:380,y:626,t:1526328830816};\\\", \\\"{x:376,y:622,t:1526328830832};\\\", \\\"{x:373,y:616,t:1526328830849};\\\", \\\"{x:370,y:610,t:1526328830866};\\\", \\\"{x:367,y:601,t:1526328830882};\\\", \\\"{x:365,y:597,t:1526328830899};\\\", \\\"{x:365,y:593,t:1526328830916};\\\", \\\"{x:363,y:590,t:1526328830932};\\\", \\\"{x:363,y:588,t:1526328830949};\\\", \\\"{x:362,y:585,t:1526328830966};\\\", \\\"{x:362,y:582,t:1526328830983};\\\", \\\"{x:362,y:578,t:1526328831000};\\\", \\\"{x:362,y:575,t:1526328831016};\\\", \\\"{x:362,y:571,t:1526328831033};\\\", \\\"{x:362,y:567,t:1526328831049};\\\", \\\"{x:362,y:565,t:1526328831066};\\\", \\\"{x:362,y:561,t:1526328831084};\\\", \\\"{x:362,y:560,t:1526328831099};\\\", \\\"{x:362,y:557,t:1526328831115};\\\", \\\"{x:363,y:555,t:1526328831134};\\\", \\\"{x:363,y:554,t:1526328831149};\\\", \\\"{x:364,y:551,t:1526328831166};\\\", \\\"{x:366,y:548,t:1526328831183};\\\", \\\"{x:367,y:547,t:1526328831200};\\\", \\\"{x:370,y:544,t:1526328831216};\\\", \\\"{x:377,y:538,t:1526328831234};\\\", \\\"{x:389,y:532,t:1526328831250};\\\", \\\"{x:406,y:526,t:1526328831266};\\\", \\\"{x:436,y:516,t:1526328831283};\\\", \\\"{x:454,y:510,t:1526328831299};\\\", \\\"{x:475,y:505,t:1526328831316};\\\", \\\"{x:497,y:502,t:1526328831333};\\\", \\\"{x:522,y:498,t:1526328831351};\\\", \\\"{x:546,y:497,t:1526328831367};\\\", \\\"{x:567,y:497,t:1526328831383};\\\", \\\"{x:583,y:497,t:1526328831401};\\\", \\\"{x:594,y:497,t:1526328831417};\\\", \\\"{x:598,y:497,t:1526328831434};\\\", \\\"{x:601,y:497,t:1526328831451};\\\", \\\"{x:612,y:497,t:1526328831467};\\\", \\\"{x:619,y:497,t:1526328831484};\\\", \\\"{x:625,y:497,t:1526328831501};\\\", \\\"{x:628,y:497,t:1526328831517};\\\", \\\"{x:632,y:498,t:1526328831533};\\\", \\\"{x:636,y:498,t:1526328831550};\\\", \\\"{x:643,y:499,t:1526328831568};\\\", \\\"{x:649,y:500,t:1526328831582};\\\", \\\"{x:652,y:501,t:1526328831600};\\\", \\\"{x:653,y:501,t:1526328831617};\\\", \\\"{x:657,y:502,t:1526328831633};\\\", \\\"{x:663,y:502,t:1526328831650};\\\", \\\"{x:682,y:505,t:1526328831667};\\\", \\\"{x:691,y:505,t:1526328831683};\\\", \\\"{x:698,y:508,t:1526328831700};\\\", \\\"{x:705,y:508,t:1526328831717};\\\", \\\"{x:711,y:510,t:1526328831733};\\\", \\\"{x:721,y:510,t:1526328831750};\\\", \\\"{x:736,y:510,t:1526328831769};\\\", \\\"{x:750,y:510,t:1526328831783};\\\", \\\"{x:759,y:510,t:1526328831799};\\\", \\\"{x:766,y:510,t:1526328831817};\\\", \\\"{x:772,y:510,t:1526328831834};\\\", \\\"{x:777,y:510,t:1526328831850};\\\", \\\"{x:781,y:510,t:1526328831867};\\\", \\\"{x:782,y:510,t:1526328831899};\\\", \\\"{x:785,y:510,t:1526328831907};\\\", \\\"{x:787,y:510,t:1526328831917};\\\", \\\"{x:791,y:510,t:1526328831934};\\\", \\\"{x:794,y:510,t:1526328831950};\\\", \\\"{x:797,y:510,t:1526328832020};\\\", \\\"{x:804,y:508,t:1526328832036};\\\", \\\"{x:808,y:508,t:1526328832051};\\\", \\\"{x:816,y:507,t:1526328832068};\\\", \\\"{x:818,y:506,t:1526328832084};\\\", \\\"{x:821,y:506,t:1526328832148};\\\", \\\"{x:822,y:506,t:1526328832156};\\\", \\\"{x:826,y:506,t:1526328832173};\\\", \\\"{x:829,y:506,t:1526328832184};\\\", \\\"{x:832,y:506,t:1526328832200};\\\", \\\"{x:833,y:506,t:1526328832217};\\\", \\\"{x:834,y:506,t:1526328832707};\\\", \\\"{x:834,y:507,t:1526328832724};\\\", \\\"{x:834,y:508,t:1526328832739};\\\", \\\"{x:834,y:509,t:1526328832751};\\\", \\\"{x:835,y:512,t:1526328832767};\\\", \\\"{x:835,y:513,t:1526328832785};\\\", \\\"{x:835,y:514,t:1526328832802};\\\", \\\"{x:836,y:516,t:1526328832817};\\\", \\\"{x:836,y:517,t:1526328832834};\\\", \\\"{x:836,y:518,t:1526328832852};\\\", \\\"{x:836,y:519,t:1526328832867};\\\", \\\"{x:836,y:520,t:1526328832899};\\\", \\\"{x:837,y:522,t:1526328832908};\\\", \\\"{x:839,y:524,t:1526328832925};\\\", \\\"{x:839,y:525,t:1526328832942};\\\", \\\"{x:839,y:527,t:1526328832956};\\\", \\\"{x:839,y:528,t:1526328832968};\\\", \\\"{x:840,y:529,t:1526328832984};\\\", \\\"{x:841,y:531,t:1526328833001};\\\", \\\"{x:841,y:533,t:1526328833017};\\\", \\\"{x:842,y:533,t:1526328833035};\\\", \\\"{x:842,y:534,t:1526328833050};\\\", \\\"{x:843,y:535,t:1526328834100};\\\", \\\"{x:844,y:535,t:1526328834108};\\\", \\\"{x:845,y:535,t:1526328834126};\\\", \\\"{x:846,y:535,t:1526328834148};\\\", \\\"{x:847,y:535,t:1526328834164};\\\", \\\"{x:848,y:535,t:1526328834171};\\\", \\\"{x:848,y:538,t:1526328834186};\\\", \\\"{x:844,y:544,t:1526328834207};\\\", \\\"{x:837,y:552,t:1526328834218};\\\", \\\"{x:821,y:562,t:1526328834235};\\\", \\\"{x:802,y:574,t:1526328834252};\\\", \\\"{x:779,y:587,t:1526328834269};\\\", \\\"{x:753,y:603,t:1526328834285};\\\", \\\"{x:731,y:617,t:1526328834302};\\\", \\\"{x:713,y:630,t:1526328834320};\\\", \\\"{x:698,y:641,t:1526328834336};\\\", \\\"{x:689,y:648,t:1526328834353};\\\", \\\"{x:681,y:652,t:1526328834368};\\\", \\\"{x:674,y:655,t:1526328834385};\\\", \\\"{x:669,y:656,t:1526328834403};\\\", \\\"{x:667,y:657,t:1526328834419};\\\", \\\"{x:663,y:660,t:1526328834435};\\\", \\\"{x:660,y:664,t:1526328834453};\\\", \\\"{x:655,y:669,t:1526328834469};\\\", \\\"{x:650,y:672,t:1526328834485};\\\", \\\"{x:634,y:679,t:1526328834503};\\\", \\\"{x:614,y:685,t:1526328834518};\\\", \\\"{x:591,y:690,t:1526328834536};\\\", \\\"{x:569,y:694,t:1526328834552};\\\", \\\"{x:544,y:696,t:1526328834568};\\\", \\\"{x:523,y:697,t:1526328834586};\\\", \\\"{x:507,y:699,t:1526328834603};\\\", \\\"{x:495,y:701,t:1526328834618};\\\", \\\"{x:488,y:702,t:1526328834636};\\\", \\\"{x:485,y:704,t:1526328834653};\\\", \\\"{x:483,y:705,t:1526328834669};\\\", \\\"{x:482,y:707,t:1526328834686};\\\", \\\"{x:482,y:708,t:1526328834702};\\\", \\\"{x:482,y:713,t:1526328834719};\\\", \\\"{x:482,y:721,t:1526328834737};\\\", \\\"{x:484,y:733,t:1526328834752};\\\", \\\"{x:486,y:741,t:1526328834768};\\\", \\\"{x:489,y:751,t:1526328834785};\\\", \\\"{x:493,y:759,t:1526328834802};\\\", \\\"{x:496,y:762,t:1526328834817};\\\", \\\"{x:498,y:763,t:1526328834836};\\\", \\\"{x:497,y:762,t:1526328834940};\\\", \\\"{x:493,y:755,t:1526328834956};\\\", \\\"{x:493,y:753,t:1526328834970};\\\", \\\"{x:492,y:746,t:1526328834986};\\\", \\\"{x:491,y:739,t:1526328835003};\\\", \\\"{x:491,y:737,t:1526328835019};\\\", \\\"{x:491,y:736,t:1526328835037};\\\", \\\"{x:491,y:734,t:1526328835053};\\\", \\\"{x:491,y:733,t:1526328835069};\\\", \\\"{x:490,y:730,t:1526328835086};\\\", \\\"{x:490,y:729,t:1526328835403};\\\" ] }, { \\\"rt\\\": 59071, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 749529, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-12 PM-01 PM-02:30-03:30-03 PM-B -N -03 PM-3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:729,t:1526328837107};\\\", \\\"{x:489,y:731,t:1526328837127};\\\", \\\"{x:487,y:734,t:1526328837138};\\\", \\\"{x:482,y:739,t:1526328837155};\\\", \\\"{x:478,y:741,t:1526328837171};\\\", \\\"{x:476,y:744,t:1526328837188};\\\", \\\"{x:474,y:745,t:1526328837205};\\\", \\\"{x:474,y:746,t:1526328837235};\\\", \\\"{x:475,y:749,t:1526328837411};\\\", \\\"{x:483,y:755,t:1526328837427};\\\", \\\"{x:487,y:758,t:1526328837438};\\\", \\\"{x:493,y:761,t:1526328837455};\\\", \\\"{x:496,y:764,t:1526328837472};\\\", \\\"{x:502,y:767,t:1526328837488};\\\", \\\"{x:517,y:771,t:1526328837504};\\\", \\\"{x:542,y:776,t:1526328837521};\\\", \\\"{x:579,y:779,t:1526328837538};\\\", \\\"{x:629,y:779,t:1526328837554};\\\", \\\"{x:679,y:779,t:1526328837571};\\\", \\\"{x:716,y:769,t:1526328837588};\\\", \\\"{x:766,y:758,t:1526328837604};\\\", \\\"{x:834,y:744,t:1526328837622};\\\", \\\"{x:898,y:736,t:1526328837638};\\\", \\\"{x:949,y:733,t:1526328837655};\\\", \\\"{x:994,y:733,t:1526328837672};\\\", \\\"{x:1044,y:733,t:1526328837688};\\\", \\\"{x:1083,y:733,t:1526328837705};\\\", \\\"{x:1109,y:732,t:1526328837722};\\\", \\\"{x:1124,y:732,t:1526328837739};\\\", \\\"{x:1127,y:732,t:1526328837755};\\\", \\\"{x:1126,y:732,t:1526328837916};\\\", \\\"{x:1122,y:732,t:1526328837924};\\\", \\\"{x:1111,y:732,t:1526328837940};\\\", \\\"{x:1100,y:732,t:1526328837955};\\\", \\\"{x:1066,y:732,t:1526328837972};\\\", \\\"{x:1045,y:732,t:1526328837989};\\\", \\\"{x:1022,y:732,t:1526328838005};\\\", \\\"{x:994,y:732,t:1526328838022};\\\", \\\"{x:970,y:732,t:1526328838039};\\\", \\\"{x:947,y:732,t:1526328838055};\\\", \\\"{x:933,y:732,t:1526328838071};\\\", \\\"{x:930,y:732,t:1526328838089};\\\", \\\"{x:928,y:732,t:1526328838123};\\\", \\\"{x:927,y:732,t:1526328839348};\\\", \\\"{x:925,y:733,t:1526328839355};\\\", \\\"{x:917,y:737,t:1526328839378};\\\", \\\"{x:912,y:737,t:1526328839389};\\\", \\\"{x:904,y:739,t:1526328839406};\\\", \\\"{x:895,y:742,t:1526328839422};\\\", \\\"{x:889,y:742,t:1526328839440};\\\", \\\"{x:880,y:743,t:1526328839456};\\\", \\\"{x:874,y:744,t:1526328839472};\\\", \\\"{x:870,y:745,t:1526328839490};\\\", \\\"{x:866,y:746,t:1526328839506};\\\", \\\"{x:864,y:746,t:1526328839523};\\\", \\\"{x:861,y:746,t:1526328839539};\\\", \\\"{x:860,y:746,t:1526328839556};\\\", \\\"{x:859,y:746,t:1526328839573};\\\", \\\"{x:858,y:746,t:1526328839589};\\\", \\\"{x:857,y:746,t:1526328839611};\\\", \\\"{x:856,y:747,t:1526328839635};\\\", \\\"{x:856,y:751,t:1526328842205};\\\", \\\"{x:856,y:757,t:1526328842211};\\\", \\\"{x:865,y:776,t:1526328842227};\\\", \\\"{x:876,y:791,t:1526328842242};\\\", \\\"{x:896,y:824,t:1526328842257};\\\", \\\"{x:920,y:854,t:1526328842275};\\\", \\\"{x:981,y:912,t:1526328842292};\\\", \\\"{x:1013,y:939,t:1526328842307};\\\", \\\"{x:1042,y:960,t:1526328842325};\\\", \\\"{x:1060,y:972,t:1526328842341};\\\", \\\"{x:1076,y:979,t:1526328842357};\\\", \\\"{x:1094,y:986,t:1526328842375};\\\", \\\"{x:1115,y:991,t:1526328842392};\\\", \\\"{x:1136,y:996,t:1526328842407};\\\", \\\"{x:1156,y:998,t:1526328842423};\\\", \\\"{x:1179,y:1001,t:1526328842441};\\\", \\\"{x:1201,y:1003,t:1526328842457};\\\", \\\"{x:1223,y:1005,t:1526328842474};\\\", \\\"{x:1250,y:1007,t:1526328842491};\\\", \\\"{x:1263,y:1007,t:1526328842508};\\\", \\\"{x:1273,y:1007,t:1526328842524};\\\", \\\"{x:1285,y:1007,t:1526328842541};\\\", \\\"{x:1297,y:1006,t:1526328842558};\\\", \\\"{x:1308,y:1005,t:1526328842574};\\\", \\\"{x:1321,y:1002,t:1526328842591};\\\", \\\"{x:1331,y:1001,t:1526328842608};\\\", \\\"{x:1339,y:1000,t:1526328842624};\\\", \\\"{x:1348,y:998,t:1526328842641};\\\", \\\"{x:1356,y:997,t:1526328842658};\\\", \\\"{x:1359,y:996,t:1526328842674};\\\", \\\"{x:1362,y:996,t:1526328842691};\\\", \\\"{x:1363,y:996,t:1526328842739};\\\", \\\"{x:1364,y:995,t:1526328842844};\\\", \\\"{x:1365,y:994,t:1526328842875};\\\", \\\"{x:1367,y:993,t:1526328842891};\\\", \\\"{x:1371,y:993,t:1526328842908};\\\", \\\"{x:1373,y:993,t:1526328842924};\\\", \\\"{x:1376,y:993,t:1526328842941};\\\", \\\"{x:1382,y:993,t:1526328842958};\\\", \\\"{x:1386,y:993,t:1526328842974};\\\", \\\"{x:1390,y:991,t:1526328842992};\\\", \\\"{x:1392,y:991,t:1526328843008};\\\", \\\"{x:1394,y:991,t:1526328843024};\\\", \\\"{x:1395,y:991,t:1526328843041};\\\", \\\"{x:1396,y:990,t:1526328843180};\\\", \\\"{x:1397,y:990,t:1526328845172};\\\", \\\"{x:1400,y:990,t:1526328845180};\\\", \\\"{x:1402,y:989,t:1526328845192};\\\", \\\"{x:1411,y:984,t:1526328845251};\\\", \\\"{x:1413,y:984,t:1526328845267};\\\", \\\"{x:1414,y:983,t:1526328845276};\\\", \\\"{x:1417,y:982,t:1526328845291};\\\", \\\"{x:1420,y:980,t:1526328845309};\\\", \\\"{x:1424,y:978,t:1526328845326};\\\", \\\"{x:1425,y:976,t:1526328845342};\\\", \\\"{x:1430,y:974,t:1526328845359};\\\", \\\"{x:1433,y:973,t:1526328845376};\\\", \\\"{x:1435,y:972,t:1526328845392};\\\", \\\"{x:1437,y:971,t:1526328845409};\\\", \\\"{x:1438,y:971,t:1526328845425};\\\", \\\"{x:1441,y:969,t:1526328845442};\\\", \\\"{x:1451,y:969,t:1526328845459};\\\", \\\"{x:1462,y:969,t:1526328845476};\\\", \\\"{x:1473,y:969,t:1526328845493};\\\", \\\"{x:1486,y:969,t:1526328845509};\\\", \\\"{x:1494,y:969,t:1526328845526};\\\", \\\"{x:1502,y:969,t:1526328845543};\\\", \\\"{x:1514,y:969,t:1526328845559};\\\", \\\"{x:1526,y:969,t:1526328845577};\\\", \\\"{x:1537,y:966,t:1526328845593};\\\", \\\"{x:1542,y:966,t:1526328845609};\\\", \\\"{x:1550,y:966,t:1526328845626};\\\", \\\"{x:1563,y:966,t:1526328845642};\\\", \\\"{x:1570,y:966,t:1526328845659};\\\", \\\"{x:1576,y:965,t:1526328845676};\\\", \\\"{x:1580,y:964,t:1526328845693};\\\", \\\"{x:1581,y:964,t:1526328845710};\\\", \\\"{x:1579,y:964,t:1526328845915};\\\", \\\"{x:1577,y:964,t:1526328845930};\\\", \\\"{x:1577,y:965,t:1526328845943};\\\", \\\"{x:1575,y:966,t:1526328845959};\\\", \\\"{x:1574,y:966,t:1526328845976};\\\", \\\"{x:1572,y:968,t:1526328845993};\\\", \\\"{x:1570,y:969,t:1526328846009};\\\", \\\"{x:1569,y:969,t:1526328846034};\\\", \\\"{x:1568,y:969,t:1526328846051};\\\", \\\"{x:1567,y:970,t:1526328846059};\\\", \\\"{x:1566,y:970,t:1526328846076};\\\", \\\"{x:1565,y:970,t:1526328846099};\\\", \\\"{x:1565,y:971,t:1526328846109};\\\", \\\"{x:1564,y:971,t:1526328846155};\\\", \\\"{x:1563,y:972,t:1526328846179};\\\", \\\"{x:1561,y:973,t:1526328846797};\\\", \\\"{x:1560,y:973,t:1526328846813};\\\", \\\"{x:1557,y:973,t:1526328846827};\\\", \\\"{x:1555,y:973,t:1526328846844};\\\", \\\"{x:1554,y:973,t:1526328846860};\\\", \\\"{x:1553,y:973,t:1526328847284};\\\", \\\"{x:1551,y:973,t:1526328847297};\\\", \\\"{x:1550,y:973,t:1526328847313};\\\", \\\"{x:1548,y:973,t:1526328848036};\\\", \\\"{x:1545,y:967,t:1526328869582};\\\", \\\"{x:1536,y:950,t:1526328869596};\\\", \\\"{x:1531,y:942,t:1526328869607};\\\", \\\"{x:1526,y:931,t:1526328869624};\\\", \\\"{x:1523,y:923,t:1526328869641};\\\", \\\"{x:1521,y:917,t:1526328869657};\\\", \\\"{x:1519,y:913,t:1526328869675};\\\", \\\"{x:1518,y:911,t:1526328869691};\\\", \\\"{x:1517,y:907,t:1526328869707};\\\", \\\"{x:1515,y:903,t:1526328869724};\\\", \\\"{x:1513,y:899,t:1526328869742};\\\", \\\"{x:1512,y:892,t:1526328869757};\\\", \\\"{x:1511,y:885,t:1526328869774};\\\", \\\"{x:1511,y:879,t:1526328869791};\\\", \\\"{x:1511,y:871,t:1526328869807};\\\", \\\"{x:1511,y:865,t:1526328869824};\\\", \\\"{x:1511,y:860,t:1526328869842};\\\", \\\"{x:1513,y:855,t:1526328869857};\\\", \\\"{x:1515,y:853,t:1526328869875};\\\", \\\"{x:1517,y:850,t:1526328869891};\\\", \\\"{x:1518,y:848,t:1526328869907};\\\", \\\"{x:1521,y:847,t:1526328869925};\\\", \\\"{x:1523,y:846,t:1526328869941};\\\", \\\"{x:1527,y:844,t:1526328869958};\\\", \\\"{x:1531,y:841,t:1526328869974};\\\", \\\"{x:1534,y:839,t:1526328869991};\\\", \\\"{x:1535,y:839,t:1526328870011};\\\", \\\"{x:1535,y:838,t:1526328870093};\\\", \\\"{x:1536,y:836,t:1526328870108};\\\", \\\"{x:1537,y:835,t:1526328870180};\\\", \\\"{x:1540,y:833,t:1526328870195};\\\", \\\"{x:1542,y:831,t:1526328870208};\\\", \\\"{x:1543,y:829,t:1526328870224};\\\", \\\"{x:1543,y:828,t:1526328870240};\\\", \\\"{x:1543,y:827,t:1526328870257};\\\", \\\"{x:1543,y:826,t:1526328870275};\\\", \\\"{x:1544,y:826,t:1526328870509};\\\", \\\"{x:1543,y:826,t:1526328887875};\\\", \\\"{x:1533,y:822,t:1526328887884};\\\", \\\"{x:1485,y:808,t:1526328887906};\\\", \\\"{x:1415,y:787,t:1526328887917};\\\", \\\"{x:1352,y:761,t:1526328887937};\\\", \\\"{x:1305,y:742,t:1526328887952};\\\", \\\"{x:1282,y:731,t:1526328887967};\\\", \\\"{x:1276,y:727,t:1526328887984};\\\", \\\"{x:1269,y:723,t:1526328888164};\\\", \\\"{x:1245,y:691,t:1526328888172};\\\", \\\"{x:1159,y:577,t:1526328888187};\\\", \\\"{x:1097,y:526,t:1526328888201};\\\", \\\"{x:965,y:442,t:1526328888218};\\\", \\\"{x:807,y:373,t:1526328888233};\\\", \\\"{x:556,y:296,t:1526328888251};\\\", \\\"{x:404,y:254,t:1526328888267};\\\", \\\"{x:278,y:229,t:1526328888284};\\\", \\\"{x:195,y:218,t:1526328888301};\\\", \\\"{x:155,y:211,t:1526328888317};\\\", \\\"{x:139,y:209,t:1526328888333};\\\", \\\"{x:136,y:209,t:1526328888351};\\\", \\\"{x:131,y:211,t:1526328888367};\\\", \\\"{x:126,y:224,t:1526328888383};\\\", \\\"{x:118,y:242,t:1526328888401};\\\", \\\"{x:112,y:260,t:1526328888418};\\\", \\\"{x:105,y:281,t:1526328888434};\\\", \\\"{x:99,y:313,t:1526328888451};\\\", \\\"{x:99,y:336,t:1526328888467};\\\", \\\"{x:99,y:361,t:1526328888485};\\\", \\\"{x:99,y:387,t:1526328888501};\\\", \\\"{x:99,y:405,t:1526328888518};\\\", \\\"{x:99,y:424,t:1526328888535};\\\", \\\"{x:102,y:441,t:1526328888551};\\\", \\\"{x:105,y:458,t:1526328888568};\\\", \\\"{x:108,y:471,t:1526328888584};\\\", \\\"{x:111,y:482,t:1526328888601};\\\", \\\"{x:113,y:495,t:1526328888619};\\\", \\\"{x:119,y:519,t:1526328888636};\\\", \\\"{x:129,y:552,t:1526328888668};\\\", \\\"{x:132,y:558,t:1526328888681};\\\", \\\"{x:133,y:562,t:1526328888697};\\\", \\\"{x:135,y:566,t:1526328888715};\\\", \\\"{x:136,y:567,t:1526328888818};\\\", \\\"{x:137,y:564,t:1526328888834};\\\", \\\"{x:139,y:560,t:1526328888848};\\\", \\\"{x:139,y:557,t:1526328888865};\\\", \\\"{x:140,y:554,t:1526328888881};\\\", \\\"{x:140,y:551,t:1526328888898};\\\", \\\"{x:141,y:551,t:1526328888931};\\\", \\\"{x:143,y:550,t:1526328888948};\\\", \\\"{x:151,y:544,t:1526328888965};\\\", \\\"{x:158,y:539,t:1526328888982};\\\", \\\"{x:163,y:535,t:1526328888997};\\\", \\\"{x:163,y:534,t:1526328889014};\\\", \\\"{x:164,y:534,t:1526328889419};\\\", \\\"{x:167,y:533,t:1526328889431};\\\", \\\"{x:188,y:533,t:1526328889448};\\\", \\\"{x:209,y:539,t:1526328889465};\\\", \\\"{x:235,y:550,t:1526328889481};\\\", \\\"{x:282,y:573,t:1526328889499};\\\", \\\"{x:344,y:607,t:1526328889515};\\\", \\\"{x:393,y:644,t:1526328889532};\\\", \\\"{x:441,y:679,t:1526328889548};\\\", \\\"{x:488,y:712,t:1526328889565};\\\", \\\"{x:531,y:742,t:1526328889582};\\\", \\\"{x:573,y:763,t:1526328889600};\\\", \\\"{x:618,y:776,t:1526328889615};\\\", \\\"{x:666,y:786,t:1526328889632};\\\", \\\"{x:717,y:793,t:1526328889648};\\\", \\\"{x:762,y:799,t:1526328889665};\\\", \\\"{x:793,y:800,t:1526328889682};\\\", \\\"{x:821,y:798,t:1526328889698};\\\", \\\"{x:835,y:793,t:1526328889715};\\\", \\\"{x:851,y:789,t:1526328889732};\\\", \\\"{x:863,y:785,t:1526328889748};\\\", \\\"{x:874,y:783,t:1526328889765};\\\", \\\"{x:886,y:780,t:1526328889782};\\\", \\\"{x:905,y:778,t:1526328889798};\\\", \\\"{x:919,y:775,t:1526328889815};\\\", \\\"{x:940,y:773,t:1526328889832};\\\", \\\"{x:966,y:771,t:1526328889849};\\\", \\\"{x:998,y:769,t:1526328889865};\\\", \\\"{x:1046,y:769,t:1526328889883};\\\", \\\"{x:1157,y:769,t:1526328889899};\\\", \\\"{x:1238,y:769,t:1526328889915};\\\", \\\"{x:1323,y:760,t:1526328889933};\\\", \\\"{x:1401,y:758,t:1526328889950};\\\", \\\"{x:1465,y:751,t:1526328889965};\\\", \\\"{x:1527,y:750,t:1526328889982};\\\", \\\"{x:1577,y:750,t:1526328889999};\\\", \\\"{x:1616,y:750,t:1526328890015};\\\", \\\"{x:1647,y:750,t:1526328890032};\\\", \\\"{x:1673,y:750,t:1526328890049};\\\", \\\"{x:1689,y:750,t:1526328890065};\\\", \\\"{x:1698,y:750,t:1526328890082};\\\", \\\"{x:1703,y:750,t:1526328890099};\\\", \\\"{x:1705,y:750,t:1526328890116};\\\", \\\"{x:1705,y:752,t:1526328890139};\\\", \\\"{x:1705,y:754,t:1526328890149};\\\", \\\"{x:1705,y:756,t:1526328890166};\\\", \\\"{x:1705,y:757,t:1526328890182};\\\", \\\"{x:1704,y:762,t:1526328890199};\\\", \\\"{x:1702,y:767,t:1526328890216};\\\", \\\"{x:1699,y:773,t:1526328890232};\\\", \\\"{x:1697,y:778,t:1526328890248};\\\", \\\"{x:1695,y:784,t:1526328890266};\\\", \\\"{x:1694,y:791,t:1526328890282};\\\", \\\"{x:1688,y:802,t:1526328890299};\\\", \\\"{x:1687,y:807,t:1526328890316};\\\", \\\"{x:1686,y:815,t:1526328890332};\\\", \\\"{x:1680,y:822,t:1526328890349};\\\", \\\"{x:1675,y:826,t:1526328890367};\\\", \\\"{x:1666,y:834,t:1526328890382};\\\", \\\"{x:1661,y:838,t:1526328890399};\\\", \\\"{x:1656,y:842,t:1526328890416};\\\", \\\"{x:1653,y:844,t:1526328890432};\\\", \\\"{x:1651,y:847,t:1526328890449};\\\", \\\"{x:1649,y:848,t:1526328890466};\\\", \\\"{x:1647,y:850,t:1526328890482};\\\", \\\"{x:1646,y:851,t:1526328890499};\\\", \\\"{x:1644,y:852,t:1526328890516};\\\", \\\"{x:1642,y:852,t:1526328890533};\\\", \\\"{x:1640,y:853,t:1526328890549};\\\", \\\"{x:1637,y:855,t:1526328890566};\\\", \\\"{x:1635,y:855,t:1526328890587};\\\", \\\"{x:1634,y:856,t:1526328890600};\\\", \\\"{x:1631,y:858,t:1526328890616};\\\", \\\"{x:1628,y:859,t:1526328890633};\\\", \\\"{x:1626,y:861,t:1526328890649};\\\", \\\"{x:1623,y:866,t:1526328890666};\\\", \\\"{x:1619,y:874,t:1526328890683};\\\", \\\"{x:1616,y:882,t:1526328890699};\\\", \\\"{x:1611,y:891,t:1526328890716};\\\", \\\"{x:1607,y:902,t:1526328890732};\\\", \\\"{x:1604,y:911,t:1526328890749};\\\", \\\"{x:1601,y:920,t:1526328890766};\\\", \\\"{x:1595,y:929,t:1526328890783};\\\", \\\"{x:1591,y:934,t:1526328890799};\\\", \\\"{x:1587,y:942,t:1526328890816};\\\", \\\"{x:1585,y:949,t:1526328890833};\\\", \\\"{x:1583,y:955,t:1526328890850};\\\", \\\"{x:1582,y:959,t:1526328890866};\\\", \\\"{x:1579,y:962,t:1526328890883};\\\", \\\"{x:1578,y:964,t:1526328890900};\\\", \\\"{x:1577,y:965,t:1526328890988};\\\", \\\"{x:1575,y:965,t:1526328891003};\\\", \\\"{x:1573,y:965,t:1526328891016};\\\", \\\"{x:1564,y:965,t:1526328891033};\\\", \\\"{x:1558,y:965,t:1526328891049};\\\", \\\"{x:1555,y:965,t:1526328891066};\\\", \\\"{x:1552,y:965,t:1526328891084};\\\", \\\"{x:1551,y:965,t:1526328891155};\\\", \\\"{x:1550,y:966,t:1526328891371};\\\", \\\"{x:1549,y:966,t:1526328891389};\\\", \\\"{x:1548,y:967,t:1526328891400};\\\", \\\"{x:1547,y:967,t:1526328891444};\\\", \\\"{x:1547,y:966,t:1526328891827};\\\", \\\"{x:1547,y:965,t:1526328891836};\\\", \\\"{x:1547,y:963,t:1526328891852};\\\", \\\"{x:1547,y:959,t:1526328891868};\\\", \\\"{x:1547,y:956,t:1526328891884};\\\", \\\"{x:1547,y:954,t:1526328891901};\\\", \\\"{x:1547,y:952,t:1526328891918};\\\", \\\"{x:1547,y:951,t:1526328891934};\\\", \\\"{x:1547,y:949,t:1526328891951};\\\", \\\"{x:1547,y:948,t:1526328891997};\\\", \\\"{x:1547,y:947,t:1526328892019};\\\", \\\"{x:1548,y:947,t:1526328892035};\\\", \\\"{x:1548,y:946,t:1526328892051};\\\", \\\"{x:1548,y:945,t:1526328892068};\\\", \\\"{x:1548,y:943,t:1526328892084};\\\", \\\"{x:1548,y:942,t:1526328892101};\\\", \\\"{x:1548,y:939,t:1526328892119};\\\", \\\"{x:1548,y:937,t:1526328892134};\\\", \\\"{x:1548,y:936,t:1526328892151};\\\", \\\"{x:1548,y:933,t:1526328892168};\\\", \\\"{x:1548,y:929,t:1526328892184};\\\", \\\"{x:1548,y:925,t:1526328892201};\\\", \\\"{x:1548,y:918,t:1526328892218};\\\", \\\"{x:1548,y:910,t:1526328892235};\\\", \\\"{x:1548,y:904,t:1526328892251};\\\", \\\"{x:1548,y:900,t:1526328892268};\\\", \\\"{x:1548,y:896,t:1526328892285};\\\", \\\"{x:1548,y:891,t:1526328892301};\\\", \\\"{x:1548,y:886,t:1526328892318};\\\", \\\"{x:1548,y:883,t:1526328892335};\\\", \\\"{x:1548,y:881,t:1526328892351};\\\", \\\"{x:1549,y:880,t:1526328892367};\\\", \\\"{x:1549,y:878,t:1526328892384};\\\", \\\"{x:1549,y:877,t:1526328892400};\\\", \\\"{x:1549,y:875,t:1526328892418};\\\", \\\"{x:1549,y:869,t:1526328892434};\\\", \\\"{x:1549,y:866,t:1526328892450};\\\", \\\"{x:1549,y:863,t:1526328892467};\\\", \\\"{x:1548,y:862,t:1526328892485};\\\", \\\"{x:1547,y:859,t:1526328892500};\\\", \\\"{x:1546,y:854,t:1526328892517};\\\", \\\"{x:1546,y:852,t:1526328892535};\\\", \\\"{x:1545,y:847,t:1526328892551};\\\", \\\"{x:1544,y:844,t:1526328892568};\\\", \\\"{x:1543,y:840,t:1526328892585};\\\", \\\"{x:1543,y:839,t:1526328892600};\\\", \\\"{x:1543,y:837,t:1526328892618};\\\", \\\"{x:1541,y:834,t:1526328892635};\\\", \\\"{x:1540,y:831,t:1526328892651};\\\", \\\"{x:1539,y:829,t:1526328892667};\\\", \\\"{x:1539,y:828,t:1526328892715};\\\", \\\"{x:1539,y:827,t:1526328892804};\\\", \\\"{x:1538,y:827,t:1526328894597};\\\", \\\"{x:1529,y:827,t:1526328894603};\\\", \\\"{x:1496,y:823,t:1526328894620};\\\", \\\"{x:1433,y:808,t:1526328894637};\\\", \\\"{x:1324,y:785,t:1526328894652};\\\", \\\"{x:1221,y:773,t:1526328894670};\\\", \\\"{x:1164,y:766,t:1526328894687};\\\", \\\"{x:1132,y:766,t:1526328894703};\\\", \\\"{x:1110,y:766,t:1526328894720};\\\", \\\"{x:1092,y:766,t:1526328894737};\\\", \\\"{x:1077,y:767,t:1526328894753};\\\", \\\"{x:1062,y:768,t:1526328894770};\\\", \\\"{x:1038,y:772,t:1526328894787};\\\", \\\"{x:1022,y:777,t:1526328894802};\\\", \\\"{x:1005,y:781,t:1526328894819};\\\", \\\"{x:980,y:784,t:1526328894837};\\\", \\\"{x:955,y:784,t:1526328894852};\\\", \\\"{x:918,y:782,t:1526328894869};\\\", \\\"{x:857,y:774,t:1526328894886};\\\", \\\"{x:769,y:755,t:1526328894902};\\\", \\\"{x:675,y:732,t:1526328894920};\\\", \\\"{x:593,y:713,t:1526328894937};\\\", \\\"{x:551,y:706,t:1526328894953};\\\", \\\"{x:522,y:701,t:1526328894970};\\\", \\\"{x:499,y:699,t:1526328894987};\\\", \\\"{x:495,y:698,t:1526328895003};\\\", \\\"{x:494,y:698,t:1526328895027};\\\", \\\"{x:493,y:698,t:1526328895067};\\\", \\\"{x:492,y:698,t:1526328895075};\\\", \\\"{x:491,y:698,t:1526328895087};\\\", \\\"{x:490,y:698,t:1526328895102};\\\", \\\"{x:490,y:699,t:1526328895139};\\\", \\\"{x:488,y:703,t:1526328895155};\\\", \\\"{x:488,y:705,t:1526328895170};\\\", \\\"{x:488,y:711,t:1526328895186};\\\", \\\"{x:487,y:713,t:1526328895204};\\\", \\\"{x:487,y:715,t:1526328895220};\\\", \\\"{x:486,y:717,t:1526328895238};\\\", \\\"{x:486,y:720,t:1526328895254};\\\", \\\"{x:486,y:722,t:1526328895270};\\\", \\\"{x:486,y:724,t:1526328895287};\\\", \\\"{x:486,y:727,t:1526328895303};\\\", \\\"{x:486,y:730,t:1526328895320};\\\", \\\"{x:486,y:731,t:1526328895336};\\\", \\\"{x:486,y:732,t:1526328895355};\\\", \\\"{x:485,y:734,t:1526328895378};\\\", \\\"{x:484,y:735,t:1526328895418};\\\", \\\"{x:484,y:736,t:1526328895443};\\\", \\\"{x:483,y:736,t:1526328895454};\\\", \\\"{x:482,y:736,t:1526328895470};\\\" ] }, { \\\"rt\\\": 99846, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 850953, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-10 AM-11 AM-01:30\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:737,t:1526328897876};\\\", \\\"{x:496,y:739,t:1526328897891};\\\", \\\"{x:505,y:741,t:1526328897906};\\\", \\\"{x:529,y:751,t:1526328897923};\\\", \\\"{x:545,y:755,t:1526328897939};\\\", \\\"{x:553,y:757,t:1526328897956};\\\", \\\"{x:563,y:762,t:1526328897972};\\\", \\\"{x:575,y:767,t:1526328897990};\\\", \\\"{x:593,y:777,t:1526328898005};\\\", \\\"{x:613,y:788,t:1526328898021};\\\", \\\"{x:636,y:797,t:1526328898039};\\\", \\\"{x:660,y:808,t:1526328898056};\\\", \\\"{x:685,y:814,t:1526328898071};\\\", \\\"{x:713,y:824,t:1526328898088};\\\", \\\"{x:736,y:828,t:1526328898105};\\\", \\\"{x:752,y:830,t:1526328898121};\\\", \\\"{x:759,y:830,t:1526328898138};\\\", \\\"{x:760,y:830,t:1526328898163};\\\", \\\"{x:762,y:830,t:1526328898178};\\\", \\\"{x:764,y:829,t:1526328898251};\\\", \\\"{x:766,y:828,t:1526328898259};\\\", \\\"{x:767,y:827,t:1526328898272};\\\", \\\"{x:770,y:827,t:1526328909707};\\\", \\\"{x:807,y:827,t:1526328909715};\\\", \\\"{x:946,y:857,t:1526328909733};\\\", \\\"{x:1018,y:875,t:1526328909745};\\\", \\\"{x:1198,y:949,t:1526328909762};\\\", \\\"{x:1300,y:994,t:1526328909779};\\\", \\\"{x:1411,y:1024,t:1526328909796};\\\", \\\"{x:1526,y:1051,t:1526328909813};\\\", \\\"{x:1644,y:1080,t:1526328909828};\\\", \\\"{x:1766,y:1099,t:1526328909846};\\\", \\\"{x:1891,y:1118,t:1526328909863};\\\", \\\"{x:1919,y:1132,t:1526328909879};\\\", \\\"{x:1919,y:1140,t:1526328909896};\\\", \\\"{x:1919,y:1139,t:1526328909914};\\\", \\\"{x:1919,y:1132,t:1526328909931};\\\", \\\"{x:1919,y:1127,t:1526328909949};\\\", \\\"{x:1919,y:1116,t:1526328909965};\\\", \\\"{x:1918,y:1074,t:1526328909982};\\\", \\\"{x:1898,y:1012,t:1526328909999};\\\", \\\"{x:1861,y:954,t:1526328910015};\\\", \\\"{x:1817,y:908,t:1526328910031};\\\", \\\"{x:1752,y:862,t:1526328910049};\\\", \\\"{x:1655,y:814,t:1526328910065};\\\", \\\"{x:1551,y:771,t:1526328910082};\\\", \\\"{x:1401,y:710,t:1526328910098};\\\", \\\"{x:1324,y:680,t:1526328910115};\\\", \\\"{x:1276,y:664,t:1526328910131};\\\", \\\"{x:1234,y:645,t:1526328910149};\\\", \\\"{x:1213,y:635,t:1526328910164};\\\", \\\"{x:1203,y:632,t:1526328910182};\\\", \\\"{x:1202,y:633,t:1526328910227};\\\", \\\"{x:1202,y:640,t:1526328910236};\\\", \\\"{x:1202,y:658,t:1526328910251};\\\", \\\"{x:1202,y:669,t:1526328910265};\\\", \\\"{x:1206,y:711,t:1526328910283};\\\", \\\"{x:1220,y:751,t:1526328910298};\\\", \\\"{x:1248,y:793,t:1526328910315};\\\", \\\"{x:1296,y:836,t:1526328910332};\\\", \\\"{x:1355,y:869,t:1526328910349};\\\", \\\"{x:1410,y:889,t:1526328910365};\\\", \\\"{x:1429,y:892,t:1526328910383};\\\", \\\"{x:1435,y:893,t:1526328910400};\\\", \\\"{x:1437,y:893,t:1526328910540};\\\", \\\"{x:1439,y:893,t:1526328910603};\\\", \\\"{x:1448,y:890,t:1526328910619};\\\", \\\"{x:1451,y:888,t:1526328910633};\\\", \\\"{x:1465,y:888,t:1526328910650};\\\", \\\"{x:1480,y:887,t:1526328910666};\\\", \\\"{x:1496,y:886,t:1526328910683};\\\", \\\"{x:1497,y:886,t:1526328910700};\\\", \\\"{x:1498,y:886,t:1526328910716};\\\", \\\"{x:1493,y:886,t:1526328935333};\\\", \\\"{x:1454,y:894,t:1526328935341};\\\", \\\"{x:1401,y:898,t:1526328935355};\\\", \\\"{x:1271,y:898,t:1526328935371};\\\", \\\"{x:1208,y:888,t:1526328935388};\\\", \\\"{x:1096,y:861,t:1526328935405};\\\", \\\"{x:1020,y:846,t:1526328935421};\\\", \\\"{x:939,y:822,t:1526328935438};\\\", \\\"{x:880,y:792,t:1526328935455};\\\", \\\"{x:821,y:775,t:1526328935471};\\\", \\\"{x:759,y:755,t:1526328935487};\\\", \\\"{x:687,y:721,t:1526328935505};\\\", \\\"{x:619,y:696,t:1526328935521};\\\", \\\"{x:536,y:670,t:1526328935538};\\\", \\\"{x:453,y:647,t:1526328935555};\\\", \\\"{x:373,y:627,t:1526328935572};\\\", \\\"{x:292,y:612,t:1526328935588};\\\", \\\"{x:236,y:604,t:1526328935605};\\\", \\\"{x:212,y:601,t:1526328935614};\\\", \\\"{x:160,y:587,t:1526328935632};\\\", \\\"{x:131,y:579,t:1526328935648};\\\", \\\"{x:93,y:564,t:1526328935672};\\\", \\\"{x:76,y:557,t:1526328935688};\\\", \\\"{x:64,y:552,t:1526328935704};\\\", \\\"{x:58,y:548,t:1526328935721};\\\", \\\"{x:54,y:548,t:1526328935738};\\\", \\\"{x:50,y:547,t:1526328935754};\\\", \\\"{x:44,y:545,t:1526328935772};\\\", \\\"{x:42,y:544,t:1526328935789};\\\", \\\"{x:43,y:544,t:1526328935908};\\\", \\\"{x:53,y:547,t:1526328935925};\\\", \\\"{x:56,y:547,t:1526328935939};\\\", \\\"{x:68,y:550,t:1526328935955};\\\", \\\"{x:84,y:557,t:1526328935971};\\\", \\\"{x:97,y:562,t:1526328935988};\\\", \\\"{x:106,y:565,t:1526328936005};\\\", \\\"{x:112,y:566,t:1526328936021};\\\", \\\"{x:120,y:569,t:1526328936038};\\\", \\\"{x:123,y:569,t:1526328936055};\\\", \\\"{x:124,y:570,t:1526328936072};\\\", \\\"{x:126,y:570,t:1526328936100};\\\", \\\"{x:127,y:571,t:1526328936116};\\\", \\\"{x:130,y:572,t:1526328936124};\\\", \\\"{x:131,y:572,t:1526328936139};\\\", \\\"{x:143,y:574,t:1526328936156};\\\", \\\"{x:152,y:578,t:1526328936173};\\\", \\\"{x:162,y:579,t:1526328936189};\\\", \\\"{x:177,y:582,t:1526328936206};\\\", \\\"{x:198,y:583,t:1526328936222};\\\", \\\"{x:221,y:584,t:1526328936239};\\\", \\\"{x:248,y:584,t:1526328936255};\\\", \\\"{x:271,y:584,t:1526328936271};\\\", \\\"{x:292,y:584,t:1526328936289};\\\", \\\"{x:306,y:584,t:1526328936305};\\\", \\\"{x:315,y:584,t:1526328936321};\\\", \\\"{x:320,y:584,t:1526328936339};\\\", \\\"{x:322,y:584,t:1526328936355};\\\", \\\"{x:323,y:584,t:1526328936461};\\\", \\\"{x:328,y:584,t:1526328936476};\\\", \\\"{x:329,y:584,t:1526328936489};\\\", \\\"{x:336,y:584,t:1526328936506};\\\", \\\"{x:345,y:584,t:1526328936522};\\\", \\\"{x:357,y:584,t:1526328936539};\\\", \\\"{x:374,y:584,t:1526328936556};\\\", \\\"{x:390,y:584,t:1526328936571};\\\", \\\"{x:417,y:584,t:1526328936589};\\\", \\\"{x:438,y:584,t:1526328936607};\\\", \\\"{x:452,y:584,t:1526328936622};\\\", \\\"{x:463,y:584,t:1526328936639};\\\", \\\"{x:470,y:584,t:1526328936655};\\\", \\\"{x:477,y:584,t:1526328936672};\\\", \\\"{x:482,y:584,t:1526328936689};\\\", \\\"{x:486,y:584,t:1526328936705};\\\", \\\"{x:489,y:584,t:1526328936722};\\\", \\\"{x:492,y:584,t:1526328936739};\\\", \\\"{x:495,y:585,t:1526328936755};\\\", \\\"{x:505,y:585,t:1526328936773};\\\", \\\"{x:517,y:587,t:1526328936789};\\\", \\\"{x:532,y:587,t:1526328936805};\\\", \\\"{x:549,y:588,t:1526328936822};\\\", \\\"{x:565,y:588,t:1526328936840};\\\", \\\"{x:581,y:588,t:1526328936856};\\\", \\\"{x:602,y:590,t:1526328936873};\\\", \\\"{x:622,y:590,t:1526328936890};\\\", \\\"{x:646,y:590,t:1526328936906};\\\", \\\"{x:663,y:590,t:1526328936922};\\\", \\\"{x:680,y:590,t:1526328936940};\\\", \\\"{x:695,y:590,t:1526328936956};\\\", \\\"{x:704,y:589,t:1526328936972};\\\", \\\"{x:709,y:587,t:1526328936990};\\\", \\\"{x:712,y:586,t:1526328937007};\\\", \\\"{x:713,y:585,t:1526328937052};\\\", \\\"{x:714,y:585,t:1526328937061};\\\", \\\"{x:716,y:584,t:1526328937072};\\\", \\\"{x:720,y:581,t:1526328937090};\\\", \\\"{x:726,y:578,t:1526328937108};\\\", \\\"{x:732,y:574,t:1526328937123};\\\", \\\"{x:741,y:570,t:1526328937140};\\\", \\\"{x:745,y:567,t:1526328937156};\\\", \\\"{x:751,y:565,t:1526328937172};\\\", \\\"{x:759,y:562,t:1526328937189};\\\", \\\"{x:765,y:558,t:1526328937206};\\\", \\\"{x:770,y:557,t:1526328937222};\\\", \\\"{x:773,y:556,t:1526328937240};\\\", \\\"{x:773,y:555,t:1526328937259};\\\", \\\"{x:774,y:554,t:1526328937291};\\\", \\\"{x:775,y:554,t:1526328937307};\\\", \\\"{x:782,y:551,t:1526328937322};\\\", \\\"{x:785,y:550,t:1526328937339};\\\", \\\"{x:790,y:547,t:1526328937355};\\\", \\\"{x:792,y:546,t:1526328937373};\\\", \\\"{x:794,y:545,t:1526328937389};\\\", \\\"{x:795,y:544,t:1526328937405};\\\", \\\"{x:795,y:543,t:1526328937422};\\\", \\\"{x:798,y:541,t:1526328937439};\\\", \\\"{x:803,y:537,t:1526328937456};\\\", \\\"{x:809,y:533,t:1526328937473};\\\", \\\"{x:813,y:532,t:1526328937489};\\\", \\\"{x:816,y:530,t:1526328937507};\\\", \\\"{x:816,y:529,t:1526328937532};\\\", \\\"{x:818,y:529,t:1526328937539};\\\", \\\"{x:820,y:528,t:1526328937556};\\\", \\\"{x:823,y:526,t:1526328937572};\\\", \\\"{x:825,y:525,t:1526328937590};\\\", \\\"{x:828,y:524,t:1526328937607};\\\", \\\"{x:830,y:523,t:1526328937623};\\\", \\\"{x:831,y:522,t:1526328937639};\\\", \\\"{x:838,y:530,t:1526328938301};\\\", \\\"{x:864,y:565,t:1526328938324};\\\", \\\"{x:894,y:598,t:1526328938341};\\\", \\\"{x:936,y:645,t:1526328938356};\\\", \\\"{x:992,y:695,t:1526328938373};\\\", \\\"{x:1040,y:744,t:1526328938390};\\\", \\\"{x:1086,y:792,t:1526328938407};\\\", \\\"{x:1129,y:834,t:1526328938423};\\\", \\\"{x:1167,y:881,t:1526328938441};\\\", \\\"{x:1200,y:931,t:1526328938458};\\\", \\\"{x:1231,y:988,t:1526328938474};\\\", \\\"{x:1250,y:1044,t:1526328938491};\\\", \\\"{x:1261,y:1108,t:1526328938507};\\\", \\\"{x:1265,y:1130,t:1526328938524};\\\", \\\"{x:1276,y:1145,t:1526328938540};\\\", \\\"{x:1290,y:1157,t:1526328938557};\\\", \\\"{x:1296,y:1164,t:1526328938574};\\\", \\\"{x:1298,y:1170,t:1526328938591};\\\", \\\"{x:1303,y:1172,t:1526328988876};\\\", \\\"{x:1314,y:1172,t:1526328988890};\\\", \\\"{x:1324,y:1174,t:1526328988906};\\\", \\\"{x:1328,y:1175,t:1526328988919};\\\", \\\"{x:1331,y:1176,t:1526328988936};\\\", \\\"{x:1334,y:1177,t:1526328988953};\\\", \\\"{x:1340,y:1177,t:1526328988970};\\\", \\\"{x:1343,y:1177,t:1526328988987};\\\", \\\"{x:1345,y:1179,t:1526328989002};\\\", \\\"{x:1348,y:1180,t:1526328989020};\\\", \\\"{x:1352,y:1183,t:1526328989037};\\\", \\\"{x:1355,y:1184,t:1526328989053};\\\", \\\"{x:1359,y:1187,t:1526328989067};\\\", \\\"{x:1364,y:1191,t:1526328989082};\\\", \\\"{x:1381,y:1199,t:1526328989099};\\\", \\\"{x:1390,y:1199,t:1526328989116};\\\", \\\"{x:1393,y:1199,t:1526328989132};\\\", \\\"{x:1398,y:1199,t:1526328989149};\\\", \\\"{x:1399,y:1199,t:1526328989166};\\\", \\\"{x:1400,y:1199,t:1526328989195};\\\", \\\"{x:1399,y:1199,t:1526328989604};\\\", \\\"{x:1394,y:1197,t:1526328989620};\\\", \\\"{x:1390,y:1195,t:1526328989633};\\\", \\\"{x:1382,y:1192,t:1526328989649};\\\", \\\"{x:1375,y:1192,t:1526328989666};\\\", \\\"{x:1368,y:1192,t:1526328989683};\\\", \\\"{x:1361,y:1194,t:1526328989700};\\\", \\\"{x:1356,y:1194,t:1526328989715};\\\", \\\"{x:1354,y:1194,t:1526328989733};\\\", \\\"{x:1351,y:1194,t:1526328989749};\\\", \\\"{x:1343,y:1189,t:1526328989767};\\\", \\\"{x:1336,y:1178,t:1526328989784};\\\", \\\"{x:1331,y:1169,t:1526328989799};\\\", \\\"{x:1326,y:1154,t:1526328989816};\\\", \\\"{x:1321,y:1143,t:1526328989832};\\\", \\\"{x:1314,y:1130,t:1526328989848};\\\", \\\"{x:1307,y:1115,t:1526328989865};\\\", \\\"{x:1303,y:1101,t:1526328989881};\\\", \\\"{x:1301,y:1088,t:1526328989899};\\\", \\\"{x:1295,y:1054,t:1526328989915};\\\", \\\"{x:1292,y:1027,t:1526328989932};\\\", \\\"{x:1292,y:1007,t:1526328989949};\\\", \\\"{x:1298,y:988,t:1526328989966};\\\", \\\"{x:1310,y:968,t:1526328989982};\\\", \\\"{x:1329,y:954,t:1526328989999};\\\", \\\"{x:1349,y:945,t:1526328990015};\\\", \\\"{x:1363,y:942,t:1526328990032};\\\", \\\"{x:1373,y:939,t:1526328990049};\\\", \\\"{x:1379,y:938,t:1526328990065};\\\", \\\"{x:1384,y:938,t:1526328990082};\\\", \\\"{x:1397,y:940,t:1526328990099};\\\", \\\"{x:1412,y:951,t:1526328990115};\\\", \\\"{x:1436,y:969,t:1526328990132};\\\", \\\"{x:1448,y:978,t:1526328990150};\\\", \\\"{x:1452,y:979,t:1526328990166};\\\", \\\"{x:1454,y:980,t:1526328990182};\\\", \\\"{x:1459,y:979,t:1526328990429};\\\", \\\"{x:1465,y:976,t:1526328990436};\\\", \\\"{x:1467,y:976,t:1526328990451};\\\", \\\"{x:1471,y:972,t:1526328990465};\\\", \\\"{x:1471,y:964,t:1526328995469};\\\", \\\"{x:1412,y:884,t:1526328995484};\\\", \\\"{x:1358,y:837,t:1526328995497};\\\", \\\"{x:1215,y:755,t:1526328995512};\\\", \\\"{x:1030,y:667,t:1526328995529};\\\", \\\"{x:862,y:599,t:1526328995546};\\\", \\\"{x:729,y:553,t:1526328995563};\\\", \\\"{x:581,y:505,t:1526328995580};\\\", \\\"{x:521,y:483,t:1526328995604};\\\", \\\"{x:513,y:478,t:1526328995621};\\\", \\\"{x:511,y:476,t:1526328995651};\\\", \\\"{x:508,y:474,t:1526328995659};\\\", \\\"{x:504,y:472,t:1526328995671};\\\", \\\"{x:503,y:471,t:1526328995688};\\\", \\\"{x:504,y:470,t:1526328995740};\\\", \\\"{x:511,y:470,t:1526328995755};\\\", \\\"{x:531,y:484,t:1526328995772};\\\", \\\"{x:558,y:498,t:1526328995788};\\\", \\\"{x:574,y:508,t:1526328995805};\\\", \\\"{x:580,y:514,t:1526328995822};\\\", \\\"{x:581,y:515,t:1526328995838};\\\", \\\"{x:582,y:516,t:1526328995956};\\\", \\\"{x:584,y:516,t:1526328995972};\\\", \\\"{x:586,y:516,t:1526328996003};\\\", \\\"{x:587,y:516,t:1526328996019};\\\", \\\"{x:591,y:515,t:1526328996028};\\\", \\\"{x:593,y:514,t:1526328996039};\\\", \\\"{x:602,y:513,t:1526328996056};\\\", \\\"{x:609,y:510,t:1526328996072};\\\", \\\"{x:611,y:509,t:1526328996088};\\\", \\\"{x:610,y:513,t:1526328996411};\\\", \\\"{x:606,y:521,t:1526328996423};\\\", \\\"{x:599,y:537,t:1526328996439};\\\", \\\"{x:580,y:571,t:1526328996455};\\\", \\\"{x:566,y:602,t:1526328996472};\\\", \\\"{x:547,y:641,t:1526328996489};\\\", \\\"{x:533,y:672,t:1526328996506};\\\", \\\"{x:517,y:703,t:1526328996522};\\\", \\\"{x:506,y:725,t:1526328996539};\\\", \\\"{x:489,y:752,t:1526328996555};\\\", \\\"{x:486,y:763,t:1526328996571};\\\", \\\"{x:483,y:768,t:1526328996588};\\\", \\\"{x:483,y:771,t:1526328996606};\\\", \\\"{x:483,y:772,t:1526328996622};\\\", \\\"{x:484,y:771,t:1526328996707};\\\", \\\"{x:488,y:768,t:1526328996723};\\\", \\\"{x:489,y:765,t:1526328996739};\\\", \\\"{x:501,y:756,t:1526328996755};\\\", \\\"{x:508,y:752,t:1526328996772};\\\", \\\"{x:512,y:749,t:1526328996788};\\\", \\\"{x:512,y:748,t:1526328996805};\\\", \\\"{x:512,y:747,t:1526328997243};\\\", \\\"{x:512,y:746,t:1526328997259};\\\", \\\"{x:511,y:745,t:1526328997275};\\\", \\\"{x:510,y:744,t:1526328997291};\\\", \\\"{x:509,y:744,t:1526328997332};\\\", \\\"{x:509,y:742,t:1526328998828};\\\", \\\"{x:529,y:735,t:1526328998843};\\\", \\\"{x:541,y:732,t:1526328998857};\\\", \\\"{x:570,y:722,t:1526328998873};\\\", \\\"{x:605,y:710,t:1526328998890};\\\", \\\"{x:631,y:701,t:1526328998907};\\\", \\\"{x:673,y:683,t:1526328998923};\\\", \\\"{x:707,y:674,t:1526328998939};\\\", \\\"{x:730,y:666,t:1526328998956};\\\", \\\"{x:749,y:660,t:1526328998974};\\\", \\\"{x:762,y:654,t:1526328998990};\\\", \\\"{x:765,y:652,t:1526328999007};\\\", \\\"{x:766,y:651,t:1526328999024};\\\", \\\"{x:767,y:649,t:1526328999040};\\\", \\\"{x:768,y:648,t:1526328999056};\\\", \\\"{x:769,y:647,t:1526328999073};\\\", \\\"{x:769,y:646,t:1526328999090};\\\", \\\"{x:770,y:646,t:1526328999106};\\\", \\\"{x:770,y:644,t:1526328999123};\\\", \\\"{x:772,y:642,t:1526328999140};\\\", \\\"{x:777,y:636,t:1526328999157};\\\", \\\"{x:785,y:626,t:1526328999173};\\\", \\\"{x:797,y:617,t:1526328999190};\\\", \\\"{x:813,y:603,t:1526328999207};\\\", \\\"{x:827,y:593,t:1526328999224};\\\", \\\"{x:843,y:584,t:1526328999240};\\\", \\\"{x:854,y:576,t:1526328999257};\\\", \\\"{x:859,y:573,t:1526328999274};\\\", \\\"{x:861,y:573,t:1526328999339};\\\", \\\"{x:861,y:572,t:1526328999347};\\\", \\\"{x:862,y:571,t:1526328999363};\\\", \\\"{x:863,y:570,t:1526328999379};\\\", \\\"{x:864,y:570,t:1526328999391};\\\", \\\"{x:864,y:569,t:1526328999408};\\\", \\\"{x:865,y:569,t:1526328999636};\\\", \\\"{x:865,y:568,t:1526328999644};\\\", \\\"{x:866,y:568,t:1526328999660};\\\", \\\"{x:866,y:568,t:1526328999741};\\\", \\\"{x:865,y:568,t:1526329001636};\\\", \\\"{x:865,y:570,t:1526329001844};\\\", \\\"{x:866,y:574,t:1526329001859};\\\", \\\"{x:869,y:578,t:1526329001877};\\\", \\\"{x:869,y:582,t:1526329001893};\\\", \\\"{x:869,y:589,t:1526329001910};\\\", \\\"{x:869,y:596,t:1526329001926};\\\", \\\"{x:870,y:602,t:1526329001943};\\\", \\\"{x:872,y:611,t:1526329001960};\\\", \\\"{x:874,y:620,t:1526329001976};\\\", \\\"{x:874,y:626,t:1526329001992};\\\", \\\"{x:874,y:629,t:1526329002010};\\\", \\\"{x:874,y:635,t:1526329002026};\\\", \\\"{x:874,y:640,t:1526329002042};\\\", \\\"{x:874,y:641,t:1526329002060};\\\", \\\"{x:874,y:643,t:1526329002124};\\\", \\\"{x:874,y:644,t:1526329002180};\\\", \\\"{x:873,y:646,t:1526329002220};\\\", \\\"{x:872,y:647,t:1526329002277};\\\", \\\"{x:871,y:648,t:1526329002293};\\\", \\\"{x:870,y:648,t:1526329002310};\\\", \\\"{x:869,y:648,t:1526329002327};\\\", \\\"{x:868,y:650,t:1526329002347};\\\", \\\"{x:867,y:650,t:1526329002360};\\\", \\\"{x:866,y:651,t:1526329002376};\\\", \\\"{x:863,y:654,t:1526329002394};\\\", \\\"{x:860,y:657,t:1526329002410};\\\", \\\"{x:859,y:659,t:1526329002435};\\\", \\\"{x:859,y:660,t:1526329002555};\\\", \\\"{x:859,y:661,t:1526329007130};\\\", \\\"{x:859,y:664,t:1526329007147};\\\", \\\"{x:859,y:667,t:1526329007163};\\\", \\\"{x:859,y:670,t:1526329007182};\\\", \\\"{x:860,y:671,t:1526329007197};\\\", \\\"{x:864,y:674,t:1526329007214};\\\", \\\"{x:872,y:678,t:1526329007232};\\\", \\\"{x:876,y:679,t:1526329007247};\\\", \\\"{x:880,y:680,t:1526329007264};\\\", \\\"{x:883,y:680,t:1526329007281};\\\", \\\"{x:887,y:680,t:1526329007298};\\\", \\\"{x:893,y:681,t:1526329007314};\\\", \\\"{x:898,y:681,t:1526329007332};\\\", \\\"{x:901,y:681,t:1526329007347};\\\", \\\"{x:904,y:681,t:1526329007364};\\\", \\\"{x:907,y:681,t:1526329007381};\\\", \\\"{x:912,y:683,t:1526329007398};\\\", \\\"{x:918,y:685,t:1526329007414};\\\", \\\"{x:920,y:686,t:1526329007431};\\\", \\\"{x:924,y:688,t:1526329007448};\\\", \\\"{x:926,y:690,t:1526329007464};\\\", \\\"{x:930,y:690,t:1526329007481};\\\", \\\"{x:933,y:692,t:1526329007499};\\\", \\\"{x:934,y:692,t:1526329007514};\\\", \\\"{x:935,y:692,t:1526329007571};\\\", \\\"{x:934,y:693,t:1526329009603};\\\", \\\"{x:929,y:694,t:1526329009617};\\\", \\\"{x:917,y:694,t:1526329009633};\\\", \\\"{x:909,y:679,t:1526329009650};\\\", \\\"{x:904,y:653,t:1526329009666};\\\", \\\"{x:896,y:621,t:1526329009682};\\\", \\\"{x:873,y:553,t:1526329009699};\\\", \\\"{x:862,y:511,t:1526329009717};\\\", \\\"{x:853,y:476,t:1526329009733};\\\", \\\"{x:846,y:447,t:1526329009750};\\\", \\\"{x:842,y:425,t:1526329009767};\\\", \\\"{x:840,y:402,t:1526329009782};\\\", \\\"{x:833,y:368,t:1526329009799};\\\", \\\"{x:822,y:331,t:1526329009816};\\\", \\\"{x:818,y:307,t:1526329009832};\\\", \\\"{x:817,y:288,t:1526329009850};\\\", \\\"{x:815,y:271,t:1526329009867};\\\", \\\"{x:811,y:256,t:1526329009883};\\\", \\\"{x:811,y:237,t:1526329009900};\\\", \\\"{x:810,y:231,t:1526329009917};\\\", \\\"{x:810,y:227,t:1526329009934};\\\", \\\"{x:810,y:223,t:1526329009950};\\\", \\\"{x:810,y:221,t:1526329009967};\\\", \\\"{x:810,y:219,t:1526329009984};\\\", \\\"{x:811,y:218,t:1526329010012};\\\", \\\"{x:812,y:218,t:1526329010052};\\\", \\\"{x:815,y:218,t:1526329010067};\\\", \\\"{x:818,y:218,t:1526329010084};\\\", \\\"{x:821,y:218,t:1526329010101};\\\", \\\"{x:827,y:223,t:1526329010116};\\\", \\\"{x:833,y:228,t:1526329010134};\\\", \\\"{x:836,y:232,t:1526329010151};\\\", \\\"{x:839,y:236,t:1526329010166};\\\", \\\"{x:841,y:238,t:1526329010185};\\\", \\\"{x:843,y:240,t:1526329010200};\\\", \\\"{x:844,y:241,t:1526329010216};\\\", \\\"{x:844,y:242,t:1526329010315};\\\", \\\"{x:844,y:243,t:1526329010330};\\\", \\\"{x:844,y:244,t:1526329010346};\\\", \\\"{x:844,y:245,t:1526329010362};\\\", \\\"{x:842,y:246,t:1526329010370};\\\", \\\"{x:841,y:246,t:1526329010383};\\\", \\\"{x:840,y:246,t:1526329010515};\\\", \\\"{x:840,y:245,t:1526329010531};\\\", \\\"{x:838,y:244,t:1526329010540};\\\", \\\"{x:838,y:243,t:1526329010554};\\\", \\\"{x:837,y:242,t:1526329010570};\\\", \\\"{x:836,y:241,t:1526329010644};\\\", \\\"{x:836,y:241,t:1526329011069};\\\", \\\"{x:835,y:241,t:1526329011467};\\\", \\\"{x:834,y:250,t:1526329011492};\\\", \\\"{x:833,y:252,t:1526329011501};\\\", \\\"{x:831,y:258,t:1526329011518};\\\", \\\"{x:831,y:261,t:1526329011535};\\\", \\\"{x:831,y:264,t:1526329011550};\\\", \\\"{x:831,y:265,t:1526329011568};\\\", \\\"{x:830,y:268,t:1526329011584};\\\", \\\"{x:830,y:270,t:1526329011600};\\\", \\\"{x:829,y:275,t:1526329011618};\\\", \\\"{x:828,y:281,t:1526329011634};\\\", \\\"{x:828,y:287,t:1526329011651};\\\", \\\"{x:826,y:295,t:1526329011668};\\\", \\\"{x:825,y:304,t:1526329011684};\\\", \\\"{x:823,y:313,t:1526329011701};\\\", \\\"{x:823,y:319,t:1526329011718};\\\", \\\"{x:823,y:324,t:1526329011735};\\\", \\\"{x:823,y:330,t:1526329011751};\\\", \\\"{x:823,y:336,t:1526329011768};\\\", \\\"{x:823,y:343,t:1526329011783};\\\", \\\"{x:823,y:347,t:1526329011801};\\\", \\\"{x:823,y:350,t:1526329011818};\\\", \\\"{x:823,y:353,t:1526329011834};\\\", \\\"{x:822,y:361,t:1526329011851};\\\", \\\"{x:821,y:364,t:1526329011867};\\\", \\\"{x:821,y:366,t:1526329011884};\\\", \\\"{x:821,y:371,t:1526329011901};\\\", \\\"{x:821,y:373,t:1526329011916};\\\", \\\"{x:821,y:374,t:1526329011934};\\\", \\\"{x:821,y:375,t:1526329011950};\\\", \\\"{x:821,y:379,t:1526329011967};\\\", \\\"{x:821,y:382,t:1526329011984};\\\", \\\"{x:823,y:391,t:1526329012001};\\\", \\\"{x:823,y:396,t:1526329012017};\\\", \\\"{x:825,y:400,t:1526329012034};\\\", \\\"{x:825,y:401,t:1526329012548};\\\", \\\"{x:825,y:402,t:1526329012555};\\\", \\\"{x:825,y:403,t:1526329012566};\\\", \\\"{x:824,y:406,t:1526329012584};\\\", \\\"{x:824,y:408,t:1526329012599};\\\", \\\"{x:824,y:412,t:1526329012619};\\\", \\\"{x:824,y:413,t:1526329012636};\\\", \\\"{x:824,y:414,t:1526329012652};\\\", \\\"{x:824,y:415,t:1526329012683};\\\", \\\"{x:824,y:417,t:1526329012691};\\\", \\\"{x:824,y:418,t:1526329012731};\\\", \\\"{x:824,y:419,t:1526329012739};\\\", \\\"{x:824,y:420,t:1526329012753};\\\", \\\"{x:824,y:421,t:1526329012770};\\\", \\\"{x:824,y:423,t:1526329012787};\\\", \\\"{x:824,y:424,t:1526329012802};\\\", \\\"{x:824,y:427,t:1526329012820};\\\", \\\"{x:826,y:428,t:1526329012837};\\\", \\\"{x:826,y:430,t:1526329012852};\\\", \\\"{x:826,y:431,t:1526329012869};\\\", \\\"{x:826,y:433,t:1526329012886};\\\", \\\"{x:826,y:434,t:1526329012902};\\\", \\\"{x:827,y:436,t:1526329012920};\\\", \\\"{x:827,y:438,t:1526329012955};\\\", \\\"{x:827,y:439,t:1526329013011};\\\", \\\"{x:827,y:441,t:1526329013043};\\\", \\\"{x:828,y:442,t:1526329013091};\\\", \\\"{x:828,y:445,t:1526329013114};\\\", \\\"{x:829,y:445,t:1526329013203};\\\", \\\"{x:830,y:445,t:1526329013232};\\\", \\\"{x:832,y:445,t:1526329013235};\\\", \\\"{x:833,y:444,t:1526329013252};\\\", \\\"{x:834,y:443,t:1526329013315};\\\", \\\"{x:834,y:443,t:1526329013423};\\\", \\\"{x:833,y:443,t:1526329013763};\\\", \\\"{x:830,y:446,t:1526329013771};\\\", \\\"{x:826,y:452,t:1526329013788};\\\", \\\"{x:825,y:456,t:1526329013803};\\\", \\\"{x:822,y:461,t:1526329013820};\\\", \\\"{x:818,y:466,t:1526329013836};\\\", \\\"{x:815,y:471,t:1526329013852};\\\", \\\"{x:813,y:475,t:1526329013870};\\\", \\\"{x:810,y:481,t:1526329013886};\\\", \\\"{x:808,y:486,t:1526329013902};\\\", \\\"{x:807,y:489,t:1526329013920};\\\", \\\"{x:806,y:496,t:1526329013936};\\\", \\\"{x:805,y:501,t:1526329013953};\\\", \\\"{x:803,y:507,t:1526329013969};\\\", \\\"{x:803,y:518,t:1526329013986};\\\", \\\"{x:803,y:525,t:1526329014002};\\\", \\\"{x:803,y:530,t:1526329014019};\\\", \\\"{x:804,y:537,t:1526329014036};\\\", \\\"{x:806,y:543,t:1526329014053};\\\", \\\"{x:808,y:548,t:1526329014069};\\\", \\\"{x:810,y:553,t:1526329014087};\\\", \\\"{x:813,y:561,t:1526329014104};\\\", \\\"{x:818,y:570,t:1526329014120};\\\", \\\"{x:821,y:577,t:1526329014137};\\\", \\\"{x:825,y:585,t:1526329014154};\\\", \\\"{x:827,y:590,t:1526329014169};\\\", \\\"{x:831,y:596,t:1526329014187};\\\", \\\"{x:834,y:602,t:1526329014204};\\\", \\\"{x:835,y:606,t:1526329014219};\\\", \\\"{x:837,y:610,t:1526329014237};\\\", \\\"{x:838,y:614,t:1526329014252};\\\", \\\"{x:839,y:619,t:1526329014270};\\\", \\\"{x:840,y:622,t:1526329014287};\\\", \\\"{x:841,y:625,t:1526329014302};\\\", \\\"{x:841,y:629,t:1526329014320};\\\", \\\"{x:841,y:632,t:1526329014336};\\\", \\\"{x:841,y:635,t:1526329014352};\\\", \\\"{x:841,y:637,t:1526329014369};\\\", \\\"{x:841,y:641,t:1526329014386};\\\", \\\"{x:841,y:642,t:1526329014403};\\\", \\\"{x:841,y:644,t:1526329014420};\\\", \\\"{x:841,y:645,t:1526329014437};\\\", \\\"{x:841,y:646,t:1526329014484};\\\", \\\"{x:841,y:647,t:1526329014507};\\\", \\\"{x:840,y:647,t:1526329014564};\\\", \\\"{x:839,y:648,t:1526329014587};\\\", \\\"{x:838,y:650,t:1526329014603};\\\", \\\"{x:836,y:652,t:1526329014620};\\\", \\\"{x:834,y:654,t:1526329014637};\\\", \\\"{x:832,y:655,t:1526329014654};\\\", \\\"{x:830,y:657,t:1526329014670};\\\", \\\"{x:827,y:660,t:1526329014687};\\\", \\\"{x:824,y:665,t:1526329014705};\\\", \\\"{x:823,y:668,t:1526329014720};\\\", \\\"{x:821,y:671,t:1526329014736};\\\", \\\"{x:820,y:674,t:1526329014754};\\\", \\\"{x:817,y:678,t:1526329014769};\\\", \\\"{x:814,y:686,t:1526329014786};\\\", \\\"{x:813,y:689,t:1526329014804};\\\", \\\"{x:812,y:693,t:1526329014820};\\\", \\\"{x:811,y:696,t:1526329014836};\\\", \\\"{x:810,y:702,t:1526329014854};\\\", \\\"{x:809,y:708,t:1526329014870};\\\", \\\"{x:809,y:714,t:1526329014887};\\\", \\\"{x:809,y:716,t:1526329014904};\\\", \\\"{x:807,y:717,t:1526329014919};\\\", \\\"{x:806,y:717,t:1526329014937};\\\", \\\"{x:807,y:717,t:1526329015683};\\\", \\\"{x:808,y:716,t:1526329015690};\\\", \\\"{x:809,y:715,t:1526329015706};\\\", \\\"{x:811,y:713,t:1526329015721};\\\", \\\"{x:812,y:713,t:1526329015738};\\\", \\\"{x:815,y:711,t:1526329015754};\\\", \\\"{x:818,y:710,t:1526329015770};\\\", \\\"{x:819,y:709,t:1526329015788};\\\", \\\"{x:820,y:709,t:1526329015819};\\\", \\\"{x:821,y:708,t:1526329015827};\\\", \\\"{x:822,y:707,t:1526329015838};\\\", \\\"{x:823,y:706,t:1526329015859};\\\", \\\"{x:825,y:705,t:1526329015875};\\\", \\\"{x:826,y:705,t:1526329016004};\\\", \\\"{x:827,y:704,t:1526329016021};\\\", \\\"{x:828,y:704,t:1526329016043};\\\", \\\"{x:830,y:703,t:1526329016067};\\\", \\\"{x:830,y:702,t:1526329016099};\\\", \\\"{x:831,y:702,t:1526329016138};\\\", \\\"{x:832,y:701,t:1526329016155};\\\", \\\"{x:833,y:701,t:1526329016179};\\\", \\\"{x:833,y:701,t:1526329017976};\\\", \\\"{x:832,y:705,t:1526329019875};\\\", \\\"{x:829,y:712,t:1526329019892};\\\", \\\"{x:828,y:718,t:1526329019905};\\\", \\\"{x:823,y:736,t:1526329019924};\\\", \\\"{x:821,y:747,t:1526329019941};\\\", \\\"{x:821,y:760,t:1526329019958};\\\", \\\"{x:819,y:771,t:1526329019975};\\\", \\\"{x:819,y:785,t:1526329019991};\\\", \\\"{x:819,y:796,t:1526329020007};\\\", \\\"{x:819,y:814,t:1526329020025};\\\", \\\"{x:819,y:832,t:1526329020041};\\\", \\\"{x:820,y:850,t:1526329020058};\\\", \\\"{x:820,y:869,t:1526329020074};\\\", \\\"{x:820,y:879,t:1526329020090};\\\", \\\"{x:821,y:885,t:1526329020108};\\\", \\\"{x:821,y:888,t:1526329020125};\\\", \\\"{x:821,y:891,t:1526329020141};\\\", \\\"{x:821,y:894,t:1526329020158};\\\", \\\"{x:821,y:897,t:1526329020175};\\\", \\\"{x:821,y:900,t:1526329020191};\\\", \\\"{x:821,y:904,t:1526329020208};\\\", \\\"{x:821,y:905,t:1526329020225};\\\", \\\"{x:821,y:909,t:1526329020241};\\\", \\\"{x:821,y:911,t:1526329020257};\\\", \\\"{x:821,y:914,t:1526329020274};\\\", \\\"{x:822,y:917,t:1526329020291};\\\", \\\"{x:823,y:919,t:1526329020308};\\\", \\\"{x:825,y:922,t:1526329020325};\\\", \\\"{x:826,y:925,t:1526329020342};\\\", \\\"{x:827,y:928,t:1526329020359};\\\", \\\"{x:828,y:931,t:1526329020375};\\\", \\\"{x:829,y:934,t:1526329020392};\\\", \\\"{x:831,y:941,t:1526329020407};\\\", \\\"{x:833,y:947,t:1526329020424};\\\", \\\"{x:836,y:952,t:1526329020441};\\\", \\\"{x:836,y:954,t:1526329020458};\\\", \\\"{x:836,y:955,t:1526329020475};\\\", \\\"{x:836,y:956,t:1526329020563};\\\", \\\"{x:836,y:958,t:1526329020578};\\\", \\\"{x:835,y:959,t:1526329020592};\\\", \\\"{x:833,y:960,t:1526329020607};\\\", \\\"{x:832,y:961,t:1526329020625};\\\", \\\"{x:831,y:965,t:1526329021067};\\\", \\\"{x:831,y:969,t:1526329021075};\\\", \\\"{x:831,y:977,t:1526329021093};\\\", \\\"{x:833,y:986,t:1526329021110};\\\", \\\"{x:834,y:994,t:1526329021126};\\\", \\\"{x:838,y:1004,t:1526329021142};\\\", \\\"{x:839,y:1011,t:1526329021159};\\\", \\\"{x:840,y:1015,t:1526329021175};\\\", \\\"{x:841,y:1018,t:1526329021191};\\\", \\\"{x:843,y:1021,t:1526329021209};\\\", \\\"{x:843,y:1022,t:1526329021225};\\\", \\\"{x:844,y:1024,t:1526329021242};\\\", \\\"{x:845,y:1024,t:1526329021266};\\\", \\\"{x:848,y:1024,t:1526329021291};\\\", \\\"{x:850,y:1024,t:1526329021307};\\\", \\\"{x:851,y:1024,t:1526329021315};\\\", \\\"{x:852,y:1024,t:1526329021331};\\\", \\\"{x:853,y:1024,t:1526329021343};\\\", \\\"{x:854,y:1024,t:1526329021359};\\\", \\\"{x:856,y:1024,t:1526329021376};\\\", \\\"{x:858,y:1023,t:1526329021393};\\\", \\\"{x:860,y:1022,t:1526329021410};\\\", \\\"{x:861,y:1021,t:1526329021426};\\\", \\\"{x:863,y:1021,t:1526329021443};\\\", \\\"{x:864,y:1021,t:1526329021467};\\\", \\\"{x:865,y:1020,t:1526329021476};\\\", \\\"{x:866,y:1019,t:1526329021708};\\\", \\\"{x:867,y:1019,t:1526329021715};\\\", \\\"{x:869,y:1019,t:1526329021730};\\\", \\\"{x:870,y:1019,t:1526329021743};\\\", \\\"{x:871,y:1019,t:1526329021762};\\\", \\\"{x:871,y:1018,t:1526329021776};\\\", \\\"{x:872,y:1018,t:1526329021793};\\\", \\\"{x:872,y:1018,t:1526329021966};\\\", \\\"{x:873,y:1018,t:1526329023204};\\\", \\\"{x:872,y:1016,t:1526329023235};\\\", \\\"{x:871,y:1016,t:1526329023251};\\\", \\\"{x:871,y:1015,t:1526329023260};\\\", \\\"{x:870,y:1015,t:1526329023277};\\\", \\\"{x:867,y:1013,t:1526329023294};\\\", \\\"{x:866,y:1012,t:1526329023310};\\\", \\\"{x:864,y:1011,t:1526329023326};\\\", \\\"{x:862,y:1010,t:1526329023346};\\\", \\\"{x:862,y:1009,t:1526329023764};\\\", \\\"{x:860,y:1009,t:1526329023779};\\\", \\\"{x:859,y:1006,t:1526329023794};\\\", \\\"{x:857,y:1006,t:1526329023810};\\\", \\\"{x:855,y:1004,t:1526329023826};\\\", \\\"{x:852,y:1003,t:1526329023843};\\\", \\\"{x:851,y:1002,t:1526329023861};\\\", \\\"{x:849,y:1002,t:1526329023883};\\\", \\\"{x:849,y:1001,t:1526329023899};\\\", \\\"{x:848,y:1001,t:1526329023931};\\\", \\\"{x:847,y:1000,t:1526329023945};\\\", \\\"{x:846,y:1000,t:1526329023960};\\\", \\\"{x:846,y:999,t:1526329023987};\\\", \\\"{x:845,y:999,t:1526329023995};\\\", \\\"{x:844,y:998,t:1526329024019};\\\", \\\"{x:843,y:997,t:1526329024035};\\\", \\\"{x:842,y:996,t:1526329024075};\\\", \\\"{x:841,y:996,t:1526329024091};\\\", \\\"{x:840,y:995,t:1526329024107};\\\", \\\"{x:838,y:993,t:1526329024131};\\\", \\\"{x:837,y:993,t:1526329024145};\\\", \\\"{x:835,y:992,t:1526329024161};\\\", \\\"{x:832,y:991,t:1526329024177};\\\", \\\"{x:829,y:989,t:1526329024193};\\\", \\\"{x:818,y:985,t:1526329024210};\\\", \\\"{x:811,y:984,t:1526329024226};\\\", \\\"{x:802,y:981,t:1526329024243};\\\", \\\"{x:796,y:980,t:1526329024260};\\\", \\\"{x:792,y:977,t:1526329024276};\\\", \\\"{x:784,y:976,t:1526329024293};\\\", \\\"{x:777,y:972,t:1526329024310};\\\", \\\"{x:768,y:970,t:1526329024326};\\\", \\\"{x:758,y:967,t:1526329024344};\\\", \\\"{x:745,y:963,t:1526329024360};\\\", \\\"{x:731,y:961,t:1526329024377};\\\", \\\"{x:713,y:955,t:1526329024393};\\\", \\\"{x:685,y:950,t:1526329024410};\\\", \\\"{x:661,y:946,t:1526329024426};\\\", \\\"{x:638,y:946,t:1526329024444};\\\", \\\"{x:612,y:946,t:1526329024460};\\\", \\\"{x:584,y:946,t:1526329024476};\\\", \\\"{x:556,y:946,t:1526329024493};\\\", \\\"{x:527,y:946,t:1526329024510};\\\", \\\"{x:503,y:946,t:1526329024527};\\\", \\\"{x:478,y:946,t:1526329024544};\\\", \\\"{x:455,y:944,t:1526329024561};\\\", \\\"{x:430,y:940,t:1526329024576};\\\", \\\"{x:396,y:932,t:1526329024594};\\\", \\\"{x:349,y:923,t:1526329024611};\\\", \\\"{x:327,y:921,t:1526329024626};\\\", \\\"{x:314,y:917,t:1526329024644};\\\", \\\"{x:298,y:913,t:1526329024661};\\\", \\\"{x:288,y:910,t:1526329024677};\\\", \\\"{x:277,y:908,t:1526329024694};\\\", \\\"{x:270,y:907,t:1526329024711};\\\", \\\"{x:266,y:906,t:1526329024727};\\\", \\\"{x:263,y:906,t:1526329024744};\\\", \\\"{x:262,y:906,t:1526329024761};\\\", \\\"{x:261,y:906,t:1526329024779};\\\", \\\"{x:260,y:905,t:1526329024794};\\\", \\\"{x:253,y:902,t:1526329024811};\\\", \\\"{x:249,y:900,t:1526329024827};\\\", \\\"{x:241,y:896,t:1526329024843};\\\", \\\"{x:234,y:894,t:1526329024860};\\\", \\\"{x:230,y:892,t:1526329024877};\\\", \\\"{x:229,y:891,t:1526329024894};\\\", \\\"{x:217,y:882,t:1526329024911};\\\", \\\"{x:194,y:871,t:1526329024927};\\\", \\\"{x:181,y:865,t:1526329024944};\\\", \\\"{x:174,y:861,t:1526329024961};\\\", \\\"{x:171,y:860,t:1526329024978};\\\", \\\"{x:170,y:860,t:1526329024994};\\\", \\\"{x:168,y:859,t:1526329025011};\\\", \\\"{x:164,y:859,t:1526329025027};\\\", \\\"{x:161,y:858,t:1526329025044};\\\", \\\"{x:160,y:856,t:1526329025139};\\\", \\\"{x:159,y:854,t:1526329025147};\\\", \\\"{x:158,y:853,t:1526329025161};\\\", \\\"{x:153,y:848,t:1526329025177};\\\", \\\"{x:151,y:846,t:1526329025193};\\\", \\\"{x:149,y:845,t:1526329025211};\\\", \\\"{x:148,y:843,t:1526329025227};\\\", \\\"{x:147,y:843,t:1526329025244};\\\", \\\"{x:144,y:841,t:1526329025261};\\\", \\\"{x:143,y:841,t:1526329025278};\\\", \\\"{x:142,y:840,t:1526329025294};\\\", \\\"{x:140,y:840,t:1526329025836};\\\", \\\"{x:138,y:839,t:1526329025844};\\\", \\\"{x:135,y:839,t:1526329025860};\\\", \\\"{x:134,y:839,t:1526329025878};\\\", \\\"{x:143,y:838,t:1526329061831};\\\", \\\"{x:166,y:838,t:1526329061846};\\\", \\\"{x:174,y:841,t:1526329061860};\\\", \\\"{x:180,y:844,t:1526329061878};\\\", \\\"{x:193,y:850,t:1526329061895};\\\", \\\"{x:210,y:860,t:1526329061910};\\\", \\\"{x:233,y:871,t:1526329061927};\\\", \\\"{x:255,y:879,t:1526329061945};\\\", \\\"{x:276,y:885,t:1526329061960};\\\", \\\"{x:299,y:890,t:1526329061977};\\\", \\\"{x:320,y:898,t:1526329061994};\\\", \\\"{x:344,y:905,t:1526329062011};\\\", \\\"{x:373,y:912,t:1526329062027};\\\", \\\"{x:404,y:916,t:1526329062044};\\\", \\\"{x:441,y:922,t:1526329062060};\\\", \\\"{x:474,y:925,t:1526329062078};\\\", \\\"{x:517,y:932,t:1526329062094};\\\", \\\"{x:544,y:932,t:1526329062110};\\\", \\\"{x:570,y:935,t:1526329062127};\\\", \\\"{x:598,y:940,t:1526329062144};\\\", \\\"{x:621,y:943,t:1526329062160};\\\", \\\"{x:645,y:948,t:1526329062177};\\\", \\\"{x:673,y:954,t:1526329062194};\\\", \\\"{x:695,y:959,t:1526329062210};\\\", \\\"{x:712,y:966,t:1526329062227};\\\", \\\"{x:725,y:970,t:1526329062244};\\\", \\\"{x:734,y:974,t:1526329062260};\\\", \\\"{x:744,y:978,t:1526329062276};\\\", \\\"{x:759,y:985,t:1526329062294};\\\", \\\"{x:767,y:989,t:1526329062309};\\\", \\\"{x:772,y:991,t:1526329062327};\\\", \\\"{x:778,y:994,t:1526329062344};\\\", \\\"{x:783,y:996,t:1526329062360};\\\", \\\"{x:787,y:997,t:1526329062377};\\\", \\\"{x:789,y:998,t:1526329062394};\\\", \\\"{x:790,y:998,t:1526329062410};\\\", \\\"{x:791,y:999,t:1526329062427};\\\", \\\"{x:792,y:999,t:1526329062444};\\\", \\\"{x:797,y:1000,t:1526329062461};\\\", \\\"{x:803,y:1003,t:1526329062477};\\\", \\\"{x:810,y:1005,t:1526329062495};\\\", \\\"{x:818,y:1007,t:1526329062509};\\\", \\\"{x:825,y:1007,t:1526329062527};\\\", \\\"{x:829,y:1008,t:1526329062544};\\\", \\\"{x:833,y:1009,t:1526329062560};\\\", \\\"{x:835,y:1009,t:1526329062577};\\\", \\\"{x:836,y:1009,t:1526329062594};\\\", \\\"{x:839,y:1009,t:1526329062610};\\\", \\\"{x:840,y:1010,t:1526329062626};\\\", \\\"{x:842,y:1010,t:1526329062645};\\\", \\\"{x:844,y:1010,t:1526329062661};\\\", \\\"{x:845,y:1010,t:1526329062677};\\\", \\\"{x:846,y:1010,t:1526329062693};\\\", \\\"{x:849,y:1011,t:1526329062711};\\\", \\\"{x:851,y:1011,t:1526329062727};\\\", \\\"{x:853,y:1012,t:1526329062743};\\\", \\\"{x:858,y:1014,t:1526329062761};\\\", \\\"{x:860,y:1014,t:1526329062777};\\\", \\\"{x:863,y:1015,t:1526329062793};\\\", \\\"{x:866,y:1016,t:1526329062810};\\\", \\\"{x:870,y:1018,t:1526329062827};\\\", \\\"{x:873,y:1019,t:1526329062844};\\\", \\\"{x:875,y:1021,t:1526329062861};\\\", \\\"{x:877,y:1023,t:1526329062877};\\\", \\\"{x:880,y:1025,t:1526329062894};\\\", \\\"{x:883,y:1028,t:1526329062911};\\\", \\\"{x:885,y:1029,t:1526329062927};\\\", \\\"{x:886,y:1030,t:1526329062943};\\\", \\\"{x:887,y:1031,t:1526329062961};\\\", \\\"{x:888,y:1032,t:1526329062977};\\\", \\\"{x:890,y:1034,t:1526329062994};\\\", \\\"{x:891,y:1035,t:1526329063011};\\\", \\\"{x:892,y:1036,t:1526329063027};\\\", \\\"{x:894,y:1037,t:1526329063043};\\\", \\\"{x:896,y:1039,t:1526329063060};\\\", \\\"{x:899,y:1042,t:1526329063077};\\\", \\\"{x:900,y:1042,t:1526329063094};\\\", \\\"{x:902,y:1043,t:1526329063111};\\\", \\\"{x:904,y:1045,t:1526329063127};\\\", \\\"{x:908,y:1047,t:1526329063144};\\\", \\\"{x:912,y:1049,t:1526329063160};\\\", \\\"{x:916,y:1051,t:1526329063176};\\\", \\\"{x:917,y:1052,t:1526329063194};\\\", \\\"{x:918,y:1053,t:1526329063210};\\\", \\\"{x:919,y:1054,t:1526329063229};\\\", \\\"{x:922,y:1055,t:1526329063244};\\\", \\\"{x:924,y:1056,t:1526329063261};\\\", \\\"{x:928,y:1058,t:1526329063277};\\\", \\\"{x:930,y:1059,t:1526329063294};\\\", \\\"{x:931,y:1060,t:1526329063311};\\\", \\\"{x:932,y:1060,t:1526329063334};\\\", \\\"{x:932,y:1061,t:1526329063344};\\\", \\\"{x:934,y:1061,t:1526329063361};\\\", \\\"{x:936,y:1062,t:1526329063377};\\\", \\\"{x:938,y:1063,t:1526329063394};\\\", \\\"{x:940,y:1063,t:1526329063411};\\\", \\\"{x:941,y:1065,t:1526329063427};\\\", \\\"{x:942,y:1065,t:1526329063446};\\\", \\\"{x:944,y:1066,t:1526329063462};\\\", \\\"{x:944,y:1067,t:1526329063487};\\\", \\\"{x:945,y:1067,t:1526329063502};\\\", \\\"{x:945,y:1068,t:1526329063510};\\\", \\\"{x:947,y:1068,t:1526329063527};\\\", \\\"{x:948,y:1068,t:1526329063558};\\\", \\\"{x:948,y:1069,t:1526329063606};\\\", \\\"{x:949,y:1069,t:1526329063614};\\\", \\\"{x:950,y:1069,t:1526329063627};\\\", \\\"{x:950,y:1070,t:1526329063644};\\\", \\\"{x:951,y:1071,t:1526329063661};\\\", \\\"{x:952,y:1072,t:1526329063695};\\\", \\\"{x:955,y:1074,t:1526329063711};\\\", \\\"{x:956,y:1075,t:1526329063727};\\\", \\\"{x:957,y:1075,t:1526329063748};\\\", \\\"{x:958,y:1075,t:1526329063764};\\\", \\\"{x:959,y:1075,t:1526329063797};\\\", \\\"{x:960,y:1076,t:1526329063815};\\\", \\\"{x:961,y:1076,t:1526329063838};\\\", \\\"{x:963,y:1077,t:1526329063848};\\\", \\\"{x:965,y:1077,t:1526329063864};\\\", \\\"{x:966,y:1077,t:1526329063882};\\\", \\\"{x:968,y:1077,t:1526329063897};\\\", \\\"{x:970,y:1077,t:1526329063915};\\\", \\\"{x:971,y:1077,t:1526329063931};\\\", \\\"{x:973,y:1077,t:1526329063948};\\\", \\\"{x:974,y:1077,t:1526329063965};\\\", \\\"{x:975,y:1077,t:1526329063982};\\\", \\\"{x:976,y:1077,t:1526329063998};\\\", \\\"{x:977,y:1077,t:1526329064390};\\\", \\\"{x:978,y:1078,t:1526329064406};\\\", \\\"{x:978,y:1080,t:1526329064415};\\\", \\\"{x:978,y:1083,t:1526329064432};\\\", \\\"{x:978,y:1087,t:1526329064448};\\\", \\\"{x:978,y:1088,t:1526329064470};\\\" ] }, { \\\"rt\\\": 9705, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"united states\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 861680, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 13244, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 875946, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 41944, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 919235, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"9393C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"too\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2754}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"9393C\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2274},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2276},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2288,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2289,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2290,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2291,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2292,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2294},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2296,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2299,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 122, dom: 1804, initialDom: 2789",
  "javascriptErrors": []
}