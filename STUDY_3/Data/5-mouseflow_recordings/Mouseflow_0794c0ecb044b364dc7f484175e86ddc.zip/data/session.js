var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0794c0ecb044b364dc7f484175e86ddc",
  "created": "2018-05-18T11:08:28.451279-07:00",
  "lastActivity": "2018-05-18T11:10:58.8018991-07:00",
  "pageViews": [
    {
      "id": "05182802aeb12d83b9ba7addeddb87323a7fea7a",
      "startTime": "2018-05-18T11:08:28.451279-07:00",
      "endTime": "2018-05-18T11:10:58.8018991-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 150560,
      "engagementTime": 58406,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 150560,
  "engagementTime": 58406,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.45",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3528264d785ff3a0bf741d6f8fe09b4e",
  "gdpr": false
}