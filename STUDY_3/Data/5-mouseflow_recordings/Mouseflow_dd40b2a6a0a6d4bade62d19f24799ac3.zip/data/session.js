var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dd40b2a6a0a6d4bade62d19f24799ac3",
  "created": "2018-05-22T14:09:12.2813134-07:00",
  "lastActivity": "2018-05-22T14:09:27.7643194-07:00",
  "pageViews": [
    {
      "id": "052212268f4b64d3efade507d0de72df8e27fc25",
      "startTime": "2018-05-22T14:09:12.300714-07:00",
      "endTime": "2018-05-22T14:09:27.7643194-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 15700,
      "engagementTime": 15700,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15700,
  "engagementTime": 15700,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OZV09",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ab7bda5bcc8e538a0f9b8ef9bfdf7389",
  "gdpr": false
}