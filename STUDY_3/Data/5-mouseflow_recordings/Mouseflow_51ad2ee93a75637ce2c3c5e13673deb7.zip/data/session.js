var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "51ad2ee93a75637ce2c3c5e13673deb7",
  "created": "2018-05-22T16:00:54.7299518-07:00",
  "lastActivity": "2018-05-22T16:05:27.9861639-07:00",
  "pageViews": [
    {
      "id": "0522544404aa3f752cbc0f5e6fc4f947aa4918c4",
      "startTime": "2018-05-22T16:00:54.865115-07:00",
      "endTime": "2018-05-22T16:05:27.9861639-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 273649,
      "engagementTime": 66367,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 273649,
  "engagementTime": 66367,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d76e8fc323f7da2081e93859e7f7147f",
  "gdpr": false
}