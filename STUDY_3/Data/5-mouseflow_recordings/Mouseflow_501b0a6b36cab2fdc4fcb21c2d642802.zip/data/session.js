var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "501b0a6b36cab2fdc4fcb21c2d642802",
  "created": "2018-05-18T11:14:42.3497284-07:00",
  "lastActivity": "2018-05-18T11:14:52.8147284-07:00",
  "pageViews": [
    {
      "id": "05184264db89df7476ba3cb8bdc0aa33f76a5b6b",
      "startTime": "2018-05-18T11:14:42.3497284-07:00",
      "endTime": "2018-05-18T11:14:52.8147284-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10465,
      "engagementTime": 10458,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10465,
  "engagementTime": 10458,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FY6UN",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "54f5183b5cf299b1f19a2df529dd3100",
  "gdpr": false
}