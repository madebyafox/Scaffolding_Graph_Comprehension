var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05250057c1e6562f7008636127008fb2572e4a3f"] = {
  "startTime": "2018-05-25T18:07:00.2980427Z",
  "websitePageUrl": "/",
  "visitTime": 128590,
  "engagementTime": 53820,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "bb17480892c5fc6e888a1865acf27a8b",
    "created": "2018-05-25T18:07:00.2980427+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "617179051477d335f532005176e7374c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bb17480892c5fc6e888a1865acf27a8b/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 247,
      "e": 247,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 1077,
      "y": 538
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 52619,
      "y": 40754,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 1330,
      "y": 649
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 1339,
      "y": 665
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 1290,
      "y": 667
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 50816,
      "y": 42638,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 1288,
      "y": 667
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 50707,
      "y": 42638,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2506,
      "e": 2506,
      "ty": 3,
      "x": 1288,
      "y": 667,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2617,
      "e": 2617,
      "ty": 4,
      "x": 50707,
      "y": 42638,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2617,
      "e": 2617,
      "ty": 5,
      "x": 1288,
      "y": 667,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 1225,
      "y": 715
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 1070,
      "y": 791
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 38802,
      "y": 52796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3103,
      "e": 3103,
      "ty": 2,
      "x": 1057,
      "y": 810
    },
    {
      "t": 3205,
      "e": 3205,
      "ty": 2,
      "x": 1054,
      "y": 811
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 3,
      "x": 1054,
      "y": 811,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 37928,
      "y": 54435,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3370,
      "e": 3370,
      "ty": 4,
      "x": 37928,
      "y": 54435,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3370,
      "e": 3370,
      "ty": 5,
      "x": 1054,
      "y": 811,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1044,
      "y": 716
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 37382,
      "y": 46652,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1037,
      "y": 691
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1051,
      "y": 681
    },
    {
      "t": 4254,
      "e": 4254,
      "ty": 41,
      "x": 37819,
      "y": 43703,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1052,
      "y": 680
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 4799,
      "e": 4799,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 5099,
      "e": 5099,
      "ty": 2,
      "x": 1058,
      "y": 696
    },
    {
      "t": 5099,
      "e": 5099,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1064,
      "y": 697
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 38474,
      "y": 45096,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1058,
      "y": 698
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 38146,
      "y": 45178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1057,
      "y": 700
    },
    {
      "t": 5754,
      "e": 5754,
      "ty": 41,
      "x": 38092,
      "y": 45342,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 24901,
      "e": 10754,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 24901,
      "e": 10754,
      "ty": 2,
      "x": 1057,
      "y": 766
    },
    {
      "t": 25001,
      "e": 10854,
      "ty": 41,
      "x": 38092,
      "y": 46406,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26251,
      "e": 12104,
      "ty": 41,
      "x": 38638,
      "y": 44686,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26301,
      "e": 12154,
      "ty": 2,
      "x": 1107,
      "y": 738
    },
    {
      "t": 26400,
      "e": 12253,
      "ty": 2,
      "x": 1182,
      "y": 780
    },
    {
      "t": 26501,
      "e": 12354,
      "ty": 41,
      "x": 44918,
      "y": 47553,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 28201,
      "e": 14054,
      "ty": 2,
      "x": 1144,
      "y": 809
    },
    {
      "t": 28251,
      "e": 14104,
      "ty": 41,
      "x": 42843,
      "y": 49929,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30001,
      "e": 15854,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 86488,
      "e": 19104,
      "ty": 2,
      "x": 1134,
      "y": 805
    },
    {
      "t": 86488,
      "e": 19104,
      "ty": 41,
      "x": 38776,
      "y": 44151,
      "ta": "html > body"
    },
    {
      "t": 86588,
      "e": 19204,
      "ty": 2,
      "x": 787,
      "y": 163
    },
    {
      "t": 86687,
      "e": 19303,
      "ty": 2,
      "x": 813,
      "y": 16
    },
    {
      "t": 86738,
      "e": 19354,
      "ty": 41,
      "x": 27722,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 86840,
      "e": 19456,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 86909,
      "e": 19525,
      "ty": 2,
      "x": 810,
      "y": 20
    },
    {
      "t": 86988,
      "e": 19604,
      "ty": 2,
      "x": 801,
      "y": 48
    },
    {
      "t": 86988,
      "e": 19604,
      "ty": 41,
      "x": 21278,
      "y": 22159,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 87087,
      "e": 19703,
      "ty": 2,
      "x": 800,
      "y": 85
    },
    {
      "t": 87188,
      "e": 19804,
      "ty": 2,
      "x": 798,
      "y": 114
    },
    {
      "t": 87238,
      "e": 19854,
      "ty": 41,
      "x": 21060,
      "y": 52259,
      "ta": "> div.masterdiv > div > div > h3"
    },
    {
      "t": 87287,
      "e": 19903,
      "ty": 2,
      "x": 798,
      "y": 118
    },
    {
      "t": 87588,
      "e": 20204,
      "ty": 2,
      "x": 798,
      "y": 143
    },
    {
      "t": 87688,
      "e": 20304,
      "ty": 2,
      "x": 866,
      "y": 450
    },
    {
      "t": 87738,
      "e": 20354,
      "ty": 41,
      "x": 32349,
      "y": 8901,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 87788,
      "e": 20404,
      "ty": 2,
      "x": 964,
      "y": 746
    },
    {
      "t": 87888,
      "e": 20504,
      "ty": 2,
      "x": 924,
      "y": 816
    },
    {
      "t": 87988,
      "e": 20604,
      "ty": 2,
      "x": 862,
      "y": 912
    },
    {
      "t": 87988,
      "e": 20604,
      "ty": 41,
      "x": 12296,
      "y": 11961,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 88187,
      "e": 20803,
      "ty": 2,
      "x": 859,
      "y": 913
    },
    {
      "t": 88238,
      "e": 20854,
      "ty": 41,
      "x": 10196,
      "y": 26856,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 88288,
      "e": 20904,
      "ty": 2,
      "x": 845,
      "y": 920
    },
    {
      "t": 88387,
      "e": 21003,
      "ty": 2,
      "x": 839,
      "y": 922
    },
    {
      "t": 88488,
      "e": 21104,
      "ty": 2,
      "x": 821,
      "y": 927
    },
    {
      "t": 88488,
      "e": 21104,
      "ty": 41,
      "x": 57547,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 88587,
      "e": 21203,
      "ty": 2,
      "x": 808,
      "y": 927
    },
    {
      "t": 88627,
      "e": 21243,
      "ty": 3,
      "x": 808,
      "y": 927,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 88738,
      "e": 21354,
      "ty": 41,
      "x": 14950,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 88748,
      "e": 21364,
      "ty": 4,
      "x": 14950,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 88748,
      "e": 21364,
      "ty": 5,
      "x": 808,
      "y": 927,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 88749,
      "e": 21365,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 88754,
      "e": 21370,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 88988,
      "e": 21604,
      "ty": 2,
      "x": 823,
      "y": 933
    },
    {
      "t": 88988,
      "e": 21604,
      "ty": 41,
      "x": 26052,
      "y": 63310,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 89088,
      "e": 21704,
      "ty": 2,
      "x": 1043,
      "y": 1100
    },
    {
      "t": 89188,
      "e": 21804,
      "ty": 2,
      "x": 1139,
      "y": 1143
    },
    {
      "t": 89237,
      "e": 21853,
      "ty": 41,
      "x": 36469,
      "y": 60549,
      "ta": "> div.masterdiv"
    },
    {
      "t": 89262,
      "e": 21878,
      "ty": 6,
      "x": 1027,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 89288,
      "e": 21904,
      "ty": 2,
      "x": 1013,
      "y": 1081
    },
    {
      "t": 89387,
      "e": 22003,
      "ty": 2,
      "x": 978,
      "y": 1095
    },
    {
      "t": 89488,
      "e": 22104,
      "ty": 2,
      "x": 976,
      "y": 1097
    },
    {
      "t": 89488,
      "e": 22104,
      "ty": 41,
      "x": 36317,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 89645,
      "e": 22261,
      "ty": 3,
      "x": 976,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 89646,
      "e": 22262,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 89647,
      "e": 22263,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 89731,
      "e": 22347,
      "ty": 4,
      "x": 36317,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 89732,
      "e": 22348,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 89732,
      "e": 22348,
      "ty": 5,
      "x": 976,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 89733,
      "e": 22349,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 90737,
      "e": 23353,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 90888,
      "e": 23504,
      "ty": 2,
      "x": 976,
      "y": 1075
    },
    {
      "t": 90988,
      "e": 23604,
      "ty": 2,
      "x": 759,
      "y": 489
    },
    {
      "t": 90988,
      "e": 23604,
      "ty": 41,
      "x": 6967,
      "y": 30426,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 91088,
      "e": 23704,
      "ty": 2,
      "x": 706,
      "y": 385
    },
    {
      "t": 91244,
      "e": 23860,
      "ty": 41,
      "x": 24037,
      "y": 20884,
      "ta": "html > body"
    },
    {
      "t": 91388,
      "e": 24004,
      "ty": 2,
      "x": 717,
      "y": 405
    },
    {
      "t": 91488,
      "e": 24104,
      "ty": 2,
      "x": 967,
      "y": 565
    },
    {
      "t": 91488,
      "e": 24104,
      "ty": 41,
      "x": 34389,
      "y": 58513,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 91587,
      "e": 24203,
      "ty": 2,
      "x": 986,
      "y": 579
    },
    {
      "t": 91688,
      "e": 24304,
      "ty": 2,
      "x": 982,
      "y": 584
    },
    {
      "t": 91716,
      "e": 24332,
      "ty": 6,
      "x": 979,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91738,
      "e": 24354,
      "ty": 41,
      "x": 36336,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91788,
      "e": 24404,
      "ty": 2,
      "x": 971,
      "y": 603
    },
    {
      "t": 91931,
      "e": 24547,
      "ty": 3,
      "x": 971,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91931,
      "e": 24547,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91988,
      "e": 24604,
      "ty": 41,
      "x": 35254,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92027,
      "e": 24643,
      "ty": 4,
      "x": 35254,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92028,
      "e": 24644,
      "ty": 5,
      "x": 971,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93728,
      "e": 26344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 93855,
      "e": 26471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 93855,
      "e": 26471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93992,
      "e": 26608,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 94063,
      "e": 26679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 94368,
      "e": 26984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 94369,
      "e": 26985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94376,
      "e": 26992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "80"
    },
    {
      "t": 94376,
      "e": 26992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94431,
      "e": 27047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOP"
    },
    {
      "t": 94439,
      "e": 27055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOP"
    },
    {
      "t": 94735,
      "e": 27351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOP"
    },
    {
      "t": 94879,
      "e": 27495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 94992,
      "e": 27608,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 95023,
      "e": 27639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 95623,
      "e": 28239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 95624,
      "e": 28240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95735,
      "e": 28351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 95735,
      "e": 28351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95743,
      "e": 28359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOve"
    },
    {
      "t": 95854,
      "e": 28470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 95870,
      "e": 28486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 95870,
      "e": 28486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95967,
      "e": 28583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 96455,
      "e": 29071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 96561,
      "e": 29073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOve"
    },
    {
      "t": 96663,
      "e": 29175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 96735,
      "e": 29247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOv"
    },
    {
      "t": 96823,
      "e": 29335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 96887,
      "e": 29399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 96992,
      "e": 29504,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 97238,
      "e": 29750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 97694,
      "e": 30206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 97695,
      "e": 30207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97814,
      "e": 30326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 97855,
      "e": 30367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 97855,
      "e": 30367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97958,
      "e": 30470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 97975,
      "e": 30487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 97975,
      "e": 30487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98039,
      "e": 30551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 98191,
      "e": 30703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 98191,
      "e": 30703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98311,
      "e": 30823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||B"
    },
    {
      "t": 98319,
      "e": 30831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 98319,
      "e": 30831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98431,
      "e": 30943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 98431,
      "e": 30943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98447,
      "e": 30959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||ER"
    },
    {
      "t": 98527,
      "e": 31039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 98535,
      "e": 31047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 99103,
      "e": 31615,
      "ty": 7,
      "x": 964,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99187,
      "e": 31699,
      "ty": 2,
      "x": 958,
      "y": 669
    },
    {
      "t": 99236,
      "e": 31748,
      "ty": 6,
      "x": 958,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99237,
      "e": 31749,
      "ty": 41,
      "x": 32443,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99287,
      "e": 31799,
      "ty": 2,
      "x": 958,
      "y": 679
    },
    {
      "t": 99387,
      "e": 31899,
      "ty": 2,
      "x": 959,
      "y": 679
    },
    {
      "t": 99403,
      "e": 31915,
      "ty": 7,
      "x": 959,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99487,
      "e": 31999,
      "ty": 2,
      "x": 959,
      "y": 674
    },
    {
      "t": 99488,
      "e": 32000,
      "ty": 41,
      "x": 32659,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 99587,
      "e": 32099,
      "ty": 2,
      "x": 962,
      "y": 675
    },
    {
      "t": 99687,
      "e": 32199,
      "ty": 6,
      "x": 964,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99687,
      "e": 32199,
      "ty": 2,
      "x": 964,
      "y": 679
    },
    {
      "t": 99738,
      "e": 32250,
      "ty": 41,
      "x": 34173,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99787,
      "e": 32299,
      "ty": 2,
      "x": 966,
      "y": 681
    },
    {
      "t": 99859,
      "e": 32371,
      "ty": 3,
      "x": 966,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99859,
      "e": 32371,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 99859,
      "e": 32371,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99860,
      "e": 32372,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100019,
      "e": 32531,
      "ty": 4,
      "x": 34173,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100019,
      "e": 32531,
      "ty": 5,
      "x": 966,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100567,
      "e": 33079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 100567,
      "e": 33079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100647,
      "e": 33159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 100734,
      "e": 33246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 100735,
      "e": 33247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100815,
      "e": 33327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 100879,
      "e": 33391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 100879,
      "e": 33391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100967,
      "e": 33479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 101087,
      "e": 33599,
      "ty": 2,
      "x": 977,
      "y": 697
    },
    {
      "t": 101089,
      "e": 33601,
      "ty": 7,
      "x": 979,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101138,
      "e": 33650,
      "ty": 6,
      "x": 979,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 101187,
      "e": 33699,
      "ty": 2,
      "x": 979,
      "y": 712
    },
    {
      "t": 101237,
      "e": 33749,
      "ty": 41,
      "x": 43332,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 101287,
      "e": 33799,
      "ty": 2,
      "x": 980,
      "y": 726
    },
    {
      "t": 101387,
      "e": 33899,
      "ty": 2,
      "x": 980,
      "y": 727
    },
    {
      "t": 101487,
      "e": 33999,
      "ty": 41,
      "x": 43332,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 101688,
      "e": 34200,
      "ty": 2,
      "x": 980,
      "y": 728
    },
    {
      "t": 101737,
      "e": 34249,
      "ty": 41,
      "x": 44363,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 101788,
      "e": 34300,
      "ty": 2,
      "x": 982,
      "y": 728
    },
    {
      "t": 102887,
      "e": 35399,
      "ty": 2,
      "x": 982,
      "y": 727
    },
    {
      "t": 102987,
      "e": 35499,
      "ty": 41,
      "x": 44363,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103820,
      "e": 36332,
      "ty": 3,
      "x": 982,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103820,
      "e": 36332,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 103821,
      "e": 36333,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103821,
      "e": 36333,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103914,
      "e": 36426,
      "ty": 4,
      "x": 44363,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103917,
      "e": 36429,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103917,
      "e": 36429,
      "ty": 5,
      "x": 982,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103917,
      "e": 36429,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 104387,
      "e": 36899,
      "ty": 2,
      "x": 987,
      "y": 726
    },
    {
      "t": 104487,
      "e": 36999,
      "ty": 2,
      "x": 988,
      "y": 726
    },
    {
      "t": 104488,
      "e": 37000,
      "ty": 41,
      "x": 33748,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 104687,
      "e": 37199,
      "ty": 2,
      "x": 979,
      "y": 713
    },
    {
      "t": 104738,
      "e": 37250,
      "ty": 41,
      "x": 33301,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 104787,
      "e": 37299,
      "ty": 2,
      "x": 975,
      "y": 711
    },
    {
      "t": 105012,
      "e": 37524,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 105043,
      "e": 37555,
      "ty": 6,
      "x": 975,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 109988,
      "e": 42500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 114711,
      "e": 42555,
      "ty": 7,
      "x": 959,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 114711,
      "e": 42555,
      "ty": 6,
      "x": 959,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 114738,
      "e": 42582,
      "ty": 41,
      "x": 31106,
      "y": 7058,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 114744,
      "e": 42588,
      "ty": 7,
      "x": 934,
      "y": 659,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 114787,
      "e": 42631,
      "ty": 2,
      "x": 905,
      "y": 647
    },
    {
      "t": 114887,
      "e": 42731,
      "ty": 2,
      "x": 897,
      "y": 646
    },
    {
      "t": 114987,
      "e": 42831,
      "ty": 2,
      "x": 915,
      "y": 614
    },
    {
      "t": 114988,
      "e": 42832,
      "ty": 41,
      "x": 30578,
      "y": 32227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 115087,
      "e": 42931,
      "ty": 2,
      "x": 1055,
      "y": 403
    },
    {
      "t": 115188,
      "e": 43032,
      "ty": 2,
      "x": 1123,
      "y": 327
    },
    {
      "t": 115237,
      "e": 43081,
      "ty": 41,
      "x": 40811,
      "y": 13898,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115588,
      "e": 43432,
      "ty": 2,
      "x": 1111,
      "y": 322
    },
    {
      "t": 115688,
      "e": 43532,
      "ty": 2,
      "x": 909,
      "y": 340
    },
    {
      "t": 115738,
      "e": 43582,
      "ty": 41,
      "x": 24822,
      "y": 17222,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115788,
      "e": 43632,
      "ty": 2,
      "x": 738,
      "y": 391
    },
    {
      "t": 115887,
      "e": 43731,
      "ty": 2,
      "x": 657,
      "y": 402
    },
    {
      "t": 115987,
      "e": 43831,
      "ty": 2,
      "x": 620,
      "y": 402
    },
    {
      "t": 115988,
      "e": 43832,
      "ty": 41,
      "x": 16065,
      "y": 19091,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116188,
      "e": 44032,
      "ty": 2,
      "x": 662,
      "y": 369
    },
    {
      "t": 116238,
      "e": 44082,
      "ty": 41,
      "x": 29102,
      "y": 40977,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 116288,
      "e": 44132,
      "ty": 2,
      "x": 890,
      "y": 452
    },
    {
      "t": 116387,
      "e": 44231,
      "ty": 2,
      "x": 816,
      "y": 473
    },
    {
      "t": 116478,
      "e": 44322,
      "ty": 6,
      "x": 714,
      "y": 522,
      "ta": "#da1"
    },
    {
      "t": 116488,
      "e": 44332,
      "ty": 2,
      "x": 714,
      "y": 522
    },
    {
      "t": 116488,
      "e": 44332,
      "ty": 41,
      "x": 41541,
      "y": 32818,
      "ta": "#da1"
    },
    {
      "t": 116494,
      "e": 44338,
      "ty": 7,
      "x": 680,
      "y": 551,
      "ta": "#da1"
    },
    {
      "t": 116561,
      "e": 44405,
      "ty": 6,
      "x": 685,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 116579,
      "e": 44423,
      "ty": 7,
      "x": 724,
      "y": 747,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 116579,
      "e": 44423,
      "ty": 6,
      "x": 724,
      "y": 747,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 116588,
      "e": 44432,
      "ty": 2,
      "x": 724,
      "y": 747
    },
    {
      "t": 116594,
      "e": 44438,
      "ty": 7,
      "x": 756,
      "y": 774,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 116595,
      "e": 44439,
      "ty": 6,
      "x": 756,
      "y": 774,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116687,
      "e": 44531,
      "ty": 2,
      "x": 759,
      "y": 776
    },
    {
      "t": 116738,
      "e": 44582,
      "ty": 41,
      "x": 21632,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116788,
      "e": 44632,
      "ty": 2,
      "x": 775,
      "y": 777
    },
    {
      "t": 116811,
      "e": 44655,
      "ty": 7,
      "x": 842,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 116887,
      "e": 44731,
      "ty": 2,
      "x": 905,
      "y": 812
    },
    {
      "t": 116987,
      "e": 44831,
      "ty": 2,
      "x": 938,
      "y": 860
    },
    {
      "t": 116988,
      "e": 44832,
      "ty": 41,
      "x": 31709,
      "y": 50806,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 117087,
      "e": 44931,
      "ty": 2,
      "x": 981,
      "y": 981
    },
    {
      "t": 117188,
      "e": 45032,
      "ty": 2,
      "x": 996,
      "y": 1041
    },
    {
      "t": 117238,
      "e": 45082,
      "ty": 41,
      "x": 34464,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 117288,
      "e": 45132,
      "ty": 2,
      "x": 994,
      "y": 1057
    },
    {
      "t": 117361,
      "e": 45205,
      "ty": 6,
      "x": 994,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 117387,
      "e": 45231,
      "ty": 2,
      "x": 994,
      "y": 1082
    },
    {
      "t": 117488,
      "e": 45332,
      "ty": 2,
      "x": 994,
      "y": 1102
    },
    {
      "t": 117488,
      "e": 45332,
      "ty": 41,
      "x": 46147,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 117688,
      "e": 45532,
      "ty": 2,
      "x": 999,
      "y": 1097
    },
    {
      "t": 117738,
      "e": 45582,
      "ty": 41,
      "x": 51062,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 117788,
      "e": 45632,
      "ty": 2,
      "x": 1003,
      "y": 1093
    },
    {
      "t": 117860,
      "e": 45704,
      "ty": 3,
      "x": 1003,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 117860,
      "e": 45704,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 117970,
      "e": 45814,
      "ty": 4,
      "x": 51062,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 117971,
      "e": 45815,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 117972,
      "e": 45816,
      "ty": 5,
      "x": 1003,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 117972,
      "e": 45816,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 118738,
      "e": 46582,
      "ty": 41,
      "x": 34299,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 118788,
      "e": 46632,
      "ty": 2,
      "x": 1004,
      "y": 1092
    },
    {
      "t": 118973,
      "e": 46817,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 118987,
      "e": 46831,
      "ty": 2,
      "x": 1004,
      "y": 1091
    },
    {
      "t": 118988,
      "e": 46832,
      "ty": 41,
      "x": 34299,
      "y": 59995,
      "ta": "html > body"
    },
    {
      "t": 119876,
      "e": 47720,
      "ty": 2,
      "x": 982,
      "y": 1054
    },
    {
      "t": 119975,
      "e": 47819,
      "ty": 2,
      "x": 684,
      "y": 787
    },
    {
      "t": 119975,
      "e": 47819,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 119977,
      "e": 47821,
      "ty": 41,
      "x": 19393,
      "y": 49811,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120075,
      "e": 47919,
      "ty": 2,
      "x": 652,
      "y": 696
    },
    {
      "t": 120176,
      "e": 48020,
      "ty": 2,
      "x": 667,
      "y": 677
    },
    {
      "t": 120225,
      "e": 48069,
      "ty": 41,
      "x": 19733,
      "y": 40105,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120275,
      "e": 48119,
      "ty": 2,
      "x": 740,
      "y": 640
    },
    {
      "t": 120375,
      "e": 48219,
      "ty": 2,
      "x": 933,
      "y": 636
    },
    {
      "t": 120475,
      "e": 48319,
      "ty": 2,
      "x": 965,
      "y": 637
    },
    {
      "t": 120476,
      "e": 48320,
      "ty": 41,
      "x": 33034,
      "y": 38164,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120775,
      "e": 48619,
      "ty": 2,
      "x": 981,
      "y": 633
    },
    {
      "t": 120875,
      "e": 48719,
      "ty": 2,
      "x": 986,
      "y": 630
    },
    {
      "t": 120976,
      "e": 48820,
      "ty": 2,
      "x": 987,
      "y": 630
    },
    {
      "t": 120976,
      "e": 48820,
      "ty": 41,
      "x": 34102,
      "y": 37620,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 127586,
      "e": 53820,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 128590,
      "e": 53820,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 188, dom: 670, initialDom: 675",
  "javascriptErrors": []
}