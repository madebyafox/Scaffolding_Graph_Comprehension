var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06041893c6f01a12f8dff35bf4b1fe203c3b414e"] = {
  "startTime": "2018-06-04T20:22:18.5733157Z",
  "websitePageUrl": "/16",
  "visitTime": 135088,
  "engagementTime": 125114,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1881ee49b481645f1e95ee852ba42d4b",
    "created": "2018-06-04T20:22:18.5733157+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=VHSFM",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1f6a082bf72901a3bac49752e04d19ab",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1881ee49b481645f1e95ee852ba42d4b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 247,
      "e": 247,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 904,
      "e": 904,
      "ty": 2,
      "x": 528,
      "y": 746
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 520,
      "y": 692
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 47538,
      "y": 37891,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1020,
      "e": 1020,
      "ty": 6,
      "x": 509,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 508,
      "y": 555
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 509,
      "y": 544
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 46302,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1508,
      "e": 1508,
      "ty": 3,
      "x": 509,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1509,
      "e": 1509,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1651,
      "e": 1651,
      "ty": 4,
      "x": 46302,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1651,
      "e": 1651,
      "ty": 5,
      "x": 509,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 510,
      "y": 543
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 46414,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 8751,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10785,
      "e": 8751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11168,
      "e": 9134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11168,
      "e": 9134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11279,
      "e": 9245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 11302,
      "e": 9268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 11319,
      "e": 9285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11319,
      "e": 9285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11448,
      "e": 9414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11448,
      "e": 9414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11469,
      "e": 9435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In "
    },
    {
      "t": 11590,
      "e": 9556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In "
    },
    {
      "t": 11598,
      "e": 9564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11599,
      "e": 9565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11719,
      "e": 9685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In t"
    },
    {
      "t": 11736,
      "e": 9702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11736,
      "e": 9702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11799,
      "e": 9765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11799,
      "e": 9765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11854,
      "e": 9820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 11911,
      "e": 9877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11911,
      "e": 9877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11943,
      "e": 9909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12007,
      "e": 9973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12007,
      "e": 9973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12063,
      "e": 10029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12167,
      "e": 10133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12471,
      "e": 10437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12473,
      "e": 10439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12584,
      "e": 10550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 12584,
      "e": 10550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12630,
      "e": 10596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tr"
    },
    {
      "t": 12703,
      "e": 10669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12703,
      "e": 10669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12703,
      "e": 10669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12847,
      "e": 10813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13239,
      "e": 11205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13240,
      "e": 11206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13367,
      "e": 11333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13390,
      "e": 11356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13391,
      "e": 11357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13479,
      "e": 11445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 13666,
      "e": 11632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 13667,
      "e": 11633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13786,
      "e": 11752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 14265,
      "e": 12231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14265,
      "e": 12231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14406,
      "e": 12372,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangu"
    },
    {
      "t": 14410,
      "e": 12376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 14411,
      "e": 12377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14417,
      "e": 12383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ul"
    },
    {
      "t": 14505,
      "e": 12471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14505,
      "e": 12471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14570,
      "e": 12536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14649,
      "e": 12615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14651,
      "e": 12617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14651,
      "e": 12617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14753,
      "e": 12719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14770,
      "e": 12736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14770,
      "e": 12736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14914,
      "e": 12880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14978,
      "e": 12944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14979,
      "e": 12945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15098,
      "e": 13064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15098,
      "e": 13064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15154,
      "e": 13120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gr"
    },
    {
      "t": 15218,
      "e": 13184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15306,
      "e": 13272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15307,
      "e": 13273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15321,
      "e": 13287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 15322,
      "e": 13288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15361,
      "e": 13327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||aq"
    },
    {
      "t": 15401,
      "e": 13367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15401,
      "e": 13367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15457,
      "e": 13423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 15522,
      "e": 13488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15530,
      "e": 13496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15530,
      "e": 13496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15633,
      "e": 13599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15914,
      "e": 13880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15993,
      "e": 13959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graqp"
    },
    {
      "t": 16097,
      "e": 14063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16170,
      "e": 14136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graq"
    },
    {
      "t": 16266,
      "e": 14232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16338,
      "e": 14304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular gra"
    },
    {
      "t": 17162,
      "e": 15128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17163,
      "e": 15129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17289,
      "e": 15255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 17329,
      "e": 15295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17330,
      "e": 15296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17449,
      "e": 15415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17585,
      "e": 15551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 17585,
      "e": 15551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17689,
      "e": 15655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 18546,
      "e": 16512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18547,
      "e": 16513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18658,
      "e": 16624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18659,
      "e": 16625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18689,
      "e": 16655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 18769,
      "e": 16735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18825,
      "e": 16791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18825,
      "e": 16791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18906,
      "e": 16872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18906,
      "e": 16872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18929,
      "e": 16895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 19026,
      "e": 16992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19074,
      "e": 17040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19074,
      "e": 17040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19202,
      "e": 17168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20004,
      "e": 17970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20378,
      "e": 18344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 20379,
      "e": 18345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20498,
      "e": 18464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20498,
      "e": 18464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20521,
      "e": 18487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||cl"
    },
    {
      "t": 20650,
      "e": 18616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20651,
      "e": 18617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20657,
      "e": 18623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20737,
      "e": 18703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20737,
      "e": 18703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20769,
      "e": 18735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20841,
      "e": 18807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20971,
      "e": 18937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20971,
      "e": 18937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21065,
      "e": 19031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21065,
      "e": 19031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21122,
      "e": 19088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 21202,
      "e": 19168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21258,
      "e": 19224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21258,
      "e": 19224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21406,
      "e": 19372,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the closer "
    },
    {
      "t": 21409,
      "e": 19375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22202,
      "e": 20168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22281,
      "e": 20247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the closer"
    },
    {
      "t": 22393,
      "e": 20359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22481,
      "e": 20447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the close"
    },
    {
      "t": 22586,
      "e": 20552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22666,
      "e": 20632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the clos"
    },
    {
      "t": 22762,
      "e": 20728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22826,
      "e": 20792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the clo"
    },
    {
      "t": 22938,
      "e": 20904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23017,
      "e": 20983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the cl"
    },
    {
      "t": 23114,
      "e": 21080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23194,
      "e": 21160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the c"
    },
    {
      "t": 23474,
      "e": 21440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23521,
      "e": 21487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the "
    },
    {
      "t": 23802,
      "e": 21768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23802,
      "e": 21768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23921,
      "e": 21887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 24402,
      "e": 22368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24403,
      "e": 22369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24506,
      "e": 22472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24506,
      "e": 22472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24553,
      "e": 22519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ef"
    },
    {
      "t": 24618,
      "e": 22584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24786,
      "e": 22752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24787,
      "e": 22753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24849,
      "e": 22815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25674,
      "e": 23640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25675,
      "e": 23641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25690,
      "e": 23656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25705,
      "e": 23671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25705,
      "e": 23671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25713,
      "e": 23679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26154,
      "e": 24120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26155,
      "e": 24121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26209,
      "e": 24175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26209,
      "e": 24175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26305,
      "e": 24271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mo"
    },
    {
      "t": 26386,
      "e": 24352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26387,
      "e": 24353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26409,
      "e": 24375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26529,
      "e": 24495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26530,
      "e": 24496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26601,
      "e": 24567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26633,
      "e": 24599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26866,
      "e": 24832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26937,
      "e": 24903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left  mos"
    },
    {
      "t": 27041,
      "e": 25007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27122,
      "e": 25088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left  mo"
    },
    {
      "t": 27218,
      "e": 25184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27289,
      "e": 25255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left  m"
    },
    {
      "t": 27401,
      "e": 25367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27505,
      "e": 25471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left  "
    },
    {
      "t": 28074,
      "e": 26040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28161,
      "e": 26040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left "
    },
    {
      "t": 28361,
      "e": 26240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28362,
      "e": 26241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28513,
      "e": 26392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28522,
      "e": 26401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28522,
      "e": 26401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28635,
      "e": 26514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28636,
      "e": 26515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28642,
      "e": 26521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||os"
    },
    {
      "t": 28729,
      "e": 26608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28729,
      "e": 26608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28786,
      "e": 26665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28849,
      "e": 26728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28881,
      "e": 26760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28882,
      "e": 26761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29007,
      "e": 26886,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most "
    },
    {
      "t": 29018,
      "e": 26897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30433,
      "e": 28312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 30433,
      "e": 28312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30545,
      "e": 28424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30545,
      "e": 28424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30585,
      "e": 28464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bo"
    },
    {
      "t": 30649,
      "e": 28528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30650,
      "e": 28529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30657,
      "e": 28536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30721,
      "e": 28600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30833,
      "e": 28712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30833,
      "e": 28712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30906,
      "e": 28785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30979,
      "e": 28858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30979,
      "e": 28858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31057,
      "e": 28936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 31234,
      "e": 29113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31234,
      "e": 29113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31321,
      "e": 29200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32017,
      "e": 29896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32017,
      "e": 29896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32153,
      "e": 30032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32153,
      "e": 30032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32169,
      "e": 30048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||si"
    },
    {
      "t": 32242,
      "e": 30121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32298,
      "e": 30177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32298,
      "e": 30177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32405,
      "e": 30284,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bottm sid"
    },
    {
      "t": 32433,
      "e": 30312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32505,
      "e": 30384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32577,
      "e": 30456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bottm si"
    },
    {
      "t": 32689,
      "e": 30568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32793,
      "e": 30672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bottm s"
    },
    {
      "t": 32889,
      "e": 30768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32977,
      "e": 30856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bottm "
    },
    {
      "t": 33065,
      "e": 30944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33153,
      "e": 31032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bottm"
    },
    {
      "t": 33242,
      "e": 31121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33329,
      "e": 31208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bott"
    },
    {
      "t": 33441,
      "e": 31320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33514,
      "e": 31393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bot"
    },
    {
      "t": 33618,
      "e": 31497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33689,
      "e": 31568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bo"
    },
    {
      "t": 33806,
      "e": 31685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most bo"
    },
    {
      "t": 33811,
      "e": 31690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33913,
      "e": 31792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most b"
    },
    {
      "t": 33937,
      "e": 31816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34436,
      "e": 32315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34441,
      "e": 32315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most"
    },
    {
      "t": 34606,
      "e": 32480,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left most"
    },
    {
      "t": 34698,
      "e": 32572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34777,
      "e": 32651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left mos"
    },
    {
      "t": 34898,
      "e": 32772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34970,
      "e": 32844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left mo"
    },
    {
      "t": 35081,
      "e": 32955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35161,
      "e": 33035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left m"
    },
    {
      "t": 35306,
      "e": 33180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35385,
      "e": 33259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left "
    },
    {
      "t": 35698,
      "e": 33572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 35698,
      "e": 33572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35805,
      "e": 33679,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left b"
    },
    {
      "t": 35825,
      "e": 33699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35826,
      "e": 33700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35849,
      "e": 33723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bo"
    },
    {
      "t": 35865,
      "e": 33739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35866,
      "e": 33740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35929,
      "e": 33803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35954,
      "e": 33828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36083,
      "e": 33957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36085,
      "e": 33959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36137,
      "e": 34011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36137,
      "e": 34011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36153,
      "e": 34027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 36249,
      "e": 34123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36273,
      "e": 34147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36274,
      "e": 34148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36377,
      "e": 34251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36514,
      "e": 34388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36514,
      "e": 34388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36608,
      "e": 34482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36609,
      "e": 34483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36609,
      "e": 34483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36729,
      "e": 34603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36762,
      "e": 34636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36762,
      "e": 34636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36833,
      "e": 34707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36834,
      "e": 34708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36841,
      "e": 34715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||id"
    },
    {
      "t": 36954,
      "e": 34828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36954,
      "e": 34828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37009,
      "e": 34883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37033,
      "e": 34907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37033,
      "e": 34907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37113,
      "e": 34987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37161,
      "e": 35035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39538,
      "e": 37412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39538,
      "e": 37412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39617,
      "e": 37491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39826,
      "e": 37700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39826,
      "e": 37700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39953,
      "e": 37827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39985,
      "e": 37859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39986,
      "e": 37860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40004,
      "e": 37878,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40090,
      "e": 37964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40091,
      "e": 37965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40105,
      "e": 37979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 40202,
      "e": 38076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40226,
      "e": 38100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40227,
      "e": 38101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40305,
      "e": 38179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40321,
      "e": 38195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40321,
      "e": 38195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40409,
      "e": 38283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40417,
      "e": 38291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40418,
      "e": 38292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40521,
      "e": 38395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40890,
      "e": 38764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40890,
      "e": 38764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41006,
      "e": 38880,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the s"
    },
    {
      "t": 41025,
      "e": 38899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41138,
      "e": 39012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41139,
      "e": 39013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41217,
      "e": 39091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41305,
      "e": 39179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41306,
      "e": 39180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41401,
      "e": 39275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41402,
      "e": 39276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41433,
      "e": 39307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 41530,
      "e": 39404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41545,
      "e": 39419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41547,
      "e": 39421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41641,
      "e": 39515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41826,
      "e": 39700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41826,
      "e": 39700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41945,
      "e": 39819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43178,
      "e": 41052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43179,
      "e": 41053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43289,
      "e": 41163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 43458,
      "e": 41332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43459,
      "e": 41333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43537,
      "e": 41411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44305,
      "e": 42179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44377,
      "e": 42251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start a"
    },
    {
      "t": 44498,
      "e": 42372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44585,
      "e": 42459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start "
    },
    {
      "t": 44786,
      "e": 42660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44787,
      "e": 42661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44897,
      "e": 42771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44961,
      "e": 42835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44962,
      "e": 42836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45065,
      "e": 42939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 45074,
      "e": 42948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45074,
      "e": 42948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45201,
      "e": 43075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45265,
      "e": 43139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45266,
      "e": 43140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45377,
      "e": 43251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46130,
      "e": 44004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46131,
      "e": 44005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46193,
      "e": 44067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47745,
      "e": 45619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47747,
      "e": 45621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47873,
      "e": 45747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47921,
      "e": 45795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47922,
      "e": 45796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48000,
      "e": 45874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48001,
      "e": 45875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48041,
      "e": 45915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 48114,
      "e": 45988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48114,
      "e": 45988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48137,
      "e": 46011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 48226,
      "e": 46100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48345,
      "e": 46219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48347,
      "e": 46221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48409,
      "e": 46283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48818,
      "e": 46692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 48818,
      "e": 46692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48922,
      "e": 46796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 49002,
      "e": 46876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49003,
      "e": 46877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49112,
      "e": 46986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49194,
      "e": 47068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 49194,
      "e": 47068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49313,
      "e": 47187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 49321,
      "e": 47195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49321,
      "e": 47195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49425,
      "e": 47299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49426,
      "e": 47300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49449,
      "e": 47323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 49481,
      "e": 47355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 49481,
      "e": 47355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49521,
      "e": 47395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 49593,
      "e": 47467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49730,
      "e": 47604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49730,
      "e": 47604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49785,
      "e": 47659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49809,
      "e": 47683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49809,
      "e": 47683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49921,
      "e": 47795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50004,
      "e": 47878,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50346,
      "e": 48220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50417,
      "e": 48291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whosr"
    },
    {
      "t": 50545,
      "e": 48419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50617,
      "e": 48491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whos"
    },
    {
      "t": 50640,
      "e": 48514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50641,
      "e": 48515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50745,
      "e": 48619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 51154,
      "e": 49028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51249,
      "e": 49123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whos"
    },
    {
      "t": 51369,
      "e": 49243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51370,
      "e": 49244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51473,
      "e": 49347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51489,
      "e": 49363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51489,
      "e": 49363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51606,
      "e": 49480,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose "
    },
    {
      "t": 51617,
      "e": 49491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51729,
      "e": 49603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 51730,
      "e": 49604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51848,
      "e": 49722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 51921,
      "e": 49795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51921,
      "e": 49795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51986,
      "e": 49860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52073,
      "e": 49947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52075,
      "e": 49949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52144,
      "e": 50018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52282,
      "e": 50156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52282,
      "e": 50156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52393,
      "e": 50267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52450,
      "e": 50324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52451,
      "e": 50325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52569,
      "e": 50443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52810,
      "e": 50684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 52810,
      "e": 50684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52929,
      "e": 50803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 52985,
      "e": 50859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52986,
      "e": 50860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53065,
      "e": 50939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 53154,
      "e": 51028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53156,
      "e": 51030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53225,
      "e": 51099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 53264,
      "e": 51138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53265,
      "e": 51139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53394,
      "e": 51268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54730,
      "e": 52604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54730,
      "e": 52604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54833,
      "e": 52707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54865,
      "e": 52739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54865,
      "e": 52739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54897,
      "e": 52771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55007,
      "e": 52881,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle in"
    },
    {
      "t": 55017,
      "e": 52891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55019,
      "e": 52893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55105,
      "e": 52979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55206,
      "e": 53080,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle in "
    },
    {
      "t": 55209,
      "e": 53083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55210,
      "e": 53084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55313,
      "e": 53187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55577,
      "e": 53451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55642,
      "e": 53452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle in "
    },
    {
      "t": 55761,
      "e": 53571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55833,
      "e": 53643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle in"
    },
    {
      "t": 55945,
      "e": 53755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55993,
      "e": 53803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55993,
      "e": 53803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56009,
      "e": 53819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is"
    },
    {
      "t": 56112,
      "e": 53922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56161,
      "e": 53971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56162,
      "e": 53972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56281,
      "e": 54091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56282,
      "e": 54092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56282,
      "e": 54092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56393,
      "e": 54203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56396,
      "e": 54206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56401,
      "e": 54211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 56472,
      "e": 54282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56513,
      "e": 54323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56513,
      "e": 54323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56601,
      "e": 54411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56601,
      "e": 54411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56657,
      "e": 54467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 56714,
      "e": 54524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56810,
      "e": 54620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56810,
      "e": 54620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56945,
      "e": 54755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 56969,
      "e": 54779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56969,
      "e": 54779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57129,
      "e": 54939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57266,
      "e": 55076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 57266,
      "e": 55076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57393,
      "e": 55203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 57441,
      "e": 55251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 57442,
      "e": 55252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57553,
      "e": 55363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57555,
      "e": 55365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57561,
      "e": 55371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 57697,
      "e": 55507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57697,
      "e": 55507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57705,
      "e": 55515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57807,
      "e": 55617,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the lable "
    },
    {
      "t": 57840,
      "e": 55650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58049,
      "e": 55859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58120,
      "e": 55930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the lable"
    },
    {
      "t": 58241,
      "e": 56051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58304,
      "e": 56114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the labl"
    },
    {
      "t": 58406,
      "e": 56115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the labl"
    },
    {
      "t": 58425,
      "e": 56134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58497,
      "e": 56206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the lab"
    },
    {
      "t": 58607,
      "e": 56316,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the lab"
    },
    {
      "t": 58746,
      "e": 56455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58800,
      "e": 56509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the la"
    },
    {
      "t": 58921,
      "e": 56630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58985,
      "e": 56694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the l"
    },
    {
      "t": 59610,
      "e": 57319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59610,
      "e": 57319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59736,
      "e": 57445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59777,
      "e": 57486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 59777,
      "e": 57486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59865,
      "e": 57574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 59905,
      "e": 57614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59906,
      "e": 57615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59985,
      "e": 57694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59985,
      "e": 57694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59993,
      "e": 57702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||el"
    },
    {
      "t": 60089,
      "e": 57798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60153,
      "e": 57862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60153,
      "e": 57862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60281,
      "e": 57990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60346,
      "e": 58055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60346,
      "e": 58055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60457,
      "e": 58166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60497,
      "e": 58206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 60497,
      "e": 58206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60602,
      "e": 58311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 60625,
      "e": 58334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60626,
      "e": 58335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60721,
      "e": 58430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60745,
      "e": 58454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60745,
      "e": 58454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60817,
      "e": 58526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60841,
      "e": 58550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60841,
      "e": 58550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60905,
      "e": 58614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60969,
      "e": 58678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60969,
      "e": 58678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61065,
      "e": 58774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 61066,
      "e": 58775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61067,
      "e": 58776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61177,
      "e": 58886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61603,
      "e": 59312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 61604,
      "e": 59313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61705,
      "e": 59414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 61705,
      "e": 59414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61745,
      "e": 59454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 61817,
      "e": 59526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61818,
      "e": 59527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61841,
      "e": 59550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 61920,
      "e": 59629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 61921,
      "e": 59630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61929,
      "e": 59638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 62009,
      "e": 59718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62137,
      "e": 59846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62138,
      "e": 59847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62184,
      "e": 59893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70004,
      "e": 64893,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74613,
      "e": 64893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 74614,
      "e": 64894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74708,
      "e": 64988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 74809,
      "e": 65089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift."
    },
    {
      "t": 74812,
      "e": 65092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74813,
      "e": 65093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74916,
      "e": 65196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75060,
      "e": 65340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 75196,
      "e": 65476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 75201,
      "e": 65481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75324,
      "e": 65604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 75332,
      "e": 65612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75732,
      "e": 66012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75734,
      "e": 66014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75804,
      "e": 66084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 76229,
      "e": 66509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76230,
      "e": 66510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76307,
      "e": 66587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 76309,
      "e": 66589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76348,
      "e": 66628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| w"
    },
    {
      "t": 76404,
      "e": 66684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76405,
      "e": 66685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76493,
      "e": 66773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 76533,
      "e": 66813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76533,
      "e": 66813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76548,
      "e": 66828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76636,
      "e": 66916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76764,
      "e": 67044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 76765,
      "e": 67045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76861,
      "e": 67141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 76997,
      "e": 67277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 76998,
      "e": 67278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77084,
      "e": 67364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 77197,
      "e": 67477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77197,
      "e": 67477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77300,
      "e": 67580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 77300,
      "e": 67580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77324,
      "e": 67604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 77412,
      "e": 67692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77493,
      "e": 67773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77493,
      "e": 67773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77580,
      "e": 67860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 77580,
      "e": 67860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77612,
      "e": 67892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 77708,
      "e": 67988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77709,
      "e": 67989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77732,
      "e": 68012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 77812,
      "e": 68092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77828,
      "e": 68108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 77828,
      "e": 68108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77949,
      "e": 68229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77950,
      "e": 68230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77956,
      "e": 68236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 78053,
      "e": 68333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78157,
      "e": 68437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 78157,
      "e": 68437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78159,
      "e": 68439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "192"
    },
    {
      "t": 78159,
      "e": 68439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78252,
      "e": 68532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1`"
    },
    {
      "t": 78252,
      "e": 68532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 78253,
      "e": 68533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78268,
      "e": 68548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 78410,
      "e": 68690,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 1`2"
    },
    {
      "t": 78445,
      "e": 68725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78541,
      "e": 68821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78628,
      "e": 68908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 1`"
    },
    {
      "t": 78748,
      "e": 69028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78828,
      "e": 69028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 1"
    },
    {
      "t": 78884,
      "e": 69084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 78885,
      "e": 69085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78996,
      "e": 69196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 79012,
      "e": 69212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 79013,
      "e": 69213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79196,
      "e": 69396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 79204,
      "e": 69404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 79205,
      "e": 69405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79332,
      "e": 69532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 79493,
      "e": 69693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79493,
      "e": 69693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79604,
      "e": 69804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80469,
      "e": 70669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 80469,
      "e": 70669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80556,
      "e": 70756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 80628,
      "e": 70828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 80629,
      "e": 70829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80707,
      "e": 70907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 80804,
      "e": 71004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80805,
      "e": 71005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80908,
      "e": 71108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80932,
      "e": 71132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80932,
      "e": 71132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81020,
      "e": 71220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81044,
      "e": 71244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 81045,
      "e": 71245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81115,
      "e": 71315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 81172,
      "e": 71372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 81172,
      "e": 71372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81276,
      "e": 71476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 81309,
      "e": 71509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81309,
      "e": 71509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81428,
      "e": 71628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81653,
      "e": 71853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 81653,
      "e": 71853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81724,
      "e": 71924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 81836,
      "e": 72036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81837,
      "e": 72037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81940,
      "e": 72140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81940,
      "e": 72140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81948,
      "e": 72148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 82085,
      "e": 72285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83669,
      "e": 73869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 83669,
      "e": 73869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83806,
      "e": 74006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 83908,
      "e": 74108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 83911,
      "e": 74111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84020,
      "e": 74220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 84020,
      "e": 74220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84028,
      "e": 74228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 84156,
      "e": 74356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84197,
      "e": 74397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84197,
      "e": 74397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84349,
      "e": 74549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84405,
      "e": 74605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84405,
      "e": 74605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84516,
      "e": 74716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 84516,
      "e": 74716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84540,
      "e": 74740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 84604,
      "e": 74804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84653,
      "e": 74853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 84654,
      "e": 74854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84740,
      "e": 74940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84740,
      "e": 74940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84764,
      "e": 74964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 84860,
      "e": 75060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88221,
      "e": 78421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 88222,
      "e": 78422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88340,
      "e": 78540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 88356,
      "e": 78556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 88356,
      "e": 78556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88436,
      "e": 78636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 88573,
      "e": 78773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 88574,
      "e": 78774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88620,
      "e": 78820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 88716,
      "e": 78916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 88716,
      "e": 78916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88788,
      "e": 78988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 88908,
      "e": 79108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 88909,
      "e": 79109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88988,
      "e": 79188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 88988,
      "e": 79188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88996,
      "e": 79196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 89117,
      "e": 79317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89140,
      "e": 79340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89141,
      "e": 79341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89252,
      "e": 79452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89269,
      "e": 79469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89269,
      "e": 79469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89356,
      "e": 79556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89363,
      "e": 79563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89364,
      "e": 79564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89460,
      "e": 79660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 89508,
      "e": 79708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 89509,
      "e": 79709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89572,
      "e": 79772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 89588,
      "e": 79788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89588,
      "e": 79788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89716,
      "e": 79916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89901,
      "e": 80101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 89901,
      "e": 80101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89996,
      "e": 80196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 89996,
      "e": 80196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90006,
      "e": 80206,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90028,
      "e": 80228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 90108,
      "e": 80308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90108,
      "e": 80308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90116,
      "e": 80316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 90236,
      "e": 80436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90293,
      "e": 80493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90293,
      "e": 80493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90408,
      "e": 80608,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the posi"
    },
    {
      "t": 90412,
      "e": 80612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 90420,
      "e": 80620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90420,
      "e": 80620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90541,
      "e": 80741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90605,
      "e": 80805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90605,
      "e": 80805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90691,
      "e": 80891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 90844,
      "e": 81044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 90846,
      "e": 81046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90971,
      "e": 81171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90972,
      "e": 81172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90988,
      "e": 81188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 91084,
      "e": 81284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91116,
      "e": 81316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91117,
      "e": 81317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91244,
      "e": 81444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91316,
      "e": 81516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 91316,
      "e": 81516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91397,
      "e": 81597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 91421,
      "e": 81621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 91421,
      "e": 81621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91428,
      "e": 81628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 91428,
      "e": 81628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91452,
      "e": 81652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gr"
    },
    {
      "t": 91540,
      "e": 81740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91660,
      "e": 81860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 91660,
      "e": 81860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91805,
      "e": 82005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 91805,
      "e": 82005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91819,
      "e": 82019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ad"
    },
    {
      "t": 91931,
      "e": 82131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91940,
      "e": 82140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91940,
      "e": 82140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92020,
      "e": 82220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 92028,
      "e": 82228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 92028,
      "e": 82228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92140,
      "e": 82340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 92140,
      "e": 82340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92196,
      "e": 82396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 92236,
      "e": 82436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 92237,
      "e": 82437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92259,
      "e": 82459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 92347,
      "e": 82547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92364,
      "e": 82564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92364,
      "e": 82564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92484,
      "e": 82684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92716,
      "e": 82916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93216,
      "e": 83416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93248,
      "e": 83448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93281,
      "e": 83481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93314,
      "e": 83514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93347,
      "e": 83547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93380,
      "e": 83580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93404,
      "e": 83604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive ggr"
    },
    {
      "t": 93749,
      "e": 83949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93820,
      "e": 83949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive gg"
    },
    {
      "t": 93964,
      "e": 84093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94043,
      "e": 84172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive g"
    },
    {
      "t": 94508,
      "e": 84637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 94508,
      "e": 84637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94609,
      "e": 84738,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive gr"
    },
    {
      "t": 94652,
      "e": 84781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 94652,
      "e": 84781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94660,
      "e": 84789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 94810,
      "e": 84939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive gra"
    },
    {
      "t": 94812,
      "e": 84941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 94814,
      "e": 84943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94835,
      "e": 84964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 94947,
      "e": 85076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94948,
      "e": 85077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 94949,
      "e": 85078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95044,
      "e": 85173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95044,
      "e": 85173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95060,
      "e": 85189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ie"
    },
    {
      "t": 95164,
      "e": 85293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95220,
      "e": 85349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 95220,
      "e": 85349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95284,
      "e": 85413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 95316,
      "e": 85445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95317,
      "e": 85446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95413,
      "e": 85542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95420,
      "e": 85549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95422,
      "e": 85551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95548,
      "e": 85677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 96172,
      "e": 86301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 96173,
      "e": 86302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96267,
      "e": 86396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 96380,
      "e": 86509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 96381,
      "e": 86510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96459,
      "e": 86588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 96476,
      "e": 86605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96476,
      "e": 86605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96556,
      "e": 86685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 96572,
      "e": 86701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 96572,
      "e": 86701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96675,
      "e": 86804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 96676,
      "e": 86804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 96677,
      "e": 86805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96797,
      "e": 86925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 96876,
      "e": 87004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96877,
      "e": 87005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96963,
      "e": 87091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 97012,
      "e": 87140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 97012,
      "e": 87140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97108,
      "e": 87236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97108,
      "e": 87236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97148,
      "e": 87276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 97220,
      "e": 87348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97260,
      "e": 87388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 97261,
      "e": 87389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97363,
      "e": 87491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 97363,
      "e": 87491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 97365,
      "e": 87493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97468,
      "e": 87596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 97469,
      "e": 87597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97477,
      "e": 87605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ab"
    },
    {
      "t": 97572,
      "e": 87700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97579,
      "e": 87707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97580,
      "e": 87708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97652,
      "e": 87780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 97653,
      "e": 87781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97676,
      "e": 87804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||el"
    },
    {
      "t": 97764,
      "e": 87892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97771,
      "e": 87899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97772,
      "e": 87900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97868,
      "e": 87996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 97957,
      "e": 88085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 97957,
      "e": 88085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98036,
      "e": 88164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 98060,
      "e": 88188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 98060,
      "e": 88188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98164,
      "e": 88292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98164,
      "e": 88292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98172,
      "e": 88300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 98300,
      "e": 88428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98340,
      "e": 88468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 98340,
      "e": 88468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98453,
      "e": 88581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 98453,
      "e": 88581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98515,
      "e": 88643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 98579,
      "e": 88707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 98580,
      "e": 88708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98588,
      "e": 88716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 98740,
      "e": 88868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 98741,
      "e": 88869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98756,
      "e": 88884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 98812,
      "e": 88940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 98812,
      "e": 88940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98900,
      "e": 89028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 98924,
      "e": 89052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98925,
      "e": 89053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 98925,
      "e": 89053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99029,
      "e": 89157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 99029,
      "e": 89157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99068,
      "e": 89196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ed"
    },
    {
      "t": 99140,
      "e": 89268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99975,
      "e": 90103,
      "ty": 7,
      "x": 469,
      "y": 619,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100007,
      "e": 90135,
      "ty": 2,
      "x": 465,
      "y": 626
    },
    {
      "t": 100007,
      "e": 90135,
      "ty": 41,
      "x": 41356,
      "y": 34235,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 100092,
      "e": 90220,
      "ty": 6,
      "x": 465,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100107,
      "e": 90235,
      "ty": 2,
      "x": 465,
      "y": 598
    },
    {
      "t": 100207,
      "e": 90335,
      "ty": 2,
      "x": 478,
      "y": 540
    },
    {
      "t": 100257,
      "e": 90385,
      "ty": 41,
      "x": 43379,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100308,
      "e": 90436,
      "ty": 2,
      "x": 483,
      "y": 531
    },
    {
      "t": 100507,
      "e": 90635,
      "ty": 2,
      "x": 484,
      "y": 531
    },
    {
      "t": 100507,
      "e": 90635,
      "ty": 41,
      "x": 43492,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100607,
      "e": 90735,
      "ty": 2,
      "x": 478,
      "y": 576
    },
    {
      "t": 100692,
      "e": 90820,
      "ty": 7,
      "x": 462,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100708,
      "e": 90836,
      "ty": 2,
      "x": 462,
      "y": 605
    },
    {
      "t": 100757,
      "e": 90885,
      "ty": 41,
      "x": 40906,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 100808,
      "e": 90936,
      "ty": 2,
      "x": 455,
      "y": 619
    },
    {
      "t": 100907,
      "e": 91035,
      "ty": 2,
      "x": 455,
      "y": 623
    },
    {
      "t": 100961,
      "e": 91089,
      "ty": 6,
      "x": 429,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 100993,
      "e": 91121,
      "ty": 7,
      "x": 407,
      "y": 703,
      "ta": "#strategyButton"
    },
    {
      "t": 101007,
      "e": 91135,
      "ty": 2,
      "x": 407,
      "y": 703
    },
    {
      "t": 101007,
      "e": 91135,
      "ty": 41,
      "x": 41383,
      "y": 53257,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 101108,
      "e": 91236,
      "ty": 2,
      "x": 407,
      "y": 705
    },
    {
      "t": 101193,
      "e": 91321,
      "ty": 6,
      "x": 408,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 101208,
      "e": 91336,
      "ty": 2,
      "x": 408,
      "y": 688
    },
    {
      "t": 101257,
      "e": 91385,
      "ty": 41,
      "x": 40088,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 101307,
      "e": 91435,
      "ty": 2,
      "x": 412,
      "y": 677
    },
    {
      "t": 102920,
      "e": 93048,
      "ty": 3,
      "x": 412,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 102922,
      "e": 93050,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive gradient until a label is reached"
    },
    {
      "t": 102922,
      "e": 93050,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102924,
      "e": 93052,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 103032,
      "e": 93160,
      "ty": 4,
      "x": 40088,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 103043,
      "e": 93171,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 103045,
      "e": 93173,
      "ty": 5,
      "x": 412,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 103051,
      "e": 93179,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 104052,
      "e": 94180,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 105607,
      "e": 95735,
      "ty": 2,
      "x": 486,
      "y": 666
    },
    {
      "t": 105708,
      "e": 95836,
      "ty": 2,
      "x": 773,
      "y": 607
    },
    {
      "t": 105747,
      "e": 95875,
      "ty": 6,
      "x": 876,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105758,
      "e": 95886,
      "ty": 41,
      "x": 14707,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105797,
      "e": 95925,
      "ty": 7,
      "x": 905,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105807,
      "e": 95935,
      "ty": 2,
      "x": 905,
      "y": 551
    },
    {
      "t": 105907,
      "e": 96035,
      "ty": 2,
      "x": 975,
      "y": 522
    },
    {
      "t": 106007,
      "e": 96135,
      "ty": 2,
      "x": 976,
      "y": 522
    },
    {
      "t": 106008,
      "e": 96135,
      "ty": 41,
      "x": 36336,
      "y": 32767,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 106108,
      "e": 96235,
      "ty": 2,
      "x": 987,
      "y": 544
    },
    {
      "t": 106147,
      "e": 96274,
      "ty": 6,
      "x": 989,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106208,
      "e": 96335,
      "ty": 2,
      "x": 990,
      "y": 555
    },
    {
      "t": 106257,
      "e": 96384,
      "ty": 41,
      "x": 39364,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106308,
      "e": 96435,
      "ty": 2,
      "x": 990,
      "y": 556
    },
    {
      "t": 106408,
      "e": 96535,
      "ty": 2,
      "x": 992,
      "y": 557
    },
    {
      "t": 106441,
      "e": 96568,
      "ty": 3,
      "x": 994,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106443,
      "e": 96570,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106508,
      "e": 96635,
      "ty": 2,
      "x": 994,
      "y": 559
    },
    {
      "t": 106508,
      "e": 96635,
      "ty": 41,
      "x": 40229,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106568,
      "e": 96695,
      "ty": 4,
      "x": 40229,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106568,
      "e": 96695,
      "ty": 5,
      "x": 994,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 107341,
      "e": 97468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 107341,
      "e": 97468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 107436,
      "e": 97563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 107436,
      "e": 97563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 107491,
      "e": 97618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 107565,
      "e": 97692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 107604,
      "e": 97731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "192"
    },
    {
      "t": 107605,
      "e": 97732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 107733,
      "e": 97860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21`"
    },
    {
      "t": 108428,
      "e": 98555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 108507,
      "e": 98634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 108596,
      "e": 98723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 108596,
      "e": 98723,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 108596,
      "e": 98723,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108597,
      "e": 98724,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108716,
      "e": 98843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 109221,
      "e": 99348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 109444,
      "e": 99571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 109445,
      "e": 99572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109516,
      "e": 99643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 109572,
      "e": 99699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 109572,
      "e": 99699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109668,
      "e": 99795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 109740,
      "e": 99867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 109741,
      "e": 99868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109860,
      "e": 99987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 109997,
      "e": 100124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 110406,
      "e": 100533,
      "ty": 2,
      "x": 993,
      "y": 558
    },
    {
      "t": 110507,
      "e": 100634,
      "ty": 41,
      "x": 40013,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110568,
      "e": 100695,
      "ty": 7,
      "x": 993,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110584,
      "e": 100711,
      "ty": 6,
      "x": 993,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110607,
      "e": 100734,
      "ty": 2,
      "x": 994,
      "y": 662
    },
    {
      "t": 110617,
      "e": 100744,
      "ty": 7,
      "x": 1000,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 110617,
      "e": 100744,
      "ty": 6,
      "x": 1000,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 110707,
      "e": 100834,
      "ty": 2,
      "x": 1003,
      "y": 702
    },
    {
      "t": 110734,
      "e": 100861,
      "ty": 7,
      "x": 1003,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 110757,
      "e": 100884,
      "ty": 41,
      "x": 34299,
      "y": 39110,
      "ta": "html > body"
    },
    {
      "t": 110807,
      "e": 100934,
      "ty": 2,
      "x": 1004,
      "y": 714
    },
    {
      "t": 111006,
      "e": 101133,
      "ty": 2,
      "x": 1007,
      "y": 714
    },
    {
      "t": 111007,
      "e": 101134,
      "ty": 41,
      "x": 34403,
      "y": 39110,
      "ta": "html > body"
    },
    {
      "t": 111069,
      "e": 101196,
      "ty": 6,
      "x": 1008,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111107,
      "e": 101234,
      "ty": 2,
      "x": 1010,
      "y": 701
    },
    {
      "t": 111201,
      "e": 101328,
      "ty": 3,
      "x": 1010,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111203,
      "e": 101330,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 111203,
      "e": 101330,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 111204,
      "e": 101331,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111256,
      "e": 101383,
      "ty": 41,
      "x": 58794,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111320,
      "e": 101447,
      "ty": 4,
      "x": 58794,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111321,
      "e": 101448,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111321,
      "e": 101448,
      "ty": 5,
      "x": 1010,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 111321,
      "e": 101448,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 112207,
      "e": 102334,
      "ty": 2,
      "x": 1010,
      "y": 697
    },
    {
      "t": 112257,
      "e": 102384,
      "ty": 41,
      "x": 34196,
      "y": 37780,
      "ta": "html > body"
    },
    {
      "t": 112307,
      "e": 102434,
      "ty": 2,
      "x": 997,
      "y": 686
    },
    {
      "t": 112339,
      "e": 102466,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 112506,
      "e": 102633,
      "ty": 2,
      "x": 996,
      "y": 685
    },
    {
      "t": 112507,
      "e": 102634,
      "ty": 41,
      "x": 41431,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 113007,
      "e": 103134,
      "ty": 2,
      "x": 986,
      "y": 679
    },
    {
      "t": 113007,
      "e": 103134,
      "ty": 41,
      "x": 44189,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 113107,
      "e": 103234,
      "ty": 2,
      "x": 963,
      "y": 590
    },
    {
      "t": 113206,
      "e": 103333,
      "ty": 2,
      "x": 917,
      "y": 221
    },
    {
      "t": 113257,
      "e": 103384,
      "ty": 41,
      "x": 18411,
      "y": 971,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 113307,
      "e": 103434,
      "ty": 2,
      "x": 895,
      "y": 165
    },
    {
      "t": 113407,
      "e": 103534,
      "ty": 2,
      "x": 867,
      "y": 208
    },
    {
      "t": 113507,
      "e": 103634,
      "ty": 2,
      "x": 851,
      "y": 243
    },
    {
      "t": 113507,
      "e": 103634,
      "ty": 41,
      "x": 24220,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 114209,
      "e": 104336,
      "ty": 3,
      "x": 851,
      "y": 243,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 114306,
      "e": 104433,
      "ty": 2,
      "x": 851,
      "y": 244
    },
    {
      "t": 114312,
      "e": 104439,
      "ty": 4,
      "x": 24220,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 114312,
      "e": 104439,
      "ty": 5,
      "x": 851,
      "y": 244,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 114312,
      "e": 104439,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 114313,
      "e": 104440,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 114507,
      "e": 104634,
      "ty": 2,
      "x": 855,
      "y": 269
    },
    {
      "t": 114508,
      "e": 104635,
      "ty": 41,
      "x": 25573,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 114607,
      "e": 104734,
      "ty": 2,
      "x": 868,
      "y": 314
    },
    {
      "t": 114706,
      "e": 104833,
      "ty": 2,
      "x": 870,
      "y": 331
    },
    {
      "t": 114757,
      "e": 104884,
      "ty": 41,
      "x": 12003,
      "y": 13600,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 114806,
      "e": 104933,
      "ty": 2,
      "x": 872,
      "y": 343
    },
    {
      "t": 114907,
      "e": 105034,
      "ty": 2,
      "x": 862,
      "y": 357
    },
    {
      "t": 115006,
      "e": 105133,
      "ty": 2,
      "x": 848,
      "y": 386
    },
    {
      "t": 115007,
      "e": 105134,
      "ty": 41,
      "x": 6307,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115106,
      "e": 105233,
      "ty": 2,
      "x": 846,
      "y": 392
    },
    {
      "t": 115257,
      "e": 105384,
      "ty": 41,
      "x": 5832,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115307,
      "e": 105434,
      "ty": 2,
      "x": 847,
      "y": 379
    },
    {
      "t": 115407,
      "e": 105534,
      "ty": 2,
      "x": 847,
      "y": 378
    },
    {
      "t": 115507,
      "e": 105634,
      "ty": 2,
      "x": 848,
      "y": 378
    },
    {
      "t": 115507,
      "e": 105634,
      "ty": 41,
      "x": 6307,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 115606,
      "e": 105733,
      "ty": 2,
      "x": 857,
      "y": 380
    },
    {
      "t": 115757,
      "e": 105884,
      "ty": 41,
      "x": 8918,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115807,
      "e": 105934,
      "ty": 2,
      "x": 860,
      "y": 387
    },
    {
      "t": 115907,
      "e": 106034,
      "ty": 2,
      "x": 861,
      "y": 389
    },
    {
      "t": 116007,
      "e": 106134,
      "ty": 2,
      "x": 861,
      "y": 390
    },
    {
      "t": 116007,
      "e": 106134,
      "ty": 41,
      "x": 9392,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 116607,
      "e": 106734,
      "ty": 2,
      "x": 895,
      "y": 394
    },
    {
      "t": 116707,
      "e": 106834,
      "ty": 2,
      "x": 993,
      "y": 403
    },
    {
      "t": 116757,
      "e": 106884,
      "ty": 41,
      "x": 40719,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 116807,
      "e": 106934,
      "ty": 2,
      "x": 992,
      "y": 408
    },
    {
      "t": 116907,
      "e": 107034,
      "ty": 2,
      "x": 936,
      "y": 452
    },
    {
      "t": 117008,
      "e": 107135,
      "ty": 2,
      "x": 923,
      "y": 463
    },
    {
      "t": 117008,
      "e": 107135,
      "ty": 41,
      "x": 24107,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 117107,
      "e": 107234,
      "ty": 2,
      "x": 884,
      "y": 485
    },
    {
      "t": 117208,
      "e": 107335,
      "ty": 2,
      "x": 869,
      "y": 485
    },
    {
      "t": 117258,
      "e": 107385,
      "ty": 41,
      "x": 45005,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 117306,
      "e": 107433,
      "ty": 2,
      "x": 862,
      "y": 469
    },
    {
      "t": 117440,
      "e": 107567,
      "ty": 3,
      "x": 862,
      "y": 468,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 117441,
      "e": 107568,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 117507,
      "e": 107634,
      "ty": 2,
      "x": 862,
      "y": 468
    },
    {
      "t": 117507,
      "e": 107634,
      "ty": 41,
      "x": 42891,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 117537,
      "e": 107664,
      "ty": 4,
      "x": 42891,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 117537,
      "e": 107664,
      "ty": 5,
      "x": 862,
      "y": 468,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 117538,
      "e": 107665,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 117539,
      "e": 107666,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 117706,
      "e": 107833,
      "ty": 2,
      "x": 877,
      "y": 498
    },
    {
      "t": 117757,
      "e": 107884,
      "ty": 41,
      "x": 15563,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 117807,
      "e": 107934,
      "ty": 2,
      "x": 890,
      "y": 535
    },
    {
      "t": 117907,
      "e": 108034,
      "ty": 2,
      "x": 896,
      "y": 571
    },
    {
      "t": 118008,
      "e": 108135,
      "ty": 2,
      "x": 898,
      "y": 596
    },
    {
      "t": 118008,
      "e": 108135,
      "ty": 41,
      "x": 18173,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 118107,
      "e": 108234,
      "ty": 2,
      "x": 901,
      "y": 621
    },
    {
      "t": 118207,
      "e": 108334,
      "ty": 2,
      "x": 901,
      "y": 631
    },
    {
      "t": 118257,
      "e": 108384,
      "ty": 41,
      "x": 18411,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 118307,
      "e": 108434,
      "ty": 2,
      "x": 899,
      "y": 647
    },
    {
      "t": 118407,
      "e": 108534,
      "ty": 2,
      "x": 898,
      "y": 660
    },
    {
      "t": 118507,
      "e": 108634,
      "ty": 2,
      "x": 898,
      "y": 668
    },
    {
      "t": 118507,
      "e": 108634,
      "ty": 41,
      "x": 20561,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 118607,
      "e": 108734,
      "ty": 2,
      "x": 898,
      "y": 673
    },
    {
      "t": 118707,
      "e": 108834,
      "ty": 2,
      "x": 893,
      "y": 677
    },
    {
      "t": 118757,
      "e": 108884,
      "ty": 41,
      "x": 17339,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 118807,
      "e": 108934,
      "ty": 2,
      "x": 884,
      "y": 688
    },
    {
      "t": 118907,
      "e": 109034,
      "ty": 2,
      "x": 888,
      "y": 694
    },
    {
      "t": 119007,
      "e": 109134,
      "ty": 2,
      "x": 894,
      "y": 718
    },
    {
      "t": 119007,
      "e": 109134,
      "ty": 41,
      "x": 17224,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 119107,
      "e": 109234,
      "ty": 2,
      "x": 895,
      "y": 722
    },
    {
      "t": 119208,
      "e": 109335,
      "ty": 2,
      "x": 895,
      "y": 730
    },
    {
      "t": 119259,
      "e": 109337,
      "ty": 41,
      "x": 18467,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 119307,
      "e": 109385,
      "ty": 2,
      "x": 895,
      "y": 733
    },
    {
      "t": 119507,
      "e": 109585,
      "ty": 2,
      "x": 891,
      "y": 729
    },
    {
      "t": 119508,
      "e": 109586,
      "ty": 41,
      "x": 17463,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 119608,
      "e": 109686,
      "ty": 2,
      "x": 891,
      "y": 726
    },
    {
      "t": 119707,
      "e": 109785,
      "ty": 2,
      "x": 892,
      "y": 711
    },
    {
      "t": 119757,
      "e": 109835,
      "ty": 41,
      "x": 17784,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 119807,
      "e": 109885,
      "ty": 2,
      "x": 893,
      "y": 701
    },
    {
      "t": 119907,
      "e": 109985,
      "ty": 2,
      "x": 895,
      "y": 695
    },
    {
      "t": 120007,
      "e": 110085,
      "ty": 2,
      "x": 898,
      "y": 684
    },
    {
      "t": 120008,
      "e": 110086,
      "ty": 41,
      "x": 20561,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 120107,
      "e": 110185,
      "ty": 2,
      "x": 901,
      "y": 677
    },
    {
      "t": 120207,
      "e": 110285,
      "ty": 2,
      "x": 902,
      "y": 676
    },
    {
      "t": 120257,
      "e": 110335,
      "ty": 41,
      "x": 21635,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 120508,
      "e": 110586,
      "ty": 2,
      "x": 906,
      "y": 680
    },
    {
      "t": 120508,
      "e": 110586,
      "ty": 41,
      "x": 22709,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 120607,
      "e": 110685,
      "ty": 2,
      "x": 906,
      "y": 686
    },
    {
      "t": 120707,
      "e": 110785,
      "ty": 2,
      "x": 906,
      "y": 691
    },
    {
      "t": 120757,
      "e": 110835,
      "ty": 41,
      "x": 21060,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 120807,
      "e": 110885,
      "ty": 2,
      "x": 904,
      "y": 702
    },
    {
      "t": 120907,
      "e": 110985,
      "ty": 2,
      "x": 904,
      "y": 723
    },
    {
      "t": 121007,
      "e": 111085,
      "ty": 2,
      "x": 903,
      "y": 729
    },
    {
      "t": 121008,
      "e": 111086,
      "ty": 41,
      "x": 20475,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 121108,
      "e": 111186,
      "ty": 2,
      "x": 901,
      "y": 739
    },
    {
      "t": 121207,
      "e": 111285,
      "ty": 2,
      "x": 901,
      "y": 746
    },
    {
      "t": 121258,
      "e": 111336,
      "ty": 41,
      "x": 33204,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 121307,
      "e": 111385,
      "ty": 2,
      "x": 901,
      "y": 754
    },
    {
      "t": 121407,
      "e": 111485,
      "ty": 2,
      "x": 900,
      "y": 763
    },
    {
      "t": 121507,
      "e": 111585,
      "ty": 2,
      "x": 899,
      "y": 772
    },
    {
      "t": 121507,
      "e": 111585,
      "ty": 41,
      "x": 18411,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 121607,
      "e": 111685,
      "ty": 2,
      "x": 898,
      "y": 782
    },
    {
      "t": 121707,
      "e": 111785,
      "ty": 2,
      "x": 898,
      "y": 789
    },
    {
      "t": 121757,
      "e": 111835,
      "ty": 41,
      "x": 42870,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 121808,
      "e": 111886,
      "ty": 2,
      "x": 898,
      "y": 797
    },
    {
      "t": 121907,
      "e": 111985,
      "ty": 2,
      "x": 897,
      "y": 806
    },
    {
      "t": 122007,
      "e": 112085,
      "ty": 2,
      "x": 897,
      "y": 812
    },
    {
      "t": 122007,
      "e": 112085,
      "ty": 41,
      "x": 44609,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 122107,
      "e": 112185,
      "ty": 2,
      "x": 897,
      "y": 815
    },
    {
      "t": 122208,
      "e": 112286,
      "ty": 2,
      "x": 897,
      "y": 820
    },
    {
      "t": 122258,
      "e": 112336,
      "ty": 41,
      "x": 44609,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 122308,
      "e": 112386,
      "ty": 2,
      "x": 897,
      "y": 825
    },
    {
      "t": 122408,
      "e": 112486,
      "ty": 2,
      "x": 897,
      "y": 828
    },
    {
      "t": 122508,
      "e": 112586,
      "ty": 2,
      "x": 898,
      "y": 832
    },
    {
      "t": 122508,
      "e": 112586,
      "ty": 41,
      "x": 18173,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 122607,
      "e": 112685,
      "ty": 2,
      "x": 898,
      "y": 836
    },
    {
      "t": 122707,
      "e": 112785,
      "ty": 2,
      "x": 898,
      "y": 842
    },
    {
      "t": 122757,
      "e": 112835,
      "ty": 41,
      "x": 53953,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 123257,
      "e": 113335,
      "ty": 41,
      "x": 53953,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 123307,
      "e": 113385,
      "ty": 2,
      "x": 897,
      "y": 835
    },
    {
      "t": 123407,
      "e": 113485,
      "ty": 2,
      "x": 894,
      "y": 823
    },
    {
      "t": 123507,
      "e": 113585,
      "ty": 2,
      "x": 894,
      "y": 811
    },
    {
      "t": 123508,
      "e": 113586,
      "ty": 41,
      "x": 42838,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 123607,
      "e": 113685,
      "ty": 2,
      "x": 898,
      "y": 790
    },
    {
      "t": 123707,
      "e": 113785,
      "ty": 2,
      "x": 899,
      "y": 778
    },
    {
      "t": 123758,
      "e": 113836,
      "ty": 41,
      "x": 18411,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 123807,
      "e": 113885,
      "ty": 2,
      "x": 900,
      "y": 771
    },
    {
      "t": 123908,
      "e": 113986,
      "ty": 2,
      "x": 902,
      "y": 763
    },
    {
      "t": 124007,
      "e": 114085,
      "ty": 2,
      "x": 904,
      "y": 756
    },
    {
      "t": 124007,
      "e": 114085,
      "ty": 41,
      "x": 34456,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 124108,
      "e": 114186,
      "ty": 2,
      "x": 905,
      "y": 756
    },
    {
      "t": 124257,
      "e": 114335,
      "ty": 41,
      "x": 34873,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 124408,
      "e": 114486,
      "ty": 2,
      "x": 905,
      "y": 755
    },
    {
      "t": 124508,
      "e": 114586,
      "ty": 41,
      "x": 34873,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 124707,
      "e": 114785,
      "ty": 2,
      "x": 910,
      "y": 718
    },
    {
      "t": 124758,
      "e": 114836,
      "ty": 41,
      "x": 22320,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 124807,
      "e": 114885,
      "ty": 2,
      "x": 911,
      "y": 699
    },
    {
      "t": 124908,
      "e": 114986,
      "ty": 2,
      "x": 911,
      "y": 697
    },
    {
      "t": 124961,
      "e": 114987,
      "ty": 3,
      "x": 911,
      "y": 697,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 124963,
      "e": 114989,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 125008,
      "e": 115034,
      "ty": 41,
      "x": 22572,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 125071,
      "e": 115097,
      "ty": 4,
      "x": 22572,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 125071,
      "e": 115097,
      "ty": 5,
      "x": 911,
      "y": 697,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 125072,
      "e": 115098,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 125073,
      "e": 115099,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 125207,
      "e": 115233,
      "ty": 2,
      "x": 911,
      "y": 699
    },
    {
      "t": 125257,
      "e": 115283,
      "ty": 41,
      "x": 22572,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 125307,
      "e": 115333,
      "ty": 2,
      "x": 911,
      "y": 734
    },
    {
      "t": 125407,
      "e": 115433,
      "ty": 2,
      "x": 913,
      "y": 754
    },
    {
      "t": 125507,
      "e": 115533,
      "ty": 2,
      "x": 914,
      "y": 759
    },
    {
      "t": 125507,
      "e": 115533,
      "ty": 41,
      "x": 38628,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 125608,
      "e": 115634,
      "ty": 2,
      "x": 914,
      "y": 760
    },
    {
      "t": 125608,
      "e": 115634,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 125707,
      "e": 115733,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 125757,
      "e": 115783,
      "ty": 41,
      "x": 38628,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 125808,
      "e": 115834,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 126007,
      "e": 116033,
      "ty": 2,
      "x": 921,
      "y": 807
    },
    {
      "t": 126008,
      "e": 116034,
      "ty": 41,
      "x": 58774,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 126107,
      "e": 116133,
      "ty": 2,
      "x": 921,
      "y": 872
    },
    {
      "t": 126207,
      "e": 116233,
      "ty": 2,
      "x": 906,
      "y": 905
    },
    {
      "t": 126257,
      "e": 116283,
      "ty": 41,
      "x": 18173,
      "y": 20164,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 126307,
      "e": 116333,
      "ty": 2,
      "x": 874,
      "y": 927
    },
    {
      "t": 126408,
      "e": 116434,
      "ty": 2,
      "x": 862,
      "y": 931
    },
    {
      "t": 126508,
      "e": 116534,
      "ty": 2,
      "x": 860,
      "y": 931
    },
    {
      "t": 126508,
      "e": 116534,
      "ty": 41,
      "x": 42136,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 126708,
      "e": 116734,
      "ty": 2,
      "x": 861,
      "y": 932
    },
    {
      "t": 126712,
      "e": 116738,
      "ty": 3,
      "x": 861,
      "y": 932,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 126714,
      "e": 116740,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126757,
      "e": 116783,
      "ty": 41,
      "x": 43229,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 126784,
      "e": 116810,
      "ty": 4,
      "x": 43229,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 126784,
      "e": 116810,
      "ty": 5,
      "x": 861,
      "y": 932,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 126785,
      "e": 116811,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 126787,
      "e": 116813,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 127007,
      "e": 117033,
      "ty": 2,
      "x": 868,
      "y": 949
    },
    {
      "t": 127007,
      "e": 117033,
      "ty": 41,
      "x": 11054,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 127048,
      "e": 117074,
      "ty": 6,
      "x": 892,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127107,
      "e": 117133,
      "ty": 2,
      "x": 900,
      "y": 1030
    },
    {
      "t": 127165,
      "e": 117191,
      "ty": 7,
      "x": 906,
      "y": 1039,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127207,
      "e": 117233,
      "ty": 2,
      "x": 907,
      "y": 1039
    },
    {
      "t": 127257,
      "e": 117283,
      "ty": 41,
      "x": 30959,
      "y": 57114,
      "ta": "html > body"
    },
    {
      "t": 127383,
      "e": 117409,
      "ty": 6,
      "x": 908,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127408,
      "e": 117434,
      "ty": 2,
      "x": 908,
      "y": 1031
    },
    {
      "t": 127481,
      "e": 117507,
      "ty": 3,
      "x": 910,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127483,
      "e": 117509,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 127483,
      "e": 117509,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127507,
      "e": 117533,
      "ty": 2,
      "x": 910,
      "y": 1028
    },
    {
      "t": 127507,
      "e": 117533,
      "ty": 41,
      "x": 41529,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127592,
      "e": 117618,
      "ty": 4,
      "x": 41529,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127593,
      "e": 117619,
      "ty": 5,
      "x": 910,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127600,
      "e": 117626,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 127602,
      "e": 117628,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 127603,
      "e": 117629,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 127907,
      "e": 117933,
      "ty": 2,
      "x": 925,
      "y": 1005
    },
    {
      "t": 128008,
      "e": 118034,
      "ty": 2,
      "x": 1000,
      "y": 882
    },
    {
      "t": 128008,
      "e": 118034,
      "ty": 41,
      "x": 34162,
      "y": 48417,
      "ta": "html > body"
    },
    {
      "t": 128107,
      "e": 118133,
      "ty": 2,
      "x": 1017,
      "y": 810
    },
    {
      "t": 128208,
      "e": 118234,
      "ty": 2,
      "x": 1021,
      "y": 793
    },
    {
      "t": 128257,
      "e": 118283,
      "ty": 41,
      "x": 34919,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 128308,
      "e": 118334,
      "ty": 2,
      "x": 1022,
      "y": 791
    },
    {
      "t": 128958,
      "e": 118984,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 130007,
      "e": 120033,
      "ty": 2,
      "x": 1018,
      "y": 801
    },
    {
      "t": 130008,
      "e": 120034,
      "ty": 41,
      "x": 35645,
      "y": 2943,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 130008,
      "e": 120034,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130108,
      "e": 120134,
      "ty": 2,
      "x": 982,
      "y": 973
    },
    {
      "t": 130206,
      "e": 120232,
      "ty": 2,
      "x": 973,
      "y": 1045
    },
    {
      "t": 130257,
      "e": 120283,
      "ty": 41,
      "x": 33382,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 130307,
      "e": 120333,
      "ty": 2,
      "x": 972,
      "y": 1055
    },
    {
      "t": 130401,
      "e": 120427,
      "ty": 6,
      "x": 973,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 130407,
      "e": 120433,
      "ty": 2,
      "x": 973,
      "y": 1073
    },
    {
      "t": 130507,
      "e": 120533,
      "ty": 2,
      "x": 978,
      "y": 1086
    },
    {
      "t": 130507,
      "e": 120533,
      "ty": 41,
      "x": 37409,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 130607,
      "e": 120633,
      "ty": 2,
      "x": 978,
      "y": 1087
    },
    {
      "t": 130757,
      "e": 120783,
      "ty": 41,
      "x": 37409,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 131007,
      "e": 121033,
      "ty": 2,
      "x": 978,
      "y": 1086
    },
    {
      "t": 131008,
      "e": 121034,
      "ty": 41,
      "x": 37409,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 131107,
      "e": 121133,
      "ty": 2,
      "x": 978,
      "y": 1085
    },
    {
      "t": 131207,
      "e": 121233,
      "ty": 2,
      "x": 978,
      "y": 1084
    },
    {
      "t": 131257,
      "e": 121283,
      "ty": 41,
      "x": 37409,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 131507,
      "e": 121533,
      "ty": 2,
      "x": 979,
      "y": 1081
    },
    {
      "t": 131507,
      "e": 121533,
      "ty": 41,
      "x": 37955,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 131607,
      "e": 121633,
      "ty": 2,
      "x": 979,
      "y": 1080
    },
    {
      "t": 131756,
      "e": 121782,
      "ty": 41,
      "x": 37955,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 132537,
      "e": 122563,
      "ty": 3,
      "x": 979,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 132538,
      "e": 122564,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 132632,
      "e": 122658,
      "ty": 4,
      "x": 37955,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 132632,
      "e": 122658,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 132632,
      "e": 122658,
      "ty": 5,
      "x": 979,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 132632,
      "e": 122658,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 133670,
      "e": 123696,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 134910,
      "e": 124936,
      "ty": 2,
      "x": 979,
      "y": 1079
    },
    {
      "t": 135011,
      "e": 125037,
      "ty": 41,
      "x": 33354,
      "y": 32879,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 135088,
      "e": 125114,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 10215, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 10221, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 21020, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 32326, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 418924, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 452256, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 18035, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 471672, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 17014, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 489688, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 31275, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 522462, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -12 PM-11 AM-F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:999,y:1082,t:1528143413341};\\\", \\\"{x:1020,y:926,t:1528143413357};\\\", \\\"{x:1046,y:765,t:1528143413373};\\\", \\\"{x:1063,y:640,t:1528143413390};\\\", \\\"{x:1102,y:502,t:1528143413407};\\\", \\\"{x:1142,y:395,t:1528143413423};\\\", \\\"{x:1198,y:332,t:1528143413440};\\\", \\\"{x:1246,y:278,t:1528143413457};\\\", \\\"{x:1298,y:259,t:1528143413473};\\\", \\\"{x:1299,y:259,t:1528143413490};\\\", \\\"{x:1301,y:259,t:1528143414085};\\\", \\\"{x:1302,y:259,t:1528143414092};\\\", \\\"{x:1304,y:259,t:1528143414107};\\\", \\\"{x:1316,y:267,t:1528143414125};\\\", \\\"{x:1318,y:268,t:1528143414142};\\\", \\\"{x:1318,y:269,t:1528143414165};\\\", \\\"{x:1319,y:269,t:1528143414260};\\\", \\\"{x:1321,y:269,t:1528143414275};\\\", \\\"{x:1341,y:289,t:1528143414292};\\\", \\\"{x:1405,y:358,t:1528143414307};\\\", \\\"{x:1547,y:482,t:1528143414324};\\\", \\\"{x:1636,y:547,t:1528143414342};\\\", \\\"{x:1693,y:589,t:1528143414357};\\\", \\\"{x:1725,y:612,t:1528143414374};\\\", \\\"{x:1749,y:630,t:1528143414392};\\\", \\\"{x:1766,y:642,t:1528143414408};\\\", \\\"{x:1771,y:646,t:1528143414424};\\\", \\\"{x:1771,y:647,t:1528143414442};\\\", \\\"{x:1772,y:648,t:1528143414709};\\\", \\\"{x:1770,y:660,t:1528143414724};\\\", \\\"{x:1761,y:676,t:1528143414742};\\\", \\\"{x:1751,y:697,t:1528143414759};\\\", \\\"{x:1742,y:715,t:1528143414775};\\\", \\\"{x:1735,y:726,t:1528143414791};\\\", \\\"{x:1731,y:732,t:1528143414809};\\\", \\\"{x:1731,y:734,t:1528143414825};\\\", \\\"{x:1730,y:737,t:1528143414842};\\\", \\\"{x:1729,y:738,t:1528143414859};\\\", \\\"{x:1728,y:740,t:1528143414875};\\\", \\\"{x:1728,y:742,t:1528143414891};\\\", \\\"{x:1727,y:744,t:1528143414909};\\\", \\\"{x:1727,y:747,t:1528143414925};\\\", \\\"{x:1726,y:750,t:1528143414942};\\\", \\\"{x:1726,y:754,t:1528143414959};\\\", \\\"{x:1724,y:760,t:1528143414975};\\\", \\\"{x:1723,y:765,t:1528143414991};\\\", \\\"{x:1723,y:773,t:1528143415009};\\\", \\\"{x:1720,y:778,t:1528143415026};\\\", \\\"{x:1717,y:787,t:1528143415042};\\\", \\\"{x:1716,y:792,t:1528143415058};\\\", \\\"{x:1715,y:796,t:1528143415075};\\\", \\\"{x:1714,y:800,t:1528143415092};\\\", \\\"{x:1712,y:804,t:1528143415108};\\\", \\\"{x:1711,y:806,t:1528143415126};\\\", \\\"{x:1710,y:808,t:1528143415142};\\\", \\\"{x:1707,y:810,t:1528143415159};\\\", \\\"{x:1698,y:816,t:1528143415175};\\\", \\\"{x:1681,y:820,t:1528143415192};\\\", \\\"{x:1661,y:822,t:1528143415211};\\\", \\\"{x:1642,y:823,t:1528143415226};\\\", \\\"{x:1634,y:823,t:1528143415241};\\\", \\\"{x:1624,y:827,t:1528143415259};\\\", \\\"{x:1622,y:827,t:1528143415276};\\\", \\\"{x:1620,y:828,t:1528143415291};\\\", \\\"{x:1617,y:829,t:1528143415315};\\\", \\\"{x:1612,y:831,t:1528143415331};\\\", \\\"{x:1607,y:832,t:1528143415341};\\\", \\\"{x:1592,y:835,t:1528143415358};\\\", \\\"{x:1572,y:839,t:1528143415375};\\\", \\\"{x:1557,y:841,t:1528143415391};\\\", \\\"{x:1547,y:844,t:1528143415408};\\\", \\\"{x:1543,y:845,t:1528143415425};\\\", \\\"{x:1542,y:845,t:1528143415441};\\\", \\\"{x:1541,y:845,t:1528143415458};\\\", \\\"{x:1541,y:846,t:1528143415509};\\\", \\\"{x:1540,y:847,t:1528143415526};\\\", \\\"{x:1536,y:851,t:1528143415542};\\\", \\\"{x:1533,y:855,t:1528143415559};\\\", \\\"{x:1526,y:862,t:1528143415576};\\\", \\\"{x:1519,y:869,t:1528143415593};\\\", \\\"{x:1512,y:875,t:1528143415609};\\\", \\\"{x:1506,y:880,t:1528143415626};\\\", \\\"{x:1502,y:883,t:1528143415643};\\\", \\\"{x:1498,y:886,t:1528143415659};\\\", \\\"{x:1495,y:887,t:1528143415675};\\\", \\\"{x:1493,y:889,t:1528143415691};\\\", \\\"{x:1492,y:890,t:1528143415715};\\\", \\\"{x:1491,y:890,t:1528143415724};\\\", \\\"{x:1490,y:891,t:1528143415742};\\\", \\\"{x:1490,y:892,t:1528143415763};\\\", \\\"{x:1489,y:892,t:1528143415775};\\\", \\\"{x:1488,y:893,t:1528143415792};\\\", \\\"{x:1485,y:894,t:1528143415808};\\\", \\\"{x:1480,y:896,t:1528143415825};\\\", \\\"{x:1475,y:899,t:1528143415842};\\\", \\\"{x:1469,y:900,t:1528143415858};\\\", \\\"{x:1465,y:901,t:1528143415875};\\\", \\\"{x:1463,y:901,t:1528143415892};\\\", \\\"{x:1462,y:901,t:1528143415908};\\\", \\\"{x:1460,y:901,t:1528143415926};\\\", \\\"{x:1457,y:901,t:1528143415943};\\\", \\\"{x:1456,y:901,t:1528143415959};\\\", \\\"{x:1455,y:901,t:1528143415975};\\\", \\\"{x:1454,y:901,t:1528143415992};\\\", \\\"{x:1453,y:901,t:1528143416009};\\\", \\\"{x:1452,y:902,t:1528143416025};\\\", \\\"{x:1451,y:902,t:1528143416042};\\\", \\\"{x:1450,y:902,t:1528143416060};\\\", \\\"{x:1449,y:902,t:1528143416076};\\\", \\\"{x:1448,y:902,t:1528143416117};\\\", \\\"{x:1448,y:903,t:1528143416221};\\\", \\\"{x:1447,y:903,t:1528143416245};\\\", \\\"{x:1445,y:905,t:1528143416260};\\\", \\\"{x:1444,y:906,t:1528143416275};\\\", \\\"{x:1437,y:912,t:1528143416293};\\\", \\\"{x:1430,y:918,t:1528143416310};\\\", \\\"{x:1423,y:921,t:1528143416326};\\\", \\\"{x:1419,y:924,t:1528143416343};\\\", \\\"{x:1417,y:925,t:1528143416360};\\\", \\\"{x:1417,y:926,t:1528143416437};\\\", \\\"{x:1416,y:926,t:1528143416444};\\\", \\\"{x:1415,y:929,t:1528143416468};\\\", \\\"{x:1414,y:931,t:1528143416492};\\\", \\\"{x:1414,y:932,t:1528143416510};\\\", \\\"{x:1413,y:932,t:1528143416527};\\\", \\\"{x:1413,y:934,t:1528143416543};\\\", \\\"{x:1412,y:936,t:1528143416560};\\\", \\\"{x:1412,y:937,t:1528143416580};\\\", \\\"{x:1411,y:939,t:1528143416593};\\\", \\\"{x:1410,y:939,t:1528143416610};\\\", \\\"{x:1410,y:941,t:1528143416627};\\\", \\\"{x:1409,y:942,t:1528143416643};\\\", \\\"{x:1409,y:943,t:1528143416660};\\\", \\\"{x:1409,y:944,t:1528143416676};\\\", \\\"{x:1409,y:945,t:1528143416692};\\\", \\\"{x:1408,y:946,t:1528143416723};\\\", \\\"{x:1407,y:946,t:1528143416795};\\\", \\\"{x:1407,y:947,t:1528143416811};\\\", \\\"{x:1407,y:948,t:1528143416836};\\\", \\\"{x:1406,y:949,t:1528143416851};\\\", \\\"{x:1405,y:951,t:1528143416875};\\\", \\\"{x:1405,y:952,t:1528143416908};\\\", \\\"{x:1404,y:953,t:1528143416915};\\\", \\\"{x:1404,y:954,t:1528143416940};\\\", \\\"{x:1403,y:954,t:1528143416956};\\\", \\\"{x:1403,y:955,t:1528143417005};\\\", \\\"{x:1402,y:955,t:1528143417012};\\\", \\\"{x:1402,y:956,t:1528143417149};\\\", \\\"{x:1401,y:956,t:1528143417160};\\\", \\\"{x:1401,y:957,t:1528143417177};\\\", \\\"{x:1400,y:958,t:1528143417205};\\\", \\\"{x:1399,y:958,t:1528143417228};\\\", \\\"{x:1398,y:959,t:1528143417244};\\\", \\\"{x:1396,y:960,t:1528143417268};\\\", \\\"{x:1395,y:961,t:1528143417300};\\\", \\\"{x:1394,y:962,t:1528143417310};\\\", \\\"{x:1393,y:962,t:1528143417333};\\\", \\\"{x:1392,y:962,t:1528143417357};\\\", \\\"{x:1391,y:963,t:1528143417373};\\\", \\\"{x:1390,y:963,t:1528143417388};\\\", \\\"{x:1389,y:963,t:1528143417428};\\\", \\\"{x:1388,y:963,t:1528143417445};\\\", \\\"{x:1387,y:963,t:1528143417461};\\\", \\\"{x:1385,y:963,t:1528143417477};\\\", \\\"{x:1384,y:964,t:1528143417494};\\\", \\\"{x:1383,y:964,t:1528143417510};\\\", \\\"{x:1382,y:964,t:1528143417527};\\\", \\\"{x:1381,y:964,t:1528143417685};\\\", \\\"{x:1380,y:964,t:1528143418868};\\\", \\\"{x:1379,y:964,t:1528143418884};\\\", \\\"{x:1379,y:965,t:1528143418895};\\\", \\\"{x:1378,y:966,t:1528143418912};\\\", \\\"{x:1377,y:967,t:1528143418928};\\\", \\\"{x:1376,y:968,t:1528143418945};\\\", \\\"{x:1376,y:969,t:1528143418962};\\\", \\\"{x:1376,y:970,t:1528143418988};\\\", \\\"{x:1375,y:970,t:1528143418997};\\\", \\\"{x:1375,y:971,t:1528143419069};\\\", \\\"{x:1374,y:971,t:1528143419084};\\\", \\\"{x:1374,y:972,t:1528143419133};\\\", \\\"{x:1373,y:973,t:1528143419148};\\\", \\\"{x:1372,y:974,t:1528143419180};\\\", \\\"{x:1372,y:975,t:1528143419196};\\\", \\\"{x:1371,y:976,t:1528143419213};\\\", \\\"{x:1370,y:977,t:1528143419228};\\\", \\\"{x:1369,y:977,t:1528143419301};\\\", \\\"{x:1368,y:977,t:1528143419312};\\\", \\\"{x:1365,y:977,t:1528143419329};\\\", \\\"{x:1363,y:977,t:1528143419344};\\\", \\\"{x:1361,y:976,t:1528143419361};\\\", \\\"{x:1360,y:975,t:1528143419379};\\\", \\\"{x:1359,y:974,t:1528143419395};\\\", \\\"{x:1358,y:974,t:1528143419412};\\\", \\\"{x:1357,y:973,t:1528143419436};\\\", \\\"{x:1355,y:973,t:1528143419460};\\\", \\\"{x:1354,y:973,t:1528143419469};\\\", \\\"{x:1352,y:973,t:1528143419479};\\\", \\\"{x:1348,y:973,t:1528143419494};\\\", \\\"{x:1346,y:973,t:1528143419512};\\\", \\\"{x:1341,y:972,t:1528143419529};\\\", \\\"{x:1338,y:972,t:1528143419544};\\\", \\\"{x:1334,y:972,t:1528143419562};\\\", \\\"{x:1330,y:972,t:1528143419579};\\\", \\\"{x:1327,y:972,t:1528143419596};\\\", \\\"{x:1326,y:971,t:1528143419612};\\\", \\\"{x:1325,y:971,t:1528143419644};\\\", \\\"{x:1324,y:971,t:1528143419733};\\\", \\\"{x:1323,y:971,t:1528143419745};\\\", \\\"{x:1320,y:971,t:1528143419762};\\\", \\\"{x:1315,y:971,t:1528143419780};\\\", \\\"{x:1309,y:971,t:1528143419796};\\\", \\\"{x:1306,y:971,t:1528143419812};\\\", \\\"{x:1304,y:971,t:1528143419829};\\\", \\\"{x:1302,y:970,t:1528143419846};\\\", \\\"{x:1301,y:970,t:1528143420045};\\\", \\\"{x:1298,y:970,t:1528143420062};\\\", \\\"{x:1294,y:970,t:1528143420079};\\\", \\\"{x:1291,y:969,t:1528143420096};\\\", \\\"{x:1289,y:969,t:1528143420112};\\\", \\\"{x:1288,y:969,t:1528143420129};\\\", \\\"{x:1287,y:964,t:1528143420380};\\\", \\\"{x:1287,y:954,t:1528143420397};\\\", \\\"{x:1289,y:946,t:1528143420412};\\\", \\\"{x:1292,y:939,t:1528143420429};\\\", \\\"{x:1294,y:931,t:1528143420446};\\\", \\\"{x:1298,y:924,t:1528143420463};\\\", \\\"{x:1299,y:922,t:1528143420479};\\\", \\\"{x:1300,y:919,t:1528143420496};\\\", \\\"{x:1301,y:918,t:1528143420512};\\\", \\\"{x:1301,y:917,t:1528143420529};\\\", \\\"{x:1301,y:915,t:1528143420546};\\\", \\\"{x:1302,y:913,t:1528143420563};\\\", \\\"{x:1303,y:911,t:1528143420579};\\\", \\\"{x:1305,y:907,t:1528143420596};\\\", \\\"{x:1307,y:903,t:1528143420612};\\\", \\\"{x:1308,y:901,t:1528143420629};\\\", \\\"{x:1310,y:897,t:1528143420646};\\\", \\\"{x:1311,y:895,t:1528143420663};\\\", \\\"{x:1312,y:894,t:1528143420679};\\\", \\\"{x:1312,y:893,t:1528143420696};\\\", \\\"{x:1312,y:892,t:1528143420714};\\\", \\\"{x:1313,y:890,t:1528143420729};\\\", \\\"{x:1314,y:888,t:1528143420746};\\\", \\\"{x:1315,y:887,t:1528143420764};\\\", \\\"{x:1317,y:883,t:1528143420780};\\\", \\\"{x:1318,y:880,t:1528143420796};\\\", \\\"{x:1320,y:876,t:1528143420812};\\\", \\\"{x:1322,y:872,t:1528143420830};\\\", \\\"{x:1322,y:870,t:1528143420845};\\\", \\\"{x:1325,y:867,t:1528143420863};\\\", \\\"{x:1327,y:862,t:1528143420879};\\\", \\\"{x:1328,y:859,t:1528143420895};\\\", \\\"{x:1330,y:857,t:1528143420912};\\\", \\\"{x:1332,y:854,t:1528143420929};\\\", \\\"{x:1332,y:852,t:1528143420945};\\\", \\\"{x:1333,y:851,t:1528143420962};\\\", \\\"{x:1334,y:849,t:1528143420979};\\\", \\\"{x:1336,y:846,t:1528143420996};\\\", \\\"{x:1336,y:845,t:1528143421012};\\\", \\\"{x:1338,y:844,t:1528143421029};\\\", \\\"{x:1341,y:839,t:1528143421045};\\\", \\\"{x:1344,y:834,t:1528143421063};\\\", \\\"{x:1348,y:826,t:1528143421079};\\\", \\\"{x:1352,y:818,t:1528143421095};\\\", \\\"{x:1354,y:811,t:1528143421113};\\\", \\\"{x:1357,y:807,t:1528143421130};\\\", \\\"{x:1358,y:805,t:1528143421146};\\\", \\\"{x:1360,y:801,t:1528143421162};\\\", \\\"{x:1360,y:797,t:1528143421179};\\\", \\\"{x:1362,y:794,t:1528143421195};\\\", \\\"{x:1362,y:791,t:1528143421213};\\\", \\\"{x:1362,y:788,t:1528143421230};\\\", \\\"{x:1364,y:784,t:1528143421246};\\\", \\\"{x:1365,y:781,t:1528143421263};\\\", \\\"{x:1366,y:779,t:1528143421280};\\\", \\\"{x:1367,y:777,t:1528143421297};\\\", \\\"{x:1367,y:774,t:1528143421313};\\\", \\\"{x:1369,y:771,t:1528143421330};\\\", \\\"{x:1369,y:767,t:1528143421347};\\\", \\\"{x:1371,y:763,t:1528143421363};\\\", \\\"{x:1372,y:759,t:1528143421380};\\\", \\\"{x:1373,y:759,t:1528143421708};\\\", \\\"{x:1375,y:759,t:1528143421725};\\\", \\\"{x:1376,y:759,t:1528143421748};\\\", \\\"{x:1377,y:759,t:1528143421767};\\\", \\\"{x:1378,y:760,t:1528143421779};\\\", \\\"{x:1379,y:760,t:1528143421796};\\\", \\\"{x:1379,y:761,t:1528143421813};\\\", \\\"{x:1382,y:764,t:1528143421829};\\\", \\\"{x:1386,y:769,t:1528143421847};\\\", \\\"{x:1388,y:771,t:1528143421863};\\\", \\\"{x:1392,y:776,t:1528143421879};\\\", \\\"{x:1394,y:778,t:1528143421896};\\\", \\\"{x:1396,y:782,t:1528143421914};\\\", \\\"{x:1397,y:782,t:1528143421930};\\\", \\\"{x:1398,y:784,t:1528143421946};\\\", \\\"{x:1401,y:787,t:1528143421964};\\\", \\\"{x:1401,y:788,t:1528143421980};\\\", \\\"{x:1401,y:789,t:1528143421996};\\\", \\\"{x:1401,y:790,t:1528143422014};\\\", \\\"{x:1402,y:792,t:1528143422030};\\\", \\\"{x:1404,y:796,t:1528143422047};\\\", \\\"{x:1405,y:799,t:1528143422064};\\\", \\\"{x:1405,y:803,t:1528143422080};\\\", \\\"{x:1405,y:806,t:1528143422097};\\\", \\\"{x:1407,y:808,t:1528143422113};\\\", \\\"{x:1407,y:809,t:1528143422129};\\\", \\\"{x:1407,y:812,t:1528143422147};\\\", \\\"{x:1408,y:816,t:1528143422164};\\\", \\\"{x:1410,y:821,t:1528143422180};\\\", \\\"{x:1411,y:825,t:1528143422197};\\\", \\\"{x:1411,y:831,t:1528143422214};\\\", \\\"{x:1412,y:838,t:1528143422230};\\\", \\\"{x:1412,y:846,t:1528143422247};\\\", \\\"{x:1415,y:859,t:1528143422264};\\\", \\\"{x:1416,y:872,t:1528143422281};\\\", \\\"{x:1417,y:880,t:1528143422296};\\\", \\\"{x:1417,y:884,t:1528143422314};\\\", \\\"{x:1419,y:890,t:1528143422331};\\\", \\\"{x:1419,y:893,t:1528143422347};\\\", \\\"{x:1419,y:895,t:1528143422363};\\\", \\\"{x:1420,y:896,t:1528143422380};\\\", \\\"{x:1419,y:897,t:1528143422636};\\\", \\\"{x:1406,y:890,t:1528143422647};\\\", \\\"{x:1348,y:868,t:1528143422664};\\\", \\\"{x:1289,y:850,t:1528143422680};\\\", \\\"{x:1231,y:824,t:1528143422697};\\\", \\\"{x:1169,y:804,t:1528143422713};\\\", \\\"{x:1102,y:781,t:1528143422730};\\\", \\\"{x:1064,y:767,t:1528143422747};\\\", \\\"{x:1021,y:748,t:1528143422763};\\\", \\\"{x:994,y:736,t:1528143422780};\\\", \\\"{x:980,y:727,t:1528143422797};\\\", \\\"{x:975,y:723,t:1528143422813};\\\", \\\"{x:971,y:719,t:1528143422830};\\\", \\\"{x:962,y:713,t:1528143422847};\\\", \\\"{x:950,y:707,t:1528143422863};\\\", \\\"{x:930,y:699,t:1528143422880};\\\", \\\"{x:898,y:691,t:1528143422897};\\\", \\\"{x:845,y:684,t:1528143422913};\\\", \\\"{x:781,y:676,t:1528143422930};\\\", \\\"{x:687,y:676,t:1528143422947};\\\", \\\"{x:639,y:670,t:1528143422963};\\\", \\\"{x:594,y:663,t:1528143422980};\\\", \\\"{x:558,y:659,t:1528143422997};\\\", \\\"{x:528,y:654,t:1528143423014};\\\", \\\"{x:512,y:651,t:1528143423030};\\\", \\\"{x:506,y:650,t:1528143423049};\\\", \\\"{x:501,y:650,t:1528143423063};\\\", \\\"{x:497,y:649,t:1528143423080};\\\", \\\"{x:492,y:649,t:1528143423098};\\\", \\\"{x:481,y:647,t:1528143423115};\\\", \\\"{x:474,y:646,t:1528143423131};\\\", \\\"{x:471,y:645,t:1528143423148};\\\", \\\"{x:465,y:643,t:1528143423165};\\\", \\\"{x:453,y:638,t:1528143423182};\\\", \\\"{x:433,y:631,t:1528143423198};\\\", \\\"{x:407,y:625,t:1528143423215};\\\", \\\"{x:379,y:617,t:1528143423233};\\\", \\\"{x:351,y:612,t:1528143423250};\\\", \\\"{x:319,y:607,t:1528143423266};\\\", \\\"{x:282,y:603,t:1528143423282};\\\", \\\"{x:241,y:603,t:1528143423299};\\\", \\\"{x:223,y:603,t:1528143423316};\\\", \\\"{x:220,y:603,t:1528143423332};\\\", \\\"{x:221,y:602,t:1528143423379};\\\", \\\"{x:225,y:601,t:1528143423387};\\\", \\\"{x:229,y:598,t:1528143423399};\\\", \\\"{x:235,y:595,t:1528143423416};\\\", \\\"{x:242,y:591,t:1528143423433};\\\", \\\"{x:246,y:588,t:1528143423449};\\\", \\\"{x:254,y:585,t:1528143423466};\\\", \\\"{x:265,y:581,t:1528143423484};\\\", \\\"{x:271,y:580,t:1528143423500};\\\", \\\"{x:279,y:577,t:1528143423517};\\\", \\\"{x:288,y:575,t:1528143423532};\\\", \\\"{x:295,y:574,t:1528143423551};\\\", \\\"{x:305,y:573,t:1528143423566};\\\", \\\"{x:312,y:572,t:1528143423582};\\\", \\\"{x:314,y:571,t:1528143423599};\\\", \\\"{x:316,y:570,t:1528143423616};\\\", \\\"{x:318,y:570,t:1528143423635};\\\", \\\"{x:323,y:568,t:1528143423649};\\\", \\\"{x:327,y:567,t:1528143423666};\\\", \\\"{x:340,y:565,t:1528143423683};\\\", \\\"{x:350,y:563,t:1528143423699};\\\", \\\"{x:356,y:563,t:1528143423716};\\\", \\\"{x:361,y:563,t:1528143423733};\\\", \\\"{x:364,y:562,t:1528143423750};\\\", \\\"{x:366,y:561,t:1528143423767};\\\", \\\"{x:367,y:560,t:1528143423783};\\\", \\\"{x:369,y:560,t:1528143423799};\\\", \\\"{x:371,y:559,t:1528143423816};\\\", \\\"{x:372,y:559,t:1528143423833};\\\", \\\"{x:373,y:558,t:1528143423849};\\\", \\\"{x:374,y:558,t:1528143423884};\\\", \\\"{x:375,y:558,t:1528143423964};\\\", \\\"{x:376,y:558,t:1528143423987};\\\", \\\"{x:377,y:558,t:1528143424020};\\\", \\\"{x:378,y:558,t:1528143424034};\\\", \\\"{x:379,y:558,t:1528143424068};\\\", \\\"{x:379,y:558,t:1528143424160};\\\", \\\"{x:381,y:560,t:1528143424388};\\\", \\\"{x:381,y:561,t:1528143424401};\\\", \\\"{x:384,y:565,t:1528143424418};\\\", \\\"{x:385,y:569,t:1528143424434};\\\", \\\"{x:389,y:577,t:1528143424453};\\\", \\\"{x:402,y:596,t:1528143424468};\\\", \\\"{x:413,y:610,t:1528143424483};\\\", \\\"{x:422,y:620,t:1528143424501};\\\", \\\"{x:431,y:629,t:1528143424516};\\\", \\\"{x:443,y:639,t:1528143424533};\\\", \\\"{x:453,y:649,t:1528143424550};\\\", \\\"{x:462,y:658,t:1528143424568};\\\", \\\"{x:467,y:663,t:1528143424583};\\\", \\\"{x:469,y:666,t:1528143424600};\\\", \\\"{x:475,y:673,t:1528143424617};\\\", \\\"{x:479,y:678,t:1528143424633};\\\", \\\"{x:482,y:683,t:1528143424650};\\\", \\\"{x:487,y:687,t:1528143424667};\\\", \\\"{x:488,y:689,t:1528143424692};\\\", \\\"{x:489,y:690,t:1528143424708};\\\", \\\"{x:490,y:690,t:1528143424717};\\\", \\\"{x:492,y:692,t:1528143424733};\\\", \\\"{x:494,y:697,t:1528143424751};\\\", \\\"{x:497,y:703,t:1528143424769};\\\", \\\"{x:499,y:706,t:1528143424783};\\\", \\\"{x:501,y:709,t:1528143424800};\\\", \\\"{x:502,y:712,t:1528143424817};\\\", \\\"{x:503,y:715,t:1528143424834};\\\", \\\"{x:505,y:718,t:1528143424850};\\\", \\\"{x:505,y:719,t:1528143426517};\\\", \\\"{x:509,y:722,t:1528143426524};\\\", \\\"{x:517,y:724,t:1528143426536};\\\", \\\"{x:550,y:729,t:1528143426553};\\\", \\\"{x:614,y:737,t:1528143426570};\\\", \\\"{x:714,y:751,t:1528143426585};\\\", \\\"{x:819,y:767,t:1528143426602};\\\", \\\"{x:944,y:786,t:1528143426618};\\\", \\\"{x:1128,y:811,t:1528143426635};\\\", \\\"{x:1241,y:823,t:1528143426651};\\\", \\\"{x:1347,y:841,t:1528143426669};\\\", \\\"{x:1428,y:852,t:1528143426686};\\\", \\\"{x:1467,y:857,t:1528143426703};\\\", \\\"{x:1494,y:862,t:1528143426719};\\\", \\\"{x:1508,y:863,t:1528143426736};\\\", \\\"{x:1512,y:864,t:1528143426753};\\\", \\\"{x:1508,y:862,t:1528143426868};\\\", \\\"{x:1502,y:860,t:1528143426886};\\\", \\\"{x:1496,y:860,t:1528143426903};\\\", \\\"{x:1490,y:858,t:1528143426919};\\\", \\\"{x:1489,y:858,t:1528143426936};\\\", \\\"{x:1486,y:858,t:1528143426953};\\\", \\\"{x:1485,y:858,t:1528143426969};\\\", \\\"{x:1481,y:858,t:1528143426986};\\\", \\\"{x:1476,y:864,t:1528143427003};\\\", \\\"{x:1472,y:871,t:1528143427019};\\\", \\\"{x:1464,y:882,t:1528143427036};\\\", \\\"{x:1457,y:886,t:1528143427053};\\\", \\\"{x:1452,y:890,t:1528143427069};\\\", \\\"{x:1446,y:893,t:1528143427086};\\\", \\\"{x:1440,y:896,t:1528143427103};\\\", \\\"{x:1435,y:898,t:1528143427119};\\\", \\\"{x:1427,y:901,t:1528143427136};\\\", \\\"{x:1421,y:902,t:1528143427154};\\\", \\\"{x:1416,y:904,t:1528143427169};\\\", \\\"{x:1415,y:904,t:1528143427186};\\\", \\\"{x:1413,y:905,t:1528143427203};\\\", \\\"{x:1408,y:907,t:1528143427221};\\\", \\\"{x:1403,y:909,t:1528143427237};\\\", \\\"{x:1399,y:910,t:1528143427254};\\\", \\\"{x:1396,y:912,t:1528143427270};\\\", \\\"{x:1391,y:913,t:1528143427287};\\\", \\\"{x:1386,y:916,t:1528143427303};\\\", \\\"{x:1380,y:917,t:1528143427320};\\\", \\\"{x:1374,y:922,t:1528143427336};\\\", \\\"{x:1366,y:928,t:1528143427353};\\\", \\\"{x:1356,y:935,t:1528143427370};\\\", \\\"{x:1350,y:938,t:1528143427386};\\\", \\\"{x:1346,y:942,t:1528143427403};\\\", \\\"{x:1341,y:946,t:1528143427420};\\\", \\\"{x:1339,y:948,t:1528143427436};\\\", \\\"{x:1336,y:951,t:1528143427453};\\\", \\\"{x:1334,y:954,t:1528143427470};\\\", \\\"{x:1332,y:956,t:1528143427486};\\\", \\\"{x:1330,y:959,t:1528143427503};\\\", \\\"{x:1329,y:960,t:1528143427520};\\\", \\\"{x:1327,y:962,t:1528143427537};\\\", \\\"{x:1322,y:963,t:1528143427553};\\\", \\\"{x:1316,y:965,t:1528143427570};\\\", \\\"{x:1311,y:965,t:1528143427587};\\\", \\\"{x:1309,y:965,t:1528143427602};\\\", \\\"{x:1308,y:966,t:1528143427619};\\\", \\\"{x:1306,y:966,t:1528143427659};\\\", \\\"{x:1305,y:966,t:1528143427708};\\\", \\\"{x:1303,y:966,t:1528143427720};\\\", \\\"{x:1299,y:966,t:1528143427737};\\\", \\\"{x:1289,y:966,t:1528143427752};\\\", \\\"{x:1283,y:966,t:1528143427770};\\\", \\\"{x:1281,y:966,t:1528143427787};\\\", \\\"{x:1280,y:966,t:1528143427803};\\\", \\\"{x:1279,y:966,t:1528143428540};\\\", \\\"{x:1278,y:967,t:1528143428564};\\\", \\\"{x:1277,y:967,t:1528143428588};\\\", \\\"{x:1276,y:967,t:1528143428700};\\\", \\\"{x:1276,y:966,t:1528143430397};\\\", \\\"{x:1276,y:965,t:1528143430412};\\\", \\\"{x:1276,y:964,t:1528143430422};\\\", \\\"{x:1276,y:963,t:1528143430439};\\\", \\\"{x:1278,y:961,t:1528143430455};\\\", \\\"{x:1279,y:960,t:1528143430473};\\\", \\\"{x:1279,y:959,t:1528143430489};\\\", \\\"{x:1280,y:957,t:1528143430506};\\\", \\\"{x:1280,y:956,t:1528143430522};\\\", \\\"{x:1282,y:953,t:1528143430539};\\\", \\\"{x:1282,y:951,t:1528143430555};\\\", \\\"{x:1283,y:949,t:1528143430572};\\\", \\\"{x:1284,y:948,t:1528143430588};\\\", \\\"{x:1286,y:944,t:1528143430605};\\\", \\\"{x:1289,y:938,t:1528143430622};\\\", \\\"{x:1291,y:935,t:1528143430639};\\\", \\\"{x:1293,y:931,t:1528143430655};\\\", \\\"{x:1295,y:928,t:1528143430672};\\\", \\\"{x:1297,y:925,t:1528143430689};\\\", \\\"{x:1300,y:921,t:1528143430706};\\\", \\\"{x:1302,y:919,t:1528143430722};\\\", \\\"{x:1304,y:917,t:1528143430739};\\\", \\\"{x:1307,y:912,t:1528143430755};\\\", \\\"{x:1309,y:909,t:1528143430772};\\\", \\\"{x:1312,y:905,t:1528143430789};\\\", \\\"{x:1314,y:902,t:1528143430806};\\\", \\\"{x:1316,y:900,t:1528143430822};\\\", \\\"{x:1318,y:898,t:1528143430839};\\\", \\\"{x:1318,y:897,t:1528143430855};\\\", \\\"{x:1319,y:893,t:1528143430871};\\\", \\\"{x:1321,y:888,t:1528143430889};\\\", \\\"{x:1323,y:885,t:1528143430906};\\\", \\\"{x:1325,y:881,t:1528143430922};\\\", \\\"{x:1329,y:878,t:1528143430939};\\\", \\\"{x:1333,y:871,t:1528143430956};\\\", \\\"{x:1335,y:869,t:1528143430972};\\\", \\\"{x:1337,y:868,t:1528143430989};\\\", \\\"{x:1338,y:866,t:1528143431006};\\\", \\\"{x:1338,y:865,t:1528143431022};\\\", \\\"{x:1340,y:863,t:1528143431039};\\\", \\\"{x:1341,y:860,t:1528143431056};\\\", \\\"{x:1341,y:858,t:1528143431073};\\\", \\\"{x:1343,y:857,t:1528143431090};\\\", \\\"{x:1344,y:856,t:1528143431107};\\\", \\\"{x:1345,y:854,t:1528143431124};\\\", \\\"{x:1346,y:853,t:1528143431139};\\\", \\\"{x:1347,y:852,t:1528143431156};\\\", \\\"{x:1347,y:851,t:1528143431174};\\\", \\\"{x:1347,y:850,t:1528143431189};\\\", \\\"{x:1347,y:849,t:1528143431207};\\\", \\\"{x:1349,y:848,t:1528143431223};\\\", \\\"{x:1349,y:846,t:1528143431239};\\\", \\\"{x:1350,y:844,t:1528143431257};\\\", \\\"{x:1352,y:840,t:1528143431273};\\\", \\\"{x:1355,y:829,t:1528143431289};\\\", \\\"{x:1364,y:813,t:1528143431307};\\\", \\\"{x:1370,y:800,t:1528143431324};\\\", \\\"{x:1376,y:790,t:1528143431340};\\\", \\\"{x:1382,y:778,t:1528143431356};\\\", \\\"{x:1383,y:775,t:1528143431373};\\\", \\\"{x:1384,y:773,t:1528143431389};\\\", \\\"{x:1386,y:771,t:1528143431407};\\\", \\\"{x:1387,y:769,t:1528143431424};\\\", \\\"{x:1388,y:768,t:1528143431444};\\\", \\\"{x:1388,y:767,t:1528143431476};\\\", \\\"{x:1389,y:767,t:1528143431516};\\\", \\\"{x:1390,y:766,t:1528143431541};\\\", \\\"{x:1392,y:764,t:1528143431556};\\\", \\\"{x:1393,y:764,t:1528143431573};\\\", \\\"{x:1394,y:762,t:1528143431590};\\\", \\\"{x:1396,y:760,t:1528143431606};\\\", \\\"{x:1396,y:759,t:1528143431623};\\\", \\\"{x:1397,y:759,t:1528143431641};\\\", \\\"{x:1397,y:758,t:1528143431780};\\\", \\\"{x:1396,y:758,t:1528143431791};\\\", \\\"{x:1395,y:758,t:1528143431807};\\\", \\\"{x:1393,y:758,t:1528143431828};\\\", \\\"{x:1392,y:758,t:1528143431840};\\\", \\\"{x:1390,y:758,t:1528143431857};\\\", \\\"{x:1389,y:758,t:1528143431874};\\\", \\\"{x:1387,y:758,t:1528143431891};\\\", \\\"{x:1386,y:758,t:1528143431906};\\\", \\\"{x:1383,y:759,t:1528143431923};\\\", \\\"{x:1380,y:762,t:1528143431940};\\\", \\\"{x:1380,y:760,t:1528143432835};\\\", \\\"{x:1381,y:754,t:1528143432843};\\\", \\\"{x:1384,y:748,t:1528143432857};\\\", \\\"{x:1390,y:733,t:1528143432874};\\\", \\\"{x:1397,y:718,t:1528143432891};\\\", \\\"{x:1404,y:699,t:1528143432906};\\\", \\\"{x:1419,y:663,t:1528143432923};\\\", \\\"{x:1434,y:624,t:1528143432941};\\\", \\\"{x:1447,y:589,t:1528143432957};\\\", \\\"{x:1463,y:548,t:1528143432974};\\\", \\\"{x:1483,y:506,t:1528143432991};\\\", \\\"{x:1503,y:459,t:1528143433007};\\\", \\\"{x:1516,y:417,t:1528143433024};\\\", \\\"{x:1526,y:391,t:1528143433042};\\\", \\\"{x:1533,y:371,t:1528143433057};\\\", \\\"{x:1539,y:357,t:1528143433074};\\\", \\\"{x:1548,y:336,t:1528143433091};\\\", \\\"{x:1549,y:335,t:1528143433107};\\\", \\\"{x:1552,y:329,t:1528143433124};\\\", \\\"{x:1553,y:328,t:1528143433141};\\\", \\\"{x:1555,y:326,t:1528143433157};\\\", \\\"{x:1555,y:325,t:1528143433174};\\\", \\\"{x:1558,y:321,t:1528143433191};\\\", \\\"{x:1559,y:319,t:1528143433208};\\\", \\\"{x:1560,y:317,t:1528143433224};\\\", \\\"{x:1561,y:317,t:1528143433242};\\\", \\\"{x:1561,y:318,t:1528143433412};\\\", \\\"{x:1553,y:328,t:1528143433425};\\\", \\\"{x:1522,y:356,t:1528143433442};\\\", \\\"{x:1474,y:393,t:1528143433458};\\\", \\\"{x:1403,y:434,t:1528143433475};\\\", \\\"{x:1322,y:474,t:1528143433491};\\\", \\\"{x:1232,y:514,t:1528143433508};\\\", \\\"{x:1202,y:525,t:1528143433525};\\\", \\\"{x:1168,y:535,t:1528143433542};\\\", \\\"{x:1134,y:544,t:1528143433559};\\\", \\\"{x:1098,y:555,t:1528143433574};\\\", \\\"{x:1074,y:562,t:1528143433592};\\\", \\\"{x:1052,y:567,t:1528143433607};\\\", \\\"{x:1034,y:567,t:1528143433623};\\\", \\\"{x:1010,y:567,t:1528143433640};\\\", \\\"{x:967,y:568,t:1528143433657};\\\", \\\"{x:920,y:568,t:1528143433674};\\\", \\\"{x:856,y:577,t:1528143433691};\\\", \\\"{x:753,y:596,t:1528143433707};\\\", \\\"{x:706,y:602,t:1528143433725};\\\", \\\"{x:661,y:614,t:1528143433741};\\\", \\\"{x:615,y:624,t:1528143433757};\\\", \\\"{x:579,y:632,t:1528143433775};\\\", \\\"{x:550,y:642,t:1528143433790};\\\", \\\"{x:531,y:649,t:1528143433808};\\\", \\\"{x:524,y:652,t:1528143433825};\\\", \\\"{x:523,y:653,t:1528143433841};\\\", \\\"{x:522,y:654,t:1528143433857};\\\", \\\"{x:521,y:655,t:1528143433875};\\\", \\\"{x:520,y:660,t:1528143433891};\\\", \\\"{x:520,y:665,t:1528143433908};\\\", \\\"{x:517,y:674,t:1528143433925};\\\", \\\"{x:515,y:683,t:1528143433942};\\\", \\\"{x:514,y:688,t:1528143433958};\\\", \\\"{x:513,y:692,t:1528143433974};\\\", \\\"{x:513,y:696,t:1528143433992};\\\", \\\"{x:513,y:701,t:1528143434010};\\\", \\\"{x:513,y:706,t:1528143434025};\\\", \\\"{x:513,y:711,t:1528143434042};\\\", \\\"{x:512,y:714,t:1528143434058};\\\", \\\"{x:512,y:716,t:1528143434075};\\\", \\\"{x:511,y:717,t:1528143435052};\\\", \\\"{x:510,y:717,t:1528143435092};\\\", \\\"{x:509,y:717,t:1528143435109};\\\", \\\"{x:508,y:717,t:1528143435126};\\\", \\\"{x:507,y:717,t:1528143435142};\\\", \\\"{x:506,y:717,t:1528143435187};\\\" ] }, { \\\"rt\\\": 23478, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 547197, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -D -04 PM-D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:717,t:1528143438004};\\\", \\\"{x:515,y:718,t:1528143438018};\\\", \\\"{x:524,y:722,t:1528143438028};\\\", \\\"{x:551,y:722,t:1528143438044};\\\", \\\"{x:579,y:722,t:1528143438061};\\\", \\\"{x:603,y:722,t:1528143438078};\\\", \\\"{x:619,y:722,t:1528143438095};\\\", \\\"{x:630,y:722,t:1528143438111};\\\", \\\"{x:643,y:722,t:1528143438127};\\\", \\\"{x:657,y:723,t:1528143438145};\\\", \\\"{x:668,y:723,t:1528143438161};\\\", \\\"{x:676,y:723,t:1528143438178};\\\", \\\"{x:688,y:723,t:1528143438194};\\\", \\\"{x:695,y:723,t:1528143438212};\\\", \\\"{x:702,y:724,t:1528143438228};\\\", \\\"{x:708,y:724,t:1528143438244};\\\", \\\"{x:714,y:724,t:1528143438262};\\\", \\\"{x:720,y:724,t:1528143438278};\\\", \\\"{x:728,y:724,t:1528143438295};\\\", \\\"{x:738,y:724,t:1528143438312};\\\", \\\"{x:745,y:724,t:1528143438329};\\\", \\\"{x:756,y:724,t:1528143438345};\\\", \\\"{x:766,y:724,t:1528143438362};\\\", \\\"{x:774,y:724,t:1528143438379};\\\", \\\"{x:783,y:724,t:1528143438395};\\\", \\\"{x:787,y:724,t:1528143438412};\\\", \\\"{x:794,y:724,t:1528143438429};\\\", \\\"{x:804,y:724,t:1528143438445};\\\", \\\"{x:812,y:724,t:1528143438462};\\\", \\\"{x:819,y:724,t:1528143438480};\\\", \\\"{x:824,y:724,t:1528143438495};\\\", \\\"{x:831,y:724,t:1528143438512};\\\", \\\"{x:839,y:724,t:1528143438529};\\\", \\\"{x:848,y:724,t:1528143438545};\\\", \\\"{x:858,y:727,t:1528143438562};\\\", \\\"{x:877,y:731,t:1528143438579};\\\", \\\"{x:890,y:734,t:1528143438595};\\\", \\\"{x:902,y:738,t:1528143438613};\\\", \\\"{x:912,y:739,t:1528143438630};\\\", \\\"{x:926,y:742,t:1528143438645};\\\", \\\"{x:941,y:743,t:1528143438663};\\\", \\\"{x:956,y:744,t:1528143438680};\\\", \\\"{x:968,y:747,t:1528143438695};\\\", \\\"{x:976,y:748,t:1528143438712};\\\", \\\"{x:985,y:749,t:1528143438730};\\\", \\\"{x:996,y:752,t:1528143438747};\\\", \\\"{x:1008,y:756,t:1528143438763};\\\", \\\"{x:1029,y:764,t:1528143438778};\\\", \\\"{x:1048,y:771,t:1528143438795};\\\", \\\"{x:1061,y:774,t:1528143438812};\\\", \\\"{x:1077,y:779,t:1528143438829};\\\", \\\"{x:1092,y:785,t:1528143438846};\\\", \\\"{x:1111,y:792,t:1528143438862};\\\", \\\"{x:1124,y:797,t:1528143438879};\\\", \\\"{x:1132,y:799,t:1528143438896};\\\", \\\"{x:1141,y:804,t:1528143438911};\\\", \\\"{x:1154,y:807,t:1528143438929};\\\", \\\"{x:1167,y:813,t:1528143438946};\\\", \\\"{x:1179,y:816,t:1528143438962};\\\", \\\"{x:1191,y:820,t:1528143438979};\\\", \\\"{x:1198,y:821,t:1528143438995};\\\", \\\"{x:1205,y:822,t:1528143439012};\\\", \\\"{x:1213,y:822,t:1528143439029};\\\", \\\"{x:1223,y:822,t:1528143439046};\\\", \\\"{x:1233,y:822,t:1528143439062};\\\", \\\"{x:1243,y:822,t:1528143439079};\\\", \\\"{x:1250,y:822,t:1528143439096};\\\", \\\"{x:1260,y:821,t:1528143439113};\\\", \\\"{x:1266,y:819,t:1528143439130};\\\", \\\"{x:1269,y:818,t:1528143439146};\\\", \\\"{x:1274,y:815,t:1528143439164};\\\", \\\"{x:1277,y:813,t:1528143439180};\\\", \\\"{x:1279,y:810,t:1528143439196};\\\", \\\"{x:1282,y:807,t:1528143439214};\\\", \\\"{x:1283,y:805,t:1528143439230};\\\", \\\"{x:1286,y:800,t:1528143439246};\\\", \\\"{x:1290,y:793,t:1528143439264};\\\", \\\"{x:1293,y:787,t:1528143439279};\\\", \\\"{x:1296,y:782,t:1528143439297};\\\", \\\"{x:1299,y:777,t:1528143439313};\\\", \\\"{x:1303,y:771,t:1528143439329};\\\", \\\"{x:1310,y:763,t:1528143439347};\\\", \\\"{x:1322,y:750,t:1528143439364};\\\", \\\"{x:1329,y:742,t:1528143439379};\\\", \\\"{x:1338,y:735,t:1528143439397};\\\", \\\"{x:1344,y:731,t:1528143439414};\\\", \\\"{x:1347,y:729,t:1528143439430};\\\", \\\"{x:1351,y:727,t:1528143439447};\\\", \\\"{x:1354,y:727,t:1528143439463};\\\", \\\"{x:1355,y:726,t:1528143439479};\\\", \\\"{x:1356,y:725,t:1528143439496};\\\", \\\"{x:1357,y:724,t:1528143439513};\\\", \\\"{x:1360,y:723,t:1528143439530};\\\", \\\"{x:1363,y:719,t:1528143439546};\\\", \\\"{x:1367,y:713,t:1528143439563};\\\", \\\"{x:1370,y:709,t:1528143439579};\\\", \\\"{x:1372,y:706,t:1528143439596};\\\", \\\"{x:1374,y:703,t:1528143439613};\\\", \\\"{x:1376,y:699,t:1528143439630};\\\", \\\"{x:1377,y:696,t:1528143439646};\\\", \\\"{x:1378,y:694,t:1528143439663};\\\", \\\"{x:1379,y:692,t:1528143439680};\\\", \\\"{x:1380,y:690,t:1528143439696};\\\", \\\"{x:1380,y:689,t:1528143439714};\\\", \\\"{x:1381,y:687,t:1528143439731};\\\", \\\"{x:1381,y:685,t:1528143439746};\\\", \\\"{x:1381,y:684,t:1528143439763};\\\", \\\"{x:1382,y:683,t:1528143439781};\\\", \\\"{x:1383,y:680,t:1528143439796};\\\", \\\"{x:1383,y:679,t:1528143439813};\\\", \\\"{x:1383,y:677,t:1528143439831};\\\", \\\"{x:1382,y:677,t:1528143440092};\\\", \\\"{x:1381,y:678,t:1528143440100};\\\", \\\"{x:1381,y:679,t:1528143440114};\\\", \\\"{x:1380,y:680,t:1528143440130};\\\", \\\"{x:1379,y:684,t:1528143440148};\\\", \\\"{x:1378,y:686,t:1528143440163};\\\", \\\"{x:1376,y:689,t:1528143440180};\\\", \\\"{x:1375,y:691,t:1528143440198};\\\", \\\"{x:1374,y:692,t:1528143440214};\\\", \\\"{x:1372,y:694,t:1528143440231};\\\", \\\"{x:1371,y:695,t:1528143440247};\\\", \\\"{x:1370,y:696,t:1528143440265};\\\", \\\"{x:1370,y:697,t:1528143440284};\\\", \\\"{x:1370,y:699,t:1528143440298};\\\", \\\"{x:1370,y:700,t:1528143440324};\\\", \\\"{x:1370,y:701,t:1528143440332};\\\", \\\"{x:1369,y:703,t:1528143440348};\\\", \\\"{x:1368,y:703,t:1528143440364};\\\", \\\"{x:1368,y:705,t:1528143440381};\\\", \\\"{x:1368,y:706,t:1528143440404};\\\", \\\"{x:1368,y:708,t:1528143440444};\\\", \\\"{x:1367,y:708,t:1528143440459};\\\", \\\"{x:1367,y:709,t:1528143440476};\\\", \\\"{x:1367,y:711,t:1528143440597};\\\", \\\"{x:1366,y:712,t:1528143440620};\\\", \\\"{x:1365,y:713,t:1528143440632};\\\", \\\"{x:1365,y:714,t:1528143440648};\\\", \\\"{x:1364,y:715,t:1528143440664};\\\", \\\"{x:1364,y:716,t:1528143440684};\\\", \\\"{x:1363,y:718,t:1528143440698};\\\", \\\"{x:1363,y:720,t:1528143440714};\\\", \\\"{x:1361,y:723,t:1528143440731};\\\", \\\"{x:1361,y:725,t:1528143440748};\\\", \\\"{x:1360,y:731,t:1528143440764};\\\", \\\"{x:1358,y:737,t:1528143440781};\\\", \\\"{x:1357,y:742,t:1528143440798};\\\", \\\"{x:1356,y:744,t:1528143440814};\\\", \\\"{x:1355,y:745,t:1528143440836};\\\", \\\"{x:1354,y:747,t:1528143440859};\\\", \\\"{x:1354,y:749,t:1528143440888};\\\", \\\"{x:1354,y:751,t:1528143440898};\\\", \\\"{x:1353,y:753,t:1528143440914};\\\", \\\"{x:1351,y:760,t:1528143440931};\\\", \\\"{x:1350,y:764,t:1528143440946};\\\", \\\"{x:1349,y:764,t:1528143440964};\\\", \\\"{x:1349,y:766,t:1528143440981};\\\", \\\"{x:1349,y:767,t:1528143440998};\\\", \\\"{x:1349,y:768,t:1528143441014};\\\", \\\"{x:1348,y:770,t:1528143441031};\\\", \\\"{x:1348,y:771,t:1528143441048};\\\", \\\"{x:1348,y:774,t:1528143441064};\\\", \\\"{x:1348,y:775,t:1528143441082};\\\", \\\"{x:1347,y:777,t:1528143441099};\\\", \\\"{x:1347,y:779,t:1528143441115};\\\", \\\"{x:1347,y:782,t:1528143441131};\\\", \\\"{x:1347,y:783,t:1528143441155};\\\", \\\"{x:1346,y:785,t:1528143441180};\\\", \\\"{x:1346,y:786,t:1528143441196};\\\", \\\"{x:1345,y:789,t:1528143441204};\\\", \\\"{x:1344,y:790,t:1528143441215};\\\", \\\"{x:1344,y:793,t:1528143441231};\\\", \\\"{x:1343,y:797,t:1528143441248};\\\", \\\"{x:1341,y:801,t:1528143441265};\\\", \\\"{x:1340,y:804,t:1528143441282};\\\", \\\"{x:1340,y:805,t:1528143441299};\\\", \\\"{x:1340,y:807,t:1528143441315};\\\", \\\"{x:1339,y:809,t:1528143441332};\\\", \\\"{x:1338,y:811,t:1528143441349};\\\", \\\"{x:1338,y:812,t:1528143441365};\\\", \\\"{x:1337,y:814,t:1528143441381};\\\", \\\"{x:1337,y:815,t:1528143441404};\\\", \\\"{x:1337,y:816,t:1528143441436};\\\", \\\"{x:1336,y:817,t:1528143441452};\\\", \\\"{x:1346,y:803,t:1528143442460};\\\", \\\"{x:1366,y:779,t:1528143442467};\\\", \\\"{x:1386,y:754,t:1528143442484};\\\", \\\"{x:1471,y:656,t:1528143442500};\\\", \\\"{x:1527,y:590,t:1528143442516};\\\", \\\"{x:1575,y:535,t:1528143442533};\\\", \\\"{x:1603,y:500,t:1528143442550};\\\", \\\"{x:1624,y:466,t:1528143442567};\\\", \\\"{x:1638,y:443,t:1528143442582};\\\", \\\"{x:1650,y:418,t:1528143442600};\\\", \\\"{x:1658,y:406,t:1528143442617};\\\", \\\"{x:1659,y:403,t:1528143442633};\\\", \\\"{x:1659,y:401,t:1528143442650};\\\", \\\"{x:1660,y:401,t:1528143442666};\\\", \\\"{x:1660,y:399,t:1528143442683};\\\", \\\"{x:1661,y:398,t:1528143442700};\\\", \\\"{x:1657,y:402,t:1528143442820};\\\", \\\"{x:1652,y:408,t:1528143442833};\\\", \\\"{x:1648,y:414,t:1528143442850};\\\", \\\"{x:1645,y:417,t:1528143442867};\\\", \\\"{x:1640,y:423,t:1528143442883};\\\", \\\"{x:1637,y:424,t:1528143442900};\\\", \\\"{x:1635,y:427,t:1528143442917};\\\", \\\"{x:1634,y:427,t:1528143442940};\\\", \\\"{x:1634,y:428,t:1528143442972};\\\", \\\"{x:1633,y:428,t:1528143442983};\\\", \\\"{x:1631,y:429,t:1528143443028};\\\", \\\"{x:1631,y:430,t:1528143443052};\\\", \\\"{x:1630,y:432,t:1528143443068};\\\", \\\"{x:1629,y:433,t:1528143443083};\\\", \\\"{x:1628,y:436,t:1528143443100};\\\", \\\"{x:1628,y:438,t:1528143443117};\\\", \\\"{x:1627,y:440,t:1528143443134};\\\", \\\"{x:1626,y:441,t:1528143443150};\\\", \\\"{x:1626,y:443,t:1528143443167};\\\", \\\"{x:1626,y:444,t:1528143443188};\\\", \\\"{x:1626,y:446,t:1528143443199};\\\", \\\"{x:1624,y:448,t:1528143443220};\\\", \\\"{x:1624,y:449,t:1528143443234};\\\", \\\"{x:1624,y:452,t:1528143443251};\\\", \\\"{x:1624,y:454,t:1528143443267};\\\", \\\"{x:1623,y:458,t:1528143443283};\\\", \\\"{x:1623,y:459,t:1528143443300};\\\", \\\"{x:1623,y:461,t:1528143443317};\\\", \\\"{x:1622,y:464,t:1528143443334};\\\", \\\"{x:1622,y:467,t:1528143443350};\\\", \\\"{x:1621,y:470,t:1528143443367};\\\", \\\"{x:1620,y:472,t:1528143443384};\\\", \\\"{x:1620,y:474,t:1528143443401};\\\", \\\"{x:1619,y:476,t:1528143443420};\\\", \\\"{x:1619,y:478,t:1528143443444};\\\", \\\"{x:1618,y:479,t:1528143443460};\\\", \\\"{x:1618,y:480,t:1528143443476};\\\", \\\"{x:1617,y:481,t:1528143443492};\\\", \\\"{x:1616,y:481,t:1528143443515};\\\", \\\"{x:1616,y:482,t:1528143443523};\\\", \\\"{x:1614,y:484,t:1528143443539};\\\", \\\"{x:1614,y:485,t:1528143443555};\\\", \\\"{x:1613,y:486,t:1528143443571};\\\", \\\"{x:1613,y:488,t:1528143443583};\\\", \\\"{x:1610,y:490,t:1528143443601};\\\", \\\"{x:1610,y:492,t:1528143443616};\\\", \\\"{x:1609,y:494,t:1528143443633};\\\", \\\"{x:1608,y:496,t:1528143443651};\\\", \\\"{x:1607,y:497,t:1528143443667};\\\", \\\"{x:1606,y:498,t:1528143443691};\\\", \\\"{x:1606,y:499,t:1528143443707};\\\", \\\"{x:1606,y:500,t:1528143443732};\\\", \\\"{x:1604,y:503,t:1528143443739};\\\", \\\"{x:1604,y:504,t:1528143443756};\\\", \\\"{x:1604,y:505,t:1528143443767};\\\", \\\"{x:1602,y:509,t:1528143443784};\\\", \\\"{x:1599,y:513,t:1528143443801};\\\", \\\"{x:1596,y:518,t:1528143443816};\\\", \\\"{x:1595,y:521,t:1528143443833};\\\", \\\"{x:1593,y:524,t:1528143443851};\\\", \\\"{x:1592,y:526,t:1528143443867};\\\", \\\"{x:1591,y:528,t:1528143443884};\\\", \\\"{x:1590,y:530,t:1528143443901};\\\", \\\"{x:1589,y:531,t:1528143443918};\\\", \\\"{x:1589,y:533,t:1528143443934};\\\", \\\"{x:1588,y:535,t:1528143443950};\\\", \\\"{x:1588,y:536,t:1528143443967};\\\", \\\"{x:1587,y:538,t:1528143443984};\\\", \\\"{x:1586,y:540,t:1528143444012};\\\", \\\"{x:1585,y:540,t:1528143444044};\\\", \\\"{x:1585,y:541,t:1528143444148};\\\", \\\"{x:1585,y:542,t:1528143444196};\\\", \\\"{x:1585,y:543,t:1528143444220};\\\", \\\"{x:1585,y:544,t:1528143444236};\\\", \\\"{x:1585,y:545,t:1528143444252};\\\", \\\"{x:1585,y:547,t:1528143444292};\\\", \\\"{x:1585,y:546,t:1528143444828};\\\", \\\"{x:1585,y:543,t:1528143444836};\\\", \\\"{x:1585,y:539,t:1528143444852};\\\", \\\"{x:1586,y:537,t:1528143444868};\\\", \\\"{x:1586,y:536,t:1528143444885};\\\", \\\"{x:1586,y:535,t:1528143444902};\\\", \\\"{x:1586,y:533,t:1528143444919};\\\", \\\"{x:1587,y:532,t:1528143444940};\\\", \\\"{x:1587,y:531,t:1528143444988};\\\", \\\"{x:1587,y:530,t:1528143445003};\\\", \\\"{x:1589,y:528,t:1528143445019};\\\", \\\"{x:1589,y:527,t:1528143445036};\\\", \\\"{x:1590,y:526,t:1528143445068};\\\", \\\"{x:1590,y:524,t:1528143445092};\\\", \\\"{x:1591,y:523,t:1528143445116};\\\", \\\"{x:1591,y:522,t:1528143445139};\\\", \\\"{x:1592,y:521,t:1528143445155};\\\", \\\"{x:1592,y:520,t:1528143445260};\\\", \\\"{x:1592,y:518,t:1528143445364};\\\", \\\"{x:1592,y:517,t:1528143445405};\\\", \\\"{x:1593,y:517,t:1528143445419};\\\", \\\"{x:1593,y:515,t:1528143445436};\\\", \\\"{x:1594,y:515,t:1528143445452};\\\", \\\"{x:1594,y:514,t:1528143445468};\\\", \\\"{x:1594,y:513,t:1528143445486};\\\", \\\"{x:1595,y:512,t:1528143445563};\\\", \\\"{x:1595,y:511,t:1528143445595};\\\", \\\"{x:1595,y:509,t:1528143445619};\\\", \\\"{x:1595,y:508,t:1528143445635};\\\", \\\"{x:1596,y:502,t:1528143445653};\\\", \\\"{x:1597,y:497,t:1528143445668};\\\", \\\"{x:1599,y:492,t:1528143445686};\\\", \\\"{x:1601,y:483,t:1528143445703};\\\", \\\"{x:1606,y:469,t:1528143445718};\\\", \\\"{x:1610,y:456,t:1528143445735};\\\", \\\"{x:1614,y:444,t:1528143445752};\\\", \\\"{x:1614,y:436,t:1528143445769};\\\", \\\"{x:1615,y:432,t:1528143445787};\\\", \\\"{x:1615,y:430,t:1528143445802};\\\", \\\"{x:1615,y:429,t:1528143445843};\\\", \\\"{x:1615,y:432,t:1528143448820};\\\", \\\"{x:1615,y:433,t:1528143448828};\\\", \\\"{x:1615,y:436,t:1528143448841};\\\", \\\"{x:1615,y:438,t:1528143448855};\\\", \\\"{x:1615,y:440,t:1528143448871};\\\", \\\"{x:1614,y:443,t:1528143448889};\\\", \\\"{x:1614,y:446,t:1528143448905};\\\", \\\"{x:1614,y:450,t:1528143448922};\\\", \\\"{x:1614,y:454,t:1528143448939};\\\", \\\"{x:1615,y:459,t:1528143448955};\\\", \\\"{x:1615,y:465,t:1528143448971};\\\", \\\"{x:1616,y:471,t:1528143448989};\\\", \\\"{x:1618,y:473,t:1528143449005};\\\", \\\"{x:1619,y:478,t:1528143449022};\\\", \\\"{x:1619,y:482,t:1528143449039};\\\", \\\"{x:1619,y:486,t:1528143449055};\\\", \\\"{x:1619,y:493,t:1528143449072};\\\", \\\"{x:1619,y:503,t:1528143449088};\\\", \\\"{x:1619,y:513,t:1528143449105};\\\", \\\"{x:1619,y:523,t:1528143449122};\\\", \\\"{x:1620,y:531,t:1528143449139};\\\", \\\"{x:1623,y:545,t:1528143449155};\\\", \\\"{x:1623,y:553,t:1528143449171};\\\", \\\"{x:1624,y:562,t:1528143449188};\\\", \\\"{x:1625,y:577,t:1528143449205};\\\", \\\"{x:1625,y:595,t:1528143449222};\\\", \\\"{x:1625,y:613,t:1528143449239};\\\", \\\"{x:1625,y:632,t:1528143449256};\\\", \\\"{x:1625,y:643,t:1528143449272};\\\", \\\"{x:1625,y:653,t:1528143449289};\\\", \\\"{x:1625,y:666,t:1528143449305};\\\", \\\"{x:1625,y:682,t:1528143449321};\\\", \\\"{x:1625,y:697,t:1528143449339};\\\", \\\"{x:1627,y:714,t:1528143449355};\\\", \\\"{x:1629,y:724,t:1528143449372};\\\", \\\"{x:1630,y:734,t:1528143449389};\\\", \\\"{x:1632,y:741,t:1528143449406};\\\", \\\"{x:1632,y:745,t:1528143449422};\\\", \\\"{x:1632,y:748,t:1528143449439};\\\", \\\"{x:1632,y:753,t:1528143449456};\\\", \\\"{x:1632,y:759,t:1528143449472};\\\", \\\"{x:1632,y:764,t:1528143449489};\\\", \\\"{x:1633,y:770,t:1528143449506};\\\", \\\"{x:1636,y:778,t:1528143449523};\\\", \\\"{x:1637,y:790,t:1528143449538};\\\", \\\"{x:1641,y:810,t:1528143449555};\\\", \\\"{x:1641,y:823,t:1528143449573};\\\", \\\"{x:1641,y:835,t:1528143449588};\\\", \\\"{x:1641,y:849,t:1528143449605};\\\", \\\"{x:1641,y:862,t:1528143449622};\\\", \\\"{x:1640,y:874,t:1528143449638};\\\", \\\"{x:1639,y:887,t:1528143449656};\\\", \\\"{x:1637,y:897,t:1528143449672};\\\", \\\"{x:1635,y:906,t:1528143449689};\\\", \\\"{x:1634,y:913,t:1528143449706};\\\", \\\"{x:1633,y:919,t:1528143449723};\\\", \\\"{x:1633,y:926,t:1528143449739};\\\", \\\"{x:1631,y:938,t:1528143449756};\\\", \\\"{x:1630,y:942,t:1528143449772};\\\", \\\"{x:1630,y:946,t:1528143449789};\\\", \\\"{x:1630,y:951,t:1528143449805};\\\", \\\"{x:1630,y:956,t:1528143449822};\\\", \\\"{x:1630,y:960,t:1528143449838};\\\", \\\"{x:1628,y:963,t:1528143449856};\\\", \\\"{x:1627,y:968,t:1528143449873};\\\", \\\"{x:1627,y:970,t:1528143449890};\\\", \\\"{x:1627,y:971,t:1528143449907};\\\", \\\"{x:1626,y:972,t:1528143449923};\\\", \\\"{x:1625,y:973,t:1528143449940};\\\", \\\"{x:1625,y:974,t:1528143449956};\\\", \\\"{x:1624,y:974,t:1528143449973};\\\", \\\"{x:1624,y:970,t:1528143450292};\\\", \\\"{x:1624,y:965,t:1528143450307};\\\", \\\"{x:1624,y:953,t:1528143450323};\\\", \\\"{x:1618,y:894,t:1528143450340};\\\", \\\"{x:1607,y:811,t:1528143450357};\\\", \\\"{x:1591,y:703,t:1528143450373};\\\", \\\"{x:1570,y:583,t:1528143450390};\\\", \\\"{x:1553,y:439,t:1528143450407};\\\", \\\"{x:1545,y:330,t:1528143450423};\\\", \\\"{x:1545,y:282,t:1528143450440};\\\", \\\"{x:1546,y:266,t:1528143450457};\\\", \\\"{x:1546,y:261,t:1528143450473};\\\", \\\"{x:1546,y:257,t:1528143450491};\\\", \\\"{x:1546,y:256,t:1528143450507};\\\", \\\"{x:1547,y:254,t:1528143450524};\\\", \\\"{x:1547,y:249,t:1528143450540};\\\", \\\"{x:1549,y:244,t:1528143450557};\\\", \\\"{x:1550,y:243,t:1528143450573};\\\", \\\"{x:1551,y:242,t:1528143450590};\\\", \\\"{x:1554,y:242,t:1528143450607};\\\", \\\"{x:1565,y:246,t:1528143450623};\\\", \\\"{x:1583,y:262,t:1528143450640};\\\", \\\"{x:1610,y:288,t:1528143450657};\\\", \\\"{x:1631,y:311,t:1528143450674};\\\", \\\"{x:1646,y:331,t:1528143450690};\\\", \\\"{x:1657,y:349,t:1528143450707};\\\", \\\"{x:1663,y:370,t:1528143450723};\\\", \\\"{x:1663,y:379,t:1528143450739};\\\", \\\"{x:1663,y:382,t:1528143450757};\\\", \\\"{x:1662,y:383,t:1528143450876};\\\", \\\"{x:1657,y:384,t:1528143450890};\\\", \\\"{x:1647,y:388,t:1528143450907};\\\", \\\"{x:1627,y:395,t:1528143450923};\\\", \\\"{x:1617,y:401,t:1528143450939};\\\", \\\"{x:1613,y:402,t:1528143450956};\\\", \\\"{x:1610,y:404,t:1528143450973};\\\", \\\"{x:1610,y:405,t:1528143451003};\\\", \\\"{x:1610,y:407,t:1528143451011};\\\", \\\"{x:1610,y:409,t:1528143451027};\\\", \\\"{x:1610,y:412,t:1528143451039};\\\", \\\"{x:1610,y:415,t:1528143451056};\\\", \\\"{x:1611,y:419,t:1528143451074};\\\", \\\"{x:1611,y:421,t:1528143451089};\\\", \\\"{x:1611,y:423,t:1528143451107};\\\", \\\"{x:1611,y:425,t:1528143451124};\\\", \\\"{x:1611,y:426,t:1528143451388};\\\", \\\"{x:1611,y:428,t:1528143451412};\\\", \\\"{x:1611,y:430,t:1528143451428};\\\", \\\"{x:1611,y:431,t:1528143451441};\\\", \\\"{x:1608,y:434,t:1528143451459};\\\", \\\"{x:1607,y:437,t:1528143451474};\\\", \\\"{x:1604,y:440,t:1528143451491};\\\", \\\"{x:1603,y:444,t:1528143451508};\\\", \\\"{x:1603,y:445,t:1528143451524};\\\", \\\"{x:1601,y:449,t:1528143451542};\\\", \\\"{x:1600,y:452,t:1528143451558};\\\", \\\"{x:1600,y:455,t:1528143451574};\\\", \\\"{x:1599,y:458,t:1528143451591};\\\", \\\"{x:1597,y:460,t:1528143451608};\\\", \\\"{x:1596,y:462,t:1528143451624};\\\", \\\"{x:1595,y:464,t:1528143451643};\\\", \\\"{x:1594,y:464,t:1528143451658};\\\", \\\"{x:1593,y:466,t:1528143451674};\\\", \\\"{x:1591,y:468,t:1528143451691};\\\", \\\"{x:1589,y:472,t:1528143451707};\\\", \\\"{x:1587,y:477,t:1528143451724};\\\", \\\"{x:1584,y:483,t:1528143451741};\\\", \\\"{x:1581,y:488,t:1528143451758};\\\", \\\"{x:1578,y:495,t:1528143451774};\\\", \\\"{x:1573,y:502,t:1528143451791};\\\", \\\"{x:1571,y:507,t:1528143451808};\\\", \\\"{x:1570,y:511,t:1528143451825};\\\", \\\"{x:1569,y:514,t:1528143451841};\\\", \\\"{x:1567,y:521,t:1528143451858};\\\", \\\"{x:1566,y:528,t:1528143451875};\\\", \\\"{x:1563,y:536,t:1528143451891};\\\", \\\"{x:1561,y:546,t:1528143451908};\\\", \\\"{x:1557,y:552,t:1528143451925};\\\", \\\"{x:1557,y:557,t:1528143451941};\\\", \\\"{x:1553,y:564,t:1528143451958};\\\", \\\"{x:1551,y:568,t:1528143451975};\\\", \\\"{x:1549,y:573,t:1528143451991};\\\", \\\"{x:1546,y:580,t:1528143452008};\\\", \\\"{x:1543,y:586,t:1528143452025};\\\", \\\"{x:1540,y:595,t:1528143452042};\\\", \\\"{x:1537,y:602,t:1528143452058};\\\", \\\"{x:1535,y:606,t:1528143452075};\\\", \\\"{x:1533,y:610,t:1528143452092};\\\", \\\"{x:1533,y:611,t:1528143452116};\\\", \\\"{x:1532,y:614,t:1528143452125};\\\", \\\"{x:1530,y:616,t:1528143452142};\\\", \\\"{x:1529,y:620,t:1528143452158};\\\", \\\"{x:1528,y:622,t:1528143452176};\\\", \\\"{x:1525,y:628,t:1528143452192};\\\", \\\"{x:1523,y:635,t:1528143452208};\\\", \\\"{x:1518,y:643,t:1528143452226};\\\", \\\"{x:1513,y:655,t:1528143452242};\\\", \\\"{x:1505,y:671,t:1528143452259};\\\", \\\"{x:1494,y:688,t:1528143452275};\\\", \\\"{x:1481,y:707,t:1528143452291};\\\", \\\"{x:1475,y:719,t:1528143452309};\\\", \\\"{x:1472,y:726,t:1528143452328};\\\", \\\"{x:1468,y:727,t:1528143452346};\\\", \\\"{x:1467,y:728,t:1528143452362};\\\", \\\"{x:1466,y:728,t:1528143452503};\\\", \\\"{x:1465,y:728,t:1528143452519};\\\", \\\"{x:1465,y:727,t:1528143452528};\\\", \\\"{x:1467,y:721,t:1528143452545};\\\", \\\"{x:1473,y:717,t:1528143452563};\\\", \\\"{x:1474,y:714,t:1528143452578};\\\", \\\"{x:1474,y:717,t:1528143453239};\\\", \\\"{x:1471,y:722,t:1528143453247};\\\", \\\"{x:1467,y:728,t:1528143453262};\\\", \\\"{x:1458,y:742,t:1528143453279};\\\", \\\"{x:1454,y:749,t:1528143453296};\\\", \\\"{x:1451,y:756,t:1528143453312};\\\", \\\"{x:1447,y:762,t:1528143453329};\\\", \\\"{x:1442,y:769,t:1528143453347};\\\", \\\"{x:1440,y:773,t:1528143453362};\\\", \\\"{x:1436,y:781,t:1528143453380};\\\", \\\"{x:1434,y:785,t:1528143453397};\\\", \\\"{x:1429,y:791,t:1528143453413};\\\", \\\"{x:1427,y:794,t:1528143453429};\\\", \\\"{x:1422,y:800,t:1528143453446};\\\", \\\"{x:1420,y:806,t:1528143453462};\\\", \\\"{x:1413,y:816,t:1528143453479};\\\", \\\"{x:1409,y:823,t:1528143453496};\\\", \\\"{x:1406,y:830,t:1528143453512};\\\", \\\"{x:1401,y:838,t:1528143453528};\\\", \\\"{x:1395,y:845,t:1528143453545};\\\", \\\"{x:1390,y:854,t:1528143453562};\\\", \\\"{x:1387,y:861,t:1528143453579};\\\", \\\"{x:1383,y:867,t:1528143453595};\\\", \\\"{x:1382,y:870,t:1528143453611};\\\", \\\"{x:1379,y:876,t:1528143453628};\\\", \\\"{x:1377,y:884,t:1528143453646};\\\", \\\"{x:1373,y:890,t:1528143453661};\\\", \\\"{x:1373,y:894,t:1528143453679};\\\", \\\"{x:1371,y:896,t:1528143453696};\\\", \\\"{x:1371,y:901,t:1528143453713};\\\", \\\"{x:1369,y:904,t:1528143453728};\\\", \\\"{x:1367,y:908,t:1528143453745};\\\", \\\"{x:1366,y:910,t:1528143453763};\\\", \\\"{x:1365,y:912,t:1528143453779};\\\", \\\"{x:1364,y:914,t:1528143453796};\\\", \\\"{x:1363,y:916,t:1528143453813};\\\", \\\"{x:1362,y:920,t:1528143453829};\\\", \\\"{x:1360,y:924,t:1528143453846};\\\", \\\"{x:1359,y:927,t:1528143453862};\\\", \\\"{x:1359,y:929,t:1528143453879};\\\", \\\"{x:1357,y:932,t:1528143453896};\\\", \\\"{x:1356,y:934,t:1528143453913};\\\", \\\"{x:1355,y:936,t:1528143453929};\\\", \\\"{x:1353,y:938,t:1528143453946};\\\", \\\"{x:1353,y:939,t:1528143453966};\\\", \\\"{x:1351,y:941,t:1528143453979};\\\", \\\"{x:1350,y:942,t:1528143453996};\\\", \\\"{x:1349,y:945,t:1528143454013};\\\", \\\"{x:1346,y:949,t:1528143454029};\\\", \\\"{x:1346,y:953,t:1528143454047};\\\", \\\"{x:1345,y:955,t:1528143454062};\\\", \\\"{x:1344,y:956,t:1528143454079};\\\", \\\"{x:1344,y:957,t:1528143454097};\\\", \\\"{x:1326,y:957,t:1528143455783};\\\", \\\"{x:1244,y:950,t:1528143455799};\\\", \\\"{x:1119,y:948,t:1528143455814};\\\", \\\"{x:971,y:958,t:1528143455832};\\\", \\\"{x:894,y:964,t:1528143455848};\\\", \\\"{x:857,y:959,t:1528143455864};\\\", \\\"{x:793,y:942,t:1528143455881};\\\", \\\"{x:728,y:919,t:1528143455898};\\\", \\\"{x:658,y:898,t:1528143455914};\\\", \\\"{x:593,y:875,t:1528143455931};\\\", \\\"{x:535,y:849,t:1528143455948};\\\", \\\"{x:493,y:828,t:1528143455965};\\\", \\\"{x:473,y:815,t:1528143455981};\\\", \\\"{x:452,y:800,t:1528143455999};\\\", \\\"{x:449,y:794,t:1528143456014};\\\", \\\"{x:447,y:790,t:1528143456031};\\\", \\\"{x:447,y:789,t:1528143456048};\\\", \\\"{x:446,y:787,t:1528143456065};\\\", \\\"{x:446,y:786,t:1528143456081};\\\", \\\"{x:446,y:784,t:1528143456098};\\\", \\\"{x:446,y:779,t:1528143456115};\\\", \\\"{x:446,y:769,t:1528143456131};\\\", \\\"{x:451,y:756,t:1528143456149};\\\", \\\"{x:456,y:746,t:1528143456166};\\\", \\\"{x:462,y:736,t:1528143456181};\\\", \\\"{x:473,y:718,t:1528143456200};\\\", \\\"{x:483,y:705,t:1528143456215};\\\", \\\"{x:488,y:698,t:1528143456231};\\\", \\\"{x:498,y:689,t:1528143456246};\\\", \\\"{x:509,y:679,t:1528143456262};\\\", \\\"{x:524,y:666,t:1528143456279};\\\", \\\"{x:540,y:653,t:1528143456296};\\\", \\\"{x:552,y:642,t:1528143456313};\\\", \\\"{x:562,y:630,t:1528143456329};\\\", \\\"{x:567,y:625,t:1528143456345};\\\", \\\"{x:567,y:624,t:1528143456363};\\\", \\\"{x:567,y:623,t:1528143456397};\\\", \\\"{x:566,y:620,t:1528143456414};\\\", \\\"{x:563,y:618,t:1528143456430};\\\", \\\"{x:549,y:610,t:1528143456448};\\\", \\\"{x:541,y:606,t:1528143456463};\\\", \\\"{x:531,y:600,t:1528143456480};\\\", \\\"{x:515,y:590,t:1528143456496};\\\", \\\"{x:494,y:580,t:1528143456513};\\\", \\\"{x:476,y:572,t:1528143456530};\\\", \\\"{x:467,y:567,t:1528143456547};\\\", \\\"{x:463,y:565,t:1528143456563};\\\", \\\"{x:461,y:565,t:1528143456579};\\\", \\\"{x:460,y:565,t:1528143456622};\\\", \\\"{x:457,y:565,t:1528143456661};\\\", \\\"{x:454,y:567,t:1528143456670};\\\", \\\"{x:451,y:571,t:1528143456681};\\\", \\\"{x:438,y:581,t:1528143456697};\\\", \\\"{x:426,y:593,t:1528143456715};\\\", \\\"{x:409,y:606,t:1528143456730};\\\", \\\"{x:395,y:618,t:1528143456747};\\\", \\\"{x:388,y:622,t:1528143456764};\\\", \\\"{x:387,y:622,t:1528143456780};\\\", \\\"{x:384,y:622,t:1528143456854};\\\", \\\"{x:382,y:622,t:1528143456864};\\\", \\\"{x:378,y:616,t:1528143456880};\\\", \\\"{x:378,y:615,t:1528143456897};\\\", \\\"{x:378,y:610,t:1528143456914};\\\", \\\"{x:378,y:608,t:1528143456930};\\\", \\\"{x:378,y:604,t:1528143456947};\\\", \\\"{x:378,y:603,t:1528143456964};\\\", \\\"{x:378,y:602,t:1528143456980};\\\", \\\"{x:378,y:601,t:1528143456997};\\\", \\\"{x:379,y:601,t:1528143457030};\\\", \\\"{x:380,y:600,t:1528143457047};\\\", \\\"{x:381,y:599,t:1528143457070};\\\", \\\"{x:382,y:598,t:1528143457081};\\\", \\\"{x:383,y:599,t:1528143457342};\\\", \\\"{x:386,y:600,t:1528143457349};\\\", \\\"{x:391,y:605,t:1528143457363};\\\", \\\"{x:396,y:617,t:1528143457381};\\\", \\\"{x:401,y:628,t:1528143457398};\\\", \\\"{x:403,y:634,t:1528143457414};\\\", \\\"{x:405,y:639,t:1528143457430};\\\", \\\"{x:409,y:644,t:1528143457447};\\\", \\\"{x:412,y:650,t:1528143457464};\\\", \\\"{x:416,y:653,t:1528143457481};\\\", \\\"{x:422,y:659,t:1528143457497};\\\", \\\"{x:428,y:668,t:1528143457514};\\\", \\\"{x:434,y:673,t:1528143457531};\\\", \\\"{x:437,y:676,t:1528143457548};\\\", \\\"{x:441,y:680,t:1528143457564};\\\", \\\"{x:444,y:683,t:1528143457581};\\\", \\\"{x:448,y:686,t:1528143457598};\\\", \\\"{x:450,y:688,t:1528143457614};\\\", \\\"{x:452,y:690,t:1528143457631};\\\", \\\"{x:457,y:693,t:1528143457648};\\\", \\\"{x:464,y:698,t:1528143457664};\\\", \\\"{x:471,y:703,t:1528143457682};\\\", \\\"{x:474,y:707,t:1528143457698};\\\", \\\"{x:479,y:711,t:1528143457714};\\\", \\\"{x:481,y:713,t:1528143457730};\\\", \\\"{x:484,y:715,t:1528143457748};\\\", \\\"{x:487,y:717,t:1528143457764};\\\", \\\"{x:490,y:719,t:1528143457781};\\\", \\\"{x:492,y:721,t:1528143457798};\\\" ] }, { \\\"rt\\\": 23291, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 571826, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:718,t:1528143462167};\\\", \\\"{x:493,y:678,t:1528143462186};\\\", \\\"{x:492,y:638,t:1528143462201};\\\", \\\"{x:490,y:607,t:1528143462218};\\\", \\\"{x:490,y:589,t:1528143462234};\\\", \\\"{x:490,y:582,t:1528143462251};\\\", \\\"{x:492,y:576,t:1528143462268};\\\", \\\"{x:492,y:574,t:1528143462286};\\\", \\\"{x:495,y:570,t:1528143462301};\\\", \\\"{x:499,y:564,t:1528143462318};\\\", \\\"{x:502,y:558,t:1528143462335};\\\", \\\"{x:504,y:552,t:1528143462351};\\\", \\\"{x:507,y:548,t:1528143462368};\\\", \\\"{x:510,y:543,t:1528143462386};\\\", \\\"{x:512,y:540,t:1528143462401};\\\", \\\"{x:515,y:536,t:1528143462418};\\\", \\\"{x:518,y:533,t:1528143462435};\\\", \\\"{x:524,y:528,t:1528143462451};\\\", \\\"{x:531,y:525,t:1528143462468};\\\", \\\"{x:539,y:519,t:1528143462485};\\\", \\\"{x:549,y:513,t:1528143462501};\\\", \\\"{x:560,y:506,t:1528143462518};\\\", \\\"{x:568,y:504,t:1528143462536};\\\", \\\"{x:576,y:500,t:1528143462551};\\\", \\\"{x:584,y:496,t:1528143462568};\\\", \\\"{x:593,y:495,t:1528143462585};\\\", \\\"{x:609,y:495,t:1528143462601};\\\", \\\"{x:636,y:499,t:1528143462618};\\\", \\\"{x:668,y:505,t:1528143462635};\\\", \\\"{x:710,y:511,t:1528143462652};\\\", \\\"{x:771,y:521,t:1528143462669};\\\", \\\"{x:837,y:537,t:1528143462686};\\\", \\\"{x:917,y:547,t:1528143462702};\\\", \\\"{x:972,y:554,t:1528143462719};\\\", \\\"{x:1023,y:562,t:1528143462735};\\\", \\\"{x:1057,y:568,t:1528143462752};\\\", \\\"{x:1079,y:572,t:1528143462769};\\\", \\\"{x:1097,y:574,t:1528143462785};\\\", \\\"{x:1109,y:575,t:1528143462802};\\\", \\\"{x:1115,y:576,t:1528143462818};\\\", \\\"{x:1120,y:576,t:1528143462835};\\\", \\\"{x:1121,y:577,t:1528143462851};\\\", \\\"{x:1123,y:577,t:1528143462869};\\\", \\\"{x:1124,y:577,t:1528143462885};\\\", \\\"{x:1126,y:577,t:1528143462901};\\\", \\\"{x:1127,y:577,t:1528143462918};\\\", \\\"{x:1126,y:577,t:1528143463591};\\\", \\\"{x:1119,y:577,t:1528143463602};\\\", \\\"{x:1102,y:577,t:1528143463617};\\\", \\\"{x:1070,y:577,t:1528143463634};\\\", \\\"{x:995,y:577,t:1528143463652};\\\", \\\"{x:914,y:576,t:1528143463667};\\\", \\\"{x:798,y:563,t:1528143463686};\\\", \\\"{x:675,y:551,t:1528143463702};\\\", \\\"{x:531,y:528,t:1528143463719};\\\", \\\"{x:467,y:520,t:1528143463736};\\\", \\\"{x:432,y:515,t:1528143463752};\\\", \\\"{x:423,y:511,t:1528143463769};\\\", \\\"{x:422,y:511,t:1528143463786};\\\", \\\"{x:424,y:508,t:1528143463990};\\\", \\\"{x:425,y:507,t:1528143464004};\\\", \\\"{x:428,y:503,t:1528143464021};\\\", \\\"{x:433,y:500,t:1528143464035};\\\", \\\"{x:436,y:497,t:1528143464052};\\\", \\\"{x:439,y:497,t:1528143464069};\\\", \\\"{x:441,y:496,t:1528143464086};\\\", \\\"{x:442,y:496,t:1528143464239};\\\", \\\"{x:444,y:496,t:1528143464310};\\\", \\\"{x:445,y:496,t:1528143464334};\\\", \\\"{x:448,y:496,t:1528143464342};\\\", \\\"{x:449,y:496,t:1528143464353};\\\", \\\"{x:452,y:496,t:1528143464369};\\\", \\\"{x:456,y:496,t:1528143464386};\\\", \\\"{x:459,y:496,t:1528143464403};\\\", \\\"{x:464,y:496,t:1528143464419};\\\", \\\"{x:470,y:496,t:1528143464437};\\\", \\\"{x:476,y:496,t:1528143464452};\\\", \\\"{x:481,y:496,t:1528143464470};\\\", \\\"{x:487,y:496,t:1528143464486};\\\", \\\"{x:491,y:496,t:1528143464503};\\\", \\\"{x:492,y:496,t:1528143464520};\\\", \\\"{x:495,y:496,t:1528143464536};\\\", \\\"{x:498,y:496,t:1528143464553};\\\", \\\"{x:502,y:496,t:1528143464570};\\\", \\\"{x:506,y:496,t:1528143464587};\\\", \\\"{x:517,y:496,t:1528143464603};\\\", \\\"{x:527,y:496,t:1528143464619};\\\", \\\"{x:540,y:496,t:1528143464636};\\\", \\\"{x:554,y:496,t:1528143464653};\\\", \\\"{x:567,y:496,t:1528143464670};\\\", \\\"{x:582,y:496,t:1528143464686};\\\", \\\"{x:594,y:497,t:1528143464702};\\\", \\\"{x:605,y:499,t:1528143464720};\\\", \\\"{x:619,y:500,t:1528143464736};\\\", \\\"{x:635,y:503,t:1528143464752};\\\", \\\"{x:664,y:505,t:1528143464770};\\\", \\\"{x:686,y:508,t:1528143464787};\\\", \\\"{x:745,y:515,t:1528143464802};\\\", \\\"{x:814,y:533,t:1528143464820};\\\", \\\"{x:865,y:552,t:1528143464838};\\\", \\\"{x:884,y:568,t:1528143464853};\\\", \\\"{x:939,y:591,t:1528143464870};\\\", \\\"{x:959,y:604,t:1528143464887};\\\", \\\"{x:976,y:617,t:1528143464903};\\\", \\\"{x:983,y:624,t:1528143464920};\\\", \\\"{x:992,y:632,t:1528143464937};\\\", \\\"{x:1015,y:646,t:1528143464953};\\\", \\\"{x:1026,y:653,t:1528143464970};\\\", \\\"{x:1037,y:660,t:1528143464987};\\\", \\\"{x:1040,y:662,t:1528143465003};\\\", \\\"{x:1040,y:663,t:1528143465020};\\\", \\\"{x:1043,y:664,t:1528143465037};\\\", \\\"{x:1043,y:665,t:1528143465054};\\\", \\\"{x:1043,y:666,t:1528143465103};\\\", \\\"{x:1047,y:669,t:1528143465120};\\\", \\\"{x:1060,y:676,t:1528143465138};\\\", \\\"{x:1073,y:679,t:1528143465154};\\\", \\\"{x:1095,y:685,t:1528143465170};\\\", \\\"{x:1124,y:695,t:1528143465187};\\\", \\\"{x:1150,y:702,t:1528143465203};\\\", \\\"{x:1174,y:709,t:1528143465220};\\\", \\\"{x:1204,y:717,t:1528143465237};\\\", \\\"{x:1222,y:723,t:1528143465254};\\\", \\\"{x:1237,y:727,t:1528143465270};\\\", \\\"{x:1240,y:729,t:1528143465287};\\\", \\\"{x:1242,y:729,t:1528143465303};\\\", \\\"{x:1244,y:731,t:1528143465320};\\\", \\\"{x:1246,y:732,t:1528143465337};\\\", \\\"{x:1246,y:733,t:1528143465353};\\\", \\\"{x:1247,y:733,t:1528143465382};\\\", \\\"{x:1247,y:734,t:1528143465398};\\\", \\\"{x:1247,y:736,t:1528143465407};\\\", \\\"{x:1249,y:737,t:1528143465421};\\\", \\\"{x:1249,y:738,t:1528143465438};\\\", \\\"{x:1249,y:740,t:1528143465454};\\\", \\\"{x:1249,y:744,t:1528143465471};\\\", \\\"{x:1249,y:749,t:1528143465487};\\\", \\\"{x:1249,y:752,t:1528143465504};\\\", \\\"{x:1249,y:758,t:1528143465520};\\\", \\\"{x:1248,y:765,t:1528143465537};\\\", \\\"{x:1247,y:767,t:1528143465554};\\\", \\\"{x:1245,y:769,t:1528143465570};\\\", \\\"{x:1245,y:771,t:1528143465588};\\\", \\\"{x:1242,y:776,t:1528143465603};\\\", \\\"{x:1241,y:777,t:1528143465620};\\\", \\\"{x:1238,y:782,t:1528143465637};\\\", \\\"{x:1237,y:786,t:1528143465654};\\\", \\\"{x:1232,y:796,t:1528143465670};\\\", \\\"{x:1229,y:800,t:1528143465687};\\\", \\\"{x:1226,y:805,t:1528143465703};\\\", \\\"{x:1223,y:809,t:1528143465720};\\\", \\\"{x:1223,y:810,t:1528143465737};\\\", \\\"{x:1222,y:810,t:1528143465753};\\\", \\\"{x:1221,y:812,t:1528143465771};\\\", \\\"{x:1221,y:813,t:1528143465823};\\\", \\\"{x:1221,y:815,t:1528143465935};\\\", \\\"{x:1220,y:816,t:1528143465942};\\\", \\\"{x:1220,y:817,t:1528143465954};\\\", \\\"{x:1220,y:821,t:1528143465971};\\\", \\\"{x:1220,y:823,t:1528143465988};\\\", \\\"{x:1220,y:824,t:1528143466005};\\\", \\\"{x:1220,y:826,t:1528143466021};\\\", \\\"{x:1220,y:827,t:1528143466047};\\\", \\\"{x:1220,y:828,t:1528143466081};\\\", \\\"{x:1220,y:829,t:1528143466109};\\\", \\\"{x:1220,y:830,t:1528143466134};\\\", \\\"{x:1220,y:831,t:1528143466149};\\\", \\\"{x:1220,y:832,t:1528143466158};\\\", \\\"{x:1220,y:833,t:1528143466182};\\\", \\\"{x:1220,y:834,t:1528143466197};\\\", \\\"{x:1220,y:835,t:1528143466213};\\\", \\\"{x:1221,y:836,t:1528143466278};\\\", \\\"{x:1221,y:837,t:1528143466335};\\\", \\\"{x:1221,y:838,t:1528143466359};\\\", \\\"{x:1221,y:839,t:1528143466415};\\\", \\\"{x:1222,y:839,t:1528143466430};\\\", \\\"{x:1223,y:839,t:1528143466454};\\\", \\\"{x:1223,y:840,t:1528143466470};\\\", \\\"{x:1224,y:841,t:1528143466488};\\\", \\\"{x:1225,y:842,t:1528143466575};\\\", \\\"{x:1226,y:843,t:1528143466599};\\\", \\\"{x:1226,y:844,t:1528143466607};\\\", \\\"{x:1227,y:845,t:1528143466630};\\\", \\\"{x:1227,y:846,t:1528143466774};\\\", \\\"{x:1227,y:847,t:1528143466790};\\\", \\\"{x:1227,y:849,t:1528143466806};\\\", \\\"{x:1228,y:851,t:1528143466821};\\\", \\\"{x:1228,y:853,t:1528143466839};\\\", \\\"{x:1230,y:856,t:1528143466855};\\\", \\\"{x:1230,y:860,t:1528143466871};\\\", \\\"{x:1230,y:861,t:1528143466888};\\\", \\\"{x:1232,y:863,t:1528143466905};\\\", \\\"{x:1232,y:864,t:1528143466927};\\\", \\\"{x:1232,y:865,t:1528143466942};\\\", \\\"{x:1232,y:866,t:1528143466957};\\\", \\\"{x:1233,y:867,t:1528143466974};\\\", \\\"{x:1234,y:869,t:1528143466998};\\\", \\\"{x:1234,y:870,t:1528143467005};\\\", \\\"{x:1234,y:872,t:1528143467020};\\\", \\\"{x:1235,y:874,t:1528143467037};\\\", \\\"{x:1236,y:879,t:1528143467053};\\\", \\\"{x:1237,y:880,t:1528143467070};\\\", \\\"{x:1239,y:883,t:1528143467087};\\\", \\\"{x:1239,y:884,t:1528143467104};\\\", \\\"{x:1240,y:886,t:1528143467120};\\\", \\\"{x:1240,y:887,t:1528143467141};\\\", \\\"{x:1240,y:888,t:1528143467154};\\\", \\\"{x:1241,y:889,t:1528143467171};\\\", \\\"{x:1242,y:892,t:1528143467187};\\\", \\\"{x:1243,y:894,t:1528143467204};\\\", \\\"{x:1243,y:896,t:1528143467221};\\\", \\\"{x:1243,y:898,t:1528143467238};\\\", \\\"{x:1246,y:902,t:1528143467254};\\\", \\\"{x:1247,y:906,t:1528143467271};\\\", \\\"{x:1248,y:910,t:1528143467288};\\\", \\\"{x:1250,y:914,t:1528143467304};\\\", \\\"{x:1251,y:917,t:1528143467320};\\\", \\\"{x:1254,y:921,t:1528143467338};\\\", \\\"{x:1257,y:924,t:1528143467355};\\\", \\\"{x:1260,y:927,t:1528143467370};\\\", \\\"{x:1264,y:931,t:1528143467387};\\\", \\\"{x:1266,y:935,t:1528143467405};\\\", \\\"{x:1270,y:939,t:1528143467421};\\\", \\\"{x:1272,y:942,t:1528143467439};\\\", \\\"{x:1274,y:944,t:1528143467455};\\\", \\\"{x:1275,y:945,t:1528143467472};\\\", \\\"{x:1275,y:946,t:1528143467510};\\\", \\\"{x:1276,y:947,t:1528143467527};\\\", \\\"{x:1276,y:948,t:1528143467542};\\\", \\\"{x:1276,y:949,t:1528143467599};\\\", \\\"{x:1276,y:951,t:1528143467630};\\\", \\\"{x:1276,y:952,t:1528143467646};\\\", \\\"{x:1276,y:954,t:1528143467678};\\\", \\\"{x:1277,y:954,t:1528143467726};\\\", \\\"{x:1277,y:955,t:1528143467738};\\\", \\\"{x:1277,y:957,t:1528143468671};\\\", \\\"{x:1278,y:957,t:1528143468710};\\\", \\\"{x:1278,y:958,t:1528143469151};\\\", \\\"{x:1282,y:956,t:1528143469159};\\\", \\\"{x:1287,y:946,t:1528143469172};\\\", \\\"{x:1290,y:938,t:1528143469189};\\\", \\\"{x:1293,y:930,t:1528143469204};\\\", \\\"{x:1297,y:926,t:1528143469221};\\\", \\\"{x:1297,y:925,t:1528143469238};\\\", \\\"{x:1298,y:924,t:1528143469366};\\\", \\\"{x:1298,y:923,t:1528143469374};\\\", \\\"{x:1299,y:922,t:1528143469389};\\\", \\\"{x:1300,y:920,t:1528143469404};\\\", \\\"{x:1302,y:918,t:1528143469421};\\\", \\\"{x:1307,y:914,t:1528143469438};\\\", \\\"{x:1312,y:911,t:1528143469455};\\\", \\\"{x:1317,y:909,t:1528143469471};\\\", \\\"{x:1319,y:907,t:1528143469489};\\\", \\\"{x:1320,y:907,t:1528143469504};\\\", \\\"{x:1321,y:905,t:1528143469542};\\\", \\\"{x:1324,y:903,t:1528143470359};\\\", \\\"{x:1329,y:896,t:1528143470373};\\\", \\\"{x:1335,y:889,t:1528143470390};\\\", \\\"{x:1341,y:880,t:1528143470405};\\\", \\\"{x:1348,y:873,t:1528143470422};\\\", \\\"{x:1353,y:867,t:1528143470439};\\\", \\\"{x:1356,y:862,t:1528143470455};\\\", \\\"{x:1363,y:855,t:1528143470472};\\\", \\\"{x:1365,y:851,t:1528143470489};\\\", \\\"{x:1367,y:848,t:1528143470505};\\\", \\\"{x:1368,y:846,t:1528143470523};\\\", \\\"{x:1370,y:844,t:1528143470539};\\\", \\\"{x:1371,y:842,t:1528143470556};\\\", \\\"{x:1372,y:842,t:1528143470572};\\\", \\\"{x:1373,y:841,t:1528143470589};\\\", \\\"{x:1374,y:839,t:1528143470606};\\\", \\\"{x:1375,y:838,t:1528143470622};\\\", \\\"{x:1377,y:836,t:1528143470639};\\\", \\\"{x:1380,y:831,t:1528143470655};\\\", \\\"{x:1382,y:827,t:1528143470672};\\\", \\\"{x:1387,y:822,t:1528143470688};\\\", \\\"{x:1391,y:815,t:1528143470706};\\\", \\\"{x:1396,y:807,t:1528143470721};\\\", \\\"{x:1399,y:799,t:1528143470738};\\\", \\\"{x:1401,y:795,t:1528143470756};\\\", \\\"{x:1402,y:790,t:1528143470771};\\\", \\\"{x:1404,y:785,t:1528143470788};\\\", \\\"{x:1405,y:780,t:1528143470806};\\\", \\\"{x:1406,y:776,t:1528143470822};\\\", \\\"{x:1407,y:774,t:1528143470854};\\\", \\\"{x:1407,y:773,t:1528143470870};\\\", \\\"{x:1407,y:771,t:1528143470886};\\\", \\\"{x:1408,y:771,t:1528143470894};\\\", \\\"{x:1408,y:770,t:1528143470906};\\\", \\\"{x:1409,y:767,t:1528143470922};\\\", \\\"{x:1409,y:766,t:1528143470938};\\\", \\\"{x:1411,y:764,t:1528143470956};\\\", \\\"{x:1411,y:763,t:1528143471078};\\\", \\\"{x:1410,y:763,t:1528143471094};\\\", \\\"{x:1408,y:763,t:1528143471105};\\\", \\\"{x:1404,y:763,t:1528143471121};\\\", \\\"{x:1400,y:763,t:1528143471138};\\\", \\\"{x:1387,y:762,t:1528143471156};\\\", \\\"{x:1363,y:762,t:1528143471172};\\\", \\\"{x:1292,y:762,t:1528143471189};\\\", \\\"{x:1142,y:748,t:1528143471206};\\\", \\\"{x:1004,y:727,t:1528143471222};\\\", \\\"{x:851,y:703,t:1528143471238};\\\", \\\"{x:674,y:676,t:1528143471256};\\\", \\\"{x:505,y:649,t:1528143471273};\\\", \\\"{x:364,y:632,t:1528143471289};\\\", \\\"{x:203,y:610,t:1528143471321};\\\", \\\"{x:175,y:605,t:1528143471343};\\\", \\\"{x:175,y:603,t:1528143471422};\\\", \\\"{x:176,y:603,t:1528143471429};\\\", \\\"{x:177,y:602,t:1528143471442};\\\", \\\"{x:177,y:601,t:1528143471477};\\\", \\\"{x:179,y:599,t:1528143471493};\\\", \\\"{x:185,y:583,t:1528143471510};\\\", \\\"{x:188,y:577,t:1528143471526};\\\", \\\"{x:196,y:562,t:1528143471543};\\\", \\\"{x:200,y:557,t:1528143471559};\\\", \\\"{x:202,y:554,t:1528143471575};\\\", \\\"{x:204,y:553,t:1528143471592};\\\", \\\"{x:205,y:552,t:1528143471609};\\\", \\\"{x:206,y:551,t:1528143471625};\\\", \\\"{x:207,y:551,t:1528143471743};\\\", \\\"{x:208,y:551,t:1528143471766};\\\", \\\"{x:209,y:551,t:1528143471775};\\\", \\\"{x:210,y:551,t:1528143471792};\\\", \\\"{x:212,y:551,t:1528143471810};\\\", \\\"{x:216,y:549,t:1528143471826};\\\", \\\"{x:220,y:546,t:1528143471843};\\\", \\\"{x:223,y:545,t:1528143471860};\\\", \\\"{x:223,y:544,t:1528143473935};\\\", \\\"{x:222,y:544,t:1528143479767};\\\", \\\"{x:221,y:544,t:1528143479781};\\\", \\\"{x:213,y:544,t:1528143479797};\\\", \\\"{x:206,y:546,t:1528143479813};\\\", \\\"{x:202,y:555,t:1528143479830};\\\", \\\"{x:202,y:559,t:1528143479847};\\\", \\\"{x:202,y:562,t:1528143479863};\\\", \\\"{x:203,y:562,t:1528143479880};\\\", \\\"{x:203,y:564,t:1528143479898};\\\", \\\"{x:208,y:564,t:1528143479913};\\\", \\\"{x:226,y:564,t:1528143479930};\\\", \\\"{x:251,y:564,t:1528143479948};\\\", \\\"{x:277,y:564,t:1528143479965};\\\", \\\"{x:299,y:564,t:1528143479980};\\\", \\\"{x:318,y:564,t:1528143479997};\\\", \\\"{x:327,y:563,t:1528143480015};\\\", \\\"{x:329,y:562,t:1528143480033};\\\", \\\"{x:330,y:561,t:1528143480050};\\\", \\\"{x:335,y:560,t:1528143480066};\\\", \\\"{x:339,y:559,t:1528143480083};\\\", \\\"{x:343,y:558,t:1528143480099};\\\", \\\"{x:345,y:557,t:1528143480117};\\\", \\\"{x:345,y:556,t:1528143480133};\\\", \\\"{x:347,y:555,t:1528143480150};\\\", \\\"{x:350,y:555,t:1528143480167};\\\", \\\"{x:362,y:555,t:1528143480184};\\\", \\\"{x:373,y:555,t:1528143480200};\\\", \\\"{x:377,y:558,t:1528143480217};\\\", \\\"{x:381,y:560,t:1528143480234};\\\", \\\"{x:389,y:564,t:1528143480251};\\\", \\\"{x:392,y:566,t:1528143480267};\\\", \\\"{x:393,y:567,t:1528143480283};\\\", \\\"{x:394,y:568,t:1528143480310};\\\", \\\"{x:400,y:576,t:1528143482456};\\\", \\\"{x:410,y:590,t:1528143482469};\\\", \\\"{x:430,y:616,t:1528143482485};\\\", \\\"{x:449,y:642,t:1528143482502};\\\", \\\"{x:457,y:654,t:1528143482518};\\\", \\\"{x:465,y:664,t:1528143482535};\\\", \\\"{x:471,y:673,t:1528143482552};\\\", \\\"{x:474,y:677,t:1528143482567};\\\", \\\"{x:475,y:678,t:1528143482585};\\\", \\\"{x:477,y:681,t:1528143482601};\\\", \\\"{x:478,y:684,t:1528143482618};\\\", \\\"{x:479,y:685,t:1528143482635};\\\", \\\"{x:481,y:686,t:1528143482651};\\\", \\\"{x:481,y:688,t:1528143482668};\\\", \\\"{x:481,y:689,t:1528143482685};\\\", \\\"{x:483,y:692,t:1528143482702};\\\", \\\"{x:484,y:698,t:1528143482718};\\\", \\\"{x:487,y:704,t:1528143482736};\\\", \\\"{x:488,y:708,t:1528143482751};\\\", \\\"{x:491,y:713,t:1528143482769};\\\", \\\"{x:495,y:717,t:1528143482786};\\\", \\\"{x:496,y:717,t:1528143482801};\\\", \\\"{x:498,y:717,t:1528143482819};\\\", \\\"{x:499,y:718,t:1528143482835};\\\" ] }, { \\\"rt\\\": 13998, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 587057, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -H -H -5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:718,t:1528143486854};\\\", \\\"{x:501,y:718,t:1528143486862};\\\", \\\"{x:506,y:718,t:1528143486876};\\\", \\\"{x:520,y:718,t:1528143486891};\\\", \\\"{x:543,y:718,t:1528143486908};\\\", \\\"{x:580,y:713,t:1528143486927};\\\", \\\"{x:645,y:705,t:1528143486941};\\\", \\\"{x:692,y:700,t:1528143486958};\\\", \\\"{x:709,y:700,t:1528143486972};\\\", \\\"{x:759,y:700,t:1528143486989};\\\", \\\"{x:801,y:700,t:1528143487005};\\\", \\\"{x:874,y:705,t:1528143487022};\\\", \\\"{x:931,y:717,t:1528143487039};\\\", \\\"{x:988,y:728,t:1528143487055};\\\", \\\"{x:1046,y:745,t:1528143487073};\\\", \\\"{x:1102,y:763,t:1528143487089};\\\", \\\"{x:1163,y:780,t:1528143487105};\\\", \\\"{x:1221,y:793,t:1528143487122};\\\", \\\"{x:1282,y:808,t:1528143487139};\\\", \\\"{x:1336,y:821,t:1528143487155};\\\", \\\"{x:1376,y:828,t:1528143487172};\\\", \\\"{x:1415,y:833,t:1528143487190};\\\", \\\"{x:1443,y:833,t:1528143487205};\\\", \\\"{x:1472,y:833,t:1528143487222};\\\", \\\"{x:1482,y:832,t:1528143487241};\\\", \\\"{x:1496,y:832,t:1528143487256};\\\", \\\"{x:1511,y:832,t:1528143487273};\\\", \\\"{x:1523,y:832,t:1528143487290};\\\", \\\"{x:1530,y:832,t:1528143487305};\\\", \\\"{x:1533,y:832,t:1528143487322};\\\", \\\"{x:1538,y:832,t:1528143487340};\\\", \\\"{x:1545,y:832,t:1528143487357};\\\", \\\"{x:1551,y:833,t:1528143487373};\\\", \\\"{x:1559,y:837,t:1528143487390};\\\", \\\"{x:1566,y:840,t:1528143487406};\\\", \\\"{x:1573,y:843,t:1528143487422};\\\", \\\"{x:1576,y:845,t:1528143487440};\\\", \\\"{x:1578,y:847,t:1528143487457};\\\", \\\"{x:1582,y:851,t:1528143487473};\\\", \\\"{x:1586,y:857,t:1528143487490};\\\", \\\"{x:1589,y:865,t:1528143487507};\\\", \\\"{x:1592,y:873,t:1528143487522};\\\", \\\"{x:1599,y:882,t:1528143487540};\\\", \\\"{x:1603,y:893,t:1528143487557};\\\", \\\"{x:1609,y:900,t:1528143487572};\\\", \\\"{x:1616,y:915,t:1528143487590};\\\", \\\"{x:1618,y:919,t:1528143487607};\\\", \\\"{x:1622,y:923,t:1528143487623};\\\", \\\"{x:1622,y:924,t:1528143487646};\\\", \\\"{x:1623,y:925,t:1528143487657};\\\", \\\"{x:1623,y:926,t:1528143487694};\\\", \\\"{x:1623,y:927,t:1528143487707};\\\", \\\"{x:1623,y:930,t:1528143487723};\\\", \\\"{x:1623,y:932,t:1528143487740};\\\", \\\"{x:1623,y:936,t:1528143487757};\\\", \\\"{x:1623,y:939,t:1528143487773};\\\", \\\"{x:1623,y:943,t:1528143487790};\\\", \\\"{x:1623,y:948,t:1528143487807};\\\", \\\"{x:1623,y:950,t:1528143487824};\\\", \\\"{x:1623,y:951,t:1528143487840};\\\", \\\"{x:1623,y:953,t:1528143487886};\\\", \\\"{x:1622,y:953,t:1528143487894};\\\", \\\"{x:1622,y:954,t:1528143487910};\\\", \\\"{x:1620,y:958,t:1528143487935};\\\", \\\"{x:1619,y:959,t:1528143488063};\\\", \\\"{x:1619,y:960,t:1528143488078};\\\", \\\"{x:1618,y:961,t:1528143488110};\\\", \\\"{x:1616,y:961,t:1528143488175};\\\", \\\"{x:1613,y:960,t:1528143488190};\\\", \\\"{x:1611,y:953,t:1528143488208};\\\", \\\"{x:1610,y:949,t:1528143488224};\\\", \\\"{x:1607,y:940,t:1528143488241};\\\", \\\"{x:1604,y:932,t:1528143488257};\\\", \\\"{x:1603,y:926,t:1528143488274};\\\", \\\"{x:1600,y:922,t:1528143488291};\\\", \\\"{x:1597,y:914,t:1528143488307};\\\", \\\"{x:1593,y:904,t:1528143488324};\\\", \\\"{x:1587,y:889,t:1528143488342};\\\", \\\"{x:1582,y:877,t:1528143488357};\\\", \\\"{x:1579,y:869,t:1528143488374};\\\", \\\"{x:1570,y:854,t:1528143488391};\\\", \\\"{x:1564,y:843,t:1528143488407};\\\", \\\"{x:1555,y:827,t:1528143488424};\\\", \\\"{x:1545,y:809,t:1528143488441};\\\", \\\"{x:1533,y:788,t:1528143488457};\\\", \\\"{x:1527,y:772,t:1528143488474};\\\", \\\"{x:1519,y:757,t:1528143488491};\\\", \\\"{x:1513,y:747,t:1528143488508};\\\", \\\"{x:1512,y:746,t:1528143488524};\\\", \\\"{x:1510,y:743,t:1528143488541};\\\", \\\"{x:1509,y:736,t:1528143488558};\\\", \\\"{x:1505,y:728,t:1528143488574};\\\", \\\"{x:1504,y:718,t:1528143488590};\\\", \\\"{x:1500,y:709,t:1528143488608};\\\", \\\"{x:1497,y:699,t:1528143488624};\\\", \\\"{x:1493,y:682,t:1528143488640};\\\", \\\"{x:1489,y:670,t:1528143488658};\\\", \\\"{x:1484,y:657,t:1528143488674};\\\", \\\"{x:1478,y:644,t:1528143488691};\\\", \\\"{x:1476,y:639,t:1528143488708};\\\", \\\"{x:1475,y:635,t:1528143488724};\\\", \\\"{x:1472,y:631,t:1528143488741};\\\", \\\"{x:1471,y:627,t:1528143488758};\\\", \\\"{x:1469,y:619,t:1528143488774};\\\", \\\"{x:1467,y:613,t:1528143488790};\\\", \\\"{x:1464,y:605,t:1528143488807};\\\", \\\"{x:1464,y:600,t:1528143488823};\\\", \\\"{x:1460,y:593,t:1528143488841};\\\", \\\"{x:1459,y:589,t:1528143488857};\\\", \\\"{x:1458,y:585,t:1528143488874};\\\", \\\"{x:1456,y:581,t:1528143488890};\\\", \\\"{x:1455,y:579,t:1528143488908};\\\", \\\"{x:1453,y:577,t:1528143488925};\\\", \\\"{x:1452,y:576,t:1528143488942};\\\", \\\"{x:1451,y:576,t:1528143488998};\\\", \\\"{x:1450,y:574,t:1528143489007};\\\", \\\"{x:1449,y:574,t:1528143489025};\\\", \\\"{x:1447,y:573,t:1528143489041};\\\", \\\"{x:1446,y:573,t:1528143489058};\\\", \\\"{x:1442,y:571,t:1528143489074};\\\", \\\"{x:1441,y:571,t:1528143489091};\\\", \\\"{x:1440,y:570,t:1528143489108};\\\", \\\"{x:1439,y:570,t:1528143489125};\\\", \\\"{x:1437,y:569,t:1528143489141};\\\", \\\"{x:1435,y:567,t:1528143489158};\\\", \\\"{x:1434,y:567,t:1528143489182};\\\", \\\"{x:1434,y:566,t:1528143489191};\\\", \\\"{x:1432,y:565,t:1528143489208};\\\", \\\"{x:1430,y:564,t:1528143489225};\\\", \\\"{x:1429,y:563,t:1528143489241};\\\", \\\"{x:1426,y:561,t:1528143489258};\\\", \\\"{x:1423,y:558,t:1528143489275};\\\", \\\"{x:1420,y:553,t:1528143489292};\\\", \\\"{x:1414,y:546,t:1528143489308};\\\", \\\"{x:1405,y:536,t:1528143489325};\\\", \\\"{x:1399,y:527,t:1528143489342};\\\", \\\"{x:1389,y:516,t:1528143489358};\\\", \\\"{x:1379,y:510,t:1528143489374};\\\", \\\"{x:1367,y:505,t:1528143489392};\\\", \\\"{x:1348,y:502,t:1528143489408};\\\", \\\"{x:1322,y:500,t:1528143489425};\\\", \\\"{x:1259,y:490,t:1528143489442};\\\", \\\"{x:1131,y:490,t:1528143489457};\\\", \\\"{x:957,y:514,t:1528143489475};\\\", \\\"{x:763,y:553,t:1528143489493};\\\", \\\"{x:589,y:598,t:1528143489508};\\\", \\\"{x:458,y:623,t:1528143489525};\\\", \\\"{x:375,y:634,t:1528143489541};\\\", \\\"{x:323,y:644,t:1528143489557};\\\", \\\"{x:301,y:645,t:1528143489575};\\\", \\\"{x:292,y:646,t:1528143489590};\\\", \\\"{x:291,y:647,t:1528143489607};\\\", \\\"{x:291,y:648,t:1528143489637};\\\", \\\"{x:291,y:649,t:1528143489661};\\\", \\\"{x:291,y:651,t:1528143489675};\\\", \\\"{x:291,y:652,t:1528143489742};\\\", \\\"{x:294,y:652,t:1528143489758};\\\", \\\"{x:309,y:630,t:1528143489774};\\\", \\\"{x:319,y:618,t:1528143489792};\\\", \\\"{x:328,y:608,t:1528143489807};\\\", \\\"{x:342,y:596,t:1528143489825};\\\", \\\"{x:358,y:588,t:1528143489841};\\\", \\\"{x:375,y:582,t:1528143489857};\\\", \\\"{x:396,y:577,t:1528143489875};\\\", \\\"{x:420,y:575,t:1528143489891};\\\", \\\"{x:441,y:575,t:1528143489907};\\\", \\\"{x:464,y:573,t:1528143489925};\\\", \\\"{x:490,y:573,t:1528143489942};\\\", \\\"{x:500,y:573,t:1528143489958};\\\", \\\"{x:505,y:573,t:1528143489974};\\\", \\\"{x:506,y:573,t:1528143489991};\\\", \\\"{x:504,y:573,t:1528143490070};\\\", \\\"{x:502,y:573,t:1528143490077};\\\", \\\"{x:498,y:573,t:1528143490092};\\\", \\\"{x:490,y:575,t:1528143490109};\\\", \\\"{x:483,y:576,t:1528143490124};\\\", \\\"{x:478,y:576,t:1528143490141};\\\", \\\"{x:475,y:576,t:1528143490157};\\\", \\\"{x:472,y:576,t:1528143490175};\\\", \\\"{x:468,y:576,t:1528143490192};\\\", \\\"{x:462,y:576,t:1528143490208};\\\", \\\"{x:456,y:575,t:1528143490224};\\\", \\\"{x:449,y:575,t:1528143490242};\\\", \\\"{x:441,y:575,t:1528143490259};\\\", \\\"{x:431,y:575,t:1528143490274};\\\", \\\"{x:417,y:575,t:1528143490291};\\\", \\\"{x:401,y:575,t:1528143490310};\\\", \\\"{x:369,y:575,t:1528143490326};\\\", \\\"{x:350,y:575,t:1528143490341};\\\", \\\"{x:337,y:575,t:1528143490358};\\\", \\\"{x:326,y:575,t:1528143490375};\\\", \\\"{x:320,y:575,t:1528143490391};\\\", \\\"{x:313,y:575,t:1528143490408};\\\", \\\"{x:308,y:575,t:1528143490426};\\\", \\\"{x:302,y:577,t:1528143490441};\\\", \\\"{x:293,y:580,t:1528143490458};\\\", \\\"{x:285,y:581,t:1528143490475};\\\", \\\"{x:277,y:582,t:1528143490492};\\\", \\\"{x:263,y:587,t:1528143490509};\\\", \\\"{x:242,y:593,t:1528143490525};\\\", \\\"{x:236,y:594,t:1528143490541};\\\", \\\"{x:235,y:594,t:1528143490558};\\\", \\\"{x:238,y:594,t:1528143490614};\\\", \\\"{x:245,y:593,t:1528143490626};\\\", \\\"{x:274,y:586,t:1528143490642};\\\", \\\"{x:310,y:582,t:1528143490658};\\\", \\\"{x:348,y:581,t:1528143490675};\\\", \\\"{x:380,y:581,t:1528143490691};\\\", \\\"{x:404,y:581,t:1528143490708};\\\", \\\"{x:434,y:581,t:1528143490726};\\\", \\\"{x:449,y:581,t:1528143490742};\\\", \\\"{x:462,y:581,t:1528143490758};\\\", \\\"{x:473,y:581,t:1528143490775};\\\", \\\"{x:483,y:578,t:1528143490791};\\\", \\\"{x:492,y:576,t:1528143490809};\\\", \\\"{x:500,y:572,t:1528143490826};\\\", \\\"{x:505,y:571,t:1528143490842};\\\", \\\"{x:508,y:569,t:1528143490859};\\\", \\\"{x:510,y:568,t:1528143490876};\\\", \\\"{x:513,y:567,t:1528143490892};\\\", \\\"{x:516,y:565,t:1528143490909};\\\", \\\"{x:518,y:565,t:1528143490926};\\\", \\\"{x:521,y:564,t:1528143490942};\\\", \\\"{x:525,y:564,t:1528143490960};\\\", \\\"{x:529,y:562,t:1528143490976};\\\", \\\"{x:539,y:560,t:1528143490992};\\\", \\\"{x:551,y:559,t:1528143491011};\\\", \\\"{x:562,y:557,t:1528143491026};\\\", \\\"{x:569,y:557,t:1528143491043};\\\", \\\"{x:574,y:557,t:1528143491060};\\\", \\\"{x:580,y:557,t:1528143491075};\\\", \\\"{x:585,y:559,t:1528143491093};\\\", \\\"{x:587,y:559,t:1528143491110};\\\", \\\"{x:589,y:559,t:1528143491126};\\\", \\\"{x:591,y:559,t:1528143491142};\\\", \\\"{x:595,y:559,t:1528143491160};\\\", \\\"{x:597,y:559,t:1528143491177};\\\", \\\"{x:598,y:559,t:1528143491193};\\\", \\\"{x:599,y:559,t:1528143491212};\\\", \\\"{x:600,y:559,t:1528143491230};\\\", \\\"{x:601,y:559,t:1528143491294};\\\", \\\"{x:602,y:560,t:1528143491742};\\\", \\\"{x:602,y:564,t:1528143491760};\\\", \\\"{x:602,y:569,t:1528143491777};\\\", \\\"{x:602,y:571,t:1528143491793};\\\", \\\"{x:601,y:572,t:1528143491810};\\\", \\\"{x:601,y:573,t:1528143491862};\\\", \\\"{x:612,y:594,t:1528143492607};\\\", \\\"{x:711,y:683,t:1528143492626};\\\", \\\"{x:843,y:759,t:1528143492643};\\\", \\\"{x:992,y:824,t:1528143492661};\\\", \\\"{x:1141,y:870,t:1528143492676};\\\", \\\"{x:1320,y:912,t:1528143492693};\\\", \\\"{x:1416,y:923,t:1528143492710};\\\", \\\"{x:1514,y:923,t:1528143492726};\\\", \\\"{x:1605,y:923,t:1528143492744};\\\", \\\"{x:1686,y:923,t:1528143492760};\\\", \\\"{x:1725,y:923,t:1528143492776};\\\", \\\"{x:1744,y:925,t:1528143492794};\\\", \\\"{x:1747,y:925,t:1528143492810};\\\", \\\"{x:1748,y:925,t:1528143492863};\\\", \\\"{x:1750,y:925,t:1528143492877};\\\", \\\"{x:1761,y:920,t:1528143492894};\\\", \\\"{x:1767,y:915,t:1528143492911};\\\", \\\"{x:1767,y:913,t:1528143492927};\\\", \\\"{x:1765,y:913,t:1528143492999};\\\", \\\"{x:1758,y:914,t:1528143493011};\\\", \\\"{x:1727,y:917,t:1528143493027};\\\", \\\"{x:1697,y:922,t:1528143493044};\\\", \\\"{x:1668,y:923,t:1528143493061};\\\", \\\"{x:1648,y:923,t:1528143493078};\\\", \\\"{x:1626,y:923,t:1528143493095};\\\", \\\"{x:1617,y:923,t:1528143493111};\\\", \\\"{x:1614,y:923,t:1528143493128};\\\", \\\"{x:1613,y:923,t:1528143493144};\\\", \\\"{x:1612,y:923,t:1528143493161};\\\", \\\"{x:1611,y:923,t:1528143493178};\\\", \\\"{x:1609,y:924,t:1528143493194};\\\", \\\"{x:1608,y:926,t:1528143493211};\\\", \\\"{x:1607,y:926,t:1528143493231};\\\", \\\"{x:1607,y:927,t:1528143493254};\\\", \\\"{x:1605,y:929,t:1528143493287};\\\", \\\"{x:1605,y:931,t:1528143493302};\\\", \\\"{x:1604,y:932,t:1528143493311};\\\", \\\"{x:1603,y:936,t:1528143493328};\\\", \\\"{x:1602,y:940,t:1528143493344};\\\", \\\"{x:1601,y:942,t:1528143493361};\\\", \\\"{x:1600,y:943,t:1528143493379};\\\", \\\"{x:1599,y:943,t:1528143493414};\\\", \\\"{x:1598,y:943,t:1528143493454};\\\", \\\"{x:1596,y:943,t:1528143493462};\\\", \\\"{x:1589,y:935,t:1528143493478};\\\", \\\"{x:1586,y:930,t:1528143493494};\\\", \\\"{x:1584,y:927,t:1528143493511};\\\", \\\"{x:1582,y:924,t:1528143493529};\\\", \\\"{x:1581,y:921,t:1528143493544};\\\", \\\"{x:1578,y:916,t:1528143493561};\\\", \\\"{x:1576,y:909,t:1528143493578};\\\", \\\"{x:1574,y:905,t:1528143493594};\\\", \\\"{x:1573,y:900,t:1528143493614};\\\", \\\"{x:1572,y:898,t:1528143493628};\\\", \\\"{x:1571,y:895,t:1528143493645};\\\", \\\"{x:1571,y:894,t:1528143493660};\\\", \\\"{x:1570,y:887,t:1528143493678};\\\", \\\"{x:1569,y:879,t:1528143493694};\\\", \\\"{x:1565,y:867,t:1528143493710};\\\", \\\"{x:1564,y:862,t:1528143493728};\\\", \\\"{x:1564,y:857,t:1528143493744};\\\", \\\"{x:1561,y:853,t:1528143493760};\\\", \\\"{x:1561,y:850,t:1528143493778};\\\", \\\"{x:1561,y:847,t:1528143493795};\\\", \\\"{x:1558,y:842,t:1528143493810};\\\", \\\"{x:1557,y:837,t:1528143493827};\\\", \\\"{x:1556,y:835,t:1528143493845};\\\", \\\"{x:1556,y:833,t:1528143493861};\\\", \\\"{x:1554,y:829,t:1528143493877};\\\", \\\"{x:1553,y:826,t:1528143493895};\\\", \\\"{x:1551,y:823,t:1528143493911};\\\", \\\"{x:1550,y:819,t:1528143493928};\\\", \\\"{x:1547,y:814,t:1528143493945};\\\", \\\"{x:1546,y:811,t:1528143493961};\\\", \\\"{x:1544,y:807,t:1528143493977};\\\", \\\"{x:1542,y:803,t:1528143493995};\\\", \\\"{x:1540,y:799,t:1528143494011};\\\", \\\"{x:1539,y:794,t:1528143494028};\\\", \\\"{x:1536,y:788,t:1528143494045};\\\", \\\"{x:1532,y:777,t:1528143494062};\\\", \\\"{x:1530,y:774,t:1528143494078};\\\", \\\"{x:1528,y:772,t:1528143494095};\\\", \\\"{x:1528,y:768,t:1528143494112};\\\", \\\"{x:1527,y:766,t:1528143494128};\\\", \\\"{x:1526,y:763,t:1528143494146};\\\", \\\"{x:1525,y:762,t:1528143494162};\\\", \\\"{x:1525,y:761,t:1528143494190};\\\", \\\"{x:1524,y:759,t:1528143494199};\\\", \\\"{x:1523,y:757,t:1528143494231};\\\", \\\"{x:1523,y:755,t:1528143494255};\\\", \\\"{x:1522,y:755,t:1528143494287};\\\", \\\"{x:1522,y:754,t:1528143494319};\\\", \\\"{x:1521,y:752,t:1528143494359};\\\", \\\"{x:1521,y:751,t:1528143494374};\\\", \\\"{x:1521,y:750,t:1528143494415};\\\", \\\"{x:1520,y:749,t:1528143494428};\\\", \\\"{x:1520,y:748,t:1528143494479};\\\", \\\"{x:1520,y:747,t:1528143494495};\\\", \\\"{x:1519,y:745,t:1528143494513};\\\", \\\"{x:1519,y:744,t:1528143494529};\\\", \\\"{x:1519,y:743,t:1528143494545};\\\", \\\"{x:1518,y:741,t:1528143494563};\\\", \\\"{x:1518,y:740,t:1528143494590};\\\", \\\"{x:1518,y:738,t:1528143494599};\\\", \\\"{x:1518,y:737,t:1528143494623};\\\", \\\"{x:1518,y:735,t:1528143494630};\\\", \\\"{x:1518,y:734,t:1528143494645};\\\", \\\"{x:1518,y:733,t:1528143494662};\\\", \\\"{x:1518,y:732,t:1528143494679};\\\", \\\"{x:1518,y:731,t:1528143494694};\\\", \\\"{x:1518,y:730,t:1528143494711};\\\", \\\"{x:1518,y:729,t:1528143494729};\\\", \\\"{x:1518,y:726,t:1528143494745};\\\", \\\"{x:1518,y:725,t:1528143494766};\\\", \\\"{x:1518,y:724,t:1528143494779};\\\", \\\"{x:1518,y:723,t:1528143494795};\\\", \\\"{x:1518,y:722,t:1528143494811};\\\", \\\"{x:1518,y:719,t:1528143494829};\\\", \\\"{x:1517,y:718,t:1528143494845};\\\", \\\"{x:1517,y:717,t:1528143494862};\\\", \\\"{x:1516,y:716,t:1528143494878};\\\", \\\"{x:1516,y:715,t:1528143494896};\\\", \\\"{x:1515,y:715,t:1528143494912};\\\", \\\"{x:1515,y:713,t:1528143494929};\\\", \\\"{x:1514,y:711,t:1528143494945};\\\", \\\"{x:1511,y:708,t:1528143494962};\\\", \\\"{x:1510,y:706,t:1528143494979};\\\", \\\"{x:1508,y:703,t:1528143494996};\\\", \\\"{x:1506,y:701,t:1528143495013};\\\", \\\"{x:1505,y:700,t:1528143495029};\\\", \\\"{x:1503,y:698,t:1528143495046};\\\", \\\"{x:1502,y:697,t:1528143495063};\\\", \\\"{x:1499,y:693,t:1528143495079};\\\", \\\"{x:1498,y:691,t:1528143495097};\\\", \\\"{x:1495,y:688,t:1528143495112};\\\", \\\"{x:1491,y:683,t:1528143495129};\\\", \\\"{x:1487,y:678,t:1528143495146};\\\", \\\"{x:1486,y:675,t:1528143495163};\\\", \\\"{x:1484,y:673,t:1528143495179};\\\", \\\"{x:1481,y:670,t:1528143495196};\\\", \\\"{x:1479,y:666,t:1528143495212};\\\", \\\"{x:1476,y:662,t:1528143495229};\\\", \\\"{x:1472,y:651,t:1528143495246};\\\", \\\"{x:1471,y:646,t:1528143495262};\\\", \\\"{x:1470,y:644,t:1528143495279};\\\", \\\"{x:1469,y:642,t:1528143495297};\\\", \\\"{x:1467,y:640,t:1528143495312};\\\", \\\"{x:1466,y:638,t:1528143495329};\\\", \\\"{x:1464,y:636,t:1528143495347};\\\", \\\"{x:1461,y:635,t:1528143495362};\\\", \\\"{x:1459,y:633,t:1528143495379};\\\", \\\"{x:1455,y:631,t:1528143495397};\\\", \\\"{x:1455,y:629,t:1528143495413};\\\", \\\"{x:1453,y:628,t:1528143495429};\\\", \\\"{x:1450,y:623,t:1528143495446};\\\", \\\"{x:1448,y:621,t:1528143495462};\\\", \\\"{x:1446,y:615,t:1528143495479};\\\", \\\"{x:1443,y:610,t:1528143495496};\\\", \\\"{x:1440,y:605,t:1528143495513};\\\", \\\"{x:1438,y:602,t:1528143495529};\\\", \\\"{x:1436,y:599,t:1528143495546};\\\", \\\"{x:1435,y:598,t:1528143495563};\\\", \\\"{x:1433,y:595,t:1528143495579};\\\", \\\"{x:1432,y:594,t:1528143495596};\\\", \\\"{x:1431,y:592,t:1528143495614};\\\", \\\"{x:1430,y:591,t:1528143495630};\\\", \\\"{x:1429,y:590,t:1528143495670};\\\", \\\"{x:1428,y:590,t:1528143495679};\\\", \\\"{x:1426,y:587,t:1528143495696};\\\", \\\"{x:1425,y:584,t:1528143495713};\\\", \\\"{x:1423,y:582,t:1528143495734};\\\", \\\"{x:1422,y:582,t:1528143495746};\\\", \\\"{x:1422,y:580,t:1528143495763};\\\", \\\"{x:1421,y:579,t:1528143495780};\\\", \\\"{x:1419,y:576,t:1528143495797};\\\", \\\"{x:1419,y:574,t:1528143495814};\\\", \\\"{x:1419,y:573,t:1528143495829};\\\", \\\"{x:1418,y:572,t:1528143495845};\\\", \\\"{x:1418,y:570,t:1528143495863};\\\", \\\"{x:1417,y:569,t:1528143495878};\\\", \\\"{x:1416,y:568,t:1528143495896};\\\", \\\"{x:1416,y:567,t:1528143495913};\\\", \\\"{x:1416,y:565,t:1528143495965};\\\", \\\"{x:1416,y:564,t:1528143495990};\\\", \\\"{x:1415,y:564,t:1528143496006};\\\", \\\"{x:1415,y:562,t:1528143496030};\\\", \\\"{x:1414,y:561,t:1528143496062};\\\", \\\"{x:1414,y:559,t:1528143496103};\\\", \\\"{x:1413,y:559,t:1528143496151};\\\", \\\"{x:1411,y:559,t:1528143497006};\\\", \\\"{x:1410,y:559,t:1528143497022};\\\", \\\"{x:1408,y:559,t:1528143497039};\\\", \\\"{x:1407,y:559,t:1528143497078};\\\", \\\"{x:1405,y:559,t:1528143497118};\\\", \\\"{x:1404,y:559,t:1528143497158};\\\", \\\"{x:1403,y:559,t:1528143497191};\\\", \\\"{x:1401,y:561,t:1528143497495};\\\", \\\"{x:1400,y:561,t:1528143497759};\\\", \\\"{x:1399,y:561,t:1528143497783};\\\", \\\"{x:1398,y:561,t:1528143497798};\\\", \\\"{x:1395,y:562,t:1528143497814};\\\", \\\"{x:1388,y:565,t:1528143497831};\\\", \\\"{x:1384,y:567,t:1528143497848};\\\", \\\"{x:1376,y:569,t:1528143497865};\\\", \\\"{x:1368,y:573,t:1528143497881};\\\", \\\"{x:1355,y:579,t:1528143497898};\\\", \\\"{x:1322,y:588,t:1528143497915};\\\", \\\"{x:1265,y:602,t:1528143497932};\\\", \\\"{x:1194,y:614,t:1528143497948};\\\", \\\"{x:1119,y:626,t:1528143497964};\\\", \\\"{x:1061,y:631,t:1528143497981};\\\", \\\"{x:971,y:643,t:1528143497998};\\\", \\\"{x:905,y:648,t:1528143498014};\\\", \\\"{x:849,y:658,t:1528143498031};\\\", \\\"{x:787,y:668,t:1528143498048};\\\", \\\"{x:734,y:675,t:1528143498064};\\\", \\\"{x:691,y:684,t:1528143498081};\\\", \\\"{x:668,y:691,t:1528143498098};\\\", \\\"{x:654,y:695,t:1528143498114};\\\", \\\"{x:648,y:698,t:1528143498131};\\\", \\\"{x:646,y:699,t:1528143498148};\\\", \\\"{x:645,y:699,t:1528143498164};\\\", \\\"{x:644,y:701,t:1528143498182};\\\", \\\"{x:639,y:706,t:1528143498198};\\\", \\\"{x:631,y:714,t:1528143498214};\\\", \\\"{x:628,y:718,t:1528143498231};\\\", \\\"{x:625,y:723,t:1528143498248};\\\", \\\"{x:623,y:727,t:1528143498264};\\\", \\\"{x:619,y:730,t:1528143498281};\\\", \\\"{x:615,y:732,t:1528143498298};\\\", \\\"{x:611,y:735,t:1528143498315};\\\", \\\"{x:606,y:736,t:1528143498331};\\\", \\\"{x:601,y:737,t:1528143498348};\\\", \\\"{x:592,y:737,t:1528143498364};\\\", \\\"{x:582,y:737,t:1528143498382};\\\", \\\"{x:574,y:736,t:1528143498398};\\\", \\\"{x:567,y:734,t:1528143498414};\\\", \\\"{x:564,y:734,t:1528143498431};\\\", \\\"{x:562,y:734,t:1528143498448};\\\", \\\"{x:561,y:734,t:1528143498465};\\\", \\\"{x:558,y:734,t:1528143498482};\\\", \\\"{x:555,y:733,t:1528143498498};\\\", \\\"{x:552,y:733,t:1528143498515};\\\", \\\"{x:551,y:733,t:1528143498531};\\\", \\\"{x:548,y:731,t:1528143498549};\\\", \\\"{x:541,y:729,t:1528143498565};\\\", \\\"{x:529,y:726,t:1528143498581};\\\", \\\"{x:526,y:726,t:1528143498599};\\\", \\\"{x:524,y:725,t:1528143498614};\\\", \\\"{x:523,y:724,t:1528143498637};\\\", \\\"{x:522,y:724,t:1528143498649};\\\", \\\"{x:521,y:724,t:1528143498666};\\\", \\\"{x:521,y:723,t:1528143498709};\\\" ] }, { \\\"rt\\\": 32908, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 621298, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -F -I -O -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:720,t:1528143501910};\\\", \\\"{x:525,y:707,t:1528143501928};\\\", \\\"{x:528,y:697,t:1528143501933};\\\", \\\"{x:530,y:690,t:1528143501950};\\\", \\\"{x:533,y:686,t:1528143501968};\\\", \\\"{x:535,y:684,t:1528143501985};\\\", \\\"{x:536,y:683,t:1528143502000};\\\", \\\"{x:537,y:682,t:1528143502017};\\\", \\\"{x:538,y:682,t:1528143502035};\\\", \\\"{x:542,y:679,t:1528143502050};\\\", \\\"{x:547,y:674,t:1528143502068};\\\", \\\"{x:552,y:667,t:1528143502085};\\\", \\\"{x:556,y:656,t:1528143502102};\\\", \\\"{x:565,y:631,t:1528143502119};\\\", \\\"{x:567,y:618,t:1528143502136};\\\", \\\"{x:571,y:606,t:1528143502151};\\\", \\\"{x:572,y:602,t:1528143502167};\\\", \\\"{x:574,y:598,t:1528143502185};\\\", \\\"{x:574,y:595,t:1528143502202};\\\", \\\"{x:574,y:593,t:1528143502218};\\\", \\\"{x:574,y:591,t:1528143502235};\\\", \\\"{x:575,y:589,t:1528143502251};\\\", \\\"{x:575,y:586,t:1528143502268};\\\", \\\"{x:575,y:580,t:1528143502285};\\\", \\\"{x:576,y:576,t:1528143502301};\\\", \\\"{x:577,y:571,t:1528143502317};\\\", \\\"{x:577,y:559,t:1528143502335};\\\", \\\"{x:577,y:541,t:1528143502353};\\\", \\\"{x:577,y:528,t:1528143502368};\\\", \\\"{x:577,y:520,t:1528143502384};\\\", \\\"{x:577,y:514,t:1528143502402};\\\", \\\"{x:577,y:512,t:1528143502417};\\\", \\\"{x:577,y:511,t:1528143502437};\\\", \\\"{x:578,y:511,t:1528143502469};\\\", \\\"{x:578,y:510,t:1528143504158};\\\", \\\"{x:575,y:508,t:1528143504606};\\\", \\\"{x:568,y:504,t:1528143504621};\\\", \\\"{x:548,y:492,t:1528143504639};\\\", \\\"{x:534,y:486,t:1528143504655};\\\", \\\"{x:518,y:480,t:1528143504671};\\\", \\\"{x:508,y:476,t:1528143504688};\\\", \\\"{x:499,y:472,t:1528143504705};\\\", \\\"{x:495,y:471,t:1528143504721};\\\", \\\"{x:494,y:471,t:1528143504758};\\\", \\\"{x:494,y:470,t:1528143504854};\\\", \\\"{x:494,y:469,t:1528143504872};\\\", \\\"{x:493,y:469,t:1528143504910};\\\", \\\"{x:493,y:468,t:1528143505430};\\\", \\\"{x:494,y:468,t:1528143505519};\\\", \\\"{x:495,y:468,t:1528143505550};\\\", \\\"{x:496,y:468,t:1528143505566};\\\", \\\"{x:497,y:468,t:1528143505598};\\\", \\\"{x:498,y:469,t:1528143505629};\\\", \\\"{x:500,y:469,t:1528143505701};\\\", \\\"{x:500,y:470,t:1528143505709};\\\", \\\"{x:501,y:470,t:1528143505934};\\\", \\\"{x:503,y:470,t:1528143505966};\\\", \\\"{x:504,y:470,t:1528143505982};\\\", \\\"{x:506,y:470,t:1528143505990};\\\", \\\"{x:508,y:470,t:1528143506007};\\\", \\\"{x:510,y:470,t:1528143506023};\\\", \\\"{x:511,y:470,t:1528143506054};\\\", \\\"{x:512,y:470,t:1528143506062};\\\", \\\"{x:513,y:470,t:1528143506078};\\\", \\\"{x:514,y:470,t:1528143506102};\\\", \\\"{x:515,y:470,t:1528143506110};\\\", \\\"{x:516,y:470,t:1528143506124};\\\", \\\"{x:517,y:470,t:1528143506142};\\\", \\\"{x:518,y:470,t:1528143506158};\\\", \\\"{x:519,y:470,t:1528143506173};\\\", \\\"{x:520,y:470,t:1528143506190};\\\", \\\"{x:521,y:470,t:1528143506208};\\\", \\\"{x:524,y:470,t:1528143506223};\\\", \\\"{x:526,y:469,t:1528143506240};\\\", \\\"{x:532,y:469,t:1528143506257};\\\", \\\"{x:539,y:468,t:1528143506274};\\\", \\\"{x:545,y:467,t:1528143506291};\\\", \\\"{x:554,y:467,t:1528143506307};\\\", \\\"{x:558,y:467,t:1528143506324};\\\", \\\"{x:562,y:467,t:1528143506340};\\\", \\\"{x:566,y:467,t:1528143506358};\\\", \\\"{x:571,y:467,t:1528143506374};\\\", \\\"{x:574,y:467,t:1528143506390};\\\", \\\"{x:575,y:466,t:1528143506408};\\\", \\\"{x:577,y:466,t:1528143506430};\\\", \\\"{x:578,y:466,t:1528143506454};\\\", \\\"{x:579,y:466,t:1528143506494};\\\", \\\"{x:579,y:465,t:1528143506510};\\\", \\\"{x:580,y:465,t:1528143506951};\\\", \\\"{x:581,y:465,t:1528143506982};\\\", \\\"{x:583,y:465,t:1528143506997};\\\", \\\"{x:584,y:465,t:1528143507014};\\\", \\\"{x:586,y:465,t:1528143507030};\\\", \\\"{x:587,y:465,t:1528143507062};\\\", \\\"{x:589,y:465,t:1528143507102};\\\", \\\"{x:590,y:465,t:1528143507118};\\\", \\\"{x:592,y:466,t:1528143507134};\\\", \\\"{x:593,y:466,t:1528143507141};\\\", \\\"{x:596,y:466,t:1528143507158};\\\", \\\"{x:598,y:466,t:1528143507175};\\\", \\\"{x:605,y:469,t:1528143507192};\\\", \\\"{x:616,y:473,t:1528143507209};\\\", \\\"{x:626,y:475,t:1528143507225};\\\", \\\"{x:637,y:479,t:1528143507242};\\\", \\\"{x:643,y:480,t:1528143507258};\\\", \\\"{x:649,y:482,t:1528143507274};\\\", \\\"{x:655,y:483,t:1528143507292};\\\", \\\"{x:660,y:483,t:1528143507308};\\\", \\\"{x:663,y:484,t:1528143507325};\\\", \\\"{x:666,y:484,t:1528143507342};\\\", \\\"{x:667,y:484,t:1528143507358};\\\", \\\"{x:669,y:484,t:1528143507375};\\\", \\\"{x:669,y:485,t:1528143507392};\\\", \\\"{x:670,y:486,t:1528143507408};\\\", \\\"{x:671,y:486,t:1528143507425};\\\", \\\"{x:672,y:486,t:1528143507446};\\\", \\\"{x:673,y:489,t:1528143507710};\\\", \\\"{x:673,y:493,t:1528143507726};\\\", \\\"{x:670,y:498,t:1528143507742};\\\", \\\"{x:666,y:503,t:1528143507760};\\\", \\\"{x:664,y:505,t:1528143507777};\\\", \\\"{x:664,y:506,t:1528143507846};\\\", \\\"{x:663,y:507,t:1528143507870};\\\", \\\"{x:663,y:508,t:1528143507999};\\\", \\\"{x:663,y:510,t:1528143508009};\\\", \\\"{x:663,y:513,t:1528143508026};\\\", \\\"{x:663,y:515,t:1528143508043};\\\", \\\"{x:663,y:517,t:1528143508059};\\\", \\\"{x:664,y:519,t:1528143508077};\\\", \\\"{x:664,y:525,t:1528143508095};\\\", \\\"{x:665,y:530,t:1528143508109};\\\", \\\"{x:665,y:534,t:1528143508126};\\\", \\\"{x:665,y:535,t:1528143508138};\\\", \\\"{x:666,y:539,t:1528143508155};\\\", \\\"{x:667,y:542,t:1528143508170};\\\", \\\"{x:669,y:545,t:1528143508188};\\\", \\\"{x:671,y:552,t:1528143508206};\\\", \\\"{x:673,y:555,t:1528143508221};\\\", \\\"{x:675,y:558,t:1528143508239};\\\", \\\"{x:676,y:559,t:1528143508256};\\\", \\\"{x:677,y:560,t:1528143508273};\\\", \\\"{x:678,y:561,t:1528143508290};\\\", \\\"{x:679,y:562,t:1528143508306};\\\", \\\"{x:680,y:563,t:1528143508406};\\\", \\\"{x:681,y:563,t:1528143508424};\\\", \\\"{x:681,y:564,t:1528143508440};\\\", \\\"{x:682,y:565,t:1528143508477};\\\", \\\"{x:683,y:565,t:1528143508494};\\\", \\\"{x:683,y:566,t:1528143508506};\\\", \\\"{x:684,y:566,t:1528143508542};\\\", \\\"{x:686,y:567,t:1528143508557};\\\", \\\"{x:687,y:568,t:1528143508574};\\\", \\\"{x:689,y:569,t:1528143508590};\\\", \\\"{x:692,y:572,t:1528143508607};\\\", \\\"{x:693,y:572,t:1528143508638};\\\", \\\"{x:694,y:572,t:1528143508646};\\\", \\\"{x:696,y:573,t:1528143509046};\\\", \\\"{x:698,y:576,t:1528143509058};\\\", \\\"{x:707,y:581,t:1528143509074};\\\", \\\"{x:714,y:586,t:1528143509091};\\\", \\\"{x:718,y:588,t:1528143509108};\\\", \\\"{x:719,y:588,t:1528143509158};\\\", \\\"{x:720,y:588,t:1528143509278};\\\", \\\"{x:722,y:588,t:1528143509292};\\\", \\\"{x:727,y:590,t:1528143509309};\\\", \\\"{x:734,y:593,t:1528143509325};\\\", \\\"{x:746,y:597,t:1528143509341};\\\", \\\"{x:752,y:599,t:1528143509356};\\\", \\\"{x:758,y:601,t:1528143509374};\\\", \\\"{x:762,y:603,t:1528143509391};\\\", \\\"{x:767,y:605,t:1528143509407};\\\", \\\"{x:770,y:606,t:1528143509424};\\\", \\\"{x:775,y:609,t:1528143509441};\\\", \\\"{x:781,y:610,t:1528143509457};\\\", \\\"{x:787,y:614,t:1528143509474};\\\", \\\"{x:792,y:616,t:1528143509491};\\\", \\\"{x:796,y:618,t:1528143509507};\\\", \\\"{x:801,y:621,t:1528143509524};\\\", \\\"{x:809,y:625,t:1528143509541};\\\", \\\"{x:814,y:628,t:1528143509559};\\\", \\\"{x:822,y:632,t:1528143509574};\\\", \\\"{x:828,y:635,t:1528143509590};\\\", \\\"{x:834,y:638,t:1528143509607};\\\", \\\"{x:835,y:639,t:1528143509625};\\\", \\\"{x:840,y:641,t:1528143509640};\\\", \\\"{x:843,y:642,t:1528143509657};\\\", \\\"{x:846,y:645,t:1528143509674};\\\", \\\"{x:849,y:645,t:1528143509690};\\\", \\\"{x:853,y:647,t:1528143509707};\\\", \\\"{x:854,y:648,t:1528143509724};\\\", \\\"{x:855,y:648,t:1528143509741};\\\", \\\"{x:856,y:649,t:1528143509757};\\\", \\\"{x:857,y:649,t:1528143509774};\\\", \\\"{x:859,y:649,t:1528143509791};\\\", \\\"{x:860,y:649,t:1528143509894};\\\", \\\"{x:861,y:649,t:1528143509910};\\\", \\\"{x:862,y:649,t:1528143510014};\\\", \\\"{x:863,y:649,t:1528143510070};\\\", \\\"{x:864,y:649,t:1528143510077};\\\", \\\"{x:865,y:650,t:1528143510090};\\\", \\\"{x:867,y:651,t:1528143510107};\\\", \\\"{x:871,y:652,t:1528143510124};\\\", \\\"{x:875,y:653,t:1528143510140};\\\", \\\"{x:883,y:655,t:1528143510158};\\\", \\\"{x:889,y:657,t:1528143510174};\\\", \\\"{x:895,y:657,t:1528143510190};\\\", \\\"{x:897,y:659,t:1528143510207};\\\", \\\"{x:898,y:659,t:1528143510224};\\\", \\\"{x:902,y:659,t:1528143510240};\\\", \\\"{x:905,y:662,t:1528143510258};\\\", \\\"{x:911,y:663,t:1528143510274};\\\", \\\"{x:915,y:665,t:1528143510291};\\\", \\\"{x:917,y:666,t:1528143510307};\\\", \\\"{x:919,y:667,t:1528143510325};\\\", \\\"{x:920,y:667,t:1528143510340};\\\", \\\"{x:925,y:670,t:1528143510357};\\\", \\\"{x:929,y:672,t:1528143510374};\\\", \\\"{x:933,y:674,t:1528143510391};\\\", \\\"{x:937,y:676,t:1528143510408};\\\", \\\"{x:940,y:677,t:1528143510424};\\\", \\\"{x:945,y:680,t:1528143510441};\\\", \\\"{x:951,y:681,t:1528143510458};\\\", \\\"{x:955,y:682,t:1528143510475};\\\", \\\"{x:960,y:684,t:1528143510491};\\\", \\\"{x:970,y:685,t:1528143510508};\\\", \\\"{x:987,y:689,t:1528143510525};\\\", \\\"{x:1006,y:694,t:1528143510542};\\\", \\\"{x:1033,y:701,t:1528143510558};\\\", \\\"{x:1044,y:704,t:1528143510575};\\\", \\\"{x:1049,y:706,t:1528143510591};\\\", \\\"{x:1057,y:709,t:1528143510608};\\\", \\\"{x:1063,y:711,t:1528143510625};\\\", \\\"{x:1066,y:712,t:1528143510640};\\\", \\\"{x:1070,y:713,t:1528143510657};\\\", \\\"{x:1072,y:714,t:1528143510674};\\\", \\\"{x:1073,y:714,t:1528143510690};\\\", \\\"{x:1076,y:716,t:1528143510707};\\\", \\\"{x:1079,y:717,t:1528143510724};\\\", \\\"{x:1080,y:717,t:1528143510740};\\\", \\\"{x:1081,y:717,t:1528143510774};\\\", \\\"{x:1082,y:717,t:1528143511094};\\\", \\\"{x:1086,y:717,t:1528143511108};\\\", \\\"{x:1099,y:726,t:1528143511125};\\\", \\\"{x:1110,y:732,t:1528143511141};\\\", \\\"{x:1132,y:743,t:1528143511158};\\\", \\\"{x:1155,y:757,t:1528143511174};\\\", \\\"{x:1178,y:770,t:1528143511191};\\\", \\\"{x:1203,y:781,t:1528143511208};\\\", \\\"{x:1233,y:795,t:1528143511225};\\\", \\\"{x:1254,y:805,t:1528143511241};\\\", \\\"{x:1278,y:815,t:1528143511258};\\\", \\\"{x:1301,y:822,t:1528143511276};\\\", \\\"{x:1324,y:828,t:1528143511291};\\\", \\\"{x:1343,y:833,t:1528143511308};\\\", \\\"{x:1358,y:839,t:1528143511326};\\\", \\\"{x:1374,y:846,t:1528143511342};\\\", \\\"{x:1384,y:850,t:1528143511359};\\\", \\\"{x:1389,y:853,t:1528143511375};\\\", \\\"{x:1391,y:855,t:1528143511391};\\\", \\\"{x:1392,y:855,t:1528143511408};\\\", \\\"{x:1393,y:856,t:1528143511425};\\\", \\\"{x:1394,y:857,t:1528143511470};\\\", \\\"{x:1394,y:858,t:1528143511527};\\\", \\\"{x:1394,y:859,t:1528143511567};\\\", \\\"{x:1394,y:861,t:1528143511647};\\\", \\\"{x:1394,y:862,t:1528143511687};\\\", \\\"{x:1394,y:863,t:1528143511694};\\\", \\\"{x:1394,y:864,t:1528143511708};\\\", \\\"{x:1394,y:865,t:1528143511726};\\\", \\\"{x:1393,y:868,t:1528143511742};\\\", \\\"{x:1391,y:872,t:1528143511759};\\\", \\\"{x:1391,y:875,t:1528143511774};\\\", \\\"{x:1390,y:879,t:1528143511792};\\\", \\\"{x:1390,y:880,t:1528143511815};\\\", \\\"{x:1388,y:882,t:1528143511825};\\\", \\\"{x:1387,y:885,t:1528143511854};\\\", \\\"{x:1387,y:886,t:1528143511862};\\\", \\\"{x:1387,y:888,t:1528143511876};\\\", \\\"{x:1386,y:893,t:1528143511891};\\\", \\\"{x:1384,y:899,t:1528143511909};\\\", \\\"{x:1383,y:900,t:1528143511926};\\\", \\\"{x:1382,y:903,t:1528143511942};\\\", \\\"{x:1381,y:908,t:1528143511958};\\\", \\\"{x:1380,y:913,t:1528143511975};\\\", \\\"{x:1379,y:917,t:1528143511991};\\\", \\\"{x:1379,y:921,t:1528143512008};\\\", \\\"{x:1379,y:924,t:1528143512025};\\\", \\\"{x:1379,y:927,t:1528143512042};\\\", \\\"{x:1379,y:928,t:1528143512058};\\\", \\\"{x:1379,y:930,t:1528143512075};\\\", \\\"{x:1379,y:931,t:1528143512102};\\\", \\\"{x:1379,y:932,t:1528143512119};\\\", \\\"{x:1379,y:933,t:1528143512143};\\\", \\\"{x:1378,y:933,t:1528143512158};\\\", \\\"{x:1378,y:934,t:1528143512174};\\\", \\\"{x:1378,y:935,t:1528143512466};\\\", \\\"{x:1378,y:936,t:1528143512497};\\\", \\\"{x:1378,y:937,t:1528143512529};\\\", \\\"{x:1378,y:939,t:1528143512545};\\\", \\\"{x:1378,y:941,t:1528143512561};\\\", \\\"{x:1378,y:946,t:1528143512578};\\\", \\\"{x:1378,y:950,t:1528143512595};\\\", \\\"{x:1378,y:953,t:1528143512611};\\\", \\\"{x:1378,y:954,t:1528143512628};\\\", \\\"{x:1378,y:955,t:1528143512645};\\\", \\\"{x:1378,y:956,t:1528143512665};\\\", \\\"{x:1377,y:956,t:1528143512785};\\\", \\\"{x:1376,y:956,t:1528143512825};\\\", \\\"{x:1375,y:956,t:1528143512841};\\\", \\\"{x:1374,y:956,t:1528143512888};\\\", \\\"{x:1373,y:956,t:1528143512913};\\\", \\\"{x:1372,y:956,t:1528143512928};\\\", \\\"{x:1371,y:956,t:1528143512952};\\\", \\\"{x:1370,y:956,t:1528143512960};\\\", \\\"{x:1369,y:956,t:1528143512977};\\\", \\\"{x:1365,y:958,t:1528143512994};\\\", \\\"{x:1363,y:960,t:1528143513010};\\\", \\\"{x:1361,y:961,t:1528143513027};\\\", \\\"{x:1359,y:961,t:1528143513045};\\\", \\\"{x:1358,y:961,t:1528143513073};\\\", \\\"{x:1358,y:962,t:1528143513080};\\\", \\\"{x:1356,y:962,t:1528143513186};\\\", \\\"{x:1354,y:963,t:1528143513298};\\\", \\\"{x:1353,y:963,t:1528143513311};\\\", \\\"{x:1352,y:963,t:1528143513328};\\\", \\\"{x:1349,y:963,t:1528143513345};\\\", \\\"{x:1348,y:964,t:1528143513360};\\\", \\\"{x:1347,y:964,t:1528143513377};\\\", \\\"{x:1345,y:964,t:1528143513395};\\\", \\\"{x:1344,y:964,t:1528143513411};\\\", \\\"{x:1343,y:964,t:1528143513428};\\\", \\\"{x:1342,y:964,t:1528143513445};\\\", \\\"{x:1342,y:962,t:1528143513850};\\\", \\\"{x:1342,y:958,t:1528143513861};\\\", \\\"{x:1344,y:949,t:1528143513878};\\\", \\\"{x:1349,y:936,t:1528143513895};\\\", \\\"{x:1354,y:924,t:1528143513911};\\\", \\\"{x:1360,y:911,t:1528143513928};\\\", \\\"{x:1368,y:885,t:1528143513945};\\\", \\\"{x:1370,y:863,t:1528143513961};\\\", \\\"{x:1371,y:846,t:1528143513978};\\\", \\\"{x:1373,y:826,t:1528143513995};\\\", \\\"{x:1375,y:815,t:1528143514011};\\\", \\\"{x:1378,y:804,t:1528143514028};\\\", \\\"{x:1378,y:794,t:1528143514045};\\\", \\\"{x:1379,y:785,t:1528143514061};\\\", \\\"{x:1380,y:781,t:1528143514078};\\\", \\\"{x:1383,y:773,t:1528143514095};\\\", \\\"{x:1384,y:761,t:1528143514113};\\\", \\\"{x:1388,y:748,t:1528143514128};\\\", \\\"{x:1394,y:729,t:1528143514144};\\\", \\\"{x:1399,y:715,t:1528143514160};\\\", \\\"{x:1403,y:707,t:1528143514177};\\\", \\\"{x:1407,y:702,t:1528143514194};\\\", \\\"{x:1408,y:698,t:1528143514210};\\\", \\\"{x:1410,y:693,t:1528143514227};\\\", \\\"{x:1411,y:692,t:1528143514244};\\\", \\\"{x:1411,y:690,t:1528143514260};\\\", \\\"{x:1412,y:688,t:1528143514277};\\\", \\\"{x:1412,y:686,t:1528143514295};\\\", \\\"{x:1412,y:679,t:1528143514311};\\\", \\\"{x:1412,y:668,t:1528143514327};\\\", \\\"{x:1411,y:653,t:1528143514345};\\\", \\\"{x:1405,y:640,t:1528143514360};\\\", \\\"{x:1394,y:622,t:1528143514377};\\\", \\\"{x:1382,y:611,t:1528143514394};\\\", \\\"{x:1370,y:602,t:1528143514411};\\\", \\\"{x:1355,y:594,t:1528143514427};\\\", \\\"{x:1338,y:584,t:1528143514445};\\\", \\\"{x:1319,y:569,t:1528143514460};\\\", \\\"{x:1307,y:559,t:1528143514478};\\\", \\\"{x:1296,y:543,t:1528143514495};\\\", \\\"{x:1285,y:527,t:1528143514511};\\\", \\\"{x:1282,y:519,t:1528143514528};\\\", \\\"{x:1281,y:514,t:1528143514545};\\\", \\\"{x:1280,y:511,t:1528143514561};\\\", \\\"{x:1280,y:510,t:1528143514578};\\\", \\\"{x:1280,y:509,t:1528143514595};\\\", \\\"{x:1280,y:507,t:1528143514617};\\\", \\\"{x:1281,y:507,t:1528143514628};\\\", \\\"{x:1285,y:505,t:1528143514645};\\\", \\\"{x:1290,y:503,t:1528143514661};\\\", \\\"{x:1297,y:500,t:1528143514678};\\\", \\\"{x:1306,y:497,t:1528143514694};\\\", \\\"{x:1318,y:493,t:1528143514711};\\\", \\\"{x:1327,y:486,t:1528143514728};\\\", \\\"{x:1335,y:480,t:1528143514744};\\\", \\\"{x:1338,y:478,t:1528143514761};\\\", \\\"{x:1339,y:478,t:1528143514800};\\\", \\\"{x:1338,y:478,t:1528143514905};\\\", \\\"{x:1337,y:478,t:1528143514913};\\\", \\\"{x:1336,y:480,t:1528143514928};\\\", \\\"{x:1334,y:482,t:1528143514945};\\\", \\\"{x:1332,y:483,t:1528143514960};\\\", \\\"{x:1330,y:485,t:1528143514978};\\\", \\\"{x:1328,y:488,t:1528143514995};\\\", \\\"{x:1326,y:493,t:1528143515011};\\\", \\\"{x:1323,y:498,t:1528143515028};\\\", \\\"{x:1320,y:502,t:1528143515045};\\\", \\\"{x:1319,y:503,t:1528143515061};\\\", \\\"{x:1318,y:505,t:1528143515077};\\\", \\\"{x:1318,y:506,t:1528143515094};\\\", \\\"{x:1317,y:507,t:1528143515110};\\\", \\\"{x:1316,y:508,t:1528143515127};\\\", \\\"{x:1315,y:508,t:1528143515497};\\\", \\\"{x:1314,y:509,t:1528143515511};\\\", \\\"{x:1313,y:511,t:1528143515528};\\\", \\\"{x:1313,y:512,t:1528143515545};\\\", \\\"{x:1311,y:513,t:1528143515561};\\\", \\\"{x:1311,y:514,t:1528143515648};\\\", \\\"{x:1310,y:514,t:1528143515721};\\\", \\\"{x:1310,y:515,t:1528143515745};\\\", \\\"{x:1309,y:517,t:1528143515761};\\\", \\\"{x:1308,y:518,t:1528143515778};\\\", \\\"{x:1308,y:519,t:1528143515795};\\\", \\\"{x:1307,y:520,t:1528143515849};\\\", \\\"{x:1307,y:521,t:1528143515873};\\\", \\\"{x:1305,y:523,t:1528143515881};\\\", \\\"{x:1304,y:525,t:1528143515894};\\\", \\\"{x:1303,y:531,t:1528143515911};\\\", \\\"{x:1299,y:536,t:1528143515928};\\\", \\\"{x:1295,y:546,t:1528143515945};\\\", \\\"{x:1290,y:554,t:1528143515961};\\\", \\\"{x:1288,y:558,t:1528143515978};\\\", \\\"{x:1287,y:562,t:1528143515995};\\\", \\\"{x:1287,y:563,t:1528143516011};\\\", \\\"{x:1286,y:565,t:1528143516028};\\\", \\\"{x:1285,y:567,t:1528143516045};\\\", \\\"{x:1284,y:569,t:1528143516061};\\\", \\\"{x:1283,y:573,t:1528143516077};\\\", \\\"{x:1281,y:580,t:1528143516095};\\\", \\\"{x:1279,y:585,t:1528143516111};\\\", \\\"{x:1279,y:590,t:1528143516128};\\\", \\\"{x:1276,y:598,t:1528143516144};\\\", \\\"{x:1273,y:602,t:1528143516160};\\\", \\\"{x:1272,y:606,t:1528143516178};\\\", \\\"{x:1271,y:607,t:1528143516195};\\\", \\\"{x:1271,y:608,t:1528143516211};\\\", \\\"{x:1270,y:609,t:1528143516227};\\\", \\\"{x:1270,y:610,t:1528143516312};\\\", \\\"{x:1270,y:611,t:1528143516327};\\\", \\\"{x:1269,y:618,t:1528143516344};\\\", \\\"{x:1265,y:627,t:1528143516360};\\\", \\\"{x:1262,y:632,t:1528143516378};\\\", \\\"{x:1259,y:639,t:1528143516394};\\\", \\\"{x:1257,y:645,t:1528143516411};\\\", \\\"{x:1255,y:647,t:1528143516428};\\\", \\\"{x:1253,y:650,t:1528143516444};\\\", \\\"{x:1252,y:654,t:1528143516461};\\\", \\\"{x:1251,y:656,t:1528143516477};\\\", \\\"{x:1250,y:657,t:1528143516494};\\\", \\\"{x:1249,y:659,t:1528143516511};\\\", \\\"{x:1249,y:660,t:1528143516529};\\\", \\\"{x:1248,y:662,t:1528143516552};\\\", \\\"{x:1247,y:663,t:1528143516561};\\\", \\\"{x:1246,y:664,t:1528143516578};\\\", \\\"{x:1246,y:665,t:1528143516595};\\\", \\\"{x:1246,y:666,t:1528143516785};\\\", \\\"{x:1244,y:667,t:1528143516800};\\\", \\\"{x:1244,y:668,t:1528143516811};\\\", \\\"{x:1244,y:669,t:1528143516828};\\\", \\\"{x:1243,y:670,t:1528143516850};\\\", \\\"{x:1243,y:671,t:1528143516985};\\\", \\\"{x:1242,y:673,t:1528143516995};\\\", \\\"{x:1242,y:674,t:1528143517017};\\\", \\\"{x:1242,y:676,t:1528143517033};\\\", \\\"{x:1244,y:671,t:1528143517169};\\\", \\\"{x:1249,y:664,t:1528143517178};\\\", \\\"{x:1258,y:647,t:1528143517195};\\\", \\\"{x:1268,y:632,t:1528143517211};\\\", \\\"{x:1279,y:617,t:1528143517228};\\\", \\\"{x:1288,y:604,t:1528143517245};\\\", \\\"{x:1297,y:595,t:1528143517261};\\\", \\\"{x:1301,y:590,t:1528143517279};\\\", \\\"{x:1306,y:584,t:1528143517295};\\\", \\\"{x:1311,y:579,t:1528143517311};\\\", \\\"{x:1315,y:572,t:1528143517328};\\\", \\\"{x:1326,y:560,t:1528143517344};\\\", \\\"{x:1333,y:550,t:1528143517361};\\\", \\\"{x:1336,y:546,t:1528143517378};\\\", \\\"{x:1337,y:543,t:1528143517395};\\\", \\\"{x:1338,y:541,t:1528143517411};\\\", \\\"{x:1338,y:539,t:1528143517428};\\\", \\\"{x:1338,y:538,t:1528143517445};\\\", \\\"{x:1339,y:536,t:1528143517461};\\\", \\\"{x:1339,y:535,t:1528143517481};\\\", \\\"{x:1340,y:533,t:1528143517495};\\\", \\\"{x:1340,y:530,t:1528143517511};\\\", \\\"{x:1340,y:529,t:1528143517528};\\\", \\\"{x:1340,y:528,t:1528143517544};\\\", \\\"{x:1337,y:525,t:1528143517561};\\\", \\\"{x:1326,y:521,t:1528143517578};\\\", \\\"{x:1317,y:520,t:1528143517595};\\\", \\\"{x:1309,y:515,t:1528143517611};\\\", \\\"{x:1299,y:513,t:1528143517628};\\\", \\\"{x:1298,y:513,t:1528143517645};\\\", \\\"{x:1296,y:513,t:1528143517661};\\\", \\\"{x:1295,y:513,t:1528143517762};\\\", \\\"{x:1296,y:514,t:1528143517785};\\\", \\\"{x:1297,y:515,t:1528143517795};\\\", \\\"{x:1298,y:515,t:1528143517811};\\\", \\\"{x:1300,y:516,t:1528143517841};\\\", \\\"{x:1301,y:516,t:1528143517865};\\\", \\\"{x:1302,y:516,t:1528143517881};\\\", \\\"{x:1303,y:517,t:1528143517896};\\\", \\\"{x:1303,y:518,t:1528143517921};\\\", \\\"{x:1304,y:518,t:1528143517944};\\\", \\\"{x:1305,y:519,t:1528143517961};\\\", \\\"{x:1306,y:520,t:1528143517978};\\\", \\\"{x:1307,y:524,t:1528143517995};\\\", \\\"{x:1309,y:530,t:1528143518011};\\\", \\\"{x:1309,y:536,t:1528143518028};\\\", \\\"{x:1310,y:543,t:1528143518045};\\\", \\\"{x:1310,y:550,t:1528143518061};\\\", \\\"{x:1310,y:558,t:1528143518078};\\\", \\\"{x:1310,y:567,t:1528143518096};\\\", \\\"{x:1311,y:572,t:1528143518111};\\\", \\\"{x:1311,y:576,t:1528143518128};\\\", \\\"{x:1311,y:580,t:1528143518145};\\\", \\\"{x:1311,y:585,t:1528143518161};\\\", \\\"{x:1311,y:590,t:1528143518178};\\\", \\\"{x:1311,y:595,t:1528143518195};\\\", \\\"{x:1311,y:601,t:1528143518211};\\\", \\\"{x:1312,y:606,t:1528143518228};\\\", \\\"{x:1313,y:610,t:1528143518246};\\\", \\\"{x:1313,y:614,t:1528143518262};\\\", \\\"{x:1314,y:618,t:1528143518277};\\\", \\\"{x:1314,y:623,t:1528143518295};\\\", \\\"{x:1314,y:632,t:1528143518311};\\\", \\\"{x:1314,y:640,t:1528143518329};\\\", \\\"{x:1314,y:649,t:1528143518345};\\\", \\\"{x:1314,y:657,t:1528143518361};\\\", \\\"{x:1314,y:664,t:1528143518378};\\\", \\\"{x:1316,y:670,t:1528143518395};\\\", \\\"{x:1316,y:676,t:1528143518411};\\\", \\\"{x:1316,y:682,t:1528143518428};\\\", \\\"{x:1316,y:689,t:1528143518446};\\\", \\\"{x:1312,y:697,t:1528143518461};\\\", \\\"{x:1308,y:708,t:1528143518478};\\\", \\\"{x:1305,y:714,t:1528143518495};\\\", \\\"{x:1303,y:720,t:1528143518511};\\\", \\\"{x:1303,y:722,t:1528143518528};\\\", \\\"{x:1302,y:724,t:1528143518545};\\\", \\\"{x:1302,y:726,t:1528143518561};\\\", \\\"{x:1301,y:729,t:1528143518578};\\\", \\\"{x:1300,y:731,t:1528143518595};\\\", \\\"{x:1300,y:732,t:1528143518611};\\\", \\\"{x:1300,y:734,t:1528143518628};\\\", \\\"{x:1299,y:737,t:1528143518645};\\\", \\\"{x:1299,y:741,t:1528143518660};\\\", \\\"{x:1299,y:743,t:1528143518678};\\\", \\\"{x:1299,y:747,t:1528143518694};\\\", \\\"{x:1298,y:750,t:1528143518711};\\\", \\\"{x:1296,y:754,t:1528143518727};\\\", \\\"{x:1296,y:757,t:1528143518744};\\\", \\\"{x:1296,y:760,t:1528143518761};\\\", \\\"{x:1296,y:762,t:1528143518777};\\\", \\\"{x:1296,y:764,t:1528143518795};\\\", \\\"{x:1296,y:767,t:1528143518811};\\\", \\\"{x:1296,y:771,t:1528143518827};\\\", \\\"{x:1296,y:775,t:1528143518844};\\\", \\\"{x:1296,y:780,t:1528143518860};\\\", \\\"{x:1296,y:782,t:1528143518878};\\\", \\\"{x:1295,y:785,t:1528143518894};\\\", \\\"{x:1294,y:787,t:1528143518911};\\\", \\\"{x:1294,y:789,t:1528143518928};\\\", \\\"{x:1294,y:795,t:1528143518944};\\\", \\\"{x:1294,y:801,t:1528143518961};\\\", \\\"{x:1293,y:805,t:1528143518979};\\\", \\\"{x:1292,y:809,t:1528143518995};\\\", \\\"{x:1291,y:811,t:1528143519010};\\\", \\\"{x:1291,y:812,t:1528143519028};\\\", \\\"{x:1291,y:815,t:1528143519045};\\\", \\\"{x:1291,y:816,t:1528143519060};\\\", \\\"{x:1291,y:819,t:1528143519078};\\\", \\\"{x:1291,y:822,t:1528143519095};\\\", \\\"{x:1289,y:825,t:1528143519111};\\\", \\\"{x:1289,y:828,t:1528143519128};\\\", \\\"{x:1288,y:831,t:1528143519144};\\\", \\\"{x:1288,y:833,t:1528143519161};\\\", \\\"{x:1288,y:837,t:1528143519178};\\\", \\\"{x:1287,y:842,t:1528143519195};\\\", \\\"{x:1286,y:845,t:1528143519211};\\\", \\\"{x:1286,y:847,t:1528143519228};\\\", \\\"{x:1285,y:851,t:1528143519245};\\\", \\\"{x:1284,y:855,t:1528143519261};\\\", \\\"{x:1284,y:857,t:1528143519278};\\\", \\\"{x:1283,y:858,t:1528143519295};\\\", \\\"{x:1283,y:860,t:1528143519311};\\\", \\\"{x:1283,y:864,t:1528143519328};\\\", \\\"{x:1282,y:870,t:1528143519344};\\\", \\\"{x:1281,y:874,t:1528143519360};\\\", \\\"{x:1281,y:877,t:1528143519378};\\\", \\\"{x:1281,y:880,t:1528143519395};\\\", \\\"{x:1279,y:883,t:1528143519411};\\\", \\\"{x:1279,y:886,t:1528143519429};\\\", \\\"{x:1279,y:889,t:1528143519445};\\\", \\\"{x:1278,y:891,t:1528143519462};\\\", \\\"{x:1278,y:892,t:1528143519478};\\\", \\\"{x:1278,y:895,t:1528143519495};\\\", \\\"{x:1277,y:897,t:1528143519512};\\\", \\\"{x:1277,y:900,t:1528143519529};\\\", \\\"{x:1277,y:902,t:1528143519544};\\\", \\\"{x:1277,y:905,t:1528143519561};\\\", \\\"{x:1276,y:908,t:1528143519578};\\\", \\\"{x:1275,y:909,t:1528143519596};\\\", \\\"{x:1275,y:911,t:1528143519611};\\\", \\\"{x:1275,y:913,t:1528143519628};\\\", \\\"{x:1275,y:914,t:1528143519645};\\\", \\\"{x:1275,y:917,t:1528143519662};\\\", \\\"{x:1275,y:919,t:1528143519678};\\\", \\\"{x:1275,y:921,t:1528143519695};\\\", \\\"{x:1275,y:923,t:1528143519711};\\\", \\\"{x:1275,y:924,t:1528143519728};\\\", \\\"{x:1275,y:926,t:1528143519745};\\\", \\\"{x:1275,y:927,t:1528143519769};\\\", \\\"{x:1275,y:929,t:1528143519785};\\\", \\\"{x:1275,y:930,t:1528143519795};\\\", \\\"{x:1275,y:932,t:1528143519811};\\\", \\\"{x:1275,y:933,t:1528143519829};\\\", \\\"{x:1275,y:935,t:1528143519846};\\\", \\\"{x:1275,y:936,t:1528143519873};\\\", \\\"{x:1275,y:938,t:1528143519930};\\\", \\\"{x:1275,y:939,t:1528143519960};\\\", \\\"{x:1275,y:941,t:1528143520025};\\\", \\\"{x:1275,y:935,t:1528143520160};\\\", \\\"{x:1275,y:920,t:1528143520168};\\\", \\\"{x:1276,y:903,t:1528143520177};\\\", \\\"{x:1284,y:839,t:1528143520194};\\\", \\\"{x:1298,y:731,t:1528143520211};\\\", \\\"{x:1316,y:582,t:1528143520228};\\\", \\\"{x:1318,y:457,t:1528143520245};\\\", \\\"{x:1318,y:377,t:1528143520260};\\\", \\\"{x:1318,y:349,t:1528143520278};\\\", \\\"{x:1318,y:323,t:1528143520295};\\\", \\\"{x:1318,y:304,t:1528143520311};\\\", \\\"{x:1318,y:296,t:1528143520328};\\\", \\\"{x:1318,y:293,t:1528143520344};\\\", \\\"{x:1318,y:294,t:1528143520506};\\\", \\\"{x:1318,y:305,t:1528143520513};\\\", \\\"{x:1317,y:316,t:1528143520529};\\\", \\\"{x:1304,y:360,t:1528143520545};\\\", \\\"{x:1296,y:391,t:1528143520561};\\\", \\\"{x:1292,y:402,t:1528143520578};\\\", \\\"{x:1292,y:409,t:1528143520595};\\\", \\\"{x:1291,y:411,t:1528143520611};\\\", \\\"{x:1291,y:412,t:1528143520628};\\\", \\\"{x:1291,y:413,t:1528143520645};\\\", \\\"{x:1291,y:414,t:1528143520754};\\\", \\\"{x:1291,y:415,t:1528143520761};\\\", \\\"{x:1291,y:417,t:1528143520778};\\\", \\\"{x:1291,y:422,t:1528143520795};\\\", \\\"{x:1291,y:427,t:1528143520811};\\\", \\\"{x:1291,y:433,t:1528143520828};\\\", \\\"{x:1291,y:439,t:1528143520845};\\\", \\\"{x:1291,y:442,t:1528143520861};\\\", \\\"{x:1291,y:446,t:1528143520878};\\\", \\\"{x:1291,y:447,t:1528143520904};\\\", \\\"{x:1291,y:448,t:1528143520911};\\\", \\\"{x:1291,y:449,t:1528143520928};\\\", \\\"{x:1291,y:451,t:1528143520943};\\\", \\\"{x:1291,y:455,t:1528143520960};\\\", \\\"{x:1291,y:463,t:1528143520978};\\\", \\\"{x:1291,y:470,t:1528143520995};\\\", \\\"{x:1291,y:476,t:1528143521011};\\\", \\\"{x:1291,y:482,t:1528143521027};\\\", \\\"{x:1291,y:486,t:1528143521044};\\\", \\\"{x:1291,y:491,t:1528143521061};\\\", \\\"{x:1291,y:499,t:1528143521078};\\\", \\\"{x:1293,y:505,t:1528143521095};\\\", \\\"{x:1293,y:510,t:1528143521111};\\\", \\\"{x:1294,y:518,t:1528143521128};\\\", \\\"{x:1295,y:529,t:1528143521144};\\\", \\\"{x:1297,y:535,t:1528143521161};\\\", \\\"{x:1297,y:538,t:1528143521178};\\\", \\\"{x:1297,y:542,t:1528143521195};\\\", \\\"{x:1297,y:548,t:1528143521211};\\\", \\\"{x:1298,y:554,t:1528143521228};\\\", \\\"{x:1298,y:559,t:1528143521245};\\\", \\\"{x:1298,y:563,t:1528143521261};\\\", \\\"{x:1298,y:567,t:1528143521278};\\\", \\\"{x:1298,y:572,t:1528143521295};\\\", \\\"{x:1298,y:574,t:1528143521310};\\\", \\\"{x:1298,y:577,t:1528143521328};\\\", \\\"{x:1298,y:582,t:1528143521344};\\\", \\\"{x:1298,y:585,t:1528143521360};\\\", \\\"{x:1298,y:589,t:1528143521378};\\\", \\\"{x:1298,y:593,t:1528143521395};\\\", \\\"{x:1298,y:596,t:1528143521411};\\\", \\\"{x:1299,y:600,t:1528143521428};\\\", \\\"{x:1299,y:603,t:1528143521446};\\\", \\\"{x:1299,y:605,t:1528143521461};\\\", \\\"{x:1299,y:607,t:1528143521478};\\\", \\\"{x:1299,y:609,t:1528143521495};\\\", \\\"{x:1299,y:612,t:1528143521511};\\\", \\\"{x:1299,y:615,t:1528143521528};\\\", \\\"{x:1299,y:618,t:1528143521545};\\\", \\\"{x:1299,y:620,t:1528143521561};\\\", \\\"{x:1299,y:622,t:1528143521578};\\\", \\\"{x:1299,y:624,t:1528143521595};\\\", \\\"{x:1299,y:625,t:1528143521611};\\\", \\\"{x:1299,y:627,t:1528143521628};\\\", \\\"{x:1299,y:630,t:1528143521645};\\\", \\\"{x:1300,y:631,t:1528143521662};\\\", \\\"{x:1300,y:633,t:1528143521679};\\\", \\\"{x:1301,y:643,t:1528143521695};\\\", \\\"{x:1301,y:663,t:1528143521712};\\\", \\\"{x:1301,y:672,t:1528143521729};\\\", \\\"{x:1301,y:673,t:1528143521745};\\\", \\\"{x:1302,y:673,t:1528143522833};\\\", \\\"{x:1302,y:672,t:1528143522873};\\\", \\\"{x:1302,y:671,t:1528143522881};\\\", \\\"{x:1303,y:669,t:1528143522897};\\\", \\\"{x:1303,y:667,t:1528143522937};\\\", \\\"{x:1304,y:666,t:1528143522953};\\\", \\\"{x:1304,y:665,t:1528143522962};\\\", \\\"{x:1305,y:663,t:1528143522978};\\\", \\\"{x:1306,y:662,t:1528143522996};\\\", \\\"{x:1306,y:661,t:1528143523024};\\\", \\\"{x:1306,y:660,t:1528143523033};\\\", \\\"{x:1306,y:658,t:1528143523047};\\\", \\\"{x:1307,y:656,t:1528143523062};\\\", \\\"{x:1308,y:653,t:1528143523078};\\\", \\\"{x:1308,y:651,t:1528143523095};\\\", \\\"{x:1308,y:649,t:1528143523112};\\\", \\\"{x:1308,y:648,t:1528143523128};\\\", \\\"{x:1311,y:644,t:1528143523145};\\\", \\\"{x:1312,y:643,t:1528143523162};\\\", \\\"{x:1313,y:642,t:1528143523593};\\\", \\\"{x:1314,y:643,t:1528143523601};\\\", \\\"{x:1314,y:645,t:1528143523613};\\\", \\\"{x:1314,y:649,t:1528143523628};\\\", \\\"{x:1314,y:652,t:1528143523646};\\\", \\\"{x:1314,y:654,t:1528143523663};\\\", \\\"{x:1314,y:655,t:1528143523678};\\\", \\\"{x:1314,y:656,t:1528143523695};\\\", \\\"{x:1314,y:657,t:1528143523712};\\\", \\\"{x:1314,y:659,t:1528143523728};\\\", \\\"{x:1315,y:661,t:1528143523744};\\\", \\\"{x:1315,y:663,t:1528143523762};\\\", \\\"{x:1315,y:666,t:1528143523779};\\\", \\\"{x:1316,y:668,t:1528143523795};\\\", \\\"{x:1316,y:672,t:1528143523813};\\\", \\\"{x:1316,y:676,t:1528143523829};\\\", \\\"{x:1318,y:682,t:1528143523845};\\\", \\\"{x:1318,y:688,t:1528143523863};\\\", \\\"{x:1318,y:692,t:1528143523878};\\\", \\\"{x:1318,y:694,t:1528143523895};\\\", \\\"{x:1318,y:697,t:1528143523913};\\\", \\\"{x:1318,y:698,t:1528143523929};\\\", \\\"{x:1318,y:700,t:1528143523945};\\\", \\\"{x:1319,y:703,t:1528143523962};\\\", \\\"{x:1319,y:704,t:1528143523979};\\\", \\\"{x:1319,y:705,t:1528143523996};\\\", \\\"{x:1319,y:708,t:1528143524012};\\\", \\\"{x:1319,y:710,t:1528143524028};\\\", \\\"{x:1319,y:713,t:1528143524045};\\\", \\\"{x:1319,y:717,t:1528143524062};\\\", \\\"{x:1318,y:722,t:1528143524078};\\\", \\\"{x:1317,y:727,t:1528143524095};\\\", \\\"{x:1315,y:734,t:1528143524112};\\\", \\\"{x:1314,y:741,t:1528143524128};\\\", \\\"{x:1314,y:744,t:1528143524145};\\\", \\\"{x:1314,y:745,t:1528143524161};\\\", \\\"{x:1314,y:747,t:1528143524178};\\\", \\\"{x:1313,y:748,t:1528143524195};\\\", \\\"{x:1313,y:749,t:1528143524216};\\\", \\\"{x:1313,y:750,t:1528143524232};\\\", \\\"{x:1313,y:751,t:1528143524245};\\\", \\\"{x:1313,y:754,t:1528143524262};\\\", \\\"{x:1310,y:758,t:1528143524278};\\\", \\\"{x:1310,y:762,t:1528143524295};\\\", \\\"{x:1309,y:773,t:1528143524312};\\\", \\\"{x:1307,y:781,t:1528143524329};\\\", \\\"{x:1306,y:785,t:1528143524344};\\\", \\\"{x:1306,y:786,t:1528143524362};\\\", \\\"{x:1306,y:791,t:1528143524378};\\\", \\\"{x:1306,y:795,t:1528143524395};\\\", \\\"{x:1306,y:800,t:1528143524412};\\\", \\\"{x:1305,y:807,t:1528143524428};\\\", \\\"{x:1305,y:811,t:1528143524445};\\\", \\\"{x:1303,y:818,t:1528143524462};\\\", \\\"{x:1302,y:822,t:1528143524478};\\\", \\\"{x:1302,y:828,t:1528143524496};\\\", \\\"{x:1302,y:838,t:1528143524513};\\\", \\\"{x:1301,y:842,t:1528143524528};\\\", \\\"{x:1301,y:844,t:1528143524545};\\\", \\\"{x:1301,y:845,t:1528143524561};\\\", \\\"{x:1301,y:834,t:1528143524665};\\\", \\\"{x:1301,y:817,t:1528143524678};\\\", \\\"{x:1301,y:789,t:1528143524695};\\\", \\\"{x:1301,y:747,t:1528143524714};\\\", \\\"{x:1301,y:728,t:1528143524729};\\\", \\\"{x:1301,y:721,t:1528143524745};\\\", \\\"{x:1301,y:715,t:1528143524763};\\\", \\\"{x:1301,y:706,t:1528143524779};\\\", \\\"{x:1301,y:696,t:1528143524796};\\\", \\\"{x:1303,y:685,t:1528143524813};\\\", \\\"{x:1305,y:669,t:1528143524828};\\\", \\\"{x:1305,y:663,t:1528143524845};\\\", \\\"{x:1306,y:661,t:1528143524861};\\\", \\\"{x:1307,y:659,t:1528143524877};\\\", \\\"{x:1307,y:657,t:1528143524895};\\\", \\\"{x:1307,y:656,t:1528143524920};\\\", \\\"{x:1308,y:654,t:1528143524960};\\\", \\\"{x:1308,y:653,t:1528143524992};\\\", \\\"{x:1308,y:651,t:1528143525033};\\\", \\\"{x:1309,y:651,t:1528143525056};\\\", \\\"{x:1311,y:655,t:1528143525161};\\\", \\\"{x:1325,y:685,t:1528143525178};\\\", \\\"{x:1334,y:710,t:1528143525195};\\\", \\\"{x:1340,y:731,t:1528143525213};\\\", \\\"{x:1345,y:755,t:1528143525228};\\\", \\\"{x:1355,y:785,t:1528143525246};\\\", \\\"{x:1377,y:830,t:1528143525262};\\\", \\\"{x:1401,y:874,t:1528143525278};\\\", \\\"{x:1419,y:908,t:1528143525296};\\\", \\\"{x:1431,y:931,t:1528143525313};\\\", \\\"{x:1436,y:945,t:1528143525329};\\\", \\\"{x:1441,y:955,t:1528143525345};\\\", \\\"{x:1445,y:970,t:1528143525362};\\\", \\\"{x:1449,y:983,t:1528143525379};\\\", \\\"{x:1455,y:999,t:1528143525395};\\\", \\\"{x:1457,y:1010,t:1528143525412};\\\", \\\"{x:1460,y:1019,t:1528143525429};\\\", \\\"{x:1461,y:1024,t:1528143525445};\\\", \\\"{x:1462,y:1025,t:1528143525463};\\\", \\\"{x:1462,y:1026,t:1528143525529};\\\", \\\"{x:1455,y:982,t:1528143525545};\\\", \\\"{x:1445,y:914,t:1528143525562};\\\", \\\"{x:1428,y:848,t:1528143525578};\\\", \\\"{x:1414,y:801,t:1528143525596};\\\", \\\"{x:1409,y:782,t:1528143525612};\\\", \\\"{x:1407,y:775,t:1528143525628};\\\", \\\"{x:1405,y:771,t:1528143525645};\\\", \\\"{x:1405,y:769,t:1528143525662};\\\", \\\"{x:1405,y:767,t:1528143525678};\\\", \\\"{x:1405,y:766,t:1528143525695};\\\", \\\"{x:1405,y:762,t:1528143525711};\\\", \\\"{x:1402,y:756,t:1528143525728};\\\", \\\"{x:1401,y:752,t:1528143525745};\\\", \\\"{x:1399,y:748,t:1528143525762};\\\", \\\"{x:1397,y:747,t:1528143525833};\\\", \\\"{x:1394,y:746,t:1528143525845};\\\", \\\"{x:1391,y:743,t:1528143525862};\\\", \\\"{x:1387,y:739,t:1528143525878};\\\", \\\"{x:1382,y:732,t:1528143525894};\\\", \\\"{x:1378,y:727,t:1528143525912};\\\", \\\"{x:1376,y:723,t:1528143525928};\\\", \\\"{x:1373,y:716,t:1528143525945};\\\", \\\"{x:1370,y:708,t:1528143525962};\\\", \\\"{x:1369,y:704,t:1528143525978};\\\", \\\"{x:1366,y:695,t:1528143525995};\\\", \\\"{x:1365,y:686,t:1528143526012};\\\", \\\"{x:1365,y:683,t:1528143526028};\\\", \\\"{x:1365,y:680,t:1528143526045};\\\", \\\"{x:1365,y:679,t:1528143526062};\\\", \\\"{x:1363,y:678,t:1528143526078};\\\", \\\"{x:1363,y:676,t:1528143526095};\\\", \\\"{x:1362,y:673,t:1528143526112};\\\", \\\"{x:1362,y:669,t:1528143526128};\\\", \\\"{x:1361,y:663,t:1528143526145};\\\", \\\"{x:1361,y:659,t:1528143526162};\\\", \\\"{x:1360,y:656,t:1528143526178};\\\", \\\"{x:1359,y:652,t:1528143526195};\\\", \\\"{x:1358,y:651,t:1528143526212};\\\", \\\"{x:1357,y:650,t:1528143526249};\\\", \\\"{x:1356,y:649,t:1528143526585};\\\", \\\"{x:1354,y:649,t:1528143526595};\\\", \\\"{x:1344,y:644,t:1528143526612};\\\", \\\"{x:1315,y:632,t:1528143526629};\\\", \\\"{x:1233,y:617,t:1528143526645};\\\", \\\"{x:1138,y:602,t:1528143526661};\\\", \\\"{x:1054,y:598,t:1528143526678};\\\", \\\"{x:1011,y:595,t:1528143526695};\\\", \\\"{x:954,y:594,t:1528143526712};\\\", \\\"{x:935,y:593,t:1528143526728};\\\", \\\"{x:922,y:593,t:1528143526745};\\\", \\\"{x:912,y:593,t:1528143526762};\\\", \\\"{x:903,y:593,t:1528143526778};\\\", \\\"{x:892,y:593,t:1528143526795};\\\", \\\"{x:878,y:593,t:1528143526812};\\\", \\\"{x:857,y:593,t:1528143526828};\\\", \\\"{x:830,y:593,t:1528143526845};\\\", \\\"{x:791,y:593,t:1528143526862};\\\", \\\"{x:735,y:591,t:1528143526878};\\\", \\\"{x:671,y:583,t:1528143526896};\\\", \\\"{x:572,y:569,t:1528143526912};\\\", \\\"{x:516,y:559,t:1528143526928};\\\", \\\"{x:483,y:554,t:1528143526940};\\\", \\\"{x:419,y:546,t:1528143526957};\\\", \\\"{x:354,y:541,t:1528143526973};\\\", \\\"{x:295,y:535,t:1528143526992};\\\", \\\"{x:273,y:536,t:1528143527007};\\\", \\\"{x:267,y:537,t:1528143527025};\\\", \\\"{x:263,y:538,t:1528143527042};\\\", \\\"{x:262,y:538,t:1528143527058};\\\", \\\"{x:261,y:539,t:1528143527075};\\\", \\\"{x:261,y:541,t:1528143527092};\\\", \\\"{x:261,y:546,t:1528143527107};\\\", \\\"{x:261,y:555,t:1528143527125};\\\", \\\"{x:261,y:565,t:1528143527143};\\\", \\\"{x:265,y:574,t:1528143527158};\\\", \\\"{x:268,y:583,t:1528143527175};\\\", \\\"{x:272,y:589,t:1528143527193};\\\", \\\"{x:270,y:589,t:1528143527280};\\\", \\\"{x:263,y:588,t:1528143527292};\\\", \\\"{x:247,y:578,t:1528143527308};\\\", \\\"{x:218,y:568,t:1528143527325};\\\", \\\"{x:193,y:563,t:1528143527342};\\\", \\\"{x:166,y:556,t:1528143527359};\\\", \\\"{x:145,y:552,t:1528143527375};\\\", \\\"{x:128,y:551,t:1528143527391};\\\", \\\"{x:127,y:551,t:1528143527409};\\\", \\\"{x:129,y:551,t:1528143527457};\\\", \\\"{x:139,y:551,t:1528143527465};\\\", \\\"{x:158,y:551,t:1528143527475};\\\", \\\"{x:236,y:551,t:1528143527492};\\\", \\\"{x:344,y:551,t:1528143527509};\\\", \\\"{x:448,y:542,t:1528143527527};\\\", \\\"{x:565,y:540,t:1528143527543};\\\", \\\"{x:686,y:529,t:1528143527559};\\\", \\\"{x:850,y:509,t:1528143527576};\\\", \\\"{x:908,y:496,t:1528143527591};\\\", \\\"{x:957,y:491,t:1528143527609};\\\", \\\"{x:982,y:484,t:1528143527626};\\\", \\\"{x:992,y:481,t:1528143527642};\\\", \\\"{x:994,y:481,t:1528143527659};\\\", \\\"{x:995,y:481,t:1528143527676};\\\", \\\"{x:994,y:481,t:1528143527776};\\\", \\\"{x:979,y:485,t:1528143527792};\\\", \\\"{x:934,y:513,t:1528143527810};\\\", \\\"{x:895,y:538,t:1528143527828};\\\", \\\"{x:855,y:561,t:1528143527843};\\\", \\\"{x:837,y:567,t:1528143527858};\\\", \\\"{x:827,y:571,t:1528143527876};\\\", \\\"{x:823,y:571,t:1528143527892};\\\", \\\"{x:821,y:571,t:1528143527908};\\\", \\\"{x:822,y:570,t:1528143528056};\\\", \\\"{x:823,y:569,t:1528143528064};\\\", \\\"{x:824,y:567,t:1528143528076};\\\", \\\"{x:826,y:563,t:1528143528092};\\\", \\\"{x:828,y:562,t:1528143528109};\\\", \\\"{x:829,y:561,t:1528143528126};\\\", \\\"{x:831,y:558,t:1528143528144};\\\", \\\"{x:831,y:556,t:1528143528160};\\\", \\\"{x:832,y:553,t:1528143528176};\\\", \\\"{x:833,y:551,t:1528143528193};\\\", \\\"{x:833,y:550,t:1528143528209};\\\", \\\"{x:833,y:549,t:1528143528226};\\\", \\\"{x:834,y:545,t:1528143528243};\\\", \\\"{x:834,y:544,t:1528143528259};\\\", \\\"{x:834,y:543,t:1528143528288};\\\", \\\"{x:834,y:542,t:1528143528304};\\\", \\\"{x:834,y:541,t:1528143528393};\\\", \\\"{x:833,y:541,t:1528143529649};\\\", \\\"{x:832,y:541,t:1528143529889};\\\", \\\"{x:832,y:543,t:1528143529896};\\\", \\\"{x:834,y:544,t:1528143529911};\\\", \\\"{x:840,y:549,t:1528143529928};\\\", \\\"{x:848,y:552,t:1528143529945};\\\", \\\"{x:852,y:553,t:1528143529961};\\\", \\\"{x:858,y:553,t:1528143529978};\\\", \\\"{x:864,y:554,t:1528143529995};\\\", \\\"{x:870,y:555,t:1528143530012};\\\", \\\"{x:878,y:556,t:1528143530028};\\\", \\\"{x:888,y:560,t:1528143530045};\\\", \\\"{x:898,y:562,t:1528143530062};\\\", \\\"{x:909,y:567,t:1528143530078};\\\", \\\"{x:925,y:572,t:1528143530094};\\\", \\\"{x:943,y:580,t:1528143530110};\\\", \\\"{x:966,y:585,t:1528143530127};\\\", \\\"{x:1002,y:593,t:1528143530144};\\\", \\\"{x:1034,y:597,t:1528143530161};\\\", \\\"{x:1062,y:597,t:1528143530178};\\\", \\\"{x:1084,y:597,t:1528143530194};\\\", \\\"{x:1108,y:597,t:1528143530211};\\\", \\\"{x:1123,y:597,t:1528143530228};\\\", \\\"{x:1133,y:597,t:1528143530244};\\\", \\\"{x:1142,y:598,t:1528143530262};\\\", \\\"{x:1147,y:598,t:1528143530278};\\\", \\\"{x:1152,y:599,t:1528143530294};\\\", \\\"{x:1158,y:601,t:1528143530311};\\\", \\\"{x:1171,y:602,t:1528143530328};\\\", \\\"{x:1178,y:603,t:1528143530345};\\\", \\\"{x:1185,y:603,t:1528143530362};\\\", \\\"{x:1195,y:606,t:1528143530378};\\\", \\\"{x:1210,y:609,t:1528143530394};\\\", \\\"{x:1221,y:613,t:1528143530411};\\\", \\\"{x:1234,y:616,t:1528143530428};\\\", \\\"{x:1243,y:618,t:1528143530444};\\\", \\\"{x:1253,y:620,t:1528143530461};\\\", \\\"{x:1262,y:621,t:1528143530479};\\\", \\\"{x:1266,y:622,t:1528143530495};\\\", \\\"{x:1271,y:624,t:1528143530512};\\\", \\\"{x:1278,y:626,t:1528143530528};\\\", \\\"{x:1281,y:628,t:1528143530545};\\\", \\\"{x:1284,y:629,t:1528143530561};\\\", \\\"{x:1285,y:629,t:1528143530665};\\\", \\\"{x:1286,y:623,t:1528143530689};\\\", \\\"{x:1288,y:617,t:1528143530696};\\\", \\\"{x:1289,y:610,t:1528143530712};\\\", \\\"{x:1290,y:601,t:1528143530728};\\\", \\\"{x:1292,y:596,t:1528143530745};\\\", \\\"{x:1293,y:591,t:1528143530762};\\\", \\\"{x:1295,y:587,t:1528143530779};\\\", \\\"{x:1295,y:579,t:1528143530795};\\\", \\\"{x:1297,y:570,t:1528143530810};\\\", \\\"{x:1299,y:562,t:1528143530828};\\\", \\\"{x:1304,y:554,t:1528143530844};\\\", \\\"{x:1308,y:549,t:1528143530860};\\\", \\\"{x:1311,y:545,t:1528143530878};\\\", \\\"{x:1315,y:543,t:1528143530895};\\\", \\\"{x:1317,y:542,t:1528143530911};\\\", \\\"{x:1317,y:541,t:1528143530928};\\\", \\\"{x:1319,y:540,t:1528143530945};\\\", \\\"{x:1321,y:535,t:1528143530962};\\\", \\\"{x:1321,y:533,t:1528143530978};\\\", \\\"{x:1322,y:532,t:1528143530995};\\\", \\\"{x:1322,y:530,t:1528143531011};\\\", \\\"{x:1324,y:530,t:1528143531028};\\\", \\\"{x:1325,y:531,t:1528143531112};\\\", \\\"{x:1325,y:547,t:1528143531129};\\\", \\\"{x:1325,y:568,t:1528143531146};\\\", \\\"{x:1325,y:588,t:1528143531162};\\\", \\\"{x:1325,y:599,t:1528143531178};\\\", \\\"{x:1323,y:612,t:1528143531195};\\\", \\\"{x:1323,y:620,t:1528143531212};\\\", \\\"{x:1323,y:624,t:1528143531228};\\\", \\\"{x:1323,y:629,t:1528143531245};\\\", \\\"{x:1323,y:634,t:1528143531262};\\\", \\\"{x:1323,y:640,t:1528143531279};\\\", \\\"{x:1323,y:651,t:1528143531295};\\\", \\\"{x:1323,y:667,t:1528143531312};\\\", \\\"{x:1321,y:677,t:1528143531328};\\\", \\\"{x:1321,y:684,t:1528143531345};\\\", \\\"{x:1318,y:692,t:1528143531362};\\\", \\\"{x:1318,y:698,t:1528143531379};\\\", \\\"{x:1317,y:700,t:1528143531395};\\\", \\\"{x:1317,y:703,t:1528143531412};\\\", \\\"{x:1317,y:706,t:1528143531429};\\\", \\\"{x:1317,y:710,t:1528143531445};\\\", \\\"{x:1317,y:715,t:1528143531462};\\\", \\\"{x:1317,y:718,t:1528143531479};\\\", \\\"{x:1317,y:720,t:1528143531495};\\\", \\\"{x:1317,y:721,t:1528143531569};\\\", \\\"{x:1317,y:723,t:1528143531580};\\\", \\\"{x:1317,y:725,t:1528143531595};\\\", \\\"{x:1317,y:728,t:1528143531613};\\\", \\\"{x:1318,y:731,t:1528143531630};\\\", \\\"{x:1318,y:733,t:1528143531646};\\\", \\\"{x:1318,y:734,t:1528143531663};\\\", \\\"{x:1318,y:736,t:1528143531679};\\\", \\\"{x:1318,y:741,t:1528143531695};\\\", \\\"{x:1323,y:765,t:1528143531712};\\\", \\\"{x:1323,y:781,t:1528143531730};\\\", \\\"{x:1323,y:791,t:1528143531746};\\\", \\\"{x:1323,y:795,t:1528143531763};\\\", \\\"{x:1323,y:797,t:1528143531780};\\\", \\\"{x:1323,y:798,t:1528143531809};\\\", \\\"{x:1323,y:799,t:1528143531817};\\\", \\\"{x:1323,y:801,t:1528143531832};\\\", \\\"{x:1322,y:802,t:1528143531849};\\\", \\\"{x:1322,y:805,t:1528143531863};\\\", \\\"{x:1322,y:808,t:1528143531880};\\\", \\\"{x:1322,y:813,t:1528143531897};\\\", \\\"{x:1321,y:818,t:1528143531912};\\\", \\\"{x:1319,y:824,t:1528143531930};\\\", \\\"{x:1319,y:830,t:1528143531947};\\\", \\\"{x:1318,y:838,t:1528143531963};\\\", \\\"{x:1317,y:846,t:1528143531980};\\\", \\\"{x:1315,y:854,t:1528143531997};\\\", \\\"{x:1315,y:863,t:1528143532013};\\\", \\\"{x:1315,y:873,t:1528143532030};\\\", \\\"{x:1315,y:884,t:1528143532046};\\\", \\\"{x:1315,y:899,t:1528143532062};\\\", \\\"{x:1314,y:917,t:1528143532079};\\\", \\\"{x:1314,y:930,t:1528143532096};\\\", \\\"{x:1314,y:934,t:1528143532112};\\\", \\\"{x:1314,y:937,t:1528143532129};\\\", \\\"{x:1313,y:939,t:1528143532146};\\\", \\\"{x:1311,y:941,t:1528143532163};\\\", \\\"{x:1310,y:941,t:1528143532180};\\\", \\\"{x:1308,y:941,t:1528143532196};\\\", \\\"{x:1303,y:941,t:1528143532213};\\\", \\\"{x:1289,y:933,t:1528143532229};\\\", \\\"{x:1258,y:918,t:1528143532246};\\\", \\\"{x:1213,y:898,t:1528143532263};\\\", \\\"{x:1158,y:875,t:1528143532279};\\\", \\\"{x:1041,y:841,t:1528143532297};\\\", \\\"{x:955,y:828,t:1528143532314};\\\", \\\"{x:863,y:828,t:1528143532329};\\\", \\\"{x:766,y:828,t:1528143532346};\\\", \\\"{x:702,y:827,t:1528143532364};\\\", \\\"{x:657,y:832,t:1528143532380};\\\", \\\"{x:628,y:837,t:1528143532396};\\\", \\\"{x:604,y:841,t:1528143532414};\\\", \\\"{x:595,y:843,t:1528143532429};\\\", \\\"{x:594,y:843,t:1528143532447};\\\", \\\"{x:593,y:843,t:1528143532489};\\\", \\\"{x:592,y:841,t:1528143532513};\\\", \\\"{x:583,y:827,t:1528143532530};\\\", \\\"{x:571,y:813,t:1528143532547};\\\", \\\"{x:558,y:798,t:1528143532563};\\\", \\\"{x:544,y:782,t:1528143532580};\\\", \\\"{x:533,y:770,t:1528143532596};\\\", \\\"{x:528,y:761,t:1528143532613};\\\", \\\"{x:526,y:756,t:1528143532630};\\\", \\\"{x:523,y:748,t:1528143532648};\\\", \\\"{x:522,y:738,t:1528143532663};\\\", \\\"{x:522,y:717,t:1528143532679};\\\", \\\"{x:524,y:709,t:1528143532696};\\\", \\\"{x:526,y:706,t:1528143532713};\\\", \\\"{x:526,y:705,t:1528143532729};\\\", \\\"{x:528,y:702,t:1528143532746};\\\", \\\"{x:528,y:703,t:1528143532936};\\\", \\\"{x:528,y:703,t:1528143532938};\\\", \\\"{x:528,y:705,t:1528143532946};\\\", \\\"{x:528,y:706,t:1528143532963};\\\", \\\"{x:528,y:708,t:1528143532981};\\\", \\\"{x:527,y:710,t:1528143532997};\\\", \\\"{x:527,y:713,t:1528143533014};\\\", \\\"{x:527,y:719,t:1528143533032};\\\", \\\"{x:527,y:723,t:1528143533047};\\\", \\\"{x:527,y:726,t:1528143533063};\\\", \\\"{x:527,y:727,t:1528143533120};\\\" ] }, { \\\"rt\\\": 7480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 630017, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:727,t:1528143535889};\\\", \\\"{x:545,y:727,t:1528143535900};\\\", \\\"{x:599,y:723,t:1528143535918};\\\", \\\"{x:692,y:714,t:1528143535933};\\\", \\\"{x:807,y:708,t:1528143535949};\\\", \\\"{x:926,y:706,t:1528143535966};\\\", \\\"{x:1048,y:706,t:1528143535982};\\\", \\\"{x:1157,y:700,t:1528143536000};\\\", \\\"{x:1272,y:678,t:1528143536016};\\\", \\\"{x:1332,y:663,t:1528143536033};\\\", \\\"{x:1356,y:652,t:1528143536049};\\\", \\\"{x:1371,y:647,t:1528143536066};\\\", \\\"{x:1372,y:646,t:1528143536082};\\\", \\\"{x:1372,y:644,t:1528143536128};\\\", \\\"{x:1371,y:644,t:1528143536145};\\\", \\\"{x:1370,y:644,t:1528143536152};\\\", \\\"{x:1369,y:643,t:1528143536167};\\\", \\\"{x:1366,y:641,t:1528143536182};\\\", \\\"{x:1363,y:639,t:1528143536200};\\\", \\\"{x:1353,y:633,t:1528143536217};\\\", \\\"{x:1341,y:628,t:1528143536234};\\\", \\\"{x:1329,y:623,t:1528143536249};\\\", \\\"{x:1315,y:620,t:1528143536267};\\\", \\\"{x:1296,y:620,t:1528143536283};\\\", \\\"{x:1275,y:620,t:1528143536300};\\\", \\\"{x:1260,y:620,t:1528143536317};\\\", \\\"{x:1250,y:618,t:1528143536334};\\\", \\\"{x:1242,y:616,t:1528143536349};\\\", \\\"{x:1236,y:614,t:1528143536367};\\\", \\\"{x:1227,y:611,t:1528143536384};\\\", \\\"{x:1220,y:608,t:1528143536400};\\\", \\\"{x:1204,y:601,t:1528143536417};\\\", \\\"{x:1190,y:596,t:1528143536434};\\\", \\\"{x:1181,y:593,t:1528143536450};\\\", \\\"{x:1166,y:589,t:1528143536466};\\\", \\\"{x:1153,y:588,t:1528143536484};\\\", \\\"{x:1146,y:587,t:1528143536500};\\\", \\\"{x:1142,y:587,t:1528143536517};\\\", \\\"{x:1138,y:585,t:1528143536534};\\\", \\\"{x:1135,y:584,t:1528143536551};\\\", \\\"{x:1133,y:584,t:1528143536567};\\\", \\\"{x:1132,y:584,t:1528143536584};\\\", \\\"{x:1130,y:584,t:1528143536633};\\\", \\\"{x:1129,y:584,t:1528143536673};\\\", \\\"{x:1127,y:584,t:1528143536705};\\\", \\\"{x:1125,y:584,t:1528143536721};\\\", \\\"{x:1124,y:584,t:1528143536734};\\\", \\\"{x:1122,y:583,t:1528143536751};\\\", \\\"{x:1121,y:583,t:1528143536767};\\\", \\\"{x:1120,y:583,t:1528143536784};\\\", \\\"{x:1119,y:582,t:1528143536809};\\\", \\\"{x:1118,y:581,t:1528143536841};\\\", \\\"{x:1116,y:580,t:1528143536857};\\\", \\\"{x:1114,y:580,t:1528143536868};\\\", \\\"{x:1109,y:577,t:1528143536884};\\\", \\\"{x:1106,y:576,t:1528143536901};\\\", \\\"{x:1104,y:576,t:1528143536918};\\\", \\\"{x:1102,y:576,t:1528143536934};\\\", \\\"{x:1098,y:574,t:1528143536951};\\\", \\\"{x:1096,y:574,t:1528143536968};\\\", \\\"{x:1095,y:573,t:1528143536984};\\\", \\\"{x:1096,y:573,t:1528143537041};\\\", \\\"{x:1097,y:574,t:1528143537051};\\\", \\\"{x:1100,y:575,t:1528143537068};\\\", \\\"{x:1101,y:575,t:1528143537085};\\\", \\\"{x:1104,y:575,t:1528143537101};\\\", \\\"{x:1105,y:577,t:1528143537118};\\\", \\\"{x:1109,y:578,t:1528143537135};\\\", \\\"{x:1115,y:578,t:1528143537151};\\\", \\\"{x:1128,y:578,t:1528143537168};\\\", \\\"{x:1157,y:578,t:1528143537185};\\\", \\\"{x:1173,y:578,t:1528143537201};\\\", \\\"{x:1186,y:578,t:1528143537218};\\\", \\\"{x:1197,y:578,t:1528143537235};\\\", \\\"{x:1204,y:578,t:1528143537251};\\\", \\\"{x:1210,y:578,t:1528143537268};\\\", \\\"{x:1217,y:578,t:1528143537285};\\\", \\\"{x:1223,y:578,t:1528143537301};\\\", \\\"{x:1228,y:578,t:1528143537317};\\\", \\\"{x:1235,y:578,t:1528143537335};\\\", \\\"{x:1241,y:577,t:1528143537351};\\\", \\\"{x:1256,y:573,t:1528143537368};\\\", \\\"{x:1264,y:571,t:1528143537384};\\\", \\\"{x:1268,y:571,t:1528143537402};\\\", \\\"{x:1269,y:571,t:1528143537417};\\\", \\\"{x:1264,y:571,t:1528143537465};\\\", \\\"{x:1254,y:571,t:1528143537472};\\\", \\\"{x:1238,y:571,t:1528143537485};\\\", \\\"{x:1168,y:578,t:1528143537502};\\\", \\\"{x:1086,y:587,t:1528143537518};\\\", \\\"{x:978,y:600,t:1528143537535};\\\", \\\"{x:883,y:617,t:1528143537553};\\\", \\\"{x:804,y:625,t:1528143537568};\\\", \\\"{x:737,y:627,t:1528143537584};\\\", \\\"{x:675,y:628,t:1528143537600};\\\", \\\"{x:588,y:644,t:1528143537618};\\\", \\\"{x:527,y:654,t:1528143537634};\\\", \\\"{x:489,y:654,t:1528143537651};\\\", \\\"{x:469,y:654,t:1528143537667};\\\", \\\"{x:452,y:649,t:1528143537684};\\\", \\\"{x:438,y:641,t:1528143537700};\\\", \\\"{x:431,y:639,t:1528143537717};\\\", \\\"{x:423,y:635,t:1528143537733};\\\", \\\"{x:418,y:632,t:1528143537750};\\\", \\\"{x:416,y:631,t:1528143537768};\\\", \\\"{x:416,y:630,t:1528143537783};\\\", \\\"{x:414,y:630,t:1528143537800};\\\", \\\"{x:410,y:628,t:1528143537817};\\\", \\\"{x:404,y:624,t:1528143537835};\\\", \\\"{x:397,y:620,t:1528143537850};\\\", \\\"{x:392,y:619,t:1528143537868};\\\", \\\"{x:384,y:616,t:1528143537885};\\\", \\\"{x:380,y:614,t:1528143537900};\\\", \\\"{x:374,y:612,t:1528143537918};\\\", \\\"{x:367,y:608,t:1528143537934};\\\", \\\"{x:360,y:607,t:1528143537950};\\\", \\\"{x:352,y:606,t:1528143537967};\\\", \\\"{x:337,y:603,t:1528143537984};\\\", \\\"{x:325,y:601,t:1528143538000};\\\", \\\"{x:312,y:597,t:1528143538018};\\\", \\\"{x:301,y:594,t:1528143538034};\\\", \\\"{x:294,y:593,t:1528143538050};\\\", \\\"{x:283,y:593,t:1528143538067};\\\", \\\"{x:272,y:593,t:1528143538085};\\\", \\\"{x:257,y:593,t:1528143538100};\\\", \\\"{x:234,y:593,t:1528143538118};\\\", \\\"{x:209,y:593,t:1528143538135};\\\", \\\"{x:189,y:593,t:1528143538151};\\\", \\\"{x:176,y:593,t:1528143538167};\\\", \\\"{x:170,y:593,t:1528143538183};\\\", \\\"{x:169,y:593,t:1528143538200};\\\", \\\"{x:168,y:595,t:1528143538218};\\\", \\\"{x:166,y:599,t:1528143538234};\\\", \\\"{x:165,y:608,t:1528143538252};\\\", \\\"{x:164,y:615,t:1528143538268};\\\", \\\"{x:164,y:620,t:1528143538285};\\\", \\\"{x:164,y:623,t:1528143538301};\\\", \\\"{x:164,y:624,t:1528143538317};\\\", \\\"{x:164,y:625,t:1528143538335};\\\", \\\"{x:164,y:626,t:1528143538351};\\\", \\\"{x:164,y:627,t:1528143538367};\\\", \\\"{x:169,y:628,t:1528143538385};\\\", \\\"{x:183,y:629,t:1528143538402};\\\", \\\"{x:205,y:629,t:1528143538417};\\\", \\\"{x:228,y:629,t:1528143538435};\\\", \\\"{x:248,y:628,t:1528143538452};\\\", \\\"{x:268,y:621,t:1528143538468};\\\", \\\"{x:289,y:612,t:1528143538485};\\\", \\\"{x:308,y:604,t:1528143538502};\\\", \\\"{x:323,y:594,t:1528143538519};\\\", \\\"{x:334,y:586,t:1528143538534};\\\", \\\"{x:348,y:578,t:1528143538551};\\\", \\\"{x:362,y:569,t:1528143538568};\\\", \\\"{x:373,y:564,t:1528143538584};\\\", \\\"{x:385,y:559,t:1528143538602};\\\", \\\"{x:399,y:554,t:1528143538619};\\\", \\\"{x:416,y:551,t:1528143538635};\\\", \\\"{x:436,y:543,t:1528143538652};\\\", \\\"{x:458,y:536,t:1528143538668};\\\", \\\"{x:482,y:531,t:1528143538685};\\\", \\\"{x:502,y:525,t:1528143538702};\\\", \\\"{x:516,y:520,t:1528143538720};\\\", \\\"{x:525,y:518,t:1528143538734};\\\", \\\"{x:531,y:518,t:1528143538751};\\\", \\\"{x:540,y:514,t:1528143538769};\\\", \\\"{x:549,y:510,t:1528143538784};\\\", \\\"{x:554,y:508,t:1528143538801};\\\", \\\"{x:556,y:508,t:1528143538818};\\\", \\\"{x:557,y:507,t:1528143538835};\\\", \\\"{x:559,y:506,t:1528143538851};\\\", \\\"{x:567,y:504,t:1528143538868};\\\", \\\"{x:576,y:503,t:1528143538884};\\\", \\\"{x:588,y:502,t:1528143538901};\\\", \\\"{x:603,y:502,t:1528143538918};\\\", \\\"{x:613,y:500,t:1528143538936};\\\", \\\"{x:619,y:500,t:1528143538952};\\\", \\\"{x:622,y:500,t:1528143538969};\\\", \\\"{x:625,y:503,t:1528143539384};\\\", \\\"{x:637,y:509,t:1528143539392};\\\", \\\"{x:647,y:515,t:1528143539402};\\\", \\\"{x:663,y:523,t:1528143539419};\\\", \\\"{x:686,y:533,t:1528143539436};\\\", \\\"{x:718,y:545,t:1528143539451};\\\", \\\"{x:744,y:552,t:1528143539469};\\\", \\\"{x:769,y:555,t:1528143539486};\\\", \\\"{x:791,y:555,t:1528143539502};\\\", \\\"{x:807,y:555,t:1528143539519};\\\", \\\"{x:816,y:555,t:1528143539536};\\\", \\\"{x:819,y:555,t:1528143539552};\\\", \\\"{x:820,y:555,t:1528143539601};\\\", \\\"{x:823,y:554,t:1528143539633};\\\", \\\"{x:823,y:553,t:1528143539640};\\\", \\\"{x:824,y:552,t:1528143539657};\\\", \\\"{x:825,y:551,t:1528143539669};\\\", \\\"{x:825,y:550,t:1528143539686};\\\", \\\"{x:825,y:549,t:1528143539712};\\\", \\\"{x:826,y:549,t:1528143539753};\\\", \\\"{x:826,y:548,t:1528143539800};\\\", \\\"{x:828,y:547,t:1528143539809};\\\", \\\"{x:828,y:546,t:1528143539840};\\\", \\\"{x:829,y:546,t:1528143540127};\\\", \\\"{x:828,y:545,t:1528143540848};\\\", \\\"{x:826,y:545,t:1528143540856};\\\", \\\"{x:822,y:547,t:1528143540870};\\\", \\\"{x:810,y:552,t:1528143540885};\\\", \\\"{x:798,y:555,t:1528143540902};\\\", \\\"{x:784,y:560,t:1528143540920};\\\", \\\"{x:765,y:567,t:1528143540936};\\\", \\\"{x:744,y:576,t:1528143540952};\\\", \\\"{x:732,y:584,t:1528143540969};\\\", \\\"{x:726,y:587,t:1528143540986};\\\", \\\"{x:723,y:589,t:1528143541004};\\\", \\\"{x:718,y:592,t:1528143541019};\\\", \\\"{x:715,y:595,t:1528143541037};\\\", \\\"{x:710,y:600,t:1528143541054};\\\", \\\"{x:706,y:604,t:1528143541070};\\\", \\\"{x:700,y:612,t:1528143541086};\\\", \\\"{x:692,y:623,t:1528143541103};\\\", \\\"{x:683,y:632,t:1528143541120};\\\", \\\"{x:676,y:637,t:1528143541136};\\\", \\\"{x:663,y:649,t:1528143541154};\\\", \\\"{x:651,y:661,t:1528143541170};\\\", \\\"{x:640,y:669,t:1528143541186};\\\", \\\"{x:630,y:678,t:1528143541203};\\\", \\\"{x:612,y:691,t:1528143541221};\\\", \\\"{x:594,y:702,t:1528143541237};\\\", \\\"{x:574,y:711,t:1528143541253};\\\", \\\"{x:552,y:723,t:1528143541272};\\\", \\\"{x:523,y:734,t:1528143541286};\\\", \\\"{x:484,y:753,t:1528143541303};\\\", \\\"{x:468,y:762,t:1528143541320};\\\", \\\"{x:463,y:763,t:1528143541337};\\\", \\\"{x:462,y:763,t:1528143541354};\\\", \\\"{x:462,y:762,t:1528143541569};\\\", \\\"{x:463,y:761,t:1528143541576};\\\", \\\"{x:464,y:758,t:1528143541587};\\\", \\\"{x:466,y:756,t:1528143541604};\\\", \\\"{x:468,y:754,t:1528143541622};\\\" ] }, { \\\"rt\\\": 30080, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 661383, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-J -11 AM-11 AM-12 PM-10 AM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:469,y:751,t:1528143543977};\\\", \\\"{x:467,y:725,t:1528143543989};\\\", \\\"{x:454,y:628,t:1528143544006};\\\", \\\"{x:447,y:579,t:1528143544022};\\\", \\\"{x:447,y:539,t:1528143544040};\\\", \\\"{x:442,y:512,t:1528143544056};\\\", \\\"{x:431,y:489,t:1528143544072};\\\", \\\"{x:428,y:485,t:1528143544089};\\\", \\\"{x:427,y:485,t:1528143544576};\\\", \\\"{x:425,y:485,t:1528143545058};\\\", \\\"{x:417,y:481,t:1528143545065};\\\", \\\"{x:412,y:479,t:1528143545075};\\\", \\\"{x:407,y:476,t:1528143545092};\\\", \\\"{x:405,y:475,t:1528143545109};\\\", \\\"{x:401,y:472,t:1528143545125};\\\", \\\"{x:400,y:472,t:1528143545144};\\\", \\\"{x:400,y:471,t:1528143545159};\\\", \\\"{x:399,y:471,t:1528143545240};\\\", \\\"{x:398,y:471,t:1528143545249};\\\", \\\"{x:399,y:471,t:1528143546848};\\\", \\\"{x:400,y:471,t:1528143546863};\\\", \\\"{x:403,y:469,t:1528143546880};\\\", \\\"{x:408,y:468,t:1528143546897};\\\", \\\"{x:412,y:465,t:1528143546914};\\\", \\\"{x:417,y:465,t:1528143546931};\\\", \\\"{x:419,y:465,t:1528143546947};\\\", \\\"{x:423,y:465,t:1528143546964};\\\", \\\"{x:426,y:465,t:1528143546980};\\\", \\\"{x:430,y:465,t:1528143546998};\\\", \\\"{x:437,y:465,t:1528143547014};\\\", \\\"{x:441,y:464,t:1528143547030};\\\", \\\"{x:443,y:464,t:1528143547047};\\\", \\\"{x:445,y:463,t:1528143547065};\\\", \\\"{x:446,y:463,t:1528143547097};\\\", \\\"{x:447,y:462,t:1528143547114};\\\", \\\"{x:448,y:462,t:1528143547132};\\\", \\\"{x:451,y:461,t:1528143547147};\\\", \\\"{x:457,y:461,t:1528143547164};\\\", \\\"{x:461,y:461,t:1528143547181};\\\", \\\"{x:464,y:461,t:1528143547198};\\\", \\\"{x:467,y:461,t:1528143547213};\\\", \\\"{x:471,y:461,t:1528143547231};\\\", \\\"{x:476,y:461,t:1528143547247};\\\", \\\"{x:480,y:461,t:1528143547264};\\\", \\\"{x:482,y:461,t:1528143547281};\\\", \\\"{x:485,y:461,t:1528143547297};\\\", \\\"{x:486,y:461,t:1528143547315};\\\", \\\"{x:487,y:461,t:1528143547344};\\\", \\\"{x:488,y:461,t:1528143547409};\\\", \\\"{x:489,y:461,t:1528143547432};\\\", \\\"{x:490,y:461,t:1528143547456};\\\", \\\"{x:491,y:461,t:1528143547513};\\\", \\\"{x:492,y:461,t:1528143547561};\\\", \\\"{x:493,y:461,t:1528143547576};\\\", \\\"{x:494,y:461,t:1528143547584};\\\", \\\"{x:495,y:461,t:1528143547600};\\\", \\\"{x:497,y:461,t:1528143547616};\\\", \\\"{x:502,y:461,t:1528143547632};\\\", \\\"{x:508,y:462,t:1528143547649};\\\", \\\"{x:513,y:463,t:1528143547665};\\\", \\\"{x:517,y:464,t:1528143547683};\\\", \\\"{x:522,y:464,t:1528143547699};\\\", \\\"{x:524,y:464,t:1528143547716};\\\", \\\"{x:526,y:464,t:1528143547732};\\\", \\\"{x:527,y:464,t:1528143547749};\\\", \\\"{x:529,y:464,t:1528143547766};\\\", \\\"{x:531,y:466,t:1528143547782};\\\", \\\"{x:532,y:466,t:1528143547799};\\\", \\\"{x:536,y:466,t:1528143547817};\\\", \\\"{x:538,y:466,t:1528143547832};\\\", \\\"{x:539,y:466,t:1528143547849};\\\", \\\"{x:543,y:466,t:1528143547866};\\\", \\\"{x:547,y:466,t:1528143547884};\\\", \\\"{x:551,y:467,t:1528143547899};\\\", \\\"{x:554,y:468,t:1528143547916};\\\", \\\"{x:556,y:468,t:1528143547934};\\\", \\\"{x:557,y:469,t:1528143547952};\\\", \\\"{x:559,y:469,t:1528143548025};\\\", \\\"{x:560,y:469,t:1528143548073};\\\", \\\"{x:562,y:469,t:1528143548137};\\\", \\\"{x:563,y:469,t:1528143548287};\\\", \\\"{x:565,y:469,t:1528143548424};\\\", \\\"{x:566,y:469,t:1528143548434};\\\", \\\"{x:569,y:469,t:1528143548452};\\\", \\\"{x:570,y:469,t:1528143548472};\\\", \\\"{x:571,y:469,t:1528143548488};\\\", \\\"{x:572,y:469,t:1528143548520};\\\", \\\"{x:572,y:470,t:1528143548657};\\\", \\\"{x:570,y:470,t:1528143548801};\\\", \\\"{x:566,y:470,t:1528143548809};\\\", \\\"{x:561,y:470,t:1528143548818};\\\", \\\"{x:549,y:471,t:1528143548834};\\\", \\\"{x:528,y:471,t:1528143548851};\\\", \\\"{x:501,y:471,t:1528143548869};\\\", \\\"{x:473,y:471,t:1528143548884};\\\", \\\"{x:451,y:468,t:1528143548902};\\\", \\\"{x:444,y:467,t:1528143548919};\\\", \\\"{x:443,y:467,t:1528143548935};\\\", \\\"{x:446,y:467,t:1528143549297};\\\", \\\"{x:450,y:467,t:1528143549312};\\\", \\\"{x:453,y:467,t:1528143549320};\\\", \\\"{x:460,y:467,t:1528143549336};\\\", \\\"{x:465,y:467,t:1528143549353};\\\", \\\"{x:469,y:468,t:1528143549370};\\\", \\\"{x:471,y:468,t:1528143549387};\\\", \\\"{x:473,y:468,t:1528143549404};\\\", \\\"{x:475,y:468,t:1528143549420};\\\", \\\"{x:476,y:468,t:1528143549438};\\\", \\\"{x:478,y:468,t:1528143549454};\\\", \\\"{x:479,y:468,t:1528143549471};\\\", \\\"{x:481,y:468,t:1528143549488};\\\", \\\"{x:485,y:468,t:1528143549504};\\\", \\\"{x:487,y:468,t:1528143549520};\\\", \\\"{x:490,y:468,t:1528143549537};\\\", \\\"{x:493,y:468,t:1528143549555};\\\", \\\"{x:497,y:468,t:1528143549571};\\\", \\\"{x:501,y:468,t:1528143549587};\\\", \\\"{x:506,y:468,t:1528143549604};\\\", \\\"{x:510,y:468,t:1528143549621};\\\", \\\"{x:516,y:468,t:1528143549637};\\\", \\\"{x:521,y:468,t:1528143549654};\\\", \\\"{x:525,y:468,t:1528143549671};\\\", \\\"{x:529,y:469,t:1528143549687};\\\", \\\"{x:532,y:469,t:1528143549705};\\\", \\\"{x:535,y:469,t:1528143549721};\\\", \\\"{x:540,y:469,t:1528143549739};\\\", \\\"{x:545,y:469,t:1528143549754};\\\", \\\"{x:549,y:469,t:1528143549771};\\\", \\\"{x:553,y:469,t:1528143549789};\\\", \\\"{x:555,y:469,t:1528143549805};\\\", \\\"{x:556,y:469,t:1528143549821};\\\", \\\"{x:561,y:469,t:1528143549839};\\\", \\\"{x:567,y:469,t:1528143549856};\\\", \\\"{x:570,y:469,t:1528143549872};\\\", \\\"{x:574,y:469,t:1528143549889};\\\", \\\"{x:575,y:469,t:1528143549905};\\\", \\\"{x:577,y:469,t:1528143549922};\\\", \\\"{x:579,y:469,t:1528143549938};\\\", \\\"{x:580,y:469,t:1528143549961};\\\", \\\"{x:581,y:469,t:1528143550000};\\\", \\\"{x:583,y:469,t:1528143550017};\\\", \\\"{x:585,y:469,t:1528143550073};\\\", \\\"{x:586,y:469,t:1528143550096};\\\", \\\"{x:589,y:469,t:1528143550120};\\\", \\\"{x:590,y:469,t:1528143550129};\\\", \\\"{x:591,y:469,t:1528143550139};\\\", \\\"{x:595,y:469,t:1528143550155};\\\", \\\"{x:598,y:469,t:1528143550173};\\\", \\\"{x:602,y:469,t:1528143550189};\\\", \\\"{x:605,y:470,t:1528143550205};\\\", \\\"{x:607,y:470,t:1528143550222};\\\", \\\"{x:610,y:472,t:1528143550240};\\\", \\\"{x:611,y:472,t:1528143550264};\\\", \\\"{x:613,y:472,t:1528143550273};\\\", \\\"{x:614,y:472,t:1528143550289};\\\", \\\"{x:615,y:472,t:1528143550307};\\\", \\\"{x:616,y:472,t:1528143550322};\\\", \\\"{x:618,y:472,t:1528143550344};\\\", \\\"{x:619,y:472,t:1528143550424};\\\", \\\"{x:619,y:473,t:1528143550456};\\\", \\\"{x:620,y:473,t:1528143551121};\\\", \\\"{x:622,y:474,t:1528143551824};\\\", \\\"{x:622,y:475,t:1528143551833};\\\", \\\"{x:623,y:475,t:1528143551843};\\\", \\\"{x:625,y:476,t:1528143551861};\\\", \\\"{x:626,y:477,t:1528143551888};\\\", \\\"{x:627,y:478,t:1528143551897};\\\", \\\"{x:628,y:478,t:1528143551911};\\\", \\\"{x:630,y:479,t:1528143551928};\\\", \\\"{x:634,y:480,t:1528143551944};\\\", \\\"{x:639,y:481,t:1528143551960};\\\", \\\"{x:643,y:482,t:1528143551977};\\\", \\\"{x:650,y:483,t:1528143551994};\\\", \\\"{x:655,y:483,t:1528143552010};\\\", \\\"{x:662,y:485,t:1528143552027};\\\", \\\"{x:666,y:485,t:1528143552044};\\\", \\\"{x:676,y:485,t:1528143552061};\\\", \\\"{x:695,y:485,t:1528143552078};\\\", \\\"{x:718,y:485,t:1528143552095};\\\", \\\"{x:740,y:485,t:1528143552111};\\\", \\\"{x:767,y:485,t:1528143552128};\\\", \\\"{x:802,y:489,t:1528143552146};\\\", \\\"{x:827,y:493,t:1528143552161};\\\", \\\"{x:849,y:494,t:1528143552177};\\\", \\\"{x:863,y:494,t:1528143552195};\\\", \\\"{x:867,y:498,t:1528143552212};\\\", \\\"{x:867,y:499,t:1528143552228};\\\", \\\"{x:867,y:500,t:1528143552245};\\\", \\\"{x:869,y:500,t:1528143552666};\\\", \\\"{x:871,y:500,t:1528143552679};\\\", \\\"{x:876,y:500,t:1528143552696};\\\", \\\"{x:879,y:500,t:1528143552713};\\\", \\\"{x:881,y:500,t:1528143552729};\\\", \\\"{x:886,y:500,t:1528143552746};\\\", \\\"{x:888,y:500,t:1528143552763};\\\", \\\"{x:889,y:500,t:1528143552779};\\\", \\\"{x:892,y:500,t:1528143552796};\\\", \\\"{x:893,y:500,t:1528143552814};\\\", \\\"{x:894,y:500,t:1528143552830};\\\", \\\"{x:896,y:500,t:1528143552846};\\\", \\\"{x:897,y:500,t:1528143552864};\\\", \\\"{x:898,y:500,t:1528143552929};\\\", \\\"{x:899,y:500,t:1528143552960};\\\", \\\"{x:901,y:500,t:1528143552968};\\\", \\\"{x:905,y:500,t:1528143552979};\\\", \\\"{x:913,y:500,t:1528143552996};\\\", \\\"{x:934,y:506,t:1528143553012};\\\", \\\"{x:962,y:522,t:1528143553029};\\\", \\\"{x:986,y:532,t:1528143553046};\\\", \\\"{x:1009,y:539,t:1528143553063};\\\", \\\"{x:1031,y:548,t:1528143553079};\\\", \\\"{x:1041,y:551,t:1528143553097};\\\", \\\"{x:1045,y:552,t:1528143553113};\\\", \\\"{x:1047,y:552,t:1528143553130};\\\", \\\"{x:1048,y:552,t:1528143553147};\\\", \\\"{x:1050,y:553,t:1528143553232};\\\", \\\"{x:1056,y:557,t:1528143554073};\\\", \\\"{x:1064,y:562,t:1528143554083};\\\", \\\"{x:1074,y:571,t:1528143554098};\\\", \\\"{x:1077,y:580,t:1528143554115};\\\", \\\"{x:1079,y:589,t:1528143554132};\\\", \\\"{x:1081,y:596,t:1528143554148};\\\", \\\"{x:1084,y:600,t:1528143554165};\\\", \\\"{x:1085,y:601,t:1528143554181};\\\", \\\"{x:1085,y:602,t:1528143554198};\\\", \\\"{x:1086,y:603,t:1528143554215};\\\", \\\"{x:1087,y:604,t:1528143554232};\\\", \\\"{x:1088,y:605,t:1528143554248};\\\", \\\"{x:1089,y:606,t:1528143554265};\\\", \\\"{x:1089,y:607,t:1528143554282};\\\", \\\"{x:1090,y:609,t:1528143554298};\\\", \\\"{x:1090,y:612,t:1528143554315};\\\", \\\"{x:1090,y:620,t:1528143554331};\\\", \\\"{x:1090,y:624,t:1528143554348};\\\", \\\"{x:1090,y:628,t:1528143554365};\\\", \\\"{x:1088,y:630,t:1528143554382};\\\", \\\"{x:1088,y:631,t:1528143554400};\\\", \\\"{x:1087,y:632,t:1528143554414};\\\", \\\"{x:1086,y:633,t:1528143554432};\\\", \\\"{x:1085,y:633,t:1528143554465};\\\", \\\"{x:1085,y:635,t:1528143555153};\\\", \\\"{x:1088,y:636,t:1528143555209};\\\", \\\"{x:1089,y:636,t:1528143555216};\\\", \\\"{x:1091,y:637,t:1528143555232};\\\", \\\"{x:1092,y:638,t:1528143555249};\\\", \\\"{x:1093,y:638,t:1528143555266};\\\", \\\"{x:1093,y:639,t:1528143555393};\\\", \\\"{x:1095,y:639,t:1528143555449};\\\", \\\"{x:1096,y:639,t:1528143555473};\\\", \\\"{x:1097,y:639,t:1528143555488};\\\", \\\"{x:1098,y:639,t:1528143555499};\\\", \\\"{x:1100,y:640,t:1528143555520};\\\", \\\"{x:1101,y:641,t:1528143555703};\\\", \\\"{x:1101,y:640,t:1528143556672};\\\", \\\"{x:1101,y:638,t:1528143556684};\\\", \\\"{x:1101,y:635,t:1528143556700};\\\", \\\"{x:1102,y:631,t:1528143556716};\\\", \\\"{x:1102,y:630,t:1528143556734};\\\", \\\"{x:1103,y:629,t:1528143556751};\\\", \\\"{x:1104,y:634,t:1528143557017};\\\", \\\"{x:1105,y:649,t:1528143557034};\\\", \\\"{x:1106,y:666,t:1528143557051};\\\", \\\"{x:1109,y:676,t:1528143557067};\\\", \\\"{x:1111,y:684,t:1528143557084};\\\", \\\"{x:1113,y:691,t:1528143557101};\\\", \\\"{x:1113,y:692,t:1528143557117};\\\", \\\"{x:1113,y:693,t:1528143557134};\\\", \\\"{x:1114,y:693,t:1528143557151};\\\", \\\"{x:1114,y:694,t:1528143557192};\\\", \\\"{x:1114,y:695,t:1528143557200};\\\", \\\"{x:1114,y:699,t:1528143557217};\\\", \\\"{x:1117,y:706,t:1528143557234};\\\", \\\"{x:1119,y:716,t:1528143557251};\\\", \\\"{x:1120,y:727,t:1528143557267};\\\", \\\"{x:1124,y:739,t:1528143557284};\\\", \\\"{x:1127,y:750,t:1528143557301};\\\", \\\"{x:1129,y:757,t:1528143557317};\\\", \\\"{x:1131,y:764,t:1528143557334};\\\", \\\"{x:1132,y:771,t:1528143557351};\\\", \\\"{x:1133,y:775,t:1528143557367};\\\", \\\"{x:1135,y:780,t:1528143557384};\\\", \\\"{x:1135,y:785,t:1528143557401};\\\", \\\"{x:1136,y:786,t:1528143557417};\\\", \\\"{x:1136,y:788,t:1528143557434};\\\", \\\"{x:1136,y:789,t:1528143557451};\\\", \\\"{x:1137,y:791,t:1528143557468};\\\", \\\"{x:1137,y:792,t:1528143557484};\\\", \\\"{x:1137,y:794,t:1528143557501};\\\", \\\"{x:1138,y:796,t:1528143557517};\\\", \\\"{x:1138,y:797,t:1528143557537};\\\", \\\"{x:1138,y:798,t:1528143557551};\\\", \\\"{x:1138,y:801,t:1528143557568};\\\", \\\"{x:1138,y:804,t:1528143557584};\\\", \\\"{x:1137,y:811,t:1528143557600};\\\", \\\"{x:1137,y:815,t:1528143557618};\\\", \\\"{x:1135,y:818,t:1528143557634};\\\", \\\"{x:1135,y:820,t:1528143557651};\\\", \\\"{x:1135,y:823,t:1528143557668};\\\", \\\"{x:1135,y:825,t:1528143557704};\\\", \\\"{x:1134,y:826,t:1528143557729};\\\", \\\"{x:1133,y:828,t:1528143557752};\\\", \\\"{x:1133,y:829,t:1528143557768};\\\", \\\"{x:1133,y:831,t:1528143557784};\\\", \\\"{x:1132,y:834,t:1528143557801};\\\", \\\"{x:1132,y:835,t:1528143557818};\\\", \\\"{x:1131,y:839,t:1528143557834};\\\", \\\"{x:1131,y:841,t:1528143557851};\\\", \\\"{x:1130,y:844,t:1528143557868};\\\", \\\"{x:1129,y:845,t:1528143557885};\\\", \\\"{x:1129,y:847,t:1528143557901};\\\", \\\"{x:1129,y:849,t:1528143557918};\\\", \\\"{x:1128,y:851,t:1528143557935};\\\", \\\"{x:1128,y:852,t:1528143557951};\\\", \\\"{x:1127,y:855,t:1528143557968};\\\", \\\"{x:1127,y:858,t:1528143557985};\\\", \\\"{x:1127,y:861,t:1528143558001};\\\", \\\"{x:1126,y:862,t:1528143558018};\\\", \\\"{x:1125,y:862,t:1528143558035};\\\", \\\"{x:1125,y:864,t:1528143558065};\\\", \\\"{x:1124,y:866,t:1528143558080};\\\", \\\"{x:1124,y:867,t:1528143558097};\\\", \\\"{x:1124,y:868,t:1528143558121};\\\", \\\"{x:1124,y:869,t:1528143558145};\\\", \\\"{x:1124,y:870,t:1528143558169};\\\", \\\"{x:1124,y:863,t:1528143558353};\\\", \\\"{x:1124,y:857,t:1528143558367};\\\", \\\"{x:1124,y:831,t:1528143558385};\\\", \\\"{x:1126,y:810,t:1528143558402};\\\", \\\"{x:1128,y:794,t:1528143558418};\\\", \\\"{x:1129,y:791,t:1528143558435};\\\", \\\"{x:1129,y:790,t:1528143558452};\\\", \\\"{x:1129,y:794,t:1528143558553};\\\", \\\"{x:1129,y:802,t:1528143558568};\\\", \\\"{x:1124,y:823,t:1528143558585};\\\", \\\"{x:1121,y:830,t:1528143558602};\\\", \\\"{x:1119,y:837,t:1528143558619};\\\", \\\"{x:1118,y:839,t:1528143558635};\\\", \\\"{x:1117,y:842,t:1528143558652};\\\", \\\"{x:1116,y:848,t:1528143558668};\\\", \\\"{x:1113,y:855,t:1528143558684};\\\", \\\"{x:1108,y:865,t:1528143558702};\\\", \\\"{x:1108,y:872,t:1528143558718};\\\", \\\"{x:1107,y:878,t:1528143558735};\\\", \\\"{x:1107,y:880,t:1528143558752};\\\", \\\"{x:1105,y:884,t:1528143558768};\\\", \\\"{x:1105,y:887,t:1528143558784};\\\", \\\"{x:1105,y:891,t:1528143558801};\\\", \\\"{x:1106,y:896,t:1528143558818};\\\", \\\"{x:1107,y:900,t:1528143558835};\\\", \\\"{x:1108,y:905,t:1528143558851};\\\", \\\"{x:1108,y:907,t:1528143558868};\\\", \\\"{x:1108,y:910,t:1528143558884};\\\", \\\"{x:1108,y:914,t:1528143558902};\\\", \\\"{x:1108,y:920,t:1528143558919};\\\", \\\"{x:1108,y:927,t:1528143558935};\\\", \\\"{x:1108,y:937,t:1528143558952};\\\", \\\"{x:1108,y:939,t:1528143558968};\\\", \\\"{x:1108,y:941,t:1528143558985};\\\", \\\"{x:1108,y:942,t:1528143559002};\\\", \\\"{x:1109,y:943,t:1528143559225};\\\", \\\"{x:1111,y:944,t:1528143559257};\\\", \\\"{x:1113,y:944,t:1528143559273};\\\", \\\"{x:1114,y:944,t:1528143559286};\\\", \\\"{x:1116,y:945,t:1528143559302};\\\", \\\"{x:1120,y:946,t:1528143559319};\\\", \\\"{x:1122,y:946,t:1528143559336};\\\", \\\"{x:1125,y:948,t:1528143559352};\\\", \\\"{x:1126,y:948,t:1528143559369};\\\", \\\"{x:1131,y:949,t:1528143559386};\\\", \\\"{x:1133,y:950,t:1528143559402};\\\", \\\"{x:1138,y:950,t:1528143559419};\\\", \\\"{x:1140,y:951,t:1528143559436};\\\", \\\"{x:1147,y:954,t:1528143559452};\\\", \\\"{x:1152,y:954,t:1528143559469};\\\", \\\"{x:1158,y:954,t:1528143559487};\\\", \\\"{x:1163,y:955,t:1528143559502};\\\", \\\"{x:1167,y:956,t:1528143559519};\\\", \\\"{x:1169,y:957,t:1528143559536};\\\", \\\"{x:1170,y:957,t:1528143559552};\\\", \\\"{x:1172,y:957,t:1528143559576};\\\", \\\"{x:1173,y:957,t:1528143559616};\\\", \\\"{x:1175,y:957,t:1528143559657};\\\", \\\"{x:1176,y:957,t:1528143559713};\\\", \\\"{x:1178,y:957,t:1528143559744};\\\", \\\"{x:1179,y:957,t:1528143559793};\\\", \\\"{x:1181,y:957,t:1528143559849};\\\", \\\"{x:1182,y:957,t:1528143559872};\\\", \\\"{x:1183,y:957,t:1528143559889};\\\", \\\"{x:1184,y:957,t:1528143559905};\\\", \\\"{x:1185,y:957,t:1528143559929};\\\", \\\"{x:1186,y:957,t:1528143559945};\\\", \\\"{x:1187,y:957,t:1528143559969};\\\", \\\"{x:1188,y:957,t:1528143559992};\\\", \\\"{x:1189,y:957,t:1528143560002};\\\", \\\"{x:1190,y:957,t:1528143560023};\\\", \\\"{x:1191,y:957,t:1528143560063};\\\", \\\"{x:1192,y:957,t:1528143560080};\\\", \\\"{x:1193,y:956,t:1528143560096};\\\", \\\"{x:1194,y:956,t:1528143560120};\\\", \\\"{x:1195,y:955,t:1528143560136};\\\", \\\"{x:1196,y:955,t:1528143560152};\\\", \\\"{x:1197,y:955,t:1528143560192};\\\", \\\"{x:1199,y:955,t:1528143560215};\\\", \\\"{x:1200,y:955,t:1528143560248};\\\", \\\"{x:1202,y:955,t:1528143560319};\\\", \\\"{x:1203,y:955,t:1528143560351};\\\", \\\"{x:1204,y:955,t:1528143560439};\\\", \\\"{x:1205,y:955,t:1528143560471};\\\", \\\"{x:1206,y:955,t:1528143560485};\\\", \\\"{x:1207,y:956,t:1528143560502};\\\", \\\"{x:1208,y:957,t:1528143560520};\\\", \\\"{x:1209,y:957,t:1528143560536};\\\", \\\"{x:1211,y:958,t:1528143560568};\\\", \\\"{x:1212,y:958,t:1528143560592};\\\", \\\"{x:1213,y:959,t:1528143560649};\\\", \\\"{x:1210,y:957,t:1528143561129};\\\", \\\"{x:1205,y:955,t:1528143561137};\\\", \\\"{x:1199,y:952,t:1528143561154};\\\", \\\"{x:1192,y:947,t:1528143561170};\\\", \\\"{x:1185,y:937,t:1528143561187};\\\", \\\"{x:1181,y:930,t:1528143561204};\\\", \\\"{x:1179,y:925,t:1528143561220};\\\", \\\"{x:1176,y:921,t:1528143561237};\\\", \\\"{x:1174,y:919,t:1528143561254};\\\", \\\"{x:1174,y:918,t:1528143561271};\\\", \\\"{x:1174,y:915,t:1528143561287};\\\", \\\"{x:1174,y:908,t:1528143561304};\\\", \\\"{x:1174,y:902,t:1528143561320};\\\", \\\"{x:1174,y:897,t:1528143561337};\\\", \\\"{x:1180,y:882,t:1528143561354};\\\", \\\"{x:1190,y:867,t:1528143561370};\\\", \\\"{x:1198,y:851,t:1528143561387};\\\", \\\"{x:1210,y:831,t:1528143561406};\\\", \\\"{x:1222,y:804,t:1528143561420};\\\", \\\"{x:1231,y:779,t:1528143561437};\\\", \\\"{x:1236,y:759,t:1528143561454};\\\", \\\"{x:1237,y:749,t:1528143561471};\\\", \\\"{x:1238,y:741,t:1528143561486};\\\", \\\"{x:1238,y:733,t:1528143561503};\\\", \\\"{x:1238,y:729,t:1528143561519};\\\", \\\"{x:1238,y:723,t:1528143561536};\\\", \\\"{x:1238,y:720,t:1528143561554};\\\", \\\"{x:1238,y:710,t:1528143561571};\\\", \\\"{x:1240,y:698,t:1528143561587};\\\", \\\"{x:1242,y:681,t:1528143561603};\\\", \\\"{x:1246,y:665,t:1528143561620};\\\", \\\"{x:1250,y:652,t:1528143561636};\\\", \\\"{x:1252,y:649,t:1528143561654};\\\", \\\"{x:1254,y:649,t:1528143561671};\\\", \\\"{x:1255,y:649,t:1528143561696};\\\", \\\"{x:1257,y:648,t:1528143561704};\\\", \\\"{x:1258,y:648,t:1528143561753};\\\", \\\"{x:1259,y:651,t:1528143561760};\\\", \\\"{x:1259,y:654,t:1528143561772};\\\", \\\"{x:1260,y:657,t:1528143561787};\\\", \\\"{x:1262,y:659,t:1528143561816};\\\", \\\"{x:1263,y:661,t:1528143561825};\\\", \\\"{x:1265,y:662,t:1528143561837};\\\", \\\"{x:1272,y:666,t:1528143561854};\\\", \\\"{x:1277,y:669,t:1528143561872};\\\", \\\"{x:1285,y:672,t:1528143561889};\\\", \\\"{x:1287,y:673,t:1528143561905};\\\", \\\"{x:1291,y:677,t:1528143561921};\\\", \\\"{x:1296,y:682,t:1528143561938};\\\", \\\"{x:1309,y:698,t:1528143561954};\\\", \\\"{x:1319,y:707,t:1528143561971};\\\", \\\"{x:1325,y:719,t:1528143561988};\\\", \\\"{x:1328,y:737,t:1528143562004};\\\", \\\"{x:1328,y:767,t:1528143562021};\\\", \\\"{x:1324,y:806,t:1528143562037};\\\", \\\"{x:1314,y:838,t:1528143562053};\\\", \\\"{x:1305,y:869,t:1528143562071};\\\", \\\"{x:1288,y:924,t:1528143562087};\\\", \\\"{x:1282,y:941,t:1528143562103};\\\", \\\"{x:1279,y:950,t:1528143562121};\\\", \\\"{x:1277,y:956,t:1528143562138};\\\", \\\"{x:1275,y:961,t:1528143562154};\\\", \\\"{x:1273,y:968,t:1528143562171};\\\", \\\"{x:1272,y:973,t:1528143562188};\\\", \\\"{x:1268,y:983,t:1528143562203};\\\", \\\"{x:1265,y:989,t:1528143562220};\\\", \\\"{x:1263,y:997,t:1528143562238};\\\", \\\"{x:1261,y:1004,t:1528143562254};\\\", \\\"{x:1260,y:1007,t:1528143562271};\\\", \\\"{x:1260,y:1008,t:1528143562288};\\\", \\\"{x:1260,y:1004,t:1528143562417};\\\", \\\"{x:1260,y:996,t:1528143562424};\\\", \\\"{x:1260,y:989,t:1528143562438};\\\", \\\"{x:1260,y:978,t:1528143562456};\\\", \\\"{x:1262,y:969,t:1528143562472};\\\", \\\"{x:1265,y:959,t:1528143562489};\\\", \\\"{x:1265,y:958,t:1528143562505};\\\", \\\"{x:1265,y:957,t:1528143562569};\\\", \\\"{x:1266,y:957,t:1528143563079};\\\", \\\"{x:1268,y:957,t:1528143563087};\\\", \\\"{x:1272,y:957,t:1528143563105};\\\", \\\"{x:1273,y:957,t:1528143563122};\\\", \\\"{x:1274,y:957,t:1528143563160};\\\", \\\"{x:1275,y:957,t:1528143563171};\\\", \\\"{x:1276,y:957,t:1528143563192};\\\", \\\"{x:1277,y:957,t:1528143563224};\\\", \\\"{x:1278,y:957,t:1528143563256};\\\", \\\"{x:1278,y:958,t:1528143563272};\\\", \\\"{x:1279,y:958,t:1528143563313};\\\", \\\"{x:1281,y:959,t:1528143563323};\\\", \\\"{x:1284,y:960,t:1528143563339};\\\", \\\"{x:1285,y:961,t:1528143563356};\\\", \\\"{x:1287,y:961,t:1528143563409};\\\", \\\"{x:1288,y:961,t:1528143563422};\\\", \\\"{x:1291,y:962,t:1528143563440};\\\", \\\"{x:1292,y:962,t:1528143563456};\\\", \\\"{x:1295,y:963,t:1528143563473};\\\", \\\"{x:1296,y:964,t:1528143563489};\\\", \\\"{x:1297,y:964,t:1528143563504};\\\", \\\"{x:1299,y:964,t:1528143563521};\\\", \\\"{x:1303,y:964,t:1528143563539};\\\", \\\"{x:1306,y:964,t:1528143563554};\\\", \\\"{x:1311,y:964,t:1528143563572};\\\", \\\"{x:1313,y:964,t:1528143563589};\\\", \\\"{x:1314,y:964,t:1528143563605};\\\", \\\"{x:1317,y:964,t:1528143563622};\\\", \\\"{x:1321,y:964,t:1528143563638};\\\", \\\"{x:1326,y:965,t:1528143563656};\\\", \\\"{x:1328,y:966,t:1528143563672};\\\", \\\"{x:1332,y:967,t:1528143563689};\\\", \\\"{x:1333,y:968,t:1528143563706};\\\", \\\"{x:1335,y:969,t:1528143563722};\\\", \\\"{x:1339,y:970,t:1528143563739};\\\", \\\"{x:1339,y:971,t:1528143563756};\\\", \\\"{x:1341,y:971,t:1528143563772};\\\", \\\"{x:1343,y:971,t:1528143563873};\\\", \\\"{x:1343,y:961,t:1528143565882};\\\", \\\"{x:1343,y:915,t:1528143565891};\\\", \\\"{x:1328,y:862,t:1528143565907};\\\", \\\"{x:1307,y:829,t:1528143565924};\\\", \\\"{x:1285,y:800,t:1528143565941};\\\", \\\"{x:1259,y:767,t:1528143565958};\\\", \\\"{x:1223,y:721,t:1528143565974};\\\", \\\"{x:1187,y:675,t:1528143565992};\\\", \\\"{x:1170,y:651,t:1528143566007};\\\", \\\"{x:1158,y:620,t:1528143566024};\\\", \\\"{x:1156,y:603,t:1528143566041};\\\", \\\"{x:1155,y:597,t:1528143566057};\\\", \\\"{x:1155,y:594,t:1528143566074};\\\", \\\"{x:1155,y:591,t:1528143566092};\\\", \\\"{x:1155,y:590,t:1528143566108};\\\", \\\"{x:1156,y:590,t:1528143566124};\\\", \\\"{x:1157,y:590,t:1528143566141};\\\", \\\"{x:1158,y:600,t:1528143566160};\\\", \\\"{x:1158,y:611,t:1528143566174};\\\", \\\"{x:1159,y:626,t:1528143566192};\\\", \\\"{x:1161,y:636,t:1528143566208};\\\", \\\"{x:1162,y:656,t:1528143566225};\\\", \\\"{x:1163,y:670,t:1528143566241};\\\", \\\"{x:1164,y:686,t:1528143566257};\\\", \\\"{x:1167,y:703,t:1528143566275};\\\", \\\"{x:1167,y:718,t:1528143566291};\\\", \\\"{x:1167,y:738,t:1528143566308};\\\", \\\"{x:1168,y:764,t:1528143566325};\\\", \\\"{x:1168,y:793,t:1528143566342};\\\", \\\"{x:1170,y:832,t:1528143566358};\\\", \\\"{x:1176,y:880,t:1528143566374};\\\", \\\"{x:1183,y:917,t:1528143566392};\\\", \\\"{x:1187,y:953,t:1528143566408};\\\", \\\"{x:1192,y:962,t:1528143566424};\\\", \\\"{x:1198,y:968,t:1528143566441};\\\", \\\"{x:1202,y:970,t:1528143566458};\\\", \\\"{x:1209,y:971,t:1528143566474};\\\", \\\"{x:1211,y:971,t:1528143566491};\\\", \\\"{x:1216,y:972,t:1528143566508};\\\", \\\"{x:1223,y:973,t:1528143566524};\\\", \\\"{x:1232,y:977,t:1528143566542};\\\", \\\"{x:1245,y:980,t:1528143566559};\\\", \\\"{x:1262,y:985,t:1528143566574};\\\", \\\"{x:1287,y:988,t:1528143566591};\\\", \\\"{x:1323,y:992,t:1528143566608};\\\", \\\"{x:1345,y:993,t:1528143566624};\\\", \\\"{x:1366,y:993,t:1528143566641};\\\", \\\"{x:1388,y:991,t:1528143566658};\\\", \\\"{x:1408,y:984,t:1528143566675};\\\", \\\"{x:1426,y:974,t:1528143566692};\\\", \\\"{x:1433,y:968,t:1528143566709};\\\", \\\"{x:1438,y:965,t:1528143566725};\\\", \\\"{x:1439,y:964,t:1528143566905};\\\", \\\"{x:1439,y:962,t:1528143567130};\\\", \\\"{x:1439,y:961,t:1528143567142};\\\", \\\"{x:1439,y:958,t:1528143567158};\\\", \\\"{x:1439,y:956,t:1528143567175};\\\", \\\"{x:1439,y:952,t:1528143567191};\\\", \\\"{x:1439,y:948,t:1528143567209};\\\", \\\"{x:1441,y:945,t:1528143567225};\\\", \\\"{x:1441,y:944,t:1528143567243};\\\", \\\"{x:1444,y:938,t:1528143567258};\\\", \\\"{x:1447,y:929,t:1528143567274};\\\", \\\"{x:1450,y:916,t:1528143567292};\\\", \\\"{x:1454,y:899,t:1528143567308};\\\", \\\"{x:1455,y:883,t:1528143567325};\\\", \\\"{x:1455,y:870,t:1528143567342};\\\", \\\"{x:1455,y:859,t:1528143567358};\\\", \\\"{x:1455,y:856,t:1528143567375};\\\", \\\"{x:1455,y:855,t:1528143567424};\\\", \\\"{x:1457,y:852,t:1528143567465};\\\", \\\"{x:1457,y:851,t:1528143567480};\\\", \\\"{x:1457,y:848,t:1528143567492};\\\", \\\"{x:1457,y:842,t:1528143567508};\\\", \\\"{x:1457,y:839,t:1528143567525};\\\", \\\"{x:1457,y:838,t:1528143567542};\\\", \\\"{x:1454,y:837,t:1528143567593};\\\", \\\"{x:1425,y:834,t:1528143567608};\\\", \\\"{x:1322,y:814,t:1528143567626};\\\", \\\"{x:1152,y:778,t:1528143567642};\\\", \\\"{x:967,y:728,t:1528143567660};\\\", \\\"{x:822,y:698,t:1528143567675};\\\", \\\"{x:719,y:668,t:1528143567693};\\\", \\\"{x:609,y:635,t:1528143567709};\\\", \\\"{x:485,y:588,t:1528143567726};\\\", \\\"{x:388,y:543,t:1528143567743};\\\", \\\"{x:303,y:509,t:1528143567759};\\\", \\\"{x:255,y:486,t:1528143567776};\\\", \\\"{x:254,y:485,t:1528143567799};\\\", \\\"{x:254,y:484,t:1528143567832};\\\", \\\"{x:256,y:485,t:1528143568016};\\\", \\\"{x:261,y:494,t:1528143568027};\\\", \\\"{x:267,y:509,t:1528143568043};\\\", \\\"{x:273,y:519,t:1528143568060};\\\", \\\"{x:276,y:524,t:1528143568076};\\\", \\\"{x:280,y:535,t:1528143568093};\\\", \\\"{x:281,y:541,t:1528143568110};\\\", \\\"{x:285,y:548,t:1528143568125};\\\", \\\"{x:285,y:551,t:1528143568143};\\\", \\\"{x:285,y:553,t:1528143568159};\\\", \\\"{x:285,y:558,t:1528143568176};\\\", \\\"{x:283,y:567,t:1528143568193};\\\", \\\"{x:277,y:580,t:1528143568210};\\\", \\\"{x:269,y:594,t:1528143568226};\\\", \\\"{x:258,y:608,t:1528143568243};\\\", \\\"{x:248,y:616,t:1528143568260};\\\", \\\"{x:234,y:623,t:1528143568275};\\\", \\\"{x:217,y:626,t:1528143568293};\\\", \\\"{x:206,y:627,t:1528143568310};\\\", \\\"{x:199,y:627,t:1528143568325};\\\", \\\"{x:198,y:627,t:1528143568343};\\\", \\\"{x:198,y:628,t:1528143568375};\\\", \\\"{x:198,y:629,t:1528143568393};\\\", \\\"{x:198,y:630,t:1528143568410};\\\", \\\"{x:199,y:631,t:1528143568432};\\\", \\\"{x:200,y:631,t:1528143568456};\\\", \\\"{x:204,y:631,t:1528143568464};\\\", \\\"{x:207,y:629,t:1528143568477};\\\", \\\"{x:212,y:623,t:1528143568493};\\\", \\\"{x:216,y:616,t:1528143568510};\\\", \\\"{x:223,y:605,t:1528143568527};\\\", \\\"{x:231,y:595,t:1528143568544};\\\", \\\"{x:249,y:579,t:1528143568560};\\\", \\\"{x:260,y:574,t:1528143568576};\\\", \\\"{x:278,y:569,t:1528143568593};\\\", \\\"{x:323,y:567,t:1528143568609};\\\", \\\"{x:403,y:567,t:1528143568626};\\\", \\\"{x:473,y:567,t:1528143568643};\\\", \\\"{x:559,y:567,t:1528143568660};\\\", \\\"{x:631,y:567,t:1528143568676};\\\", \\\"{x:695,y:567,t:1528143568693};\\\", \\\"{x:740,y:567,t:1528143568711};\\\", \\\"{x:769,y:565,t:1528143568727};\\\", \\\"{x:784,y:563,t:1528143568743};\\\", \\\"{x:800,y:559,t:1528143568759};\\\", \\\"{x:802,y:558,t:1528143568777};\\\", \\\"{x:803,y:557,t:1528143568848};\\\", \\\"{x:798,y:557,t:1528143568993};\\\", \\\"{x:790,y:561,t:1528143569000};\\\", \\\"{x:781,y:564,t:1528143569010};\\\", \\\"{x:753,y:573,t:1528143569026};\\\", \\\"{x:731,y:580,t:1528143569043};\\\", \\\"{x:712,y:587,t:1528143569061};\\\", \\\"{x:692,y:592,t:1528143569077};\\\", \\\"{x:683,y:595,t:1528143569095};\\\", \\\"{x:680,y:595,t:1528143569110};\\\", \\\"{x:676,y:596,t:1528143569127};\\\", \\\"{x:671,y:596,t:1528143569143};\\\", \\\"{x:659,y:598,t:1528143569160};\\\", \\\"{x:653,y:599,t:1528143569177};\\\", \\\"{x:651,y:599,t:1528143569193};\\\", \\\"{x:648,y:599,t:1528143569210};\\\", \\\"{x:646,y:599,t:1528143569227};\\\", \\\"{x:645,y:599,t:1528143569243};\\\", \\\"{x:644,y:599,t:1528143569337};\\\", \\\"{x:644,y:598,t:1528143569369};\\\", \\\"{x:644,y:597,t:1528143569378};\\\", \\\"{x:644,y:595,t:1528143569394};\\\", \\\"{x:644,y:594,t:1528143569416};\\\", \\\"{x:644,y:593,t:1528143569449};\\\", \\\"{x:644,y:592,t:1528143569472};\\\", \\\"{x:643,y:592,t:1528143569480};\\\", \\\"{x:641,y:590,t:1528143569496};\\\", \\\"{x:640,y:590,t:1528143569511};\\\", \\\"{x:638,y:589,t:1528143569527};\\\", \\\"{x:637,y:588,t:1528143569545};\\\", \\\"{x:634,y:587,t:1528143569561};\\\", \\\"{x:631,y:586,t:1528143569578};\\\", \\\"{x:629,y:585,t:1528143569594};\\\", \\\"{x:628,y:584,t:1528143569616};\\\", \\\"{x:626,y:583,t:1528143569632};\\\", \\\"{x:624,y:583,t:1528143569655};\\\", \\\"{x:626,y:583,t:1528143569847};\\\", \\\"{x:635,y:583,t:1528143569861};\\\", \\\"{x:655,y:583,t:1528143569878};\\\", \\\"{x:682,y:583,t:1528143569894};\\\", \\\"{x:711,y:583,t:1528143569911};\\\", \\\"{x:741,y:583,t:1528143569927};\\\", \\\"{x:750,y:583,t:1528143569944};\\\", \\\"{x:756,y:583,t:1528143569961};\\\", \\\"{x:759,y:583,t:1528143569978};\\\", \\\"{x:761,y:583,t:1528143569994};\\\", \\\"{x:767,y:583,t:1528143570011};\\\", \\\"{x:774,y:583,t:1528143570028};\\\", \\\"{x:782,y:583,t:1528143570044};\\\", \\\"{x:785,y:583,t:1528143570061};\\\", \\\"{x:789,y:583,t:1528143570078};\\\", \\\"{x:797,y:583,t:1528143570094};\\\", \\\"{x:805,y:583,t:1528143570111};\\\", \\\"{x:809,y:583,t:1528143570128};\\\", \\\"{x:811,y:583,t:1528143570160};\\\", \\\"{x:812,y:583,t:1528143570209};\\\", \\\"{x:814,y:583,t:1528143570216};\\\", \\\"{x:818,y:583,t:1528143570228};\\\", \\\"{x:829,y:582,t:1528143570245};\\\", \\\"{x:837,y:582,t:1528143570260};\\\", \\\"{x:838,y:582,t:1528143570278};\\\", \\\"{x:839,y:582,t:1528143570295};\\\", \\\"{x:840,y:582,t:1528143570311};\\\", \\\"{x:838,y:582,t:1528143571897};\\\", \\\"{x:836,y:582,t:1528143571912};\\\", \\\"{x:832,y:586,t:1528143571929};\\\", \\\"{x:823,y:598,t:1528143571947};\\\", \\\"{x:814,y:610,t:1528143571964};\\\", \\\"{x:803,y:625,t:1528143571979};\\\", \\\"{x:797,y:635,t:1528143571995};\\\", \\\"{x:791,y:642,t:1528143572012};\\\", \\\"{x:787,y:647,t:1528143572029};\\\", \\\"{x:784,y:650,t:1528143572046};\\\", \\\"{x:782,y:652,t:1528143572063};\\\", \\\"{x:780,y:654,t:1528143572078};\\\", \\\"{x:762,y:670,t:1528143572096};\\\", \\\"{x:725,y:693,t:1528143572113};\\\", \\\"{x:655,y:730,t:1528143572129};\\\", \\\"{x:597,y:755,t:1528143572146};\\\", \\\"{x:538,y:772,t:1528143572163};\\\", \\\"{x:504,y:778,t:1528143572179};\\\", \\\"{x:479,y:779,t:1528143572197};\\\", \\\"{x:458,y:779,t:1528143572213};\\\", \\\"{x:447,y:779,t:1528143572229};\\\", \\\"{x:444,y:779,t:1528143572246};\\\", \\\"{x:444,y:776,t:1528143572417};\\\", \\\"{x:445,y:769,t:1528143572430};\\\", \\\"{x:450,y:762,t:1528143572450};\\\", \\\"{x:453,y:758,t:1528143572467};\\\", \\\"{x:455,y:755,t:1528143572483};\\\", \\\"{x:458,y:754,t:1528143572501};\\\", \\\"{x:459,y:754,t:1528143572516};\\\", \\\"{x:460,y:753,t:1528143572534};\\\", \\\"{x:461,y:753,t:1528143572555};\\\", \\\"{x:462,y:752,t:1528143572571};\\\", \\\"{x:463,y:752,t:1528143572603};\\\", \\\"{x:464,y:752,t:1528143572619};\\\", \\\"{x:466,y:751,t:1528143572634};\\\", \\\"{x:466,y:750,t:1528143572651};\\\", \\\"{x:467,y:750,t:1528143572667};\\\", \\\"{x:469,y:747,t:1528143572684};\\\", \\\"{x:474,y:742,t:1528143572701};\\\", \\\"{x:478,y:738,t:1528143572717};\\\", \\\"{x:481,y:731,t:1528143572734};\\\", \\\"{x:482,y:727,t:1528143572752};\\\", \\\"{x:483,y:727,t:1528143572767};\\\", \\\"{x:483,y:726,t:1528143572784};\\\", \\\"{x:484,y:726,t:1528143573140};\\\" ] }, { \\\"rt\\\": 40401, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 703078, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -03 PM-03 PM-B -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:726,t:1528143575540};\\\", \\\"{x:480,y:726,t:1528143575575};\\\", \\\"{x:477,y:726,t:1528143575585};\\\", \\\"{x:468,y:721,t:1528143575602};\\\", \\\"{x:439,y:653,t:1528143575620};\\\", \\\"{x:406,y:587,t:1528143575636};\\\", \\\"{x:398,y:581,t:1528143575653};\\\", \\\"{x:392,y:571,t:1528143575669};\\\", \\\"{x:388,y:567,t:1528143575686};\\\", \\\"{x:386,y:566,t:1528143575703};\\\", \\\"{x:386,y:565,t:1528143575869};\\\", \\\"{x:383,y:564,t:1528143575886};\\\", \\\"{x:381,y:560,t:1528143575905};\\\", \\\"{x:371,y:547,t:1528143575921};\\\", \\\"{x:363,y:535,t:1528143575935};\\\", \\\"{x:362,y:534,t:1528143575953};\\\", \\\"{x:362,y:533,t:1528143575970};\\\", \\\"{x:361,y:532,t:1528143575986};\\\", \\\"{x:360,y:532,t:1528143576003};\\\", \\\"{x:359,y:532,t:1528143576068};\\\", \\\"{x:359,y:531,t:1528143576076};\\\", \\\"{x:359,y:530,t:1528143576099};\\\", \\\"{x:356,y:527,t:1528143576108};\\\", \\\"{x:356,y:526,t:1528143576120};\\\", \\\"{x:356,y:524,t:1528143576138};\\\", \\\"{x:356,y:522,t:1528143576153};\\\", \\\"{x:356,y:521,t:1528143576170};\\\", \\\"{x:358,y:516,t:1528143576188};\\\", \\\"{x:365,y:516,t:1528143576203};\\\", \\\"{x:379,y:517,t:1528143576219};\\\", \\\"{x:403,y:521,t:1528143576237};\\\", \\\"{x:426,y:526,t:1528143576253};\\\", \\\"{x:435,y:526,t:1528143576270};\\\", \\\"{x:449,y:524,t:1528143576286};\\\", \\\"{x:464,y:519,t:1528143576303};\\\", \\\"{x:475,y:515,t:1528143576320};\\\", \\\"{x:480,y:514,t:1528143576337};\\\", \\\"{x:481,y:514,t:1528143576353};\\\", \\\"{x:482,y:514,t:1528143576370};\\\", \\\"{x:483,y:514,t:1528143576387};\\\", \\\"{x:485,y:514,t:1528143576403};\\\", \\\"{x:488,y:514,t:1528143576420};\\\", \\\"{x:490,y:514,t:1528143576437};\\\", \\\"{x:495,y:512,t:1528143576454};\\\", \\\"{x:500,y:512,t:1528143576472};\\\", \\\"{x:504,y:511,t:1528143576487};\\\", \\\"{x:507,y:510,t:1528143576503};\\\", \\\"{x:512,y:507,t:1528143576520};\\\", \\\"{x:515,y:505,t:1528143576537};\\\", \\\"{x:518,y:504,t:1528143576552};\\\", \\\"{x:522,y:501,t:1528143576570};\\\", \\\"{x:527,y:498,t:1528143576587};\\\", \\\"{x:531,y:497,t:1528143576603};\\\", \\\"{x:534,y:497,t:1528143576620};\\\", \\\"{x:537,y:497,t:1528143576637};\\\", \\\"{x:542,y:497,t:1528143576654};\\\", \\\"{x:546,y:497,t:1528143576670};\\\", \\\"{x:550,y:497,t:1528143576687};\\\", \\\"{x:555,y:497,t:1528143576704};\\\", \\\"{x:559,y:495,t:1528143576720};\\\", \\\"{x:566,y:491,t:1528143576737};\\\", \\\"{x:574,y:487,t:1528143576755};\\\", \\\"{x:585,y:479,t:1528143576771};\\\", \\\"{x:592,y:475,t:1528143576787};\\\", \\\"{x:597,y:474,t:1528143576803};\\\", \\\"{x:601,y:474,t:1528143576820};\\\", \\\"{x:607,y:474,t:1528143576837};\\\", \\\"{x:610,y:474,t:1528143576854};\\\", \\\"{x:614,y:475,t:1528143576870};\\\", \\\"{x:618,y:475,t:1528143576887};\\\", \\\"{x:619,y:475,t:1528143576907};\\\", \\\"{x:621,y:475,t:1528143576920};\\\", \\\"{x:624,y:475,t:1528143576937};\\\", \\\"{x:627,y:475,t:1528143576954};\\\", \\\"{x:631,y:475,t:1528143576970};\\\", \\\"{x:635,y:474,t:1528143576987};\\\", \\\"{x:636,y:474,t:1528143577004};\\\", \\\"{x:639,y:474,t:1528143577020};\\\", \\\"{x:642,y:474,t:1528143577037};\\\", \\\"{x:644,y:474,t:1528143577054};\\\", \\\"{x:644,y:472,t:1528143577188};\\\", \\\"{x:635,y:466,t:1528143577204};\\\", \\\"{x:612,y:455,t:1528143577221};\\\", \\\"{x:573,y:441,t:1528143577237};\\\", \\\"{x:526,y:429,t:1528143577254};\\\", \\\"{x:479,y:423,t:1528143577271};\\\", \\\"{x:434,y:417,t:1528143577287};\\\", \\\"{x:401,y:414,t:1528143577305};\\\", \\\"{x:379,y:414,t:1528143577321};\\\", \\\"{x:369,y:414,t:1528143577337};\\\", \\\"{x:367,y:415,t:1528143577354};\\\", \\\"{x:366,y:415,t:1528143577371};\\\", \\\"{x:365,y:418,t:1528143577444};\\\", \\\"{x:365,y:421,t:1528143577455};\\\", \\\"{x:363,y:428,t:1528143577472};\\\", \\\"{x:358,y:440,t:1528143577487};\\\", \\\"{x:355,y:451,t:1528143577504};\\\", \\\"{x:348,y:463,t:1528143577522};\\\", \\\"{x:341,y:475,t:1528143577538};\\\", \\\"{x:336,y:483,t:1528143577555};\\\", \\\"{x:322,y:490,t:1528143577573};\\\", \\\"{x:293,y:496,t:1528143577587};\\\", \\\"{x:254,y:497,t:1528143577605};\\\", \\\"{x:217,y:497,t:1528143577621};\\\", \\\"{x:197,y:497,t:1528143577637};\\\", \\\"{x:188,y:497,t:1528143577654};\\\", \\\"{x:185,y:496,t:1528143577671};\\\", \\\"{x:185,y:495,t:1528143577707};\\\", \\\"{x:185,y:493,t:1528143577828};\\\", \\\"{x:185,y:491,t:1528143577844};\\\", \\\"{x:186,y:491,t:1528143577855};\\\", \\\"{x:191,y:489,t:1528143577873};\\\", \\\"{x:194,y:488,t:1528143577889};\\\", \\\"{x:199,y:488,t:1528143577906};\\\", \\\"{x:202,y:488,t:1528143577922};\\\", \\\"{x:206,y:488,t:1528143577939};\\\", \\\"{x:211,y:487,t:1528143577956};\\\", \\\"{x:212,y:487,t:1528143577971};\\\", \\\"{x:216,y:485,t:1528143577990};\\\", \\\"{x:218,y:484,t:1528143578005};\\\", \\\"{x:222,y:484,t:1528143578021};\\\", \\\"{x:227,y:482,t:1528143578037};\\\", \\\"{x:233,y:481,t:1528143578054};\\\", \\\"{x:237,y:481,t:1528143578071};\\\", \\\"{x:245,y:481,t:1528143578087};\\\", \\\"{x:256,y:481,t:1528143578104};\\\", \\\"{x:269,y:481,t:1528143578121};\\\", \\\"{x:284,y:481,t:1528143578138};\\\", \\\"{x:302,y:481,t:1528143578154};\\\", \\\"{x:322,y:481,t:1528143578171};\\\", \\\"{x:360,y:481,t:1528143578188};\\\", \\\"{x:390,y:481,t:1528143578206};\\\", \\\"{x:420,y:481,t:1528143578221};\\\", \\\"{x:447,y:481,t:1528143578237};\\\", \\\"{x:469,y:479,t:1528143578254};\\\", \\\"{x:498,y:479,t:1528143578271};\\\", \\\"{x:522,y:479,t:1528143578287};\\\", \\\"{x:540,y:479,t:1528143578305};\\\", \\\"{x:555,y:479,t:1528143578321};\\\", \\\"{x:566,y:479,t:1528143578338};\\\", \\\"{x:581,y:482,t:1528143578355};\\\", \\\"{x:597,y:488,t:1528143578371};\\\", \\\"{x:646,y:500,t:1528143578387};\\\", \\\"{x:695,y:503,t:1528143578405};\\\", \\\"{x:772,y:510,t:1528143578423};\\\", \\\"{x:848,y:515,t:1528143578438};\\\", \\\"{x:924,y:519,t:1528143578455};\\\", \\\"{x:977,y:519,t:1528143578472};\\\", \\\"{x:1036,y:519,t:1528143578489};\\\", \\\"{x:1097,y:519,t:1528143578505};\\\", \\\"{x:1145,y:519,t:1528143578523};\\\", \\\"{x:1169,y:517,t:1528143578538};\\\", \\\"{x:1191,y:513,t:1528143578555};\\\", \\\"{x:1194,y:511,t:1528143578572};\\\", \\\"{x:1194,y:510,t:1528143578612};\\\", \\\"{x:1193,y:508,t:1528143578623};\\\", \\\"{x:1187,y:504,t:1528143578639};\\\", \\\"{x:1182,y:499,t:1528143578655};\\\", \\\"{x:1177,y:493,t:1528143578672};\\\", \\\"{x:1177,y:492,t:1528143578690};\\\", \\\"{x:1176,y:490,t:1528143578765};\\\", \\\"{x:1174,y:487,t:1528143578780};\\\", \\\"{x:1173,y:487,t:1528143578789};\\\", \\\"{x:1172,y:485,t:1528143578806};\\\", \\\"{x:1170,y:483,t:1528143578822};\\\", \\\"{x:1169,y:483,t:1528143578940};\\\", \\\"{x:1166,y:486,t:1528143578955};\\\", \\\"{x:1163,y:494,t:1528143578972};\\\", \\\"{x:1160,y:499,t:1528143578989};\\\", \\\"{x:1160,y:500,t:1528143579012};\\\", \\\"{x:1159,y:501,t:1528143584213};\\\", \\\"{x:1162,y:503,t:1528143584228};\\\", \\\"{x:1168,y:506,t:1528143584236};\\\", \\\"{x:1168,y:510,t:1528143584249};\\\", \\\"{x:1171,y:519,t:1528143584265};\\\", \\\"{x:1173,y:525,t:1528143584283};\\\", \\\"{x:1177,y:528,t:1528143584300};\\\", \\\"{x:1181,y:533,t:1528143584316};\\\", \\\"{x:1185,y:538,t:1528143584332};\\\", \\\"{x:1186,y:540,t:1528143584350};\\\", \\\"{x:1188,y:542,t:1528143584366};\\\", \\\"{x:1191,y:545,t:1528143584382};\\\", \\\"{x:1192,y:550,t:1528143584399};\\\", \\\"{x:1195,y:556,t:1528143584415};\\\", \\\"{x:1199,y:565,t:1528143584431};\\\", \\\"{x:1204,y:579,t:1528143584448};\\\", \\\"{x:1211,y:592,t:1528143584466};\\\", \\\"{x:1220,y:612,t:1528143584482};\\\", \\\"{x:1228,y:629,t:1528143584499};\\\", \\\"{x:1244,y:651,t:1528143584516};\\\", \\\"{x:1255,y:664,t:1528143584532};\\\", \\\"{x:1266,y:678,t:1528143584549};\\\", \\\"{x:1273,y:686,t:1528143584565};\\\", \\\"{x:1281,y:694,t:1528143584582};\\\", \\\"{x:1288,y:704,t:1528143584598};\\\", \\\"{x:1296,y:713,t:1528143584615};\\\", \\\"{x:1303,y:721,t:1528143584633};\\\", \\\"{x:1306,y:727,t:1528143584649};\\\", \\\"{x:1308,y:731,t:1528143584665};\\\", \\\"{x:1311,y:735,t:1528143584683};\\\", \\\"{x:1313,y:738,t:1528143584699};\\\", \\\"{x:1314,y:739,t:1528143584715};\\\", \\\"{x:1315,y:740,t:1528143584732};\\\", \\\"{x:1316,y:740,t:1528143584749};\\\", \\\"{x:1317,y:741,t:1528143584766};\\\", \\\"{x:1319,y:741,t:1528143584783};\\\", \\\"{x:1321,y:742,t:1528143584800};\\\", \\\"{x:1322,y:742,t:1528143584815};\\\", \\\"{x:1323,y:743,t:1528143584833};\\\", \\\"{x:1325,y:744,t:1528143584876};\\\", \\\"{x:1326,y:744,t:1528143584892};\\\", \\\"{x:1327,y:745,t:1528143584900};\\\", \\\"{x:1329,y:746,t:1528143584917};\\\", \\\"{x:1331,y:747,t:1528143584933};\\\", \\\"{x:1332,y:748,t:1528143584950};\\\", \\\"{x:1333,y:748,t:1528143584967};\\\", \\\"{x:1335,y:748,t:1528143584983};\\\", \\\"{x:1337,y:750,t:1528143585028};\\\", \\\"{x:1338,y:750,t:1528143585044};\\\", \\\"{x:1339,y:750,t:1528143585085};\\\", \\\"{x:1339,y:751,t:1528143585125};\\\", \\\"{x:1340,y:751,t:1528143585148};\\\", \\\"{x:1342,y:753,t:1528143585164};\\\", \\\"{x:1343,y:753,t:1528143585181};\\\", \\\"{x:1344,y:754,t:1528143585187};\\\", \\\"{x:1346,y:756,t:1528143585200};\\\", \\\"{x:1349,y:758,t:1528143585220};\\\", \\\"{x:1350,y:759,t:1528143585233};\\\", \\\"{x:1351,y:760,t:1528143585249};\\\", \\\"{x:1351,y:761,t:1528143585266};\\\", \\\"{x:1350,y:766,t:1528143588308};\\\", \\\"{x:1337,y:781,t:1528143588324};\\\", \\\"{x:1320,y:801,t:1528143588340};\\\", \\\"{x:1301,y:829,t:1528143588356};\\\", \\\"{x:1293,y:839,t:1528143588372};\\\", \\\"{x:1289,y:844,t:1528143588389};\\\", \\\"{x:1289,y:846,t:1528143588407};\\\", \\\"{x:1287,y:849,t:1528143588423};\\\", \\\"{x:1287,y:851,t:1528143588468};\\\", \\\"{x:1287,y:852,t:1528143588476};\\\", \\\"{x:1287,y:854,t:1528143588492};\\\", \\\"{x:1287,y:857,t:1528143588506};\\\", \\\"{x:1287,y:861,t:1528143588523};\\\", \\\"{x:1286,y:866,t:1528143588540};\\\", \\\"{x:1283,y:881,t:1528143588556};\\\", \\\"{x:1281,y:889,t:1528143588573};\\\", \\\"{x:1280,y:896,t:1528143588589};\\\", \\\"{x:1278,y:900,t:1528143588606};\\\", \\\"{x:1277,y:903,t:1528143588624};\\\", \\\"{x:1277,y:904,t:1528143588639};\\\", \\\"{x:1277,y:905,t:1528143588660};\\\", \\\"{x:1277,y:906,t:1528143588673};\\\", \\\"{x:1276,y:908,t:1528143588689};\\\", \\\"{x:1275,y:910,t:1528143588706};\\\", \\\"{x:1274,y:915,t:1528143588723};\\\", \\\"{x:1270,y:922,t:1528143588740};\\\", \\\"{x:1268,y:928,t:1528143588756};\\\", \\\"{x:1265,y:935,t:1528143588774};\\\", \\\"{x:1263,y:940,t:1528143588789};\\\", \\\"{x:1261,y:945,t:1528143588805};\\\", \\\"{x:1260,y:946,t:1528143588823};\\\", \\\"{x:1259,y:949,t:1528143588840};\\\", \\\"{x:1258,y:950,t:1528143588855};\\\", \\\"{x:1258,y:952,t:1528143588923};\\\", \\\"{x:1256,y:952,t:1528143588948};\\\", \\\"{x:1256,y:953,t:1528143588963};\\\", \\\"{x:1255,y:954,t:1528143588973};\\\", \\\"{x:1254,y:954,t:1528143588996};\\\", \\\"{x:1252,y:954,t:1528143589036};\\\", \\\"{x:1252,y:955,t:1528143589044};\\\", \\\"{x:1250,y:956,t:1528143589076};\\\", \\\"{x:1249,y:956,t:1528143589092};\\\", \\\"{x:1249,y:955,t:1528143589692};\\\", \\\"{x:1250,y:952,t:1528143589708};\\\", \\\"{x:1251,y:948,t:1528143589725};\\\", \\\"{x:1255,y:940,t:1528143589742};\\\", \\\"{x:1257,y:933,t:1528143589758};\\\", \\\"{x:1259,y:931,t:1528143589775};\\\", \\\"{x:1261,y:926,t:1528143589791};\\\", \\\"{x:1263,y:920,t:1528143589809};\\\", \\\"{x:1266,y:915,t:1528143589825};\\\", \\\"{x:1267,y:909,t:1528143589840};\\\", \\\"{x:1270,y:904,t:1528143589857};\\\", \\\"{x:1274,y:899,t:1528143589875};\\\", \\\"{x:1276,y:895,t:1528143589890};\\\", \\\"{x:1283,y:884,t:1528143589908};\\\", \\\"{x:1292,y:874,t:1528143589925};\\\", \\\"{x:1299,y:866,t:1528143589942};\\\", \\\"{x:1303,y:861,t:1528143589958};\\\", \\\"{x:1309,y:853,t:1528143589975};\\\", \\\"{x:1317,y:843,t:1528143589992};\\\", \\\"{x:1322,y:836,t:1528143590008};\\\", \\\"{x:1327,y:826,t:1528143590025};\\\", \\\"{x:1332,y:818,t:1528143590042};\\\", \\\"{x:1335,y:813,t:1528143590058};\\\", \\\"{x:1337,y:808,t:1528143590075};\\\", \\\"{x:1341,y:799,t:1528143590091};\\\", \\\"{x:1343,y:792,t:1528143590107};\\\", \\\"{x:1345,y:786,t:1528143590125};\\\", \\\"{x:1346,y:782,t:1528143590142};\\\", \\\"{x:1347,y:778,t:1528143590159};\\\", \\\"{x:1347,y:775,t:1528143590175};\\\", \\\"{x:1347,y:773,t:1528143590192};\\\", \\\"{x:1348,y:771,t:1528143590208};\\\", \\\"{x:1348,y:770,t:1528143590244};\\\", \\\"{x:1348,y:769,t:1528143590260};\\\", \\\"{x:1348,y:768,t:1528143590275};\\\", \\\"{x:1349,y:763,t:1528143590292};\\\", \\\"{x:1349,y:760,t:1528143590309};\\\", \\\"{x:1349,y:759,t:1528143590325};\\\", \\\"{x:1349,y:757,t:1528143590343};\\\", \\\"{x:1350,y:755,t:1528143590359};\\\", \\\"{x:1350,y:754,t:1528143590380};\\\", \\\"{x:1352,y:752,t:1528143590396};\\\", \\\"{x:1351,y:752,t:1528143590813};\\\", \\\"{x:1350,y:752,t:1528143590844};\\\", \\\"{x:1349,y:752,t:1528143590868};\\\", \\\"{x:1347,y:752,t:1528143590932};\\\", \\\"{x:1346,y:752,t:1528143590943};\\\", \\\"{x:1345,y:752,t:1528143590959};\\\", \\\"{x:1344,y:752,t:1528143590977};\\\", \\\"{x:1343,y:753,t:1528143590992};\\\", \\\"{x:1342,y:753,t:1528143591709};\\\", \\\"{x:1342,y:754,t:1528143591748};\\\", \\\"{x:1342,y:755,t:1528143591805};\\\", \\\"{x:1342,y:756,t:1528143591884};\\\", \\\"{x:1342,y:757,t:1528143591908};\\\", \\\"{x:1342,y:758,t:1528143591956};\\\", \\\"{x:1342,y:759,t:1528143592156};\\\", \\\"{x:1344,y:769,t:1528143593406};\\\", \\\"{x:1375,y:786,t:1528143593415};\\\", \\\"{x:1428,y:822,t:1528143593431};\\\", \\\"{x:1432,y:828,t:1528143593448};\\\", \\\"{x:1438,y:834,t:1528143593465};\\\", \\\"{x:1439,y:834,t:1528143593500};\\\", \\\"{x:1441,y:836,t:1528143593514};\\\", \\\"{x:1445,y:838,t:1528143593531};\\\", \\\"{x:1442,y:835,t:1528143593644};\\\", \\\"{x:1437,y:832,t:1528143593652};\\\", \\\"{x:1435,y:829,t:1528143593665};\\\", \\\"{x:1433,y:826,t:1528143593682};\\\", \\\"{x:1432,y:824,t:1528143593699};\\\", \\\"{x:1432,y:823,t:1528143593715};\\\", \\\"{x:1432,y:822,t:1528143593732};\\\", \\\"{x:1434,y:822,t:1528143593844};\\\", \\\"{x:1439,y:822,t:1528143593853};\\\", \\\"{x:1443,y:822,t:1528143593865};\\\", \\\"{x:1448,y:822,t:1528143593882};\\\", \\\"{x:1450,y:822,t:1528143593898};\\\", \\\"{x:1453,y:822,t:1528143593916};\\\", \\\"{x:1454,y:823,t:1528143593932};\\\", \\\"{x:1456,y:823,t:1528143593949};\\\", \\\"{x:1457,y:823,t:1528143593972};\\\", \\\"{x:1457,y:824,t:1528143593982};\\\", \\\"{x:1459,y:824,t:1528143594045};\\\", \\\"{x:1459,y:825,t:1528143594076};\\\", \\\"{x:1460,y:826,t:1528143594084};\\\", \\\"{x:1461,y:826,t:1528143594100};\\\", \\\"{x:1462,y:826,t:1528143594116};\\\", \\\"{x:1464,y:828,t:1528143594133};\\\", \\\"{x:1466,y:830,t:1528143594149};\\\", \\\"{x:1470,y:834,t:1528143594166};\\\", \\\"{x:1471,y:836,t:1528143594183};\\\", \\\"{x:1473,y:838,t:1528143594200};\\\", \\\"{x:1474,y:842,t:1528143594215};\\\", \\\"{x:1476,y:844,t:1528143594232};\\\", \\\"{x:1478,y:849,t:1528143594249};\\\", \\\"{x:1480,y:852,t:1528143594265};\\\", \\\"{x:1481,y:856,t:1528143594282};\\\", \\\"{x:1484,y:861,t:1528143594300};\\\", \\\"{x:1488,y:866,t:1528143594316};\\\", \\\"{x:1494,y:874,t:1528143594333};\\\", \\\"{x:1498,y:882,t:1528143594349};\\\", \\\"{x:1503,y:891,t:1528143594366};\\\", \\\"{x:1509,y:901,t:1528143594382};\\\", \\\"{x:1517,y:911,t:1528143594399};\\\", \\\"{x:1528,y:926,t:1528143594416};\\\", \\\"{x:1537,y:940,t:1528143594432};\\\", \\\"{x:1542,y:948,t:1528143594449};\\\", \\\"{x:1544,y:953,t:1528143594465};\\\", \\\"{x:1547,y:962,t:1528143594482};\\\", \\\"{x:1548,y:968,t:1528143594499};\\\", \\\"{x:1550,y:975,t:1528143594516};\\\", \\\"{x:1551,y:977,t:1528143594532};\\\", \\\"{x:1553,y:981,t:1528143594549};\\\", \\\"{x:1555,y:984,t:1528143594566};\\\", \\\"{x:1557,y:986,t:1528143594582};\\\", \\\"{x:1561,y:989,t:1528143594599};\\\", \\\"{x:1561,y:990,t:1528143594635};\\\", \\\"{x:1562,y:991,t:1528143594649};\\\", \\\"{x:1561,y:991,t:1528143594964};\\\", \\\"{x:1559,y:989,t:1528143594972};\\\", \\\"{x:1557,y:985,t:1528143594983};\\\", \\\"{x:1556,y:982,t:1528143595001};\\\", \\\"{x:1555,y:981,t:1528143595018};\\\", \\\"{x:1555,y:980,t:1528143595420};\\\", \\\"{x:1554,y:979,t:1528143595444};\\\", \\\"{x:1553,y:979,t:1528143595476};\\\", \\\"{x:1551,y:977,t:1528143595484};\\\", \\\"{x:1533,y:969,t:1528143595501};\\\", \\\"{x:1514,y:949,t:1528143595518};\\\", \\\"{x:1481,y:921,t:1528143595535};\\\", \\\"{x:1444,y:894,t:1528143595551};\\\", \\\"{x:1391,y:858,t:1528143595568};\\\", \\\"{x:1351,y:828,t:1528143595585};\\\", \\\"{x:1322,y:793,t:1528143595602};\\\", \\\"{x:1307,y:766,t:1528143595618};\\\", \\\"{x:1304,y:756,t:1528143595634};\\\", \\\"{x:1304,y:749,t:1528143595651};\\\", \\\"{x:1304,y:745,t:1528143595668};\\\", \\\"{x:1304,y:743,t:1528143595684};\\\", \\\"{x:1304,y:744,t:1528143595941};\\\", \\\"{x:1304,y:746,t:1528143595952};\\\", \\\"{x:1304,y:748,t:1528143595969};\\\", \\\"{x:1305,y:749,t:1528143595985};\\\", \\\"{x:1305,y:751,t:1528143596003};\\\", \\\"{x:1307,y:752,t:1528143596019};\\\", \\\"{x:1307,y:753,t:1528143596076};\\\", \\\"{x:1308,y:755,t:1528143596100};\\\", \\\"{x:1308,y:756,t:1528143596116};\\\", \\\"{x:1308,y:758,t:1528143596124};\\\", \\\"{x:1309,y:761,t:1528143596135};\\\", \\\"{x:1311,y:764,t:1528143596152};\\\", \\\"{x:1311,y:768,t:1528143596169};\\\", \\\"{x:1312,y:774,t:1528143596186};\\\", \\\"{x:1312,y:778,t:1528143596203};\\\", \\\"{x:1313,y:788,t:1528143596220};\\\", \\\"{x:1313,y:799,t:1528143596236};\\\", \\\"{x:1313,y:815,t:1528143596252};\\\", \\\"{x:1313,y:832,t:1528143596270};\\\", \\\"{x:1313,y:849,t:1528143596286};\\\", \\\"{x:1309,y:865,t:1528143596303};\\\", \\\"{x:1304,y:872,t:1528143596319};\\\", \\\"{x:1304,y:874,t:1528143596336};\\\", \\\"{x:1302,y:876,t:1528143596352};\\\", \\\"{x:1302,y:877,t:1528143596372};\\\", \\\"{x:1302,y:878,t:1528143596388};\\\", \\\"{x:1300,y:880,t:1528143596403};\\\", \\\"{x:1297,y:884,t:1528143596421};\\\", \\\"{x:1292,y:888,t:1528143596436};\\\", \\\"{x:1288,y:893,t:1528143596453};\\\", \\\"{x:1284,y:897,t:1528143596470};\\\", \\\"{x:1281,y:900,t:1528143596487};\\\", \\\"{x:1274,y:905,t:1528143596503};\\\", \\\"{x:1261,y:913,t:1528143596519};\\\", \\\"{x:1251,y:919,t:1528143596537};\\\", \\\"{x:1243,y:923,t:1528143596553};\\\", \\\"{x:1237,y:927,t:1528143596570};\\\", \\\"{x:1230,y:928,t:1528143596587};\\\", \\\"{x:1220,y:931,t:1528143596604};\\\", \\\"{x:1215,y:932,t:1528143596621};\\\", \\\"{x:1214,y:932,t:1528143596637};\\\", \\\"{x:1213,y:932,t:1528143596685};\\\", \\\"{x:1215,y:931,t:1528143596893};\\\", \\\"{x:1216,y:929,t:1528143596905};\\\", \\\"{x:1224,y:919,t:1528143596920};\\\", \\\"{x:1232,y:906,t:1528143596937};\\\", \\\"{x:1244,y:892,t:1528143596953};\\\", \\\"{x:1266,y:863,t:1528143596971};\\\", \\\"{x:1288,y:836,t:1528143596987};\\\", \\\"{x:1311,y:807,t:1528143597005};\\\", \\\"{x:1320,y:795,t:1528143597020};\\\", \\\"{x:1327,y:784,t:1528143597038};\\\", \\\"{x:1337,y:766,t:1528143597054};\\\", \\\"{x:1343,y:752,t:1528143597071};\\\", \\\"{x:1349,y:742,t:1528143597088};\\\", \\\"{x:1359,y:726,t:1528143597104};\\\", \\\"{x:1365,y:712,t:1528143597120};\\\", \\\"{x:1370,y:702,t:1528143597137};\\\", \\\"{x:1372,y:696,t:1528143597155};\\\", \\\"{x:1376,y:687,t:1528143597171};\\\", \\\"{x:1379,y:681,t:1528143597188};\\\", \\\"{x:1380,y:680,t:1528143597212};\\\", \\\"{x:1381,y:678,t:1528143597228};\\\", \\\"{x:1384,y:675,t:1528143597237};\\\", \\\"{x:1386,y:671,t:1528143597254};\\\", \\\"{x:1389,y:667,t:1528143597271};\\\", \\\"{x:1392,y:662,t:1528143597288};\\\", \\\"{x:1395,y:658,t:1528143597305};\\\", \\\"{x:1397,y:656,t:1528143597321};\\\", \\\"{x:1398,y:654,t:1528143597337};\\\", \\\"{x:1400,y:653,t:1528143597355};\\\", \\\"{x:1400,y:650,t:1528143597371};\\\", \\\"{x:1403,y:644,t:1528143597388};\\\", \\\"{x:1403,y:640,t:1528143597404};\\\", \\\"{x:1406,y:634,t:1528143597421};\\\", \\\"{x:1408,y:629,t:1528143597437};\\\", \\\"{x:1410,y:623,t:1528143597454};\\\", \\\"{x:1413,y:617,t:1528143597471};\\\", \\\"{x:1414,y:612,t:1528143597487};\\\", \\\"{x:1418,y:601,t:1528143597504};\\\", \\\"{x:1420,y:597,t:1528143597521};\\\", \\\"{x:1422,y:591,t:1528143597538};\\\", \\\"{x:1424,y:586,t:1528143597554};\\\", \\\"{x:1427,y:571,t:1528143597571};\\\", \\\"{x:1429,y:562,t:1528143597588};\\\", \\\"{x:1433,y:558,t:1528143597605};\\\", \\\"{x:1434,y:557,t:1528143597621};\\\", \\\"{x:1435,y:558,t:1528143597756};\\\", \\\"{x:1435,y:579,t:1528143597772};\\\", \\\"{x:1435,y:599,t:1528143597788};\\\", \\\"{x:1435,y:622,t:1528143597806};\\\", \\\"{x:1435,y:644,t:1528143597822};\\\", \\\"{x:1436,y:660,t:1528143597839};\\\", \\\"{x:1437,y:673,t:1528143597855};\\\", \\\"{x:1440,y:682,t:1528143597872};\\\", \\\"{x:1443,y:693,t:1528143597888};\\\", \\\"{x:1445,y:700,t:1528143597905};\\\", \\\"{x:1447,y:706,t:1528143597921};\\\", \\\"{x:1449,y:712,t:1528143597939};\\\", \\\"{x:1454,y:730,t:1528143597956};\\\", \\\"{x:1458,y:741,t:1528143597972};\\\", \\\"{x:1463,y:756,t:1528143597989};\\\", \\\"{x:1468,y:768,t:1528143598007};\\\", \\\"{x:1473,y:784,t:1528143598023};\\\", \\\"{x:1481,y:798,t:1528143598039};\\\", \\\"{x:1488,y:810,t:1528143598055};\\\", \\\"{x:1495,y:824,t:1528143598073};\\\", \\\"{x:1501,y:835,t:1528143598089};\\\", \\\"{x:1507,y:843,t:1528143598106};\\\", \\\"{x:1515,y:852,t:1528143598123};\\\", \\\"{x:1531,y:871,t:1528143598139};\\\", \\\"{x:1558,y:895,t:1528143598156};\\\", \\\"{x:1573,y:908,t:1528143598172};\\\", \\\"{x:1583,y:919,t:1528143598188};\\\", \\\"{x:1589,y:924,t:1528143598206};\\\", \\\"{x:1591,y:925,t:1528143598223};\\\", \\\"{x:1593,y:927,t:1528143598240};\\\", \\\"{x:1596,y:929,t:1528143598256};\\\", \\\"{x:1597,y:930,t:1528143598292};\\\", \\\"{x:1597,y:931,t:1528143598436};\\\", \\\"{x:1597,y:934,t:1528143598444};\\\", \\\"{x:1597,y:937,t:1528143598455};\\\", \\\"{x:1598,y:940,t:1528143598473};\\\", \\\"{x:1599,y:941,t:1528143598490};\\\", \\\"{x:1599,y:944,t:1528143598507};\\\", \\\"{x:1599,y:947,t:1528143598523};\\\", \\\"{x:1601,y:949,t:1528143598539};\\\", \\\"{x:1601,y:950,t:1528143598564};\\\", \\\"{x:1601,y:951,t:1528143598660};\\\", \\\"{x:1601,y:953,t:1528143598674};\\\", \\\"{x:1602,y:954,t:1528143598690};\\\", \\\"{x:1602,y:955,t:1528143598707};\\\", \\\"{x:1603,y:957,t:1528143598724};\\\", \\\"{x:1603,y:958,t:1528143598740};\\\", \\\"{x:1604,y:960,t:1528143598757};\\\", \\\"{x:1604,y:962,t:1528143598827};\\\", \\\"{x:1598,y:963,t:1528143598843};\\\", \\\"{x:1587,y:963,t:1528143598856};\\\", \\\"{x:1538,y:951,t:1528143598873};\\\", \\\"{x:1432,y:904,t:1528143598890};\\\", \\\"{x:1294,y:838,t:1528143598906};\\\", \\\"{x:1201,y:798,t:1528143598923};\\\", \\\"{x:1195,y:790,t:1528143598940};\\\", \\\"{x:1194,y:788,t:1528143598956};\\\", \\\"{x:1190,y:785,t:1528143598973};\\\", \\\"{x:1048,y:734,t:1528143598990};\\\", \\\"{x:918,y:695,t:1528143599007};\\\", \\\"{x:879,y:681,t:1528143599023};\\\", \\\"{x:869,y:676,t:1528143599040};\\\", \\\"{x:867,y:675,t:1528143599057};\\\", \\\"{x:866,y:673,t:1528143599148};\\\", \\\"{x:863,y:672,t:1528143599157};\\\", \\\"{x:843,y:662,t:1528143599173};\\\", \\\"{x:794,y:638,t:1528143599191};\\\", \\\"{x:704,y:605,t:1528143599208};\\\", \\\"{x:612,y:571,t:1528143599225};\\\", \\\"{x:553,y:542,t:1528143599241};\\\", \\\"{x:498,y:511,t:1528143599256};\\\", \\\"{x:472,y:496,t:1528143599272};\\\", \\\"{x:452,y:485,t:1528143599290};\\\", \\\"{x:439,y:476,t:1528143599306};\\\", \\\"{x:436,y:473,t:1528143599322};\\\", \\\"{x:435,y:472,t:1528143599371};\\\", \\\"{x:434,y:472,t:1528143599387};\\\", \\\"{x:433,y:472,t:1528143599395};\\\", \\\"{x:431,y:472,t:1528143599411};\\\", \\\"{x:428,y:472,t:1528143599427};\\\", \\\"{x:426,y:473,t:1528143599439};\\\", \\\"{x:422,y:476,t:1528143599456};\\\", \\\"{x:419,y:478,t:1528143599472};\\\", \\\"{x:417,y:479,t:1528143599492};\\\", \\\"{x:416,y:480,t:1528143599516};\\\", \\\"{x:415,y:480,t:1528143599523};\\\", \\\"{x:413,y:482,t:1528143599539};\\\", \\\"{x:413,y:483,t:1528143599556};\\\", \\\"{x:413,y:485,t:1528143599573};\\\", \\\"{x:412,y:487,t:1528143599591};\\\", \\\"{x:411,y:489,t:1528143599606};\\\", \\\"{x:411,y:490,t:1528143599622};\\\", \\\"{x:411,y:492,t:1528143599638};\\\", \\\"{x:410,y:493,t:1528143599656};\\\", \\\"{x:410,y:494,t:1528143599675};\\\", \\\"{x:409,y:494,t:1528143599689};\\\", \\\"{x:408,y:497,t:1528143599706};\\\", \\\"{x:407,y:500,t:1528143599722};\\\", \\\"{x:405,y:506,t:1528143599739};\\\", \\\"{x:405,y:510,t:1528143599756};\\\", \\\"{x:403,y:514,t:1528143599773};\\\", \\\"{x:402,y:518,t:1528143599790};\\\", \\\"{x:401,y:520,t:1528143599827};\\\", \\\"{x:400,y:521,t:1528143599900};\\\", \\\"{x:400,y:522,t:1528143599924};\\\", \\\"{x:399,y:522,t:1528143599939};\\\", \\\"{x:398,y:525,t:1528143599958};\\\", \\\"{x:398,y:527,t:1528143599973};\\\", \\\"{x:396,y:530,t:1528143599990};\\\", \\\"{x:395,y:531,t:1528143600006};\\\", \\\"{x:395,y:533,t:1528143600023};\\\", \\\"{x:394,y:536,t:1528143600040};\\\", \\\"{x:393,y:539,t:1528143600056};\\\", \\\"{x:392,y:541,t:1528143600073};\\\", \\\"{x:392,y:543,t:1528143600091};\\\", \\\"{x:392,y:544,t:1528143600106};\\\", \\\"{x:392,y:546,t:1528143600123};\\\", \\\"{x:391,y:547,t:1528143600141};\\\", \\\"{x:391,y:549,t:1528143600244};\\\", \\\"{x:391,y:550,t:1528143600257};\\\", \\\"{x:391,y:553,t:1528143600275};\\\", \\\"{x:389,y:556,t:1528143600292};\\\", \\\"{x:389,y:558,t:1528143600307};\\\", \\\"{x:389,y:559,t:1528143600331};\\\", \\\"{x:389,y:560,t:1528143600395};\\\", \\\"{x:390,y:562,t:1528143600411};\\\", \\\"{x:398,y:566,t:1528143600424};\\\", \\\"{x:444,y:584,t:1528143600441};\\\", \\\"{x:620,y:631,t:1528143600457};\\\", \\\"{x:865,y:691,t:1528143600474};\\\", \\\"{x:1147,y:737,t:1528143600490};\\\", \\\"{x:1486,y:790,t:1528143600507};\\\", \\\"{x:1665,y:810,t:1528143600523};\\\", \\\"{x:1829,y:819,t:1528143600540};\\\", \\\"{x:1919,y:819,t:1528143600557};\\\", \\\"{x:1919,y:818,t:1528143600579};\\\", \\\"{x:1919,y:807,t:1528143600591};\\\", \\\"{x:1919,y:793,t:1528143600607};\\\", \\\"{x:1919,y:787,t:1528143600623};\\\", \\\"{x:1919,y:783,t:1528143600640};\\\", \\\"{x:1919,y:778,t:1528143600657};\\\", \\\"{x:1907,y:762,t:1528143600674};\\\", \\\"{x:1895,y:752,t:1528143600691};\\\", \\\"{x:1879,y:739,t:1528143600707};\\\", \\\"{x:1869,y:732,t:1528143600723};\\\", \\\"{x:1855,y:720,t:1528143600740};\\\", \\\"{x:1836,y:702,t:1528143600758};\\\", \\\"{x:1814,y:686,t:1528143600775};\\\", \\\"{x:1785,y:670,t:1528143600791};\\\", \\\"{x:1758,y:660,t:1528143600808};\\\", \\\"{x:1729,y:654,t:1528143600825};\\\", \\\"{x:1691,y:651,t:1528143600841};\\\", \\\"{x:1652,y:651,t:1528143600858};\\\", \\\"{x:1604,y:651,t:1528143600874};\\\", \\\"{x:1571,y:651,t:1528143600891};\\\", \\\"{x:1533,y:656,t:1528143600908};\\\", \\\"{x:1513,y:659,t:1528143600924};\\\", \\\"{x:1497,y:663,t:1528143600941};\\\", \\\"{x:1490,y:663,t:1528143600957};\\\", \\\"{x:1488,y:664,t:1528143600975};\\\", \\\"{x:1487,y:664,t:1528143600992};\\\", \\\"{x:1486,y:664,t:1528143601028};\\\", \\\"{x:1485,y:664,t:1528143601044};\\\", \\\"{x:1483,y:665,t:1528143601058};\\\", \\\"{x:1479,y:665,t:1528143601075};\\\", \\\"{x:1466,y:665,t:1528143601092};\\\", \\\"{x:1455,y:665,t:1528143601108};\\\", \\\"{x:1444,y:662,t:1528143601124};\\\", \\\"{x:1433,y:654,t:1528143601142};\\\", \\\"{x:1428,y:648,t:1528143601158};\\\", \\\"{x:1426,y:638,t:1528143601175};\\\", \\\"{x:1422,y:629,t:1528143601192};\\\", \\\"{x:1422,y:622,t:1528143601208};\\\", \\\"{x:1422,y:621,t:1528143601225};\\\", \\\"{x:1422,y:620,t:1528143601308};\\\", \\\"{x:1423,y:620,t:1528143601492};\\\", \\\"{x:1423,y:621,t:1528143601509};\\\", \\\"{x:1425,y:621,t:1528143601525};\\\", \\\"{x:1426,y:621,t:1528143601629};\\\", \\\"{x:1426,y:618,t:1528143601642};\\\", \\\"{x:1427,y:611,t:1528143601659};\\\", \\\"{x:1427,y:601,t:1528143601676};\\\", \\\"{x:1427,y:597,t:1528143601692};\\\", \\\"{x:1427,y:593,t:1528143601709};\\\", \\\"{x:1427,y:590,t:1528143601726};\\\", \\\"{x:1426,y:586,t:1528143601742};\\\", \\\"{x:1426,y:583,t:1528143601759};\\\", \\\"{x:1426,y:578,t:1528143601776};\\\", \\\"{x:1425,y:572,t:1528143601792};\\\", \\\"{x:1425,y:565,t:1528143601809};\\\", \\\"{x:1425,y:560,t:1528143601826};\\\", \\\"{x:1425,y:555,t:1528143601842};\\\", \\\"{x:1425,y:554,t:1528143601859};\\\", \\\"{x:1424,y:554,t:1528143602541};\\\", \\\"{x:1422,y:555,t:1528143602580};\\\", \\\"{x:1422,y:556,t:1528143602596};\\\", \\\"{x:1422,y:557,t:1528143602610};\\\", \\\"{x:1421,y:557,t:1528143605053};\\\", \\\"{x:1415,y:557,t:1528143610755};\\\", \\\"{x:1383,y:568,t:1528143610768};\\\", \\\"{x:1257,y:593,t:1528143610786};\\\", \\\"{x:1135,y:609,t:1528143610801};\\\", \\\"{x:1018,y:613,t:1528143610819};\\\", \\\"{x:852,y:613,t:1528143610836};\\\", \\\"{x:749,y:613,t:1528143610853};\\\", \\\"{x:650,y:613,t:1528143610869};\\\", \\\"{x:608,y:613,t:1528143610880};\\\", \\\"{x:541,y:613,t:1528143610897};\\\", \\\"{x:504,y:616,t:1528143610912};\\\", \\\"{x:485,y:618,t:1528143610930};\\\", \\\"{x:474,y:619,t:1528143610946};\\\", \\\"{x:468,y:621,t:1528143610966};\\\", \\\"{x:465,y:621,t:1528143610982};\\\", \\\"{x:463,y:623,t:1528143610998};\\\", \\\"{x:461,y:623,t:1528143611016};\\\", \\\"{x:458,y:625,t:1528143611032};\\\", \\\"{x:457,y:625,t:1528143611049};\\\", \\\"{x:456,y:625,t:1528143611067};\\\", \\\"{x:455,y:625,t:1528143611092};\\\", \\\"{x:454,y:625,t:1528143611140};\\\", \\\"{x:451,y:625,t:1528143611149};\\\", \\\"{x:442,y:625,t:1528143611166};\\\", \\\"{x:418,y:625,t:1528143611181};\\\", \\\"{x:388,y:625,t:1528143611199};\\\", \\\"{x:365,y:625,t:1528143611216};\\\", \\\"{x:348,y:625,t:1528143611232};\\\", \\\"{x:341,y:623,t:1528143611249};\\\", \\\"{x:340,y:623,t:1528143611266};\\\", \\\"{x:339,y:623,t:1528143611282};\\\", \\\"{x:348,y:623,t:1528143611484};\\\", \\\"{x:380,y:626,t:1528143611500};\\\", \\\"{x:591,y:653,t:1528143611517};\\\", \\\"{x:793,y:678,t:1528143611532};\\\", \\\"{x:991,y:697,t:1528143611550};\\\", \\\"{x:1172,y:710,t:1528143611565};\\\", \\\"{x:1343,y:730,t:1528143611583};\\\", \\\"{x:1509,y:734,t:1528143611600};\\\", \\\"{x:1656,y:734,t:1528143611616};\\\", \\\"{x:1770,y:736,t:1528143611633};\\\", \\\"{x:1835,y:736,t:1528143611650};\\\", \\\"{x:1858,y:726,t:1528143611666};\\\", \\\"{x:1866,y:725,t:1528143611682};\\\", \\\"{x:1867,y:724,t:1528143611700};\\\", \\\"{x:1867,y:723,t:1528143611723};\\\", \\\"{x:1867,y:722,t:1528143611747};\\\", \\\"{x:1867,y:720,t:1528143611756};\\\", \\\"{x:1866,y:715,t:1528143611766};\\\", \\\"{x:1856,y:704,t:1528143611783};\\\", \\\"{x:1844,y:693,t:1528143611800};\\\", \\\"{x:1822,y:676,t:1528143611817};\\\", \\\"{x:1788,y:662,t:1528143611833};\\\", \\\"{x:1738,y:646,t:1528143611850};\\\", \\\"{x:1681,y:636,t:1528143611867};\\\", \\\"{x:1607,y:628,t:1528143611883};\\\", \\\"{x:1470,y:612,t:1528143611901};\\\", \\\"{x:1371,y:603,t:1528143611917};\\\", \\\"{x:1280,y:595,t:1528143611933};\\\", \\\"{x:1175,y:596,t:1528143611950};\\\", \\\"{x:1088,y:609,t:1528143611967};\\\", \\\"{x:1058,y:613,t:1528143611983};\\\", \\\"{x:1049,y:614,t:1528143612000};\\\", \\\"{x:1052,y:613,t:1528143612108};\\\", \\\"{x:1054,y:612,t:1528143612118};\\\", \\\"{x:1057,y:610,t:1528143612133};\\\", \\\"{x:1059,y:608,t:1528143612150};\\\", \\\"{x:1059,y:607,t:1528143612167};\\\", \\\"{x:1056,y:607,t:1528143612205};\\\", \\\"{x:1050,y:608,t:1528143612218};\\\", \\\"{x:1024,y:610,t:1528143612234};\\\", \\\"{x:938,y:610,t:1528143612251};\\\", \\\"{x:749,y:609,t:1528143612267};\\\", \\\"{x:628,y:599,t:1528143612284};\\\", \\\"{x:523,y:585,t:1528143612300};\\\", \\\"{x:437,y:562,t:1528143612317};\\\", \\\"{x:374,y:545,t:1528143612334};\\\", \\\"{x:332,y:533,t:1528143612350};\\\", \\\"{x:310,y:525,t:1528143612366};\\\", \\\"{x:303,y:525,t:1528143612383};\\\", \\\"{x:302,y:524,t:1528143612400};\\\", \\\"{x:299,y:527,t:1528143612644};\\\", \\\"{x:297,y:529,t:1528143612651};\\\", \\\"{x:287,y:538,t:1528143612667};\\\", \\\"{x:272,y:547,t:1528143612684};\\\", \\\"{x:253,y:556,t:1528143612701};\\\", \\\"{x:238,y:566,t:1528143612717};\\\", \\\"{x:229,y:570,t:1528143612734};\\\", \\\"{x:225,y:570,t:1528143612751};\\\", \\\"{x:220,y:571,t:1528143612767};\\\", \\\"{x:217,y:571,t:1528143612784};\\\", \\\"{x:213,y:572,t:1528143612801};\\\", \\\"{x:212,y:572,t:1528143612816};\\\", \\\"{x:213,y:572,t:1528143612932};\\\", \\\"{x:218,y:570,t:1528143612940};\\\", \\\"{x:227,y:568,t:1528143612951};\\\", \\\"{x:250,y:565,t:1528143612967};\\\", \\\"{x:279,y:563,t:1528143612986};\\\", \\\"{x:307,y:557,t:1528143613001};\\\", \\\"{x:355,y:555,t:1528143613018};\\\", \\\"{x:414,y:555,t:1528143613033};\\\", \\\"{x:501,y:552,t:1528143613051};\\\", \\\"{x:545,y:549,t:1528143613067};\\\", \\\"{x:566,y:546,t:1528143613083};\\\", \\\"{x:576,y:545,t:1528143613101};\\\", \\\"{x:579,y:544,t:1528143613118};\\\", \\\"{x:581,y:544,t:1528143613134};\\\", \\\"{x:583,y:543,t:1528143613151};\\\", \\\"{x:584,y:542,t:1528143613219};\\\", \\\"{x:586,y:541,t:1528143613234};\\\", \\\"{x:588,y:540,t:1528143613251};\\\", \\\"{x:590,y:540,t:1528143613267};\\\", \\\"{x:595,y:540,t:1528143613284};\\\", \\\"{x:605,y:540,t:1528143613301};\\\", \\\"{x:610,y:540,t:1528143613318};\\\", \\\"{x:621,y:540,t:1528143613335};\\\", \\\"{x:641,y:537,t:1528143613351};\\\", \\\"{x:657,y:535,t:1528143613369};\\\", \\\"{x:676,y:530,t:1528143613384};\\\", \\\"{x:699,y:527,t:1528143613402};\\\", \\\"{x:721,y:525,t:1528143613418};\\\", \\\"{x:743,y:521,t:1528143613436};\\\", \\\"{x:773,y:521,t:1528143613451};\\\", \\\"{x:785,y:521,t:1528143613467};\\\", \\\"{x:801,y:521,t:1528143613485};\\\", \\\"{x:809,y:521,t:1528143613501};\\\", \\\"{x:814,y:521,t:1528143613518};\\\", \\\"{x:815,y:521,t:1528143613635};\\\", \\\"{x:816,y:524,t:1528143613651};\\\", \\\"{x:816,y:526,t:1528143613676};\\\", \\\"{x:816,y:527,t:1528143613691};\\\", \\\"{x:818,y:528,t:1528143613700};\\\", \\\"{x:818,y:529,t:1528143613717};\\\", \\\"{x:819,y:530,t:1528143613746};\\\", \\\"{x:821,y:530,t:1528143613763};\\\", \\\"{x:822,y:531,t:1528143613771};\\\", \\\"{x:825,y:532,t:1528143613785};\\\", \\\"{x:827,y:532,t:1528143613800};\\\", \\\"{x:830,y:534,t:1528143613818};\\\", \\\"{x:831,y:535,t:1528143613834};\\\", \\\"{x:831,y:544,t:1528143614115};\\\", \\\"{x:824,y:559,t:1528143614124};\\\", \\\"{x:813,y:573,t:1528143614135};\\\", \\\"{x:793,y:598,t:1528143614152};\\\", \\\"{x:781,y:612,t:1528143614168};\\\", \\\"{x:769,y:621,t:1528143614184};\\\", \\\"{x:760,y:629,t:1528143614202};\\\", \\\"{x:745,y:636,t:1528143614219};\\\", \\\"{x:732,y:640,t:1528143614235};\\\", \\\"{x:709,y:648,t:1528143614252};\\\", \\\"{x:661,y:663,t:1528143614268};\\\", \\\"{x:596,y:684,t:1528143614285};\\\", \\\"{x:553,y:693,t:1528143614302};\\\", \\\"{x:522,y:702,t:1528143614319};\\\", \\\"{x:501,y:704,t:1528143614334};\\\", \\\"{x:490,y:705,t:1528143614352};\\\", \\\"{x:484,y:705,t:1528143614369};\\\", \\\"{x:483,y:705,t:1528143614385};\\\", \\\"{x:482,y:708,t:1528143614467};\\\", \\\"{x:482,y:713,t:1528143614475};\\\", \\\"{x:482,y:720,t:1528143614485};\\\", \\\"{x:482,y:733,t:1528143614501};\\\", \\\"{x:482,y:745,t:1528143614519};\\\", \\\"{x:482,y:750,t:1528143614535};\\\", \\\"{x:482,y:757,t:1528143614552};\\\", \\\"{x:482,y:759,t:1528143614569};\\\", \\\"{x:483,y:759,t:1528143614585};\\\", \\\"{x:483,y:757,t:1528143614811};\\\", \\\"{x:483,y:755,t:1528143614819};\\\", \\\"{x:483,y:751,t:1528143614836};\\\", \\\"{x:483,y:748,t:1528143614851};\\\", \\\"{x:483,y:746,t:1528143614869};\\\", \\\"{x:483,y:745,t:1528143614886};\\\", \\\"{x:483,y:744,t:1528143615652};\\\" ] }, { \\\"rt\\\": 28568, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 732939, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-J -I -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:743,t:1528143616946};\\\", \\\"{x:483,y:733,t:1528143617836};\\\", \\\"{x:483,y:713,t:1528143617852};\\\", \\\"{x:485,y:671,t:1528143617867};\\\", \\\"{x:486,y:665,t:1528143617885};\\\", \\\"{x:486,y:664,t:1528143617905};\\\", \\\"{x:486,y:663,t:1528143617921};\\\", \\\"{x:486,y:662,t:1528143617963};\\\", \\\"{x:487,y:662,t:1528143617979};\\\", \\\"{x:487,y:661,t:1528143617987};\\\", \\\"{x:488,y:658,t:1528143618005};\\\", \\\"{x:492,y:654,t:1528143618021};\\\", \\\"{x:496,y:650,t:1528143618038};\\\", \\\"{x:505,y:641,t:1528143618056};\\\", \\\"{x:517,y:631,t:1528143618073};\\\", \\\"{x:530,y:621,t:1528143618088};\\\", \\\"{x:543,y:612,t:1528143618105};\\\", \\\"{x:554,y:605,t:1528143618122};\\\", \\\"{x:560,y:603,t:1528143618138};\\\", \\\"{x:570,y:597,t:1528143618155};\\\", \\\"{x:578,y:595,t:1528143618171};\\\", \\\"{x:587,y:593,t:1528143618189};\\\", \\\"{x:592,y:591,t:1528143618205};\\\", \\\"{x:602,y:587,t:1528143618223};\\\", \\\"{x:613,y:584,t:1528143618238};\\\", \\\"{x:621,y:582,t:1528143618255};\\\", \\\"{x:631,y:577,t:1528143618272};\\\", \\\"{x:641,y:572,t:1528143618288};\\\", \\\"{x:650,y:568,t:1528143618306};\\\", \\\"{x:657,y:565,t:1528143618322};\\\", \\\"{x:665,y:561,t:1528143618338};\\\", \\\"{x:671,y:558,t:1528143618355};\\\", \\\"{x:674,y:557,t:1528143618372};\\\", \\\"{x:675,y:556,t:1528143618388};\\\", \\\"{x:676,y:555,t:1528143618412};\\\", \\\"{x:677,y:555,t:1528143618427};\\\", \\\"{x:678,y:554,t:1528143618438};\\\", \\\"{x:680,y:553,t:1528143618455};\\\", \\\"{x:687,y:552,t:1528143618472};\\\", \\\"{x:698,y:549,t:1528143618488};\\\", \\\"{x:709,y:544,t:1528143618505};\\\", \\\"{x:727,y:538,t:1528143618525};\\\", \\\"{x:751,y:533,t:1528143618538};\\\", \\\"{x:766,y:533,t:1528143618555};\\\", \\\"{x:779,y:533,t:1528143618571};\\\", \\\"{x:797,y:533,t:1528143618589};\\\", \\\"{x:815,y:531,t:1528143618605};\\\", \\\"{x:832,y:531,t:1528143618622};\\\", \\\"{x:863,y:528,t:1528143618639};\\\", \\\"{x:893,y:526,t:1528143618656};\\\", \\\"{x:921,y:526,t:1528143618672};\\\", \\\"{x:948,y:526,t:1528143618689};\\\", \\\"{x:974,y:526,t:1528143618706};\\\", \\\"{x:997,y:526,t:1528143618722};\\\", \\\"{x:1033,y:526,t:1528143618738};\\\", \\\"{x:1051,y:526,t:1528143618755};\\\", \\\"{x:1070,y:526,t:1528143618772};\\\", \\\"{x:1082,y:524,t:1528143618789};\\\", \\\"{x:1098,y:522,t:1528143618805};\\\", \\\"{x:1114,y:520,t:1528143618822};\\\", \\\"{x:1123,y:518,t:1528143618839};\\\", \\\"{x:1131,y:517,t:1528143618855};\\\", \\\"{x:1134,y:517,t:1528143618872};\\\", \\\"{x:1135,y:516,t:1528143618889};\\\", \\\"{x:1137,y:516,t:1528143618905};\\\", \\\"{x:1138,y:515,t:1528143618924};\\\", \\\"{x:1140,y:515,t:1528143618939};\\\", \\\"{x:1144,y:513,t:1528143618955};\\\", \\\"{x:1151,y:509,t:1528143618972};\\\", \\\"{x:1155,y:507,t:1528143618989};\\\", \\\"{x:1163,y:503,t:1528143619005};\\\", \\\"{x:1169,y:500,t:1528143619022};\\\", \\\"{x:1177,y:498,t:1528143619040};\\\", \\\"{x:1187,y:496,t:1528143619055};\\\", \\\"{x:1193,y:496,t:1528143619072};\\\", \\\"{x:1199,y:496,t:1528143619089};\\\", \\\"{x:1217,y:496,t:1528143619105};\\\", \\\"{x:1227,y:500,t:1528143619123};\\\", \\\"{x:1240,y:500,t:1528143619140};\\\", \\\"{x:1247,y:500,t:1528143619155};\\\", \\\"{x:1251,y:500,t:1528143619172};\\\", \\\"{x:1254,y:499,t:1528143619189};\\\", \\\"{x:1255,y:499,t:1528143619205};\\\", \\\"{x:1255,y:498,t:1528143619222};\\\", \\\"{x:1254,y:497,t:1528143619404};\\\", \\\"{x:1252,y:495,t:1528143619412};\\\", \\\"{x:1247,y:492,t:1528143619423};\\\", \\\"{x:1234,y:484,t:1528143619439};\\\", \\\"{x:1215,y:473,t:1528143619457};\\\", \\\"{x:1190,y:462,t:1528143619473};\\\", \\\"{x:1154,y:450,t:1528143619490};\\\", \\\"{x:1109,y:450,t:1528143619506};\\\", \\\"{x:1036,y:450,t:1528143619522};\\\", \\\"{x:903,y:450,t:1528143619540};\\\", \\\"{x:817,y:450,t:1528143619556};\\\", \\\"{x:742,y:450,t:1528143619572};\\\", \\\"{x:697,y:450,t:1528143619589};\\\", \\\"{x:663,y:450,t:1528143619607};\\\", \\\"{x:641,y:450,t:1528143619623};\\\", \\\"{x:627,y:449,t:1528143619639};\\\", \\\"{x:612,y:446,t:1528143619657};\\\", \\\"{x:602,y:443,t:1528143619673};\\\", \\\"{x:601,y:443,t:1528143619689};\\\", \\\"{x:599,y:442,t:1528143619707};\\\", \\\"{x:598,y:442,t:1528143619780};\\\", \\\"{x:597,y:442,t:1528143619795};\\\", \\\"{x:595,y:442,t:1528143619806};\\\", \\\"{x:593,y:441,t:1528143619822};\\\", \\\"{x:589,y:441,t:1528143619840};\\\", \\\"{x:585,y:438,t:1528143619856};\\\", \\\"{x:580,y:437,t:1528143619872};\\\", \\\"{x:566,y:434,t:1528143619889};\\\", \\\"{x:552,y:433,t:1528143619906};\\\", \\\"{x:540,y:429,t:1528143619922};\\\", \\\"{x:508,y:429,t:1528143619939};\\\", \\\"{x:485,y:429,t:1528143619955};\\\", \\\"{x:466,y:429,t:1528143619972};\\\", \\\"{x:448,y:429,t:1528143619989};\\\", \\\"{x:437,y:429,t:1528143620006};\\\", \\\"{x:433,y:429,t:1528143620022};\\\", \\\"{x:431,y:429,t:1528143620348};\\\", \\\"{x:429,y:435,t:1528143620356};\\\", \\\"{x:426,y:445,t:1528143620373};\\\", \\\"{x:423,y:453,t:1528143620390};\\\", \\\"{x:419,y:464,t:1528143620407};\\\", \\\"{x:417,y:469,t:1528143620423};\\\", \\\"{x:414,y:474,t:1528143620440};\\\", \\\"{x:414,y:477,t:1528143620457};\\\", \\\"{x:413,y:478,t:1528143620473};\\\", \\\"{x:414,y:478,t:1528143620644};\\\", \\\"{x:415,y:478,t:1528143620657};\\\", \\\"{x:420,y:478,t:1528143620674};\\\", \\\"{x:426,y:478,t:1528143620689};\\\", \\\"{x:432,y:478,t:1528143620707};\\\", \\\"{x:439,y:478,t:1528143620724};\\\", \\\"{x:443,y:478,t:1528143620740};\\\", \\\"{x:451,y:480,t:1528143620757};\\\", \\\"{x:458,y:480,t:1528143620773};\\\", \\\"{x:472,y:481,t:1528143620790};\\\", \\\"{x:490,y:481,t:1528143620806};\\\", \\\"{x:506,y:481,t:1528143620823};\\\", \\\"{x:522,y:481,t:1528143620840};\\\", \\\"{x:539,y:481,t:1528143620856};\\\", \\\"{x:551,y:481,t:1528143620874};\\\", \\\"{x:568,y:482,t:1528143620890};\\\", \\\"{x:591,y:485,t:1528143620907};\\\", \\\"{x:627,y:491,t:1528143620926};\\\", \\\"{x:651,y:494,t:1528143620940};\\\", \\\"{x:673,y:498,t:1528143620956};\\\", \\\"{x:688,y:499,t:1528143620974};\\\", \\\"{x:698,y:502,t:1528143620989};\\\", \\\"{x:708,y:502,t:1528143621007};\\\", \\\"{x:717,y:502,t:1528143621024};\\\", \\\"{x:729,y:502,t:1528143621041};\\\", \\\"{x:744,y:502,t:1528143621057};\\\", \\\"{x:761,y:501,t:1528143621074};\\\", \\\"{x:779,y:499,t:1528143621091};\\\", \\\"{x:790,y:499,t:1528143621107};\\\", \\\"{x:811,y:499,t:1528143621124};\\\", \\\"{x:831,y:499,t:1528143621142};\\\", \\\"{x:856,y:502,t:1528143621158};\\\", \\\"{x:882,y:504,t:1528143621174};\\\", \\\"{x:907,y:507,t:1528143621191};\\\", \\\"{x:936,y:507,t:1528143621207};\\\", \\\"{x:963,y:507,t:1528143621225};\\\", \\\"{x:991,y:507,t:1528143621241};\\\", \\\"{x:1011,y:507,t:1528143621257};\\\", \\\"{x:1033,y:504,t:1528143621274};\\\", \\\"{x:1063,y:495,t:1528143621291};\\\", \\\"{x:1081,y:490,t:1528143621308};\\\", \\\"{x:1098,y:483,t:1528143621324};\\\", \\\"{x:1114,y:479,t:1528143621341};\\\", \\\"{x:1128,y:478,t:1528143621358};\\\", \\\"{x:1138,y:478,t:1528143621374};\\\", \\\"{x:1147,y:478,t:1528143621391};\\\", \\\"{x:1161,y:481,t:1528143621408};\\\", \\\"{x:1178,y:486,t:1528143621424};\\\", \\\"{x:1186,y:487,t:1528143621442};\\\", \\\"{x:1195,y:488,t:1528143621458};\\\", \\\"{x:1200,y:490,t:1528143621474};\\\", \\\"{x:1210,y:487,t:1528143621491};\\\", \\\"{x:1215,y:485,t:1528143621509};\\\", \\\"{x:1218,y:484,t:1528143621525};\\\", \\\"{x:1220,y:483,t:1528143621542};\\\", \\\"{x:1222,y:483,t:1528143621559};\\\", \\\"{x:1224,y:483,t:1528143621579};\\\", \\\"{x:1225,y:483,t:1528143621591};\\\", \\\"{x:1228,y:483,t:1528143621608};\\\", \\\"{x:1232,y:483,t:1528143621625};\\\", \\\"{x:1237,y:485,t:1528143621641};\\\", \\\"{x:1243,y:489,t:1528143621659};\\\", \\\"{x:1246,y:491,t:1528143621676};\\\", \\\"{x:1247,y:491,t:1528143621691};\\\", \\\"{x:1248,y:491,t:1528143621749};\\\", \\\"{x:1249,y:492,t:1528143621780};\\\", \\\"{x:1251,y:495,t:1528143621792};\\\", \\\"{x:1255,y:504,t:1528143621809};\\\", \\\"{x:1259,y:513,t:1528143621826};\\\", \\\"{x:1262,y:525,t:1528143621842};\\\", \\\"{x:1266,y:533,t:1528143621859};\\\", \\\"{x:1268,y:537,t:1528143621875};\\\", \\\"{x:1269,y:538,t:1528143622092};\\\", \\\"{x:1269,y:542,t:1528143622109};\\\", \\\"{x:1269,y:544,t:1528143622126};\\\", \\\"{x:1269,y:545,t:1528143622143};\\\", \\\"{x:1269,y:546,t:1528143622159};\\\", \\\"{x:1269,y:547,t:1528143622176};\\\", \\\"{x:1269,y:549,t:1528143622193};\\\", \\\"{x:1269,y:552,t:1528143622209};\\\", \\\"{x:1269,y:556,t:1528143622226};\\\", \\\"{x:1270,y:561,t:1528143622243};\\\", \\\"{x:1270,y:567,t:1528143622259};\\\", \\\"{x:1271,y:575,t:1528143622276};\\\", \\\"{x:1271,y:578,t:1528143622293};\\\", \\\"{x:1272,y:579,t:1528143622310};\\\", \\\"{x:1272,y:580,t:1528143622326};\\\", \\\"{x:1272,y:583,t:1528143622725};\\\", \\\"{x:1272,y:588,t:1528143622732};\\\", \\\"{x:1272,y:593,t:1528143622743};\\\", \\\"{x:1272,y:601,t:1528143622760};\\\", \\\"{x:1272,y:607,t:1528143622777};\\\", \\\"{x:1272,y:610,t:1528143622793};\\\", \\\"{x:1272,y:614,t:1528143622810};\\\", \\\"{x:1272,y:619,t:1528143622827};\\\", \\\"{x:1272,y:623,t:1528143622843};\\\", \\\"{x:1273,y:632,t:1528143622860};\\\", \\\"{x:1273,y:638,t:1528143622877};\\\", \\\"{x:1273,y:646,t:1528143622893};\\\", \\\"{x:1273,y:657,t:1528143622910};\\\", \\\"{x:1273,y:687,t:1528143622927};\\\", \\\"{x:1262,y:731,t:1528143622943};\\\", \\\"{x:1252,y:772,t:1528143622960};\\\", \\\"{x:1245,y:799,t:1528143622977};\\\", \\\"{x:1242,y:819,t:1528143622995};\\\", \\\"{x:1241,y:826,t:1528143623009};\\\", \\\"{x:1241,y:829,t:1528143623027};\\\", \\\"{x:1241,y:831,t:1528143623044};\\\", \\\"{x:1241,y:832,t:1528143623060};\\\", \\\"{x:1241,y:833,t:1528143623076};\\\", \\\"{x:1241,y:835,t:1528143623093};\\\", \\\"{x:1241,y:838,t:1528143623109};\\\", \\\"{x:1241,y:842,t:1528143623126};\\\", \\\"{x:1243,y:841,t:1528143623316};\\\", \\\"{x:1244,y:839,t:1528143623327};\\\", \\\"{x:1246,y:835,t:1528143623344};\\\", \\\"{x:1247,y:834,t:1528143623361};\\\", \\\"{x:1247,y:833,t:1528143623377};\\\", \\\"{x:1250,y:830,t:1528143623395};\\\", \\\"{x:1251,y:829,t:1528143623410};\\\", \\\"{x:1251,y:828,t:1528143623836};\\\", \\\"{x:1250,y:828,t:1528143623852};\\\", \\\"{x:1250,y:827,t:1528143623861};\\\", \\\"{x:1249,y:827,t:1528143623878};\\\", \\\"{x:1246,y:826,t:1528143623894};\\\", \\\"{x:1245,y:826,t:1528143623932};\\\", \\\"{x:1244,y:826,t:1528143624140};\\\", \\\"{x:1243,y:826,t:1528143624148};\\\", \\\"{x:1242,y:826,t:1528143624161};\\\", \\\"{x:1239,y:827,t:1528143624178};\\\", \\\"{x:1238,y:827,t:1528143624196};\\\", \\\"{x:1236,y:827,t:1528143624212};\\\", \\\"{x:1234,y:827,t:1528143624228};\\\", \\\"{x:1232,y:827,t:1528143624245};\\\", \\\"{x:1229,y:828,t:1528143624262};\\\", \\\"{x:1225,y:830,t:1528143624278};\\\", \\\"{x:1218,y:833,t:1528143624297};\\\", \\\"{x:1213,y:834,t:1528143624312};\\\", \\\"{x:1209,y:834,t:1528143624328};\\\", \\\"{x:1206,y:834,t:1528143624345};\\\", \\\"{x:1204,y:834,t:1528143632412};\\\", \\\"{x:1189,y:829,t:1528143632421};\\\", \\\"{x:1166,y:823,t:1528143632437};\\\", \\\"{x:1164,y:823,t:1528143632456};\\\", \\\"{x:1158,y:823,t:1528143632473};\\\", \\\"{x:1153,y:823,t:1528143632491};\\\", \\\"{x:1150,y:822,t:1528143632508};\\\", \\\"{x:1149,y:821,t:1528143632599};\\\", \\\"{x:1149,y:820,t:1528143632671};\\\", \\\"{x:1150,y:820,t:1528143632687};\\\", \\\"{x:1151,y:819,t:1528143632695};\\\", \\\"{x:1152,y:818,t:1528143632707};\\\", \\\"{x:1153,y:817,t:1528143632723};\\\", \\\"{x:1155,y:815,t:1528143632741};\\\", \\\"{x:1159,y:811,t:1528143632758};\\\", \\\"{x:1164,y:805,t:1528143632774};\\\", \\\"{x:1169,y:795,t:1528143632790};\\\", \\\"{x:1172,y:791,t:1528143632807};\\\", \\\"{x:1176,y:784,t:1528143632823};\\\", \\\"{x:1178,y:778,t:1528143632840};\\\", \\\"{x:1180,y:773,t:1528143632856};\\\", \\\"{x:1181,y:770,t:1528143632874};\\\", \\\"{x:1182,y:767,t:1528143632889};\\\", \\\"{x:1184,y:764,t:1528143632907};\\\", \\\"{x:1185,y:760,t:1528143632923};\\\", \\\"{x:1188,y:754,t:1528143632940};\\\", \\\"{x:1190,y:748,t:1528143632957};\\\", \\\"{x:1191,y:743,t:1528143632973};\\\", \\\"{x:1192,y:741,t:1528143632990};\\\", \\\"{x:1193,y:737,t:1528143633006};\\\", \\\"{x:1195,y:734,t:1528143633024};\\\", \\\"{x:1196,y:730,t:1528143633040};\\\", \\\"{x:1200,y:724,t:1528143633057};\\\", \\\"{x:1203,y:720,t:1528143633074};\\\", \\\"{x:1204,y:717,t:1528143633090};\\\", \\\"{x:1205,y:715,t:1528143633107};\\\", \\\"{x:1205,y:714,t:1528143633124};\\\", \\\"{x:1205,y:713,t:1528143633141};\\\", \\\"{x:1205,y:712,t:1528143633157};\\\", \\\"{x:1206,y:712,t:1528143633182};\\\", \\\"{x:1206,y:711,t:1528143633207};\\\", \\\"{x:1207,y:711,t:1528143633224};\\\", \\\"{x:1208,y:710,t:1528143633254};\\\", \\\"{x:1209,y:709,t:1528143633335};\\\", \\\"{x:1210,y:709,t:1528143633615};\\\", \\\"{x:1211,y:709,t:1528143633679};\\\", \\\"{x:1212,y:709,t:1528143633691};\\\", \\\"{x:1213,y:709,t:1528143633708};\\\", \\\"{x:1215,y:709,t:1528143633724};\\\", \\\"{x:1218,y:709,t:1528143633741};\\\", \\\"{x:1224,y:711,t:1528143633759};\\\", \\\"{x:1227,y:712,t:1528143633774};\\\", \\\"{x:1228,y:713,t:1528143633791};\\\", \\\"{x:1229,y:713,t:1528143633809};\\\", \\\"{x:1230,y:714,t:1528143634086};\\\", \\\"{x:1232,y:714,t:1528143634094};\\\", \\\"{x:1232,y:715,t:1528143634108};\\\", \\\"{x:1234,y:720,t:1528143634125};\\\", \\\"{x:1239,y:729,t:1528143634143};\\\", \\\"{x:1240,y:732,t:1528143634159};\\\", \\\"{x:1241,y:735,t:1528143634176};\\\", \\\"{x:1243,y:739,t:1528143634192};\\\", \\\"{x:1245,y:742,t:1528143634208};\\\", \\\"{x:1245,y:744,t:1528143634225};\\\", \\\"{x:1245,y:748,t:1528143634243};\\\", \\\"{x:1247,y:750,t:1528143634258};\\\", \\\"{x:1247,y:752,t:1528143634275};\\\", \\\"{x:1248,y:753,t:1528143634292};\\\", \\\"{x:1248,y:755,t:1528143634308};\\\", \\\"{x:1248,y:757,t:1528143634325};\\\", \\\"{x:1251,y:760,t:1528143634342};\\\", \\\"{x:1252,y:764,t:1528143634359};\\\", \\\"{x:1253,y:766,t:1528143634376};\\\", \\\"{x:1255,y:769,t:1528143634392};\\\", \\\"{x:1255,y:772,t:1528143634409};\\\", \\\"{x:1258,y:776,t:1528143634426};\\\", \\\"{x:1260,y:780,t:1528143634443};\\\", \\\"{x:1263,y:786,t:1528143634459};\\\", \\\"{x:1266,y:793,t:1528143634475};\\\", \\\"{x:1270,y:802,t:1528143634492};\\\", \\\"{x:1275,y:809,t:1528143634509};\\\", \\\"{x:1279,y:816,t:1528143634525};\\\", \\\"{x:1284,y:822,t:1528143634542};\\\", \\\"{x:1284,y:825,t:1528143634558};\\\", \\\"{x:1287,y:829,t:1528143634575};\\\", \\\"{x:1287,y:832,t:1528143634592};\\\", \\\"{x:1290,y:836,t:1528143634610};\\\", \\\"{x:1291,y:840,t:1528143634626};\\\", \\\"{x:1296,y:847,t:1528143634642};\\\", \\\"{x:1299,y:854,t:1528143634660};\\\", \\\"{x:1301,y:859,t:1528143634676};\\\", \\\"{x:1303,y:865,t:1528143634691};\\\", \\\"{x:1307,y:871,t:1528143634709};\\\", \\\"{x:1308,y:875,t:1528143634725};\\\", \\\"{x:1309,y:876,t:1528143634757};\\\", \\\"{x:1310,y:876,t:1528143634774};\\\", \\\"{x:1313,y:876,t:1528143634790};\\\", \\\"{x:1315,y:875,t:1528143634797};\\\", \\\"{x:1318,y:872,t:1528143634809};\\\", \\\"{x:1322,y:865,t:1528143634825};\\\", \\\"{x:1324,y:859,t:1528143634842};\\\", \\\"{x:1326,y:852,t:1528143634859};\\\", \\\"{x:1327,y:850,t:1528143634876};\\\", \\\"{x:1329,y:848,t:1528143634892};\\\", \\\"{x:1330,y:847,t:1528143634909};\\\", \\\"{x:1334,y:843,t:1528143634925};\\\", \\\"{x:1336,y:841,t:1528143634942};\\\", \\\"{x:1338,y:839,t:1528143634959};\\\", \\\"{x:1339,y:835,t:1528143634976};\\\", \\\"{x:1340,y:833,t:1528143634992};\\\", \\\"{x:1340,y:831,t:1528143635009};\\\", \\\"{x:1340,y:827,t:1528143635026};\\\", \\\"{x:1341,y:821,t:1528143635043};\\\", \\\"{x:1343,y:811,t:1528143635059};\\\", \\\"{x:1345,y:800,t:1528143635076};\\\", \\\"{x:1346,y:794,t:1528143635093};\\\", \\\"{x:1347,y:788,t:1528143635109};\\\", \\\"{x:1349,y:779,t:1528143635126};\\\", \\\"{x:1350,y:772,t:1528143635142};\\\", \\\"{x:1350,y:768,t:1528143635159};\\\", \\\"{x:1351,y:764,t:1528143635176};\\\", \\\"{x:1352,y:763,t:1528143635193};\\\", \\\"{x:1355,y:758,t:1528143635209};\\\", \\\"{x:1357,y:753,t:1528143635226};\\\", \\\"{x:1359,y:751,t:1528143635243};\\\", \\\"{x:1359,y:750,t:1528143635262};\\\", \\\"{x:1359,y:749,t:1528143635415};\\\", \\\"{x:1359,y:748,t:1528143635479};\\\", \\\"{x:1358,y:748,t:1528143635502};\\\", \\\"{x:1358,y:749,t:1528143635510};\\\", \\\"{x:1356,y:751,t:1528143635525};\\\", \\\"{x:1356,y:754,t:1528143635543};\\\", \\\"{x:1355,y:761,t:1528143635559};\\\", \\\"{x:1353,y:764,t:1528143635576};\\\", \\\"{x:1352,y:768,t:1528143635593};\\\", \\\"{x:1351,y:771,t:1528143635610};\\\", \\\"{x:1348,y:776,t:1528143635625};\\\", \\\"{x:1347,y:782,t:1528143635643};\\\", \\\"{x:1344,y:790,t:1528143635660};\\\", \\\"{x:1342,y:798,t:1528143635677};\\\", \\\"{x:1338,y:807,t:1528143635693};\\\", \\\"{x:1335,y:822,t:1528143635710};\\\", \\\"{x:1332,y:832,t:1528143635727};\\\", \\\"{x:1329,y:843,t:1528143635743};\\\", \\\"{x:1326,y:854,t:1528143635760};\\\", \\\"{x:1321,y:869,t:1528143635777};\\\", \\\"{x:1318,y:882,t:1528143635793};\\\", \\\"{x:1315,y:894,t:1528143635810};\\\", \\\"{x:1310,y:908,t:1528143635827};\\\", \\\"{x:1310,y:912,t:1528143635843};\\\", \\\"{x:1309,y:916,t:1528143635860};\\\", \\\"{x:1309,y:917,t:1528143635877};\\\", \\\"{x:1308,y:918,t:1528143635893};\\\", \\\"{x:1307,y:920,t:1528143635926};\\\", \\\"{x:1305,y:922,t:1528143635943};\\\", \\\"{x:1300,y:924,t:1528143635960};\\\", \\\"{x:1289,y:927,t:1528143635977};\\\", \\\"{x:1275,y:930,t:1528143635993};\\\", \\\"{x:1261,y:930,t:1528143636010};\\\", \\\"{x:1245,y:930,t:1528143636027};\\\", \\\"{x:1231,y:930,t:1528143636044};\\\", \\\"{x:1218,y:930,t:1528143636061};\\\", \\\"{x:1205,y:926,t:1528143636078};\\\", \\\"{x:1195,y:921,t:1528143636094};\\\", \\\"{x:1192,y:918,t:1528143636110};\\\", \\\"{x:1190,y:917,t:1528143636127};\\\", \\\"{x:1189,y:914,t:1528143636144};\\\", \\\"{x:1188,y:912,t:1528143636160};\\\", \\\"{x:1186,y:909,t:1528143636177};\\\", \\\"{x:1186,y:908,t:1528143636194};\\\", \\\"{x:1186,y:907,t:1528143636210};\\\", \\\"{x:1186,y:905,t:1528143636227};\\\", \\\"{x:1186,y:901,t:1528143636244};\\\", \\\"{x:1186,y:893,t:1528143636260};\\\", \\\"{x:1186,y:877,t:1528143636277};\\\", \\\"{x:1191,y:853,t:1528143636294};\\\", \\\"{x:1194,y:839,t:1528143636311};\\\", \\\"{x:1196,y:829,t:1528143636327};\\\", \\\"{x:1197,y:814,t:1528143636344};\\\", \\\"{x:1198,y:804,t:1528143636361};\\\", \\\"{x:1198,y:800,t:1528143636377};\\\", \\\"{x:1196,y:796,t:1528143636394};\\\", \\\"{x:1192,y:791,t:1528143636411};\\\", \\\"{x:1182,y:782,t:1528143636427};\\\", \\\"{x:1155,y:771,t:1528143636444};\\\", \\\"{x:1092,y:747,t:1528143636461};\\\", \\\"{x:1001,y:724,t:1528143636477};\\\", \\\"{x:869,y:693,t:1528143636494};\\\", \\\"{x:785,y:678,t:1528143636511};\\\", \\\"{x:708,y:658,t:1528143636527};\\\", \\\"{x:624,y:633,t:1528143636544};\\\", \\\"{x:571,y:617,t:1528143636562};\\\", \\\"{x:545,y:608,t:1528143636577};\\\", \\\"{x:527,y:600,t:1528143636594};\\\", \\\"{x:524,y:599,t:1528143636605};\\\", \\\"{x:523,y:599,t:1528143636622};\\\", \\\"{x:521,y:597,t:1528143636639};\\\", \\\"{x:511,y:590,t:1528143636656};\\\", \\\"{x:497,y:582,t:1528143636673};\\\", \\\"{x:484,y:575,t:1528143636689};\\\", \\\"{x:467,y:570,t:1528143636706};\\\", \\\"{x:457,y:569,t:1528143636724};\\\", \\\"{x:445,y:569,t:1528143636741};\\\", \\\"{x:437,y:569,t:1528143636757};\\\", \\\"{x:430,y:569,t:1528143636774};\\\", \\\"{x:423,y:570,t:1528143636791};\\\", \\\"{x:416,y:571,t:1528143636807};\\\", \\\"{x:408,y:572,t:1528143636824};\\\", \\\"{x:403,y:573,t:1528143636841};\\\", \\\"{x:398,y:574,t:1528143636858};\\\", \\\"{x:393,y:575,t:1528143636876};\\\", \\\"{x:386,y:576,t:1528143636891};\\\", \\\"{x:376,y:576,t:1528143636908};\\\", \\\"{x:371,y:577,t:1528143636926};\\\", \\\"{x:366,y:577,t:1528143636941};\\\", \\\"{x:344,y:577,t:1528143636958};\\\", \\\"{x:317,y:577,t:1528143636975};\\\", \\\"{x:286,y:577,t:1528143636992};\\\", \\\"{x:252,y:577,t:1528143637011};\\\", \\\"{x:230,y:577,t:1528143637025};\\\", \\\"{x:220,y:577,t:1528143637040};\\\", \\\"{x:214,y:577,t:1528143637057};\\\", \\\"{x:212,y:577,t:1528143637072};\\\", \\\"{x:210,y:577,t:1528143637089};\\\", \\\"{x:209,y:577,t:1528143637107};\\\", \\\"{x:208,y:577,t:1528143637122};\\\", \\\"{x:207,y:576,t:1528143637139};\\\", \\\"{x:206,y:575,t:1528143637157};\\\", \\\"{x:202,y:568,t:1528143637173};\\\", \\\"{x:192,y:551,t:1528143637191};\\\", \\\"{x:191,y:544,t:1528143637207};\\\", \\\"{x:185,y:535,t:1528143637224};\\\", \\\"{x:182,y:527,t:1528143637242};\\\", \\\"{x:179,y:523,t:1528143637257};\\\", \\\"{x:178,y:518,t:1528143637274};\\\", \\\"{x:175,y:513,t:1528143637292};\\\", \\\"{x:172,y:508,t:1528143637307};\\\", \\\"{x:171,y:505,t:1528143637324};\\\", \\\"{x:168,y:501,t:1528143637341};\\\", \\\"{x:167,y:500,t:1528143637357};\\\", \\\"{x:167,y:499,t:1528143637374};\\\", \\\"{x:166,y:498,t:1528143637391};\\\", \\\"{x:165,y:498,t:1528143637408};\\\", \\\"{x:164,y:497,t:1528143637424};\\\", \\\"{x:162,y:496,t:1528143637441};\\\", \\\"{x:162,y:495,t:1528143637458};\\\", \\\"{x:161,y:495,t:1528143637479};\\\", \\\"{x:190,y:508,t:1528143642128};\\\", \\\"{x:215,y:525,t:1528143642141};\\\", \\\"{x:228,y:525,t:1528143643103};\\\", \\\"{x:237,y:522,t:1528143643114};\\\", \\\"{x:254,y:517,t:1528143643130};\\\", \\\"{x:271,y:512,t:1528143643145};\\\", \\\"{x:291,y:504,t:1528143643163};\\\", \\\"{x:307,y:498,t:1528143643179};\\\", \\\"{x:311,y:494,t:1528143643195};\\\", \\\"{x:312,y:494,t:1528143643285};\\\", \\\"{x:316,y:493,t:1528143643302};\\\", \\\"{x:357,y:480,t:1528143643313};\\\", \\\"{x:469,y:460,t:1528143643330};\\\", \\\"{x:588,y:458,t:1528143643345};\\\", \\\"{x:680,y:458,t:1528143643363};\\\", \\\"{x:749,y:458,t:1528143643380};\\\", \\\"{x:799,y:463,t:1528143643395};\\\", \\\"{x:841,y:475,t:1528143643412};\\\", \\\"{x:880,y:484,t:1528143643430};\\\", \\\"{x:922,y:498,t:1528143643446};\\\", \\\"{x:980,y:519,t:1528143643463};\\\", \\\"{x:1022,y:532,t:1528143643480};\\\", \\\"{x:1050,y:544,t:1528143643496};\\\", \\\"{x:1077,y:556,t:1528143643512};\\\", \\\"{x:1107,y:568,t:1528143643529};\\\", \\\"{x:1138,y:578,t:1528143643546};\\\", \\\"{x:1171,y:584,t:1528143643562};\\\", \\\"{x:1210,y:596,t:1528143643579};\\\", \\\"{x:1264,y:607,t:1528143643596};\\\", \\\"{x:1334,y:629,t:1528143643612};\\\", \\\"{x:1397,y:646,t:1528143643629};\\\", \\\"{x:1468,y:661,t:1528143643646};\\\", \\\"{x:1488,y:664,t:1528143643662};\\\", \\\"{x:1496,y:666,t:1528143643679};\\\", \\\"{x:1491,y:670,t:1528143643727};\\\", \\\"{x:1480,y:673,t:1528143643735};\\\", \\\"{x:1458,y:684,t:1528143643746};\\\", \\\"{x:1403,y:710,t:1528143643764};\\\", \\\"{x:1330,y:731,t:1528143643780};\\\", \\\"{x:1223,y:760,t:1528143643798};\\\", \\\"{x:1109,y:776,t:1528143643814};\\\", \\\"{x:994,y:782,t:1528143643830};\\\", \\\"{x:830,y:786,t:1528143643846};\\\", \\\"{x:719,y:786,t:1528143643864};\\\", \\\"{x:614,y:786,t:1528143643879};\\\", \\\"{x:532,y:782,t:1528143643897};\\\", \\\"{x:458,y:774,t:1528143643914};\\\", \\\"{x:394,y:764,t:1528143643930};\\\", \\\"{x:355,y:761,t:1528143643946};\\\", \\\"{x:339,y:761,t:1528143643964};\\\", \\\"{x:321,y:768,t:1528143643980};\\\", \\\"{x:315,y:771,t:1528143643997};\\\", \\\"{x:316,y:771,t:1528143644103};\\\", \\\"{x:318,y:771,t:1528143644114};\\\", \\\"{x:321,y:768,t:1528143644129};\\\", \\\"{x:321,y:764,t:1528143644147};\\\", \\\"{x:322,y:763,t:1528143644166};\\\", \\\"{x:325,y:763,t:1528143644179};\\\", \\\"{x:327,y:763,t:1528143644206};\\\", \\\"{x:328,y:763,t:1528143644246};\\\", \\\"{x:331,y:763,t:1528143644263};\\\", \\\"{x:338,y:763,t:1528143644280};\\\", \\\"{x:350,y:766,t:1528143644296};\\\", \\\"{x:362,y:767,t:1528143644313};\\\", \\\"{x:378,y:771,t:1528143644331};\\\", \\\"{x:395,y:776,t:1528143644346};\\\", \\\"{x:398,y:777,t:1528143644363};\\\", \\\"{x:399,y:777,t:1528143644383};\\\", \\\"{x:401,y:777,t:1528143644396};\\\", \\\"{x:402,y:777,t:1528143644414};\\\", \\\"{x:404,y:777,t:1528143644438};\\\", \\\"{x:406,y:777,t:1528143644454};\\\", \\\"{x:409,y:777,t:1528143644464};\\\", \\\"{x:418,y:774,t:1528143644480};\\\", \\\"{x:427,y:768,t:1528143644497};\\\", \\\"{x:435,y:764,t:1528143644514};\\\", \\\"{x:439,y:761,t:1528143644531};\\\", \\\"{x:442,y:761,t:1528143644547};\\\", \\\"{x:443,y:760,t:1528143644615};\\\", \\\"{x:444,y:760,t:1528143644647};\\\", \\\"{x:445,y:758,t:1528143644663};\\\", \\\"{x:448,y:753,t:1528143644681};\\\", \\\"{x:456,y:744,t:1528143644699};\\\", \\\"{x:474,y:733,t:1528143644713};\\\", \\\"{x:486,y:727,t:1528143644728};\\\", \\\"{x:492,y:725,t:1528143644745};\\\", \\\"{x:487,y:725,t:1528143645894};\\\", \\\"{x:477,y:715,t:1528143645925};\\\" ] }, { \\\"rt\\\": 9859, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 744078, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -02 PM-02 PM-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:714,t:1528143646798};\\\", \\\"{x:476,y:712,t:1528143646941};\\\", \\\"{x:476,y:707,t:1528143646950};\\\", \\\"{x:476,y:704,t:1528143646965};\\\", \\\"{x:476,y:698,t:1528143646981};\\\", \\\"{x:477,y:692,t:1528143646998};\\\", \\\"{x:477,y:684,t:1528143647016};\\\", \\\"{x:477,y:676,t:1528143647032};\\\", \\\"{x:476,y:666,t:1528143647049};\\\", \\\"{x:473,y:654,t:1528143647066};\\\", \\\"{x:470,y:648,t:1528143647083};\\\", \\\"{x:467,y:640,t:1528143647100};\\\", \\\"{x:465,y:631,t:1528143647117};\\\", \\\"{x:461,y:620,t:1528143647133};\\\", \\\"{x:458,y:612,t:1528143647148};\\\", \\\"{x:457,y:608,t:1528143647166};\\\", \\\"{x:456,y:602,t:1528143647182};\\\", \\\"{x:454,y:597,t:1528143647198};\\\", \\\"{x:453,y:595,t:1528143647215};\\\", \\\"{x:453,y:594,t:1528143647233};\\\", \\\"{x:453,y:593,t:1528143647262};\\\", \\\"{x:453,y:591,t:1528143647269};\\\", \\\"{x:453,y:589,t:1528143647285};\\\", \\\"{x:453,y:587,t:1528143647300};\\\", \\\"{x:453,y:584,t:1528143647315};\\\", \\\"{x:453,y:581,t:1528143647332};\\\", \\\"{x:453,y:579,t:1528143647349};\\\", \\\"{x:453,y:576,t:1528143647365};\\\", \\\"{x:453,y:575,t:1528143647382};\\\", \\\"{x:453,y:574,t:1528143647654};\\\", \\\"{x:456,y:570,t:1528143647666};\\\", \\\"{x:464,y:564,t:1528143647683};\\\", \\\"{x:476,y:555,t:1528143647702};\\\", \\\"{x:496,y:544,t:1528143647716};\\\", \\\"{x:518,y:532,t:1528143647732};\\\", \\\"{x:553,y:518,t:1528143647750};\\\", \\\"{x:604,y:516,t:1528143647766};\\\", \\\"{x:679,y:539,t:1528143647782};\\\", \\\"{x:763,y:566,t:1528143647800};\\\", \\\"{x:862,y:590,t:1528143647816};\\\", \\\"{x:975,y:620,t:1528143647832};\\\", \\\"{x:1089,y:641,t:1528143647850};\\\", \\\"{x:1212,y:659,t:1528143647866};\\\", \\\"{x:1326,y:678,t:1528143647882};\\\", \\\"{x:1425,y:690,t:1528143647899};\\\", \\\"{x:1529,y:697,t:1528143647917};\\\", \\\"{x:1664,y:705,t:1528143647934};\\\", \\\"{x:1724,y:708,t:1528143647949};\\\", \\\"{x:1766,y:708,t:1528143647967};\\\", \\\"{x:1803,y:710,t:1528143647983};\\\", \\\"{x:1826,y:710,t:1528143647999};\\\", \\\"{x:1841,y:710,t:1528143648016};\\\", \\\"{x:1851,y:710,t:1528143648033};\\\", \\\"{x:1856,y:710,t:1528143648049};\\\", \\\"{x:1861,y:710,t:1528143648066};\\\", \\\"{x:1859,y:710,t:1528143648199};\\\", \\\"{x:1857,y:710,t:1528143648206};\\\", \\\"{x:1852,y:710,t:1528143648217};\\\", \\\"{x:1841,y:710,t:1528143648234};\\\", \\\"{x:1829,y:714,t:1528143648251};\\\", \\\"{x:1810,y:723,t:1528143648267};\\\", \\\"{x:1797,y:729,t:1528143648284};\\\", \\\"{x:1781,y:734,t:1528143648301};\\\", \\\"{x:1769,y:739,t:1528143648319};\\\", \\\"{x:1762,y:742,t:1528143648334};\\\", \\\"{x:1760,y:744,t:1528143648351};\\\", \\\"{x:1759,y:744,t:1528143648368};\\\", \\\"{x:1756,y:746,t:1528143648384};\\\", \\\"{x:1750,y:746,t:1528143648401};\\\", \\\"{x:1744,y:748,t:1528143648418};\\\", \\\"{x:1732,y:750,t:1528143648435};\\\", \\\"{x:1722,y:753,t:1528143648451};\\\", \\\"{x:1706,y:755,t:1528143648468};\\\", \\\"{x:1691,y:755,t:1528143648486};\\\", \\\"{x:1675,y:756,t:1528143648501};\\\", \\\"{x:1642,y:758,t:1528143648518};\\\", \\\"{x:1619,y:758,t:1528143648535};\\\", \\\"{x:1598,y:758,t:1528143648551};\\\", \\\"{x:1573,y:759,t:1528143648568};\\\", \\\"{x:1548,y:759,t:1528143648585};\\\", \\\"{x:1526,y:759,t:1528143648603};\\\", \\\"{x:1507,y:759,t:1528143648618};\\\", \\\"{x:1492,y:757,t:1528143648635};\\\", \\\"{x:1481,y:754,t:1528143648653};\\\", \\\"{x:1472,y:751,t:1528143648668};\\\", \\\"{x:1464,y:750,t:1528143648685};\\\", \\\"{x:1457,y:748,t:1528143648703};\\\", \\\"{x:1454,y:748,t:1528143648719};\\\", \\\"{x:1448,y:748,t:1528143648736};\\\", \\\"{x:1438,y:748,t:1528143648752};\\\", \\\"{x:1430,y:748,t:1528143648769};\\\", \\\"{x:1419,y:747,t:1528143648784};\\\", \\\"{x:1413,y:746,t:1528143648801};\\\", \\\"{x:1403,y:743,t:1528143648818};\\\", \\\"{x:1396,y:741,t:1528143648835};\\\", \\\"{x:1391,y:738,t:1528143648852};\\\", \\\"{x:1384,y:733,t:1528143648868};\\\", \\\"{x:1378,y:730,t:1528143648886};\\\", \\\"{x:1374,y:727,t:1528143648901};\\\", \\\"{x:1372,y:722,t:1528143648918};\\\", \\\"{x:1371,y:718,t:1528143648936};\\\", \\\"{x:1371,y:716,t:1528143648952};\\\", \\\"{x:1371,y:715,t:1528143648969};\\\", \\\"{x:1370,y:713,t:1528143648986};\\\", \\\"{x:1370,y:712,t:1528143649001};\\\", \\\"{x:1370,y:711,t:1528143649019};\\\", \\\"{x:1369,y:708,t:1528143649036};\\\", \\\"{x:1368,y:706,t:1528143649053};\\\", \\\"{x:1366,y:705,t:1528143649069};\\\", \\\"{x:1366,y:704,t:1528143649086};\\\", \\\"{x:1361,y:698,t:1528143649102};\\\", \\\"{x:1357,y:693,t:1528143649119};\\\", \\\"{x:1355,y:691,t:1528143649136};\\\", \\\"{x:1354,y:690,t:1528143649159};\\\", \\\"{x:1353,y:689,t:1528143649175};\\\", \\\"{x:1353,y:690,t:1528143649423};\\\", \\\"{x:1353,y:691,t:1528143649437};\\\", \\\"{x:1353,y:694,t:1528143649456};\\\", \\\"{x:1353,y:697,t:1528143649470};\\\", \\\"{x:1354,y:699,t:1528143649487};\\\", \\\"{x:1355,y:702,t:1528143649502};\\\", \\\"{x:1357,y:708,t:1528143649519};\\\", \\\"{x:1359,y:712,t:1528143649536};\\\", \\\"{x:1362,y:717,t:1528143649553};\\\", \\\"{x:1364,y:721,t:1528143649570};\\\", \\\"{x:1366,y:727,t:1528143649586};\\\", \\\"{x:1370,y:734,t:1528143649604};\\\", \\\"{x:1373,y:738,t:1528143649620};\\\", \\\"{x:1376,y:745,t:1528143649637};\\\", \\\"{x:1382,y:754,t:1528143649653};\\\", \\\"{x:1387,y:764,t:1528143649670};\\\", \\\"{x:1391,y:774,t:1528143649687};\\\", \\\"{x:1397,y:785,t:1528143649703};\\\", \\\"{x:1402,y:797,t:1528143649721};\\\", \\\"{x:1409,y:809,t:1528143649736};\\\", \\\"{x:1415,y:818,t:1528143649754};\\\", \\\"{x:1420,y:827,t:1528143649770};\\\", \\\"{x:1424,y:834,t:1528143649787};\\\", \\\"{x:1431,y:844,t:1528143649803};\\\", \\\"{x:1437,y:854,t:1528143649821};\\\", \\\"{x:1440,y:858,t:1528143649837};\\\", \\\"{x:1444,y:864,t:1528143649854};\\\", \\\"{x:1448,y:874,t:1528143649871};\\\", \\\"{x:1456,y:893,t:1528143649888};\\\", \\\"{x:1464,y:913,t:1528143649904};\\\", \\\"{x:1474,y:933,t:1528143649921};\\\", \\\"{x:1482,y:953,t:1528143649938};\\\", \\\"{x:1489,y:969,t:1528143649954};\\\", \\\"{x:1495,y:980,t:1528143649971};\\\", \\\"{x:1501,y:989,t:1528143649988};\\\", \\\"{x:1505,y:996,t:1528143650005};\\\", \\\"{x:1507,y:1003,t:1528143650020};\\\", \\\"{x:1509,y:1004,t:1528143650037};\\\", \\\"{x:1510,y:1006,t:1528143650054};\\\", \\\"{x:1511,y:1006,t:1528143650071};\\\", \\\"{x:1511,y:1007,t:1528143650110};\\\", \\\"{x:1510,y:1007,t:1528143650231};\\\", \\\"{x:1510,y:1006,t:1528143650247};\\\", \\\"{x:1508,y:1004,t:1528143650254};\\\", \\\"{x:1507,y:1001,t:1528143650272};\\\", \\\"{x:1505,y:999,t:1528143650288};\\\", \\\"{x:1504,y:997,t:1528143650305};\\\", \\\"{x:1502,y:994,t:1528143650322};\\\", \\\"{x:1501,y:993,t:1528143650339};\\\", \\\"{x:1501,y:991,t:1528143650355};\\\", \\\"{x:1499,y:988,t:1528143650372};\\\", \\\"{x:1498,y:987,t:1528143650389};\\\", \\\"{x:1498,y:986,t:1528143650423};\\\", \\\"{x:1497,y:984,t:1528143650440};\\\", \\\"{x:1495,y:980,t:1528143650456};\\\", \\\"{x:1491,y:975,t:1528143650472};\\\", \\\"{x:1490,y:973,t:1528143650489};\\\", \\\"{x:1486,y:967,t:1528143650506};\\\", \\\"{x:1480,y:956,t:1528143650523};\\\", \\\"{x:1478,y:954,t:1528143650539};\\\", \\\"{x:1477,y:952,t:1528143650556};\\\", \\\"{x:1475,y:948,t:1528143650572};\\\", \\\"{x:1474,y:946,t:1528143650589};\\\", \\\"{x:1472,y:942,t:1528143650606};\\\", \\\"{x:1471,y:939,t:1528143650623};\\\", \\\"{x:1470,y:936,t:1528143650640};\\\", \\\"{x:1468,y:932,t:1528143650656};\\\", \\\"{x:1466,y:927,t:1528143650674};\\\", \\\"{x:1464,y:921,t:1528143650689};\\\", \\\"{x:1463,y:917,t:1528143650706};\\\", \\\"{x:1461,y:911,t:1528143650724};\\\", \\\"{x:1458,y:904,t:1528143650739};\\\", \\\"{x:1455,y:897,t:1528143650756};\\\", \\\"{x:1450,y:884,t:1528143650773};\\\", \\\"{x:1433,y:851,t:1528143650789};\\\", \\\"{x:1422,y:826,t:1528143650805};\\\", \\\"{x:1415,y:808,t:1528143650822};\\\", \\\"{x:1409,y:795,t:1528143650839};\\\", \\\"{x:1404,y:788,t:1528143650856};\\\", \\\"{x:1402,y:784,t:1528143650873};\\\", \\\"{x:1398,y:779,t:1528143650890};\\\", \\\"{x:1396,y:775,t:1528143650906};\\\", \\\"{x:1394,y:767,t:1528143650923};\\\", \\\"{x:1392,y:762,t:1528143650940};\\\", \\\"{x:1389,y:758,t:1528143650957};\\\", \\\"{x:1387,y:753,t:1528143650973};\\\", \\\"{x:1383,y:748,t:1528143650989};\\\", \\\"{x:1381,y:746,t:1528143651006};\\\", \\\"{x:1380,y:744,t:1528143651023};\\\", \\\"{x:1378,y:743,t:1528143651039};\\\", \\\"{x:1378,y:739,t:1528143651057};\\\", \\\"{x:1375,y:733,t:1528143651073};\\\", \\\"{x:1371,y:723,t:1528143651089};\\\", \\\"{x:1366,y:717,t:1528143651106};\\\", \\\"{x:1357,y:703,t:1528143651124};\\\", \\\"{x:1350,y:692,t:1528143651139};\\\", \\\"{x:1344,y:680,t:1528143651156};\\\", \\\"{x:1337,y:665,t:1528143651173};\\\", \\\"{x:1330,y:655,t:1528143651190};\\\", \\\"{x:1325,y:646,t:1528143651206};\\\", \\\"{x:1317,y:634,t:1528143651223};\\\", \\\"{x:1312,y:627,t:1528143651240};\\\", \\\"{x:1305,y:618,t:1528143651256};\\\", \\\"{x:1295,y:606,t:1528143651273};\\\", \\\"{x:1282,y:599,t:1528143651290};\\\", \\\"{x:1267,y:589,t:1528143651306};\\\", \\\"{x:1255,y:580,t:1528143651324};\\\", \\\"{x:1246,y:578,t:1528143651341};\\\", \\\"{x:1233,y:574,t:1528143651356};\\\", \\\"{x:1199,y:573,t:1528143651374};\\\", \\\"{x:1155,y:573,t:1528143651391};\\\", \\\"{x:1082,y:585,t:1528143651408};\\\", \\\"{x:1001,y:600,t:1528143651423};\\\", \\\"{x:908,y:618,t:1528143651442};\\\", \\\"{x:825,y:627,t:1528143651457};\\\", \\\"{x:768,y:632,t:1528143651470};\\\", \\\"{x:717,y:633,t:1528143651486};\\\", \\\"{x:658,y:633,t:1528143651502};\\\", \\\"{x:592,y:633,t:1528143651519};\\\", \\\"{x:536,y:633,t:1528143651535};\\\", \\\"{x:480,y:633,t:1528143651553};\\\", \\\"{x:427,y:633,t:1528143651570};\\\", \\\"{x:390,y:633,t:1528143651586};\\\", \\\"{x:358,y:633,t:1528143651602};\\\", \\\"{x:338,y:633,t:1528143651619};\\\", \\\"{x:320,y:633,t:1528143651636};\\\", \\\"{x:310,y:633,t:1528143651653};\\\", \\\"{x:305,y:633,t:1528143651670};\\\", \\\"{x:303,y:633,t:1528143651751};\\\", \\\"{x:300,y:633,t:1528143651758};\\\", \\\"{x:294,y:632,t:1528143651770};\\\", \\\"{x:285,y:627,t:1528143651787};\\\", \\\"{x:279,y:624,t:1528143651802};\\\", \\\"{x:272,y:619,t:1528143651820};\\\", \\\"{x:262,y:614,t:1528143651836};\\\", \\\"{x:254,y:608,t:1528143651853};\\\", \\\"{x:247,y:603,t:1528143651868};\\\", \\\"{x:242,y:600,t:1528143651886};\\\", \\\"{x:234,y:596,t:1528143651902};\\\", \\\"{x:225,y:594,t:1528143651919};\\\", \\\"{x:217,y:591,t:1528143651937};\\\", \\\"{x:211,y:587,t:1528143651952};\\\", \\\"{x:202,y:582,t:1528143651970};\\\", \\\"{x:189,y:574,t:1528143651987};\\\", \\\"{x:175,y:567,t:1528143652003};\\\", \\\"{x:161,y:561,t:1528143652019};\\\", \\\"{x:151,y:556,t:1528143652036};\\\", \\\"{x:148,y:553,t:1528143652054};\\\", \\\"{x:148,y:552,t:1528143652070};\\\", \\\"{x:152,y:548,t:1528143652087};\\\", \\\"{x:162,y:543,t:1528143652102};\\\", \\\"{x:173,y:536,t:1528143652119};\\\", \\\"{x:188,y:528,t:1528143652136};\\\", \\\"{x:200,y:522,t:1528143652153};\\\", \\\"{x:216,y:521,t:1528143652169};\\\", \\\"{x:228,y:520,t:1528143652187};\\\", \\\"{x:238,y:516,t:1528143652204};\\\", \\\"{x:254,y:513,t:1528143652220};\\\", \\\"{x:274,y:507,t:1528143652238};\\\", \\\"{x:288,y:504,t:1528143652253};\\\", \\\"{x:292,y:502,t:1528143652269};\\\", \\\"{x:299,y:501,t:1528143652286};\\\", \\\"{x:307,y:500,t:1528143652302};\\\", \\\"{x:325,y:500,t:1528143652320};\\\", \\\"{x:377,y:497,t:1528143652337};\\\", \\\"{x:469,y:495,t:1528143652353};\\\", \\\"{x:548,y:491,t:1528143652370};\\\", \\\"{x:622,y:486,t:1528143652387};\\\", \\\"{x:670,y:478,t:1528143652402};\\\", \\\"{x:696,y:473,t:1528143652419};\\\", \\\"{x:704,y:472,t:1528143652437};\\\", \\\"{x:700,y:473,t:1528143652638};\\\", \\\"{x:688,y:478,t:1528143652654};\\\", \\\"{x:676,y:482,t:1528143652670};\\\", \\\"{x:669,y:484,t:1528143652687};\\\", \\\"{x:662,y:486,t:1528143652704};\\\", \\\"{x:658,y:486,t:1528143652720};\\\", \\\"{x:656,y:487,t:1528143652737};\\\", \\\"{x:655,y:487,t:1528143652766};\\\", \\\"{x:653,y:487,t:1528143652774};\\\", \\\"{x:652,y:487,t:1528143652786};\\\", \\\"{x:648,y:487,t:1528143652804};\\\", \\\"{x:644,y:488,t:1528143652821};\\\", \\\"{x:638,y:490,t:1528143652837};\\\", \\\"{x:629,y:494,t:1528143652853};\\\", \\\"{x:622,y:497,t:1528143652870};\\\", \\\"{x:615,y:500,t:1528143652888};\\\", \\\"{x:606,y:504,t:1528143652904};\\\", \\\"{x:600,y:505,t:1528143652921};\\\", \\\"{x:597,y:507,t:1528143652939};\\\", \\\"{x:596,y:507,t:1528143653190};\\\", \\\"{x:596,y:506,t:1528143653206};\\\", \\\"{x:596,y:507,t:1528143654591};\\\", \\\"{x:595,y:523,t:1528143654609};\\\", \\\"{x:591,y:547,t:1528143654625};\\\", \\\"{x:587,y:574,t:1528143654638};\\\", \\\"{x:582,y:593,t:1528143654655};\\\", \\\"{x:576,y:612,t:1528143654672};\\\", \\\"{x:572,y:626,t:1528143654688};\\\", \\\"{x:567,y:643,t:1528143654704};\\\", \\\"{x:563,y:654,t:1528143654721};\\\", \\\"{x:561,y:661,t:1528143654738};\\\", \\\"{x:559,y:668,t:1528143654754};\\\", \\\"{x:558,y:670,t:1528143654771};\\\", \\\"{x:558,y:671,t:1528143654798};\\\", \\\"{x:559,y:671,t:1528143654822};\\\", \\\"{x:563,y:659,t:1528143654839};\\\", \\\"{x:567,y:644,t:1528143654855};\\\", \\\"{x:570,y:629,t:1528143654872};\\\", \\\"{x:574,y:609,t:1528143654889};\\\", \\\"{x:576,y:590,t:1528143654906};\\\", \\\"{x:579,y:574,t:1528143654921};\\\", \\\"{x:579,y:563,t:1528143654938};\\\", \\\"{x:579,y:558,t:1528143654955};\\\", \\\"{x:579,y:553,t:1528143654972};\\\", \\\"{x:579,y:546,t:1528143654989};\\\", \\\"{x:579,y:534,t:1528143655006};\\\", \\\"{x:579,y:531,t:1528143655021};\\\", \\\"{x:579,y:526,t:1528143655039};\\\", \\\"{x:579,y:521,t:1528143655056};\\\", \\\"{x:580,y:517,t:1528143655073};\\\", \\\"{x:581,y:515,t:1528143655088};\\\", \\\"{x:582,y:512,t:1528143655105};\\\", \\\"{x:587,y:507,t:1528143655121};\\\", \\\"{x:594,y:503,t:1528143655139};\\\", \\\"{x:597,y:501,t:1528143655154};\\\", \\\"{x:602,y:499,t:1528143655172};\\\", \\\"{x:600,y:513,t:1528143655501};\\\", \\\"{x:598,y:525,t:1528143655510};\\\", \\\"{x:595,y:541,t:1528143655520};\\\", \\\"{x:586,y:589,t:1528143655539};\\\", \\\"{x:574,y:639,t:1528143655556};\\\", \\\"{x:562,y:681,t:1528143655573};\\\", \\\"{x:553,y:700,t:1528143655589};\\\", \\\"{x:546,y:720,t:1528143655606};\\\", \\\"{x:543,y:725,t:1528143655623};\\\", \\\"{x:542,y:727,t:1528143655639};\\\", \\\"{x:542,y:728,t:1528143655656};\\\", \\\"{x:541,y:728,t:1528143655718};\\\", \\\"{x:541,y:730,t:1528143655726};\\\", \\\"{x:540,y:732,t:1528143655740};\\\", \\\"{x:540,y:735,t:1528143655756};\\\", \\\"{x:540,y:736,t:1528143655782};\\\" ] }, { \\\"rt\\\": 8064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 753350, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:737,t:1528143658551};\\\", \\\"{x:554,y:737,t:1528143658558};\\\", \\\"{x:633,y:732,t:1528143658575};\\\", \\\"{x:744,y:730,t:1528143658591};\\\", \\\"{x:860,y:730,t:1528143658607};\\\", \\\"{x:952,y:730,t:1528143658624};\\\", \\\"{x:1010,y:730,t:1528143658641};\\\", \\\"{x:1072,y:730,t:1528143658658};\\\", \\\"{x:1117,y:730,t:1528143658674};\\\", \\\"{x:1156,y:730,t:1528143658691};\\\", \\\"{x:1193,y:729,t:1528143658707};\\\", \\\"{x:1221,y:724,t:1528143658725};\\\", \\\"{x:1236,y:723,t:1528143658741};\\\", \\\"{x:1246,y:720,t:1528143658758};\\\", \\\"{x:1249,y:720,t:1528143658775};\\\", \\\"{x:1252,y:719,t:1528143658791};\\\", \\\"{x:1257,y:717,t:1528143658808};\\\", \\\"{x:1266,y:713,t:1528143658825};\\\", \\\"{x:1272,y:712,t:1528143658842};\\\", \\\"{x:1278,y:711,t:1528143658858};\\\", \\\"{x:1283,y:709,t:1528143658875};\\\", \\\"{x:1285,y:708,t:1528143658892};\\\", \\\"{x:1287,y:708,t:1528143658908};\\\", \\\"{x:1288,y:708,t:1528143658942};\\\", \\\"{x:1290,y:708,t:1528143658966};\\\", \\\"{x:1291,y:708,t:1528143658982};\\\", \\\"{x:1292,y:708,t:1528143658992};\\\", \\\"{x:1296,y:712,t:1528143659009};\\\", \\\"{x:1300,y:721,t:1528143659026};\\\", \\\"{x:1307,y:732,t:1528143659043};\\\", \\\"{x:1311,y:743,t:1528143659058};\\\", \\\"{x:1320,y:761,t:1528143659076};\\\", \\\"{x:1329,y:780,t:1528143659093};\\\", \\\"{x:1338,y:796,t:1528143659108};\\\", \\\"{x:1347,y:818,t:1528143659125};\\\", \\\"{x:1353,y:837,t:1528143659142};\\\", \\\"{x:1356,y:845,t:1528143659159};\\\", \\\"{x:1359,y:851,t:1528143659176};\\\", \\\"{x:1365,y:858,t:1528143659193};\\\", \\\"{x:1366,y:864,t:1528143659208};\\\", \\\"{x:1368,y:867,t:1528143659226};\\\", \\\"{x:1369,y:869,t:1528143659243};\\\", \\\"{x:1371,y:871,t:1528143659259};\\\", \\\"{x:1373,y:874,t:1528143659276};\\\", \\\"{x:1376,y:878,t:1528143659293};\\\", \\\"{x:1379,y:882,t:1528143659309};\\\", \\\"{x:1383,y:885,t:1528143659326};\\\", \\\"{x:1388,y:889,t:1528143659344};\\\", \\\"{x:1391,y:892,t:1528143659359};\\\", \\\"{x:1395,y:896,t:1528143659376};\\\", \\\"{x:1399,y:901,t:1528143659392};\\\", \\\"{x:1402,y:904,t:1528143659409};\\\", \\\"{x:1403,y:906,t:1528143659425};\\\", \\\"{x:1403,y:907,t:1528143659443};\\\", \\\"{x:1404,y:908,t:1528143659470};\\\", \\\"{x:1403,y:910,t:1528143659589};\\\", \\\"{x:1402,y:910,t:1528143659598};\\\", \\\"{x:1402,y:911,t:1528143659609};\\\", \\\"{x:1401,y:912,t:1528143659625};\\\", \\\"{x:1398,y:916,t:1528143659642};\\\", \\\"{x:1394,y:921,t:1528143659659};\\\", \\\"{x:1393,y:924,t:1528143659675};\\\", \\\"{x:1391,y:928,t:1528143659692};\\\", \\\"{x:1389,y:931,t:1528143659709};\\\", \\\"{x:1386,y:934,t:1528143659725};\\\", \\\"{x:1381,y:941,t:1528143659742};\\\", \\\"{x:1380,y:943,t:1528143659760};\\\", \\\"{x:1378,y:947,t:1528143659776};\\\", \\\"{x:1377,y:951,t:1528143659793};\\\", \\\"{x:1376,y:952,t:1528143659809};\\\", \\\"{x:1375,y:954,t:1528143659825};\\\", \\\"{x:1374,y:956,t:1528143659843};\\\", \\\"{x:1373,y:957,t:1528143659859};\\\", \\\"{x:1372,y:958,t:1528143659878};\\\", \\\"{x:1371,y:958,t:1528143659893};\\\", \\\"{x:1369,y:958,t:1528143659909};\\\", \\\"{x:1367,y:958,t:1528143659926};\\\", \\\"{x:1366,y:959,t:1528143659942};\\\", \\\"{x:1364,y:960,t:1528143659960};\\\", \\\"{x:1363,y:960,t:1528143659976};\\\", \\\"{x:1360,y:960,t:1528143659993};\\\", \\\"{x:1356,y:960,t:1528143660010};\\\", \\\"{x:1353,y:960,t:1528143660025};\\\", \\\"{x:1352,y:960,t:1528143660159};\\\", \\\"{x:1352,y:956,t:1528143660176};\\\", \\\"{x:1352,y:952,t:1528143660193};\\\", \\\"{x:1352,y:949,t:1528143660210};\\\", \\\"{x:1354,y:941,t:1528143660226};\\\", \\\"{x:1359,y:924,t:1528143660243};\\\", \\\"{x:1363,y:906,t:1528143660260};\\\", \\\"{x:1369,y:891,t:1528143660276};\\\", \\\"{x:1372,y:876,t:1528143660293};\\\", \\\"{x:1375,y:868,t:1528143660309};\\\", \\\"{x:1378,y:857,t:1528143660326};\\\", \\\"{x:1380,y:848,t:1528143660342};\\\", \\\"{x:1382,y:840,t:1528143660359};\\\", \\\"{x:1385,y:830,t:1528143660377};\\\", \\\"{x:1391,y:813,t:1528143660393};\\\", \\\"{x:1398,y:797,t:1528143660409};\\\", \\\"{x:1401,y:783,t:1528143660427};\\\", \\\"{x:1406,y:768,t:1528143660442};\\\", \\\"{x:1409,y:761,t:1528143660460};\\\", \\\"{x:1410,y:756,t:1528143660476};\\\", \\\"{x:1413,y:751,t:1528143660492};\\\", \\\"{x:1413,y:750,t:1528143660510};\\\", \\\"{x:1414,y:748,t:1528143660527};\\\", \\\"{x:1413,y:747,t:1528143660590};\\\", \\\"{x:1409,y:747,t:1528143660599};\\\", \\\"{x:1404,y:747,t:1528143660610};\\\", \\\"{x:1387,y:748,t:1528143660627};\\\", \\\"{x:1367,y:751,t:1528143660643};\\\", \\\"{x:1344,y:761,t:1528143660662};\\\", \\\"{x:1319,y:771,t:1528143660676};\\\", \\\"{x:1287,y:784,t:1528143660692};\\\", \\\"{x:1244,y:800,t:1528143660709};\\\", \\\"{x:1194,y:813,t:1528143660725};\\\", \\\"{x:1157,y:819,t:1528143660742};\\\", \\\"{x:1117,y:820,t:1528143660759};\\\", \\\"{x:1081,y:820,t:1528143660776};\\\", \\\"{x:1025,y:820,t:1528143660794};\\\", \\\"{x:963,y:820,t:1528143660809};\\\", \\\"{x:916,y:820,t:1528143660826};\\\", \\\"{x:855,y:813,t:1528143660843};\\\", \\\"{x:792,y:801,t:1528143660859};\\\", \\\"{x:728,y:791,t:1528143660877};\\\", \\\"{x:667,y:775,t:1528143660893};\\\", \\\"{x:610,y:764,t:1528143660909};\\\", \\\"{x:559,y:749,t:1528143660926};\\\", \\\"{x:546,y:740,t:1528143660943};\\\", \\\"{x:536,y:735,t:1528143660959};\\\", \\\"{x:530,y:734,t:1528143660977};\\\", \\\"{x:525,y:732,t:1528143660994};\\\", \\\"{x:523,y:731,t:1528143661010};\\\", \\\"{x:516,y:726,t:1528143661027};\\\", \\\"{x:511,y:711,t:1528143661044};\\\", \\\"{x:508,y:691,t:1528143661060};\\\", \\\"{x:508,y:666,t:1528143661078};\\\", \\\"{x:500,y:627,t:1528143661094};\\\", \\\"{x:497,y:619,t:1528143661110};\\\", \\\"{x:496,y:617,t:1528143661127};\\\", \\\"{x:496,y:616,t:1528143661165};\\\", \\\"{x:496,y:615,t:1528143661177};\\\", \\\"{x:496,y:614,t:1528143661194};\\\", \\\"{x:496,y:612,t:1528143661211};\\\", \\\"{x:496,y:611,t:1528143661230};\\\", \\\"{x:496,y:610,t:1528143661287};\\\", \\\"{x:494,y:608,t:1528143661294};\\\", \\\"{x:479,y:603,t:1528143661311};\\\", \\\"{x:462,y:601,t:1528143661327};\\\", \\\"{x:443,y:596,t:1528143661345};\\\", \\\"{x:419,y:595,t:1528143661362};\\\", \\\"{x:395,y:595,t:1528143661377};\\\", \\\"{x:371,y:594,t:1528143661394};\\\", \\\"{x:354,y:594,t:1528143661410};\\\", \\\"{x:339,y:594,t:1528143661427};\\\", \\\"{x:335,y:594,t:1528143661444};\\\", \\\"{x:339,y:589,t:1528143661640};\\\", \\\"{x:352,y:575,t:1528143661661};\\\", \\\"{x:362,y:561,t:1528143661677};\\\", \\\"{x:370,y:552,t:1528143661694};\\\", \\\"{x:374,y:545,t:1528143661711};\\\", \\\"{x:378,y:539,t:1528143661728};\\\", \\\"{x:380,y:535,t:1528143661744};\\\", \\\"{x:381,y:534,t:1528143661761};\\\", \\\"{x:383,y:532,t:1528143661777};\\\", \\\"{x:383,y:531,t:1528143661793};\\\", \\\"{x:384,y:531,t:1528143661813};\\\", \\\"{x:383,y:532,t:1528143662094};\\\", \\\"{x:383,y:538,t:1528143662111};\\\", \\\"{x:383,y:542,t:1528143662127};\\\", \\\"{x:383,y:550,t:1528143662144};\\\", \\\"{x:383,y:556,t:1528143662161};\\\", \\\"{x:383,y:565,t:1528143662178};\\\", \\\"{x:384,y:575,t:1528143662195};\\\", \\\"{x:384,y:584,t:1528143662210};\\\", \\\"{x:384,y:588,t:1528143662228};\\\", \\\"{x:384,y:596,t:1528143662246};\\\", \\\"{x:384,y:597,t:1528143662262};\\\", \\\"{x:384,y:599,t:1528143662278};\\\", \\\"{x:385,y:601,t:1528143662296};\\\", \\\"{x:385,y:602,t:1528143662310};\\\", \\\"{x:385,y:603,t:1528143662446};\\\", \\\"{x:386,y:603,t:1528143662462};\\\", \\\"{x:387,y:606,t:1528143662678};\\\", \\\"{x:400,y:620,t:1528143662695};\\\", \\\"{x:406,y:635,t:1528143662712};\\\", \\\"{x:412,y:646,t:1528143662728};\\\", \\\"{x:418,y:654,t:1528143662745};\\\", \\\"{x:424,y:662,t:1528143662762};\\\", \\\"{x:429,y:669,t:1528143662779};\\\", \\\"{x:430,y:673,t:1528143662796};\\\", \\\"{x:432,y:676,t:1528143662812};\\\", \\\"{x:434,y:679,t:1528143662829};\\\", \\\"{x:435,y:681,t:1528143662845};\\\", \\\"{x:439,y:684,t:1528143662862};\\\", \\\"{x:442,y:687,t:1528143662879};\\\", \\\"{x:450,y:693,t:1528143662895};\\\", \\\"{x:459,y:700,t:1528143662912};\\\", \\\"{x:466,y:707,t:1528143662930};\\\", \\\"{x:468,y:710,t:1528143662946};\\\", \\\"{x:470,y:711,t:1528143662962};\\\", \\\"{x:468,y:701,t:1528143663047};\\\", \\\"{x:448,y:647,t:1528143663063};\\\", \\\"{x:440,y:627,t:1528143663080};\\\", \\\"{x:432,y:616,t:1528143663095};\\\", \\\"{x:426,y:604,t:1528143663112};\\\", \\\"{x:421,y:595,t:1528143663130};\\\", \\\"{x:421,y:594,t:1528143663145};\\\", \\\"{x:419,y:594,t:1528143663230};\\\", \\\"{x:418,y:593,t:1528143663246};\\\", \\\"{x:415,y:593,t:1528143663262};\\\", \\\"{x:407,y:593,t:1528143663279};\\\", \\\"{x:397,y:595,t:1528143663296};\\\", \\\"{x:391,y:597,t:1528143663312};\\\", \\\"{x:382,y:604,t:1528143663330};\\\", \\\"{x:372,y:614,t:1528143663346};\\\", \\\"{x:368,y:618,t:1528143663362};\\\", \\\"{x:366,y:620,t:1528143663379};\\\", \\\"{x:364,y:621,t:1528143663395};\\\", \\\"{x:363,y:622,t:1528143663412};\\\", \\\"{x:363,y:624,t:1528143663518};\\\", \\\"{x:364,y:625,t:1528143663530};\\\", \\\"{x:368,y:625,t:1528143663546};\\\", \\\"{x:371,y:626,t:1528143663562};\\\", \\\"{x:378,y:626,t:1528143663579};\\\", \\\"{x:383,y:626,t:1528143663596};\\\", \\\"{x:385,y:626,t:1528143663612};\\\", \\\"{x:386,y:626,t:1528143663654};\\\", \\\"{x:387,y:626,t:1528143663918};\\\", \\\"{x:392,y:630,t:1528143663929};\\\", \\\"{x:397,y:639,t:1528143663947};\\\", \\\"{x:404,y:650,t:1528143663962};\\\", \\\"{x:411,y:665,t:1528143663979};\\\", \\\"{x:419,y:677,t:1528143663997};\\\", \\\"{x:425,y:689,t:1528143664014};\\\", \\\"{x:426,y:691,t:1528143664029};\\\", \\\"{x:429,y:694,t:1528143664046};\\\", \\\"{x:430,y:697,t:1528143664063};\\\", \\\"{x:433,y:701,t:1528143664079};\\\", \\\"{x:439,y:707,t:1528143664097};\\\", \\\"{x:444,y:714,t:1528143664114};\\\", \\\"{x:447,y:718,t:1528143664129};\\\", \\\"{x:452,y:720,t:1528143664147};\\\", \\\"{x:452,y:721,t:1528143664163};\\\", \\\"{x:453,y:722,t:1528143664180};\\\", \\\"{x:455,y:722,t:1528143664311};\\\", \\\"{x:457,y:722,t:1528143664318};\\\", \\\"{x:459,y:722,t:1528143664331};\\\", \\\"{x:467,y:727,t:1528143664346};\\\", \\\"{x:478,y:735,t:1528143664364};\\\", \\\"{x:484,y:741,t:1528143664381};\\\", \\\"{x:493,y:750,t:1528143664396};\\\", \\\"{x:499,y:755,t:1528143664415};\\\", \\\"{x:501,y:756,t:1528143664430};\\\", \\\"{x:502,y:756,t:1528143664879};\\\", \\\"{x:502,y:754,t:1528143664903};\\\", \\\"{x:502,y:742,t:1528143664913};\\\", \\\"{x:504,y:728,t:1528143664930};\\\", \\\"{x:504,y:727,t:1528143664957};\\\", \\\"{x:505,y:727,t:1528143666005};\\\" ] }, { \\\"rt\\\": 11264, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 765944, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -F -10 AM-F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:723,t:1528143668423};\\\", \\\"{x:571,y:700,t:1528143668434};\\\", \\\"{x:686,y:637,t:1528143668450};\\\", \\\"{x:709,y:620,t:1528143668466};\\\", \\\"{x:730,y:611,t:1528143668484};\\\", \\\"{x:751,y:610,t:1528143668500};\\\", \\\"{x:766,y:610,t:1528143668516};\\\", \\\"{x:802,y:610,t:1528143668533};\\\", \\\"{x:886,y:611,t:1528143668549};\\\", \\\"{x:1009,y:617,t:1528143668567};\\\", \\\"{x:1150,y:617,t:1528143668584};\\\", \\\"{x:1248,y:621,t:1528143668601};\\\", \\\"{x:1356,y:621,t:1528143668616};\\\", \\\"{x:1442,y:621,t:1528143668633};\\\", \\\"{x:1501,y:625,t:1528143668651};\\\", \\\"{x:1538,y:625,t:1528143668667};\\\", \\\"{x:1564,y:626,t:1528143668684};\\\", \\\"{x:1579,y:626,t:1528143668703};\\\", \\\"{x:1587,y:628,t:1528143668718};\\\", \\\"{x:1592,y:628,t:1528143668733};\\\", \\\"{x:1591,y:628,t:1528143668950};\\\", \\\"{x:1591,y:627,t:1528143668968};\\\", \\\"{x:1590,y:627,t:1528143668998};\\\", \\\"{x:1588,y:627,t:1528143669006};\\\", \\\"{x:1585,y:627,t:1528143669018};\\\", \\\"{x:1576,y:627,t:1528143669035};\\\", \\\"{x:1559,y:627,t:1528143669051};\\\", \\\"{x:1537,y:629,t:1528143669067};\\\", \\\"{x:1526,y:630,t:1528143669085};\\\", \\\"{x:1513,y:632,t:1528143669100};\\\", \\\"{x:1481,y:642,t:1528143669117};\\\", \\\"{x:1457,y:647,t:1528143669134};\\\", \\\"{x:1433,y:654,t:1528143669150};\\\", \\\"{x:1415,y:660,t:1528143669169};\\\", \\\"{x:1405,y:662,t:1528143669184};\\\", \\\"{x:1397,y:664,t:1528143669200};\\\", \\\"{x:1393,y:666,t:1528143669217};\\\", \\\"{x:1391,y:667,t:1528143669235};\\\", \\\"{x:1390,y:667,t:1528143669252};\\\", \\\"{x:1389,y:668,t:1528143669268};\\\", \\\"{x:1388,y:670,t:1528143669287};\\\", \\\"{x:1385,y:672,t:1528143669302};\\\", \\\"{x:1381,y:679,t:1528143669318};\\\", \\\"{x:1375,y:687,t:1528143669335};\\\", \\\"{x:1369,y:693,t:1528143669352};\\\", \\\"{x:1367,y:696,t:1528143669369};\\\", \\\"{x:1365,y:698,t:1528143669385};\\\", \\\"{x:1364,y:699,t:1528143669406};\\\", \\\"{x:1364,y:700,t:1528143669447};\\\", \\\"{x:1363,y:700,t:1528143669455};\\\", \\\"{x:1362,y:701,t:1528143669468};\\\", \\\"{x:1361,y:703,t:1528143669485};\\\", \\\"{x:1356,y:705,t:1528143669502};\\\", \\\"{x:1355,y:705,t:1528143669518};\\\", \\\"{x:1354,y:706,t:1528143669535};\\\", \\\"{x:1353,y:703,t:1528143670055};\\\", \\\"{x:1352,y:703,t:1528143670069};\\\", \\\"{x:1351,y:700,t:1528143670087};\\\", \\\"{x:1351,y:698,t:1528143670103};\\\", \\\"{x:1350,y:696,t:1528143670118};\\\", \\\"{x:1350,y:695,t:1528143670135};\\\", \\\"{x:1349,y:694,t:1528143670175};\\\", \\\"{x:1346,y:700,t:1528143671631};\\\", \\\"{x:1344,y:707,t:1528143671639};\\\", \\\"{x:1334,y:722,t:1528143671656};\\\", \\\"{x:1326,y:742,t:1528143671672};\\\", \\\"{x:1317,y:756,t:1528143671688};\\\", \\\"{x:1311,y:766,t:1528143671705};\\\", \\\"{x:1308,y:770,t:1528143671722};\\\", \\\"{x:1305,y:774,t:1528143671738};\\\", \\\"{x:1305,y:775,t:1528143671755};\\\", \\\"{x:1304,y:776,t:1528143671772};\\\", \\\"{x:1302,y:779,t:1528143671788};\\\", \\\"{x:1301,y:782,t:1528143671805};\\\", \\\"{x:1297,y:788,t:1528143671822};\\\", \\\"{x:1294,y:794,t:1528143671838};\\\", \\\"{x:1289,y:804,t:1528143671856};\\\", \\\"{x:1284,y:812,t:1528143671872};\\\", \\\"{x:1282,y:815,t:1528143671888};\\\", \\\"{x:1281,y:816,t:1528143671905};\\\", \\\"{x:1281,y:815,t:1528143671991};\\\", \\\"{x:1281,y:811,t:1528143672005};\\\", \\\"{x:1281,y:776,t:1528143672022};\\\", \\\"{x:1283,y:755,t:1528143672038};\\\", \\\"{x:1287,y:744,t:1528143672055};\\\", \\\"{x:1288,y:736,t:1528143672072};\\\", \\\"{x:1290,y:732,t:1528143672089};\\\", \\\"{x:1290,y:730,t:1528143672105};\\\", \\\"{x:1291,y:727,t:1528143672123};\\\", \\\"{x:1293,y:722,t:1528143672139};\\\", \\\"{x:1296,y:714,t:1528143672156};\\\", \\\"{x:1300,y:704,t:1528143672172};\\\", \\\"{x:1304,y:696,t:1528143672189};\\\", \\\"{x:1307,y:689,t:1528143672206};\\\", \\\"{x:1309,y:683,t:1528143672223};\\\", \\\"{x:1312,y:676,t:1528143672239};\\\", \\\"{x:1313,y:670,t:1528143672256};\\\", \\\"{x:1317,y:664,t:1528143672272};\\\", \\\"{x:1321,y:656,t:1528143672289};\\\", \\\"{x:1324,y:649,t:1528143672307};\\\", \\\"{x:1327,y:644,t:1528143672322};\\\", \\\"{x:1329,y:640,t:1528143672339};\\\", \\\"{x:1331,y:637,t:1528143672356};\\\", \\\"{x:1334,y:631,t:1528143672372};\\\", \\\"{x:1337,y:627,t:1528143672388};\\\", \\\"{x:1341,y:619,t:1528143672406};\\\", \\\"{x:1342,y:618,t:1528143672422};\\\", \\\"{x:1344,y:615,t:1528143672438};\\\", \\\"{x:1347,y:610,t:1528143672456};\\\", \\\"{x:1351,y:606,t:1528143672473};\\\", \\\"{x:1354,y:600,t:1528143672488};\\\", \\\"{x:1359,y:595,t:1528143672506};\\\", \\\"{x:1362,y:592,t:1528143672523};\\\", \\\"{x:1365,y:589,t:1528143672539};\\\", \\\"{x:1366,y:588,t:1528143672555};\\\", \\\"{x:1368,y:586,t:1528143672573};\\\", \\\"{x:1369,y:585,t:1528143672589};\\\", \\\"{x:1370,y:583,t:1528143672606};\\\", \\\"{x:1370,y:582,t:1528143672623};\\\", \\\"{x:1371,y:582,t:1528143672639};\\\", \\\"{x:1373,y:580,t:1528143672656};\\\", \\\"{x:1374,y:580,t:1528143672673};\\\", \\\"{x:1375,y:579,t:1528143672690};\\\", \\\"{x:1374,y:580,t:1528143672806};\\\", \\\"{x:1356,y:585,t:1528143672823};\\\", \\\"{x:1344,y:588,t:1528143672840};\\\", \\\"{x:1323,y:596,t:1528143672856};\\\", \\\"{x:1286,y:606,t:1528143672873};\\\", \\\"{x:1214,y:615,t:1528143672890};\\\", \\\"{x:1139,y:615,t:1528143672907};\\\", \\\"{x:1056,y:615,t:1528143672923};\\\", \\\"{x:926,y:615,t:1528143672941};\\\", \\\"{x:816,y:608,t:1528143672957};\\\", \\\"{x:733,y:599,t:1528143672972};\\\", \\\"{x:658,y:588,t:1528143672989};\\\", \\\"{x:601,y:575,t:1528143673004};\\\", \\\"{x:538,y:571,t:1528143673021};\\\", \\\"{x:509,y:567,t:1528143673036};\\\", \\\"{x:489,y:567,t:1528143673054};\\\", \\\"{x:488,y:567,t:1528143673070};\\\", \\\"{x:487,y:567,t:1528143673093};\\\", \\\"{x:485,y:567,t:1528143673310};\\\", \\\"{x:484,y:568,t:1528143673322};\\\", \\\"{x:480,y:574,t:1528143673338};\\\", \\\"{x:478,y:576,t:1528143673354};\\\", \\\"{x:480,y:576,t:1528143673430};\\\", \\\"{x:486,y:576,t:1528143673437};\\\", \\\"{x:498,y:569,t:1528143673455};\\\", \\\"{x:513,y:562,t:1528143673473};\\\", \\\"{x:528,y:552,t:1528143673489};\\\", \\\"{x:540,y:545,t:1528143673503};\\\", \\\"{x:560,y:540,t:1528143673521};\\\", \\\"{x:589,y:536,t:1528143673536};\\\", \\\"{x:623,y:534,t:1528143673554};\\\", \\\"{x:656,y:530,t:1528143673571};\\\", \\\"{x:709,y:522,t:1528143673586};\\\", \\\"{x:743,y:519,t:1528143673603};\\\", \\\"{x:772,y:516,t:1528143673621};\\\", \\\"{x:807,y:512,t:1528143673638};\\\", \\\"{x:822,y:512,t:1528143673655};\\\", \\\"{x:830,y:512,t:1528143673671};\\\", \\\"{x:833,y:512,t:1528143673688};\\\", \\\"{x:836,y:511,t:1528143673705};\\\", \\\"{x:837,y:511,t:1528143673721};\\\", \\\"{x:840,y:510,t:1528143673738};\\\", \\\"{x:843,y:510,t:1528143673755};\\\", \\\"{x:846,y:510,t:1528143673771};\\\", \\\"{x:848,y:510,t:1528143673788};\\\", \\\"{x:849,y:510,t:1528143673805};\\\", \\\"{x:850,y:511,t:1528143673821};\\\", \\\"{x:852,y:517,t:1528143673838};\\\", \\\"{x:852,y:523,t:1528143673855};\\\", \\\"{x:852,y:529,t:1528143673871};\\\", \\\"{x:852,y:535,t:1528143673887};\\\", \\\"{x:852,y:538,t:1528143673904};\\\", \\\"{x:852,y:542,t:1528143673920};\\\", \\\"{x:850,y:545,t:1528143673938};\\\", \\\"{x:850,y:546,t:1528143674453};\\\", \\\"{x:850,y:551,t:1528143674461};\\\", \\\"{x:850,y:580,t:1528143674474};\\\", \\\"{x:881,y:670,t:1528143674489};\\\", \\\"{x:908,y:733,t:1528143674504};\\\", \\\"{x:934,y:797,t:1528143674521};\\\", \\\"{x:965,y:866,t:1528143674539};\\\", \\\"{x:993,y:924,t:1528143674555};\\\", \\\"{x:1022,y:978,t:1528143674571};\\\", \\\"{x:1041,y:1013,t:1528143674588};\\\", \\\"{x:1063,y:1049,t:1528143674605};\\\", \\\"{x:1093,y:1105,t:1528143674621};\\\", \\\"{x:1109,y:1139,t:1528143674639};\\\", \\\"{x:1122,y:1159,t:1528143674655};\\\", \\\"{x:1131,y:1169,t:1528143674672};\\\", \\\"{x:1133,y:1171,t:1528143674689};\\\", \\\"{x:1135,y:1171,t:1528143674717};\\\", \\\"{x:1136,y:1169,t:1528143674725};\\\", \\\"{x:1137,y:1162,t:1528143674739};\\\", \\\"{x:1143,y:1145,t:1528143674755};\\\", \\\"{x:1151,y:1124,t:1528143674772};\\\", \\\"{x:1156,y:1107,t:1528143674789};\\\", \\\"{x:1164,y:1089,t:1528143674806};\\\", \\\"{x:1167,y:1081,t:1528143674821};\\\", \\\"{x:1168,y:1076,t:1528143674838};\\\", \\\"{x:1171,y:1073,t:1528143674856};\\\", \\\"{x:1173,y:1069,t:1528143674872};\\\", \\\"{x:1175,y:1065,t:1528143674889};\\\", \\\"{x:1179,y:1059,t:1528143674906};\\\", \\\"{x:1183,y:1050,t:1528143674922};\\\", \\\"{x:1188,y:1038,t:1528143674939};\\\", \\\"{x:1193,y:1031,t:1528143674956};\\\", \\\"{x:1195,y:1028,t:1528143674972};\\\", \\\"{x:1196,y:1028,t:1528143674998};\\\", \\\"{x:1196,y:1027,t:1528143675006};\\\", \\\"{x:1197,y:1027,t:1528143675030};\\\", \\\"{x:1198,y:1027,t:1528143675039};\\\", \\\"{x:1200,y:1024,t:1528143675056};\\\", \\\"{x:1203,y:1020,t:1528143675072};\\\", \\\"{x:1207,y:1016,t:1528143675089};\\\", \\\"{x:1209,y:1014,t:1528143675107};\\\", \\\"{x:1213,y:1011,t:1528143675122};\\\", \\\"{x:1214,y:1010,t:1528143675142};\\\", \\\"{x:1214,y:1009,t:1528143675175};\\\", \\\"{x:1214,y:1008,t:1528143675222};\\\", \\\"{x:1215,y:1008,t:1528143675239};\\\", \\\"{x:1216,y:1007,t:1528143675590};\\\", \\\"{x:1216,y:1004,t:1528143675639};\\\", \\\"{x:1218,y:972,t:1528143675657};\\\", \\\"{x:1244,y:917,t:1528143675674};\\\", \\\"{x:1277,y:857,t:1528143675689};\\\", \\\"{x:1305,y:793,t:1528143675707};\\\", \\\"{x:1328,y:741,t:1528143675723};\\\", \\\"{x:1341,y:710,t:1528143675740};\\\", \\\"{x:1348,y:696,t:1528143675757};\\\", \\\"{x:1353,y:684,t:1528143675775};\\\", \\\"{x:1356,y:678,t:1528143675789};\\\", \\\"{x:1358,y:675,t:1528143675806};\\\", \\\"{x:1359,y:671,t:1528143675822};\\\", \\\"{x:1362,y:665,t:1528143675839};\\\", \\\"{x:1366,y:658,t:1528143675855};\\\", \\\"{x:1367,y:654,t:1528143675873};\\\", \\\"{x:1370,y:646,t:1528143675889};\\\", \\\"{x:1371,y:643,t:1528143675906};\\\", \\\"{x:1376,y:637,t:1528143675923};\\\", \\\"{x:1379,y:631,t:1528143675940};\\\", \\\"{x:1380,y:628,t:1528143675956};\\\", \\\"{x:1382,y:626,t:1528143675974};\\\", \\\"{x:1386,y:620,t:1528143675990};\\\", \\\"{x:1388,y:615,t:1528143676006};\\\", \\\"{x:1391,y:610,t:1528143676022};\\\", \\\"{x:1393,y:605,t:1528143676040};\\\", \\\"{x:1396,y:599,t:1528143676056};\\\", \\\"{x:1397,y:596,t:1528143676073};\\\", \\\"{x:1398,y:593,t:1528143676090};\\\", \\\"{x:1401,y:589,t:1528143676106};\\\", \\\"{x:1403,y:584,t:1528143676123};\\\", \\\"{x:1409,y:575,t:1528143676140};\\\", \\\"{x:1414,y:567,t:1528143676156};\\\", \\\"{x:1415,y:564,t:1528143676173};\\\", \\\"{x:1414,y:564,t:1528143676311};\\\", \\\"{x:1409,y:572,t:1528143676325};\\\", \\\"{x:1397,y:598,t:1528143676340};\\\", \\\"{x:1374,y:635,t:1528143676358};\\\", \\\"{x:1327,y:695,t:1528143676373};\\\", \\\"{x:1250,y:769,t:1528143676390};\\\", \\\"{x:1189,y:810,t:1528143676407};\\\", \\\"{x:1148,y:833,t:1528143676423};\\\", \\\"{x:1126,y:841,t:1528143676440};\\\", \\\"{x:1101,y:845,t:1528143676457};\\\", \\\"{x:1058,y:851,t:1528143676474};\\\", \\\"{x:1002,y:852,t:1528143676490};\\\", \\\"{x:910,y:852,t:1528143676508};\\\", \\\"{x:810,y:852,t:1528143676524};\\\", \\\"{x:691,y:852,t:1528143676540};\\\", \\\"{x:580,y:852,t:1528143676557};\\\", \\\"{x:494,y:852,t:1528143676573};\\\", \\\"{x:419,y:849,t:1528143676590};\\\", \\\"{x:390,y:844,t:1528143676607};\\\", \\\"{x:373,y:842,t:1528143676623};\\\", \\\"{x:369,y:840,t:1528143676640};\\\", \\\"{x:367,y:840,t:1528143676703};\\\", \\\"{x:366,y:837,t:1528143676710};\\\", \\\"{x:364,y:831,t:1528143676723};\\\", \\\"{x:360,y:815,t:1528143676741};\\\", \\\"{x:356,y:802,t:1528143676757};\\\", \\\"{x:352,y:790,t:1528143676774};\\\", \\\"{x:349,y:783,t:1528143676790};\\\", \\\"{x:348,y:774,t:1528143676807};\\\", \\\"{x:348,y:762,t:1528143676824};\\\", \\\"{x:349,y:750,t:1528143676841};\\\", \\\"{x:352,y:744,t:1528143676857};\\\", \\\"{x:356,y:739,t:1528143676874};\\\", \\\"{x:360,y:735,t:1528143676890};\\\", \\\"{x:363,y:733,t:1528143676907};\\\", \\\"{x:365,y:731,t:1528143676924};\\\", \\\"{x:371,y:729,t:1528143676940};\\\", \\\"{x:380,y:729,t:1528143676957};\\\", \\\"{x:396,y:729,t:1528143676974};\\\", \\\"{x:402,y:729,t:1528143676990};\\\", \\\"{x:410,y:733,t:1528143677007};\\\", \\\"{x:416,y:733,t:1528143677024};\\\", \\\"{x:422,y:733,t:1528143677040};\\\", \\\"{x:430,y:733,t:1528143677057};\\\", \\\"{x:444,y:733,t:1528143677074};\\\", \\\"{x:462,y:725,t:1528143677090};\\\", \\\"{x:470,y:721,t:1528143677106};\\\", \\\"{x:473,y:720,t:1528143677124};\\\", \\\"{x:474,y:719,t:1528143677141};\\\", \\\"{x:476,y:719,t:1528143677503};\\\", \\\"{x:480,y:719,t:1528143677694};\\\", \\\"{x:481,y:719,t:1528143677708};\\\", \\\"{x:482,y:720,t:1528143677725};\\\", \\\"{x:483,y:720,t:1528143677741};\\\", \\\"{x:483,y:721,t:1528143677782};\\\", \\\"{x:485,y:721,t:1528143678534};\\\", \\\"{x:485,y:722,t:1528143678542};\\\" ] }, { \\\"rt\\\": 21214, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 788388, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -06 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:721,t:1528143679749};\\\", \\\"{x:484,y:721,t:1528143679766};\\\", \\\"{x:483,y:721,t:1528143679776};\\\", \\\"{x:480,y:719,t:1528143679794};\\\", \\\"{x:479,y:718,t:1528143679810};\\\", \\\"{x:478,y:718,t:1528143679826};\\\", \\\"{x:474,y:717,t:1528143679843};\\\", \\\"{x:472,y:716,t:1528143679860};\\\", \\\"{x:469,y:714,t:1528143679876};\\\", \\\"{x:467,y:713,t:1528143679893};\\\", \\\"{x:464,y:712,t:1528143679909};\\\", \\\"{x:462,y:711,t:1528143679942};\\\", \\\"{x:460,y:710,t:1528143679958};\\\", \\\"{x:455,y:709,t:1528143680004};\\\", \\\"{x:453,y:708,t:1528143680010};\\\", \\\"{x:450,y:707,t:1528143680026};\\\", \\\"{x:448,y:707,t:1528143680043};\\\", \\\"{x:444,y:707,t:1528143680059};\\\", \\\"{x:440,y:707,t:1528143680076};\\\", \\\"{x:429,y:707,t:1528143680093};\\\", \\\"{x:418,y:707,t:1528143680109};\\\", \\\"{x:405,y:707,t:1528143680125};\\\", \\\"{x:394,y:707,t:1528143680143};\\\", \\\"{x:382,y:707,t:1528143680159};\\\", \\\"{x:375,y:707,t:1528143680176};\\\", \\\"{x:369,y:707,t:1528143680193};\\\", \\\"{x:365,y:707,t:1528143680210};\\\", \\\"{x:364,y:707,t:1528143680226};\\\", \\\"{x:363,y:707,t:1528143680243};\\\", \\\"{x:362,y:707,t:1528143680260};\\\", \\\"{x:361,y:707,t:1528143680276};\\\", \\\"{x:359,y:707,t:1528143680293};\\\", \\\"{x:356,y:707,t:1528143680310};\\\", \\\"{x:355,y:707,t:1528143680327};\\\", \\\"{x:361,y:707,t:1528143681902};\\\", \\\"{x:375,y:707,t:1528143681911};\\\", \\\"{x:441,y:714,t:1528143681929};\\\", \\\"{x:571,y:716,t:1528143681945};\\\", \\\"{x:710,y:716,t:1528143681961};\\\", \\\"{x:851,y:716,t:1528143681978};\\\", \\\"{x:981,y:716,t:1528143681994};\\\", \\\"{x:1125,y:716,t:1528143682011};\\\", \\\"{x:1260,y:716,t:1528143682029};\\\", \\\"{x:1401,y:716,t:1528143682045};\\\", \\\"{x:1521,y:716,t:1528143682061};\\\", \\\"{x:1637,y:716,t:1528143682079};\\\", \\\"{x:1679,y:716,t:1528143682095};\\\", \\\"{x:1714,y:716,t:1528143682112};\\\", \\\"{x:1737,y:710,t:1528143682128};\\\", \\\"{x:1762,y:702,t:1528143682145};\\\", \\\"{x:1773,y:697,t:1528143682161};\\\", \\\"{x:1781,y:693,t:1528143682179};\\\", \\\"{x:1781,y:692,t:1528143682214};\\\", \\\"{x:1781,y:691,t:1528143682238};\\\", \\\"{x:1778,y:688,t:1528143682246};\\\", \\\"{x:1773,y:685,t:1528143682262};\\\", \\\"{x:1743,y:673,t:1528143682279};\\\", \\\"{x:1721,y:669,t:1528143682295};\\\", \\\"{x:1691,y:669,t:1528143682311};\\\", \\\"{x:1670,y:676,t:1528143682329};\\\", \\\"{x:1656,y:682,t:1528143682345};\\\", \\\"{x:1646,y:690,t:1528143682362};\\\", \\\"{x:1642,y:695,t:1528143682379};\\\", \\\"{x:1640,y:698,t:1528143682396};\\\", \\\"{x:1638,y:701,t:1528143682412};\\\", \\\"{x:1638,y:703,t:1528143682429};\\\", \\\"{x:1637,y:706,t:1528143682446};\\\", \\\"{x:1637,y:710,t:1528143682462};\\\", \\\"{x:1637,y:714,t:1528143682478};\\\", \\\"{x:1637,y:720,t:1528143682496};\\\", \\\"{x:1637,y:724,t:1528143682513};\\\", \\\"{x:1637,y:725,t:1528143682528};\\\", \\\"{x:1634,y:727,t:1528143682545};\\\", \\\"{x:1632,y:727,t:1528143682563};\\\", \\\"{x:1630,y:727,t:1528143682579};\\\", \\\"{x:1629,y:727,t:1528143682596};\\\", \\\"{x:1628,y:727,t:1528143682614};\\\", \\\"{x:1627,y:727,t:1528143682719};\\\", \\\"{x:1626,y:727,t:1528143682729};\\\", \\\"{x:1625,y:727,t:1528143682745};\\\", \\\"{x:1624,y:725,t:1528143682763};\\\", \\\"{x:1613,y:715,t:1528143682778};\\\", \\\"{x:1603,y:702,t:1528143682795};\\\", \\\"{x:1595,y:692,t:1528143682813};\\\", \\\"{x:1588,y:677,t:1528143682829};\\\", \\\"{x:1579,y:661,t:1528143682846};\\\", \\\"{x:1566,y:648,t:1528143682862};\\\", \\\"{x:1561,y:644,t:1528143682879};\\\", \\\"{x:1555,y:638,t:1528143682895};\\\", \\\"{x:1555,y:637,t:1528143682913};\\\", \\\"{x:1553,y:634,t:1528143682929};\\\", \\\"{x:1551,y:633,t:1528143682946};\\\", \\\"{x:1551,y:631,t:1528143682962};\\\", \\\"{x:1551,y:627,t:1528143682979};\\\", \\\"{x:1550,y:623,t:1528143682995};\\\", \\\"{x:1549,y:620,t:1528143683012};\\\", \\\"{x:1549,y:616,t:1528143683029};\\\", \\\"{x:1549,y:615,t:1528143683045};\\\", \\\"{x:1548,y:609,t:1528143683062};\\\", \\\"{x:1548,y:603,t:1528143683079};\\\", \\\"{x:1547,y:598,t:1528143683096};\\\", \\\"{x:1546,y:596,t:1528143683112};\\\", \\\"{x:1546,y:595,t:1528143683157};\\\", \\\"{x:1545,y:594,t:1528143683199};\\\", \\\"{x:1545,y:595,t:1528143683519};\\\", \\\"{x:1545,y:597,t:1528143683542};\\\", \\\"{x:1545,y:599,t:1528143683550};\\\", \\\"{x:1546,y:599,t:1528143683562};\\\", \\\"{x:1546,y:601,t:1528143683579};\\\", \\\"{x:1546,y:602,t:1528143683597};\\\", \\\"{x:1547,y:604,t:1528143683613};\\\", \\\"{x:1548,y:606,t:1528143683630};\\\", \\\"{x:1549,y:608,t:1528143683646};\\\", \\\"{x:1550,y:609,t:1528143683663};\\\", \\\"{x:1551,y:610,t:1528143683680};\\\", \\\"{x:1552,y:612,t:1528143683697};\\\", \\\"{x:1553,y:614,t:1528143683713};\\\", \\\"{x:1555,y:616,t:1528143683730};\\\", \\\"{x:1556,y:617,t:1528143683747};\\\", \\\"{x:1559,y:621,t:1528143683762};\\\", \\\"{x:1560,y:624,t:1528143683779};\\\", \\\"{x:1561,y:627,t:1528143683796};\\\", \\\"{x:1563,y:630,t:1528143683813};\\\", \\\"{x:1566,y:634,t:1528143683829};\\\", \\\"{x:1569,y:640,t:1528143683846};\\\", \\\"{x:1570,y:643,t:1528143683863};\\\", \\\"{x:1571,y:645,t:1528143683879};\\\", \\\"{x:1574,y:647,t:1528143683896};\\\", \\\"{x:1577,y:651,t:1528143683914};\\\", \\\"{x:1578,y:653,t:1528143683930};\\\", \\\"{x:1580,y:655,t:1528143683947};\\\", \\\"{x:1582,y:658,t:1528143683964};\\\", \\\"{x:1584,y:661,t:1528143683980};\\\", \\\"{x:1585,y:662,t:1528143683997};\\\", \\\"{x:1587,y:664,t:1528143684014};\\\", \\\"{x:1588,y:665,t:1528143684030};\\\", \\\"{x:1590,y:667,t:1528143684047};\\\", \\\"{x:1590,y:668,t:1528143684070};\\\", \\\"{x:1591,y:669,t:1528143684086};\\\", \\\"{x:1592,y:670,t:1528143684096};\\\", \\\"{x:1593,y:671,t:1528143684114};\\\", \\\"{x:1594,y:672,t:1528143684130};\\\", \\\"{x:1596,y:675,t:1528143684147};\\\", \\\"{x:1597,y:676,t:1528143684164};\\\", \\\"{x:1599,y:678,t:1528143684180};\\\", \\\"{x:1603,y:682,t:1528143684197};\\\", \\\"{x:1609,y:690,t:1528143684214};\\\", \\\"{x:1612,y:694,t:1528143684233};\\\", \\\"{x:1615,y:700,t:1528143684246};\\\", \\\"{x:1620,y:707,t:1528143684263};\\\", \\\"{x:1625,y:713,t:1528143684280};\\\", \\\"{x:1628,y:718,t:1528143684296};\\\", \\\"{x:1629,y:719,t:1528143684313};\\\", \\\"{x:1631,y:722,t:1528143684330};\\\", \\\"{x:1631,y:723,t:1528143684346};\\\", \\\"{x:1632,y:724,t:1528143684363};\\\", \\\"{x:1632,y:725,t:1528143684380};\\\", \\\"{x:1633,y:727,t:1528143684396};\\\", \\\"{x:1635,y:732,t:1528143684414};\\\", \\\"{x:1636,y:735,t:1528143684430};\\\", \\\"{x:1636,y:737,t:1528143684446};\\\", \\\"{x:1636,y:741,t:1528143684464};\\\", \\\"{x:1636,y:744,t:1528143684480};\\\", \\\"{x:1636,y:750,t:1528143684496};\\\", \\\"{x:1639,y:755,t:1528143684514};\\\", \\\"{x:1639,y:761,t:1528143684531};\\\", \\\"{x:1639,y:765,t:1528143684546};\\\", \\\"{x:1640,y:771,t:1528143684564};\\\", \\\"{x:1642,y:776,t:1528143684581};\\\", \\\"{x:1643,y:780,t:1528143684596};\\\", \\\"{x:1643,y:781,t:1528143684613};\\\", \\\"{x:1644,y:783,t:1528143684630};\\\", \\\"{x:1645,y:785,t:1528143684654};\\\", \\\"{x:1648,y:788,t:1528143684663};\\\", \\\"{x:1659,y:806,t:1528143684681};\\\", \\\"{x:1659,y:804,t:1528143685583};\\\", \\\"{x:1661,y:785,t:1528143685598};\\\", \\\"{x:1661,y:766,t:1528143685614};\\\", \\\"{x:1661,y:744,t:1528143685632};\\\", \\\"{x:1660,y:725,t:1528143685648};\\\", \\\"{x:1656,y:713,t:1528143685665};\\\", \\\"{x:1655,y:708,t:1528143685681};\\\", \\\"{x:1654,y:707,t:1528143685698};\\\", \\\"{x:1654,y:706,t:1528143685715};\\\", \\\"{x:1654,y:705,t:1528143685732};\\\", \\\"{x:1654,y:704,t:1528143685747};\\\", \\\"{x:1653,y:703,t:1528143685765};\\\", \\\"{x:1651,y:698,t:1528143685782};\\\", \\\"{x:1649,y:695,t:1528143685798};\\\", \\\"{x:1647,y:694,t:1528143685815};\\\", \\\"{x:1646,y:693,t:1528143685832};\\\", \\\"{x:1645,y:691,t:1528143685848};\\\", \\\"{x:1644,y:690,t:1528143685864};\\\", \\\"{x:1642,y:688,t:1528143685882};\\\", \\\"{x:1641,y:688,t:1528143685983};\\\", \\\"{x:1638,y:688,t:1528143686030};\\\", \\\"{x:1634,y:688,t:1528143686048};\\\", \\\"{x:1631,y:691,t:1528143686065};\\\", \\\"{x:1630,y:692,t:1528143686081};\\\", \\\"{x:1629,y:694,t:1528143686099};\\\", \\\"{x:1628,y:694,t:1528143686115};\\\", \\\"{x:1628,y:695,t:1528143686132};\\\", \\\"{x:1627,y:695,t:1528143687111};\\\", \\\"{x:1625,y:695,t:1528143687215};\\\", \\\"{x:1622,y:691,t:1528143687233};\\\", \\\"{x:1620,y:688,t:1528143687249};\\\", \\\"{x:1617,y:684,t:1528143687266};\\\", \\\"{x:1615,y:682,t:1528143687282};\\\", \\\"{x:1614,y:681,t:1528143687298};\\\", \\\"{x:1614,y:680,t:1528143687430};\\\", \\\"{x:1614,y:681,t:1528143688254};\\\", \\\"{x:1616,y:690,t:1528143688267};\\\", \\\"{x:1618,y:704,t:1528143688284};\\\", \\\"{x:1622,y:719,t:1528143688300};\\\", \\\"{x:1626,y:735,t:1528143688317};\\\", \\\"{x:1631,y:760,t:1528143688334};\\\", \\\"{x:1636,y:777,t:1528143688350};\\\", \\\"{x:1642,y:795,t:1528143688367};\\\", \\\"{x:1649,y:812,t:1528143688384};\\\", \\\"{x:1653,y:826,t:1528143688400};\\\", \\\"{x:1658,y:842,t:1528143688416};\\\", \\\"{x:1664,y:855,t:1528143688434};\\\", \\\"{x:1669,y:869,t:1528143688450};\\\", \\\"{x:1675,y:882,t:1528143688466};\\\", \\\"{x:1683,y:899,t:1528143688484};\\\", \\\"{x:1688,y:910,t:1528143688501};\\\", \\\"{x:1694,y:922,t:1528143688517};\\\", \\\"{x:1699,y:931,t:1528143688535};\\\", \\\"{x:1703,y:937,t:1528143688550};\\\", \\\"{x:1705,y:939,t:1528143688567};\\\", \\\"{x:1706,y:943,t:1528143688584};\\\", \\\"{x:1709,y:947,t:1528143688600};\\\", \\\"{x:1712,y:951,t:1528143688617};\\\", \\\"{x:1714,y:954,t:1528143688634};\\\", \\\"{x:1715,y:956,t:1528143688650};\\\", \\\"{x:1717,y:958,t:1528143688667};\\\", \\\"{x:1719,y:960,t:1528143688683};\\\", \\\"{x:1719,y:962,t:1528143688701};\\\", \\\"{x:1720,y:962,t:1528143688718};\\\", \\\"{x:1721,y:963,t:1528143688734};\\\", \\\"{x:1723,y:963,t:1528143688758};\\\", \\\"{x:1723,y:964,t:1528143688798};\\\", \\\"{x:1724,y:964,t:1528143688814};\\\", \\\"{x:1726,y:965,t:1528143688831};\\\", \\\"{x:1727,y:965,t:1528143688871};\\\", \\\"{x:1727,y:966,t:1528143688884};\\\", \\\"{x:1728,y:966,t:1528143688901};\\\", \\\"{x:1729,y:966,t:1528143688918};\\\", \\\"{x:1730,y:966,t:1528143689053};\\\", \\\"{x:1731,y:966,t:1528143689066};\\\", \\\"{x:1732,y:967,t:1528143689083};\\\", \\\"{x:1733,y:967,t:1528143689622};\\\", \\\"{x:1734,y:967,t:1528143689718};\\\", \\\"{x:1735,y:967,t:1528143689735};\\\", \\\"{x:1737,y:966,t:1528143689751};\\\", \\\"{x:1739,y:965,t:1528143689768};\\\", \\\"{x:1741,y:963,t:1528143689785};\\\", \\\"{x:1742,y:962,t:1528143689802};\\\", \\\"{x:1743,y:960,t:1528143689822};\\\", \\\"{x:1744,y:959,t:1528143689835};\\\", \\\"{x:1745,y:957,t:1528143689854};\\\", \\\"{x:1745,y:956,t:1528143689868};\\\", \\\"{x:1747,y:954,t:1528143689885};\\\", \\\"{x:1748,y:953,t:1528143689901};\\\", \\\"{x:1749,y:952,t:1528143689918};\\\", \\\"{x:1749,y:951,t:1528143689935};\\\", \\\"{x:1749,y:950,t:1528143689959};\\\", \\\"{x:1750,y:949,t:1528143689982};\\\", \\\"{x:1749,y:949,t:1528143690198};\\\", \\\"{x:1748,y:949,t:1528143690223};\\\", \\\"{x:1747,y:949,t:1528143690239};\\\", \\\"{x:1747,y:950,t:1528143690252};\\\", \\\"{x:1746,y:950,t:1528143690319};\\\", \\\"{x:1746,y:951,t:1528143690397};\\\", \\\"{x:1745,y:951,t:1528143690405};\\\", \\\"{x:1745,y:952,t:1528143690429};\\\", \\\"{x:1745,y:953,t:1528143690437};\\\", \\\"{x:1745,y:954,t:1528143690453};\\\", \\\"{x:1745,y:955,t:1528143690470};\\\", \\\"{x:1745,y:956,t:1528143690484};\\\", \\\"{x:1745,y:957,t:1528143690502};\\\", \\\"{x:1745,y:959,t:1528143690518};\\\", \\\"{x:1745,y:961,t:1528143690535};\\\", \\\"{x:1745,y:962,t:1528143690551};\\\", \\\"{x:1745,y:964,t:1528143690569};\\\", \\\"{x:1745,y:965,t:1528143690585};\\\", \\\"{x:1745,y:966,t:1528143690605};\\\", \\\"{x:1745,y:967,t:1528143690845};\\\", \\\"{x:1745,y:968,t:1528143690853};\\\", \\\"{x:1746,y:968,t:1528143690910};\\\", \\\"{x:1746,y:969,t:1528143691423};\\\", \\\"{x:1747,y:969,t:1528143691511};\\\", \\\"{x:1748,y:969,t:1528143692047};\\\", \\\"{x:1749,y:969,t:1528143692078};\\\", \\\"{x:1750,y:968,t:1528143692086};\\\", \\\"{x:1751,y:967,t:1528143692103};\\\", \\\"{x:1753,y:967,t:1528143692182};\\\", \\\"{x:1754,y:966,t:1528143692198};\\\", \\\"{x:1755,y:965,t:1528143692222};\\\", \\\"{x:1755,y:964,t:1528143692237};\\\", \\\"{x:1756,y:962,t:1528143692254};\\\", \\\"{x:1758,y:958,t:1528143692270};\\\", \\\"{x:1760,y:955,t:1528143692287};\\\", \\\"{x:1762,y:952,t:1528143692303};\\\", \\\"{x:1764,y:949,t:1528143692320};\\\", \\\"{x:1765,y:946,t:1528143692337};\\\", \\\"{x:1767,y:943,t:1528143692353};\\\", \\\"{x:1768,y:941,t:1528143692370};\\\", \\\"{x:1772,y:937,t:1528143692387};\\\", \\\"{x:1775,y:931,t:1528143692403};\\\", \\\"{x:1778,y:925,t:1528143692420};\\\", \\\"{x:1781,y:920,t:1528143692438};\\\", \\\"{x:1783,y:918,t:1528143692454};\\\", \\\"{x:1786,y:911,t:1528143692473};\\\", \\\"{x:1788,y:906,t:1528143692491};\\\", \\\"{x:1790,y:904,t:1528143692506};\\\", \\\"{x:1792,y:900,t:1528143692523};\\\", \\\"{x:1797,y:890,t:1528143692540};\\\", \\\"{x:1802,y:884,t:1528143692557};\\\", \\\"{x:1808,y:875,t:1528143692573};\\\", \\\"{x:1812,y:871,t:1528143692590};\\\", \\\"{x:1819,y:863,t:1528143692606};\\\", \\\"{x:1822,y:859,t:1528143692624};\\\", \\\"{x:1825,y:854,t:1528143692640};\\\", \\\"{x:1828,y:850,t:1528143692657};\\\", \\\"{x:1832,y:844,t:1528143692674};\\\", \\\"{x:1835,y:839,t:1528143692691};\\\", \\\"{x:1837,y:836,t:1528143692707};\\\", \\\"{x:1840,y:832,t:1528143692724};\\\", \\\"{x:1841,y:831,t:1528143692826};\\\", \\\"{x:1840,y:831,t:1528143693010};\\\", \\\"{x:1839,y:831,t:1528143693025};\\\", \\\"{x:1837,y:831,t:1528143693040};\\\", \\\"{x:1836,y:831,t:1528143693058};\\\", \\\"{x:1834,y:831,t:1528143693073};\\\", \\\"{x:1833,y:831,t:1528143693097};\\\", \\\"{x:1832,y:832,t:1528143693107};\\\", \\\"{x:1830,y:833,t:1528143693129};\\\", \\\"{x:1829,y:834,t:1528143693153};\\\", \\\"{x:1828,y:834,t:1528143693170};\\\", \\\"{x:1827,y:836,t:1528143693177};\\\", \\\"{x:1827,y:838,t:1528143693193};\\\", \\\"{x:1826,y:838,t:1528143693207};\\\", \\\"{x:1825,y:840,t:1528143693224};\\\", \\\"{x:1824,y:842,t:1528143693241};\\\", \\\"{x:1824,y:843,t:1528143693257};\\\", \\\"{x:1824,y:845,t:1528143693274};\\\", \\\"{x:1823,y:846,t:1528143693290};\\\", \\\"{x:1822,y:848,t:1528143693306};\\\", \\\"{x:1821,y:850,t:1528143693323};\\\", \\\"{x:1820,y:854,t:1528143693339};\\\", \\\"{x:1818,y:856,t:1528143693361};\\\", \\\"{x:1817,y:856,t:1528143693554};\\\", \\\"{x:1817,y:857,t:1528143693561};\\\", \\\"{x:1816,y:857,t:1528143693577};\\\", \\\"{x:1815,y:858,t:1528143693591};\\\", \\\"{x:1814,y:859,t:1528143693608};\\\", \\\"{x:1812,y:860,t:1528143693625};\\\", \\\"{x:1811,y:861,t:1528143693658};\\\", \\\"{x:1810,y:861,t:1528143693697};\\\", \\\"{x:1808,y:862,t:1528143693714};\\\", \\\"{x:1807,y:862,t:1528143693809};\\\", \\\"{x:1806,y:862,t:1528143693841};\\\", \\\"{x:1805,y:862,t:1528143693865};\\\", \\\"{x:1805,y:863,t:1528143693897};\\\", \\\"{x:1804,y:863,t:1528143693946};\\\", \\\"{x:1803,y:863,t:1528143694538};\\\", \\\"{x:1802,y:863,t:1528143694769};\\\", \\\"{x:1801,y:863,t:1528143694810};\\\", \\\"{x:1800,y:863,t:1528143694825};\\\", \\\"{x:1799,y:863,t:1528143694866};\\\", \\\"{x:1797,y:863,t:1528143694875};\\\", \\\"{x:1792,y:863,t:1528143694892};\\\", \\\"{x:1779,y:863,t:1528143694908};\\\", \\\"{x:1755,y:863,t:1528143694925};\\\", \\\"{x:1725,y:860,t:1528143694943};\\\", \\\"{x:1694,y:856,t:1528143694959};\\\", \\\"{x:1659,y:849,t:1528143694976};\\\", \\\"{x:1627,y:839,t:1528143694993};\\\", \\\"{x:1604,y:829,t:1528143695009};\\\", \\\"{x:1571,y:812,t:1528143695025};\\\", \\\"{x:1556,y:799,t:1528143695043};\\\", \\\"{x:1545,y:783,t:1528143695058};\\\", \\\"{x:1538,y:768,t:1528143695075};\\\", \\\"{x:1533,y:744,t:1528143695092};\\\", \\\"{x:1528,y:714,t:1528143695108};\\\", \\\"{x:1527,y:695,t:1528143695126};\\\", \\\"{x:1527,y:684,t:1528143695143};\\\", \\\"{x:1528,y:680,t:1528143695159};\\\", \\\"{x:1530,y:678,t:1528143695177};\\\", \\\"{x:1531,y:678,t:1528143695192};\\\", \\\"{x:1533,y:678,t:1528143695216};\\\", \\\"{x:1534,y:678,t:1528143695280};\\\", \\\"{x:1536,y:678,t:1528143695296};\\\", \\\"{x:1537,y:678,t:1528143695313};\\\", \\\"{x:1539,y:677,t:1528143695329};\\\", \\\"{x:1540,y:677,t:1528143695344};\\\", \\\"{x:1541,y:677,t:1528143695377};\\\", \\\"{x:1542,y:677,t:1528143695392};\\\", \\\"{x:1545,y:677,t:1528143695409};\\\", \\\"{x:1548,y:678,t:1528143695426};\\\", \\\"{x:1550,y:680,t:1528143695442};\\\", \\\"{x:1558,y:687,t:1528143695459};\\\", \\\"{x:1567,y:695,t:1528143695475};\\\", \\\"{x:1570,y:698,t:1528143695491};\\\", \\\"{x:1575,y:702,t:1528143695509};\\\", \\\"{x:1580,y:707,t:1528143695524};\\\", \\\"{x:1584,y:711,t:1528143695541};\\\", \\\"{x:1586,y:713,t:1528143695559};\\\", \\\"{x:1589,y:717,t:1528143695575};\\\", \\\"{x:1591,y:719,t:1528143695592};\\\", \\\"{x:1593,y:722,t:1528143695609};\\\", \\\"{x:1594,y:724,t:1528143695625};\\\", \\\"{x:1594,y:725,t:1528143695642};\\\", \\\"{x:1595,y:727,t:1528143695659};\\\", \\\"{x:1596,y:729,t:1528143695675};\\\", \\\"{x:1596,y:733,t:1528143695693};\\\", \\\"{x:1596,y:736,t:1528143695709};\\\", \\\"{x:1596,y:739,t:1528143695726};\\\", \\\"{x:1596,y:740,t:1528143695743};\\\", \\\"{x:1596,y:741,t:1528143695759};\\\", \\\"{x:1596,y:742,t:1528143695896};\\\", \\\"{x:1596,y:743,t:1528143695909};\\\", \\\"{x:1594,y:751,t:1528143695926};\\\", \\\"{x:1593,y:758,t:1528143695942};\\\", \\\"{x:1590,y:763,t:1528143695959};\\\", \\\"{x:1589,y:770,t:1528143695976};\\\", \\\"{x:1586,y:775,t:1528143695992};\\\", \\\"{x:1581,y:785,t:1528143696009};\\\", \\\"{x:1581,y:788,t:1528143696026};\\\", \\\"{x:1578,y:792,t:1528143696042};\\\", \\\"{x:1576,y:799,t:1528143696059};\\\", \\\"{x:1574,y:805,t:1528143696076};\\\", \\\"{x:1574,y:809,t:1528143696092};\\\", \\\"{x:1570,y:815,t:1528143696110};\\\", \\\"{x:1569,y:820,t:1528143696126};\\\", \\\"{x:1568,y:823,t:1528143696142};\\\", \\\"{x:1565,y:827,t:1528143696160};\\\", \\\"{x:1562,y:834,t:1528143696176};\\\", \\\"{x:1560,y:841,t:1528143696193};\\\", \\\"{x:1555,y:853,t:1528143696209};\\\", \\\"{x:1550,y:861,t:1528143696226};\\\", \\\"{x:1545,y:870,t:1528143696242};\\\", \\\"{x:1538,y:879,t:1528143696259};\\\", \\\"{x:1533,y:887,t:1528143696276};\\\", \\\"{x:1528,y:893,t:1528143696293};\\\", \\\"{x:1526,y:897,t:1528143696309};\\\", \\\"{x:1524,y:901,t:1528143696327};\\\", \\\"{x:1523,y:901,t:1528143696343};\\\", \\\"{x:1522,y:903,t:1528143696360};\\\", \\\"{x:1521,y:904,t:1528143696377};\\\", \\\"{x:1520,y:905,t:1528143696393};\\\", \\\"{x:1519,y:907,t:1528143696409};\\\", \\\"{x:1518,y:909,t:1528143696426};\\\", \\\"{x:1516,y:914,t:1528143696443};\\\", \\\"{x:1512,y:920,t:1528143696459};\\\", \\\"{x:1510,y:922,t:1528143696476};\\\", \\\"{x:1508,y:924,t:1528143696493};\\\", \\\"{x:1507,y:927,t:1528143696510};\\\", \\\"{x:1506,y:928,t:1528143696526};\\\", \\\"{x:1505,y:930,t:1528143696543};\\\", \\\"{x:1505,y:931,t:1528143696559};\\\", \\\"{x:1504,y:931,t:1528143696577};\\\", \\\"{x:1503,y:933,t:1528143696609};\\\", \\\"{x:1502,y:933,t:1528143696627};\\\", \\\"{x:1501,y:934,t:1528143696644};\\\", \\\"{x:1501,y:935,t:1528143696659};\\\", \\\"{x:1499,y:936,t:1528143696677};\\\", \\\"{x:1499,y:937,t:1528143696713};\\\", \\\"{x:1499,y:938,t:1528143696729};\\\", \\\"{x:1499,y:940,t:1528143696745};\\\", \\\"{x:1498,y:941,t:1528143696762};\\\", \\\"{x:1498,y:942,t:1528143696777};\\\", \\\"{x:1497,y:944,t:1528143696801};\\\", \\\"{x:1496,y:944,t:1528143696825};\\\", \\\"{x:1496,y:945,t:1528143696843};\\\", \\\"{x:1495,y:945,t:1528143696866};\\\", \\\"{x:1494,y:945,t:1528143696897};\\\", \\\"{x:1493,y:945,t:1528143696913};\\\", \\\"{x:1492,y:945,t:1528143696937};\\\", \\\"{x:1491,y:945,t:1528143696945};\\\", \\\"{x:1490,y:945,t:1528143696960};\\\", \\\"{x:1483,y:944,t:1528143696976};\\\", \\\"{x:1464,y:939,t:1528143696993};\\\", \\\"{x:1426,y:928,t:1528143697009};\\\", \\\"{x:1373,y:905,t:1528143697026};\\\", \\\"{x:1293,y:868,t:1528143697043};\\\", \\\"{x:1188,y:823,t:1528143697060};\\\", \\\"{x:1079,y:762,t:1528143697076};\\\", \\\"{x:969,y:699,t:1528143697093};\\\", \\\"{x:879,y:649,t:1528143697110};\\\", \\\"{x:806,y:612,t:1528143697127};\\\", \\\"{x:754,y:589,t:1528143697144};\\\", \\\"{x:731,y:577,t:1528143697159};\\\", \\\"{x:715,y:568,t:1528143697177};\\\", \\\"{x:713,y:566,t:1528143697194};\\\", \\\"{x:711,y:565,t:1528143697211};\\\", \\\"{x:710,y:564,t:1528143697227};\\\", \\\"{x:702,y:560,t:1528143697244};\\\", \\\"{x:679,y:553,t:1528143697262};\\\", \\\"{x:648,y:549,t:1528143697277};\\\", \\\"{x:605,y:546,t:1528143697294};\\\", \\\"{x:570,y:546,t:1528143697311};\\\", \\\"{x:555,y:546,t:1528143697327};\\\", \\\"{x:554,y:546,t:1528143697343};\\\", \\\"{x:553,y:546,t:1528143697361};\\\", \\\"{x:551,y:546,t:1528143697561};\\\", \\\"{x:534,y:546,t:1528143697578};\\\", \\\"{x:491,y:550,t:1528143697596};\\\", \\\"{x:446,y:554,t:1528143697611};\\\", \\\"{x:396,y:561,t:1528143697627};\\\", \\\"{x:335,y:570,t:1528143697644};\\\", \\\"{x:293,y:574,t:1528143697661};\\\", \\\"{x:262,y:574,t:1528143697679};\\\", \\\"{x:233,y:574,t:1528143697693};\\\", \\\"{x:212,y:574,t:1528143697711};\\\", \\\"{x:205,y:573,t:1528143697727};\\\", \\\"{x:207,y:570,t:1528143697800};\\\", \\\"{x:215,y:567,t:1528143697811};\\\", \\\"{x:223,y:559,t:1528143697827};\\\", \\\"{x:238,y:549,t:1528143697844};\\\", \\\"{x:258,y:538,t:1528143697861};\\\", \\\"{x:288,y:526,t:1528143697879};\\\", \\\"{x:332,y:515,t:1528143697897};\\\", \\\"{x:373,y:504,t:1528143697911};\\\", \\\"{x:413,y:498,t:1528143697928};\\\", \\\"{x:461,y:495,t:1528143697944};\\\", \\\"{x:481,y:491,t:1528143697960};\\\", \\\"{x:499,y:491,t:1528143697978};\\\", \\\"{x:514,y:491,t:1528143697995};\\\", \\\"{x:524,y:491,t:1528143698011};\\\", \\\"{x:531,y:491,t:1528143698028};\\\", \\\"{x:535,y:491,t:1528143698044};\\\", \\\"{x:538,y:491,t:1528143698061};\\\", \\\"{x:540,y:491,t:1528143698078};\\\", \\\"{x:542,y:492,t:1528143698095};\\\", \\\"{x:545,y:492,t:1528143698111};\\\", \\\"{x:549,y:495,t:1528143698127};\\\", \\\"{x:553,y:496,t:1528143698145};\\\", \\\"{x:556,y:498,t:1528143698161};\\\", \\\"{x:560,y:499,t:1528143698178};\\\", \\\"{x:565,y:500,t:1528143698195};\\\", \\\"{x:572,y:500,t:1528143698211};\\\", \\\"{x:576,y:501,t:1528143698228};\\\", \\\"{x:579,y:502,t:1528143698245};\\\", \\\"{x:581,y:502,t:1528143698261};\\\", \\\"{x:582,y:502,t:1528143698278};\\\", \\\"{x:584,y:502,t:1528143698295};\\\", \\\"{x:588,y:502,t:1528143698311};\\\", \\\"{x:592,y:502,t:1528143698329};\\\", \\\"{x:598,y:502,t:1528143698345};\\\", \\\"{x:599,y:502,t:1528143698361};\\\", \\\"{x:601,y:502,t:1528143698386};\\\", \\\"{x:602,y:502,t:1528143698649};\\\", \\\"{x:619,y:501,t:1528143698662};\\\", \\\"{x:668,y:496,t:1528143698678};\\\", \\\"{x:713,y:496,t:1528143698695};\\\", \\\"{x:743,y:496,t:1528143698712};\\\", \\\"{x:772,y:496,t:1528143698728};\\\", \\\"{x:821,y:496,t:1528143698745};\\\", \\\"{x:846,y:496,t:1528143698762};\\\", \\\"{x:863,y:496,t:1528143698778};\\\", \\\"{x:872,y:495,t:1528143698795};\\\", \\\"{x:874,y:495,t:1528143698811};\\\", \\\"{x:873,y:494,t:1528143699001};\\\", \\\"{x:867,y:493,t:1528143699013};\\\", \\\"{x:861,y:492,t:1528143699028};\\\", \\\"{x:855,y:492,t:1528143699045};\\\", \\\"{x:851,y:492,t:1528143699061};\\\", \\\"{x:845,y:492,t:1528143699079};\\\", \\\"{x:844,y:492,t:1528143699094};\\\", \\\"{x:842,y:492,t:1528143699111};\\\", \\\"{x:840,y:492,t:1528143699129};\\\", \\\"{x:839,y:492,t:1528143699153};\\\", \\\"{x:838,y:492,t:1528143699162};\\\", \\\"{x:836,y:492,t:1528143699179};\\\", \\\"{x:835,y:492,t:1528143699195};\\\", \\\"{x:834,y:492,t:1528143699212};\\\", \\\"{x:833,y:493,t:1528143699225};\\\", \\\"{x:831,y:495,t:1528143699649};\\\", \\\"{x:830,y:502,t:1528143699663};\\\", \\\"{x:826,y:521,t:1528143699681};\\\", \\\"{x:820,y:541,t:1528143699696};\\\", \\\"{x:813,y:557,t:1528143699712};\\\", \\\"{x:798,y:582,t:1528143699729};\\\", \\\"{x:785,y:602,t:1528143699747};\\\", \\\"{x:768,y:621,t:1528143699763};\\\", \\\"{x:751,y:643,t:1528143699779};\\\", \\\"{x:733,y:660,t:1528143699796};\\\", \\\"{x:717,y:673,t:1528143699813};\\\", \\\"{x:696,y:685,t:1528143699829};\\\", \\\"{x:676,y:695,t:1528143699846};\\\", \\\"{x:658,y:705,t:1528143699863};\\\", \\\"{x:643,y:712,t:1528143699879};\\\", \\\"{x:636,y:718,t:1528143699896};\\\", \\\"{x:633,y:719,t:1528143699912};\\\", \\\"{x:630,y:720,t:1528143699930};\\\", \\\"{x:625,y:722,t:1528143699946};\\\", \\\"{x:620,y:723,t:1528143699963};\\\", \\\"{x:617,y:724,t:1528143699980};\\\", \\\"{x:606,y:728,t:1528143699996};\\\", \\\"{x:592,y:733,t:1528143700013};\\\", \\\"{x:573,y:740,t:1528143700030};\\\", \\\"{x:555,y:745,t:1528143700046};\\\", \\\"{x:543,y:749,t:1528143700063};\\\", \\\"{x:538,y:751,t:1528143700079};\\\", \\\"{x:535,y:752,t:1528143700096};\\\", \\\"{x:534,y:752,t:1528143700121};\\\", \\\"{x:533,y:752,t:1528143700129};\\\", \\\"{x:532,y:752,t:1528143700146};\\\", \\\"{x:531,y:752,t:1528143700163};\\\", \\\"{x:529,y:752,t:1528143700179};\\\", \\\"{x:528,y:752,t:1528143700209};\\\", \\\"{x:527,y:753,t:1528143700263};\\\", \\\"{x:527,y:753,t:1528143700357};\\\" ] }, { \\\"rt\\\": 11443, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 801078, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:752,t:1528143701872};\\\", \\\"{x:528,y:751,t:1528143702480};\\\", \\\"{x:536,y:745,t:1528143702488};\\\", \\\"{x:547,y:738,t:1528143702499};\\\", \\\"{x:564,y:730,t:1528143702516};\\\", \\\"{x:579,y:725,t:1528143702534};\\\", \\\"{x:600,y:718,t:1528143702549};\\\", \\\"{x:628,y:714,t:1528143702565};\\\", \\\"{x:654,y:710,t:1528143702581};\\\", \\\"{x:695,y:709,t:1528143702598};\\\", \\\"{x:746,y:709,t:1528143702616};\\\", \\\"{x:810,y:709,t:1528143702631};\\\", \\\"{x:885,y:709,t:1528143702648};\\\", \\\"{x:924,y:709,t:1528143702665};\\\", \\\"{x:958,y:709,t:1528143702681};\\\", \\\"{x:987,y:709,t:1528143702698};\\\", \\\"{x:1007,y:709,t:1528143702715};\\\", \\\"{x:1024,y:707,t:1528143702732};\\\", \\\"{x:1034,y:705,t:1528143702748};\\\", \\\"{x:1041,y:704,t:1528143702765};\\\", \\\"{x:1045,y:703,t:1528143702782};\\\", \\\"{x:1049,y:703,t:1528143702798};\\\", \\\"{x:1054,y:700,t:1528143702816};\\\", \\\"{x:1065,y:699,t:1528143702833};\\\", \\\"{x:1068,y:697,t:1528143702849};\\\", \\\"{x:1081,y:695,t:1528143702866};\\\", \\\"{x:1087,y:694,t:1528143702883};\\\", \\\"{x:1093,y:693,t:1528143702898};\\\", \\\"{x:1099,y:693,t:1528143702916};\\\", \\\"{x:1107,y:693,t:1528143702933};\\\", \\\"{x:1117,y:696,t:1528143702949};\\\", \\\"{x:1131,y:699,t:1528143702967};\\\", \\\"{x:1144,y:707,t:1528143702983};\\\", \\\"{x:1158,y:715,t:1528143702998};\\\", \\\"{x:1170,y:722,t:1528143703016};\\\", \\\"{x:1180,y:730,t:1528143703034};\\\", \\\"{x:1185,y:736,t:1528143703049};\\\", \\\"{x:1187,y:741,t:1528143703066};\\\", \\\"{x:1190,y:744,t:1528143703083};\\\", \\\"{x:1192,y:748,t:1528143703099};\\\", \\\"{x:1193,y:752,t:1528143703115};\\\", \\\"{x:1194,y:755,t:1528143703133};\\\", \\\"{x:1198,y:762,t:1528143703149};\\\", \\\"{x:1200,y:767,t:1528143703166};\\\", \\\"{x:1202,y:772,t:1528143703183};\\\", \\\"{x:1202,y:773,t:1528143703199};\\\", \\\"{x:1203,y:774,t:1528143703216};\\\", \\\"{x:1201,y:774,t:1528143703466};\\\", \\\"{x:1200,y:774,t:1528143703483};\\\", \\\"{x:1199,y:775,t:1528143703561};\\\", \\\"{x:1199,y:776,t:1528143703577};\\\", \\\"{x:1200,y:778,t:1528143703585};\\\", \\\"{x:1201,y:778,t:1528143703601};\\\", \\\"{x:1202,y:780,t:1528143703616};\\\", \\\"{x:1205,y:783,t:1528143703632};\\\", \\\"{x:1208,y:786,t:1528143703649};\\\", \\\"{x:1209,y:788,t:1528143703666};\\\", \\\"{x:1211,y:791,t:1528143703682};\\\", \\\"{x:1213,y:794,t:1528143703700};\\\", \\\"{x:1215,y:797,t:1528143703717};\\\", \\\"{x:1218,y:803,t:1528143703733};\\\", \\\"{x:1220,y:807,t:1528143703750};\\\", \\\"{x:1222,y:813,t:1528143703767};\\\", \\\"{x:1227,y:821,t:1528143703783};\\\", \\\"{x:1232,y:829,t:1528143703800};\\\", \\\"{x:1241,y:847,t:1528143703818};\\\", \\\"{x:1248,y:858,t:1528143703833};\\\", \\\"{x:1254,y:869,t:1528143703849};\\\", \\\"{x:1258,y:876,t:1528143703867};\\\", \\\"{x:1261,y:880,t:1528143703883};\\\", \\\"{x:1262,y:882,t:1528143703900};\\\", \\\"{x:1264,y:884,t:1528143703917};\\\", \\\"{x:1266,y:886,t:1528143703932};\\\", \\\"{x:1268,y:888,t:1528143703950};\\\", \\\"{x:1270,y:890,t:1528143703967};\\\", \\\"{x:1273,y:891,t:1528143703983};\\\", \\\"{x:1274,y:892,t:1528143704000};\\\", \\\"{x:1279,y:893,t:1528143704017};\\\", \\\"{x:1283,y:896,t:1528143704033};\\\", \\\"{x:1287,y:896,t:1528143704049};\\\", \\\"{x:1296,y:899,t:1528143704067};\\\", \\\"{x:1308,y:902,t:1528143704083};\\\", \\\"{x:1327,y:908,t:1528143704100};\\\", \\\"{x:1348,y:913,t:1528143704117};\\\", \\\"{x:1372,y:921,t:1528143704133};\\\", \\\"{x:1389,y:926,t:1528143704150};\\\", \\\"{x:1405,y:930,t:1528143704167};\\\", \\\"{x:1418,y:932,t:1528143704183};\\\", \\\"{x:1430,y:934,t:1528143704199};\\\", \\\"{x:1444,y:934,t:1528143704216};\\\", \\\"{x:1456,y:936,t:1528143704232};\\\", \\\"{x:1467,y:936,t:1528143704249};\\\", \\\"{x:1482,y:936,t:1528143704266};\\\", \\\"{x:1497,y:936,t:1528143704283};\\\", \\\"{x:1512,y:936,t:1528143704299};\\\", \\\"{x:1525,y:936,t:1528143704316};\\\", \\\"{x:1534,y:936,t:1528143704333};\\\", \\\"{x:1541,y:936,t:1528143704349};\\\", \\\"{x:1543,y:936,t:1528143704366};\\\", \\\"{x:1544,y:936,t:1528143704383};\\\", \\\"{x:1545,y:937,t:1528143704530};\\\", \\\"{x:1546,y:937,t:1528143704537};\\\", \\\"{x:1548,y:938,t:1528143704549};\\\", \\\"{x:1549,y:938,t:1528143704567};\\\", \\\"{x:1551,y:938,t:1528143704584};\\\", \\\"{x:1553,y:940,t:1528143704600};\\\", \\\"{x:1554,y:941,t:1528143704617};\\\", \\\"{x:1555,y:941,t:1528143704633};\\\", \\\"{x:1555,y:943,t:1528143704650};\\\", \\\"{x:1556,y:943,t:1528143704667};\\\", \\\"{x:1556,y:944,t:1528143704684};\\\", \\\"{x:1556,y:946,t:1528143704700};\\\", \\\"{x:1557,y:946,t:1528143704730};\\\", \\\"{x:1557,y:947,t:1528143704809};\\\", \\\"{x:1557,y:946,t:1528143704905};\\\", \\\"{x:1557,y:937,t:1528143704917};\\\", \\\"{x:1550,y:921,t:1528143704934};\\\", \\\"{x:1549,y:916,t:1528143704951};\\\", \\\"{x:1548,y:913,t:1528143704967};\\\", \\\"{x:1547,y:911,t:1528143704983};\\\", \\\"{x:1546,y:907,t:1528143705001};\\\", \\\"{x:1546,y:905,t:1528143705017};\\\", \\\"{x:1545,y:901,t:1528143705034};\\\", \\\"{x:1543,y:897,t:1528143705051};\\\", \\\"{x:1540,y:890,t:1528143705067};\\\", \\\"{x:1537,y:881,t:1528143705084};\\\", \\\"{x:1534,y:875,t:1528143705101};\\\", \\\"{x:1534,y:873,t:1528143705117};\\\", \\\"{x:1531,y:868,t:1528143705134};\\\", \\\"{x:1528,y:864,t:1528143705151};\\\", \\\"{x:1526,y:860,t:1528143705167};\\\", \\\"{x:1523,y:856,t:1528143705184};\\\", \\\"{x:1520,y:850,t:1528143705202};\\\", \\\"{x:1518,y:848,t:1528143705217};\\\", \\\"{x:1516,y:846,t:1528143705234};\\\", \\\"{x:1516,y:845,t:1528143705257};\\\", \\\"{x:1515,y:844,t:1528143705268};\\\", \\\"{x:1513,y:843,t:1528143705284};\\\", \\\"{x:1512,y:841,t:1528143705301};\\\", \\\"{x:1509,y:838,t:1528143705318};\\\", \\\"{x:1506,y:835,t:1528143705335};\\\", \\\"{x:1502,y:830,t:1528143705351};\\\", \\\"{x:1499,y:827,t:1528143705369};\\\", \\\"{x:1494,y:824,t:1528143705384};\\\", \\\"{x:1484,y:820,t:1528143705401};\\\", \\\"{x:1468,y:815,t:1528143705418};\\\", \\\"{x:1436,y:801,t:1528143705434};\\\", \\\"{x:1361,y:775,t:1528143705451};\\\", \\\"{x:1237,y:743,t:1528143705468};\\\", \\\"{x:1063,y:698,t:1528143705485};\\\", \\\"{x:871,y:652,t:1528143705502};\\\", \\\"{x:670,y:604,t:1528143705519};\\\", \\\"{x:505,y:564,t:1528143705533};\\\", \\\"{x:356,y:524,t:1528143705550};\\\", \\\"{x:241,y:498,t:1528143705568};\\\", \\\"{x:106,y:467,t:1528143705585};\\\", \\\"{x:67,y:456,t:1528143705601};\\\", \\\"{x:50,y:452,t:1528143705617};\\\", \\\"{x:48,y:452,t:1528143705634};\\\", \\\"{x:47,y:452,t:1528143706025};\\\", \\\"{x:47,y:451,t:1528143706035};\\\", \\\"{x:57,y:461,t:1528143706051};\\\", \\\"{x:62,y:469,t:1528143706069};\\\", \\\"{x:67,y:479,t:1528143706085};\\\", \\\"{x:74,y:488,t:1528143706103};\\\", \\\"{x:78,y:494,t:1528143706118};\\\", \\\"{x:81,y:497,t:1528143706134};\\\", \\\"{x:84,y:499,t:1528143706151};\\\", \\\"{x:88,y:501,t:1528143706168};\\\", \\\"{x:91,y:503,t:1528143706184};\\\", \\\"{x:93,y:505,t:1528143706202};\\\", \\\"{x:98,y:507,t:1528143706218};\\\", \\\"{x:102,y:508,t:1528143706234};\\\", \\\"{x:116,y:517,t:1528143706252};\\\", \\\"{x:131,y:525,t:1528143706269};\\\", \\\"{x:155,y:538,t:1528143706284};\\\", \\\"{x:179,y:548,t:1528143706301};\\\", \\\"{x:200,y:557,t:1528143706319};\\\", \\\"{x:226,y:565,t:1528143706335};\\\", \\\"{x:250,y:569,t:1528143706351};\\\", \\\"{x:278,y:570,t:1528143706370};\\\", \\\"{x:289,y:571,t:1528143706384};\\\", \\\"{x:296,y:572,t:1528143706401};\\\", \\\"{x:302,y:572,t:1528143706419};\\\", \\\"{x:306,y:572,t:1528143706435};\\\", \\\"{x:309,y:572,t:1528143706451};\\\", \\\"{x:315,y:572,t:1528143706468};\\\", \\\"{x:328,y:572,t:1528143706485};\\\", \\\"{x:347,y:575,t:1528143706501};\\\", \\\"{x:370,y:578,t:1528143706518};\\\", \\\"{x:395,y:579,t:1528143706537};\\\", \\\"{x:423,y:579,t:1528143706552};\\\", \\\"{x:460,y:579,t:1528143706568};\\\", \\\"{x:480,y:579,t:1528143706585};\\\", \\\"{x:497,y:579,t:1528143706601};\\\", \\\"{x:512,y:579,t:1528143706619};\\\", \\\"{x:523,y:579,t:1528143706636};\\\", \\\"{x:531,y:579,t:1528143706651};\\\", \\\"{x:539,y:579,t:1528143706668};\\\", \\\"{x:546,y:579,t:1528143706685};\\\", \\\"{x:555,y:579,t:1528143706701};\\\", \\\"{x:565,y:579,t:1528143706718};\\\", \\\"{x:578,y:579,t:1528143706736};\\\", \\\"{x:585,y:579,t:1528143706751};\\\", \\\"{x:594,y:577,t:1528143706768};\\\", \\\"{x:602,y:574,t:1528143706785};\\\", \\\"{x:608,y:571,t:1528143706802};\\\", \\\"{x:612,y:569,t:1528143706819};\\\", \\\"{x:614,y:568,t:1528143706836};\\\", \\\"{x:615,y:568,t:1528143706852};\\\", \\\"{x:618,y:574,t:1528143707561};\\\", \\\"{x:620,y:584,t:1528143707569};\\\", \\\"{x:624,y:609,t:1528143707589};\\\", \\\"{x:629,y:639,t:1528143707602};\\\", \\\"{x:636,y:670,t:1528143707619};\\\", \\\"{x:644,y:695,t:1528143707635};\\\", \\\"{x:648,y:712,t:1528143707653};\\\", \\\"{x:649,y:716,t:1528143707669};\\\", \\\"{x:648,y:716,t:1528143708074};\\\", \\\"{x:647,y:716,t:1528143708089};\\\", \\\"{x:642,y:716,t:1528143708103};\\\", \\\"{x:624,y:716,t:1528143708120};\\\", \\\"{x:592,y:717,t:1528143708137};\\\", \\\"{x:577,y:717,t:1528143708153};\\\", \\\"{x:567,y:716,t:1528143708170};\\\", \\\"{x:559,y:712,t:1528143708187};\\\", \\\"{x:555,y:711,t:1528143708203};\\\", \\\"{x:552,y:708,t:1528143708220};\\\", \\\"{x:551,y:708,t:1528143708236};\\\", \\\"{x:550,y:708,t:1528143708490};\\\", \\\"{x:550,y:709,t:1528143708504};\\\", \\\"{x:550,y:712,t:1528143708521};\\\", \\\"{x:550,y:715,t:1528143708537};\\\", \\\"{x:548,y:717,t:1528143708554};\\\", \\\"{x:548,y:719,t:1528143708570};\\\", \\\"{x:550,y:720,t:1528143708827};\\\", \\\"{x:568,y:725,t:1528143708838};\\\", \\\"{x:660,y:740,t:1528143708853};\\\", \\\"{x:834,y:763,t:1528143708870};\\\", \\\"{x:1041,y:792,t:1528143708887};\\\", \\\"{x:1268,y:825,t:1528143708903};\\\", \\\"{x:1612,y:844,t:1528143708920};\\\", \\\"{x:1805,y:862,t:1528143708937};\\\", \\\"{x:1919,y:871,t:1528143708955};\\\", \\\"{x:1919,y:875,t:1528143709003};\\\", \\\"{x:1919,y:876,t:1528143709020};\\\", \\\"{x:1919,y:877,t:1528143709037};\\\", \\\"{x:1918,y:877,t:1528143709081};\\\", \\\"{x:1916,y:877,t:1528143709089};\\\", \\\"{x:1912,y:876,t:1528143709103};\\\", \\\"{x:1900,y:876,t:1528143709120};\\\", \\\"{x:1875,y:876,t:1528143709137};\\\", \\\"{x:1856,y:876,t:1528143709153};\\\", \\\"{x:1829,y:876,t:1528143709172};\\\", \\\"{x:1784,y:871,t:1528143709188};\\\", \\\"{x:1744,y:865,t:1528143709204};\\\", \\\"{x:1720,y:863,t:1528143709221};\\\", \\\"{x:1694,y:858,t:1528143709238};\\\", \\\"{x:1681,y:858,t:1528143709254};\\\", \\\"{x:1665,y:857,t:1528143709270};\\\", \\\"{x:1650,y:857,t:1528143709288};\\\", \\\"{x:1640,y:857,t:1528143709305};\\\", \\\"{x:1635,y:857,t:1528143709320};\\\", \\\"{x:1631,y:859,t:1528143709338};\\\", \\\"{x:1628,y:866,t:1528143709355};\\\", \\\"{x:1621,y:881,t:1528143709373};\\\", \\\"{x:1615,y:893,t:1528143709388};\\\", \\\"{x:1609,y:902,t:1528143709405};\\\", \\\"{x:1604,y:909,t:1528143709422};\\\", \\\"{x:1601,y:915,t:1528143709439};\\\", \\\"{x:1598,y:919,t:1528143709456};\\\", \\\"{x:1595,y:923,t:1528143709471};\\\", \\\"{x:1592,y:928,t:1528143709489};\\\", \\\"{x:1589,y:931,t:1528143709505};\\\", \\\"{x:1587,y:933,t:1528143709521};\\\", \\\"{x:1585,y:936,t:1528143709538};\\\", \\\"{x:1584,y:939,t:1528143709555};\\\", \\\"{x:1583,y:940,t:1528143709572};\\\", \\\"{x:1582,y:941,t:1528143709588};\\\", \\\"{x:1580,y:943,t:1528143709606};\\\", \\\"{x:1577,y:945,t:1528143709622};\\\", \\\"{x:1572,y:945,t:1528143709639};\\\", \\\"{x:1569,y:948,t:1528143709655};\\\", \\\"{x:1565,y:948,t:1528143709672};\\\", \\\"{x:1562,y:948,t:1528143709688};\\\", \\\"{x:1557,y:949,t:1528143709705};\\\", \\\"{x:1554,y:949,t:1528143709722};\\\", \\\"{x:1553,y:949,t:1528143709745};\\\", \\\"{x:1552,y:949,t:1528143709769};\\\", \\\"{x:1551,y:948,t:1528143709777};\\\", \\\"{x:1550,y:944,t:1528143709788};\\\", \\\"{x:1545,y:932,t:1528143709805};\\\", \\\"{x:1539,y:916,t:1528143709822};\\\", \\\"{x:1528,y:893,t:1528143709838};\\\", \\\"{x:1514,y:873,t:1528143709855};\\\", \\\"{x:1504,y:855,t:1528143709873};\\\", \\\"{x:1496,y:836,t:1528143709889};\\\", \\\"{x:1493,y:820,t:1528143709906};\\\", \\\"{x:1488,y:807,t:1528143709923};\\\", \\\"{x:1477,y:792,t:1528143709939};\\\", \\\"{x:1455,y:763,t:1528143709955};\\\", \\\"{x:1428,y:738,t:1528143709973};\\\", \\\"{x:1407,y:713,t:1528143709989};\\\", \\\"{x:1390,y:695,t:1528143710005};\\\", \\\"{x:1380,y:679,t:1528143710022};\\\", \\\"{x:1375,y:668,t:1528143710039};\\\", \\\"{x:1366,y:649,t:1528143710055};\\\", \\\"{x:1358,y:630,t:1528143710072};\\\", \\\"{x:1348,y:619,t:1528143710090};\\\", \\\"{x:1344,y:616,t:1528143710105};\\\", \\\"{x:1338,y:615,t:1528143710122};\\\", \\\"{x:1331,y:615,t:1528143710139};\\\", \\\"{x:1317,y:615,t:1528143710155};\\\", \\\"{x:1286,y:615,t:1528143710172};\\\", \\\"{x:1214,y:615,t:1528143710189};\\\", \\\"{x:1137,y:622,t:1528143710206};\\\", \\\"{x:1040,y:635,t:1528143710222};\\\", \\\"{x:1026,y:637,t:1528143710239};\\\", \\\"{x:1023,y:638,t:1528143710256};\\\", \\\"{x:1021,y:638,t:1528143710386};\\\", \\\"{x:1016,y:638,t:1528143710393};\\\", \\\"{x:1003,y:638,t:1528143710407};\\\", \\\"{x:980,y:627,t:1528143710423};\\\", \\\"{x:940,y:607,t:1528143710441};\\\", \\\"{x:897,y:598,t:1528143710456};\\\", \\\"{x:855,y:598,t:1528143710471};\\\", \\\"{x:798,y:608,t:1528143710488};\\\", \\\"{x:778,y:610,t:1528143710505};\\\", \\\"{x:769,y:610,t:1528143710521};\\\", \\\"{x:766,y:610,t:1528143710538};\\\", \\\"{x:765,y:610,t:1528143710673};\\\", \\\"{x:764,y:610,t:1528143710729};\\\", \\\"{x:763,y:610,t:1528143710752};\\\", \\\"{x:760,y:610,t:1528143710761};\\\", \\\"{x:759,y:610,t:1528143710772};\\\", \\\"{x:756,y:611,t:1528143710788};\\\", \\\"{x:754,y:611,t:1528143710805};\\\", \\\"{x:751,y:612,t:1528143710821};\\\", \\\"{x:747,y:614,t:1528143710839};\\\", \\\"{x:745,y:614,t:1528143710856};\\\", \\\"{x:742,y:615,t:1528143710872};\\\", \\\"{x:741,y:615,t:1528143710889};\\\", \\\"{x:739,y:616,t:1528143710906};\\\", \\\"{x:736,y:617,t:1528143710922};\\\", \\\"{x:731,y:621,t:1528143710939};\\\", \\\"{x:726,y:624,t:1528143710955};\\\", \\\"{x:722,y:627,t:1528143710974};\\\", \\\"{x:718,y:631,t:1528143710988};\\\", \\\"{x:713,y:635,t:1528143711006};\\\", \\\"{x:706,y:643,t:1528143711023};\\\", \\\"{x:695,y:651,t:1528143711039};\\\", \\\"{x:688,y:658,t:1528143711055};\\\", \\\"{x:680,y:665,t:1528143711071};\\\", \\\"{x:668,y:677,t:1528143711088};\\\", \\\"{x:655,y:688,t:1528143711106};\\\", \\\"{x:643,y:696,t:1528143711122};\\\", \\\"{x:628,y:702,t:1528143711139};\\\", \\\"{x:615,y:708,t:1528143711155};\\\", \\\"{x:606,y:713,t:1528143711171};\\\", \\\"{x:599,y:716,t:1528143711189};\\\", \\\"{x:592,y:719,t:1528143711205};\\\", \\\"{x:580,y:724,t:1528143711222};\\\", \\\"{x:572,y:727,t:1528143711238};\\\", \\\"{x:568,y:728,t:1528143711255};\\\", \\\"{x:566,y:731,t:1528143711271};\\\", \\\"{x:565,y:733,t:1528143711288};\\\", \\\"{x:565,y:737,t:1528143711305};\\\", \\\"{x:565,y:741,t:1528143711322};\\\", \\\"{x:564,y:744,t:1528143711339};\\\", \\\"{x:561,y:748,t:1528143711356};\\\", \\\"{x:559,y:749,t:1528143711376};\\\", \\\"{x:559,y:750,t:1528143711392};\\\", \\\"{x:558,y:750,t:1528143711408};\\\", \\\"{x:557,y:750,t:1528143711424};\\\", \\\"{x:556,y:750,t:1528143711440};\\\", \\\"{x:555,y:750,t:1528143711456};\\\", \\\"{x:550,y:750,t:1528143711472};\\\", \\\"{x:546,y:750,t:1528143711490};\\\", \\\"{x:541,y:750,t:1528143711505};\\\", \\\"{x:537,y:750,t:1528143711522};\\\", \\\"{x:534,y:750,t:1528143711540};\\\", \\\"{x:532,y:750,t:1528143711555};\\\", \\\"{x:530,y:749,t:1528143711572};\\\", \\\"{x:528,y:748,t:1528143711590};\\\", \\\"{x:527,y:748,t:1528143711624};\\\", \\\"{x:527,y:743,t:1528143713521};\\\", \\\"{x:527,y:733,t:1528143713528};\\\" ] }, { \\\"rt\\\": 23537, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 825880, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-12 PM-X -X -X -X -X -07 PM-X -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:731,t:1528143714320};\\\", \\\"{x:529,y:731,t:1528143715001};\\\", \\\"{x:529,y:737,t:1528143715010};\\\", \\\"{x:523,y:747,t:1528143715025};\\\", \\\"{x:518,y:756,t:1528143715042};\\\", \\\"{x:514,y:760,t:1528143715058};\\\", \\\"{x:512,y:763,t:1528143715075};\\\", \\\"{x:511,y:764,t:1528143715092};\\\", \\\"{x:510,y:765,t:1528143715109};\\\", \\\"{x:510,y:766,t:1528143715248};\\\", \\\"{x:508,y:767,t:1528143715553};\\\", \\\"{x:507,y:768,t:1528143715560};\\\", \\\"{x:503,y:773,t:1528143715577};\\\", \\\"{x:502,y:777,t:1528143715593};\\\", \\\"{x:501,y:778,t:1528143715656};\\\", \\\"{x:500,y:778,t:1528143716153};\\\", \\\"{x:503,y:770,t:1528143716905};\\\", \\\"{x:504,y:767,t:1528143716914};\\\", \\\"{x:504,y:765,t:1528143716927};\\\", \\\"{x:504,y:763,t:1528143716944};\\\", \\\"{x:504,y:761,t:1528143716960};\\\", \\\"{x:505,y:760,t:1528143716977};\\\", \\\"{x:507,y:759,t:1528143717362};\\\", \\\"{x:515,y:744,t:1528143717377};\\\", \\\"{x:526,y:718,t:1528143717395};\\\", \\\"{x:532,y:702,t:1528143717411};\\\", \\\"{x:532,y:700,t:1528143717428};\\\", \\\"{x:534,y:700,t:1528143717921};\\\", \\\"{x:546,y:700,t:1528143717929};\\\", \\\"{x:568,y:700,t:1528143717945};\\\", \\\"{x:586,y:700,t:1528143717961};\\\", \\\"{x:605,y:703,t:1528143717979};\\\", \\\"{x:620,y:704,t:1528143717995};\\\", \\\"{x:637,y:707,t:1528143718011};\\\", \\\"{x:662,y:707,t:1528143718028};\\\", \\\"{x:690,y:708,t:1528143718046};\\\", \\\"{x:722,y:708,t:1528143718060};\\\", \\\"{x:751,y:709,t:1528143718078};\\\", \\\"{x:780,y:715,t:1528143718096};\\\", \\\"{x:804,y:721,t:1528143718111};\\\", \\\"{x:824,y:727,t:1528143718128};\\\", \\\"{x:856,y:736,t:1528143718144};\\\", \\\"{x:886,y:743,t:1528143718161};\\\", \\\"{x:921,y:750,t:1528143718179};\\\", \\\"{x:961,y:758,t:1528143718195};\\\", \\\"{x:1005,y:762,t:1528143718212};\\\", \\\"{x:1058,y:768,t:1528143718229};\\\", \\\"{x:1091,y:768,t:1528143718246};\\\", \\\"{x:1124,y:772,t:1528143718262};\\\", \\\"{x:1151,y:777,t:1528143718278};\\\", \\\"{x:1176,y:780,t:1528143718295};\\\", \\\"{x:1195,y:782,t:1528143718312};\\\", \\\"{x:1215,y:786,t:1528143718328};\\\", \\\"{x:1225,y:791,t:1528143718345};\\\", \\\"{x:1233,y:798,t:1528143718361};\\\", \\\"{x:1246,y:805,t:1528143718378};\\\", \\\"{x:1256,y:812,t:1528143718395};\\\", \\\"{x:1261,y:816,t:1528143718412};\\\", \\\"{x:1266,y:822,t:1528143718428};\\\", \\\"{x:1270,y:828,t:1528143718446};\\\", \\\"{x:1273,y:832,t:1528143718462};\\\", \\\"{x:1276,y:837,t:1528143718479};\\\", \\\"{x:1278,y:840,t:1528143718495};\\\", \\\"{x:1281,y:844,t:1528143718512};\\\", \\\"{x:1282,y:847,t:1528143718529};\\\", \\\"{x:1284,y:851,t:1528143718545};\\\", \\\"{x:1285,y:855,t:1528143718562};\\\", \\\"{x:1286,y:859,t:1528143718579};\\\", \\\"{x:1289,y:865,t:1528143718595};\\\", \\\"{x:1291,y:871,t:1528143718613};\\\", \\\"{x:1296,y:881,t:1528143718628};\\\", \\\"{x:1301,y:887,t:1528143718646};\\\", \\\"{x:1309,y:894,t:1528143718663};\\\", \\\"{x:1314,y:899,t:1528143718678};\\\", \\\"{x:1318,y:902,t:1528143718696};\\\", \\\"{x:1321,y:907,t:1528143718713};\\\", \\\"{x:1321,y:916,t:1528143718729};\\\", \\\"{x:1321,y:934,t:1528143718745};\\\", \\\"{x:1321,y:950,t:1528143718762};\\\", \\\"{x:1320,y:960,t:1528143718779};\\\", \\\"{x:1319,y:965,t:1528143718795};\\\", \\\"{x:1319,y:966,t:1528143718812};\\\", \\\"{x:1319,y:967,t:1528143718962};\\\", \\\"{x:1320,y:969,t:1528143718980};\\\", \\\"{x:1325,y:971,t:1528143718996};\\\", \\\"{x:1331,y:972,t:1528143719012};\\\", \\\"{x:1340,y:975,t:1528143719030};\\\", \\\"{x:1345,y:975,t:1528143719045};\\\", \\\"{x:1350,y:976,t:1528143719063};\\\", \\\"{x:1354,y:976,t:1528143719080};\\\", \\\"{x:1356,y:976,t:1528143719096};\\\", \\\"{x:1366,y:973,t:1528143719113};\\\", \\\"{x:1372,y:971,t:1528143719129};\\\", \\\"{x:1381,y:968,t:1528143719146};\\\", \\\"{x:1390,y:965,t:1528143719163};\\\", \\\"{x:1398,y:964,t:1528143719180};\\\", \\\"{x:1404,y:961,t:1528143719196};\\\", \\\"{x:1412,y:960,t:1528143719213};\\\", \\\"{x:1420,y:957,t:1528143719230};\\\", \\\"{x:1426,y:955,t:1528143719246};\\\", \\\"{x:1437,y:953,t:1528143719263};\\\", \\\"{x:1450,y:952,t:1528143719280};\\\", \\\"{x:1466,y:949,t:1528143719296};\\\", \\\"{x:1479,y:947,t:1528143719312};\\\", \\\"{x:1483,y:946,t:1528143719329};\\\", \\\"{x:1484,y:946,t:1528143719346};\\\", \\\"{x:1486,y:945,t:1528143719362};\\\", \\\"{x:1486,y:947,t:1528143719849};\\\", \\\"{x:1486,y:949,t:1528143719864};\\\", \\\"{x:1485,y:952,t:1528143719880};\\\", \\\"{x:1485,y:955,t:1528143719897};\\\", \\\"{x:1485,y:959,t:1528143719913};\\\", \\\"{x:1485,y:960,t:1528143719930};\\\", \\\"{x:1485,y:961,t:1528143719961};\\\", \\\"{x:1483,y:956,t:1528143720146};\\\", \\\"{x:1481,y:947,t:1528143720164};\\\", \\\"{x:1481,y:940,t:1528143720180};\\\", \\\"{x:1481,y:936,t:1528143720197};\\\", \\\"{x:1479,y:932,t:1528143720214};\\\", \\\"{x:1479,y:928,t:1528143720231};\\\", \\\"{x:1479,y:922,t:1528143720246};\\\", \\\"{x:1478,y:906,t:1528143720264};\\\", \\\"{x:1478,y:883,t:1528143720281};\\\", \\\"{x:1478,y:877,t:1528143720297};\\\", \\\"{x:1478,y:872,t:1528143720314};\\\", \\\"{x:1478,y:868,t:1528143720331};\\\", \\\"{x:1478,y:867,t:1528143720347};\\\", \\\"{x:1478,y:866,t:1528143720364};\\\", \\\"{x:1478,y:864,t:1528143720380};\\\", \\\"{x:1477,y:863,t:1528143720401};\\\", \\\"{x:1477,y:862,t:1528143720414};\\\", \\\"{x:1477,y:860,t:1528143720431};\\\", \\\"{x:1477,y:857,t:1528143720446};\\\", \\\"{x:1477,y:855,t:1528143720464};\\\", \\\"{x:1477,y:852,t:1528143720480};\\\", \\\"{x:1477,y:848,t:1528143720496};\\\", \\\"{x:1477,y:846,t:1528143720513};\\\", \\\"{x:1477,y:844,t:1528143720530};\\\", \\\"{x:1477,y:841,t:1528143720546};\\\", \\\"{x:1477,y:839,t:1528143720562};\\\", \\\"{x:1477,y:838,t:1528143720580};\\\", \\\"{x:1477,y:836,t:1528143720601};\\\", \\\"{x:1477,y:835,t:1528143720613};\\\", \\\"{x:1477,y:833,t:1528143720631};\\\", \\\"{x:1477,y:832,t:1528143720647};\\\", \\\"{x:1477,y:829,t:1528143720663};\\\", \\\"{x:1478,y:825,t:1528143720680};\\\", \\\"{x:1479,y:822,t:1528143720697};\\\", \\\"{x:1479,y:821,t:1528143720720};\\\", \\\"{x:1480,y:819,t:1528143720737};\\\", \\\"{x:1481,y:819,t:1528143720747};\\\", \\\"{x:1481,y:817,t:1528143720768};\\\", \\\"{x:1482,y:815,t:1528143720793};\\\", \\\"{x:1483,y:813,t:1528143720809};\\\", \\\"{x:1484,y:812,t:1528143720832};\\\", \\\"{x:1484,y:810,t:1528143720866};\\\", \\\"{x:1484,y:811,t:1528143722481};\\\", \\\"{x:1484,y:813,t:1528143722499};\\\", \\\"{x:1485,y:819,t:1528143722516};\\\", \\\"{x:1487,y:825,t:1528143722532};\\\", \\\"{x:1489,y:828,t:1528143722549};\\\", \\\"{x:1490,y:831,t:1528143722565};\\\", \\\"{x:1490,y:833,t:1528143722582};\\\", \\\"{x:1490,y:834,t:1528143722598};\\\", \\\"{x:1491,y:834,t:1528143722722};\\\", \\\"{x:1492,y:834,t:1528143723521};\\\", \\\"{x:1492,y:832,t:1528143723537};\\\", \\\"{x:1493,y:830,t:1528143723557};\\\", \\\"{x:1494,y:827,t:1528143723635};\\\", \\\"{x:1493,y:825,t:1528143724385};\\\", \\\"{x:1492,y:825,t:1528143724401};\\\", \\\"{x:1491,y:825,t:1528143724802};\\\", \\\"{x:1491,y:827,t:1528143724817};\\\", \\\"{x:1491,y:828,t:1528143724833};\\\", \\\"{x:1490,y:831,t:1528143724850};\\\", \\\"{x:1490,y:832,t:1528143724867};\\\", \\\"{x:1489,y:834,t:1528143724883};\\\", \\\"{x:1489,y:835,t:1528143724905};\\\", \\\"{x:1488,y:836,t:1528143724917};\\\", \\\"{x:1488,y:837,t:1528143724934};\\\", \\\"{x:1488,y:839,t:1528143724951};\\\", \\\"{x:1488,y:840,t:1528143724967};\\\", \\\"{x:1488,y:841,t:1528143724984};\\\", \\\"{x:1488,y:843,t:1528143725001};\\\", \\\"{x:1488,y:844,t:1528143725073};\\\", \\\"{x:1488,y:845,t:1528143725089};\\\", \\\"{x:1488,y:846,t:1528143725121};\\\", \\\"{x:1487,y:846,t:1528143726673};\\\", \\\"{x:1487,y:844,t:1528143726897};\\\", \\\"{x:1487,y:843,t:1528143726905};\\\", \\\"{x:1487,y:842,t:1528143726921};\\\", \\\"{x:1487,y:841,t:1528143726936};\\\", \\\"{x:1487,y:840,t:1528143726953};\\\", \\\"{x:1487,y:839,t:1528143726969};\\\", \\\"{x:1487,y:838,t:1528143726985};\\\", \\\"{x:1487,y:837,t:1528143727409};\\\", \\\"{x:1487,y:836,t:1528143727419};\\\", \\\"{x:1486,y:835,t:1528143727435};\\\", \\\"{x:1485,y:835,t:1528143727453};\\\", \\\"{x:1485,y:832,t:1528143727469};\\\", \\\"{x:1484,y:828,t:1528143727485};\\\", \\\"{x:1484,y:826,t:1528143727502};\\\", \\\"{x:1483,y:824,t:1528143727520};\\\", \\\"{x:1482,y:824,t:1528143729169};\\\", \\\"{x:1480,y:824,t:1528143729193};\\\", \\\"{x:1477,y:824,t:1528143729204};\\\", \\\"{x:1468,y:824,t:1528143729221};\\\", \\\"{x:1457,y:824,t:1528143729237};\\\", \\\"{x:1447,y:824,t:1528143729254};\\\", \\\"{x:1430,y:824,t:1528143729271};\\\", \\\"{x:1407,y:823,t:1528143729287};\\\", \\\"{x:1371,y:818,t:1528143729304};\\\", \\\"{x:1325,y:812,t:1528143729321};\\\", \\\"{x:1292,y:808,t:1528143729337};\\\", \\\"{x:1269,y:805,t:1528143729355};\\\", \\\"{x:1253,y:804,t:1528143729371};\\\", \\\"{x:1251,y:803,t:1528143729388};\\\", \\\"{x:1260,y:802,t:1528143729562};\\\", \\\"{x:1274,y:801,t:1528143729571};\\\", \\\"{x:1304,y:796,t:1528143729588};\\\", \\\"{x:1333,y:792,t:1528143729604};\\\", \\\"{x:1354,y:789,t:1528143729621};\\\", \\\"{x:1371,y:787,t:1528143729638};\\\", \\\"{x:1389,y:784,t:1528143729654};\\\", \\\"{x:1413,y:782,t:1528143729671};\\\", \\\"{x:1449,y:781,t:1528143729688};\\\", \\\"{x:1509,y:804,t:1528143729705};\\\", \\\"{x:1586,y:832,t:1528143729721};\\\", \\\"{x:1610,y:840,t:1528143729738};\\\", \\\"{x:1615,y:843,t:1528143729755};\\\", \\\"{x:1614,y:847,t:1528143729772};\\\", \\\"{x:1612,y:849,t:1528143729788};\\\", \\\"{x:1607,y:851,t:1528143729804};\\\", \\\"{x:1597,y:853,t:1528143729821};\\\", \\\"{x:1576,y:856,t:1528143729838};\\\", \\\"{x:1534,y:859,t:1528143729854};\\\", \\\"{x:1434,y:859,t:1528143729871};\\\", \\\"{x:1286,y:844,t:1528143729888};\\\", \\\"{x:1019,y:806,t:1528143729905};\\\", \\\"{x:834,y:781,t:1528143729921};\\\", \\\"{x:659,y:755,t:1528143729938};\\\", \\\"{x:480,y:728,t:1528143729955};\\\", \\\"{x:324,y:699,t:1528143729971};\\\", \\\"{x:205,y:685,t:1528143729988};\\\", \\\"{x:121,y:670,t:1528143730006};\\\", \\\"{x:63,y:665,t:1528143730021};\\\", \\\"{x:25,y:662,t:1528143730037};\\\", \\\"{x:0,y:662,t:1528143730054};\\\", \\\"{x:0,y:661,t:1528143730070};\\\", \\\"{x:0,y:656,t:1528143730087};\\\", \\\"{x:0,y:649,t:1528143730104};\\\", \\\"{x:0,y:627,t:1528143730119};\\\", \\\"{x:0,y:607,t:1528143730137};\\\", \\\"{x:0,y:583,t:1528143730154};\\\", \\\"{x:3,y:558,t:1528143730170};\\\", \\\"{x:15,y:543,t:1528143730187};\\\", \\\"{x:30,y:532,t:1528143730203};\\\", \\\"{x:52,y:522,t:1528143730222};\\\", \\\"{x:93,y:509,t:1528143730237};\\\", \\\"{x:149,y:501,t:1528143730254};\\\", \\\"{x:206,y:498,t:1528143730271};\\\", \\\"{x:312,y:498,t:1528143730289};\\\", \\\"{x:389,y:498,t:1528143730304};\\\", \\\"{x:454,y:498,t:1528143730321};\\\", \\\"{x:494,y:498,t:1528143730339};\\\", \\\"{x:525,y:508,t:1528143730355};\\\", \\\"{x:547,y:514,t:1528143730371};\\\", \\\"{x:563,y:520,t:1528143730388};\\\", \\\"{x:573,y:525,t:1528143730404};\\\", \\\"{x:573,y:526,t:1528143730421};\\\", \\\"{x:577,y:528,t:1528143730439};\\\", \\\"{x:582,y:529,t:1528143730454};\\\", \\\"{x:591,y:532,t:1528143730472};\\\", \\\"{x:601,y:535,t:1528143730488};\\\", \\\"{x:602,y:537,t:1528143730505};\\\", \\\"{x:603,y:538,t:1528143730522};\\\", \\\"{x:605,y:543,t:1528143730539};\\\", \\\"{x:607,y:551,t:1528143730556};\\\", \\\"{x:607,y:561,t:1528143730571};\\\", \\\"{x:607,y:570,t:1528143730589};\\\", \\\"{x:607,y:577,t:1528143730607};\\\", \\\"{x:607,y:582,t:1528143730622};\\\", \\\"{x:607,y:586,t:1528143730639};\\\", \\\"{x:607,y:588,t:1528143730656};\\\", \\\"{x:607,y:589,t:1528143730769};\\\", \\\"{x:608,y:590,t:1528143730800};\\\", \\\"{x:610,y:592,t:1528143731024};\\\", \\\"{x:613,y:593,t:1528143731038};\\\", \\\"{x:666,y:626,t:1528143731057};\\\", \\\"{x:829,y:730,t:1528143731072};\\\", \\\"{x:966,y:807,t:1528143731089};\\\", \\\"{x:1120,y:876,t:1528143731106};\\\", \\\"{x:1277,y:943,t:1528143731122};\\\", \\\"{x:1418,y:985,t:1528143731139};\\\", \\\"{x:1547,y:1034,t:1528143731156};\\\", \\\"{x:1659,y:1056,t:1528143731172};\\\", \\\"{x:1736,y:1059,t:1528143731188};\\\", \\\"{x:1780,y:1047,t:1528143731206};\\\", \\\"{x:1810,y:1040,t:1528143731223};\\\", \\\"{x:1818,y:1031,t:1528143731238};\\\", \\\"{x:1823,y:1014,t:1528143731256};\\\", \\\"{x:1803,y:985,t:1528143731272};\\\", \\\"{x:1799,y:981,t:1528143731289};\\\", \\\"{x:1797,y:979,t:1528143731306};\\\", \\\"{x:1792,y:975,t:1528143731323};\\\", \\\"{x:1784,y:969,t:1528143731339};\\\", \\\"{x:1769,y:956,t:1528143731356};\\\", \\\"{x:1747,y:937,t:1528143731373};\\\", \\\"{x:1720,y:922,t:1528143731389};\\\", \\\"{x:1683,y:902,t:1528143731406};\\\", \\\"{x:1656,y:888,t:1528143731423};\\\", \\\"{x:1636,y:883,t:1528143731439};\\\", \\\"{x:1625,y:879,t:1528143731456};\\\", \\\"{x:1604,y:873,t:1528143731473};\\\", \\\"{x:1599,y:871,t:1528143731489};\\\", \\\"{x:1598,y:871,t:1528143731506};\\\", \\\"{x:1597,y:871,t:1528143731523};\\\", \\\"{x:1596,y:871,t:1528143731544};\\\", \\\"{x:1595,y:870,t:1528143731593};\\\", \\\"{x:1595,y:869,t:1528143731625};\\\", \\\"{x:1591,y:866,t:1528143731641};\\\", \\\"{x:1568,y:852,t:1528143731656};\\\", \\\"{x:1531,y:841,t:1528143731673};\\\", \\\"{x:1514,y:837,t:1528143731691};\\\", \\\"{x:1505,y:835,t:1528143731706};\\\", \\\"{x:1500,y:835,t:1528143731723};\\\", \\\"{x:1492,y:835,t:1528143731740};\\\", \\\"{x:1481,y:835,t:1528143731756};\\\", \\\"{x:1475,y:835,t:1528143731774};\\\", \\\"{x:1474,y:835,t:1528143731790};\\\", \\\"{x:1473,y:835,t:1528143731842};\\\", \\\"{x:1473,y:829,t:1528143732409};\\\", \\\"{x:1473,y:820,t:1528143732424};\\\", \\\"{x:1473,y:805,t:1528143732440};\\\", \\\"{x:1473,y:802,t:1528143732457};\\\", \\\"{x:1473,y:801,t:1528143732474};\\\", \\\"{x:1473,y:800,t:1528143732490};\\\", \\\"{x:1473,y:798,t:1528143732507};\\\", \\\"{x:1473,y:797,t:1528143732523};\\\", \\\"{x:1473,y:796,t:1528143732541};\\\", \\\"{x:1473,y:793,t:1528143732557};\\\", \\\"{x:1473,y:792,t:1528143732577};\\\", \\\"{x:1473,y:790,t:1528143732593};\\\", \\\"{x:1473,y:789,t:1528143732617};\\\", \\\"{x:1473,y:787,t:1528143732633};\\\", \\\"{x:1473,y:786,t:1528143732649};\\\", \\\"{x:1473,y:784,t:1528143732665};\\\", \\\"{x:1473,y:783,t:1528143732681};\\\", \\\"{x:1473,y:781,t:1528143732691};\\\", \\\"{x:1472,y:780,t:1528143732707};\\\", \\\"{x:1472,y:779,t:1528143732724};\\\", \\\"{x:1472,y:778,t:1528143732745};\\\", \\\"{x:1472,y:777,t:1528143732777};\\\", \\\"{x:1472,y:776,t:1528143732793};\\\", \\\"{x:1472,y:775,t:1528143732807};\\\", \\\"{x:1472,y:774,t:1528143732824};\\\", \\\"{x:1471,y:772,t:1528143732840};\\\", \\\"{x:1471,y:770,t:1528143732857};\\\", \\\"{x:1470,y:768,t:1528143732874};\\\", \\\"{x:1469,y:764,t:1528143732890};\\\", \\\"{x:1469,y:762,t:1528143732907};\\\", \\\"{x:1469,y:761,t:1528143732925};\\\", \\\"{x:1469,y:759,t:1528143732941};\\\", \\\"{x:1469,y:758,t:1528143732957};\\\", \\\"{x:1469,y:757,t:1528143732977};\\\", \\\"{x:1468,y:755,t:1528143732993};\\\", \\\"{x:1468,y:754,t:1528143733009};\\\", \\\"{x:1468,y:752,t:1528143733024};\\\", \\\"{x:1467,y:749,t:1528143733040};\\\", \\\"{x:1467,y:745,t:1528143733056};\\\", \\\"{x:1467,y:741,t:1528143733074};\\\", \\\"{x:1466,y:735,t:1528143733090};\\\", \\\"{x:1464,y:730,t:1528143733107};\\\", \\\"{x:1463,y:725,t:1528143733124};\\\", \\\"{x:1463,y:714,t:1528143733141};\\\", \\\"{x:1463,y:702,t:1528143733157};\\\", \\\"{x:1463,y:695,t:1528143733174};\\\", \\\"{x:1463,y:692,t:1528143733190};\\\", \\\"{x:1463,y:688,t:1528143733206};\\\", \\\"{x:1463,y:684,t:1528143733224};\\\", \\\"{x:1463,y:676,t:1528143733240};\\\", \\\"{x:1463,y:672,t:1528143733257};\\\", \\\"{x:1463,y:667,t:1528143733274};\\\", \\\"{x:1463,y:663,t:1528143733291};\\\", \\\"{x:1463,y:658,t:1528143733307};\\\", \\\"{x:1463,y:652,t:1528143733324};\\\", \\\"{x:1463,y:644,t:1528143733341};\\\", \\\"{x:1463,y:636,t:1528143733357};\\\", \\\"{x:1463,y:631,t:1528143733374};\\\", \\\"{x:1463,y:626,t:1528143733391};\\\", \\\"{x:1463,y:617,t:1528143733407};\\\", \\\"{x:1463,y:609,t:1528143733424};\\\", \\\"{x:1463,y:601,t:1528143733441};\\\", \\\"{x:1463,y:595,t:1528143733457};\\\", \\\"{x:1463,y:593,t:1528143733474};\\\", \\\"{x:1463,y:592,t:1528143733491};\\\", \\\"{x:1463,y:589,t:1528143733508};\\\", \\\"{x:1463,y:582,t:1528143733524};\\\", \\\"{x:1463,y:569,t:1528143733541};\\\", \\\"{x:1463,y:558,t:1528143733557};\\\", \\\"{x:1463,y:543,t:1528143733574};\\\", \\\"{x:1463,y:525,t:1528143733591};\\\", \\\"{x:1463,y:512,t:1528143733607};\\\", \\\"{x:1463,y:497,t:1528143733624};\\\", \\\"{x:1463,y:475,t:1528143733640};\\\", \\\"{x:1463,y:461,t:1528143733658};\\\", \\\"{x:1463,y:452,t:1528143733673};\\\", \\\"{x:1463,y:444,t:1528143733691};\\\", \\\"{x:1463,y:437,t:1528143733707};\\\", \\\"{x:1463,y:432,t:1528143733724};\\\", \\\"{x:1463,y:425,t:1528143733740};\\\", \\\"{x:1463,y:417,t:1528143733757};\\\", \\\"{x:1463,y:409,t:1528143733774};\\\", \\\"{x:1463,y:405,t:1528143733791};\\\", \\\"{x:1463,y:393,t:1528143733808};\\\", \\\"{x:1463,y:378,t:1528143733823};\\\", \\\"{x:1463,y:370,t:1528143733841};\\\", \\\"{x:1463,y:363,t:1528143733857};\\\", \\\"{x:1464,y:357,t:1528143733874};\\\", \\\"{x:1465,y:353,t:1528143733890};\\\", \\\"{x:1465,y:350,t:1528143733908};\\\", \\\"{x:1466,y:346,t:1528143733924};\\\", \\\"{x:1466,y:341,t:1528143733941};\\\", \\\"{x:1466,y:336,t:1528143733958};\\\", \\\"{x:1467,y:334,t:1528143733974};\\\", \\\"{x:1467,y:330,t:1528143733991};\\\", \\\"{x:1468,y:327,t:1528143734008};\\\", \\\"{x:1469,y:322,t:1528143734024};\\\", \\\"{x:1471,y:319,t:1528143734041};\\\", \\\"{x:1471,y:317,t:1528143734058};\\\", \\\"{x:1471,y:315,t:1528143734074};\\\", \\\"{x:1472,y:314,t:1528143734153};\\\", \\\"{x:1472,y:313,t:1528143734184};\\\", \\\"{x:1472,y:312,t:1528143734200};\\\", \\\"{x:1472,y:310,t:1528143734208};\\\", \\\"{x:1472,y:309,t:1528143734225};\\\", \\\"{x:1474,y:307,t:1528143734241};\\\", \\\"{x:1474,y:306,t:1528143734257};\\\", \\\"{x:1474,y:303,t:1528143734275};\\\", \\\"{x:1475,y:302,t:1528143734291};\\\", \\\"{x:1475,y:300,t:1528143734320};\\\", \\\"{x:1475,y:299,t:1528143734369};\\\", \\\"{x:1476,y:299,t:1528143734376};\\\", \\\"{x:1476,y:297,t:1528143734481};\\\", \\\"{x:1446,y:296,t:1528143734946};\\\", \\\"{x:1388,y:305,t:1528143734958};\\\", \\\"{x:1292,y:315,t:1528143734975};\\\", \\\"{x:1200,y:330,t:1528143734992};\\\", \\\"{x:1065,y:349,t:1528143735008};\\\", \\\"{x:973,y:365,t:1528143735025};\\\", \\\"{x:888,y:374,t:1528143735042};\\\", \\\"{x:818,y:384,t:1528143735058};\\\", \\\"{x:772,y:393,t:1528143735075};\\\", \\\"{x:739,y:406,t:1528143735092};\\\", \\\"{x:707,y:424,t:1528143735108};\\\", \\\"{x:680,y:446,t:1528143735126};\\\", \\\"{x:658,y:467,t:1528143735142};\\\", \\\"{x:639,y:489,t:1528143735158};\\\", \\\"{x:623,y:518,t:1528143735177};\\\", \\\"{x:611,y:540,t:1528143735192};\\\", \\\"{x:590,y:569,t:1528143735208};\\\", \\\"{x:575,y:589,t:1528143735226};\\\", \\\"{x:563,y:606,t:1528143735242};\\\", \\\"{x:558,y:616,t:1528143735259};\\\", \\\"{x:557,y:621,t:1528143735275};\\\", \\\"{x:556,y:622,t:1528143735293};\\\", \\\"{x:555,y:622,t:1528143735384};\\\", \\\"{x:552,y:622,t:1528143735392};\\\", \\\"{x:540,y:622,t:1528143735409};\\\", \\\"{x:519,y:622,t:1528143735426};\\\", \\\"{x:479,y:622,t:1528143735444};\\\", \\\"{x:415,y:622,t:1528143735458};\\\", \\\"{x:354,y:622,t:1528143735476};\\\", \\\"{x:309,y:622,t:1528143735493};\\\", \\\"{x:289,y:618,t:1528143735508};\\\", \\\"{x:287,y:618,t:1528143735526};\\\", \\\"{x:284,y:617,t:1528143735817};\\\", \\\"{x:276,y:613,t:1528143735827};\\\", \\\"{x:262,y:607,t:1528143735843};\\\", \\\"{x:253,y:605,t:1528143735860};\\\", \\\"{x:244,y:604,t:1528143735876};\\\", \\\"{x:229,y:603,t:1528143735892};\\\", \\\"{x:214,y:603,t:1528143735910};\\\", \\\"{x:200,y:603,t:1528143735926};\\\", \\\"{x:191,y:603,t:1528143735943};\\\", \\\"{x:184,y:603,t:1528143735959};\\\", \\\"{x:182,y:603,t:1528143735975};\\\", \\\"{x:182,y:602,t:1528143736057};\\\", \\\"{x:186,y:600,t:1528143736064};\\\", \\\"{x:195,y:595,t:1528143736077};\\\", \\\"{x:211,y:587,t:1528143736093};\\\", \\\"{x:227,y:578,t:1528143736110};\\\", \\\"{x:241,y:572,t:1528143736127};\\\", \\\"{x:257,y:566,t:1528143736143};\\\", \\\"{x:280,y:562,t:1528143736160};\\\", \\\"{x:294,y:559,t:1528143736177};\\\", \\\"{x:312,y:558,t:1528143736192};\\\", \\\"{x:331,y:555,t:1528143736209};\\\", \\\"{x:352,y:553,t:1528143736227};\\\", \\\"{x:368,y:553,t:1528143736242};\\\", \\\"{x:388,y:552,t:1528143736261};\\\", \\\"{x:410,y:548,t:1528143736277};\\\", \\\"{x:427,y:546,t:1528143736293};\\\", \\\"{x:436,y:546,t:1528143736310};\\\", \\\"{x:439,y:546,t:1528143736327};\\\", \\\"{x:440,y:546,t:1528143736342};\\\", \\\"{x:441,y:546,t:1528143736392};\\\", \\\"{x:442,y:546,t:1528143736410};\\\", \\\"{x:442,y:550,t:1528143736427};\\\", \\\"{x:440,y:557,t:1528143736443};\\\", \\\"{x:438,y:561,t:1528143736461};\\\", \\\"{x:437,y:564,t:1528143736477};\\\", \\\"{x:435,y:566,t:1528143736494};\\\", \\\"{x:434,y:566,t:1528143736510};\\\", \\\"{x:433,y:568,t:1528143736527};\\\", \\\"{x:432,y:569,t:1528143736544};\\\", \\\"{x:430,y:571,t:1528143736561};\\\", \\\"{x:421,y:575,t:1528143736577};\\\", \\\"{x:416,y:577,t:1528143736594};\\\", \\\"{x:411,y:579,t:1528143736611};\\\", \\\"{x:408,y:579,t:1528143736626};\\\", \\\"{x:404,y:580,t:1528143736644};\\\", \\\"{x:400,y:581,t:1528143736660};\\\", \\\"{x:397,y:581,t:1528143736676};\\\", \\\"{x:395,y:582,t:1528143736694};\\\", \\\"{x:394,y:582,t:1528143736709};\\\", \\\"{x:393,y:582,t:1528143736726};\\\", \\\"{x:391,y:583,t:1528143736744};\\\", \\\"{x:391,y:587,t:1528143737016};\\\", \\\"{x:409,y:603,t:1528143737026};\\\", \\\"{x:439,y:634,t:1528143737044};\\\", \\\"{x:460,y:654,t:1528143737061};\\\", \\\"{x:483,y:674,t:1528143737076};\\\", \\\"{x:511,y:711,t:1528143737094};\\\", \\\"{x:540,y:758,t:1528143737112};\\\", \\\"{x:569,y:805,t:1528143737127};\\\", \\\"{x:603,y:858,t:1528143737143};\\\", \\\"{x:613,y:873,t:1528143737160};\\\", \\\"{x:619,y:878,t:1528143737177};\\\", \\\"{x:620,y:878,t:1528143737194};\\\", \\\"{x:620,y:877,t:1528143737273};\\\", \\\"{x:620,y:870,t:1528143737281};\\\", \\\"{x:620,y:864,t:1528143737295};\\\", \\\"{x:620,y:856,t:1528143737312};\\\", \\\"{x:620,y:847,t:1528143737327};\\\", \\\"{x:617,y:833,t:1528143737344};\\\", \\\"{x:608,y:808,t:1528143737361};\\\", \\\"{x:597,y:795,t:1528143737378};\\\", \\\"{x:584,y:784,t:1528143737394};\\\", \\\"{x:575,y:778,t:1528143737411};\\\", \\\"{x:571,y:776,t:1528143737429};\\\", \\\"{x:567,y:773,t:1528143737444};\\\", \\\"{x:565,y:772,t:1528143737462};\\\", \\\"{x:563,y:771,t:1528143737480};\\\", \\\"{x:561,y:769,t:1528143737497};\\\", \\\"{x:558,y:768,t:1528143737511};\\\", \\\"{x:549,y:761,t:1528143737530};\\\", \\\"{x:540,y:755,t:1528143737544};\\\", \\\"{x:534,y:749,t:1528143737559};\\\", \\\"{x:529,y:746,t:1528143737576};\\\" ] }, { \\\"rt\\\": 102789, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 929977, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"In this triangular graph, the left bottom side is the start of a shift, whose pinnacle is the label of the shift. So we look for 12pm on the x axis and follow the positive gradient until a label is reached\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7270, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 938253, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 15259, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 954534, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 3680, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 959564, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"VHSFM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"VHSFM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 186, dom: 839, initialDom: 909",
  "javascriptErrors": []
}