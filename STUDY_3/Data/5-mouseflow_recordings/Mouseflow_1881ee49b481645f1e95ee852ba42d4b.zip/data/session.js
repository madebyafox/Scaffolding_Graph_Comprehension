var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1881ee49b481645f1e95ee852ba42d4b",
  "created": "2018-06-04T13:22:18.5733157-07:00",
  "lastActivity": "2018-06-04T13:24:33.6461637-07:00",
  "pageViews": [
    {
      "id": "06041893c6f01a12f8dff35bf4b1fe203c3b414e",
      "startTime": "2018-06-04T13:22:18.5733157-07:00",
      "endTime": "2018-06-04T13:24:33.6461637-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 135088,
      "engagementTime": 125114,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 135088,
  "engagementTime": 125114,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=VHSFM",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1f6a082bf72901a3bac49752e04d19ab",
  "gdpr": false
}