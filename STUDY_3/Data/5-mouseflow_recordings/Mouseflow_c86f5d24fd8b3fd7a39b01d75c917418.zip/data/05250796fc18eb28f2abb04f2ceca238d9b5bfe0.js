var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05250796fc18eb28f2abb04f2ceca238d9b5bfe0"] = {
  "startTime": "2018-05-25T18:06:07.5720381Z",
  "websitePageUrl": "/",
  "visitTime": 197944,
  "engagementTime": 49207,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c86f5d24fd8b3fd7a39b01d75c917418",
    "created": "2018-05-25T18:06:07.5720381+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "63583b3f016f3f9ad9850c012ba5f67a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c86f5d24fd8b3fd7a39b01d75c917418/play"
  },
  "events": [
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 300,
      "e": 300,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 10000,
      "e": 9000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33261,
      "e": 9000,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 33300,
      "e": 9039,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 33300,
      "e": 9039,
      "ty": 2,
      "x": 633,
      "y": 11
    },
    {
      "t": 33501,
      "e": 9240,
      "ty": 41,
      "x": 21523,
      "y": 166,
      "ta": "html > body"
    },
    {
      "t": 40000,
      "e": 14240,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 147696,
      "e": 14240,
      "ty": 2,
      "x": 1335,
      "y": 0
    },
    {
      "t": 147747,
      "e": 14291,
      "ty": 41,
      "x": 62745,
      "y": 3877,
      "ta": "> div.masterdiv"
    },
    {
      "t": 147796,
      "e": 14340,
      "ty": 2,
      "x": 1843,
      "y": 84
    },
    {
      "t": 147896,
      "e": 14440,
      "ty": 2,
      "x": 1155,
      "y": 318
    },
    {
      "t": 147996,
      "e": 14540,
      "ty": 2,
      "x": 793,
      "y": 400
    },
    {
      "t": 147997,
      "e": 14541,
      "ty": 41,
      "x": 24576,
      "y": 10251,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 148096,
      "e": 14640,
      "ty": 2,
      "x": 846,
      "y": 703
    },
    {
      "t": 148195,
      "e": 14739,
      "ty": 2,
      "x": 524,
      "y": 1199
    },
    {
      "t": 148295,
      "e": 14839,
      "ty": 2,
      "x": 539,
      "y": 1165
    },
    {
      "t": 148396,
      "e": 14940,
      "ty": 2,
      "x": 774,
      "y": 847
    },
    {
      "t": 148496,
      "e": 15040,
      "ty": 2,
      "x": 691,
      "y": 774
    },
    {
      "t": 148496,
      "e": 15040,
      "ty": 41,
      "x": 19558,
      "y": 47286,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 148596,
      "e": 15140,
      "ty": 2,
      "x": 665,
      "y": 756
    },
    {
      "t": 148696,
      "e": 15240,
      "ty": 2,
      "x": 753,
      "y": 711
    },
    {
      "t": 148745,
      "e": 15289,
      "ty": 41,
      "x": 25166,
      "y": 11709,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 148796,
      "e": 15340,
      "ty": 2,
      "x": 825,
      "y": 692
    },
    {
      "t": 148896,
      "e": 15440,
      "ty": 2,
      "x": 916,
      "y": 689
    },
    {
      "t": 148996,
      "e": 15540,
      "ty": 2,
      "x": 1140,
      "y": 712
    },
    {
      "t": 148997,
      "e": 15541,
      "ty": 41,
      "x": 41647,
      "y": 18263,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 149096,
      "e": 15640,
      "ty": 2,
      "x": 1177,
      "y": 717
    },
    {
      "t": 149196,
      "e": 15740,
      "ty": 2,
      "x": 1156,
      "y": 734
    },
    {
      "t": 149246,
      "e": 15790,
      "ty": 41,
      "x": 37662,
      "y": 53319,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 149295,
      "e": 15839,
      "ty": 2,
      "x": 886,
      "y": 948
    },
    {
      "t": 149396,
      "e": 15940,
      "ty": 2,
      "x": 799,
      "y": 1039
    },
    {
      "t": 149495,
      "e": 16039,
      "ty": 2,
      "x": 792,
      "y": 1056
    },
    {
      "t": 149496,
      "e": 16040,
      "ty": 41,
      "x": 24527,
      "y": 64379,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149596,
      "e": 16140,
      "ty": 2,
      "x": 821,
      "y": 989
    },
    {
      "t": 149696,
      "e": 16240,
      "ty": 2,
      "x": 825,
      "y": 973
    },
    {
      "t": 149746,
      "e": 16290,
      "ty": 41,
      "x": 26248,
      "y": 58147,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149796,
      "e": 16340,
      "ty": 2,
      "x": 834,
      "y": 948
    },
    {
      "t": 149896,
      "e": 16440,
      "ty": 2,
      "x": 835,
      "y": 932
    },
    {
      "t": 149996,
      "e": 16540,
      "ty": 2,
      "x": 831,
      "y": 923
    },
    {
      "t": 149996,
      "e": 16540,
      "ty": 41,
      "x": 5787,
      "y": 44729,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 150096,
      "e": 16640,
      "ty": 2,
      "x": 826,
      "y": 918
    },
    {
      "t": 150196,
      "e": 16740,
      "ty": 2,
      "x": 823,
      "y": 916
    },
    {
      "t": 150246,
      "e": 16790,
      "ty": 41,
      "x": 64101,
      "y": 16434,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 150328,
      "e": 16872,
      "ty": 3,
      "x": 823,
      "y": 916,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 150469,
      "e": 17013,
      "ty": 4,
      "x": 64101,
      "y": 16434,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 150470,
      "e": 17014,
      "ty": 5,
      "x": 823,
      "y": 916,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 150472,
      "e": 17016,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 150476,
      "e": 17020,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 150995,
      "e": 17539,
      "ty": 2,
      "x": 918,
      "y": 1000
    },
    {
      "t": 150996,
      "e": 17540,
      "ty": 41,
      "x": 30725,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 151096,
      "e": 17640,
      "ty": 2,
      "x": 948,
      "y": 1027
    },
    {
      "t": 151196,
      "e": 17740,
      "ty": 2,
      "x": 963,
      "y": 1074
    },
    {
      "t": 151246,
      "e": 17790,
      "ty": 41,
      "x": 35771,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 151296,
      "e": 17840,
      "ty": 2,
      "x": 979,
      "y": 1104
    },
    {
      "t": 151497,
      "e": 18041,
      "ty": 41,
      "x": 37955,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 151678,
      "e": 18222,
      "ty": 3,
      "x": 979,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 151680,
      "e": 18224,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 151681,
      "e": 18225,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 151789,
      "e": 18333,
      "ty": 4,
      "x": 37955,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 151791,
      "e": 18335,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 151792,
      "e": 18336,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 151792,
      "e": 18336,
      "ty": 5,
      "x": 979,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 152798,
      "e": 19342,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 152896,
      "e": 19440,
      "ty": 2,
      "x": 1108,
      "y": 1061
    },
    {
      "t": 152996,
      "e": 19540,
      "ty": 2,
      "x": 1221,
      "y": 1023
    },
    {
      "t": 152996,
      "e": 19540,
      "ty": 41,
      "x": 41772,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 153096,
      "e": 19640,
      "ty": 2,
      "x": 1333,
      "y": 953
    },
    {
      "t": 153196,
      "e": 19740,
      "ty": 2,
      "x": 1372,
      "y": 917
    },
    {
      "t": 153247,
      "e": 19791,
      "ty": 41,
      "x": 46973,
      "y": 50245,
      "ta": "html > body"
    },
    {
      "t": 153312,
      "e": 19856,
      "ty": 2,
      "x": 1372,
      "y": 915
    },
    {
      "t": 153396,
      "e": 19940,
      "ty": 2,
      "x": 1247,
      "y": 835
    },
    {
      "t": 153478,
      "e": 20022,
      "ty": 6,
      "x": 981,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153496,
      "e": 20040,
      "ty": 2,
      "x": 975,
      "y": 683
    },
    {
      "t": 153497,
      "e": 20041,
      "ty": 41,
      "x": 36119,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153510,
      "e": 20054,
      "ty": 7,
      "x": 972,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153596,
      "e": 20140,
      "ty": 2,
      "x": 925,
      "y": 610
    },
    {
      "t": 153695,
      "e": 20239,
      "ty": 2,
      "x": 925,
      "y": 607
    },
    {
      "t": 153746,
      "e": 20290,
      "ty": 41,
      "x": 25305,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 153799,
      "e": 20343,
      "ty": 6,
      "x": 925,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153896,
      "e": 20440,
      "ty": 2,
      "x": 924,
      "y": 600
    },
    {
      "t": 153942,
      "e": 20486,
      "ty": 3,
      "x": 924,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153942,
      "e": 20486,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153995,
      "e": 20539,
      "ty": 41,
      "x": 25089,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154078,
      "e": 20622,
      "ty": 4,
      "x": 25089,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154079,
      "e": 20623,
      "ty": 5,
      "x": 924,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156690,
      "e": 23234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 156850,
      "e": 23394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 156850,
      "e": 23394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156953,
      "e": 23497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 156977,
      "e": 23521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 157001,
      "e": 23545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 157002,
      "e": 23546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157123,
      "e": 23667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 157123,
      "e": 23667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157161,
      "e": 23705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 157241,
      "e": 23785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 157354,
      "e": 23898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 157355,
      "e": 23899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157457,
      "e": 24001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nove"
    },
    {
      "t": 157490,
      "e": 24034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 157490,
      "e": 24034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157600,
      "e": 24144,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Novem"
    },
    {
      "t": 157602,
      "e": 24146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 157658,
      "e": 24202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 157659,
      "e": 24203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157753,
      "e": 24297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 158705,
      "e": 25249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 158707,
      "e": 25251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158770,
      "e": 25314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 158770,
      "e": 25314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158849,
      "e": 25393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||er"
    },
    {
      "t": 158906,
      "e": 25394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 158970,
      "e": 25458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 158970,
      "e": 25458,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 158971,
      "e": 25459,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158972,
      "e": 25460,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 159089,
      "e": 25577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 160322,
      "e": 26810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 160322,
      "e": 26810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160400,
      "e": 26888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 160498,
      "e": 26986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 160499,
      "e": 26987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160601,
      "e": 27089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 160625,
      "e": 27113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 160769,
      "e": 27257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 160769,
      "e": 27257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160890,
      "e": 27378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 162168,
      "e": 28656,
      "ty": 7,
      "x": 924,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 162196,
      "e": 28684,
      "ty": 2,
      "x": 924,
      "y": 612
    },
    {
      "t": 162245,
      "e": 28733,
      "ty": 41,
      "x": 25521,
      "y": 7046,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 162295,
      "e": 28783,
      "ty": 2,
      "x": 929,
      "y": 631
    },
    {
      "t": 162396,
      "e": 28884,
      "ty": 2,
      "x": 953,
      "y": 666
    },
    {
      "t": 162419,
      "e": 28907,
      "ty": 6,
      "x": 970,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162495,
      "e": 28983,
      "ty": 2,
      "x": 977,
      "y": 699
    },
    {
      "t": 162495,
      "e": 28983,
      "ty": 41,
      "x": 36552,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162501,
      "e": 28989,
      "ty": 7,
      "x": 979,
      "y": 703,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162595,
      "e": 29083,
      "ty": 2,
      "x": 987,
      "y": 706
    },
    {
      "t": 162622,
      "e": 29110,
      "ty": 6,
      "x": 987,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 162695,
      "e": 29183,
      "ty": 2,
      "x": 987,
      "y": 709
    },
    {
      "t": 162746,
      "e": 29234,
      "ty": 41,
      "x": 44363,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 162795,
      "e": 29283,
      "ty": 2,
      "x": 979,
      "y": 723
    },
    {
      "t": 162895,
      "e": 29383,
      "ty": 2,
      "x": 979,
      "y": 725
    },
    {
      "t": 162995,
      "e": 29483,
      "ty": 41,
      "x": 42817,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163342,
      "e": 29830,
      "ty": 3,
      "x": 979,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163343,
      "e": 29831,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 163344,
      "e": 29832,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163345,
      "e": 29833,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163413,
      "e": 29901,
      "ty": 4,
      "x": 42817,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163414,
      "e": 29902,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163415,
      "e": 29903,
      "ty": 5,
      "x": 979,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 163415,
      "e": 29903,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 163796,
      "e": 30284,
      "ty": 2,
      "x": 974,
      "y": 731
    },
    {
      "t": 163895,
      "e": 30383,
      "ty": 2,
      "x": 967,
      "y": 737
    },
    {
      "t": 163996,
      "e": 30484,
      "ty": 2,
      "x": 965,
      "y": 737
    },
    {
      "t": 163996,
      "e": 30484,
      "ty": 41,
      "x": 32956,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 164531,
      "e": 31019,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 164558,
      "e": 31046,
      "ty": 6,
      "x": 965,
      "y": 737,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 169996,
      "e": 36046,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180582,
      "e": 36046,
      "ty": 7,
      "x": 844,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 180583,
      "e": 36047,
      "ty": 6,
      "x": 844,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 180594,
      "e": 36058,
      "ty": 2,
      "x": 844,
      "y": 700
    },
    {
      "t": 180598,
      "e": 36062,
      "ty": 7,
      "x": 716,
      "y": 656,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 180694,
      "e": 36158,
      "ty": 2,
      "x": 106,
      "y": 525
    },
    {
      "t": 180743,
      "e": 36207,
      "ty": 41,
      "x": 2513,
      "y": 28640,
      "ta": "> div.masterdiv"
    },
    {
      "t": 180793,
      "e": 36257,
      "ty": 2,
      "x": 81,
      "y": 525
    },
    {
      "t": 180893,
      "e": 36357,
      "ty": 2,
      "x": 218,
      "y": 586
    },
    {
      "t": 180993,
      "e": 36457,
      "ty": 2,
      "x": 310,
      "y": 612
    },
    {
      "t": 180993,
      "e": 36457,
      "ty": 41,
      "x": 814,
      "y": 31917,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 181094,
      "e": 36558,
      "ty": 2,
      "x": 311,
      "y": 612
    },
    {
      "t": 181192,
      "e": 36656,
      "ty": 2,
      "x": 323,
      "y": 631
    },
    {
      "t": 181243,
      "e": 36707,
      "ty": 41,
      "x": 10831,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 181293,
      "e": 36757,
      "ty": 2,
      "x": 353,
      "y": 646
    },
    {
      "t": 181393,
      "e": 36857,
      "ty": 2,
      "x": 386,
      "y": 657
    },
    {
      "t": 181494,
      "e": 36958,
      "ty": 2,
      "x": 443,
      "y": 670
    },
    {
      "t": 181494,
      "e": 36958,
      "ty": 41,
      "x": 7357,
      "y": 40903,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 181498,
      "e": 36962,
      "ty": 6,
      "x": 462,
      "y": 675,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 181593,
      "e": 37057,
      "ty": 2,
      "x": 498,
      "y": 683
    },
    {
      "t": 181693,
      "e": 37157,
      "ty": 2,
      "x": 511,
      "y": 683
    },
    {
      "t": 181742,
      "e": 37206,
      "ty": 41,
      "x": 9118,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 181793,
      "e": 37257,
      "ty": 2,
      "x": 514,
      "y": 688
    },
    {
      "t": 181893,
      "e": 37357,
      "ty": 2,
      "x": 512,
      "y": 690
    },
    {
      "t": 181993,
      "e": 37457,
      "ty": 2,
      "x": 498,
      "y": 690
    },
    {
      "t": 181993,
      "e": 37457,
      "ty": 41,
      "x": 8409,
      "y": 44506,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 182092,
      "e": 37556,
      "ty": 2,
      "x": 486,
      "y": 693
    },
    {
      "t": 182167,
      "e": 37631,
      "ty": 7,
      "x": 481,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 182167,
      "e": 37631,
      "ty": 6,
      "x": 481,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 182193,
      "e": 37657,
      "ty": 2,
      "x": 479,
      "y": 704
    },
    {
      "t": 182243,
      "e": 37707,
      "ty": 41,
      "x": 7345,
      "y": 32804,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 182292,
      "e": 37756,
      "ty": 2,
      "x": 477,
      "y": 713
    },
    {
      "t": 182467,
      "e": 37931,
      "ty": 7,
      "x": 473,
      "y": 734,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 182467,
      "e": 37931,
      "ty": 6,
      "x": 473,
      "y": 734,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 182493,
      "e": 37957,
      "ty": 2,
      "x": 472,
      "y": 737
    },
    {
      "t": 182493,
      "e": 37957,
      "ty": 41,
      "x": 7092,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 182593,
      "e": 38057,
      "ty": 2,
      "x": 471,
      "y": 741
    },
    {
      "t": 182692,
      "e": 38156,
      "ty": 2,
      "x": 471,
      "y": 745
    },
    {
      "t": 182743,
      "e": 38207,
      "ty": 41,
      "x": 7041,
      "y": 58549,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 182749,
      "e": 38213,
      "ty": 7,
      "x": 471,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 182750,
      "e": 38214,
      "ty": 6,
      "x": 471,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 182793,
      "e": 38257,
      "ty": 2,
      "x": 476,
      "y": 758
    },
    {
      "t": 182893,
      "e": 38357,
      "ty": 2,
      "x": 487,
      "y": 763
    },
    {
      "t": 182983,
      "e": 38447,
      "ty": 7,
      "x": 506,
      "y": 750,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 182983,
      "e": 38447,
      "ty": 6,
      "x": 506,
      "y": 750,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 182994,
      "e": 38458,
      "ty": 2,
      "x": 506,
      "y": 750
    },
    {
      "t": 182994,
      "e": 38458,
      "ty": 41,
      "x": 8814,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 183092,
      "e": 38556,
      "ty": 2,
      "x": 486,
      "y": 752
    },
    {
      "t": 183100,
      "e": 38564,
      "ty": 7,
      "x": 480,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 183100,
      "e": 38564,
      "ty": 6,
      "x": 480,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183193,
      "e": 38657,
      "ty": 2,
      "x": 473,
      "y": 759
    },
    {
      "t": 183244,
      "e": 38708,
      "ty": 41,
      "x": 7142,
      "y": 9398,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183293,
      "e": 38757,
      "ty": 2,
      "x": 473,
      "y": 760
    },
    {
      "t": 183393,
      "e": 38857,
      "ty": 2,
      "x": 479,
      "y": 767
    },
    {
      "t": 183466,
      "e": 38930,
      "ty": 7,
      "x": 572,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 183493,
      "e": 38957,
      "ty": 2,
      "x": 581,
      "y": 784
    },
    {
      "t": 183493,
      "e": 38957,
      "ty": 41,
      "x": 14146,
      "y": 58565,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 183592,
      "e": 39056,
      "ty": 2,
      "x": 593,
      "y": 786
    },
    {
      "t": 183693,
      "e": 39157,
      "ty": 2,
      "x": 600,
      "y": 786
    },
    {
      "t": 183743,
      "e": 39207,
      "ty": 41,
      "x": 16114,
      "y": 50737,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 183792,
      "e": 39256,
      "ty": 2,
      "x": 645,
      "y": 1010
    },
    {
      "t": 183893,
      "e": 39357,
      "ty": 2,
      "x": 649,
      "y": 1026
    },
    {
      "t": 183993,
      "e": 39457,
      "ty": 2,
      "x": 741,
      "y": 1002
    },
    {
      "t": 183993,
      "e": 39457,
      "ty": 41,
      "x": 22017,
      "y": 60640,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 184093,
      "e": 39557,
      "ty": 2,
      "x": 869,
      "y": 1022
    },
    {
      "t": 184193,
      "e": 39657,
      "ty": 2,
      "x": 913,
      "y": 1065
    },
    {
      "t": 184201,
      "e": 39665,
      "ty": 6,
      "x": 929,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 184243,
      "e": 39707,
      "ty": 41,
      "x": 28125,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 184293,
      "e": 39757,
      "ty": 2,
      "x": 969,
      "y": 1100
    },
    {
      "t": 184393,
      "e": 39857,
      "ty": 2,
      "x": 988,
      "y": 1100
    },
    {
      "t": 184493,
      "e": 39957,
      "ty": 2,
      "x": 988,
      "y": 1099
    },
    {
      "t": 184493,
      "e": 39957,
      "ty": 41,
      "x": 42870,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 184593,
      "e": 40057,
      "ty": 2,
      "x": 983,
      "y": 1082
    },
    {
      "t": 184692,
      "e": 40156,
      "ty": 2,
      "x": 983,
      "y": 1081
    },
    {
      "t": 184739,
      "e": 40203,
      "ty": 3,
      "x": 983,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 184739,
      "e": 40203,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 184743,
      "e": 40207,
      "ty": 41,
      "x": 40140,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 184858,
      "e": 40322,
      "ty": 4,
      "x": 40140,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 184859,
      "e": 40323,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 184859,
      "e": 40323,
      "ty": 5,
      "x": 983,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 184861,
      "e": 40325,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 185093,
      "e": 40557,
      "ty": 2,
      "x": 1002,
      "y": 1036
    },
    {
      "t": 185193,
      "e": 40657,
      "ty": 2,
      "x": 1020,
      "y": 935
    },
    {
      "t": 185243,
      "e": 40707,
      "ty": 41,
      "x": 33439,
      "y": 40606,
      "ta": "html > body"
    },
    {
      "t": 185293,
      "e": 40757,
      "ty": 2,
      "x": 753,
      "y": 510
    },
    {
      "t": 185393,
      "e": 40857,
      "ty": 2,
      "x": 243,
      "y": 170
    },
    {
      "t": 185493,
      "e": 40957,
      "ty": 2,
      "x": 238,
      "y": 165
    },
    {
      "t": 185493,
      "e": 40957,
      "ty": 41,
      "x": 7920,
      "y": 8697,
      "ta": "html > body"
    },
    {
      "t": 185861,
      "e": 41325,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 189993,
      "e": 45457,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 194694,
      "e": 45957,
      "ty": 2,
      "x": 316,
      "y": 179
    },
    {
      "t": 194743,
      "e": 46006,
      "ty": 41,
      "x": 19150,
      "y": 15180,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 194793,
      "e": 46056,
      "ty": 2,
      "x": 897,
      "y": 488
    },
    {
      "t": 194893,
      "e": 46156,
      "ty": 2,
      "x": 1018,
      "y": 761
    },
    {
      "t": 194993,
      "e": 46256,
      "ty": 2,
      "x": 983,
      "y": 919
    },
    {
      "t": 194994,
      "e": 46257,
      "ty": 41,
      "x": 33908,
      "y": 60060,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 195093,
      "e": 46356,
      "ty": 2,
      "x": 964,
      "y": 967
    },
    {
      "t": 195194,
      "e": 46457,
      "ty": 2,
      "x": 959,
      "y": 984
    },
    {
      "t": 195244,
      "e": 46507,
      "ty": 41,
      "x": 32743,
      "y": 65107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 196937,
      "e": 48200,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 197944,
      "e": 49207,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 83, dom: 666, initialDom: 672",
  "javascriptErrors": []
}