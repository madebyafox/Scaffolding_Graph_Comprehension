var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05221444307148c0d6920c5abbfc642e5c78bd09"] = {
  "startTime": "2018-05-22T17:07:15.0405914Z",
  "websitePageUrl": "/",
  "visitTime": 166430,
  "engagementTime": 48283,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "aef39d005661a27d888b590c374dac0e",
    "created": "2018-05-22T17:07:15.030294+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "462c73c0f43773e55fe8df3752922562",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/aef39d005661a27d888b590c374dac0e/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 295,
      "e": 295,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 8769,
      "e": 5101,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8799,
      "e": 5131,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 8799,
      "e": 5131,
      "ty": 2,
      "x": 403,
      "y": 60
    },
    {
      "t": 9001,
      "e": 5333,
      "ty": 41,
      "x": 13602,
      "y": 2880,
      "ta": "html > body"
    },
    {
      "t": 10000,
      "e": 6332,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 69203,
      "e": 10333,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 69303,
      "e": 10433,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 80004,
      "e": 15433,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 121007,
      "e": 15433,
      "ty": 2,
      "x": 807,
      "y": 37
    },
    {
      "t": 121008,
      "e": 15434,
      "ty": 41,
      "x": 21713,
      "y": 16065,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 121107,
      "e": 15533,
      "ty": 2,
      "x": 1146,
      "y": 663
    },
    {
      "t": 121207,
      "e": 15633,
      "ty": 2,
      "x": 1233,
      "y": 896
    },
    {
      "t": 121258,
      "e": 15684,
      "ty": 41,
      "x": 46222,
      "y": 61602,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 121308,
      "e": 15734,
      "ty": 2,
      "x": 1233,
      "y": 897
    },
    {
      "t": 121408,
      "e": 15834,
      "ty": 2,
      "x": 1063,
      "y": 1003
    },
    {
      "t": 121507,
      "e": 15933,
      "ty": 41,
      "x": 27183,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121508,
      "e": 15934,
      "ty": 2,
      "x": 846,
      "y": 993
    },
    {
      "t": 121607,
      "e": 16033,
      "ty": 2,
      "x": 845,
      "y": 983
    },
    {
      "t": 121707,
      "e": 16133,
      "ty": 2,
      "x": 821,
      "y": 940
    },
    {
      "t": 121757,
      "e": 16183,
      "ty": 41,
      "x": 25609,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 121807,
      "e": 16233,
      "ty": 2,
      "x": 811,
      "y": 928
    },
    {
      "t": 122007,
      "e": 16433,
      "ty": 2,
      "x": 810,
      "y": 923
    },
    {
      "t": 122007,
      "e": 16433,
      "ty": 41,
      "x": 21503,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122068,
      "e": 16494,
      "ty": 3,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122107,
      "e": 16533,
      "ty": 2,
      "x": 810,
      "y": 922
    },
    {
      "t": 122163,
      "e": 16589,
      "ty": 4,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122165,
      "e": 16591,
      "ty": 5,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122167,
      "e": 16593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 122176,
      "e": 16602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 122257,
      "e": 16683,
      "ty": 41,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122408,
      "e": 16834,
      "ty": 2,
      "x": 1056,
      "y": 1076
    },
    {
      "t": 122508,
      "e": 16934,
      "ty": 2,
      "x": 1086,
      "y": 1088
    },
    {
      "t": 122508,
      "e": 16934,
      "ty": 41,
      "x": 37123,
      "y": 59829,
      "ta": "> div.masterdiv"
    },
    {
      "t": 122608,
      "e": 17034,
      "ty": 2,
      "x": 1079,
      "y": 1081
    },
    {
      "t": 122707,
      "e": 17133,
      "ty": 2,
      "x": 1045,
      "y": 1084
    },
    {
      "t": 122757,
      "e": 17183,
      "ty": 41,
      "x": 55977,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 122807,
      "e": 17233,
      "ty": 2,
      "x": 1008,
      "y": 1087
    },
    {
      "t": 122905,
      "e": 17331,
      "ty": 3,
      "x": 1005,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 122907,
      "e": 17333,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 122907,
      "e": 17333,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122907,
      "e": 17333,
      "ty": 2,
      "x": 1005,
      "y": 1088
    },
    {
      "t": 122986,
      "e": 17412,
      "ty": 4,
      "x": 52154,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 122988,
      "e": 17414,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 122989,
      "e": 17415,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 122990,
      "e": 17416,
      "ty": 5,
      "x": 1005,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 123007,
      "e": 17433,
      "ty": 2,
      "x": 1003,
      "y": 1088
    },
    {
      "t": 123007,
      "e": 17433,
      "ty": 41,
      "x": 34265,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 123207,
      "e": 17633,
      "ty": 2,
      "x": 1014,
      "y": 1063
    },
    {
      "t": 123258,
      "e": 17684,
      "ty": 41,
      "x": 34678,
      "y": 58444,
      "ta": "html > body"
    },
    {
      "t": 123307,
      "e": 17733,
      "ty": 2,
      "x": 1015,
      "y": 1063
    },
    {
      "t": 123507,
      "e": 17933,
      "ty": 2,
      "x": 999,
      "y": 1038
    },
    {
      "t": 123507,
      "e": 17933,
      "ty": 41,
      "x": 34127,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 123607,
      "e": 18033,
      "ty": 2,
      "x": 998,
      "y": 1024
    },
    {
      "t": 123707,
      "e": 18133,
      "ty": 2,
      "x": 1008,
      "y": 965
    },
    {
      "t": 123758,
      "e": 18184,
      "ty": 41,
      "x": 34644,
      "y": 50411,
      "ta": "html > body"
    },
    {
      "t": 123807,
      "e": 18233,
      "ty": 2,
      "x": 1017,
      "y": 895
    },
    {
      "t": 123907,
      "e": 18333,
      "ty": 2,
      "x": 1017,
      "y": 891
    },
    {
      "t": 123991,
      "e": 18417,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 124007,
      "e": 18433,
      "ty": 41,
      "x": 34747,
      "y": 48915,
      "ta": "html > body"
    },
    {
      "t": 124707,
      "e": 19133,
      "ty": 2,
      "x": 1015,
      "y": 856
    },
    {
      "t": 124756,
      "e": 19182,
      "ty": 41,
      "x": 34437,
      "y": 43819,
      "ta": "html > body"
    },
    {
      "t": 124807,
      "e": 19233,
      "ty": 2,
      "x": 1001,
      "y": 768
    },
    {
      "t": 124907,
      "e": 19333,
      "ty": 2,
      "x": 994,
      "y": 749
    },
    {
      "t": 124925,
      "e": 19351,
      "ty": 6,
      "x": 987,
      "y": 738,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124974,
      "e": 19400,
      "ty": 7,
      "x": 960,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124975,
      "e": 19401,
      "ty": 6,
      "x": 960,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124990,
      "e": 19416,
      "ty": 7,
      "x": 950,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 125007,
      "e": 19433,
      "ty": 2,
      "x": 950,
      "y": 662
    },
    {
      "t": 125007,
      "e": 19433,
      "ty": 41,
      "x": 30712,
      "y": 33119,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 125057,
      "e": 19483,
      "ty": 6,
      "x": 919,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125107,
      "e": 19533,
      "ty": 2,
      "x": 916,
      "y": 602
    },
    {
      "t": 125235,
      "e": 19661,
      "ty": 3,
      "x": 916,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125239,
      "e": 19665,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125258,
      "e": 19684,
      "ty": 41,
      "x": 23359,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125338,
      "e": 19764,
      "ty": 4,
      "x": 23359,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125338,
      "e": 19764,
      "ty": 5,
      "x": 916,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125707,
      "e": 20133,
      "ty": 2,
      "x": 929,
      "y": 605
    },
    {
      "t": 125758,
      "e": 20184,
      "ty": 41,
      "x": 26170,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127927,
      "e": 22353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 127928,
      "e": 22354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128014,
      "e": 22440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "e"
    },
    {
      "t": 128142,
      "e": 22568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 128142,
      "e": 22568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128254,
      "e": 22680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 128255,
      "e": 22681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128262,
      "e": 22688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ech"
    },
    {
      "t": 128357,
      "e": 22783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ech"
    },
    {
      "t": 128381,
      "e": 22807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 128382,
      "e": 22808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128510,
      "e": 22936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "echo"
    },
    {
      "t": 128614,
      "e": 23040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 128615,
      "e": 23041,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "echo"
    },
    {
      "t": 128616,
      "e": 23042,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128618,
      "e": 23044,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 128709,
      "e": 23135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 130008,
      "e": 24434,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130591,
      "e": 25017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 130591,
      "e": 25017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130757,
      "e": 25183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 130878,
      "e": 25304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 130879,
      "e": 25305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130989,
      "e": 25415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 131005,
      "e": 25431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 131006,
      "e": 25432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131158,
      "e": 25584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 132097,
      "e": 26523,
      "ty": 7,
      "x": 942,
      "y": 611,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132108,
      "e": 26534,
      "ty": 2,
      "x": 942,
      "y": 611
    },
    {
      "t": 132181,
      "e": 26607,
      "ty": 6,
      "x": 961,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132208,
      "e": 26634,
      "ty": 2,
      "x": 965,
      "y": 698
    },
    {
      "t": 132213,
      "e": 26639,
      "ty": 7,
      "x": 966,
      "y": 705,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132230,
      "e": 26656,
      "ty": 6,
      "x": 966,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132257,
      "e": 26683,
      "ty": 41,
      "x": 36117,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132308,
      "e": 26734,
      "ty": 2,
      "x": 966,
      "y": 709
    },
    {
      "t": 132408,
      "e": 26834,
      "ty": 2,
      "x": 967,
      "y": 717
    },
    {
      "t": 132491,
      "e": 26917,
      "ty": 3,
      "x": 967,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132493,
      "e": 26919,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 132494,
      "e": 26920,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132494,
      "e": 26920,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132507,
      "e": 26933,
      "ty": 2,
      "x": 967,
      "y": 719
    },
    {
      "t": 132509,
      "e": 26935,
      "ty": 41,
      "x": 36632,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132593,
      "e": 27019,
      "ty": 4,
      "x": 36632,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132594,
      "e": 27020,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132595,
      "e": 27021,
      "ty": 5,
      "x": 967,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132596,
      "e": 27022,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 132708,
      "e": 27134,
      "ty": 2,
      "x": 968,
      "y": 720
    },
    {
      "t": 132758,
      "e": 27184,
      "ty": 41,
      "x": 33060,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 133308,
      "e": 27734,
      "ty": 2,
      "x": 942,
      "y": 708
    },
    {
      "t": 133407,
      "e": 27833,
      "ty": 2,
      "x": 908,
      "y": 664
    },
    {
      "t": 133508,
      "e": 27934,
      "ty": 2,
      "x": 894,
      "y": 604
    },
    {
      "t": 133508,
      "e": 27934,
      "ty": 41,
      "x": 30511,
      "y": 33016,
      "ta": "html > body"
    },
    {
      "t": 133607,
      "e": 28033,
      "ty": 2,
      "x": 888,
      "y": 578
    },
    {
      "t": 133708,
      "e": 28134,
      "ty": 2,
      "x": 888,
      "y": 577
    },
    {
      "t": 133758,
      "e": 28184,
      "ty": 41,
      "x": 30305,
      "y": 31521,
      "ta": "html > body"
    },
    {
      "t": 133930,
      "e": 28356,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 134007,
      "e": 28433,
      "ty": 2,
      "x": 881,
      "y": 575
    },
    {
      "t": 134007,
      "e": 28433,
      "ty": 41,
      "x": 59706,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 134110,
      "e": 28536,
      "ty": 2,
      "x": 874,
      "y": 572
    },
    {
      "t": 134208,
      "e": 28634,
      "ty": 2,
      "x": 873,
      "y": 572
    },
    {
      "t": 134258,
      "e": 28684,
      "ty": 41,
      "x": 58833,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 134407,
      "e": 28833,
      "ty": 2,
      "x": 853,
      "y": 565
    },
    {
      "t": 134507,
      "e": 28933,
      "ty": 2,
      "x": 845,
      "y": 563
    },
    {
      "t": 134509,
      "e": 28935,
      "ty": 41,
      "x": 55780,
      "y": 28122,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 135106,
      "e": 29532,
      "ty": 2,
      "x": 843,
      "y": 558
    },
    {
      "t": 135207,
      "e": 29633,
      "ty": 2,
      "x": 840,
      "y": 553
    },
    {
      "t": 135258,
      "e": 29684,
      "ty": 41,
      "x": 26888,
      "y": 36129,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 135308,
      "e": 29734,
      "ty": 2,
      "x": 838,
      "y": 548
    },
    {
      "t": 135508,
      "e": 29934,
      "ty": 41,
      "x": 26790,
      "y": 35097,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 135607,
      "e": 30033,
      "ty": 2,
      "x": 837,
      "y": 544
    },
    {
      "t": 135757,
      "e": 30183,
      "ty": 41,
      "x": 26740,
      "y": 33033,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 136107,
      "e": 30533,
      "ty": 2,
      "x": 835,
      "y": 538
    },
    {
      "t": 136257,
      "e": 30683,
      "ty": 41,
      "x": 26642,
      "y": 29937,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 136407,
      "e": 30833,
      "ty": 2,
      "x": 834,
      "y": 537
    },
    {
      "t": 136508,
      "e": 30934,
      "ty": 41,
      "x": 26593,
      "y": 29421,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 136607,
      "e": 31033,
      "ty": 2,
      "x": 830,
      "y": 537
    },
    {
      "t": 136757,
      "e": 31183,
      "ty": 41,
      "x": 26396,
      "y": 29421,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 137257,
      "e": 31683,
      "ty": 41,
      "x": 26298,
      "y": 29421,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 137307,
      "e": 31733,
      "ty": 2,
      "x": 820,
      "y": 541
    },
    {
      "t": 137407,
      "e": 31833,
      "ty": 2,
      "x": 829,
      "y": 546
    },
    {
      "t": 137507,
      "e": 31933,
      "ty": 2,
      "x": 845,
      "y": 566
    },
    {
      "t": 137508,
      "e": 31934,
      "ty": 41,
      "x": 55780,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 137807,
      "e": 32233,
      "ty": 2,
      "x": 847,
      "y": 566
    },
    {
      "t": 137868,
      "e": 32294,
      "ty": 6,
      "x": 901,
      "y": 528,
      "ta": "#da1"
    },
    {
      "t": 137907,
      "e": 32333,
      "ty": 2,
      "x": 905,
      "y": 524
    },
    {
      "t": 138006,
      "e": 32432,
      "ty": 2,
      "x": 906,
      "y": 512
    },
    {
      "t": 138007,
      "e": 32433,
      "ty": 41,
      "x": 62500,
      "y": 51,
      "ta": "#da1"
    },
    {
      "t": 138018,
      "e": 32444,
      "ty": 7,
      "x": 906,
      "y": 511,
      "ta": "#da1"
    },
    {
      "t": 138107,
      "e": 32533,
      "ty": 2,
      "x": 898,
      "y": 478
    },
    {
      "t": 138207,
      "e": 32633,
      "ty": 2,
      "x": 888,
      "y": 448
    },
    {
      "t": 138257,
      "e": 32683,
      "ty": 41,
      "x": 29102,
      "y": 46828,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 138307,
      "e": 32733,
      "ty": 2,
      "x": 885,
      "y": 445
    },
    {
      "t": 138508,
      "e": 32934,
      "ty": 41,
      "x": 29102,
      "y": 45658,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 138606,
      "e": 33032,
      "ty": 2,
      "x": 879,
      "y": 445
    },
    {
      "t": 138707,
      "e": 33133,
      "ty": 2,
      "x": 832,
      "y": 439
    },
    {
      "t": 138757,
      "e": 33183,
      "ty": 41,
      "x": 26298,
      "y": 38637,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 138807,
      "e": 33233,
      "ty": 2,
      "x": 818,
      "y": 438
    },
    {
      "t": 138907,
      "e": 33333,
      "ty": 2,
      "x": 760,
      "y": 438
    },
    {
      "t": 139007,
      "e": 33433,
      "ty": 2,
      "x": 716,
      "y": 449
    },
    {
      "t": 139008,
      "e": 33434,
      "ty": 41,
      "x": 20788,
      "y": 50339,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 140007,
      "e": 34433,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140707,
      "e": 35133,
      "ty": 2,
      "x": 736,
      "y": 449
    },
    {
      "t": 140757,
      "e": 35183,
      "ty": 41,
      "x": 31611,
      "y": 58531,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 140807,
      "e": 35233,
      "ty": 2,
      "x": 985,
      "y": 460
    },
    {
      "t": 140907,
      "e": 35333,
      "ty": 2,
      "x": 1049,
      "y": 469
    },
    {
      "t": 141007,
      "e": 35433,
      "ty": 2,
      "x": 1079,
      "y": 482
    },
    {
      "t": 141008,
      "e": 35434,
      "ty": 41,
      "x": 38646,
      "y": 1040,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 141507,
      "e": 35933,
      "ty": 2,
      "x": 1078,
      "y": 483
    },
    {
      "t": 141507,
      "e": 35933,
      "ty": 41,
      "x": 38597,
      "y": 1556,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 141607,
      "e": 36033,
      "ty": 2,
      "x": 1046,
      "y": 485
    },
    {
      "t": 141757,
      "e": 36183,
      "ty": 41,
      "x": 37023,
      "y": 2588,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 149407,
      "e": 41183,
      "ty": 2,
      "x": 1016,
      "y": 456
    },
    {
      "t": 149508,
      "e": 41284,
      "ty": 2,
      "x": 1016,
      "y": 469
    },
    {
      "t": 149508,
      "e": 41284,
      "ty": 41,
      "x": 35547,
      "y": 9762,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 149562,
      "e": 41338,
      "ty": 6,
      "x": 1037,
      "y": 687,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 149578,
      "e": 41354,
      "ty": 7,
      "x": 1037,
      "y": 765,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 149578,
      "e": 41354,
      "ty": 6,
      "x": 1037,
      "y": 765,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 149595,
      "e": 41371,
      "ty": 7,
      "x": 1037,
      "y": 868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 149607,
      "e": 41383,
      "ty": 2,
      "x": 1037,
      "y": 868
    },
    {
      "t": 149707,
      "e": 41483,
      "ty": 2,
      "x": 1049,
      "y": 1055
    },
    {
      "t": 149758,
      "e": 41534,
      "ty": 41,
      "x": 37170,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149808,
      "e": 41584,
      "ty": 2,
      "x": 1049,
      "y": 1062
    },
    {
      "t": 149907,
      "e": 41683,
      "ty": 2,
      "x": 1032,
      "y": 1073
    },
    {
      "t": 149911,
      "e": 41687,
      "ty": 6,
      "x": 1020,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 150007,
      "e": 41783,
      "ty": 2,
      "x": 989,
      "y": 1082
    },
    {
      "t": 150007,
      "e": 41783,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150008,
      "e": 41784,
      "ty": 41,
      "x": 43416,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 150107,
      "e": 41883,
      "ty": 2,
      "x": 956,
      "y": 1090
    },
    {
      "t": 150208,
      "e": 41984,
      "ty": 2,
      "x": 952,
      "y": 1090
    },
    {
      "t": 150257,
      "e": 42033,
      "ty": 41,
      "x": 23210,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 150259,
      "e": 42035,
      "ty": 3,
      "x": 952,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 150260,
      "e": 42036,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 150353,
      "e": 42129,
      "ty": 4,
      "x": 23210,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 150354,
      "e": 42130,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 150355,
      "e": 42131,
      "ty": 5,
      "x": 952,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 150357,
      "e": 42133,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 150508,
      "e": 42284,
      "ty": 2,
      "x": 953,
      "y": 1088
    },
    {
      "t": 150508,
      "e": 42284,
      "ty": 41,
      "x": 32543,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 150607,
      "e": 42383,
      "ty": 2,
      "x": 1116,
      "y": 1084
    },
    {
      "t": 150758,
      "e": 42534,
      "ty": 41,
      "x": 38157,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 150908,
      "e": 42684,
      "ty": 2,
      "x": 1110,
      "y": 1077
    },
    {
      "t": 151010,
      "e": 42786,
      "ty": 2,
      "x": 1109,
      "y": 1061
    },
    {
      "t": 151010,
      "e": 42786,
      "ty": 41,
      "x": 37915,
      "y": 58333,
      "ta": "html > body"
    },
    {
      "t": 151107,
      "e": 42883,
      "ty": 2,
      "x": 1103,
      "y": 1051
    },
    {
      "t": 151208,
      "e": 42984,
      "ty": 2,
      "x": 1098,
      "y": 1037
    },
    {
      "t": 151257,
      "e": 43033,
      "ty": 41,
      "x": 37502,
      "y": 56837,
      "ta": "html > body"
    },
    {
      "t": 151307,
      "e": 43083,
      "ty": 2,
      "x": 1096,
      "y": 1033
    },
    {
      "t": 151358,
      "e": 43134,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 151507,
      "e": 43283,
      "ty": 41,
      "x": 37468,
      "y": 56782,
      "ta": "html > body"
    },
    {
      "t": 160008,
      "e": 48283,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 165424,
      "e": 48283,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 166430,
      "e": 48283,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 130, dom: 562, initialDom: 566",
  "javascriptErrors": []
}