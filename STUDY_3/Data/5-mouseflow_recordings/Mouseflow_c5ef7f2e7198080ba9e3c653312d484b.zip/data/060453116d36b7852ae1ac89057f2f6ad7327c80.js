var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060453116d36b7852ae1ac89057f2f6ad7327c80"] = {
  "startTime": "2018-06-04T19:20:53.159747Z",
  "websitePageUrl": "/16",
  "visitTime": 170098,
  "engagementTime": 102125,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c5ef7f2e7198080ba9e3c653312d484b",
    "created": "2018-06-04T19:20:53.159747+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=TZYD4",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d32ccced8e7d03431c09254fc0da13a5",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c5ef7f2e7198080ba9e3c653312d484b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 242,
      "e": 242,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 529,
      "y": 628
    },
    {
      "t": 947,
      "e": 947,
      "ty": 6,
      "x": 540,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 556,
      "y": 577
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 51585,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 591,
      "y": 560
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 55519,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6751,
      "e": 6501,
      "ty": 41,
      "x": 55632,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6800,
      "e": 6550,
      "ty": 2,
      "x": 592,
      "y": 559
    },
    {
      "t": 10001,
      "e": 9751,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10335,
      "e": 10085,
      "ty": 3,
      "x": 592,
      "y": 559,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10336,
      "e": 10086,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10484,
      "e": 10234,
      "ty": 4,
      "x": 55632,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10484,
      "e": 10234,
      "ty": 5,
      "x": 592,
      "y": 559,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12490,
      "e": 12240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12988,
      "e": 12738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13021,
      "e": 12771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13053,
      "e": 12803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13080,
      "e": 12830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13080,
      "e": 12830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13168,
      "e": 12918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 13176,
      "e": 12926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 13241,
      "e": 12991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13241,
      "e": 12991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13328,
      "e": 13078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13328,
      "e": 13078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13344,
      "e": 13094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 13344,
      "e": 13094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13376,
      "e": 13126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Finm"
    },
    {
      "t": 13392,
      "e": 13142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13400,
      "e": 13150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13425,
      "e": 13175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13425,
      "e": 13175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13511,
      "e": 13261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 13785,
      "e": 13535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13848,
      "e": 13598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Finm"
    },
    {
      "t": 13944,
      "e": 13694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14009,
      "e": 13759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 14793,
      "e": 14543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 14793,
      "e": 14543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14872,
      "e": 14622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find"
    },
    {
      "t": 14912,
      "e": 14662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14912,
      "e": 14662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15016,
      "e": 14766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15521,
      "e": 15271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 15522,
      "e": 15272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15608,
      "e": 15358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 15656,
      "e": 15406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15656,
      "e": 15406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15760,
      "e": 15510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15881,
      "e": 15631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15881,
      "e": 15631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15960,
      "e": 15710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15960,
      "e": 15710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15999,
      "e": 15749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 16080,
      "e": 15830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16088,
      "e": 15838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16088,
      "e": 15838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16176,
      "e": 15926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16281,
      "e": 16031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16281,
      "e": 16031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16384,
      "e": 16134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16384,
      "e": 16134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16432,
      "e": 16182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16433,
      "e": 16183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16439,
      "e": 16189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on "
    },
    {
      "t": 16464,
      "e": 16214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16544,
      "e": 16294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16600,
      "e": 16350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16601,
      "e": 16351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16687,
      "e": 16437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16712,
      "e": 16462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16712,
      "e": 16462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16784,
      "e": 16534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16816,
      "e": 16566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16817,
      "e": 16567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16904,
      "e": 16654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16905,
      "e": 16655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16936,
      "e": 16686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 17040,
      "e": 16790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17945,
      "e": 17695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17945,
      "e": 17695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18016,
      "e": 17766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18409,
      "e": 18159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18409,
      "e": 18159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18464,
      "e": 18214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18602,
      "e": 18352,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-"
    },
    {
      "t": 18608,
      "e": 18358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18609,
      "e": 18359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18712,
      "e": 18462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19113,
      "e": 18863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19113,
      "e": 18863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19184,
      "e": 18934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19304,
      "e": 19054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19305,
      "e": 19055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19344,
      "e": 19094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19385,
      "e": 19135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19385,
      "e": 19135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19472,
      "e": 19222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20001,
      "e": 19751,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20353,
      "e": 20103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 20353,
      "e": 20103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20455,
      "e": 20205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 20536,
      "e": 20286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20536,
      "e": 20286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20633,
      "e": 20383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20777,
      "e": 20527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21088,
      "e": 20838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21089,
      "e": 20839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21168,
      "e": 20918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 21176,
      "e": 20926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21200,
      "e": 20950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21200,
      "e": 20950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21256,
      "e": 21006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21329,
      "e": 21079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21330,
      "e": 21080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21416,
      "e": 21166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21416,
      "e": 21166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21416,
      "e": 21166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21472,
      "e": 21222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21472,
      "e": 21222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21504,
      "e": 21254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 21584,
      "e": 21334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21625,
      "e": 21375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21625,
      "e": 21375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21713,
      "e": 21463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 21800,
      "e": 21550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21801,
      "e": 21551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21840,
      "e": 21590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21840,
      "e": 21590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21896,
      "e": 21646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 21936,
      "e": 21686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21936,
      "e": 21686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21992,
      "e": 21742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21992,
      "e": 21742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22000,
      "e": 21750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 22024,
      "e": 21774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22097,
      "e": 21847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22169,
      "e": 21919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22170,
      "e": 21920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22256,
      "e": 22006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22296,
      "e": 22046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22296,
      "e": 22046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22360,
      "e": 22110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22385,
      "e": 22135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22385,
      "e": 22135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22464,
      "e": 22214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22464,
      "e": 22214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22472,
      "e": 22222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 22601,
      "e": 22351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22601,
      "e": 22351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22648,
      "e": 22398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22697,
      "e": 22447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24800,
      "e": 24550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24801,
      "e": 24551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24919,
      "e": 24669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25192,
      "e": 24942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25192,
      "e": 24942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25305,
      "e": 25055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25449,
      "e": 25199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25449,
      "e": 25199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25543,
      "e": 25293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25752,
      "e": 25502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25832,
      "e": 25582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there g"
    },
    {
      "t": 25888,
      "e": 25638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25984,
      "e": 25734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there "
    },
    {
      "t": 26472,
      "e": 26222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26474,
      "e": 26224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26583,
      "e": 26333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26648,
      "e": 26398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26649,
      "e": 26399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26721,
      "e": 26471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26840,
      "e": 26590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26842,
      "e": 26592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26896,
      "e": 26646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27000,
      "e": 26750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27000,
      "e": 26750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27048,
      "e": 26798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27152,
      "e": 26902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27152,
      "e": 26902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27248,
      "e": 26998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27249,
      "e": 26999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 27250,
      "e": 27000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27345,
      "e": 27095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27345,
      "e": 27095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27352,
      "e": 27102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w "
    },
    {
      "t": 27424,
      "e": 27174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27456,
      "e": 27206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27456,
      "e": 27206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27544,
      "e": 27294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27568,
      "e": 27318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27569,
      "e": 27319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27623,
      "e": 27373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27671,
      "e": 27421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27672,
      "e": 27422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27752,
      "e": 27502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27752,
      "e": 27502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27760,
      "e": 27510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 27863,
      "e": 27613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27952,
      "e": 27702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27953,
      "e": 27703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28057,
      "e": 27807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 28104,
      "e": 27854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28105,
      "e": 27855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28184,
      "e": 27934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28184,
      "e": 27934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28192,
      "e": 27942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ia"
    },
    {
      "t": 28304,
      "e": 28054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28400,
      "e": 28150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28400,
      "e": 28150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28473,
      "e": 28223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 28600,
      "e": 28350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28600,
      "e": 28350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28744,
      "e": 28494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28745,
      "e": 28495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28783,
      "e": 28533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 28832,
      "e": 28582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28872,
      "e": 28622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28872,
      "e": 28622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28984,
      "e": 28734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28985,
      "e": 28735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28991,
      "e": 28741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 29104,
      "e": 28741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29104,
      "e": 28741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29111,
      "e": 28748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29200,
      "e": 28837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29361,
      "e": 28998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29361,
      "e": 28998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29448,
      "e": 29085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 29536,
      "e": 29173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29536,
      "e": 29173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29648,
      "e": 29285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29680,
      "e": 29317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29681,
      "e": 29318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29768,
      "e": 29405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29785,
      "e": 29422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29785,
      "e": 29422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29872,
      "e": 29509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29912,
      "e": 29549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29913,
      "e": 29550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 29637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30152,
      "e": 29789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30152,
      "e": 29789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30224,
      "e": 29861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30248,
      "e": 29885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30248,
      "e": 29885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30312,
      "e": 29949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30328,
      "e": 29965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30328,
      "e": 29965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30384,
      "e": 30021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30385,
      "e": 30022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30424,
      "e": 30061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 30480,
      "e": 30117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30681,
      "e": 30318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30681,
      "e": 30318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30776,
      "e": 30413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31393,
      "e": 31030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31393,
      "e": 31030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31464,
      "e": 31101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 31512,
      "e": 31149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31512,
      "e": 31149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31591,
      "e": 31228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31600,
      "e": 31237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31601,
      "e": 31238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31672,
      "e": 31309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31761,
      "e": 31398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31761,
      "e": 31398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31872,
      "e": 31509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 31887,
      "e": 31524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31887,
      "e": 31524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31992,
      "e": 31629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32120,
      "e": 31757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32121,
      "e": 31758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32256,
      "e": 31893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32256,
      "e": 31893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32296,
      "e": 31933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 32392,
      "e": 32029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33040,
      "e": 32677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33042,
      "e": 32679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33112,
      "e": 32749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 33208,
      "e": 32845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33208,
      "e": 32845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33288,
      "e": 32925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33320,
      "e": 32957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33322,
      "e": 32959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33410,
      "e": 33047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 33449,
      "e": 33086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33449,
      "e": 33086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33519,
      "e": 33156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33520,
      "e": 33157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33528,
      "e": 33165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 33607,
      "e": 33244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33688,
      "e": 33325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33689,
      "e": 33326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33799,
      "e": 33436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33952,
      "e": 33589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33955,
      "e": 33592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34016,
      "e": 33653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34128,
      "e": 33765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34128,
      "e": 33765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34192,
      "e": 33829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34193,
      "e": 33830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34216,
      "e": 33853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 34305,
      "e": 33942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34305,
      "e": 33942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34360,
      "e": 33997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 34408,
      "e": 34045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34408,
      "e": 34045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34408,
      "e": 34045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34504,
      "e": 34141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34504,
      "e": 34141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34512,
      "e": 34149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 34577,
      "e": 34214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34640,
      "e": 34277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34641,
      "e": 34278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34688,
      "e": 34325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34793,
      "e": 34430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34793,
      "e": 34430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34936,
      "e": 34573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34937,
      "e": 34574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34944,
      "e": 34581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 35023,
      "e": 34660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35104,
      "e": 34741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35104,
      "e": 34741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35217,
      "e": 34854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35536,
      "e": 35173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35537,
      "e": 35174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35664,
      "e": 35301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35664,
      "e": 35301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35671,
      "e": 35308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 35752,
      "e": 35389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35753,
      "e": 35390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35783,
      "e": 35420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35785,
      "e": 35422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35791,
      "e": 35428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 35888,
      "e": 35525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35891,
      "e": 35528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35891,
      "e": 35528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35928,
      "e": 35565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35984,
      "e": 35621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40000,
      "e": 39637,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 47929,
      "e": 40621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48015,
      "e": 40707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that poin"
    },
    {
      "t": 48783,
      "e": 41475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48784,
      "e": 41476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48856,
      "e": 41548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48944,
      "e": 41636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 48945,
      "e": 41637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49023,
      "e": 41715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 49095,
      "e": 41787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49096,
      "e": 41788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49184,
      "e": 41876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49239,
      "e": 41931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 49415,
      "e": 42107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49416,
      "e": 42108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49528,
      "e": 42220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 49536,
      "e": 42228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49600,
      "e": 42292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49600,
      "e": 42292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49671,
      "e": 42363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 49792,
      "e": 42484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 49792,
      "e": 42484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49856,
      "e": 42548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49857,
      "e": 42549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49864,
      "e": 42556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 49951,
      "e": 42643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50063,
      "e": 42755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50063,
      "e": 42755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50127,
      "e": 42819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 50239,
      "e": 42931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50240,
      "e": 42932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50368,
      "e": 43060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50368,
      "e": 43060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50423,
      "e": 43115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 50431,
      "e": 43123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50432,
      "e": 43124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50487,
      "e": 43179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50535,
      "e": 43227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50536,
      "e": 43228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50543,
      "e": 43235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50600,
      "e": 43292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50688,
      "e": 43380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50689,
      "e": 43381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50775,
      "e": 43467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50896,
      "e": 43588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50896,
      "e": 43588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50975,
      "e": 43667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51039,
      "e": 43731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51040,
      "e": 43732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51095,
      "e": 43787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51096,
      "e": 43788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51096,
      "e": 43788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51192,
      "e": 43884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51192,
      "e": 43884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51231,
      "e": 43923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 51271,
      "e": 43963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51448,
      "e": 44140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51448,
      "e": 44140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51575,
      "e": 44267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52440,
      "e": 45132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 52440,
      "e": 45132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52567,
      "e": 45259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52567,
      "e": 45259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52575,
      "e": 45267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fa"
    },
    {
      "t": 52696,
      "e": 45388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52704,
      "e": 45396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52705,
      "e": 45397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52767,
      "e": 45459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52856,
      "e": 45548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52857,
      "e": 45549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52951,
      "e": 45643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52959,
      "e": 45651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 52959,
      "e": 45651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53063,
      "e": 45755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53080,
      "e": 45772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53080,
      "e": 45772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53175,
      "e": 45867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53279,
      "e": 45971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53280,
      "e": 45972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53392,
      "e": 46084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53392,
      "e": 46084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53447,
      "e": 46139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 53487,
      "e": 46179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53488,
      "e": 46180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53512,
      "e": 46204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53592,
      "e": 46284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53616,
      "e": 46308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53617,
      "e": 46309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53695,
      "e": 46387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53728,
      "e": 46420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53728,
      "e": 46420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53799,
      "e": 46491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53800,
      "e": 46492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53807,
      "e": 46499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 53879,
      "e": 46571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53880,
      "e": 46572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53952,
      "e": 46644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53992,
      "e": 46684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54032,
      "e": 46724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54033,
      "e": 46725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54127,
      "e": 46819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54304,
      "e": 46996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 54304,
      "e": 46996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54367,
      "e": 47059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 54504,
      "e": 47196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54505,
      "e": 47197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54601,
      "e": 47293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54601,
      "e": 47293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54663,
      "e": 47355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 54703,
      "e": 47395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54735,
      "e": 47427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54735,
      "e": 47427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54848,
      "e": 47540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54911,
      "e": 47603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54913,
      "e": 47605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55016,
      "e": 47708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56031,
      "e": 48723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 56032,
      "e": 48724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56120,
      "e": 48812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 56216,
      "e": 48908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56217,
      "e": 48909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56295,
      "e": 48987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56312,
      "e": 49004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56312,
      "e": 49004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56456,
      "e": 49148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 56456,
      "e": 49148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56463,
      "e": 49155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 56536,
      "e": 49228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56664,
      "e": 49356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56664,
      "e": 49356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56736,
      "e": 49428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57152,
      "e": 49844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57152,
      "e": 49844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57263,
      "e": 49955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 57335,
      "e": 50027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57335,
      "e": 50027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57424,
      "e": 50116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57479,
      "e": 50171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57480,
      "e": 50172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57591,
      "e": 50283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57615,
      "e": 50307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57615,
      "e": 50307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57695,
      "e": 50387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57767,
      "e": 50459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57769,
      "e": 50461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57863,
      "e": 50555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58224,
      "e": 50916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 58225,
      "e": 50917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58312,
      "e": 51004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 58455,
      "e": 51147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 58456,
      "e": 51148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58543,
      "e": 51235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 58615,
      "e": 51307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58615,
      "e": 51307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58687,
      "e": 51379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58803,
      "e": 51495,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12 "
    },
    {
      "t": 59032,
      "e": 51724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59119,
      "e": 51811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12"
    },
    {
      "t": 59325,
      "e": 52017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59325,
      "e": 52017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59412,
      "e": 52104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 59413,
      "e": 52105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59461,
      "e": 52153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 59541,
      "e": 52233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59901,
      "e": 52593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59957,
      "e": 52649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12o"
    },
    {
      "t": 60053,
      "e": 52745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 60116,
      "e": 52808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12"
    },
    {
      "t": 60685,
      "e": 53377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 60685,
      "e": 53377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60781,
      "e": 53473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 60781,
      "e": 53473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60844,
      "e": 53536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p,"
    },
    {
      "t": 60876,
      "e": 53568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61717,
      "e": 54409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61796,
      "e": 54409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12p"
    },
    {
      "t": 62021,
      "e": 54634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 62022,
      "e": 54635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62092,
      "e": 54705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 62200,
      "e": 54813,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12pm"
    },
    {
      "t": 64845,
      "e": 57458,
      "ty": 7,
      "x": 540,
      "y": 628,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64898,
      "e": 57511,
      "ty": 2,
      "x": 429,
      "y": 712
    },
    {
      "t": 64997,
      "e": 57610,
      "ty": 2,
      "x": 391,
      "y": 721
    },
    {
      "t": 64997,
      "e": 57610,
      "ty": 41,
      "x": 33893,
      "y": 65053,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 65097,
      "e": 57710,
      "ty": 2,
      "x": 390,
      "y": 716
    },
    {
      "t": 65145,
      "e": 57758,
      "ty": 6,
      "x": 428,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 65197,
      "e": 57810,
      "ty": 2,
      "x": 436,
      "y": 670
    },
    {
      "t": 65248,
      "e": 57861,
      "ty": 41,
      "x": 53195,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 65298,
      "e": 57911,
      "ty": 2,
      "x": 443,
      "y": 658
    },
    {
      "t": 65385,
      "e": 57998,
      "ty": 3,
      "x": 443,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 65387,
      "e": 58000,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12pm"
    },
    {
      "t": 65388,
      "e": 58001,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65389,
      "e": 58002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 65498,
      "e": 58111,
      "ty": 41,
      "x": 57018,
      "y": 6294,
      "ta": "#strategyButton"
    },
    {
      "t": 65521,
      "e": 58134,
      "ty": 4,
      "x": 57018,
      "y": 6294,
      "ta": "#strategyButton"
    },
    {
      "t": 65531,
      "e": 58144,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 65532,
      "e": 58145,
      "ty": 5,
      "x": 443,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 65540,
      "e": 58153,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 65598,
      "e": 58211,
      "ty": 2,
      "x": 442,
      "y": 658
    },
    {
      "t": 65698,
      "e": 58311,
      "ty": 2,
      "x": 432,
      "y": 663
    },
    {
      "t": 65748,
      "e": 58361,
      "ty": 41,
      "x": 14601,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 65998,
      "e": 58611,
      "ty": 2,
      "x": 441,
      "y": 660
    },
    {
      "t": 65998,
      "e": 58611,
      "ty": 41,
      "x": 14911,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 66097,
      "e": 58710,
      "ty": 2,
      "x": 450,
      "y": 658
    },
    {
      "t": 66248,
      "e": 58861,
      "ty": 41,
      "x": 15221,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 66298,
      "e": 58911,
      "ty": 2,
      "x": 451,
      "y": 658
    },
    {
      "t": 66499,
      "e": 59112,
      "ty": 41,
      "x": 15255,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 66540,
      "e": 59153,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 66698,
      "e": 59311,
      "ty": 2,
      "x": 459,
      "y": 658
    },
    {
      "t": 66748,
      "e": 59361,
      "ty": 41,
      "x": 15738,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 66798,
      "e": 59411,
      "ty": 2,
      "x": 467,
      "y": 662
    },
    {
      "t": 66897,
      "e": 59510,
      "ty": 2,
      "x": 642,
      "y": 681
    },
    {
      "t": 66931,
      "e": 59544,
      "ty": 6,
      "x": 937,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66948,
      "e": 59561,
      "ty": 7,
      "x": 1056,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66997,
      "e": 59610,
      "ty": 2,
      "x": 1288,
      "y": 680
    },
    {
      "t": 66997,
      "e": 59610,
      "ty": 41,
      "x": 44080,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 67098,
      "e": 59711,
      "ty": 2,
      "x": 1296,
      "y": 678
    },
    {
      "t": 67197,
      "e": 59810,
      "ty": 2,
      "x": 1184,
      "y": 621
    },
    {
      "t": 67247,
      "e": 59860,
      "ty": 41,
      "x": 65318,
      "y": 9160,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67298,
      "e": 59911,
      "ty": 2,
      "x": 1083,
      "y": 587
    },
    {
      "t": 67398,
      "e": 60011,
      "ty": 2,
      "x": 1058,
      "y": 578
    },
    {
      "t": 67431,
      "e": 60044,
      "ty": 6,
      "x": 1051,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67498,
      "e": 60111,
      "ty": 2,
      "x": 1035,
      "y": 564
    },
    {
      "t": 67498,
      "e": 60111,
      "ty": 41,
      "x": 49097,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67665,
      "e": 60278,
      "ty": 3,
      "x": 1035,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67665,
      "e": 60278,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67761,
      "e": 60374,
      "ty": 4,
      "x": 49097,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67761,
      "e": 60374,
      "ty": 5,
      "x": 1035,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68614,
      "e": 61227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 68614,
      "e": 61227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68668,
      "e": 61281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 68757,
      "e": 61370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 68757,
      "e": 61370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68828,
      "e": 61441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 69566,
      "e": 62179,
      "ty": 7,
      "x": 1035,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69598,
      "e": 62211,
      "ty": 2,
      "x": 1033,
      "y": 578
    },
    {
      "t": 69698,
      "e": 62311,
      "ty": 2,
      "x": 1044,
      "y": 623
    },
    {
      "t": 69717,
      "e": 62312,
      "ty": 6,
      "x": 1053,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69748,
      "e": 62343,
      "ty": 41,
      "x": 54071,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69798,
      "e": 62393,
      "ty": 2,
      "x": 1061,
      "y": 667
    },
    {
      "t": 69799,
      "e": 62394,
      "ty": 7,
      "x": 1064,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69898,
      "e": 62493,
      "ty": 2,
      "x": 1074,
      "y": 687
    },
    {
      "t": 69998,
      "e": 62593,
      "ty": 2,
      "x": 1076,
      "y": 684
    },
    {
      "t": 69998,
      "e": 62593,
      "ty": 41,
      "x": 36779,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 70098,
      "e": 62693,
      "ty": 2,
      "x": 1081,
      "y": 670
    },
    {
      "t": 70198,
      "e": 62793,
      "ty": 2,
      "x": 1082,
      "y": 669
    },
    {
      "t": 70241,
      "e": 62836,
      "ty": 3,
      "x": 1082,
      "y": 669,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70241,
      "e": 62836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 70241,
      "e": 62836,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70248,
      "e": 62843,
      "ty": 41,
      "x": 59262,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70296,
      "e": 62891,
      "ty": 4,
      "x": 59262,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70297,
      "e": 62892,
      "ty": 5,
      "x": 1082,
      "y": 669,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70490,
      "e": 63085,
      "ty": 6,
      "x": 1082,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70498,
      "e": 63093,
      "ty": 2,
      "x": 1082,
      "y": 665
    },
    {
      "t": 70499,
      "e": 63094,
      "ty": 41,
      "x": 59262,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70597,
      "e": 63192,
      "ty": 2,
      "x": 1086,
      "y": 652
    },
    {
      "t": 70690,
      "e": 63285,
      "ty": 3,
      "x": 1086,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70690,
      "e": 63285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70749,
      "e": 63344,
      "ty": 41,
      "x": 60127,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70769,
      "e": 63364,
      "ty": 4,
      "x": 60127,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70769,
      "e": 63364,
      "ty": 5,
      "x": 1086,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71749,
      "e": 64344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 71884,
      "e": 64479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 71886,
      "e": 64481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71949,
      "e": 64544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 71957,
      "e": 64552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 72061,
      "e": 64656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 72061,
      "e": 64656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72148,
      "e": 64743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 72148,
      "e": 64743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72180,
      "e": 64775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 72261,
      "e": 64856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 72276,
      "e": 64871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 72277,
      "e": 64872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72357,
      "e": 64952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 72397,
      "e": 64992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 72398,
      "e": 64993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72476,
      "e": 65071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 72612,
      "e": 65207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 72612,
      "e": 65207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72701,
      "e": 65296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 72741,
      "e": 65336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 72741,
      "e": 65336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72853,
      "e": 65448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 72949,
      "e": 65544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 73316,
      "e": 65911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 73318,
      "e": 65913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73372,
      "e": 65967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 73404,
      "e": 65999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 73684,
      "e": 66279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 73685,
      "e": 66280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73757,
      "e": 66352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 73805,
      "e": 66400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 73806,
      "e": 66401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73965,
      "e": 66560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 73965,
      "e": 66560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73972,
      "e": 66567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 74076,
      "e": 66671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74124,
      "e": 66719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 74125,
      "e": 66720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74180,
      "e": 66775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 74636,
      "e": 67231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 74638,
      "e": 67233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74732,
      "e": 67327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 75898,
      "e": 68493,
      "ty": 2,
      "x": 1078,
      "y": 656
    },
    {
      "t": 75905,
      "e": 68500,
      "ty": 7,
      "x": 1066,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75999,
      "e": 68594,
      "ty": 2,
      "x": 1055,
      "y": 688
    },
    {
      "t": 75999,
      "e": 68594,
      "ty": 41,
      "x": 36056,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 76098,
      "e": 68693,
      "ty": 2,
      "x": 1055,
      "y": 689
    },
    {
      "t": 76198,
      "e": 68793,
      "ty": 2,
      "x": 1050,
      "y": 689
    },
    {
      "t": 76248,
      "e": 68843,
      "ty": 41,
      "x": 35574,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 76298,
      "e": 68893,
      "ty": 2,
      "x": 1026,
      "y": 687
    },
    {
      "t": 76306,
      "e": 68901,
      "ty": 6,
      "x": 1011,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76399,
      "e": 68994,
      "ty": 2,
      "x": 1001,
      "y": 689
    },
    {
      "t": 76434,
      "e": 69029,
      "ty": 3,
      "x": 1001,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76434,
      "e": 69029,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 76435,
      "e": 69030,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76435,
      "e": 69030,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76498,
      "e": 69093,
      "ty": 41,
      "x": 54156,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76560,
      "e": 69155,
      "ty": 4,
      "x": 54156,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76560,
      "e": 69155,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76561,
      "e": 69156,
      "ty": 5,
      "x": 1001,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76561,
      "e": 69156,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 77580,
      "e": 70175,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 78097,
      "e": 70692,
      "ty": 2,
      "x": 1199,
      "y": 794
    },
    {
      "t": 78197,
      "e": 70792,
      "ty": 2,
      "x": 1572,
      "y": 1004
    },
    {
      "t": 78248,
      "e": 70843,
      "ty": 41,
      "x": 56340,
      "y": 55563,
      "ta": "html > body"
    },
    {
      "t": 78297,
      "e": 70892,
      "ty": 2,
      "x": 1674,
      "y": 969
    },
    {
      "t": 78498,
      "e": 71093,
      "ty": 41,
      "x": 57373,
      "y": 53236,
      "ta": "html > body"
    },
    {
      "t": 78797,
      "e": 71392,
      "ty": 2,
      "x": 1676,
      "y": 968
    },
    {
      "t": 78897,
      "e": 71492,
      "ty": 2,
      "x": 1402,
      "y": 707
    },
    {
      "t": 78997,
      "e": 71592,
      "ty": 2,
      "x": 1085,
      "y": 444
    },
    {
      "t": 78997,
      "e": 71592,
      "ty": 41,
      "x": 62553,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 79098,
      "e": 71693,
      "ty": 2,
      "x": 1062,
      "y": 413
    },
    {
      "t": 79197,
      "e": 71792,
      "ty": 2,
      "x": 983,
      "y": 337
    },
    {
      "t": 79247,
      "e": 71842,
      "ty": 41,
      "x": 33715,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 79298,
      "e": 71893,
      "ty": 2,
      "x": 911,
      "y": 282
    },
    {
      "t": 79397,
      "e": 71992,
      "ty": 2,
      "x": 886,
      "y": 265
    },
    {
      "t": 79498,
      "e": 72093,
      "ty": 2,
      "x": 879,
      "y": 261
    },
    {
      "t": 79498,
      "e": 72093,
      "ty": 41,
      "x": 43852,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 79597,
      "e": 72192,
      "ty": 2,
      "x": 878,
      "y": 261
    },
    {
      "t": 79748,
      "e": 72343,
      "ty": 41,
      "x": 43091,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 79754,
      "e": 72349,
      "ty": 3,
      "x": 878,
      "y": 261,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 79848,
      "e": 72443,
      "ty": 4,
      "x": 43091,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 79848,
      "e": 72443,
      "ty": 5,
      "x": 878,
      "y": 261,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 79849,
      "e": 72444,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79850,
      "e": 72445,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 80397,
      "e": 72992,
      "ty": 2,
      "x": 891,
      "y": 273
    },
    {
      "t": 80497,
      "e": 73092,
      "ty": 2,
      "x": 916,
      "y": 322
    },
    {
      "t": 80497,
      "e": 73092,
      "ty": 41,
      "x": 22445,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 80598,
      "e": 73193,
      "ty": 2,
      "x": 933,
      "y": 349
    },
    {
      "t": 80697,
      "e": 73292,
      "ty": 2,
      "x": 935,
      "y": 353
    },
    {
      "t": 80748,
      "e": 73343,
      "ty": 41,
      "x": 26954,
      "y": 14347,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80797,
      "e": 73392,
      "ty": 2,
      "x": 935,
      "y": 354
    },
    {
      "t": 80998,
      "e": 73593,
      "ty": 2,
      "x": 903,
      "y": 305
    },
    {
      "t": 80998,
      "e": 73593,
      "ty": 41,
      "x": 19360,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 81098,
      "e": 73693,
      "ty": 2,
      "x": 869,
      "y": 256
    },
    {
      "t": 81198,
      "e": 73793,
      "ty": 2,
      "x": 864,
      "y": 249
    },
    {
      "t": 81247,
      "e": 73842,
      "ty": 41,
      "x": 33228,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81297,
      "e": 73892,
      "ty": 2,
      "x": 862,
      "y": 244
    },
    {
      "t": 81344,
      "e": 73939,
      "ty": 3,
      "x": 862,
      "y": 244,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81344,
      "e": 73939,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81465,
      "e": 74060,
      "ty": 4,
      "x": 33228,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81465,
      "e": 74060,
      "ty": 5,
      "x": 862,
      "y": 244,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81466,
      "e": 74061,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 81468,
      "e": 74063,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 81497,
      "e": 74092,
      "ty": 41,
      "x": 33228,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 81998,
      "e": 74593,
      "ty": 2,
      "x": 861,
      "y": 244
    },
    {
      "t": 81998,
      "e": 74593,
      "ty": 41,
      "x": 32409,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 82198,
      "e": 74793,
      "ty": 2,
      "x": 860,
      "y": 245
    },
    {
      "t": 82247,
      "e": 74842,
      "ty": 41,
      "x": 8206,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 82298,
      "e": 74893,
      "ty": 2,
      "x": 855,
      "y": 257
    },
    {
      "t": 82398,
      "e": 74993,
      "ty": 2,
      "x": 854,
      "y": 257
    },
    {
      "t": 82489,
      "e": 75084,
      "ty": 3,
      "x": 854,
      "y": 257,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 82490,
      "e": 75085,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 82497,
      "e": 75092,
      "ty": 41,
      "x": 24812,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 82600,
      "e": 75195,
      "ty": 4,
      "x": 24812,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 82600,
      "e": 75195,
      "ty": 5,
      "x": 854,
      "y": 257,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 82600,
      "e": 75195,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 82601,
      "e": 75196,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 82897,
      "e": 75492,
      "ty": 2,
      "x": 865,
      "y": 315
    },
    {
      "t": 82997,
      "e": 75592,
      "ty": 2,
      "x": 883,
      "y": 368
    },
    {
      "t": 82998,
      "e": 75593,
      "ty": 41,
      "x": 14614,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 83097,
      "e": 75692,
      "ty": 2,
      "x": 883,
      "y": 369
    },
    {
      "t": 83248,
      "e": 75843,
      "ty": 41,
      "x": 14614,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 83397,
      "e": 75992,
      "ty": 2,
      "x": 881,
      "y": 375
    },
    {
      "t": 83497,
      "e": 76092,
      "ty": 2,
      "x": 857,
      "y": 408
    },
    {
      "t": 83498,
      "e": 76093,
      "ty": 41,
      "x": 41647,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 83577,
      "e": 76172,
      "ty": 6,
      "x": 836,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 83597,
      "e": 76192,
      "ty": 2,
      "x": 836,
      "y": 472
    },
    {
      "t": 83610,
      "e": 76205,
      "ty": 7,
      "x": 834,
      "y": 482,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 83629,
      "e": 76206,
      "ty": 6,
      "x": 833,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 83644,
      "e": 76221,
      "ty": 7,
      "x": 832,
      "y": 511,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 83661,
      "e": 76238,
      "ty": 6,
      "x": 829,
      "y": 525,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 83677,
      "e": 76254,
      "ty": 7,
      "x": 828,
      "y": 534,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 83697,
      "e": 76274,
      "ty": 2,
      "x": 828,
      "y": 540
    },
    {
      "t": 83748,
      "e": 76325,
      "ty": 41,
      "x": 1561,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 83797,
      "e": 76374,
      "ty": 2,
      "x": 828,
      "y": 542
    },
    {
      "t": 83861,
      "e": 76438,
      "ty": 6,
      "x": 839,
      "y": 522,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 83876,
      "e": 76453,
      "ty": 7,
      "x": 843,
      "y": 506,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 83897,
      "e": 76474,
      "ty": 2,
      "x": 845,
      "y": 492
    },
    {
      "t": 83998,
      "e": 76575,
      "ty": 2,
      "x": 851,
      "y": 470
    },
    {
      "t": 83998,
      "e": 76575,
      "ty": 41,
      "x": 31264,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 84097,
      "e": 76674,
      "ty": 2,
      "x": 855,
      "y": 460
    },
    {
      "t": 84197,
      "e": 76774,
      "ty": 2,
      "x": 879,
      "y": 428
    },
    {
      "t": 84248,
      "e": 76825,
      "ty": 41,
      "x": 15088,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 84297,
      "e": 76874,
      "ty": 2,
      "x": 886,
      "y": 417
    },
    {
      "t": 84397,
      "e": 76974,
      "ty": 2,
      "x": 899,
      "y": 404
    },
    {
      "t": 84498,
      "e": 77075,
      "ty": 2,
      "x": 935,
      "y": 380
    },
    {
      "t": 84498,
      "e": 77075,
      "ty": 41,
      "x": 26954,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 84598,
      "e": 77175,
      "ty": 2,
      "x": 968,
      "y": 365
    },
    {
      "t": 84697,
      "e": 77274,
      "ty": 2,
      "x": 969,
      "y": 364
    },
    {
      "t": 84747,
      "e": 77324,
      "ty": 41,
      "x": 28141,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 84797,
      "e": 77374,
      "ty": 2,
      "x": 899,
      "y": 398
    },
    {
      "t": 84898,
      "e": 77475,
      "ty": 2,
      "x": 867,
      "y": 449
    },
    {
      "t": 84997,
      "e": 77574,
      "ty": 2,
      "x": 860,
      "y": 489
    },
    {
      "t": 84997,
      "e": 77574,
      "ty": 41,
      "x": 34625,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85098,
      "e": 77675,
      "ty": 2,
      "x": 858,
      "y": 505
    },
    {
      "t": 85197,
      "e": 77774,
      "ty": 2,
      "x": 857,
      "y": 508
    },
    {
      "t": 85247,
      "e": 77824,
      "ty": 41,
      "x": 31933,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85498,
      "e": 78075,
      "ty": 2,
      "x": 857,
      "y": 502
    },
    {
      "t": 85498,
      "e": 78075,
      "ty": 41,
      "x": 31933,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85536,
      "e": 78113,
      "ty": 3,
      "x": 857,
      "y": 502,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85538,
      "e": 78115,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 85639,
      "e": 78216,
      "ty": 4,
      "x": 31933,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85640,
      "e": 78217,
      "ty": 5,
      "x": 857,
      "y": 502,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 85640,
      "e": 78217,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 85641,
      "e": 78218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 86097,
      "e": 78674,
      "ty": 2,
      "x": 1052,
      "y": 604
    },
    {
      "t": 86197,
      "e": 78774,
      "ty": 2,
      "x": 1053,
      "y": 604
    },
    {
      "t": 86247,
      "e": 78824,
      "ty": 41,
      "x": 54959,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86398,
      "e": 78975,
      "ty": 2,
      "x": 1117,
      "y": 644
    },
    {
      "t": 86497,
      "e": 79074,
      "ty": 2,
      "x": 1270,
      "y": 710
    },
    {
      "t": 86498,
      "e": 79075,
      "ty": 41,
      "x": 43460,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 86597,
      "e": 79174,
      "ty": 2,
      "x": 1295,
      "y": 718
    },
    {
      "t": 86748,
      "e": 79325,
      "ty": 41,
      "x": 44321,
      "y": 39332,
      "ta": "html > body"
    },
    {
      "t": 87397,
      "e": 79974,
      "ty": 2,
      "x": 1133,
      "y": 693
    },
    {
      "t": 87498,
      "e": 80075,
      "ty": 2,
      "x": 893,
      "y": 654
    },
    {
      "t": 87498,
      "e": 80075,
      "ty": 41,
      "x": 16987,
      "y": 10561,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 87597,
      "e": 80174,
      "ty": 2,
      "x": 870,
      "y": 653
    },
    {
      "t": 87698,
      "e": 80275,
      "ty": 2,
      "x": 866,
      "y": 653
    },
    {
      "t": 87748,
      "e": 80325,
      "ty": 41,
      "x": 10579,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 87899,
      "e": 80476,
      "ty": 2,
      "x": 866,
      "y": 668
    },
    {
      "t": 87998,
      "e": 80575,
      "ty": 2,
      "x": 872,
      "y": 702
    },
    {
      "t": 87998,
      "e": 80575,
      "ty": 41,
      "x": 12744,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 88097,
      "e": 80674,
      "ty": 2,
      "x": 872,
      "y": 705
    },
    {
      "t": 88198,
      "e": 80775,
      "ty": 2,
      "x": 872,
      "y": 716
    },
    {
      "t": 88248,
      "e": 80825,
      "ty": 41,
      "x": 12003,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 88598,
      "e": 81175,
      "ty": 2,
      "x": 863,
      "y": 716
    },
    {
      "t": 88698,
      "e": 81275,
      "ty": 2,
      "x": 857,
      "y": 716
    },
    {
      "t": 88748,
      "e": 81325,
      "ty": 41,
      "x": 8443,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 88798,
      "e": 81375,
      "ty": 2,
      "x": 856,
      "y": 716
    },
    {
      "t": 88898,
      "e": 81475,
      "ty": 2,
      "x": 856,
      "y": 719
    },
    {
      "t": 88998,
      "e": 81575,
      "ty": 2,
      "x": 853,
      "y": 730
    },
    {
      "t": 88999,
      "e": 81576,
      "ty": 41,
      "x": 7925,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 89098,
      "e": 81675,
      "ty": 2,
      "x": 852,
      "y": 730
    },
    {
      "t": 89198,
      "e": 81775,
      "ty": 2,
      "x": 851,
      "y": 731
    },
    {
      "t": 89224,
      "e": 81801,
      "ty": 3,
      "x": 851,
      "y": 731,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 89224,
      "e": 81801,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 89247,
      "e": 81824,
      "ty": 41,
      "x": 7423,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 89352,
      "e": 81929,
      "ty": 4,
      "x": 7423,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 89352,
      "e": 81929,
      "ty": 5,
      "x": 851,
      "y": 731,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 89352,
      "e": 81929,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 89353,
      "e": 81930,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 89698,
      "e": 82275,
      "ty": 2,
      "x": 853,
      "y": 732
    },
    {
      "t": 89748,
      "e": 82325,
      "ty": 41,
      "x": 48225,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 89798,
      "e": 82375,
      "ty": 2,
      "x": 1043,
      "y": 814
    },
    {
      "t": 89898,
      "e": 82475,
      "ty": 2,
      "x": 1046,
      "y": 815
    },
    {
      "t": 89998,
      "e": 82575,
      "ty": 41,
      "x": 53297,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 90197,
      "e": 82774,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 90297,
      "e": 82874,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 90398,
      "e": 82975,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 90698,
      "e": 83275,
      "ty": 2,
      "x": 1036,
      "y": 839
    },
    {
      "t": 90748,
      "e": 83325,
      "ty": 41,
      "x": 35498,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 90797,
      "e": 83374,
      "ty": 2,
      "x": 899,
      "y": 922
    },
    {
      "t": 90898,
      "e": 83475,
      "ty": 2,
      "x": 863,
      "y": 936
    },
    {
      "t": 90998,
      "e": 83575,
      "ty": 2,
      "x": 844,
      "y": 952
    },
    {
      "t": 90998,
      "e": 83575,
      "ty": 41,
      "x": 5358,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 91198,
      "e": 83775,
      "ty": 2,
      "x": 844,
      "y": 943
    },
    {
      "t": 91248,
      "e": 83825,
      "ty": 41,
      "x": 24660,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91272,
      "e": 83849,
      "ty": 3,
      "x": 844,
      "y": 943,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91274,
      "e": 83851,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 91384,
      "e": 83961,
      "ty": 4,
      "x": 24660,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91384,
      "e": 83961,
      "ty": 5,
      "x": 844,
      "y": 943,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91384,
      "e": 83961,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 91385,
      "e": 83962,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 91598,
      "e": 84175,
      "ty": 2,
      "x": 847,
      "y": 950
    },
    {
      "t": 91698,
      "e": 84275,
      "ty": 2,
      "x": 866,
      "y": 974
    },
    {
      "t": 91747,
      "e": 84324,
      "ty": 41,
      "x": 51202,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 91784,
      "e": 84361,
      "ty": 6,
      "x": 884,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91798,
      "e": 84375,
      "ty": 2,
      "x": 884,
      "y": 1011
    },
    {
      "t": 91898,
      "e": 84475,
      "ty": 2,
      "x": 893,
      "y": 1014
    },
    {
      "t": 91998,
      "e": 84575,
      "ty": 2,
      "x": 900,
      "y": 1029
    },
    {
      "t": 91998,
      "e": 84575,
      "ty": 41,
      "x": 36375,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92025,
      "e": 84602,
      "ty": 3,
      "x": 900,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92026,
      "e": 84603,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 92027,
      "e": 84604,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92136,
      "e": 84713,
      "ty": 4,
      "x": 36375,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92137,
      "e": 84714,
      "ty": 5,
      "x": 900,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92139,
      "e": 84716,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92141,
      "e": 84718,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 92141,
      "e": 84718,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 92698,
      "e": 85275,
      "ty": 2,
      "x": 898,
      "y": 976
    },
    {
      "t": 92748,
      "e": 85325,
      "ty": 41,
      "x": 27274,
      "y": 43708,
      "ta": "html > body"
    },
    {
      "t": 92798,
      "e": 85375,
      "ty": 2,
      "x": 437,
      "y": 566
    },
    {
      "t": 92897,
      "e": 85474,
      "ty": 2,
      "x": 235,
      "y": 479
    },
    {
      "t": 92998,
      "e": 85575,
      "ty": 41,
      "x": 7817,
      "y": 26092,
      "ta": "html > body"
    },
    {
      "t": 93398,
      "e": 85975,
      "ty": 2,
      "x": 296,
      "y": 476
    },
    {
      "t": 93488,
      "e": 86065,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 93497,
      "e": 86074,
      "ty": 2,
      "x": 424,
      "y": 469
    },
    {
      "t": 93497,
      "e": 86074,
      "ty": 41,
      "x": 6422,
      "y": 15575,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 93598,
      "e": 86175,
      "ty": 2,
      "x": 654,
      "y": 469
    },
    {
      "t": 93697,
      "e": 86274,
      "ty": 2,
      "x": 893,
      "y": 468
    },
    {
      "t": 93748,
      "e": 86325,
      "ty": 41,
      "x": 30332,
      "y": 15111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 93798,
      "e": 86375,
      "ty": 2,
      "x": 910,
      "y": 465
    },
    {
      "t": 93898,
      "e": 86475,
      "ty": 2,
      "x": 911,
      "y": 465
    },
    {
      "t": 93998,
      "e": 86575,
      "ty": 41,
      "x": 30381,
      "y": 15111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 99999,
      "e": 91575,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 159397,
      "e": 91575,
      "ty": 2,
      "x": 791,
      "y": 858
    },
    {
      "t": 159496,
      "e": 91674,
      "ty": 2,
      "x": 773,
      "y": 905
    },
    {
      "t": 159498,
      "e": 91676,
      "ty": 41,
      "x": 23592,
      "y": 53923,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 159747,
      "e": 91925,
      "ty": 41,
      "x": 23149,
      "y": 52698,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 159796,
      "e": 91974,
      "ty": 2,
      "x": 714,
      "y": 866
    },
    {
      "t": 159896,
      "e": 92074,
      "ty": 2,
      "x": 575,
      "y": 847
    },
    {
      "t": 159997,
      "e": 92175,
      "ty": 2,
      "x": 555,
      "y": 845
    },
    {
      "t": 159997,
      "e": 92175,
      "ty": 41,
      "x": 12867,
      "y": 54435,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 160397,
      "e": 92575,
      "ty": 2,
      "x": 694,
      "y": 837
    },
    {
      "t": 160496,
      "e": 92674,
      "ty": 2,
      "x": 808,
      "y": 846
    },
    {
      "t": 160497,
      "e": 92675,
      "ty": 41,
      "x": 25314,
      "y": 55606,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 160597,
      "e": 92775,
      "ty": 2,
      "x": 863,
      "y": 902
    },
    {
      "t": 160697,
      "e": 92875,
      "ty": 2,
      "x": 942,
      "y": 1006
    },
    {
      "t": 160746,
      "e": 92924,
      "ty": 41,
      "x": 32693,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 160797,
      "e": 92975,
      "ty": 2,
      "x": 961,
      "y": 1022
    },
    {
      "t": 160895,
      "e": 93073,
      "ty": 2,
      "x": 979,
      "y": 1056
    },
    {
      "t": 160996,
      "e": 93174,
      "ty": 2,
      "x": 988,
      "y": 1065
    },
    {
      "t": 160996,
      "e": 93174,
      "ty": 41,
      "x": 34169,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 161051,
      "e": 93229,
      "ty": 6,
      "x": 992,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 161096,
      "e": 93274,
      "ty": 2,
      "x": 996,
      "y": 1077
    },
    {
      "t": 161196,
      "e": 93374,
      "ty": 2,
      "x": 998,
      "y": 1079
    },
    {
      "t": 161246,
      "e": 93424,
      "ty": 41,
      "x": 48332,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 161496,
      "e": 93674,
      "ty": 2,
      "x": 1000,
      "y": 1080
    },
    {
      "t": 161496,
      "e": 93674,
      "ty": 41,
      "x": 49424,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 166647,
      "e": 98674,
      "ty": 3,
      "x": 1000,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 166648,
      "e": 98675,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 166780,
      "e": 98807,
      "ty": 4,
      "x": 49424,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 166781,
      "e": 98808,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 166782,
      "e": 98809,
      "ty": 5,
      "x": 1000,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 166783,
      "e": 98810,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 167823,
      "e": 99850,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 169748,
      "e": 101775,
      "ty": 41,
      "x": 32254,
      "y": 32857,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 169796,
      "e": 101823,
      "ty": 2,
      "x": 532,
      "y": 895
    },
    {
      "t": 169896,
      "e": 101923,
      "ty": 2,
      "x": 251,
      "y": 816
    },
    {
      "t": 169996,
      "e": 102023,
      "ty": 41,
      "x": 7678,
      "y": 32809,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 169997,
      "e": 102024,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170098,
      "e": 102125,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 169141, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 169146, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11813, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 182284, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9716, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"yankee\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 193004, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 44016, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 238105, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13591, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 252700, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 31232, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 285471, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-11 AM-A -A -A -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1010,y:1035,t:1528139590985};\\\", \\\"{x:982,y:997,t:1528139590992};\\\", \\\"{x:930,y:925,t:1528139591005};\\\", \\\"{x:820,y:793,t:1528139591022};\\\", \\\"{x:748,y:713,t:1528139591039};\\\", \\\"{x:705,y:656,t:1528139591058};\\\", \\\"{x:690,y:627,t:1528139591071};\\\", \\\"{x:666,y:579,t:1528139591088};\\\", \\\"{x:640,y:518,t:1528139591105};\\\", \\\"{x:622,y:459,t:1528139591122};\\\", \\\"{x:612,y:418,t:1528139591138};\\\", \\\"{x:609,y:391,t:1528139591156};\\\", \\\"{x:609,y:366,t:1528139591171};\\\", \\\"{x:609,y:346,t:1528139591188};\\\", \\\"{x:609,y:334,t:1528139591205};\\\", \\\"{x:609,y:324,t:1528139591222};\\\", \\\"{x:609,y:322,t:1528139591238};\\\", \\\"{x:610,y:322,t:1528139591465};\\\", \\\"{x:610,y:327,t:1528139591473};\\\", \\\"{x:610,y:339,t:1528139591488};\\\", \\\"{x:610,y:350,t:1528139591506};\\\", \\\"{x:610,y:357,t:1528139591522};\\\", \\\"{x:605,y:364,t:1528139591538};\\\", \\\"{x:603,y:367,t:1528139591555};\\\", \\\"{x:601,y:370,t:1528139591573};\\\", \\\"{x:600,y:372,t:1528139591588};\\\", \\\"{x:597,y:374,t:1528139591605};\\\", \\\"{x:593,y:377,t:1528139591622};\\\", \\\"{x:589,y:380,t:1528139591638};\\\", \\\"{x:580,y:384,t:1528139591656};\\\", \\\"{x:568,y:388,t:1528139591672};\\\", \\\"{x:555,y:392,t:1528139591688};\\\", \\\"{x:542,y:397,t:1528139591706};\\\", \\\"{x:526,y:404,t:1528139591722};\\\", \\\"{x:511,y:410,t:1528139591739};\\\", \\\"{x:497,y:416,t:1528139591756};\\\", \\\"{x:483,y:425,t:1528139591772};\\\", \\\"{x:467,y:438,t:1528139591788};\\\", \\\"{x:450,y:455,t:1528139591805};\\\", \\\"{x:438,y:470,t:1528139591822};\\\", \\\"{x:430,y:478,t:1528139591838};\\\", \\\"{x:425,y:484,t:1528139591855};\\\", \\\"{x:424,y:485,t:1528139591872};\\\", \\\"{x:423,y:487,t:1528139591895};\\\", \\\"{x:423,y:488,t:1528139591952};\\\", \\\"{x:424,y:488,t:1528139592456};\\\", \\\"{x:431,y:488,t:1528139592472};\\\", \\\"{x:439,y:488,t:1528139592489};\\\", \\\"{x:442,y:488,t:1528139592506};\\\", \\\"{x:444,y:488,t:1528139592523};\\\", \\\"{x:447,y:488,t:1528139592539};\\\", \\\"{x:450,y:488,t:1528139592557};\\\", \\\"{x:455,y:487,t:1528139592573};\\\", \\\"{x:460,y:486,t:1528139592589};\\\", \\\"{x:464,y:485,t:1528139592606};\\\", \\\"{x:473,y:484,t:1528139592623};\\\", \\\"{x:478,y:483,t:1528139592639};\\\", \\\"{x:482,y:482,t:1528139592657};\\\", \\\"{x:487,y:481,t:1528139592672};\\\", \\\"{x:490,y:480,t:1528139592689};\\\", \\\"{x:494,y:480,t:1528139592706};\\\", \\\"{x:497,y:479,t:1528139592722};\\\", \\\"{x:503,y:479,t:1528139592739};\\\", \\\"{x:510,y:478,t:1528139592756};\\\", \\\"{x:515,y:477,t:1528139592773};\\\", \\\"{x:519,y:477,t:1528139592789};\\\", \\\"{x:524,y:476,t:1528139592807};\\\", \\\"{x:526,y:476,t:1528139592823};\\\", \\\"{x:529,y:474,t:1528139592840};\\\", \\\"{x:531,y:474,t:1528139592857};\\\", \\\"{x:535,y:474,t:1528139592873};\\\", \\\"{x:536,y:474,t:1528139592890};\\\", \\\"{x:538,y:474,t:1528139593408};\\\", \\\"{x:542,y:475,t:1528139593424};\\\", \\\"{x:548,y:479,t:1528139593440};\\\", \\\"{x:553,y:481,t:1528139593457};\\\", \\\"{x:558,y:482,t:1528139593474};\\\", \\\"{x:563,y:485,t:1528139593491};\\\", \\\"{x:568,y:487,t:1528139593507};\\\", \\\"{x:576,y:491,t:1528139593523};\\\", \\\"{x:581,y:495,t:1528139593541};\\\", \\\"{x:582,y:497,t:1528139593556};\\\", \\\"{x:582,y:500,t:1528139593573};\\\", \\\"{x:582,y:503,t:1528139593590};\\\", \\\"{x:582,y:504,t:1528139593607};\\\", \\\"{x:582,y:506,t:1528139593632};\\\", \\\"{x:581,y:506,t:1528139593640};\\\", \\\"{x:579,y:508,t:1528139593656};\\\", \\\"{x:579,y:509,t:1528139593674};\\\", \\\"{x:579,y:510,t:1528139593704};\\\", \\\"{x:578,y:510,t:1528139593736};\\\", \\\"{x:578,y:513,t:1528139594144};\\\", \\\"{x:578,y:520,t:1528139594157};\\\", \\\"{x:578,y:542,t:1528139594175};\\\", \\\"{x:582,y:563,t:1528139594191};\\\", \\\"{x:589,y:587,t:1528139594203};\\\", \\\"{x:599,y:610,t:1528139594219};\\\", \\\"{x:609,y:630,t:1528139594236};\\\", \\\"{x:620,y:652,t:1528139594252};\\\", \\\"{x:634,y:682,t:1528139594275};\\\", \\\"{x:651,y:707,t:1528139594291};\\\", \\\"{x:671,y:734,t:1528139594308};\\\", \\\"{x:700,y:770,t:1528139594324};\\\", \\\"{x:723,y:793,t:1528139594341};\\\", \\\"{x:752,y:822,t:1528139594358};\\\", \\\"{x:791,y:860,t:1528139594375};\\\", \\\"{x:828,y:895,t:1528139594391};\\\", \\\"{x:869,y:939,t:1528139594407};\\\", \\\"{x:888,y:963,t:1528139594424};\\\", \\\"{x:903,y:980,t:1528139594441};\\\", \\\"{x:915,y:993,t:1528139594457};\\\", \\\"{x:926,y:1004,t:1528139594475};\\\", \\\"{x:934,y:1012,t:1528139594491};\\\", \\\"{x:943,y:1018,t:1528139594508};\\\", \\\"{x:954,y:1025,t:1528139594525};\\\", \\\"{x:965,y:1035,t:1528139594541};\\\", \\\"{x:980,y:1045,t:1528139594557};\\\", \\\"{x:990,y:1054,t:1528139594574};\\\", \\\"{x:1002,y:1062,t:1528139594591};\\\", \\\"{x:1009,y:1066,t:1528139594607};\\\", \\\"{x:1011,y:1066,t:1528139594625};\\\", \\\"{x:1012,y:1066,t:1528139594681};\\\", \\\"{x:1013,y:1066,t:1528139594691};\\\", \\\"{x:1016,y:1066,t:1528139594708};\\\", \\\"{x:1024,y:1066,t:1528139594724};\\\", \\\"{x:1030,y:1066,t:1528139594740};\\\", \\\"{x:1033,y:1066,t:1528139594758};\\\", \\\"{x:1038,y:1065,t:1528139594773};\\\", \\\"{x:1041,y:1065,t:1528139594790};\\\", \\\"{x:1044,y:1064,t:1528139594808};\\\", \\\"{x:1046,y:1064,t:1528139594823};\\\", \\\"{x:1050,y:1063,t:1528139594840};\\\", \\\"{x:1054,y:1061,t:1528139594858};\\\", \\\"{x:1060,y:1058,t:1528139594874};\\\", \\\"{x:1065,y:1057,t:1528139594891};\\\", \\\"{x:1069,y:1054,t:1528139594907};\\\", \\\"{x:1071,y:1053,t:1528139594924};\\\", \\\"{x:1073,y:1050,t:1528139594941};\\\", \\\"{x:1077,y:1048,t:1528139594958};\\\", \\\"{x:1081,y:1046,t:1528139594974};\\\", \\\"{x:1085,y:1042,t:1528139594991};\\\", \\\"{x:1088,y:1038,t:1528139595007};\\\", \\\"{x:1092,y:1032,t:1528139595024};\\\", \\\"{x:1095,y:1026,t:1528139595041};\\\", \\\"{x:1099,y:1023,t:1528139595057};\\\", \\\"{x:1101,y:1020,t:1528139595074};\\\", \\\"{x:1104,y:1018,t:1528139595091};\\\", \\\"{x:1105,y:1016,t:1528139595107};\\\", \\\"{x:1107,y:1015,t:1528139595124};\\\", \\\"{x:1109,y:1013,t:1528139595140};\\\", \\\"{x:1113,y:1011,t:1528139595157};\\\", \\\"{x:1117,y:1010,t:1528139595173};\\\", \\\"{x:1121,y:1007,t:1528139595189};\\\", \\\"{x:1125,y:1006,t:1528139595206};\\\", \\\"{x:1134,y:1002,t:1528139595223};\\\", \\\"{x:1144,y:997,t:1528139595239};\\\", \\\"{x:1152,y:994,t:1528139595256};\\\", \\\"{x:1158,y:991,t:1528139595273};\\\", \\\"{x:1162,y:989,t:1528139595289};\\\", \\\"{x:1167,y:987,t:1528139595307};\\\", \\\"{x:1171,y:985,t:1528139595324};\\\", \\\"{x:1175,y:983,t:1528139595340};\\\", \\\"{x:1180,y:981,t:1528139595357};\\\", \\\"{x:1189,y:978,t:1528139595381};\\\", \\\"{x:1192,y:976,t:1528139595391};\\\", \\\"{x:1198,y:974,t:1528139595407};\\\", \\\"{x:1205,y:971,t:1528139595423};\\\", \\\"{x:1207,y:970,t:1528139595439};\\\", \\\"{x:1208,y:970,t:1528139595456};\\\", \\\"{x:1209,y:969,t:1528139595473};\\\", \\\"{x:1212,y:968,t:1528139595490};\\\", \\\"{x:1213,y:967,t:1528139595506};\\\", \\\"{x:1217,y:966,t:1528139595523};\\\", \\\"{x:1221,y:964,t:1528139595539};\\\", \\\"{x:1224,y:963,t:1528139595556};\\\", \\\"{x:1228,y:963,t:1528139595572};\\\", \\\"{x:1230,y:962,t:1528139595590};\\\", \\\"{x:1232,y:961,t:1528139595607};\\\", \\\"{x:1233,y:961,t:1528139595623};\\\", \\\"{x:1236,y:959,t:1528139595639};\\\", \\\"{x:1244,y:958,t:1528139595657};\\\", \\\"{x:1250,y:956,t:1528139595672};\\\", \\\"{x:1255,y:955,t:1528139595690};\\\", \\\"{x:1257,y:955,t:1528139595706};\\\", \\\"{x:1259,y:953,t:1528139595723};\\\", \\\"{x:1260,y:953,t:1528139595752};\\\", \\\"{x:1261,y:953,t:1528139595777};\\\", \\\"{x:1262,y:953,t:1528139595800};\\\", \\\"{x:1263,y:953,t:1528139595841};\\\", \\\"{x:1265,y:953,t:1528139595857};\\\", \\\"{x:1266,y:953,t:1528139595873};\\\", \\\"{x:1267,y:953,t:1528139595890};\\\", \\\"{x:1268,y:953,t:1528139596640};\\\", \\\"{x:1268,y:957,t:1528139596654};\\\", \\\"{x:1268,y:973,t:1528139596671};\\\", \\\"{x:1268,y:979,t:1528139596689};\\\", \\\"{x:1268,y:982,t:1528139596705};\\\", \\\"{x:1268,y:984,t:1528139596722};\\\", \\\"{x:1269,y:985,t:1528139597025};\\\", \\\"{x:1271,y:985,t:1528139597040};\\\", \\\"{x:1273,y:985,t:1528139597056};\\\", \\\"{x:1277,y:982,t:1528139597073};\\\", \\\"{x:1281,y:979,t:1528139597088};\\\", \\\"{x:1284,y:977,t:1528139597105};\\\", \\\"{x:1285,y:976,t:1528139597121};\\\", \\\"{x:1286,y:975,t:1528139597138};\\\", \\\"{x:1287,y:974,t:1528139597207};\\\", \\\"{x:1287,y:973,t:1528139597263};\\\", \\\"{x:1287,y:972,t:1528139597336};\\\", \\\"{x:1288,y:970,t:1528139597352};\\\", \\\"{x:1288,y:969,t:1528139597360};\\\", \\\"{x:1288,y:968,t:1528139597371};\\\", \\\"{x:1288,y:967,t:1528139597388};\\\", \\\"{x:1288,y:965,t:1528139597404};\\\", \\\"{x:1288,y:964,t:1528139597421};\\\", \\\"{x:1288,y:962,t:1528139597438};\\\", \\\"{x:1288,y:959,t:1528139597454};\\\", \\\"{x:1288,y:956,t:1528139597471};\\\", \\\"{x:1288,y:953,t:1528139597488};\\\", \\\"{x:1288,y:952,t:1528139597504};\\\", \\\"{x:1288,y:948,t:1528139597521};\\\", \\\"{x:1288,y:945,t:1528139597538};\\\", \\\"{x:1288,y:939,t:1528139597554};\\\", \\\"{x:1288,y:931,t:1528139597571};\\\", \\\"{x:1288,y:923,t:1528139597588};\\\", \\\"{x:1288,y:913,t:1528139597604};\\\", \\\"{x:1288,y:905,t:1528139597621};\\\", \\\"{x:1288,y:900,t:1528139597639};\\\", \\\"{x:1288,y:892,t:1528139597655};\\\", \\\"{x:1288,y:885,t:1528139597672};\\\", \\\"{x:1288,y:878,t:1528139597687};\\\", \\\"{x:1288,y:870,t:1528139597705};\\\", \\\"{x:1288,y:866,t:1528139597721};\\\", \\\"{x:1288,y:863,t:1528139597738};\\\", \\\"{x:1288,y:860,t:1528139597755};\\\", \\\"{x:1288,y:858,t:1528139597771};\\\", \\\"{x:1288,y:856,t:1528139597787};\\\", \\\"{x:1288,y:855,t:1528139597804};\\\", \\\"{x:1288,y:852,t:1528139597821};\\\", \\\"{x:1287,y:848,t:1528139597837};\\\", \\\"{x:1286,y:845,t:1528139597855};\\\", \\\"{x:1284,y:841,t:1528139597872};\\\", \\\"{x:1284,y:838,t:1528139597887};\\\", \\\"{x:1284,y:836,t:1528139597904};\\\", \\\"{x:1283,y:835,t:1528139597931};\\\", \\\"{x:1283,y:832,t:1528139597953};\\\", \\\"{x:1281,y:829,t:1528139597969};\\\", \\\"{x:1281,y:824,t:1528139597994};\\\", \\\"{x:1281,y:822,t:1528139598011};\\\", \\\"{x:1281,y:819,t:1528139598028};\\\", \\\"{x:1280,y:818,t:1528139598043};\\\", \\\"{x:1280,y:817,t:1528139598061};\\\", \\\"{x:1280,y:816,t:1528139598087};\\\", \\\"{x:1280,y:815,t:1528139598416};\\\", \\\"{x:1280,y:816,t:1528139598456};\\\", \\\"{x:1278,y:820,t:1528139598464};\\\", \\\"{x:1278,y:823,t:1528139598478};\\\", \\\"{x:1278,y:828,t:1528139598500};\\\", \\\"{x:1277,y:832,t:1528139598510};\\\", \\\"{x:1276,y:838,t:1528139598544};\\\", \\\"{x:1276,y:839,t:1528139598561};\\\", \\\"{x:1276,y:840,t:1528139598599};\\\", \\\"{x:1277,y:840,t:1528139598817};\\\", \\\"{x:1277,y:839,t:1528139598832};\\\", \\\"{x:1277,y:838,t:1528139598845};\\\", \\\"{x:1277,y:837,t:1528139598861};\\\", \\\"{x:1277,y:836,t:1528139598879};\\\", \\\"{x:1277,y:835,t:1528139599248};\\\", \\\"{x:1277,y:834,t:1528139599266};\\\", \\\"{x:1277,y:833,t:1528139599278};\\\", \\\"{x:1277,y:832,t:1528139599303};\\\", \\\"{x:1277,y:831,t:1528139599383};\\\", \\\"{x:1277,y:830,t:1528139599395};\\\", \\\"{x:1277,y:829,t:1528139599411};\\\", \\\"{x:1277,y:825,t:1528139609426};\\\", \\\"{x:1277,y:813,t:1528139609448};\\\", \\\"{x:1278,y:807,t:1528139609465};\\\", \\\"{x:1279,y:800,t:1528139609486};\\\", \\\"{x:1279,y:797,t:1528139609503};\\\", \\\"{x:1279,y:795,t:1528139609520};\\\", \\\"{x:1279,y:792,t:1528139609537};\\\", \\\"{x:1279,y:791,t:1528139609553};\\\", \\\"{x:1279,y:788,t:1528139609570};\\\", \\\"{x:1279,y:786,t:1528139609587};\\\", \\\"{x:1279,y:782,t:1528139609603};\\\", \\\"{x:1279,y:777,t:1528139609620};\\\", \\\"{x:1279,y:770,t:1528139609638};\\\", \\\"{x:1279,y:763,t:1528139609654};\\\", \\\"{x:1279,y:754,t:1528139609670};\\\", \\\"{x:1279,y:736,t:1528139609688};\\\", \\\"{x:1279,y:721,t:1528139609704};\\\", \\\"{x:1279,y:704,t:1528139609721};\\\", \\\"{x:1275,y:680,t:1528139609737};\\\", \\\"{x:1274,y:658,t:1528139609754};\\\", \\\"{x:1274,y:638,t:1528139609770};\\\", \\\"{x:1274,y:617,t:1528139609787};\\\", \\\"{x:1274,y:597,t:1528139609804};\\\", \\\"{x:1274,y:578,t:1528139609821};\\\", \\\"{x:1273,y:556,t:1528139609838};\\\", \\\"{x:1273,y:534,t:1528139609854};\\\", \\\"{x:1273,y:514,t:1528139609871};\\\", \\\"{x:1273,y:482,t:1528139609887};\\\", \\\"{x:1273,y:463,t:1528139609903};\\\", \\\"{x:1273,y:447,t:1528139609921};\\\", \\\"{x:1273,y:429,t:1528139609938};\\\", \\\"{x:1273,y:414,t:1528139609954};\\\", \\\"{x:1273,y:398,t:1528139609971};\\\", \\\"{x:1273,y:384,t:1528139609988};\\\", \\\"{x:1273,y:370,t:1528139610004};\\\", \\\"{x:1273,y:359,t:1528139610021};\\\", \\\"{x:1273,y:346,t:1528139610038};\\\", \\\"{x:1273,y:335,t:1528139610054};\\\", \\\"{x:1273,y:327,t:1528139610071};\\\", \\\"{x:1273,y:318,t:1528139610088};\\\", \\\"{x:1273,y:316,t:1528139610105};\\\", \\\"{x:1273,y:314,t:1528139610122};\\\", \\\"{x:1270,y:314,t:1528139610223};\\\", \\\"{x:1262,y:315,t:1528139610237};\\\", \\\"{x:1236,y:333,t:1528139610254};\\\", \\\"{x:1162,y:378,t:1528139610271};\\\", \\\"{x:1080,y:412,t:1528139610286};\\\", \\\"{x:991,y:437,t:1528139610304};\\\", \\\"{x:891,y:465,t:1528139610321};\\\", \\\"{x:789,y:479,t:1528139610337};\\\", \\\"{x:683,y:497,t:1528139610354};\\\", \\\"{x:588,y:510,t:1528139610371};\\\", \\\"{x:540,y:518,t:1528139610387};\\\", \\\"{x:510,y:521,t:1528139610405};\\\", \\\"{x:495,y:521,t:1528139610421};\\\", \\\"{x:484,y:521,t:1528139610437};\\\", \\\"{x:474,y:521,t:1528139610454};\\\", \\\"{x:448,y:521,t:1528139610471};\\\", \\\"{x:430,y:521,t:1528139610487};\\\", \\\"{x:411,y:521,t:1528139610505};\\\", \\\"{x:389,y:521,t:1528139610521};\\\", \\\"{x:369,y:521,t:1528139610539};\\\", \\\"{x:350,y:521,t:1528139610555};\\\", \\\"{x:332,y:521,t:1528139610571};\\\", \\\"{x:315,y:523,t:1528139610587};\\\", \\\"{x:301,y:526,t:1528139610605};\\\", \\\"{x:290,y:527,t:1528139610622};\\\", \\\"{x:276,y:529,t:1528139610638};\\\", \\\"{x:260,y:531,t:1528139610655};\\\", \\\"{x:232,y:538,t:1528139610672};\\\", \\\"{x:216,y:544,t:1528139610690};\\\", \\\"{x:210,y:548,t:1528139610703};\\\", \\\"{x:209,y:549,t:1528139610721};\\\", \\\"{x:209,y:550,t:1528139610758};\\\", \\\"{x:213,y:551,t:1528139610775};\\\", \\\"{x:220,y:551,t:1528139610787};\\\", \\\"{x:239,y:552,t:1528139610804};\\\", \\\"{x:264,y:552,t:1528139610821};\\\", \\\"{x:287,y:552,t:1528139610838};\\\", \\\"{x:309,y:549,t:1528139610854};\\\", \\\"{x:329,y:548,t:1528139610871};\\\", \\\"{x:338,y:548,t:1528139610888};\\\", \\\"{x:344,y:548,t:1528139610905};\\\", \\\"{x:349,y:548,t:1528139610921};\\\", \\\"{x:354,y:548,t:1528139610937};\\\", \\\"{x:356,y:548,t:1528139610954};\\\", \\\"{x:357,y:548,t:1528139610971};\\\", \\\"{x:358,y:548,t:1528139611006};\\\", \\\"{x:359,y:548,t:1528139611021};\\\", \\\"{x:361,y:549,t:1528139611038};\\\", \\\"{x:363,y:550,t:1528139611054};\\\", \\\"{x:363,y:551,t:1528139611071};\\\", \\\"{x:365,y:551,t:1528139611128};\\\", \\\"{x:366,y:552,t:1528139611151};\\\", \\\"{x:367,y:552,t:1528139611184};\\\", \\\"{x:368,y:552,t:1528139611191};\\\", \\\"{x:369,y:552,t:1528139611205};\\\", \\\"{x:374,y:553,t:1528139611222};\\\", \\\"{x:379,y:554,t:1528139611238};\\\", \\\"{x:385,y:554,t:1528139611254};\\\", \\\"{x:388,y:554,t:1528139611271};\\\", \\\"{x:390,y:554,t:1528139611288};\\\", \\\"{x:391,y:554,t:1528139611304};\\\", \\\"{x:392,y:554,t:1528139611321};\\\", \\\"{x:394,y:554,t:1528139612096};\\\", \\\"{x:397,y:566,t:1528139612105};\\\", \\\"{x:412,y:592,t:1528139612123};\\\", \\\"{x:430,y:619,t:1528139612140};\\\", \\\"{x:455,y:651,t:1528139612156};\\\", \\\"{x:488,y:686,t:1528139612173};\\\", \\\"{x:510,y:710,t:1528139612189};\\\", \\\"{x:534,y:727,t:1528139612205};\\\", \\\"{x:559,y:744,t:1528139612223};\\\", \\\"{x:588,y:761,t:1528139612239};\\\", \\\"{x:603,y:767,t:1528139612254};\\\", \\\"{x:622,y:776,t:1528139612272};\\\", \\\"{x:644,y:784,t:1528139612289};\\\", \\\"{x:664,y:789,t:1528139612305};\\\", \\\"{x:679,y:792,t:1528139612322};\\\", \\\"{x:696,y:795,t:1528139612340};\\\", \\\"{x:717,y:797,t:1528139612356};\\\", \\\"{x:735,y:797,t:1528139612372};\\\", \\\"{x:756,y:797,t:1528139612389};\\\", \\\"{x:793,y:797,t:1528139612406};\\\", \\\"{x:823,y:797,t:1528139612422};\\\", \\\"{x:858,y:792,t:1528139612439};\\\", \\\"{x:870,y:789,t:1528139612456};\\\", \\\"{x:876,y:786,t:1528139612472};\\\", \\\"{x:878,y:785,t:1528139612489};\\\", \\\"{x:883,y:784,t:1528139612506};\\\", \\\"{x:893,y:781,t:1528139612522};\\\", \\\"{x:904,y:778,t:1528139612539};\\\", \\\"{x:916,y:773,t:1528139612556};\\\", \\\"{x:924,y:771,t:1528139612572};\\\", \\\"{x:936,y:767,t:1528139612590};\\\", \\\"{x:942,y:766,t:1528139612607};\\\", \\\"{x:950,y:764,t:1528139612622};\\\", \\\"{x:956,y:761,t:1528139612640};\\\", \\\"{x:958,y:761,t:1528139612656};\\\", \\\"{x:960,y:760,t:1528139613032};\\\", \\\"{x:964,y:760,t:1528139613040};\\\", \\\"{x:980,y:758,t:1528139613057};\\\", \\\"{x:1004,y:756,t:1528139613074};\\\", \\\"{x:1033,y:752,t:1528139613089};\\\", \\\"{x:1071,y:747,t:1528139613106};\\\", \\\"{x:1105,y:743,t:1528139613123};\\\", \\\"{x:1130,y:743,t:1528139613140};\\\", \\\"{x:1141,y:743,t:1528139613156};\\\", \\\"{x:1147,y:743,t:1528139613174};\\\", \\\"{x:1151,y:743,t:1528139613190};\\\", \\\"{x:1156,y:743,t:1528139613207};\\\", \\\"{x:1161,y:743,t:1528139613223};\\\", \\\"{x:1168,y:743,t:1528139613240};\\\", \\\"{x:1177,y:746,t:1528139613256};\\\", \\\"{x:1186,y:752,t:1528139613273};\\\", \\\"{x:1195,y:757,t:1528139613291};\\\", \\\"{x:1203,y:761,t:1528139613306};\\\", \\\"{x:1207,y:764,t:1528139613324};\\\", \\\"{x:1209,y:765,t:1528139613341};\\\", \\\"{x:1211,y:766,t:1528139613357};\\\", \\\"{x:1218,y:770,t:1528139613374};\\\", \\\"{x:1235,y:778,t:1528139613391};\\\", \\\"{x:1260,y:788,t:1528139613406};\\\", \\\"{x:1295,y:804,t:1528139613425};\\\", \\\"{x:1312,y:808,t:1528139613440};\\\", \\\"{x:1323,y:813,t:1528139613456};\\\", \\\"{x:1324,y:814,t:1528139613474};\\\", \\\"{x:1326,y:814,t:1528139613561};\\\", \\\"{x:1324,y:814,t:1528139613624};\\\", \\\"{x:1316,y:812,t:1528139613641};\\\", \\\"{x:1312,y:811,t:1528139613658};\\\", \\\"{x:1308,y:811,t:1528139613674};\\\", \\\"{x:1304,y:809,t:1528139613691};\\\", \\\"{x:1297,y:809,t:1528139613707};\\\", \\\"{x:1294,y:809,t:1528139613723};\\\", \\\"{x:1292,y:811,t:1528139613741};\\\", \\\"{x:1291,y:811,t:1528139613758};\\\", \\\"{x:1291,y:812,t:1528139613773};\\\", \\\"{x:1291,y:813,t:1528139613791};\\\", \\\"{x:1290,y:814,t:1528139613807};\\\", \\\"{x:1289,y:815,t:1528139613824};\\\", \\\"{x:1289,y:817,t:1528139613841};\\\", \\\"{x:1287,y:819,t:1528139613857};\\\", \\\"{x:1286,y:821,t:1528139613873};\\\", \\\"{x:1285,y:824,t:1528139613891};\\\", \\\"{x:1284,y:826,t:1528139613912};\\\", \\\"{x:1283,y:827,t:1528139613923};\\\", \\\"{x:1283,y:828,t:1528139613951};\\\", \\\"{x:1282,y:830,t:1528139613967};\\\", \\\"{x:1282,y:831,t:1528139613975};\\\", \\\"{x:1282,y:832,t:1528139613990};\\\", \\\"{x:1280,y:833,t:1528139614007};\\\", \\\"{x:1277,y:833,t:1528139617351};\\\", \\\"{x:1247,y:821,t:1528139617381};\\\", \\\"{x:1142,y:807,t:1528139617398};\\\", \\\"{x:1002,y:781,t:1528139617409};\\\", \\\"{x:905,y:766,t:1528139617427};\\\", \\\"{x:792,y:751,t:1528139617443};\\\", \\\"{x:672,y:751,t:1528139617460};\\\", \\\"{x:581,y:751,t:1528139617476};\\\", \\\"{x:522,y:750,t:1528139617494};\\\", \\\"{x:490,y:747,t:1528139617509};\\\", \\\"{x:472,y:747,t:1528139617526};\\\", \\\"{x:468,y:748,t:1528139617543};\\\", \\\"{x:465,y:748,t:1528139617560};\\\", \\\"{x:464,y:750,t:1528139617576};\\\", \\\"{x:458,y:753,t:1528139617594};\\\", \\\"{x:451,y:757,t:1528139617609};\\\", \\\"{x:438,y:766,t:1528139617628};\\\", \\\"{x:427,y:773,t:1528139617644};\\\", \\\"{x:419,y:780,t:1528139617660};\\\", \\\"{x:412,y:788,t:1528139617676};\\\", \\\"{x:408,y:793,t:1528139617693};\\\", \\\"{x:406,y:798,t:1528139617711};\\\", \\\"{x:406,y:799,t:1528139617726};\\\", \\\"{x:406,y:800,t:1528139617792};\\\", \\\"{x:411,y:800,t:1528139617800};\\\", \\\"{x:414,y:799,t:1528139617811};\\\", \\\"{x:430,y:793,t:1528139617827};\\\", \\\"{x:451,y:785,t:1528139617843};\\\", \\\"{x:463,y:780,t:1528139617860};\\\", \\\"{x:469,y:778,t:1528139617877};\\\", \\\"{x:480,y:775,t:1528139617894};\\\", \\\"{x:486,y:773,t:1528139617911};\\\", \\\"{x:491,y:772,t:1528139617926};\\\", \\\"{x:498,y:770,t:1528139617944};\\\", \\\"{x:501,y:770,t:1528139617960};\\\", \\\"{x:506,y:767,t:1528139617977};\\\", \\\"{x:510,y:766,t:1528139617994};\\\", \\\"{x:513,y:765,t:1528139618011};\\\", \\\"{x:514,y:764,t:1528139618056};\\\" ] }, { \\\"rt\\\": 25803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 312479, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-A -D -D -X -X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:755,t:1528139620151};\\\", \\\"{x:499,y:734,t:1528139620162};\\\", \\\"{x:473,y:703,t:1528139620178};\\\", \\\"{x:445,y:677,t:1528139620196};\\\", \\\"{x:415,y:648,t:1528139620213};\\\", \\\"{x:400,y:638,t:1528139620228};\\\", \\\"{x:393,y:636,t:1528139620245};\\\", \\\"{x:390,y:636,t:1528139620262};\\\", \\\"{x:383,y:629,t:1528139620278};\\\", \\\"{x:382,y:628,t:1528139620295};\\\", \\\"{x:385,y:628,t:1528139621287};\\\", \\\"{x:390,y:628,t:1528139621297};\\\", \\\"{x:415,y:628,t:1528139621314};\\\", \\\"{x:441,y:624,t:1528139621331};\\\", \\\"{x:464,y:623,t:1528139621346};\\\", \\\"{x:491,y:623,t:1528139621362};\\\", \\\"{x:517,y:623,t:1528139621380};\\\", \\\"{x:545,y:622,t:1528139621395};\\\", \\\"{x:572,y:617,t:1528139621413};\\\", \\\"{x:591,y:611,t:1528139621429};\\\", \\\"{x:632,y:600,t:1528139621447};\\\", \\\"{x:651,y:596,t:1528139621462};\\\", \\\"{x:686,y:593,t:1528139621480};\\\", \\\"{x:703,y:589,t:1528139621496};\\\", \\\"{x:719,y:585,t:1528139621512};\\\", \\\"{x:735,y:580,t:1528139621530};\\\", \\\"{x:746,y:579,t:1528139621546};\\\", \\\"{x:758,y:576,t:1528139621563};\\\", \\\"{x:773,y:574,t:1528139621579};\\\", \\\"{x:796,y:570,t:1528139621597};\\\", \\\"{x:812,y:568,t:1528139621613};\\\", \\\"{x:826,y:565,t:1528139621629};\\\", \\\"{x:835,y:564,t:1528139621646};\\\", \\\"{x:839,y:564,t:1528139621663};\\\", \\\"{x:841,y:564,t:1528139621679};\\\", \\\"{x:841,y:561,t:1528139622847};\\\", \\\"{x:834,y:559,t:1528139622864};\\\", \\\"{x:831,y:557,t:1528139622881};\\\", \\\"{x:826,y:556,t:1528139622898};\\\", \\\"{x:818,y:552,t:1528139622914};\\\", \\\"{x:806,y:546,t:1528139622930};\\\", \\\"{x:790,y:541,t:1528139622946};\\\", \\\"{x:769,y:537,t:1528139622962};\\\", \\\"{x:741,y:531,t:1528139622980};\\\", \\\"{x:720,y:524,t:1528139622998};\\\", \\\"{x:692,y:515,t:1528139623014};\\\", \\\"{x:657,y:506,t:1528139623030};\\\", \\\"{x:610,y:492,t:1528139623047};\\\", \\\"{x:585,y:486,t:1528139623064};\\\", \\\"{x:574,y:485,t:1528139623081};\\\", \\\"{x:560,y:483,t:1528139623097};\\\", \\\"{x:548,y:480,t:1528139623114};\\\", \\\"{x:532,y:477,t:1528139623131};\\\", \\\"{x:510,y:471,t:1528139623148};\\\", \\\"{x:479,y:464,t:1528139623165};\\\", \\\"{x:437,y:459,t:1528139623181};\\\", \\\"{x:411,y:455,t:1528139623197};\\\", \\\"{x:395,y:454,t:1528139623215};\\\", \\\"{x:394,y:454,t:1528139623230};\\\", \\\"{x:392,y:454,t:1528139623248};\\\", \\\"{x:393,y:454,t:1528139623327};\\\", \\\"{x:395,y:454,t:1528139623335};\\\", \\\"{x:400,y:455,t:1528139623348};\\\", \\\"{x:407,y:458,t:1528139623364};\\\", \\\"{x:419,y:461,t:1528139623381};\\\", \\\"{x:442,y:464,t:1528139623398};\\\", \\\"{x:506,y:471,t:1528139623415};\\\", \\\"{x:562,y:481,t:1528139623431};\\\", \\\"{x:616,y:482,t:1528139623448};\\\", \\\"{x:668,y:487,t:1528139623465};\\\", \\\"{x:726,y:487,t:1528139623482};\\\", \\\"{x:802,y:489,t:1528139623498};\\\", \\\"{x:865,y:496,t:1528139623515};\\\", \\\"{x:896,y:496,t:1528139623532};\\\", \\\"{x:919,y:496,t:1528139623548};\\\", \\\"{x:935,y:496,t:1528139623565};\\\", \\\"{x:946,y:496,t:1528139623581};\\\", \\\"{x:960,y:496,t:1528139623597};\\\", \\\"{x:970,y:496,t:1528139623615};\\\", \\\"{x:977,y:496,t:1528139623631};\\\", \\\"{x:988,y:496,t:1528139623649};\\\", \\\"{x:1003,y:496,t:1528139623665};\\\", \\\"{x:1019,y:496,t:1528139623682};\\\", \\\"{x:1039,y:496,t:1528139623698};\\\", \\\"{x:1057,y:497,t:1528139623715};\\\", \\\"{x:1076,y:502,t:1528139623733};\\\", \\\"{x:1098,y:508,t:1528139623748};\\\", \\\"{x:1124,y:516,t:1528139623765};\\\", \\\"{x:1165,y:525,t:1528139623782};\\\", \\\"{x:1217,y:536,t:1528139623798};\\\", \\\"{x:1264,y:548,t:1528139623815};\\\", \\\"{x:1311,y:561,t:1528139623831};\\\", \\\"{x:1327,y:567,t:1528139623848};\\\", \\\"{x:1333,y:568,t:1528139623865};\\\", \\\"{x:1334,y:568,t:1528139623882};\\\", \\\"{x:1334,y:569,t:1528139623903};\\\", \\\"{x:1334,y:571,t:1528139623928};\\\", \\\"{x:1334,y:574,t:1528139623936};\\\", \\\"{x:1335,y:578,t:1528139623948};\\\", \\\"{x:1337,y:582,t:1528139623964};\\\", \\\"{x:1337,y:586,t:1528139623981};\\\", \\\"{x:1336,y:589,t:1528139623999};\\\", \\\"{x:1333,y:591,t:1528139624014};\\\", \\\"{x:1331,y:592,t:1528139624031};\\\", \\\"{x:1329,y:592,t:1528139624048};\\\", \\\"{x:1327,y:592,t:1528139624064};\\\", \\\"{x:1325,y:592,t:1528139624082};\\\", \\\"{x:1321,y:593,t:1528139624099};\\\", \\\"{x:1318,y:593,t:1528139624115};\\\", \\\"{x:1316,y:595,t:1528139624131};\\\", \\\"{x:1313,y:595,t:1528139624149};\\\", \\\"{x:1309,y:595,t:1528139624164};\\\", \\\"{x:1303,y:595,t:1528139624181};\\\", \\\"{x:1294,y:595,t:1528139624199};\\\", \\\"{x:1286,y:595,t:1528139624215};\\\", \\\"{x:1277,y:595,t:1528139624232};\\\", \\\"{x:1263,y:595,t:1528139624249};\\\", \\\"{x:1253,y:595,t:1528139624265};\\\", \\\"{x:1240,y:595,t:1528139624282};\\\", \\\"{x:1236,y:595,t:1528139624299};\\\", \\\"{x:1235,y:595,t:1528139624315};\\\", \\\"{x:1234,y:595,t:1528139624332};\\\", \\\"{x:1232,y:595,t:1528139624349};\\\", \\\"{x:1229,y:595,t:1528139624365};\\\", \\\"{x:1228,y:598,t:1528139624382};\\\", \\\"{x:1228,y:610,t:1528139624399};\\\", \\\"{x:1225,y:626,t:1528139624415};\\\", \\\"{x:1225,y:642,t:1528139624432};\\\", \\\"{x:1225,y:672,t:1528139624449};\\\", \\\"{x:1230,y:697,t:1528139624467};\\\", \\\"{x:1237,y:716,t:1528139624482};\\\", \\\"{x:1243,y:729,t:1528139624499};\\\", \\\"{x:1251,y:745,t:1528139624516};\\\", \\\"{x:1257,y:758,t:1528139624532};\\\", \\\"{x:1258,y:766,t:1528139624549};\\\", \\\"{x:1262,y:774,t:1528139624566};\\\", \\\"{x:1265,y:782,t:1528139624582};\\\", \\\"{x:1266,y:788,t:1528139624599};\\\", \\\"{x:1267,y:791,t:1528139624615};\\\", \\\"{x:1267,y:795,t:1528139624632};\\\", \\\"{x:1267,y:801,t:1528139624649};\\\", \\\"{x:1268,y:806,t:1528139624666};\\\", \\\"{x:1271,y:815,t:1528139624682};\\\", \\\"{x:1277,y:827,t:1528139624706};\\\", \\\"{x:1287,y:841,t:1528139624717};\\\", \\\"{x:1309,y:859,t:1528139624748};\\\", \\\"{x:1318,y:862,t:1528139624766};\\\", \\\"{x:1327,y:864,t:1528139624782};\\\", \\\"{x:1329,y:864,t:1528139624799};\\\", \\\"{x:1330,y:864,t:1528139624816};\\\", \\\"{x:1331,y:864,t:1528139624862};\\\", \\\"{x:1332,y:864,t:1528139624878};\\\", \\\"{x:1334,y:864,t:1528139624886};\\\", \\\"{x:1335,y:863,t:1528139624899};\\\", \\\"{x:1339,y:858,t:1528139624915};\\\", \\\"{x:1344,y:852,t:1528139624932};\\\", \\\"{x:1347,y:848,t:1528139624950};\\\", \\\"{x:1353,y:841,t:1528139624966};\\\", \\\"{x:1354,y:841,t:1528139624982};\\\", \\\"{x:1356,y:838,t:1528139624999};\\\", \\\"{x:1357,y:837,t:1528139625022};\\\", \\\"{x:1359,y:837,t:1528139625033};\\\", \\\"{x:1363,y:834,t:1528139625050};\\\", \\\"{x:1366,y:832,t:1528139625066};\\\", \\\"{x:1368,y:831,t:1528139625082};\\\", \\\"{x:1369,y:831,t:1528139625099};\\\", \\\"{x:1369,y:830,t:1528139625116};\\\", \\\"{x:1370,y:829,t:1528139625133};\\\", \\\"{x:1371,y:829,t:1528139625149};\\\", \\\"{x:1371,y:828,t:1528139625166};\\\", \\\"{x:1371,y:827,t:1528139625183};\\\", \\\"{x:1371,y:825,t:1528139625200};\\\", \\\"{x:1370,y:824,t:1528139625416};\\\", \\\"{x:1369,y:824,t:1528139625434};\\\", \\\"{x:1366,y:824,t:1528139625451};\\\", \\\"{x:1361,y:822,t:1528139625468};\\\", \\\"{x:1357,y:822,t:1528139625484};\\\", \\\"{x:1352,y:822,t:1528139625501};\\\", \\\"{x:1347,y:821,t:1528139625518};\\\", \\\"{x:1344,y:820,t:1528139625534};\\\", \\\"{x:1337,y:818,t:1528139625552};\\\", \\\"{x:1329,y:816,t:1528139625567};\\\", \\\"{x:1320,y:813,t:1528139625585};\\\", \\\"{x:1317,y:812,t:1528139625601};\\\", \\\"{x:1314,y:811,t:1528139625619};\\\", \\\"{x:1310,y:809,t:1528139625635};\\\", \\\"{x:1308,y:808,t:1528139625651};\\\", \\\"{x:1306,y:805,t:1528139625668};\\\", \\\"{x:1305,y:803,t:1528139625685};\\\", \\\"{x:1303,y:798,t:1528139625701};\\\", \\\"{x:1302,y:792,t:1528139625718};\\\", \\\"{x:1300,y:778,t:1528139625735};\\\", \\\"{x:1292,y:757,t:1528139625751};\\\", \\\"{x:1286,y:737,t:1528139625768};\\\", \\\"{x:1285,y:726,t:1528139625785};\\\", \\\"{x:1285,y:721,t:1528139625802};\\\", \\\"{x:1285,y:709,t:1528139625818};\\\", \\\"{x:1288,y:697,t:1528139625835};\\\", \\\"{x:1293,y:686,t:1528139625852};\\\", \\\"{x:1299,y:673,t:1528139625868};\\\", \\\"{x:1306,y:658,t:1528139625885};\\\", \\\"{x:1315,y:643,t:1528139625902};\\\", \\\"{x:1322,y:627,t:1528139625920};\\\", \\\"{x:1327,y:615,t:1528139625936};\\\", \\\"{x:1333,y:604,t:1528139625952};\\\", \\\"{x:1338,y:594,t:1528139625969};\\\", \\\"{x:1343,y:587,t:1528139625985};\\\", \\\"{x:1346,y:583,t:1528139626002};\\\", \\\"{x:1348,y:582,t:1528139626019};\\\", \\\"{x:1349,y:582,t:1528139626063};\\\", \\\"{x:1351,y:582,t:1528139626270};\\\", \\\"{x:1355,y:582,t:1528139626286};\\\", \\\"{x:1395,y:577,t:1528139626302};\\\", \\\"{x:1424,y:571,t:1528139626319};\\\", \\\"{x:1456,y:562,t:1528139626336};\\\", \\\"{x:1486,y:553,t:1528139626353};\\\", \\\"{x:1510,y:542,t:1528139626369};\\\", \\\"{x:1530,y:533,t:1528139626385};\\\", \\\"{x:1547,y:524,t:1528139626403};\\\", \\\"{x:1559,y:519,t:1528139626420};\\\", \\\"{x:1568,y:515,t:1528139626435};\\\", \\\"{x:1570,y:513,t:1528139626453};\\\", \\\"{x:1574,y:510,t:1528139626470};\\\", \\\"{x:1577,y:508,t:1528139626487};\\\", \\\"{x:1579,y:506,t:1528139626503};\\\", \\\"{x:1581,y:504,t:1528139626520};\\\", \\\"{x:1582,y:502,t:1528139626536};\\\", \\\"{x:1586,y:500,t:1528139626553};\\\", \\\"{x:1589,y:498,t:1528139626570};\\\", \\\"{x:1590,y:495,t:1528139626587};\\\", \\\"{x:1592,y:492,t:1528139626603};\\\", \\\"{x:1595,y:487,t:1528139626619};\\\", \\\"{x:1595,y:485,t:1528139626637};\\\", \\\"{x:1597,y:481,t:1528139626653};\\\", \\\"{x:1599,y:476,t:1528139626669};\\\", \\\"{x:1605,y:464,t:1528139626686};\\\", \\\"{x:1609,y:454,t:1528139626702};\\\", \\\"{x:1615,y:445,t:1528139626719};\\\", \\\"{x:1619,y:437,t:1528139626736};\\\", \\\"{x:1623,y:431,t:1528139626753};\\\", \\\"{x:1626,y:426,t:1528139626769};\\\", \\\"{x:1629,y:422,t:1528139626787};\\\", \\\"{x:1630,y:420,t:1528139626803};\\\", \\\"{x:1633,y:417,t:1528139626820};\\\", \\\"{x:1633,y:415,t:1528139626836};\\\", \\\"{x:1634,y:414,t:1528139626853};\\\", \\\"{x:1633,y:414,t:1528139627046};\\\", \\\"{x:1632,y:414,t:1528139627070};\\\", \\\"{x:1631,y:414,t:1528139627111};\\\", \\\"{x:1629,y:414,t:1528139627142};\\\", \\\"{x:1627,y:414,t:1528139627153};\\\", \\\"{x:1624,y:414,t:1528139627171};\\\", \\\"{x:1623,y:414,t:1528139627188};\\\", \\\"{x:1621,y:414,t:1528139627205};\\\", \\\"{x:1620,y:414,t:1528139627220};\\\", \\\"{x:1617,y:415,t:1528139627238};\\\", \\\"{x:1616,y:417,t:1528139627254};\\\", \\\"{x:1613,y:421,t:1528139627271};\\\", \\\"{x:1613,y:429,t:1528139627289};\\\", \\\"{x:1611,y:442,t:1528139627305};\\\", \\\"{x:1608,y:456,t:1528139627321};\\\", \\\"{x:1608,y:464,t:1528139627330};\\\", \\\"{x:1606,y:479,t:1528139627347};\\\", \\\"{x:1603,y:492,t:1528139627364};\\\", \\\"{x:1602,y:501,t:1528139627381};\\\", \\\"{x:1602,y:511,t:1528139627396};\\\", \\\"{x:1602,y:521,t:1528139627413};\\\", \\\"{x:1602,y:533,t:1528139627431};\\\", \\\"{x:1602,y:534,t:1528139627447};\\\", \\\"{x:1602,y:535,t:1528139627471};\\\", \\\"{x:1602,y:536,t:1528139627543};\\\", \\\"{x:1602,y:539,t:1528139627551};\\\", \\\"{x:1602,y:543,t:1528139627564};\\\", \\\"{x:1603,y:550,t:1528139627581};\\\", \\\"{x:1605,y:557,t:1528139627598};\\\", \\\"{x:1605,y:561,t:1528139627613};\\\", \\\"{x:1607,y:566,t:1528139627631};\\\", \\\"{x:1608,y:570,t:1528139627647};\\\", \\\"{x:1609,y:574,t:1528139627664};\\\", \\\"{x:1610,y:576,t:1528139627680};\\\", \\\"{x:1611,y:578,t:1528139627697};\\\", \\\"{x:1612,y:578,t:1528139627714};\\\", \\\"{x:1613,y:578,t:1528139627815};\\\", \\\"{x:1614,y:578,t:1528139627912};\\\", \\\"{x:1614,y:580,t:1528139628119};\\\", \\\"{x:1614,y:582,t:1528139628130};\\\", \\\"{x:1615,y:585,t:1528139628147};\\\", \\\"{x:1617,y:589,t:1528139628164};\\\", \\\"{x:1619,y:598,t:1528139628180};\\\", \\\"{x:1621,y:604,t:1528139628197};\\\", \\\"{x:1623,y:613,t:1528139628213};\\\", \\\"{x:1625,y:619,t:1528139628230};\\\", \\\"{x:1627,y:628,t:1528139628247};\\\", \\\"{x:1628,y:634,t:1528139628264};\\\", \\\"{x:1629,y:638,t:1528139628280};\\\", \\\"{x:1629,y:641,t:1528139628297};\\\", \\\"{x:1629,y:643,t:1528139628313};\\\", \\\"{x:1629,y:644,t:1528139628342};\\\", \\\"{x:1627,y:644,t:1528139628406};\\\", \\\"{x:1626,y:644,t:1528139628415};\\\", \\\"{x:1624,y:644,t:1528139628430};\\\", \\\"{x:1616,y:641,t:1528139628446};\\\", \\\"{x:1592,y:628,t:1528139628463};\\\", \\\"{x:1585,y:621,t:1528139628480};\\\", \\\"{x:1585,y:622,t:1528139628560};\\\", \\\"{x:1578,y:623,t:1528139628567};\\\", \\\"{x:1578,y:624,t:1528139628580};\\\", \\\"{x:1577,y:625,t:1528139628596};\\\", \\\"{x:1568,y:627,t:1528139628613};\\\", \\\"{x:1555,y:631,t:1528139628630};\\\", \\\"{x:1550,y:632,t:1528139628646};\\\", \\\"{x:1535,y:638,t:1528139628663};\\\", \\\"{x:1515,y:644,t:1528139628680};\\\", \\\"{x:1483,y:655,t:1528139628696};\\\", \\\"{x:1440,y:664,t:1528139628713};\\\", \\\"{x:1410,y:676,t:1528139628730};\\\", \\\"{x:1370,y:687,t:1528139628746};\\\", \\\"{x:1328,y:701,t:1528139628763};\\\", \\\"{x:1282,y:709,t:1528139628780};\\\", \\\"{x:1233,y:712,t:1528139628796};\\\", \\\"{x:1203,y:716,t:1528139628812};\\\", \\\"{x:1185,y:719,t:1528139628829};\\\", \\\"{x:1170,y:719,t:1528139628845};\\\", \\\"{x:1146,y:719,t:1528139628862};\\\", \\\"{x:1116,y:719,t:1528139628880};\\\", \\\"{x:1072,y:716,t:1528139628895};\\\", \\\"{x:1011,y:709,t:1528139628912};\\\", \\\"{x:938,y:706,t:1528139628929};\\\", \\\"{x:877,y:706,t:1528139628946};\\\", \\\"{x:798,y:702,t:1528139628963};\\\", \\\"{x:711,y:696,t:1528139628979};\\\", \\\"{x:624,y:681,t:1528139628997};\\\", \\\"{x:543,y:668,t:1528139629013};\\\", \\\"{x:450,y:656,t:1528139629037};\\\", \\\"{x:399,y:655,t:1528139629054};\\\", \\\"{x:377,y:654,t:1528139629068};\\\", \\\"{x:365,y:651,t:1528139629087};\\\", \\\"{x:358,y:650,t:1528139629103};\\\", \\\"{x:344,y:647,t:1528139629119};\\\", \\\"{x:320,y:647,t:1528139629135};\\\", \\\"{x:291,y:647,t:1528139629153};\\\", \\\"{x:276,y:647,t:1528139629169};\\\", \\\"{x:274,y:647,t:1528139629186};\\\", \\\"{x:273,y:647,t:1528139629202};\\\", \\\"{x:276,y:647,t:1528139629239};\\\", \\\"{x:284,y:645,t:1528139629253};\\\", \\\"{x:304,y:638,t:1528139629269};\\\", \\\"{x:331,y:627,t:1528139629288};\\\", \\\"{x:343,y:621,t:1528139629303};\\\", \\\"{x:345,y:620,t:1528139629319};\\\", \\\"{x:346,y:620,t:1528139629336};\\\", \\\"{x:346,y:619,t:1528139629375};\\\", \\\"{x:348,y:618,t:1528139629399};\\\", \\\"{x:348,y:617,t:1528139629409};\\\", \\\"{x:348,y:616,t:1528139629420};\\\", \\\"{x:350,y:614,t:1528139629435};\\\", \\\"{x:353,y:612,t:1528139629453};\\\", \\\"{x:359,y:608,t:1528139629469};\\\", \\\"{x:367,y:605,t:1528139629486};\\\", \\\"{x:381,y:599,t:1528139629503};\\\", \\\"{x:390,y:594,t:1528139629519};\\\", \\\"{x:403,y:586,t:1528139629535};\\\", \\\"{x:412,y:581,t:1528139629554};\\\", \\\"{x:423,y:576,t:1528139629569};\\\", \\\"{x:438,y:571,t:1528139629586};\\\", \\\"{x:453,y:567,t:1528139629602};\\\", \\\"{x:468,y:566,t:1528139629620};\\\", \\\"{x:483,y:563,t:1528139629635};\\\", \\\"{x:507,y:563,t:1528139629654};\\\", \\\"{x:535,y:561,t:1528139629670};\\\", \\\"{x:586,y:561,t:1528139629686};\\\", \\\"{x:644,y:561,t:1528139629702};\\\", \\\"{x:724,y:569,t:1528139629720};\\\", \\\"{x:783,y:571,t:1528139629737};\\\", \\\"{x:834,y:571,t:1528139629752};\\\", \\\"{x:864,y:571,t:1528139629770};\\\", \\\"{x:882,y:572,t:1528139629786};\\\", \\\"{x:893,y:573,t:1528139629803};\\\", \\\"{x:898,y:575,t:1528139629819};\\\", \\\"{x:901,y:575,t:1528139629835};\\\", \\\"{x:895,y:575,t:1528139629936};\\\", \\\"{x:887,y:573,t:1528139629943};\\\", \\\"{x:873,y:570,t:1528139629954};\\\", \\\"{x:839,y:570,t:1528139629969};\\\", \\\"{x:801,y:570,t:1528139629986};\\\", \\\"{x:743,y:570,t:1528139630003};\\\", \\\"{x:645,y:570,t:1528139630021};\\\", \\\"{x:550,y:566,t:1528139630037};\\\", \\\"{x:463,y:561,t:1528139630053};\\\", \\\"{x:377,y:561,t:1528139630070};\\\", \\\"{x:320,y:561,t:1528139630086};\\\", \\\"{x:255,y:572,t:1528139630103};\\\", \\\"{x:225,y:573,t:1528139630120};\\\", \\\"{x:197,y:578,t:1528139630136};\\\", \\\"{x:184,y:581,t:1528139630153};\\\", \\\"{x:182,y:581,t:1528139630169};\\\", \\\"{x:181,y:582,t:1528139630198};\\\", \\\"{x:180,y:583,t:1528139630207};\\\", \\\"{x:179,y:585,t:1528139630223};\\\", \\\"{x:178,y:588,t:1528139630239};\\\", \\\"{x:178,y:590,t:1528139630254};\\\", \\\"{x:176,y:595,t:1528139630270};\\\", \\\"{x:174,y:602,t:1528139630286};\\\", \\\"{x:173,y:612,t:1528139630304};\\\", \\\"{x:173,y:628,t:1528139630321};\\\", \\\"{x:177,y:649,t:1528139630338};\\\", \\\"{x:188,y:668,t:1528139630354};\\\", \\\"{x:196,y:675,t:1528139630370};\\\", \\\"{x:207,y:678,t:1528139630387};\\\", \\\"{x:221,y:680,t:1528139630403};\\\", \\\"{x:244,y:680,t:1528139630419};\\\", \\\"{x:279,y:673,t:1528139630437};\\\", \\\"{x:329,y:659,t:1528139630453};\\\", \\\"{x:363,y:649,t:1528139630469};\\\", \\\"{x:409,y:633,t:1528139630486};\\\", \\\"{x:428,y:626,t:1528139630504};\\\", \\\"{x:435,y:622,t:1528139630519};\\\", \\\"{x:436,y:622,t:1528139630542};\\\", \\\"{x:436,y:621,t:1528139630648};\\\", \\\"{x:434,y:618,t:1528139630663};\\\", \\\"{x:428,y:616,t:1528139630672};\\\", \\\"{x:420,y:613,t:1528139630687};\\\", \\\"{x:414,y:610,t:1528139630704};\\\", \\\"{x:410,y:608,t:1528139630720};\\\", \\\"{x:404,y:606,t:1528139630737};\\\", \\\"{x:403,y:605,t:1528139630753};\\\", \\\"{x:407,y:606,t:1528139630879};\\\", \\\"{x:414,y:609,t:1528139630888};\\\", \\\"{x:427,y:614,t:1528139630905};\\\", \\\"{x:436,y:618,t:1528139630921};\\\", \\\"{x:442,y:620,t:1528139630937};\\\", \\\"{x:450,y:620,t:1528139630954};\\\", \\\"{x:463,y:622,t:1528139630970};\\\", \\\"{x:474,y:623,t:1528139630987};\\\", \\\"{x:494,y:626,t:1528139631004};\\\", \\\"{x:509,y:628,t:1528139631021};\\\", \\\"{x:519,y:630,t:1528139631038};\\\", \\\"{x:522,y:631,t:1528139631053};\\\", \\\"{x:523,y:632,t:1528139631102};\\\", \\\"{x:523,y:634,t:1528139631118};\\\", \\\"{x:523,y:639,t:1528139631127};\\\", \\\"{x:523,y:647,t:1528139631137};\\\", \\\"{x:523,y:661,t:1528139631155};\\\", \\\"{x:523,y:672,t:1528139631171};\\\", \\\"{x:521,y:682,t:1528139631188};\\\", \\\"{x:516,y:687,t:1528139631204};\\\", \\\"{x:512,y:690,t:1528139631221};\\\", \\\"{x:502,y:692,t:1528139631238};\\\", \\\"{x:487,y:692,t:1528139631253};\\\", \\\"{x:463,y:690,t:1528139631271};\\\", \\\"{x:454,y:688,t:1528139631288};\\\", \\\"{x:447,y:683,t:1528139631304};\\\", \\\"{x:431,y:674,t:1528139631321};\\\", \\\"{x:392,y:651,t:1528139631338};\\\", \\\"{x:359,y:622,t:1528139631355};\\\", \\\"{x:342,y:606,t:1528139631372};\\\", \\\"{x:333,y:595,t:1528139631388};\\\", \\\"{x:324,y:582,t:1528139631403};\\\", \\\"{x:322,y:577,t:1528139631423};\\\", \\\"{x:322,y:574,t:1528139631438};\\\", \\\"{x:321,y:568,t:1528139631455};\\\", \\\"{x:317,y:563,t:1528139631471};\\\", \\\"{x:310,y:559,t:1528139631488};\\\", \\\"{x:300,y:554,t:1528139631504};\\\", \\\"{x:286,y:552,t:1528139631521};\\\", \\\"{x:260,y:550,t:1528139631539};\\\", \\\"{x:233,y:556,t:1528139631555};\\\", \\\"{x:209,y:567,t:1528139631571};\\\", \\\"{x:188,y:575,t:1528139631588};\\\", \\\"{x:171,y:585,t:1528139631604};\\\", \\\"{x:160,y:593,t:1528139631620};\\\", \\\"{x:153,y:597,t:1528139631637};\\\", \\\"{x:147,y:601,t:1528139631654};\\\", \\\"{x:145,y:602,t:1528139631671};\\\", \\\"{x:143,y:602,t:1528139631688};\\\", \\\"{x:140,y:602,t:1528139631704};\\\", \\\"{x:139,y:602,t:1528139631720};\\\", \\\"{x:145,y:602,t:1528139631839};\\\", \\\"{x:160,y:602,t:1528139631857};\\\", \\\"{x:175,y:602,t:1528139631871};\\\", \\\"{x:184,y:602,t:1528139631887};\\\", \\\"{x:185,y:604,t:1528139631942};\\\", \\\"{x:185,y:608,t:1528139631955};\\\", \\\"{x:184,y:621,t:1528139631972};\\\", \\\"{x:180,y:634,t:1528139631987};\\\", \\\"{x:176,y:646,t:1528139632005};\\\", \\\"{x:172,y:660,t:1528139632022};\\\", \\\"{x:170,y:672,t:1528139632038};\\\", \\\"{x:168,y:678,t:1528139632054};\\\", \\\"{x:168,y:679,t:1528139632116};\\\", \\\"{x:167,y:680,t:1528139632124};\\\", \\\"{x:167,y:682,t:1528139632135};\\\", \\\"{x:167,y:683,t:1528139632153};\\\", \\\"{x:167,y:684,t:1528139632169};\\\", \\\"{x:166,y:685,t:1528139632821};\\\", \\\"{x:165,y:685,t:1528139632837};\\\", \\\"{x:164,y:684,t:1528139632861};\\\", \\\"{x:163,y:683,t:1528139632869};\\\", \\\"{x:162,y:681,t:1528139632887};\\\", \\\"{x:161,y:680,t:1528139632908};\\\", \\\"{x:160,y:679,t:1528139632919};\\\", \\\"{x:159,y:679,t:1528139632940};\\\", \\\"{x:159,y:678,t:1528139632954};\\\", \\\"{x:158,y:678,t:1528139633149};\\\", \\\"{x:158,y:678,t:1528139633229};\\\", \\\"{x:161,y:675,t:1528139633477};\\\", \\\"{x:168,y:675,t:1528139633487};\\\", \\\"{x:190,y:675,t:1528139633505};\\\", \\\"{x:217,y:675,t:1528139633522};\\\", \\\"{x:251,y:673,t:1528139633537};\\\", \\\"{x:301,y:673,t:1528139633554};\\\", \\\"{x:387,y:673,t:1528139633571};\\\", \\\"{x:501,y:673,t:1528139633587};\\\", \\\"{x:645,y:676,t:1528139633604};\\\", \\\"{x:829,y:687,t:1528139633621};\\\", \\\"{x:932,y:689,t:1528139633636};\\\", \\\"{x:999,y:698,t:1528139633653};\\\", \\\"{x:1028,y:702,t:1528139633670};\\\", \\\"{x:1042,y:704,t:1528139633686};\\\", \\\"{x:1048,y:706,t:1528139633704};\\\", \\\"{x:1052,y:707,t:1528139633720};\\\", \\\"{x:1055,y:707,t:1528139633736};\\\", \\\"{x:1056,y:708,t:1528139633753};\\\", \\\"{x:1057,y:708,t:1528139633770};\\\", \\\"{x:1060,y:709,t:1528139633901};\\\", \\\"{x:1062,y:710,t:1528139633917};\\\", \\\"{x:1065,y:711,t:1528139633925};\\\", \\\"{x:1068,y:712,t:1528139633937};\\\", \\\"{x:1075,y:715,t:1528139633953};\\\", \\\"{x:1091,y:721,t:1528139633970};\\\", \\\"{x:1112,y:727,t:1528139633985};\\\", \\\"{x:1139,y:735,t:1528139634003};\\\", \\\"{x:1180,y:752,t:1528139634020};\\\", \\\"{x:1223,y:768,t:1528139634036};\\\", \\\"{x:1280,y:792,t:1528139634052};\\\", \\\"{x:1296,y:798,t:1528139634070};\\\", \\\"{x:1297,y:800,t:1528139634086};\\\", \\\"{x:1298,y:800,t:1528139634292};\\\", \\\"{x:1300,y:802,t:1528139634308};\\\", \\\"{x:1301,y:802,t:1528139634318};\\\", \\\"{x:1307,y:807,t:1528139634336};\\\", \\\"{x:1313,y:812,t:1528139634352};\\\", \\\"{x:1320,y:820,t:1528139634369};\\\", \\\"{x:1333,y:830,t:1528139634385};\\\", \\\"{x:1341,y:837,t:1528139634402};\\\", \\\"{x:1347,y:840,t:1528139634419};\\\", \\\"{x:1349,y:842,t:1528139634435};\\\", \\\"{x:1349,y:843,t:1528139634493};\\\", \\\"{x:1349,y:845,t:1528139634509};\\\", \\\"{x:1349,y:848,t:1528139634519};\\\", \\\"{x:1349,y:854,t:1528139634535};\\\", \\\"{x:1349,y:858,t:1528139634553};\\\", \\\"{x:1354,y:864,t:1528139634568};\\\", \\\"{x:1354,y:865,t:1528139634586};\\\", \\\"{x:1354,y:866,t:1528139638237};\\\", \\\"{x:1354,y:867,t:1528139638334};\\\", \\\"{x:1354,y:868,t:1528139638373};\\\", \\\"{x:1354,y:869,t:1528139638381};\\\", \\\"{x:1355,y:871,t:1528139638393};\\\", \\\"{x:1360,y:873,t:1528139638409};\\\", \\\"{x:1361,y:875,t:1528139638427};\\\", \\\"{x:1363,y:875,t:1528139638443};\\\", \\\"{x:1364,y:875,t:1528139639894};\\\", \\\"{x:1367,y:875,t:1528139639905};\\\", \\\"{x:1435,y:816,t:1528139639922};\\\", \\\"{x:1532,y:691,t:1528139639939};\\\", \\\"{x:1624,y:521,t:1528139639956};\\\", \\\"{x:1750,y:252,t:1528139639972};\\\", \\\"{x:1819,y:71,t:1528139639989};\\\", \\\"{x:1860,y:0,t:1528139640006};\\\", \\\"{x:1883,y:0,t:1528139640022};\\\", \\\"{x:1901,y:0,t:1528139640038};\\\", \\\"{x:1904,y:0,t:1528139640055};\\\", \\\"{x:1905,y:0,t:1528139640072};\\\", \\\"{x:1904,y:0,t:1528139640116};\\\", \\\"{x:1898,y:0,t:1528139640125};\\\", \\\"{x:1889,y:2,t:1528139640136};\\\", \\\"{x:1867,y:13,t:1528139640159};\\\", \\\"{x:1861,y:19,t:1528139640176};\\\", \\\"{x:1854,y:25,t:1528139640192};\\\", \\\"{x:1847,y:27,t:1528139640209};\\\", \\\"{x:1838,y:31,t:1528139640226};\\\", \\\"{x:1816,y:41,t:1528139640243};\\\", \\\"{x:1795,y:52,t:1528139640259};\\\", \\\"{x:1742,y:82,t:1528139640276};\\\", \\\"{x:1696,y:107,t:1528139640292};\\\", \\\"{x:1660,y:124,t:1528139640308};\\\", \\\"{x:1636,y:132,t:1528139640326};\\\", \\\"{x:1626,y:137,t:1528139640343};\\\", \\\"{x:1621,y:139,t:1528139640360};\\\", \\\"{x:1619,y:139,t:1528139640376};\\\", \\\"{x:1617,y:140,t:1528139640393};\\\", \\\"{x:1615,y:141,t:1528139640409};\\\", \\\"{x:1613,y:142,t:1528139640426};\\\", \\\"{x:1611,y:143,t:1528139640443};\\\", \\\"{x:1608,y:143,t:1528139640459};\\\", \\\"{x:1597,y:144,t:1528139640476};\\\", \\\"{x:1592,y:144,t:1528139640492};\\\", \\\"{x:1588,y:144,t:1528139640508};\\\", \\\"{x:1585,y:144,t:1528139640526};\\\", \\\"{x:1576,y:144,t:1528139640543};\\\", \\\"{x:1559,y:144,t:1528139640559};\\\", \\\"{x:1541,y:144,t:1528139640576};\\\", \\\"{x:1524,y:144,t:1528139640592};\\\", \\\"{x:1512,y:144,t:1528139640609};\\\", \\\"{x:1501,y:144,t:1528139640626};\\\", \\\"{x:1495,y:144,t:1528139640643};\\\", \\\"{x:1493,y:146,t:1528139640659};\\\", \\\"{x:1491,y:147,t:1528139640676};\\\", \\\"{x:1489,y:148,t:1528139640693};\\\", \\\"{x:1488,y:149,t:1528139640709};\\\", \\\"{x:1487,y:151,t:1528139640726};\\\", \\\"{x:1487,y:152,t:1528139640743};\\\", \\\"{x:1486,y:153,t:1528139640759};\\\", \\\"{x:1486,y:154,t:1528139640781};\\\", \\\"{x:1486,y:155,t:1528139640797};\\\", \\\"{x:1485,y:156,t:1528139640811};\\\", \\\"{x:1484,y:157,t:1528139640827};\\\", \\\"{x:1483,y:159,t:1528139640847};\\\", \\\"{x:1481,y:160,t:1528139640876};\\\", \\\"{x:1480,y:160,t:1528139640940};\\\", \\\"{x:1480,y:161,t:1528139640948};\\\", \\\"{x:1479,y:162,t:1528139640959};\\\", \\\"{x:1478,y:162,t:1528139643918};\\\", \\\"{x:1478,y:163,t:1528139643981};\\\", \\\"{x:1478,y:164,t:1528139643993};\\\", \\\"{x:1478,y:165,t:1528139644011};\\\", \\\"{x:1469,y:169,t:1528139644030};\\\", \\\"{x:1451,y:179,t:1528139644044};\\\", \\\"{x:1437,y:185,t:1528139644059};\\\", \\\"{x:1416,y:197,t:1528139644079};\\\", \\\"{x:1385,y:210,t:1528139644095};\\\", \\\"{x:1347,y:227,t:1528139644112};\\\", \\\"{x:1288,y:252,t:1528139644128};\\\", \\\"{x:1219,y:283,t:1528139644145};\\\", \\\"{x:1140,y:316,t:1528139644162};\\\", \\\"{x:1045,y:343,t:1528139644179};\\\", \\\"{x:943,y:373,t:1528139644195};\\\", \\\"{x:770,y:408,t:1528139644212};\\\", \\\"{x:647,y:440,t:1528139644229};\\\", \\\"{x:515,y:494,t:1528139644246};\\\", \\\"{x:397,y:540,t:1528139644262};\\\", \\\"{x:302,y:572,t:1528139644280};\\\", \\\"{x:243,y:590,t:1528139644296};\\\", \\\"{x:207,y:604,t:1528139644311};\\\", \\\"{x:180,y:617,t:1528139644330};\\\", \\\"{x:159,y:632,t:1528139644346};\\\", \\\"{x:143,y:646,t:1528139644362};\\\", \\\"{x:133,y:662,t:1528139644379};\\\", \\\"{x:127,y:688,t:1528139644396};\\\", \\\"{x:127,y:708,t:1528139644412};\\\", \\\"{x:131,y:727,t:1528139644429};\\\", \\\"{x:140,y:734,t:1528139644445};\\\", \\\"{x:148,y:745,t:1528139644462};\\\", \\\"{x:161,y:759,t:1528139644479};\\\", \\\"{x:185,y:777,t:1528139644496};\\\", \\\"{x:217,y:796,t:1528139644512};\\\", \\\"{x:241,y:808,t:1528139644529};\\\", \\\"{x:261,y:813,t:1528139644546};\\\", \\\"{x:286,y:817,t:1528139644562};\\\", \\\"{x:315,y:820,t:1528139644579};\\\", \\\"{x:354,y:821,t:1528139644596};\\\", \\\"{x:370,y:818,t:1528139644612};\\\", \\\"{x:383,y:812,t:1528139644629};\\\", \\\"{x:402,y:803,t:1528139644646};\\\", \\\"{x:420,y:801,t:1528139644662};\\\", \\\"{x:429,y:799,t:1528139644679};\\\", \\\"{x:435,y:798,t:1528139644697};\\\", \\\"{x:440,y:798,t:1528139644713};\\\", \\\"{x:448,y:795,t:1528139644729};\\\", \\\"{x:458,y:794,t:1528139644747};\\\", \\\"{x:468,y:791,t:1528139644763};\\\", \\\"{x:474,y:788,t:1528139644779};\\\", \\\"{x:483,y:783,t:1528139644796};\\\", \\\"{x:484,y:781,t:1528139644812};\\\", \\\"{x:488,y:778,t:1528139644830};\\\", \\\"{x:492,y:776,t:1528139644847};\\\", \\\"{x:493,y:775,t:1528139644864};\\\", \\\"{x:497,y:772,t:1528139644879};\\\", \\\"{x:498,y:767,t:1528139644898};\\\", \\\"{x:500,y:764,t:1528139644913};\\\", \\\"{x:501,y:761,t:1528139644928};\\\", \\\"{x:503,y:759,t:1528139644944};\\\", \\\"{x:503,y:758,t:1528139644963};\\\", \\\"{x:504,y:758,t:1528139644978};\\\", \\\"{x:504,y:757,t:1528139645036};\\\" ] }, { \\\"rt\\\": 66172, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 379907, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 0, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -11 AM-A -A -A -C -C -C -A -C -A -Z -A -A -O -O -O -I -H -H -H -J -J -X -X -X -D -D -D -K -A -C -11 AM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:753,t:1528139647437};\\\", \\\"{x:512,y:749,t:1528139647448};\\\", \\\"{x:517,y:745,t:1528139647464};\\\", \\\"{x:523,y:740,t:1528139647480};\\\", \\\"{x:529,y:736,t:1528139647497};\\\", \\\"{x:533,y:734,t:1528139647514};\\\", \\\"{x:536,y:732,t:1528139647532};\\\", \\\"{x:536,y:731,t:1528139647548};\\\", \\\"{x:537,y:731,t:1528139647572};\\\", \\\"{x:538,y:731,t:1528139647588};\\\", \\\"{x:539,y:730,t:1528139647598};\\\", \\\"{x:540,y:727,t:1528139650677};\\\", \\\"{x:545,y:718,t:1528139650688};\\\", \\\"{x:555,y:703,t:1528139650704};\\\", \\\"{x:558,y:698,t:1528139650720};\\\", \\\"{x:560,y:696,t:1528139651365};\\\", \\\"{x:560,y:695,t:1528139651372};\\\", \\\"{x:561,y:695,t:1528139651388};\\\", \\\"{x:563,y:693,t:1528139651406};\\\", \\\"{x:568,y:692,t:1528139651423};\\\", \\\"{x:569,y:691,t:1528139651439};\\\", \\\"{x:573,y:691,t:1528139651456};\\\", \\\"{x:578,y:689,t:1528139651473};\\\", \\\"{x:594,y:685,t:1528139651491};\\\", \\\"{x:624,y:679,t:1528139651507};\\\", \\\"{x:670,y:675,t:1528139651523};\\\", \\\"{x:770,y:656,t:1528139651552};\\\", \\\"{x:817,y:644,t:1528139651569};\\\", \\\"{x:862,y:633,t:1528139651586};\\\", \\\"{x:912,y:617,t:1528139651602};\\\", \\\"{x:961,y:607,t:1528139651619};\\\", \\\"{x:1019,y:593,t:1528139651634};\\\", \\\"{x:1065,y:582,t:1528139651651};\\\", \\\"{x:1103,y:571,t:1528139651668};\\\", \\\"{x:1120,y:566,t:1528139651684};\\\", \\\"{x:1134,y:562,t:1528139651701};\\\", \\\"{x:1153,y:557,t:1528139651717};\\\", \\\"{x:1168,y:555,t:1528139651734};\\\", \\\"{x:1175,y:555,t:1528139651752};\\\", \\\"{x:1176,y:555,t:1528139651767};\\\", \\\"{x:1181,y:553,t:1528139651784};\\\", \\\"{x:1187,y:552,t:1528139651800};\\\", \\\"{x:1196,y:552,t:1528139651818};\\\", \\\"{x:1204,y:552,t:1528139651834};\\\", \\\"{x:1213,y:552,t:1528139651851};\\\", \\\"{x:1221,y:552,t:1528139651868};\\\", \\\"{x:1228,y:552,t:1528139651884};\\\", \\\"{x:1238,y:552,t:1528139651900};\\\", \\\"{x:1243,y:552,t:1528139651918};\\\", \\\"{x:1246,y:552,t:1528139651933};\\\", \\\"{x:1252,y:552,t:1528139651951};\\\", \\\"{x:1259,y:553,t:1528139651967};\\\", \\\"{x:1267,y:554,t:1528139651984};\\\", \\\"{x:1275,y:557,t:1528139652001};\\\", \\\"{x:1280,y:557,t:1528139652017};\\\", \\\"{x:1287,y:559,t:1528139652033};\\\", \\\"{x:1291,y:560,t:1528139652051};\\\", \\\"{x:1299,y:562,t:1528139652067};\\\", \\\"{x:1304,y:564,t:1528139652084};\\\", \\\"{x:1308,y:565,t:1528139652100};\\\", \\\"{x:1315,y:569,t:1528139652116};\\\", \\\"{x:1320,y:571,t:1528139652133};\\\", \\\"{x:1325,y:574,t:1528139652149};\\\", \\\"{x:1328,y:577,t:1528139652166};\\\", \\\"{x:1340,y:589,t:1528139652183};\\\", \\\"{x:1356,y:610,t:1528139652199};\\\", \\\"{x:1377,y:632,t:1528139652217};\\\", \\\"{x:1397,y:658,t:1528139652232};\\\", \\\"{x:1409,y:682,t:1528139652249};\\\", \\\"{x:1419,y:700,t:1528139652266};\\\", \\\"{x:1423,y:715,t:1528139652282};\\\", \\\"{x:1427,y:732,t:1528139652299};\\\", \\\"{x:1427,y:737,t:1528139652316};\\\", \\\"{x:1426,y:741,t:1528139652333};\\\", \\\"{x:1421,y:747,t:1528139652349};\\\", \\\"{x:1414,y:751,t:1528139652365};\\\", \\\"{x:1408,y:755,t:1528139652382};\\\", \\\"{x:1400,y:759,t:1528139652399};\\\", \\\"{x:1393,y:763,t:1528139652416};\\\", \\\"{x:1386,y:767,t:1528139652433};\\\", \\\"{x:1376,y:771,t:1528139652449};\\\", \\\"{x:1366,y:773,t:1528139652465};\\\", \\\"{x:1350,y:778,t:1528139652482};\\\", \\\"{x:1330,y:779,t:1528139652498};\\\", \\\"{x:1307,y:783,t:1528139652515};\\\", \\\"{x:1284,y:787,t:1528139652532};\\\", \\\"{x:1250,y:792,t:1528139652548};\\\", \\\"{x:1234,y:794,t:1528139652566};\\\", \\\"{x:1223,y:798,t:1528139652582};\\\", \\\"{x:1217,y:801,t:1528139652599};\\\", \\\"{x:1212,y:804,t:1528139652614};\\\", \\\"{x:1208,y:807,t:1528139652631};\\\", \\\"{x:1201,y:813,t:1528139652648};\\\", \\\"{x:1196,y:818,t:1528139652664};\\\", \\\"{x:1193,y:822,t:1528139652682};\\\", \\\"{x:1191,y:826,t:1528139652697};\\\", \\\"{x:1190,y:828,t:1528139652714};\\\", \\\"{x:1189,y:829,t:1528139652732};\\\", \\\"{x:1189,y:831,t:1528139652747};\\\", \\\"{x:1189,y:832,t:1528139652765};\\\", \\\"{x:1189,y:835,t:1528139652781};\\\", \\\"{x:1189,y:836,t:1528139652821};\\\", \\\"{x:1190,y:836,t:1528139652845};\\\", \\\"{x:1192,y:836,t:1528139652853};\\\", \\\"{x:1193,y:836,t:1528139652865};\\\", \\\"{x:1197,y:836,t:1528139652881};\\\", \\\"{x:1202,y:835,t:1528139652898};\\\", \\\"{x:1207,y:832,t:1528139652914};\\\", \\\"{x:1213,y:830,t:1528139652938};\\\", \\\"{x:1215,y:829,t:1528139652947};\\\", \\\"{x:1217,y:828,t:1528139652963};\\\", \\\"{x:1218,y:827,t:1528139652986};\\\", \\\"{x:1221,y:829,t:1528139660128};\\\", \\\"{x:1228,y:836,t:1528139660137};\\\", \\\"{x:1232,y:842,t:1528139660153};\\\", \\\"{x:1239,y:852,t:1528139660174};\\\", \\\"{x:1241,y:855,t:1528139660191};\\\", \\\"{x:1242,y:856,t:1528139660211};\\\", \\\"{x:1242,y:857,t:1528139660235};\\\", \\\"{x:1242,y:858,t:1528139660284};\\\", \\\"{x:1243,y:859,t:1528139660324};\\\", \\\"{x:1244,y:860,t:1528139660356};\\\", \\\"{x:1244,y:861,t:1528139660364};\\\", \\\"{x:1244,y:863,t:1528139660374};\\\", \\\"{x:1245,y:865,t:1528139660391};\\\", \\\"{x:1247,y:867,t:1528139660408};\\\", \\\"{x:1249,y:873,t:1528139660425};\\\", \\\"{x:1251,y:878,t:1528139660442};\\\", \\\"{x:1253,y:884,t:1528139660459};\\\", \\\"{x:1255,y:891,t:1528139660475};\\\", \\\"{x:1260,y:913,t:1528139660492};\\\", \\\"{x:1263,y:929,t:1528139660508};\\\", \\\"{x:1268,y:945,t:1528139660525};\\\", \\\"{x:1273,y:958,t:1528139660541};\\\", \\\"{x:1277,y:968,t:1528139660559};\\\", \\\"{x:1280,y:973,t:1528139660575};\\\", \\\"{x:1281,y:976,t:1528139660592};\\\", \\\"{x:1283,y:977,t:1528139660609};\\\", \\\"{x:1283,y:979,t:1528139660625};\\\", \\\"{x:1283,y:980,t:1528139660644};\\\", \\\"{x:1284,y:981,t:1528139660668};\\\", \\\"{x:1284,y:982,t:1528139660757};\\\", \\\"{x:1284,y:981,t:1528139660965};\\\", \\\"{x:1285,y:977,t:1528139660976};\\\", \\\"{x:1288,y:965,t:1528139660993};\\\", \\\"{x:1289,y:955,t:1528139661009};\\\", \\\"{x:1291,y:945,t:1528139661026};\\\", \\\"{x:1291,y:925,t:1528139661042};\\\", \\\"{x:1291,y:911,t:1528139661059};\\\", \\\"{x:1292,y:904,t:1528139661076};\\\", \\\"{x:1293,y:900,t:1528139661092};\\\", \\\"{x:1293,y:896,t:1528139661109};\\\", \\\"{x:1294,y:892,t:1528139661126};\\\", \\\"{x:1294,y:887,t:1528139661142};\\\", \\\"{x:1294,y:878,t:1528139661159};\\\", \\\"{x:1294,y:868,t:1528139661176};\\\", \\\"{x:1294,y:863,t:1528139661192};\\\", \\\"{x:1294,y:862,t:1528139661209};\\\", \\\"{x:1294,y:860,t:1528139661226};\\\", \\\"{x:1294,y:859,t:1528139661269};\\\", \\\"{x:1294,y:857,t:1528139661277};\\\", \\\"{x:1292,y:849,t:1528139661293};\\\", \\\"{x:1286,y:838,t:1528139661309};\\\", \\\"{x:1281,y:829,t:1528139661326};\\\", \\\"{x:1280,y:827,t:1528139661342};\\\", \\\"{x:1278,y:825,t:1528139661359};\\\", \\\"{x:1278,y:823,t:1528139661380};\\\", \\\"{x:1277,y:822,t:1528139661395};\\\", \\\"{x:1277,y:821,t:1528139661443};\\\", \\\"{x:1277,y:820,t:1528139661460};\\\", \\\"{x:1277,y:821,t:1528139661925};\\\", \\\"{x:1277,y:822,t:1528139661932};\\\", \\\"{x:1277,y:824,t:1528139661942};\\\", \\\"{x:1277,y:825,t:1528139661960};\\\", \\\"{x:1277,y:827,t:1528139661981};\\\", \\\"{x:1277,y:828,t:1528139661993};\\\", \\\"{x:1278,y:829,t:1528139662019};\\\", \\\"{x:1251,y:830,t:1528139669468};\\\", \\\"{x:1245,y:830,t:1528139669484};\\\", \\\"{x:1243,y:830,t:1528139669499};\\\", \\\"{x:1241,y:830,t:1528139669515};\\\", \\\"{x:1239,y:830,t:1528139669829};\\\", \\\"{x:1238,y:830,t:1528139669852};\\\", \\\"{x:1237,y:830,t:1528139669876};\\\", \\\"{x:1236,y:830,t:1528139669892};\\\", \\\"{x:1235,y:831,t:1528139669917};\\\", \\\"{x:1234,y:831,t:1528139669940};\\\", \\\"{x:1233,y:831,t:1528139669950};\\\", \\\"{x:1232,y:831,t:1528139669972};\\\", \\\"{x:1231,y:831,t:1528139669996};\\\", \\\"{x:1230,y:832,t:1528139670044};\\\", \\\"{x:1229,y:832,t:1528139670085};\\\", \\\"{x:1228,y:832,t:1528139670108};\\\", \\\"{x:1227,y:832,t:1528139670140};\\\", \\\"{x:1226,y:833,t:1528139670156};\\\", \\\"{x:1225,y:833,t:1528139670173};\\\", \\\"{x:1223,y:834,t:1528139670228};\\\", \\\"{x:1222,y:834,t:1528139670267};\\\", \\\"{x:1221,y:834,t:1528139670283};\\\", \\\"{x:1221,y:835,t:1528139670299};\\\", \\\"{x:1220,y:835,t:1528139670339};\\\", \\\"{x:1218,y:835,t:1528139670356};\\\", \\\"{x:1217,y:835,t:1528139670407};\\\", \\\"{x:1216,y:835,t:1528139670433};\\\", \\\"{x:1213,y:836,t:1528139670932};\\\", \\\"{x:1210,y:836,t:1528139670952};\\\", \\\"{x:1208,y:835,t:1528139670967};\\\", \\\"{x:1207,y:834,t:1528139670983};\\\", \\\"{x:1207,y:832,t:1528139671003};\\\", \\\"{x:1206,y:831,t:1528139671027};\\\", \\\"{x:1206,y:830,t:1528139671036};\\\", \\\"{x:1205,y:830,t:1528139671060};\\\", \\\"{x:1205,y:829,t:1528139671068};\\\", \\\"{x:1204,y:828,t:1528139671091};\\\", \\\"{x:1204,y:827,t:1528139671123};\\\", \\\"{x:1204,y:826,t:1528139671140};\\\", \\\"{x:1203,y:826,t:1528139671150};\\\", \\\"{x:1203,y:825,t:1528139671167};\\\", \\\"{x:1203,y:823,t:1528139671184};\\\", \\\"{x:1203,y:822,t:1528139671253};\\\", \\\"{x:1204,y:821,t:1528139671332};\\\", \\\"{x:1205,y:821,t:1528139671652};\\\", \\\"{x:1206,y:821,t:1528139671667};\\\", \\\"{x:1209,y:823,t:1528139671684};\\\", \\\"{x:1211,y:824,t:1528139671702};\\\", \\\"{x:1212,y:825,t:1528139671721};\\\", \\\"{x:1214,y:826,t:1528139671734};\\\", \\\"{x:1215,y:827,t:1528139671751};\\\", \\\"{x:1217,y:827,t:1528139671768};\\\", \\\"{x:1218,y:828,t:1528139671784};\\\", \\\"{x:1218,y:829,t:1528139671812};\\\", \\\"{x:1219,y:829,t:1528139671852};\\\", \\\"{x:1220,y:829,t:1528139671916};\\\", \\\"{x:1225,y:829,t:1528139679663};\\\", \\\"{x:1232,y:830,t:1528139679675};\\\", \\\"{x:1245,y:832,t:1528139679691};\\\", \\\"{x:1251,y:832,t:1528139679707};\\\", \\\"{x:1254,y:832,t:1528139679724};\\\", \\\"{x:1255,y:832,t:1528139679812};\\\", \\\"{x:1256,y:832,t:1528139679824};\\\", \\\"{x:1257,y:832,t:1528139679840};\\\", \\\"{x:1259,y:832,t:1528139679857};\\\", \\\"{x:1260,y:832,t:1528139679874};\\\", \\\"{x:1261,y:832,t:1528139679891};\\\", \\\"{x:1263,y:832,t:1528139679908};\\\", \\\"{x:1266,y:832,t:1528139679924};\\\", \\\"{x:1270,y:832,t:1528139679941};\\\", \\\"{x:1272,y:831,t:1528139679958};\\\", \\\"{x:1273,y:831,t:1528139679974};\\\", \\\"{x:1274,y:831,t:1528139679991};\\\", \\\"{x:1275,y:831,t:1528139680007};\\\", \\\"{x:1276,y:831,t:1528139680176};\\\", \\\"{x:1276,y:830,t:1528139680660};\\\", \\\"{x:1270,y:830,t:1528139680677};\\\", \\\"{x:1254,y:830,t:1528139680691};\\\", \\\"{x:1243,y:830,t:1528139680708};\\\", \\\"{x:1230,y:830,t:1528139680724};\\\", \\\"{x:1220,y:830,t:1528139680742};\\\", \\\"{x:1218,y:830,t:1528139680758};\\\", \\\"{x:1217,y:830,t:1528139681548};\\\", \\\"{x:1219,y:830,t:1528139681972};\\\", \\\"{x:1221,y:830,t:1528139681982};\\\", \\\"{x:1224,y:830,t:1528139681993};\\\", \\\"{x:1228,y:830,t:1528139682009};\\\", \\\"{x:1235,y:830,t:1528139682027};\\\", \\\"{x:1238,y:830,t:1528139682043};\\\", \\\"{x:1240,y:829,t:1528139682059};\\\", \\\"{x:1242,y:829,t:1528139682076};\\\", \\\"{x:1243,y:829,t:1528139682092};\\\", \\\"{x:1244,y:829,t:1528139682109};\\\", \\\"{x:1245,y:829,t:1528139682126};\\\", \\\"{x:1248,y:829,t:1528139682143};\\\", \\\"{x:1250,y:829,t:1528139682160};\\\", \\\"{x:1252,y:829,t:1528139682177};\\\", \\\"{x:1253,y:829,t:1528139682193};\\\", \\\"{x:1254,y:829,t:1528139682210};\\\", \\\"{x:1255,y:829,t:1528139682227};\\\", \\\"{x:1257,y:829,t:1528139682243};\\\", \\\"{x:1259,y:829,t:1528139682260};\\\", \\\"{x:1263,y:829,t:1528139682277};\\\", \\\"{x:1267,y:829,t:1528139682293};\\\", \\\"{x:1272,y:829,t:1528139682310};\\\", \\\"{x:1276,y:829,t:1528139682331};\\\", \\\"{x:1278,y:829,t:1528139682343};\\\", \\\"{x:1279,y:829,t:1528139682359};\\\", \\\"{x:1280,y:829,t:1528139682411};\\\", \\\"{x:1281,y:829,t:1528139682957};\\\", \\\"{x:1282,y:829,t:1528139682964};\\\", \\\"{x:1284,y:828,t:1528139682977};\\\", \\\"{x:1289,y:828,t:1528139682995};\\\", \\\"{x:1292,y:828,t:1528139683010};\\\", \\\"{x:1297,y:828,t:1528139683026};\\\", \\\"{x:1301,y:828,t:1528139683043};\\\", \\\"{x:1303,y:828,t:1528139683060};\\\", \\\"{x:1305,y:828,t:1528139683077};\\\", \\\"{x:1308,y:828,t:1528139683093};\\\", \\\"{x:1310,y:828,t:1528139683111};\\\", \\\"{x:1312,y:828,t:1528139683127};\\\", \\\"{x:1313,y:828,t:1528139683144};\\\", \\\"{x:1315,y:828,t:1528139683161};\\\", \\\"{x:1316,y:828,t:1528139683177};\\\", \\\"{x:1317,y:828,t:1528139683194};\\\", \\\"{x:1318,y:828,t:1528139683211};\\\", \\\"{x:1319,y:828,t:1528139683261};\\\", \\\"{x:1320,y:828,t:1528139683291};\\\", \\\"{x:1321,y:828,t:1528139683581};\\\", \\\"{x:1322,y:827,t:1528139683594};\\\", \\\"{x:1324,y:827,t:1528139683611};\\\", \\\"{x:1327,y:827,t:1528139683628};\\\", \\\"{x:1329,y:827,t:1528139683644};\\\", \\\"{x:1333,y:827,t:1528139683661};\\\", \\\"{x:1334,y:827,t:1528139683684};\\\", \\\"{x:1336,y:827,t:1528139683724};\\\", \\\"{x:1337,y:827,t:1528139683732};\\\", \\\"{x:1338,y:830,t:1528139683745};\\\", \\\"{x:1341,y:840,t:1528139683762};\\\", \\\"{x:1342,y:854,t:1528139683777};\\\", \\\"{x:1342,y:869,t:1528139683794};\\\", \\\"{x:1342,y:886,t:1528139683811};\\\", \\\"{x:1342,y:908,t:1528139683828};\\\", \\\"{x:1342,y:914,t:1528139683844};\\\", \\\"{x:1342,y:917,t:1528139683860};\\\", \\\"{x:1342,y:919,t:1528139683878};\\\", \\\"{x:1342,y:920,t:1528139683894};\\\", \\\"{x:1342,y:922,t:1528139683911};\\\", \\\"{x:1342,y:923,t:1528139683928};\\\", \\\"{x:1342,y:924,t:1528139683956};\\\", \\\"{x:1344,y:924,t:1528139684061};\\\", \\\"{x:1349,y:915,t:1528139684078};\\\", \\\"{x:1352,y:908,t:1528139684095};\\\", \\\"{x:1354,y:903,t:1528139684111};\\\", \\\"{x:1355,y:898,t:1528139684128};\\\", \\\"{x:1357,y:894,t:1528139684145};\\\", \\\"{x:1358,y:894,t:1528139684161};\\\", \\\"{x:1358,y:893,t:1528139684178};\\\", \\\"{x:1357,y:892,t:1528139684435};\\\", \\\"{x:1356,y:892,t:1528139684445};\\\", \\\"{x:1354,y:892,t:1528139684461};\\\", \\\"{x:1353,y:892,t:1528139684482};\\\", \\\"{x:1352,y:892,t:1528139684515};\\\", \\\"{x:1351,y:892,t:1528139684532};\\\", \\\"{x:1348,y:892,t:1528139684561};\\\", \\\"{x:1346,y:892,t:1528139684577};\\\", \\\"{x:1345,y:892,t:1528139684611};\\\", \\\"{x:1343,y:892,t:1528139684708};\\\", \\\"{x:1342,y:892,t:1528139685427};\\\", \\\"{x:1338,y:889,t:1528139685435};\\\", \\\"{x:1336,y:889,t:1528139685458};\\\", \\\"{x:1335,y:889,t:1528139685483};\\\", \\\"{x:1330,y:887,t:1528139685496};\\\", \\\"{x:1327,y:885,t:1528139685512};\\\", \\\"{x:1324,y:883,t:1528139685529};\\\", \\\"{x:1321,y:881,t:1528139685546};\\\", \\\"{x:1318,y:879,t:1528139685561};\\\", \\\"{x:1315,y:875,t:1528139685578};\\\", \\\"{x:1307,y:868,t:1528139685595};\\\", \\\"{x:1302,y:863,t:1528139685611};\\\", \\\"{x:1296,y:859,t:1528139685629};\\\", \\\"{x:1288,y:853,t:1528139685645};\\\", \\\"{x:1275,y:844,t:1528139685662};\\\", \\\"{x:1270,y:842,t:1528139685678};\\\", \\\"{x:1265,y:839,t:1528139685695};\\\", \\\"{x:1264,y:838,t:1528139685712};\\\", \\\"{x:1263,y:838,t:1528139685738};\\\", \\\"{x:1262,y:837,t:1528139685747};\\\", \\\"{x:1262,y:836,t:1528139686003};\\\", \\\"{x:1263,y:835,t:1528139686026};\\\", \\\"{x:1266,y:834,t:1528139686035};\\\", \\\"{x:1267,y:834,t:1528139686045};\\\", \\\"{x:1268,y:833,t:1528139686063};\\\", \\\"{x:1269,y:833,t:1528139686079};\\\", \\\"{x:1271,y:832,t:1528139686115};\\\", \\\"{x:1273,y:831,t:1528139686131};\\\", \\\"{x:1274,y:830,t:1528139686146};\\\", \\\"{x:1275,y:830,t:1528139686162};\\\", \\\"{x:1277,y:829,t:1528139686181};\\\", \\\"{x:1279,y:823,t:1528139686680};\\\", \\\"{x:1284,y:809,t:1528139686697};\\\", \\\"{x:1287,y:803,t:1528139686712};\\\", \\\"{x:1290,y:796,t:1528139686730};\\\", \\\"{x:1292,y:791,t:1528139686747};\\\", \\\"{x:1292,y:790,t:1528139686762};\\\", \\\"{x:1292,y:788,t:1528139686780};\\\", \\\"{x:1293,y:786,t:1528139686797};\\\", \\\"{x:1293,y:785,t:1528139686827};\\\", \\\"{x:1294,y:784,t:1528139686836};\\\", \\\"{x:1294,y:782,t:1528139686860};\\\", \\\"{x:1295,y:781,t:1528139686868};\\\", \\\"{x:1295,y:780,t:1528139686880};\\\", \\\"{x:1296,y:777,t:1528139686896};\\\", \\\"{x:1296,y:775,t:1528139686913};\\\", \\\"{x:1298,y:769,t:1528139686930};\\\", \\\"{x:1300,y:762,t:1528139686947};\\\", \\\"{x:1300,y:744,t:1528139686964};\\\", \\\"{x:1300,y:730,t:1528139686979};\\\", \\\"{x:1301,y:721,t:1528139686997};\\\", \\\"{x:1301,y:716,t:1528139687013};\\\", \\\"{x:1301,y:713,t:1528139687030};\\\", \\\"{x:1301,y:712,t:1528139687046};\\\", \\\"{x:1301,y:709,t:1528139687064};\\\", \\\"{x:1301,y:706,t:1528139687080};\\\", \\\"{x:1301,y:701,t:1528139687097};\\\", \\\"{x:1301,y:695,t:1528139687114};\\\", \\\"{x:1301,y:687,t:1528139687130};\\\", \\\"{x:1302,y:678,t:1528139687147};\\\", \\\"{x:1303,y:665,t:1528139687164};\\\", \\\"{x:1303,y:657,t:1528139687180};\\\", \\\"{x:1303,y:651,t:1528139687197};\\\", \\\"{x:1303,y:648,t:1528139687214};\\\", \\\"{x:1303,y:645,t:1528139687230};\\\", \\\"{x:1303,y:643,t:1528139687247};\\\", \\\"{x:1303,y:642,t:1528139687265};\\\", \\\"{x:1303,y:640,t:1528139687280};\\\", \\\"{x:1304,y:637,t:1528139687297};\\\", \\\"{x:1304,y:634,t:1528139687314};\\\", \\\"{x:1305,y:632,t:1528139687331};\\\", \\\"{x:1305,y:630,t:1528139687347};\\\", \\\"{x:1306,y:627,t:1528139687364};\\\", \\\"{x:1306,y:626,t:1528139687380};\\\", \\\"{x:1306,y:625,t:1528139687397};\\\", \\\"{x:1306,y:624,t:1528139687467};\\\", \\\"{x:1306,y:623,t:1528139687491};\\\", \\\"{x:1307,y:622,t:1528139687507};\\\", \\\"{x:1309,y:620,t:1528139687515};\\\", \\\"{x:1310,y:620,t:1528139687539};\\\", \\\"{x:1311,y:620,t:1528139688060};\\\", \\\"{x:1311,y:621,t:1528139688076};\\\", \\\"{x:1312,y:621,t:1528139688083};\\\", \\\"{x:1312,y:622,t:1528139688099};\\\", \\\"{x:1313,y:622,t:1528139688114};\\\", \\\"{x:1313,y:623,t:1528139688196};\\\", \\\"{x:1313,y:624,t:1528139688220};\\\", \\\"{x:1313,y:625,t:1528139688330};\\\", \\\"{x:1314,y:625,t:1528139688348};\\\", \\\"{x:1314,y:626,t:1528139688387};\\\", \\\"{x:1315,y:627,t:1528139688403};\\\", \\\"{x:1315,y:628,t:1528139688427};\\\", \\\"{x:1316,y:629,t:1528139688459};\\\", \\\"{x:1316,y:628,t:1528139689187};\\\", \\\"{x:1316,y:622,t:1528139689200};\\\", \\\"{x:1316,y:615,t:1528139689214};\\\", \\\"{x:1316,y:608,t:1528139689232};\\\", \\\"{x:1316,y:602,t:1528139689249};\\\", \\\"{x:1316,y:598,t:1528139689264};\\\", \\\"{x:1316,y:594,t:1528139689282};\\\", \\\"{x:1316,y:590,t:1528139689298};\\\", \\\"{x:1316,y:586,t:1528139689314};\\\", \\\"{x:1316,y:579,t:1528139689331};\\\", \\\"{x:1317,y:575,t:1528139689348};\\\", \\\"{x:1319,y:571,t:1528139689365};\\\", \\\"{x:1319,y:567,t:1528139689381};\\\", \\\"{x:1321,y:564,t:1528139689399};\\\", \\\"{x:1321,y:560,t:1528139689414};\\\", \\\"{x:1321,y:553,t:1528139689432};\\\", \\\"{x:1323,y:548,t:1528139689449};\\\", \\\"{x:1323,y:543,t:1528139689464};\\\", \\\"{x:1323,y:542,t:1528139689482};\\\", \\\"{x:1323,y:541,t:1528139689580};\\\", \\\"{x:1323,y:538,t:1528139691868};\\\", \\\"{x:1324,y:532,t:1528139691884};\\\", \\\"{x:1325,y:526,t:1528139691900};\\\", \\\"{x:1327,y:522,t:1528139691917};\\\", \\\"{x:1327,y:518,t:1528139691934};\\\", \\\"{x:1327,y:516,t:1528139691951};\\\", \\\"{x:1327,y:514,t:1528139691968};\\\", \\\"{x:1327,y:513,t:1528139691984};\\\", \\\"{x:1329,y:511,t:1528139692000};\\\", \\\"{x:1329,y:510,t:1528139692017};\\\", \\\"{x:1329,y:508,t:1528139692035};\\\", \\\"{x:1330,y:507,t:1528139692051};\\\", \\\"{x:1330,y:506,t:1528139692068};\\\", \\\"{x:1330,y:505,t:1528139692082};\\\", \\\"{x:1330,y:504,t:1528139692099};\\\", \\\"{x:1330,y:503,t:1528139692122};\\\", \\\"{x:1330,y:502,t:1528139692138};\\\", \\\"{x:1330,y:501,t:1528139692162};\\\", \\\"{x:1330,y:500,t:1528139692178};\\\", \\\"{x:1329,y:500,t:1528139692202};\\\", \\\"{x:1327,y:499,t:1528139692258};\\\", \\\"{x:1327,y:498,t:1528139692282};\\\", \\\"{x:1326,y:498,t:1528139692314};\\\", \\\"{x:1325,y:498,t:1528139692322};\\\", \\\"{x:1324,y:498,t:1528139692353};\\\", \\\"{x:1323,y:498,t:1528139692369};\\\", \\\"{x:1322,y:498,t:1528139692393};\\\", \\\"{x:1321,y:498,t:1528139692433};\\\", \\\"{x:1320,y:498,t:1528139692450};\\\", \\\"{x:1319,y:497,t:1528139692465};\\\", \\\"{x:1318,y:497,t:1528139692505};\\\", \\\"{x:1317,y:497,t:1528139692544};\\\", \\\"{x:1316,y:496,t:1528139692560};\\\", \\\"{x:1315,y:496,t:1528139692568};\\\", \\\"{x:1314,y:496,t:1528139692592};\\\", \\\"{x:1313,y:495,t:1528139692601};\\\", \\\"{x:1312,y:495,t:1528139692617};\\\", \\\"{x:1311,y:495,t:1528139692682};\\\", \\\"{x:1310,y:495,t:1528139693322};\\\", \\\"{x:1315,y:501,t:1528139693785};\\\", \\\"{x:1349,y:529,t:1528139693816};\\\", \\\"{x:1362,y:537,t:1528139693832};\\\", \\\"{x:1372,y:542,t:1528139693850};\\\", \\\"{x:1377,y:542,t:1528139693866};\\\", \\\"{x:1382,y:545,t:1528139693883};\\\", \\\"{x:1386,y:545,t:1528139693899};\\\", \\\"{x:1387,y:545,t:1528139693917};\\\", \\\"{x:1388,y:545,t:1528139693933};\\\", \\\"{x:1390,y:545,t:1528139693950};\\\", \\\"{x:1392,y:545,t:1528139693966};\\\", \\\"{x:1396,y:545,t:1528139693984};\\\", \\\"{x:1398,y:545,t:1528139693999};\\\", \\\"{x:1399,y:545,t:1528139694105};\\\", \\\"{x:1399,y:546,t:1528139694145};\\\", \\\"{x:1399,y:548,t:1528139694153};\\\", \\\"{x:1399,y:549,t:1528139694166};\\\", \\\"{x:1399,y:553,t:1528139694184};\\\", \\\"{x:1399,y:556,t:1528139694200};\\\", \\\"{x:1399,y:557,t:1528139694298};\\\", \\\"{x:1399,y:558,t:1528139694305};\\\", \\\"{x:1400,y:559,t:1528139694317};\\\", \\\"{x:1401,y:560,t:1528139694334};\\\", \\\"{x:1403,y:561,t:1528139694350};\\\", \\\"{x:1405,y:562,t:1528139694367};\\\", \\\"{x:1407,y:563,t:1528139694384};\\\", \\\"{x:1409,y:564,t:1528139694403};\\\", \\\"{x:1411,y:566,t:1528139694417};\\\", \\\"{x:1412,y:566,t:1528139694434};\\\", \\\"{x:1415,y:566,t:1528139694450};\\\", \\\"{x:1417,y:567,t:1528139694466};\\\", \\\"{x:1420,y:568,t:1528139694512};\\\", \\\"{x:1419,y:566,t:1528139694934};\\\", \\\"{x:1418,y:563,t:1528139694951};\\\", \\\"{x:1416,y:562,t:1528139694968};\\\", \\\"{x:1416,y:561,t:1528139694985};\\\", \\\"{x:1415,y:560,t:1528139695001};\\\", \\\"{x:1414,y:557,t:1528139696596};\\\", \\\"{x:1412,y:531,t:1528139696620};\\\", \\\"{x:1412,y:524,t:1528139696636};\\\", \\\"{x:1412,y:514,t:1528139696651};\\\", \\\"{x:1412,y:505,t:1528139696669};\\\", \\\"{x:1412,y:501,t:1528139696686};\\\", \\\"{x:1412,y:497,t:1528139696702};\\\", \\\"{x:1413,y:491,t:1528139696719};\\\", \\\"{x:1413,y:487,t:1528139696736};\\\", \\\"{x:1414,y:483,t:1528139696752};\\\", \\\"{x:1414,y:477,t:1528139696769};\\\", \\\"{x:1414,y:474,t:1528139696786};\\\", \\\"{x:1414,y:473,t:1528139696801};\\\", \\\"{x:1414,y:471,t:1528139696819};\\\", \\\"{x:1414,y:466,t:1528139696836};\\\", \\\"{x:1414,y:463,t:1528139696852};\\\", \\\"{x:1414,y:459,t:1528139696868};\\\", \\\"{x:1414,y:457,t:1528139696886};\\\", \\\"{x:1414,y:456,t:1528139696901};\\\", \\\"{x:1414,y:455,t:1528139696919};\\\", \\\"{x:1414,y:454,t:1528139696936};\\\", \\\"{x:1414,y:452,t:1528139696952};\\\", \\\"{x:1413,y:446,t:1528139696970};\\\", \\\"{x:1413,y:443,t:1528139696986};\\\", \\\"{x:1413,y:442,t:1528139697003};\\\", \\\"{x:1413,y:440,t:1528139697019};\\\", \\\"{x:1413,y:439,t:1528139697037};\\\", \\\"{x:1413,y:437,t:1528139697052};\\\", \\\"{x:1413,y:434,t:1528139697073};\\\", \\\"{x:1413,y:433,t:1528139697086};\\\", \\\"{x:1413,y:432,t:1528139697102};\\\", \\\"{x:1413,y:431,t:1528139697136};\\\", \\\"{x:1413,y:430,t:1528139697369};\\\", \\\"{x:1413,y:414,t:1528139697853};\\\", \\\"{x:1413,y:390,t:1528139697870};\\\", \\\"{x:1415,y:366,t:1528139697887};\\\", \\\"{x:1416,y:346,t:1528139697902};\\\", \\\"{x:1417,y:329,t:1528139697919};\\\", \\\"{x:1422,y:314,t:1528139697937};\\\", \\\"{x:1426,y:307,t:1528139697953};\\\", \\\"{x:1429,y:301,t:1528139697970};\\\", \\\"{x:1435,y:291,t:1528139697987};\\\", \\\"{x:1441,y:280,t:1528139698003};\\\", \\\"{x:1443,y:272,t:1528139698020};\\\", \\\"{x:1444,y:265,t:1528139698037};\\\", \\\"{x:1444,y:257,t:1528139698053};\\\", \\\"{x:1444,y:248,t:1528139698070};\\\", \\\"{x:1444,y:241,t:1528139698087};\\\", \\\"{x:1444,y:232,t:1528139698103};\\\", \\\"{x:1445,y:224,t:1528139698120};\\\", \\\"{x:1448,y:215,t:1528139698137};\\\", \\\"{x:1448,y:208,t:1528139698153};\\\", \\\"{x:1451,y:200,t:1528139698170};\\\", \\\"{x:1453,y:193,t:1528139698187};\\\", \\\"{x:1457,y:186,t:1528139698203};\\\", \\\"{x:1461,y:181,t:1528139698220};\\\", \\\"{x:1467,y:172,t:1528139698237};\\\", \\\"{x:1480,y:163,t:1528139698255};\\\", \\\"{x:1488,y:156,t:1528139698270};\\\", \\\"{x:1495,y:150,t:1528139698287};\\\", \\\"{x:1497,y:147,t:1528139698304};\\\", \\\"{x:1498,y:145,t:1528139698319};\\\", \\\"{x:1499,y:143,t:1528139698337};\\\", \\\"{x:1500,y:142,t:1528139698353};\\\", \\\"{x:1495,y:143,t:1528139698481};\\\", \\\"{x:1493,y:144,t:1528139698490};\\\", \\\"{x:1491,y:146,t:1528139698505};\\\", \\\"{x:1485,y:148,t:1528139698520};\\\", \\\"{x:1478,y:151,t:1528139698538};\\\", \\\"{x:1478,y:152,t:1528139698554};\\\", \\\"{x:1477,y:152,t:1528139698738};\\\", \\\"{x:1478,y:154,t:1528139698794};\\\", \\\"{x:1479,y:156,t:1528139698805};\\\", \\\"{x:1482,y:159,t:1528139698825};\\\", \\\"{x:1485,y:163,t:1528139698837};\\\", \\\"{x:1485,y:164,t:1528139698865};\\\", \\\"{x:1486,y:165,t:1528139698897};\\\", \\\"{x:1486,y:166,t:1528139699378};\\\", \\\"{x:1489,y:169,t:1528139699429};\\\", \\\"{x:1494,y:174,t:1528139699438};\\\", \\\"{x:1499,y:182,t:1528139699454};\\\", \\\"{x:1508,y:195,t:1528139699471};\\\", \\\"{x:1517,y:202,t:1528139699489};\\\", \\\"{x:1518,y:204,t:1528139699504};\\\", \\\"{x:1522,y:207,t:1528139699521};\\\", \\\"{x:1524,y:209,t:1528139699537};\\\", \\\"{x:1525,y:212,t:1528139699555};\\\", \\\"{x:1529,y:220,t:1528139699571};\\\", \\\"{x:1537,y:229,t:1528139699588};\\\", \\\"{x:1545,y:240,t:1528139699605};\\\", \\\"{x:1551,y:247,t:1528139699621};\\\", \\\"{x:1553,y:250,t:1528139699638};\\\", \\\"{x:1555,y:252,t:1528139699655};\\\", \\\"{x:1556,y:256,t:1528139699671};\\\", \\\"{x:1566,y:276,t:1528139699689};\\\", \\\"{x:1577,y:300,t:1528139699705};\\\", \\\"{x:1590,y:328,t:1528139699721};\\\", \\\"{x:1600,y:350,t:1528139699738};\\\", \\\"{x:1608,y:363,t:1528139699758};\\\", \\\"{x:1611,y:369,t:1528139699771};\\\", \\\"{x:1613,y:373,t:1528139699788};\\\", \\\"{x:1614,y:376,t:1528139699805};\\\", \\\"{x:1617,y:385,t:1528139699821};\\\", \\\"{x:1623,y:401,t:1528139699839};\\\", \\\"{x:1629,y:418,t:1528139699855};\\\", \\\"{x:1634,y:429,t:1528139699871};\\\", \\\"{x:1637,y:435,t:1528139699890};\\\", \\\"{x:1637,y:436,t:1528139699922};\\\", \\\"{x:1637,y:438,t:1528139699945};\\\", \\\"{x:1637,y:439,t:1528139699956};\\\", \\\"{x:1637,y:442,t:1528139699972};\\\", \\\"{x:1637,y:445,t:1528139699989};\\\", \\\"{x:1637,y:446,t:1528139700006};\\\", \\\"{x:1637,y:448,t:1528139700022};\\\", \\\"{x:1636,y:449,t:1528139700039};\\\", \\\"{x:1630,y:449,t:1528139700056};\\\", \\\"{x:1627,y:449,t:1528139700072};\\\", \\\"{x:1624,y:449,t:1528139700090};\\\", \\\"{x:1623,y:449,t:1528139700130};\\\", \\\"{x:1621,y:448,t:1528139700170};\\\", \\\"{x:1621,y:446,t:1528139700185};\\\", \\\"{x:1620,y:443,t:1528139700194};\\\", \\\"{x:1620,y:442,t:1528139700205};\\\", \\\"{x:1619,y:438,t:1528139700222};\\\", \\\"{x:1618,y:436,t:1528139700239};\\\", \\\"{x:1618,y:434,t:1528139700258};\\\", \\\"{x:1618,y:430,t:1528139700288};\\\", \\\"{x:1618,y:425,t:1528139700304};\\\", \\\"{x:1616,y:423,t:1528139700323};\\\", \\\"{x:1615,y:423,t:1528139700970};\\\", \\\"{x:1615,y:424,t:1528139700978};\\\", \\\"{x:1615,y:425,t:1528139700998};\\\", \\\"{x:1615,y:427,t:1528139701022};\\\", \\\"{x:1614,y:427,t:1528139701097};\\\", \\\"{x:1614,y:428,t:1528139701145};\\\", \\\"{x:1613,y:429,t:1528139701872};\\\", \\\"{x:1613,y:430,t:1528139702970};\\\", \\\"{x:1609,y:430,t:1528139702977};\\\", \\\"{x:1607,y:430,t:1528139702993};\\\", \\\"{x:1603,y:434,t:1528139703008};\\\", \\\"{x:1598,y:439,t:1528139703024};\\\", \\\"{x:1594,y:443,t:1528139703040};\\\", \\\"{x:1594,y:444,t:1528139703057};\\\", \\\"{x:1592,y:446,t:1528139703306};\\\", \\\"{x:1589,y:452,t:1528139703314};\\\", \\\"{x:1583,y:460,t:1528139703325};\\\", \\\"{x:1578,y:478,t:1528139703341};\\\", \\\"{x:1571,y:500,t:1528139703357};\\\", \\\"{x:1561,y:523,t:1528139703375};\\\", \\\"{x:1551,y:544,t:1528139703391};\\\", \\\"{x:1534,y:582,t:1528139703408};\\\", \\\"{x:1513,y:629,t:1528139703428};\\\", \\\"{x:1506,y:661,t:1528139703442};\\\", \\\"{x:1500,y:681,t:1528139703458};\\\", \\\"{x:1497,y:697,t:1528139703473};\\\", \\\"{x:1497,y:709,t:1528139703491};\\\", \\\"{x:1495,y:716,t:1528139703507};\\\", \\\"{x:1493,y:723,t:1528139703524};\\\", \\\"{x:1487,y:735,t:1528139703541};\\\", \\\"{x:1476,y:747,t:1528139703558};\\\", \\\"{x:1466,y:756,t:1528139703574};\\\", \\\"{x:1455,y:765,t:1528139703591};\\\", \\\"{x:1448,y:774,t:1528139703608};\\\", \\\"{x:1440,y:789,t:1528139703624};\\\", \\\"{x:1419,y:813,t:1528139703641};\\\", \\\"{x:1405,y:823,t:1528139703659};\\\", \\\"{x:1397,y:827,t:1528139703674};\\\", \\\"{x:1395,y:828,t:1528139703691};\\\", \\\"{x:1393,y:828,t:1528139703708};\\\", \\\"{x:1392,y:828,t:1528139703730};\\\", \\\"{x:1391,y:828,t:1528139703742};\\\", \\\"{x:1389,y:828,t:1528139703759};\\\", \\\"{x:1387,y:828,t:1528139703775};\\\", \\\"{x:1386,y:828,t:1528139703882};\\\", \\\"{x:1382,y:829,t:1528139703897};\\\", \\\"{x:1380,y:831,t:1528139703909};\\\", \\\"{x:1375,y:831,t:1528139703924};\\\", \\\"{x:1366,y:832,t:1528139703942};\\\", \\\"{x:1359,y:833,t:1528139703958};\\\", \\\"{x:1355,y:833,t:1528139703974};\\\", \\\"{x:1346,y:836,t:1528139703991};\\\", \\\"{x:1338,y:836,t:1528139704008};\\\", \\\"{x:1322,y:836,t:1528139704025};\\\", \\\"{x:1315,y:834,t:1528139704041};\\\", \\\"{x:1310,y:833,t:1528139704059};\\\", \\\"{x:1303,y:832,t:1528139704076};\\\", \\\"{x:1295,y:831,t:1528139704092};\\\", \\\"{x:1283,y:829,t:1528139704110};\\\", \\\"{x:1261,y:829,t:1528139704141};\\\", \\\"{x:1251,y:829,t:1528139704158};\\\", \\\"{x:1232,y:829,t:1528139704175};\\\", \\\"{x:1214,y:833,t:1528139704193};\\\", \\\"{x:1195,y:839,t:1528139704209};\\\", \\\"{x:1158,y:849,t:1528139704225};\\\", \\\"{x:1140,y:851,t:1528139704242};\\\", \\\"{x:1127,y:856,t:1528139704258};\\\", \\\"{x:1115,y:860,t:1528139704275};\\\", \\\"{x:1102,y:863,t:1528139704292};\\\", \\\"{x:1093,y:866,t:1528139704309};\\\", \\\"{x:1091,y:866,t:1528139704326};\\\", \\\"{x:1090,y:866,t:1528139704343};\\\", \\\"{x:1093,y:866,t:1528139704529};\\\", \\\"{x:1101,y:865,t:1528139704543};\\\", \\\"{x:1110,y:863,t:1528139704559};\\\", \\\"{x:1115,y:863,t:1528139704576};\\\", \\\"{x:1119,y:863,t:1528139704592};\\\", \\\"{x:1120,y:863,t:1528139704617};\\\", \\\"{x:1122,y:863,t:1528139704626};\\\", \\\"{x:1124,y:863,t:1528139704643};\\\", \\\"{x:1127,y:863,t:1528139704660};\\\", \\\"{x:1130,y:863,t:1528139704676};\\\", \\\"{x:1133,y:863,t:1528139704693};\\\", \\\"{x:1139,y:863,t:1528139704710};\\\", \\\"{x:1147,y:863,t:1528139704727};\\\", \\\"{x:1153,y:863,t:1528139704744};\\\", \\\"{x:1157,y:863,t:1528139704760};\\\", \\\"{x:1168,y:863,t:1528139704777};\\\", \\\"{x:1175,y:864,t:1528139704794};\\\", \\\"{x:1180,y:865,t:1528139704810};\\\", \\\"{x:1184,y:865,t:1528139704827};\\\", \\\"{x:1186,y:866,t:1528139704845};\\\", \\\"{x:1187,y:866,t:1528139704861};\\\", \\\"{x:1188,y:866,t:1528139704881};\\\", \\\"{x:1189,y:866,t:1528139704913};\\\", \\\"{x:1190,y:867,t:1528139704962};\\\", \\\"{x:1192,y:868,t:1528139704978};\\\", \\\"{x:1193,y:868,t:1528139704995};\\\", \\\"{x:1194,y:868,t:1528139705011};\\\", \\\"{x:1196,y:871,t:1528139705029};\\\", \\\"{x:1197,y:873,t:1528139705045};\\\", \\\"{x:1198,y:877,t:1528139705062};\\\", \\\"{x:1200,y:881,t:1528139705078};\\\", \\\"{x:1201,y:885,t:1528139705095};\\\", \\\"{x:1204,y:896,t:1528139705112};\\\", \\\"{x:1209,y:908,t:1528139705129};\\\", \\\"{x:1214,y:922,t:1528139705145};\\\", \\\"{x:1220,y:935,t:1528139705161};\\\", \\\"{x:1226,y:951,t:1528139705179};\\\", \\\"{x:1231,y:963,t:1528139705196};\\\", \\\"{x:1236,y:972,t:1528139705213};\\\", \\\"{x:1244,y:983,t:1528139705229};\\\", \\\"{x:1248,y:989,t:1528139705246};\\\", \\\"{x:1252,y:993,t:1528139705262};\\\", \\\"{x:1253,y:994,t:1528139705280};\\\", \\\"{x:1255,y:994,t:1528139705442};\\\", \\\"{x:1256,y:994,t:1528139705450};\\\", \\\"{x:1260,y:994,t:1528139705463};\\\", \\\"{x:1265,y:988,t:1528139705480};\\\", \\\"{x:1269,y:983,t:1528139705497};\\\", \\\"{x:1275,y:978,t:1528139705513};\\\", \\\"{x:1277,y:976,t:1528139705529};\\\", \\\"{x:1278,y:976,t:1528139705547};\\\", \\\"{x:1278,y:975,t:1528139705564};\\\", \\\"{x:1279,y:974,t:1528139705581};\\\", \\\"{x:1279,y:973,t:1528139705706};\\\", \\\"{x:1280,y:972,t:1528139706522};\\\", \\\"{x:1282,y:969,t:1528139706534};\\\", \\\"{x:1284,y:965,t:1528139706551};\\\", \\\"{x:1286,y:963,t:1528139706567};\\\", \\\"{x:1288,y:959,t:1528139706584};\\\", \\\"{x:1291,y:955,t:1528139706601};\\\", \\\"{x:1294,y:951,t:1528139706617};\\\", \\\"{x:1295,y:950,t:1528139706633};\\\", \\\"{x:1297,y:947,t:1528139706650};\\\", \\\"{x:1301,y:942,t:1528139706667};\\\", \\\"{x:1315,y:926,t:1528139706683};\\\", \\\"{x:1335,y:902,t:1528139706700};\\\", \\\"{x:1363,y:871,t:1528139706717};\\\", \\\"{x:1387,y:847,t:1528139706735};\\\", \\\"{x:1412,y:821,t:1528139706750};\\\", \\\"{x:1432,y:799,t:1528139706767};\\\", \\\"{x:1449,y:773,t:1528139706784};\\\", \\\"{x:1466,y:746,t:1528139706801};\\\", \\\"{x:1489,y:705,t:1528139706818};\\\", \\\"{x:1500,y:683,t:1528139706835};\\\", \\\"{x:1509,y:666,t:1528139706852};\\\", \\\"{x:1515,y:650,t:1528139706868};\\\", \\\"{x:1520,y:639,t:1528139706885};\\\", \\\"{x:1524,y:631,t:1528139706902};\\\", \\\"{x:1528,y:621,t:1528139706918};\\\", \\\"{x:1535,y:606,t:1528139706934};\\\", \\\"{x:1542,y:589,t:1528139706952};\\\", \\\"{x:1551,y:571,t:1528139706969};\\\", \\\"{x:1567,y:544,t:1528139706984};\\\", \\\"{x:1587,y:505,t:1528139707001};\\\", \\\"{x:1597,y:482,t:1528139707019};\\\", \\\"{x:1608,y:458,t:1528139707036};\\\", \\\"{x:1620,y:434,t:1528139707052};\\\", \\\"{x:1632,y:414,t:1528139707069};\\\", \\\"{x:1639,y:396,t:1528139707085};\\\", \\\"{x:1644,y:381,t:1528139707101};\\\", \\\"{x:1650,y:360,t:1528139707119};\\\", \\\"{x:1653,y:344,t:1528139707136};\\\", \\\"{x:1654,y:334,t:1528139707152};\\\", \\\"{x:1655,y:327,t:1528139707169};\\\", \\\"{x:1656,y:322,t:1528139707185};\\\", \\\"{x:1657,y:317,t:1528139707203};\\\", \\\"{x:1657,y:315,t:1528139707220};\\\", \\\"{x:1657,y:314,t:1528139707297};\\\", \\\"{x:1654,y:314,t:1528139707408};\\\", \\\"{x:1651,y:314,t:1528139707419};\\\", \\\"{x:1647,y:314,t:1528139707436};\\\", \\\"{x:1643,y:315,t:1528139707453};\\\", \\\"{x:1641,y:316,t:1528139707469};\\\", \\\"{x:1639,y:316,t:1528139707486};\\\", \\\"{x:1638,y:318,t:1528139707503};\\\", \\\"{x:1634,y:321,t:1528139707520};\\\", \\\"{x:1628,y:326,t:1528139707536};\\\", \\\"{x:1622,y:331,t:1528139707553};\\\", \\\"{x:1613,y:340,t:1528139707571};\\\", \\\"{x:1603,y:351,t:1528139707587};\\\", \\\"{x:1591,y:365,t:1528139707604};\\\", \\\"{x:1580,y:379,t:1528139707620};\\\", \\\"{x:1559,y:398,t:1528139707637};\\\", \\\"{x:1529,y:420,t:1528139707653};\\\", \\\"{x:1500,y:443,t:1528139707671};\\\", \\\"{x:1473,y:465,t:1528139707687};\\\", \\\"{x:1455,y:482,t:1528139707705};\\\", \\\"{x:1434,y:502,t:1528139707721};\\\", \\\"{x:1404,y:538,t:1528139707738};\\\", \\\"{x:1383,y:562,t:1528139707755};\\\", \\\"{x:1363,y:580,t:1528139707771};\\\", \\\"{x:1347,y:603,t:1528139707789};\\\", \\\"{x:1326,y:634,t:1528139707805};\\\", \\\"{x:1304,y:665,t:1528139707822};\\\", \\\"{x:1289,y:694,t:1528139707838};\\\", \\\"{x:1279,y:715,t:1528139707854};\\\", \\\"{x:1268,y:741,t:1528139707871};\\\", \\\"{x:1257,y:780,t:1528139707889};\\\", \\\"{x:1254,y:792,t:1528139707904};\\\", \\\"{x:1241,y:820,t:1528139707922};\\\", \\\"{x:1234,y:837,t:1528139707939};\\\", \\\"{x:1227,y:857,t:1528139707954};\\\", \\\"{x:1223,y:875,t:1528139707972};\\\", \\\"{x:1222,y:893,t:1528139707988};\\\", \\\"{x:1222,y:904,t:1528139708005};\\\", \\\"{x:1222,y:908,t:1528139708022};\\\", \\\"{x:1222,y:910,t:1528139708039};\\\", \\\"{x:1222,y:911,t:1528139708058};\\\", \\\"{x:1223,y:911,t:1528139708073};\\\", \\\"{x:1227,y:917,t:1528139708090};\\\", \\\"{x:1235,y:925,t:1528139708105};\\\", \\\"{x:1243,y:936,t:1528139708123};\\\", \\\"{x:1248,y:943,t:1528139708138};\\\", \\\"{x:1254,y:947,t:1528139708156};\\\", \\\"{x:1258,y:948,t:1528139708173};\\\", \\\"{x:1263,y:950,t:1528139708190};\\\", \\\"{x:1269,y:950,t:1528139708206};\\\", \\\"{x:1275,y:951,t:1528139708223};\\\", \\\"{x:1281,y:955,t:1528139708240};\\\", \\\"{x:1287,y:956,t:1528139708256};\\\", \\\"{x:1291,y:959,t:1528139708273};\\\", \\\"{x:1293,y:960,t:1528139708290};\\\", \\\"{x:1293,y:958,t:1528139708493};\\\", \\\"{x:1290,y:948,t:1528139708507};\\\", \\\"{x:1288,y:945,t:1528139708524};\\\", \\\"{x:1285,y:937,t:1528139708541};\\\", \\\"{x:1280,y:925,t:1528139708558};\\\", \\\"{x:1272,y:908,t:1528139708573};\\\", \\\"{x:1264,y:891,t:1528139708591};\\\", \\\"{x:1258,y:882,t:1528139708607};\\\", \\\"{x:1255,y:877,t:1528139708624};\\\", \\\"{x:1254,y:876,t:1528139708641};\\\", \\\"{x:1251,y:871,t:1528139708658};\\\", \\\"{x:1251,y:870,t:1528139708675};\\\", \\\"{x:1251,y:868,t:1528139708690};\\\", \\\"{x:1250,y:868,t:1528139708708};\\\", \\\"{x:1249,y:867,t:1528139708725};\\\", \\\"{x:1249,y:871,t:1528139708962};\\\", \\\"{x:1253,y:879,t:1528139708976};\\\", \\\"{x:1259,y:897,t:1528139708992};\\\", \\\"{x:1266,y:911,t:1528139709009};\\\", \\\"{x:1275,y:928,t:1528139709026};\\\", \\\"{x:1282,y:940,t:1528139709043};\\\", \\\"{x:1284,y:944,t:1528139709059};\\\", \\\"{x:1284,y:943,t:1528139709234};\\\", \\\"{x:1283,y:936,t:1528139709243};\\\", \\\"{x:1280,y:929,t:1528139709260};\\\", \\\"{x:1278,y:924,t:1528139709276};\\\", \\\"{x:1276,y:918,t:1528139709293};\\\", \\\"{x:1273,y:910,t:1528139709310};\\\", \\\"{x:1267,y:899,t:1528139709327};\\\", \\\"{x:1264,y:895,t:1528139709344};\\\", \\\"{x:1260,y:887,t:1528139709360};\\\", \\\"{x:1253,y:877,t:1528139709377};\\\", \\\"{x:1247,y:869,t:1528139709393};\\\", \\\"{x:1243,y:862,t:1528139709409};\\\", \\\"{x:1239,y:855,t:1528139709426};\\\", \\\"{x:1236,y:851,t:1528139709444};\\\", \\\"{x:1233,y:847,t:1528139709461};\\\", \\\"{x:1231,y:844,t:1528139709477};\\\", \\\"{x:1228,y:840,t:1528139709494};\\\", \\\"{x:1217,y:828,t:1528139709515};\\\", \\\"{x:1201,y:813,t:1528139709529};\\\", \\\"{x:1167,y:787,t:1528139709543};\\\", \\\"{x:1098,y:743,t:1528139709562};\\\", \\\"{x:1031,y:709,t:1528139709579};\\\", \\\"{x:961,y:672,t:1528139709597};\\\", \\\"{x:909,y:652,t:1528139709613};\\\", \\\"{x:887,y:646,t:1528139709630};\\\", \\\"{x:866,y:640,t:1528139709647};\\\", \\\"{x:843,y:634,t:1528139709663};\\\", \\\"{x:824,y:629,t:1528139709680};\\\", \\\"{x:811,y:625,t:1528139709695};\\\", \\\"{x:798,y:624,t:1528139709712};\\\", \\\"{x:777,y:622,t:1528139709729};\\\", \\\"{x:760,y:619,t:1528139709746};\\\", \\\"{x:741,y:618,t:1528139709762};\\\", \\\"{x:723,y:618,t:1528139709780};\\\", \\\"{x:716,y:618,t:1528139709796};\\\", \\\"{x:707,y:619,t:1528139709812};\\\", \\\"{x:698,y:624,t:1528139709829};\\\", \\\"{x:683,y:634,t:1528139709846};\\\", \\\"{x:667,y:645,t:1528139709862};\\\", \\\"{x:653,y:656,t:1528139709880};\\\", \\\"{x:631,y:677,t:1528139709897};\\\", \\\"{x:620,y:699,t:1528139709913};\\\", \\\"{x:609,y:717,t:1528139709929};\\\", \\\"{x:594,y:740,t:1528139709946};\\\", \\\"{x:582,y:750,t:1528139709963};\\\", \\\"{x:566,y:760,t:1528139709979};\\\", \\\"{x:556,y:767,t:1528139709997};\\\", \\\"{x:548,y:771,t:1528139710012};\\\", \\\"{x:546,y:772,t:1528139710030};\\\", \\\"{x:544,y:774,t:1528139710046};\\\", \\\"{x:542,y:775,t:1528139710063};\\\", \\\"{x:540,y:775,t:1528139710079};\\\", \\\"{x:538,y:777,t:1528139710096};\\\", \\\"{x:537,y:776,t:1528139710248};\\\", \\\"{x:537,y:772,t:1528139710263};\\\", \\\"{x:537,y:767,t:1528139710280};\\\", \\\"{x:537,y:761,t:1528139710296};\\\", \\\"{x:536,y:756,t:1528139710313};\\\", \\\"{x:536,y:754,t:1528139710329};\\\", \\\"{x:536,y:752,t:1528139710346};\\\", \\\"{x:536,y:751,t:1528139710425};\\\" ] }, { \\\"rt\\\": 27963, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 409541, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-04 PM-H -H -04 PM-B -G -G -U -U -Z -Z -Z -Z -A -A -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:874,y:414,t:1528139714366};\\\", \\\"{x:924,y:366,t:1528139714458};\\\", \\\"{x:923,y:366,t:1528139715793};\\\", \\\"{x:923,y:365,t:1528139715800};\\\", \\\"{x:921,y:365,t:1528139715818};\\\", \\\"{x:920,y:365,t:1528139715834};\\\", \\\"{x:919,y:364,t:1528139715851};\\\", \\\"{x:919,y:368,t:1528139717098};\\\", \\\"{x:932,y:407,t:1528139717105};\\\", \\\"{x:952,y:455,t:1528139717119};\\\", \\\"{x:1013,y:546,t:1528139717137};\\\", \\\"{x:1087,y:637,t:1528139717151};\\\", \\\"{x:1201,y:755,t:1528139717168};\\\", \\\"{x:1289,y:831,t:1528139717184};\\\", \\\"{x:1380,y:905,t:1528139717201};\\\", \\\"{x:1462,y:971,t:1528139717219};\\\", \\\"{x:1530,y:1024,t:1528139717235};\\\", \\\"{x:1581,y:1065,t:1528139717252};\\\", \\\"{x:1622,y:1096,t:1528139717269};\\\", \\\"{x:1643,y:1111,t:1528139717284};\\\", \\\"{x:1655,y:1119,t:1528139717302};\\\", \\\"{x:1666,y:1128,t:1528139717319};\\\", \\\"{x:1675,y:1134,t:1528139717335};\\\", \\\"{x:1679,y:1137,t:1528139717351};\\\", \\\"{x:1681,y:1138,t:1528139717369};\\\", \\\"{x:1683,y:1138,t:1528139717408};\\\", \\\"{x:1684,y:1136,t:1528139717418};\\\", \\\"{x:1685,y:1129,t:1528139717436};\\\", \\\"{x:1685,y:1126,t:1528139717481};\\\", \\\"{x:1683,y:1121,t:1528139717489};\\\", \\\"{x:1680,y:1115,t:1528139717502};\\\", \\\"{x:1667,y:1098,t:1528139717519};\\\", \\\"{x:1643,y:1073,t:1528139717537};\\\", \\\"{x:1617,y:1056,t:1528139717553};\\\", \\\"{x:1595,y:1046,t:1528139717570};\\\", \\\"{x:1579,y:1039,t:1528139717586};\\\", \\\"{x:1568,y:1034,t:1528139717602};\\\", \\\"{x:1559,y:1029,t:1528139717619};\\\", \\\"{x:1550,y:1023,t:1528139717636};\\\", \\\"{x:1545,y:1021,t:1528139717652};\\\", \\\"{x:1541,y:1019,t:1528139717669};\\\", \\\"{x:1539,y:1017,t:1528139717686};\\\", \\\"{x:1538,y:1017,t:1528139717702};\\\", \\\"{x:1537,y:1017,t:1528139717719};\\\", \\\"{x:1536,y:1016,t:1528139717738};\\\", \\\"{x:1536,y:1015,t:1528139717873};\\\", \\\"{x:1536,y:1014,t:1528139717905};\\\", \\\"{x:1536,y:1013,t:1528139717919};\\\", \\\"{x:1536,y:1011,t:1528139717937};\\\", \\\"{x:1542,y:1006,t:1528139717954};\\\", \\\"{x:1546,y:1003,t:1528139717969};\\\", \\\"{x:1550,y:1001,t:1528139717986};\\\", \\\"{x:1552,y:999,t:1528139718003};\\\", \\\"{x:1557,y:997,t:1528139718019};\\\", \\\"{x:1562,y:996,t:1528139718036};\\\", \\\"{x:1569,y:992,t:1528139718053};\\\", \\\"{x:1574,y:990,t:1528139718069};\\\", \\\"{x:1578,y:988,t:1528139718086};\\\", \\\"{x:1582,y:987,t:1528139718103};\\\", \\\"{x:1584,y:985,t:1528139718119};\\\", \\\"{x:1585,y:985,t:1528139718137};\\\", \\\"{x:1590,y:982,t:1528139718153};\\\", \\\"{x:1593,y:980,t:1528139718169};\\\", \\\"{x:1597,y:976,t:1528139718186};\\\", \\\"{x:1600,y:974,t:1528139718203};\\\", \\\"{x:1603,y:969,t:1528139718220};\\\", \\\"{x:1605,y:965,t:1528139718237};\\\", \\\"{x:1606,y:963,t:1528139718253};\\\", \\\"{x:1606,y:962,t:1528139718274};\\\", \\\"{x:1607,y:962,t:1528139718286};\\\", \\\"{x:1607,y:961,t:1528139718330};\\\", \\\"{x:1607,y:960,t:1528139718345};\\\", \\\"{x:1607,y:959,t:1528139718394};\\\", \\\"{x:1607,y:958,t:1528139718434};\\\", \\\"{x:1607,y:957,t:1528139718761};\\\", \\\"{x:1607,y:956,t:1528139718770};\\\", \\\"{x:1607,y:953,t:1528139718787};\\\", \\\"{x:1606,y:952,t:1528139718804};\\\", \\\"{x:1606,y:950,t:1528139718820};\\\", \\\"{x:1605,y:948,t:1528139718837};\\\", \\\"{x:1604,y:947,t:1528139718854};\\\", \\\"{x:1603,y:944,t:1528139718870};\\\", \\\"{x:1602,y:943,t:1528139718887};\\\", \\\"{x:1601,y:941,t:1528139718903};\\\", \\\"{x:1598,y:937,t:1528139718920};\\\", \\\"{x:1592,y:928,t:1528139718938};\\\", \\\"{x:1588,y:923,t:1528139718953};\\\", \\\"{x:1585,y:919,t:1528139718971};\\\", \\\"{x:1583,y:914,t:1528139718987};\\\", \\\"{x:1582,y:911,t:1528139719004};\\\", \\\"{x:1581,y:908,t:1528139719020};\\\", \\\"{x:1577,y:901,t:1528139719037};\\\", \\\"{x:1572,y:891,t:1528139719054};\\\", \\\"{x:1570,y:880,t:1528139719070};\\\", \\\"{x:1569,y:876,t:1528139719087};\\\", \\\"{x:1567,y:868,t:1528139719103};\\\", \\\"{x:1565,y:861,t:1528139719121};\\\", \\\"{x:1558,y:844,t:1528139719137};\\\", \\\"{x:1548,y:825,t:1528139719153};\\\", \\\"{x:1535,y:804,t:1528139719170};\\\", \\\"{x:1517,y:772,t:1528139719187};\\\", \\\"{x:1496,y:741,t:1528139719205};\\\", \\\"{x:1482,y:716,t:1528139719220};\\\", \\\"{x:1467,y:694,t:1528139719237};\\\", \\\"{x:1455,y:672,t:1528139719254};\\\", \\\"{x:1443,y:646,t:1528139719270};\\\", \\\"{x:1434,y:629,t:1528139719287};\\\", \\\"{x:1429,y:617,t:1528139719305};\\\", \\\"{x:1426,y:605,t:1528139719320};\\\", \\\"{x:1420,y:590,t:1528139719337};\\\", \\\"{x:1417,y:581,t:1528139719354};\\\", \\\"{x:1415,y:573,t:1528139719370};\\\", \\\"{x:1412,y:566,t:1528139719393};\\\", \\\"{x:1412,y:562,t:1528139719404};\\\", \\\"{x:1411,y:561,t:1528139719456};\\\", \\\"{x:1411,y:560,t:1528139719521};\\\", \\\"{x:1411,y:559,t:1528139719577};\\\", \\\"{x:1408,y:559,t:1528139724509};\\\", \\\"{x:1316,y:555,t:1528139724525};\\\", \\\"{x:1214,y:555,t:1528139724543};\\\", \\\"{x:1071,y:540,t:1528139724557};\\\", \\\"{x:894,y:513,t:1528139724575};\\\", \\\"{x:742,y:495,t:1528139724591};\\\", \\\"{x:622,y:477,t:1528139724608};\\\", \\\"{x:515,y:469,t:1528139724624};\\\", \\\"{x:473,y:469,t:1528139724641};\\\", \\\"{x:448,y:473,t:1528139724657};\\\", \\\"{x:432,y:483,t:1528139724675};\\\", \\\"{x:424,y:490,t:1528139724691};\\\", \\\"{x:422,y:493,t:1528139724708};\\\", \\\"{x:421,y:495,t:1528139724724};\\\", \\\"{x:421,y:502,t:1528139724741};\\\", \\\"{x:422,y:515,t:1528139724758};\\\", \\\"{x:425,y:532,t:1528139724776};\\\", \\\"{x:439,y:551,t:1528139724793};\\\", \\\"{x:455,y:571,t:1528139724808};\\\", \\\"{x:479,y:596,t:1528139724826};\\\", \\\"{x:501,y:608,t:1528139724843};\\\", \\\"{x:526,y:618,t:1528139724859};\\\", \\\"{x:554,y:622,t:1528139724874};\\\", \\\"{x:584,y:626,t:1528139724892};\\\", \\\"{x:616,y:629,t:1528139724908};\\\", \\\"{x:636,y:631,t:1528139724924};\\\", \\\"{x:644,y:633,t:1528139724942};\\\", \\\"{x:647,y:634,t:1528139724957};\\\", \\\"{x:648,y:634,t:1528139725032};\\\", \\\"{x:649,y:634,t:1528139725042};\\\", \\\"{x:650,y:634,t:1528139725057};\\\", \\\"{x:650,y:630,t:1528139725075};\\\", \\\"{x:650,y:627,t:1528139725091};\\\", \\\"{x:650,y:626,t:1528139725108};\\\", \\\"{x:650,y:624,t:1528139725125};\\\", \\\"{x:648,y:616,t:1528139725143};\\\", \\\"{x:643,y:610,t:1528139725158};\\\", \\\"{x:642,y:609,t:1528139725174};\\\", \\\"{x:638,y:607,t:1528139725192};\\\", \\\"{x:631,y:602,t:1528139725208};\\\", \\\"{x:627,y:599,t:1528139725224};\\\", \\\"{x:625,y:598,t:1528139725242};\\\", \\\"{x:621,y:596,t:1528139725258};\\\", \\\"{x:618,y:595,t:1528139725275};\\\", \\\"{x:616,y:595,t:1528139725292};\\\", \\\"{x:615,y:595,t:1528139725309};\\\", \\\"{x:613,y:595,t:1528139725376};\\\", \\\"{x:613,y:593,t:1528139725704};\\\", \\\"{x:616,y:591,t:1528139725712};\\\", \\\"{x:621,y:587,t:1528139725726};\\\", \\\"{x:629,y:582,t:1528139725742};\\\", \\\"{x:633,y:581,t:1528139725759};\\\", \\\"{x:644,y:575,t:1528139725777};\\\", \\\"{x:648,y:573,t:1528139725792};\\\", \\\"{x:656,y:570,t:1528139725810};\\\", \\\"{x:666,y:565,t:1528139725825};\\\", \\\"{x:679,y:560,t:1528139725842};\\\", \\\"{x:696,y:555,t:1528139725859};\\\", \\\"{x:721,y:550,t:1528139725876};\\\", \\\"{x:756,y:550,t:1528139725893};\\\", \\\"{x:787,y:550,t:1528139725909};\\\", \\\"{x:825,y:550,t:1528139725926};\\\", \\\"{x:886,y:550,t:1528139725943};\\\", \\\"{x:956,y:558,t:1528139725959};\\\", \\\"{x:1018,y:565,t:1528139725976};\\\", \\\"{x:1030,y:567,t:1528139725992};\\\", \\\"{x:1065,y:572,t:1528139726009};\\\", \\\"{x:1082,y:573,t:1528139726025};\\\", \\\"{x:1087,y:575,t:1528139726043};\\\", \\\"{x:1091,y:576,t:1528139726058};\\\", \\\"{x:1094,y:576,t:1528139726075};\\\", \\\"{x:1097,y:576,t:1528139726093};\\\", \\\"{x:1102,y:577,t:1528139726109};\\\", \\\"{x:1118,y:581,t:1528139726125};\\\", \\\"{x:1142,y:588,t:1528139726143};\\\", \\\"{x:1169,y:594,t:1528139726159};\\\", \\\"{x:1191,y:598,t:1528139726176};\\\", \\\"{x:1219,y:602,t:1528139726192};\\\", \\\"{x:1227,y:602,t:1528139726209};\\\", \\\"{x:1232,y:602,t:1528139726226};\\\", \\\"{x:1244,y:602,t:1528139726243};\\\", \\\"{x:1263,y:602,t:1528139726258};\\\", \\\"{x:1281,y:602,t:1528139726275};\\\", \\\"{x:1296,y:602,t:1528139726293};\\\", \\\"{x:1307,y:602,t:1528139726309};\\\", \\\"{x:1316,y:600,t:1528139726326};\\\", \\\"{x:1325,y:597,t:1528139726343};\\\", \\\"{x:1334,y:597,t:1528139726360};\\\", \\\"{x:1338,y:597,t:1528139726376};\\\", \\\"{x:1339,y:597,t:1528139726393};\\\", \\\"{x:1341,y:596,t:1528139726411};\\\", \\\"{x:1346,y:594,t:1528139726426};\\\", \\\"{x:1350,y:592,t:1528139726443};\\\", \\\"{x:1354,y:590,t:1528139726460};\\\", \\\"{x:1358,y:587,t:1528139726476};\\\", \\\"{x:1363,y:585,t:1528139726493};\\\", \\\"{x:1374,y:581,t:1528139726511};\\\", \\\"{x:1379,y:581,t:1528139726526};\\\", \\\"{x:1386,y:580,t:1528139726544};\\\", \\\"{x:1388,y:578,t:1528139726560};\\\", \\\"{x:1390,y:578,t:1528139726577};\\\", \\\"{x:1392,y:577,t:1528139726593};\\\", \\\"{x:1394,y:576,t:1528139726610};\\\", \\\"{x:1396,y:576,t:1528139726627};\\\", \\\"{x:1398,y:575,t:1528139726643};\\\", \\\"{x:1399,y:575,t:1528139726660};\\\", \\\"{x:1400,y:574,t:1528139726678};\\\", \\\"{x:1401,y:574,t:1528139726693};\\\", \\\"{x:1402,y:573,t:1528139726711};\\\", \\\"{x:1404,y:572,t:1528139726784};\\\", \\\"{x:1404,y:571,t:1528139726816};\\\", \\\"{x:1405,y:571,t:1528139726856};\\\", \\\"{x:1406,y:570,t:1528139726864};\\\", \\\"{x:1408,y:569,t:1528139726876};\\\", \\\"{x:1410,y:567,t:1528139726896};\\\", \\\"{x:1412,y:566,t:1528139726910};\\\", \\\"{x:1413,y:565,t:1528139726936};\\\", \\\"{x:1415,y:563,t:1528139726968};\\\", \\\"{x:1415,y:562,t:1528139726992};\\\", \\\"{x:1424,y:583,t:1528139729932};\\\", \\\"{x:1464,y:659,t:1528139729945};\\\", \\\"{x:1507,y:718,t:1528139729962};\\\", \\\"{x:1536,y:760,t:1528139729979};\\\", \\\"{x:1570,y:803,t:1528139729996};\\\", \\\"{x:1598,y:841,t:1528139730012};\\\", \\\"{x:1618,y:865,t:1528139730029};\\\", \\\"{x:1634,y:884,t:1528139730046};\\\", \\\"{x:1649,y:905,t:1528139730062};\\\", \\\"{x:1660,y:920,t:1528139730080};\\\", \\\"{x:1664,y:929,t:1528139730096};\\\", \\\"{x:1664,y:931,t:1528139730113};\\\", \\\"{x:1665,y:932,t:1528139730129};\\\", \\\"{x:1666,y:933,t:1528139730146};\\\", \\\"{x:1666,y:934,t:1528139730177};\\\", \\\"{x:1667,y:935,t:1528139730185};\\\", \\\"{x:1667,y:936,t:1528139730197};\\\", \\\"{x:1667,y:938,t:1528139730212};\\\", \\\"{x:1667,y:940,t:1528139730273};\\\", \\\"{x:1663,y:942,t:1528139730280};\\\", \\\"{x:1658,y:946,t:1528139730295};\\\", \\\"{x:1653,y:952,t:1528139730311};\\\", \\\"{x:1649,y:956,t:1528139730329};\\\", \\\"{x:1645,y:959,t:1528139730346};\\\", \\\"{x:1639,y:961,t:1528139730363};\\\", \\\"{x:1636,y:964,t:1528139730379};\\\", \\\"{x:1635,y:964,t:1528139730396};\\\", \\\"{x:1633,y:966,t:1528139730413};\\\", \\\"{x:1632,y:967,t:1528139730429};\\\", \\\"{x:1630,y:968,t:1528139730447};\\\", \\\"{x:1628,y:969,t:1528139730463};\\\", \\\"{x:1626,y:970,t:1528139730479};\\\", \\\"{x:1624,y:970,t:1528139730578};\\\", \\\"{x:1621,y:964,t:1528139730586};\\\", \\\"{x:1617,y:958,t:1528139730596};\\\", \\\"{x:1614,y:954,t:1528139730614};\\\", \\\"{x:1613,y:953,t:1528139730641};\\\", \\\"{x:1613,y:952,t:1528139730649};\\\", \\\"{x:1612,y:952,t:1528139730664};\\\", \\\"{x:1610,y:950,t:1528139730680};\\\", \\\"{x:1610,y:949,t:1528139730705};\\\", \\\"{x:1610,y:947,t:1528139730713};\\\", \\\"{x:1610,y:942,t:1528139730729};\\\", \\\"{x:1610,y:935,t:1528139730747};\\\", \\\"{x:1612,y:926,t:1528139730764};\\\", \\\"{x:1616,y:917,t:1528139730781};\\\", \\\"{x:1622,y:906,t:1528139730797};\\\", \\\"{x:1634,y:892,t:1528139730814};\\\", \\\"{x:1644,y:883,t:1528139730829};\\\", \\\"{x:1650,y:877,t:1528139730847};\\\", \\\"{x:1655,y:869,t:1528139730863};\\\", \\\"{x:1660,y:863,t:1528139730880};\\\", \\\"{x:1662,y:857,t:1528139730896};\\\", \\\"{x:1666,y:852,t:1528139730913};\\\", \\\"{x:1668,y:849,t:1528139730931};\\\", \\\"{x:1668,y:848,t:1528139730947};\\\", \\\"{x:1669,y:847,t:1528139730963};\\\", \\\"{x:1670,y:846,t:1528139730986};\\\", \\\"{x:1671,y:845,t:1528139730996};\\\", \\\"{x:1672,y:844,t:1528139731014};\\\", \\\"{x:1673,y:843,t:1528139731030};\\\", \\\"{x:1675,y:841,t:1528139731047};\\\", \\\"{x:1677,y:840,t:1528139731064};\\\", \\\"{x:1681,y:837,t:1528139731081};\\\", \\\"{x:1683,y:836,t:1528139731097};\\\", \\\"{x:1683,y:835,t:1528139731117};\\\", \\\"{x:1683,y:834,t:1528139731129};\\\", \\\"{x:1684,y:834,t:1528139731146};\\\", \\\"{x:1685,y:832,t:1528139731176};\\\", \\\"{x:1686,y:831,t:1528139731192};\\\", \\\"{x:1686,y:828,t:1528139732034};\\\", \\\"{x:1684,y:819,t:1528139732050};\\\", \\\"{x:1675,y:805,t:1528139732064};\\\", \\\"{x:1674,y:804,t:1528139732080};\\\", \\\"{x:1673,y:802,t:1528139732097};\\\", \\\"{x:1672,y:799,t:1528139732114};\\\", \\\"{x:1670,y:796,t:1528139732130};\\\", \\\"{x:1669,y:795,t:1528139732147};\\\", \\\"{x:1668,y:794,t:1528139732164};\\\", \\\"{x:1668,y:793,t:1528139732184};\\\", \\\"{x:1667,y:793,t:1528139732232};\\\", \\\"{x:1667,y:792,t:1528139732247};\\\", \\\"{x:1666,y:790,t:1528139732264};\\\", \\\"{x:1665,y:788,t:1528139732281};\\\", \\\"{x:1664,y:787,t:1528139732298};\\\", \\\"{x:1663,y:787,t:1528139732314};\\\", \\\"{x:1662,y:785,t:1528139732331};\\\", \\\"{x:1661,y:784,t:1528139732360};\\\", \\\"{x:1660,y:782,t:1528139732376};\\\", \\\"{x:1659,y:781,t:1528139732408};\\\", \\\"{x:1659,y:779,t:1528139732417};\\\", \\\"{x:1657,y:778,t:1528139732431};\\\", \\\"{x:1656,y:775,t:1528139732447};\\\", \\\"{x:1654,y:772,t:1528139732464};\\\", \\\"{x:1654,y:771,t:1528139732480};\\\", \\\"{x:1653,y:770,t:1528139732497};\\\", \\\"{x:1653,y:769,t:1528139732514};\\\", \\\"{x:1652,y:768,t:1528139732536};\\\", \\\"{x:1652,y:767,t:1528139732562};\\\", \\\"{x:1652,y:766,t:1528139732581};\\\", \\\"{x:1651,y:766,t:1528139732597};\\\", \\\"{x:1650,y:765,t:1528139732614};\\\", \\\"{x:1650,y:763,t:1528139732631};\\\", \\\"{x:1649,y:762,t:1528139732647};\\\", \\\"{x:1647,y:760,t:1528139732665};\\\", \\\"{x:1647,y:759,t:1528139732689};\\\", \\\"{x:1647,y:758,t:1528139732768};\\\", \\\"{x:1646,y:757,t:1528139732882};\\\", \\\"{x:1644,y:756,t:1528139732944};\\\", \\\"{x:1640,y:756,t:1528139732952};\\\", \\\"{x:1637,y:756,t:1528139732965};\\\", \\\"{x:1631,y:756,t:1528139732981};\\\", \\\"{x:1626,y:756,t:1528139732998};\\\", \\\"{x:1616,y:759,t:1528139733015};\\\", \\\"{x:1602,y:764,t:1528139733032};\\\", \\\"{x:1588,y:774,t:1528139733048};\\\", \\\"{x:1581,y:778,t:1528139733065};\\\", \\\"{x:1574,y:782,t:1528139733081};\\\", \\\"{x:1567,y:788,t:1528139733099};\\\", \\\"{x:1560,y:793,t:1528139733116};\\\", \\\"{x:1554,y:796,t:1528139733132};\\\", \\\"{x:1550,y:799,t:1528139733149};\\\", \\\"{x:1542,y:805,t:1528139733165};\\\", \\\"{x:1536,y:809,t:1528139733182};\\\", \\\"{x:1532,y:814,t:1528139733199};\\\", \\\"{x:1526,y:816,t:1528139733216};\\\", \\\"{x:1521,y:819,t:1528139733231};\\\", \\\"{x:1514,y:823,t:1528139733248};\\\", \\\"{x:1509,y:825,t:1528139733265};\\\", \\\"{x:1503,y:827,t:1528139733282};\\\", \\\"{x:1494,y:830,t:1528139733299};\\\", \\\"{x:1487,y:831,t:1528139733316};\\\", \\\"{x:1478,y:832,t:1528139733335};\\\", \\\"{x:1472,y:835,t:1528139733348};\\\", \\\"{x:1468,y:836,t:1528139733365};\\\", \\\"{x:1467,y:836,t:1528139733381};\\\", \\\"{x:1466,y:836,t:1528139733398};\\\", \\\"{x:1465,y:836,t:1528139733415};\\\", \\\"{x:1464,y:836,t:1528139733561};\\\", \\\"{x:1464,y:835,t:1528139733568};\\\", \\\"{x:1464,y:834,t:1528139733582};\\\", \\\"{x:1465,y:831,t:1528139733598};\\\", \\\"{x:1467,y:830,t:1528139733616};\\\", \\\"{x:1469,y:828,t:1528139733632};\\\", \\\"{x:1470,y:827,t:1528139733656};\\\", \\\"{x:1471,y:827,t:1528139733954};\\\", \\\"{x:1472,y:827,t:1528139733965};\\\", \\\"{x:1473,y:827,t:1528139734041};\\\", \\\"{x:1474,y:827,t:1528139734138};\\\", \\\"{x:1475,y:827,t:1528139734202};\\\", \\\"{x:1476,y:827,t:1528139734222};\\\", \\\"{x:1477,y:827,t:1528139734255};\\\", \\\"{x:1478,y:827,t:1528139734296};\\\", \\\"{x:1479,y:827,t:1528139734304};\\\", \\\"{x:1480,y:826,t:1528139734553};\\\", \\\"{x:1476,y:825,t:1528139734569};\\\", \\\"{x:1464,y:825,t:1528139734583};\\\", \\\"{x:1448,y:831,t:1528139734599};\\\", \\\"{x:1417,y:842,t:1528139734616};\\\", \\\"{x:1390,y:849,t:1528139734632};\\\", \\\"{x:1368,y:855,t:1528139734649};\\\", \\\"{x:1356,y:859,t:1528139734666};\\\", \\\"{x:1355,y:859,t:1528139734682};\\\", \\\"{x:1354,y:859,t:1528139734699};\\\", \\\"{x:1353,y:860,t:1528139734717};\\\", \\\"{x:1353,y:861,t:1528139734937};\\\", \\\"{x:1353,y:863,t:1528139734950};\\\", \\\"{x:1352,y:868,t:1528139734967};\\\", \\\"{x:1351,y:872,t:1528139734984};\\\", \\\"{x:1347,y:882,t:1528139735000};\\\", \\\"{x:1340,y:896,t:1528139735017};\\\", \\\"{x:1338,y:902,t:1528139735034};\\\", \\\"{x:1336,y:906,t:1528139735050};\\\", \\\"{x:1335,y:908,t:1528139735067};\\\", \\\"{x:1335,y:909,t:1528139735097};\\\", \\\"{x:1335,y:906,t:1528139735305};\\\", \\\"{x:1337,y:902,t:1528139735317};\\\", \\\"{x:1341,y:894,t:1528139735333};\\\", \\\"{x:1345,y:889,t:1528139735351};\\\", \\\"{x:1348,y:887,t:1528139735366};\\\", \\\"{x:1348,y:888,t:1528139735848};\\\", \\\"{x:1348,y:889,t:1528139735872};\\\", \\\"{x:1348,y:890,t:1528139735888};\\\", \\\"{x:1348,y:891,t:1528139735904};\\\", \\\"{x:1347,y:893,t:1528139735939};\\\", \\\"{x:1347,y:894,t:1528139735967};\\\", \\\"{x:1346,y:894,t:1528139735983};\\\", \\\"{x:1345,y:895,t:1528139736000};\\\", \\\"{x:1345,y:896,t:1528139736097};\\\", \\\"{x:1343,y:891,t:1528139736619};\\\", \\\"{x:1336,y:879,t:1528139736635};\\\", \\\"{x:1332,y:874,t:1528139736650};\\\", \\\"{x:1330,y:870,t:1528139736667};\\\", \\\"{x:1328,y:868,t:1528139736684};\\\", \\\"{x:1327,y:867,t:1528139736702};\\\", \\\"{x:1327,y:866,t:1528139736744};\\\", \\\"{x:1327,y:865,t:1528139736776};\\\", \\\"{x:1326,y:865,t:1528139736784};\\\", \\\"{x:1325,y:863,t:1528139736801};\\\", \\\"{x:1324,y:862,t:1528139736817};\\\", \\\"{x:1322,y:861,t:1528139736834};\\\", \\\"{x:1320,y:859,t:1528139736851};\\\", \\\"{x:1318,y:858,t:1528139736868};\\\", \\\"{x:1315,y:855,t:1528139736884};\\\", \\\"{x:1312,y:853,t:1528139736902};\\\", \\\"{x:1311,y:852,t:1528139736917};\\\", \\\"{x:1309,y:851,t:1528139736934};\\\", \\\"{x:1307,y:850,t:1528139736952};\\\", \\\"{x:1305,y:848,t:1528139736968};\\\", \\\"{x:1297,y:843,t:1528139736985};\\\", \\\"{x:1291,y:839,t:1528139737002};\\\", \\\"{x:1284,y:833,t:1528139737020};\\\", \\\"{x:1277,y:828,t:1528139737034};\\\", \\\"{x:1272,y:826,t:1528139737052};\\\", \\\"{x:1272,y:825,t:1528139737068};\\\", \\\"{x:1271,y:825,t:1528139737135};\\\", \\\"{x:1272,y:826,t:1528139737480};\\\", \\\"{x:1276,y:828,t:1528139737490};\\\", \\\"{x:1278,y:829,t:1528139737518};\\\", \\\"{x:1279,y:829,t:1528139737584};\\\", \\\"{x:1269,y:829,t:1528139737902};\\\", \\\"{x:1261,y:829,t:1528139737918};\\\", \\\"{x:1247,y:829,t:1528139737935};\\\", \\\"{x:1240,y:829,t:1528139737952};\\\", \\\"{x:1236,y:829,t:1528139737968};\\\", \\\"{x:1234,y:829,t:1528139737986};\\\", \\\"{x:1233,y:829,t:1528139738002};\\\", \\\"{x:1230,y:829,t:1528139738018};\\\", \\\"{x:1227,y:829,t:1528139738035};\\\", \\\"{x:1226,y:829,t:1528139738052};\\\", \\\"{x:1224,y:829,t:1528139738069};\\\", \\\"{x:1223,y:829,t:1528139738086};\\\", \\\"{x:1221,y:829,t:1528139738103};\\\", \\\"{x:1220,y:829,t:1528139738121};\\\", \\\"{x:1218,y:829,t:1528139738135};\\\", \\\"{x:1217,y:829,t:1528139738176};\\\", \\\"{x:1215,y:829,t:1528139738192};\\\", \\\"{x:1214,y:829,t:1528139738202};\\\", \\\"{x:1213,y:829,t:1528139738218};\\\", \\\"{x:1211,y:829,t:1528139738236};\\\", \\\"{x:1209,y:829,t:1528139738252};\\\", \\\"{x:1208,y:829,t:1528139738269};\\\", \\\"{x:1206,y:829,t:1528139738336};\\\", \\\"{x:1215,y:834,t:1528139738485};\\\", \\\"{x:1246,y:844,t:1528139738503};\\\", \\\"{x:1278,y:854,t:1528139738519};\\\", \\\"{x:1367,y:879,t:1528139738536};\\\", \\\"{x:1425,y:894,t:1528139738552};\\\", \\\"{x:1478,y:910,t:1528139738569};\\\", \\\"{x:1537,y:926,t:1528139738585};\\\", \\\"{x:1579,y:939,t:1528139738603};\\\", \\\"{x:1592,y:940,t:1528139738619};\\\", \\\"{x:1593,y:941,t:1528139738636};\\\", \\\"{x:1595,y:941,t:1528139738652};\\\", \\\"{x:1591,y:941,t:1528139738794};\\\", \\\"{x:1580,y:941,t:1528139738803};\\\", \\\"{x:1554,y:941,t:1528139738819};\\\", \\\"{x:1526,y:941,t:1528139738837};\\\", \\\"{x:1495,y:941,t:1528139738852};\\\", \\\"{x:1467,y:943,t:1528139738869};\\\", \\\"{x:1449,y:946,t:1528139738886};\\\", \\\"{x:1439,y:947,t:1528139738902};\\\", \\\"{x:1438,y:947,t:1528139738920};\\\", \\\"{x:1439,y:949,t:1528139739088};\\\", \\\"{x:1446,y:951,t:1528139739102};\\\", \\\"{x:1461,y:951,t:1528139739119};\\\", \\\"{x:1487,y:953,t:1528139739136};\\\", \\\"{x:1506,y:953,t:1528139739154};\\\", \\\"{x:1527,y:955,t:1528139739170};\\\", \\\"{x:1541,y:956,t:1528139739186};\\\", \\\"{x:1549,y:958,t:1528139739202};\\\", \\\"{x:1554,y:959,t:1528139739220};\\\", \\\"{x:1556,y:959,t:1528139739237};\\\", \\\"{x:1557,y:959,t:1528139739254};\\\", \\\"{x:1558,y:959,t:1528139739313};\\\", \\\"{x:1559,y:959,t:1528139739321};\\\", \\\"{x:1564,y:960,t:1528139739336};\\\", \\\"{x:1573,y:963,t:1528139739355};\\\", \\\"{x:1580,y:963,t:1528139739370};\\\", \\\"{x:1585,y:963,t:1528139739387};\\\", \\\"{x:1588,y:963,t:1528139739404};\\\", \\\"{x:1589,y:963,t:1528139739420};\\\", \\\"{x:1592,y:964,t:1528139739437};\\\", \\\"{x:1594,y:965,t:1528139739454};\\\", \\\"{x:1597,y:966,t:1528139739470};\\\", \\\"{x:1599,y:966,t:1528139739487};\\\", \\\"{x:1600,y:966,t:1528139739504};\\\", \\\"{x:1601,y:966,t:1528139739519};\\\", \\\"{x:1604,y:966,t:1528139739537};\\\", \\\"{x:1608,y:968,t:1528139739554};\\\", \\\"{x:1610,y:968,t:1528139739570};\\\", \\\"{x:1611,y:968,t:1528139739587};\\\", \\\"{x:1612,y:968,t:1528139739604};\\\", \\\"{x:1613,y:968,t:1528139739620};\\\", \\\"{x:1614,y:968,t:1528139739641};\\\", \\\"{x:1615,y:968,t:1528139739654};\\\", \\\"{x:1616,y:968,t:1528139739670};\\\", \\\"{x:1618,y:968,t:1528139739689};\\\", \\\"{x:1618,y:967,t:1528139739704};\\\", \\\"{x:1620,y:966,t:1528139739721};\\\", \\\"{x:1620,y:964,t:1528139739745};\\\", \\\"{x:1620,y:961,t:1528139739754};\\\", \\\"{x:1620,y:960,t:1528139739771};\\\", \\\"{x:1621,y:957,t:1528139739787};\\\", \\\"{x:1621,y:952,t:1528139739804};\\\", \\\"{x:1621,y:945,t:1528139739821};\\\", \\\"{x:1620,y:938,t:1528139739837};\\\", \\\"{x:1618,y:928,t:1528139739854};\\\", \\\"{x:1616,y:919,t:1528139739871};\\\", \\\"{x:1614,y:911,t:1528139739887};\\\", \\\"{x:1611,y:905,t:1528139739904};\\\", \\\"{x:1610,y:901,t:1528139739921};\\\", \\\"{x:1608,y:897,t:1528139739937};\\\", \\\"{x:1607,y:894,t:1528139739953};\\\", \\\"{x:1606,y:890,t:1528139739970};\\\", \\\"{x:1603,y:885,t:1528139739986};\\\", \\\"{x:1600,y:879,t:1528139740004};\\\", \\\"{x:1598,y:876,t:1528139740021};\\\", \\\"{x:1595,y:871,t:1528139740038};\\\", \\\"{x:1594,y:867,t:1528139740053};\\\", \\\"{x:1592,y:864,t:1528139740070};\\\", \\\"{x:1589,y:859,t:1528139740086};\\\", \\\"{x:1584,y:851,t:1528139740104};\\\", \\\"{x:1577,y:842,t:1528139740120};\\\", \\\"{x:1573,y:836,t:1528139740137};\\\", \\\"{x:1567,y:828,t:1528139740154};\\\", \\\"{x:1563,y:821,t:1528139740171};\\\", \\\"{x:1558,y:814,t:1528139740187};\\\", \\\"{x:1535,y:781,t:1528139740204};\\\", \\\"{x:1503,y:736,t:1528139740221};\\\", \\\"{x:1466,y:687,t:1528139740238};\\\", \\\"{x:1432,y:642,t:1528139740254};\\\", \\\"{x:1395,y:598,t:1528139740270};\\\", \\\"{x:1373,y:573,t:1528139740287};\\\", \\\"{x:1360,y:557,t:1528139740303};\\\", \\\"{x:1350,y:545,t:1528139740320};\\\", \\\"{x:1343,y:536,t:1528139740338};\\\", \\\"{x:1332,y:523,t:1528139740353};\\\", \\\"{x:1321,y:510,t:1528139740371};\\\", \\\"{x:1312,y:502,t:1528139740387};\\\", \\\"{x:1306,y:495,t:1528139740403};\\\", \\\"{x:1297,y:489,t:1528139740421};\\\", \\\"{x:1287,y:483,t:1528139740437};\\\", \\\"{x:1275,y:477,t:1528139740454};\\\", \\\"{x:1266,y:473,t:1528139740471};\\\", \\\"{x:1260,y:471,t:1528139740487};\\\", \\\"{x:1257,y:470,t:1528139740503};\\\", \\\"{x:1256,y:470,t:1528139740520};\\\", \\\"{x:1252,y:470,t:1528139740538};\\\", \\\"{x:1244,y:470,t:1528139740555};\\\", \\\"{x:1230,y:470,t:1528139740571};\\\", \\\"{x:1211,y:470,t:1528139740588};\\\", \\\"{x:1188,y:470,t:1528139740604};\\\", \\\"{x:1159,y:476,t:1528139740621};\\\", \\\"{x:1120,y:484,t:1528139740638};\\\", \\\"{x:1045,y:502,t:1528139740655};\\\", \\\"{x:961,y:519,t:1528139740671};\\\", \\\"{x:860,y:538,t:1528139740688};\\\", \\\"{x:711,y:578,t:1528139740704};\\\", \\\"{x:623,y:615,t:1528139740720};\\\", \\\"{x:563,y:646,t:1528139740738};\\\", \\\"{x:513,y:689,t:1528139740755};\\\", \\\"{x:435,y:789,t:1528139740788};\\\", \\\"{x:415,y:820,t:1528139740805};\\\", \\\"{x:407,y:832,t:1528139740820};\\\", \\\"{x:404,y:835,t:1528139740837};\\\", \\\"{x:412,y:835,t:1528139741000};\\\", \\\"{x:423,y:829,t:1528139741009};\\\", \\\"{x:434,y:823,t:1528139741021};\\\", \\\"{x:467,y:809,t:1528139741038};\\\", \\\"{x:491,y:797,t:1528139741055};\\\", \\\"{x:511,y:787,t:1528139741072};\\\", \\\"{x:518,y:784,t:1528139741088};\\\", \\\"{x:518,y:783,t:1528139741105};\\\", \\\"{x:519,y:783,t:1528139741225};\\\", \\\"{x:519,y:782,t:1528139741289};\\\", \\\"{x:519,y:781,t:1528139741305};\\\", \\\"{x:517,y:773,t:1528139741322};\\\", \\\"{x:514,y:764,t:1528139741340};\\\", \\\"{x:513,y:755,t:1528139741354};\\\", \\\"{x:513,y:748,t:1528139741371};\\\", \\\"{x:513,y:741,t:1528139741388};\\\", \\\"{x:513,y:734,t:1528139741405};\\\", \\\"{x:514,y:729,t:1528139741422};\\\", \\\"{x:514,y:727,t:1528139741439};\\\", \\\"{x:514,y:732,t:1528139741865};\\\", \\\"{x:514,y:734,t:1528139741872};\\\", \\\"{x:514,y:738,t:1528139741890};\\\", \\\"{x:514,y:739,t:1528139741905};\\\", \\\"{x:514,y:740,t:1528139741921};\\\", \\\"{x:514,y:741,t:1528139741953};\\\" ] }, { \\\"rt\\\": 23046, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 433876, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -I -I -I -I -I -O -O -O -12 PM-12 PM-O -O -I -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:740,t:1528139744104};\\\", \\\"{x:513,y:740,t:1528139745490};\\\", \\\"{x:511,y:740,t:1528139745496};\\\", \\\"{x:508,y:740,t:1528139745508};\\\", \\\"{x:507,y:740,t:1528139745525};\\\", \\\"{x:506,y:740,t:1528139745657};\\\", \\\"{x:506,y:732,t:1528139745674};\\\", \\\"{x:507,y:720,t:1528139745692};\\\", \\\"{x:510,y:704,t:1528139745708};\\\", \\\"{x:515,y:683,t:1528139745726};\\\", \\\"{x:518,y:667,t:1528139745742};\\\", \\\"{x:520,y:653,t:1528139745758};\\\", \\\"{x:521,y:644,t:1528139745774};\\\", \\\"{x:523,y:641,t:1528139745791};\\\", \\\"{x:523,y:639,t:1528139745808};\\\", \\\"{x:524,y:637,t:1528139745824};\\\", \\\"{x:524,y:636,t:1528139745912};\\\", \\\"{x:524,y:630,t:1528139746538};\\\", \\\"{x:524,y:600,t:1528139746559};\\\", \\\"{x:524,y:585,t:1528139746574};\\\", \\\"{x:521,y:569,t:1528139746589};\\\", \\\"{x:514,y:545,t:1528139746609};\\\", \\\"{x:510,y:533,t:1528139746626};\\\", \\\"{x:506,y:529,t:1528139746643};\\\", \\\"{x:505,y:527,t:1528139746658};\\\", \\\"{x:499,y:524,t:1528139746675};\\\", \\\"{x:492,y:521,t:1528139746692};\\\", \\\"{x:475,y:516,t:1528139746709};\\\", \\\"{x:451,y:515,t:1528139746726};\\\", \\\"{x:425,y:515,t:1528139746742};\\\", \\\"{x:405,y:515,t:1528139746760};\\\", \\\"{x:398,y:515,t:1528139746775};\\\", \\\"{x:393,y:515,t:1528139746792};\\\", \\\"{x:390,y:516,t:1528139746810};\\\", \\\"{x:388,y:518,t:1528139746827};\\\", \\\"{x:387,y:519,t:1528139746843};\\\", \\\"{x:385,y:522,t:1528139746860};\\\", \\\"{x:383,y:524,t:1528139746877};\\\", \\\"{x:382,y:526,t:1528139746894};\\\", \\\"{x:380,y:528,t:1528139746910};\\\", \\\"{x:379,y:529,t:1528139746927};\\\", \\\"{x:378,y:531,t:1528139746944};\\\", \\\"{x:383,y:532,t:1528139747225};\\\", \\\"{x:388,y:532,t:1528139747233};\\\", \\\"{x:393,y:532,t:1528139747245};\\\", \\\"{x:404,y:532,t:1528139747262};\\\", \\\"{x:416,y:529,t:1528139747278};\\\", \\\"{x:428,y:524,t:1528139747295};\\\", \\\"{x:442,y:520,t:1528139747312};\\\", \\\"{x:454,y:520,t:1528139747328};\\\", \\\"{x:465,y:519,t:1528139747345};\\\", \\\"{x:474,y:519,t:1528139747363};\\\", \\\"{x:480,y:519,t:1528139747379};\\\", \\\"{x:488,y:519,t:1528139747395};\\\", \\\"{x:493,y:519,t:1528139747411};\\\", \\\"{x:496,y:519,t:1528139747428};\\\", \\\"{x:500,y:519,t:1528139747446};\\\", \\\"{x:502,y:518,t:1528139747461};\\\", \\\"{x:503,y:518,t:1528139747488};\\\", \\\"{x:505,y:518,t:1528139748049};\\\", \\\"{x:517,y:517,t:1528139748064};\\\", \\\"{x:543,y:517,t:1528139748081};\\\", \\\"{x:565,y:517,t:1528139748098};\\\", \\\"{x:581,y:517,t:1528139748115};\\\", \\\"{x:598,y:517,t:1528139748132};\\\", \\\"{x:618,y:517,t:1528139748148};\\\", \\\"{x:640,y:517,t:1528139748165};\\\", \\\"{x:658,y:517,t:1528139748182};\\\", \\\"{x:672,y:517,t:1528139748199};\\\", \\\"{x:685,y:517,t:1528139748215};\\\", \\\"{x:707,y:512,t:1528139748232};\\\", \\\"{x:719,y:511,t:1528139748248};\\\", \\\"{x:729,y:510,t:1528139748266};\\\", \\\"{x:736,y:509,t:1528139748282};\\\", \\\"{x:740,y:509,t:1528139748299};\\\", \\\"{x:744,y:509,t:1528139748316};\\\", \\\"{x:754,y:508,t:1528139748332};\\\", \\\"{x:761,y:507,t:1528139748349};\\\", \\\"{x:762,y:507,t:1528139748366};\\\", \\\"{x:755,y:507,t:1528139749002};\\\", \\\"{x:740,y:509,t:1528139749019};\\\", \\\"{x:723,y:509,t:1528139749035};\\\", \\\"{x:707,y:509,t:1528139749052};\\\", \\\"{x:696,y:506,t:1528139749069};\\\", \\\"{x:692,y:505,t:1528139749085};\\\", \\\"{x:690,y:505,t:1528139749102};\\\", \\\"{x:687,y:505,t:1528139749119};\\\", \\\"{x:680,y:504,t:1528139749135};\\\", \\\"{x:665,y:503,t:1528139749153};\\\", \\\"{x:655,y:503,t:1528139749169};\\\", \\\"{x:646,y:502,t:1528139749185};\\\", \\\"{x:641,y:500,t:1528139749201};\\\", \\\"{x:650,y:496,t:1528139751537};\\\", \\\"{x:671,y:494,t:1528139751544};\\\", \\\"{x:721,y:490,t:1528139751562};\\\", \\\"{x:780,y:480,t:1528139751578};\\\", \\\"{x:850,y:477,t:1528139751595};\\\", \\\"{x:923,y:477,t:1528139751612};\\\", \\\"{x:1003,y:477,t:1528139751629};\\\", \\\"{x:1081,y:485,t:1528139751646};\\\", \\\"{x:1167,y:496,t:1528139751662};\\\", \\\"{x:1245,y:509,t:1528139751680};\\\", \\\"{x:1289,y:513,t:1528139751695};\\\", \\\"{x:1330,y:521,t:1528139751712};\\\", \\\"{x:1337,y:521,t:1528139751729};\\\", \\\"{x:1341,y:522,t:1528139751745};\\\", \\\"{x:1342,y:522,t:1528139751764};\\\", \\\"{x:1343,y:523,t:1528139751779};\\\", \\\"{x:1344,y:523,t:1528139751841};\\\", \\\"{x:1345,y:523,t:1528139751849};\\\", \\\"{x:1348,y:526,t:1528139751864};\\\", \\\"{x:1369,y:543,t:1528139751879};\\\", \\\"{x:1401,y:572,t:1528139751897};\\\", \\\"{x:1412,y:582,t:1528139751913};\\\", \\\"{x:1418,y:588,t:1528139751929};\\\", \\\"{x:1420,y:590,t:1528139751947};\\\", \\\"{x:1423,y:596,t:1528139751963};\\\", \\\"{x:1426,y:602,t:1528139751980};\\\", \\\"{x:1428,y:607,t:1528139751997};\\\", \\\"{x:1430,y:615,t:1528139752014};\\\", \\\"{x:1430,y:624,t:1528139752031};\\\", \\\"{x:1430,y:638,t:1528139752048};\\\", \\\"{x:1430,y:657,t:1528139752063};\\\", \\\"{x:1430,y:682,t:1528139752081};\\\", \\\"{x:1430,y:700,t:1528139752094};\\\", \\\"{x:1430,y:713,t:1528139752111};\\\", \\\"{x:1430,y:726,t:1528139752128};\\\", \\\"{x:1430,y:733,t:1528139752144};\\\", \\\"{x:1430,y:737,t:1528139752162};\\\", \\\"{x:1430,y:739,t:1528139752177};\\\", \\\"{x:1430,y:740,t:1528139752194};\\\", \\\"{x:1418,y:728,t:1528139753150};\\\", \\\"{x:1375,y:680,t:1528139753166};\\\", \\\"{x:1335,y:651,t:1528139753181};\\\", \\\"{x:1319,y:640,t:1528139753199};\\\", \\\"{x:1315,y:636,t:1528139753215};\\\", \\\"{x:1310,y:630,t:1528139753240};\\\", \\\"{x:1298,y:613,t:1528139753266};\\\", \\\"{x:1297,y:609,t:1528139753282};\\\", \\\"{x:1296,y:605,t:1528139753293};\\\", \\\"{x:1296,y:601,t:1528139753308};\\\", \\\"{x:1294,y:598,t:1528139753326};\\\", \\\"{x:1294,y:596,t:1528139753343};\\\", \\\"{x:1294,y:595,t:1528139753359};\\\", \\\"{x:1298,y:592,t:1528139753376};\\\", \\\"{x:1308,y:587,t:1528139753393};\\\", \\\"{x:1323,y:579,t:1528139753409};\\\", \\\"{x:1333,y:566,t:1528139753426};\\\", \\\"{x:1338,y:552,t:1528139753442};\\\", \\\"{x:1338,y:547,t:1528139753459};\\\", \\\"{x:1338,y:546,t:1528139753477};\\\", \\\"{x:1338,y:544,t:1528139753492};\\\", \\\"{x:1338,y:540,t:1528139753509};\\\", \\\"{x:1338,y:539,t:1528139753526};\\\", \\\"{x:1338,y:538,t:1528139753542};\\\", \\\"{x:1338,y:534,t:1528139753629};\\\", \\\"{x:1338,y:528,t:1528139753642};\\\", \\\"{x:1338,y:519,t:1528139753659};\\\", \\\"{x:1335,y:508,t:1528139753676};\\\", \\\"{x:1333,y:502,t:1528139753692};\\\", \\\"{x:1333,y:500,t:1528139753709};\\\", \\\"{x:1333,y:499,t:1528139753772};\\\", \\\"{x:1331,y:499,t:1528139753868};\\\", \\\"{x:1328,y:499,t:1528139753877};\\\", \\\"{x:1322,y:500,t:1528139753892};\\\", \\\"{x:1316,y:501,t:1528139753910};\\\", \\\"{x:1313,y:501,t:1528139753957};\\\", \\\"{x:1311,y:501,t:1528139753964};\\\", \\\"{x:1308,y:501,t:1528139753980};\\\", \\\"{x:1301,y:501,t:1528139753995};\\\", \\\"{x:1298,y:499,t:1528139754012};\\\", \\\"{x:1294,y:497,t:1528139754029};\\\", \\\"{x:1293,y:497,t:1528139754045};\\\", \\\"{x:1292,y:497,t:1528139754062};\\\", \\\"{x:1292,y:496,t:1528139754286};\\\", \\\"{x:1293,y:496,t:1528139754301};\\\", \\\"{x:1295,y:496,t:1528139754312};\\\", \\\"{x:1300,y:495,t:1528139754330};\\\", \\\"{x:1308,y:494,t:1528139754345};\\\", \\\"{x:1316,y:494,t:1528139754364};\\\", \\\"{x:1318,y:493,t:1528139754379};\\\", \\\"{x:1321,y:491,t:1528139755454};\\\", \\\"{x:1324,y:491,t:1528139755463};\\\", \\\"{x:1325,y:489,t:1528139755480};\\\", \\\"{x:1326,y:488,t:1528139755501};\\\", \\\"{x:1327,y:488,t:1528139755556};\\\", \\\"{x:1328,y:488,t:1528139755669};\\\", \\\"{x:1328,y:489,t:1528139755685};\\\", \\\"{x:1327,y:490,t:1528139755697};\\\", \\\"{x:1323,y:494,t:1528139755713};\\\", \\\"{x:1318,y:498,t:1528139755734};\\\", \\\"{x:1314,y:502,t:1528139755746};\\\", \\\"{x:1311,y:504,t:1528139755780};\\\", \\\"{x:1310,y:505,t:1528139755797};\\\", \\\"{x:1312,y:505,t:1528139756142};\\\", \\\"{x:1315,y:505,t:1528139756149};\\\", \\\"{x:1317,y:503,t:1528139756165};\\\", \\\"{x:1318,y:502,t:1528139756180};\\\", \\\"{x:1319,y:502,t:1528139756197};\\\", \\\"{x:1319,y:501,t:1528139756972};\\\", \\\"{x:1319,y:500,t:1528139756998};\\\", \\\"{x:1314,y:490,t:1528139757030};\\\", \\\"{x:1313,y:487,t:1528139757046};\\\", \\\"{x:1310,y:482,t:1528139757064};\\\", \\\"{x:1310,y:481,t:1528139757081};\\\", \\\"{x:1309,y:480,t:1528139757097};\\\", \\\"{x:1309,y:489,t:1528139757366};\\\", \\\"{x:1309,y:505,t:1528139757381};\\\", \\\"{x:1309,y:519,t:1528139757399};\\\", \\\"{x:1309,y:527,t:1528139757415};\\\", \\\"{x:1309,y:537,t:1528139757431};\\\", \\\"{x:1311,y:544,t:1528139757448};\\\", \\\"{x:1311,y:546,t:1528139757464};\\\", \\\"{x:1312,y:551,t:1528139757481};\\\", \\\"{x:1312,y:556,t:1528139757498};\\\", \\\"{x:1312,y:562,t:1528139757514};\\\", \\\"{x:1313,y:567,t:1528139757531};\\\", \\\"{x:1313,y:570,t:1528139757548};\\\", \\\"{x:1313,y:573,t:1528139757564};\\\", \\\"{x:1315,y:577,t:1528139757581};\\\", \\\"{x:1315,y:578,t:1528139757598};\\\", \\\"{x:1316,y:581,t:1528139757615};\\\", \\\"{x:1316,y:582,t:1528139757636};\\\", \\\"{x:1316,y:584,t:1528139757648};\\\", \\\"{x:1317,y:589,t:1528139757665};\\\", \\\"{x:1319,y:598,t:1528139757681};\\\", \\\"{x:1319,y:603,t:1528139757698};\\\", \\\"{x:1319,y:605,t:1528139757715};\\\", \\\"{x:1319,y:607,t:1528139757731};\\\", \\\"{x:1320,y:610,t:1528139757748};\\\", \\\"{x:1321,y:623,t:1528139757764};\\\", \\\"{x:1324,y:639,t:1528139757781};\\\", \\\"{x:1324,y:652,t:1528139757798};\\\", \\\"{x:1324,y:657,t:1528139757815};\\\", \\\"{x:1324,y:658,t:1528139757831};\\\", \\\"{x:1324,y:657,t:1528139758046};\\\", \\\"{x:1324,y:656,t:1528139758054};\\\", \\\"{x:1323,y:654,t:1528139758066};\\\", \\\"{x:1321,y:649,t:1528139758082};\\\", \\\"{x:1319,y:646,t:1528139758098};\\\", \\\"{x:1319,y:644,t:1528139758116};\\\", \\\"{x:1319,y:643,t:1528139758134};\\\", \\\"{x:1319,y:642,t:1528139758189};\\\", \\\"{x:1319,y:641,t:1528139758199};\\\", \\\"{x:1317,y:639,t:1528139758215};\\\", \\\"{x:1317,y:637,t:1528139758233};\\\", \\\"{x:1317,y:634,t:1528139758252};\\\", \\\"{x:1316,y:633,t:1528139758265};\\\", \\\"{x:1316,y:631,t:1528139758282};\\\", \\\"{x:1315,y:630,t:1528139758298};\\\", \\\"{x:1314,y:627,t:1528139758315};\\\", \\\"{x:1313,y:626,t:1528139758349};\\\", \\\"{x:1313,y:625,t:1528139758365};\\\", \\\"{x:1313,y:624,t:1528139758389};\\\", \\\"{x:1312,y:624,t:1528139758997};\\\", \\\"{x:1312,y:625,t:1528139759025};\\\", \\\"{x:1311,y:627,t:1528139759049};\\\", \\\"{x:1311,y:629,t:1528139759066};\\\", \\\"{x:1311,y:630,t:1528139759082};\\\", \\\"{x:1311,y:632,t:1528139759493};\\\", \\\"{x:1311,y:638,t:1528139759503};\\\", \\\"{x:1311,y:642,t:1528139759516};\\\", \\\"{x:1311,y:651,t:1528139759532};\\\", \\\"{x:1312,y:659,t:1528139759549};\\\", \\\"{x:1312,y:665,t:1528139759566};\\\", \\\"{x:1315,y:678,t:1528139759583};\\\", \\\"{x:1315,y:693,t:1528139759599};\\\", \\\"{x:1317,y:715,t:1528139759617};\\\", \\\"{x:1317,y:742,t:1528139759633};\\\", \\\"{x:1318,y:765,t:1528139759650};\\\", \\\"{x:1321,y:785,t:1528139759666};\\\", \\\"{x:1323,y:799,t:1528139759683};\\\", \\\"{x:1326,y:808,t:1528139759700};\\\", \\\"{x:1328,y:818,t:1528139759716};\\\", \\\"{x:1331,y:838,t:1528139759733};\\\", \\\"{x:1333,y:847,t:1528139759750};\\\", \\\"{x:1333,y:852,t:1528139759767};\\\", \\\"{x:1333,y:858,t:1528139759784};\\\", \\\"{x:1333,y:865,t:1528139759801};\\\", \\\"{x:1333,y:870,t:1528139759816};\\\", \\\"{x:1333,y:879,t:1528139759834};\\\", \\\"{x:1334,y:886,t:1528139759851};\\\", \\\"{x:1334,y:894,t:1528139759866};\\\", \\\"{x:1334,y:899,t:1528139759884};\\\", \\\"{x:1334,y:902,t:1528139759901};\\\", \\\"{x:1335,y:907,t:1528139759917};\\\", \\\"{x:1335,y:919,t:1528139759934};\\\", \\\"{x:1335,y:937,t:1528139759951};\\\", \\\"{x:1337,y:968,t:1528139759967};\\\", \\\"{x:1339,y:981,t:1528139759984};\\\", \\\"{x:1337,y:984,t:1528139760001};\\\", \\\"{x:1337,y:986,t:1528139760017};\\\", \\\"{x:1337,y:985,t:1528139760094};\\\", \\\"{x:1336,y:978,t:1528139760101};\\\", \\\"{x:1336,y:972,t:1528139760117};\\\", \\\"{x:1337,y:923,t:1528139760134};\\\", \\\"{x:1337,y:909,t:1528139760151};\\\", \\\"{x:1337,y:885,t:1528139760167};\\\", \\\"{x:1337,y:859,t:1528139760183};\\\", \\\"{x:1337,y:838,t:1528139760201};\\\", \\\"{x:1337,y:821,t:1528139760217};\\\", \\\"{x:1341,y:800,t:1528139760234};\\\", \\\"{x:1344,y:783,t:1528139760250};\\\", \\\"{x:1348,y:770,t:1528139760268};\\\", \\\"{x:1348,y:754,t:1528139760283};\\\", \\\"{x:1348,y:737,t:1528139760300};\\\", \\\"{x:1345,y:708,t:1528139760316};\\\", \\\"{x:1338,y:682,t:1528139760333};\\\", \\\"{x:1333,y:662,t:1528139760350};\\\", \\\"{x:1328,y:648,t:1528139760367};\\\", \\\"{x:1322,y:634,t:1528139760383};\\\", \\\"{x:1317,y:626,t:1528139760401};\\\", \\\"{x:1314,y:619,t:1528139760418};\\\", \\\"{x:1311,y:616,t:1528139760433};\\\", \\\"{x:1308,y:612,t:1528139760451};\\\", \\\"{x:1306,y:610,t:1528139760467};\\\", \\\"{x:1305,y:609,t:1528139760484};\\\", \\\"{x:1304,y:607,t:1528139760500};\\\", \\\"{x:1303,y:605,t:1528139760549};\\\", \\\"{x:1302,y:605,t:1528139760557};\\\", \\\"{x:1302,y:604,t:1528139760567};\\\", \\\"{x:1301,y:604,t:1528139760583};\\\", \\\"{x:1299,y:604,t:1528139760601};\\\", \\\"{x:1290,y:604,t:1528139760617};\\\", \\\"{x:1269,y:610,t:1528139760633};\\\", \\\"{x:1239,y:618,t:1528139760650};\\\", \\\"{x:1194,y:632,t:1528139760668};\\\", \\\"{x:1135,y:642,t:1528139760683};\\\", \\\"{x:1060,y:651,t:1528139760700};\\\", \\\"{x:960,y:651,t:1528139760717};\\\", \\\"{x:906,y:652,t:1528139760735};\\\", \\\"{x:857,y:655,t:1528139760750};\\\", \\\"{x:825,y:655,t:1528139760767};\\\", \\\"{x:775,y:655,t:1528139760784};\\\", \\\"{x:710,y:652,t:1528139760800};\\\", \\\"{x:643,y:644,t:1528139760818};\\\", \\\"{x:617,y:641,t:1528139760834};\\\", \\\"{x:607,y:641,t:1528139760851};\\\", \\\"{x:600,y:641,t:1528139760867};\\\", \\\"{x:596,y:641,t:1528139760885};\\\", \\\"{x:596,y:640,t:1528139760980};\\\", \\\"{x:604,y:636,t:1528139760989};\\\", \\\"{x:612,y:634,t:1528139761001};\\\", \\\"{x:632,y:624,t:1528139761018};\\\", \\\"{x:652,y:616,t:1528139761034};\\\", \\\"{x:673,y:606,t:1528139761051};\\\", \\\"{x:691,y:596,t:1528139761068};\\\", \\\"{x:711,y:588,t:1528139761085};\\\", \\\"{x:721,y:584,t:1528139761101};\\\", \\\"{x:725,y:583,t:1528139761118};\\\", \\\"{x:727,y:582,t:1528139761134};\\\", \\\"{x:731,y:581,t:1528139761151};\\\", \\\"{x:738,y:576,t:1528139761167};\\\", \\\"{x:744,y:574,t:1528139761184};\\\", \\\"{x:749,y:570,t:1528139761201};\\\", \\\"{x:754,y:568,t:1528139761217};\\\", \\\"{x:758,y:566,t:1528139761234};\\\", \\\"{x:766,y:564,t:1528139761251};\\\", \\\"{x:773,y:564,t:1528139761268};\\\", \\\"{x:778,y:563,t:1528139761284};\\\", \\\"{x:780,y:563,t:1528139761301};\\\", \\\"{x:781,y:563,t:1528139761319};\\\", \\\"{x:784,y:563,t:1528139761334};\\\", \\\"{x:785,y:563,t:1528139761351};\\\", \\\"{x:787,y:563,t:1528139761369};\\\", \\\"{x:788,y:563,t:1528139761384};\\\", \\\"{x:791,y:563,t:1528139761402};\\\", \\\"{x:797,y:563,t:1528139761418};\\\", \\\"{x:804,y:563,t:1528139761434};\\\", \\\"{x:810,y:563,t:1528139761451};\\\", \\\"{x:812,y:563,t:1528139761468};\\\", \\\"{x:813,y:563,t:1528139761493};\\\", \\\"{x:814,y:563,t:1528139761502};\\\", \\\"{x:815,y:563,t:1528139761526};\\\", \\\"{x:816,y:563,t:1528139761534};\\\", \\\"{x:817,y:563,t:1528139761551};\\\", \\\"{x:818,y:564,t:1528139761569};\\\", \\\"{x:821,y:565,t:1528139761585};\\\", \\\"{x:824,y:566,t:1528139761603};\\\", \\\"{x:825,y:566,t:1528139761717};\\\", \\\"{x:826,y:566,t:1528139761786};\\\", \\\"{x:827,y:567,t:1528139761802};\\\", \\\"{x:827,y:567,t:1528139761899};\\\", \\\"{x:842,y:570,t:1528139762142};\\\", \\\"{x:864,y:570,t:1528139762152};\\\", \\\"{x:928,y:577,t:1528139762170};\\\", \\\"{x:992,y:577,t:1528139762186};\\\", \\\"{x:1059,y:577,t:1528139762201};\\\", \\\"{x:1134,y:577,t:1528139762218};\\\", \\\"{x:1195,y:578,t:1528139762235};\\\", \\\"{x:1246,y:578,t:1528139762252};\\\", \\\"{x:1280,y:578,t:1528139762269};\\\", \\\"{x:1288,y:576,t:1528139762285};\\\", \\\"{x:1290,y:576,t:1528139762301};\\\", \\\"{x:1291,y:575,t:1528139762318};\\\", \\\"{x:1293,y:575,t:1528139762341};\\\", \\\"{x:1295,y:575,t:1528139762351};\\\", \\\"{x:1300,y:573,t:1528139762369};\\\", \\\"{x:1305,y:572,t:1528139762386};\\\", \\\"{x:1307,y:570,t:1528139762402};\\\", \\\"{x:1308,y:569,t:1528139762493};\\\", \\\"{x:1308,y:566,t:1528139762508};\\\", \\\"{x:1309,y:556,t:1528139762518};\\\", \\\"{x:1309,y:549,t:1528139762535};\\\", \\\"{x:1312,y:540,t:1528139762552};\\\", \\\"{x:1313,y:526,t:1528139762568};\\\", \\\"{x:1313,y:515,t:1528139762585};\\\", \\\"{x:1313,y:505,t:1528139762602};\\\", \\\"{x:1314,y:502,t:1528139762619};\\\", \\\"{x:1315,y:501,t:1528139762635};\\\", \\\"{x:1316,y:500,t:1528139762652};\\\", \\\"{x:1316,y:499,t:1528139762693};\\\", \\\"{x:1317,y:499,t:1528139762702};\\\", \\\"{x:1317,y:496,t:1528139762719};\\\", \\\"{x:1317,y:495,t:1528139762735};\\\", \\\"{x:1317,y:494,t:1528139762752};\\\", \\\"{x:1317,y:493,t:1528139762773};\\\", \\\"{x:1317,y:492,t:1528139762785};\\\", \\\"{x:1318,y:495,t:1528139763198};\\\", \\\"{x:1318,y:508,t:1528139763220};\\\", \\\"{x:1318,y:534,t:1528139763236};\\\", \\\"{x:1324,y:556,t:1528139763252};\\\", \\\"{x:1326,y:575,t:1528139763270};\\\", \\\"{x:1327,y:590,t:1528139763286};\\\", \\\"{x:1331,y:602,t:1528139763302};\\\", \\\"{x:1333,y:609,t:1528139763319};\\\", \\\"{x:1334,y:611,t:1528139763336};\\\", \\\"{x:1334,y:612,t:1528139763422};\\\", \\\"{x:1334,y:614,t:1528139763437};\\\", \\\"{x:1334,y:615,t:1528139763454};\\\", \\\"{x:1334,y:616,t:1528139763469};\\\", \\\"{x:1334,y:617,t:1528139763486};\\\", \\\"{x:1332,y:618,t:1528139763524};\\\", \\\"{x:1331,y:618,t:1528139763536};\\\", \\\"{x:1328,y:620,t:1528139763553};\\\", \\\"{x:1327,y:620,t:1528139763569};\\\", \\\"{x:1326,y:620,t:1528139763586};\\\", \\\"{x:1325,y:620,t:1528139763602};\\\", \\\"{x:1324,y:621,t:1528139763619};\\\", \\\"{x:1323,y:622,t:1528139763645};\\\", \\\"{x:1322,y:622,t:1528139763653};\\\", \\\"{x:1321,y:623,t:1528139763669};\\\", \\\"{x:1320,y:624,t:1528139763686};\\\", \\\"{x:1318,y:625,t:1528139763707};\\\", \\\"{x:1317,y:630,t:1528139763719};\\\", \\\"{x:1316,y:633,t:1528139763737};\\\", \\\"{x:1316,y:634,t:1528139763754};\\\", \\\"{x:1316,y:635,t:1528139763769};\\\", \\\"{x:1315,y:635,t:1528139763934};\\\", \\\"{x:1314,y:635,t:1528139763941};\\\", \\\"{x:1312,y:637,t:1528139764117};\\\", \\\"{x:1310,y:641,t:1528139764125};\\\", \\\"{x:1307,y:647,t:1528139764137};\\\", \\\"{x:1305,y:656,t:1528139764153};\\\", \\\"{x:1302,y:667,t:1528139764171};\\\", \\\"{x:1300,y:674,t:1528139764186};\\\", \\\"{x:1298,y:683,t:1528139764204};\\\", \\\"{x:1295,y:693,t:1528139764221};\\\", \\\"{x:1295,y:697,t:1528139764237};\\\", \\\"{x:1293,y:711,t:1528139764253};\\\", \\\"{x:1293,y:719,t:1528139764271};\\\", \\\"{x:1293,y:728,t:1528139764287};\\\", \\\"{x:1293,y:739,t:1528139764304};\\\", \\\"{x:1293,y:754,t:1528139764321};\\\", \\\"{x:1293,y:768,t:1528139764337};\\\", \\\"{x:1293,y:787,t:1528139764354};\\\", \\\"{x:1293,y:806,t:1528139764370};\\\", \\\"{x:1296,y:825,t:1528139764386};\\\", \\\"{x:1298,y:839,t:1528139764403};\\\", \\\"{x:1299,y:844,t:1528139764421};\\\", \\\"{x:1299,y:845,t:1528139764437};\\\", \\\"{x:1299,y:846,t:1528139764469};\\\", \\\"{x:1299,y:847,t:1528139764534};\\\", \\\"{x:1299,y:850,t:1528139764550};\\\", \\\"{x:1302,y:853,t:1528139764557};\\\", \\\"{x:1303,y:856,t:1528139764571};\\\", \\\"{x:1306,y:864,t:1528139764588};\\\", \\\"{x:1307,y:870,t:1528139764604};\\\", \\\"{x:1310,y:879,t:1528139764622};\\\", \\\"{x:1311,y:882,t:1528139764637};\\\", \\\"{x:1312,y:885,t:1528139764654};\\\", \\\"{x:1312,y:887,t:1528139764671};\\\", \\\"{x:1314,y:892,t:1528139764688};\\\", \\\"{x:1315,y:897,t:1528139764704};\\\", \\\"{x:1317,y:902,t:1528139764720};\\\", \\\"{x:1318,y:907,t:1528139764738};\\\", \\\"{x:1319,y:912,t:1528139764754};\\\", \\\"{x:1319,y:916,t:1528139764771};\\\", \\\"{x:1321,y:924,t:1528139764788};\\\", \\\"{x:1322,y:935,t:1528139764804};\\\", \\\"{x:1322,y:949,t:1528139764821};\\\", \\\"{x:1322,y:961,t:1528139764838};\\\", \\\"{x:1322,y:965,t:1528139764854};\\\", \\\"{x:1322,y:968,t:1528139764871};\\\", \\\"{x:1322,y:969,t:1528139764888};\\\", \\\"{x:1322,y:970,t:1528139764904};\\\", \\\"{x:1322,y:971,t:1528139764925};\\\", \\\"{x:1322,y:974,t:1528139764998};\\\", \\\"{x:1322,y:975,t:1528139765005};\\\", \\\"{x:1322,y:977,t:1528139765021};\\\", \\\"{x:1322,y:982,t:1528139765037};\\\", \\\"{x:1322,y:983,t:1528139765061};\\\", \\\"{x:1322,y:982,t:1528139765245};\\\", \\\"{x:1321,y:981,t:1528139765255};\\\", \\\"{x:1315,y:971,t:1528139765271};\\\", \\\"{x:1302,y:957,t:1528139765288};\\\", \\\"{x:1280,y:945,t:1528139765305};\\\", \\\"{x:1248,y:932,t:1528139765321};\\\", \\\"{x:1212,y:921,t:1528139765338};\\\", \\\"{x:1180,y:911,t:1528139765355};\\\", \\\"{x:1161,y:910,t:1528139765371};\\\", \\\"{x:1148,y:905,t:1528139765388};\\\", \\\"{x:1116,y:900,t:1528139765406};\\\", \\\"{x:1094,y:896,t:1528139765421};\\\", \\\"{x:1063,y:889,t:1528139765438};\\\", \\\"{x:1029,y:881,t:1528139765455};\\\", \\\"{x:989,y:874,t:1528139765471};\\\", \\\"{x:940,y:865,t:1528139765488};\\\", \\\"{x:903,y:860,t:1528139765505};\\\", \\\"{x:876,y:855,t:1528139765522};\\\", \\\"{x:852,y:851,t:1528139765538};\\\", \\\"{x:830,y:847,t:1528139765555};\\\", \\\"{x:810,y:838,t:1528139765571};\\\", \\\"{x:786,y:826,t:1528139765588};\\\", \\\"{x:726,y:791,t:1528139765605};\\\", \\\"{x:692,y:774,t:1528139765621};\\\", \\\"{x:660,y:762,t:1528139765637};\\\", \\\"{x:630,y:750,t:1528139765655};\\\", \\\"{x:600,y:743,t:1528139765672};\\\", \\\"{x:578,y:737,t:1528139765688};\\\", \\\"{x:561,y:734,t:1528139765705};\\\", \\\"{x:546,y:733,t:1528139765722};\\\", \\\"{x:534,y:732,t:1528139765737};\\\", \\\"{x:527,y:732,t:1528139765754};\\\", \\\"{x:518,y:733,t:1528139765772};\\\", \\\"{x:512,y:734,t:1528139765788};\\\", \\\"{x:505,y:734,t:1528139765805};\\\", \\\"{x:499,y:734,t:1528139765821};\\\", \\\"{x:498,y:734,t:1528139765886};\\\", \\\"{x:497,y:734,t:1528139765893};\\\", \\\"{x:496,y:735,t:1528139765905};\\\", \\\"{x:496,y:741,t:1528139765921};\\\", \\\"{x:495,y:752,t:1528139765939};\\\", \\\"{x:495,y:767,t:1528139765954};\\\", \\\"{x:495,y:779,t:1528139765971};\\\", \\\"{x:497,y:790,t:1528139765989};\\\", \\\"{x:498,y:792,t:1528139766004};\\\", \\\"{x:499,y:794,t:1528139766021};\\\", \\\"{x:499,y:795,t:1528139766038};\\\", \\\"{x:500,y:795,t:1528139766055};\\\", \\\"{x:501,y:795,t:1528139766182};\\\", \\\"{x:502,y:795,t:1528139766188};\\\", \\\"{x:503,y:795,t:1528139766222};\\\", \\\"{x:506,y:792,t:1528139766239};\\\", \\\"{x:509,y:783,t:1528139766257};\\\", \\\"{x:516,y:773,t:1528139766271};\\\", \\\"{x:519,y:769,t:1528139766289};\\\", \\\"{x:520,y:768,t:1528139766305};\\\", \\\"{x:521,y:767,t:1528139766323};\\\", \\\"{x:523,y:765,t:1528139767102};\\\", \\\"{x:530,y:760,t:1528139767108};\\\", \\\"{x:537,y:757,t:1528139767122};\\\", \\\"{x:547,y:752,t:1528139767139};\\\", \\\"{x:561,y:745,t:1528139767155};\\\", \\\"{x:583,y:733,t:1528139767172};\\\", \\\"{x:599,y:721,t:1528139767189};\\\", \\\"{x:617,y:707,t:1528139767205};\\\", \\\"{x:632,y:693,t:1528139767222};\\\", \\\"{x:643,y:680,t:1528139767240};\\\", \\\"{x:654,y:666,t:1528139767256};\\\", \\\"{x:662,y:658,t:1528139767273};\\\", \\\"{x:671,y:652,t:1528139767289};\\\", \\\"{x:684,y:645,t:1528139767305};\\\", \\\"{x:700,y:638,t:1528139767323};\\\", \\\"{x:710,y:631,t:1528139767340};\\\", \\\"{x:717,y:628,t:1528139767356};\\\", \\\"{x:717,y:627,t:1528139767389};\\\" ] }, { \\\"rt\\\": 12933, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 448109, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -G -G -E -E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:757,y:583,t:1528139767970};\\\", \\\"{x:763,y:583,t:1528139769397};\\\", \\\"{x:772,y:583,t:1528139769417};\\\", \\\"{x:773,y:583,t:1528139769424};\\\", \\\"{x:774,y:583,t:1528139769452};\\\", \\\"{x:775,y:583,t:1528139769476};\\\", \\\"{x:776,y:583,t:1528139769564};\\\", \\\"{x:777,y:583,t:1528139769604};\\\", \\\"{x:780,y:579,t:1528139769949};\\\", \\\"{x:786,y:574,t:1528139769957};\\\", \\\"{x:800,y:567,t:1528139769975};\\\", \\\"{x:812,y:560,t:1528139769993};\\\", \\\"{x:825,y:557,t:1528139770008};\\\", \\\"{x:846,y:551,t:1528139770025};\\\", \\\"{x:866,y:548,t:1528139770041};\\\", \\\"{x:880,y:547,t:1528139770058};\\\", \\\"{x:888,y:543,t:1528139770074};\\\", \\\"{x:894,y:542,t:1528139770092};\\\", \\\"{x:909,y:537,t:1528139770108};\\\", \\\"{x:920,y:533,t:1528139770124};\\\", \\\"{x:934,y:529,t:1528139770141};\\\", \\\"{x:956,y:525,t:1528139770159};\\\", \\\"{x:1000,y:522,t:1528139770175};\\\", \\\"{x:1053,y:522,t:1528139770192};\\\", \\\"{x:1117,y:522,t:1528139770209};\\\", \\\"{x:1175,y:527,t:1528139770224};\\\", \\\"{x:1242,y:536,t:1528139770242};\\\", \\\"{x:1302,y:541,t:1528139770258};\\\", \\\"{x:1342,y:542,t:1528139770275};\\\", \\\"{x:1364,y:542,t:1528139770292};\\\", \\\"{x:1375,y:542,t:1528139770308};\\\", \\\"{x:1376,y:542,t:1528139770325};\\\", \\\"{x:1376,y:544,t:1528139770446};\\\", \\\"{x:1372,y:546,t:1528139770459};\\\", \\\"{x:1367,y:549,t:1528139770475};\\\", \\\"{x:1362,y:552,t:1528139770492};\\\", \\\"{x:1351,y:554,t:1528139770509};\\\", \\\"{x:1339,y:554,t:1528139770525};\\\", \\\"{x:1331,y:554,t:1528139770542};\\\", \\\"{x:1326,y:556,t:1528139770559};\\\", \\\"{x:1321,y:558,t:1528139770576};\\\", \\\"{x:1313,y:558,t:1528139770592};\\\", \\\"{x:1306,y:558,t:1528139770609};\\\", \\\"{x:1303,y:558,t:1528139770626};\\\", \\\"{x:1302,y:559,t:1528139770642};\\\", \\\"{x:1300,y:559,t:1528139770782};\\\", \\\"{x:1299,y:559,t:1528139770793};\\\", \\\"{x:1296,y:559,t:1528139770810};\\\", \\\"{x:1292,y:559,t:1528139770826};\\\", \\\"{x:1290,y:559,t:1528139770843};\\\", \\\"{x:1288,y:559,t:1528139770860};\\\", \\\"{x:1282,y:560,t:1528139770878};\\\", \\\"{x:1277,y:562,t:1528139770892};\\\", \\\"{x:1274,y:563,t:1528139770908};\\\", \\\"{x:1271,y:564,t:1528139770926};\\\", \\\"{x:1268,y:564,t:1528139770942};\\\", \\\"{x:1265,y:565,t:1528139770959};\\\", \\\"{x:1264,y:565,t:1528139770975};\\\", \\\"{x:1265,y:565,t:1528139771261};\\\", \\\"{x:1266,y:565,t:1528139771276};\\\", \\\"{x:1268,y:565,t:1528139771293};\\\", \\\"{x:1269,y:565,t:1528139771349};\\\", \\\"{x:1270,y:566,t:1528139771360};\\\", \\\"{x:1271,y:568,t:1528139771376};\\\", \\\"{x:1272,y:568,t:1528139771581};\\\", \\\"{x:1273,y:568,t:1528139771605};\\\", \\\"{x:1274,y:568,t:1528139771614};\\\", \\\"{x:1274,y:567,t:1528139771629};\\\", \\\"{x:1275,y:567,t:1528139771643};\\\", \\\"{x:1276,y:567,t:1528139771661};\\\", \\\"{x:1277,y:566,t:1528139771678};\\\", \\\"{x:1278,y:566,t:1528139771710};\\\", \\\"{x:1279,y:564,t:1528139771750};\\\", \\\"{x:1280,y:564,t:1528139771821};\\\", \\\"{x:1281,y:564,t:1528139771837};\\\", \\\"{x:1283,y:563,t:1528139771853};\\\", \\\"{x:1284,y:562,t:1528139771885};\\\", \\\"{x:1285,y:561,t:1528139771909};\\\", \\\"{x:1288,y:560,t:1528139771928};\\\", \\\"{x:1292,y:558,t:1528139771945};\\\", \\\"{x:1299,y:554,t:1528139771960};\\\", \\\"{x:1303,y:554,t:1528139771977};\\\", \\\"{x:1305,y:553,t:1528139771994};\\\", \\\"{x:1308,y:552,t:1528139772010};\\\", \\\"{x:1314,y:551,t:1528139772027};\\\", \\\"{x:1327,y:551,t:1528139772045};\\\", \\\"{x:1339,y:553,t:1528139772060};\\\", \\\"{x:1353,y:556,t:1528139772077};\\\", \\\"{x:1358,y:556,t:1528139772093};\\\", \\\"{x:1362,y:556,t:1528139772110};\\\", \\\"{x:1365,y:556,t:1528139772127};\\\", \\\"{x:1369,y:556,t:1528139772145};\\\", \\\"{x:1374,y:556,t:1528139772160};\\\", \\\"{x:1379,y:556,t:1528139772177};\\\", \\\"{x:1381,y:556,t:1528139772194};\\\", \\\"{x:1383,y:556,t:1528139772212};\\\", \\\"{x:1387,y:557,t:1528139772227};\\\", \\\"{x:1389,y:558,t:1528139772244};\\\", \\\"{x:1393,y:560,t:1528139772261};\\\", \\\"{x:1395,y:561,t:1528139772294};\\\", \\\"{x:1398,y:562,t:1528139772311};\\\", \\\"{x:1400,y:564,t:1528139772327};\\\", \\\"{x:1402,y:564,t:1528139772345};\\\", \\\"{x:1403,y:564,t:1528139772361};\\\", \\\"{x:1404,y:564,t:1528139772398};\\\", \\\"{x:1405,y:564,t:1528139772411};\\\", \\\"{x:1406,y:564,t:1528139772427};\\\", \\\"{x:1409,y:564,t:1528139772444};\\\", \\\"{x:1413,y:564,t:1528139772461};\\\", \\\"{x:1415,y:564,t:1528139772477};\\\", \\\"{x:1418,y:564,t:1528139772494};\\\", \\\"{x:1421,y:564,t:1528139772511};\\\", \\\"{x:1422,y:564,t:1528139772528};\\\", \\\"{x:1424,y:564,t:1528139772556};\\\", \\\"{x:1425,y:564,t:1528139772613};\\\", \\\"{x:1422,y:564,t:1528139772829};\\\", \\\"{x:1418,y:564,t:1528139772844};\\\", \\\"{x:1395,y:564,t:1528139772862};\\\", \\\"{x:1368,y:564,t:1528139772879};\\\", \\\"{x:1334,y:564,t:1528139772894};\\\", \\\"{x:1281,y:564,t:1528139772911};\\\", \\\"{x:1233,y:567,t:1528139772928};\\\", \\\"{x:1188,y:579,t:1528139772944};\\\", \\\"{x:1144,y:591,t:1528139772961};\\\", \\\"{x:1102,y:603,t:1528139772978};\\\", \\\"{x:1070,y:609,t:1528139772995};\\\", \\\"{x:1045,y:612,t:1528139773011};\\\", \\\"{x:1032,y:615,t:1528139773029};\\\", \\\"{x:1030,y:615,t:1528139773045};\\\", \\\"{x:1029,y:615,t:1528139773069};\\\", \\\"{x:1028,y:615,t:1528139773109};\\\", \\\"{x:1027,y:615,t:1528139773117};\\\", \\\"{x:1025,y:615,t:1528139773129};\\\", \\\"{x:1016,y:615,t:1528139773145};\\\", \\\"{x:1013,y:616,t:1528139773161};\\\", \\\"{x:1008,y:617,t:1528139773178};\\\", \\\"{x:1006,y:617,t:1528139773196};\\\", \\\"{x:1005,y:618,t:1528139773212};\\\", \\\"{x:1004,y:618,t:1528139773228};\\\", \\\"{x:1002,y:618,t:1528139773253};\\\", \\\"{x:999,y:618,t:1528139773262};\\\", \\\"{x:988,y:621,t:1528139773277};\\\", \\\"{x:967,y:625,t:1528139773294};\\\", \\\"{x:949,y:629,t:1528139773312};\\\", \\\"{x:933,y:634,t:1528139773328};\\\", \\\"{x:925,y:637,t:1528139773343};\\\", \\\"{x:917,y:640,t:1528139773360};\\\", \\\"{x:915,y:641,t:1528139773377};\\\", \\\"{x:914,y:643,t:1528139773393};\\\", \\\"{x:918,y:643,t:1528139773612};\\\", \\\"{x:927,y:639,t:1528139773627};\\\", \\\"{x:965,y:623,t:1528139773644};\\\", \\\"{x:999,y:608,t:1528139773661};\\\", \\\"{x:1038,y:591,t:1528139773678};\\\", \\\"{x:1073,y:576,t:1528139773694};\\\", \\\"{x:1104,y:569,t:1528139773710};\\\", \\\"{x:1134,y:564,t:1528139773728};\\\", \\\"{x:1156,y:561,t:1528139773744};\\\", \\\"{x:1164,y:558,t:1528139773761};\\\", \\\"{x:1165,y:558,t:1528139773777};\\\", \\\"{x:1167,y:557,t:1528139773794};\\\", \\\"{x:1170,y:556,t:1528139773810};\\\", \\\"{x:1172,y:555,t:1528139773828};\\\", \\\"{x:1184,y:554,t:1528139773844};\\\", \\\"{x:1192,y:554,t:1528139773861};\\\", \\\"{x:1207,y:554,t:1528139773877};\\\", \\\"{x:1228,y:561,t:1528139773895};\\\", \\\"{x:1244,y:563,t:1528139773910};\\\", \\\"{x:1260,y:566,t:1528139773927};\\\", \\\"{x:1277,y:569,t:1528139773944};\\\", \\\"{x:1299,y:574,t:1528139773961};\\\", \\\"{x:1312,y:578,t:1528139773978};\\\", \\\"{x:1321,y:579,t:1528139773995};\\\", \\\"{x:1329,y:580,t:1528139774011};\\\", \\\"{x:1330,y:580,t:1528139774027};\\\", \\\"{x:1331,y:580,t:1528139774045};\\\", \\\"{x:1331,y:579,t:1528139774165};\\\", \\\"{x:1329,y:572,t:1528139774179};\\\", \\\"{x:1312,y:560,t:1528139774195};\\\", \\\"{x:1306,y:557,t:1528139774212};\\\", \\\"{x:1305,y:556,t:1528139774228};\\\", \\\"{x:1304,y:555,t:1528139774253};\\\", \\\"{x:1303,y:555,t:1528139774445};\\\", \\\"{x:1297,y:554,t:1528139774462};\\\", \\\"{x:1289,y:554,t:1528139774478};\\\", \\\"{x:1280,y:557,t:1528139774495};\\\", \\\"{x:1273,y:559,t:1528139774512};\\\", \\\"{x:1269,y:560,t:1528139774529};\\\", \\\"{x:1267,y:561,t:1528139774545};\\\", \\\"{x:1265,y:562,t:1528139774605};\\\", \\\"{x:1265,y:563,t:1528139774782};\\\", \\\"{x:1267,y:565,t:1528139774795};\\\", \\\"{x:1268,y:565,t:1528139774837};\\\", \\\"{x:1270,y:566,t:1528139774877};\\\", \\\"{x:1272,y:566,t:1528139774885};\\\", \\\"{x:1273,y:566,t:1528139774896};\\\", \\\"{x:1275,y:567,t:1528139774913};\\\", \\\"{x:1276,y:567,t:1528139775133};\\\", \\\"{x:1277,y:567,t:1528139775146};\\\", \\\"{x:1279,y:567,t:1528139775179};\\\", \\\"{x:1280,y:567,t:1528139775230};\\\", \\\"{x:1280,y:566,t:1528139775253};\\\", \\\"{x:1282,y:565,t:1528139775268};\\\", \\\"{x:1283,y:565,t:1528139775280};\\\", \\\"{x:1284,y:564,t:1528139775296};\\\", \\\"{x:1285,y:564,t:1528139775630};\\\", \\\"{x:1290,y:562,t:1528139775647};\\\", \\\"{x:1299,y:562,t:1528139775663};\\\", \\\"{x:1309,y:561,t:1528139775680};\\\", \\\"{x:1321,y:561,t:1528139775696};\\\", \\\"{x:1326,y:561,t:1528139775714};\\\", \\\"{x:1330,y:561,t:1528139775730};\\\", \\\"{x:1333,y:561,t:1528139775746};\\\", \\\"{x:1338,y:561,t:1528139775763};\\\", \\\"{x:1345,y:563,t:1528139775779};\\\", \\\"{x:1348,y:563,t:1528139775796};\\\", \\\"{x:1352,y:563,t:1528139775813};\\\", \\\"{x:1354,y:563,t:1528139775830};\\\", \\\"{x:1357,y:563,t:1528139775846};\\\", \\\"{x:1359,y:563,t:1528139775863};\\\", \\\"{x:1360,y:563,t:1528139775881};\\\", \\\"{x:1362,y:563,t:1528139775896};\\\", \\\"{x:1365,y:564,t:1528139775913};\\\", \\\"{x:1368,y:564,t:1528139775930};\\\", \\\"{x:1372,y:564,t:1528139775946};\\\", \\\"{x:1377,y:564,t:1528139775964};\\\", \\\"{x:1384,y:564,t:1528139775981};\\\", \\\"{x:1391,y:564,t:1528139775997};\\\", \\\"{x:1402,y:564,t:1528139776013};\\\", \\\"{x:1409,y:564,t:1528139776031};\\\", \\\"{x:1411,y:564,t:1528139776046};\\\", \\\"{x:1412,y:564,t:1528139776063};\\\", \\\"{x:1413,y:564,t:1528139776080};\\\", \\\"{x:1414,y:564,t:1528139776097};\\\", \\\"{x:1415,y:564,t:1528139776133};\\\", \\\"{x:1416,y:564,t:1528139776189};\\\", \\\"{x:1413,y:564,t:1528139776526};\\\", \\\"{x:1407,y:563,t:1528139776534};\\\", \\\"{x:1400,y:563,t:1528139776548};\\\", \\\"{x:1388,y:568,t:1528139776564};\\\", \\\"{x:1372,y:574,t:1528139776581};\\\", \\\"{x:1348,y:580,t:1528139776597};\\\", \\\"{x:1332,y:583,t:1528139776614};\\\", \\\"{x:1314,y:583,t:1528139776631};\\\", \\\"{x:1291,y:583,t:1528139776647};\\\", \\\"{x:1244,y:591,t:1528139776664};\\\", \\\"{x:1177,y:599,t:1528139776680};\\\", \\\"{x:1113,y:617,t:1528139776698};\\\", \\\"{x:1030,y:630,t:1528139776715};\\\", \\\"{x:927,y:645,t:1528139776730};\\\", \\\"{x:821,y:659,t:1528139776747};\\\", \\\"{x:719,y:675,t:1528139776764};\\\", \\\"{x:629,y:692,t:1528139776780};\\\", \\\"{x:507,y:715,t:1528139776798};\\\", \\\"{x:448,y:723,t:1528139776815};\\\", \\\"{x:354,y:723,t:1528139776830};\\\", \\\"{x:322,y:723,t:1528139776847};\\\", \\\"{x:308,y:723,t:1528139776862};\\\", \\\"{x:291,y:716,t:1528139776880};\\\", \\\"{x:284,y:714,t:1528139776896};\\\", \\\"{x:283,y:713,t:1528139776913};\\\", \\\"{x:282,y:712,t:1528139776929};\\\", \\\"{x:282,y:709,t:1528139777021};\\\", \\\"{x:286,y:699,t:1528139777029};\\\", \\\"{x:297,y:674,t:1528139777047};\\\", \\\"{x:308,y:651,t:1528139777063};\\\", \\\"{x:316,y:634,t:1528139777080};\\\", \\\"{x:325,y:617,t:1528139777098};\\\", \\\"{x:336,y:599,t:1528139777115};\\\", \\\"{x:345,y:586,t:1528139777131};\\\", \\\"{x:355,y:574,t:1528139777147};\\\", \\\"{x:374,y:559,t:1528139777165};\\\", \\\"{x:393,y:547,t:1528139777180};\\\", \\\"{x:419,y:535,t:1528139777197};\\\", \\\"{x:435,y:530,t:1528139777214};\\\", \\\"{x:453,y:526,t:1528139777230};\\\", \\\"{x:472,y:525,t:1528139777247};\\\", \\\"{x:490,y:522,t:1528139777265};\\\", \\\"{x:509,y:520,t:1528139777281};\\\", \\\"{x:536,y:516,t:1528139777298};\\\", \\\"{x:554,y:514,t:1528139777313};\\\", \\\"{x:568,y:509,t:1528139777331};\\\", \\\"{x:573,y:507,t:1528139777347};\\\", \\\"{x:574,y:506,t:1528139777364};\\\", \\\"{x:576,y:506,t:1528139777380};\\\", \\\"{x:577,y:506,t:1528139777436};\\\", \\\"{x:579,y:506,t:1528139777452};\\\", \\\"{x:582,y:506,t:1528139777464};\\\", \\\"{x:588,y:506,t:1528139777481};\\\", \\\"{x:593,y:505,t:1528139777498};\\\", \\\"{x:598,y:503,t:1528139777514};\\\", \\\"{x:605,y:502,t:1528139777530};\\\", \\\"{x:610,y:502,t:1528139777548};\\\", \\\"{x:613,y:501,t:1528139777563};\\\", \\\"{x:615,y:501,t:1528139777580};\\\", \\\"{x:616,y:501,t:1528139777597};\\\", \\\"{x:617,y:500,t:1528139777614};\\\", \\\"{x:618,y:500,t:1528139777660};\\\", \\\"{x:624,y:500,t:1528139777997};\\\", \\\"{x:637,y:500,t:1528139778004};\\\", \\\"{x:660,y:500,t:1528139778014};\\\", \\\"{x:728,y:513,t:1528139778031};\\\", \\\"{x:791,y:526,t:1528139778048};\\\", \\\"{x:833,y:532,t:1528139778065};\\\", \\\"{x:861,y:539,t:1528139778080};\\\", \\\"{x:878,y:544,t:1528139778098};\\\", \\\"{x:885,y:546,t:1528139778115};\\\", \\\"{x:885,y:547,t:1528139778130};\\\", \\\"{x:883,y:544,t:1528139778269};\\\", \\\"{x:873,y:540,t:1528139778281};\\\", \\\"{x:860,y:534,t:1528139778299};\\\", \\\"{x:856,y:534,t:1528139778315};\\\", \\\"{x:854,y:534,t:1528139778331};\\\", \\\"{x:852,y:535,t:1528139778348};\\\", \\\"{x:851,y:536,t:1528139778365};\\\", \\\"{x:850,y:536,t:1528139778404};\\\", \\\"{x:848,y:538,t:1528139778517};\\\", \\\"{x:847,y:538,t:1528139778532};\\\", \\\"{x:843,y:541,t:1528139778548};\\\", \\\"{x:842,y:541,t:1528139778565};\\\", \\\"{x:840,y:542,t:1528139778582};\\\", \\\"{x:839,y:542,t:1528139778612};\\\", \\\"{x:838,y:543,t:1528139778861};\\\", \\\"{x:838,y:543,t:1528139778880};\\\", \\\"{x:837,y:543,t:1528139778924};\\\", \\\"{x:834,y:543,t:1528139778932};\\\", \\\"{x:822,y:545,t:1528139778948};\\\", \\\"{x:801,y:551,t:1528139778965};\\\", \\\"{x:778,y:557,t:1528139778982};\\\", \\\"{x:744,y:568,t:1528139778999};\\\", \\\"{x:718,y:575,t:1528139779016};\\\", \\\"{x:694,y:581,t:1528139779031};\\\", \\\"{x:672,y:587,t:1528139779049};\\\", \\\"{x:647,y:595,t:1528139779066};\\\", \\\"{x:625,y:600,t:1528139779081};\\\", \\\"{x:605,y:606,t:1528139779100};\\\", \\\"{x:587,y:611,t:1528139779115};\\\", \\\"{x:569,y:619,t:1528139779131};\\\", \\\"{x:539,y:636,t:1528139779148};\\\", \\\"{x:519,y:647,t:1528139779165};\\\", \\\"{x:500,y:658,t:1528139779182};\\\", \\\"{x:486,y:668,t:1528139779199};\\\", \\\"{x:476,y:675,t:1528139779215};\\\", \\\"{x:472,y:681,t:1528139779231};\\\", \\\"{x:468,y:683,t:1528139779249};\\\", \\\"{x:467,y:685,t:1528139779266};\\\", \\\"{x:466,y:685,t:1528139779282};\\\", \\\"{x:466,y:686,t:1528139779299};\\\", \\\"{x:465,y:688,t:1528139779317};\\\", \\\"{x:461,y:697,t:1528139779333};\\\", \\\"{x:460,y:703,t:1528139779349};\\\", \\\"{x:460,y:706,t:1528139779366};\\\", \\\"{x:460,y:712,t:1528139779384};\\\", \\\"{x:460,y:717,t:1528139779399};\\\", \\\"{x:462,y:723,t:1528139779418};\\\", \\\"{x:467,y:733,t:1528139779434};\\\", \\\"{x:472,y:741,t:1528139779449};\\\", \\\"{x:477,y:746,t:1528139779466};\\\", \\\"{x:479,y:747,t:1528139779483};\\\", \\\"{x:480,y:748,t:1528139779499};\\\", \\\"{x:481,y:748,t:1528139779973};\\\", \\\"{x:482,y:748,t:1528139780013};\\\", \\\"{x:483,y:747,t:1528139780021};\\\", \\\"{x:484,y:746,t:1528139780033};\\\", \\\"{x:485,y:745,t:1528139780060};\\\", \\\"{x:485,y:738,t:1528139781524};\\\", \\\"{x:488,y:736,t:1528139781534};\\\", \\\"{x:489,y:736,t:1528139781550};\\\", \\\"{x:490,y:736,t:1528139782116};\\\" ] }, { \\\"rt\\\": 36591, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 486053, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -H -B -M -X -X -O -O -X -O -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:733,t:1528139782973};\\\", \\\"{x:504,y:727,t:1528139782988};\\\", \\\"{x:515,y:718,t:1528139783005};\\\", \\\"{x:530,y:697,t:1528139783020};\\\", \\\"{x:536,y:689,t:1528139783035};\\\", \\\"{x:558,y:668,t:1528139783052};\\\", \\\"{x:580,y:649,t:1528139783069};\\\", \\\"{x:599,y:636,t:1528139783085};\\\", \\\"{x:612,y:627,t:1528139783103};\\\", \\\"{x:619,y:623,t:1528139783117};\\\", \\\"{x:624,y:619,t:1528139783135};\\\", \\\"{x:632,y:615,t:1528139783152};\\\", \\\"{x:636,y:613,t:1528139783169};\\\", \\\"{x:637,y:612,t:1528139783185};\\\", \\\"{x:639,y:612,t:1528139783573};\\\", \\\"{x:644,y:609,t:1528139783586};\\\", \\\"{x:645,y:608,t:1528139783601};\\\", \\\"{x:647,y:607,t:1528139784253};\\\", \\\"{x:653,y:603,t:1528139784269};\\\", \\\"{x:658,y:600,t:1528139784287};\\\", \\\"{x:661,y:599,t:1528139784303};\\\", \\\"{x:669,y:595,t:1528139784319};\\\", \\\"{x:682,y:589,t:1528139784337};\\\", \\\"{x:697,y:577,t:1528139784353};\\\", \\\"{x:711,y:568,t:1528139784369};\\\", \\\"{x:722,y:560,t:1528139784386};\\\", \\\"{x:727,y:555,t:1528139784403};\\\", \\\"{x:728,y:555,t:1528139784420};\\\", \\\"{x:729,y:554,t:1528139784460};\\\", \\\"{x:729,y:553,t:1528139784476};\\\", \\\"{x:725,y:547,t:1528139784486};\\\", \\\"{x:694,y:533,t:1528139784504};\\\", \\\"{x:654,y:521,t:1528139784521};\\\", \\\"{x:599,y:504,t:1528139784537};\\\", \\\"{x:522,y:486,t:1528139784553};\\\", \\\"{x:427,y:472,t:1528139784570};\\\", \\\"{x:330,y:457,t:1528139784586};\\\", \\\"{x:262,y:447,t:1528139784603};\\\", \\\"{x:224,y:442,t:1528139784619};\\\", \\\"{x:214,y:440,t:1528139784636};\\\", \\\"{x:211,y:440,t:1528139784653};\\\", \\\"{x:211,y:439,t:1528139784901};\\\", \\\"{x:220,y:437,t:1528139784909};\\\", \\\"{x:231,y:434,t:1528139784921};\\\", \\\"{x:257,y:430,t:1528139784938};\\\", \\\"{x:277,y:426,t:1528139784953};\\\", \\\"{x:301,y:421,t:1528139784971};\\\", \\\"{x:327,y:420,t:1528139784986};\\\", \\\"{x:349,y:420,t:1528139785003};\\\", \\\"{x:379,y:419,t:1528139785020};\\\", \\\"{x:394,y:419,t:1528139785037};\\\", \\\"{x:404,y:419,t:1528139785053};\\\", \\\"{x:407,y:419,t:1528139785069};\\\", \\\"{x:409,y:419,t:1528139785469};\\\", \\\"{x:427,y:423,t:1528139785487};\\\", \\\"{x:450,y:435,t:1528139785503};\\\", \\\"{x:466,y:441,t:1528139785520};\\\", \\\"{x:476,y:446,t:1528139785538};\\\", \\\"{x:495,y:452,t:1528139785553};\\\", \\\"{x:517,y:459,t:1528139785570};\\\", \\\"{x:536,y:465,t:1528139785587};\\\", \\\"{x:553,y:469,t:1528139785604};\\\", \\\"{x:567,y:473,t:1528139785619};\\\", \\\"{x:587,y:476,t:1528139785636};\\\", \\\"{x:594,y:477,t:1528139785653};\\\", \\\"{x:597,y:477,t:1528139785669};\\\", \\\"{x:597,y:478,t:1528139785686};\\\", \\\"{x:599,y:478,t:1528139786156};\\\", \\\"{x:610,y:478,t:1528139786169};\\\", \\\"{x:641,y:478,t:1528139786186};\\\", \\\"{x:675,y:478,t:1528139786203};\\\", \\\"{x:713,y:478,t:1528139786219};\\\", \\\"{x:792,y:478,t:1528139786237};\\\", \\\"{x:831,y:478,t:1528139786253};\\\", \\\"{x:858,y:478,t:1528139786269};\\\", \\\"{x:865,y:478,t:1528139786286};\\\", \\\"{x:866,y:478,t:1528139786317};\\\", \\\"{x:867,y:478,t:1528139786324};\\\", \\\"{x:873,y:478,t:1528139786677};\\\", \\\"{x:879,y:478,t:1528139786687};\\\", \\\"{x:887,y:478,t:1528139786703};\\\", \\\"{x:891,y:478,t:1528139786720};\\\", \\\"{x:900,y:478,t:1528139786738};\\\", \\\"{x:922,y:478,t:1528139786754};\\\", \\\"{x:925,y:478,t:1528139786769};\\\", \\\"{x:926,y:478,t:1528139786786};\\\", \\\"{x:929,y:478,t:1528139787268};\\\", \\\"{x:932,y:478,t:1528139787276};\\\", \\\"{x:937,y:481,t:1528139787286};\\\", \\\"{x:957,y:496,t:1528139787303};\\\", \\\"{x:985,y:515,t:1528139787320};\\\", \\\"{x:1024,y:532,t:1528139787337};\\\", \\\"{x:1059,y:550,t:1528139787353};\\\", \\\"{x:1080,y:558,t:1528139787370};\\\", \\\"{x:1095,y:563,t:1528139787387};\\\", \\\"{x:1106,y:567,t:1528139787404};\\\", \\\"{x:1125,y:572,t:1528139787420};\\\", \\\"{x:1155,y:580,t:1528139787437};\\\", \\\"{x:1168,y:584,t:1528139787453};\\\", \\\"{x:1171,y:585,t:1528139787469};\\\", \\\"{x:1172,y:587,t:1528139787572};\\\", \\\"{x:1172,y:592,t:1528139787586};\\\", \\\"{x:1172,y:603,t:1528139787602};\\\", \\\"{x:1172,y:608,t:1528139787619};\\\", \\\"{x:1169,y:617,t:1528139787636};\\\", \\\"{x:1166,y:623,t:1528139787653};\\\", \\\"{x:1165,y:625,t:1528139787669};\\\", \\\"{x:1165,y:626,t:1528139787686};\\\", \\\"{x:1164,y:627,t:1528139787702};\\\", \\\"{x:1163,y:628,t:1528139787720};\\\", \\\"{x:1161,y:628,t:1528139787741};\\\", \\\"{x:1161,y:629,t:1528139787752};\\\", \\\"{x:1157,y:631,t:1528139787770};\\\", \\\"{x:1155,y:632,t:1528139787787};\\\", \\\"{x:1152,y:632,t:1528139787802};\\\", \\\"{x:1151,y:634,t:1528139787819};\\\", \\\"{x:1148,y:635,t:1528139787837};\\\", \\\"{x:1146,y:635,t:1528139787885};\\\", \\\"{x:1148,y:635,t:1528139789973};\\\", \\\"{x:1157,y:635,t:1528139789986};\\\", \\\"{x:1180,y:635,t:1528139790003};\\\", \\\"{x:1201,y:635,t:1528139790020};\\\", \\\"{x:1212,y:633,t:1528139790036};\\\", \\\"{x:1224,y:633,t:1528139790053};\\\", \\\"{x:1228,y:633,t:1528139790069};\\\", \\\"{x:1231,y:633,t:1528139790086};\\\", \\\"{x:1235,y:633,t:1528139790103};\\\", \\\"{x:1244,y:639,t:1528139790120};\\\", \\\"{x:1251,y:642,t:1528139790136};\\\", \\\"{x:1256,y:643,t:1528139790153};\\\", \\\"{x:1261,y:646,t:1528139790170};\\\", \\\"{x:1270,y:650,t:1528139790186};\\\", \\\"{x:1285,y:658,t:1528139790203};\\\", \\\"{x:1301,y:667,t:1528139790220};\\\", \\\"{x:1319,y:677,t:1528139790236};\\\", \\\"{x:1344,y:690,t:1528139790253};\\\", \\\"{x:1361,y:698,t:1528139790271};\\\", \\\"{x:1372,y:705,t:1528139790286};\\\", \\\"{x:1384,y:712,t:1528139790302};\\\", \\\"{x:1396,y:718,t:1528139790320};\\\", \\\"{x:1400,y:721,t:1528139790335};\\\", \\\"{x:1403,y:722,t:1528139790352};\\\", \\\"{x:1403,y:723,t:1528139790476};\\\", \\\"{x:1403,y:724,t:1528139790492};\\\", \\\"{x:1402,y:724,t:1528139790503};\\\", \\\"{x:1395,y:724,t:1528139790519};\\\", \\\"{x:1384,y:724,t:1528139790535};\\\", \\\"{x:1375,y:724,t:1528139790552};\\\", \\\"{x:1373,y:723,t:1528139790569};\\\", \\\"{x:1371,y:723,t:1528139790585};\\\", \\\"{x:1369,y:723,t:1528139790604};\\\", \\\"{x:1367,y:723,t:1528139790619};\\\", \\\"{x:1361,y:721,t:1528139790635};\\\", \\\"{x:1349,y:715,t:1528139790652};\\\", \\\"{x:1348,y:714,t:1528139790669};\\\", \\\"{x:1347,y:714,t:1528139790734};\\\", \\\"{x:1346,y:713,t:1528139790741};\\\", \\\"{x:1344,y:712,t:1528139790753};\\\", \\\"{x:1343,y:710,t:1528139790770};\\\", \\\"{x:1342,y:707,t:1528139790786};\\\", \\\"{x:1341,y:706,t:1528139790804};\\\", \\\"{x:1341,y:705,t:1528139790820};\\\", \\\"{x:1340,y:704,t:1528139790835};\\\", \\\"{x:1340,y:703,t:1528139790981};\\\", \\\"{x:1340,y:701,t:1528139790997};\\\", \\\"{x:1341,y:698,t:1528139791005};\\\", \\\"{x:1342,y:696,t:1528139791023};\\\", \\\"{x:1344,y:691,t:1528139791036};\\\", \\\"{x:1348,y:686,t:1528139791052};\\\", \\\"{x:1348,y:685,t:1528139791069};\\\", \\\"{x:1347,y:685,t:1528139791389};\\\", \\\"{x:1346,y:686,t:1528139791453};\\\", \\\"{x:1345,y:686,t:1528139791469};\\\", \\\"{x:1345,y:687,t:1528139791486};\\\", \\\"{x:1344,y:687,t:1528139791502};\\\", \\\"{x:1343,y:687,t:1528139791520};\\\", \\\"{x:1342,y:688,t:1528139791536};\\\", \\\"{x:1341,y:688,t:1528139791805};\\\", \\\"{x:1342,y:691,t:1528139791901};\\\", \\\"{x:1344,y:697,t:1528139791910};\\\", \\\"{x:1346,y:699,t:1528139791920};\\\", \\\"{x:1346,y:701,t:1528139791938};\\\", \\\"{x:1346,y:702,t:1528139791952};\\\", \\\"{x:1347,y:703,t:1528139792101};\\\", \\\"{x:1354,y:703,t:1528139797677};\\\", \\\"{x:1362,y:700,t:1528139797685};\\\", \\\"{x:1370,y:695,t:1528139797702};\\\", \\\"{x:1375,y:694,t:1528139797718};\\\", \\\"{x:1378,y:692,t:1528139797735};\\\", \\\"{x:1380,y:692,t:1528139797752};\\\", \\\"{x:1381,y:692,t:1528139798053};\\\", \\\"{x:1391,y:696,t:1528139798069};\\\", \\\"{x:1394,y:698,t:1528139798085};\\\", \\\"{x:1398,y:699,t:1528139798103};\\\", \\\"{x:1407,y:701,t:1528139798119};\\\", \\\"{x:1425,y:705,t:1528139798135};\\\", \\\"{x:1446,y:710,t:1528139798152};\\\", \\\"{x:1472,y:713,t:1528139798169};\\\", \\\"{x:1507,y:718,t:1528139798185};\\\", \\\"{x:1532,y:723,t:1528139798202};\\\", \\\"{x:1539,y:723,t:1528139798219};\\\", \\\"{x:1541,y:723,t:1528139798235};\\\", \\\"{x:1543,y:723,t:1528139798317};\\\", \\\"{x:1544,y:722,t:1528139798325};\\\", \\\"{x:1547,y:720,t:1528139798335};\\\", \\\"{x:1552,y:716,t:1528139798352};\\\", \\\"{x:1557,y:712,t:1528139798369};\\\", \\\"{x:1564,y:708,t:1528139798385};\\\", \\\"{x:1569,y:703,t:1528139798402};\\\", \\\"{x:1573,y:699,t:1528139798419};\\\", \\\"{x:1577,y:695,t:1528139798435};\\\", \\\"{x:1578,y:693,t:1528139798452};\\\", \\\"{x:1579,y:691,t:1528139798469};\\\", \\\"{x:1580,y:688,t:1528139798485};\\\", \\\"{x:1580,y:686,t:1528139798502};\\\", \\\"{x:1580,y:685,t:1528139798519};\\\", \\\"{x:1582,y:683,t:1528139798535};\\\", \\\"{x:1582,y:681,t:1528139798552};\\\", \\\"{x:1582,y:679,t:1528139798569};\\\", \\\"{x:1582,y:676,t:1528139798585};\\\", \\\"{x:1582,y:675,t:1528139798602};\\\", \\\"{x:1582,y:673,t:1528139798619};\\\", \\\"{x:1582,y:672,t:1528139798636};\\\", \\\"{x:1582,y:669,t:1528139798652};\\\", \\\"{x:1582,y:661,t:1528139798668};\\\", \\\"{x:1582,y:655,t:1528139798686};\\\", \\\"{x:1582,y:653,t:1528139798702};\\\", \\\"{x:1582,y:650,t:1528139798719};\\\", \\\"{x:1582,y:648,t:1528139798735};\\\", \\\"{x:1582,y:647,t:1528139798752};\\\", \\\"{x:1582,y:645,t:1528139798769};\\\", \\\"{x:1582,y:642,t:1528139798785};\\\", \\\"{x:1582,y:637,t:1528139798802};\\\", \\\"{x:1581,y:635,t:1528139798820};\\\", \\\"{x:1581,y:634,t:1528139798877};\\\", \\\"{x:1581,y:632,t:1528139798950};\\\", \\\"{x:1581,y:631,t:1528139798989};\\\", \\\"{x:1581,y:629,t:1528139799133};\\\", \\\"{x:1578,y:629,t:1528139799821};\\\", \\\"{x:1577,y:630,t:1528139799836};\\\", \\\"{x:1575,y:631,t:1528139799853};\\\", \\\"{x:1575,y:632,t:1528139799869};\\\", \\\"{x:1574,y:632,t:1528139799917};\\\", \\\"{x:1574,y:633,t:1528139799965};\\\", \\\"{x:1572,y:633,t:1528139799973};\\\", \\\"{x:1571,y:634,t:1528139799985};\\\", \\\"{x:1567,y:637,t:1528139800002};\\\", \\\"{x:1564,y:640,t:1528139800018};\\\", \\\"{x:1558,y:647,t:1528139800035};\\\", \\\"{x:1546,y:659,t:1528139800053};\\\", \\\"{x:1536,y:666,t:1528139800069};\\\", \\\"{x:1529,y:670,t:1528139800085};\\\", \\\"{x:1518,y:676,t:1528139800102};\\\", \\\"{x:1504,y:683,t:1528139800118};\\\", \\\"{x:1491,y:691,t:1528139800135};\\\", \\\"{x:1482,y:697,t:1528139800153};\\\", \\\"{x:1470,y:703,t:1528139800168};\\\", \\\"{x:1458,y:709,t:1528139800185};\\\", \\\"{x:1451,y:712,t:1528139800202};\\\", \\\"{x:1443,y:716,t:1528139800218};\\\", \\\"{x:1434,y:720,t:1528139800235};\\\", \\\"{x:1420,y:726,t:1528139800253};\\\", \\\"{x:1409,y:732,t:1528139800269};\\\", \\\"{x:1393,y:743,t:1528139800285};\\\", \\\"{x:1382,y:751,t:1528139800303};\\\", \\\"{x:1374,y:756,t:1528139800319};\\\", \\\"{x:1371,y:758,t:1528139800334};\\\", \\\"{x:1366,y:761,t:1528139800352};\\\", \\\"{x:1363,y:762,t:1528139800368};\\\", \\\"{x:1359,y:765,t:1528139800385};\\\", \\\"{x:1355,y:767,t:1528139800401};\\\", \\\"{x:1354,y:767,t:1528139800417};\\\", \\\"{x:1353,y:767,t:1528139800435};\\\", \\\"{x:1355,y:765,t:1528139800549};\\\", \\\"{x:1367,y:758,t:1528139800556};\\\", \\\"{x:1377,y:753,t:1528139800568};\\\", \\\"{x:1396,y:742,t:1528139800585};\\\", \\\"{x:1404,y:735,t:1528139800602};\\\", \\\"{x:1410,y:729,t:1528139800618};\\\", \\\"{x:1412,y:726,t:1528139800635};\\\", \\\"{x:1415,y:723,t:1528139800652};\\\", \\\"{x:1415,y:722,t:1528139800669};\\\", \\\"{x:1415,y:720,t:1528139800685};\\\", \\\"{x:1407,y:725,t:1528139800829};\\\", \\\"{x:1390,y:736,t:1528139800837};\\\", \\\"{x:1351,y:770,t:1528139800853};\\\", \\\"{x:1311,y:799,t:1528139800869};\\\", \\\"{x:1289,y:812,t:1528139800885};\\\", \\\"{x:1276,y:819,t:1528139800902};\\\", \\\"{x:1272,y:823,t:1528139800919};\\\", \\\"{x:1270,y:823,t:1528139800936};\\\", \\\"{x:1269,y:824,t:1528139800951};\\\", \\\"{x:1270,y:824,t:1528139801044};\\\", \\\"{x:1278,y:816,t:1528139801051};\\\", \\\"{x:1298,y:794,t:1528139801068};\\\", \\\"{x:1316,y:778,t:1528139801085};\\\", \\\"{x:1329,y:764,t:1528139801102};\\\", \\\"{x:1348,y:750,t:1528139801118};\\\", \\\"{x:1358,y:741,t:1528139801135};\\\", \\\"{x:1359,y:740,t:1528139801152};\\\", \\\"{x:1353,y:744,t:1528139801245};\\\", \\\"{x:1340,y:756,t:1528139801252};\\\", \\\"{x:1315,y:779,t:1528139801268};\\\", \\\"{x:1300,y:792,t:1528139801285};\\\", \\\"{x:1285,y:804,t:1528139801302};\\\", \\\"{x:1275,y:812,t:1528139801318};\\\", \\\"{x:1272,y:814,t:1528139801336};\\\", \\\"{x:1272,y:813,t:1528139801421};\\\", \\\"{x:1280,y:802,t:1528139801436};\\\", \\\"{x:1312,y:773,t:1528139801453};\\\", \\\"{x:1333,y:757,t:1528139801469};\\\", \\\"{x:1352,y:742,t:1528139801485};\\\", \\\"{x:1361,y:735,t:1528139801502};\\\", \\\"{x:1365,y:733,t:1528139801518};\\\", \\\"{x:1365,y:732,t:1528139801535};\\\", \\\"{x:1361,y:734,t:1528139801621};\\\", \\\"{x:1341,y:747,t:1528139801635};\\\", \\\"{x:1282,y:798,t:1528139801652};\\\", \\\"{x:1244,y:827,t:1528139801669};\\\", \\\"{x:1216,y:846,t:1528139801685};\\\", \\\"{x:1200,y:855,t:1528139801702};\\\", \\\"{x:1193,y:858,t:1528139801718};\\\", \\\"{x:1193,y:856,t:1528139801805};\\\", \\\"{x:1197,y:842,t:1528139801818};\\\", \\\"{x:1206,y:813,t:1528139801836};\\\", \\\"{x:1221,y:786,t:1528139801853};\\\", \\\"{x:1230,y:776,t:1528139801869};\\\", \\\"{x:1234,y:772,t:1528139801885};\\\", \\\"{x:1236,y:771,t:1528139801903};\\\", \\\"{x:1234,y:771,t:1528139801964};\\\", \\\"{x:1223,y:779,t:1528139801971};\\\", \\\"{x:1214,y:788,t:1528139801984};\\\", \\\"{x:1198,y:802,t:1528139802002};\\\", \\\"{x:1191,y:811,t:1528139802017};\\\", \\\"{x:1182,y:817,t:1528139802034};\\\", \\\"{x:1177,y:820,t:1528139802052};\\\", \\\"{x:1187,y:814,t:1528139802116};\\\", \\\"{x:1220,y:794,t:1528139802124};\\\", \\\"{x:1261,y:775,t:1528139802134};\\\", \\\"{x:1334,y:735,t:1528139802150};\\\", \\\"{x:1410,y:696,t:1528139802168};\\\", \\\"{x:1482,y:662,t:1528139802185};\\\", \\\"{x:1538,y:637,t:1528139802201};\\\", \\\"{x:1557,y:629,t:1528139802217};\\\", \\\"{x:1561,y:629,t:1528139802235};\\\", \\\"{x:1560,y:629,t:1528139802268};\\\", \\\"{x:1529,y:652,t:1528139802284};\\\", \\\"{x:1501,y:687,t:1528139802302};\\\", \\\"{x:1481,y:715,t:1528139802318};\\\", \\\"{x:1460,y:744,t:1528139802335};\\\", \\\"{x:1444,y:765,t:1528139802352};\\\", \\\"{x:1432,y:781,t:1528139802368};\\\", \\\"{x:1424,y:793,t:1528139802386};\\\", \\\"{x:1422,y:795,t:1528139802401};\\\", \\\"{x:1422,y:791,t:1528139802477};\\\", \\\"{x:1426,y:781,t:1528139802485};\\\", \\\"{x:1442,y:752,t:1528139802502};\\\", \\\"{x:1454,y:735,t:1528139802518};\\\", \\\"{x:1461,y:723,t:1528139802535};\\\", \\\"{x:1468,y:716,t:1528139802552};\\\", \\\"{x:1469,y:714,t:1528139802568};\\\", \\\"{x:1468,y:717,t:1528139802636};\\\", \\\"{x:1461,y:729,t:1528139802651};\\\", \\\"{x:1440,y:759,t:1528139802667};\\\", \\\"{x:1428,y:774,t:1528139802685};\\\", \\\"{x:1426,y:777,t:1528139802701};\\\", \\\"{x:1432,y:771,t:1528139802765};\\\", \\\"{x:1442,y:761,t:1528139802773};\\\", \\\"{x:1449,y:755,t:1528139802785};\\\", \\\"{x:1457,y:748,t:1528139802801};\\\", \\\"{x:1459,y:747,t:1528139802818};\\\", \\\"{x:1459,y:755,t:1528139802901};\\\", \\\"{x:1447,y:787,t:1528139802918};\\\", \\\"{x:1436,y:809,t:1528139802936};\\\", \\\"{x:1424,y:825,t:1528139802952};\\\", \\\"{x:1416,y:840,t:1528139802968};\\\", \\\"{x:1408,y:852,t:1528139802985};\\\", \\\"{x:1404,y:859,t:1528139803001};\\\", \\\"{x:1404,y:862,t:1528139803018};\\\", \\\"{x:1404,y:861,t:1528139803141};\\\", \\\"{x:1404,y:859,t:1528139803152};\\\", \\\"{x:1405,y:858,t:1528139803168};\\\", \\\"{x:1404,y:859,t:1528139803236};\\\", \\\"{x:1396,y:869,t:1528139803252};\\\", \\\"{x:1365,y:904,t:1528139803268};\\\", \\\"{x:1342,y:924,t:1528139803284};\\\", \\\"{x:1327,y:941,t:1528139803302};\\\", \\\"{x:1316,y:955,t:1528139803318};\\\", \\\"{x:1312,y:959,t:1528139803335};\\\", \\\"{x:1315,y:951,t:1528139803444};\\\", \\\"{x:1320,y:936,t:1528139803452};\\\", \\\"{x:1327,y:917,t:1528139803469};\\\", \\\"{x:1337,y:898,t:1528139803485};\\\", \\\"{x:1346,y:883,t:1528139803501};\\\", \\\"{x:1353,y:876,t:1528139803518};\\\", \\\"{x:1353,y:878,t:1528139803597};\\\", \\\"{x:1352,y:889,t:1528139803605};\\\", \\\"{x:1348,y:897,t:1528139803619};\\\", \\\"{x:1342,y:909,t:1528139803635};\\\", \\\"{x:1339,y:912,t:1528139803651};\\\", \\\"{x:1340,y:907,t:1528139803725};\\\", \\\"{x:1348,y:899,t:1528139803735};\\\", \\\"{x:1363,y:884,t:1528139803751};\\\", \\\"{x:1373,y:875,t:1528139803769};\\\", \\\"{x:1383,y:866,t:1528139803786};\\\", \\\"{x:1392,y:861,t:1528139803801};\\\", \\\"{x:1395,y:859,t:1528139803819};\\\", \\\"{x:1395,y:863,t:1528139803893};\\\", \\\"{x:1390,y:869,t:1528139803901};\\\", \\\"{x:1380,y:881,t:1528139803919};\\\", \\\"{x:1378,y:884,t:1528139803937};\\\", \\\"{x:1385,y:877,t:1528139804037};\\\", \\\"{x:1391,y:869,t:1528139804052};\\\", \\\"{x:1411,y:846,t:1528139804068};\\\", \\\"{x:1420,y:836,t:1528139804084};\\\", \\\"{x:1425,y:835,t:1528139804102};\\\", \\\"{x:1419,y:835,t:1528139804173};\\\", \\\"{x:1410,y:840,t:1528139804186};\\\", \\\"{x:1385,y:855,t:1528139804201};\\\", \\\"{x:1361,y:869,t:1528139804219};\\\", \\\"{x:1345,y:877,t:1528139804236};\\\", \\\"{x:1341,y:878,t:1528139804251};\\\", \\\"{x:1340,y:878,t:1528139804269};\\\", \\\"{x:1341,y:873,t:1528139804325};\\\", \\\"{x:1349,y:866,t:1528139804335};\\\", \\\"{x:1364,y:853,t:1528139804352};\\\", \\\"{x:1376,y:844,t:1528139804369};\\\", \\\"{x:1391,y:833,t:1528139804386};\\\", \\\"{x:1408,y:823,t:1528139804402};\\\", \\\"{x:1421,y:818,t:1528139804419};\\\", \\\"{x:1435,y:813,t:1528139804436};\\\", \\\"{x:1441,y:810,t:1528139804452};\\\", \\\"{x:1468,y:799,t:1528139804469};\\\", \\\"{x:1482,y:795,t:1528139804484};\\\", \\\"{x:1496,y:789,t:1528139804502};\\\", \\\"{x:1511,y:782,t:1528139804518};\\\", \\\"{x:1527,y:776,t:1528139804535};\\\", \\\"{x:1545,y:767,t:1528139804550};\\\", \\\"{x:1561,y:762,t:1528139804568};\\\", \\\"{x:1568,y:759,t:1528139804584};\\\", \\\"{x:1569,y:757,t:1528139804601};\\\", \\\"{x:1570,y:757,t:1528139804618};\\\", \\\"{x:1571,y:755,t:1528139804635};\\\", \\\"{x:1566,y:757,t:1528139804772};\\\", \\\"{x:1559,y:762,t:1528139804784};\\\", \\\"{x:1544,y:773,t:1528139804800};\\\", \\\"{x:1530,y:782,t:1528139804818};\\\", \\\"{x:1524,y:786,t:1528139804834};\\\", \\\"{x:1520,y:787,t:1528139804851};\\\", \\\"{x:1519,y:787,t:1528139804908};\\\", \\\"{x:1518,y:787,t:1528139804918};\\\", \\\"{x:1516,y:789,t:1528139804934};\\\", \\\"{x:1514,y:790,t:1528139804951};\\\", \\\"{x:1512,y:792,t:1528139804968};\\\", \\\"{x:1511,y:793,t:1528139804984};\\\", \\\"{x:1509,y:795,t:1528139805101};\\\", \\\"{x:1507,y:796,t:1528139805118};\\\", \\\"{x:1504,y:801,t:1528139805134};\\\", \\\"{x:1502,y:804,t:1528139805152};\\\", \\\"{x:1499,y:808,t:1528139805169};\\\", \\\"{x:1495,y:814,t:1528139805185};\\\", \\\"{x:1492,y:818,t:1528139805201};\\\", \\\"{x:1491,y:821,t:1528139805218};\\\", \\\"{x:1489,y:824,t:1528139805234};\\\", \\\"{x:1488,y:826,t:1528139805252};\\\", \\\"{x:1486,y:828,t:1528139805269};\\\", \\\"{x:1485,y:830,t:1528139805284};\\\", \\\"{x:1485,y:831,t:1528139805308};\\\", \\\"{x:1484,y:832,t:1528139805324};\\\", \\\"{x:1483,y:833,t:1528139805334};\\\", \\\"{x:1482,y:835,t:1528139805350};\\\", \\\"{x:1482,y:837,t:1528139805368};\\\", \\\"{x:1479,y:840,t:1528139805384};\\\", \\\"{x:1478,y:843,t:1528139805400};\\\", \\\"{x:1474,y:848,t:1528139805418};\\\", \\\"{x:1471,y:850,t:1528139805434};\\\", \\\"{x:1470,y:854,t:1528139805451};\\\", \\\"{x:1465,y:860,t:1528139805467};\\\", \\\"{x:1463,y:866,t:1528139805484};\\\", \\\"{x:1460,y:873,t:1528139805501};\\\", \\\"{x:1454,y:882,t:1528139805518};\\\", \\\"{x:1451,y:889,t:1528139805534};\\\", \\\"{x:1445,y:895,t:1528139805551};\\\", \\\"{x:1437,y:905,t:1528139805568};\\\", \\\"{x:1429,y:914,t:1528139805584};\\\", \\\"{x:1419,y:922,t:1528139805601};\\\", \\\"{x:1412,y:927,t:1528139805618};\\\", \\\"{x:1410,y:929,t:1528139805634};\\\", \\\"{x:1409,y:930,t:1528139805685};\\\", \\\"{x:1407,y:933,t:1528139805702};\\\", \\\"{x:1407,y:934,t:1528139805719};\\\", \\\"{x:1406,y:935,t:1528139805735};\\\", \\\"{x:1406,y:936,t:1528139805780};\\\", \\\"{x:1406,y:937,t:1528139805804};\\\", \\\"{x:1406,y:938,t:1528139805845};\\\", \\\"{x:1406,y:939,t:1528139805861};\\\", \\\"{x:1406,y:940,t:1528139805868};\\\", \\\"{x:1406,y:942,t:1528139805885};\\\", \\\"{x:1406,y:943,t:1528139805902};\\\", \\\"{x:1406,y:944,t:1528139805918};\\\", \\\"{x:1406,y:938,t:1528139806061};\\\", \\\"{x:1406,y:928,t:1528139806069};\\\", \\\"{x:1407,y:915,t:1528139806085};\\\", \\\"{x:1412,y:905,t:1528139806102};\\\", \\\"{x:1416,y:894,t:1528139806118};\\\", \\\"{x:1419,y:889,t:1528139806135};\\\", \\\"{x:1425,y:881,t:1528139806152};\\\", \\\"{x:1429,y:875,t:1528139806169};\\\", \\\"{x:1432,y:871,t:1528139806184};\\\", \\\"{x:1436,y:866,t:1528139806201};\\\", \\\"{x:1439,y:861,t:1528139806218};\\\", \\\"{x:1440,y:859,t:1528139806235};\\\", \\\"{x:1441,y:858,t:1528139806251};\\\", \\\"{x:1442,y:856,t:1528139806268};\\\", \\\"{x:1443,y:854,t:1528139806285};\\\", \\\"{x:1445,y:852,t:1528139806301};\\\", \\\"{x:1447,y:850,t:1528139806318};\\\", \\\"{x:1449,y:846,t:1528139806335};\\\", \\\"{x:1453,y:840,t:1528139806351};\\\", \\\"{x:1460,y:834,t:1528139806368};\\\", \\\"{x:1466,y:829,t:1528139806384};\\\", \\\"{x:1469,y:825,t:1528139806401};\\\", \\\"{x:1476,y:818,t:1528139806418};\\\", \\\"{x:1480,y:815,t:1528139806434};\\\", \\\"{x:1482,y:812,t:1528139806451};\\\", \\\"{x:1486,y:808,t:1528139806468};\\\", \\\"{x:1487,y:807,t:1528139806484};\\\", \\\"{x:1489,y:805,t:1528139806501};\\\", \\\"{x:1491,y:802,t:1528139806518};\\\", \\\"{x:1492,y:801,t:1528139806535};\\\", \\\"{x:1493,y:800,t:1528139806551};\\\", \\\"{x:1494,y:798,t:1528139806568};\\\", \\\"{x:1495,y:797,t:1528139806584};\\\", \\\"{x:1496,y:795,t:1528139806601};\\\", \\\"{x:1497,y:794,t:1528139806619};\\\", \\\"{x:1498,y:792,t:1528139806634};\\\", \\\"{x:1498,y:791,t:1528139806652};\\\", \\\"{x:1499,y:789,t:1528139806668};\\\", \\\"{x:1500,y:789,t:1528139806685};\\\", \\\"{x:1501,y:788,t:1528139806702};\\\", \\\"{x:1501,y:786,t:1528139806719};\\\", \\\"{x:1503,y:784,t:1528139806734};\\\", \\\"{x:1505,y:782,t:1528139806752};\\\", \\\"{x:1506,y:781,t:1528139806769};\\\", \\\"{x:1507,y:779,t:1528139806784};\\\", \\\"{x:1508,y:778,t:1528139806801};\\\", \\\"{x:1510,y:776,t:1528139806819};\\\", \\\"{x:1510,y:775,t:1528139806835};\\\", \\\"{x:1511,y:774,t:1528139806851};\\\", \\\"{x:1512,y:772,t:1528139806868};\\\", \\\"{x:1513,y:770,t:1528139806885};\\\", \\\"{x:1515,y:768,t:1528139806902};\\\", \\\"{x:1517,y:766,t:1528139806918};\\\", \\\"{x:1519,y:763,t:1528139806935};\\\", \\\"{x:1522,y:761,t:1528139806953};\\\", \\\"{x:1523,y:760,t:1528139806968};\\\", \\\"{x:1524,y:758,t:1528139806988};\\\", \\\"{x:1525,y:757,t:1528139807012};\\\", \\\"{x:1521,y:757,t:1528139807557};\\\", \\\"{x:1518,y:758,t:1528139807567};\\\", \\\"{x:1515,y:759,t:1528139807583};\\\", \\\"{x:1513,y:760,t:1528139807601};\\\", \\\"{x:1511,y:760,t:1528139807617};\\\", \\\"{x:1510,y:761,t:1528139807634};\\\", \\\"{x:1509,y:762,t:1528139807651};\\\", \\\"{x:1507,y:763,t:1528139807667};\\\", \\\"{x:1504,y:769,t:1528139807684};\\\", \\\"{x:1502,y:772,t:1528139807701};\\\", \\\"{x:1500,y:774,t:1528139807717};\\\", \\\"{x:1498,y:776,t:1528139807734};\\\", \\\"{x:1497,y:777,t:1528139807751};\\\", \\\"{x:1496,y:777,t:1528139807767};\\\", \\\"{x:1496,y:778,t:1528139807785};\\\", \\\"{x:1494,y:782,t:1528139807802};\\\", \\\"{x:1491,y:786,t:1528139807817};\\\", \\\"{x:1490,y:788,t:1528139807834};\\\", \\\"{x:1487,y:792,t:1528139807852};\\\", \\\"{x:1486,y:794,t:1528139807867};\\\", \\\"{x:1484,y:797,t:1528139807884};\\\", \\\"{x:1483,y:799,t:1528139807902};\\\", \\\"{x:1482,y:802,t:1528139807917};\\\", \\\"{x:1480,y:804,t:1528139807934};\\\", \\\"{x:1478,y:806,t:1528139807951};\\\", \\\"{x:1476,y:807,t:1528139807967};\\\", \\\"{x:1475,y:810,t:1528139807984};\\\", \\\"{x:1473,y:813,t:1528139808001};\\\", \\\"{x:1472,y:816,t:1528139808017};\\\", \\\"{x:1470,y:818,t:1528139808034};\\\", \\\"{x:1469,y:820,t:1528139808051};\\\", \\\"{x:1468,y:822,t:1528139808067};\\\", \\\"{x:1468,y:826,t:1528139808084};\\\", \\\"{x:1467,y:826,t:1528139808101};\\\", \\\"{x:1467,y:829,t:1528139808493};\\\", \\\"{x:1467,y:835,t:1528139808501};\\\", \\\"{x:1466,y:840,t:1528139808517};\\\", \\\"{x:1462,y:844,t:1528139808535};\\\", \\\"{x:1461,y:846,t:1528139808552};\\\", \\\"{x:1461,y:848,t:1528139808568};\\\", \\\"{x:1461,y:849,t:1528139808677};\\\", \\\"{x:1460,y:849,t:1528139808709};\\\", \\\"{x:1460,y:851,t:1528139808718};\\\", \\\"{x:1459,y:853,t:1528139808735};\\\", \\\"{x:1459,y:856,t:1528139808751};\\\", \\\"{x:1455,y:862,t:1528139808768};\\\", \\\"{x:1454,y:866,t:1528139808785};\\\", \\\"{x:1452,y:870,t:1528139808802};\\\", \\\"{x:1451,y:873,t:1528139808817};\\\", \\\"{x:1448,y:880,t:1528139808835};\\\", \\\"{x:1446,y:886,t:1528139808852};\\\", \\\"{x:1445,y:890,t:1528139808868};\\\", \\\"{x:1445,y:892,t:1528139808884};\\\", \\\"{x:1444,y:893,t:1528139808901};\\\", \\\"{x:1444,y:894,t:1528139808917};\\\", \\\"{x:1443,y:897,t:1528139808934};\\\", \\\"{x:1442,y:901,t:1528139808951};\\\", \\\"{x:1440,y:904,t:1528139808968};\\\", \\\"{x:1437,y:910,t:1528139808985};\\\", \\\"{x:1435,y:917,t:1528139809001};\\\", \\\"{x:1432,y:920,t:1528139809017};\\\", \\\"{x:1432,y:923,t:1528139809035};\\\", \\\"{x:1430,y:927,t:1528139809051};\\\", \\\"{x:1428,y:931,t:1528139809068};\\\", \\\"{x:1427,y:935,t:1528139809085};\\\", \\\"{x:1426,y:936,t:1528139809101};\\\", \\\"{x:1426,y:937,t:1528139809118};\\\", \\\"{x:1425,y:939,t:1528139809135};\\\", \\\"{x:1423,y:940,t:1528139809152};\\\", \\\"{x:1423,y:941,t:1528139809168};\\\", \\\"{x:1422,y:943,t:1528139809185};\\\", \\\"{x:1421,y:944,t:1528139809202};\\\", \\\"{x:1420,y:945,t:1528139809218};\\\", \\\"{x:1420,y:946,t:1528139809234};\\\", \\\"{x:1419,y:948,t:1528139809252};\\\", \\\"{x:1419,y:949,t:1528139809268};\\\", \\\"{x:1418,y:951,t:1528139809285};\\\", \\\"{x:1418,y:952,t:1528139809301};\\\", \\\"{x:1417,y:953,t:1528139809318};\\\", \\\"{x:1417,y:951,t:1528139809573};\\\", \\\"{x:1417,y:945,t:1528139809585};\\\", \\\"{x:1421,y:936,t:1528139809601};\\\", \\\"{x:1423,y:928,t:1528139809617};\\\", \\\"{x:1426,y:918,t:1528139809634};\\\", \\\"{x:1431,y:909,t:1528139809650};\\\", \\\"{x:1435,y:900,t:1528139809668};\\\", \\\"{x:1440,y:891,t:1528139809685};\\\", \\\"{x:1444,y:887,t:1528139809701};\\\", \\\"{x:1448,y:883,t:1528139809718};\\\", \\\"{x:1452,y:879,t:1528139809734};\\\", \\\"{x:1455,y:876,t:1528139809751};\\\", \\\"{x:1459,y:874,t:1528139809768};\\\", \\\"{x:1461,y:871,t:1528139809785};\\\", \\\"{x:1462,y:869,t:1528139809800};\\\", \\\"{x:1464,y:865,t:1528139809818};\\\", \\\"{x:1467,y:862,t:1528139809835};\\\", \\\"{x:1470,y:857,t:1528139809851};\\\", \\\"{x:1473,y:850,t:1528139809868};\\\", \\\"{x:1479,y:842,t:1528139809884};\\\", \\\"{x:1482,y:837,t:1528139809901};\\\", \\\"{x:1485,y:833,t:1528139809918};\\\", \\\"{x:1487,y:830,t:1528139809935};\\\", \\\"{x:1488,y:829,t:1528139809950};\\\", \\\"{x:1489,y:828,t:1528139809967};\\\", \\\"{x:1489,y:827,t:1528139809988};\\\", \\\"{x:1490,y:827,t:1528139810011};\\\", \\\"{x:1490,y:826,t:1528139810019};\\\", \\\"{x:1491,y:826,t:1528139810034};\\\", \\\"{x:1492,y:824,t:1528139810050};\\\", \\\"{x:1494,y:819,t:1528139810067};\\\", \\\"{x:1496,y:811,t:1528139810084};\\\", \\\"{x:1500,y:803,t:1528139810100};\\\", \\\"{x:1504,y:795,t:1528139810117};\\\", \\\"{x:1509,y:785,t:1528139810134};\\\", \\\"{x:1516,y:775,t:1528139810150};\\\", \\\"{x:1521,y:768,t:1528139810167};\\\", \\\"{x:1525,y:764,t:1528139810184};\\\", \\\"{x:1527,y:762,t:1528139810201};\\\", \\\"{x:1528,y:759,t:1528139810218};\\\", \\\"{x:1530,y:758,t:1528139810234};\\\", \\\"{x:1532,y:755,t:1528139810250};\\\", \\\"{x:1532,y:753,t:1528139810268};\\\", \\\"{x:1533,y:751,t:1528139810284};\\\", \\\"{x:1534,y:750,t:1528139810308};\\\", \\\"{x:1533,y:750,t:1528139810629};\\\", \\\"{x:1532,y:750,t:1528139810637};\\\", \\\"{x:1531,y:750,t:1528139810651};\\\", \\\"{x:1528,y:751,t:1528139810668};\\\", \\\"{x:1523,y:754,t:1528139810685};\\\", \\\"{x:1522,y:754,t:1528139810700};\\\", \\\"{x:1519,y:755,t:1528139810717};\\\", \\\"{x:1518,y:756,t:1528139810734};\\\", \\\"{x:1517,y:757,t:1528139810750};\\\", \\\"{x:1516,y:757,t:1528139810767};\\\", \\\"{x:1513,y:757,t:1528139810785};\\\", \\\"{x:1512,y:757,t:1528139810800};\\\", \\\"{x:1510,y:758,t:1528139810818};\\\", \\\"{x:1509,y:758,t:1528139810835};\\\", \\\"{x:1508,y:759,t:1528139810850};\\\", \\\"{x:1507,y:759,t:1528139810933};\\\", \\\"{x:1507,y:760,t:1528139810941};\\\", \\\"{x:1505,y:760,t:1528139810987};\\\", \\\"{x:1505,y:761,t:1528139811012};\\\", \\\"{x:1504,y:761,t:1528139811149};\\\", \\\"{x:1503,y:762,t:1528139811188};\\\", \\\"{x:1503,y:763,t:1528139811213};\\\", \\\"{x:1501,y:764,t:1528139811221};\\\", \\\"{x:1500,y:765,t:1528139811235};\\\", \\\"{x:1495,y:768,t:1528139811251};\\\", \\\"{x:1492,y:771,t:1528139811268};\\\", \\\"{x:1488,y:775,t:1528139811284};\\\", \\\"{x:1484,y:781,t:1528139811300};\\\", \\\"{x:1480,y:786,t:1528139811317};\\\", \\\"{x:1477,y:791,t:1528139811334};\\\", \\\"{x:1473,y:797,t:1528139811350};\\\", \\\"{x:1466,y:806,t:1528139811367};\\\", \\\"{x:1461,y:813,t:1528139811384};\\\", \\\"{x:1457,y:819,t:1528139811400};\\\", \\\"{x:1453,y:825,t:1528139811417};\\\", \\\"{x:1451,y:826,t:1528139811435};\\\", \\\"{x:1450,y:827,t:1528139811451};\\\", \\\"{x:1448,y:830,t:1528139811467};\\\", \\\"{x:1444,y:834,t:1528139811484};\\\", \\\"{x:1439,y:838,t:1528139811501};\\\", \\\"{x:1439,y:840,t:1528139811517};\\\", \\\"{x:1439,y:841,t:1528139811535};\\\", \\\"{x:1439,y:842,t:1528139811645};\\\", \\\"{x:1442,y:839,t:1528139811652};\\\", \\\"{x:1447,y:834,t:1528139811667};\\\", \\\"{x:1454,y:827,t:1528139811685};\\\", \\\"{x:1457,y:823,t:1528139811700};\\\", \\\"{x:1461,y:819,t:1528139811718};\\\", \\\"{x:1465,y:816,t:1528139811735};\\\", \\\"{x:1467,y:815,t:1528139811750};\\\", \\\"{x:1468,y:815,t:1528139811767};\\\", \\\"{x:1470,y:813,t:1528139811784};\\\", \\\"{x:1472,y:813,t:1528139811800};\\\", \\\"{x:1473,y:812,t:1528139811819};\\\", \\\"{x:1474,y:812,t:1528139811835};\\\", \\\"{x:1475,y:812,t:1528139811852};\\\", \\\"{x:1477,y:812,t:1528139811884};\\\", \\\"{x:1484,y:814,t:1528139811900};\\\", \\\"{x:1504,y:823,t:1528139811918};\\\", \\\"{x:1528,y:830,t:1528139811935};\\\", \\\"{x:1550,y:837,t:1528139811951};\\\", \\\"{x:1565,y:846,t:1528139811967};\\\", \\\"{x:1572,y:850,t:1528139811984};\\\", \\\"{x:1576,y:854,t:1528139812000};\\\", \\\"{x:1579,y:859,t:1528139812017};\\\", \\\"{x:1583,y:867,t:1528139812034};\\\", \\\"{x:1586,y:874,t:1528139812050};\\\", \\\"{x:1590,y:882,t:1528139812067};\\\", \\\"{x:1595,y:889,t:1528139812083};\\\", \\\"{x:1598,y:892,t:1528139812098};\\\", \\\"{x:1599,y:892,t:1528139812170};\\\", \\\"{x:1601,y:893,t:1528139812181};\\\", \\\"{x:1605,y:898,t:1528139812198};\\\", \\\"{x:1607,y:906,t:1528139812216};\\\", \\\"{x:1609,y:912,t:1528139812231};\\\", \\\"{x:1610,y:916,t:1528139812249};\\\", \\\"{x:1611,y:919,t:1528139812265};\\\", \\\"{x:1613,y:923,t:1528139812282};\\\", \\\"{x:1615,y:929,t:1528139812298};\\\", \\\"{x:1618,y:933,t:1528139812315};\\\", \\\"{x:1620,y:939,t:1528139812332};\\\", \\\"{x:1621,y:941,t:1528139812349};\\\", \\\"{x:1622,y:945,t:1528139812365};\\\", \\\"{x:1624,y:946,t:1528139812381};\\\", \\\"{x:1625,y:946,t:1528139812398};\\\", \\\"{x:1627,y:948,t:1528139812415};\\\", \\\"{x:1628,y:951,t:1528139812432};\\\", \\\"{x:1628,y:954,t:1528139812448};\\\", \\\"{x:1628,y:955,t:1528139812466};\\\", \\\"{x:1628,y:956,t:1528139812482};\\\", \\\"{x:1628,y:957,t:1528139812498};\\\", \\\"{x:1627,y:958,t:1528139812546};\\\", \\\"{x:1626,y:958,t:1528139812585};\\\", \\\"{x:1625,y:958,t:1528139812598};\\\", \\\"{x:1621,y:957,t:1528139812614};\\\", \\\"{x:1611,y:953,t:1528139812631};\\\", \\\"{x:1602,y:951,t:1528139812648};\\\", \\\"{x:1597,y:948,t:1528139812665};\\\", \\\"{x:1590,y:945,t:1528139812681};\\\", \\\"{x:1582,y:939,t:1528139812698};\\\", \\\"{x:1573,y:934,t:1528139812716};\\\", \\\"{x:1570,y:932,t:1528139812731};\\\", \\\"{x:1565,y:930,t:1528139812748};\\\", \\\"{x:1558,y:924,t:1528139812765};\\\", \\\"{x:1551,y:914,t:1528139812781};\\\", \\\"{x:1543,y:898,t:1528139812798};\\\", \\\"{x:1533,y:881,t:1528139812815};\\\", \\\"{x:1525,y:865,t:1528139812831};\\\", \\\"{x:1522,y:855,t:1528139812848};\\\", \\\"{x:1518,y:848,t:1528139812865};\\\", \\\"{x:1517,y:845,t:1528139812881};\\\", \\\"{x:1514,y:838,t:1528139812898};\\\", \\\"{x:1513,y:834,t:1528139812915};\\\", \\\"{x:1513,y:833,t:1528139812938};\\\", \\\"{x:1512,y:833,t:1528139812949};\\\", \\\"{x:1512,y:831,t:1528139812966};\\\", \\\"{x:1512,y:828,t:1528139812982};\\\", \\\"{x:1511,y:827,t:1528139812999};\\\", \\\"{x:1510,y:825,t:1528139813016};\\\", \\\"{x:1509,y:823,t:1528139813032};\\\", \\\"{x:1508,y:823,t:1528139813048};\\\", \\\"{x:1508,y:822,t:1528139813065};\\\", \\\"{x:1507,y:822,t:1528139813147};\\\", \\\"{x:1506,y:822,t:1528139813154};\\\", \\\"{x:1504,y:822,t:1528139813165};\\\", \\\"{x:1502,y:822,t:1528139813182};\\\", \\\"{x:1501,y:822,t:1528139813199};\\\", \\\"{x:1500,y:822,t:1528139813242};\\\", \\\"{x:1499,y:822,t:1528139813290};\\\", \\\"{x:1498,y:823,t:1528139813298};\\\", \\\"{x:1497,y:824,t:1528139813315};\\\", \\\"{x:1495,y:824,t:1528139813331};\\\", \\\"{x:1492,y:826,t:1528139813348};\\\", \\\"{x:1491,y:826,t:1528139813366};\\\", \\\"{x:1491,y:827,t:1528139813381};\\\", \\\"{x:1490,y:827,t:1528139813491};\\\", \\\"{x:1489,y:827,t:1528139813659};\\\", \\\"{x:1489,y:828,t:1528139813666};\\\", \\\"{x:1488,y:828,t:1528139813698};\\\", \\\"{x:1486,y:828,t:1528139813716};\\\", \\\"{x:1484,y:828,t:1528139813731};\\\", \\\"{x:1481,y:829,t:1528139813749};\\\", \\\"{x:1480,y:829,t:1528139813765};\\\", \\\"{x:1480,y:830,t:1528139813781};\\\", \\\"{x:1478,y:830,t:1528139814003};\\\", \\\"{x:1477,y:829,t:1528139814016};\\\", \\\"{x:1477,y:825,t:1528139814033};\\\", \\\"{x:1477,y:822,t:1528139814049};\\\", \\\"{x:1477,y:818,t:1528139814065};\\\", \\\"{x:1477,y:815,t:1528139814081};\\\", \\\"{x:1477,y:810,t:1528139814099};\\\", \\\"{x:1477,y:809,t:1528139814115};\\\", \\\"{x:1477,y:806,t:1528139814132};\\\", \\\"{x:1479,y:805,t:1528139814149};\\\", \\\"{x:1481,y:804,t:1528139814166};\\\", \\\"{x:1481,y:802,t:1528139814259};\\\", \\\"{x:1476,y:798,t:1528139814266};\\\", \\\"{x:1458,y:791,t:1528139814282};\\\", \\\"{x:1432,y:786,t:1528139814299};\\\", \\\"{x:1392,y:780,t:1528139814316};\\\", \\\"{x:1308,y:767,t:1528139814332};\\\", \\\"{x:1180,y:740,t:1528139814349};\\\", \\\"{x:1085,y:726,t:1528139814365};\\\", \\\"{x:1000,y:717,t:1528139814382};\\\", \\\"{x:942,y:710,t:1528139814399};\\\", \\\"{x:901,y:709,t:1528139814416};\\\", \\\"{x:886,y:706,t:1528139814432};\\\", \\\"{x:880,y:703,t:1528139814449};\\\", \\\"{x:878,y:702,t:1528139814466};\\\", \\\"{x:877,y:701,t:1528139814482};\\\", \\\"{x:873,y:699,t:1528139814498};\\\", \\\"{x:869,y:698,t:1528139814515};\\\", \\\"{x:866,y:697,t:1528139814532};\\\", \\\"{x:860,y:695,t:1528139814549};\\\", \\\"{x:846,y:691,t:1528139814565};\\\", \\\"{x:832,y:689,t:1528139814582};\\\", \\\"{x:807,y:682,t:1528139814599};\\\", \\\"{x:767,y:670,t:1528139814616};\\\", \\\"{x:718,y:644,t:1528139814631};\\\", \\\"{x:686,y:625,t:1528139814650};\\\", \\\"{x:670,y:613,t:1528139814666};\\\", \\\"{x:666,y:609,t:1528139814681};\\\", \\\"{x:664,y:608,t:1528139814698};\\\", \\\"{x:664,y:607,t:1528139814708};\\\", \\\"{x:662,y:606,t:1528139814725};\\\", \\\"{x:661,y:604,t:1528139814742};\\\", \\\"{x:660,y:603,t:1528139814759};\\\", \\\"{x:659,y:603,t:1528139814775};\\\", \\\"{x:658,y:602,t:1528139814825};\\\", \\\"{x:654,y:599,t:1528139814842};\\\", \\\"{x:650,y:596,t:1528139814859};\\\", \\\"{x:639,y:589,t:1528139814876};\\\", \\\"{x:626,y:584,t:1528139814892};\\\", \\\"{x:608,y:578,t:1528139814910};\\\", \\\"{x:583,y:574,t:1528139814926};\\\", \\\"{x:543,y:573,t:1528139814942};\\\", \\\"{x:471,y:573,t:1528139814960};\\\", \\\"{x:415,y:573,t:1528139814976};\\\", \\\"{x:373,y:573,t:1528139814993};\\\", \\\"{x:350,y:573,t:1528139815009};\\\", \\\"{x:342,y:573,t:1528139815025};\\\", \\\"{x:341,y:573,t:1528139815043};\\\", \\\"{x:338,y:575,t:1528139815187};\\\", \\\"{x:333,y:577,t:1528139815194};\\\", \\\"{x:331,y:579,t:1528139815209};\\\", \\\"{x:327,y:583,t:1528139815225};\\\", \\\"{x:322,y:586,t:1528139815243};\\\", \\\"{x:319,y:588,t:1528139815259};\\\", \\\"{x:307,y:591,t:1528139815276};\\\", \\\"{x:293,y:594,t:1528139815293};\\\", \\\"{x:283,y:596,t:1528139815309};\\\", \\\"{x:279,y:597,t:1528139815326};\\\", \\\"{x:278,y:597,t:1528139815343};\\\", \\\"{x:275,y:599,t:1528139815359};\\\", \\\"{x:274,y:599,t:1528139815376};\\\", \\\"{x:273,y:599,t:1528139815394};\\\", \\\"{x:272,y:600,t:1528139815410};\\\", \\\"{x:278,y:597,t:1528139815483};\\\", \\\"{x:290,y:592,t:1528139815494};\\\", \\\"{x:310,y:581,t:1528139815510};\\\", \\\"{x:333,y:571,t:1528139815526};\\\", \\\"{x:355,y:564,t:1528139815542};\\\", \\\"{x:378,y:557,t:1528139815560};\\\", \\\"{x:397,y:553,t:1528139815577};\\\", \\\"{x:419,y:553,t:1528139815592};\\\", \\\"{x:475,y:559,t:1528139815610};\\\", \\\"{x:534,y:576,t:1528139815625};\\\", \\\"{x:562,y:586,t:1528139815642};\\\", \\\"{x:581,y:592,t:1528139815659};\\\", \\\"{x:592,y:596,t:1528139815677};\\\", \\\"{x:595,y:596,t:1528139815692};\\\", \\\"{x:596,y:591,t:1528139815980};\\\", \\\"{x:599,y:583,t:1528139815993};\\\", \\\"{x:600,y:580,t:1528139816009};\\\", \\\"{x:605,y:571,t:1528139816026};\\\", \\\"{x:608,y:568,t:1528139816043};\\\", \\\"{x:606,y:568,t:1528139816338};\\\", \\\"{x:596,y:573,t:1528139816345};\\\", \\\"{x:589,y:577,t:1528139816360};\\\", \\\"{x:568,y:584,t:1528139816376};\\\", \\\"{x:532,y:595,t:1528139816394};\\\", \\\"{x:513,y:601,t:1528139816410};\\\", \\\"{x:505,y:604,t:1528139816426};\\\", \\\"{x:502,y:605,t:1528139816443};\\\", \\\"{x:501,y:606,t:1528139816460};\\\", \\\"{x:499,y:607,t:1528139816476};\\\", \\\"{x:494,y:608,t:1528139816495};\\\", \\\"{x:486,y:613,t:1528139816510};\\\", \\\"{x:474,y:617,t:1528139816526};\\\", \\\"{x:464,y:623,t:1528139816543};\\\", \\\"{x:454,y:627,t:1528139816560};\\\", \\\"{x:449,y:630,t:1528139816576};\\\", \\\"{x:446,y:631,t:1528139816593};\\\", \\\"{x:445,y:631,t:1528139816618};\\\", \\\"{x:444,y:631,t:1528139816634};\\\", \\\"{x:442,y:631,t:1528139816644};\\\", \\\"{x:431,y:631,t:1528139816661};\\\", \\\"{x:411,y:630,t:1528139816678};\\\", \\\"{x:379,y:630,t:1528139816693};\\\", \\\"{x:323,y:628,t:1528139816710};\\\", \\\"{x:245,y:628,t:1528139816729};\\\", \\\"{x:192,y:628,t:1528139816743};\\\", \\\"{x:155,y:628,t:1528139816760};\\\", \\\"{x:128,y:628,t:1528139816777};\\\", \\\"{x:124,y:628,t:1528139816793};\\\", \\\"{x:123,y:626,t:1528139816825};\\\", \\\"{x:122,y:626,t:1528139816834};\\\", \\\"{x:122,y:625,t:1528139816843};\\\", \\\"{x:126,y:612,t:1528139816860};\\\", \\\"{x:139,y:602,t:1528139816877};\\\", \\\"{x:162,y:589,t:1528139816894};\\\", \\\"{x:197,y:570,t:1528139816911};\\\", \\\"{x:232,y:550,t:1528139816929};\\\", \\\"{x:262,y:548,t:1528139816944};\\\", \\\"{x:302,y:548,t:1528139816961};\\\", \\\"{x:394,y:544,t:1528139816978};\\\", \\\"{x:432,y:551,t:1528139816993};\\\", \\\"{x:487,y:551,t:1528139817010};\\\", \\\"{x:507,y:551,t:1528139817028};\\\", \\\"{x:528,y:552,t:1528139817043};\\\", \\\"{x:548,y:554,t:1528139817060};\\\", \\\"{x:556,y:557,t:1528139817078};\\\", \\\"{x:562,y:558,t:1528139817094};\\\", \\\"{x:565,y:558,t:1528139817110};\\\", \\\"{x:567,y:558,t:1528139817127};\\\", \\\"{x:570,y:558,t:1528139817144};\\\", \\\"{x:583,y:558,t:1528139817160};\\\", \\\"{x:620,y:563,t:1528139817179};\\\", \\\"{x:642,y:567,t:1528139817195};\\\", \\\"{x:662,y:568,t:1528139817211};\\\", \\\"{x:685,y:572,t:1528139817227};\\\", \\\"{x:714,y:576,t:1528139817244};\\\", \\\"{x:735,y:580,t:1528139817262};\\\", \\\"{x:741,y:581,t:1528139817277};\\\", \\\"{x:742,y:581,t:1528139817294};\\\", \\\"{x:744,y:582,t:1528139817329};\\\", \\\"{x:744,y:583,t:1528139817344};\\\", \\\"{x:749,y:584,t:1528139817360};\\\", \\\"{x:752,y:584,t:1528139817377};\\\", \\\"{x:753,y:584,t:1528139817393};\\\", \\\"{x:754,y:584,t:1528139817442};\\\", \\\"{x:756,y:584,t:1528139817449};\\\", \\\"{x:757,y:584,t:1528139817461};\\\", \\\"{x:767,y:584,t:1528139817477};\\\", \\\"{x:776,y:584,t:1528139817493};\\\", \\\"{x:777,y:584,t:1528139817530};\\\", \\\"{x:778,y:584,t:1528139817544};\\\", \\\"{x:782,y:583,t:1528139817560};\\\", \\\"{x:787,y:582,t:1528139817577};\\\", \\\"{x:793,y:580,t:1528139817593};\\\", \\\"{x:798,y:578,t:1528139817610};\\\", \\\"{x:799,y:578,t:1528139817627};\\\", \\\"{x:801,y:577,t:1528139817643};\\\", \\\"{x:803,y:576,t:1528139817673};\\\", \\\"{x:807,y:576,t:1528139817682};\\\", \\\"{x:814,y:576,t:1528139817693};\\\", \\\"{x:827,y:577,t:1528139817710};\\\", \\\"{x:832,y:578,t:1528139817728};\\\", \\\"{x:828,y:582,t:1528139818113};\\\", \\\"{x:820,y:588,t:1528139818128};\\\", \\\"{x:806,y:596,t:1528139818144};\\\", \\\"{x:790,y:605,t:1528139818162};\\\", \\\"{x:780,y:610,t:1528139818179};\\\", \\\"{x:768,y:618,t:1528139818194};\\\", \\\"{x:754,y:624,t:1528139818211};\\\", \\\"{x:742,y:631,t:1528139818228};\\\", \\\"{x:734,y:636,t:1528139818245};\\\", \\\"{x:724,y:643,t:1528139818261};\\\", \\\"{x:708,y:654,t:1528139818278};\\\", \\\"{x:692,y:665,t:1528139818294};\\\", \\\"{x:674,y:675,t:1528139818311};\\\", \\\"{x:654,y:686,t:1528139818328};\\\", \\\"{x:638,y:697,t:1528139818344};\\\", \\\"{x:622,y:706,t:1528139818362};\\\", \\\"{x:617,y:708,t:1528139818379};\\\", \\\"{x:614,y:711,t:1528139818394};\\\", \\\"{x:611,y:713,t:1528139818412};\\\", \\\"{x:610,y:713,t:1528139818434};\\\", \\\"{x:609,y:713,t:1528139818458};\\\", \\\"{x:607,y:713,t:1528139818466};\\\", \\\"{x:604,y:713,t:1528139818479};\\\", \\\"{x:596,y:713,t:1528139818495};\\\", \\\"{x:582,y:714,t:1528139818511};\\\", \\\"{x:566,y:719,t:1528139818529};\\\", \\\"{x:542,y:725,t:1528139818546};\\\", \\\"{x:535,y:729,t:1528139818561};\\\", \\\"{x:517,y:735,t:1528139818578};\\\", \\\"{x:504,y:738,t:1528139818596};\\\", \\\"{x:492,y:742,t:1528139818611};\\\", \\\"{x:486,y:743,t:1528139818628};\\\", \\\"{x:482,y:743,t:1528139818646};\\\", \\\"{x:480,y:744,t:1528139818662};\\\", \\\"{x:477,y:744,t:1528139818778};\\\", \\\"{x:477,y:744,t:1528139818863};\\\", \\\"{x:477,y:745,t:1528139819562};\\\", \\\"{x:501,y:745,t:1528139819580};\\\", \\\"{x:520,y:735,t:1528139819596};\\\" ] }, { \\\"rt\\\": 103013, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 590392, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -B -B -10 AM-B -B -B -01 PM-02 PM-B -B -02 PM-02 PM-B -B -B -X -03 PM-10 AM-F -G -G -G -G -C -C -C -04 PM-04 PM-B -C -B -F -F -G -G -C -C -G -G -B -B -G -G -F -F -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:735,t:1528139820962};\\\", \\\"{x:527,y:735,t:1528139820970};\\\", \\\"{x:535,y:738,t:1528139820981};\\\", \\\"{x:554,y:745,t:1528139820999};\\\", \\\"{x:570,y:751,t:1528139821016};\\\", \\\"{x:581,y:756,t:1528139821031};\\\", \\\"{x:589,y:759,t:1528139821046};\\\", \\\"{x:590,y:759,t:1528139821081};\\\", \\\"{x:590,y:756,t:1528139822234};\\\", \\\"{x:592,y:752,t:1528139822355};\\\", \\\"{x:593,y:744,t:1528139822364};\\\", \\\"{x:606,y:714,t:1528139822379};\\\", \\\"{x:615,y:683,t:1528139822397};\\\", \\\"{x:636,y:638,t:1528139822414};\\\", \\\"{x:654,y:604,t:1528139822432};\\\", \\\"{x:670,y:578,t:1528139822447};\\\", \\\"{x:685,y:558,t:1528139822465};\\\", \\\"{x:699,y:538,t:1528139822481};\\\", \\\"{x:703,y:533,t:1528139822498};\\\", \\\"{x:705,y:527,t:1528139822514};\\\", \\\"{x:705,y:526,t:1528139822531};\\\", \\\"{x:705,y:525,t:1528139822549};\\\", \\\"{x:705,y:521,t:1528139822565};\\\", \\\"{x:705,y:513,t:1528139822582};\\\", \\\"{x:688,y:494,t:1528139822599};\\\", \\\"{x:657,y:477,t:1528139822616};\\\", \\\"{x:632,y:467,t:1528139822631};\\\", \\\"{x:622,y:463,t:1528139822649};\\\", \\\"{x:619,y:463,t:1528139822665};\\\", \\\"{x:612,y:463,t:1528139822681};\\\", \\\"{x:602,y:463,t:1528139822698};\\\", \\\"{x:592,y:463,t:1528139822715};\\\", \\\"{x:582,y:464,t:1528139822732};\\\", \\\"{x:570,y:472,t:1528139822748};\\\", \\\"{x:564,y:479,t:1528139822766};\\\", \\\"{x:563,y:482,t:1528139822782};\\\", \\\"{x:563,y:483,t:1528139822799};\\\", \\\"{x:563,y:486,t:1528139822816};\\\", \\\"{x:562,y:486,t:1528139823394};\\\", \\\"{x:561,y:485,t:1528139823459};\\\", \\\"{x:560,y:485,t:1528139823469};\\\", \\\"{x:557,y:483,t:1528139823486};\\\", \\\"{x:556,y:483,t:1528139823501};\\\", \\\"{x:555,y:480,t:1528139823658};\\\", \\\"{x:555,y:479,t:1528139823674};\\\", \\\"{x:555,y:478,t:1528139823687};\\\", \\\"{x:555,y:477,t:1528139823703};\\\", \\\"{x:556,y:475,t:1528139823720};\\\", \\\"{x:556,y:474,t:1528139823746};\\\", \\\"{x:557,y:473,t:1528139824274};\\\", \\\"{x:561,y:471,t:1528139824289};\\\", \\\"{x:580,y:462,t:1528139824306};\\\", \\\"{x:586,y:461,t:1528139824322};\\\", \\\"{x:592,y:460,t:1528139824338};\\\", \\\"{x:599,y:459,t:1528139824356};\\\", \\\"{x:610,y:457,t:1528139824373};\\\", \\\"{x:621,y:455,t:1528139824389};\\\", \\\"{x:637,y:455,t:1528139824406};\\\", \\\"{x:661,y:455,t:1528139824422};\\\", \\\"{x:686,y:455,t:1528139824440};\\\", \\\"{x:707,y:453,t:1528139824456};\\\", \\\"{x:719,y:449,t:1528139824473};\\\", \\\"{x:736,y:444,t:1528139824489};\\\", \\\"{x:754,y:442,t:1528139824506};\\\", \\\"{x:767,y:439,t:1528139824523};\\\", \\\"{x:785,y:439,t:1528139824540};\\\", \\\"{x:808,y:439,t:1528139824557};\\\", \\\"{x:839,y:439,t:1528139824574};\\\", \\\"{x:868,y:439,t:1528139824590};\\\", \\\"{x:891,y:439,t:1528139824607};\\\", \\\"{x:918,y:439,t:1528139824624};\\\", \\\"{x:954,y:439,t:1528139824640};\\\", \\\"{x:1002,y:439,t:1528139824657};\\\", \\\"{x:1086,y:439,t:1528139824674};\\\", \\\"{x:1139,y:431,t:1528139824691};\\\", \\\"{x:1184,y:424,t:1528139824707};\\\", \\\"{x:1217,y:417,t:1528139824724};\\\", \\\"{x:1266,y:409,t:1528139824741};\\\", \\\"{x:1358,y:408,t:1528139824758};\\\", \\\"{x:1466,y:408,t:1528139824774};\\\", \\\"{x:1571,y:408,t:1528139824791};\\\", \\\"{x:1641,y:408,t:1528139824808};\\\", \\\"{x:1680,y:408,t:1528139824825};\\\", \\\"{x:1709,y:408,t:1528139824841};\\\", \\\"{x:1724,y:408,t:1528139824858};\\\", \\\"{x:1725,y:408,t:1528139824876};\\\", \\\"{x:1715,y:404,t:1528139825035};\\\", \\\"{x:1696,y:404,t:1528139825042};\\\", \\\"{x:1642,y:413,t:1528139825059};\\\", \\\"{x:1595,y:432,t:1528139825076};\\\", \\\"{x:1559,y:449,t:1528139825092};\\\", \\\"{x:1507,y:468,t:1528139825109};\\\", \\\"{x:1449,y:485,t:1528139825126};\\\", \\\"{x:1390,y:495,t:1528139825143};\\\", \\\"{x:1350,y:495,t:1528139825159};\\\", \\\"{x:1333,y:495,t:1528139825176};\\\", \\\"{x:1326,y:495,t:1528139825193};\\\", \\\"{x:1321,y:495,t:1528139825210};\\\", \\\"{x:1319,y:495,t:1528139825227};\\\", \\\"{x:1318,y:495,t:1528139825243};\\\", \\\"{x:1316,y:495,t:1528139825260};\\\", \\\"{x:1315,y:495,t:1528139825276};\\\", \\\"{x:1304,y:495,t:1528139825294};\\\", \\\"{x:1294,y:497,t:1528139825310};\\\", \\\"{x:1284,y:499,t:1528139825327};\\\", \\\"{x:1275,y:502,t:1528139825344};\\\", \\\"{x:1270,y:503,t:1528139825360};\\\", \\\"{x:1268,y:503,t:1528139825377};\\\", \\\"{x:1267,y:503,t:1528139825499};\\\", \\\"{x:1265,y:503,t:1528139825511};\\\", \\\"{x:1260,y:503,t:1528139825528};\\\", \\\"{x:1252,y:503,t:1528139825544};\\\", \\\"{x:1251,y:503,t:1528139825561};\\\", \\\"{x:1250,y:503,t:1528139825578};\\\", \\\"{x:1252,y:501,t:1528139826515};\\\", \\\"{x:1261,y:497,t:1528139826532};\\\", \\\"{x:1266,y:494,t:1528139826548};\\\", \\\"{x:1269,y:493,t:1528139826565};\\\", \\\"{x:1271,y:492,t:1528139826582};\\\", \\\"{x:1272,y:492,t:1528139826599};\\\", \\\"{x:1273,y:495,t:1528139826939};\\\", \\\"{x:1274,y:498,t:1528139826951};\\\", \\\"{x:1275,y:501,t:1528139826967};\\\", \\\"{x:1277,y:505,t:1528139826984};\\\", \\\"{x:1277,y:508,t:1528139827000};\\\", \\\"{x:1279,y:511,t:1528139827018};\\\", \\\"{x:1281,y:515,t:1528139827034};\\\", \\\"{x:1283,y:518,t:1528139827051};\\\", \\\"{x:1286,y:524,t:1528139827067};\\\", \\\"{x:1287,y:528,t:1528139827084};\\\", \\\"{x:1289,y:536,t:1528139827101};\\\", \\\"{x:1290,y:542,t:1528139827117};\\\", \\\"{x:1291,y:546,t:1528139827135};\\\", \\\"{x:1291,y:549,t:1528139827151};\\\", \\\"{x:1291,y:550,t:1528139827218};\\\", \\\"{x:1292,y:550,t:1528139827234};\\\", \\\"{x:1291,y:550,t:1528139829514};\\\", \\\"{x:1287,y:555,t:1528139829527};\\\", \\\"{x:1280,y:564,t:1528139829547};\\\", \\\"{x:1277,y:571,t:1528139829563};\\\", \\\"{x:1273,y:576,t:1528139829579};\\\", \\\"{x:1272,y:577,t:1528139829731};\\\", \\\"{x:1273,y:577,t:1528139829819};\\\", \\\"{x:1276,y:577,t:1528139829829};\\\", \\\"{x:1287,y:574,t:1528139829845};\\\", \\\"{x:1299,y:569,t:1528139829862};\\\", \\\"{x:1311,y:564,t:1528139829879};\\\", \\\"{x:1320,y:559,t:1528139829896};\\\", \\\"{x:1326,y:556,t:1528139829913};\\\", \\\"{x:1331,y:553,t:1528139829929};\\\", \\\"{x:1333,y:551,t:1528139829946};\\\", \\\"{x:1337,y:549,t:1528139829962};\\\", \\\"{x:1339,y:548,t:1528139829979};\\\", \\\"{x:1341,y:546,t:1528139830187};\\\", \\\"{x:1342,y:545,t:1528139830202};\\\", \\\"{x:1343,y:545,t:1528139830214};\\\", \\\"{x:1344,y:544,t:1528139830231};\\\", \\\"{x:1346,y:544,t:1528139830247};\\\", \\\"{x:1348,y:543,t:1528139830265};\\\", \\\"{x:1352,y:543,t:1528139830282};\\\", \\\"{x:1359,y:543,t:1528139830298};\\\", \\\"{x:1366,y:543,t:1528139830315};\\\", \\\"{x:1371,y:543,t:1528139830331};\\\", \\\"{x:1373,y:542,t:1528139830348};\\\", \\\"{x:1375,y:542,t:1528139830364};\\\", \\\"{x:1377,y:541,t:1528139830381};\\\", \\\"{x:1378,y:541,t:1528139830398};\\\", \\\"{x:1381,y:541,t:1528139830415};\\\", \\\"{x:1383,y:541,t:1528139830431};\\\", \\\"{x:1384,y:541,t:1528139830610};\\\", \\\"{x:1387,y:541,t:1528139830618};\\\", \\\"{x:1388,y:545,t:1528139830632};\\\", \\\"{x:1388,y:554,t:1528139830649};\\\", \\\"{x:1389,y:571,t:1528139830666};\\\", \\\"{x:1389,y:583,t:1528139830682};\\\", \\\"{x:1389,y:592,t:1528139830700};\\\", \\\"{x:1389,y:597,t:1528139830716};\\\", \\\"{x:1389,y:605,t:1528139830733};\\\", \\\"{x:1389,y:614,t:1528139830749};\\\", \\\"{x:1389,y:621,t:1528139830766};\\\", \\\"{x:1389,y:627,t:1528139830783};\\\", \\\"{x:1389,y:632,t:1528139830800};\\\", \\\"{x:1389,y:636,t:1528139830816};\\\", \\\"{x:1391,y:640,t:1528139830833};\\\", \\\"{x:1391,y:646,t:1528139830850};\\\", \\\"{x:1391,y:653,t:1528139830866};\\\", \\\"{x:1391,y:666,t:1528139830883};\\\", \\\"{x:1391,y:683,t:1528139830900};\\\", \\\"{x:1391,y:702,t:1528139830917};\\\", \\\"{x:1391,y:718,t:1528139830933};\\\", \\\"{x:1386,y:734,t:1528139830950};\\\", \\\"{x:1383,y:746,t:1528139830967};\\\", \\\"{x:1380,y:755,t:1528139830984};\\\", \\\"{x:1379,y:759,t:1528139831000};\\\", \\\"{x:1377,y:761,t:1528139831017};\\\", \\\"{x:1377,y:763,t:1528139831035};\\\", \\\"{x:1376,y:764,t:1528139831053};\\\", \\\"{x:1376,y:765,t:1528139831067};\\\", \\\"{x:1375,y:766,t:1528139831089};\\\", \\\"{x:1374,y:766,t:1528139831101};\\\", \\\"{x:1371,y:768,t:1528139831117};\\\", \\\"{x:1365,y:770,t:1528139831134};\\\", \\\"{x:1362,y:772,t:1528139831151};\\\", \\\"{x:1357,y:772,t:1528139831167};\\\", \\\"{x:1355,y:773,t:1528139831184};\\\", \\\"{x:1354,y:774,t:1528139831201};\\\", \\\"{x:1353,y:774,t:1528139831234};\\\", \\\"{x:1351,y:774,t:1528139831299};\\\", \\\"{x:1350,y:774,t:1528139831306};\\\", \\\"{x:1349,y:774,t:1528139831318};\\\", \\\"{x:1347,y:772,t:1528139831336};\\\", \\\"{x:1345,y:770,t:1528139831352};\\\", \\\"{x:1342,y:766,t:1528139831369};\\\", \\\"{x:1342,y:765,t:1528139831386};\\\", \\\"{x:1340,y:761,t:1528139831402};\\\", \\\"{x:1340,y:760,t:1528139831434};\\\", \\\"{x:1340,y:759,t:1528139831441};\\\", \\\"{x:1341,y:759,t:1528139831762};\\\", \\\"{x:1342,y:759,t:1528139831770};\\\", \\\"{x:1345,y:759,t:1528139831788};\\\", \\\"{x:1347,y:759,t:1528139831804};\\\", \\\"{x:1349,y:759,t:1528139831820};\\\", \\\"{x:1350,y:759,t:1528139831837};\\\", \\\"{x:1350,y:760,t:1528139832850};\\\", \\\"{x:1350,y:761,t:1528139832881};\\\", \\\"{x:1348,y:761,t:1528139834067};\\\", \\\"{x:1343,y:762,t:1528139834080};\\\", \\\"{x:1341,y:764,t:1528139834098};\\\", \\\"{x:1339,y:765,t:1528139834114};\\\", \\\"{x:1338,y:766,t:1528139834283};\\\", \\\"{x:1337,y:767,t:1528139834297};\\\", \\\"{x:1336,y:768,t:1528139834314};\\\", \\\"{x:1335,y:769,t:1528139834331};\\\", \\\"{x:1336,y:768,t:1528139834666};\\\", \\\"{x:1338,y:763,t:1528139834683};\\\", \\\"{x:1340,y:760,t:1528139834700};\\\", \\\"{x:1341,y:760,t:1528139834716};\\\", \\\"{x:1342,y:760,t:1528139835586};\\\", \\\"{x:1345,y:760,t:1528139835604};\\\", \\\"{x:1346,y:760,t:1528139835620};\\\", \\\"{x:1347,y:760,t:1528139835637};\\\", \\\"{x:1349,y:760,t:1528139835653};\\\", \\\"{x:1350,y:760,t:1528139835674};\\\", \\\"{x:1351,y:761,t:1528139835690};\\\", \\\"{x:1352,y:761,t:1528139835747};\\\", \\\"{x:1352,y:762,t:1528139836274};\\\", \\\"{x:1351,y:764,t:1528139836290};\\\", \\\"{x:1349,y:766,t:1528139836306};\\\", \\\"{x:1347,y:767,t:1528139836322};\\\", \\\"{x:1345,y:769,t:1528139836474};\\\", \\\"{x:1342,y:773,t:1528139836490};\\\", \\\"{x:1340,y:776,t:1528139836507};\\\", \\\"{x:1337,y:781,t:1528139836524};\\\", \\\"{x:1335,y:783,t:1528139836540};\\\", \\\"{x:1334,y:784,t:1528139836558};\\\", \\\"{x:1333,y:785,t:1528139836674};\\\", \\\"{x:1333,y:786,t:1528139836706};\\\", \\\"{x:1331,y:788,t:1528139836714};\\\", \\\"{x:1330,y:789,t:1528139836724};\\\", \\\"{x:1328,y:792,t:1528139836741};\\\", \\\"{x:1326,y:795,t:1528139836758};\\\", \\\"{x:1325,y:796,t:1528139836774};\\\", \\\"{x:1324,y:797,t:1528139836791};\\\", \\\"{x:1325,y:797,t:1528139837186};\\\", \\\"{x:1326,y:794,t:1528139837194};\\\", \\\"{x:1328,y:791,t:1528139837210};\\\", \\\"{x:1329,y:790,t:1528139837227};\\\", \\\"{x:1330,y:789,t:1528139837243};\\\", \\\"{x:1332,y:789,t:1528139837260};\\\", \\\"{x:1332,y:788,t:1528139837276};\\\", \\\"{x:1333,y:788,t:1528139837293};\\\", \\\"{x:1334,y:787,t:1528139837311};\\\", \\\"{x:1338,y:785,t:1528139837328};\\\", \\\"{x:1339,y:784,t:1528139837344};\\\", \\\"{x:1341,y:781,t:1528139837360};\\\", \\\"{x:1343,y:778,t:1528139837378};\\\", \\\"{x:1344,y:777,t:1528139837394};\\\", \\\"{x:1344,y:776,t:1528139837410};\\\", \\\"{x:1345,y:775,t:1528139837428};\\\", \\\"{x:1346,y:775,t:1528139837445};\\\", \\\"{x:1346,y:774,t:1528139837539};\\\", \\\"{x:1347,y:772,t:1528139837554};\\\", \\\"{x:1347,y:771,t:1528139837570};\\\", \\\"{x:1348,y:769,t:1528139837578};\\\", \\\"{x:1349,y:767,t:1528139837594};\\\", \\\"{x:1350,y:765,t:1528139837612};\\\", \\\"{x:1350,y:762,t:1528139837629};\\\", \\\"{x:1351,y:760,t:1528139837645};\\\", \\\"{x:1351,y:759,t:1528139837661};\\\", \\\"{x:1351,y:760,t:1528139838154};\\\", \\\"{x:1350,y:760,t:1528139838163};\\\", \\\"{x:1349,y:761,t:1528139838185};\\\", \\\"{x:1348,y:761,t:1528139838202};\\\", \\\"{x:1347,y:761,t:1528139838214};\\\", \\\"{x:1347,y:762,t:1528139838230};\\\", \\\"{x:1346,y:763,t:1528139838248};\\\", \\\"{x:1345,y:763,t:1528139838264};\\\", \\\"{x:1344,y:763,t:1528139838281};\\\", \\\"{x:1344,y:764,t:1528139838426};\\\", \\\"{x:1343,y:766,t:1528139838442};\\\", \\\"{x:1342,y:766,t:1528139838451};\\\", \\\"{x:1341,y:768,t:1528139838465};\\\", \\\"{x:1339,y:771,t:1528139838482};\\\", \\\"{x:1339,y:772,t:1528139838499};\\\", \\\"{x:1338,y:773,t:1528139838516};\\\", \\\"{x:1337,y:775,t:1528139838667};\\\", \\\"{x:1335,y:779,t:1528139838683};\\\", \\\"{x:1333,y:782,t:1528139838699};\\\", \\\"{x:1331,y:785,t:1528139838717};\\\", \\\"{x:1330,y:788,t:1528139838734};\\\", \\\"{x:1330,y:790,t:1528139838750};\\\", \\\"{x:1330,y:791,t:1528139838778};\\\", \\\"{x:1329,y:791,t:1528139838923};\\\", \\\"{x:1328,y:793,t:1528139838938};\\\", \\\"{x:1327,y:794,t:1528139838954};\\\", \\\"{x:1327,y:795,t:1528139838967};\\\", \\\"{x:1326,y:796,t:1528139838985};\\\", \\\"{x:1326,y:797,t:1528139839034};\\\", \\\"{x:1326,y:798,t:1528139839082};\\\", \\\"{x:1324,y:799,t:1528139839090};\\\", \\\"{x:1324,y:800,t:1528139839105};\\\", \\\"{x:1323,y:801,t:1528139839117};\\\", \\\"{x:1322,y:803,t:1528139839134};\\\", \\\"{x:1320,y:806,t:1528139839151};\\\", \\\"{x:1319,y:809,t:1528139839169};\\\", \\\"{x:1317,y:810,t:1528139839185};\\\", \\\"{x:1316,y:813,t:1528139839202};\\\", \\\"{x:1316,y:815,t:1528139839218};\\\", \\\"{x:1315,y:815,t:1528139839236};\\\", \\\"{x:1314,y:816,t:1528139839274};\\\", \\\"{x:1313,y:817,t:1528139839370};\\\", \\\"{x:1311,y:820,t:1528139839386};\\\", \\\"{x:1311,y:822,t:1528139839403};\\\", \\\"{x:1309,y:824,t:1528139839420};\\\", \\\"{x:1307,y:825,t:1528139839436};\\\", \\\"{x:1307,y:827,t:1528139839453};\\\", \\\"{x:1306,y:828,t:1528139839469};\\\", \\\"{x:1305,y:829,t:1528139839571};\\\", \\\"{x:1304,y:830,t:1528139839586};\\\", \\\"{x:1303,y:831,t:1528139839610};\\\", \\\"{x:1301,y:833,t:1528139839626};\\\", \\\"{x:1300,y:837,t:1528139839642};\\\", \\\"{x:1298,y:838,t:1528139839653};\\\", \\\"{x:1297,y:840,t:1528139839670};\\\", \\\"{x:1295,y:842,t:1528139839687};\\\", \\\"{x:1294,y:844,t:1528139839704};\\\", \\\"{x:1293,y:845,t:1528139839722};\\\", \\\"{x:1293,y:846,t:1528139839809};\\\", \\\"{x:1292,y:846,t:1528139839833};\\\", \\\"{x:1292,y:847,t:1528139839849};\\\", \\\"{x:1292,y:849,t:1528139839857};\\\", \\\"{x:1291,y:849,t:1528139839871};\\\", \\\"{x:1289,y:853,t:1528139839888};\\\", \\\"{x:1287,y:857,t:1528139839904};\\\", \\\"{x:1284,y:862,t:1528139839921};\\\", \\\"{x:1281,y:865,t:1528139839937};\\\", \\\"{x:1280,y:867,t:1528139839954};\\\", \\\"{x:1280,y:869,t:1528139839972};\\\", \\\"{x:1279,y:870,t:1528139840002};\\\", \\\"{x:1278,y:871,t:1528139840034};\\\", \\\"{x:1278,y:872,t:1528139840058};\\\", \\\"{x:1278,y:874,t:1528139840072};\\\", \\\"{x:1276,y:878,t:1528139840089};\\\", \\\"{x:1274,y:883,t:1528139840105};\\\", \\\"{x:1271,y:888,t:1528139840121};\\\", \\\"{x:1268,y:892,t:1528139840138};\\\", \\\"{x:1266,y:896,t:1528139840156};\\\", \\\"{x:1263,y:901,t:1528139840173};\\\", \\\"{x:1262,y:904,t:1528139840189};\\\", \\\"{x:1261,y:906,t:1528139840205};\\\", \\\"{x:1260,y:907,t:1528139840222};\\\", \\\"{x:1260,y:908,t:1528139840239};\\\", \\\"{x:1260,y:909,t:1528139840265};\\\", \\\"{x:1259,y:909,t:1528139840289};\\\", \\\"{x:1259,y:911,t:1528139840306};\\\", \\\"{x:1258,y:914,t:1528139840322};\\\", \\\"{x:1257,y:916,t:1528139840339};\\\", \\\"{x:1256,y:918,t:1528139840356};\\\", \\\"{x:1256,y:919,t:1528139840373};\\\", \\\"{x:1254,y:922,t:1528139840389};\\\", \\\"{x:1253,y:926,t:1528139840406};\\\", \\\"{x:1251,y:928,t:1528139840424};\\\", \\\"{x:1251,y:930,t:1528139840440};\\\", \\\"{x:1249,y:932,t:1528139840457};\\\", \\\"{x:1248,y:934,t:1528139840474};\\\", \\\"{x:1248,y:935,t:1528139840491};\\\", \\\"{x:1244,y:940,t:1528139840508};\\\", \\\"{x:1242,y:943,t:1528139840524};\\\", \\\"{x:1241,y:945,t:1528139840540};\\\", \\\"{x:1239,y:948,t:1528139840557};\\\", \\\"{x:1238,y:950,t:1528139840575};\\\", \\\"{x:1237,y:950,t:1528139840590};\\\", \\\"{x:1236,y:953,t:1528139840608};\\\", \\\"{x:1236,y:957,t:1528139840625};\\\", \\\"{x:1234,y:961,t:1528139840641};\\\", \\\"{x:1232,y:968,t:1528139840658};\\\", \\\"{x:1230,y:972,t:1528139840675};\\\", \\\"{x:1230,y:973,t:1528139840691};\\\", \\\"{x:1229,y:974,t:1528139840707};\\\", \\\"{x:1229,y:975,t:1528139841010};\\\", \\\"{x:1230,y:975,t:1528139841034};\\\", \\\"{x:1232,y:975,t:1528139841042};\\\", \\\"{x:1233,y:975,t:1528139841072};\\\", \\\"{x:1233,y:974,t:1528139841081};\\\", \\\"{x:1235,y:974,t:1528139841097};\\\", \\\"{x:1236,y:974,t:1528139841109};\\\", \\\"{x:1239,y:972,t:1528139841126};\\\", \\\"{x:1240,y:972,t:1528139841143};\\\", \\\"{x:1242,y:971,t:1528139841159};\\\", \\\"{x:1243,y:971,t:1528139841177};\\\", \\\"{x:1243,y:970,t:1528139841193};\\\", \\\"{x:1244,y:970,t:1528139841217};\\\", \\\"{x:1246,y:969,t:1528139841226};\\\", \\\"{x:1246,y:968,t:1528139841243};\\\", \\\"{x:1251,y:965,t:1528139841260};\\\", \\\"{x:1253,y:964,t:1528139841277};\\\", \\\"{x:1256,y:962,t:1528139841293};\\\", \\\"{x:1257,y:962,t:1528139841311};\\\", \\\"{x:1258,y:961,t:1528139841327};\\\", \\\"{x:1258,y:960,t:1528139841344};\\\", \\\"{x:1260,y:960,t:1528139841361};\\\", \\\"{x:1264,y:957,t:1528139841378};\\\", \\\"{x:1269,y:953,t:1528139841394};\\\", \\\"{x:1277,y:946,t:1528139841411};\\\", \\\"{x:1287,y:934,t:1528139841428};\\\", \\\"{x:1298,y:917,t:1528139841444};\\\", \\\"{x:1308,y:898,t:1528139841462};\\\", \\\"{x:1318,y:878,t:1528139841478};\\\", \\\"{x:1326,y:854,t:1528139841495};\\\", \\\"{x:1330,y:834,t:1528139841512};\\\", \\\"{x:1336,y:819,t:1528139841529};\\\", \\\"{x:1338,y:808,t:1528139841545};\\\", \\\"{x:1340,y:798,t:1528139841562};\\\", \\\"{x:1342,y:789,t:1528139841578};\\\", \\\"{x:1342,y:785,t:1528139841594};\\\", \\\"{x:1343,y:781,t:1528139841612};\\\", \\\"{x:1343,y:780,t:1528139841629};\\\", \\\"{x:1343,y:779,t:1528139841645};\\\", \\\"{x:1343,y:778,t:1528139841661};\\\", \\\"{x:1343,y:777,t:1528139841681};\\\", \\\"{x:1344,y:774,t:1528139841695};\\\", \\\"{x:1344,y:772,t:1528139841712};\\\", \\\"{x:1345,y:768,t:1528139841728};\\\", \\\"{x:1346,y:762,t:1528139841745};\\\", \\\"{x:1346,y:757,t:1528139841762};\\\", \\\"{x:1346,y:754,t:1528139841779};\\\", \\\"{x:1346,y:753,t:1528139841795};\\\", \\\"{x:1347,y:755,t:1528139842162};\\\", \\\"{x:1349,y:759,t:1528139842170};\\\", \\\"{x:1350,y:763,t:1528139842181};\\\", \\\"{x:1351,y:765,t:1528139842197};\\\", \\\"{x:1352,y:768,t:1528139842216};\\\", \\\"{x:1354,y:770,t:1528139842231};\\\", \\\"{x:1355,y:772,t:1528139842248};\\\", \\\"{x:1357,y:773,t:1528139842265};\\\", \\\"{x:1358,y:776,t:1528139842281};\\\", \\\"{x:1358,y:778,t:1528139842298};\\\", \\\"{x:1362,y:784,t:1528139842314};\\\", \\\"{x:1365,y:793,t:1528139842332};\\\", \\\"{x:1369,y:802,t:1528139842349};\\\", \\\"{x:1371,y:808,t:1528139842365};\\\", \\\"{x:1371,y:811,t:1528139842382};\\\", \\\"{x:1373,y:813,t:1528139842399};\\\", \\\"{x:1373,y:814,t:1528139842417};\\\", \\\"{x:1373,y:815,t:1528139842442};\\\", \\\"{x:1373,y:816,t:1528139842506};\\\", \\\"{x:1373,y:818,t:1528139842516};\\\", \\\"{x:1374,y:828,t:1528139842533};\\\", \\\"{x:1376,y:843,t:1528139842548};\\\", \\\"{x:1381,y:865,t:1528139842565};\\\", \\\"{x:1386,y:892,t:1528139842583};\\\", \\\"{x:1391,y:913,t:1528139842600};\\\", \\\"{x:1395,y:929,t:1528139842615};\\\", \\\"{x:1396,y:938,t:1528139842632};\\\", \\\"{x:1396,y:942,t:1528139842649};\\\", \\\"{x:1396,y:944,t:1528139842666};\\\", \\\"{x:1398,y:946,t:1528139842858};\\\", \\\"{x:1401,y:950,t:1528139842866};\\\", \\\"{x:1404,y:953,t:1528139842884};\\\", \\\"{x:1406,y:954,t:1528139842901};\\\", \\\"{x:1407,y:955,t:1528139842918};\\\", \\\"{x:1410,y:958,t:1528139843067};\\\", \\\"{x:1415,y:962,t:1528139843074};\\\", \\\"{x:1419,y:964,t:1528139843085};\\\", \\\"{x:1427,y:972,t:1528139843102};\\\", \\\"{x:1431,y:975,t:1528139843118};\\\", \\\"{x:1436,y:977,t:1528139843135};\\\", \\\"{x:1439,y:979,t:1528139843151};\\\", \\\"{x:1443,y:980,t:1528139843168};\\\", \\\"{x:1449,y:983,t:1528139843185};\\\", \\\"{x:1456,y:983,t:1528139843201};\\\", \\\"{x:1462,y:983,t:1528139843219};\\\", \\\"{x:1467,y:983,t:1528139843235};\\\", \\\"{x:1469,y:983,t:1528139843252};\\\", \\\"{x:1472,y:983,t:1528139843268};\\\", \\\"{x:1473,y:983,t:1528139843286};\\\", \\\"{x:1474,y:983,t:1528139843442};\\\", \\\"{x:1474,y:981,t:1528139843473};\\\", \\\"{x:1474,y:980,t:1528139843487};\\\", \\\"{x:1474,y:977,t:1528139843502};\\\", \\\"{x:1473,y:975,t:1528139843519};\\\", \\\"{x:1471,y:973,t:1528139843537};\\\", \\\"{x:1469,y:973,t:1528139843554};\\\", \\\"{x:1468,y:972,t:1528139843593};\\\", \\\"{x:1466,y:972,t:1528139843650};\\\", \\\"{x:1464,y:971,t:1528139843665};\\\", \\\"{x:1463,y:970,t:1528139843674};\\\", \\\"{x:1462,y:969,t:1528139843690};\\\", \\\"{x:1461,y:969,t:1528139843704};\\\", \\\"{x:1459,y:968,t:1528139843721};\\\", \\\"{x:1455,y:967,t:1528139843737};\\\", \\\"{x:1454,y:966,t:1528139843754};\\\", \\\"{x:1453,y:966,t:1528139843770};\\\", \\\"{x:1451,y:966,t:1528139843788};\\\", \\\"{x:1450,y:966,t:1528139843843};\\\", \\\"{x:1449,y:966,t:1528139843858};\\\", \\\"{x:1448,y:965,t:1528139843963};\\\", \\\"{x:1448,y:964,t:1528139844002};\\\", \\\"{x:1447,y:964,t:1528139844250};\\\", \\\"{x:1446,y:964,t:1528139845666};\\\", \\\"{x:1444,y:962,t:1528139845679};\\\", \\\"{x:1435,y:960,t:1528139845696};\\\", \\\"{x:1427,y:958,t:1528139845714};\\\", \\\"{x:1425,y:958,t:1528139845729};\\\", \\\"{x:1421,y:957,t:1528139845746};\\\", \\\"{x:1420,y:956,t:1528139845770};\\\", \\\"{x:1419,y:956,t:1528139845779};\\\", \\\"{x:1417,y:955,t:1528139845946};\\\", \\\"{x:1407,y:930,t:1528139845964};\\\", \\\"{x:1392,y:884,t:1528139845979};\\\", \\\"{x:1378,y:855,t:1528139845996};\\\", \\\"{x:1369,y:834,t:1528139846013};\\\", \\\"{x:1361,y:815,t:1528139846030};\\\", \\\"{x:1357,y:801,t:1528139846046};\\\", \\\"{x:1353,y:787,t:1528139846063};\\\", \\\"{x:1352,y:779,t:1528139846080};\\\", \\\"{x:1352,y:770,t:1528139846097};\\\", \\\"{x:1349,y:767,t:1528139846113};\\\", \\\"{x:1349,y:764,t:1528139846329};\\\", \\\"{x:1349,y:763,t:1528139846337};\\\", \\\"{x:1349,y:761,t:1528139846349};\\\", \\\"{x:1349,y:760,t:1528139846365};\\\", \\\"{x:1349,y:759,t:1528139846382};\\\", \\\"{x:1349,y:769,t:1528139850667};\\\", \\\"{x:1349,y:782,t:1528139850683};\\\", \\\"{x:1348,y:785,t:1528139850700};\\\", \\\"{x:1348,y:786,t:1528139850730};\\\", \\\"{x:1348,y:780,t:1528139851074};\\\", \\\"{x:1348,y:777,t:1528139851085};\\\", \\\"{x:1348,y:775,t:1528139851102};\\\", \\\"{x:1347,y:774,t:1528139851118};\\\", \\\"{x:1347,y:773,t:1528139851135};\\\", \\\"{x:1347,y:771,t:1528139851218};\\\", \\\"{x:1347,y:767,t:1528139851236};\\\", \\\"{x:1347,y:765,t:1528139851252};\\\", \\\"{x:1345,y:761,t:1528139851269};\\\", \\\"{x:1345,y:759,t:1528139851286};\\\", \\\"{x:1349,y:768,t:1528139851794};\\\", \\\"{x:1354,y:777,t:1528139851806};\\\", \\\"{x:1363,y:791,t:1528139851821};\\\", \\\"{x:1371,y:806,t:1528139851838};\\\", \\\"{x:1377,y:818,t:1528139851856};\\\", \\\"{x:1387,y:835,t:1528139851872};\\\", \\\"{x:1393,y:848,t:1528139851888};\\\", \\\"{x:1398,y:856,t:1528139851905};\\\", \\\"{x:1402,y:861,t:1528139851922};\\\", \\\"{x:1402,y:863,t:1528139851940};\\\", \\\"{x:1403,y:864,t:1528139851955};\\\", \\\"{x:1405,y:866,t:1528139851972};\\\", \\\"{x:1406,y:868,t:1528139851989};\\\", \\\"{x:1408,y:870,t:1528139852005};\\\", \\\"{x:1408,y:873,t:1528139852022};\\\", \\\"{x:1411,y:877,t:1528139852039};\\\", \\\"{x:1415,y:888,t:1528139852056};\\\", \\\"{x:1426,y:907,t:1528139852072};\\\", \\\"{x:1437,y:930,t:1528139852089};\\\", \\\"{x:1455,y:962,t:1528139852106};\\\", \\\"{x:1461,y:972,t:1528139852123};\\\", \\\"{x:1461,y:974,t:1528139852139};\\\", \\\"{x:1462,y:975,t:1528139852186};\\\", \\\"{x:1463,y:976,t:1528139852202};\\\", \\\"{x:1464,y:976,t:1528139852209};\\\", \\\"{x:1464,y:977,t:1528139852223};\\\", \\\"{x:1464,y:978,t:1528139852240};\\\", \\\"{x:1464,y:980,t:1528139852257};\\\", \\\"{x:1466,y:982,t:1528139852273};\\\", \\\"{x:1466,y:984,t:1528139852290};\\\", \\\"{x:1466,y:986,t:1528139852308};\\\", \\\"{x:1466,y:978,t:1528139852450};\\\", \\\"{x:1464,y:971,t:1528139852457};\\\", \\\"{x:1461,y:959,t:1528139852475};\\\", \\\"{x:1459,y:953,t:1528139852491};\\\", \\\"{x:1457,y:949,t:1528139852508};\\\", \\\"{x:1456,y:946,t:1528139852524};\\\", \\\"{x:1456,y:944,t:1528139852542};\\\", \\\"{x:1456,y:943,t:1528139852569};\\\", \\\"{x:1454,y:940,t:1528139852610};\\\", \\\"{x:1452,y:935,t:1528139852625};\\\", \\\"{x:1442,y:913,t:1528139852641};\\\", \\\"{x:1430,y:885,t:1528139852658};\\\", \\\"{x:1399,y:838,t:1528139852674};\\\", \\\"{x:1383,y:811,t:1528139852691};\\\", \\\"{x:1377,y:799,t:1528139852708};\\\", \\\"{x:1374,y:794,t:1528139852725};\\\", \\\"{x:1373,y:792,t:1528139852742};\\\", \\\"{x:1371,y:789,t:1528139852758};\\\", \\\"{x:1371,y:788,t:1528139852775};\\\", \\\"{x:1369,y:785,t:1528139852791};\\\", \\\"{x:1368,y:784,t:1528139852809};\\\", \\\"{x:1367,y:782,t:1528139852826};\\\", \\\"{x:1366,y:779,t:1528139852842};\\\", \\\"{x:1364,y:775,t:1528139852859};\\\", \\\"{x:1362,y:771,t:1528139852875};\\\", \\\"{x:1361,y:767,t:1528139852892};\\\", \\\"{x:1358,y:763,t:1528139852909};\\\", \\\"{x:1354,y:758,t:1528139852926};\\\", \\\"{x:1352,y:753,t:1528139852943};\\\", \\\"{x:1349,y:750,t:1528139852959};\\\", \\\"{x:1346,y:747,t:1528139852975};\\\", \\\"{x:1346,y:746,t:1528139852993};\\\", \\\"{x:1344,y:746,t:1528139854090};\\\", \\\"{x:1343,y:746,t:1528139858050};\\\", \\\"{x:1335,y:748,t:1528139858065};\\\", \\\"{x:1326,y:756,t:1528139858082};\\\", \\\"{x:1325,y:758,t:1528139858098};\\\", \\\"{x:1326,y:758,t:1528139858370};\\\", \\\"{x:1330,y:756,t:1528139858382};\\\", \\\"{x:1334,y:754,t:1528139858399};\\\", \\\"{x:1338,y:753,t:1528139858416};\\\", \\\"{x:1339,y:752,t:1528139858432};\\\", \\\"{x:1340,y:752,t:1528139858514};\\\", \\\"{x:1343,y:755,t:1528139858538};\\\", \\\"{x:1345,y:758,t:1528139858550};\\\", \\\"{x:1346,y:760,t:1528139858566};\\\", \\\"{x:1346,y:761,t:1528139858583};\\\", \\\"{x:1347,y:761,t:1528139858634};\\\", \\\"{x:1347,y:762,t:1528139858914};\\\", \\\"{x:1344,y:762,t:1528139858922};\\\", \\\"{x:1342,y:764,t:1528139858934};\\\", \\\"{x:1339,y:768,t:1528139858953};\\\", \\\"{x:1337,y:770,t:1528139858969};\\\", \\\"{x:1336,y:773,t:1528139858985};\\\", \\\"{x:1335,y:775,t:1528139859001};\\\", \\\"{x:1335,y:776,t:1528139859018};\\\", \\\"{x:1334,y:776,t:1528139859035};\\\", \\\"{x:1333,y:777,t:1528139859057};\\\", \\\"{x:1332,y:778,t:1528139859069};\\\", \\\"{x:1330,y:780,t:1528139859085};\\\", \\\"{x:1330,y:782,t:1528139859102};\\\", \\\"{x:1328,y:786,t:1528139859118};\\\", \\\"{x:1326,y:789,t:1528139859135};\\\", \\\"{x:1323,y:795,t:1528139859152};\\\", \\\"{x:1318,y:807,t:1528139859170};\\\", \\\"{x:1318,y:815,t:1528139859185};\\\", \\\"{x:1315,y:826,t:1528139859202};\\\", \\\"{x:1313,y:838,t:1528139859219};\\\", \\\"{x:1312,y:848,t:1528139859237};\\\", \\\"{x:1310,y:855,t:1528139859253};\\\", \\\"{x:1309,y:863,t:1528139859269};\\\", \\\"{x:1309,y:866,t:1528139859286};\\\", \\\"{x:1309,y:870,t:1528139859303};\\\", \\\"{x:1308,y:873,t:1528139859319};\\\", \\\"{x:1305,y:879,t:1528139859336};\\\", \\\"{x:1305,y:886,t:1528139859352};\\\", \\\"{x:1304,y:893,t:1528139859370};\\\", \\\"{x:1301,y:901,t:1528139859386};\\\", \\\"{x:1301,y:907,t:1528139859403};\\\", \\\"{x:1300,y:915,t:1528139859420};\\\", \\\"{x:1298,y:923,t:1528139859435};\\\", \\\"{x:1296,y:928,t:1528139859453};\\\", \\\"{x:1293,y:935,t:1528139859470};\\\", \\\"{x:1290,y:942,t:1528139859487};\\\", \\\"{x:1290,y:944,t:1528139859503};\\\", \\\"{x:1289,y:944,t:1528139859520};\\\", \\\"{x:1289,y:945,t:1528139859537};\\\", \\\"{x:1287,y:948,t:1528139859553};\\\", \\\"{x:1284,y:950,t:1528139859570};\\\", \\\"{x:1280,y:953,t:1528139859587};\\\", \\\"{x:1277,y:956,t:1528139859604};\\\", \\\"{x:1270,y:961,t:1528139859622};\\\", \\\"{x:1265,y:964,t:1528139859638};\\\", \\\"{x:1258,y:968,t:1528139859655};\\\", \\\"{x:1255,y:971,t:1528139859671};\\\", \\\"{x:1250,y:975,t:1528139859687};\\\", \\\"{x:1245,y:979,t:1528139859704};\\\", \\\"{x:1242,y:981,t:1528139859721};\\\", \\\"{x:1241,y:981,t:1528139859738};\\\", \\\"{x:1240,y:981,t:1528139859850};\\\", \\\"{x:1239,y:981,t:1528139859960};\\\", \\\"{x:1238,y:981,t:1528139859976};\\\", \\\"{x:1236,y:981,t:1528139859989};\\\", \\\"{x:1236,y:977,t:1528139860006};\\\", \\\"{x:1236,y:970,t:1528139860021};\\\", \\\"{x:1236,y:964,t:1528139860039};\\\", \\\"{x:1236,y:957,t:1528139860056};\\\", \\\"{x:1236,y:952,t:1528139860072};\\\", \\\"{x:1236,y:950,t:1528139860089};\\\", \\\"{x:1236,y:949,t:1528139860105};\\\", \\\"{x:1236,y:948,t:1528139860122};\\\", \\\"{x:1236,y:947,t:1528139860194};\\\", \\\"{x:1234,y:947,t:1528139860378};\\\", \\\"{x:1232,y:947,t:1528139860390};\\\", \\\"{x:1229,y:948,t:1528139860406};\\\", \\\"{x:1222,y:950,t:1528139860424};\\\", \\\"{x:1217,y:951,t:1528139860440};\\\", \\\"{x:1216,y:952,t:1528139860457};\\\", \\\"{x:1215,y:952,t:1528139860545};\\\", \\\"{x:1214,y:952,t:1528139860569};\\\", \\\"{x:1213,y:952,t:1528139860585};\\\", \\\"{x:1212,y:953,t:1528139860602};\\\", \\\"{x:1211,y:953,t:1528139861890};\\\", \\\"{x:1211,y:951,t:1528139861898};\\\", \\\"{x:1211,y:949,t:1528139861914};\\\", \\\"{x:1211,y:946,t:1528139861931};\\\", \\\"{x:1211,y:943,t:1528139861948};\\\", \\\"{x:1211,y:941,t:1528139861964};\\\", \\\"{x:1211,y:937,t:1528139861980};\\\", \\\"{x:1212,y:934,t:1528139861997};\\\", \\\"{x:1213,y:932,t:1528139862015};\\\", \\\"{x:1213,y:931,t:1528139862049};\\\", \\\"{x:1214,y:931,t:1528139862122};\\\", \\\"{x:1215,y:930,t:1528139862145};\\\", \\\"{x:1215,y:929,t:1528139862154};\\\", \\\"{x:1216,y:929,t:1528139862166};\\\", \\\"{x:1216,y:928,t:1528139862181};\\\", \\\"{x:1217,y:926,t:1528139862198};\\\", \\\"{x:1219,y:924,t:1528139862216};\\\", \\\"{x:1220,y:922,t:1528139862231};\\\", \\\"{x:1220,y:921,t:1528139862257};\\\", \\\"{x:1220,y:920,t:1528139862458};\\\", \\\"{x:1220,y:919,t:1528139862466};\\\", \\\"{x:1222,y:917,t:1528139862483};\\\", \\\"{x:1223,y:915,t:1528139862500};\\\", \\\"{x:1225,y:915,t:1528139862516};\\\", \\\"{x:1225,y:914,t:1528139862537};\\\", \\\"{x:1226,y:914,t:1528139862594};\\\", \\\"{x:1227,y:913,t:1528139862617};\\\", \\\"{x:1228,y:912,t:1528139862634};\\\", \\\"{x:1230,y:911,t:1528139862665};\\\", \\\"{x:1230,y:910,t:1528139862673};\\\", \\\"{x:1231,y:909,t:1528139862682};\\\", \\\"{x:1233,y:907,t:1528139862700};\\\", \\\"{x:1233,y:906,t:1528139862717};\\\", \\\"{x:1234,y:905,t:1528139862733};\\\", \\\"{x:1235,y:904,t:1528139862761};\\\", \\\"{x:1236,y:903,t:1528139862785};\\\", \\\"{x:1237,y:903,t:1528139862817};\\\", \\\"{x:1238,y:902,t:1528139862865};\\\", \\\"{x:1240,y:901,t:1528139862889};\\\", \\\"{x:1241,y:901,t:1528139862902};\\\", \\\"{x:1242,y:898,t:1528139862918};\\\", \\\"{x:1244,y:895,t:1528139862934};\\\", \\\"{x:1245,y:893,t:1528139862951};\\\", \\\"{x:1246,y:892,t:1528139862968};\\\", \\\"{x:1247,y:891,t:1528139862986};\\\", \\\"{x:1248,y:890,t:1528139863001};\\\", \\\"{x:1248,y:889,t:1528139863194};\\\", \\\"{x:1248,y:888,t:1528139863203};\\\", \\\"{x:1249,y:887,t:1528139863219};\\\", \\\"{x:1250,y:887,t:1528139863250};\\\", \\\"{x:1253,y:887,t:1528139865130};\\\", \\\"{x:1265,y:881,t:1528139865145};\\\", \\\"{x:1282,y:872,t:1528139865161};\\\", \\\"{x:1291,y:867,t:1528139865177};\\\", \\\"{x:1299,y:864,t:1528139865195};\\\", \\\"{x:1310,y:859,t:1528139865212};\\\", \\\"{x:1328,y:853,t:1528139865228};\\\", \\\"{x:1341,y:851,t:1528139865244};\\\", \\\"{x:1349,y:849,t:1528139865262};\\\", \\\"{x:1351,y:849,t:1528139865277};\\\", \\\"{x:1352,y:848,t:1528139865295};\\\", \\\"{x:1353,y:848,t:1528139865311};\\\", \\\"{x:1354,y:847,t:1528139865329};\\\", \\\"{x:1356,y:846,t:1528139865345};\\\", \\\"{x:1365,y:843,t:1528139865361};\\\", \\\"{x:1370,y:841,t:1528139865378};\\\", \\\"{x:1374,y:841,t:1528139865396};\\\", \\\"{x:1384,y:841,t:1528139865411};\\\", \\\"{x:1403,y:841,t:1528139865428};\\\", \\\"{x:1421,y:841,t:1528139865445};\\\", \\\"{x:1436,y:842,t:1528139865462};\\\", \\\"{x:1454,y:842,t:1528139865478};\\\", \\\"{x:1469,y:840,t:1528139865495};\\\", \\\"{x:1487,y:834,t:1528139865513};\\\", \\\"{x:1493,y:830,t:1528139865528};\\\", \\\"{x:1497,y:827,t:1528139865545};\\\", \\\"{x:1503,y:824,t:1528139865562};\\\", \\\"{x:1514,y:819,t:1528139865579};\\\", \\\"{x:1521,y:817,t:1528139865595};\\\", \\\"{x:1528,y:814,t:1528139865613};\\\", \\\"{x:1532,y:812,t:1528139865629};\\\", \\\"{x:1537,y:811,t:1528139865646};\\\", \\\"{x:1539,y:811,t:1528139865662};\\\", \\\"{x:1537,y:811,t:1528139865818};\\\", \\\"{x:1535,y:811,t:1528139865831};\\\", \\\"{x:1526,y:812,t:1528139865848};\\\", \\\"{x:1519,y:816,t:1528139865863};\\\", \\\"{x:1514,y:818,t:1528139865880};\\\", \\\"{x:1511,y:820,t:1528139865897};\\\", \\\"{x:1509,y:820,t:1528139865913};\\\", \\\"{x:1507,y:821,t:1528139865930};\\\", \\\"{x:1506,y:821,t:1528139865947};\\\", \\\"{x:1505,y:821,t:1528139865964};\\\", \\\"{x:1505,y:822,t:1528139865981};\\\", \\\"{x:1504,y:822,t:1528139866009};\\\", \\\"{x:1503,y:822,t:1528139866042};\\\", \\\"{x:1502,y:822,t:1528139866082};\\\", \\\"{x:1500,y:823,t:1528139866098};\\\", \\\"{x:1497,y:825,t:1528139866115};\\\", \\\"{x:1494,y:826,t:1528139866132};\\\", \\\"{x:1488,y:829,t:1528139866148};\\\", \\\"{x:1483,y:830,t:1528139866165};\\\", \\\"{x:1481,y:831,t:1528139866182};\\\", \\\"{x:1480,y:832,t:1528139866198};\\\", \\\"{x:1480,y:837,t:1528139866563};\\\", \\\"{x:1484,y:857,t:1528139866569};\\\", \\\"{x:1489,y:867,t:1528139866584};\\\", \\\"{x:1501,y:883,t:1528139866601};\\\", \\\"{x:1517,y:901,t:1528139866617};\\\", \\\"{x:1537,y:921,t:1528139866634};\\\", \\\"{x:1551,y:935,t:1528139866651};\\\", \\\"{x:1560,y:943,t:1528139866668};\\\", \\\"{x:1565,y:947,t:1528139866684};\\\", \\\"{x:1570,y:951,t:1528139866701};\\\", \\\"{x:1571,y:951,t:1528139866718};\\\", \\\"{x:1572,y:952,t:1528139866735};\\\", \\\"{x:1574,y:953,t:1528139866750};\\\", \\\"{x:1575,y:953,t:1528139866786};\\\", \\\"{x:1576,y:954,t:1528139866842};\\\", \\\"{x:1576,y:956,t:1528139866866};\\\", \\\"{x:1576,y:958,t:1528139866874};\\\", \\\"{x:1576,y:960,t:1528139866884};\\\", \\\"{x:1576,y:963,t:1528139866902};\\\", \\\"{x:1572,y:965,t:1528139866919};\\\", \\\"{x:1569,y:966,t:1528139866934};\\\", \\\"{x:1567,y:966,t:1528139866954};\\\", \\\"{x:1566,y:966,t:1528139867010};\\\", \\\"{x:1564,y:966,t:1528139867025};\\\", \\\"{x:1563,y:966,t:1528139867050};\\\", \\\"{x:1561,y:966,t:1528139867065};\\\", \\\"{x:1558,y:966,t:1528139867073};\\\", \\\"{x:1557,y:969,t:1528139867086};\\\", \\\"{x:1555,y:972,t:1528139867103};\\\", \\\"{x:1553,y:975,t:1528139867119};\\\", \\\"{x:1553,y:971,t:1528139867249};\\\", \\\"{x:1553,y:968,t:1528139867258};\\\", \\\"{x:1553,y:966,t:1528139867270};\\\", \\\"{x:1553,y:965,t:1528139867286};\\\", \\\"{x:1553,y:964,t:1528139867304};\\\", \\\"{x:1553,y:963,t:1528139867320};\\\", \\\"{x:1555,y:963,t:1528139867353};\\\", \\\"{x:1556,y:963,t:1528139867370};\\\", \\\"{x:1558,y:963,t:1528139867387};\\\", \\\"{x:1560,y:961,t:1528139867404};\\\", \\\"{x:1561,y:961,t:1528139867420};\\\", \\\"{x:1563,y:960,t:1528139867436};\\\", \\\"{x:1565,y:958,t:1528139867454};\\\", \\\"{x:1569,y:953,t:1528139867470};\\\", \\\"{x:1572,y:950,t:1528139867487};\\\", \\\"{x:1573,y:948,t:1528139867503};\\\", \\\"{x:1574,y:947,t:1528139867521};\\\", \\\"{x:1575,y:947,t:1528139867537};\\\", \\\"{x:1576,y:947,t:1528139867562};\\\", \\\"{x:1580,y:944,t:1528139867978};\\\", \\\"{x:1581,y:940,t:1528139867989};\\\", \\\"{x:1584,y:936,t:1528139868006};\\\", \\\"{x:1586,y:934,t:1528139868022};\\\", \\\"{x:1591,y:932,t:1528139868039};\\\", \\\"{x:1593,y:932,t:1528139868081};\\\", \\\"{x:1594,y:932,t:1528139868114};\\\", \\\"{x:1596,y:932,t:1528139868124};\\\", \\\"{x:1597,y:932,t:1528139868154};\\\", \\\"{x:1597,y:931,t:1528139868162};\\\", \\\"{x:1598,y:930,t:1528139868177};\\\", \\\"{x:1600,y:929,t:1528139868191};\\\", \\\"{x:1601,y:928,t:1528139868206};\\\", \\\"{x:1604,y:926,t:1528139868223};\\\", \\\"{x:1606,y:925,t:1528139868241};\\\", \\\"{x:1609,y:925,t:1528139868257};\\\", \\\"{x:1610,y:925,t:1528139868274};\\\", \\\"{x:1612,y:925,t:1528139868291};\\\", \\\"{x:1614,y:925,t:1528139868307};\\\", \\\"{x:1615,y:925,t:1528139868323};\\\", \\\"{x:1616,y:925,t:1528139868341};\\\", \\\"{x:1617,y:925,t:1528139868458};\\\", \\\"{x:1618,y:925,t:1528139868714};\\\", \\\"{x:1618,y:926,t:1528139868802};\\\", \\\"{x:1618,y:925,t:1528139869402};\\\", \\\"{x:1614,y:915,t:1528139869412};\\\", \\\"{x:1607,y:900,t:1528139869429};\\\", \\\"{x:1601,y:889,t:1528139869445};\\\", \\\"{x:1595,y:882,t:1528139869463};\\\", \\\"{x:1592,y:878,t:1528139869479};\\\", \\\"{x:1591,y:877,t:1528139869495};\\\", \\\"{x:1590,y:876,t:1528139869513};\\\", \\\"{x:1588,y:875,t:1528139869529};\\\", \\\"{x:1584,y:869,t:1528139869545};\\\", \\\"{x:1579,y:861,t:1528139869563};\\\", \\\"{x:1568,y:850,t:1528139869580};\\\", \\\"{x:1555,y:839,t:1528139869595};\\\", \\\"{x:1542,y:830,t:1528139869613};\\\", \\\"{x:1527,y:820,t:1528139869630};\\\", \\\"{x:1512,y:812,t:1528139869646};\\\", \\\"{x:1494,y:803,t:1528139869662};\\\", \\\"{x:1472,y:798,t:1528139869680};\\\", \\\"{x:1447,y:797,t:1528139869697};\\\", \\\"{x:1410,y:804,t:1528139869714};\\\", \\\"{x:1379,y:818,t:1528139869730};\\\", \\\"{x:1336,y:843,t:1528139869746};\\\", \\\"{x:1287,y:872,t:1528139869764};\\\", \\\"{x:1255,y:896,t:1528139869781};\\\", \\\"{x:1232,y:911,t:1528139869796};\\\", \\\"{x:1219,y:919,t:1528139869814};\\\", \\\"{x:1213,y:924,t:1528139869831};\\\", \\\"{x:1211,y:926,t:1528139869848};\\\", \\\"{x:1209,y:926,t:1528139869864};\\\", \\\"{x:1209,y:928,t:1528139869881};\\\", \\\"{x:1209,y:932,t:1528139869897};\\\", \\\"{x:1209,y:936,t:1528139869916};\\\", \\\"{x:1209,y:938,t:1528139869930};\\\", \\\"{x:1207,y:944,t:1528139869947};\\\", \\\"{x:1206,y:949,t:1528139869964};\\\", \\\"{x:1206,y:957,t:1528139869980};\\\", \\\"{x:1206,y:967,t:1528139869997};\\\", \\\"{x:1206,y:976,t:1528139870014};\\\", \\\"{x:1206,y:980,t:1528139870031};\\\", \\\"{x:1206,y:982,t:1528139870047};\\\", \\\"{x:1210,y:973,t:1528139870177};\\\", \\\"{x:1212,y:968,t:1528139870186};\\\", \\\"{x:1215,y:963,t:1528139870199};\\\", \\\"{x:1219,y:956,t:1528139870216};\\\", \\\"{x:1222,y:952,t:1528139870232};\\\", \\\"{x:1224,y:950,t:1528139870249};\\\", \\\"{x:1228,y:948,t:1528139870265};\\\", \\\"{x:1231,y:945,t:1528139870282};\\\", \\\"{x:1234,y:942,t:1528139870299};\\\", \\\"{x:1238,y:937,t:1528139870315};\\\", \\\"{x:1242,y:930,t:1528139870332};\\\", \\\"{x:1245,y:919,t:1528139870350};\\\", \\\"{x:1250,y:909,t:1528139870365};\\\", \\\"{x:1254,y:901,t:1528139870382};\\\", \\\"{x:1259,y:892,t:1528139870400};\\\", \\\"{x:1262,y:887,t:1528139870417};\\\", \\\"{x:1266,y:880,t:1528139870433};\\\", \\\"{x:1268,y:878,t:1528139870450};\\\", \\\"{x:1270,y:876,t:1528139870467};\\\", \\\"{x:1271,y:875,t:1528139870484};\\\", \\\"{x:1273,y:872,t:1528139870500};\\\", \\\"{x:1275,y:870,t:1528139870517};\\\", \\\"{x:1279,y:865,t:1528139870534};\\\", \\\"{x:1284,y:856,t:1528139870549};\\\", \\\"{x:1288,y:848,t:1528139870566};\\\", \\\"{x:1292,y:838,t:1528139870583};\\\", \\\"{x:1295,y:831,t:1528139870602};\\\", \\\"{x:1296,y:827,t:1528139870617};\\\", \\\"{x:1299,y:819,t:1528139870634};\\\", \\\"{x:1301,y:815,t:1528139870651};\\\", \\\"{x:1302,y:810,t:1528139870668};\\\", \\\"{x:1304,y:808,t:1528139870684};\\\", \\\"{x:1304,y:806,t:1528139870701};\\\", \\\"{x:1305,y:805,t:1528139870718};\\\", \\\"{x:1305,y:804,t:1528139870761};\\\", \\\"{x:1306,y:803,t:1528139870769};\\\", \\\"{x:1306,y:802,t:1528139870842};\\\", \\\"{x:1307,y:801,t:1528139870857};\\\", \\\"{x:1307,y:800,t:1528139871378};\\\", \\\"{x:1307,y:794,t:1528139871387};\\\", \\\"{x:1309,y:784,t:1528139871404};\\\", \\\"{x:1310,y:778,t:1528139871420};\\\", \\\"{x:1312,y:772,t:1528139871436};\\\", \\\"{x:1313,y:766,t:1528139871454};\\\", \\\"{x:1314,y:764,t:1528139871470};\\\", \\\"{x:1316,y:758,t:1528139871488};\\\", \\\"{x:1320,y:750,t:1528139871503};\\\", \\\"{x:1330,y:732,t:1528139871521};\\\", \\\"{x:1335,y:722,t:1528139871537};\\\", \\\"{x:1339,y:706,t:1528139871555};\\\", \\\"{x:1344,y:689,t:1528139871570};\\\", \\\"{x:1348,y:678,t:1528139871588};\\\", \\\"{x:1354,y:669,t:1528139871605};\\\", \\\"{x:1358,y:660,t:1528139871622};\\\", \\\"{x:1363,y:654,t:1528139871638};\\\", \\\"{x:1364,y:650,t:1528139871655};\\\", \\\"{x:1366,y:647,t:1528139871671};\\\", \\\"{x:1370,y:643,t:1528139871689};\\\", \\\"{x:1373,y:639,t:1528139871705};\\\", \\\"{x:1374,y:636,t:1528139871722};\\\", \\\"{x:1377,y:632,t:1528139871739};\\\", \\\"{x:1382,y:626,t:1528139871754};\\\", \\\"{x:1386,y:619,t:1528139871771};\\\", \\\"{x:1389,y:613,t:1528139871788};\\\", \\\"{x:1391,y:609,t:1528139871805};\\\", \\\"{x:1393,y:605,t:1528139871821};\\\", \\\"{x:1394,y:602,t:1528139871839};\\\", \\\"{x:1395,y:598,t:1528139871855};\\\", \\\"{x:1398,y:590,t:1528139871873};\\\", \\\"{x:1399,y:586,t:1528139871888};\\\", \\\"{x:1400,y:584,t:1528139871905};\\\", \\\"{x:1400,y:583,t:1528139871929};\\\", \\\"{x:1400,y:582,t:1528139871961};\\\", \\\"{x:1401,y:580,t:1528139872010};\\\", \\\"{x:1402,y:579,t:1528139872025};\\\", \\\"{x:1404,y:577,t:1528139872041};\\\", \\\"{x:1405,y:573,t:1528139872057};\\\", \\\"{x:1410,y:566,t:1528139872073};\\\", \\\"{x:1413,y:560,t:1528139872090};\\\", \\\"{x:1415,y:556,t:1528139872105};\\\", \\\"{x:1417,y:553,t:1528139872121};\\\", \\\"{x:1420,y:550,t:1528139872139};\\\", \\\"{x:1421,y:548,t:1528139872155};\\\", \\\"{x:1423,y:548,t:1528139872172};\\\", \\\"{x:1422,y:548,t:1528139872895};\\\", \\\"{x:1420,y:549,t:1528139872908};\\\", \\\"{x:1419,y:550,t:1528139872924};\\\", \\\"{x:1418,y:552,t:1528139872942};\\\", \\\"{x:1418,y:553,t:1528139872967};\\\", \\\"{x:1418,y:554,t:1528139874200};\\\", \\\"{x:1418,y:555,t:1528139874231};\\\", \\\"{x:1418,y:557,t:1528139874367};\\\", \\\"{x:1418,y:559,t:1528139874381};\\\", \\\"{x:1418,y:562,t:1528139874398};\\\", \\\"{x:1420,y:567,t:1528139874416};\\\", \\\"{x:1420,y:568,t:1528139874430};\\\", \\\"{x:1420,y:569,t:1528139874447};\\\", \\\"{x:1422,y:572,t:1528139874528};\\\", \\\"{x:1423,y:577,t:1528139874535};\\\", \\\"{x:1427,y:584,t:1528139874548};\\\", \\\"{x:1435,y:599,t:1528139874565};\\\", \\\"{x:1444,y:620,t:1528139874582};\\\", \\\"{x:1459,y:655,t:1528139874599};\\\", \\\"{x:1464,y:671,t:1528139874615};\\\", \\\"{x:1466,y:679,t:1528139874632};\\\", \\\"{x:1467,y:682,t:1528139874648};\\\", \\\"{x:1467,y:683,t:1528139874666};\\\", \\\"{x:1467,y:684,t:1528139874682};\\\", \\\"{x:1463,y:684,t:1528139874699};\\\", \\\"{x:1433,y:674,t:1528139874716};\\\", \\\"{x:1383,y:653,t:1528139874733};\\\", \\\"{x:1336,y:639,t:1528139874749};\\\", \\\"{x:1293,y:632,t:1528139874766};\\\", \\\"{x:1137,y:612,t:1528139874783};\\\", \\\"{x:999,y:595,t:1528139874799};\\\", \\\"{x:869,y:576,t:1528139874817};\\\", \\\"{x:749,y:574,t:1528139874833};\\\", \\\"{x:652,y:575,t:1528139874849};\\\", \\\"{x:566,y:588,t:1528139874871};\\\", \\\"{x:547,y:591,t:1528139874888};\\\", \\\"{x:541,y:592,t:1528139874904};\\\", \\\"{x:544,y:589,t:1528139875080};\\\", \\\"{x:559,y:583,t:1528139875089};\\\", \\\"{x:598,y:566,t:1528139875105};\\\", \\\"{x:626,y:553,t:1528139875123};\\\", \\\"{x:653,y:542,t:1528139875138};\\\", \\\"{x:683,y:533,t:1528139875155};\\\", \\\"{x:718,y:527,t:1528139875171};\\\", \\\"{x:766,y:521,t:1528139875189};\\\", \\\"{x:806,y:519,t:1528139875205};\\\", \\\"{x:837,y:519,t:1528139875221};\\\", \\\"{x:877,y:519,t:1528139875238};\\\", \\\"{x:892,y:518,t:1528139875255};\\\", \\\"{x:912,y:518,t:1528139875271};\\\", \\\"{x:944,y:519,t:1528139875288};\\\", \\\"{x:984,y:531,t:1528139875305};\\\", \\\"{x:1004,y:540,t:1528139875321};\\\", \\\"{x:1027,y:553,t:1528139875338};\\\", \\\"{x:1064,y:576,t:1528139875356};\\\", \\\"{x:1119,y:599,t:1528139875372};\\\", \\\"{x:1172,y:622,t:1528139875389};\\\", \\\"{x:1199,y:629,t:1528139875405};\\\", \\\"{x:1226,y:636,t:1528139875421};\\\", \\\"{x:1262,y:639,t:1528139875438};\\\", \\\"{x:1284,y:639,t:1528139875455};\\\", \\\"{x:1317,y:639,t:1528139875471};\\\", \\\"{x:1358,y:639,t:1528139875488};\\\", \\\"{x:1400,y:639,t:1528139875505};\\\", \\\"{x:1440,y:639,t:1528139875522};\\\", \\\"{x:1489,y:644,t:1528139875538};\\\", \\\"{x:1536,y:656,t:1528139875556};\\\", \\\"{x:1569,y:666,t:1528139875573};\\\", \\\"{x:1586,y:674,t:1528139875588};\\\", \\\"{x:1588,y:676,t:1528139875605};\\\", \\\"{x:1589,y:676,t:1528139875664};\\\", \\\"{x:1589,y:677,t:1528139875673};\\\", \\\"{x:1588,y:677,t:1528139875689};\\\", \\\"{x:1586,y:677,t:1528139875706};\\\", \\\"{x:1585,y:678,t:1528139875723};\\\", \\\"{x:1581,y:679,t:1528139875739};\\\", \\\"{x:1573,y:679,t:1528139875756};\\\", \\\"{x:1566,y:682,t:1528139875773};\\\", \\\"{x:1560,y:685,t:1528139875789};\\\", \\\"{x:1552,y:688,t:1528139875806};\\\", \\\"{x:1539,y:701,t:1528139875823};\\\", \\\"{x:1533,y:706,t:1528139875839};\\\", \\\"{x:1522,y:714,t:1528139875856};\\\", \\\"{x:1510,y:719,t:1528139875873};\\\", \\\"{x:1500,y:722,t:1528139875889};\\\", \\\"{x:1496,y:723,t:1528139875906};\\\", \\\"{x:1495,y:723,t:1528139875923};\\\", \\\"{x:1490,y:723,t:1528139875939};\\\", \\\"{x:1485,y:723,t:1528139875956};\\\", \\\"{x:1481,y:722,t:1528139875973};\\\", \\\"{x:1475,y:720,t:1528139875988};\\\", \\\"{x:1472,y:719,t:1528139876006};\\\", \\\"{x:1464,y:719,t:1528139876022};\\\", \\\"{x:1461,y:719,t:1528139876040};\\\", \\\"{x:1459,y:719,t:1528139876055};\\\", \\\"{x:1456,y:720,t:1528139876072};\\\", \\\"{x:1454,y:720,t:1528139876167};\\\", \\\"{x:1450,y:709,t:1528139876175};\\\", \\\"{x:1444,y:684,t:1528139876190};\\\", \\\"{x:1440,y:658,t:1528139876206};\\\", \\\"{x:1438,y:629,t:1528139876224};\\\", \\\"{x:1436,y:613,t:1528139876239};\\\", \\\"{x:1434,y:606,t:1528139876256};\\\", \\\"{x:1434,y:605,t:1528139876273};\\\", \\\"{x:1430,y:611,t:1528139876519};\\\", \\\"{x:1423,y:638,t:1528139876527};\\\", \\\"{x:1413,y:663,t:1528139876540};\\\", \\\"{x:1395,y:720,t:1528139876557};\\\", \\\"{x:1367,y:778,t:1528139876573};\\\", \\\"{x:1341,y:820,t:1528139876590};\\\", \\\"{x:1318,y:846,t:1528139876607};\\\", \\\"{x:1311,y:853,t:1528139876623};\\\", \\\"{x:1308,y:856,t:1528139876640};\\\", \\\"{x:1308,y:857,t:1528139876657};\\\", \\\"{x:1308,y:858,t:1528139876672};\\\", \\\"{x:1306,y:861,t:1528139876690};\\\", \\\"{x:1306,y:864,t:1528139876707};\\\", \\\"{x:1304,y:868,t:1528139876723};\\\", \\\"{x:1302,y:874,t:1528139876740};\\\", \\\"{x:1298,y:887,t:1528139876757};\\\", \\\"{x:1292,y:907,t:1528139876773};\\\", \\\"{x:1287,y:932,t:1528139876790};\\\", \\\"{x:1281,y:959,t:1528139876807};\\\", \\\"{x:1280,y:966,t:1528139876823};\\\", \\\"{x:1280,y:967,t:1528139876839};\\\", \\\"{x:1280,y:964,t:1528139876959};\\\", \\\"{x:1282,y:954,t:1528139876974};\\\", \\\"{x:1286,y:941,t:1528139876990};\\\", \\\"{x:1293,y:927,t:1528139877007};\\\", \\\"{x:1298,y:919,t:1528139877024};\\\", \\\"{x:1305,y:910,t:1528139877040};\\\", \\\"{x:1312,y:905,t:1528139877057};\\\", \\\"{x:1318,y:900,t:1528139877074};\\\", \\\"{x:1324,y:893,t:1528139877090};\\\", \\\"{x:1329,y:887,t:1528139877107};\\\", \\\"{x:1335,y:877,t:1528139877124};\\\", \\\"{x:1343,y:864,t:1528139877140};\\\", \\\"{x:1348,y:849,t:1528139877156};\\\", \\\"{x:1358,y:833,t:1528139877174};\\\", \\\"{x:1365,y:817,t:1528139877190};\\\", \\\"{x:1375,y:795,t:1528139877207};\\\", \\\"{x:1383,y:782,t:1528139877224};\\\", \\\"{x:1386,y:775,t:1528139877240};\\\", \\\"{x:1388,y:770,t:1528139877257};\\\", \\\"{x:1391,y:763,t:1528139877274};\\\", \\\"{x:1393,y:760,t:1528139877290};\\\", \\\"{x:1395,y:757,t:1528139877307};\\\", \\\"{x:1396,y:755,t:1528139877324};\\\", \\\"{x:1397,y:753,t:1528139877340};\\\", \\\"{x:1399,y:748,t:1528139877357};\\\", \\\"{x:1403,y:739,t:1528139877374};\\\", \\\"{x:1408,y:720,t:1528139877391};\\\", \\\"{x:1409,y:707,t:1528139877407};\\\", \\\"{x:1413,y:690,t:1528139877424};\\\", \\\"{x:1416,y:680,t:1528139877441};\\\", \\\"{x:1418,y:671,t:1528139877457};\\\", \\\"{x:1422,y:664,t:1528139877474};\\\", \\\"{x:1423,y:661,t:1528139877491};\\\", \\\"{x:1424,y:658,t:1528139877507};\\\", \\\"{x:1425,y:656,t:1528139877524};\\\", \\\"{x:1426,y:655,t:1528139877541};\\\", \\\"{x:1426,y:654,t:1528139877557};\\\", \\\"{x:1428,y:651,t:1528139877574};\\\", \\\"{x:1430,y:647,t:1528139877591};\\\", \\\"{x:1432,y:643,t:1528139877607};\\\", \\\"{x:1433,y:640,t:1528139877624};\\\", \\\"{x:1434,y:636,t:1528139877641};\\\", \\\"{x:1436,y:631,t:1528139877657};\\\", \\\"{x:1437,y:628,t:1528139877674};\\\", \\\"{x:1439,y:625,t:1528139877691};\\\", \\\"{x:1439,y:624,t:1528139877707};\\\", \\\"{x:1439,y:623,t:1528139877807};\\\", \\\"{x:1440,y:622,t:1528139878000};\\\", \\\"{x:1441,y:622,t:1528139878015};\\\", \\\"{x:1442,y:623,t:1528139878024};\\\", \\\"{x:1443,y:624,t:1528139878088};\\\", \\\"{x:1446,y:625,t:1528139878136};\\\", \\\"{x:1446,y:626,t:1528139878158};\\\", \\\"{x:1451,y:627,t:1528139878174};\\\", \\\"{x:1459,y:630,t:1528139878192};\\\", \\\"{x:1466,y:634,t:1528139878208};\\\", \\\"{x:1472,y:639,t:1528139878224};\\\", \\\"{x:1480,y:647,t:1528139878241};\\\", \\\"{x:1490,y:661,t:1528139878258};\\\", \\\"{x:1501,y:680,t:1528139878274};\\\", \\\"{x:1518,y:705,t:1528139878291};\\\", \\\"{x:1534,y:730,t:1528139878308};\\\", \\\"{x:1548,y:748,t:1528139878324};\\\", \\\"{x:1555,y:757,t:1528139878341};\\\", \\\"{x:1557,y:759,t:1528139878358};\\\", \\\"{x:1558,y:760,t:1528139878375};\\\", \\\"{x:1559,y:761,t:1528139878423};\\\", \\\"{x:1560,y:766,t:1528139878431};\\\", \\\"{x:1560,y:768,t:1528139878441};\\\", \\\"{x:1561,y:775,t:1528139878458};\\\", \\\"{x:1564,y:788,t:1528139878475};\\\", \\\"{x:1566,y:805,t:1528139878491};\\\", \\\"{x:1572,y:830,t:1528139878508};\\\", \\\"{x:1574,y:857,t:1528139878525};\\\", \\\"{x:1576,y:880,t:1528139878541};\\\", \\\"{x:1578,y:903,t:1528139878558};\\\", \\\"{x:1582,y:930,t:1528139878576};\\\", \\\"{x:1583,y:940,t:1528139878591};\\\", \\\"{x:1584,y:943,t:1528139878608};\\\", \\\"{x:1585,y:944,t:1528139878655};\\\", \\\"{x:1585,y:946,t:1528139878663};\\\", \\\"{x:1586,y:947,t:1528139878675};\\\", \\\"{x:1588,y:950,t:1528139878691};\\\", \\\"{x:1590,y:955,t:1528139878708};\\\", \\\"{x:1594,y:961,t:1528139878725};\\\", \\\"{x:1602,y:975,t:1528139878741};\\\", \\\"{x:1609,y:987,t:1528139878757};\\\", \\\"{x:1614,y:994,t:1528139878774};\\\", \\\"{x:1615,y:997,t:1528139878791};\\\", \\\"{x:1616,y:998,t:1528139878807};\\\", \\\"{x:1616,y:995,t:1528139878871};\\\", \\\"{x:1616,y:979,t:1528139878878};\\\", \\\"{x:1616,y:956,t:1528139878891};\\\", \\\"{x:1603,y:926,t:1528139878907};\\\", \\\"{x:1599,y:915,t:1528139878925};\\\", \\\"{x:1598,y:914,t:1528139878942};\\\", \\\"{x:1597,y:911,t:1528139878967};\\\", \\\"{x:1597,y:909,t:1528139878983};\\\", \\\"{x:1597,y:908,t:1528139878992};\\\", \\\"{x:1593,y:901,t:1528139879008};\\\", \\\"{x:1583,y:883,t:1528139879025};\\\", \\\"{x:1551,y:838,t:1528139879042};\\\", \\\"{x:1526,y:807,t:1528139879058};\\\", \\\"{x:1523,y:801,t:1528139879075};\\\", \\\"{x:1521,y:797,t:1528139879094};\\\", \\\"{x:1518,y:787,t:1528139879108};\\\", \\\"{x:1508,y:767,t:1528139879124};\\\", \\\"{x:1502,y:750,t:1528139879142};\\\", \\\"{x:1496,y:735,t:1528139879159};\\\", \\\"{x:1486,y:713,t:1528139879175};\\\", \\\"{x:1479,y:706,t:1528139879192};\\\", \\\"{x:1479,y:705,t:1528139879208};\\\", \\\"{x:1477,y:703,t:1528139879303};\\\", \\\"{x:1475,y:696,t:1528139879313};\\\", \\\"{x:1470,y:685,t:1528139879325};\\\", \\\"{x:1459,y:665,t:1528139879341};\\\", \\\"{x:1442,y:633,t:1528139879358};\\\", \\\"{x:1430,y:614,t:1528139879374};\\\", \\\"{x:1416,y:596,t:1528139879392};\\\", \\\"{x:1402,y:582,t:1528139879409};\\\", \\\"{x:1385,y:575,t:1528139879424};\\\", \\\"{x:1354,y:559,t:1528139879442};\\\", \\\"{x:1296,y:546,t:1528139879458};\\\", \\\"{x:1215,y:530,t:1528139879474};\\\", \\\"{x:1116,y:522,t:1528139879491};\\\", \\\"{x:1011,y:522,t:1528139879509};\\\", \\\"{x:916,y:522,t:1528139879525};\\\", \\\"{x:827,y:522,t:1528139879541};\\\", \\\"{x:747,y:522,t:1528139879559};\\\", \\\"{x:726,y:524,t:1528139879574};\\\", \\\"{x:718,y:525,t:1528139879592};\\\", \\\"{x:716,y:525,t:1528139879608};\\\", \\\"{x:714,y:525,t:1528139879625};\\\", \\\"{x:713,y:526,t:1528139879678};\\\", \\\"{x:708,y:528,t:1528139879692};\\\", \\\"{x:699,y:534,t:1528139879708};\\\", \\\"{x:686,y:542,t:1528139879726};\\\", \\\"{x:667,y:554,t:1528139879742};\\\", \\\"{x:655,y:559,t:1528139879759};\\\", \\\"{x:647,y:562,t:1528139879775};\\\", \\\"{x:638,y:564,t:1528139879792};\\\", \\\"{x:625,y:568,t:1528139879809};\\\", \\\"{x:609,y:571,t:1528139879825};\\\", \\\"{x:593,y:573,t:1528139879843};\\\", \\\"{x:575,y:574,t:1528139879859};\\\", \\\"{x:556,y:577,t:1528139879875};\\\", \\\"{x:531,y:577,t:1528139879891};\\\", \\\"{x:504,y:577,t:1528139879909};\\\", \\\"{x:472,y:579,t:1528139879926};\\\", \\\"{x:440,y:579,t:1528139879941};\\\", \\\"{x:382,y:585,t:1528139879959};\\\", \\\"{x:352,y:590,t:1528139879976};\\\", \\\"{x:336,y:595,t:1528139879992};\\\", \\\"{x:323,y:597,t:1528139880008};\\\", \\\"{x:315,y:599,t:1528139880025};\\\", \\\"{x:306,y:599,t:1528139880042};\\\", \\\"{x:300,y:599,t:1528139880059};\\\", \\\"{x:298,y:599,t:1528139880076};\\\", \\\"{x:294,y:598,t:1528139880092};\\\", \\\"{x:288,y:596,t:1528139880108};\\\", \\\"{x:279,y:592,t:1528139880126};\\\", \\\"{x:255,y:586,t:1528139880148};\\\", \\\"{x:245,y:585,t:1528139880158};\\\", \\\"{x:234,y:585,t:1528139880176};\\\", \\\"{x:222,y:585,t:1528139880192};\\\", \\\"{x:205,y:588,t:1528139880208};\\\", \\\"{x:185,y:591,t:1528139880226};\\\", \\\"{x:164,y:593,t:1528139880243};\\\", \\\"{x:148,y:597,t:1528139880259};\\\", \\\"{x:140,y:597,t:1528139880275};\\\", \\\"{x:136,y:597,t:1528139880293};\\\", \\\"{x:135,y:597,t:1528139880407};\\\", \\\"{x:134,y:597,t:1528139880414};\\\", \\\"{x:132,y:597,t:1528139880426};\\\", \\\"{x:131,y:597,t:1528139880494};\\\", \\\"{x:130,y:596,t:1528139880510};\\\", \\\"{x:127,y:593,t:1528139880527};\\\", \\\"{x:125,y:589,t:1528139880544};\\\", \\\"{x:125,y:583,t:1528139880560};\\\", \\\"{x:125,y:578,t:1528139880576};\\\", \\\"{x:125,y:575,t:1528139880592};\\\", \\\"{x:125,y:571,t:1528139880610};\\\", \\\"{x:125,y:570,t:1528139880626};\\\", \\\"{x:125,y:569,t:1528139880643};\\\", \\\"{x:125,y:568,t:1528139880660};\\\", \\\"{x:126,y:568,t:1528139880703};\\\", \\\"{x:128,y:569,t:1528139880727};\\\", \\\"{x:129,y:569,t:1528139880743};\\\", \\\"{x:130,y:569,t:1528139880760};\\\", \\\"{x:132,y:569,t:1528139881583};\\\", \\\"{x:137,y:569,t:1528139881594};\\\", \\\"{x:146,y:569,t:1528139881611};\\\", \\\"{x:153,y:569,t:1528139881627};\\\", \\\"{x:157,y:569,t:1528139881643};\\\", \\\"{x:161,y:571,t:1528139881660};\\\", \\\"{x:164,y:573,t:1528139881676};\\\", \\\"{x:165,y:573,t:1528139881694};\\\", \\\"{x:166,y:575,t:1528139881710};\\\", \\\"{x:167,y:575,t:1528139881726};\\\", \\\"{x:171,y:575,t:1528139882473};\\\", \\\"{x:176,y:575,t:1528139882478};\\\", \\\"{x:196,y:572,t:1528139882495};\\\", \\\"{x:227,y:560,t:1528139882511};\\\", \\\"{x:267,y:546,t:1528139882529};\\\", \\\"{x:329,y:529,t:1528139882546};\\\", \\\"{x:435,y:507,t:1528139882561};\\\", \\\"{x:574,y:486,t:1528139882578};\\\", \\\"{x:719,y:475,t:1528139882595};\\\", \\\"{x:858,y:453,t:1528139882610};\\\", \\\"{x:989,y:445,t:1528139882628};\\\", \\\"{x:1108,y:445,t:1528139882645};\\\", \\\"{x:1221,y:452,t:1528139882661};\\\", \\\"{x:1315,y:466,t:1528139882678};\\\", \\\"{x:1419,y:479,t:1528139882694};\\\", \\\"{x:1476,y:491,t:1528139882711};\\\", \\\"{x:1512,y:495,t:1528139882728};\\\", \\\"{x:1523,y:497,t:1528139882745};\\\", \\\"{x:1524,y:497,t:1528139882760};\\\", \\\"{x:1527,y:504,t:1528139882871};\\\", \\\"{x:1528,y:514,t:1528139882878};\\\", \\\"{x:1528,y:531,t:1528139882895};\\\", \\\"{x:1528,y:551,t:1528139882911};\\\", \\\"{x:1526,y:570,t:1528139882927};\\\", \\\"{x:1521,y:586,t:1528139882945};\\\", \\\"{x:1520,y:592,t:1528139882961};\\\", \\\"{x:1520,y:594,t:1528139882978};\\\", \\\"{x:1518,y:596,t:1528139882995};\\\", \\\"{x:1518,y:597,t:1528139883011};\\\", \\\"{x:1517,y:600,t:1528139883028};\\\", \\\"{x:1515,y:605,t:1528139883046};\\\", \\\"{x:1513,y:610,t:1528139883062};\\\", \\\"{x:1513,y:614,t:1528139883078};\\\", \\\"{x:1508,y:622,t:1528139883095};\\\", \\\"{x:1506,y:628,t:1528139883112};\\\", \\\"{x:1502,y:637,t:1528139883128};\\\", \\\"{x:1497,y:648,t:1528139883145};\\\", \\\"{x:1492,y:659,t:1528139883162};\\\", \\\"{x:1488,y:668,t:1528139883179};\\\", \\\"{x:1486,y:672,t:1528139883195};\\\", \\\"{x:1484,y:674,t:1528139883212};\\\", \\\"{x:1482,y:674,t:1528139883304};\\\", \\\"{x:1481,y:674,t:1528139883312};\\\", \\\"{x:1479,y:673,t:1528139883328};\\\", \\\"{x:1475,y:669,t:1528139883345};\\\", \\\"{x:1471,y:663,t:1528139883363};\\\", \\\"{x:1469,y:660,t:1528139883378};\\\", \\\"{x:1455,y:641,t:1528139883396};\\\", \\\"{x:1424,y:605,t:1528139883412};\\\", \\\"{x:1414,y:594,t:1528139883428};\\\", \\\"{x:1414,y:593,t:1528139883445};\\\", \\\"{x:1414,y:592,t:1528139883512};\\\", \\\"{x:1413,y:603,t:1528139883631};\\\", \\\"{x:1412,y:617,t:1528139883645};\\\", \\\"{x:1410,y:643,t:1528139883662};\\\", \\\"{x:1410,y:654,t:1528139883679};\\\", \\\"{x:1410,y:657,t:1528139883695};\\\", \\\"{x:1410,y:658,t:1528139883712};\\\", \\\"{x:1410,y:660,t:1528139883729};\\\", \\\"{x:1411,y:660,t:1528139883745};\\\", \\\"{x:1415,y:661,t:1528139883762};\\\", \\\"{x:1417,y:662,t:1528139883779};\\\", \\\"{x:1424,y:662,t:1528139883795};\\\", \\\"{x:1431,y:662,t:1528139883813};\\\", \\\"{x:1432,y:662,t:1528139883829};\\\", \\\"{x:1435,y:663,t:1528139883846};\\\", \\\"{x:1437,y:664,t:1528139883863};\\\", \\\"{x:1441,y:671,t:1528139883879};\\\", \\\"{x:1442,y:673,t:1528139883895};\\\", \\\"{x:1442,y:677,t:1528139883913};\\\", \\\"{x:1442,y:678,t:1528139883929};\\\", \\\"{x:1442,y:679,t:1528139883992};\\\", \\\"{x:1442,y:680,t:1528139884006};\\\", \\\"{x:1441,y:680,t:1528139884031};\\\", \\\"{x:1439,y:682,t:1528139884045};\\\", \\\"{x:1433,y:686,t:1528139884063};\\\", \\\"{x:1425,y:692,t:1528139884079};\\\", \\\"{x:1419,y:697,t:1528139884096};\\\", \\\"{x:1413,y:702,t:1528139884112};\\\", \\\"{x:1409,y:708,t:1528139884130};\\\", \\\"{x:1406,y:711,t:1528139884146};\\\", \\\"{x:1404,y:713,t:1528139884162};\\\", \\\"{x:1403,y:716,t:1528139884179};\\\", \\\"{x:1401,y:717,t:1528139884196};\\\", \\\"{x:1400,y:717,t:1528139884212};\\\", \\\"{x:1399,y:719,t:1528139884229};\\\", \\\"{x:1397,y:719,t:1528139884255};\\\", \\\"{x:1396,y:720,t:1528139884263};\\\", \\\"{x:1390,y:722,t:1528139884279};\\\", \\\"{x:1380,y:724,t:1528139884296};\\\", \\\"{x:1371,y:729,t:1528139884312};\\\", \\\"{x:1360,y:736,t:1528139884329};\\\", \\\"{x:1351,y:743,t:1528139884346};\\\", \\\"{x:1342,y:748,t:1528139884363};\\\", \\\"{x:1336,y:754,t:1528139884380};\\\", \\\"{x:1333,y:756,t:1528139884396};\\\", \\\"{x:1332,y:756,t:1528139884413};\\\", \\\"{x:1331,y:756,t:1528139884535};\\\", \\\"{x:1329,y:759,t:1528139884546};\\\", \\\"{x:1324,y:768,t:1528139884562};\\\", \\\"{x:1319,y:777,t:1528139884579};\\\", \\\"{x:1309,y:791,t:1528139884596};\\\", \\\"{x:1300,y:806,t:1528139884613};\\\", \\\"{x:1289,y:821,t:1528139884629};\\\", \\\"{x:1279,y:836,t:1528139884646};\\\", \\\"{x:1271,y:844,t:1528139884662};\\\", \\\"{x:1264,y:852,t:1528139884679};\\\", \\\"{x:1263,y:853,t:1528139884696};\\\", \\\"{x:1262,y:853,t:1528139884713};\\\", \\\"{x:1261,y:854,t:1528139884729};\\\", \\\"{x:1261,y:855,t:1528139884747};\\\", \\\"{x:1260,y:856,t:1528139884763};\\\", \\\"{x:1259,y:857,t:1528139884780};\\\", \\\"{x:1262,y:857,t:1528139884831};\\\", \\\"{x:1266,y:857,t:1528139884847};\\\", \\\"{x:1284,y:845,t:1528139884863};\\\", \\\"{x:1295,y:836,t:1528139884879};\\\", \\\"{x:1303,y:830,t:1528139884896};\\\", \\\"{x:1312,y:824,t:1528139884914};\\\", \\\"{x:1317,y:821,t:1528139884930};\\\", \\\"{x:1323,y:817,t:1528139884946};\\\", \\\"{x:1327,y:813,t:1528139884963};\\\", \\\"{x:1331,y:807,t:1528139884979};\\\", \\\"{x:1338,y:795,t:1528139884997};\\\", \\\"{x:1350,y:784,t:1528139885014};\\\", \\\"{x:1365,y:769,t:1528139885029};\\\", \\\"{x:1381,y:754,t:1528139885046};\\\", \\\"{x:1401,y:739,t:1528139885062};\\\", \\\"{x:1418,y:726,t:1528139885079};\\\", \\\"{x:1435,y:716,t:1528139885096};\\\", \\\"{x:1445,y:708,t:1528139885113};\\\", \\\"{x:1452,y:704,t:1528139885129};\\\", \\\"{x:1458,y:699,t:1528139885147};\\\", \\\"{x:1463,y:693,t:1528139885163};\\\", \\\"{x:1465,y:688,t:1528139885180};\\\", \\\"{x:1466,y:685,t:1528139885196};\\\", \\\"{x:1466,y:681,t:1528139885213};\\\", \\\"{x:1466,y:677,t:1528139885230};\\\", \\\"{x:1466,y:674,t:1528139885247};\\\", \\\"{x:1466,y:672,t:1528139885263};\\\", \\\"{x:1467,y:670,t:1528139885280};\\\", \\\"{x:1467,y:669,t:1528139885327};\\\", \\\"{x:1467,y:668,t:1528139885334};\\\", \\\"{x:1467,y:666,t:1528139885347};\\\", \\\"{x:1467,y:664,t:1528139885364};\\\", \\\"{x:1467,y:662,t:1528139885380};\\\", \\\"{x:1467,y:661,t:1528139885396};\\\", \\\"{x:1467,y:658,t:1528139885414};\\\", \\\"{x:1467,y:650,t:1528139885430};\\\", \\\"{x:1467,y:641,t:1528139885445};\\\", \\\"{x:1464,y:623,t:1528139885462};\\\", \\\"{x:1463,y:612,t:1528139885479};\\\", \\\"{x:1462,y:600,t:1528139885496};\\\", \\\"{x:1461,y:597,t:1528139885512};\\\", \\\"{x:1461,y:596,t:1528139885529};\\\", \\\"{x:1460,y:596,t:1528139885728};\\\", \\\"{x:1458,y:596,t:1528139885848};\\\", \\\"{x:1450,y:600,t:1528139885864};\\\", \\\"{x:1445,y:604,t:1528139885880};\\\", \\\"{x:1443,y:607,t:1528139885896};\\\", \\\"{x:1443,y:609,t:1528139885913};\\\", \\\"{x:1443,y:610,t:1528139885959};\\\", \\\"{x:1442,y:610,t:1528139886040};\\\", \\\"{x:1441,y:612,t:1528139886096};\\\", \\\"{x:1440,y:613,t:1528139886103};\\\", \\\"{x:1440,y:615,t:1528139886113};\\\", \\\"{x:1438,y:619,t:1528139886131};\\\", \\\"{x:1437,y:621,t:1528139886148};\\\", \\\"{x:1437,y:623,t:1528139886256};\\\", \\\"{x:1437,y:628,t:1528139886263};\\\", \\\"{x:1437,y:632,t:1528139886280};\\\", \\\"{x:1437,y:637,t:1528139886297};\\\", \\\"{x:1437,y:638,t:1528139886313};\\\", \\\"{x:1438,y:642,t:1528139886330};\\\", \\\"{x:1440,y:649,t:1528139886347};\\\", \\\"{x:1441,y:652,t:1528139886363};\\\", \\\"{x:1443,y:652,t:1528139886518};\\\", \\\"{x:1445,y:651,t:1528139886530};\\\", \\\"{x:1447,y:649,t:1528139886547};\\\", \\\"{x:1450,y:647,t:1528139886564};\\\", \\\"{x:1450,y:646,t:1528139886583};\\\", \\\"{x:1450,y:645,t:1528139886597};\\\", \\\"{x:1451,y:645,t:1528139886631};\\\", \\\"{x:1451,y:644,t:1528139886648};\\\", \\\"{x:1443,y:646,t:1528139886800};\\\", \\\"{x:1433,y:657,t:1528139886814};\\\", \\\"{x:1415,y:687,t:1528139886830};\\\", \\\"{x:1395,y:718,t:1528139886847};\\\", \\\"{x:1383,y:734,t:1528139886865};\\\", \\\"{x:1378,y:741,t:1528139886880};\\\", \\\"{x:1373,y:746,t:1528139886898};\\\", \\\"{x:1367,y:752,t:1528139886915};\\\", \\\"{x:1360,y:760,t:1528139886930};\\\", \\\"{x:1354,y:766,t:1528139886947};\\\", \\\"{x:1352,y:770,t:1528139886965};\\\", \\\"{x:1346,y:776,t:1528139886981};\\\", \\\"{x:1342,y:781,t:1528139886997};\\\", \\\"{x:1335,y:792,t:1528139887014};\\\", \\\"{x:1324,y:811,t:1528139887029};\\\", \\\"{x:1315,y:827,t:1528139887047};\\\", \\\"{x:1309,y:842,t:1528139887063};\\\", \\\"{x:1302,y:855,t:1528139887081};\\\", \\\"{x:1298,y:861,t:1528139887097};\\\", \\\"{x:1296,y:865,t:1528139887113};\\\", \\\"{x:1296,y:866,t:1528139887166};\\\", \\\"{x:1299,y:866,t:1528139887180};\\\", \\\"{x:1304,y:866,t:1528139887197};\\\", \\\"{x:1318,y:847,t:1528139887214};\\\", \\\"{x:1330,y:828,t:1528139887230};\\\", \\\"{x:1342,y:804,t:1528139887247};\\\", \\\"{x:1353,y:783,t:1528139887264};\\\", \\\"{x:1370,y:759,t:1528139887281};\\\", \\\"{x:1386,y:740,t:1528139887297};\\\", \\\"{x:1400,y:728,t:1528139887315};\\\", \\\"{x:1416,y:714,t:1528139887331};\\\", \\\"{x:1423,y:708,t:1528139887347};\\\", \\\"{x:1425,y:705,t:1528139887365};\\\", \\\"{x:1427,y:704,t:1528139887381};\\\", \\\"{x:1423,y:704,t:1528139887495};\\\", \\\"{x:1416,y:708,t:1528139887503};\\\", \\\"{x:1405,y:714,t:1528139887514};\\\", \\\"{x:1382,y:736,t:1528139887531};\\\", \\\"{x:1362,y:763,t:1528139887547};\\\", \\\"{x:1346,y:786,t:1528139887565};\\\", \\\"{x:1332,y:805,t:1528139887581};\\\", \\\"{x:1320,y:819,t:1528139887598};\\\", \\\"{x:1314,y:825,t:1528139887615};\\\", \\\"{x:1312,y:828,t:1528139887632};\\\", \\\"{x:1311,y:829,t:1528139887648};\\\", \\\"{x:1311,y:828,t:1528139887798};\\\", \\\"{x:1312,y:819,t:1528139887814};\\\", \\\"{x:1315,y:812,t:1528139887830};\\\", \\\"{x:1318,y:807,t:1528139887848};\\\", \\\"{x:1322,y:800,t:1528139887864};\\\", \\\"{x:1324,y:793,t:1528139887881};\\\", \\\"{x:1326,y:786,t:1528139887898};\\\", \\\"{x:1330,y:776,t:1528139887914};\\\", \\\"{x:1332,y:769,t:1528139887931};\\\", \\\"{x:1334,y:762,t:1528139887948};\\\", \\\"{x:1336,y:756,t:1528139887964};\\\", \\\"{x:1339,y:752,t:1528139887981};\\\", \\\"{x:1339,y:751,t:1528139887998};\\\", \\\"{x:1339,y:749,t:1528139888014};\\\", \\\"{x:1336,y:758,t:1528139888248};\\\", \\\"{x:1325,y:778,t:1528139888266};\\\", \\\"{x:1313,y:797,t:1528139888281};\\\", \\\"{x:1306,y:812,t:1528139888298};\\\", \\\"{x:1299,y:823,t:1528139888316};\\\", \\\"{x:1294,y:829,t:1528139888332};\\\", \\\"{x:1292,y:835,t:1528139888349};\\\", \\\"{x:1290,y:838,t:1528139888365};\\\", \\\"{x:1288,y:840,t:1528139888381};\\\", \\\"{x:1287,y:842,t:1528139888398};\\\", \\\"{x:1287,y:840,t:1528139888527};\\\", \\\"{x:1289,y:834,t:1528139888535};\\\", \\\"{x:1295,y:827,t:1528139888548};\\\", \\\"{x:1308,y:806,t:1528139888566};\\\", \\\"{x:1324,y:785,t:1528139888582};\\\", \\\"{x:1344,y:754,t:1528139888599};\\\", \\\"{x:1361,y:732,t:1528139888616};\\\", \\\"{x:1393,y:694,t:1528139888631};\\\", \\\"{x:1413,y:671,t:1528139888648};\\\", \\\"{x:1431,y:649,t:1528139888665};\\\", \\\"{x:1450,y:624,t:1528139888683};\\\", \\\"{x:1463,y:610,t:1528139888699};\\\", \\\"{x:1469,y:602,t:1528139888715};\\\", \\\"{x:1472,y:599,t:1528139888733};\\\", \\\"{x:1473,y:599,t:1528139888749};\\\", \\\"{x:1474,y:598,t:1528139888766};\\\", \\\"{x:1465,y:601,t:1528139888936};\\\", \\\"{x:1446,y:609,t:1528139888948};\\\", \\\"{x:1393,y:625,t:1528139888965};\\\", \\\"{x:1247,y:647,t:1528139888983};\\\", \\\"{x:1095,y:647,t:1528139888998};\\\", \\\"{x:954,y:647,t:1528139889015};\\\", \\\"{x:800,y:632,t:1528139889032};\\\", \\\"{x:630,y:597,t:1528139889048};\\\", \\\"{x:492,y:556,t:1528139889065};\\\", \\\"{x:407,y:527,t:1528139889083};\\\", \\\"{x:391,y:518,t:1528139889098};\\\", \\\"{x:389,y:515,t:1528139889114};\\\", \\\"{x:387,y:509,t:1528139889133};\\\", \\\"{x:385,y:491,t:1528139889150};\\\", \\\"{x:385,y:486,t:1528139889166};\\\", \\\"{x:384,y:485,t:1528139889183};\\\", \\\"{x:383,y:485,t:1528139889200};\\\", \\\"{x:378,y:482,t:1528139889215};\\\", \\\"{x:360,y:481,t:1528139889233};\\\", \\\"{x:342,y:481,t:1528139889250};\\\", \\\"{x:327,y:481,t:1528139889266};\\\", \\\"{x:312,y:485,t:1528139889282};\\\", \\\"{x:302,y:490,t:1528139889299};\\\", \\\"{x:293,y:493,t:1528139889316};\\\", \\\"{x:290,y:494,t:1528139889333};\\\", \\\"{x:287,y:494,t:1528139889349};\\\", \\\"{x:286,y:495,t:1528139889366};\\\", \\\"{x:285,y:497,t:1528139889398};\\\", \\\"{x:283,y:499,t:1528139889406};\\\", \\\"{x:282,y:501,t:1528139889416};\\\", \\\"{x:278,y:504,t:1528139889433};\\\", \\\"{x:272,y:511,t:1528139889451};\\\", \\\"{x:260,y:521,t:1528139889467};\\\", \\\"{x:248,y:535,t:1528139889483};\\\", \\\"{x:234,y:549,t:1528139889500};\\\", \\\"{x:219,y:560,t:1528139889518};\\\", \\\"{x:209,y:567,t:1528139889533};\\\", \\\"{x:203,y:575,t:1528139889550};\\\", \\\"{x:202,y:575,t:1528139889566};\\\", \\\"{x:201,y:576,t:1528139889583};\\\", \\\"{x:199,y:578,t:1528139889655};\\\", \\\"{x:199,y:580,t:1528139889667};\\\", \\\"{x:198,y:582,t:1528139889683};\\\", \\\"{x:197,y:584,t:1528139889700};\\\", \\\"{x:196,y:585,t:1528139889716};\\\", \\\"{x:193,y:587,t:1528139889733};\\\", \\\"{x:191,y:587,t:1528139889752};\\\", \\\"{x:186,y:587,t:1528139889766};\\\", \\\"{x:185,y:587,t:1528139889783};\\\", \\\"{x:184,y:587,t:1528139889800};\\\", \\\"{x:183,y:587,t:1528139889816};\\\", \\\"{x:182,y:587,t:1528139889853};\\\", \\\"{x:181,y:587,t:1528139889867};\\\", \\\"{x:179,y:585,t:1528139889884};\\\", \\\"{x:177,y:584,t:1528139889901};\\\", \\\"{x:176,y:582,t:1528139889917};\\\", \\\"{x:173,y:581,t:1528139889934};\\\", \\\"{x:170,y:580,t:1528139889950};\\\", \\\"{x:165,y:579,t:1528139889968};\\\", \\\"{x:164,y:578,t:1528139889984};\\\", \\\"{x:161,y:578,t:1528139890001};\\\", \\\"{x:160,y:576,t:1528139890017};\\\", \\\"{x:158,y:576,t:1528139890034};\\\", \\\"{x:156,y:575,t:1528139890051};\\\", \\\"{x:154,y:574,t:1528139890068};\\\", \\\"{x:152,y:572,t:1528139890084};\\\", \\\"{x:150,y:570,t:1528139890101};\\\", \\\"{x:149,y:570,t:1528139890119};\\\", \\\"{x:148,y:569,t:1528139890350};\\\", \\\"{x:147,y:569,t:1528139890390};\\\", \\\"{x:147,y:568,t:1528139890446};\\\", \\\"{x:148,y:567,t:1528139890454};\\\", \\\"{x:151,y:566,t:1528139890467};\\\", \\\"{x:154,y:564,t:1528139890484};\\\", \\\"{x:162,y:561,t:1528139890502};\\\", \\\"{x:174,y:555,t:1528139890517};\\\", \\\"{x:209,y:545,t:1528139890533};\\\", \\\"{x:249,y:542,t:1528139890551};\\\", \\\"{x:290,y:539,t:1528139890567};\\\", \\\"{x:354,y:531,t:1528139890583};\\\", \\\"{x:436,y:523,t:1528139890601};\\\", \\\"{x:508,y:515,t:1528139890617};\\\", \\\"{x:570,y:504,t:1528139890634};\\\", \\\"{x:635,y:503,t:1528139890651};\\\", \\\"{x:690,y:503,t:1528139890668};\\\", \\\"{x:732,y:503,t:1528139890685};\\\", \\\"{x:772,y:507,t:1528139890701};\\\", \\\"{x:839,y:535,t:1528139890719};\\\", \\\"{x:883,y:553,t:1528139890734};\\\", \\\"{x:930,y:575,t:1528139890752};\\\", \\\"{x:962,y:585,t:1528139890768};\\\", \\\"{x:979,y:589,t:1528139890783};\\\", \\\"{x:997,y:594,t:1528139890801};\\\", \\\"{x:1014,y:595,t:1528139890817};\\\", \\\"{x:1029,y:598,t:1528139890834};\\\", \\\"{x:1045,y:599,t:1528139890851};\\\", \\\"{x:1067,y:603,t:1528139890867};\\\", \\\"{x:1085,y:606,t:1528139890884};\\\", \\\"{x:1104,y:609,t:1528139890900};\\\", \\\"{x:1130,y:617,t:1528139890918};\\\", \\\"{x:1170,y:639,t:1528139890934};\\\", \\\"{x:1206,y:660,t:1528139890951};\\\", \\\"{x:1240,y:684,t:1528139890967};\\\", \\\"{x:1282,y:712,t:1528139890984};\\\", \\\"{x:1332,y:736,t:1528139891000};\\\", \\\"{x:1373,y:752,t:1528139891018};\\\", \\\"{x:1395,y:757,t:1528139891033};\\\", \\\"{x:1402,y:757,t:1528139891050};\\\", \\\"{x:1403,y:757,t:1528139891071};\\\", \\\"{x:1404,y:757,t:1528139891095};\\\", \\\"{x:1405,y:757,t:1528139891112};\\\", \\\"{x:1403,y:758,t:1528139891320};\\\", \\\"{x:1401,y:758,t:1528139891333};\\\", \\\"{x:1398,y:758,t:1528139891349};\\\", \\\"{x:1391,y:764,t:1528139891366};\\\", \\\"{x:1386,y:771,t:1528139891383};\\\", \\\"{x:1379,y:781,t:1528139891400};\\\", \\\"{x:1371,y:794,t:1528139891417};\\\", \\\"{x:1362,y:807,t:1528139891433};\\\", \\\"{x:1351,y:819,t:1528139891449};\\\", \\\"{x:1339,y:830,t:1528139891467};\\\", \\\"{x:1326,y:838,t:1528139891483};\\\", \\\"{x:1315,y:846,t:1528139891499};\\\", \\\"{x:1307,y:850,t:1528139891516};\\\", \\\"{x:1302,y:852,t:1528139891533};\\\", \\\"{x:1296,y:852,t:1528139891550};\\\", \\\"{x:1294,y:853,t:1528139891565};\\\", \\\"{x:1289,y:853,t:1528139891583};\\\", \\\"{x:1285,y:854,t:1528139891599};\\\", \\\"{x:1279,y:856,t:1528139891615};\\\", \\\"{x:1273,y:859,t:1528139891633};\\\", \\\"{x:1266,y:862,t:1528139891649};\\\", \\\"{x:1253,y:872,t:1528139891666};\\\", \\\"{x:1241,y:882,t:1528139891682};\\\", \\\"{x:1225,y:893,t:1528139891699};\\\", \\\"{x:1217,y:904,t:1528139891716};\\\", \\\"{x:1207,y:916,t:1528139891732};\\\", \\\"{x:1205,y:924,t:1528139891748};\\\", \\\"{x:1196,y:931,t:1528139891766};\\\", \\\"{x:1190,y:936,t:1528139891783};\\\", \\\"{x:1187,y:937,t:1528139891799};\\\", \\\"{x:1187,y:936,t:1528139891846};\\\", \\\"{x:1188,y:934,t:1528139891863};\\\", \\\"{x:1189,y:932,t:1528139891870};\\\", \\\"{x:1190,y:930,t:1528139891881};\\\", \\\"{x:1192,y:927,t:1528139891899};\\\", \\\"{x:1195,y:922,t:1528139891916};\\\", \\\"{x:1198,y:917,t:1528139891932};\\\", \\\"{x:1200,y:913,t:1528139891948};\\\", \\\"{x:1205,y:909,t:1528139891964};\\\", \\\"{x:1208,y:906,t:1528139891981};\\\", \\\"{x:1215,y:901,t:1528139891999};\\\", \\\"{x:1223,y:897,t:1528139892015};\\\", \\\"{x:1232,y:885,t:1528139892031};\\\", \\\"{x:1241,y:872,t:1528139892048};\\\", \\\"{x:1256,y:851,t:1528139892064};\\\", \\\"{x:1271,y:830,t:1528139892082};\\\", \\\"{x:1285,y:810,t:1528139892098};\\\", \\\"{x:1299,y:792,t:1528139892115};\\\", \\\"{x:1315,y:776,t:1528139892131};\\\", \\\"{x:1325,y:765,t:1528139892148};\\\", \\\"{x:1330,y:760,t:1528139892165};\\\", \\\"{x:1334,y:756,t:1528139892182};\\\", \\\"{x:1336,y:754,t:1528139892198};\\\", \\\"{x:1339,y:751,t:1528139892215};\\\", \\\"{x:1341,y:749,t:1528139892231};\\\", \\\"{x:1342,y:748,t:1528139892248};\\\", \\\"{x:1344,y:744,t:1528139892264};\\\", \\\"{x:1345,y:741,t:1528139892281};\\\", \\\"{x:1346,y:737,t:1528139892298};\\\", \\\"{x:1347,y:734,t:1528139892314};\\\", \\\"{x:1348,y:731,t:1528139892330};\\\", \\\"{x:1349,y:725,t:1528139892347};\\\", \\\"{x:1351,y:716,t:1528139892363};\\\", \\\"{x:1351,y:711,t:1528139892380};\\\", \\\"{x:1352,y:707,t:1528139892396};\\\", \\\"{x:1354,y:704,t:1528139892413};\\\", \\\"{x:1356,y:701,t:1528139892430};\\\", \\\"{x:1356,y:700,t:1528139892446};\\\", \\\"{x:1357,y:699,t:1528139892463};\\\", \\\"{x:1357,y:698,t:1528139892480};\\\", \\\"{x:1358,y:697,t:1528139892496};\\\", \\\"{x:1358,y:696,t:1528139892519};\\\", \\\"{x:1358,y:694,t:1528139892534};\\\", \\\"{x:1359,y:693,t:1528139892550};\\\", \\\"{x:1359,y:691,t:1528139892563};\\\", \\\"{x:1359,y:689,t:1528139892580};\\\", \\\"{x:1361,y:687,t:1528139892597};\\\", \\\"{x:1361,y:686,t:1528139892613};\\\", \\\"{x:1360,y:686,t:1528139892750};\\\", \\\"{x:1358,y:687,t:1528139892761};\\\", \\\"{x:1356,y:688,t:1528139892778};\\\", \\\"{x:1354,y:689,t:1528139892796};\\\", \\\"{x:1352,y:690,t:1528139892812};\\\", \\\"{x:1350,y:691,t:1528139892829};\\\", \\\"{x:1349,y:691,t:1528139892846};\\\", \\\"{x:1348,y:691,t:1528139892870};\\\", \\\"{x:1347,y:691,t:1528139892926};\\\", \\\"{x:1346,y:691,t:1528139894623};\\\", \\\"{x:1345,y:691,t:1528139898607};\\\", \\\"{x:1345,y:689,t:1528139899255};\\\", \\\"{x:1345,y:686,t:1528139899263};\\\", \\\"{x:1345,y:682,t:1528139899279};\\\", \\\"{x:1345,y:680,t:1528139899296};\\\", \\\"{x:1345,y:679,t:1528139899312};\\\", \\\"{x:1345,y:677,t:1528139899331};\\\", \\\"{x:1346,y:676,t:1528139899439};\\\", \\\"{x:1346,y:674,t:1528139899455};\\\", \\\"{x:1346,y:673,t:1528139899463};\\\", \\\"{x:1348,y:670,t:1528139899480};\\\", \\\"{x:1349,y:666,t:1528139899496};\\\", \\\"{x:1349,y:664,t:1528139899513};\\\", \\\"{x:1351,y:661,t:1528139899530};\\\", \\\"{x:1352,y:659,t:1528139899546};\\\", \\\"{x:1352,y:658,t:1528139899563};\\\", \\\"{x:1353,y:657,t:1528139899579};\\\", \\\"{x:1354,y:656,t:1528139899614};\\\", \\\"{x:1355,y:655,t:1528139899630};\\\", \\\"{x:1356,y:654,t:1528139899679};\\\", \\\"{x:1357,y:653,t:1528139899695};\\\", \\\"{x:1357,y:652,t:1528139899711};\\\", \\\"{x:1359,y:651,t:1528139899729};\\\", \\\"{x:1361,y:649,t:1528139899746};\\\", \\\"{x:1361,y:647,t:1528139899762};\\\", \\\"{x:1361,y:646,t:1528139899778};\\\", \\\"{x:1362,y:644,t:1528139899796};\\\", \\\"{x:1363,y:643,t:1528139899855};\\\", \\\"{x:1364,y:643,t:1528139899879};\\\", \\\"{x:1365,y:643,t:1528139899895};\\\", \\\"{x:1366,y:643,t:1528139899914};\\\", \\\"{x:1368,y:641,t:1528139899958};\\\", \\\"{x:1368,y:640,t:1528139899990};\\\", \\\"{x:1369,y:639,t:1528139899997};\\\", \\\"{x:1370,y:639,t:1528139900012};\\\", \\\"{x:1370,y:638,t:1528139900027};\\\", \\\"{x:1371,y:637,t:1528139900044};\\\", \\\"{x:1371,y:636,t:1528139900070};\\\", \\\"{x:1372,y:635,t:1528139900143};\\\", \\\"{x:1373,y:635,t:1528139900199};\\\", \\\"{x:1373,y:634,t:1528139900222};\\\", \\\"{x:1374,y:632,t:1528139900246};\\\", \\\"{x:1374,y:631,t:1528139900295};\\\", \\\"{x:1375,y:630,t:1528139900311};\\\", \\\"{x:1376,y:630,t:1528139900334};\\\", \\\"{x:1377,y:629,t:1528139900384};\\\", \\\"{x:1378,y:629,t:1528139900394};\\\", \\\"{x:1380,y:627,t:1528139900411};\\\", \\\"{x:1384,y:624,t:1528139900427};\\\", \\\"{x:1387,y:621,t:1528139900444};\\\", \\\"{x:1390,y:617,t:1528139900461};\\\", \\\"{x:1392,y:613,t:1528139900477};\\\", \\\"{x:1396,y:609,t:1528139900494};\\\", \\\"{x:1400,y:602,t:1528139900510};\\\", \\\"{x:1402,y:599,t:1528139900527};\\\", \\\"{x:1404,y:596,t:1528139900544};\\\", \\\"{x:1405,y:596,t:1528139900560};\\\", \\\"{x:1406,y:595,t:1528139900577};\\\", \\\"{x:1406,y:594,t:1528139900615};\\\", \\\"{x:1408,y:593,t:1528139900646};\\\", \\\"{x:1408,y:592,t:1528139900687};\\\", \\\"{x:1408,y:590,t:1528139900695};\\\", \\\"{x:1408,y:589,t:1528139900710};\\\", \\\"{x:1410,y:585,t:1528139900726};\\\", \\\"{x:1410,y:581,t:1528139900742};\\\", \\\"{x:1412,y:579,t:1528139900760};\\\", \\\"{x:1412,y:578,t:1528139900775};\\\", \\\"{x:1412,y:577,t:1528139900792};\\\", \\\"{x:1412,y:576,t:1528139900809};\\\", \\\"{x:1412,y:575,t:1528139900919};\\\", \\\"{x:1412,y:574,t:1528139900926};\\\", \\\"{x:1412,y:572,t:1528139900943};\\\", \\\"{x:1412,y:566,t:1528139900959};\\\", \\\"{x:1412,y:561,t:1528139900976};\\\", \\\"{x:1412,y:555,t:1528139900993};\\\", \\\"{x:1412,y:553,t:1528139901008};\\\", \\\"{x:1412,y:552,t:1528139901026};\\\", \\\"{x:1412,y:551,t:1528139901046};\\\", \\\"{x:1418,y:590,t:1528139902814};\\\", \\\"{x:1442,y:654,t:1528139902821};\\\", \\\"{x:1460,y:689,t:1528139902837};\\\", \\\"{x:1487,y:743,t:1528139902853};\\\", \\\"{x:1514,y:787,t:1528139902871};\\\", \\\"{x:1521,y:797,t:1528139902888};\\\", \\\"{x:1526,y:803,t:1528139902904};\\\", \\\"{x:1530,y:806,t:1528139902921};\\\", \\\"{x:1531,y:808,t:1528139902938};\\\", \\\"{x:1532,y:809,t:1528139902953};\\\", \\\"{x:1532,y:810,t:1528139902974};\\\", \\\"{x:1533,y:812,t:1528139902986};\\\", \\\"{x:1537,y:820,t:1528139903004};\\\", \\\"{x:1548,y:838,t:1528139903021};\\\", \\\"{x:1560,y:860,t:1528139903036};\\\", \\\"{x:1583,y:892,t:1528139903054};\\\", \\\"{x:1590,y:905,t:1528139903071};\\\", \\\"{x:1595,y:913,t:1528139903086};\\\", \\\"{x:1602,y:920,t:1528139903104};\\\", \\\"{x:1604,y:925,t:1528139903120};\\\", \\\"{x:1606,y:927,t:1528139903137};\\\", \\\"{x:1606,y:928,t:1528139903183};\\\", \\\"{x:1607,y:929,t:1528139903214};\\\", \\\"{x:1607,y:931,t:1528139903223};\\\", \\\"{x:1608,y:936,t:1528139903237};\\\", \\\"{x:1608,y:939,t:1528139903252};\\\", \\\"{x:1609,y:941,t:1528139903269};\\\", \\\"{x:1609,y:945,t:1528139903286};\\\", \\\"{x:1610,y:949,t:1528139903303};\\\", \\\"{x:1610,y:950,t:1528139903320};\\\", \\\"{x:1610,y:951,t:1528139903337};\\\", \\\"{x:1610,y:948,t:1528139903431};\\\", \\\"{x:1610,y:944,t:1528139903438};\\\", \\\"{x:1608,y:938,t:1528139903453};\\\", \\\"{x:1601,y:923,t:1528139903470};\\\", \\\"{x:1590,y:906,t:1528139903486};\\\", \\\"{x:1577,y:887,t:1528139903502};\\\", \\\"{x:1576,y:887,t:1528139903519};\\\", \\\"{x:1576,y:885,t:1528139903536};\\\", \\\"{x:1575,y:885,t:1528139903553};\\\", \\\"{x:1574,y:883,t:1528139903569};\\\", \\\"{x:1571,y:877,t:1528139903586};\\\", \\\"{x:1560,y:859,t:1528139903602};\\\", \\\"{x:1550,y:841,t:1528139903619};\\\", \\\"{x:1547,y:834,t:1528139903636};\\\", \\\"{x:1545,y:826,t:1528139903651};\\\", \\\"{x:1539,y:808,t:1528139903669};\\\", \\\"{x:1535,y:792,t:1528139903686};\\\", \\\"{x:1531,y:777,t:1528139903702};\\\", \\\"{x:1521,y:744,t:1528139903718};\\\", \\\"{x:1515,y:727,t:1528139903735};\\\", \\\"{x:1511,y:716,t:1528139903752};\\\", \\\"{x:1509,y:709,t:1528139903769};\\\", \\\"{x:1507,y:703,t:1528139903785};\\\", \\\"{x:1505,y:698,t:1528139903802};\\\", \\\"{x:1503,y:694,t:1528139903819};\\\", \\\"{x:1499,y:688,t:1528139903835};\\\", \\\"{x:1497,y:684,t:1528139903852};\\\", \\\"{x:1492,y:677,t:1528139903867};\\\", \\\"{x:1483,y:663,t:1528139903885};\\\", \\\"{x:1467,y:643,t:1528139903902};\\\", \\\"{x:1452,y:630,t:1528139903919};\\\", \\\"{x:1445,y:619,t:1528139903935};\\\", \\\"{x:1443,y:613,t:1528139903952};\\\", \\\"{x:1441,y:610,t:1528139903968};\\\", \\\"{x:1439,y:606,t:1528139903985};\\\", \\\"{x:1438,y:605,t:1528139904002};\\\", \\\"{x:1438,y:604,t:1528139904018};\\\", \\\"{x:1437,y:603,t:1528139904035};\\\", \\\"{x:1436,y:602,t:1528139904055};\\\", \\\"{x:1435,y:602,t:1528139904079};\\\", \\\"{x:1435,y:601,t:1528139904135};\\\", \\\"{x:1435,y:593,t:1528139904150};\\\", \\\"{x:1434,y:584,t:1528139904168};\\\", \\\"{x:1431,y:574,t:1528139904184};\\\", \\\"{x:1427,y:565,t:1528139904201};\\\", \\\"{x:1425,y:558,t:1528139904218};\\\", \\\"{x:1425,y:555,t:1528139904233};\\\", \\\"{x:1425,y:554,t:1528139904251};\\\", \\\"{x:1424,y:554,t:1528139904268};\\\", \\\"{x:1424,y:553,t:1528139904286};\\\", \\\"{x:1424,y:552,t:1528139904312};\\\", \\\"{x:1423,y:552,t:1528139904342};\\\", \\\"{x:1423,y:551,t:1528139904383};\\\", \\\"{x:1421,y:551,t:1528139904607};\\\", \\\"{x:1420,y:550,t:1528139905566};\\\", \\\"{x:1419,y:550,t:1528139905581};\\\", \\\"{x:1417,y:549,t:1528139905597};\\\", \\\"{x:1414,y:547,t:1528139905614};\\\", \\\"{x:1413,y:547,t:1528139905629};\\\", \\\"{x:1412,y:547,t:1528139905655};\\\", \\\"{x:1411,y:547,t:1528139905719};\\\", \\\"{x:1377,y:547,t:1528139908191};\\\", \\\"{x:1207,y:579,t:1528139908207};\\\", \\\"{x:1041,y:604,t:1528139908224};\\\", \\\"{x:815,y:609,t:1528139908242};\\\", \\\"{x:544,y:602,t:1528139908257};\\\", \\\"{x:297,y:591,t:1528139908274};\\\", \\\"{x:0,y:579,t:1528139908298};\\\", \\\"{x:0,y:580,t:1528139908325};\\\", \\\"{x:0,y:584,t:1528139908333};\\\", \\\"{x:0,y:586,t:1528139908349};\\\", \\\"{x:0,y:588,t:1528139908364};\\\", \\\"{x:0,y:589,t:1528139908397};\\\", \\\"{x:1,y:592,t:1528139908414};\\\", \\\"{x:2,y:592,t:1528139908429};\\\", \\\"{x:3,y:592,t:1528139908437};\\\", \\\"{x:4,y:592,t:1528139908454};\\\", \\\"{x:7,y:592,t:1528139908470};\\\", \\\"{x:12,y:592,t:1528139908481};\\\", \\\"{x:33,y:590,t:1528139908499};\\\", \\\"{x:61,y:584,t:1528139908516};\\\", \\\"{x:100,y:579,t:1528139908532};\\\", \\\"{x:159,y:570,t:1528139908550};\\\", \\\"{x:217,y:570,t:1528139908565};\\\", \\\"{x:293,y:570,t:1528139908582};\\\", \\\"{x:327,y:570,t:1528139908598};\\\", \\\"{x:344,y:572,t:1528139908615};\\\", \\\"{x:350,y:572,t:1528139908631};\\\", \\\"{x:351,y:572,t:1528139908648};\\\", \\\"{x:342,y:570,t:1528139908757};\\\", \\\"{x:328,y:565,t:1528139908765};\\\", \\\"{x:305,y:564,t:1528139908781};\\\", \\\"{x:290,y:574,t:1528139908798};\\\", \\\"{x:271,y:587,t:1528139908816};\\\", \\\"{x:256,y:596,t:1528139908832};\\\", \\\"{x:241,y:601,t:1528139908848};\\\", \\\"{x:233,y:603,t:1528139908864};\\\", \\\"{x:232,y:603,t:1528139908941};\\\", \\\"{x:238,y:599,t:1528139908950};\\\", \\\"{x:265,y:585,t:1528139908966};\\\", \\\"{x:281,y:574,t:1528139908983};\\\", \\\"{x:306,y:563,t:1528139908998};\\\", \\\"{x:332,y:552,t:1528139909016};\\\", \\\"{x:361,y:545,t:1528139909031};\\\", \\\"{x:393,y:536,t:1528139909049};\\\", \\\"{x:446,y:532,t:1528139909066};\\\", \\\"{x:510,y:532,t:1528139909083};\\\", \\\"{x:570,y:536,t:1528139909099};\\\", \\\"{x:612,y:541,t:1528139909116};\\\", \\\"{x:627,y:543,t:1528139909133};\\\", \\\"{x:629,y:543,t:1528139909148};\\\", \\\"{x:630,y:544,t:1528139909313};\\\", \\\"{x:631,y:546,t:1528139909325};\\\", \\\"{x:633,y:551,t:1528139909334};\\\", \\\"{x:637,y:554,t:1528139909350};\\\", \\\"{x:642,y:559,t:1528139909367};\\\", \\\"{x:646,y:560,t:1528139909383};\\\", \\\"{x:653,y:562,t:1528139909398};\\\", \\\"{x:658,y:562,t:1528139909416};\\\", \\\"{x:677,y:562,t:1528139909432};\\\", \\\"{x:697,y:561,t:1528139909449};\\\", \\\"{x:715,y:560,t:1528139909466};\\\", \\\"{x:731,y:554,t:1528139909484};\\\", \\\"{x:752,y:551,t:1528139909499};\\\", \\\"{x:776,y:549,t:1528139909515};\\\", \\\"{x:802,y:549,t:1528139909533};\\\", \\\"{x:834,y:549,t:1528139909550};\\\", \\\"{x:840,y:549,t:1528139909565};\\\", \\\"{x:843,y:549,t:1528139909583};\\\", \\\"{x:845,y:549,t:1528139909600};\\\", \\\"{x:846,y:549,t:1528139909694};\\\", \\\"{x:855,y:549,t:1528139910294};\\\", \\\"{x:886,y:559,t:1528139910304};\\\", \\\"{x:922,y:568,t:1528139910317};\\\", \\\"{x:1041,y:579,t:1528139910333};\\\", \\\"{x:1102,y:579,t:1528139910349};\\\", \\\"{x:1162,y:579,t:1528139910367};\\\", \\\"{x:1215,y:571,t:1528139910384};\\\", \\\"{x:1267,y:566,t:1528139910399};\\\", \\\"{x:1302,y:560,t:1528139910416};\\\", \\\"{x:1333,y:556,t:1528139910434};\\\", \\\"{x:1351,y:554,t:1528139910450};\\\", \\\"{x:1355,y:553,t:1528139910467};\\\", \\\"{x:1356,y:553,t:1528139910526};\\\", \\\"{x:1357,y:553,t:1528139910534};\\\", \\\"{x:1360,y:553,t:1528139910550};\\\", \\\"{x:1364,y:553,t:1528139910567};\\\", \\\"{x:1365,y:552,t:1528139910606};\\\", \\\"{x:1366,y:552,t:1528139910751};\\\", \\\"{x:1368,y:552,t:1528139910767};\\\", \\\"{x:1370,y:553,t:1528139910784};\\\", \\\"{x:1375,y:556,t:1528139910800};\\\", \\\"{x:1380,y:560,t:1528139910817};\\\", \\\"{x:1383,y:562,t:1528139910834};\\\", \\\"{x:1388,y:564,t:1528139910850};\\\", \\\"{x:1391,y:564,t:1528139910867};\\\", \\\"{x:1395,y:565,t:1528139910885};\\\", \\\"{x:1402,y:567,t:1528139910901};\\\", \\\"{x:1409,y:568,t:1528139910917};\\\", \\\"{x:1421,y:568,t:1528139910933};\\\", \\\"{x:1425,y:568,t:1528139910951};\\\", \\\"{x:1429,y:568,t:1528139910966};\\\", \\\"{x:1433,y:569,t:1528139910984};\\\", \\\"{x:1435,y:569,t:1528139911001};\\\", \\\"{x:1436,y:569,t:1528139911017};\\\", \\\"{x:1437,y:570,t:1528139912279};\\\", \\\"{x:1437,y:571,t:1528139912286};\\\", \\\"{x:1435,y:571,t:1528139912301};\\\", \\\"{x:1425,y:571,t:1528139912318};\\\", \\\"{x:1423,y:570,t:1528139912335};\\\", \\\"{x:1420,y:567,t:1528139912351};\\\", \\\"{x:1417,y:566,t:1528139912368};\\\", \\\"{x:1415,y:566,t:1528139912384};\\\", \\\"{x:1413,y:564,t:1528139912400};\\\", \\\"{x:1412,y:564,t:1528139912421};\\\", \\\"{x:1411,y:564,t:1528139912437};\\\", \\\"{x:1410,y:564,t:1528139912462};\\\", \\\"{x:1410,y:563,t:1528139912470};\\\", \\\"{x:1409,y:563,t:1528139912534};\\\", \\\"{x:1408,y:563,t:1528139913656};\\\", \\\"{x:1403,y:568,t:1528139913670};\\\", \\\"{x:1390,y:584,t:1528139913686};\\\", \\\"{x:1380,y:596,t:1528139913702};\\\", \\\"{x:1372,y:607,t:1528139913719};\\\", \\\"{x:1363,y:616,t:1528139913736};\\\", \\\"{x:1359,y:623,t:1528139913752};\\\", \\\"{x:1355,y:628,t:1528139913769};\\\", \\\"{x:1352,y:632,t:1528139913786};\\\", \\\"{x:1348,y:636,t:1528139913803};\\\", \\\"{x:1345,y:640,t:1528139913819};\\\", \\\"{x:1341,y:643,t:1528139913836};\\\", \\\"{x:1337,y:647,t:1528139913853};\\\", \\\"{x:1333,y:651,t:1528139913870};\\\", \\\"{x:1325,y:661,t:1528139913887};\\\", \\\"{x:1318,y:671,t:1528139913902};\\\", \\\"{x:1312,y:681,t:1528139913919};\\\", \\\"{x:1305,y:692,t:1528139913936};\\\", \\\"{x:1297,y:706,t:1528139913952};\\\", \\\"{x:1291,y:720,t:1528139913970};\\\", \\\"{x:1285,y:736,t:1528139913986};\\\", \\\"{x:1282,y:747,t:1528139914004};\\\", \\\"{x:1278,y:760,t:1528139914020};\\\", \\\"{x:1274,y:772,t:1528139914037};\\\", \\\"{x:1271,y:782,t:1528139914054};\\\", \\\"{x:1268,y:792,t:1528139914069};\\\", \\\"{x:1264,y:812,t:1528139914086};\\\", \\\"{x:1262,y:829,t:1528139914103};\\\", \\\"{x:1259,y:852,t:1528139914120};\\\", \\\"{x:1259,y:878,t:1528139914136};\\\", \\\"{x:1255,y:902,t:1528139914153};\\\", \\\"{x:1251,y:921,t:1528139914169};\\\", \\\"{x:1246,y:938,t:1528139914187};\\\", \\\"{x:1243,y:949,t:1528139914204};\\\", \\\"{x:1242,y:960,t:1528139914219};\\\", \\\"{x:1242,y:965,t:1528139914236};\\\", \\\"{x:1242,y:968,t:1528139914254};\\\", \\\"{x:1242,y:971,t:1528139914270};\\\", \\\"{x:1242,y:972,t:1528139914286};\\\", \\\"{x:1242,y:974,t:1528139914304};\\\", \\\"{x:1241,y:974,t:1528139914320};\\\", \\\"{x:1241,y:973,t:1528139914559};\\\", \\\"{x:1241,y:966,t:1528139914569};\\\", \\\"{x:1241,y:956,t:1528139914586};\\\", \\\"{x:1242,y:942,t:1528139914603};\\\", \\\"{x:1245,y:932,t:1528139914620};\\\", \\\"{x:1249,y:920,t:1528139914637};\\\", \\\"{x:1251,y:915,t:1528139914654};\\\", \\\"{x:1255,y:910,t:1528139914671};\\\", \\\"{x:1258,y:907,t:1528139914687};\\\", \\\"{x:1260,y:903,t:1528139914703};\\\", \\\"{x:1263,y:900,t:1528139914720};\\\", \\\"{x:1267,y:895,t:1528139914736};\\\", \\\"{x:1272,y:887,t:1528139914754};\\\", \\\"{x:1277,y:879,t:1528139914770};\\\", \\\"{x:1283,y:867,t:1528139914787};\\\", \\\"{x:1292,y:852,t:1528139914804};\\\", \\\"{x:1300,y:837,t:1528139914821};\\\", \\\"{x:1309,y:821,t:1528139914837};\\\", \\\"{x:1319,y:803,t:1528139914854};\\\", \\\"{x:1329,y:788,t:1528139914871};\\\", \\\"{x:1333,y:780,t:1528139914886};\\\", \\\"{x:1338,y:775,t:1528139914904};\\\", \\\"{x:1339,y:771,t:1528139914920};\\\", \\\"{x:1341,y:767,t:1528139914937};\\\", \\\"{x:1343,y:760,t:1528139914954};\\\", \\\"{x:1346,y:755,t:1528139914971};\\\", \\\"{x:1349,y:747,t:1528139914987};\\\", \\\"{x:1350,y:741,t:1528139915004};\\\", \\\"{x:1353,y:734,t:1528139915021};\\\", \\\"{x:1355,y:726,t:1528139915037};\\\", \\\"{x:1358,y:717,t:1528139915054};\\\", \\\"{x:1360,y:699,t:1528139915071};\\\", \\\"{x:1365,y:683,t:1528139915086};\\\", \\\"{x:1371,y:670,t:1528139915104};\\\", \\\"{x:1374,y:658,t:1528139915120};\\\", \\\"{x:1377,y:651,t:1528139915138};\\\", \\\"{x:1379,y:646,t:1528139915153};\\\", \\\"{x:1379,y:642,t:1528139915171};\\\", \\\"{x:1381,y:639,t:1528139915188};\\\", \\\"{x:1381,y:635,t:1528139915204};\\\", \\\"{x:1381,y:632,t:1528139915220};\\\", \\\"{x:1382,y:631,t:1528139915238};\\\", \\\"{x:1382,y:628,t:1528139915254};\\\", \\\"{x:1385,y:622,t:1528139915270};\\\", \\\"{x:1386,y:617,t:1528139915288};\\\", \\\"{x:1387,y:611,t:1528139915304};\\\", \\\"{x:1390,y:604,t:1528139915320};\\\", \\\"{x:1393,y:595,t:1528139915337};\\\", \\\"{x:1396,y:586,t:1528139915353};\\\", \\\"{x:1400,y:577,t:1528139915371};\\\", \\\"{x:1405,y:570,t:1528139915388};\\\", \\\"{x:1409,y:563,t:1528139915404};\\\", \\\"{x:1411,y:560,t:1528139915421};\\\", \\\"{x:1412,y:558,t:1528139915438};\\\", \\\"{x:1413,y:557,t:1528139915454};\\\", \\\"{x:1414,y:556,t:1528139915470};\\\", \\\"{x:1413,y:555,t:1528139915654};\\\", \\\"{x:1402,y:559,t:1528139915670};\\\", \\\"{x:1389,y:567,t:1528139915688};\\\", \\\"{x:1382,y:576,t:1528139915704};\\\", \\\"{x:1377,y:581,t:1528139915720};\\\", \\\"{x:1374,y:583,t:1528139915737};\\\", \\\"{x:1373,y:585,t:1528139915755};\\\", \\\"{x:1372,y:586,t:1528139915770};\\\", \\\"{x:1371,y:587,t:1528139915863};\\\", \\\"{x:1370,y:592,t:1528139915871};\\\", \\\"{x:1368,y:595,t:1528139915888};\\\", \\\"{x:1366,y:605,t:1528139915904};\\\", \\\"{x:1362,y:615,t:1528139915920};\\\", \\\"{x:1358,y:628,t:1528139915936};\\\", \\\"{x:1354,y:644,t:1528139915954};\\\", \\\"{x:1351,y:657,t:1528139915969};\\\", \\\"{x:1346,y:668,t:1528139915986};\\\", \\\"{x:1343,y:677,t:1528139916004};\\\", \\\"{x:1338,y:685,t:1528139916020};\\\", \\\"{x:1337,y:689,t:1528139916037};\\\", \\\"{x:1335,y:692,t:1528139916054};\\\", \\\"{x:1334,y:693,t:1528139916078};\\\", \\\"{x:1334,y:695,t:1528139916151};\\\", \\\"{x:1334,y:698,t:1528139916159};\\\", \\\"{x:1334,y:699,t:1528139916171};\\\", \\\"{x:1334,y:700,t:1528139916188};\\\", \\\"{x:1334,y:702,t:1528139916204};\\\", \\\"{x:1334,y:705,t:1528139916221};\\\", \\\"{x:1333,y:706,t:1528139916238};\\\", \\\"{x:1333,y:707,t:1528139916254};\\\", \\\"{x:1334,y:707,t:1528139916439};\\\", \\\"{x:1339,y:707,t:1528139916455};\\\", \\\"{x:1340,y:707,t:1528139916479};\\\", \\\"{x:1341,y:707,t:1528139916502};\\\", \\\"{x:1342,y:707,t:1528139916535};\\\", \\\"{x:1343,y:707,t:1528139916551};\\\", \\\"{x:1343,y:706,t:1528139916558};\\\", \\\"{x:1343,y:705,t:1528139916574};\\\", \\\"{x:1343,y:704,t:1528139916589};\\\", \\\"{x:1345,y:702,t:1528139916605};\\\", \\\"{x:1346,y:701,t:1528139916621};\\\", \\\"{x:1346,y:700,t:1528139916662};\\\", \\\"{x:1349,y:683,t:1528139918376};\\\", \\\"{x:1350,y:668,t:1528139918390};\\\", \\\"{x:1354,y:658,t:1528139918406};\\\", \\\"{x:1359,y:641,t:1528139918423};\\\", \\\"{x:1361,y:634,t:1528139918440};\\\", \\\"{x:1363,y:626,t:1528139918456};\\\", \\\"{x:1364,y:623,t:1528139918473};\\\", \\\"{x:1365,y:618,t:1528139918490};\\\", \\\"{x:1367,y:614,t:1528139918506};\\\", \\\"{x:1368,y:607,t:1528139918522};\\\", \\\"{x:1368,y:604,t:1528139918539};\\\", \\\"{x:1369,y:599,t:1528139918556};\\\", \\\"{x:1371,y:594,t:1528139918573};\\\", \\\"{x:1371,y:590,t:1528139918590};\\\", \\\"{x:1371,y:587,t:1528139918605};\\\", \\\"{x:1372,y:586,t:1528139918622};\\\", \\\"{x:1372,y:585,t:1528139918639};\\\", \\\"{x:1373,y:584,t:1528139918663};\\\", \\\"{x:1373,y:583,t:1528139918678};\\\", \\\"{x:1374,y:582,t:1528139918690};\\\", \\\"{x:1375,y:581,t:1528139918707};\\\", \\\"{x:1376,y:578,t:1528139918722};\\\", \\\"{x:1377,y:577,t:1528139918740};\\\", \\\"{x:1378,y:577,t:1528139918757};\\\", \\\"{x:1380,y:571,t:1528139919126};\\\", \\\"{x:1384,y:565,t:1528139919139};\\\", \\\"{x:1393,y:553,t:1528139919157};\\\", \\\"{x:1399,y:547,t:1528139919174};\\\", \\\"{x:1403,y:545,t:1528139919190};\\\", \\\"{x:1405,y:543,t:1528139919206};\\\", \\\"{x:1407,y:542,t:1528139919224};\\\", \\\"{x:1409,y:540,t:1528139919240};\\\", \\\"{x:1411,y:537,t:1528139919256};\\\", \\\"{x:1412,y:535,t:1528139919274};\\\", \\\"{x:1415,y:530,t:1528139919290};\\\", \\\"{x:1419,y:525,t:1528139919307};\\\", \\\"{x:1423,y:518,t:1528139919323};\\\", \\\"{x:1426,y:514,t:1528139919339};\\\", \\\"{x:1428,y:512,t:1528139919357};\\\", \\\"{x:1429,y:512,t:1528139919374};\\\", \\\"{x:1429,y:511,t:1528139919390};\\\", \\\"{x:1430,y:510,t:1528139919534};\\\", \\\"{x:1430,y:509,t:1528139919542};\\\", \\\"{x:1430,y:508,t:1528139919556};\\\", \\\"{x:1432,y:507,t:1528139919573};\\\", \\\"{x:1432,y:506,t:1528139919589};\\\", \\\"{x:1433,y:505,t:1528139919606};\\\", \\\"{x:1432,y:504,t:1528139920054};\\\", \\\"{x:1429,y:504,t:1528139920062};\\\", \\\"{x:1427,y:504,t:1528139920073};\\\", \\\"{x:1424,y:506,t:1528139920090};\\\", \\\"{x:1419,y:508,t:1528139920106};\\\", \\\"{x:1412,y:510,t:1528139920122};\\\", \\\"{x:1405,y:514,t:1528139920140};\\\", \\\"{x:1395,y:518,t:1528139920156};\\\", \\\"{x:1390,y:522,t:1528139920173};\\\", \\\"{x:1380,y:525,t:1528139920190};\\\", \\\"{x:1377,y:526,t:1528139920208};\\\", \\\"{x:1375,y:527,t:1528139920224};\\\", \\\"{x:1373,y:528,t:1528139920241};\\\", \\\"{x:1372,y:528,t:1528139920258};\\\", \\\"{x:1372,y:529,t:1528139920273};\\\", \\\"{x:1370,y:529,t:1528139920291};\\\", \\\"{x:1368,y:530,t:1528139920307};\\\", \\\"{x:1363,y:532,t:1528139920324};\\\", \\\"{x:1356,y:536,t:1528139920340};\\\", \\\"{x:1348,y:539,t:1528139920357};\\\", \\\"{x:1337,y:547,t:1528139920373};\\\", \\\"{x:1318,y:563,t:1528139920391};\\\", \\\"{x:1309,y:572,t:1528139920408};\\\", \\\"{x:1303,y:576,t:1528139920423};\\\", \\\"{x:1300,y:577,t:1528139920440};\\\", \\\"{x:1298,y:579,t:1528139920462};\\\", \\\"{x:1297,y:579,t:1528139920799};\\\", \\\"{x:1295,y:581,t:1528139920808};\\\", \\\"{x:1286,y:596,t:1528139920825};\\\", \\\"{x:1274,y:620,t:1528139920841};\\\", \\\"{x:1263,y:642,t:1528139920857};\\\", \\\"{x:1250,y:662,t:1528139920875};\\\", \\\"{x:1239,y:681,t:1528139920890};\\\", \\\"{x:1232,y:692,t:1528139920907};\\\", \\\"{x:1230,y:698,t:1528139920924};\\\", \\\"{x:1226,y:705,t:1528139920940};\\\", \\\"{x:1224,y:712,t:1528139920957};\\\", \\\"{x:1222,y:717,t:1528139920973};\\\", \\\"{x:1219,y:721,t:1528139920990};\\\", \\\"{x:1218,y:725,t:1528139921007};\\\", \\\"{x:1214,y:731,t:1528139921024};\\\", \\\"{x:1210,y:738,t:1528139921040};\\\", \\\"{x:1205,y:750,t:1528139921057};\\\", \\\"{x:1200,y:763,t:1528139921074};\\\", \\\"{x:1195,y:775,t:1528139921091};\\\", \\\"{x:1187,y:789,t:1528139921107};\\\", \\\"{x:1180,y:803,t:1528139921124};\\\", \\\"{x:1174,y:822,t:1528139921140};\\\", \\\"{x:1163,y:843,t:1528139921157};\\\", \\\"{x:1158,y:852,t:1528139921173};\\\", \\\"{x:1153,y:859,t:1528139921191};\\\", \\\"{x:1150,y:862,t:1528139921207};\\\", \\\"{x:1147,y:866,t:1528139921224};\\\", \\\"{x:1145,y:869,t:1528139921241};\\\", \\\"{x:1142,y:871,t:1528139921257};\\\", \\\"{x:1137,y:875,t:1528139921275};\\\", \\\"{x:1135,y:875,t:1528139921292};\\\", \\\"{x:1122,y:881,t:1528139921308};\\\", \\\"{x:1121,y:882,t:1528139921324};\\\", \\\"{x:1121,y:880,t:1528139921486};\\\", \\\"{x:1121,y:877,t:1528139921502};\\\", \\\"{x:1121,y:876,t:1528139921527};\\\", \\\"{x:1121,y:875,t:1528139921542};\\\", \\\"{x:1123,y:871,t:1528139921679};\\\", \\\"{x:1127,y:866,t:1528139921691};\\\", \\\"{x:1133,y:851,t:1528139921707};\\\", \\\"{x:1141,y:836,t:1528139921725};\\\", \\\"{x:1157,y:802,t:1528139921741};\\\", \\\"{x:1168,y:782,t:1528139921757};\\\", \\\"{x:1179,y:762,t:1528139921774};\\\", \\\"{x:1191,y:742,t:1528139921792};\\\", \\\"{x:1201,y:728,t:1528139921808};\\\", \\\"{x:1209,y:716,t:1528139921823};\\\", \\\"{x:1216,y:707,t:1528139921840};\\\", \\\"{x:1219,y:702,t:1528139921858};\\\", \\\"{x:1220,y:698,t:1528139921874};\\\", \\\"{x:1225,y:688,t:1528139921891};\\\", \\\"{x:1229,y:675,t:1528139921908};\\\", \\\"{x:1233,y:664,t:1528139921924};\\\", \\\"{x:1234,y:655,t:1528139921941};\\\", \\\"{x:1237,y:642,t:1528139921957};\\\", \\\"{x:1240,y:625,t:1528139921975};\\\", \\\"{x:1244,y:612,t:1528139921991};\\\", \\\"{x:1245,y:606,t:1528139922008};\\\", \\\"{x:1246,y:601,t:1528139922024};\\\", \\\"{x:1246,y:600,t:1528139922047};\\\", \\\"{x:1248,y:605,t:1528139922182};\\\", \\\"{x:1261,y:642,t:1528139922191};\\\", \\\"{x:1296,y:730,t:1528139922209};\\\", \\\"{x:1331,y:787,t:1528139922225};\\\", \\\"{x:1361,y:832,t:1528139922241};\\\", \\\"{x:1385,y:866,t:1528139922259};\\\", \\\"{x:1409,y:892,t:1528139922275};\\\", \\\"{x:1426,y:916,t:1528139922292};\\\", \\\"{x:1442,y:938,t:1528139922309};\\\", \\\"{x:1448,y:954,t:1528139922325};\\\", \\\"{x:1449,y:963,t:1528139922341};\\\", \\\"{x:1448,y:967,t:1528139922358};\\\", \\\"{x:1441,y:968,t:1528139922375};\\\", \\\"{x:1419,y:968,t:1528139922391};\\\", \\\"{x:1359,y:956,t:1528139922408};\\\", \\\"{x:1294,y:946,t:1528139922425};\\\", \\\"{x:1238,y:938,t:1528139922441};\\\", \\\"{x:1152,y:925,t:1528139922458};\\\", \\\"{x:1063,y:898,t:1528139922475};\\\", \\\"{x:1007,y:881,t:1528139922491};\\\", \\\"{x:928,y:853,t:1528139922508};\\\", \\\"{x:884,y:833,t:1528139922525};\\\", \\\"{x:848,y:818,t:1528139922541};\\\", \\\"{x:792,y:790,t:1528139922558};\\\", \\\"{x:747,y:776,t:1528139922575};\\\", \\\"{x:703,y:766,t:1528139922591};\\\", \\\"{x:672,y:762,t:1528139922608};\\\", \\\"{x:646,y:762,t:1528139922625};\\\", \\\"{x:629,y:762,t:1528139922641};\\\", \\\"{x:615,y:762,t:1528139922658};\\\", \\\"{x:605,y:762,t:1528139922675};\\\", \\\"{x:597,y:762,t:1528139922691};\\\", \\\"{x:588,y:760,t:1528139922708};\\\", \\\"{x:573,y:755,t:1528139922725};\\\", \\\"{x:549,y:744,t:1528139922744};\\\", \\\"{x:535,y:739,t:1528139922758};\\\", \\\"{x:529,y:736,t:1528139922775};\\\", \\\"{x:525,y:735,t:1528139922791};\\\", \\\"{x:521,y:734,t:1528139922808};\\\", \\\"{x:518,y:733,t:1528139922825};\\\", \\\"{x:512,y:732,t:1528139922841};\\\", \\\"{x:501,y:732,t:1528139922858};\\\", \\\"{x:493,y:732,t:1528139922875};\\\", \\\"{x:484,y:733,t:1528139922890};\\\", \\\"{x:479,y:733,t:1528139922908};\\\", \\\"{x:475,y:733,t:1528139922925};\\\", \\\"{x:473,y:733,t:1528139923125};\\\", \\\"{x:473,y:733,t:1528139923201};\\\" ] }, { \\\"rt\\\": 44554, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 636485, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -J -J -J -08 AM-I -B -J -12 PM-11 AM-J -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:733,t:1528139930157};\\\", \\\"{x:522,y:721,t:1528139930168};\\\", \\\"{x:677,y:699,t:1528139930185};\\\", \\\"{x:774,y:699,t:1528139930202};\\\", \\\"{x:800,y:699,t:1528139930218};\\\", \\\"{x:818,y:701,t:1528139930232};\\\", \\\"{x:872,y:704,t:1528139930249};\\\", \\\"{x:961,y:719,t:1528139930266};\\\", \\\"{x:1027,y:732,t:1528139930282};\\\", \\\"{x:1041,y:736,t:1528139930299};\\\", \\\"{x:1042,y:737,t:1528139930316};\\\", \\\"{x:1049,y:740,t:1528139930333};\\\", \\\"{x:1117,y:787,t:1528139930349};\\\", \\\"{x:1158,y:820,t:1528139930366};\\\", \\\"{x:1187,y:840,t:1528139930382};\\\", \\\"{x:1198,y:849,t:1528139930400};\\\", \\\"{x:1199,y:850,t:1528139930416};\\\", \\\"{x:1200,y:850,t:1528139930446};\\\", \\\"{x:1202,y:850,t:1528139930566};\\\", \\\"{x:1203,y:850,t:1528139930926};\\\", \\\"{x:1204,y:850,t:1528139931079};\\\", \\\"{x:1205,y:848,t:1528139931093};\\\", \\\"{x:1207,y:844,t:1528139931102};\\\", \\\"{x:1208,y:843,t:1528139931117};\\\", \\\"{x:1210,y:838,t:1528139931134};\\\", \\\"{x:1211,y:837,t:1528139931151};\\\", \\\"{x:1211,y:836,t:1528139931167};\\\", \\\"{x:1212,y:835,t:1528139931310};\\\", \\\"{x:1213,y:835,t:1528139931341};\\\", \\\"{x:1213,y:834,t:1528139931357};\\\", \\\"{x:1214,y:833,t:1528139931366};\\\", \\\"{x:1214,y:832,t:1528139931383};\\\", \\\"{x:1213,y:836,t:1528139932815};\\\", \\\"{x:1208,y:846,t:1528139932832};\\\", \\\"{x:1205,y:854,t:1528139932849};\\\", \\\"{x:1202,y:857,t:1528139932866};\\\", \\\"{x:1200,y:860,t:1528139932881};\\\", \\\"{x:1199,y:864,t:1528139932899};\\\", \\\"{x:1198,y:868,t:1528139932916};\\\", \\\"{x:1196,y:872,t:1528139932932};\\\", \\\"{x:1195,y:875,t:1528139932949};\\\", \\\"{x:1193,y:878,t:1528139932967};\\\", \\\"{x:1192,y:883,t:1528139932983};\\\", \\\"{x:1191,y:887,t:1528139932999};\\\", \\\"{x:1188,y:894,t:1528139933016};\\\", \\\"{x:1183,y:901,t:1528139933033};\\\", \\\"{x:1179,y:909,t:1528139933049};\\\", \\\"{x:1171,y:918,t:1528139933066};\\\", \\\"{x:1164,y:927,t:1528139933083};\\\", \\\"{x:1161,y:934,t:1528139933099};\\\", \\\"{x:1158,y:939,t:1528139933116};\\\", \\\"{x:1155,y:943,t:1528139933134};\\\", \\\"{x:1153,y:946,t:1528139933150};\\\", \\\"{x:1151,y:948,t:1528139933166};\\\", \\\"{x:1150,y:949,t:1528139933183};\\\", \\\"{x:1150,y:946,t:1528139933642};\\\", \\\"{x:1150,y:944,t:1528139933651};\\\", \\\"{x:1151,y:942,t:1528139933666};\\\", \\\"{x:1152,y:938,t:1528139933683};\\\", \\\"{x:1152,y:937,t:1528139933700};\\\", \\\"{x:1152,y:936,t:1528139933718};\\\", \\\"{x:1152,y:935,t:1528139933852};\\\", \\\"{x:1153,y:935,t:1528139933948};\\\", \\\"{x:1154,y:933,t:1528139933996};\\\", \\\"{x:1155,y:931,t:1528139934003};\\\", \\\"{x:1155,y:930,t:1528139934017};\\\", \\\"{x:1157,y:927,t:1528139934034};\\\", \\\"{x:1159,y:925,t:1528139934051};\\\", \\\"{x:1162,y:920,t:1528139934067};\\\", \\\"{x:1164,y:917,t:1528139934084};\\\", \\\"{x:1165,y:915,t:1528139934101};\\\", \\\"{x:1166,y:914,t:1528139934117};\\\", \\\"{x:1168,y:911,t:1528139934134};\\\", \\\"{x:1170,y:908,t:1528139934150};\\\", \\\"{x:1171,y:907,t:1528139934166};\\\", \\\"{x:1172,y:905,t:1528139934184};\\\", \\\"{x:1174,y:901,t:1528139934200};\\\", \\\"{x:1176,y:899,t:1528139934216};\\\", \\\"{x:1178,y:897,t:1528139934234};\\\", \\\"{x:1180,y:894,t:1528139934250};\\\", \\\"{x:1182,y:892,t:1528139934267};\\\", \\\"{x:1183,y:891,t:1528139934284};\\\", \\\"{x:1185,y:889,t:1528139934300};\\\", \\\"{x:1187,y:887,t:1528139934318};\\\", \\\"{x:1190,y:883,t:1528139934334};\\\", \\\"{x:1193,y:878,t:1528139934350};\\\", \\\"{x:1198,y:872,t:1528139934367};\\\", \\\"{x:1202,y:868,t:1528139934384};\\\", \\\"{x:1207,y:863,t:1528139934400};\\\", \\\"{x:1212,y:857,t:1528139934418};\\\", \\\"{x:1216,y:854,t:1528139934435};\\\", \\\"{x:1221,y:849,t:1528139934451};\\\", \\\"{x:1226,y:844,t:1528139934467};\\\", \\\"{x:1230,y:839,t:1528139934485};\\\", \\\"{x:1235,y:834,t:1528139934501};\\\", \\\"{x:1243,y:827,t:1528139934517};\\\", \\\"{x:1250,y:822,t:1528139934535};\\\", \\\"{x:1258,y:818,t:1528139934551};\\\", \\\"{x:1264,y:813,t:1528139934567};\\\", \\\"{x:1271,y:810,t:1528139934584};\\\", \\\"{x:1276,y:806,t:1528139934601};\\\", \\\"{x:1283,y:804,t:1528139934618};\\\", \\\"{x:1287,y:801,t:1528139934634};\\\", \\\"{x:1294,y:797,t:1528139934651};\\\", \\\"{x:1297,y:795,t:1528139934667};\\\", \\\"{x:1301,y:794,t:1528139934685};\\\", \\\"{x:1303,y:793,t:1528139934701};\\\", \\\"{x:1304,y:792,t:1528139934718};\\\", \\\"{x:1307,y:791,t:1528139934734};\\\", \\\"{x:1309,y:790,t:1528139934751};\\\", \\\"{x:1312,y:788,t:1528139934767};\\\", \\\"{x:1315,y:787,t:1528139934785};\\\", \\\"{x:1318,y:784,t:1528139934801};\\\", \\\"{x:1321,y:782,t:1528139934818};\\\", \\\"{x:1325,y:780,t:1528139934834};\\\", \\\"{x:1333,y:776,t:1528139934851};\\\", \\\"{x:1338,y:773,t:1528139934868};\\\", \\\"{x:1346,y:768,t:1528139934885};\\\", \\\"{x:1354,y:764,t:1528139934902};\\\", \\\"{x:1361,y:758,t:1528139934919};\\\", \\\"{x:1374,y:754,t:1528139934935};\\\", \\\"{x:1380,y:749,t:1528139934952};\\\", \\\"{x:1383,y:747,t:1528139934969};\\\", \\\"{x:1384,y:746,t:1528139934984};\\\", \\\"{x:1385,y:746,t:1528139935002};\\\", \\\"{x:1386,y:746,t:1528139935691};\\\", \\\"{x:1390,y:742,t:1528139935703};\\\", \\\"{x:1395,y:734,t:1528139935719};\\\", \\\"{x:1398,y:731,t:1528139935736};\\\", \\\"{x:1399,y:730,t:1528139935752};\\\", \\\"{x:1400,y:729,t:1528139935769};\\\", \\\"{x:1399,y:729,t:1528139935932};\\\", \\\"{x:1391,y:731,t:1528139935940};\\\", \\\"{x:1388,y:733,t:1528139935953};\\\", \\\"{x:1379,y:737,t:1528139935970};\\\", \\\"{x:1375,y:738,t:1528139935986};\\\", \\\"{x:1373,y:740,t:1528139936003};\\\", \\\"{x:1372,y:740,t:1528139936035};\\\", \\\"{x:1370,y:740,t:1528139936075};\\\", \\\"{x:1370,y:741,t:1528139936086};\\\", \\\"{x:1368,y:742,t:1528139936103};\\\", \\\"{x:1367,y:742,t:1528139936120};\\\", \\\"{x:1366,y:743,t:1528139936136};\\\", \\\"{x:1365,y:743,t:1528139936153};\\\", \\\"{x:1363,y:744,t:1528139936170};\\\", \\\"{x:1357,y:746,t:1528139936186};\\\", \\\"{x:1351,y:750,t:1528139936202};\\\", \\\"{x:1342,y:756,t:1528139936220};\\\", \\\"{x:1334,y:760,t:1528139936235};\\\", \\\"{x:1330,y:762,t:1528139936253};\\\", \\\"{x:1324,y:765,t:1528139936270};\\\", \\\"{x:1318,y:769,t:1528139936286};\\\", \\\"{x:1313,y:771,t:1528139936303};\\\", \\\"{x:1307,y:775,t:1528139936320};\\\", \\\"{x:1300,y:778,t:1528139936336};\\\", \\\"{x:1285,y:784,t:1528139936353};\\\", \\\"{x:1273,y:791,t:1528139936370};\\\", \\\"{x:1261,y:797,t:1528139936386};\\\", \\\"{x:1248,y:804,t:1528139936403};\\\", \\\"{x:1231,y:815,t:1528139936419};\\\", \\\"{x:1222,y:821,t:1528139936437};\\\", \\\"{x:1214,y:826,t:1528139936453};\\\", \\\"{x:1208,y:829,t:1528139936471};\\\", \\\"{x:1200,y:835,t:1528139936486};\\\", \\\"{x:1195,y:838,t:1528139936502};\\\", \\\"{x:1190,y:841,t:1528139936520};\\\", \\\"{x:1185,y:844,t:1528139936537};\\\", \\\"{x:1182,y:847,t:1528139936553};\\\", \\\"{x:1180,y:847,t:1528139936569};\\\", \\\"{x:1178,y:849,t:1528139936587};\\\", \\\"{x:1177,y:850,t:1528139936602};\\\", \\\"{x:1176,y:851,t:1528139936619};\\\", \\\"{x:1175,y:851,t:1528139936637};\\\", \\\"{x:1174,y:852,t:1528139936660};\\\", \\\"{x:1175,y:852,t:1528139936972};\\\", \\\"{x:1177,y:852,t:1528139936987};\\\", \\\"{x:1186,y:848,t:1528139937003};\\\", \\\"{x:1190,y:845,t:1528139937020};\\\", \\\"{x:1192,y:844,t:1528139937036};\\\", \\\"{x:1196,y:842,t:1528139937054};\\\", \\\"{x:1197,y:841,t:1528139937069};\\\", \\\"{x:1202,y:838,t:1528139937087};\\\", \\\"{x:1208,y:834,t:1528139937104};\\\", \\\"{x:1214,y:830,t:1528139937121};\\\", \\\"{x:1218,y:827,t:1528139937136};\\\", \\\"{x:1221,y:825,t:1528139937154};\\\", \\\"{x:1222,y:825,t:1528139937171};\\\", \\\"{x:1223,y:824,t:1528139937187};\\\", \\\"{x:1224,y:823,t:1528139937204};\\\", \\\"{x:1225,y:822,t:1528139937252};\\\", \\\"{x:1223,y:824,t:1528139937555};\\\", \\\"{x:1212,y:831,t:1528139937571};\\\", \\\"{x:1192,y:848,t:1528139937589};\\\", \\\"{x:1185,y:853,t:1528139937603};\\\", \\\"{x:1180,y:859,t:1528139937620};\\\", \\\"{x:1178,y:861,t:1528139937637};\\\", \\\"{x:1175,y:866,t:1528139937654};\\\", \\\"{x:1171,y:874,t:1528139937671};\\\", \\\"{x:1165,y:881,t:1528139937688};\\\", \\\"{x:1163,y:887,t:1528139937704};\\\", \\\"{x:1161,y:890,t:1528139937721};\\\", \\\"{x:1160,y:893,t:1528139937738};\\\", \\\"{x:1160,y:894,t:1528139937753};\\\", \\\"{x:1158,y:898,t:1528139937771};\\\", \\\"{x:1156,y:902,t:1528139937787};\\\", \\\"{x:1153,y:908,t:1528139937804};\\\", \\\"{x:1149,y:915,t:1528139937821};\\\", \\\"{x:1146,y:919,t:1528139937838};\\\", \\\"{x:1143,y:924,t:1528139937854};\\\", \\\"{x:1141,y:928,t:1528139937870};\\\", \\\"{x:1137,y:937,t:1528139937887};\\\", \\\"{x:1133,y:944,t:1528139937903};\\\", \\\"{x:1130,y:950,t:1528139937920};\\\", \\\"{x:1129,y:953,t:1528139937937};\\\", \\\"{x:1126,y:956,t:1528139937954};\\\", \\\"{x:1126,y:957,t:1528139937970};\\\", \\\"{x:1120,y:961,t:1528139937987};\\\", \\\"{x:1117,y:963,t:1528139938005};\\\", \\\"{x:1114,y:965,t:1528139938020};\\\", \\\"{x:1109,y:969,t:1528139938037};\\\", \\\"{x:1105,y:971,t:1528139938054};\\\", \\\"{x:1101,y:973,t:1528139938071};\\\", \\\"{x:1093,y:975,t:1528139938087};\\\", \\\"{x:1088,y:977,t:1528139938104};\\\", \\\"{x:1083,y:978,t:1528139938120};\\\", \\\"{x:1080,y:978,t:1528139938138};\\\", \\\"{x:1078,y:979,t:1528139938154};\\\", \\\"{x:1077,y:979,t:1528139938171};\\\", \\\"{x:1077,y:978,t:1528139938348};\\\", \\\"{x:1077,y:977,t:1528139938356};\\\", \\\"{x:1077,y:975,t:1528139938372};\\\", \\\"{x:1077,y:972,t:1528139938387};\\\", \\\"{x:1077,y:969,t:1528139938405};\\\", \\\"{x:1077,y:965,t:1528139938422};\\\", \\\"{x:1078,y:962,t:1528139938437};\\\", \\\"{x:1078,y:959,t:1528139938454};\\\", \\\"{x:1079,y:956,t:1528139938472};\\\", \\\"{x:1080,y:954,t:1528139938488};\\\", \\\"{x:1081,y:952,t:1528139938505};\\\", \\\"{x:1082,y:950,t:1528139938522};\\\", \\\"{x:1083,y:948,t:1528139938538};\\\", \\\"{x:1084,y:948,t:1528139938554};\\\", \\\"{x:1084,y:947,t:1528139938572};\\\", \\\"{x:1085,y:946,t:1528139938588};\\\", \\\"{x:1085,y:945,t:1528139938605};\\\", \\\"{x:1085,y:944,t:1528139938667};\\\", \\\"{x:1085,y:943,t:1528139939292};\\\", \\\"{x:1086,y:942,t:1528139939316};\\\", \\\"{x:1088,y:941,t:1528139939332};\\\", \\\"{x:1091,y:940,t:1528139939339};\\\", \\\"{x:1091,y:939,t:1528139939355};\\\", \\\"{x:1093,y:938,t:1528139939373};\\\", \\\"{x:1094,y:937,t:1528139939389};\\\", \\\"{x:1094,y:936,t:1528139939405};\\\", \\\"{x:1096,y:934,t:1528139939423};\\\", \\\"{x:1097,y:933,t:1528139939439};\\\", \\\"{x:1100,y:930,t:1528139939456};\\\", \\\"{x:1103,y:926,t:1528139939472};\\\", \\\"{x:1105,y:924,t:1528139939489};\\\", \\\"{x:1108,y:921,t:1528139939505};\\\", \\\"{x:1110,y:919,t:1528139939523};\\\", \\\"{x:1112,y:916,t:1528139939538};\\\", \\\"{x:1114,y:914,t:1528139939556};\\\", \\\"{x:1115,y:913,t:1528139939572};\\\", \\\"{x:1116,y:911,t:1528139939589};\\\", \\\"{x:1117,y:909,t:1528139939606};\\\", \\\"{x:1118,y:907,t:1528139939623};\\\", \\\"{x:1119,y:905,t:1528139939639};\\\", \\\"{x:1120,y:904,t:1528139939656};\\\", \\\"{x:1121,y:902,t:1528139939672};\\\", \\\"{x:1121,y:900,t:1528139939689};\\\", \\\"{x:1121,y:899,t:1528139939707};\\\", \\\"{x:1122,y:897,t:1528139939723};\\\", \\\"{x:1123,y:894,t:1528139939739};\\\", \\\"{x:1124,y:893,t:1528139939755};\\\", \\\"{x:1125,y:891,t:1528139939772};\\\", \\\"{x:1126,y:889,t:1528139939789};\\\", \\\"{x:1127,y:888,t:1528139939806};\\\", \\\"{x:1127,y:887,t:1528139939822};\\\", \\\"{x:1128,y:886,t:1528139939839};\\\", \\\"{x:1128,y:884,t:1528139939855};\\\", \\\"{x:1129,y:884,t:1528139939872};\\\", \\\"{x:1129,y:883,t:1528139939889};\\\", \\\"{x:1130,y:882,t:1528139939905};\\\", \\\"{x:1131,y:881,t:1528139939922};\\\", \\\"{x:1131,y:880,t:1528139939955};\\\", \\\"{x:1131,y:878,t:1528139939972};\\\", \\\"{x:1133,y:877,t:1528139939995};\\\", \\\"{x:1133,y:875,t:1528139940019};\\\", \\\"{x:1134,y:874,t:1528139940027};\\\", \\\"{x:1134,y:872,t:1528139940052};\\\", \\\"{x:1136,y:871,t:1528139940060};\\\", \\\"{x:1136,y:870,t:1528139940073};\\\", \\\"{x:1137,y:868,t:1528139940089};\\\", \\\"{x:1138,y:866,t:1528139940105};\\\", \\\"{x:1140,y:861,t:1528139940122};\\\", \\\"{x:1145,y:852,t:1528139940139};\\\", \\\"{x:1148,y:848,t:1528139940156};\\\", \\\"{x:1152,y:842,t:1528139940172};\\\", \\\"{x:1154,y:838,t:1528139940190};\\\", \\\"{x:1157,y:834,t:1528139940207};\\\", \\\"{x:1159,y:829,t:1528139940222};\\\", \\\"{x:1163,y:824,t:1528139940239};\\\", \\\"{x:1167,y:820,t:1528139940257};\\\", \\\"{x:1170,y:817,t:1528139940272};\\\", \\\"{x:1172,y:814,t:1528139940290};\\\", \\\"{x:1175,y:811,t:1528139940307};\\\", \\\"{x:1177,y:809,t:1528139940323};\\\", \\\"{x:1181,y:804,t:1528139940340};\\\", \\\"{x:1184,y:800,t:1528139940357};\\\", \\\"{x:1186,y:796,t:1528139940373};\\\", \\\"{x:1188,y:792,t:1528139940390};\\\", \\\"{x:1191,y:788,t:1528139940407};\\\", \\\"{x:1192,y:784,t:1528139940423};\\\", \\\"{x:1194,y:782,t:1528139940440};\\\", \\\"{x:1194,y:780,t:1528139940457};\\\", \\\"{x:1197,y:776,t:1528139940472};\\\", \\\"{x:1197,y:774,t:1528139940490};\\\", \\\"{x:1198,y:771,t:1528139940507};\\\", \\\"{x:1199,y:767,t:1528139940523};\\\", \\\"{x:1200,y:766,t:1528139940539};\\\", \\\"{x:1200,y:763,t:1528139940556};\\\", \\\"{x:1201,y:761,t:1528139940573};\\\", \\\"{x:1201,y:760,t:1528139940589};\\\", \\\"{x:1201,y:759,t:1528139941020};\\\", \\\"{x:1198,y:759,t:1528139941035};\\\", \\\"{x:1194,y:760,t:1528139941043};\\\", \\\"{x:1192,y:761,t:1528139941056};\\\", \\\"{x:1189,y:761,t:1528139941074};\\\", \\\"{x:1187,y:763,t:1528139941091};\\\", \\\"{x:1186,y:764,t:1528139941107};\\\", \\\"{x:1184,y:765,t:1528139941124};\\\", \\\"{x:1181,y:765,t:1528139941141};\\\", \\\"{x:1178,y:767,t:1528139941157};\\\", \\\"{x:1176,y:769,t:1528139941174};\\\", \\\"{x:1172,y:771,t:1528139941191};\\\", \\\"{x:1172,y:773,t:1528139941243};\\\", \\\"{x:1174,y:774,t:1528139941257};\\\", \\\"{x:1180,y:776,t:1528139941274};\\\", \\\"{x:1188,y:776,t:1528139941291};\\\", \\\"{x:1211,y:770,t:1528139941308};\\\", \\\"{x:1227,y:767,t:1528139941324};\\\", \\\"{x:1246,y:763,t:1528139941341};\\\", \\\"{x:1257,y:760,t:1528139941358};\\\", \\\"{x:1266,y:757,t:1528139941374};\\\", \\\"{x:1272,y:755,t:1528139941391};\\\", \\\"{x:1280,y:753,t:1528139941408};\\\", \\\"{x:1288,y:751,t:1528139941424};\\\", \\\"{x:1299,y:748,t:1528139941440};\\\", \\\"{x:1308,y:747,t:1528139941458};\\\", \\\"{x:1317,y:745,t:1528139941474};\\\", \\\"{x:1325,y:744,t:1528139941491};\\\", \\\"{x:1329,y:744,t:1528139941507};\\\", \\\"{x:1330,y:743,t:1528139941523};\\\", \\\"{x:1332,y:743,t:1528139941556};\\\", \\\"{x:1333,y:743,t:1528139941563};\\\", \\\"{x:1336,y:743,t:1528139941579};\\\", \\\"{x:1338,y:743,t:1528139941591};\\\", \\\"{x:1342,y:743,t:1528139941608};\\\", \\\"{x:1343,y:743,t:1528139941625};\\\", \\\"{x:1344,y:743,t:1528139941641};\\\", \\\"{x:1342,y:744,t:1528139941756};\\\", \\\"{x:1338,y:751,t:1528139941763};\\\", \\\"{x:1337,y:754,t:1528139941775};\\\", \\\"{x:1332,y:765,t:1528139941790};\\\", \\\"{x:1328,y:771,t:1528139941808};\\\", \\\"{x:1326,y:776,t:1528139941825};\\\", \\\"{x:1324,y:781,t:1528139941841};\\\", \\\"{x:1321,y:786,t:1528139941858};\\\", \\\"{x:1314,y:803,t:1528139941875};\\\", \\\"{x:1312,y:806,t:1528139941891};\\\", \\\"{x:1304,y:825,t:1528139941908};\\\", \\\"{x:1300,y:835,t:1528139941925};\\\", \\\"{x:1296,y:841,t:1528139941941};\\\", \\\"{x:1293,y:844,t:1528139941958};\\\", \\\"{x:1291,y:850,t:1528139941975};\\\", \\\"{x:1289,y:854,t:1528139941991};\\\", \\\"{x:1284,y:863,t:1528139942008};\\\", \\\"{x:1278,y:874,t:1528139942025};\\\", \\\"{x:1271,y:888,t:1528139942042};\\\", \\\"{x:1262,y:900,t:1528139942058};\\\", \\\"{x:1252,y:915,t:1528139942075};\\\", \\\"{x:1246,y:921,t:1528139942091};\\\", \\\"{x:1240,y:927,t:1528139942108};\\\", \\\"{x:1234,y:933,t:1528139942124};\\\", \\\"{x:1226,y:939,t:1528139942142};\\\", \\\"{x:1214,y:949,t:1528139942159};\\\", \\\"{x:1205,y:958,t:1528139942175};\\\", \\\"{x:1196,y:965,t:1528139942192};\\\", \\\"{x:1190,y:971,t:1528139942208};\\\", \\\"{x:1187,y:974,t:1528139942225};\\\", \\\"{x:1185,y:975,t:1528139942242};\\\", \\\"{x:1184,y:976,t:1528139942257};\\\", \\\"{x:1184,y:974,t:1528139942370};\\\", \\\"{x:1185,y:966,t:1528139942378};\\\", \\\"{x:1188,y:961,t:1528139942392};\\\", \\\"{x:1196,y:949,t:1528139942408};\\\", \\\"{x:1208,y:935,t:1528139942424};\\\", \\\"{x:1224,y:921,t:1528139942442};\\\", \\\"{x:1243,y:905,t:1528139942458};\\\", \\\"{x:1257,y:893,t:1528139942474};\\\", \\\"{x:1266,y:882,t:1528139942492};\\\", \\\"{x:1276,y:872,t:1528139942508};\\\", \\\"{x:1283,y:863,t:1528139942525};\\\", \\\"{x:1287,y:856,t:1528139942541};\\\", \\\"{x:1293,y:850,t:1528139942559};\\\", \\\"{x:1296,y:845,t:1528139942575};\\\", \\\"{x:1300,y:842,t:1528139942592};\\\", \\\"{x:1305,y:837,t:1528139942609};\\\", \\\"{x:1310,y:832,t:1528139942625};\\\", \\\"{x:1314,y:828,t:1528139942642};\\\", \\\"{x:1324,y:821,t:1528139942659};\\\", \\\"{x:1333,y:816,t:1528139942675};\\\", \\\"{x:1341,y:810,t:1528139942692};\\\", \\\"{x:1351,y:802,t:1528139942709};\\\", \\\"{x:1363,y:795,t:1528139942725};\\\", \\\"{x:1374,y:786,t:1528139942742};\\\", \\\"{x:1380,y:781,t:1528139942759};\\\", \\\"{x:1384,y:778,t:1528139942774};\\\", \\\"{x:1388,y:774,t:1528139942792};\\\", \\\"{x:1390,y:772,t:1528139942809};\\\", \\\"{x:1391,y:771,t:1528139942826};\\\", \\\"{x:1391,y:769,t:1528139942841};\\\", \\\"{x:1393,y:767,t:1528139942858};\\\", \\\"{x:1394,y:765,t:1528139942875};\\\", \\\"{x:1397,y:762,t:1528139942892};\\\", \\\"{x:1399,y:757,t:1528139942908};\\\", \\\"{x:1403,y:753,t:1528139942926};\\\", \\\"{x:1406,y:749,t:1528139942942};\\\", \\\"{x:1409,y:744,t:1528139942958};\\\", \\\"{x:1409,y:743,t:1528139942975};\\\", \\\"{x:1410,y:742,t:1528139942992};\\\", \\\"{x:1411,y:741,t:1528139943009};\\\", \\\"{x:1412,y:740,t:1528139943026};\\\", \\\"{x:1410,y:739,t:1528139943613};\\\", \\\"{x:1397,y:743,t:1528139943626};\\\", \\\"{x:1370,y:756,t:1528139943643};\\\", \\\"{x:1358,y:759,t:1528139943659};\\\", \\\"{x:1355,y:761,t:1528139943676};\\\", \\\"{x:1354,y:762,t:1528139943813};\\\", \\\"{x:1348,y:765,t:1528139943828};\\\", \\\"{x:1329,y:773,t:1528139943844};\\\", \\\"{x:1301,y:784,t:1528139943859};\\\", \\\"{x:1267,y:796,t:1528139943875};\\\", \\\"{x:1237,y:811,t:1528139943893};\\\", \\\"{x:1218,y:827,t:1528139943911};\\\", \\\"{x:1203,y:840,t:1528139943927};\\\", \\\"{x:1192,y:853,t:1528139943943};\\\", \\\"{x:1186,y:860,t:1528139943960};\\\", \\\"{x:1180,y:867,t:1528139943977};\\\", \\\"{x:1177,y:873,t:1528139943993};\\\", \\\"{x:1172,y:882,t:1528139944010};\\\", \\\"{x:1164,y:896,t:1528139944027};\\\", \\\"{x:1157,y:907,t:1528139944043};\\\", \\\"{x:1144,y:920,t:1528139944060};\\\", \\\"{x:1130,y:931,t:1528139944077};\\\", \\\"{x:1119,y:939,t:1528139944093};\\\", \\\"{x:1112,y:943,t:1528139944110};\\\", \\\"{x:1104,y:947,t:1528139944127};\\\", \\\"{x:1091,y:949,t:1528139944143};\\\", \\\"{x:1076,y:950,t:1528139944160};\\\", \\\"{x:1057,y:952,t:1528139944177};\\\", \\\"{x:1050,y:952,t:1528139944193};\\\", \\\"{x:1047,y:952,t:1528139944209};\\\", \\\"{x:1042,y:956,t:1528139944226};\\\", \\\"{x:1037,y:956,t:1528139944243};\\\", \\\"{x:1035,y:956,t:1528139944259};\\\", \\\"{x:1034,y:954,t:1528139944346};\\\", \\\"{x:1034,y:952,t:1528139944359};\\\", \\\"{x:1041,y:942,t:1528139944376};\\\", \\\"{x:1046,y:939,t:1528139944393};\\\", \\\"{x:1052,y:933,t:1528139944409};\\\", \\\"{x:1062,y:923,t:1528139944427};\\\", \\\"{x:1068,y:918,t:1528139944443};\\\", \\\"{x:1075,y:913,t:1528139944460};\\\", \\\"{x:1084,y:906,t:1528139944477};\\\", \\\"{x:1097,y:897,t:1528139944494};\\\", \\\"{x:1108,y:889,t:1528139944510};\\\", \\\"{x:1114,y:884,t:1528139944527};\\\", \\\"{x:1115,y:883,t:1528139944543};\\\", \\\"{x:1117,y:880,t:1528139944560};\\\", \\\"{x:1121,y:876,t:1528139944577};\\\", \\\"{x:1123,y:872,t:1528139944594};\\\", \\\"{x:1127,y:865,t:1528139944610};\\\", \\\"{x:1139,y:853,t:1528139944627};\\\", \\\"{x:1147,y:840,t:1528139944643};\\\", \\\"{x:1154,y:831,t:1528139944661};\\\", \\\"{x:1161,y:821,t:1528139944677};\\\", \\\"{x:1167,y:810,t:1528139944694};\\\", \\\"{x:1171,y:802,t:1528139944711};\\\", \\\"{x:1175,y:793,t:1528139944727};\\\", \\\"{x:1180,y:784,t:1528139944744};\\\", \\\"{x:1182,y:780,t:1528139944761};\\\", \\\"{x:1183,y:777,t:1528139944777};\\\", \\\"{x:1184,y:776,t:1528139944794};\\\", \\\"{x:1184,y:774,t:1528139944811};\\\", \\\"{x:1185,y:773,t:1528139944827};\\\", \\\"{x:1186,y:770,t:1528139944844};\\\", \\\"{x:1186,y:767,t:1528139944861};\\\", \\\"{x:1187,y:766,t:1528139944877};\\\", \\\"{x:1187,y:765,t:1528139944894};\\\", \\\"{x:1188,y:764,t:1528139944911};\\\", \\\"{x:1188,y:762,t:1528139945052};\\\", \\\"{x:1189,y:761,t:1528139945068};\\\", \\\"{x:1189,y:759,t:1528139945083};\\\", \\\"{x:1189,y:758,t:1528139945094};\\\", \\\"{x:1193,y:759,t:1528139945307};\\\", \\\"{x:1198,y:770,t:1528139945315};\\\", \\\"{x:1204,y:779,t:1528139945328};\\\", \\\"{x:1211,y:792,t:1528139945344};\\\", \\\"{x:1219,y:806,t:1528139945361};\\\", \\\"{x:1224,y:812,t:1528139945378};\\\", \\\"{x:1228,y:819,t:1528139945394};\\\", \\\"{x:1233,y:829,t:1528139945412};\\\", \\\"{x:1237,y:839,t:1528139945427};\\\", \\\"{x:1244,y:853,t:1528139945444};\\\", \\\"{x:1254,y:865,t:1528139945460};\\\", \\\"{x:1258,y:871,t:1528139945478};\\\", \\\"{x:1261,y:875,t:1528139945495};\\\", \\\"{x:1263,y:880,t:1528139945510};\\\", \\\"{x:1266,y:883,t:1528139945527};\\\", \\\"{x:1270,y:891,t:1528139945545};\\\", \\\"{x:1276,y:902,t:1528139945561};\\\", \\\"{x:1285,y:916,t:1528139945578};\\\", \\\"{x:1299,y:932,t:1528139945594};\\\", \\\"{x:1304,y:939,t:1528139945611};\\\", \\\"{x:1310,y:946,t:1528139945628};\\\", \\\"{x:1315,y:952,t:1528139945645};\\\", \\\"{x:1320,y:959,t:1528139945661};\\\", \\\"{x:1326,y:969,t:1528139945677};\\\", \\\"{x:1331,y:978,t:1528139945695};\\\", \\\"{x:1335,y:984,t:1528139945712};\\\", \\\"{x:1336,y:987,t:1528139945728};\\\", \\\"{x:1334,y:987,t:1528139945892};\\\", \\\"{x:1330,y:986,t:1528139945899};\\\", \\\"{x:1327,y:985,t:1528139945912};\\\", \\\"{x:1321,y:981,t:1528139945928};\\\", \\\"{x:1311,y:970,t:1528139945945};\\\", \\\"{x:1299,y:949,t:1528139945962};\\\", \\\"{x:1288,y:932,t:1528139945978};\\\", \\\"{x:1274,y:906,t:1528139945995};\\\", \\\"{x:1265,y:891,t:1528139946014};\\\", \\\"{x:1257,y:878,t:1528139946028};\\\", \\\"{x:1248,y:862,t:1528139946045};\\\", \\\"{x:1241,y:850,t:1528139946061};\\\", \\\"{x:1237,y:842,t:1528139946078};\\\", \\\"{x:1233,y:834,t:1528139946095};\\\", \\\"{x:1228,y:825,t:1528139946112};\\\", \\\"{x:1223,y:816,t:1528139946128};\\\", \\\"{x:1217,y:808,t:1528139946144};\\\", \\\"{x:1203,y:797,t:1528139946162};\\\", \\\"{x:1187,y:788,t:1528139946177};\\\", \\\"{x:1158,y:778,t:1528139946194};\\\", \\\"{x:1133,y:771,t:1528139946212};\\\", \\\"{x:1098,y:765,t:1528139946228};\\\", \\\"{x:1039,y:756,t:1528139946245};\\\", \\\"{x:968,y:750,t:1528139946262};\\\", \\\"{x:892,y:739,t:1528139946279};\\\", \\\"{x:820,y:730,t:1528139946295};\\\", \\\"{x:731,y:715,t:1528139946312};\\\", \\\"{x:653,y:702,t:1528139946329};\\\", \\\"{x:583,y:685,t:1528139946345};\\\", \\\"{x:533,y:671,t:1528139946362};\\\", \\\"{x:481,y:655,t:1528139946381};\\\", \\\"{x:460,y:648,t:1528139946394};\\\", \\\"{x:444,y:640,t:1528139946412};\\\", \\\"{x:432,y:635,t:1528139946427};\\\", \\\"{x:412,y:625,t:1528139946443};\\\", \\\"{x:350,y:588,t:1528139946460};\\\", \\\"{x:293,y:563,t:1528139946476};\\\", \\\"{x:292,y:560,t:1528139946493};\\\", \\\"{x:292,y:559,t:1528139946509};\\\", \\\"{x:290,y:557,t:1528139946526};\\\", \\\"{x:290,y:555,t:1528139946555};\\\", \\\"{x:291,y:555,t:1528139946561};\\\", \\\"{x:298,y:554,t:1528139946576};\\\", \\\"{x:304,y:552,t:1528139946593};\\\", \\\"{x:318,y:545,t:1528139946609};\\\", \\\"{x:332,y:541,t:1528139946626};\\\", \\\"{x:343,y:545,t:1528139946643};\\\", \\\"{x:346,y:547,t:1528139946661};\\\", \\\"{x:345,y:547,t:1528139946724};\\\", \\\"{x:343,y:548,t:1528139946739};\\\", \\\"{x:340,y:550,t:1528139946747};\\\", \\\"{x:338,y:550,t:1528139946761};\\\", \\\"{x:329,y:552,t:1528139946777};\\\", \\\"{x:314,y:552,t:1528139946794};\\\", \\\"{x:292,y:552,t:1528139946811};\\\", \\\"{x:264,y:550,t:1528139946828};\\\", \\\"{x:215,y:537,t:1528139946843};\\\", \\\"{x:137,y:513,t:1528139946861};\\\", \\\"{x:47,y:484,t:1528139946876};\\\", \\\"{x:0,y:473,t:1528139946894};\\\", \\\"{x:0,y:466,t:1528139946910};\\\", \\\"{x:0,y:465,t:1528139946926};\\\", \\\"{x:2,y:463,t:1528139946946};\\\", \\\"{x:5,y:461,t:1528139946961};\\\", \\\"{x:13,y:458,t:1528139946976};\\\", \\\"{x:19,y:454,t:1528139946993};\\\", \\\"{x:26,y:451,t:1528139947010};\\\", \\\"{x:35,y:451,t:1528139947026};\\\", \\\"{x:49,y:454,t:1528139947044};\\\", \\\"{x:63,y:462,t:1528139947061};\\\", \\\"{x:73,y:465,t:1528139947077};\\\", \\\"{x:77,y:468,t:1528139947094};\\\", \\\"{x:82,y:471,t:1528139947111};\\\", \\\"{x:89,y:476,t:1528139947127};\\\", \\\"{x:96,y:483,t:1528139947144};\\\", \\\"{x:106,y:490,t:1528139947162};\\\", \\\"{x:110,y:495,t:1528139947176};\\\", \\\"{x:114,y:498,t:1528139947192};\\\", \\\"{x:116,y:499,t:1528139947209};\\\", \\\"{x:117,y:499,t:1528139947226};\\\", \\\"{x:119,y:500,t:1528139947242};\\\", \\\"{x:121,y:501,t:1528139947260};\\\", \\\"{x:127,y:502,t:1528139947276};\\\", \\\"{x:131,y:504,t:1528139947292};\\\", \\\"{x:134,y:504,t:1528139947309};\\\", \\\"{x:137,y:505,t:1528139947327};\\\", \\\"{x:137,y:506,t:1528139947346};\\\", \\\"{x:138,y:506,t:1528139947363};\\\", \\\"{x:140,y:506,t:1528139947376};\\\", \\\"{x:143,y:506,t:1528139947393};\\\", \\\"{x:145,y:505,t:1528139947410};\\\", \\\"{x:148,y:504,t:1528139947426};\\\", \\\"{x:149,y:504,t:1528139947443};\\\", \\\"{x:151,y:504,t:1528139947915};\\\", \\\"{x:157,y:504,t:1528139947926};\\\", \\\"{x:175,y:505,t:1528139947942};\\\", \\\"{x:210,y:511,t:1528139947962};\\\", \\\"{x:260,y:519,t:1528139947978};\\\", \\\"{x:357,y:547,t:1528139947996};\\\", \\\"{x:431,y:573,t:1528139948011};\\\", \\\"{x:485,y:593,t:1528139948027};\\\", \\\"{x:532,y:615,t:1528139948045};\\\", \\\"{x:584,y:647,t:1528139948061};\\\", \\\"{x:633,y:672,t:1528139948077};\\\", \\\"{x:676,y:695,t:1528139948095};\\\", \\\"{x:703,y:709,t:1528139948111};\\\", \\\"{x:725,y:719,t:1528139948127};\\\", \\\"{x:750,y:736,t:1528139948144};\\\", \\\"{x:791,y:760,t:1528139948160};\\\", \\\"{x:860,y:801,t:1528139948178};\\\", \\\"{x:972,y:852,t:1528139948194};\\\", \\\"{x:1047,y:885,t:1528139948211};\\\", \\\"{x:1093,y:902,t:1528139948227};\\\", \\\"{x:1132,y:914,t:1528139948245};\\\", \\\"{x:1168,y:930,t:1528139948261};\\\", \\\"{x:1212,y:948,t:1528139948278};\\\", \\\"{x:1244,y:966,t:1528139948295};\\\", \\\"{x:1261,y:974,t:1528139948312};\\\", \\\"{x:1267,y:976,t:1528139948328};\\\", \\\"{x:1268,y:976,t:1528139948586};\\\", \\\"{x:1269,y:975,t:1528139949236};\\\", \\\"{x:1270,y:973,t:1528139949245};\\\", \\\"{x:1270,y:971,t:1528139949262};\\\", \\\"{x:1270,y:970,t:1528139949307};\\\", \\\"{x:1271,y:970,t:1528139949427};\\\", \\\"{x:1271,y:967,t:1528139949444};\\\", \\\"{x:1271,y:961,t:1528139949451};\\\", \\\"{x:1274,y:953,t:1528139949462};\\\", \\\"{x:1275,y:942,t:1528139949479};\\\", \\\"{x:1276,y:932,t:1528139949496};\\\", \\\"{x:1278,y:923,t:1528139949512};\\\", \\\"{x:1279,y:916,t:1528139949530};\\\", \\\"{x:1279,y:908,t:1528139949546};\\\", \\\"{x:1280,y:901,t:1528139949563};\\\", \\\"{x:1282,y:895,t:1528139949579};\\\", \\\"{x:1283,y:882,t:1528139949596};\\\", \\\"{x:1284,y:868,t:1528139949613};\\\", \\\"{x:1284,y:861,t:1528139949629};\\\", \\\"{x:1284,y:856,t:1528139949646};\\\", \\\"{x:1284,y:852,t:1528139949663};\\\", \\\"{x:1284,y:849,t:1528139949679};\\\", \\\"{x:1284,y:847,t:1528139949696};\\\", \\\"{x:1283,y:845,t:1528139949713};\\\", \\\"{x:1282,y:842,t:1528139949729};\\\", \\\"{x:1281,y:839,t:1528139949746};\\\", \\\"{x:1278,y:837,t:1528139949763};\\\", \\\"{x:1276,y:835,t:1528139949779};\\\", \\\"{x:1273,y:834,t:1528139949796};\\\", \\\"{x:1269,y:833,t:1528139949813};\\\", \\\"{x:1261,y:831,t:1528139949829};\\\", \\\"{x:1247,y:830,t:1528139949846};\\\", \\\"{x:1231,y:830,t:1528139949863};\\\", \\\"{x:1223,y:830,t:1528139949879};\\\", \\\"{x:1215,y:830,t:1528139949897};\\\", \\\"{x:1197,y:830,t:1528139949923};\\\", \\\"{x:1195,y:832,t:1528139949930};\\\", \\\"{x:1194,y:832,t:1528139949946};\\\", \\\"{x:1193,y:832,t:1528139949962};\\\", \\\"{x:1192,y:832,t:1528139950115};\\\", \\\"{x:1195,y:832,t:1528139950131};\\\", \\\"{x:1199,y:830,t:1528139950146};\\\", \\\"{x:1209,y:826,t:1528139950163};\\\", \\\"{x:1206,y:827,t:1528139950332};\\\", \\\"{x:1203,y:828,t:1528139950347};\\\", \\\"{x:1191,y:844,t:1528139950363};\\\", \\\"{x:1180,y:860,t:1528139950380};\\\", \\\"{x:1171,y:871,t:1528139950397};\\\", \\\"{x:1164,y:885,t:1528139950414};\\\", \\\"{x:1159,y:894,t:1528139950430};\\\", \\\"{x:1155,y:901,t:1528139950446};\\\", \\\"{x:1152,y:908,t:1528139950462};\\\", \\\"{x:1149,y:913,t:1528139950480};\\\", \\\"{x:1147,y:918,t:1528139950497};\\\", \\\"{x:1145,y:922,t:1528139950513};\\\", \\\"{x:1141,y:929,t:1528139950529};\\\", \\\"{x:1136,y:939,t:1528139950546};\\\", \\\"{x:1134,y:943,t:1528139950562};\\\", \\\"{x:1132,y:949,t:1528139950580};\\\", \\\"{x:1129,y:953,t:1528139950597};\\\", \\\"{x:1128,y:955,t:1528139950612};\\\", \\\"{x:1127,y:956,t:1528139950667};\\\", \\\"{x:1127,y:957,t:1528139950755};\\\", \\\"{x:1127,y:958,t:1528139950771};\\\", \\\"{x:1127,y:959,t:1528139950844};\\\", \\\"{x:1127,y:960,t:1528139950851};\\\", \\\"{x:1126,y:960,t:1528139950867};\\\", \\\"{x:1125,y:960,t:1528139951267};\\\", \\\"{x:1125,y:956,t:1528139951282};\\\", \\\"{x:1125,y:944,t:1528139951297};\\\", \\\"{x:1127,y:938,t:1528139951314};\\\", \\\"{x:1129,y:933,t:1528139951331};\\\", \\\"{x:1129,y:931,t:1528139951347};\\\", \\\"{x:1129,y:929,t:1528139951364};\\\", \\\"{x:1129,y:928,t:1528139951381};\\\", \\\"{x:1130,y:927,t:1528139951397};\\\", \\\"{x:1130,y:925,t:1528139951415};\\\", \\\"{x:1131,y:923,t:1528139951431};\\\", \\\"{x:1132,y:922,t:1528139951447};\\\", \\\"{x:1133,y:921,t:1528139951464};\\\", \\\"{x:1133,y:919,t:1528139951481};\\\", \\\"{x:1133,y:918,t:1528139951497};\\\", \\\"{x:1133,y:917,t:1528139951514};\\\", \\\"{x:1136,y:913,t:1528139951531};\\\", \\\"{x:1137,y:909,t:1528139951547};\\\", \\\"{x:1138,y:906,t:1528139951564};\\\", \\\"{x:1139,y:903,t:1528139951581};\\\", \\\"{x:1140,y:899,t:1528139951597};\\\", \\\"{x:1140,y:898,t:1528139951614};\\\", \\\"{x:1141,y:896,t:1528139951631};\\\", \\\"{x:1141,y:895,t:1528139951647};\\\", \\\"{x:1141,y:893,t:1528139951664};\\\", \\\"{x:1143,y:890,t:1528139951681};\\\", \\\"{x:1143,y:888,t:1528139951698};\\\", \\\"{x:1144,y:885,t:1528139951715};\\\", \\\"{x:1145,y:881,t:1528139951731};\\\", \\\"{x:1145,y:880,t:1528139951763};\\\", \\\"{x:1146,y:880,t:1528139951781};\\\", \\\"{x:1146,y:879,t:1528139951803};\\\", \\\"{x:1146,y:878,t:1528139952013};\\\", \\\"{x:1144,y:878,t:1528139952019};\\\", \\\"{x:1141,y:878,t:1528139952031};\\\", \\\"{x:1135,y:879,t:1528139952048};\\\", \\\"{x:1132,y:880,t:1528139952065};\\\", \\\"{x:1129,y:881,t:1528139952081};\\\", \\\"{x:1128,y:882,t:1528139952098};\\\", \\\"{x:1124,y:884,t:1528139952114};\\\", \\\"{x:1120,y:886,t:1528139952131};\\\", \\\"{x:1117,y:889,t:1528139952149};\\\", \\\"{x:1116,y:890,t:1528139952165};\\\", \\\"{x:1116,y:889,t:1528139952308};\\\", \\\"{x:1116,y:885,t:1528139952315};\\\", \\\"{x:1120,y:878,t:1528139952330};\\\", \\\"{x:1121,y:874,t:1528139952347};\\\", \\\"{x:1125,y:867,t:1528139952364};\\\", \\\"{x:1134,y:854,t:1528139952380};\\\", \\\"{x:1143,y:841,t:1528139952398};\\\", \\\"{x:1154,y:828,t:1528139952415};\\\", \\\"{x:1164,y:815,t:1528139952430};\\\", \\\"{x:1173,y:806,t:1528139952447};\\\", \\\"{x:1181,y:797,t:1528139952465};\\\", \\\"{x:1190,y:786,t:1528139952481};\\\", \\\"{x:1196,y:775,t:1528139952498};\\\", \\\"{x:1211,y:750,t:1528139952515};\\\", \\\"{x:1225,y:725,t:1528139952531};\\\", \\\"{x:1240,y:697,t:1528139952548};\\\", \\\"{x:1257,y:660,t:1528139952565};\\\", \\\"{x:1269,y:626,t:1528139952582};\\\", \\\"{x:1278,y:590,t:1528139952599};\\\", \\\"{x:1288,y:557,t:1528139952616};\\\", \\\"{x:1296,y:533,t:1528139952632};\\\", \\\"{x:1301,y:515,t:1528139952648};\\\", \\\"{x:1306,y:502,t:1528139952664};\\\", \\\"{x:1309,y:495,t:1528139952682};\\\", \\\"{x:1310,y:493,t:1528139952697};\\\", \\\"{x:1310,y:492,t:1528139952827};\\\", \\\"{x:1306,y:492,t:1528139952834};\\\", \\\"{x:1299,y:494,t:1528139952848};\\\", \\\"{x:1282,y:507,t:1528139952865};\\\", \\\"{x:1274,y:521,t:1528139952882};\\\", \\\"{x:1271,y:532,t:1528139952898};\\\", \\\"{x:1266,y:544,t:1528139952914};\\\", \\\"{x:1264,y:552,t:1528139952932};\\\", \\\"{x:1263,y:555,t:1528139952948};\\\", \\\"{x:1263,y:558,t:1528139952964};\\\", \\\"{x:1263,y:559,t:1528139952994};\\\", \\\"{x:1263,y:560,t:1528139953002};\\\", \\\"{x:1263,y:562,t:1528139953015};\\\", \\\"{x:1265,y:569,t:1528139953032};\\\", \\\"{x:1269,y:576,t:1528139953048};\\\", \\\"{x:1272,y:580,t:1528139953065};\\\", \\\"{x:1273,y:581,t:1528139953083};\\\", \\\"{x:1274,y:582,t:1528139953098};\\\", \\\"{x:1275,y:582,t:1528139953115};\\\", \\\"{x:1276,y:582,t:1528139953154};\\\", \\\"{x:1277,y:582,t:1528139953194};\\\", \\\"{x:1278,y:582,t:1528139953202};\\\", \\\"{x:1278,y:581,t:1528139953283};\\\", \\\"{x:1278,y:580,t:1528139953306};\\\", \\\"{x:1279,y:578,t:1528139953315};\\\", \\\"{x:1280,y:576,t:1528139953332};\\\", \\\"{x:1281,y:573,t:1528139953349};\\\", \\\"{x:1283,y:571,t:1528139953365};\\\", \\\"{x:1283,y:569,t:1528139953382};\\\", \\\"{x:1283,y:568,t:1528139953399};\\\", \\\"{x:1284,y:567,t:1528139953415};\\\", \\\"{x:1285,y:566,t:1528139953431};\\\", \\\"{x:1285,y:565,t:1528139953449};\\\", \\\"{x:1285,y:564,t:1528139953465};\\\", \\\"{x:1285,y:563,t:1528139953483};\\\", \\\"{x:1286,y:562,t:1528139954395};\\\", \\\"{x:1288,y:562,t:1528139954403};\\\", \\\"{x:1293,y:564,t:1528139954415};\\\", \\\"{x:1298,y:569,t:1528139954433};\\\", \\\"{x:1300,y:572,t:1528139954450};\\\", \\\"{x:1300,y:573,t:1528139954465};\\\", \\\"{x:1301,y:573,t:1528139954530};\\\", \\\"{x:1301,y:574,t:1528139955203};\\\", \\\"{x:1300,y:576,t:1528139961275};\\\", \\\"{x:1296,y:580,t:1528139961288};\\\", \\\"{x:1291,y:586,t:1528139961306};\\\", \\\"{x:1286,y:594,t:1528139961323};\\\", \\\"{x:1283,y:599,t:1528139961339};\\\", \\\"{x:1278,y:606,t:1528139961356};\\\", \\\"{x:1276,y:609,t:1528139961372};\\\", \\\"{x:1275,y:611,t:1528139961389};\\\", \\\"{x:1274,y:614,t:1528139961406};\\\", \\\"{x:1274,y:615,t:1528139961423};\\\", \\\"{x:1274,y:616,t:1528139961438};\\\", \\\"{x:1274,y:617,t:1528139961459};\\\", \\\"{x:1273,y:617,t:1528139961491};\\\", \\\"{x:1272,y:618,t:1528139961515};\\\", \\\"{x:1272,y:619,t:1528139961555};\\\", \\\"{x:1271,y:619,t:1528139961587};\\\", \\\"{x:1271,y:620,t:1528139961627};\\\", \\\"{x:1271,y:621,t:1528139961651};\\\", \\\"{x:1271,y:622,t:1528139961667};\\\", \\\"{x:1269,y:624,t:1528139961707};\\\", \\\"{x:1269,y:626,t:1528139961739};\\\", \\\"{x:1269,y:627,t:1528139961851};\\\", \\\"{x:1268,y:627,t:1528139961867};\\\", \\\"{x:1268,y:628,t:1528139961914};\\\", \\\"{x:1268,y:626,t:1528139964171};\\\", \\\"{x:1269,y:626,t:1528139964179};\\\", \\\"{x:1270,y:626,t:1528139964190};\\\", \\\"{x:1273,y:623,t:1528139964207};\\\", \\\"{x:1275,y:622,t:1528139964224};\\\", \\\"{x:1275,y:621,t:1528139964239};\\\", \\\"{x:1277,y:620,t:1528139964256};\\\", \\\"{x:1279,y:616,t:1528139964274};\\\", \\\"{x:1279,y:613,t:1528139964291};\\\", \\\"{x:1280,y:609,t:1528139964307};\\\", \\\"{x:1281,y:606,t:1528139964324};\\\", \\\"{x:1281,y:605,t:1528139964341};\\\", \\\"{x:1282,y:604,t:1528139964357};\\\", \\\"{x:1282,y:603,t:1528139964491};\\\", \\\"{x:1282,y:602,t:1528139964563};\\\", \\\"{x:1284,y:602,t:1528139965099};\\\", \\\"{x:1285,y:603,t:1528139965108};\\\", \\\"{x:1286,y:603,t:1528139965124};\\\", \\\"{x:1286,y:605,t:1528139965141};\\\", \\\"{x:1287,y:605,t:1528139965159};\\\", \\\"{x:1287,y:606,t:1528139965187};\\\", \\\"{x:1289,y:607,t:1528139965195};\\\", \\\"{x:1290,y:609,t:1528139965208};\\\", \\\"{x:1294,y:614,t:1528139965225};\\\", \\\"{x:1300,y:627,t:1528139965242};\\\", \\\"{x:1313,y:648,t:1528139965259};\\\", \\\"{x:1320,y:660,t:1528139965275};\\\", \\\"{x:1330,y:676,t:1528139965291};\\\", \\\"{x:1341,y:691,t:1528139965309};\\\", \\\"{x:1353,y:708,t:1528139965325};\\\", \\\"{x:1362,y:719,t:1528139965342};\\\", \\\"{x:1370,y:731,t:1528139965359};\\\", \\\"{x:1377,y:742,t:1528139965375};\\\", \\\"{x:1386,y:755,t:1528139965391};\\\", \\\"{x:1392,y:763,t:1528139965409};\\\", \\\"{x:1401,y:773,t:1528139965426};\\\", \\\"{x:1408,y:783,t:1528139965442};\\\", \\\"{x:1416,y:794,t:1528139965459};\\\", \\\"{x:1419,y:799,t:1528139965476};\\\", \\\"{x:1422,y:804,t:1528139965492};\\\", \\\"{x:1424,y:807,t:1528139965509};\\\", \\\"{x:1427,y:809,t:1528139965525};\\\", \\\"{x:1427,y:810,t:1528139965542};\\\", \\\"{x:1428,y:811,t:1528139965559};\\\", \\\"{x:1429,y:812,t:1528139965576};\\\", \\\"{x:1430,y:813,t:1528139965591};\\\", \\\"{x:1432,y:815,t:1528139965609};\\\", \\\"{x:1433,y:816,t:1528139965626};\\\", \\\"{x:1434,y:818,t:1528139965642};\\\", \\\"{x:1436,y:820,t:1528139965658};\\\", \\\"{x:1436,y:821,t:1528139965675};\\\", \\\"{x:1438,y:821,t:1528139965980};\\\", \\\"{x:1440,y:821,t:1528139965994};\\\", \\\"{x:1442,y:821,t:1528139966009};\\\", \\\"{x:1445,y:821,t:1528139966026};\\\", \\\"{x:1449,y:821,t:1528139966042};\\\", \\\"{x:1452,y:821,t:1528139966059};\\\", \\\"{x:1454,y:821,t:1528139966075};\\\", \\\"{x:1455,y:821,t:1528139966093};\\\", \\\"{x:1456,y:821,t:1528139966109};\\\", \\\"{x:1460,y:821,t:1528139966126};\\\", \\\"{x:1462,y:821,t:1528139966143};\\\", \\\"{x:1464,y:821,t:1528139966160};\\\", \\\"{x:1465,y:821,t:1528139966175};\\\", \\\"{x:1467,y:821,t:1528139966192};\\\", \\\"{x:1468,y:821,t:1528139966210};\\\", \\\"{x:1469,y:821,t:1528139966225};\\\", \\\"{x:1470,y:821,t:1528139966291};\\\", \\\"{x:1470,y:817,t:1528139966331};\\\", \\\"{x:1470,y:811,t:1528139966342};\\\", \\\"{x:1471,y:803,t:1528139966359};\\\", \\\"{x:1471,y:794,t:1528139966376};\\\", \\\"{x:1471,y:780,t:1528139966392};\\\", \\\"{x:1465,y:758,t:1528139966410};\\\", \\\"{x:1450,y:721,t:1528139966426};\\\", \\\"{x:1431,y:680,t:1528139966443};\\\", \\\"{x:1421,y:656,t:1528139966459};\\\", \\\"{x:1415,y:640,t:1528139966476};\\\", \\\"{x:1410,y:629,t:1528139966493};\\\", \\\"{x:1406,y:615,t:1528139966510};\\\", \\\"{x:1400,y:595,t:1528139966526};\\\", \\\"{x:1399,y:584,t:1528139966543};\\\", \\\"{x:1397,y:575,t:1528139966560};\\\", \\\"{x:1396,y:569,t:1528139966575};\\\", \\\"{x:1396,y:568,t:1528139966593};\\\", \\\"{x:1396,y:567,t:1528139966610};\\\", \\\"{x:1394,y:567,t:1528139966779};\\\", \\\"{x:1385,y:567,t:1528139966793};\\\", \\\"{x:1368,y:564,t:1528139966810};\\\", \\\"{x:1347,y:574,t:1528139966827};\\\", \\\"{x:1337,y:580,t:1528139966843};\\\", \\\"{x:1325,y:589,t:1528139966860};\\\", \\\"{x:1307,y:599,t:1528139966877};\\\", \\\"{x:1274,y:612,t:1528139966893};\\\", \\\"{x:1228,y:629,t:1528139966909};\\\", \\\"{x:1181,y:647,t:1528139966927};\\\", \\\"{x:1126,y:671,t:1528139966943};\\\", \\\"{x:1066,y:693,t:1528139966960};\\\", \\\"{x:1013,y:711,t:1528139966977};\\\", \\\"{x:965,y:725,t:1528139966994};\\\", \\\"{x:924,y:729,t:1528139967010};\\\", \\\"{x:844,y:741,t:1528139967026};\\\", \\\"{x:752,y:743,t:1528139967043};\\\", \\\"{x:663,y:743,t:1528139967059};\\\", \\\"{x:565,y:745,t:1528139967076};\\\", \\\"{x:480,y:753,t:1528139967094};\\\", \\\"{x:400,y:773,t:1528139967110};\\\", \\\"{x:346,y:793,t:1528139967126};\\\", \\\"{x:339,y:797,t:1528139967143};\\\", \\\"{x:334,y:803,t:1528139967159};\\\", \\\"{x:333,y:808,t:1528139967176};\\\", \\\"{x:330,y:810,t:1528139967193};\\\", \\\"{x:335,y:809,t:1528139967266};\\\", \\\"{x:341,y:807,t:1528139967277};\\\", \\\"{x:349,y:803,t:1528139967293};\\\", \\\"{x:359,y:798,t:1528139967309};\\\", \\\"{x:371,y:791,t:1528139967326};\\\", \\\"{x:379,y:787,t:1528139967343};\\\", \\\"{x:388,y:782,t:1528139967360};\\\", \\\"{x:398,y:776,t:1528139967376};\\\", \\\"{x:410,y:770,t:1528139967393};\\\", \\\"{x:419,y:765,t:1528139967410};\\\", \\\"{x:424,y:763,t:1528139967427};\\\", \\\"{x:428,y:761,t:1528139967444};\\\", \\\"{x:435,y:759,t:1528139967461};\\\", \\\"{x:439,y:757,t:1528139967476};\\\", \\\"{x:440,y:757,t:1528139967507};\\\", \\\"{x:443,y:754,t:1528139967538};\\\", \\\"{x:446,y:752,t:1528139967555};\\\", \\\"{x:448,y:751,t:1528139967564};\\\", \\\"{x:451,y:747,t:1528139967576};\\\", \\\"{x:456,y:743,t:1528139967593};\\\", \\\"{x:476,y:726,t:1528139967610};\\\", \\\"{x:484,y:721,t:1528139967626};\\\", \\\"{x:486,y:719,t:1528139967644};\\\", \\\"{x:487,y:719,t:1528139967698};\\\", \\\"{x:488,y:723,t:1528139968124};\\\", \\\"{x:488,y:725,t:1528139968129};\\\", \\\"{x:488,y:728,t:1528139968143};\\\", \\\"{x:487,y:735,t:1528139968160};\\\", \\\"{x:487,y:742,t:1528139968177};\\\", \\\"{x:488,y:747,t:1528139968193};\\\" ] }, { \\\"rt\\\": 21724, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 659416, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:749,t:1528139971122};\\\", \\\"{x:492,y:749,t:1528139971130};\\\", \\\"{x:497,y:749,t:1528139971144};\\\", \\\"{x:506,y:744,t:1528139971161};\\\", \\\"{x:519,y:736,t:1528139971178};\\\", \\\"{x:527,y:735,t:1528139971194};\\\", \\\"{x:536,y:730,t:1528139971211};\\\", \\\"{x:554,y:727,t:1528139971229};\\\", \\\"{x:580,y:723,t:1528139971246};\\\", \\\"{x:621,y:718,t:1528139971261};\\\", \\\"{x:672,y:710,t:1528139971280};\\\", \\\"{x:722,y:704,t:1528139971297};\\\", \\\"{x:750,y:700,t:1528139971313};\\\", \\\"{x:770,y:696,t:1528139971329};\\\", \\\"{x:776,y:696,t:1528139971345};\\\", \\\"{x:775,y:696,t:1528139971546};\\\", \\\"{x:774,y:696,t:1528139971564};\\\", \\\"{x:772,y:698,t:1528139971580};\\\", \\\"{x:770,y:698,t:1528139971596};\\\", \\\"{x:769,y:699,t:1528139971614};\\\", \\\"{x:771,y:699,t:1528139974931};\\\", \\\"{x:776,y:698,t:1528139974938};\\\", \\\"{x:778,y:697,t:1528139974951};\\\", \\\"{x:788,y:693,t:1528139974967};\\\", \\\"{x:809,y:685,t:1528139974984};\\\", \\\"{x:858,y:677,t:1528139975001};\\\", \\\"{x:919,y:669,t:1528139975017};\\\", \\\"{x:1000,y:654,t:1528139975034};\\\", \\\"{x:1035,y:641,t:1528139975050};\\\", \\\"{x:1036,y:638,t:1528139975067};\\\", \\\"{x:1036,y:637,t:1528139975084};\\\", \\\"{x:1028,y:637,t:1528139975355};\\\", \\\"{x:1015,y:631,t:1528139975368};\\\", \\\"{x:986,y:628,t:1528139975385};\\\", \\\"{x:952,y:628,t:1528139975400};\\\", \\\"{x:914,y:628,t:1528139975418};\\\", \\\"{x:833,y:628,t:1528139975434};\\\", \\\"{x:764,y:628,t:1528139975450};\\\", \\\"{x:708,y:628,t:1528139975467};\\\", \\\"{x:678,y:628,t:1528139975482};\\\", \\\"{x:654,y:625,t:1528139975499};\\\", \\\"{x:631,y:622,t:1528139975517};\\\", \\\"{x:600,y:622,t:1528139975532};\\\", \\\"{x:577,y:622,t:1528139975550};\\\", \\\"{x:559,y:622,t:1528139975566};\\\", \\\"{x:551,y:622,t:1528139975582};\\\", \\\"{x:547,y:622,t:1528139975599};\\\", \\\"{x:546,y:622,t:1528139975616};\\\", \\\"{x:546,y:621,t:1528139975706};\\\", \\\"{x:552,y:617,t:1528139975716};\\\", \\\"{x:578,y:603,t:1528139975734};\\\", \\\"{x:608,y:589,t:1528139975751};\\\", \\\"{x:633,y:579,t:1528139975767};\\\", \\\"{x:657,y:569,t:1528139975784};\\\", \\\"{x:680,y:560,t:1528139975800};\\\", \\\"{x:691,y:557,t:1528139975817};\\\", \\\"{x:699,y:552,t:1528139975834};\\\", \\\"{x:701,y:552,t:1528139975850};\\\", \\\"{x:706,y:549,t:1528139975866};\\\", \\\"{x:707,y:548,t:1528139975883};\\\", \\\"{x:710,y:546,t:1528139975900};\\\", \\\"{x:713,y:543,t:1528139975917};\\\", \\\"{x:719,y:540,t:1528139975934};\\\", \\\"{x:725,y:538,t:1528139975951};\\\", \\\"{x:730,y:535,t:1528139975966};\\\", \\\"{x:742,y:530,t:1528139975984};\\\", \\\"{x:754,y:525,t:1528139976000};\\\", \\\"{x:767,y:520,t:1528139976018};\\\", \\\"{x:784,y:514,t:1528139976034};\\\", \\\"{x:796,y:507,t:1528139976050};\\\", \\\"{x:808,y:502,t:1528139976066};\\\", \\\"{x:817,y:499,t:1528139976084};\\\", \\\"{x:827,y:494,t:1528139976100};\\\", \\\"{x:831,y:492,t:1528139976116};\\\", \\\"{x:832,y:492,t:1528139976134};\\\", \\\"{x:833,y:492,t:1528139976523};\\\", \\\"{x:837,y:491,t:1528139976534};\\\", \\\"{x:861,y:487,t:1528139976551};\\\", \\\"{x:902,y:487,t:1528139976567};\\\", \\\"{x:958,y:487,t:1528139976585};\\\", \\\"{x:1024,y:487,t:1528139976601};\\\", \\\"{x:1105,y:487,t:1528139976618};\\\", \\\"{x:1150,y:487,t:1528139976634};\\\", \\\"{x:1177,y:487,t:1528139976651};\\\", \\\"{x:1196,y:487,t:1528139976668};\\\", \\\"{x:1207,y:487,t:1528139976683};\\\", \\\"{x:1216,y:487,t:1528139976700};\\\", \\\"{x:1220,y:487,t:1528139976718};\\\", \\\"{x:1226,y:487,t:1528139976733};\\\", \\\"{x:1229,y:487,t:1528139976751};\\\", \\\"{x:1231,y:487,t:1528139976768};\\\", \\\"{x:1234,y:487,t:1528139976784};\\\", \\\"{x:1236,y:487,t:1528139976801};\\\", \\\"{x:1237,y:487,t:1528139976818};\\\", \\\"{x:1239,y:487,t:1528139976851};\\\", \\\"{x:1240,y:490,t:1528139977787};\\\", \\\"{x:1239,y:507,t:1528139977802};\\\", \\\"{x:1238,y:529,t:1528139977819};\\\", \\\"{x:1238,y:567,t:1528139977835};\\\", \\\"{x:1250,y:622,t:1528139977852};\\\", \\\"{x:1269,y:681,t:1528139977869};\\\", \\\"{x:1300,y:743,t:1528139977885};\\\", \\\"{x:1329,y:787,t:1528139977902};\\\", \\\"{x:1358,y:821,t:1528139977919};\\\", \\\"{x:1386,y:842,t:1528139977935};\\\", \\\"{x:1405,y:854,t:1528139977952};\\\", \\\"{x:1420,y:864,t:1528139977968};\\\", \\\"{x:1438,y:874,t:1528139977984};\\\", \\\"{x:1459,y:884,t:1528139978001};\\\", \\\"{x:1473,y:890,t:1528139978018};\\\", \\\"{x:1482,y:895,t:1528139978035};\\\", \\\"{x:1494,y:899,t:1528139978052};\\\", \\\"{x:1499,y:899,t:1528139978069};\\\", \\\"{x:1503,y:899,t:1528139978086};\\\", \\\"{x:1505,y:900,t:1528139978101};\\\", \\\"{x:1506,y:900,t:1528139978267};\\\", \\\"{x:1506,y:898,t:1528139978275};\\\", \\\"{x:1505,y:895,t:1528139978286};\\\", \\\"{x:1500,y:891,t:1528139978302};\\\", \\\"{x:1496,y:889,t:1528139978319};\\\", \\\"{x:1493,y:887,t:1528139978336};\\\", \\\"{x:1492,y:887,t:1528139978352};\\\", \\\"{x:1492,y:886,t:1528139978378};\\\", \\\"{x:1491,y:886,t:1528139978547};\\\", \\\"{x:1491,y:883,t:1528139978554};\\\", \\\"{x:1491,y:876,t:1528139978569};\\\", \\\"{x:1491,y:860,t:1528139978586};\\\", \\\"{x:1491,y:848,t:1528139978603};\\\", \\\"{x:1487,y:827,t:1528139978619};\\\", \\\"{x:1474,y:803,t:1528139978636};\\\", \\\"{x:1463,y:785,t:1528139978653};\\\", \\\"{x:1453,y:769,t:1528139978670};\\\", \\\"{x:1445,y:758,t:1528139978687};\\\", \\\"{x:1436,y:744,t:1528139978704};\\\", \\\"{x:1419,y:728,t:1528139978719};\\\", \\\"{x:1400,y:714,t:1528139978736};\\\", \\\"{x:1383,y:707,t:1528139978753};\\\", \\\"{x:1373,y:704,t:1528139978769};\\\", \\\"{x:1366,y:701,t:1528139978786};\\\", \\\"{x:1362,y:700,t:1528139978802};\\\", \\\"{x:1359,y:700,t:1528139978818};\\\", \\\"{x:1357,y:700,t:1528139978836};\\\", \\\"{x:1356,y:700,t:1528139979121};\\\", \\\"{x:1355,y:700,t:1528139979250};\\\", \\\"{x:1353,y:699,t:1528139979308};\\\", \\\"{x:1351,y:699,t:1528139979337};\\\", \\\"{x:1351,y:698,t:1528139979352};\\\", \\\"{x:1349,y:697,t:1528139979370};\\\", \\\"{x:1349,y:698,t:1528139979498};\\\", \\\"{x:1349,y:700,t:1528139979506};\\\", \\\"{x:1350,y:704,t:1528139979521};\\\", \\\"{x:1352,y:712,t:1528139979537};\\\", \\\"{x:1354,y:718,t:1528139979553};\\\", \\\"{x:1357,y:726,t:1528139979569};\\\", \\\"{x:1358,y:730,t:1528139979587};\\\", \\\"{x:1359,y:732,t:1528139979603};\\\", \\\"{x:1359,y:735,t:1528139979620};\\\", \\\"{x:1360,y:740,t:1528139979637};\\\", \\\"{x:1361,y:749,t:1528139979653};\\\", \\\"{x:1362,y:759,t:1528139979670};\\\", \\\"{x:1366,y:771,t:1528139979686};\\\", \\\"{x:1368,y:777,t:1528139979705};\\\", \\\"{x:1372,y:787,t:1528139979736};\\\", \\\"{x:1373,y:790,t:1528139979740};\\\", \\\"{x:1375,y:795,t:1528139979754};\\\", \\\"{x:1379,y:804,t:1528139979770};\\\", \\\"{x:1385,y:816,t:1528139979786};\\\", \\\"{x:1394,y:830,t:1528139979804};\\\", \\\"{x:1400,y:838,t:1528139979820};\\\", \\\"{x:1408,y:848,t:1528139979837};\\\", \\\"{x:1420,y:859,t:1528139979854};\\\", \\\"{x:1434,y:872,t:1528139979869};\\\", \\\"{x:1453,y:887,t:1528139979887};\\\", \\\"{x:1473,y:903,t:1528139979904};\\\", \\\"{x:1489,y:917,t:1528139979920};\\\", \\\"{x:1502,y:926,t:1528139979936};\\\", \\\"{x:1514,y:933,t:1528139979954};\\\", \\\"{x:1517,y:935,t:1528139979970};\\\", \\\"{x:1518,y:936,t:1528139979987};\\\", \\\"{x:1518,y:937,t:1528139980067};\\\", \\\"{x:1518,y:938,t:1528139980099};\\\", \\\"{x:1518,y:939,t:1528139980114};\\\", \\\"{x:1518,y:940,t:1528139980123};\\\", \\\"{x:1518,y:941,t:1528139980137};\\\", \\\"{x:1518,y:943,t:1528139980154};\\\", \\\"{x:1518,y:946,t:1528139980170};\\\", \\\"{x:1518,y:948,t:1528139980186};\\\", \\\"{x:1518,y:951,t:1528139980204};\\\", \\\"{x:1518,y:954,t:1528139980221};\\\", \\\"{x:1517,y:955,t:1528139980237};\\\", \\\"{x:1517,y:957,t:1528139980254};\\\", \\\"{x:1517,y:958,t:1528139980271};\\\", \\\"{x:1515,y:961,t:1528139980288};\\\", \\\"{x:1514,y:962,t:1528139980306};\\\", \\\"{x:1514,y:964,t:1528139980321};\\\", \\\"{x:1514,y:965,t:1528139980336};\\\", \\\"{x:1513,y:967,t:1528139980354};\\\", \\\"{x:1512,y:969,t:1528139980370};\\\", \\\"{x:1511,y:970,t:1528139980401};\\\", \\\"{x:1510,y:971,t:1528139980409};\\\", \\\"{x:1509,y:972,t:1528139980420};\\\", \\\"{x:1508,y:974,t:1528139980437};\\\", \\\"{x:1507,y:975,t:1528139980453};\\\", \\\"{x:1506,y:976,t:1528139980471};\\\", \\\"{x:1504,y:977,t:1528139980487};\\\", \\\"{x:1502,y:976,t:1528139980803};\\\", \\\"{x:1492,y:964,t:1528139980821};\\\", \\\"{x:1482,y:951,t:1528139980839};\\\", \\\"{x:1470,y:937,t:1528139980854};\\\", \\\"{x:1458,y:928,t:1528139980871};\\\", \\\"{x:1444,y:916,t:1528139980888};\\\", \\\"{x:1431,y:901,t:1528139980906};\\\", \\\"{x:1420,y:890,t:1528139980922};\\\", \\\"{x:1408,y:872,t:1528139980939};\\\", \\\"{x:1401,y:863,t:1528139980955};\\\", \\\"{x:1396,y:856,t:1528139980971};\\\", \\\"{x:1393,y:852,t:1528139980988};\\\", \\\"{x:1391,y:846,t:1528139981005};\\\", \\\"{x:1389,y:844,t:1528139981021};\\\", \\\"{x:1388,y:840,t:1528139981038};\\\", \\\"{x:1386,y:837,t:1528139981055};\\\", \\\"{x:1386,y:834,t:1528139981071};\\\", \\\"{x:1383,y:827,t:1528139981088};\\\", \\\"{x:1382,y:822,t:1528139981105};\\\", \\\"{x:1379,y:812,t:1528139981122};\\\", \\\"{x:1376,y:799,t:1528139981138};\\\", \\\"{x:1374,y:791,t:1528139981155};\\\", \\\"{x:1373,y:785,t:1528139981171};\\\", \\\"{x:1372,y:781,t:1528139981189};\\\", \\\"{x:1371,y:776,t:1528139981205};\\\", \\\"{x:1370,y:769,t:1528139981221};\\\", \\\"{x:1369,y:765,t:1528139981238};\\\", \\\"{x:1367,y:760,t:1528139981255};\\\", \\\"{x:1365,y:748,t:1528139981271};\\\", \\\"{x:1360,y:737,t:1528139981288};\\\", \\\"{x:1355,y:715,t:1528139981306};\\\", \\\"{x:1349,y:701,t:1528139981322};\\\", \\\"{x:1345,y:691,t:1528139981338};\\\", \\\"{x:1344,y:684,t:1528139981354};\\\", \\\"{x:1340,y:676,t:1528139981371};\\\", \\\"{x:1336,y:667,t:1528139981388};\\\", \\\"{x:1331,y:653,t:1528139981405};\\\", \\\"{x:1321,y:638,t:1528139981421};\\\", \\\"{x:1315,y:629,t:1528139981438};\\\", \\\"{x:1311,y:621,t:1528139981455};\\\", \\\"{x:1308,y:616,t:1528139981472};\\\", \\\"{x:1306,y:613,t:1528139981488};\\\", \\\"{x:1301,y:608,t:1528139981505};\\\", \\\"{x:1294,y:599,t:1528139981522};\\\", \\\"{x:1290,y:594,t:1528139981538};\\\", \\\"{x:1285,y:587,t:1528139981555};\\\", \\\"{x:1282,y:584,t:1528139981572};\\\", \\\"{x:1280,y:582,t:1528139981588};\\\", \\\"{x:1279,y:581,t:1528139981605};\\\", \\\"{x:1279,y:580,t:1528139981623};\\\", \\\"{x:1278,y:577,t:1528139981639};\\\", \\\"{x:1277,y:576,t:1528139981656};\\\", \\\"{x:1276,y:576,t:1528139981673};\\\", \\\"{x:1276,y:575,t:1528139981688};\\\", \\\"{x:1276,y:574,t:1528139981706};\\\", \\\"{x:1273,y:574,t:1528139981723};\\\", \\\"{x:1260,y:568,t:1528139981739};\\\", \\\"{x:1239,y:565,t:1528139981755};\\\", \\\"{x:1210,y:563,t:1528139981772};\\\", \\\"{x:1172,y:563,t:1528139981790};\\\", \\\"{x:1113,y:563,t:1528139981805};\\\", \\\"{x:1038,y:563,t:1528139981823};\\\", \\\"{x:955,y:563,t:1528139981839};\\\", \\\"{x:888,y:563,t:1528139981857};\\\", \\\"{x:810,y:563,t:1528139981872};\\\", \\\"{x:768,y:563,t:1528139981889};\\\", \\\"{x:741,y:563,t:1528139981904};\\\", \\\"{x:715,y:563,t:1528139981921};\\\", \\\"{x:710,y:563,t:1528139981937};\\\", \\\"{x:707,y:563,t:1528139981954};\\\", \\\"{x:704,y:561,t:1528139981971};\\\", \\\"{x:702,y:561,t:1528139981988};\\\", \\\"{x:698,y:561,t:1528139982005};\\\", \\\"{x:694,y:560,t:1528139982022};\\\", \\\"{x:685,y:559,t:1528139982037};\\\", \\\"{x:663,y:556,t:1528139982054};\\\", \\\"{x:636,y:553,t:1528139982072};\\\", \\\"{x:602,y:547,t:1528139982090};\\\", \\\"{x:575,y:544,t:1528139982105};\\\", \\\"{x:556,y:537,t:1528139982122};\\\", \\\"{x:553,y:535,t:1528139982138};\\\", \\\"{x:553,y:534,t:1528139982155};\\\", \\\"{x:553,y:529,t:1528139982171};\\\", \\\"{x:553,y:527,t:1528139982188};\\\", \\\"{x:557,y:524,t:1528139982206};\\\", \\\"{x:559,y:522,t:1528139982222};\\\", \\\"{x:560,y:519,t:1528139982238};\\\", \\\"{x:560,y:515,t:1528139982255};\\\", \\\"{x:560,y:513,t:1528139982271};\\\", \\\"{x:560,y:512,t:1528139982288};\\\", \\\"{x:561,y:510,t:1528139982305};\\\", \\\"{x:564,y:507,t:1528139982322};\\\", \\\"{x:565,y:505,t:1528139982339};\\\", \\\"{x:567,y:504,t:1528139982355};\\\", \\\"{x:571,y:503,t:1528139982371};\\\", \\\"{x:571,y:502,t:1528139982393};\\\", \\\"{x:572,y:502,t:1528139982404};\\\", \\\"{x:573,y:502,t:1528139982563};\\\", \\\"{x:573,y:501,t:1528139982586};\\\", \\\"{x:574,y:501,t:1528139982594};\\\", \\\"{x:576,y:501,t:1528139982606};\\\", \\\"{x:579,y:500,t:1528139982622};\\\", \\\"{x:585,y:497,t:1528139982639};\\\", \\\"{x:594,y:496,t:1528139982657};\\\", \\\"{x:601,y:496,t:1528139982673};\\\", \\\"{x:609,y:496,t:1528139982689};\\\", \\\"{x:619,y:496,t:1528139982704};\\\", \\\"{x:631,y:496,t:1528139982722};\\\", \\\"{x:633,y:496,t:1528139982738};\\\", \\\"{x:635,y:495,t:1528139982755};\\\", \\\"{x:634,y:495,t:1528139982986};\\\", \\\"{x:631,y:495,t:1528139982994};\\\", \\\"{x:630,y:495,t:1528139983005};\\\", \\\"{x:626,y:495,t:1528139983022};\\\", \\\"{x:625,y:495,t:1528139983038};\\\", \\\"{x:624,y:495,t:1528139983055};\\\", \\\"{x:623,y:495,t:1528139983114};\\\", \\\"{x:622,y:495,t:1528139983130};\\\", \\\"{x:621,y:496,t:1528139983138};\\\", \\\"{x:620,y:497,t:1528139983155};\\\", \\\"{x:618,y:497,t:1528139983172};\\\", \\\"{x:617,y:498,t:1528139983586};\\\", \\\"{x:618,y:499,t:1528139983602};\\\", \\\"{x:620,y:500,t:1528139983609};\\\", \\\"{x:621,y:501,t:1528139983622};\\\", \\\"{x:624,y:502,t:1528139983640};\\\", \\\"{x:626,y:502,t:1528139983656};\\\", \\\"{x:628,y:503,t:1528139983672};\\\", \\\"{x:632,y:505,t:1528139983689};\\\", \\\"{x:641,y:509,t:1528139983706};\\\", \\\"{x:649,y:509,t:1528139983724};\\\", \\\"{x:663,y:510,t:1528139983740};\\\", \\\"{x:680,y:515,t:1528139983756};\\\", \\\"{x:701,y:520,t:1528139983774};\\\", \\\"{x:725,y:529,t:1528139983791};\\\", \\\"{x:745,y:535,t:1528139983806};\\\", \\\"{x:762,y:540,t:1528139983823};\\\", \\\"{x:776,y:543,t:1528139983840};\\\", \\\"{x:793,y:545,t:1528139983856};\\\", \\\"{x:811,y:547,t:1528139983873};\\\", \\\"{x:852,y:553,t:1528139983890};\\\", \\\"{x:884,y:557,t:1528139983907};\\\", \\\"{x:918,y:558,t:1528139983923};\\\", \\\"{x:955,y:561,t:1528139983939};\\\", \\\"{x:981,y:561,t:1528139983956};\\\", \\\"{x:1002,y:561,t:1528139983972};\\\", \\\"{x:1023,y:564,t:1528139983990};\\\", \\\"{x:1044,y:570,t:1528139984007};\\\", \\\"{x:1069,y:578,t:1528139984023};\\\", \\\"{x:1100,y:593,t:1528139984040};\\\", \\\"{x:1129,y:610,t:1528139984056};\\\", \\\"{x:1161,y:628,t:1528139984073};\\\", \\\"{x:1222,y:668,t:1528139984090};\\\", \\\"{x:1259,y:693,t:1528139984107};\\\", \\\"{x:1282,y:710,t:1528139984123};\\\", \\\"{x:1299,y:727,t:1528139984140};\\\", \\\"{x:1315,y:746,t:1528139984157};\\\", \\\"{x:1332,y:767,t:1528139984173};\\\", \\\"{x:1346,y:786,t:1528139984191};\\\", \\\"{x:1359,y:802,t:1528139984207};\\\", \\\"{x:1373,y:820,t:1528139984223};\\\", \\\"{x:1391,y:837,t:1528139984241};\\\", \\\"{x:1409,y:854,t:1528139984257};\\\", \\\"{x:1430,y:870,t:1528139984274};\\\", \\\"{x:1448,y:886,t:1528139984290};\\\", \\\"{x:1457,y:896,t:1528139984308};\\\", \\\"{x:1465,y:904,t:1528139984324};\\\", \\\"{x:1472,y:914,t:1528139984340};\\\", \\\"{x:1476,y:920,t:1528139984357};\\\", \\\"{x:1477,y:924,t:1528139984374};\\\", \\\"{x:1477,y:927,t:1528139984390};\\\", \\\"{x:1479,y:930,t:1528139984407};\\\", \\\"{x:1480,y:932,t:1528139984424};\\\", \\\"{x:1480,y:934,t:1528139984441};\\\", \\\"{x:1480,y:935,t:1528139984458};\\\", \\\"{x:1480,y:936,t:1528139984499};\\\", \\\"{x:1480,y:937,t:1528139984539};\\\", \\\"{x:1480,y:938,t:1528139984547};\\\", \\\"{x:1479,y:938,t:1528139984558};\\\", \\\"{x:1471,y:938,t:1528139984574};\\\", \\\"{x:1464,y:937,t:1528139984591};\\\", \\\"{x:1459,y:935,t:1528139984607};\\\", \\\"{x:1457,y:934,t:1528139984625};\\\", \\\"{x:1453,y:933,t:1528139984641};\\\", \\\"{x:1449,y:931,t:1528139984658};\\\", \\\"{x:1443,y:929,t:1528139984675};\\\", \\\"{x:1441,y:927,t:1528139984691};\\\", \\\"{x:1437,y:924,t:1528139984707};\\\", \\\"{x:1435,y:923,t:1528139984724};\\\", \\\"{x:1434,y:922,t:1528139984740};\\\", \\\"{x:1431,y:920,t:1528139984758};\\\", \\\"{x:1429,y:918,t:1528139984775};\\\", \\\"{x:1425,y:915,t:1528139984791};\\\", \\\"{x:1424,y:914,t:1528139984810};\\\", \\\"{x:1423,y:913,t:1528139984835};\\\", \\\"{x:1422,y:912,t:1528139984875};\\\", \\\"{x:1420,y:911,t:1528139984898};\\\", \\\"{x:1419,y:910,t:1528139984915};\\\", \\\"{x:1418,y:910,t:1528139984924};\\\", \\\"{x:1417,y:909,t:1528139984970};\\\", \\\"{x:1416,y:909,t:1528139985027};\\\", \\\"{x:1415,y:909,t:1528139985041};\\\", \\\"{x:1420,y:922,t:1528139985715};\\\", \\\"{x:1431,y:939,t:1528139985725};\\\", \\\"{x:1460,y:972,t:1528139985741};\\\", \\\"{x:1489,y:1007,t:1528139985759};\\\", \\\"{x:1514,y:1025,t:1528139985775};\\\", \\\"{x:1531,y:1036,t:1528139985791};\\\", \\\"{x:1537,y:1039,t:1528139985809};\\\", \\\"{x:1543,y:1042,t:1528139985825};\\\", \\\"{x:1544,y:1042,t:1528139985842};\\\", \\\"{x:1545,y:1042,t:1528139985947};\\\", \\\"{x:1542,y:1034,t:1528139985959};\\\", \\\"{x:1524,y:1013,t:1528139985976};\\\", \\\"{x:1509,y:994,t:1528139985991};\\\", \\\"{x:1488,y:969,t:1528139986009};\\\", \\\"{x:1465,y:944,t:1528139986026};\\\", \\\"{x:1431,y:915,t:1528139986042};\\\", \\\"{x:1410,y:901,t:1528139986059};\\\", \\\"{x:1398,y:891,t:1528139986076};\\\", \\\"{x:1393,y:887,t:1528139986093};\\\", \\\"{x:1391,y:885,t:1528139986109};\\\", \\\"{x:1389,y:882,t:1528139986126};\\\", \\\"{x:1387,y:878,t:1528139986142};\\\", \\\"{x:1383,y:871,t:1528139986159};\\\", \\\"{x:1377,y:858,t:1528139986176};\\\", \\\"{x:1363,y:837,t:1528139986192};\\\", \\\"{x:1347,y:816,t:1528139986208};\\\", \\\"{x:1334,y:801,t:1528139986226};\\\", \\\"{x:1322,y:790,t:1528139986243};\\\", \\\"{x:1320,y:789,t:1528139986258};\\\", \\\"{x:1318,y:787,t:1528139986275};\\\", \\\"{x:1316,y:786,t:1528139986293};\\\", \\\"{x:1314,y:784,t:1528139986308};\\\", \\\"{x:1308,y:780,t:1528139986325};\\\", \\\"{x:1300,y:776,t:1528139986343};\\\", \\\"{x:1296,y:773,t:1528139986358};\\\", \\\"{x:1293,y:773,t:1528139986375};\\\", \\\"{x:1300,y:774,t:1528139986483};\\\", \\\"{x:1306,y:777,t:1528139986492};\\\", \\\"{x:1311,y:779,t:1528139986509};\\\", \\\"{x:1313,y:781,t:1528139986843};\\\", \\\"{x:1319,y:783,t:1528139986859};\\\", \\\"{x:1323,y:786,t:1528139986877};\\\", \\\"{x:1328,y:788,t:1528139986892};\\\", \\\"{x:1331,y:791,t:1528139986909};\\\", \\\"{x:1336,y:797,t:1528139986927};\\\", \\\"{x:1338,y:799,t:1528139986943};\\\", \\\"{x:1340,y:802,t:1528139986960};\\\", \\\"{x:1343,y:805,t:1528139986977};\\\", \\\"{x:1344,y:806,t:1528139986993};\\\", \\\"{x:1346,y:807,t:1528139987010};\\\", \\\"{x:1347,y:808,t:1528139987026};\\\", \\\"{x:1347,y:804,t:1528139987139};\\\", \\\"{x:1340,y:785,t:1528139987146};\\\", \\\"{x:1323,y:758,t:1528139987160};\\\", \\\"{x:1298,y:724,t:1528139987176};\\\", \\\"{x:1278,y:697,t:1528139987192};\\\", \\\"{x:1261,y:674,t:1528139987210};\\\", \\\"{x:1227,y:637,t:1528139987226};\\\", \\\"{x:1211,y:619,t:1528139987242};\\\", \\\"{x:1203,y:608,t:1528139987259};\\\", \\\"{x:1200,y:603,t:1528139987277};\\\", \\\"{x:1200,y:599,t:1528139987293};\\\", \\\"{x:1200,y:598,t:1528139987309};\\\", \\\"{x:1200,y:596,t:1528139987326};\\\", \\\"{x:1200,y:595,t:1528139987347};\\\", \\\"{x:1200,y:594,t:1528139987435};\\\", \\\"{x:1200,y:593,t:1528139987466};\\\", \\\"{x:1202,y:590,t:1528139987476};\\\", \\\"{x:1210,y:588,t:1528139987493};\\\", \\\"{x:1215,y:586,t:1528139987509};\\\", \\\"{x:1220,y:583,t:1528139987527};\\\", \\\"{x:1224,y:582,t:1528139987543};\\\", \\\"{x:1224,y:581,t:1528139987559};\\\", \\\"{x:1227,y:580,t:1528139987576};\\\", \\\"{x:1230,y:579,t:1528139987593};\\\", \\\"{x:1231,y:579,t:1528139987610};\\\", \\\"{x:1235,y:578,t:1528139987627};\\\", \\\"{x:1235,y:577,t:1528139987644};\\\", \\\"{x:1236,y:577,t:1528139987675};\\\", \\\"{x:1238,y:576,t:1528139987714};\\\", \\\"{x:1240,y:576,t:1528139987731};\\\", \\\"{x:1243,y:576,t:1528139987747};\\\", \\\"{x:1244,y:576,t:1528139987762};\\\", \\\"{x:1245,y:576,t:1528139987795};\\\", \\\"{x:1246,y:576,t:1528139987810};\\\", \\\"{x:1250,y:576,t:1528139987826};\\\", \\\"{x:1254,y:578,t:1528139987844};\\\", \\\"{x:1261,y:585,t:1528139987861};\\\", \\\"{x:1270,y:595,t:1528139987877};\\\", \\\"{x:1280,y:608,t:1528139987893};\\\", \\\"{x:1289,y:619,t:1528139987910};\\\", \\\"{x:1296,y:626,t:1528139987926};\\\", \\\"{x:1301,y:631,t:1528139987943};\\\", \\\"{x:1305,y:637,t:1528139987960};\\\", \\\"{x:1313,y:644,t:1528139987976};\\\", \\\"{x:1318,y:652,t:1528139987993};\\\", \\\"{x:1329,y:669,t:1528139988009};\\\", \\\"{x:1340,y:688,t:1528139988026};\\\", \\\"{x:1354,y:711,t:1528139988043};\\\", \\\"{x:1372,y:735,t:1528139988060};\\\", \\\"{x:1396,y:768,t:1528139988075};\\\", \\\"{x:1422,y:802,t:1528139988093};\\\", \\\"{x:1439,y:823,t:1528139988110};\\\", \\\"{x:1455,y:839,t:1528139988126};\\\", \\\"{x:1472,y:861,t:1528139988143};\\\", \\\"{x:1495,y:888,t:1528139988160};\\\", \\\"{x:1514,y:910,t:1528139988176};\\\", \\\"{x:1529,y:928,t:1528139988193};\\\", \\\"{x:1540,y:941,t:1528139988210};\\\", \\\"{x:1544,y:947,t:1528139988226};\\\", \\\"{x:1545,y:953,t:1528139988244};\\\", \\\"{x:1548,y:959,t:1528139988261};\\\", \\\"{x:1549,y:964,t:1528139988277};\\\", \\\"{x:1549,y:965,t:1528139988293};\\\", \\\"{x:1549,y:967,t:1528139988310};\\\", \\\"{x:1549,y:968,t:1528139988327};\\\", \\\"{x:1551,y:970,t:1528139988403};\\\", \\\"{x:1551,y:971,t:1528139988426};\\\", \\\"{x:1551,y:973,t:1528139988450};\\\", \\\"{x:1551,y:974,t:1528139988460};\\\", \\\"{x:1552,y:977,t:1528139988477};\\\", \\\"{x:1553,y:979,t:1528139988493};\\\", \\\"{x:1554,y:981,t:1528139988511};\\\", \\\"{x:1555,y:984,t:1528139988528};\\\", \\\"{x:1556,y:987,t:1528139988544};\\\", \\\"{x:1558,y:993,t:1528139988560};\\\", \\\"{x:1559,y:998,t:1528139988577};\\\", \\\"{x:1562,y:1004,t:1528139988594};\\\", \\\"{x:1566,y:1017,t:1528139988610};\\\", \\\"{x:1568,y:1021,t:1528139988627};\\\", \\\"{x:1568,y:1024,t:1528139988643};\\\", \\\"{x:1569,y:1024,t:1528139988699};\\\", \\\"{x:1568,y:1024,t:1528139988770};\\\", \\\"{x:1567,y:1024,t:1528139988778};\\\", \\\"{x:1566,y:1024,t:1528139988794};\\\", \\\"{x:1564,y:1024,t:1528139988811};\\\", \\\"{x:1562,y:1024,t:1528139988827};\\\", \\\"{x:1561,y:1024,t:1528139988844};\\\", \\\"{x:1560,y:1023,t:1528139988874};\\\", \\\"{x:1558,y:1023,t:1528139989026};\\\", \\\"{x:1557,y:1023,t:1528139989082};\\\", \\\"{x:1557,y:1022,t:1528139989094};\\\", \\\"{x:1556,y:1021,t:1528139989110};\\\", \\\"{x:1555,y:1021,t:1528139989129};\\\", \\\"{x:1553,y:1020,t:1528139989169};\\\", \\\"{x:1551,y:1020,t:1528139989186};\\\", \\\"{x:1549,y:1020,t:1528139989194};\\\", \\\"{x:1544,y:1016,t:1528139989211};\\\", \\\"{x:1530,y:1010,t:1528139989227};\\\", \\\"{x:1506,y:1000,t:1528139989244};\\\", \\\"{x:1439,y:982,t:1528139989261};\\\", \\\"{x:1334,y:947,t:1528139989277};\\\", \\\"{x:1205,y:900,t:1528139989294};\\\", \\\"{x:1050,y:849,t:1528139989311};\\\", \\\"{x:900,y:802,t:1528139989327};\\\", \\\"{x:773,y:766,t:1528139989344};\\\", \\\"{x:670,y:736,t:1528139989361};\\\", \\\"{x:592,y:714,t:1528139989377};\\\", \\\"{x:521,y:701,t:1528139989395};\\\", \\\"{x:496,y:701,t:1528139989411};\\\", \\\"{x:479,y:701,t:1528139989427};\\\", \\\"{x:476,y:703,t:1528139989444};\\\", \\\"{x:474,y:704,t:1528139989462};\\\", \\\"{x:474,y:708,t:1528139989562};\\\", \\\"{x:474,y:711,t:1528139989578};\\\", \\\"{x:473,y:722,t:1528139989598};\\\", \\\"{x:471,y:729,t:1528139989611};\\\", \\\"{x:471,y:735,t:1528139989628};\\\", \\\"{x:474,y:741,t:1528139989643};\\\", \\\"{x:476,y:743,t:1528139989660};\\\", \\\"{x:478,y:745,t:1528139989676};\\\", \\\"{x:479,y:746,t:1528139989693};\\\", \\\"{x:480,y:746,t:1528139989721};\\\", \\\"{x:481,y:747,t:1528139989794};\\\" ] }, { \\\"rt\\\": 11390, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 672076, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:482,y:746,t:1528139995288};\\\", \\\"{x:502,y:739,t:1528139995316};\\\", \\\"{x:509,y:735,t:1528139995325};\\\", \\\"{x:515,y:733,t:1528139995342};\\\", \\\"{x:519,y:731,t:1528139995358};\\\", \\\"{x:524,y:728,t:1528139995375};\\\", \\\"{x:530,y:726,t:1528139995391};\\\", \\\"{x:537,y:723,t:1528139995408};\\\", \\\"{x:543,y:720,t:1528139995425};\\\", \\\"{x:551,y:716,t:1528139995442};\\\", \\\"{x:562,y:711,t:1528139995457};\\\", \\\"{x:574,y:708,t:1528139995475};\\\", \\\"{x:588,y:704,t:1528139995497};\\\", \\\"{x:598,y:703,t:1528139995513};\\\", \\\"{x:606,y:703,t:1528139995530};\\\", \\\"{x:623,y:699,t:1528139995547};\\\", \\\"{x:623,y:698,t:1528139996079};\\\", \\\"{x:624,y:698,t:1528139996087};\\\", \\\"{x:626,y:698,t:1528139996098};\\\", \\\"{x:628,y:698,t:1528139996114};\\\", \\\"{x:631,y:698,t:1528139996131};\\\", \\\"{x:634,y:698,t:1528139996148};\\\", \\\"{x:641,y:698,t:1528139996164};\\\", \\\"{x:652,y:698,t:1528139996181};\\\", \\\"{x:669,y:698,t:1528139996198};\\\", \\\"{x:690,y:698,t:1528139996214};\\\", \\\"{x:725,y:698,t:1528139996231};\\\", \\\"{x:751,y:698,t:1528139996248};\\\", \\\"{x:781,y:698,t:1528139996266};\\\", \\\"{x:819,y:702,t:1528139996281};\\\", \\\"{x:869,y:714,t:1528139996299};\\\", \\\"{x:931,y:733,t:1528139996316};\\\", \\\"{x:983,y:747,t:1528139996332};\\\", \\\"{x:1031,y:761,t:1528139996349};\\\", \\\"{x:1074,y:776,t:1528139996365};\\\", \\\"{x:1119,y:797,t:1528139996382};\\\", \\\"{x:1161,y:819,t:1528139996399};\\\", \\\"{x:1231,y:855,t:1528139996416};\\\", \\\"{x:1273,y:883,t:1528139996432};\\\", \\\"{x:1311,y:905,t:1528139996448};\\\", \\\"{x:1347,y:930,t:1528139996465};\\\", \\\"{x:1380,y:949,t:1528139996483};\\\", \\\"{x:1400,y:962,t:1528139996499};\\\", \\\"{x:1418,y:972,t:1528139996516};\\\", \\\"{x:1425,y:975,t:1528139996532};\\\", \\\"{x:1427,y:975,t:1528139996549};\\\", \\\"{x:1425,y:975,t:1528139996696};\\\", \\\"{x:1424,y:975,t:1528139996704};\\\", \\\"{x:1421,y:975,t:1528139996720};\\\", \\\"{x:1420,y:975,t:1528139996733};\\\", \\\"{x:1417,y:975,t:1528139996750};\\\", \\\"{x:1414,y:975,t:1528139996765};\\\", \\\"{x:1412,y:975,t:1528139996782};\\\", \\\"{x:1410,y:976,t:1528139996800};\\\", \\\"{x:1409,y:976,t:1528139996864};\\\", \\\"{x:1408,y:976,t:1528139996882};\\\", \\\"{x:1404,y:978,t:1528139996899};\\\", \\\"{x:1401,y:978,t:1528139996915};\\\", \\\"{x:1397,y:979,t:1528139996933};\\\", \\\"{x:1394,y:979,t:1528139996951};\\\", \\\"{x:1391,y:980,t:1528139996967};\\\", \\\"{x:1389,y:980,t:1528139996983};\\\", \\\"{x:1387,y:980,t:1528139997000};\\\", \\\"{x:1385,y:980,t:1528139997016};\\\", \\\"{x:1383,y:980,t:1528139997049};\\\", \\\"{x:1382,y:980,t:1528139997056};\\\", \\\"{x:1381,y:980,t:1528139997067};\\\", \\\"{x:1377,y:980,t:1528139997082};\\\", \\\"{x:1375,y:980,t:1528139997100};\\\", \\\"{x:1371,y:980,t:1528139997117};\\\", \\\"{x:1369,y:980,t:1528139997136};\\\", \\\"{x:1368,y:980,t:1528139997432};\\\", \\\"{x:1366,y:980,t:1528139998632};\\\", \\\"{x:1366,y:979,t:1528139998640};\\\", \\\"{x:1365,y:978,t:1528139998652};\\\", \\\"{x:1365,y:976,t:1528139998669};\\\", \\\"{x:1365,y:975,t:1528139998685};\\\", \\\"{x:1364,y:973,t:1528139998702};\\\", \\\"{x:1362,y:970,t:1528139998719};\\\", \\\"{x:1362,y:968,t:1528139998736};\\\", \\\"{x:1361,y:967,t:1528139998751};\\\", \\\"{x:1360,y:962,t:1528139998768};\\\", \\\"{x:1359,y:958,t:1528139998785};\\\", \\\"{x:1358,y:955,t:1528139998801};\\\", \\\"{x:1357,y:947,t:1528139998818};\\\", \\\"{x:1357,y:941,t:1528139998835};\\\", \\\"{x:1357,y:933,t:1528139998852};\\\", \\\"{x:1357,y:928,t:1528139998868};\\\", \\\"{x:1358,y:922,t:1528139998886};\\\", \\\"{x:1358,y:920,t:1528139998902};\\\", \\\"{x:1358,y:918,t:1528139998918};\\\", \\\"{x:1358,y:916,t:1528139998935};\\\", \\\"{x:1359,y:912,t:1528139998952};\\\", \\\"{x:1360,y:910,t:1528139998968};\\\", \\\"{x:1361,y:908,t:1528139998986};\\\", \\\"{x:1361,y:907,t:1528139999003};\\\", \\\"{x:1362,y:907,t:1528139999019};\\\", \\\"{x:1362,y:905,t:1528139999081};\\\", \\\"{x:1362,y:904,t:1528139999104};\\\", \\\"{x:1363,y:902,t:1528139999118};\\\", \\\"{x:1365,y:898,t:1528139999135};\\\", \\\"{x:1366,y:896,t:1528139999152};\\\", \\\"{x:1367,y:893,t:1528139999169};\\\", \\\"{x:1368,y:892,t:1528139999186};\\\", \\\"{x:1371,y:884,t:1528139999736};\\\", \\\"{x:1382,y:868,t:1528139999754};\\\", \\\"{x:1389,y:858,t:1528139999771};\\\", \\\"{x:1398,y:846,t:1528139999787};\\\", \\\"{x:1404,y:835,t:1528139999804};\\\", \\\"{x:1411,y:822,t:1528139999821};\\\", \\\"{x:1420,y:805,t:1528139999837};\\\", \\\"{x:1426,y:790,t:1528139999854};\\\", \\\"{x:1432,y:774,t:1528139999871};\\\", \\\"{x:1438,y:759,t:1528139999887};\\\", \\\"{x:1450,y:727,t:1528139999904};\\\", \\\"{x:1453,y:706,t:1528139999920};\\\", \\\"{x:1458,y:681,t:1528139999936};\\\", \\\"{x:1463,y:665,t:1528139999954};\\\", \\\"{x:1465,y:658,t:1528139999971};\\\", \\\"{x:1465,y:656,t:1528139999987};\\\", \\\"{x:1465,y:655,t:1528140000003};\\\", \\\"{x:1466,y:653,t:1528140000021};\\\", \\\"{x:1467,y:653,t:1528140000048};\\\", \\\"{x:1473,y:653,t:1528140000056};\\\", \\\"{x:1476,y:651,t:1528140000072};\\\", \\\"{x:1477,y:651,t:1528140000087};\\\", \\\"{x:1471,y:652,t:1528140000137};\\\", \\\"{x:1461,y:656,t:1528140000144};\\\", \\\"{x:1448,y:662,t:1528140000154};\\\", \\\"{x:1413,y:675,t:1528140000171};\\\", \\\"{x:1355,y:701,t:1528140000188};\\\", \\\"{x:1266,y:728,t:1528140000204};\\\", \\\"{x:1170,y:749,t:1528140000220};\\\", \\\"{x:1067,y:765,t:1528140000238};\\\", \\\"{x:964,y:769,t:1528140000255};\\\", \\\"{x:837,y:769,t:1528140000271};\\\", \\\"{x:632,y:769,t:1528140000287};\\\", \\\"{x:488,y:753,t:1528140000305};\\\", \\\"{x:367,y:739,t:1528140000321};\\\", \\\"{x:310,y:727,t:1528140000337};\\\", \\\"{x:291,y:725,t:1528140000350};\\\", \\\"{x:258,y:714,t:1528140000367};\\\", \\\"{x:242,y:709,t:1528140000384};\\\", \\\"{x:240,y:708,t:1528140000400};\\\", \\\"{x:240,y:707,t:1528140000447};\\\", \\\"{x:241,y:704,t:1528140000455};\\\", \\\"{x:249,y:701,t:1528140000467};\\\", \\\"{x:258,y:695,t:1528140000484};\\\", \\\"{x:268,y:690,t:1528140000500};\\\", \\\"{x:281,y:680,t:1528140000517};\\\", \\\"{x:298,y:669,t:1528140000535};\\\", \\\"{x:317,y:659,t:1528140000550};\\\", \\\"{x:364,y:635,t:1528140000567};\\\", \\\"{x:426,y:599,t:1528140000583};\\\", \\\"{x:496,y:566,t:1528140000601};\\\", \\\"{x:531,y:552,t:1528140000618};\\\", \\\"{x:543,y:544,t:1528140000634};\\\", \\\"{x:545,y:543,t:1528140000651};\\\", \\\"{x:540,y:539,t:1528140000904};\\\", \\\"{x:537,y:539,t:1528140000917};\\\", \\\"{x:534,y:538,t:1528140000935};\\\", \\\"{x:533,y:538,t:1528140000952};\\\", \\\"{x:531,y:537,t:1528140000968};\\\", \\\"{x:530,y:536,t:1528140000985};\\\", \\\"{x:527,y:535,t:1528140001002};\\\", \\\"{x:525,y:535,t:1528140001018};\\\", \\\"{x:521,y:534,t:1528140001034};\\\", \\\"{x:520,y:533,t:1528140001052};\\\", \\\"{x:511,y:530,t:1528140001067};\\\", \\\"{x:495,y:530,t:1528140001087};\\\", \\\"{x:479,y:528,t:1528140001101};\\\", \\\"{x:464,y:528,t:1528140001118};\\\", \\\"{x:445,y:527,t:1528140001134};\\\", \\\"{x:428,y:526,t:1528140001151};\\\", \\\"{x:416,y:526,t:1528140001168};\\\", \\\"{x:412,y:526,t:1528140001185};\\\", \\\"{x:409,y:527,t:1528140001201};\\\", \\\"{x:405,y:527,t:1528140001219};\\\", \\\"{x:402,y:527,t:1528140001235};\\\", \\\"{x:400,y:527,t:1528140001251};\\\", \\\"{x:399,y:528,t:1528140001269};\\\", \\\"{x:398,y:528,t:1528140001319};\\\", \\\"{x:397,y:528,t:1528140001335};\\\", \\\"{x:393,y:529,t:1528140001352};\\\", \\\"{x:390,y:530,t:1528140001369};\\\", \\\"{x:390,y:531,t:1528140001385};\\\", \\\"{x:389,y:534,t:1528140001807};\\\", \\\"{x:387,y:537,t:1528140001818};\\\", \\\"{x:385,y:548,t:1528140001835};\\\", \\\"{x:381,y:561,t:1528140001853};\\\", \\\"{x:378,y:575,t:1528140001869};\\\", \\\"{x:377,y:586,t:1528140001885};\\\", \\\"{x:377,y:595,t:1528140001903};\\\", \\\"{x:377,y:602,t:1528140001919};\\\", \\\"{x:377,y:611,t:1528140001935};\\\", \\\"{x:377,y:616,t:1528140001952};\\\", \\\"{x:377,y:621,t:1528140001968};\\\", \\\"{x:373,y:627,t:1528140001986};\\\", \\\"{x:373,y:629,t:1528140002002};\\\", \\\"{x:373,y:633,t:1528140002018};\\\", \\\"{x:372,y:633,t:1528140002035};\\\", \\\"{x:372,y:636,t:1528140002052};\\\", \\\"{x:372,y:633,t:1528140002296};\\\", \\\"{x:372,y:632,t:1528140002304};\\\", \\\"{x:372,y:629,t:1528140002320};\\\", \\\"{x:372,y:628,t:1528140002342};\\\", \\\"{x:375,y:630,t:1528140002623};\\\", \\\"{x:388,y:644,t:1528140002636};\\\", \\\"{x:424,y:679,t:1528140002653};\\\", \\\"{x:471,y:719,t:1528140002669};\\\", \\\"{x:502,y:749,t:1528140002687};\\\", \\\"{x:518,y:764,t:1528140002703};\\\", \\\"{x:533,y:777,t:1528140002719};\\\", \\\"{x:540,y:783,t:1528140002735};\\\", \\\"{x:546,y:787,t:1528140002752};\\\", \\\"{x:547,y:787,t:1528140002784};\\\", \\\"{x:546,y:782,t:1528140002889};\\\", \\\"{x:543,y:771,t:1528140002903};\\\", \\\"{x:534,y:753,t:1528140002920};\\\", \\\"{x:512,y:723,t:1528140002935};\\\", \\\"{x:500,y:706,t:1528140002953};\\\", \\\"{x:491,y:695,t:1528140002969};\\\", \\\"{x:489,y:692,t:1528140002986};\\\", \\\"{x:486,y:689,t:1528140003003};\\\", \\\"{x:482,y:685,t:1528140003019};\\\", \\\"{x:475,y:680,t:1528140003036};\\\", \\\"{x:468,y:675,t:1528140003053};\\\", \\\"{x:460,y:668,t:1528140003070};\\\", \\\"{x:447,y:659,t:1528140003086};\\\", \\\"{x:433,y:648,t:1528140003102};\\\", \\\"{x:395,y:626,t:1528140003120};\\\", \\\"{x:378,y:618,t:1528140003135};\\\", \\\"{x:369,y:615,t:1528140003152};\\\", \\\"{x:365,y:614,t:1528140003169};\\\", \\\"{x:363,y:614,t:1528140003186};\\\", \\\"{x:362,y:614,t:1528140003203};\\\", \\\"{x:364,y:614,t:1528140003407};\\\", \\\"{x:365,y:614,t:1528140003575};\\\", \\\"{x:367,y:614,t:1528140003648};\\\", \\\"{x:368,y:614,t:1528140003664};\\\", \\\"{x:370,y:614,t:1528140003671};\\\", \\\"{x:371,y:614,t:1528140003688};\\\", \\\"{x:375,y:614,t:1528140003704};\\\", \\\"{x:378,y:614,t:1528140003720};\\\", \\\"{x:380,y:615,t:1528140003742};\\\", \\\"{x:381,y:615,t:1528140004055};\\\", \\\"{x:392,y:629,t:1528140004071};\\\", \\\"{x:449,y:686,t:1528140004087};\\\", \\\"{x:483,y:716,t:1528140004103};\\\", \\\"{x:523,y:746,t:1528140004121};\\\", \\\"{x:534,y:755,t:1528140004137};\\\", \\\"{x:542,y:759,t:1528140004154};\\\", \\\"{x:543,y:759,t:1528140004170};\\\", \\\"{x:543,y:760,t:1528140004191};\\\", \\\"{x:542,y:760,t:1528140004280};\\\", \\\"{x:541,y:759,t:1528140004288};\\\", \\\"{x:537,y:747,t:1528140004304};\\\", \\\"{x:532,y:728,t:1528140004320};\\\", \\\"{x:527,y:715,t:1528140004338};\\\", \\\"{x:526,y:712,t:1528140004355};\\\", \\\"{x:526,y:714,t:1528140004608};\\\", \\\"{x:527,y:716,t:1528140004621};\\\", \\\"{x:528,y:719,t:1528140004638};\\\", \\\"{x:528,y:723,t:1528140004656};\\\", \\\"{x:529,y:725,t:1528140004671};\\\" ] }, { \\\"rt\\\": 8013, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 681480, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -10 AM-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:722,t:1528140006263};\\\", \\\"{x:559,y:719,t:1528140006272};\\\", \\\"{x:565,y:716,t:1528140006289};\\\", \\\"{x:574,y:709,t:1528140006305};\\\", \\\"{x:578,y:708,t:1528140006321};\\\", \\\"{x:579,y:708,t:1528140006353};\\\", \\\"{x:580,y:707,t:1528140007383};\\\", \\\"{x:582,y:706,t:1528140007399};\\\", \\\"{x:583,y:706,t:1528140007407};\\\", \\\"{x:588,y:703,t:1528140007422};\\\", \\\"{x:608,y:694,t:1528140007440};\\\", \\\"{x:638,y:682,t:1528140007457};\\\", \\\"{x:674,y:667,t:1528140007473};\\\", \\\"{x:715,y:653,t:1528140007490};\\\", \\\"{x:758,y:638,t:1528140007507};\\\", \\\"{x:805,y:624,t:1528140007525};\\\", \\\"{x:854,y:614,t:1528140007541};\\\", \\\"{x:882,y:608,t:1528140007557};\\\", \\\"{x:900,y:602,t:1528140007574};\\\", \\\"{x:912,y:598,t:1528140007590};\\\", \\\"{x:924,y:594,t:1528140007606};\\\", \\\"{x:932,y:593,t:1528140007624};\\\", \\\"{x:938,y:593,t:1528140007640};\\\", \\\"{x:949,y:593,t:1528140007657};\\\", \\\"{x:961,y:593,t:1528140007674};\\\", \\\"{x:968,y:593,t:1528140007690};\\\", \\\"{x:973,y:593,t:1528140007706};\\\", \\\"{x:975,y:593,t:1528140007724};\\\", \\\"{x:975,y:589,t:1528140007740};\\\", \\\"{x:975,y:590,t:1528140008039};\\\", \\\"{x:978,y:594,t:1528140008047};\\\", \\\"{x:988,y:603,t:1528140008058};\\\", \\\"{x:1006,y:618,t:1528140008074};\\\", \\\"{x:1028,y:629,t:1528140008091};\\\", \\\"{x:1058,y:648,t:1528140008107};\\\", \\\"{x:1108,y:669,t:1528140008125};\\\", \\\"{x:1155,y:689,t:1528140008141};\\\", \\\"{x:1198,y:704,t:1528140008158};\\\", \\\"{x:1238,y:711,t:1528140008175};\\\", \\\"{x:1261,y:717,t:1528140008192};\\\", \\\"{x:1286,y:721,t:1528140008208};\\\", \\\"{x:1306,y:725,t:1528140008224};\\\", \\\"{x:1317,y:727,t:1528140008241};\\\", \\\"{x:1322,y:727,t:1528140008259};\\\", \\\"{x:1331,y:727,t:1528140008275};\\\", \\\"{x:1338,y:727,t:1528140008292};\\\", \\\"{x:1344,y:727,t:1528140008309};\\\", \\\"{x:1351,y:727,t:1528140008325};\\\", \\\"{x:1355,y:727,t:1528140008342};\\\", \\\"{x:1357,y:727,t:1528140008358};\\\", \\\"{x:1361,y:727,t:1528140008375};\\\", \\\"{x:1366,y:727,t:1528140008392};\\\", \\\"{x:1375,y:731,t:1528140008409};\\\", \\\"{x:1381,y:733,t:1528140008426};\\\", \\\"{x:1384,y:733,t:1528140008442};\\\", \\\"{x:1388,y:733,t:1528140008459};\\\", \\\"{x:1390,y:734,t:1528140008476};\\\", \\\"{x:1394,y:734,t:1528140008492};\\\", \\\"{x:1396,y:734,t:1528140008510};\\\", \\\"{x:1399,y:735,t:1528140008526};\\\", \\\"{x:1405,y:735,t:1528140008543};\\\", \\\"{x:1408,y:734,t:1528140008559};\\\", \\\"{x:1416,y:732,t:1528140008575};\\\", \\\"{x:1420,y:729,t:1528140008593};\\\", \\\"{x:1421,y:728,t:1528140008616};\\\", \\\"{x:1421,y:727,t:1528140008640};\\\", \\\"{x:1421,y:726,t:1528140008648};\\\", \\\"{x:1421,y:725,t:1528140008664};\\\", \\\"{x:1421,y:723,t:1528140008676};\\\", \\\"{x:1421,y:722,t:1528140008693};\\\", \\\"{x:1421,y:721,t:1528140008728};\\\", \\\"{x:1421,y:719,t:1528140008743};\\\", \\\"{x:1416,y:717,t:1528140008760};\\\", \\\"{x:1405,y:716,t:1528140008778};\\\", \\\"{x:1387,y:715,t:1528140008793};\\\", \\\"{x:1364,y:715,t:1528140008810};\\\", \\\"{x:1342,y:715,t:1528140008827};\\\", \\\"{x:1330,y:715,t:1528140008843};\\\", \\\"{x:1324,y:715,t:1528140008860};\\\", \\\"{x:1322,y:713,t:1528140008877};\\\", \\\"{x:1323,y:710,t:1528140009104};\\\", \\\"{x:1326,y:708,t:1528140009111};\\\", \\\"{x:1331,y:705,t:1528140009127};\\\", \\\"{x:1341,y:701,t:1528140009144};\\\", \\\"{x:1345,y:699,t:1528140009164};\\\", \\\"{x:1346,y:699,t:1528140009177};\\\", \\\"{x:1346,y:698,t:1528140009303};\\\", \\\"{x:1345,y:698,t:1528140009327};\\\", \\\"{x:1334,y:702,t:1528140009345};\\\", \\\"{x:1318,y:714,t:1528140009361};\\\", \\\"{x:1303,y:729,t:1528140009378};\\\", \\\"{x:1288,y:748,t:1528140009395};\\\", \\\"{x:1281,y:762,t:1528140009411};\\\", \\\"{x:1272,y:784,t:1528140009427};\\\", \\\"{x:1267,y:805,t:1528140009445};\\\", \\\"{x:1262,y:818,t:1528140009462};\\\", \\\"{x:1256,y:835,t:1528140009478};\\\", \\\"{x:1254,y:848,t:1528140009495};\\\", \\\"{x:1245,y:867,t:1528140009511};\\\", \\\"{x:1240,y:878,t:1528140009529};\\\", \\\"{x:1236,y:888,t:1528140009546};\\\", \\\"{x:1231,y:903,t:1528140009562};\\\", \\\"{x:1226,y:914,t:1528140009579};\\\", \\\"{x:1219,y:931,t:1528140009595};\\\", \\\"{x:1209,y:950,t:1528140009612};\\\", \\\"{x:1207,y:966,t:1528140009629};\\\", \\\"{x:1204,y:986,t:1528140009645};\\\", \\\"{x:1202,y:999,t:1528140009662};\\\", \\\"{x:1199,y:1015,t:1528140009679};\\\", \\\"{x:1198,y:1020,t:1528140009696};\\\", \\\"{x:1197,y:1024,t:1528140009712};\\\", \\\"{x:1196,y:1028,t:1528140009729};\\\", \\\"{x:1196,y:1026,t:1528140009929};\\\", \\\"{x:1196,y:1023,t:1528140009936};\\\", \\\"{x:1197,y:1020,t:1528140009947};\\\", \\\"{x:1198,y:1018,t:1528140009963};\\\", \\\"{x:1199,y:1016,t:1528140009980};\\\", \\\"{x:1199,y:1014,t:1528140009996};\\\", \\\"{x:1201,y:1012,t:1528140010013};\\\", \\\"{x:1202,y:1009,t:1528140010030};\\\", \\\"{x:1204,y:1006,t:1528140010047};\\\", \\\"{x:1206,y:1002,t:1528140010063};\\\", \\\"{x:1209,y:997,t:1528140010080};\\\", \\\"{x:1210,y:994,t:1528140010097};\\\", \\\"{x:1212,y:989,t:1528140010113};\\\", \\\"{x:1213,y:986,t:1528140010130};\\\", \\\"{x:1214,y:981,t:1528140010148};\\\", \\\"{x:1217,y:977,t:1528140010162};\\\", \\\"{x:1217,y:975,t:1528140010180};\\\", \\\"{x:1217,y:971,t:1528140010197};\\\", \\\"{x:1220,y:967,t:1528140010215};\\\", \\\"{x:1221,y:963,t:1528140010230};\\\", \\\"{x:1223,y:958,t:1528140010248};\\\", \\\"{x:1226,y:953,t:1528140010263};\\\", \\\"{x:1228,y:949,t:1528140010280};\\\", \\\"{x:1231,y:944,t:1528140010297};\\\", \\\"{x:1234,y:937,t:1528140010314};\\\", \\\"{x:1239,y:929,t:1528140010332};\\\", \\\"{x:1242,y:924,t:1528140010347};\\\", \\\"{x:1245,y:919,t:1528140010364};\\\", \\\"{x:1248,y:914,t:1528140010381};\\\", \\\"{x:1251,y:909,t:1528140010397};\\\", \\\"{x:1254,y:903,t:1528140010413};\\\", \\\"{x:1257,y:898,t:1528140010431};\\\", \\\"{x:1263,y:888,t:1528140010448};\\\", \\\"{x:1266,y:882,t:1528140010464};\\\", \\\"{x:1271,y:876,t:1528140010481};\\\", \\\"{x:1273,y:870,t:1528140010498};\\\", \\\"{x:1275,y:866,t:1528140010514};\\\", \\\"{x:1277,y:861,t:1528140010531};\\\", \\\"{x:1278,y:857,t:1528140010547};\\\", \\\"{x:1281,y:851,t:1528140010564};\\\", \\\"{x:1282,y:847,t:1528140010580};\\\", \\\"{x:1285,y:841,t:1528140010597};\\\", \\\"{x:1286,y:839,t:1528140010615};\\\", \\\"{x:1289,y:833,t:1528140010631};\\\", \\\"{x:1297,y:818,t:1528140010648};\\\", \\\"{x:1308,y:801,t:1528140010665};\\\", \\\"{x:1320,y:784,t:1528140010681};\\\", \\\"{x:1338,y:758,t:1528140010698};\\\", \\\"{x:1355,y:739,t:1528140010715};\\\", \\\"{x:1367,y:725,t:1528140010731};\\\", \\\"{x:1372,y:719,t:1528140010748};\\\", \\\"{x:1372,y:718,t:1528140010765};\\\", \\\"{x:1375,y:713,t:1528140011153};\\\", \\\"{x:1377,y:703,t:1528140011166};\\\", \\\"{x:1380,y:698,t:1528140011184};\\\", \\\"{x:1381,y:696,t:1528140011200};\\\", \\\"{x:1383,y:691,t:1528140011217};\\\", \\\"{x:1384,y:684,t:1528140011233};\\\", \\\"{x:1387,y:675,t:1528140011250};\\\", \\\"{x:1389,y:671,t:1528140011266};\\\", \\\"{x:1390,y:667,t:1528140011283};\\\", \\\"{x:1392,y:663,t:1528140011300};\\\", \\\"{x:1393,y:660,t:1528140011316};\\\", \\\"{x:1396,y:655,t:1528140011333};\\\", \\\"{x:1398,y:645,t:1528140011351};\\\", \\\"{x:1402,y:637,t:1528140011368};\\\", \\\"{x:1404,y:631,t:1528140011383};\\\", \\\"{x:1405,y:626,t:1528140011401};\\\", \\\"{x:1406,y:623,t:1528140011418};\\\", \\\"{x:1406,y:622,t:1528140011440};\\\", \\\"{x:1406,y:621,t:1528140011450};\\\", \\\"{x:1406,y:619,t:1528140011467};\\\", \\\"{x:1407,y:614,t:1528140011483};\\\", \\\"{x:1409,y:609,t:1528140011500};\\\", \\\"{x:1409,y:604,t:1528140011518};\\\", \\\"{x:1410,y:596,t:1528140011534};\\\", \\\"{x:1411,y:596,t:1528140011550};\\\", \\\"{x:1411,y:594,t:1528140011567};\\\", \\\"{x:1411,y:593,t:1528140011584};\\\", \\\"{x:1411,y:592,t:1528140011600};\\\", \\\"{x:1412,y:589,t:1528140011618};\\\", \\\"{x:1412,y:588,t:1528140011634};\\\", \\\"{x:1412,y:585,t:1528140011651};\\\", \\\"{x:1412,y:584,t:1528140011667};\\\", \\\"{x:1412,y:583,t:1528140011684};\\\", \\\"{x:1412,y:581,t:1528140011701};\\\", \\\"{x:1413,y:578,t:1528140011717};\\\", \\\"{x:1415,y:577,t:1528140011734};\\\", \\\"{x:1415,y:573,t:1528140011751};\\\", \\\"{x:1415,y:572,t:1528140011768};\\\", \\\"{x:1416,y:571,t:1528140011785};\\\", \\\"{x:1416,y:570,t:1528140011816};\\\", \\\"{x:1416,y:569,t:1528140011848};\\\", \\\"{x:1416,y:568,t:1528140011864};\\\", \\\"{x:1416,y:567,t:1528140011885};\\\", \\\"{x:1417,y:565,t:1528140011904};\\\", \\\"{x:1418,y:564,t:1528140011918};\\\", \\\"{x:1419,y:562,t:1528140011935};\\\", \\\"{x:1421,y:559,t:1528140011951};\\\", \\\"{x:1422,y:555,t:1528140011967};\\\", \\\"{x:1423,y:554,t:1528140011985};\\\", \\\"{x:1425,y:549,t:1528140012001};\\\", \\\"{x:1427,y:543,t:1528140012018};\\\", \\\"{x:1430,y:538,t:1528140012035};\\\", \\\"{x:1434,y:530,t:1528140012051};\\\", \\\"{x:1436,y:525,t:1528140012068};\\\", \\\"{x:1437,y:523,t:1528140012085};\\\", \\\"{x:1437,y:522,t:1528140012152};\\\", \\\"{x:1428,y:518,t:1528140012169};\\\", \\\"{x:1417,y:515,t:1528140012185};\\\", \\\"{x:1387,y:515,t:1528140012202};\\\", \\\"{x:1318,y:524,t:1528140012219};\\\", \\\"{x:1234,y:524,t:1528140012235};\\\", \\\"{x:1148,y:524,t:1528140012252};\\\", \\\"{x:1073,y:524,t:1528140012269};\\\", \\\"{x:998,y:524,t:1528140012286};\\\", \\\"{x:945,y:519,t:1528140012302};\\\", \\\"{x:907,y:515,t:1528140012321};\\\", \\\"{x:874,y:509,t:1528140012335};\\\", \\\"{x:849,y:509,t:1528140012361};\\\", \\\"{x:831,y:509,t:1528140012377};\\\", \\\"{x:813,y:509,t:1528140012393};\\\", \\\"{x:796,y:509,t:1528140012411};\\\", \\\"{x:777,y:509,t:1528140012426};\\\", \\\"{x:756,y:510,t:1528140012443};\\\", \\\"{x:739,y:517,t:1528140012460};\\\", \\\"{x:723,y:521,t:1528140012476};\\\", \\\"{x:718,y:524,t:1528140012494};\\\", \\\"{x:715,y:525,t:1528140012511};\\\", \\\"{x:714,y:526,t:1528140012528};\\\", \\\"{x:709,y:527,t:1528140012544};\\\", \\\"{x:698,y:529,t:1528140012561};\\\", \\\"{x:684,y:533,t:1528140012576};\\\", \\\"{x:670,y:536,t:1528140012594};\\\", \\\"{x:658,y:540,t:1528140012610};\\\", \\\"{x:653,y:543,t:1528140012627};\\\", \\\"{x:652,y:543,t:1528140012654};\\\", \\\"{x:655,y:543,t:1528140012712};\\\", \\\"{x:665,y:538,t:1528140012727};\\\", \\\"{x:685,y:530,t:1528140012744};\\\", \\\"{x:712,y:520,t:1528140012762};\\\", \\\"{x:748,y:514,t:1528140012779};\\\", \\\"{x:773,y:512,t:1528140012794};\\\", \\\"{x:788,y:512,t:1528140012810};\\\", \\\"{x:797,y:512,t:1528140012828};\\\", \\\"{x:799,y:512,t:1528140012844};\\\", \\\"{x:800,y:512,t:1528140012861};\\\", \\\"{x:801,y:512,t:1528140012878};\\\", \\\"{x:803,y:512,t:1528140012894};\\\", \\\"{x:804,y:512,t:1528140012912};\\\", \\\"{x:805,y:514,t:1528140012927};\\\", \\\"{x:810,y:522,t:1528140012945};\\\", \\\"{x:817,y:536,t:1528140012961};\\\", \\\"{x:820,y:545,t:1528140012978};\\\", \\\"{x:821,y:546,t:1528140012995};\\\", \\\"{x:821,y:547,t:1528140013011};\\\", \\\"{x:822,y:549,t:1528140013027};\\\", \\\"{x:822,y:551,t:1528140013045};\\\", \\\"{x:824,y:556,t:1528140013061};\\\", \\\"{x:825,y:560,t:1528140013077};\\\", \\\"{x:826,y:561,t:1528140013094};\\\", \\\"{x:827,y:561,t:1528140013192};\\\", \\\"{x:831,y:558,t:1528140013199};\\\", \\\"{x:833,y:554,t:1528140013210};\\\", \\\"{x:839,y:544,t:1528140013226};\\\", \\\"{x:842,y:540,t:1528140013245};\\\", \\\"{x:842,y:538,t:1528140013260};\\\", \\\"{x:842,y:537,t:1528140013535};\\\", \\\"{x:838,y:537,t:1528140013544};\\\", \\\"{x:820,y:552,t:1528140013562};\\\", \\\"{x:806,y:564,t:1528140013578};\\\", \\\"{x:788,y:577,t:1528140013594};\\\", \\\"{x:770,y:590,t:1528140013612};\\\", \\\"{x:757,y:600,t:1528140013628};\\\", \\\"{x:750,y:608,t:1528140013645};\\\", \\\"{x:744,y:615,t:1528140013661};\\\", \\\"{x:737,y:623,t:1528140013677};\\\", \\\"{x:719,y:641,t:1528140013695};\\\", \\\"{x:700,y:653,t:1528140013711};\\\", \\\"{x:679,y:667,t:1528140013728};\\\", \\\"{x:658,y:678,t:1528140013745};\\\", \\\"{x:642,y:688,t:1528140013762};\\\", \\\"{x:626,y:694,t:1528140013778};\\\", \\\"{x:613,y:700,t:1528140013795};\\\", \\\"{x:605,y:702,t:1528140013812};\\\", \\\"{x:600,y:703,t:1528140013829};\\\", \\\"{x:595,y:705,t:1528140013845};\\\", \\\"{x:593,y:706,t:1528140013862};\\\", \\\"{x:588,y:709,t:1528140013879};\\\", \\\"{x:585,y:709,t:1528140013895};\\\", \\\"{x:578,y:711,t:1528140013912};\\\", \\\"{x:568,y:716,t:1528140013929};\\\", \\\"{x:560,y:724,t:1528140013946};\\\", \\\"{x:556,y:727,t:1528140013963};\\\", \\\"{x:554,y:728,t:1528140013979};\\\", \\\"{x:553,y:728,t:1528140013994};\\\", \\\"{x:553,y:729,t:1528140014012};\\\", \\\"{x:551,y:731,t:1528140014028};\\\", \\\"{x:550,y:736,t:1528140014044};\\\", \\\"{x:548,y:739,t:1528140014062};\\\", \\\"{x:547,y:740,t:1528140014079};\\\" ] }, { \\\"rt\\\": 13248, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 696009, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:740,t:1528140018752};\\\", \\\"{x:557,y:739,t:1528140018767};\\\", \\\"{x:597,y:736,t:1528140018785};\\\", \\\"{x:623,y:734,t:1528140018798};\\\", \\\"{x:652,y:734,t:1528140018816};\\\", \\\"{x:686,y:734,t:1528140018832};\\\", \\\"{x:733,y:734,t:1528140018849};\\\", \\\"{x:786,y:734,t:1528140018866};\\\", \\\"{x:839,y:734,t:1528140018882};\\\", \\\"{x:901,y:734,t:1528140018899};\\\", \\\"{x:968,y:734,t:1528140018916};\\\", \\\"{x:1018,y:734,t:1528140018932};\\\", \\\"{x:1065,y:734,t:1528140018949};\\\", \\\"{x:1105,y:734,t:1528140018966};\\\", \\\"{x:1157,y:734,t:1528140018983};\\\", \\\"{x:1188,y:734,t:1528140018999};\\\", \\\"{x:1215,y:734,t:1528140019015};\\\", \\\"{x:1235,y:734,t:1528140019034};\\\", \\\"{x:1249,y:731,t:1528140019049};\\\", \\\"{x:1264,y:729,t:1528140019066};\\\", \\\"{x:1283,y:728,t:1528140019083};\\\", \\\"{x:1308,y:723,t:1528140019099};\\\", \\\"{x:1341,y:722,t:1528140019116};\\\", \\\"{x:1388,y:722,t:1528140019134};\\\", \\\"{x:1440,y:719,t:1528140019150};\\\", \\\"{x:1485,y:719,t:1528140019167};\\\", \\\"{x:1523,y:719,t:1528140019184};\\\", \\\"{x:1536,y:719,t:1528140019200};\\\", \\\"{x:1541,y:719,t:1528140019217};\\\", \\\"{x:1546,y:718,t:1528140021296};\\\", \\\"{x:1557,y:716,t:1528140021304};\\\", \\\"{x:1576,y:712,t:1528140021319};\\\", \\\"{x:1588,y:711,t:1528140021335};\\\", \\\"{x:1601,y:706,t:1528140021352};\\\", \\\"{x:1609,y:706,t:1528140021368};\\\", \\\"{x:1610,y:704,t:1528140021385};\\\", \\\"{x:1611,y:703,t:1528140021496};\\\", \\\"{x:1612,y:703,t:1528140021592};\\\", \\\"{x:1613,y:703,t:1528140022006};\\\", \\\"{x:1612,y:702,t:1528140022020};\\\", \\\"{x:1608,y:704,t:1528140022036};\\\", \\\"{x:1603,y:709,t:1528140022053};\\\", \\\"{x:1600,y:712,t:1528140022070};\\\", \\\"{x:1598,y:715,t:1528140022086};\\\", \\\"{x:1595,y:719,t:1528140022103};\\\", \\\"{x:1593,y:721,t:1528140022120};\\\", \\\"{x:1592,y:723,t:1528140022142};\\\", \\\"{x:1591,y:723,t:1528140022159};\\\", \\\"{x:1591,y:724,t:1528140022170};\\\", \\\"{x:1591,y:725,t:1528140022186};\\\", \\\"{x:1590,y:727,t:1528140022203};\\\", \\\"{x:1589,y:728,t:1528140022220};\\\", \\\"{x:1588,y:731,t:1528140022237};\\\", \\\"{x:1587,y:732,t:1528140022253};\\\", \\\"{x:1585,y:736,t:1528140022269};\\\", \\\"{x:1581,y:749,t:1528140022287};\\\", \\\"{x:1578,y:756,t:1528140022303};\\\", \\\"{x:1574,y:768,t:1528140022320};\\\", \\\"{x:1570,y:780,t:1528140022337};\\\", \\\"{x:1569,y:789,t:1528140022353};\\\", \\\"{x:1567,y:796,t:1528140022371};\\\", \\\"{x:1567,y:802,t:1528140022388};\\\", \\\"{x:1565,y:812,t:1528140022403};\\\", \\\"{x:1564,y:827,t:1528140022420};\\\", \\\"{x:1560,y:848,t:1528140022437};\\\", \\\"{x:1555,y:866,t:1528140022453};\\\", \\\"{x:1551,y:882,t:1528140022471};\\\", \\\"{x:1545,y:905,t:1528140022487};\\\", \\\"{x:1543,y:915,t:1528140022504};\\\", \\\"{x:1541,y:924,t:1528140022520};\\\", \\\"{x:1540,y:929,t:1528140022537};\\\", \\\"{x:1539,y:936,t:1528140022555};\\\", \\\"{x:1538,y:942,t:1528140022571};\\\", \\\"{x:1537,y:948,t:1528140022588};\\\", \\\"{x:1535,y:952,t:1528140022604};\\\", \\\"{x:1535,y:955,t:1528140022620};\\\", \\\"{x:1535,y:956,t:1528140022638};\\\", \\\"{x:1533,y:958,t:1528140022655};\\\", \\\"{x:1533,y:959,t:1528140022671};\\\", \\\"{x:1532,y:961,t:1528140022688};\\\", \\\"{x:1530,y:965,t:1528140022704};\\\", \\\"{x:1529,y:967,t:1528140022721};\\\", \\\"{x:1528,y:969,t:1528140022738};\\\", \\\"{x:1526,y:970,t:1528140022755};\\\", \\\"{x:1525,y:971,t:1528140022772};\\\", \\\"{x:1523,y:972,t:1528140022788};\\\", \\\"{x:1521,y:974,t:1528140022808};\\\", \\\"{x:1520,y:974,t:1528140022821};\\\", \\\"{x:1518,y:974,t:1528140022838};\\\", \\\"{x:1516,y:974,t:1528140022854};\\\", \\\"{x:1511,y:974,t:1528140022871};\\\", \\\"{x:1509,y:974,t:1528140022888};\\\", \\\"{x:1507,y:975,t:1528140022904};\\\", \\\"{x:1503,y:975,t:1528140022922};\\\", \\\"{x:1502,y:976,t:1528140022938};\\\", \\\"{x:1500,y:976,t:1528140022954};\\\", \\\"{x:1499,y:976,t:1528140022976};\\\", \\\"{x:1498,y:976,t:1528140022987};\\\", \\\"{x:1497,y:976,t:1528140023632};\\\", \\\"{x:1495,y:974,t:1528140023639};\\\", \\\"{x:1492,y:972,t:1528140023656};\\\", \\\"{x:1488,y:970,t:1528140023672};\\\", \\\"{x:1481,y:967,t:1528140023689};\\\", \\\"{x:1476,y:963,t:1528140023706};\\\", \\\"{x:1474,y:962,t:1528140023723};\\\", \\\"{x:1472,y:961,t:1528140023739};\\\", \\\"{x:1471,y:960,t:1528140023756};\\\", \\\"{x:1469,y:959,t:1528140023772};\\\", \\\"{x:1468,y:959,t:1528140023815};\\\", \\\"{x:1467,y:958,t:1528140023823};\\\", \\\"{x:1465,y:957,t:1528140024072};\\\", \\\"{x:1463,y:952,t:1528140024090};\\\", \\\"{x:1461,y:945,t:1528140024105};\\\", \\\"{x:1458,y:938,t:1528140024122};\\\", \\\"{x:1456,y:930,t:1528140024139};\\\", \\\"{x:1452,y:918,t:1528140024156};\\\", \\\"{x:1448,y:906,t:1528140024172};\\\", \\\"{x:1442,y:890,t:1528140024189};\\\", \\\"{x:1435,y:876,t:1528140024206};\\\", \\\"{x:1426,y:860,t:1528140024222};\\\", \\\"{x:1415,y:844,t:1528140024238};\\\", \\\"{x:1405,y:831,t:1528140024256};\\\", \\\"{x:1396,y:821,t:1528140024272};\\\", \\\"{x:1390,y:812,t:1528140024289};\\\", \\\"{x:1382,y:798,t:1528140024307};\\\", \\\"{x:1374,y:785,t:1528140024322};\\\", \\\"{x:1366,y:770,t:1528140024339};\\\", \\\"{x:1358,y:756,t:1528140024356};\\\", \\\"{x:1349,y:743,t:1528140024373};\\\", \\\"{x:1338,y:729,t:1528140024389};\\\", \\\"{x:1331,y:719,t:1528140024407};\\\", \\\"{x:1323,y:707,t:1528140024423};\\\", \\\"{x:1321,y:703,t:1528140024440};\\\", \\\"{x:1319,y:699,t:1528140024456};\\\", \\\"{x:1316,y:696,t:1528140024473};\\\", \\\"{x:1316,y:695,t:1528140024490};\\\", \\\"{x:1316,y:692,t:1528140024506};\\\", \\\"{x:1315,y:692,t:1528140024524};\\\", \\\"{x:1314,y:689,t:1528140024539};\\\", \\\"{x:1314,y:688,t:1528140024567};\\\", \\\"{x:1314,y:687,t:1528140024575};\\\", \\\"{x:1314,y:686,t:1528140024591};\\\", \\\"{x:1313,y:686,t:1528140024606};\\\", \\\"{x:1313,y:685,t:1528140024672};\\\", \\\"{x:1313,y:683,t:1528140024776};\\\", \\\"{x:1312,y:680,t:1528140024790};\\\", \\\"{x:1308,y:673,t:1528140024807};\\\", \\\"{x:1297,y:656,t:1528140024823};\\\", \\\"{x:1283,y:644,t:1528140024840};\\\", \\\"{x:1272,y:636,t:1528140024856};\\\", \\\"{x:1259,y:627,t:1528140024873};\\\", \\\"{x:1241,y:617,t:1528140024891};\\\", \\\"{x:1220,y:606,t:1528140024908};\\\", \\\"{x:1195,y:593,t:1528140024924};\\\", \\\"{x:1171,y:582,t:1528140024941};\\\", \\\"{x:1123,y:562,t:1528140024958};\\\", \\\"{x:1086,y:549,t:1528140024974};\\\", \\\"{x:1046,y:533,t:1528140024991};\\\", \\\"{x:983,y:513,t:1528140025008};\\\", \\\"{x:953,y:506,t:1528140025024};\\\", \\\"{x:917,y:504,t:1528140025042};\\\", \\\"{x:884,y:495,t:1528140025057};\\\", \\\"{x:861,y:490,t:1528140025074};\\\", \\\"{x:848,y:486,t:1528140025088};\\\", \\\"{x:838,y:484,t:1528140025104};\\\", \\\"{x:828,y:484,t:1528140025120};\\\", \\\"{x:820,y:483,t:1528140025137};\\\", \\\"{x:814,y:483,t:1528140025154};\\\", \\\"{x:808,y:483,t:1528140025170};\\\", \\\"{x:797,y:483,t:1528140025187};\\\", \\\"{x:775,y:483,t:1528140025204};\\\", \\\"{x:749,y:483,t:1528140025220};\\\", \\\"{x:728,y:483,t:1528140025237};\\\", \\\"{x:707,y:483,t:1528140025254};\\\", \\\"{x:684,y:483,t:1528140025270};\\\", \\\"{x:651,y:483,t:1528140025288};\\\", \\\"{x:630,y:483,t:1528140025304};\\\", \\\"{x:611,y:483,t:1528140025320};\\\", \\\"{x:594,y:483,t:1528140025337};\\\", \\\"{x:584,y:483,t:1528140025354};\\\", \\\"{x:576,y:483,t:1528140025370};\\\", \\\"{x:569,y:482,t:1528140025387};\\\", \\\"{x:561,y:480,t:1528140025404};\\\", \\\"{x:553,y:479,t:1528140025421};\\\", \\\"{x:541,y:478,t:1528140025438};\\\", \\\"{x:527,y:477,t:1528140025454};\\\", \\\"{x:512,y:477,t:1528140025471};\\\", \\\"{x:502,y:477,t:1528140025487};\\\", \\\"{x:495,y:477,t:1528140025505};\\\", \\\"{x:488,y:477,t:1528140025521};\\\", \\\"{x:481,y:477,t:1528140025537};\\\", \\\"{x:474,y:477,t:1528140025554};\\\", \\\"{x:466,y:477,t:1528140025572};\\\", \\\"{x:461,y:476,t:1528140025587};\\\", \\\"{x:458,y:476,t:1528140025604};\\\", \\\"{x:457,y:475,t:1528140025622};\\\", \\\"{x:455,y:475,t:1528140025637};\\\", \\\"{x:453,y:475,t:1528140025655};\\\", \\\"{x:444,y:475,t:1528140025671};\\\", \\\"{x:437,y:475,t:1528140025687};\\\", \\\"{x:421,y:481,t:1528140025705};\\\", \\\"{x:408,y:488,t:1528140025722};\\\", \\\"{x:392,y:493,t:1528140025738};\\\", \\\"{x:380,y:497,t:1528140025754};\\\", \\\"{x:374,y:497,t:1528140025772};\\\", \\\"{x:373,y:498,t:1528140025788};\\\", \\\"{x:371,y:499,t:1528140025804};\\\", \\\"{x:370,y:500,t:1528140025821};\\\", \\\"{x:369,y:500,t:1528140025895};\\\", \\\"{x:369,y:501,t:1528140025911};\\\", \\\"{x:369,y:502,t:1528140025950};\\\", \\\"{x:369,y:503,t:1528140025974};\\\", \\\"{x:369,y:504,t:1528140025990};\\\", \\\"{x:369,y:506,t:1528140026005};\\\", \\\"{x:370,y:506,t:1528140026022};\\\", \\\"{x:371,y:506,t:1528140026038};\\\", \\\"{x:375,y:506,t:1528140026054};\\\", \\\"{x:383,y:506,t:1528140026071};\\\", \\\"{x:395,y:507,t:1528140026088};\\\", \\\"{x:406,y:508,t:1528140026104};\\\", \\\"{x:422,y:512,t:1528140026121};\\\", \\\"{x:437,y:514,t:1528140026138};\\\", \\\"{x:451,y:514,t:1528140026154};\\\", \\\"{x:460,y:514,t:1528140026171};\\\", \\\"{x:468,y:514,t:1528140026188};\\\", \\\"{x:476,y:509,t:1528140026205};\\\", \\\"{x:482,y:506,t:1528140026221};\\\", \\\"{x:489,y:502,t:1528140026238};\\\", \\\"{x:493,y:501,t:1528140026255};\\\", \\\"{x:494,y:500,t:1528140026271};\\\", \\\"{x:495,y:499,t:1528140026288};\\\", \\\"{x:497,y:499,t:1528140026305};\\\", \\\"{x:503,y:498,t:1528140026323};\\\", \\\"{x:512,y:498,t:1528140026338};\\\", \\\"{x:525,y:498,t:1528140026355};\\\", \\\"{x:536,y:498,t:1528140026371};\\\", \\\"{x:546,y:498,t:1528140026388};\\\", \\\"{x:555,y:498,t:1528140026405};\\\", \\\"{x:563,y:496,t:1528140026420};\\\", \\\"{x:567,y:496,t:1528140026438};\\\", \\\"{x:573,y:495,t:1528140026455};\\\", \\\"{x:576,y:495,t:1528140026471};\\\", \\\"{x:579,y:495,t:1528140026488};\\\", \\\"{x:581,y:495,t:1528140026505};\\\", \\\"{x:584,y:496,t:1528140026521};\\\", \\\"{x:588,y:498,t:1528140026539};\\\", \\\"{x:589,y:499,t:1528140026554};\\\", \\\"{x:591,y:499,t:1528140026571};\\\", \\\"{x:594,y:501,t:1528140026588};\\\", \\\"{x:596,y:501,t:1528140026605};\\\", \\\"{x:602,y:501,t:1528140026622};\\\", \\\"{x:608,y:501,t:1528140026638};\\\", \\\"{x:609,y:501,t:1528140026966};\\\", \\\"{x:611,y:501,t:1528140026974};\\\", \\\"{x:617,y:501,t:1528140026989};\\\", \\\"{x:636,y:499,t:1528140027006};\\\", \\\"{x:656,y:496,t:1528140027022};\\\", \\\"{x:692,y:495,t:1528140027038};\\\", \\\"{x:715,y:495,t:1528140027055};\\\", \\\"{x:732,y:495,t:1528140027073};\\\", \\\"{x:744,y:495,t:1528140027089};\\\", \\\"{x:762,y:495,t:1528140027105};\\\", \\\"{x:777,y:495,t:1528140027122};\\\", \\\"{x:790,y:495,t:1528140027139};\\\", \\\"{x:798,y:495,t:1528140027155};\\\", \\\"{x:808,y:495,t:1528140027172};\\\", \\\"{x:817,y:492,t:1528140027190};\\\", \\\"{x:818,y:491,t:1528140027206};\\\", \\\"{x:819,y:491,t:1528140027222};\\\", \\\"{x:820,y:491,t:1528140027239};\\\", \\\"{x:822,y:491,t:1528140027271};\\\", \\\"{x:823,y:492,t:1528140027367};\\\", \\\"{x:825,y:493,t:1528140027375};\\\", \\\"{x:827,y:495,t:1528140027391};\\\", \\\"{x:829,y:495,t:1528140027406};\\\", \\\"{x:830,y:496,t:1528140027422};\\\", \\\"{x:832,y:497,t:1528140027439};\\\", \\\"{x:833,y:497,t:1528140027462};\\\", \\\"{x:832,y:498,t:1528140027639};\\\", \\\"{x:821,y:504,t:1528140027647};\\\", \\\"{x:811,y:511,t:1528140027656};\\\", \\\"{x:789,y:526,t:1528140027673};\\\", \\\"{x:776,y:543,t:1528140027689};\\\", \\\"{x:762,y:566,t:1528140027706};\\\", \\\"{x:754,y:582,t:1528140027722};\\\", \\\"{x:743,y:605,t:1528140027740};\\\", \\\"{x:733,y:629,t:1528140027756};\\\", \\\"{x:723,y:645,t:1528140027773};\\\", \\\"{x:715,y:659,t:1528140027789};\\\", \\\"{x:706,y:669,t:1528140027806};\\\", \\\"{x:695,y:680,t:1528140027822};\\\", \\\"{x:687,y:693,t:1528140027839};\\\", \\\"{x:680,y:703,t:1528140027856};\\\", \\\"{x:675,y:714,t:1528140027872};\\\", \\\"{x:666,y:729,t:1528140027889};\\\", \\\"{x:655,y:742,t:1528140027906};\\\", \\\"{x:644,y:753,t:1528140027922};\\\", \\\"{x:634,y:760,t:1528140027939};\\\", \\\"{x:626,y:764,t:1528140027957};\\\", \\\"{x:620,y:765,t:1528140027974};\\\", \\\"{x:616,y:765,t:1528140027990};\\\", \\\"{x:615,y:765,t:1528140028006};\\\", \\\"{x:610,y:765,t:1528140028023};\\\", \\\"{x:604,y:765,t:1528140028039};\\\", \\\"{x:595,y:765,t:1528140028056};\\\", \\\"{x:583,y:764,t:1528140028073};\\\", \\\"{x:575,y:764,t:1528140028089};\\\", \\\"{x:566,y:763,t:1528140028106};\\\", \\\"{x:560,y:761,t:1528140028123};\\\", \\\"{x:554,y:759,t:1528140028139};\\\", \\\"{x:546,y:754,t:1528140028156};\\\", \\\"{x:531,y:744,t:1528140028173};\\\", \\\"{x:510,y:722,t:1528140028189};\\\", \\\"{x:488,y:699,t:1528140028207};\\\", \\\"{x:486,y:694,t:1528140028222};\\\", \\\"{x:486,y:693,t:1528140028240};\\\", \\\"{x:488,y:697,t:1528140028503};\\\", \\\"{x:496,y:712,t:1528140028511};\\\", \\\"{x:500,y:720,t:1528140028524};\\\", \\\"{x:504,y:729,t:1528140028541};\\\", \\\"{x:506,y:733,t:1528140028556};\\\", \\\"{x:508,y:735,t:1528140028573};\\\", \\\"{x:509,y:736,t:1528140028607};\\\", \\\"{x:511,y:735,t:1528140029592};\\\", \\\"{x:516,y:730,t:1528140029607};\\\", \\\"{x:517,y:729,t:1528140029625};\\\", \\\"{x:521,y:727,t:1528140029641};\\\", \\\"{x:523,y:725,t:1528140029658};\\\" ] }, { \\\"rt\\\": 7112, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 704441, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:724,t:1528140031120};\\\", \\\"{x:524,y:724,t:1528140031246};\\\", \\\"{x:524,y:723,t:1528140031319};\\\", \\\"{x:525,y:722,t:1528140031608};\\\", \\\"{x:526,y:722,t:1528140031631};\\\", \\\"{x:527,y:722,t:1528140031646};\\\", \\\"{x:528,y:722,t:1528140032151};\\\", \\\"{x:530,y:721,t:1528140032175};\\\", \\\"{x:533,y:720,t:1528140032183};\\\", \\\"{x:536,y:718,t:1528140032199};\\\", \\\"{x:543,y:716,t:1528140032213};\\\", \\\"{x:555,y:711,t:1528140032230};\\\", \\\"{x:570,y:711,t:1528140032247};\\\", \\\"{x:578,y:711,t:1528140032259};\\\", \\\"{x:600,y:711,t:1528140032276};\\\", \\\"{x:623,y:711,t:1528140032294};\\\", \\\"{x:649,y:711,t:1528140032309};\\\", \\\"{x:687,y:711,t:1528140032326};\\\", \\\"{x:711,y:711,t:1528140032342};\\\", \\\"{x:736,y:711,t:1528140032359};\\\", \\\"{x:759,y:711,t:1528140032376};\\\", \\\"{x:783,y:711,t:1528140032393};\\\", \\\"{x:808,y:711,t:1528140032409};\\\", \\\"{x:829,y:712,t:1528140032426};\\\", \\\"{x:855,y:715,t:1528140032443};\\\", \\\"{x:887,y:720,t:1528140032459};\\\", \\\"{x:918,y:726,t:1528140032477};\\\", \\\"{x:959,y:734,t:1528140032494};\\\", \\\"{x:1004,y:742,t:1528140032510};\\\", \\\"{x:1081,y:761,t:1528140032527};\\\", \\\"{x:1123,y:772,t:1528140032543};\\\", \\\"{x:1156,y:778,t:1528140032560};\\\", \\\"{x:1187,y:788,t:1528140032577};\\\", \\\"{x:1219,y:794,t:1528140032593};\\\", \\\"{x:1248,y:799,t:1528140032610};\\\", \\\"{x:1286,y:807,t:1528140032627};\\\", \\\"{x:1317,y:815,t:1528140032644};\\\", \\\"{x:1343,y:821,t:1528140032660};\\\", \\\"{x:1389,y:833,t:1528140032677};\\\", \\\"{x:1441,y:847,t:1528140032694};\\\", \\\"{x:1494,y:862,t:1528140032710};\\\", \\\"{x:1549,y:876,t:1528140032727};\\\", \\\"{x:1617,y:896,t:1528140032744};\\\", \\\"{x:1652,y:905,t:1528140032761};\\\", \\\"{x:1675,y:912,t:1528140032778};\\\", \\\"{x:1688,y:916,t:1528140032794};\\\", \\\"{x:1691,y:917,t:1528140032811};\\\", \\\"{x:1692,y:917,t:1528140032827};\\\", \\\"{x:1693,y:918,t:1528140032844};\\\", \\\"{x:1694,y:918,t:1528140032887};\\\", \\\"{x:1696,y:920,t:1528140032896};\\\", \\\"{x:1707,y:928,t:1528140032911};\\\", \\\"{x:1716,y:936,t:1528140032927};\\\", \\\"{x:1719,y:938,t:1528140032943};\\\", \\\"{x:1720,y:939,t:1528140032961};\\\", \\\"{x:1720,y:941,t:1528140033040};\\\", \\\"{x:1719,y:942,t:1528140033046};\\\", \\\"{x:1717,y:943,t:1528140033061};\\\", \\\"{x:1711,y:946,t:1528140033076};\\\", \\\"{x:1705,y:949,t:1528140033094};\\\", \\\"{x:1697,y:952,t:1528140033110};\\\", \\\"{x:1693,y:952,t:1528140033126};\\\", \\\"{x:1689,y:953,t:1528140033144};\\\", \\\"{x:1686,y:953,t:1528140033160};\\\", \\\"{x:1682,y:953,t:1528140033177};\\\", \\\"{x:1673,y:953,t:1528140033193};\\\", \\\"{x:1660,y:953,t:1528140033211};\\\", \\\"{x:1643,y:953,t:1528140033227};\\\", \\\"{x:1630,y:953,t:1528140033243};\\\", \\\"{x:1620,y:953,t:1528140033261};\\\", \\\"{x:1611,y:953,t:1528140033278};\\\", \\\"{x:1605,y:953,t:1528140033294};\\\", \\\"{x:1602,y:953,t:1528140033311};\\\", \\\"{x:1601,y:953,t:1528140033343};\\\", \\\"{x:1601,y:954,t:1528140033361};\\\", \\\"{x:1600,y:954,t:1528140033378};\\\", \\\"{x:1598,y:954,t:1528140033394};\\\", \\\"{x:1595,y:954,t:1528140033410};\\\", \\\"{x:1592,y:954,t:1528140033428};\\\", \\\"{x:1589,y:954,t:1528140033444};\\\", \\\"{x:1587,y:955,t:1528140033461};\\\", \\\"{x:1585,y:955,t:1528140033478};\\\", \\\"{x:1582,y:956,t:1528140033494};\\\", \\\"{x:1578,y:957,t:1528140033511};\\\", \\\"{x:1570,y:958,t:1528140033527};\\\", \\\"{x:1567,y:958,t:1528140033544};\\\", \\\"{x:1563,y:958,t:1528140033561};\\\", \\\"{x:1562,y:958,t:1528140033578};\\\", \\\"{x:1560,y:958,t:1528140033594};\\\", \\\"{x:1559,y:958,t:1528140033611};\\\", \\\"{x:1558,y:958,t:1528140033631};\\\", \\\"{x:1557,y:958,t:1528140033647};\\\", \\\"{x:1556,y:958,t:1528140033663};\\\", \\\"{x:1554,y:958,t:1528140033880};\\\", \\\"{x:1553,y:958,t:1528140033895};\\\", \\\"{x:1552,y:958,t:1528140033911};\\\", \\\"{x:1551,y:958,t:1528140033944};\\\", \\\"{x:1550,y:958,t:1528140034144};\\\", \\\"{x:1544,y:956,t:1528140034161};\\\", \\\"{x:1535,y:949,t:1528140034178};\\\", \\\"{x:1523,y:940,t:1528140034195};\\\", \\\"{x:1512,y:932,t:1528140034212};\\\", \\\"{x:1503,y:926,t:1528140034228};\\\", \\\"{x:1494,y:917,t:1528140034245};\\\", \\\"{x:1490,y:913,t:1528140034261};\\\", \\\"{x:1488,y:911,t:1528140034278};\\\", \\\"{x:1486,y:908,t:1528140034296};\\\", \\\"{x:1482,y:902,t:1528140034311};\\\", \\\"{x:1481,y:895,t:1528140034329};\\\", \\\"{x:1476,y:885,t:1528140034345};\\\", \\\"{x:1467,y:870,t:1528140034362};\\\", \\\"{x:1462,y:858,t:1528140034378};\\\", \\\"{x:1455,y:846,t:1528140034395};\\\", \\\"{x:1447,y:831,t:1528140034412};\\\", \\\"{x:1441,y:821,t:1528140034428};\\\", \\\"{x:1438,y:816,t:1528140034445};\\\", \\\"{x:1437,y:814,t:1528140034462};\\\", \\\"{x:1437,y:812,t:1528140034478};\\\", \\\"{x:1437,y:808,t:1528140034495};\\\", \\\"{x:1437,y:807,t:1528140034512};\\\", \\\"{x:1437,y:804,t:1528140034528};\\\", \\\"{x:1437,y:802,t:1528140034545};\\\", \\\"{x:1437,y:799,t:1528140034562};\\\", \\\"{x:1437,y:798,t:1528140034579};\\\", \\\"{x:1437,y:796,t:1528140034595};\\\", \\\"{x:1439,y:796,t:1528140034647};\\\", \\\"{x:1442,y:796,t:1528140034662};\\\", \\\"{x:1464,y:806,t:1528140034679};\\\", \\\"{x:1475,y:811,t:1528140034695};\\\", \\\"{x:1484,y:825,t:1528140034714};\\\", \\\"{x:1493,y:838,t:1528140034729};\\\", \\\"{x:1495,y:845,t:1528140034744};\\\", \\\"{x:1496,y:847,t:1528140034761};\\\", \\\"{x:1496,y:850,t:1528140034806};\\\", \\\"{x:1497,y:851,t:1528140034814};\\\", \\\"{x:1497,y:855,t:1528140034829};\\\", \\\"{x:1499,y:859,t:1528140034844};\\\", \\\"{x:1500,y:860,t:1528140034862};\\\", \\\"{x:1500,y:859,t:1528140035055};\\\", \\\"{x:1500,y:848,t:1528140035063};\\\", \\\"{x:1488,y:824,t:1528140035079};\\\", \\\"{x:1471,y:803,t:1528140035095};\\\", \\\"{x:1456,y:786,t:1528140035112};\\\", \\\"{x:1442,y:770,t:1528140035129};\\\", \\\"{x:1429,y:753,t:1528140035146};\\\", \\\"{x:1413,y:737,t:1528140035162};\\\", \\\"{x:1398,y:723,t:1528140035179};\\\", \\\"{x:1388,y:712,t:1528140035195};\\\", \\\"{x:1382,y:704,t:1528140035212};\\\", \\\"{x:1367,y:692,t:1528140035228};\\\", \\\"{x:1349,y:680,t:1528140035247};\\\", \\\"{x:1323,y:668,t:1528140035263};\\\", \\\"{x:1268,y:654,t:1528140035279};\\\", \\\"{x:1205,y:640,t:1528140035295};\\\", \\\"{x:1141,y:630,t:1528140035312};\\\", \\\"{x:1086,y:624,t:1528140035329};\\\", \\\"{x:1005,y:611,t:1528140035346};\\\", \\\"{x:943,y:603,t:1528140035363};\\\", \\\"{x:865,y:592,t:1528140035380};\\\", \\\"{x:798,y:581,t:1528140035396};\\\", \\\"{x:743,y:575,t:1528140035411};\\\", \\\"{x:700,y:572,t:1528140035429};\\\", \\\"{x:666,y:570,t:1528140035445};\\\", \\\"{x:636,y:570,t:1528140035462};\\\", \\\"{x:620,y:570,t:1528140035480};\\\", \\\"{x:610,y:570,t:1528140035495};\\\", \\\"{x:605,y:570,t:1528140035512};\\\", \\\"{x:603,y:570,t:1528140035529};\\\", \\\"{x:601,y:570,t:1528140035546};\\\", \\\"{x:600,y:570,t:1528140035562};\\\", \\\"{x:598,y:570,t:1528140035615};\\\", \\\"{x:597,y:570,t:1528140035629};\\\", \\\"{x:595,y:571,t:1528140035645};\\\", \\\"{x:593,y:572,t:1528140035662};\\\", \\\"{x:593,y:573,t:1528140035735};\\\", \\\"{x:594,y:573,t:1528140035746};\\\", \\\"{x:597,y:573,t:1528140035763};\\\", \\\"{x:598,y:573,t:1528140035779};\\\", \\\"{x:603,y:573,t:1528140035797};\\\", \\\"{x:608,y:573,t:1528140035813};\\\", \\\"{x:611,y:573,t:1528140035829};\\\", \\\"{x:608,y:577,t:1528140036143};\\\", \\\"{x:603,y:587,t:1528140036150};\\\", \\\"{x:599,y:597,t:1528140036162};\\\", \\\"{x:589,y:614,t:1528140036180};\\\", \\\"{x:580,y:632,t:1528140036197};\\\", \\\"{x:574,y:647,t:1528140036212};\\\", \\\"{x:571,y:657,t:1528140036229};\\\", \\\"{x:570,y:661,t:1528140036245};\\\", \\\"{x:568,y:667,t:1528140036262};\\\", \\\"{x:566,y:671,t:1528140036279};\\\", \\\"{x:565,y:676,t:1528140036297};\\\", \\\"{x:565,y:681,t:1528140036313};\\\", \\\"{x:562,y:686,t:1528140036330};\\\", \\\"{x:562,y:688,t:1528140036347};\\\", \\\"{x:562,y:690,t:1528140036363};\\\", \\\"{x:559,y:695,t:1528140036380};\\\", \\\"{x:559,y:699,t:1528140036397};\\\", \\\"{x:557,y:707,t:1528140036413};\\\", \\\"{x:555,y:713,t:1528140036429};\\\", \\\"{x:550,y:727,t:1528140036448};\\\", \\\"{x:549,y:732,t:1528140036462};\\\", \\\"{x:548,y:737,t:1528140036479};\\\", \\\"{x:547,y:738,t:1528140036496};\\\", \\\"{x:546,y:740,t:1528140036513};\\\", \\\"{x:546,y:742,t:1528140036529};\\\", \\\"{x:545,y:745,t:1528140036547};\\\", \\\"{x:543,y:748,t:1528140036564};\\\", \\\"{x:542,y:750,t:1528140036579};\\\", \\\"{x:540,y:752,t:1528140036597};\\\", \\\"{x:539,y:754,t:1528140036613};\\\", \\\"{x:537,y:754,t:1528140036791};\\\", \\\"{x:536,y:754,t:1528140036799};\\\", \\\"{x:534,y:754,t:1528140036814};\\\", \\\"{x:532,y:753,t:1528140036830};\\\", \\\"{x:529,y:752,t:1528140036847};\\\", \\\"{x:529,y:751,t:1528140036864};\\\", \\\"{x:527,y:751,t:1528140036879};\\\", \\\"{x:526,y:751,t:1528140036897};\\\", \\\"{x:526,y:750,t:1528140036914};\\\", \\\"{x:524,y:750,t:1528140036935};\\\", \\\"{x:523,y:749,t:1528140036947};\\\", \\\"{x:523,y:748,t:1528140036963};\\\", \\\"{x:523,y:742,t:1528140036980};\\\", \\\"{x:523,y:741,t:1528140036997};\\\", \\\"{x:523,y:738,t:1528140037014};\\\", \\\"{x:524,y:735,t:1528140037031};\\\", \\\"{x:524,y:734,t:1528140037751};\\\" ] }, { \\\"rt\\\": 13585, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 719305, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:731,t:1528140038928};\\\", \\\"{x:545,y:723,t:1528140038949};\\\", \\\"{x:559,y:718,t:1528140038965};\\\", \\\"{x:575,y:712,t:1528140038981};\\\", \\\"{x:594,y:706,t:1528140038998};\\\", \\\"{x:648,y:686,t:1528140039092};\\\", \\\"{x:649,y:685,t:1528140039099};\\\", \\\"{x:651,y:684,t:1528140039114};\\\", \\\"{x:658,y:682,t:1528140042136};\\\", \\\"{x:681,y:683,t:1528140042151};\\\", \\\"{x:705,y:688,t:1528140042168};\\\", \\\"{x:732,y:693,t:1528140042184};\\\", \\\"{x:757,y:697,t:1528140042201};\\\", \\\"{x:779,y:703,t:1528140042219};\\\", \\\"{x:800,y:711,t:1528140042234};\\\", \\\"{x:830,y:723,t:1528140042251};\\\", \\\"{x:863,y:738,t:1528140042268};\\\", \\\"{x:908,y:758,t:1528140042285};\\\", \\\"{x:963,y:781,t:1528140042301};\\\", \\\"{x:1025,y:803,t:1528140042318};\\\", \\\"{x:1079,y:821,t:1528140042334};\\\", \\\"{x:1145,y:838,t:1528140042350};\\\", \\\"{x:1175,y:844,t:1528140042367};\\\", \\\"{x:1200,y:850,t:1528140042383};\\\", \\\"{x:1230,y:859,t:1528140042400};\\\", \\\"{x:1269,y:872,t:1528140042418};\\\", \\\"{x:1318,y:889,t:1528140042434};\\\", \\\"{x:1383,y:914,t:1528140042451};\\\", \\\"{x:1444,y:940,t:1528140042468};\\\", \\\"{x:1497,y:963,t:1528140042485};\\\", \\\"{x:1538,y:980,t:1528140042500};\\\", \\\"{x:1562,y:992,t:1528140042518};\\\", \\\"{x:1570,y:996,t:1528140042534};\\\", \\\"{x:1571,y:997,t:1528140042655};\\\", \\\"{x:1570,y:998,t:1528140042704};\\\", \\\"{x:1569,y:999,t:1528140042718};\\\", \\\"{x:1568,y:999,t:1528140042743};\\\", \\\"{x:1565,y:999,t:1528140042855};\\\", \\\"{x:1561,y:999,t:1528140042868};\\\", \\\"{x:1553,y:999,t:1528140042885};\\\", \\\"{x:1548,y:998,t:1528140042901};\\\", \\\"{x:1546,y:998,t:1528140042919};\\\", \\\"{x:1546,y:997,t:1528140042976};\\\", \\\"{x:1545,y:996,t:1528140042999};\\\", \\\"{x:1543,y:996,t:1528140043031};\\\", \\\"{x:1541,y:995,t:1528140043039};\\\", \\\"{x:1537,y:993,t:1528140043052};\\\", \\\"{x:1527,y:990,t:1528140043068};\\\", \\\"{x:1516,y:986,t:1528140043085};\\\", \\\"{x:1502,y:980,t:1528140043102};\\\", \\\"{x:1488,y:974,t:1528140043118};\\\", \\\"{x:1465,y:960,t:1528140043134};\\\", \\\"{x:1456,y:955,t:1528140043152};\\\", \\\"{x:1450,y:951,t:1528140043168};\\\", \\\"{x:1450,y:950,t:1528140043368};\\\", \\\"{x:1455,y:947,t:1528140043385};\\\", \\\"{x:1461,y:947,t:1528140043402};\\\", \\\"{x:1464,y:947,t:1528140043419};\\\", \\\"{x:1468,y:947,t:1528140043435};\\\", \\\"{x:1470,y:947,t:1528140043452};\\\", \\\"{x:1471,y:947,t:1528140043470};\\\", \\\"{x:1473,y:947,t:1528140043560};\\\", \\\"{x:1474,y:946,t:1528140043639};\\\", \\\"{x:1476,y:946,t:1528140043652};\\\", \\\"{x:1478,y:946,t:1528140043669};\\\", \\\"{x:1480,y:946,t:1528140043685};\\\", \\\"{x:1481,y:946,t:1528140043703};\\\", \\\"{x:1481,y:945,t:1528140043735};\\\", \\\"{x:1483,y:948,t:1528140043831};\\\", \\\"{x:1483,y:951,t:1528140043840};\\\", \\\"{x:1483,y:952,t:1528140043853};\\\", \\\"{x:1483,y:956,t:1528140043869};\\\", \\\"{x:1483,y:958,t:1528140043888};\\\", \\\"{x:1483,y:959,t:1528140043927};\\\", \\\"{x:1483,y:960,t:1528140043983};\\\", \\\"{x:1483,y:961,t:1528140043992};\\\", \\\"{x:1482,y:962,t:1528140044007};\\\", \\\"{x:1481,y:966,t:1528140044020};\\\", \\\"{x:1480,y:968,t:1528140044036};\\\", \\\"{x:1479,y:972,t:1528140044052};\\\", \\\"{x:1479,y:973,t:1528140044069};\\\", \\\"{x:1479,y:974,t:1528140044087};\\\", \\\"{x:1479,y:969,t:1528140044271};\\\", \\\"{x:1479,y:967,t:1528140044287};\\\", \\\"{x:1479,y:961,t:1528140044302};\\\", \\\"{x:1479,y:953,t:1528140044319};\\\", \\\"{x:1481,y:949,t:1528140044336};\\\", \\\"{x:1481,y:947,t:1528140044353};\\\", \\\"{x:1481,y:945,t:1528140044370};\\\", \\\"{x:1481,y:942,t:1528140044387};\\\", \\\"{x:1482,y:938,t:1528140044403};\\\", \\\"{x:1482,y:933,t:1528140044419};\\\", \\\"{x:1484,y:927,t:1528140044437};\\\", \\\"{x:1485,y:920,t:1528140044453};\\\", \\\"{x:1485,y:916,t:1528140044469};\\\", \\\"{x:1485,y:909,t:1528140044487};\\\", \\\"{x:1485,y:903,t:1528140044503};\\\", \\\"{x:1485,y:896,t:1528140044520};\\\", \\\"{x:1485,y:892,t:1528140044536};\\\", \\\"{x:1485,y:889,t:1528140044553};\\\", \\\"{x:1485,y:883,t:1528140044569};\\\", \\\"{x:1485,y:878,t:1528140044586};\\\", \\\"{x:1485,y:872,t:1528140044603};\\\", \\\"{x:1485,y:867,t:1528140044619};\\\", \\\"{x:1485,y:862,t:1528140044636};\\\", \\\"{x:1485,y:857,t:1528140044654};\\\", \\\"{x:1485,y:856,t:1528140044670};\\\", \\\"{x:1485,y:855,t:1528140044686};\\\", \\\"{x:1485,y:851,t:1528140044703};\\\", \\\"{x:1485,y:849,t:1528140044719};\\\", \\\"{x:1485,y:847,t:1528140044737};\\\", \\\"{x:1485,y:845,t:1528140044753};\\\", \\\"{x:1485,y:843,t:1528140044770};\\\", \\\"{x:1485,y:841,t:1528140044786};\\\", \\\"{x:1485,y:838,t:1528140044803};\\\", \\\"{x:1485,y:837,t:1528140044819};\\\", \\\"{x:1485,y:834,t:1528140044839};\\\", \\\"{x:1484,y:834,t:1528140044852};\\\", \\\"{x:1484,y:833,t:1528140044868};\\\", \\\"{x:1484,y:832,t:1528140044886};\\\", \\\"{x:1484,y:830,t:1528140044902};\\\", \\\"{x:1484,y:829,t:1528140044942};\\\", \\\"{x:1484,y:828,t:1528140044953};\\\", \\\"{x:1484,y:827,t:1528140044974};\\\", \\\"{x:1484,y:825,t:1528140044986};\\\", \\\"{x:1484,y:824,t:1528140045004};\\\", \\\"{x:1484,y:821,t:1528140045020};\\\", \\\"{x:1484,y:820,t:1528140045036};\\\", \\\"{x:1484,y:818,t:1528140045053};\\\", \\\"{x:1484,y:816,t:1528140045070};\\\", \\\"{x:1484,y:815,t:1528140045086};\\\", \\\"{x:1484,y:813,t:1528140045103};\\\", \\\"{x:1484,y:812,t:1528140045120};\\\", \\\"{x:1484,y:810,t:1528140045137};\\\", \\\"{x:1484,y:807,t:1528140045153};\\\", \\\"{x:1484,y:806,t:1528140045170};\\\", \\\"{x:1484,y:804,t:1528140045186};\\\", \\\"{x:1484,y:802,t:1528140045203};\\\", \\\"{x:1484,y:800,t:1528140045220};\\\", \\\"{x:1484,y:797,t:1528140045236};\\\", \\\"{x:1484,y:796,t:1528140045254};\\\", \\\"{x:1484,y:793,t:1528140045269};\\\", \\\"{x:1484,y:791,t:1528140045286};\\\", \\\"{x:1484,y:788,t:1528140045303};\\\", \\\"{x:1484,y:785,t:1528140045319};\\\", \\\"{x:1484,y:783,t:1528140045336};\\\", \\\"{x:1484,y:780,t:1528140045353};\\\", \\\"{x:1484,y:777,t:1528140045370};\\\", \\\"{x:1485,y:774,t:1528140045387};\\\", \\\"{x:1485,y:771,t:1528140045403};\\\", \\\"{x:1485,y:767,t:1528140045420};\\\", \\\"{x:1486,y:763,t:1528140045437};\\\", \\\"{x:1486,y:761,t:1528140045453};\\\", \\\"{x:1487,y:757,t:1528140045470};\\\", \\\"{x:1488,y:754,t:1528140045487};\\\", \\\"{x:1488,y:750,t:1528140045503};\\\", \\\"{x:1489,y:745,t:1528140045520};\\\", \\\"{x:1490,y:738,t:1528140045537};\\\", \\\"{x:1492,y:729,t:1528140045553};\\\", \\\"{x:1493,y:720,t:1528140045570};\\\", \\\"{x:1494,y:712,t:1528140045588};\\\", \\\"{x:1494,y:704,t:1528140045603};\\\", \\\"{x:1496,y:696,t:1528140045620};\\\", \\\"{x:1497,y:684,t:1528140045637};\\\", \\\"{x:1498,y:672,t:1528140045654};\\\", \\\"{x:1498,y:660,t:1528140045670};\\\", \\\"{x:1501,y:641,t:1528140045687};\\\", \\\"{x:1503,y:624,t:1528140045704};\\\", \\\"{x:1504,y:609,t:1528140045721};\\\", \\\"{x:1506,y:591,t:1528140045737};\\\", \\\"{x:1508,y:574,t:1528140045754};\\\", \\\"{x:1508,y:554,t:1528140045771};\\\", \\\"{x:1509,y:536,t:1528140045787};\\\", \\\"{x:1509,y:519,t:1528140045803};\\\", \\\"{x:1510,y:500,t:1528140045821};\\\", \\\"{x:1510,y:485,t:1528140045838};\\\", \\\"{x:1510,y:467,t:1528140045853};\\\", \\\"{x:1510,y:455,t:1528140045870};\\\", \\\"{x:1510,y:430,t:1528140045887};\\\", \\\"{x:1510,y:415,t:1528140045905};\\\", \\\"{x:1510,y:404,t:1528140045920};\\\", \\\"{x:1510,y:390,t:1528140045938};\\\", \\\"{x:1510,y:379,t:1528140045954};\\\", \\\"{x:1510,y:367,t:1528140045970};\\\", \\\"{x:1510,y:357,t:1528140045988};\\\", \\\"{x:1510,y:348,t:1528140046004};\\\", \\\"{x:1510,y:340,t:1528140046021};\\\", \\\"{x:1508,y:331,t:1528140046037};\\\", \\\"{x:1507,y:322,t:1528140046054};\\\", \\\"{x:1505,y:313,t:1528140046070};\\\", \\\"{x:1502,y:304,t:1528140046087};\\\", \\\"{x:1501,y:300,t:1528140046104};\\\", \\\"{x:1499,y:295,t:1528140046120};\\\", \\\"{x:1498,y:291,t:1528140046138};\\\", \\\"{x:1498,y:288,t:1528140046155};\\\", \\\"{x:1498,y:287,t:1528140046170};\\\", \\\"{x:1496,y:285,t:1528140046188};\\\", \\\"{x:1496,y:284,t:1528140046204};\\\", \\\"{x:1494,y:283,t:1528140046288};\\\", \\\"{x:1487,y:283,t:1528140046304};\\\", \\\"{x:1464,y:292,t:1528140046321};\\\", \\\"{x:1425,y:329,t:1528140046338};\\\", \\\"{x:1364,y:398,t:1528140046354};\\\", \\\"{x:1292,y:478,t:1528140046371};\\\", \\\"{x:1217,y:562,t:1528140046388};\\\", \\\"{x:1166,y:620,t:1528140046404};\\\", \\\"{x:1140,y:643,t:1528140046421};\\\", \\\"{x:1122,y:660,t:1528140046438};\\\", \\\"{x:1106,y:671,t:1528140046455};\\\", \\\"{x:1076,y:684,t:1528140046471};\\\", \\\"{x:1053,y:692,t:1528140046487};\\\", \\\"{x:1028,y:699,t:1528140046504};\\\", \\\"{x:991,y:711,t:1528140046521};\\\", \\\"{x:936,y:724,t:1528140046538};\\\", \\\"{x:870,y:733,t:1528140046554};\\\", \\\"{x:792,y:743,t:1528140046571};\\\", \\\"{x:741,y:745,t:1528140046587};\\\", \\\"{x:699,y:745,t:1528140046604};\\\", \\\"{x:674,y:745,t:1528140046621};\\\", \\\"{x:654,y:738,t:1528140046636};\\\", \\\"{x:625,y:719,t:1528140046654};\\\", \\\"{x:608,y:707,t:1528140046670};\\\", \\\"{x:594,y:696,t:1528140046687};\\\", \\\"{x:582,y:686,t:1528140046704};\\\", \\\"{x:571,y:676,t:1528140046720};\\\", \\\"{x:558,y:667,t:1528140046737};\\\", \\\"{x:545,y:660,t:1528140046754};\\\", \\\"{x:530,y:651,t:1528140046771};\\\", \\\"{x:520,y:641,t:1528140046788};\\\", \\\"{x:516,y:634,t:1528140046804};\\\", \\\"{x:516,y:629,t:1528140046821};\\\", \\\"{x:525,y:615,t:1528140046838};\\\", \\\"{x:534,y:604,t:1528140046855};\\\", \\\"{x:543,y:593,t:1528140046870};\\\", \\\"{x:554,y:584,t:1528140046888};\\\", \\\"{x:565,y:579,t:1528140046905};\\\", \\\"{x:572,y:574,t:1528140046921};\\\", \\\"{x:575,y:574,t:1528140046938};\\\", \\\"{x:575,y:573,t:1528140046955};\\\", \\\"{x:576,y:572,t:1528140046971};\\\", \\\"{x:577,y:572,t:1528140046999};\\\", \\\"{x:578,y:572,t:1528140047135};\\\", \\\"{x:582,y:573,t:1528140047143};\\\", \\\"{x:587,y:573,t:1528140047155};\\\", \\\"{x:589,y:574,t:1528140047172};\\\", \\\"{x:594,y:577,t:1528140047189};\\\", \\\"{x:605,y:583,t:1528140047206};\\\", \\\"{x:612,y:585,t:1528140047222};\\\", \\\"{x:615,y:586,t:1528140047238};\\\", \\\"{x:615,y:587,t:1528140047430};\\\", \\\"{x:612,y:589,t:1528140047622};\\\", \\\"{x:597,y:589,t:1528140047638};\\\", \\\"{x:578,y:587,t:1528140047655};\\\", \\\"{x:559,y:581,t:1528140047672};\\\", \\\"{x:543,y:577,t:1528140047688};\\\", \\\"{x:527,y:573,t:1528140047705};\\\", \\\"{x:514,y:569,t:1528140047722};\\\", \\\"{x:507,y:567,t:1528140047738};\\\", \\\"{x:493,y:565,t:1528140047755};\\\", \\\"{x:471,y:565,t:1528140047772};\\\", \\\"{x:439,y:565,t:1528140047789};\\\", \\\"{x:394,y:565,t:1528140047805};\\\", \\\"{x:337,y:565,t:1528140047822};\\\", \\\"{x:321,y:565,t:1528140047838};\\\", \\\"{x:316,y:565,t:1528140047855};\\\", \\\"{x:315,y:565,t:1528140047872};\\\", \\\"{x:313,y:565,t:1528140047919};\\\", \\\"{x:311,y:565,t:1528140047926};\\\", \\\"{x:308,y:565,t:1528140047938};\\\", \\\"{x:299,y:567,t:1528140047955};\\\", \\\"{x:289,y:572,t:1528140047973};\\\", \\\"{x:277,y:579,t:1528140047990};\\\", \\\"{x:261,y:588,t:1528140048007};\\\", \\\"{x:250,y:592,t:1528140048021};\\\", \\\"{x:245,y:596,t:1528140048038};\\\", \\\"{x:243,y:596,t:1528140048056};\\\", \\\"{x:243,y:597,t:1528140048072};\\\", \\\"{x:244,y:599,t:1528140048110};\\\", \\\"{x:248,y:601,t:1528140048122};\\\", \\\"{x:257,y:604,t:1528140048139};\\\", \\\"{x:276,y:604,t:1528140048157};\\\", \\\"{x:298,y:602,t:1528140048172};\\\", \\\"{x:326,y:598,t:1528140048188};\\\", \\\"{x:381,y:589,t:1528140048206};\\\", \\\"{x:395,y:585,t:1528140048223};\\\", \\\"{x:427,y:580,t:1528140048240};\\\", \\\"{x:440,y:578,t:1528140048256};\\\", \\\"{x:444,y:575,t:1528140048273};\\\", \\\"{x:445,y:575,t:1528140048351};\\\", \\\"{x:446,y:575,t:1528140048367};\\\", \\\"{x:447,y:574,t:1528140048375};\\\", \\\"{x:448,y:574,t:1528140048389};\\\", \\\"{x:449,y:574,t:1528140048406};\\\", \\\"{x:444,y:573,t:1528140048527};\\\", \\\"{x:437,y:572,t:1528140048540};\\\", \\\"{x:422,y:573,t:1528140048556};\\\", \\\"{x:405,y:573,t:1528140048573};\\\", \\\"{x:386,y:573,t:1528140048591};\\\", \\\"{x:384,y:573,t:1528140048607};\\\", \\\"{x:383,y:573,t:1528140048623};\\\", \\\"{x:384,y:574,t:1528140048647};\\\", \\\"{x:386,y:575,t:1528140048656};\\\", \\\"{x:397,y:575,t:1528140048674};\\\", \\\"{x:420,y:572,t:1528140048690};\\\", \\\"{x:450,y:567,t:1528140048707};\\\", \\\"{x:495,y:562,t:1528140048723};\\\", \\\"{x:556,y:562,t:1528140048740};\\\", \\\"{x:632,y:562,t:1528140048756};\\\", \\\"{x:716,y:564,t:1528140048773};\\\", \\\"{x:812,y:578,t:1528140048790};\\\", \\\"{x:866,y:589,t:1528140048806};\\\", \\\"{x:898,y:597,t:1528140048823};\\\", \\\"{x:913,y:597,t:1528140048840};\\\", \\\"{x:916,y:597,t:1528140048856};\\\", \\\"{x:917,y:597,t:1528140048966};\\\", \\\"{x:915,y:600,t:1528140048974};\\\", \\\"{x:911,y:601,t:1528140048989};\\\", \\\"{x:898,y:602,t:1528140049006};\\\", \\\"{x:871,y:602,t:1528140049023};\\\", \\\"{x:849,y:602,t:1528140049039};\\\", \\\"{x:826,y:602,t:1528140049057};\\\", \\\"{x:797,y:602,t:1528140049073};\\\", \\\"{x:770,y:602,t:1528140049090};\\\", \\\"{x:745,y:602,t:1528140049107};\\\", \\\"{x:723,y:606,t:1528140049124};\\\", \\\"{x:699,y:610,t:1528140049141};\\\", \\\"{x:680,y:616,t:1528140049158};\\\", \\\"{x:665,y:624,t:1528140049173};\\\", \\\"{x:650,y:633,t:1528140049190};\\\", \\\"{x:644,y:635,t:1528140049207};\\\", \\\"{x:642,y:636,t:1528140049224};\\\", \\\"{x:641,y:636,t:1528140049240};\\\", \\\"{x:639,y:636,t:1528140049257};\\\", \\\"{x:637,y:636,t:1528140049273};\\\", \\\"{x:631,y:636,t:1528140049290};\\\", \\\"{x:622,y:636,t:1528140049307};\\\", \\\"{x:606,y:636,t:1528140049324};\\\", \\\"{x:590,y:636,t:1528140049340};\\\", \\\"{x:566,y:636,t:1528140049357};\\\", \\\"{x:536,y:636,t:1528140049373};\\\", \\\"{x:491,y:636,t:1528140049392};\\\", \\\"{x:463,y:636,t:1528140049406};\\\", \\\"{x:440,y:636,t:1528140049423};\\\", \\\"{x:425,y:636,t:1528140049439};\\\", \\\"{x:419,y:635,t:1528140049457};\\\", \\\"{x:416,y:635,t:1528140049473};\\\", \\\"{x:415,y:635,t:1528140049503};\\\", \\\"{x:412,y:635,t:1528140049871};\\\", \\\"{x:409,y:627,t:1528140049878};\\\", \\\"{x:408,y:622,t:1528140049890};\\\", \\\"{x:406,y:616,t:1528140049908};\\\", \\\"{x:406,y:606,t:1528140049923};\\\", \\\"{x:405,y:599,t:1528140049940};\\\", \\\"{x:405,y:596,t:1528140049956};\\\", \\\"{x:404,y:595,t:1528140049973};\\\", \\\"{x:404,y:594,t:1528140049990};\\\", \\\"{x:404,y:593,t:1528140050022};\\\", \\\"{x:404,y:591,t:1528140050029};\\\", \\\"{x:403,y:589,t:1528140050040};\\\", \\\"{x:403,y:586,t:1528140050057};\\\", \\\"{x:403,y:583,t:1528140050074};\\\", \\\"{x:402,y:580,t:1528140050090};\\\", \\\"{x:402,y:579,t:1528140050107};\\\", \\\"{x:401,y:578,t:1528140050175};\\\", \\\"{x:401,y:577,t:1528140050519};\\\", \\\"{x:401,y:584,t:1528140050527};\\\", \\\"{x:406,y:597,t:1528140050541};\\\", \\\"{x:419,y:626,t:1528140050558};\\\", \\\"{x:446,y:677,t:1528140050576};\\\", \\\"{x:461,y:705,t:1528140050592};\\\", \\\"{x:472,y:718,t:1528140050608};\\\", \\\"{x:477,y:728,t:1528140050624};\\\", \\\"{x:477,y:729,t:1528140050642};\\\", \\\"{x:477,y:726,t:1528140050727};\\\", \\\"{x:474,y:715,t:1528140050741};\\\", \\\"{x:448,y:685,t:1528140050759};\\\", \\\"{x:425,y:665,t:1528140050776};\\\", \\\"{x:406,y:652,t:1528140050791};\\\", \\\"{x:391,y:640,t:1528140050809};\\\", \\\"{x:384,y:633,t:1528140050824};\\\", \\\"{x:381,y:627,t:1528140050841};\\\", \\\"{x:378,y:618,t:1528140050858};\\\", \\\"{x:378,y:609,t:1528140050874};\\\", \\\"{x:379,y:603,t:1528140050891};\\\", \\\"{x:380,y:598,t:1528140050908};\\\", \\\"{x:381,y:596,t:1528140050924};\\\", \\\"{x:382,y:595,t:1528140050941};\\\", \\\"{x:383,y:594,t:1528140050966};\\\", \\\"{x:384,y:593,t:1528140050974};\\\", \\\"{x:385,y:592,t:1528140050991};\\\", \\\"{x:388,y:592,t:1528140051008};\\\", \\\"{x:388,y:591,t:1528140051024};\\\", \\\"{x:390,y:591,t:1528140051326};\\\", \\\"{x:395,y:609,t:1528140051342};\\\", \\\"{x:423,y:666,t:1528140051359};\\\", \\\"{x:448,y:699,t:1528140051376};\\\", \\\"{x:467,y:719,t:1528140051392};\\\", \\\"{x:485,y:737,t:1528140051410};\\\", \\\"{x:495,y:748,t:1528140051425};\\\", \\\"{x:499,y:752,t:1528140051442};\\\", \\\"{x:501,y:755,t:1528140051458};\\\", \\\"{x:502,y:756,t:1528140051479};\\\", \\\"{x:503,y:758,t:1528140051492};\\\", \\\"{x:504,y:760,t:1528140051509};\\\", \\\"{x:507,y:763,t:1528140051526};\\\", \\\"{x:512,y:771,t:1528140051544};\\\", \\\"{x:514,y:774,t:1528140051558};\\\", \\\"{x:518,y:778,t:1528140051574};\\\", \\\"{x:520,y:780,t:1528140051591};\\\", \\\"{x:521,y:780,t:1528140051831};\\\", \\\"{x:521,y:779,t:1528140051842};\\\", \\\"{x:524,y:776,t:1528140051860};\\\", \\\"{x:526,y:771,t:1528140051876};\\\", \\\"{x:527,y:767,t:1528140051893};\\\", \\\"{x:530,y:763,t:1528140051909};\\\" ] }, { \\\"rt\\\": 65281, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 785843, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find 2 pm on the x-axis. Then from there follow the diagonal line that goes upright from that point. Any point that falls on that line starts at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10022, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 796872, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14560, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 812451, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 73300, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 887093, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"TZYD4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"TZYD4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 100, dom: 611, initialDom: 727",
  "javascriptErrors": []
}