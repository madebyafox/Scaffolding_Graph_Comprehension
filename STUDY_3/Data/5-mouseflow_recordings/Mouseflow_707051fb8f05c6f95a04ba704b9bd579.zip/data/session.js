var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "707051fb8f05c6f95a04ba704b9bd579",
  "created": "2018-05-14T14:12:17.3288056-07:00",
  "lastActivity": "2018-05-14T14:14:06.5748056-07:00",
  "pageViews": [
    {
      "id": "05141733e60e0143df5214bfe75fe786f2ed8d5d",
      "startTime": "2018-05-14T14:12:17.3288056-07:00",
      "endTime": "2018-05-14T14:14:06.5748056-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 109246,
      "engagementTime": 108645,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 109246,
  "engagementTime": 108645,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7KANO",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a83784f47d5f27440150b4d2f71141b5",
  "gdpr": false
}