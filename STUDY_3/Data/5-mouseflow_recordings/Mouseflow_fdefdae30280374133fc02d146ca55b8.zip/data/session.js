var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fdefdae30280374133fc02d146ca55b8",
  "created": "2018-05-21T12:14:16.9679107-07:00",
  "lastActivity": "2018-05-21T12:14:28.0116265-07:00",
  "pageViews": [
    {
      "id": "0521177829382e1f55c3a1378bf3d0cdbaa16d38",
      "startTime": "2018-05-21T12:14:17.4164749-07:00",
      "endTime": "2018-05-21T12:14:28.0116265-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10826,
      "engagementTime": 10776,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10826,
  "engagementTime": 10776,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Q8EDD",
    "CONDITION=111",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b74f51b1fa2a0b81f72cbe6e99a390c0",
  "gdpr": false
}