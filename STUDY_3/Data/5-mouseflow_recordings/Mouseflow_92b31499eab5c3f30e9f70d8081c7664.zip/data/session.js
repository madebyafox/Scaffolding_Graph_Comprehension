var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "92b31499eab5c3f30e9f70d8081c7664",
  "created": "2018-05-24T12:10:06.4675971-07:00",
  "lastActivity": "2018-05-24T12:11:42.5632406-07:00",
  "pageViews": [
    {
      "id": "05240652c792733dcb95b93d892eef2ef9ac9032",
      "startTime": "2018-05-24T12:10:06.4675971-07:00",
      "endTime": "2018-05-24T12:11:42.5632406-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 96133,
      "engagementTime": 37335,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 96133,
  "engagementTime": 37335,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=M3NXB",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ab4def99e2a38dd54807a453d7ebf810",
  "gdpr": false
}