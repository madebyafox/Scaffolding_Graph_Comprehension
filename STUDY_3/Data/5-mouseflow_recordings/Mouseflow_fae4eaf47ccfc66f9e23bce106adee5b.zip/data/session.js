var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fae4eaf47ccfc66f9e23bce106adee5b",
  "created": "2018-05-29T10:15:44.4726508-07:00",
  "lastActivity": "2018-05-29T10:15:52.8996508-07:00",
  "pageViews": [
    {
      "id": "05294404845f3b725f14a6ff60312906718fc918",
      "startTime": "2018-05-29T10:15:44.4726508-07:00",
      "endTime": "2018-05-29T10:15:52.8996508-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 8427,
      "engagementTime": 16854,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8427,
  "engagementTime": 16854,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J80QC",
    "CONDITION=114",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f2a5b5c4cec27195f356894bdb210ec0",
  "gdpr": false
}