var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05213183b378978095ebbf995cd40e385d140b83"] = {
  "startTime": "2018-05-21T16:19:31.0386389Z",
  "websitePageUrl": "/16",
  "visitTime": 74340,
  "engagementTime": 74189,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f6e38771e6e1af1f866f80b87cb925fa",
    "created": "2018-05-21T16:19:31.0386389+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=Z5Z7P",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "70ef5fa64af0ea81f6b7a59beff9f663",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f6e38771e6e1af1f866f80b87cb925fa/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 258,
      "e": 258,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 530,
      "y": 743
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 517,
      "y": 739
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 46414,
      "y": 37282,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3769,
      "e": 3769,
      "ty": 6,
      "x": 495,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 495,
      "y": 551
    },
    {
      "t": 3819,
      "e": 3819,
      "ty": 7,
      "x": 495,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 513,
      "y": 478
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 515,
      "y": 508
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 46976,
      "y": 31048,
      "ta": "#.strategy > p"
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 6,
      "x": 509,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 448,
      "y": 564
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 417,
      "y": 566
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 32925,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 348,
      "y": 558
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 330,
      "y": 558
    },
    {
      "t": 4440,
      "e": 4440,
      "ty": 3,
      "x": 330,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4442,
      "e": 4442,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 26180,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4527,
      "e": 4527,
      "ty": 4,
      "x": 26180,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4527,
      "e": 4527,
      "ty": 5,
      "x": 330,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8760,
      "e": 8760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 8992,
      "e": 8992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 8993,
      "e": 8993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9087,
      "e": 9087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9103,
      "e": 9103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9368,
      "e": 9368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9369,
      "e": 9369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9463,
      "e": 9463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LO"
    },
    {
      "t": 9592,
      "e": 9592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9592,
      "e": 9592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9656,
      "e": 9656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOO"
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10312,
      "e": 10312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10407,
      "e": 10407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LO"
    },
    {
      "t": 10729,
      "e": 10729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10807,
      "e": 10807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 11144,
      "e": 11144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11144,
      "e": 11144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11304,
      "e": 11304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LO"
    },
    {
      "t": 11743,
      "e": 11743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11744,
      "e": 11744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11807,
      "e": 11807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOO"
    },
    {
      "t": 11960,
      "e": 11960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 11960,
      "e": 11960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12071,
      "e": 12071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK"
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12201,
      "e": 12201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12287,
      "e": 12287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12399,
      "e": 12399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12399,
      "e": 12399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12479,
      "e": 12479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 12543,
      "e": 12543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12544,
      "e": 12544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12615,
      "e": 12615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 12663,
      "e": 12663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12665,
      "e": 12665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12759,
      "e": 12759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12823,
      "e": 12823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12823,
      "e": 12823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12871,
      "e": 12871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 12952,
      "e": 12952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12953,
      "e": 12953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13039,
      "e": 13039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13040,
      "e": 13040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13063,
      "e": 13063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||HE"
    },
    {
      "t": 13102,
      "e": 13102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13183,
      "e": 13183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13183,
      "e": 13183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13271,
      "e": 13271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13776,
      "e": 13776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13776,
      "e": 13776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13895,
      "e": 13895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 14183,
      "e": 14183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14184,
      "e": 14184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14288,
      "e": 14288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 14376,
      "e": 14376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14376,
      "e": 14376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14943,
      "e": 14943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE XI"
    },
    {
      "t": 15031,
      "e": 15031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15088,
      "e": 15088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X"
    },
    {
      "t": 15206,
      "e": 15206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X"
    },
    {
      "t": 16424,
      "e": 16424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 16424,
      "e": 16424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16495,
      "e": 16495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 16606,
      "e": 16606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-"
    },
    {
      "t": 16815,
      "e": 16815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16817,
      "e": 16817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16903,
      "e": 16903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 17006,
      "e": 17006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-A"
    },
    {
      "t": 17175,
      "e": 17175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17177,
      "e": 17177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17255,
      "e": 17255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 17311,
      "e": 17311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17311,
      "e": 17311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17383,
      "e": 17383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 17456,
      "e": 17456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17456,
      "e": 17456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17535,
      "e": 17535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 17591,
      "e": 17591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17591,
      "e": 17591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17671,
      "e": 17671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17767,
      "e": 17767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17769,
      "e": 17769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17815,
      "e": 17815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 18040,
      "e": 18040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18041,
      "e": 18041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18087,
      "e": 18087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 18206,
      "e": 18206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FR"
    },
    {
      "t": 18520,
      "e": 18520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18599,
      "e": 18599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS F"
    },
    {
      "t": 18856,
      "e": 18856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18857,
      "e": 18857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18943,
      "e": 18943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 19008,
      "e": 19008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19008,
      "e": 19008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19047,
      "e": 19047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 19127,
      "e": 19127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19127,
      "e": 19127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19207,
      "e": 19207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19328,
      "e": 19328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 19330,
      "e": 19330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19440,
      "e": 19440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 19440,
      "e": 19440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19503,
      "e": 19503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 19535,
      "e": 19535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19591,
      "e": 19591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19592,
      "e": 19592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19647,
      "e": 19647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19832,
      "e": 19832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19960,
      "e": 19960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19961,
      "e": 19961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20004,
      "e": 20004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20014,
      "e": 20014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20079,
      "e": 20079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20648,
      "e": 20648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20761,
      "e": 20761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 "
    },
    {
      "t": 20895,
      "e": 20895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21080,
      "e": 21080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21080,
      "e": 21080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21135,
      "e": 21135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 21296,
      "e": 21296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21297,
      "e": 21297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21351,
      "e": 21351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 21422,
      "e": 21422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21544,
      "e": 21544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21544,
      "e": 21544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21630,
      "e": 21630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21695,
      "e": 21695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21695,
      "e": 21695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21767,
      "e": 21767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 22048,
      "e": 22048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22103,
      "e": 22103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 pm "
    },
    {
      "t": 22199,
      "e": 22199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22255,
      "e": 22255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 pm"
    },
    {
      "t": 22335,
      "e": 22335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22399,
      "e": 22399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 p"
    },
    {
      "t": 22496,
      "e": 22496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22559,
      "e": 22559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 "
    },
    {
      "t": 22767,
      "e": 22767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 22807,
      "e": 22807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22808,
      "e": 22808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22895,
      "e": 22895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23007,
      "e": 23007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 p"
    },
    {
      "t": 23096,
      "e": 23096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23097,
      "e": 23097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23158,
      "e": 23158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 23496,
      "e": 23496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23647,
      "e": 23647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23647,
      "e": 23647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23734,
      "e": 23734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23807,
      "e": 23807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23807,
      "e": 23807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23887,
      "e": 23887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 23911,
      "e": 23911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23911,
      "e": 23911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24015,
      "e": 24015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 24095,
      "e": 24095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24096,
      "e": 24096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24159,
      "e": 24159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24159,
      "e": 24159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24167,
      "e": 24167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D "
    },
    {
      "t": 24231,
      "e": 24231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24368,
      "e": 24368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24369,
      "e": 24369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24430,
      "e": 24430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 24856,
      "e": 24856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24856,
      "e": 24856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24942,
      "e": 24942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 25111,
      "e": 25111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25112,
      "e": 25112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25190,
      "e": 25190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25895,
      "e": 25895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25897,
      "e": 25897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26006,
      "e": 26006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 pm AND GO U"
    },
    {
      "t": 26008,
      "e": 26008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||U"
    },
    {
      "t": 26176,
      "e": 26176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26176,
      "e": 26176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26238,
      "e": 26238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 26511,
      "e": 26511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26512,
      "e": 26512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26623,
      "e": 26623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27864,
      "e": 27864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27865,
      "e": 27865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27935,
      "e": 27935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 27992,
      "e": 27992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27992,
      "e": 27992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28103,
      "e": 28103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 28135,
      "e": 28135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28135,
      "e": 28135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28215,
      "e": 28215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 28232,
      "e": 28232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28232,
      "e": 28232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28319,
      "e": 28319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28391,
      "e": 28391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28391,
      "e": 28391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28455,
      "e": 28455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 28688,
      "e": 28688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28688,
      "e": 28688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28751,
      "e": 28751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 28879,
      "e": 28879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28880,
      "e": 28880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28984,
      "e": 28984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 29177,
      "e": 29177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 29177,
      "e": 29177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29238,
      "e": 29238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 29375,
      "e": 29375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29376,
      "e": 29376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29471,
      "e": 29471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 29904,
      "e": 29904,
      "ty": 2,
      "x": 296,
      "y": 550
    },
    {
      "t": 30004,
      "e": 30004,
      "ty": 2,
      "x": 445,
      "y": 581
    },
    {
      "t": 30004,
      "e": 30004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30005,
      "e": 30005,
      "ty": 41,
      "x": 39108,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30028,
      "e": 30028,
      "ty": 7,
      "x": 505,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30104,
      "e": 30104,
      "ty": 2,
      "x": 613,
      "y": 736
    },
    {
      "t": 30205,
      "e": 30205,
      "ty": 2,
      "x": 630,
      "y": 768
    },
    {
      "t": 30255,
      "e": 30255,
      "ty": 41,
      "x": 59566,
      "y": 42046,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 30304,
      "e": 30304,
      "ty": 2,
      "x": 488,
      "y": 706
    },
    {
      "t": 30313,
      "e": 30313,
      "ty": 6,
      "x": 425,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 30362,
      "e": 30362,
      "ty": 7,
      "x": 370,
      "y": 652,
      "ta": "#strategyButton"
    },
    {
      "t": 30404,
      "e": 30404,
      "ty": 2,
      "x": 370,
      "y": 652
    },
    {
      "t": 30504,
      "e": 30504,
      "ty": 2,
      "x": 372,
      "y": 652
    },
    {
      "t": 30505,
      "e": 30505,
      "ty": 41,
      "x": 24999,
      "y": 19834,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 30546,
      "e": 30546,
      "ty": 6,
      "x": 375,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 30604,
      "e": 30604,
      "ty": 2,
      "x": 384,
      "y": 660
    },
    {
      "t": 30704,
      "e": 30704,
      "ty": 2,
      "x": 389,
      "y": 673
    },
    {
      "t": 30754,
      "e": 30754,
      "ty": 41,
      "x": 27528,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 30828,
      "e": 30828,
      "ty": 3,
      "x": 389,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 30829,
      "e": 30829,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "LOOK AT THE X-AXIS FOR 12 pm AND GO UP THE GRAPH"
    },
    {
      "t": 30831,
      "e": 30831,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30831,
      "e": 30831,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30946,
      "e": 30946,
      "ty": 4,
      "x": 27528,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 30957,
      "e": 30957,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30959,
      "e": 30959,
      "ty": 5,
      "x": 389,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 30965,
      "e": 30965,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 31966,
      "e": 31966,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 33404,
      "e": 33404,
      "ty": 2,
      "x": 396,
      "y": 674
    },
    {
      "t": 33504,
      "e": 33504,
      "ty": 2,
      "x": 737,
      "y": 674
    },
    {
      "t": 33505,
      "e": 33505,
      "ty": 41,
      "x": 25105,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 33548,
      "e": 33548,
      "ty": 6,
      "x": 833,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33604,
      "e": 33604,
      "ty": 2,
      "x": 879,
      "y": 648
    },
    {
      "t": 33614,
      "e": 33614,
      "ty": 7,
      "x": 887,
      "y": 643,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33705,
      "e": 33705,
      "ty": 2,
      "x": 889,
      "y": 630
    },
    {
      "t": 33755,
      "e": 33755,
      "ty": 41,
      "x": 17951,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 33804,
      "e": 33804,
      "ty": 2,
      "x": 893,
      "y": 581
    },
    {
      "t": 33904,
      "e": 33904,
      "ty": 2,
      "x": 893,
      "y": 576
    },
    {
      "t": 34004,
      "e": 34004,
      "ty": 2,
      "x": 893,
      "y": 575
    },
    {
      "t": 34005,
      "e": 34005,
      "ty": 41,
      "x": 18384,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 34076,
      "e": 34076,
      "ty": 6,
      "x": 893,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34104,
      "e": 34104,
      "ty": 2,
      "x": 894,
      "y": 572
    },
    {
      "t": 34204,
      "e": 34204,
      "ty": 2,
      "x": 895,
      "y": 565
    },
    {
      "t": 34255,
      "e": 34255,
      "ty": 41,
      "x": 18816,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34275,
      "e": 34275,
      "ty": 3,
      "x": 895,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34275,
      "e": 34275,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34395,
      "e": 34395,
      "ty": 4,
      "x": 18816,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34395,
      "e": 34395,
      "ty": 5,
      "x": 895,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35735,
      "e": 35735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 35739,
      "e": 35739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35863,
      "e": 35863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "99"
    },
    {
      "t": 35863,
      "e": 35863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35878,
      "e": 35878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 35951,
      "e": 35951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 36371,
      "e": 36371,
      "ty": 7,
      "x": 968,
      "y": 545,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36405,
      "e": 36405,
      "ty": 2,
      "x": 1215,
      "y": 516
    },
    {
      "t": 36505,
      "e": 36505,
      "ty": 2,
      "x": 1153,
      "y": 591
    },
    {
      "t": 36505,
      "e": 36505,
      "ty": 41,
      "x": 39431,
      "y": 32296,
      "ta": "html > body"
    },
    {
      "t": 36604,
      "e": 36604,
      "ty": 2,
      "x": 1118,
      "y": 628
    },
    {
      "t": 36668,
      "e": 36668,
      "ty": 6,
      "x": 1061,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36704,
      "e": 36704,
      "ty": 2,
      "x": 1059,
      "y": 650
    },
    {
      "t": 36754,
      "e": 36754,
      "ty": 41,
      "x": 54071,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36805,
      "e": 36805,
      "ty": 2,
      "x": 1058,
      "y": 653
    },
    {
      "t": 37268,
      "e": 37268,
      "ty": 3,
      "x": 1058,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37269,
      "e": 37269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 37269,
      "e": 37269,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37270,
      "e": 37270,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37396,
      "e": 37396,
      "ty": 4,
      "x": 54071,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37396,
      "e": 37396,
      "ty": 5,
      "x": 1058,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37604,
      "e": 37604,
      "ty": 2,
      "x": 1051,
      "y": 651
    },
    {
      "t": 37705,
      "e": 37705,
      "ty": 2,
      "x": 1051,
      "y": 650
    },
    {
      "t": 37755,
      "e": 37755,
      "ty": 41,
      "x": 52557,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38151,
      "e": 38151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 38303,
      "e": 38303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 38304,
      "e": 38304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38405,
      "e": 38405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 38414,
      "e": 38414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 38471,
      "e": 38471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 38471,
      "e": 38471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38567,
      "e": 38567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 38759,
      "e": 38759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 39367,
      "e": 39367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 39431,
      "e": 39431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 39503,
      "e": 39503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 39575,
      "e": 39575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 39719,
      "e": 39719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39824,
      "e": 39824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 39824,
      "e": 39824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39926,
      "e": 39926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 39935,
      "e": 39935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 39935,
      "e": 39935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40005,
      "e": 40005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40022,
      "e": 40022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 40199,
      "e": 40199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 40200,
      "e": 40200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40295,
      "e": 40295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 40415,
      "e": 40415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 40905,
      "e": 40905,
      "ty": 2,
      "x": 1030,
      "y": 647
    },
    {
      "t": 40920,
      "e": 40920,
      "ty": 7,
      "x": 1029,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40980,
      "e": 40980,
      "ty": 6,
      "x": 1029,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41003,
      "e": 41003,
      "ty": 7,
      "x": 1034,
      "y": 676,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41004,
      "e": 41004,
      "ty": 2,
      "x": 1034,
      "y": 676
    },
    {
      "t": 41004,
      "e": 41004,
      "ty": 41,
      "x": 35333,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 41105,
      "e": 41105,
      "ty": 2,
      "x": 1040,
      "y": 737
    },
    {
      "t": 41205,
      "e": 41205,
      "ty": 2,
      "x": 1038,
      "y": 747
    },
    {
      "t": 41254,
      "e": 41254,
      "ty": 6,
      "x": 1009,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41255,
      "e": 41255,
      "ty": 41,
      "x": 58279,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41305,
      "e": 41305,
      "ty": 2,
      "x": 977,
      "y": 683
    },
    {
      "t": 41338,
      "e": 41338,
      "ty": 7,
      "x": 970,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41405,
      "e": 41405,
      "ty": 2,
      "x": 970,
      "y": 675
    },
    {
      "t": 41505,
      "e": 41505,
      "ty": 41,
      "x": 35038,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41775,
      "e": 41775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 41846,
      "e": 41846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 41918,
      "e": 41918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 41983,
      "e": 41983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 42064,
      "e": 42064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42135,
      "e": 42135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42311,
      "e": 42311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 42311,
      "e": 42311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42415,
      "e": 42415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 42455,
      "e": 42455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 42456,
      "e": 42456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42591,
      "e": 42591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 42616,
      "e": 42616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 42616,
      "e": 42616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42622,
      "e": 42622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 42623,
      "e": 42623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42646,
      "e": 42646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USSA"
    },
    {
      "t": 42727,
      "e": 42727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 43084,
      "e": 43084,
      "ty": 6,
      "x": 970,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43104,
      "e": 43104,
      "ty": 2,
      "x": 970,
      "y": 681
    },
    {
      "t": 43139,
      "e": 43139,
      "ty": 7,
      "x": 976,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43205,
      "e": 43205,
      "ty": 2,
      "x": 976,
      "y": 728
    },
    {
      "t": 43255,
      "e": 43255,
      "ty": 41,
      "x": 33335,
      "y": 39886,
      "ta": "html > body"
    },
    {
      "t": 43373,
      "e": 43373,
      "ty": 6,
      "x": 976,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43404,
      "e": 43404,
      "ty": 2,
      "x": 976,
      "y": 696
    },
    {
      "t": 43505,
      "e": 43505,
      "ty": 2,
      "x": 971,
      "y": 679
    },
    {
      "t": 43505,
      "e": 43505,
      "ty": 41,
      "x": 38694,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43764,
      "e": 43764,
      "ty": 3,
      "x": 971,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43765,
      "e": 43765,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USSA"
    },
    {
      "t": 43765,
      "e": 43765,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43766,
      "e": 43766,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43851,
      "e": 43851,
      "ty": 4,
      "x": 38694,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43851,
      "e": 43851,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43852,
      "e": 43852,
      "ty": 5,
      "x": 971,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43852,
      "e": 43852,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 44878,
      "e": 44878,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 45903,
      "e": 45903,
      "ty": 2,
      "x": 1106,
      "y": 29
    },
    {
      "t": 46004,
      "e": 46004,
      "ty": 2,
      "x": 959,
      "y": 0
    },
    {
      "t": 46004,
      "e": 46004,
      "ty": 41,
      "x": 33025,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 46104,
      "e": 46104,
      "ty": 2,
      "x": 884,
      "y": 70
    },
    {
      "t": 46204,
      "e": 46204,
      "ty": 2,
      "x": 890,
      "y": 231
    },
    {
      "t": 46254,
      "e": 46254,
      "ty": 41,
      "x": 56975,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 46304,
      "e": 46304,
      "ty": 2,
      "x": 893,
      "y": 231
    },
    {
      "t": 46404,
      "e": 46404,
      "ty": 2,
      "x": 875,
      "y": 220
    },
    {
      "t": 46504,
      "e": 46504,
      "ty": 2,
      "x": 806,
      "y": 229
    },
    {
      "t": 46504,
      "e": 46504,
      "ty": 41,
      "x": 27481,
      "y": 12242,
      "ta": "html > body"
    },
    {
      "t": 46604,
      "e": 46604,
      "ty": 2,
      "x": 807,
      "y": 233
    },
    {
      "t": 46704,
      "e": 46704,
      "ty": 2,
      "x": 810,
      "y": 236
    },
    {
      "t": 46754,
      "e": 46754,
      "ty": 41,
      "x": 27825,
      "y": 12741,
      "ta": "html > body"
    },
    {
      "t": 46804,
      "e": 46804,
      "ty": 2,
      "x": 819,
      "y": 238
    },
    {
      "t": 46892,
      "e": 46892,
      "ty": 6,
      "x": 826,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46904,
      "e": 46904,
      "ty": 2,
      "x": 826,
      "y": 238
    },
    {
      "t": 47004,
      "e": 47004,
      "ty": 2,
      "x": 831,
      "y": 239
    },
    {
      "t": 47005,
      "e": 47005,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47104,
      "e": 47104,
      "ty": 2,
      "x": 834,
      "y": 240
    },
    {
      "t": 47254,
      "e": 47254,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47292,
      "e": 47292,
      "ty": 3,
      "x": 834,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47293,
      "e": 47293,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47402,
      "e": 47402,
      "ty": 4,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47402,
      "e": 47402,
      "ty": 5,
      "x": 834,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47403,
      "e": 47403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 47704,
      "e": 47704,
      "ty": 2,
      "x": 833,
      "y": 240
    },
    {
      "t": 47754,
      "e": 47754,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47804,
      "e": 47804,
      "ty": 2,
      "x": 832,
      "y": 240
    },
    {
      "t": 47943,
      "e": 47943,
      "ty": 7,
      "x": 843,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48004,
      "e": 48004,
      "ty": 2,
      "x": 859,
      "y": 250
    },
    {
      "t": 48004,
      "e": 48004,
      "ty": 41,
      "x": 8918,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 48104,
      "e": 48104,
      "ty": 2,
      "x": 916,
      "y": 324
    },
    {
      "t": 48204,
      "e": 48204,
      "ty": 2,
      "x": 958,
      "y": 374
    },
    {
      "t": 48255,
      "e": 48255,
      "ty": 41,
      "x": 33837,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 48304,
      "e": 48304,
      "ty": 2,
      "x": 964,
      "y": 429
    },
    {
      "t": 48404,
      "e": 48404,
      "ty": 2,
      "x": 901,
      "y": 473
    },
    {
      "t": 48504,
      "e": 48504,
      "ty": 2,
      "x": 878,
      "y": 485
    },
    {
      "t": 48504,
      "e": 48504,
      "ty": 41,
      "x": 13427,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 48604,
      "e": 48604,
      "ty": 2,
      "x": 872,
      "y": 491
    },
    {
      "t": 48704,
      "e": 48704,
      "ty": 2,
      "x": 863,
      "y": 519
    },
    {
      "t": 48756,
      "e": 48705,
      "ty": 41,
      "x": 48657,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 48804,
      "e": 48753,
      "ty": 2,
      "x": 863,
      "y": 536
    },
    {
      "t": 48904,
      "e": 48853,
      "ty": 2,
      "x": 852,
      "y": 558
    },
    {
      "t": 49004,
      "e": 48953,
      "ty": 2,
      "x": 848,
      "y": 561
    },
    {
      "t": 49005,
      "e": 48954,
      "ty": 41,
      "x": 18134,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 49060,
      "e": 49009,
      "ty": 6,
      "x": 838,
      "y": 553,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 49104,
      "e": 49053,
      "ty": 2,
      "x": 837,
      "y": 548
    },
    {
      "t": 49110,
      "e": 49059,
      "ty": 7,
      "x": 837,
      "y": 546,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 49204,
      "e": 49153,
      "ty": 2,
      "x": 837,
      "y": 541
    },
    {
      "t": 49254,
      "e": 49203,
      "ty": 41,
      "x": 3459,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 49304,
      "e": 49253,
      "ty": 2,
      "x": 835,
      "y": 536
    },
    {
      "t": 49364,
      "e": 49313,
      "ty": 6,
      "x": 833,
      "y": 532,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49405,
      "e": 49354,
      "ty": 2,
      "x": 832,
      "y": 532
    },
    {
      "t": 49504,
      "e": 49453,
      "ty": 2,
      "x": 831,
      "y": 527
    },
    {
      "t": 49504,
      "e": 49453,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49658,
      "e": 49607,
      "ty": 3,
      "x": 831,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49659,
      "e": 49608,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49660,
      "e": 49609,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49746,
      "e": 49695,
      "ty": 4,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49746,
      "e": 49695,
      "ty": 5,
      "x": 831,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 49748,
      "e": 49697,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 50804,
      "e": 50753,
      "ty": 2,
      "x": 832,
      "y": 525
    },
    {
      "t": 50845,
      "e": 50794,
      "ty": 7,
      "x": 843,
      "y": 520,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 50904,
      "e": 50853,
      "ty": 2,
      "x": 847,
      "y": 519
    },
    {
      "t": 51005,
      "e": 50954,
      "ty": 2,
      "x": 853,
      "y": 520
    },
    {
      "t": 51005,
      "e": 50954,
      "ty": 41,
      "x": 36954,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 51104,
      "e": 51053,
      "ty": 2,
      "x": 862,
      "y": 529
    },
    {
      "t": 51204,
      "e": 51153,
      "ty": 2,
      "x": 864,
      "y": 536
    },
    {
      "t": 51254,
      "e": 51203,
      "ty": 41,
      "x": 31781,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 51304,
      "e": 51253,
      "ty": 2,
      "x": 877,
      "y": 570
    },
    {
      "t": 51404,
      "e": 51353,
      "ty": 2,
      "x": 906,
      "y": 622
    },
    {
      "t": 51505,
      "e": 51454,
      "ty": 2,
      "x": 918,
      "y": 672
    },
    {
      "t": 51505,
      "e": 51454,
      "ty": 41,
      "x": 25931,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51604,
      "e": 51553,
      "ty": 2,
      "x": 913,
      "y": 706
    },
    {
      "t": 51704,
      "e": 51653,
      "ty": 2,
      "x": 917,
      "y": 724
    },
    {
      "t": 51754,
      "e": 51703,
      "ty": 41,
      "x": 23988,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 51804,
      "e": 51753,
      "ty": 2,
      "x": 917,
      "y": 728
    },
    {
      "t": 51904,
      "e": 51853,
      "ty": 2,
      "x": 917,
      "y": 729
    },
    {
      "t": 52004,
      "e": 51953,
      "ty": 41,
      "x": 23988,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 52604,
      "e": 52553,
      "ty": 2,
      "x": 916,
      "y": 728
    },
    {
      "t": 52704,
      "e": 52653,
      "ty": 2,
      "x": 892,
      "y": 736
    },
    {
      "t": 52754,
      "e": 52703,
      "ty": 41,
      "x": 21103,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52804,
      "e": 52753,
      "ty": 2,
      "x": 861,
      "y": 779
    },
    {
      "t": 52904,
      "e": 52853,
      "ty": 2,
      "x": 853,
      "y": 803
    },
    {
      "t": 53004,
      "e": 52953,
      "ty": 2,
      "x": 851,
      "y": 817
    },
    {
      "t": 53006,
      "e": 52955,
      "ty": 41,
      "x": 17458,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53104,
      "e": 53053,
      "ty": 2,
      "x": 847,
      "y": 833
    },
    {
      "t": 53204,
      "e": 53153,
      "ty": 2,
      "x": 842,
      "y": 847
    },
    {
      "t": 53254,
      "e": 53203,
      "ty": 41,
      "x": 13793,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 53304,
      "e": 53253,
      "ty": 2,
      "x": 841,
      "y": 854
    },
    {
      "t": 53404,
      "e": 53353,
      "ty": 2,
      "x": 841,
      "y": 855
    },
    {
      "t": 53505,
      "e": 53454,
      "ty": 41,
      "x": 4646,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 53598,
      "e": 53547,
      "ty": 6,
      "x": 839,
      "y": 844,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 53604,
      "e": 53553,
      "ty": 2,
      "x": 839,
      "y": 844
    },
    {
      "t": 53698,
      "e": 53647,
      "ty": 7,
      "x": 839,
      "y": 835,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 53704,
      "e": 53653,
      "ty": 2,
      "x": 839,
      "y": 835
    },
    {
      "t": 53754,
      "e": 53703,
      "ty": 41,
      "x": 12384,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 53804,
      "e": 53753,
      "ty": 2,
      "x": 839,
      "y": 830
    },
    {
      "t": 53864,
      "e": 53813,
      "ty": 6,
      "x": 839,
      "y": 816,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 53905,
      "e": 53854,
      "ty": 2,
      "x": 839,
      "y": 811
    },
    {
      "t": 53931,
      "e": 53880,
      "ty": 7,
      "x": 839,
      "y": 807,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54004,
      "e": 53953,
      "ty": 2,
      "x": 839,
      "y": 800
    },
    {
      "t": 54004,
      "e": 53953,
      "ty": 41,
      "x": 4171,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 54063,
      "e": 54012,
      "ty": 6,
      "x": 839,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54104,
      "e": 54053,
      "ty": 2,
      "x": 837,
      "y": 782
    },
    {
      "t": 54113,
      "e": 54062,
      "ty": 7,
      "x": 837,
      "y": 777,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54148,
      "e": 54097,
      "ty": 6,
      "x": 839,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54165,
      "e": 54114,
      "ty": 7,
      "x": 840,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54205,
      "e": 54154,
      "ty": 2,
      "x": 840,
      "y": 757
    },
    {
      "t": 54254,
      "e": 54203,
      "ty": 41,
      "x": 4409,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 54304,
      "e": 54253,
      "ty": 2,
      "x": 840,
      "y": 736
    },
    {
      "t": 54405,
      "e": 54354,
      "ty": 2,
      "x": 841,
      "y": 716
    },
    {
      "t": 54505,
      "e": 54454,
      "ty": 2,
      "x": 841,
      "y": 715
    },
    {
      "t": 54505,
      "e": 54454,
      "ty": 41,
      "x": 4646,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 54604,
      "e": 54553,
      "ty": 2,
      "x": 840,
      "y": 721
    },
    {
      "t": 54704,
      "e": 54653,
      "ty": 2,
      "x": 840,
      "y": 723
    },
    {
      "t": 54755,
      "e": 54704,
      "ty": 41,
      "x": 4662,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 54804,
      "e": 54753,
      "ty": 2,
      "x": 840,
      "y": 729
    },
    {
      "t": 54905,
      "e": 54854,
      "ty": 2,
      "x": 840,
      "y": 730
    },
    {
      "t": 55005,
      "e": 54954,
      "ty": 2,
      "x": 840,
      "y": 732
    },
    {
      "t": 55005,
      "e": 54954,
      "ty": 41,
      "x": 4662,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55267,
      "e": 55216,
      "ty": 3,
      "x": 840,
      "y": 732,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55269,
      "e": 55218,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 55386,
      "e": 55335,
      "ty": 4,
      "x": 4662,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55386,
      "e": 55335,
      "ty": 5,
      "x": 840,
      "y": 732,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55387,
      "e": 55336,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 55388,
      "e": 55337,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 58988,
      "e": 58937,
      "ty": 6,
      "x": 839,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59005,
      "e": 58954,
      "ty": 2,
      "x": 839,
      "y": 735
    },
    {
      "t": 59005,
      "e": 58954,
      "ty": 41,
      "x": 63408,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59018,
      "e": 58967,
      "ty": 7,
      "x": 839,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59104,
      "e": 59053,
      "ty": 2,
      "x": 844,
      "y": 753
    },
    {
      "t": 59204,
      "e": 59153,
      "ty": 2,
      "x": 846,
      "y": 756
    },
    {
      "t": 59254,
      "e": 59203,
      "ty": 41,
      "x": 10255,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59305,
      "e": 59254,
      "ty": 2,
      "x": 847,
      "y": 760
    },
    {
      "t": 59404,
      "e": 59353,
      "ty": 2,
      "x": 848,
      "y": 762
    },
    {
      "t": 59505,
      "e": 59454,
      "ty": 41,
      "x": 11089,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59605,
      "e": 59554,
      "ty": 2,
      "x": 848,
      "y": 764
    },
    {
      "t": 59704,
      "e": 59653,
      "ty": 2,
      "x": 849,
      "y": 768
    },
    {
      "t": 59754,
      "e": 59703,
      "ty": 41,
      "x": 6782,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59805,
      "e": 59754,
      "ty": 2,
      "x": 850,
      "y": 771
    },
    {
      "t": 59904,
      "e": 59853,
      "ty": 2,
      "x": 851,
      "y": 771
    },
    {
      "t": 60005,
      "e": 59954,
      "ty": 41,
      "x": 7019,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 61405,
      "e": 61354,
      "ty": 2,
      "x": 851,
      "y": 774
    },
    {
      "t": 61505,
      "e": 61454,
      "ty": 2,
      "x": 851,
      "y": 786
    },
    {
      "t": 61505,
      "e": 61454,
      "ty": 41,
      "x": 16558,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 61605,
      "e": 61554,
      "ty": 2,
      "x": 851,
      "y": 805
    },
    {
      "t": 61704,
      "e": 61653,
      "ty": 2,
      "x": 860,
      "y": 859
    },
    {
      "t": 61755,
      "e": 61704,
      "ty": 41,
      "x": 9155,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61804,
      "e": 61753,
      "ty": 2,
      "x": 860,
      "y": 949
    },
    {
      "t": 61905,
      "e": 61854,
      "ty": 2,
      "x": 856,
      "y": 961
    },
    {
      "t": 62004,
      "e": 61953,
      "ty": 2,
      "x": 851,
      "y": 969
    },
    {
      "t": 62004,
      "e": 61953,
      "ty": 41,
      "x": 23926,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62104,
      "e": 62053,
      "ty": 2,
      "x": 847,
      "y": 971
    },
    {
      "t": 62205,
      "e": 62154,
      "ty": 2,
      "x": 846,
      "y": 971
    },
    {
      "t": 62255,
      "e": 62204,
      "ty": 41,
      "x": 19881,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62305,
      "e": 62254,
      "ty": 2,
      "x": 845,
      "y": 971
    },
    {
      "t": 62404,
      "e": 62353,
      "ty": 6,
      "x": 839,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62405,
      "e": 62354,
      "ty": 2,
      "x": 839,
      "y": 967
    },
    {
      "t": 62504,
      "e": 62453,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 62505,
      "e": 62454,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62605,
      "e": 62554,
      "ty": 2,
      "x": 834,
      "y": 964
    },
    {
      "t": 62628,
      "e": 62577,
      "ty": 3,
      "x": 834,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62629,
      "e": 62578,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62629,
      "e": 62578,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62754,
      "e": 62703,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62762,
      "e": 62711,
      "ty": 4,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62763,
      "e": 62712,
      "ty": 5,
      "x": 834,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62763,
      "e": 62712,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 62921,
      "e": 62870,
      "ty": 7,
      "x": 846,
      "y": 973,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63004,
      "e": 62953,
      "ty": 2,
      "x": 886,
      "y": 999
    },
    {
      "t": 63005,
      "e": 62954,
      "ty": 41,
      "x": 64107,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 63055,
      "e": 63004,
      "ty": 6,
      "x": 891,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63105,
      "e": 63054,
      "ty": 2,
      "x": 895,
      "y": 1010
    },
    {
      "t": 63205,
      "e": 63154,
      "ty": 2,
      "x": 898,
      "y": 1015
    },
    {
      "t": 63255,
      "e": 63204,
      "ty": 41,
      "x": 35344,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63284,
      "e": 63233,
      "ty": 3,
      "x": 898,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63284,
      "e": 63233,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63286,
      "e": 63235,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63402,
      "e": 63351,
      "ty": 4,
      "x": 35344,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63402,
      "e": 63351,
      "ty": 5,
      "x": 898,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63405,
      "e": 63354,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63406,
      "e": 63355,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63407,
      "e": 63356,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 63905,
      "e": 63854,
      "ty": 2,
      "x": 899,
      "y": 1015
    },
    {
      "t": 64004,
      "e": 63953,
      "ty": 2,
      "x": 957,
      "y": 1003
    },
    {
      "t": 64005,
      "e": 63954,
      "ty": 41,
      "x": 32681,
      "y": 55120,
      "ta": "html > body"
    },
    {
      "t": 64105,
      "e": 64054,
      "ty": 2,
      "x": 1106,
      "y": 964
    },
    {
      "t": 64204,
      "e": 64153,
      "ty": 2,
      "x": 1397,
      "y": 933
    },
    {
      "t": 64255,
      "e": 64204,
      "ty": 41,
      "x": 51346,
      "y": 50633,
      "ta": "html > body"
    },
    {
      "t": 64305,
      "e": 64254,
      "ty": 2,
      "x": 1544,
      "y": 921
    },
    {
      "t": 64405,
      "e": 64354,
      "ty": 2,
      "x": 1577,
      "y": 921
    },
    {
      "t": 64506,
      "e": 64355,
      "ty": 41,
      "x": 54032,
      "y": 50577,
      "ta": "html > body"
    },
    {
      "t": 64737,
      "e": 64586,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 67405,
      "e": 67254,
      "ty": 2,
      "x": 1572,
      "y": 923
    },
    {
      "t": 67505,
      "e": 67354,
      "ty": 2,
      "x": 1559,
      "y": 926
    },
    {
      "t": 67505,
      "e": 67354,
      "ty": 41,
      "x": 62261,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68405,
      "e": 68254,
      "ty": 2,
      "x": 1561,
      "y": 928
    },
    {
      "t": 68506,
      "e": 68355,
      "ty": 41,
      "x": 62359,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68755,
      "e": 68604,
      "ty": 41,
      "x": 62015,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68806,
      "e": 68655,
      "ty": 2,
      "x": 1541,
      "y": 932
    },
    {
      "t": 68906,
      "e": 68755,
      "ty": 2,
      "x": 1446,
      "y": 976
    },
    {
      "t": 69006,
      "e": 68855,
      "ty": 2,
      "x": 1320,
      "y": 1046
    },
    {
      "t": 69006,
      "e": 68855,
      "ty": 41,
      "x": 50503,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69106,
      "e": 68955,
      "ty": 2,
      "x": 1178,
      "y": 1102
    },
    {
      "t": 69206,
      "e": 69055,
      "ty": 2,
      "x": 1107,
      "y": 1140
    },
    {
      "t": 69257,
      "e": 69106,
      "ty": 41,
      "x": 36951,
      "y": 64094,
      "ta": "> div.masterdiv"
    },
    {
      "t": 69306,
      "e": 69155,
      "ty": 2,
      "x": 1074,
      "y": 1181
    },
    {
      "t": 69406,
      "e": 69255,
      "ty": 2,
      "x": 1069,
      "y": 1190
    },
    {
      "t": 70006,
      "e": 69855,
      "ty": 2,
      "x": 1066,
      "y": 1190
    },
    {
      "t": 70007,
      "e": 69856,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70106,
      "e": 69955,
      "ty": 2,
      "x": 1029,
      "y": 1178
    },
    {
      "t": 70207,
      "e": 70056,
      "ty": 2,
      "x": 884,
      "y": 1136
    },
    {
      "t": 70256,
      "e": 70105,
      "ty": 41,
      "x": 28066,
      "y": 61601,
      "ta": "> div.masterdiv"
    },
    {
      "t": 70306,
      "e": 70155,
      "ty": 2,
      "x": 803,
      "y": 1114
    },
    {
      "t": 70406,
      "e": 70255,
      "ty": 2,
      "x": 789,
      "y": 1107
    },
    {
      "t": 70506,
      "e": 70355,
      "ty": 2,
      "x": 787,
      "y": 1101
    },
    {
      "t": 70506,
      "e": 70355,
      "ty": 41,
      "x": 26826,
      "y": 60549,
      "ta": "> div.masterdiv"
    },
    {
      "t": 70605,
      "e": 70454,
      "ty": 2,
      "x": 820,
      "y": 1063
    },
    {
      "t": 70705,
      "e": 70554,
      "ty": 2,
      "x": 950,
      "y": 1041
    },
    {
      "t": 70756,
      "e": 70605,
      "ty": 41,
      "x": 34169,
      "y": 64517,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70797,
      "e": 70646,
      "ty": 6,
      "x": 998,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 70806,
      "e": 70655,
      "ty": 2,
      "x": 998,
      "y": 1072
    },
    {
      "t": 70905,
      "e": 70754,
      "ty": 2,
      "x": 997,
      "y": 1082
    },
    {
      "t": 71005,
      "e": 70854,
      "ty": 2,
      "x": 981,
      "y": 1092
    },
    {
      "t": 71006,
      "e": 70855,
      "ty": 41,
      "x": 39047,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 71269,
      "e": 71118,
      "ty": 3,
      "x": 981,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 71270,
      "e": 71119,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 71371,
      "e": 71220,
      "ty": 4,
      "x": 39047,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 71371,
      "e": 71220,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 71372,
      "e": 71221,
      "ty": 5,
      "x": 981,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 71372,
      "e": 71221,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 72416,
      "e": 72265,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 74340,
      "e": 74189,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 202532, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 202539, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4453, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 208337, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12385, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"alpha\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 221728, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 15525, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 238345, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 18068, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 257416, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 49866, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 308657, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:964,y:1089,t:1526918883099};\\\", \\\"{x:964,y:1086,t:1526918883110};\\\", \\\"{x:964,y:1079,t:1526918883345};\\\", \\\"{x:962,y:1063,t:1526918883360};\\\", \\\"{x:938,y:1009,t:1526918883377};\\\", \\\"{x:906,y:964,t:1526918883392};\\\", \\\"{x:874,y:922,t:1526918883410};\\\", \\\"{x:838,y:873,t:1526918883427};\\\", \\\"{x:798,y:822,t:1526918883443};\\\", \\\"{x:760,y:775,t:1526918883460};\\\", \\\"{x:714,y:730,t:1526918883477};\\\", \\\"{x:675,y:694,t:1526918883493};\\\", \\\"{x:637,y:661,t:1526918883510};\\\", \\\"{x:595,y:632,t:1526918883528};\\\", \\\"{x:550,y:610,t:1526918883544};\\\", \\\"{x:515,y:595,t:1526918883559};\\\", \\\"{x:479,y:573,t:1526918883577};\\\", \\\"{x:455,y:553,t:1526918883594};\\\", \\\"{x:435,y:533,t:1526918883610};\\\", \\\"{x:422,y:515,t:1526918883626};\\\", \\\"{x:417,y:496,t:1526918883644};\\\", \\\"{x:412,y:466,t:1526918883660};\\\", \\\"{x:412,y:432,t:1526918883677};\\\", \\\"{x:412,y:398,t:1526918883694};\\\", \\\"{x:412,y:370,t:1526918883710};\\\", \\\"{x:418,y:341,t:1526918883727};\\\", \\\"{x:425,y:318,t:1526918883744};\\\", \\\"{x:438,y:293,t:1526918883761};\\\", \\\"{x:443,y:287,t:1526918883777};\\\", \\\"{x:453,y:284,t:1526918883794};\\\", \\\"{x:473,y:284,t:1526918883811};\\\", \\\"{x:500,y:285,t:1526918883827};\\\", \\\"{x:550,y:294,t:1526918883844};\\\", \\\"{x:625,y:312,t:1526918883862};\\\", \\\"{x:711,y:337,t:1526918883877};\\\", \\\"{x:804,y:360,t:1526918883894};\\\", \\\"{x:891,y:387,t:1526918883912};\\\", \\\"{x:965,y:407,t:1526918883927};\\\", \\\"{x:1013,y:429,t:1526918883944};\\\", \\\"{x:1055,y:454,t:1526918883962};\\\", \\\"{x:1077,y:472,t:1526918883977};\\\", \\\"{x:1095,y:493,t:1526918883995};\\\", \\\"{x:1114,y:515,t:1526918884012};\\\", \\\"{x:1130,y:536,t:1526918884027};\\\", \\\"{x:1150,y:559,t:1526918884044};\\\", \\\"{x:1166,y:581,t:1526918884062};\\\", \\\"{x:1185,y:600,t:1526918884077};\\\", \\\"{x:1204,y:614,t:1526918884094};\\\", \\\"{x:1220,y:626,t:1526918884111};\\\", \\\"{x:1239,y:639,t:1526918884127};\\\", \\\"{x:1262,y:654,t:1526918884145};\\\", \\\"{x:1293,y:677,t:1526918884161};\\\", \\\"{x:1314,y:696,t:1526918884178};\\\", \\\"{x:1334,y:712,t:1526918884194};\\\", \\\"{x:1352,y:727,t:1526918884212};\\\", \\\"{x:1365,y:745,t:1526918884228};\\\", \\\"{x:1376,y:760,t:1526918884247};\\\", \\\"{x:1384,y:772,t:1526918884261};\\\", \\\"{x:1387,y:780,t:1526918884277};\\\", \\\"{x:1391,y:786,t:1526918884294};\\\", \\\"{x:1393,y:791,t:1526918884311};\\\", \\\"{x:1393,y:793,t:1526918884328};\\\", \\\"{x:1393,y:794,t:1526918884344};\\\", \\\"{x:1393,y:795,t:1526918884361};\\\", \\\"{x:1393,y:797,t:1526918884561};\\\", \\\"{x:1389,y:802,t:1526918884578};\\\", \\\"{x:1373,y:819,t:1526918884594};\\\", \\\"{x:1359,y:837,t:1526918884611};\\\", \\\"{x:1345,y:856,t:1526918884628};\\\", \\\"{x:1334,y:873,t:1526918884644};\\\", \\\"{x:1327,y:887,t:1526918884661};\\\", \\\"{x:1318,y:898,t:1526918884678};\\\", \\\"{x:1316,y:905,t:1526918884695};\\\", \\\"{x:1314,y:913,t:1526918884711};\\\", \\\"{x:1314,y:917,t:1526918884728};\\\", \\\"{x:1314,y:920,t:1526918884745};\\\", \\\"{x:1314,y:924,t:1526918884761};\\\", \\\"{x:1314,y:928,t:1526918884778};\\\", \\\"{x:1315,y:930,t:1526918884794};\\\", \\\"{x:1315,y:933,t:1526918884811};\\\", \\\"{x:1318,y:936,t:1526918884828};\\\", \\\"{x:1318,y:941,t:1526918884845};\\\", \\\"{x:1318,y:943,t:1526918884861};\\\", \\\"{x:1318,y:946,t:1526918884878};\\\", \\\"{x:1318,y:947,t:1526918884895};\\\", \\\"{x:1318,y:950,t:1526918884911};\\\", \\\"{x:1318,y:954,t:1526918884929};\\\", \\\"{x:1316,y:960,t:1526918884945};\\\", \\\"{x:1316,y:965,t:1526918884961};\\\", \\\"{x:1313,y:969,t:1526918884978};\\\", \\\"{x:1312,y:973,t:1526918884995};\\\", \\\"{x:1309,y:977,t:1526918885011};\\\", \\\"{x:1309,y:979,t:1526918885028};\\\", \\\"{x:1309,y:980,t:1526918885049};\\\", \\\"{x:1309,y:982,t:1526918885081};\\\", \\\"{x:1308,y:982,t:1526918885114};\\\", \\\"{x:1306,y:983,t:1526918885354};\\\", \\\"{x:1304,y:984,t:1526918885370};\\\", \\\"{x:1303,y:984,t:1526918885379};\\\", \\\"{x:1300,y:984,t:1526918885396};\\\", \\\"{x:1296,y:984,t:1526918885413};\\\", \\\"{x:1292,y:984,t:1526918885429};\\\", \\\"{x:1290,y:982,t:1526918885446};\\\", \\\"{x:1288,y:982,t:1526918885462};\\\", \\\"{x:1287,y:982,t:1526918885479};\\\", \\\"{x:1286,y:981,t:1526918885496};\\\", \\\"{x:1285,y:980,t:1526918885513};\\\", \\\"{x:1285,y:979,t:1526918885530};\\\", \\\"{x:1284,y:977,t:1526918885545};\\\", \\\"{x:1284,y:976,t:1526918885562};\\\", \\\"{x:1283,y:976,t:1526918885578};\\\", \\\"{x:1283,y:974,t:1526918885609};\\\", \\\"{x:1283,y:973,t:1526918885632};\\\", \\\"{x:1283,y:971,t:1526918885648};\\\", \\\"{x:1283,y:970,t:1526918885672};\\\", \\\"{x:1283,y:969,t:1526918885689};\\\", \\\"{x:1283,y:968,t:1526918885697};\\\", \\\"{x:1283,y:967,t:1526918885729};\\\", \\\"{x:1283,y:966,t:1526918885745};\\\", \\\"{x:1283,y:965,t:1526918885762};\\\", \\\"{x:1283,y:964,t:1526918885786};\\\", \\\"{x:1284,y:963,t:1526918885796};\\\", \\\"{x:1284,y:962,t:1526918885813};\\\", \\\"{x:1284,y:960,t:1526918885828};\\\", \\\"{x:1284,y:959,t:1526918885846};\\\", \\\"{x:1284,y:958,t:1526918885863};\\\", \\\"{x:1284,y:957,t:1526918885880};\\\", \\\"{x:1284,y:956,t:1526918885897};\\\", \\\"{x:1284,y:955,t:1526918885914};\\\", \\\"{x:1284,y:954,t:1526918885930};\\\", \\\"{x:1284,y:953,t:1526918885946};\\\", \\\"{x:1284,y:954,t:1526918888906};\\\", \\\"{x:1284,y:955,t:1526918888915};\\\", \\\"{x:1283,y:958,t:1526918888931};\\\", \\\"{x:1282,y:959,t:1526918888948};\\\", \\\"{x:1282,y:960,t:1526918888964};\\\", \\\"{x:1281,y:962,t:1526918888982};\\\", \\\"{x:1280,y:962,t:1526918889274};\\\", \\\"{x:1279,y:962,t:1526918889762};\\\", \\\"{x:1279,y:961,t:1526918890057};\\\", \\\"{x:1279,y:960,t:1526918890074};\\\", \\\"{x:1277,y:958,t:1526918890089};\\\", \\\"{x:1276,y:957,t:1526918890145};\\\", \\\"{x:1276,y:956,t:1526918890161};\\\", \\\"{x:1276,y:955,t:1526918890169};\\\", \\\"{x:1276,y:954,t:1526918890193};\\\", \\\"{x:1276,y:952,t:1526918890201};\\\", \\\"{x:1276,y:950,t:1526918890216};\\\", \\\"{x:1273,y:945,t:1526918890232};\\\", \\\"{x:1273,y:941,t:1526918890249};\\\", \\\"{x:1269,y:932,t:1526918890266};\\\", \\\"{x:1266,y:924,t:1526918890282};\\\", \\\"{x:1266,y:918,t:1526918890299};\\\", \\\"{x:1264,y:910,t:1526918890316};\\\", \\\"{x:1263,y:900,t:1526918890332};\\\", \\\"{x:1259,y:888,t:1526918890349};\\\", \\\"{x:1256,y:875,t:1526918890366};\\\", \\\"{x:1253,y:862,t:1526918890382};\\\", \\\"{x:1253,y:852,t:1526918890399};\\\", \\\"{x:1252,y:846,t:1526918890416};\\\", \\\"{x:1251,y:837,t:1526918890432};\\\", \\\"{x:1249,y:828,t:1526918890449};\\\", \\\"{x:1247,y:814,t:1526918890465};\\\", \\\"{x:1247,y:808,t:1526918890482};\\\", \\\"{x:1247,y:801,t:1526918890499};\\\", \\\"{x:1247,y:793,t:1526918890516};\\\", \\\"{x:1247,y:786,t:1526918890533};\\\", \\\"{x:1247,y:779,t:1526918890549};\\\", \\\"{x:1247,y:768,t:1526918890566};\\\", \\\"{x:1247,y:757,t:1526918890583};\\\", \\\"{x:1246,y:748,t:1526918890599};\\\", \\\"{x:1246,y:745,t:1526918890616};\\\", \\\"{x:1245,y:742,t:1526918890632};\\\", \\\"{x:1244,y:741,t:1526918890690};\\\", \\\"{x:1239,y:742,t:1526918890699};\\\", \\\"{x:1216,y:750,t:1526918890716};\\\", \\\"{x:1185,y:756,t:1526918890733};\\\", \\\"{x:1119,y:764,t:1526918890749};\\\", \\\"{x:1030,y:767,t:1526918890766};\\\", \\\"{x:913,y:784,t:1526918890783};\\\", \\\"{x:793,y:792,t:1526918890799};\\\", \\\"{x:681,y:772,t:1526918890816};\\\", \\\"{x:504,y:725,t:1526918890835};\\\", \\\"{x:364,y:688,t:1526918890848};\\\", \\\"{x:248,y:657,t:1526918890865};\\\", \\\"{x:164,y:630,t:1526918890883};\\\", \\\"{x:116,y:606,t:1526918890900};\\\", \\\"{x:76,y:577,t:1526918890916};\\\", \\\"{x:14,y:541,t:1526918890933};\\\", \\\"{x:0,y:514,t:1526918890949};\\\", \\\"{x:0,y:496,t:1526918890966};\\\", \\\"{x:0,y:479,t:1526918890984};\\\", \\\"{x:0,y:456,t:1526918890999};\\\", \\\"{x:0,y:433,t:1526918891016};\\\", \\\"{x:0,y:428,t:1526918891032};\\\", \\\"{x:1,y:428,t:1526918891073};\\\", \\\"{x:5,y:428,t:1526918891083};\\\", \\\"{x:15,y:429,t:1526918891100};\\\", \\\"{x:29,y:432,t:1526918891117};\\\", \\\"{x:53,y:438,t:1526918891133};\\\", \\\"{x:103,y:450,t:1526918891149};\\\", \\\"{x:175,y:459,t:1526918891166};\\\", \\\"{x:251,y:464,t:1526918891184};\\\", \\\"{x:377,y:481,t:1526918891201};\\\", \\\"{x:461,y:492,t:1526918891217};\\\", \\\"{x:506,y:501,t:1526918891233};\\\", \\\"{x:526,y:506,t:1526918891252};\\\", \\\"{x:532,y:509,t:1526918891266};\\\", \\\"{x:532,y:510,t:1526918891297};\\\", \\\"{x:532,y:512,t:1526918891304};\\\", \\\"{x:532,y:514,t:1526918891316};\\\", \\\"{x:530,y:520,t:1526918891334};\\\", \\\"{x:525,y:530,t:1526918891350};\\\", \\\"{x:521,y:540,t:1526918891367};\\\", \\\"{x:515,y:547,t:1526918891385};\\\", \\\"{x:509,y:549,t:1526918891400};\\\", \\\"{x:501,y:551,t:1526918891417};\\\", \\\"{x:489,y:551,t:1526918891435};\\\", \\\"{x:476,y:551,t:1526918891451};\\\", \\\"{x:460,y:547,t:1526918891467};\\\", \\\"{x:444,y:541,t:1526918891484};\\\", \\\"{x:431,y:536,t:1526918891500};\\\", \\\"{x:420,y:533,t:1526918891516};\\\", \\\"{x:417,y:530,t:1526918891534};\\\", \\\"{x:414,y:528,t:1526918891550};\\\", \\\"{x:413,y:528,t:1526918891568};\\\", \\\"{x:409,y:528,t:1526918891583};\\\", \\\"{x:401,y:529,t:1526918891601};\\\", \\\"{x:394,y:532,t:1526918891617};\\\", \\\"{x:385,y:537,t:1526918891634};\\\", \\\"{x:379,y:540,t:1526918891651};\\\", \\\"{x:376,y:542,t:1526918891667};\\\", \\\"{x:374,y:542,t:1526918891683};\\\", \\\"{x:373,y:541,t:1526918891729};\\\", \\\"{x:373,y:540,t:1526918891737};\\\", \\\"{x:373,y:537,t:1526918891750};\\\", \\\"{x:373,y:533,t:1526918891768};\\\", \\\"{x:373,y:529,t:1526918891783};\\\", \\\"{x:374,y:526,t:1526918891800};\\\", \\\"{x:375,y:524,t:1526918891818};\\\", \\\"{x:376,y:523,t:1526918891833};\\\", \\\"{x:377,y:523,t:1526918891920};\\\", \\\"{x:377,y:522,t:1526918891937};\\\", \\\"{x:378,y:522,t:1526918892034};\\\", \\\"{x:379,y:522,t:1526918892409};\\\", \\\"{x:384,y:523,t:1526918892418};\\\", \\\"{x:403,y:533,t:1526918892435};\\\", \\\"{x:427,y:543,t:1526918892451};\\\", \\\"{x:449,y:554,t:1526918892468};\\\", \\\"{x:472,y:564,t:1526918892484};\\\", \\\"{x:492,y:572,t:1526918892501};\\\", \\\"{x:511,y:581,t:1526918892518};\\\", \\\"{x:526,y:588,t:1526918892535};\\\", \\\"{x:540,y:595,t:1526918892551};\\\", \\\"{x:556,y:604,t:1526918892567};\\\", \\\"{x:573,y:613,t:1526918892586};\\\", \\\"{x:584,y:619,t:1526918892601};\\\", \\\"{x:587,y:621,t:1526918892618};\\\", \\\"{x:591,y:622,t:1526918892635};\\\", \\\"{x:594,y:624,t:1526918892652};\\\", \\\"{x:595,y:625,t:1526918895434};\\\", \\\"{x:595,y:626,t:1526918895441};\\\", \\\"{x:595,y:627,t:1526918895453};\\\", \\\"{x:595,y:628,t:1526918895470};\\\", \\\"{x:594,y:628,t:1526918895487};\\\", \\\"{x:593,y:629,t:1526918895505};\\\", \\\"{x:593,y:630,t:1526918895537};\\\", \\\"{x:592,y:630,t:1526918895554};\\\", \\\"{x:591,y:630,t:1526918895585};\\\", \\\"{x:589,y:631,t:1526918895593};\\\", \\\"{x:588,y:631,t:1526918895609};\\\", \\\"{x:586,y:631,t:1526918895621};\\\", \\\"{x:582,y:632,t:1526918895638};\\\", \\\"{x:578,y:633,t:1526918895653};\\\", \\\"{x:575,y:634,t:1526918895671};\\\", \\\"{x:570,y:637,t:1526918895688};\\\", \\\"{x:567,y:638,t:1526918895703};\\\", \\\"{x:563,y:641,t:1526918895721};\\\", \\\"{x:560,y:643,t:1526918895737};\\\", \\\"{x:557,y:644,t:1526918895753};\\\", \\\"{x:556,y:645,t:1526918895770};\\\", \\\"{x:554,y:645,t:1526918898353};\\\", \\\"{x:553,y:645,t:1526918898449};\\\", \\\"{x:552,y:645,t:1526918898480};\\\", \\\"{x:551,y:645,t:1526918898528};\\\", \\\"{x:550,y:645,t:1526918898540};\\\", \\\"{x:549,y:644,t:1526918898560};\\\", \\\"{x:548,y:644,t:1526918898592};\\\", \\\"{x:547,y:644,t:1526918901554};\\\", \\\"{x:548,y:647,t:1526918901561};\\\", \\\"{x:548,y:649,t:1526918901577};\\\", \\\"{x:549,y:659,t:1526918901594};\\\", \\\"{x:549,y:665,t:1526918901609};\\\", \\\"{x:549,y:670,t:1526918901625};\\\", \\\"{x:551,y:675,t:1526918901642};\\\", \\\"{x:551,y:682,t:1526918901658};\\\", \\\"{x:552,y:694,t:1526918901675};\\\", \\\"{x:552,y:709,t:1526918901692};\\\", \\\"{x:552,y:724,t:1526918901707};\\\", \\\"{x:552,y:737,t:1526918901725};\\\", \\\"{x:552,y:745,t:1526918901742};\\\", \\\"{x:552,y:749,t:1526918901758};\\\", \\\"{x:552,y:752,t:1526918901775};\\\", \\\"{x:552,y:757,t:1526918901791};\\\", \\\"{x:552,y:764,t:1526918901808};\\\", \\\"{x:552,y:770,t:1526918901825};\\\", \\\"{x:552,y:775,t:1526918901841};\\\", \\\"{x:552,y:778,t:1526918901859};\\\", \\\"{x:552,y:782,t:1526918901874};\\\", \\\"{x:552,y:785,t:1526918901892};\\\", \\\"{x:552,y:787,t:1526918901909};\\\", \\\"{x:552,y:788,t:1526918901925};\\\", \\\"{x:551,y:790,t:1526918901944};\\\", \\\"{x:550,y:790,t:1526918902065};\\\", \\\"{x:549,y:790,t:1526918902081};\\\", \\\"{x:548,y:789,t:1526918902092};\\\", \\\"{x:548,y:786,t:1526918902109};\\\", \\\"{x:548,y:783,t:1526918902125};\\\", \\\"{x:548,y:778,t:1526918902142};\\\", \\\"{x:547,y:772,t:1526918902159};\\\", \\\"{x:545,y:767,t:1526918902175};\\\", \\\"{x:544,y:763,t:1526918902192};\\\", \\\"{x:541,y:754,t:1526918902209};\\\", \\\"{x:540,y:749,t:1526918902226};\\\", \\\"{x:538,y:744,t:1526918902243};\\\", \\\"{x:536,y:742,t:1526918902259};\\\", \\\"{x:535,y:740,t:1526918902275};\\\", \\\"{x:534,y:739,t:1526918902293};\\\", \\\"{x:533,y:737,t:1526918902309};\\\", \\\"{x:532,y:735,t:1526918902327};\\\", \\\"{x:531,y:734,t:1526918902343};\\\", \\\"{x:530,y:732,t:1526918902358};\\\", \\\"{x:529,y:731,t:1526918902375};\\\", \\\"{x:528,y:729,t:1526918902392};\\\", \\\"{x:528,y:728,t:1526918902408};\\\", \\\"{x:527,y:728,t:1526918902425};\\\", \\\"{x:528,y:726,t:1526918909017};\\\", \\\"{x:527,y:724,t:1526918909025};\\\", \\\"{x:523,y:720,t:1526918909039};\\\", \\\"{x:489,y:696,t:1526918909058};\\\", \\\"{x:465,y:679,t:1526918909072};\\\", \\\"{x:435,y:651,t:1526918909089};\\\", \\\"{x:418,y:624,t:1526918909114};\\\", \\\"{x:417,y:608,t:1526918909131};\\\", \\\"{x:417,y:588,t:1526918909148};\\\", \\\"{x:417,y:577,t:1526918909164};\\\", \\\"{x:421,y:558,t:1526918909181};\\\", \\\"{x:429,y:539,t:1526918909199};\\\", \\\"{x:435,y:525,t:1526918909214};\\\", \\\"{x:436,y:519,t:1526918909231};\\\", \\\"{x:438,y:517,t:1526918909248};\\\", \\\"{x:437,y:517,t:1526918909312};\\\", \\\"{x:434,y:518,t:1526918909320};\\\", \\\"{x:432,y:519,t:1526918909331};\\\", \\\"{x:423,y:523,t:1526918909347};\\\", \\\"{x:411,y:526,t:1526918909364};\\\", \\\"{x:404,y:526,t:1526918909380};\\\", \\\"{x:398,y:526,t:1526918909398};\\\", \\\"{x:396,y:526,t:1526918909414};\\\", \\\"{x:394,y:525,t:1526918909431};\\\", \\\"{x:393,y:523,t:1526918909448};\\\", \\\"{x:391,y:520,t:1526918909465};\\\", \\\"{x:390,y:520,t:1526918909481};\\\", \\\"{x:390,y:519,t:1526918909498};\\\", \\\"{x:390,y:518,t:1526918909514};\\\", \\\"{x:389,y:518,t:1526918909532};\\\", \\\"{x:389,y:517,t:1526918911377};\\\", \\\"{x:390,y:517,t:1526918911545};\\\", \\\"{x:390,y:519,t:1526918926700};\\\", \\\"{x:387,y:522,t:1526918926717};\\\", \\\"{x:372,y:522,t:1526918926735};\\\", \\\"{x:360,y:522,t:1526918926749};\\\", \\\"{x:358,y:522,t:1526918926766};\\\", \\\"{x:357,y:522,t:1526918926827};\\\", \\\"{x:357,y:521,t:1526918926891};\\\", \\\"{x:357,y:519,t:1526918926899};\\\", \\\"{x:357,y:514,t:1526918926915};\\\", \\\"{x:359,y:509,t:1526918926931};\\\", \\\"{x:361,y:503,t:1526918926948};\\\", \\\"{x:362,y:500,t:1526918926965};\\\", \\\"{x:364,y:499,t:1526918927004};\\\", \\\"{x:366,y:499,t:1526918927016};\\\", \\\"{x:376,y:509,t:1526918927032};\\\", \\\"{x:390,y:528,t:1526918927047};\\\", \\\"{x:412,y:548,t:1526918927065};\\\", \\\"{x:427,y:567,t:1526918927081};\\\", \\\"{x:434,y:577,t:1526918927099};\\\", \\\"{x:435,y:579,t:1526918927114};\\\", \\\"{x:433,y:579,t:1526918927170};\\\", \\\"{x:433,y:578,t:1526918927182};\\\", \\\"{x:433,y:574,t:1526918927198};\\\", \\\"{x:430,y:567,t:1526918927214};\\\", \\\"{x:427,y:561,t:1526918927232};\\\", \\\"{x:421,y:553,t:1526918927249};\\\", \\\"{x:417,y:549,t:1526918927266};\\\", \\\"{x:410,y:544,t:1526918927281};\\\", \\\"{x:397,y:539,t:1526918927300};\\\", \\\"{x:391,y:536,t:1526918927316};\\\", \\\"{x:387,y:533,t:1526918927331};\\\", \\\"{x:386,y:532,t:1526918927350};\\\", \\\"{x:386,y:531,t:1526918927396};\\\", \\\"{x:384,y:530,t:1526918927403};\\\", \\\"{x:384,y:529,t:1526918927415};\\\", \\\"{x:382,y:528,t:1526918927435};\\\", \\\"{x:382,y:527,t:1526918927449};\\\", \\\"{x:381,y:526,t:1526918927474};\\\", \\\"{x:384,y:530,t:1526918927715};\\\", \\\"{x:399,y:551,t:1526918927732};\\\", \\\"{x:426,y:580,t:1526918927749};\\\", \\\"{x:456,y:616,t:1526918927766};\\\", \\\"{x:479,y:652,t:1526918927782};\\\", \\\"{x:512,y:695,t:1526918927798};\\\", \\\"{x:546,y:745,t:1526918927815};\\\", \\\"{x:569,y:784,t:1526918927833};\\\", \\\"{x:582,y:800,t:1526918927848};\\\", \\\"{x:584,y:805,t:1526918927866};\\\", \\\"{x:587,y:808,t:1526918927882};\\\", \\\"{x:587,y:813,t:1526918927899};\\\", \\\"{x:589,y:819,t:1526918927916};\\\", \\\"{x:590,y:822,t:1526918927933};\\\", \\\"{x:590,y:824,t:1526918927949};\\\", \\\"{x:590,y:825,t:1526918927966};\\\", \\\"{x:590,y:826,t:1526918927983};\\\", \\\"{x:590,y:825,t:1526918928011};\\\", \\\"{x:590,y:824,t:1526918928019};\\\", \\\"{x:590,y:822,t:1526918928034};\\\", \\\"{x:588,y:816,t:1526918928049};\\\", \\\"{x:582,y:807,t:1526918928066};\\\", \\\"{x:570,y:786,t:1526918928083};\\\", \\\"{x:561,y:772,t:1526918928099};\\\", \\\"{x:552,y:759,t:1526918928116};\\\", \\\"{x:545,y:744,t:1526918928133};\\\", \\\"{x:538,y:733,t:1526918928151};\\\", \\\"{x:533,y:723,t:1526918928166};\\\", \\\"{x:528,y:715,t:1526918928183};\\\", \\\"{x:526,y:711,t:1526918928200};\\\", \\\"{x:525,y:711,t:1526918928215};\\\", \\\"{x:525,y:710,t:1526918928234};\\\", \\\"{x:525,y:709,t:1526918928307};\\\", \\\"{x:524,y:708,t:1526918928315};\\\", \\\"{x:523,y:707,t:1526918928333};\\\", \\\"{x:523,y:706,t:1526918928350};\\\", \\\"{x:522,y:705,t:1526918928366};\\\", \\\"{x:521,y:705,t:1526918928383};\\\", \\\"{x:520,y:704,t:1526918928400};\\\", \\\"{x:519,y:703,t:1526918928416};\\\" ] }, { \\\"rt\\\": 15071, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 324977, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:701,t:1526918935956};\\\", \\\"{x:528,y:692,t:1526918935976};\\\", \\\"{x:540,y:683,t:1526918935991};\\\", \\\"{x:548,y:679,t:1526918936007};\\\", \\\"{x:555,y:674,t:1526918936022};\\\", \\\"{x:557,y:674,t:1526918936038};\\\", \\\"{x:560,y:673,t:1526918936055};\\\", \\\"{x:560,y:671,t:1526918936072};\\\", \\\"{x:561,y:671,t:1526918936098};\\\", \\\"{x:562,y:669,t:1526918936106};\\\", \\\"{x:563,y:665,t:1526918936122};\\\", \\\"{x:563,y:664,t:1526918936138};\\\", \\\"{x:564,y:654,t:1526918936154};\\\", \\\"{x:563,y:644,t:1526918936173};\\\", \\\"{x:545,y:632,t:1526918936188};\\\", \\\"{x:506,y:616,t:1526918936206};\\\", \\\"{x:461,y:603,t:1526918936222};\\\", \\\"{x:413,y:587,t:1526918936239};\\\", \\\"{x:382,y:576,t:1526918936256};\\\", \\\"{x:357,y:563,t:1526918936272};\\\", \\\"{x:342,y:557,t:1526918936289};\\\", \\\"{x:336,y:551,t:1526918936306};\\\", \\\"{x:335,y:551,t:1526918936322};\\\", \\\"{x:335,y:550,t:1526918936339};\\\", \\\"{x:335,y:549,t:1526918936356};\\\", \\\"{x:335,y:547,t:1526918936372};\\\", \\\"{x:335,y:546,t:1526918936390};\\\", \\\"{x:338,y:543,t:1526918936407};\\\", \\\"{x:339,y:542,t:1526918936426};\\\", \\\"{x:339,y:543,t:1526918936467};\\\", \\\"{x:337,y:545,t:1526918936475};\\\", \\\"{x:334,y:549,t:1526918936488};\\\", \\\"{x:321,y:562,t:1526918936506};\\\", \\\"{x:286,y:575,t:1526918936523};\\\", \\\"{x:255,y:578,t:1526918936539};\\\", \\\"{x:217,y:578,t:1526918936556};\\\", \\\"{x:183,y:578,t:1526918936572};\\\", \\\"{x:159,y:578,t:1526918936589};\\\", \\\"{x:153,y:578,t:1526918936606};\\\", \\\"{x:155,y:579,t:1526918936756};\\\", \\\"{x:157,y:583,t:1526918936774};\\\", \\\"{x:160,y:588,t:1526918936789};\\\", \\\"{x:166,y:600,t:1526918936806};\\\", \\\"{x:174,y:613,t:1526918936823};\\\", \\\"{x:177,y:621,t:1526918936840};\\\", \\\"{x:178,y:628,t:1526918936856};\\\", \\\"{x:178,y:634,t:1526918936873};\\\", \\\"{x:179,y:641,t:1526918936889};\\\", \\\"{x:179,y:644,t:1526918936906};\\\", \\\"{x:179,y:647,t:1526918936923};\\\", \\\"{x:179,y:648,t:1526918936939};\\\", \\\"{x:179,y:650,t:1526918936956};\\\", \\\"{x:178,y:650,t:1526918936972};\\\", \\\"{x:177,y:650,t:1526918937042};\\\", \\\"{x:176,y:650,t:1526918937058};\\\", \\\"{x:175,y:650,t:1526918937073};\\\", \\\"{x:173,y:649,t:1526918937089};\\\", \\\"{x:170,y:648,t:1526918937107};\\\", \\\"{x:168,y:647,t:1526918937123};\\\", \\\"{x:166,y:646,t:1526918937141};\\\", \\\"{x:165,y:646,t:1526918937156};\\\", \\\"{x:163,y:646,t:1526918937173};\\\", \\\"{x:162,y:644,t:1526918937190};\\\", \\\"{x:161,y:643,t:1526918937206};\\\", \\\"{x:160,y:642,t:1526918937223};\\\", \\\"{x:159,y:641,t:1526918937240};\\\", \\\"{x:159,y:640,t:1526918937531};\\\", \\\"{x:159,y:638,t:1526918937546};\\\", \\\"{x:160,y:638,t:1526918937557};\\\", \\\"{x:167,y:634,t:1526918937572};\\\", \\\"{x:184,y:632,t:1526918937591};\\\", \\\"{x:216,y:627,t:1526918937607};\\\", \\\"{x:261,y:621,t:1526918937623};\\\", \\\"{x:334,y:618,t:1526918937640};\\\", \\\"{x:393,y:618,t:1526918937657};\\\", \\\"{x:432,y:618,t:1526918937673};\\\", \\\"{x:453,y:618,t:1526918937690};\\\", \\\"{x:463,y:618,t:1526918937707};\\\", \\\"{x:463,y:620,t:1526918937724};\\\", \\\"{x:463,y:623,t:1526918937740};\\\", \\\"{x:463,y:628,t:1526918937757};\\\", \\\"{x:463,y:633,t:1526918937773};\\\", \\\"{x:463,y:637,t:1526918937790};\\\", \\\"{x:463,y:640,t:1526918937807};\\\", \\\"{x:463,y:642,t:1526918937824};\\\", \\\"{x:461,y:645,t:1526918937840};\\\", \\\"{x:457,y:648,t:1526918937857};\\\", \\\"{x:445,y:652,t:1526918937876};\\\", \\\"{x:426,y:652,t:1526918937890};\\\", \\\"{x:390,y:652,t:1526918937906};\\\", \\\"{x:369,y:652,t:1526918937924};\\\", \\\"{x:354,y:649,t:1526918937941};\\\", \\\"{x:347,y:645,t:1526918937957};\\\", \\\"{x:343,y:642,t:1526918937974};\\\", \\\"{x:343,y:640,t:1526918938003};\\\", \\\"{x:344,y:639,t:1526918938084};\\\", \\\"{x:347,y:638,t:1526918938090};\\\", \\\"{x:351,y:636,t:1526918938107};\\\", \\\"{x:357,y:635,t:1526918938124};\\\", \\\"{x:363,y:635,t:1526918938140};\\\", \\\"{x:369,y:635,t:1526918938157};\\\", \\\"{x:372,y:634,t:1526918938174};\\\", \\\"{x:374,y:634,t:1526918938190};\\\", \\\"{x:375,y:634,t:1526918938242};\\\", \\\"{x:376,y:634,t:1526918938290};\\\", \\\"{x:377,y:634,t:1526918938307};\\\", \\\"{x:378,y:634,t:1526918938339};\\\", \\\"{x:377,y:634,t:1526918943940};\\\", \\\"{x:376,y:633,t:1526918943979};\\\", \\\"{x:381,y:633,t:1526918943992};\\\", \\\"{x:404,y:640,t:1526918944009};\\\", \\\"{x:431,y:649,t:1526918944026};\\\", \\\"{x:469,y:659,t:1526918944041};\\\", \\\"{x:547,y:672,t:1526918944075};\\\", \\\"{x:562,y:675,t:1526918944095};\\\", \\\"{x:572,y:678,t:1526918944113};\\\", \\\"{x:576,y:681,t:1526918944128};\\\", \\\"{x:577,y:681,t:1526918944154};\\\", \\\"{x:577,y:682,t:1526918944162};\\\", \\\"{x:577,y:684,t:1526918944178};\\\", \\\"{x:577,y:686,t:1526918944195};\\\", \\\"{x:577,y:689,t:1526918944212};\\\", \\\"{x:577,y:692,t:1526918944228};\\\", \\\"{x:577,y:693,t:1526918944245};\\\", \\\"{x:577,y:695,t:1526918944262};\\\", \\\"{x:572,y:696,t:1526918944278};\\\", \\\"{x:560,y:700,t:1526918944296};\\\", \\\"{x:549,y:702,t:1526918944313};\\\", \\\"{x:537,y:704,t:1526918944328};\\\", \\\"{x:525,y:706,t:1526918944345};\\\", \\\"{x:518,y:707,t:1526918944361};\\\", \\\"{x:513,y:708,t:1526918944378};\\\", \\\"{x:512,y:709,t:1526918944402};\\\", \\\"{x:511,y:709,t:1526918944411};\\\", \\\"{x:509,y:710,t:1526918944428};\\\", \\\"{x:508,y:712,t:1526918944446};\\\", \\\"{x:506,y:713,t:1526918944461};\\\", \\\"{x:505,y:714,t:1526918944478};\\\", \\\"{x:504,y:714,t:1526918944587};\\\", \\\"{x:503,y:714,t:1526918944627};\\\", \\\"{x:502,y:714,t:1526918944651};\\\", \\\"{x:501,y:714,t:1526918944723};\\\", \\\"{x:500,y:714,t:1526918944844};\\\", \\\"{x:498,y:714,t:1526918945033};\\\", \\\"{x:497,y:714,t:1526918945115};\\\" ] }, { \\\"rt\\\": 24689, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 350896, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -A -A -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:713,t:1526918948091};\\\", \\\"{x:497,y:712,t:1526918948387};\\\", \\\"{x:497,y:711,t:1526918948403};\\\", \\\"{x:496,y:711,t:1526918948499};\\\", \\\"{x:496,y:709,t:1526918949036};\\\", \\\"{x:502,y:708,t:1526918949050};\\\", \\\"{x:519,y:701,t:1526918949066};\\\", \\\"{x:564,y:695,t:1526918949084};\\\", \\\"{x:595,y:690,t:1526918949099};\\\", \\\"{x:622,y:687,t:1526918949115};\\\", \\\"{x:657,y:686,t:1526918949133};\\\", \\\"{x:683,y:684,t:1526918949150};\\\", \\\"{x:709,y:683,t:1526918949166};\\\", \\\"{x:736,y:683,t:1526918949183};\\\", \\\"{x:771,y:680,t:1526918949200};\\\", \\\"{x:811,y:680,t:1526918949217};\\\", \\\"{x:856,y:680,t:1526918949233};\\\", \\\"{x:906,y:680,t:1526918949249};\\\", \\\"{x:976,y:680,t:1526918949267};\\\", \\\"{x:1024,y:680,t:1526918949283};\\\", \\\"{x:1082,y:680,t:1526918949300};\\\", \\\"{x:1121,y:680,t:1526918949317};\\\", \\\"{x:1153,y:680,t:1526918949333};\\\", \\\"{x:1177,y:681,t:1526918949350};\\\", \\\"{x:1187,y:682,t:1526918949367};\\\", \\\"{x:1193,y:682,t:1526918949383};\\\", \\\"{x:1199,y:682,t:1526918949400};\\\", \\\"{x:1206,y:682,t:1526918949417};\\\", \\\"{x:1218,y:682,t:1526918949433};\\\", \\\"{x:1231,y:682,t:1526918949450};\\\", \\\"{x:1252,y:686,t:1526918949467};\\\", \\\"{x:1278,y:698,t:1526918949483};\\\", \\\"{x:1314,y:719,t:1526918949500};\\\", \\\"{x:1341,y:737,t:1526918949517};\\\", \\\"{x:1365,y:754,t:1526918949534};\\\", \\\"{x:1385,y:775,t:1526918949550};\\\", \\\"{x:1403,y:799,t:1526918949567};\\\", \\\"{x:1416,y:818,t:1526918949584};\\\", \\\"{x:1420,y:829,t:1526918949600};\\\", \\\"{x:1420,y:837,t:1526918949617};\\\", \\\"{x:1420,y:841,t:1526918949634};\\\", \\\"{x:1420,y:843,t:1526918949650};\\\", \\\"{x:1407,y:849,t:1526918949667};\\\", \\\"{x:1390,y:853,t:1526918949683};\\\", \\\"{x:1365,y:855,t:1526918949700};\\\", \\\"{x:1344,y:859,t:1526918949717};\\\", \\\"{x:1314,y:860,t:1526918949734};\\\", \\\"{x:1287,y:860,t:1526918949750};\\\", \\\"{x:1264,y:860,t:1526918949767};\\\", \\\"{x:1251,y:860,t:1526918949784};\\\", \\\"{x:1241,y:860,t:1526918949801};\\\", \\\"{x:1233,y:859,t:1526918949817};\\\", \\\"{x:1230,y:859,t:1526918949834};\\\", \\\"{x:1229,y:858,t:1526918949906};\\\", \\\"{x:1229,y:857,t:1526918949922};\\\", \\\"{x:1228,y:855,t:1526918949933};\\\", \\\"{x:1226,y:852,t:1526918949950};\\\", \\\"{x:1225,y:849,t:1526918949967};\\\", \\\"{x:1222,y:845,t:1526918949984};\\\", \\\"{x:1221,y:843,t:1526918950000};\\\", \\\"{x:1218,y:839,t:1526918950016};\\\", \\\"{x:1215,y:836,t:1526918950033};\\\", \\\"{x:1212,y:833,t:1526918950052};\\\", \\\"{x:1211,y:831,t:1526918950083};\\\", \\\"{x:1210,y:829,t:1526918950139};\\\", \\\"{x:1209,y:828,t:1526918950163};\\\", \\\"{x:1209,y:827,t:1526918950404};\\\", \\\"{x:1210,y:827,t:1526918950451};\\\", \\\"{x:1211,y:827,t:1526918950699};\\\", \\\"{x:1212,y:827,t:1526918950723};\\\", \\\"{x:1213,y:827,t:1526918953307};\\\", \\\"{x:1213,y:826,t:1526918953667};\\\", \\\"{x:1216,y:825,t:1526918953675};\\\", \\\"{x:1222,y:823,t:1526918953690};\\\", \\\"{x:1238,y:818,t:1526918953705};\\\", \\\"{x:1252,y:817,t:1526918953721};\\\", \\\"{x:1266,y:816,t:1526918953738};\\\", \\\"{x:1274,y:815,t:1526918953755};\\\", \\\"{x:1277,y:815,t:1526918953772};\\\", \\\"{x:1281,y:815,t:1526918953788};\\\", \\\"{x:1285,y:815,t:1526918953806};\\\", \\\"{x:1287,y:815,t:1526918953821};\\\", \\\"{x:1288,y:815,t:1526918953838};\\\", \\\"{x:1291,y:816,t:1526918953855};\\\", \\\"{x:1292,y:818,t:1526918953871};\\\", \\\"{x:1293,y:821,t:1526918953888};\\\", \\\"{x:1294,y:822,t:1526918953905};\\\", \\\"{x:1295,y:824,t:1526918953923};\\\", \\\"{x:1296,y:825,t:1526918953955};\\\", \\\"{x:1296,y:826,t:1526918953972};\\\", \\\"{x:1296,y:827,t:1526918953988};\\\", \\\"{x:1296,y:830,t:1526918954006};\\\", \\\"{x:1297,y:831,t:1526918954023};\\\", \\\"{x:1297,y:832,t:1526918954038};\\\", \\\"{x:1295,y:832,t:1526918954300};\\\", \\\"{x:1294,y:832,t:1526918954340};\\\", \\\"{x:1292,y:832,t:1526918954379};\\\", \\\"{x:1289,y:832,t:1526918954403};\\\", \\\"{x:1287,y:832,t:1526918954411};\\\", \\\"{x:1285,y:832,t:1526918954423};\\\", \\\"{x:1284,y:832,t:1526918954439};\\\", \\\"{x:1281,y:832,t:1526918954455};\\\", \\\"{x:1280,y:832,t:1526918954472};\\\", \\\"{x:1279,y:832,t:1526918954489};\\\", \\\"{x:1278,y:830,t:1526918954835};\\\", \\\"{x:1278,y:829,t:1526918954858};\\\", \\\"{x:1278,y:828,t:1526918954874};\\\", \\\"{x:1278,y:827,t:1526918954890};\\\", \\\"{x:1278,y:826,t:1526918955339};\\\", \\\"{x:1279,y:826,t:1526918955883};\\\", \\\"{x:1279,y:827,t:1526918955963};\\\", \\\"{x:1281,y:827,t:1526918956883};\\\", \\\"{x:1281,y:826,t:1526918956891};\\\", \\\"{x:1283,y:824,t:1526918956909};\\\", \\\"{x:1284,y:823,t:1526918956925};\\\", \\\"{x:1285,y:822,t:1526918956942};\\\", \\\"{x:1287,y:821,t:1526918956958};\\\", \\\"{x:1290,y:820,t:1526918956975};\\\", \\\"{x:1292,y:820,t:1526918956991};\\\", \\\"{x:1295,y:820,t:1526918957008};\\\", \\\"{x:1298,y:819,t:1526918957025};\\\", \\\"{x:1301,y:819,t:1526918957043};\\\", \\\"{x:1304,y:819,t:1526918957058};\\\", \\\"{x:1307,y:819,t:1526918957076};\\\", \\\"{x:1309,y:819,t:1526918957093};\\\", \\\"{x:1312,y:819,t:1526918957109};\\\", \\\"{x:1320,y:822,t:1526918957126};\\\", \\\"{x:1327,y:826,t:1526918957143};\\\", \\\"{x:1333,y:829,t:1526918957159};\\\", \\\"{x:1337,y:832,t:1526918957176};\\\", \\\"{x:1343,y:836,t:1526918957192};\\\", \\\"{x:1346,y:841,t:1526918957208};\\\", \\\"{x:1348,y:844,t:1526918957225};\\\", \\\"{x:1352,y:849,t:1526918957242};\\\", \\\"{x:1356,y:853,t:1526918957259};\\\", \\\"{x:1356,y:854,t:1526918957276};\\\", \\\"{x:1356,y:855,t:1526918957293};\\\", \\\"{x:1356,y:859,t:1526918957308};\\\", \\\"{x:1358,y:863,t:1526918957325};\\\", \\\"{x:1358,y:869,t:1526918957342};\\\", \\\"{x:1359,y:875,t:1526918957359};\\\", \\\"{x:1359,y:879,t:1526918957376};\\\", \\\"{x:1359,y:885,t:1526918957392};\\\", \\\"{x:1359,y:890,t:1526918957409};\\\", \\\"{x:1359,y:895,t:1526918957425};\\\", \\\"{x:1359,y:902,t:1526918957442};\\\", \\\"{x:1361,y:906,t:1526918957459};\\\", \\\"{x:1361,y:907,t:1526918957514};\\\", \\\"{x:1361,y:908,t:1526918957579};\\\", \\\"{x:1360,y:908,t:1526918957602};\\\", \\\"{x:1359,y:908,t:1526918957610};\\\", \\\"{x:1358,y:908,t:1526918957635};\\\", \\\"{x:1357,y:907,t:1526918957651};\\\", \\\"{x:1356,y:906,t:1526918957659};\\\", \\\"{x:1355,y:904,t:1526918957676};\\\", \\\"{x:1355,y:903,t:1526918957692};\\\", \\\"{x:1353,y:902,t:1526918957709};\\\", \\\"{x:1352,y:901,t:1526918957726};\\\", \\\"{x:1350,y:901,t:1526918957742};\\\", \\\"{x:1349,y:899,t:1526918957759};\\\", \\\"{x:1348,y:899,t:1526918957776};\\\", \\\"{x:1347,y:898,t:1526918957792};\\\", \\\"{x:1346,y:897,t:1526918957827};\\\", \\\"{x:1346,y:896,t:1526918957842};\\\", \\\"{x:1346,y:895,t:1526918957875};\\\", \\\"{x:1344,y:893,t:1526918957891};\\\", \\\"{x:1345,y:893,t:1526918958163};\\\", \\\"{x:1346,y:893,t:1526918958747};\\\", \\\"{x:1347,y:893,t:1526918959659};\\\", \\\"{x:1346,y:893,t:1526918962234};\\\", \\\"{x:1327,y:891,t:1526918962247};\\\", \\\"{x:1243,y:878,t:1526918962264};\\\", \\\"{x:1132,y:862,t:1526918962280};\\\", \\\"{x:994,y:847,t:1526918962297};\\\", \\\"{x:769,y:814,t:1526918962314};\\\", \\\"{x:622,y:795,t:1526918962330};\\\", \\\"{x:498,y:776,t:1526918962346};\\\", \\\"{x:408,y:759,t:1526918962364};\\\", \\\"{x:364,y:749,t:1526918962381};\\\", \\\"{x:336,y:737,t:1526918962396};\\\", \\\"{x:317,y:728,t:1526918962413};\\\", \\\"{x:298,y:714,t:1526918962431};\\\", \\\"{x:276,y:701,t:1526918962447};\\\", \\\"{x:266,y:692,t:1526918962464};\\\", \\\"{x:260,y:682,t:1526918962481};\\\", \\\"{x:253,y:669,t:1526918962497};\\\", \\\"{x:248,y:649,t:1526918962514};\\\", \\\"{x:248,y:632,t:1526918962531};\\\", \\\"{x:251,y:618,t:1526918962547};\\\", \\\"{x:260,y:606,t:1526918962560};\\\", \\\"{x:281,y:589,t:1526918962577};\\\", \\\"{x:322,y:571,t:1526918962593};\\\", \\\"{x:392,y:545,t:1526918962610};\\\", \\\"{x:442,y:529,t:1526918962627};\\\", \\\"{x:508,y:524,t:1526918962644};\\\", \\\"{x:584,y:521,t:1526918962659};\\\", \\\"{x:665,y:521,t:1526918962677};\\\", \\\"{x:740,y:530,t:1526918962693};\\\", \\\"{x:794,y:541,t:1526918962710};\\\", \\\"{x:825,y:553,t:1526918962728};\\\", \\\"{x:840,y:565,t:1526918962743};\\\", \\\"{x:846,y:571,t:1526918962760};\\\", \\\"{x:850,y:581,t:1526918962777};\\\", \\\"{x:850,y:587,t:1526918962794};\\\", \\\"{x:850,y:600,t:1526918962810};\\\", \\\"{x:850,y:609,t:1526918962827};\\\", \\\"{x:850,y:615,t:1526918962844};\\\", \\\"{x:850,y:621,t:1526918962860};\\\", \\\"{x:844,y:629,t:1526918962876};\\\", \\\"{x:832,y:639,t:1526918962893};\\\", \\\"{x:816,y:649,t:1526918962909};\\\", \\\"{x:796,y:658,t:1526918962927};\\\", \\\"{x:770,y:661,t:1526918962943};\\\", \\\"{x:741,y:666,t:1526918962960};\\\", \\\"{x:716,y:671,t:1526918962977};\\\", \\\"{x:697,y:673,t:1526918962993};\\\", \\\"{x:672,y:676,t:1526918963010};\\\", \\\"{x:653,y:676,t:1526918963026};\\\", \\\"{x:627,y:677,t:1526918963043};\\\", \\\"{x:602,y:678,t:1526918963060};\\\", \\\"{x:578,y:678,t:1526918963076};\\\", \\\"{x:547,y:680,t:1526918963093};\\\", \\\"{x:514,y:683,t:1526918963110};\\\", \\\"{x:472,y:683,t:1526918963127};\\\", \\\"{x:430,y:683,t:1526918963143};\\\", \\\"{x:398,y:683,t:1526918963160};\\\", \\\"{x:378,y:683,t:1526918963177};\\\", \\\"{x:356,y:683,t:1526918963193};\\\", \\\"{x:334,y:683,t:1526918963211};\\\", \\\"{x:308,y:679,t:1526918963227};\\\", \\\"{x:283,y:674,t:1526918963244};\\\", \\\"{x:262,y:668,t:1526918963260};\\\", \\\"{x:235,y:665,t:1526918963277};\\\", \\\"{x:206,y:661,t:1526918963293};\\\", \\\"{x:190,y:658,t:1526918963310};\\\", \\\"{x:181,y:657,t:1526918963327};\\\", \\\"{x:178,y:657,t:1526918963343};\\\", \\\"{x:177,y:655,t:1526918963360};\\\", \\\"{x:175,y:655,t:1526918963379};\\\", \\\"{x:173,y:654,t:1526918963403};\\\", \\\"{x:173,y:653,t:1526918963515};\\\", \\\"{x:173,y:652,t:1526918963527};\\\", \\\"{x:173,y:648,t:1526918963545};\\\", \\\"{x:173,y:643,t:1526918963560};\\\", \\\"{x:173,y:638,t:1526918963577};\\\", \\\"{x:173,y:631,t:1526918963594};\\\", \\\"{x:173,y:626,t:1526918963611};\\\", \\\"{x:173,y:620,t:1526918963628};\\\", \\\"{x:173,y:615,t:1526918963644};\\\", \\\"{x:173,y:611,t:1526918963662};\\\", \\\"{x:173,y:606,t:1526918963677};\\\", \\\"{x:173,y:601,t:1526918963694};\\\", \\\"{x:173,y:599,t:1526918963711};\\\", \\\"{x:171,y:596,t:1526918963728};\\\", \\\"{x:170,y:592,t:1526918963744};\\\", \\\"{x:170,y:589,t:1526918963761};\\\", \\\"{x:170,y:582,t:1526918963778};\\\", \\\"{x:169,y:578,t:1526918963795};\\\", \\\"{x:169,y:575,t:1526918963811};\\\", \\\"{x:169,y:571,t:1526918963828};\\\", \\\"{x:181,y:559,t:1526918963844};\\\", \\\"{x:212,y:543,t:1526918963862};\\\", \\\"{x:248,y:532,t:1526918963879};\\\", \\\"{x:282,y:523,t:1526918963895};\\\", \\\"{x:301,y:521,t:1526918963910};\\\", \\\"{x:304,y:521,t:1526918963928};\\\", \\\"{x:305,y:525,t:1526918963944};\\\", \\\"{x:299,y:534,t:1526918963961};\\\", \\\"{x:273,y:557,t:1526918963979};\\\", \\\"{x:252,y:567,t:1526918963994};\\\", \\\"{x:221,y:574,t:1526918964011};\\\", \\\"{x:189,y:577,t:1526918964030};\\\", \\\"{x:165,y:577,t:1526918964045};\\\", \\\"{x:146,y:577,t:1526918964061};\\\", \\\"{x:139,y:577,t:1526918964078};\\\", \\\"{x:132,y:577,t:1526918964095};\\\", \\\"{x:130,y:577,t:1526918964111};\\\", \\\"{x:129,y:577,t:1526918964219};\\\", \\\"{x:129,y:576,t:1526918964242};\\\", \\\"{x:129,y:575,t:1526918964251};\\\", \\\"{x:129,y:574,t:1526918964261};\\\", \\\"{x:129,y:572,t:1526918964278};\\\", \\\"{x:132,y:568,t:1526918964295};\\\", \\\"{x:139,y:563,t:1526918964311};\\\", \\\"{x:148,y:558,t:1526918964328};\\\", \\\"{x:151,y:556,t:1526918964345};\\\", \\\"{x:154,y:556,t:1526918964360};\\\", \\\"{x:157,y:556,t:1526918964377};\\\", \\\"{x:158,y:556,t:1526918964402};\\\", \\\"{x:159,y:556,t:1526918964411};\\\", \\\"{x:160,y:556,t:1526918964428};\\\", \\\"{x:161,y:556,t:1526918964450};\\\", \\\"{x:162,y:556,t:1526918964474};\\\", \\\"{x:163,y:556,t:1526918964490};\\\", \\\"{x:164,y:556,t:1526918964545};\\\", \\\"{x:165,y:556,t:1526918964562};\\\", \\\"{x:165,y:556,t:1526918964656};\\\", \\\"{x:165,y:555,t:1526918964730};\\\", \\\"{x:166,y:555,t:1526918964745};\\\", \\\"{x:191,y:553,t:1526918964762};\\\", \\\"{x:219,y:555,t:1526918964778};\\\", \\\"{x:259,y:562,t:1526918964795};\\\", \\\"{x:323,y:579,t:1526918964812};\\\", \\\"{x:383,y:594,t:1526918964829};\\\", \\\"{x:450,y:615,t:1526918964845};\\\", \\\"{x:512,y:632,t:1526918964863};\\\", \\\"{x:574,y:657,t:1526918964879};\\\", \\\"{x:622,y:692,t:1526918964895};\\\", \\\"{x:662,y:719,t:1526918964912};\\\", \\\"{x:680,y:735,t:1526918964929};\\\", \\\"{x:692,y:746,t:1526918964945};\\\", \\\"{x:698,y:752,t:1526918964962};\\\", \\\"{x:698,y:753,t:1526918964987};\\\", \\\"{x:698,y:754,t:1526918965011};\\\", \\\"{x:698,y:756,t:1526918965018};\\\", \\\"{x:698,y:757,t:1526918965030};\\\", \\\"{x:698,y:761,t:1526918965046};\\\", \\\"{x:686,y:766,t:1526918965062};\\\", \\\"{x:666,y:769,t:1526918965079};\\\", \\\"{x:638,y:769,t:1526918965096};\\\", \\\"{x:612,y:769,t:1526918965112};\\\", \\\"{x:582,y:763,t:1526918965129};\\\", \\\"{x:565,y:755,t:1526918965145};\\\", \\\"{x:549,y:743,t:1526918965163};\\\", \\\"{x:545,y:740,t:1526918965178};\\\", \\\"{x:543,y:738,t:1526918965195};\\\", \\\"{x:541,y:736,t:1526918965212};\\\", \\\"{x:541,y:734,t:1526918965231};\\\", \\\"{x:541,y:733,t:1526918965246};\\\", \\\"{x:540,y:731,t:1526918965262};\\\", \\\"{x:539,y:729,t:1526918965279};\\\", \\\"{x:538,y:728,t:1526918965296};\\\", \\\"{x:536,y:725,t:1526918965312};\\\", \\\"{x:533,y:723,t:1526918965329};\\\", \\\"{x:529,y:721,t:1526918965346};\\\", \\\"{x:527,y:720,t:1526918965363};\\\", \\\"{x:526,y:720,t:1526918965379};\\\", \\\"{x:525,y:720,t:1526918966003};\\\" ] }, { \\\"rt\\\": 63076, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 415267, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-B -04 PM-E -D -D -D -E -07 PM-02 PM-04 PM-04 PM-03 PM-K -K -K -U -H -H -01 PM-F -F -F -01 PM-O -I -I -O -O -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:720,t:1526918974307};\\\", \\\"{x:580,y:716,t:1526918974326};\\\", \\\"{x:610,y:711,t:1526918974338};\\\", \\\"{x:722,y:697,t:1526918974354};\\\", \\\"{x:757,y:692,t:1526918974370};\\\", \\\"{x:831,y:689,t:1526918974385};\\\", \\\"{x:876,y:689,t:1526918974402};\\\", \\\"{x:918,y:683,t:1526918974420};\\\", \\\"{x:979,y:675,t:1526918974436};\\\", \\\"{x:1054,y:664,t:1526918974454};\\\", \\\"{x:1149,y:648,t:1526918974469};\\\", \\\"{x:1249,y:635,t:1526918974486};\\\", \\\"{x:1359,y:621,t:1526918974503};\\\", \\\"{x:1466,y:615,t:1526918974519};\\\", \\\"{x:1564,y:611,t:1526918974536};\\\", \\\"{x:1641,y:611,t:1526918974553};\\\", \\\"{x:1711,y:611,t:1526918974569};\\\", \\\"{x:1759,y:611,t:1526918974586};\\\", \\\"{x:1773,y:613,t:1526918974603};\\\", \\\"{x:1774,y:614,t:1526918975164};\\\", \\\"{x:1774,y:615,t:1526918975259};\\\", \\\"{x:1773,y:616,t:1526918975379};\\\", \\\"{x:1773,y:618,t:1526918975459};\\\", \\\"{x:1772,y:618,t:1526918975475};\\\", \\\"{x:1771,y:619,t:1526918975491};\\\", \\\"{x:1771,y:620,t:1526918975505};\\\", \\\"{x:1770,y:621,t:1526918975521};\\\", \\\"{x:1769,y:621,t:1526918975538};\\\", \\\"{x:1767,y:623,t:1526918975554};\\\", \\\"{x:1766,y:624,t:1526918975579};\\\", \\\"{x:1765,y:624,t:1526918975588};\\\", \\\"{x:1764,y:625,t:1526918975605};\\\", \\\"{x:1764,y:626,t:1526918976131};\\\", \\\"{x:1763,y:627,t:1526918976139};\\\", \\\"{x:1759,y:632,t:1526918976155};\\\", \\\"{x:1747,y:641,t:1526918976172};\\\", \\\"{x:1730,y:661,t:1526918976189};\\\", \\\"{x:1704,y:685,t:1526918976205};\\\", \\\"{x:1668,y:708,t:1526918976222};\\\", \\\"{x:1634,y:732,t:1526918976239};\\\", \\\"{x:1615,y:746,t:1526918976256};\\\", \\\"{x:1600,y:756,t:1526918976272};\\\", \\\"{x:1587,y:764,t:1526918976289};\\\", \\\"{x:1580,y:770,t:1526918976307};\\\", \\\"{x:1576,y:775,t:1526918976322};\\\", \\\"{x:1574,y:777,t:1526918976339};\\\", \\\"{x:1573,y:778,t:1526918976356};\\\", \\\"{x:1573,y:779,t:1526918976372};\\\", \\\"{x:1572,y:780,t:1526918976389};\\\", \\\"{x:1571,y:780,t:1526918976406};\\\", \\\"{x:1572,y:781,t:1526918979686};\\\", \\\"{x:1572,y:783,t:1526918979697};\\\", \\\"{x:1572,y:786,t:1526918979714};\\\", \\\"{x:1572,y:788,t:1526918979730};\\\", \\\"{x:1572,y:791,t:1526918979747};\\\", \\\"{x:1573,y:791,t:1526918979815};\\\", \\\"{x:1573,y:793,t:1526918979830};\\\", \\\"{x:1573,y:794,t:1526918979847};\\\", \\\"{x:1573,y:796,t:1526918979863};\\\", \\\"{x:1574,y:799,t:1526918979880};\\\", \\\"{x:1575,y:802,t:1526918979897};\\\", \\\"{x:1577,y:804,t:1526918979914};\\\", \\\"{x:1578,y:806,t:1526918979931};\\\", \\\"{x:1580,y:807,t:1526918979947};\\\", \\\"{x:1584,y:809,t:1526918979964};\\\", \\\"{x:1586,y:809,t:1526918979981};\\\", \\\"{x:1589,y:810,t:1526918979997};\\\", \\\"{x:1594,y:812,t:1526918980014};\\\", \\\"{x:1597,y:814,t:1526918980030};\\\", \\\"{x:1603,y:817,t:1526918980047};\\\", \\\"{x:1609,y:821,t:1526918980064};\\\", \\\"{x:1616,y:825,t:1526918980081};\\\", \\\"{x:1626,y:834,t:1526918980096};\\\", \\\"{x:1634,y:840,t:1526918980114};\\\", \\\"{x:1642,y:847,t:1526918980131};\\\", \\\"{x:1648,y:854,t:1526918980147};\\\", \\\"{x:1653,y:862,t:1526918980164};\\\", \\\"{x:1658,y:872,t:1526918980181};\\\", \\\"{x:1667,y:890,t:1526918980199};\\\", \\\"{x:1673,y:909,t:1526918980214};\\\", \\\"{x:1678,y:926,t:1526918980231};\\\", \\\"{x:1682,y:945,t:1526918980248};\\\", \\\"{x:1682,y:963,t:1526918980264};\\\", \\\"{x:1682,y:977,t:1526918980281};\\\", \\\"{x:1682,y:987,t:1526918980299};\\\", \\\"{x:1682,y:994,t:1526918980314};\\\", \\\"{x:1682,y:1000,t:1526918980331};\\\", \\\"{x:1681,y:1006,t:1526918980348};\\\", \\\"{x:1677,y:1013,t:1526918980364};\\\", \\\"{x:1672,y:1019,t:1526918980381};\\\", \\\"{x:1664,y:1027,t:1526918980398};\\\", \\\"{x:1661,y:1031,t:1526918980414};\\\", \\\"{x:1658,y:1032,t:1526918980431};\\\", \\\"{x:1656,y:1033,t:1526918980454};\\\", \\\"{x:1655,y:1034,t:1526918980471};\\\", \\\"{x:1654,y:1034,t:1526918980485};\\\", \\\"{x:1653,y:1034,t:1526918980497};\\\", \\\"{x:1652,y:1034,t:1526918980514};\\\", \\\"{x:1648,y:1032,t:1526918980530};\\\", \\\"{x:1643,y:1028,t:1526918980547};\\\", \\\"{x:1640,y:1026,t:1526918980564};\\\", \\\"{x:1638,y:1024,t:1526918980580};\\\", \\\"{x:1635,y:1022,t:1526918980597};\\\", \\\"{x:1633,y:1020,t:1526918980614};\\\", \\\"{x:1631,y:1017,t:1526918980631};\\\", \\\"{x:1628,y:1013,t:1526918980648};\\\", \\\"{x:1624,y:1010,t:1526918980665};\\\", \\\"{x:1620,y:1007,t:1526918980680};\\\", \\\"{x:1618,y:1005,t:1526918980697};\\\", \\\"{x:1615,y:1003,t:1526918980714};\\\", \\\"{x:1613,y:1000,t:1526918980731};\\\", \\\"{x:1613,y:997,t:1526918980747};\\\", \\\"{x:1608,y:990,t:1526918980765};\\\", \\\"{x:1605,y:984,t:1526918980782};\\\", \\\"{x:1603,y:980,t:1526918980797};\\\", \\\"{x:1601,y:975,t:1526918980815};\\\", \\\"{x:1600,y:972,t:1526918980831};\\\", \\\"{x:1599,y:968,t:1526918980848};\\\", \\\"{x:1598,y:964,t:1526918980865};\\\", \\\"{x:1597,y:960,t:1526918980882};\\\", \\\"{x:1596,y:956,t:1526918980898};\\\", \\\"{x:1596,y:954,t:1526918980915};\\\", \\\"{x:1596,y:950,t:1526918980932};\\\", \\\"{x:1596,y:948,t:1526918980947};\\\", \\\"{x:1596,y:947,t:1526918980964};\\\", \\\"{x:1596,y:945,t:1526918980982};\\\", \\\"{x:1596,y:944,t:1526918981023};\\\", \\\"{x:1596,y:943,t:1526918981110};\\\", \\\"{x:1596,y:942,t:1526918981118};\\\", \\\"{x:1596,y:941,t:1526918981132};\\\", \\\"{x:1596,y:938,t:1526918981149};\\\", \\\"{x:1596,y:934,t:1526918981165};\\\", \\\"{x:1596,y:925,t:1526918981182};\\\", \\\"{x:1594,y:918,t:1526918981199};\\\", \\\"{x:1592,y:911,t:1526918981214};\\\", \\\"{x:1590,y:907,t:1526918981231};\\\", \\\"{x:1590,y:902,t:1526918981249};\\\", \\\"{x:1589,y:899,t:1526918981264};\\\", \\\"{x:1587,y:895,t:1526918981281};\\\", \\\"{x:1587,y:892,t:1526918981298};\\\", \\\"{x:1587,y:889,t:1526918981316};\\\", \\\"{x:1585,y:884,t:1526918981332};\\\", \\\"{x:1584,y:877,t:1526918981348};\\\", \\\"{x:1580,y:869,t:1526918981366};\\\", \\\"{x:1580,y:863,t:1526918981381};\\\", \\\"{x:1578,y:853,t:1526918981399};\\\", \\\"{x:1577,y:843,t:1526918981415};\\\", \\\"{x:1575,y:832,t:1526918981431};\\\", \\\"{x:1572,y:813,t:1526918981448};\\\", \\\"{x:1571,y:796,t:1526918981466};\\\", \\\"{x:1570,y:779,t:1526918981482};\\\", \\\"{x:1570,y:753,t:1526918981498};\\\", \\\"{x:1570,y:729,t:1526918981516};\\\", \\\"{x:1570,y:702,t:1526918981532};\\\", \\\"{x:1570,y:675,t:1526918981548};\\\", \\\"{x:1572,y:632,t:1526918981566};\\\", \\\"{x:1575,y:605,t:1526918981582};\\\", \\\"{x:1581,y:577,t:1526918981599};\\\", \\\"{x:1585,y:556,t:1526918981616};\\\", \\\"{x:1587,y:538,t:1526918981633};\\\", \\\"{x:1587,y:523,t:1526918981648};\\\", \\\"{x:1589,y:510,t:1526918981666};\\\", \\\"{x:1589,y:502,t:1526918981683};\\\", \\\"{x:1589,y:497,t:1526918981699};\\\", \\\"{x:1589,y:493,t:1526918981715};\\\", \\\"{x:1589,y:490,t:1526918981733};\\\", \\\"{x:1589,y:489,t:1526918981749};\\\", \\\"{x:1589,y:486,t:1526918981766};\\\", \\\"{x:1589,y:484,t:1526918981782};\\\", \\\"{x:1589,y:482,t:1526918981799};\\\", \\\"{x:1588,y:480,t:1526918981815};\\\", \\\"{x:1588,y:476,t:1526918981833};\\\", \\\"{x:1587,y:472,t:1526918981850};\\\", \\\"{x:1586,y:466,t:1526918981865};\\\", \\\"{x:1586,y:463,t:1526918981883};\\\", \\\"{x:1585,y:462,t:1526918981899};\\\", \\\"{x:1585,y:465,t:1526918982045};\\\", \\\"{x:1583,y:468,t:1526918982053};\\\", \\\"{x:1583,y:470,t:1526918982065};\\\", \\\"{x:1582,y:480,t:1526918982083};\\\", \\\"{x:1581,y:489,t:1526918982099};\\\", \\\"{x:1580,y:497,t:1526918982116};\\\", \\\"{x:1580,y:505,t:1526918982132};\\\", \\\"{x:1580,y:515,t:1526918982149};\\\", \\\"{x:1580,y:523,t:1526918982166};\\\", \\\"{x:1580,y:538,t:1526918982182};\\\", \\\"{x:1586,y:562,t:1526918982200};\\\", \\\"{x:1595,y:587,t:1526918982217};\\\", \\\"{x:1603,y:608,t:1526918982232};\\\", \\\"{x:1613,y:631,t:1526918982249};\\\", \\\"{x:1619,y:653,t:1526918982267};\\\", \\\"{x:1630,y:684,t:1526918982282};\\\", \\\"{x:1648,y:725,t:1526918982300};\\\", \\\"{x:1663,y:776,t:1526918982317};\\\", \\\"{x:1677,y:821,t:1526918982333};\\\", \\\"{x:1689,y:896,t:1526918982350};\\\", \\\"{x:1699,y:952,t:1526918982366};\\\", \\\"{x:1707,y:1008,t:1526918982382};\\\", \\\"{x:1715,y:1067,t:1526918982400};\\\", \\\"{x:1723,y:1123,t:1526918982416};\\\", \\\"{x:1730,y:1175,t:1526918982434};\\\", \\\"{x:1732,y:1199,t:1526918982450};\\\", \\\"{x:1736,y:1199,t:1526918982466};\\\", \\\"{x:1734,y:1199,t:1526918982510};\\\", \\\"{x:1733,y:1199,t:1526918982517};\\\", \\\"{x:1730,y:1199,t:1526918982529};\\\", \\\"{x:1726,y:1199,t:1526918982546};\\\", \\\"{x:1718,y:1198,t:1526918982562};\\\", \\\"{x:1708,y:1185,t:1526918982579};\\\", \\\"{x:1693,y:1165,t:1526918982597};\\\", \\\"{x:1681,y:1146,t:1526918982612};\\\", \\\"{x:1650,y:1099,t:1526918982629};\\\", \\\"{x:1629,y:1066,t:1526918982646};\\\", \\\"{x:1616,y:1038,t:1526918982664};\\\", \\\"{x:1604,y:1012,t:1526918982680};\\\", \\\"{x:1595,y:988,t:1526918982697};\\\", \\\"{x:1584,y:963,t:1526918982714};\\\", \\\"{x:1578,y:943,t:1526918982730};\\\", \\\"{x:1574,y:931,t:1526918982746};\\\", \\\"{x:1569,y:919,t:1526918982764};\\\", \\\"{x:1567,y:914,t:1526918982780};\\\", \\\"{x:1565,y:909,t:1526918982797};\\\", \\\"{x:1565,y:913,t:1526918982862};\\\", \\\"{x:1569,y:923,t:1526918982880};\\\", \\\"{x:1574,y:933,t:1526918982896};\\\", \\\"{x:1580,y:942,t:1526918982913};\\\", \\\"{x:1590,y:956,t:1526918982931};\\\", \\\"{x:1601,y:967,t:1526918982946};\\\", \\\"{x:1607,y:973,t:1526918982964};\\\", \\\"{x:1608,y:973,t:1526918983013};\\\", \\\"{x:1608,y:972,t:1526918983030};\\\", \\\"{x:1608,y:970,t:1526918983046};\\\", \\\"{x:1610,y:965,t:1526918983064};\\\", \\\"{x:1612,y:961,t:1526918983081};\\\", \\\"{x:1612,y:957,t:1526918983097};\\\", \\\"{x:1614,y:952,t:1526918983113};\\\", \\\"{x:1614,y:950,t:1526918983130};\\\", \\\"{x:1614,y:948,t:1526918983146};\\\", \\\"{x:1615,y:945,t:1526918983163};\\\", \\\"{x:1615,y:944,t:1526918983181};\\\", \\\"{x:1615,y:942,t:1526918983197};\\\", \\\"{x:1615,y:940,t:1526918983214};\\\", \\\"{x:1615,y:938,t:1526918983230};\\\", \\\"{x:1615,y:935,t:1526918983247};\\\", \\\"{x:1615,y:931,t:1526918983264};\\\", \\\"{x:1615,y:928,t:1526918983281};\\\", \\\"{x:1615,y:924,t:1526918983296};\\\", \\\"{x:1615,y:916,t:1526918983314};\\\", \\\"{x:1615,y:909,t:1526918983331};\\\", \\\"{x:1615,y:899,t:1526918983347};\\\", \\\"{x:1615,y:889,t:1526918983364};\\\", \\\"{x:1615,y:881,t:1526918983381};\\\", \\\"{x:1615,y:874,t:1526918983397};\\\", \\\"{x:1616,y:866,t:1526918983414};\\\", \\\"{x:1618,y:859,t:1526918983431};\\\", \\\"{x:1618,y:856,t:1526918983447};\\\", \\\"{x:1618,y:852,t:1526918983464};\\\", \\\"{x:1618,y:849,t:1526918983480};\\\", \\\"{x:1618,y:848,t:1526918983497};\\\", \\\"{x:1618,y:845,t:1526918983514};\\\", \\\"{x:1618,y:842,t:1526918983531};\\\", \\\"{x:1618,y:838,t:1526918983548};\\\", \\\"{x:1618,y:834,t:1526918983564};\\\", \\\"{x:1618,y:831,t:1526918983582};\\\", \\\"{x:1618,y:827,t:1526918983597};\\\", \\\"{x:1618,y:825,t:1526918983613};\\\", \\\"{x:1618,y:821,t:1526918983630};\\\", \\\"{x:1618,y:819,t:1526918983647};\\\", \\\"{x:1618,y:817,t:1526918983663};\\\", \\\"{x:1617,y:813,t:1526918983681};\\\", \\\"{x:1617,y:812,t:1526918983698};\\\", \\\"{x:1617,y:811,t:1526918983714};\\\", \\\"{x:1617,y:809,t:1526918983730};\\\", \\\"{x:1617,y:808,t:1526918983748};\\\", \\\"{x:1616,y:805,t:1526918983764};\\\", \\\"{x:1616,y:803,t:1526918983781};\\\", \\\"{x:1615,y:798,t:1526918983798};\\\", \\\"{x:1615,y:794,t:1526918983814};\\\", \\\"{x:1614,y:792,t:1526918983831};\\\", \\\"{x:1613,y:788,t:1526918983848};\\\", \\\"{x:1613,y:786,t:1526918983878};\\\", \\\"{x:1613,y:785,t:1526918983927};\\\", \\\"{x:1612,y:783,t:1526918984215};\\\", \\\"{x:1611,y:778,t:1526918984231};\\\", \\\"{x:1610,y:773,t:1526918984248};\\\", \\\"{x:1607,y:767,t:1526918984265};\\\", \\\"{x:1606,y:760,t:1526918984281};\\\", \\\"{x:1605,y:756,t:1526918984298};\\\", \\\"{x:1603,y:750,t:1526918984315};\\\", \\\"{x:1602,y:742,t:1526918984331};\\\", \\\"{x:1602,y:733,t:1526918984348};\\\", \\\"{x:1601,y:727,t:1526918984365};\\\", \\\"{x:1601,y:708,t:1526918984382};\\\", \\\"{x:1601,y:700,t:1526918984399};\\\", \\\"{x:1601,y:694,t:1526918984415};\\\", \\\"{x:1601,y:688,t:1526918984432};\\\", \\\"{x:1599,y:683,t:1526918984448};\\\", \\\"{x:1599,y:679,t:1526918984465};\\\", \\\"{x:1599,y:676,t:1526918984482};\\\", \\\"{x:1598,y:674,t:1526918984498};\\\", \\\"{x:1598,y:671,t:1526918984515};\\\", \\\"{x:1597,y:669,t:1526918984532};\\\", \\\"{x:1597,y:666,t:1526918984548};\\\", \\\"{x:1596,y:664,t:1526918984565};\\\", \\\"{x:1596,y:659,t:1526918984582};\\\", \\\"{x:1596,y:653,t:1526918984598};\\\", \\\"{x:1596,y:646,t:1526918984615};\\\", \\\"{x:1596,y:640,t:1526918984632};\\\", \\\"{x:1596,y:630,t:1526918984648};\\\", \\\"{x:1596,y:622,t:1526918984665};\\\", \\\"{x:1596,y:614,t:1526918984682};\\\", \\\"{x:1596,y:606,t:1526918984698};\\\", \\\"{x:1597,y:596,t:1526918984715};\\\", \\\"{x:1601,y:587,t:1526918984731};\\\", \\\"{x:1602,y:579,t:1526918984748};\\\", \\\"{x:1605,y:572,t:1526918984764};\\\", \\\"{x:1608,y:563,t:1526918984782};\\\", \\\"{x:1609,y:556,t:1526918984798};\\\", \\\"{x:1610,y:548,t:1526918984815};\\\", \\\"{x:1612,y:541,t:1526918984833};\\\", \\\"{x:1613,y:538,t:1526918984849};\\\", \\\"{x:1614,y:534,t:1526918984865};\\\", \\\"{x:1614,y:531,t:1526918984882};\\\", \\\"{x:1615,y:522,t:1526918984899};\\\", \\\"{x:1616,y:514,t:1526918984915};\\\", \\\"{x:1617,y:506,t:1526918984932};\\\", \\\"{x:1617,y:501,t:1526918984948};\\\", \\\"{x:1617,y:493,t:1526918984964};\\\", \\\"{x:1617,y:475,t:1526918984981};\\\", \\\"{x:1617,y:464,t:1526918984998};\\\", \\\"{x:1617,y:451,t:1526918985015};\\\", \\\"{x:1616,y:441,t:1526918985032};\\\", \\\"{x:1615,y:431,t:1526918985049};\\\", \\\"{x:1614,y:424,t:1526918985065};\\\", \\\"{x:1614,y:420,t:1526918985081};\\\", \\\"{x:1614,y:418,t:1526918985098};\\\", \\\"{x:1614,y:417,t:1526918985114};\\\", \\\"{x:1613,y:417,t:1526918985542};\\\", \\\"{x:1613,y:418,t:1526918985550};\\\", \\\"{x:1614,y:424,t:1526918985566};\\\", \\\"{x:1617,y:434,t:1526918985582};\\\", \\\"{x:1619,y:443,t:1526918985599};\\\", \\\"{x:1623,y:453,t:1526918985616};\\\", \\\"{x:1626,y:460,t:1526918985631};\\\", \\\"{x:1627,y:469,t:1526918985649};\\\", \\\"{x:1631,y:480,t:1526918985666};\\\", \\\"{x:1636,y:490,t:1526918985681};\\\", \\\"{x:1638,y:498,t:1526918985699};\\\", \\\"{x:1638,y:505,t:1526918985715};\\\", \\\"{x:1640,y:516,t:1526918985732};\\\", \\\"{x:1642,y:529,t:1526918985749};\\\", \\\"{x:1643,y:543,t:1526918985766};\\\", \\\"{x:1646,y:553,t:1526918985783};\\\", \\\"{x:1646,y:560,t:1526918985798};\\\", \\\"{x:1646,y:565,t:1526918985816};\\\", \\\"{x:1647,y:569,t:1526918985832};\\\", \\\"{x:1647,y:574,t:1526918985849};\\\", \\\"{x:1647,y:579,t:1526918985866};\\\", \\\"{x:1647,y:584,t:1526918985883};\\\", \\\"{x:1647,y:586,t:1526918985899};\\\", \\\"{x:1647,y:590,t:1526918985916};\\\", \\\"{x:1645,y:592,t:1526918985933};\\\", \\\"{x:1645,y:593,t:1526918985959};\\\", \\\"{x:1642,y:593,t:1526918986031};\\\", \\\"{x:1641,y:591,t:1526918986047};\\\", \\\"{x:1639,y:589,t:1526918986055};\\\", \\\"{x:1638,y:588,t:1526918986066};\\\", \\\"{x:1633,y:584,t:1526918986083};\\\", \\\"{x:1630,y:582,t:1526918986100};\\\", \\\"{x:1629,y:581,t:1526918986119};\\\", \\\"{x:1628,y:581,t:1526918986142};\\\", \\\"{x:1627,y:579,t:1526918986150};\\\", \\\"{x:1626,y:579,t:1526918986166};\\\", \\\"{x:1624,y:578,t:1526918986183};\\\", \\\"{x:1622,y:577,t:1526918986199};\\\", \\\"{x:1621,y:577,t:1526918986215};\\\", \\\"{x:1621,y:576,t:1526918986232};\\\", \\\"{x:1620,y:575,t:1526918986249};\\\", \\\"{x:1618,y:574,t:1526918986265};\\\", \\\"{x:1617,y:572,t:1526918986282};\\\", \\\"{x:1616,y:572,t:1526918986299};\\\", \\\"{x:1615,y:569,t:1526918986315};\\\", \\\"{x:1614,y:568,t:1526918986333};\\\", \\\"{x:1613,y:567,t:1526918986349};\\\", \\\"{x:1612,y:565,t:1526918986366};\\\", \\\"{x:1612,y:564,t:1526918986389};\\\", \\\"{x:1611,y:563,t:1526918986405};\\\", \\\"{x:1611,y:565,t:1526918999879};\\\", \\\"{x:1611,y:566,t:1526918999910};\\\", \\\"{x:1611,y:568,t:1526918999935};\\\", \\\"{x:1611,y:569,t:1526918999982};\\\", \\\"{x:1611,y:571,t:1526918999999};\\\", \\\"{x:1611,y:572,t:1526919000014};\\\", \\\"{x:1611,y:574,t:1526919000054};\\\", \\\"{x:1611,y:575,t:1526919000070};\\\", \\\"{x:1611,y:577,t:1526919000094};\\\", \\\"{x:1611,y:580,t:1526919000110};\\\", \\\"{x:1611,y:584,t:1526919000126};\\\", \\\"{x:1611,y:589,t:1526919000144};\\\", \\\"{x:1613,y:599,t:1526919000160};\\\", \\\"{x:1623,y:615,t:1526919000177};\\\", \\\"{x:1635,y:638,t:1526919000194};\\\", \\\"{x:1665,y:682,t:1526919000210};\\\", \\\"{x:1697,y:727,t:1526919000227};\\\", \\\"{x:1723,y:766,t:1526919000243};\\\", \\\"{x:1750,y:813,t:1526919000260};\\\", \\\"{x:1774,y:858,t:1526919000277};\\\", \\\"{x:1809,y:939,t:1526919000294};\\\", \\\"{x:1816,y:970,t:1526919000310};\\\", \\\"{x:1820,y:1008,t:1526919000327};\\\", \\\"{x:1820,y:1042,t:1526919000344};\\\", \\\"{x:1814,y:1068,t:1526919000359};\\\", \\\"{x:1806,y:1084,t:1526919000377};\\\", \\\"{x:1798,y:1095,t:1526919000393};\\\", \\\"{x:1789,y:1103,t:1526919000409};\\\", \\\"{x:1775,y:1108,t:1526919000426};\\\", \\\"{x:1760,y:1109,t:1526919000444};\\\", \\\"{x:1736,y:1109,t:1526919000460};\\\", \\\"{x:1711,y:1106,t:1526919000476};\\\", \\\"{x:1617,y:1071,t:1526919000494};\\\", \\\"{x:1560,y:1053,t:1526919000510};\\\", \\\"{x:1526,y:1041,t:1526919000527};\\\", \\\"{x:1509,y:1030,t:1526919000544};\\\", \\\"{x:1499,y:1022,t:1526919000561};\\\", \\\"{x:1495,y:1013,t:1526919000576};\\\", \\\"{x:1493,y:1003,t:1526919000594};\\\", \\\"{x:1492,y:995,t:1526919000611};\\\", \\\"{x:1491,y:989,t:1526919000627};\\\", \\\"{x:1491,y:983,t:1526919000644};\\\", \\\"{x:1491,y:976,t:1526919000661};\\\", \\\"{x:1493,y:972,t:1526919000677};\\\", \\\"{x:1502,y:960,t:1526919000694};\\\", \\\"{x:1513,y:948,t:1526919000710};\\\", \\\"{x:1528,y:937,t:1526919000727};\\\", \\\"{x:1547,y:930,t:1526919000744};\\\", \\\"{x:1565,y:925,t:1526919000761};\\\", \\\"{x:1579,y:923,t:1526919000776};\\\", \\\"{x:1595,y:921,t:1526919000794};\\\", \\\"{x:1603,y:921,t:1526919000810};\\\", \\\"{x:1609,y:921,t:1526919000827};\\\", \\\"{x:1611,y:921,t:1526919000844};\\\", \\\"{x:1613,y:921,t:1526919000860};\\\", \\\"{x:1615,y:925,t:1526919000877};\\\", \\\"{x:1617,y:928,t:1526919000893};\\\", \\\"{x:1619,y:930,t:1526919000910};\\\", \\\"{x:1620,y:932,t:1526919000926};\\\", \\\"{x:1621,y:932,t:1526919000957};\\\", \\\"{x:1622,y:933,t:1526919000973};\\\", \\\"{x:1623,y:935,t:1526919000989};\\\", \\\"{x:1623,y:937,t:1526919000997};\\\", \\\"{x:1623,y:938,t:1526919001010};\\\", \\\"{x:1625,y:943,t:1526919001027};\\\", \\\"{x:1625,y:945,t:1526919001043};\\\", \\\"{x:1625,y:948,t:1526919001060};\\\", \\\"{x:1626,y:950,t:1526919001077};\\\", \\\"{x:1626,y:951,t:1526919001093};\\\", \\\"{x:1626,y:954,t:1526919001110};\\\", \\\"{x:1626,y:956,t:1526919001127};\\\", \\\"{x:1626,y:959,t:1526919001143};\\\", \\\"{x:1626,y:961,t:1526919001160};\\\", \\\"{x:1626,y:963,t:1526919001177};\\\", \\\"{x:1626,y:964,t:1526919001193};\\\", \\\"{x:1626,y:965,t:1526919001237};\\\", \\\"{x:1625,y:966,t:1526919001245};\\\", \\\"{x:1625,y:967,t:1526919001260};\\\", \\\"{x:1621,y:970,t:1526919001278};\\\", \\\"{x:1619,y:970,t:1526919001293};\\\", \\\"{x:1619,y:971,t:1526919001311};\\\", \\\"{x:1618,y:971,t:1526919001328};\\\", \\\"{x:1616,y:971,t:1526919001373};\\\", \\\"{x:1615,y:970,t:1526919001381};\\\", \\\"{x:1614,y:970,t:1526919001397};\\\", \\\"{x:1613,y:970,t:1526919001410};\\\", \\\"{x:1610,y:968,t:1526919001427};\\\", \\\"{x:1608,y:967,t:1526919001444};\\\", \\\"{x:1608,y:966,t:1526919001461};\\\", \\\"{x:1607,y:965,t:1526919001478};\\\", \\\"{x:1607,y:964,t:1526919001509};\\\", \\\"{x:1607,y:963,t:1526919004974};\\\", \\\"{x:1607,y:961,t:1526919005006};\\\", \\\"{x:1608,y:961,t:1526919005030};\\\", \\\"{x:1609,y:961,t:1526919005047};\\\", \\\"{x:1610,y:960,t:1526919005064};\\\", \\\"{x:1612,y:960,t:1526919005080};\\\", \\\"{x:1615,y:960,t:1526919005097};\\\", \\\"{x:1618,y:960,t:1526919005114};\\\", \\\"{x:1619,y:960,t:1526919005130};\\\", \\\"{x:1620,y:960,t:1526919005147};\\\", \\\"{x:1621,y:960,t:1526919005164};\\\", \\\"{x:1622,y:960,t:1526919005182};\\\", \\\"{x:1623,y:960,t:1526919005223};\\\", \\\"{x:1624,y:960,t:1526919005341};\\\", \\\"{x:1624,y:961,t:1526919005397};\\\", \\\"{x:1624,y:962,t:1526919005413};\\\", \\\"{x:1623,y:963,t:1526919005431};\\\", \\\"{x:1623,y:965,t:1526919005447};\\\", \\\"{x:1622,y:966,t:1526919005469};\\\", \\\"{x:1621,y:966,t:1526919005631};\\\", \\\"{x:1620,y:966,t:1526919005647};\\\", \\\"{x:1619,y:966,t:1526919005694};\\\", \\\"{x:1618,y:966,t:1526919005726};\\\", \\\"{x:1618,y:965,t:1526919005750};\\\", \\\"{x:1616,y:965,t:1526919005846};\\\", \\\"{x:1615,y:965,t:1526919005903};\\\", \\\"{x:1614,y:964,t:1526919005918};\\\", \\\"{x:1613,y:964,t:1526919006023};\\\", \\\"{x:1612,y:963,t:1526919006198};\\\", \\\"{x:1611,y:963,t:1526919009734};\\\", \\\"{x:1611,y:964,t:1526919010037};\\\", \\\"{x:1611,y:965,t:1526919010077};\\\", \\\"{x:1610,y:966,t:1526919010085};\\\", \\\"{x:1610,y:967,t:1526919010101};\\\", \\\"{x:1609,y:967,t:1526919010116};\\\", \\\"{x:1609,y:969,t:1526919010141};\\\", \\\"{x:1608,y:970,t:1526919010181};\\\", \\\"{x:1607,y:970,t:1526919010221};\\\", \\\"{x:1606,y:971,t:1526919010285};\\\", \\\"{x:1604,y:971,t:1526919010309};\\\", \\\"{x:1603,y:971,t:1526919010349};\\\", \\\"{x:1602,y:971,t:1526919010462};\\\", \\\"{x:1601,y:971,t:1526919010478};\\\", \\\"{x:1600,y:972,t:1526919010493};\\\", \\\"{x:1599,y:972,t:1526919010501};\\\", \\\"{x:1598,y:972,t:1526919010517};\\\", \\\"{x:1597,y:972,t:1526919010541};\\\", \\\"{x:1595,y:972,t:1526919010565};\\\", \\\"{x:1594,y:972,t:1526919010767};\\\", \\\"{x:1592,y:972,t:1526919010789};\\\", \\\"{x:1591,y:972,t:1526919010801};\\\", \\\"{x:1588,y:970,t:1526919010819};\\\", \\\"{x:1586,y:969,t:1526919010834};\\\", \\\"{x:1585,y:968,t:1526919010854};\\\", \\\"{x:1584,y:968,t:1526919010990};\\\", \\\"{x:1583,y:969,t:1526919011001};\\\", \\\"{x:1578,y:971,t:1526919011018};\\\", \\\"{x:1572,y:975,t:1526919011035};\\\", \\\"{x:1561,y:978,t:1526919011050};\\\", \\\"{x:1550,y:979,t:1526919011067};\\\", \\\"{x:1542,y:983,t:1526919011085};\\\", \\\"{x:1538,y:983,t:1526919011101};\\\", \\\"{x:1533,y:984,t:1526919011117};\\\", \\\"{x:1531,y:984,t:1526919011134};\\\", \\\"{x:1533,y:984,t:1526919011302};\\\", \\\"{x:1542,y:982,t:1526919011318};\\\", \\\"{x:1553,y:979,t:1526919011334};\\\", \\\"{x:1561,y:975,t:1526919011351};\\\", \\\"{x:1567,y:972,t:1526919011368};\\\", \\\"{x:1569,y:972,t:1526919011386};\\\", \\\"{x:1570,y:972,t:1526919011405};\\\", \\\"{x:1570,y:970,t:1526919011702};\\\", \\\"{x:1570,y:966,t:1526919011718};\\\", \\\"{x:1570,y:958,t:1526919011735};\\\", \\\"{x:1570,y:947,t:1526919011752};\\\", \\\"{x:1570,y:933,t:1526919011768};\\\", \\\"{x:1570,y:918,t:1526919011785};\\\", \\\"{x:1571,y:901,t:1526919011803};\\\", \\\"{x:1571,y:882,t:1526919011818};\\\", \\\"{x:1571,y:857,t:1526919011836};\\\", \\\"{x:1569,y:839,t:1526919011852};\\\", \\\"{x:1569,y:828,t:1526919011868};\\\", \\\"{x:1563,y:806,t:1526919011886};\\\", \\\"{x:1550,y:781,t:1526919011902};\\\", \\\"{x:1546,y:770,t:1526919011919};\\\", \\\"{x:1539,y:756,t:1526919011936};\\\", \\\"{x:1531,y:744,t:1526919011952};\\\", \\\"{x:1519,y:727,t:1526919011968};\\\", \\\"{x:1507,y:708,t:1526919011984};\\\", \\\"{x:1495,y:693,t:1526919012002};\\\", \\\"{x:1487,y:678,t:1526919012018};\\\", \\\"{x:1481,y:668,t:1526919012034};\\\", \\\"{x:1478,y:658,t:1526919012051};\\\", \\\"{x:1477,y:654,t:1526919012068};\\\", \\\"{x:1477,y:650,t:1526919012084};\\\", \\\"{x:1476,y:644,t:1526919012102};\\\", \\\"{x:1476,y:639,t:1526919012119};\\\", \\\"{x:1481,y:627,t:1526919012135};\\\", \\\"{x:1491,y:611,t:1526919012151};\\\", \\\"{x:1495,y:602,t:1526919012169};\\\", \\\"{x:1501,y:594,t:1526919012185};\\\", \\\"{x:1506,y:588,t:1526919012201};\\\", \\\"{x:1508,y:585,t:1526919012218};\\\", \\\"{x:1509,y:584,t:1526919012234};\\\", \\\"{x:1510,y:584,t:1526919012293};\\\", \\\"{x:1512,y:584,t:1526919012326};\\\", \\\"{x:1512,y:585,t:1526919012342};\\\", \\\"{x:1512,y:587,t:1526919012352};\\\", \\\"{x:1512,y:593,t:1526919012368};\\\", \\\"{x:1512,y:600,t:1526919012385};\\\", \\\"{x:1512,y:610,t:1526919012401};\\\", \\\"{x:1512,y:621,t:1526919012419};\\\", \\\"{x:1512,y:631,t:1526919012435};\\\", \\\"{x:1512,y:637,t:1526919012453};\\\", \\\"{x:1513,y:641,t:1526919012469};\\\", \\\"{x:1513,y:643,t:1526919012485};\\\", \\\"{x:1514,y:643,t:1526919012501};\\\", \\\"{x:1514,y:645,t:1526919012519};\\\", \\\"{x:1514,y:644,t:1526919012631};\\\", \\\"{x:1514,y:643,t:1526919012637};\\\", \\\"{x:1514,y:642,t:1526919012652};\\\", \\\"{x:1514,y:639,t:1526919012668};\\\", \\\"{x:1514,y:635,t:1526919012686};\\\", \\\"{x:1514,y:633,t:1526919012701};\\\", \\\"{x:1514,y:634,t:1526919015326};\\\", \\\"{x:1513,y:635,t:1526919015338};\\\", \\\"{x:1513,y:637,t:1526919015355};\\\", \\\"{x:1510,y:642,t:1526919015371};\\\", \\\"{x:1510,y:648,t:1526919015389};\\\", \\\"{x:1508,y:656,t:1526919015404};\\\", \\\"{x:1505,y:671,t:1526919015422};\\\", \\\"{x:1502,y:686,t:1526919015437};\\\", \\\"{x:1496,y:702,t:1526919015455};\\\", \\\"{x:1491,y:725,t:1526919015472};\\\", \\\"{x:1488,y:739,t:1526919015488};\\\", \\\"{x:1488,y:749,t:1526919015504};\\\", \\\"{x:1488,y:755,t:1526919015521};\\\", \\\"{x:1488,y:759,t:1526919015538};\\\", \\\"{x:1488,y:766,t:1526919015554};\\\", \\\"{x:1489,y:773,t:1526919015571};\\\", \\\"{x:1490,y:779,t:1526919015588};\\\", \\\"{x:1491,y:784,t:1526919015604};\\\", \\\"{x:1494,y:790,t:1526919015622};\\\", \\\"{x:1495,y:797,t:1526919015638};\\\", \\\"{x:1499,y:804,t:1526919015654};\\\", \\\"{x:1499,y:807,t:1526919015671};\\\", \\\"{x:1500,y:810,t:1526919015688};\\\", \\\"{x:1500,y:812,t:1526919015704};\\\", \\\"{x:1500,y:813,t:1526919015721};\\\", \\\"{x:1501,y:816,t:1526919015739};\\\", \\\"{x:1501,y:820,t:1526919015755};\\\", \\\"{x:1500,y:825,t:1526919015771};\\\", \\\"{x:1496,y:838,t:1526919015788};\\\", \\\"{x:1490,y:853,t:1526919015806};\\\", \\\"{x:1485,y:862,t:1526919015821};\\\", \\\"{x:1482,y:865,t:1526919015838};\\\", \\\"{x:1481,y:866,t:1526919015855};\\\", \\\"{x:1480,y:867,t:1526919015871};\\\", \\\"{x:1479,y:869,t:1526919015889};\\\", \\\"{x:1478,y:869,t:1526919015942};\\\", \\\"{x:1476,y:869,t:1526919015955};\\\", \\\"{x:1475,y:869,t:1526919015973};\\\", \\\"{x:1474,y:869,t:1526919015988};\\\", \\\"{x:1472,y:867,t:1526919016006};\\\", \\\"{x:1472,y:866,t:1526919016021};\\\", \\\"{x:1472,y:862,t:1526919016038};\\\", \\\"{x:1472,y:858,t:1526919016055};\\\", \\\"{x:1472,y:855,t:1526919016071};\\\", \\\"{x:1472,y:852,t:1526919016088};\\\", \\\"{x:1472,y:850,t:1526919016105};\\\", \\\"{x:1473,y:847,t:1526919016122};\\\", \\\"{x:1474,y:846,t:1526919016137};\\\", \\\"{x:1475,y:846,t:1526919016154};\\\", \\\"{x:1476,y:844,t:1526919016170};\\\", \\\"{x:1477,y:842,t:1526919016188};\\\", \\\"{x:1478,y:840,t:1526919016277};\\\", \\\"{x:1478,y:838,t:1526919016293};\\\", \\\"{x:1478,y:837,t:1526919016305};\\\", \\\"{x:1478,y:835,t:1526919016322};\\\", \\\"{x:1479,y:834,t:1526919016338};\\\", \\\"{x:1480,y:833,t:1526919016355};\\\", \\\"{x:1480,y:830,t:1526919016372};\\\", \\\"{x:1481,y:829,t:1526919016389};\\\", \\\"{x:1480,y:830,t:1526919017190};\\\", \\\"{x:1471,y:836,t:1526919017207};\\\", \\\"{x:1443,y:844,t:1526919017222};\\\", \\\"{x:1392,y:852,t:1526919017239};\\\", \\\"{x:1287,y:852,t:1526919017256};\\\", \\\"{x:1162,y:852,t:1526919017272};\\\", \\\"{x:1043,y:852,t:1526919017289};\\\", \\\"{x:955,y:844,t:1526919017306};\\\", \\\"{x:875,y:809,t:1526919017322};\\\", \\\"{x:817,y:775,t:1526919017340};\\\", \\\"{x:747,y:742,t:1526919017356};\\\", \\\"{x:624,y:684,t:1526919017374};\\\", \\\"{x:566,y:649,t:1526919017391};\\\", \\\"{x:536,y:629,t:1526919017405};\\\", \\\"{x:511,y:612,t:1526919017422};\\\", \\\"{x:503,y:606,t:1526919017433};\\\", \\\"{x:491,y:589,t:1526919017450};\\\", \\\"{x:485,y:575,t:1526919017466};\\\", \\\"{x:483,y:553,t:1526919017492};\\\", \\\"{x:483,y:540,t:1526919017508};\\\", \\\"{x:483,y:531,t:1526919017526};\\\", \\\"{x:489,y:523,t:1526919017541};\\\", \\\"{x:495,y:518,t:1526919017557};\\\", \\\"{x:503,y:517,t:1526919017575};\\\", \\\"{x:512,y:517,t:1526919017591};\\\", \\\"{x:517,y:517,t:1526919017607};\\\", \\\"{x:521,y:518,t:1526919017625};\\\", \\\"{x:532,y:526,t:1526919017640};\\\", \\\"{x:543,y:535,t:1526919017658};\\\", \\\"{x:554,y:541,t:1526919017675};\\\", \\\"{x:577,y:551,t:1526919017691};\\\", \\\"{x:597,y:554,t:1526919017707};\\\", \\\"{x:631,y:554,t:1526919017724};\\\", \\\"{x:656,y:556,t:1526919017741};\\\", \\\"{x:676,y:557,t:1526919017758};\\\", \\\"{x:691,y:560,t:1526919017774};\\\", \\\"{x:696,y:561,t:1526919017791};\\\", \\\"{x:700,y:563,t:1526919017808};\\\", \\\"{x:703,y:564,t:1526919017825};\\\", \\\"{x:708,y:564,t:1526919017842};\\\", \\\"{x:719,y:564,t:1526919017857};\\\", \\\"{x:734,y:564,t:1526919017876};\\\", \\\"{x:756,y:563,t:1526919017891};\\\", \\\"{x:784,y:562,t:1526919017908};\\\", \\\"{x:831,y:557,t:1526919017925};\\\", \\\"{x:850,y:557,t:1526919017941};\\\", \\\"{x:854,y:557,t:1526919017958};\\\", \\\"{x:856,y:557,t:1526919017975};\\\", \\\"{x:857,y:560,t:1526919017992};\\\", \\\"{x:857,y:569,t:1526919018007};\\\", \\\"{x:855,y:582,t:1526919018026};\\\", \\\"{x:843,y:600,t:1526919018042};\\\", \\\"{x:823,y:614,t:1526919018058};\\\", \\\"{x:795,y:622,t:1526919018075};\\\", \\\"{x:748,y:627,t:1526919018092};\\\", \\\"{x:690,y:627,t:1526919018108};\\\", \\\"{x:636,y:627,t:1526919018125};\\\", \\\"{x:618,y:627,t:1526919018142};\\\", \\\"{x:606,y:622,t:1526919018158};\\\", \\\"{x:603,y:620,t:1526919018175};\\\", \\\"{x:602,y:618,t:1526919018192};\\\", \\\"{x:601,y:617,t:1526919018208};\\\", \\\"{x:600,y:617,t:1526919018224};\\\", \\\"{x:600,y:615,t:1526919018241};\\\", \\\"{x:599,y:615,t:1526919018258};\\\", \\\"{x:598,y:614,t:1526919018277};\\\", \\\"{x:597,y:612,t:1526919018294};\\\", \\\"{x:596,y:610,t:1526919018308};\\\", \\\"{x:595,y:607,t:1526919018324};\\\", \\\"{x:593,y:604,t:1526919018342};\\\", \\\"{x:592,y:600,t:1526919018358};\\\", \\\"{x:592,y:596,t:1526919018375};\\\", \\\"{x:592,y:594,t:1526919018392};\\\", \\\"{x:593,y:590,t:1526919018409};\\\", \\\"{x:595,y:589,t:1526919018425};\\\", \\\"{x:598,y:589,t:1526919018442};\\\", \\\"{x:602,y:589,t:1526919018460};\\\", \\\"{x:605,y:589,t:1526919018475};\\\", \\\"{x:606,y:589,t:1526919018492};\\\", \\\"{x:607,y:589,t:1526919018509};\\\", \\\"{x:609,y:589,t:1526919018525};\\\", \\\"{x:614,y:589,t:1526919020438};\\\", \\\"{x:634,y:589,t:1526919020446};\\\", \\\"{x:662,y:589,t:1526919020461};\\\", \\\"{x:787,y:589,t:1526919020477};\\\", \\\"{x:890,y:589,t:1526919020493};\\\", \\\"{x:993,y:591,t:1526919020510};\\\", \\\"{x:1097,y:601,t:1526919020527};\\\", \\\"{x:1206,y:619,t:1526919020544};\\\", \\\"{x:1309,y:633,t:1526919020560};\\\", \\\"{x:1390,y:646,t:1526919020576};\\\", \\\"{x:1435,y:653,t:1526919020593};\\\", \\\"{x:1452,y:655,t:1526919020610};\\\", \\\"{x:1457,y:658,t:1526919020627};\\\", \\\"{x:1459,y:661,t:1526919020644};\\\", \\\"{x:1461,y:664,t:1526919020660};\\\", \\\"{x:1464,y:669,t:1526919020677};\\\", \\\"{x:1466,y:671,t:1526919020694};\\\", \\\"{x:1466,y:672,t:1526919020710};\\\", \\\"{x:1467,y:673,t:1526919020733};\\\", \\\"{x:1468,y:673,t:1526919020757};\\\", \\\"{x:1468,y:668,t:1526919020766};\\\", \\\"{x:1464,y:661,t:1526919020777};\\\", \\\"{x:1459,y:648,t:1526919020794};\\\", \\\"{x:1456,y:640,t:1526919020810};\\\", \\\"{x:1451,y:629,t:1526919020827};\\\", \\\"{x:1444,y:618,t:1526919020844};\\\", \\\"{x:1437,y:605,t:1526919020861};\\\", \\\"{x:1431,y:594,t:1526919020878};\\\", \\\"{x:1429,y:588,t:1526919020893};\\\", \\\"{x:1429,y:586,t:1526919020910};\\\", \\\"{x:1428,y:585,t:1526919020928};\\\", \\\"{x:1428,y:583,t:1526919020944};\\\", \\\"{x:1428,y:582,t:1526919020960};\\\", \\\"{x:1428,y:581,t:1526919020978};\\\", \\\"{x:1428,y:579,t:1526919020994};\\\", \\\"{x:1428,y:578,t:1526919021011};\\\", \\\"{x:1428,y:576,t:1526919021027};\\\", \\\"{x:1428,y:574,t:1526919021044};\\\", \\\"{x:1428,y:571,t:1526919021061};\\\", \\\"{x:1428,y:566,t:1526919021078};\\\", \\\"{x:1428,y:565,t:1526919021110};\\\", \\\"{x:1428,y:564,t:1526919021117};\\\", \\\"{x:1428,y:563,t:1526919021127};\\\", \\\"{x:1428,y:562,t:1526919021157};\\\", \\\"{x:1428,y:561,t:1526919021173};\\\", \\\"{x:1428,y:560,t:1526919021205};\\\", \\\"{x:1428,y:559,t:1526919021302};\\\", \\\"{x:1428,y:558,t:1526919021366};\\\", \\\"{x:1428,y:557,t:1526919021378};\\\", \\\"{x:1428,y:556,t:1526919021397};\\\", \\\"{x:1428,y:555,t:1526919021413};\\\", \\\"{x:1428,y:554,t:1526919021427};\\\", \\\"{x:1428,y:552,t:1526919021444};\\\", \\\"{x:1428,y:550,t:1526919021462};\\\", \\\"{x:1426,y:550,t:1526919021558};\\\", \\\"{x:1423,y:550,t:1526919021566};\\\", \\\"{x:1421,y:552,t:1526919021578};\\\", \\\"{x:1418,y:554,t:1526919021595};\\\", \\\"{x:1417,y:555,t:1526919021612};\\\", \\\"{x:1416,y:557,t:1526919021628};\\\", \\\"{x:1415,y:558,t:1526919021646};\\\", \\\"{x:1414,y:559,t:1526919023070};\\\", \\\"{x:1414,y:560,t:1526919023085};\\\", \\\"{x:1414,y:561,t:1526919023102};\\\", \\\"{x:1414,y:563,t:1526919023112};\\\", \\\"{x:1414,y:565,t:1526919023130};\\\", \\\"{x:1414,y:566,t:1526919023145};\\\", \\\"{x:1414,y:568,t:1526919023162};\\\", \\\"{x:1414,y:570,t:1526919023181};\\\", \\\"{x:1414,y:573,t:1526919023196};\\\", \\\"{x:1415,y:575,t:1526919023213};\\\", \\\"{x:1415,y:583,t:1526919023229};\\\", \\\"{x:1416,y:590,t:1526919023245};\\\", \\\"{x:1416,y:595,t:1526919023262};\\\", \\\"{x:1416,y:602,t:1526919023279};\\\", \\\"{x:1417,y:606,t:1526919023296};\\\", \\\"{x:1418,y:611,t:1526919023313};\\\", \\\"{x:1418,y:614,t:1526919023330};\\\", \\\"{x:1418,y:618,t:1526919023346};\\\", \\\"{x:1419,y:622,t:1526919023362};\\\", \\\"{x:1419,y:624,t:1526919023380};\\\", \\\"{x:1419,y:626,t:1526919023396};\\\", \\\"{x:1420,y:628,t:1526919023412};\\\", \\\"{x:1420,y:633,t:1526919023429};\\\", \\\"{x:1420,y:638,t:1526919023446};\\\", \\\"{x:1420,y:640,t:1526919023462};\\\", \\\"{x:1420,y:645,t:1526919023479};\\\", \\\"{x:1420,y:650,t:1526919023496};\\\", \\\"{x:1420,y:653,t:1526919023511};\\\", \\\"{x:1420,y:657,t:1526919023528};\\\", \\\"{x:1420,y:659,t:1526919023546};\\\", \\\"{x:1420,y:660,t:1526919023562};\\\", \\\"{x:1420,y:663,t:1526919023579};\\\", \\\"{x:1420,y:665,t:1526919023596};\\\", \\\"{x:1420,y:668,t:1526919023612};\\\", \\\"{x:1420,y:674,t:1526919023628};\\\", \\\"{x:1420,y:680,t:1526919023647};\\\", \\\"{x:1420,y:685,t:1526919023662};\\\", \\\"{x:1420,y:690,t:1526919023680};\\\", \\\"{x:1420,y:695,t:1526919023696};\\\", \\\"{x:1420,y:699,t:1526919023713};\\\", \\\"{x:1420,y:705,t:1526919023730};\\\", \\\"{x:1420,y:715,t:1526919023747};\\\", \\\"{x:1420,y:723,t:1526919023763};\\\", \\\"{x:1420,y:732,t:1526919023779};\\\", \\\"{x:1422,y:740,t:1526919023797};\\\", \\\"{x:1422,y:746,t:1526919023813};\\\", \\\"{x:1422,y:753,t:1526919023829};\\\", \\\"{x:1422,y:759,t:1526919023846};\\\", \\\"{x:1422,y:765,t:1526919023863};\\\", \\\"{x:1422,y:768,t:1526919023879};\\\", \\\"{x:1422,y:774,t:1526919023897};\\\", \\\"{x:1422,y:780,t:1526919023913};\\\", \\\"{x:1422,y:787,t:1526919023930};\\\", \\\"{x:1422,y:793,t:1526919023946};\\\", \\\"{x:1422,y:797,t:1526919023963};\\\", \\\"{x:1422,y:802,t:1526919023980};\\\", \\\"{x:1422,y:805,t:1526919023997};\\\", \\\"{x:1421,y:811,t:1526919024014};\\\", \\\"{x:1421,y:815,t:1526919024030};\\\", \\\"{x:1418,y:824,t:1526919024047};\\\", \\\"{x:1414,y:840,t:1526919024063};\\\", \\\"{x:1409,y:854,t:1526919024080};\\\", \\\"{x:1408,y:860,t:1526919024096};\\\", \\\"{x:1408,y:864,t:1526919024114};\\\", \\\"{x:1407,y:868,t:1526919024130};\\\", \\\"{x:1407,y:870,t:1526919024146};\\\", \\\"{x:1407,y:874,t:1526919024164};\\\", \\\"{x:1407,y:880,t:1526919024180};\\\", \\\"{x:1407,y:886,t:1526919024197};\\\", \\\"{x:1407,y:897,t:1526919024213};\\\", \\\"{x:1407,y:905,t:1526919024230};\\\", \\\"{x:1407,y:913,t:1526919024246};\\\", \\\"{x:1407,y:921,t:1526919024263};\\\", \\\"{x:1407,y:929,t:1526919024279};\\\", \\\"{x:1407,y:933,t:1526919024296};\\\", \\\"{x:1408,y:937,t:1526919024314};\\\", \\\"{x:1408,y:941,t:1526919024329};\\\", \\\"{x:1408,y:945,t:1526919024347};\\\", \\\"{x:1408,y:949,t:1526919024364};\\\", \\\"{x:1408,y:956,t:1526919024381};\\\", \\\"{x:1408,y:963,t:1526919024396};\\\", \\\"{x:1409,y:967,t:1526919024414};\\\", \\\"{x:1409,y:968,t:1526919024484};\\\", \\\"{x:1410,y:969,t:1526919025967};\\\", \\\"{x:1411,y:970,t:1526919025981};\\\", \\\"{x:1410,y:968,t:1526919026822};\\\", \\\"{x:1410,y:967,t:1526919026854};\\\", \\\"{x:1410,y:965,t:1526919026870};\\\", \\\"{x:1410,y:964,t:1526919026894};\\\", \\\"{x:1410,y:962,t:1526919026918};\\\", \\\"{x:1410,y:961,t:1526919026934};\\\", \\\"{x:1410,y:960,t:1526919026949};\\\", \\\"{x:1410,y:959,t:1526919026965};\\\", \\\"{x:1410,y:958,t:1526919026990};\\\", \\\"{x:1410,y:957,t:1526919026999};\\\", \\\"{x:1410,y:956,t:1526919027016};\\\", \\\"{x:1410,y:955,t:1526919027032};\\\", \\\"{x:1410,y:954,t:1526919027049};\\\", \\\"{x:1411,y:953,t:1526919027066};\\\", \\\"{x:1411,y:952,t:1526919027166};\\\", \\\"{x:1411,y:951,t:1526919027182};\\\", \\\"{x:1412,y:951,t:1526919027199};\\\", \\\"{x:1412,y:950,t:1526919027216};\\\", \\\"{x:1412,y:949,t:1526919027232};\\\", \\\"{x:1412,y:947,t:1526919027249};\\\", \\\"{x:1412,y:946,t:1526919027266};\\\", \\\"{x:1412,y:944,t:1526919027283};\\\", \\\"{x:1412,y:942,t:1526919027299};\\\", \\\"{x:1412,y:940,t:1526919027315};\\\", \\\"{x:1412,y:937,t:1526919027333};\\\", \\\"{x:1412,y:935,t:1526919027349};\\\", \\\"{x:1412,y:930,t:1526919027365};\\\", \\\"{x:1412,y:928,t:1526919027383};\\\", \\\"{x:1411,y:925,t:1526919027398};\\\", \\\"{x:1411,y:923,t:1526919027415};\\\", \\\"{x:1411,y:920,t:1526919027432};\\\", \\\"{x:1411,y:915,t:1526919027448};\\\", \\\"{x:1411,y:906,t:1526919027465};\\\", \\\"{x:1411,y:893,t:1526919027482};\\\", \\\"{x:1411,y:880,t:1526919027498};\\\", \\\"{x:1411,y:864,t:1526919027515};\\\", \\\"{x:1411,y:849,t:1526919027532};\\\", \\\"{x:1411,y:821,t:1526919027549};\\\", \\\"{x:1411,y:807,t:1526919027565};\\\", \\\"{x:1407,y:798,t:1526919027582};\\\", \\\"{x:1405,y:790,t:1526919027598};\\\", \\\"{x:1405,y:787,t:1526919027616};\\\", \\\"{x:1404,y:784,t:1526919027633};\\\", \\\"{x:1403,y:782,t:1526919027649};\\\", \\\"{x:1403,y:780,t:1526919027665};\\\", \\\"{x:1402,y:779,t:1526919027682};\\\", \\\"{x:1401,y:779,t:1526919027700};\\\", \\\"{x:1401,y:778,t:1526919027724};\\\", \\\"{x:1399,y:776,t:1526919027766};\\\", \\\"{x:1397,y:775,t:1526919027782};\\\", \\\"{x:1396,y:774,t:1526919027799};\\\", \\\"{x:1394,y:772,t:1526919027816};\\\", \\\"{x:1391,y:770,t:1526919027833};\\\", \\\"{x:1390,y:768,t:1526919027849};\\\", \\\"{x:1390,y:767,t:1526919027866};\\\", \\\"{x:1389,y:766,t:1526919027882};\\\", \\\"{x:1388,y:765,t:1526919027899};\\\", \\\"{x:1388,y:764,t:1526919027925};\\\", \\\"{x:1387,y:764,t:1526919028453};\\\", \\\"{x:1386,y:764,t:1526919028476};\\\", \\\"{x:1385,y:764,t:1526919028499};\\\", \\\"{x:1383,y:765,t:1526919028516};\\\", \\\"{x:1383,y:766,t:1526919028532};\\\", \\\"{x:1382,y:766,t:1526919028549};\\\", \\\"{x:1381,y:767,t:1526919028566};\\\", \\\"{x:1380,y:768,t:1526919028582};\\\", \\\"{x:1379,y:768,t:1526919028599};\\\", \\\"{x:1378,y:768,t:1526919028694};\\\", \\\"{x:1377,y:768,t:1526919028735};\\\", \\\"{x:1376,y:768,t:1526919028750};\\\", \\\"{x:1375,y:768,t:1526919029118};\\\", \\\"{x:1375,y:766,t:1526919029133};\\\", \\\"{x:1375,y:765,t:1526919029151};\\\", \\\"{x:1375,y:763,t:1526919029167};\\\", \\\"{x:1375,y:762,t:1526919029184};\\\", \\\"{x:1375,y:760,t:1526919029200};\\\", \\\"{x:1375,y:759,t:1526919029278};\\\", \\\"{x:1376,y:759,t:1526919029454};\\\", \\\"{x:1377,y:759,t:1526919029469};\\\", \\\"{x:1378,y:759,t:1526919029484};\\\", \\\"{x:1379,y:761,t:1526919029500};\\\", \\\"{x:1382,y:766,t:1526919029516};\\\", \\\"{x:1386,y:778,t:1526919029534};\\\", \\\"{x:1389,y:790,t:1526919029551};\\\", \\\"{x:1393,y:803,t:1526919029567};\\\", \\\"{x:1394,y:815,t:1526919029584};\\\", \\\"{x:1397,y:827,t:1526919029601};\\\", \\\"{x:1399,y:840,t:1526919029618};\\\", \\\"{x:1399,y:850,t:1526919029634};\\\", \\\"{x:1399,y:858,t:1526919029651};\\\", \\\"{x:1402,y:871,t:1526919029668};\\\", \\\"{x:1402,y:881,t:1526919029683};\\\", \\\"{x:1402,y:888,t:1526919029701};\\\", \\\"{x:1402,y:899,t:1526919029718};\\\", \\\"{x:1403,y:909,t:1526919029734};\\\", \\\"{x:1403,y:921,t:1526919029751};\\\", \\\"{x:1404,y:933,t:1526919029768};\\\", \\\"{x:1406,y:943,t:1526919029784};\\\", \\\"{x:1407,y:952,t:1526919029801};\\\", \\\"{x:1408,y:959,t:1526919029817};\\\", \\\"{x:1408,y:964,t:1526919029834};\\\", \\\"{x:1410,y:967,t:1526919029851};\\\", \\\"{x:1410,y:970,t:1526919029868};\\\", \\\"{x:1410,y:972,t:1526919029883};\\\", \\\"{x:1410,y:975,t:1526919029901};\\\", \\\"{x:1410,y:978,t:1526919029917};\\\", \\\"{x:1411,y:980,t:1526919029934};\\\", \\\"{x:1411,y:982,t:1526919029951};\\\", \\\"{x:1411,y:983,t:1526919029968};\\\", \\\"{x:1412,y:983,t:1526919030020};\\\", \\\"{x:1411,y:983,t:1526919030261};\\\", \\\"{x:1410,y:983,t:1526919030277};\\\", \\\"{x:1408,y:983,t:1526919030302};\\\", \\\"{x:1406,y:983,t:1526919030317};\\\", \\\"{x:1401,y:980,t:1526919030335};\\\", \\\"{x:1394,y:973,t:1526919030351};\\\", \\\"{x:1391,y:970,t:1526919030367};\\\", \\\"{x:1387,y:963,t:1526919030385};\\\", \\\"{x:1378,y:948,t:1526919030401};\\\", \\\"{x:1370,y:932,t:1526919030418};\\\", \\\"{x:1360,y:908,t:1526919030435};\\\", \\\"{x:1355,y:877,t:1526919030450};\\\", \\\"{x:1355,y:857,t:1526919030468};\\\", \\\"{x:1352,y:835,t:1526919030485};\\\", \\\"{x:1350,y:809,t:1526919030502};\\\", \\\"{x:1350,y:795,t:1526919030518};\\\", \\\"{x:1350,y:785,t:1526919030535};\\\", \\\"{x:1350,y:778,t:1526919030552};\\\", \\\"{x:1350,y:771,t:1526919030568};\\\", \\\"{x:1350,y:762,t:1526919030585};\\\", \\\"{x:1350,y:753,t:1526919030601};\\\", \\\"{x:1350,y:745,t:1526919030617};\\\", \\\"{x:1349,y:740,t:1526919030635};\\\", \\\"{x:1348,y:735,t:1526919030652};\\\", \\\"{x:1348,y:730,t:1526919030668};\\\", \\\"{x:1345,y:721,t:1526919030686};\\\", \\\"{x:1344,y:718,t:1526919030702};\\\", \\\"{x:1344,y:716,t:1526919030718};\\\", \\\"{x:1342,y:715,t:1526919030735};\\\", \\\"{x:1341,y:714,t:1526919030752};\\\", \\\"{x:1336,y:713,t:1526919030768};\\\", \\\"{x:1332,y:710,t:1526919030785};\\\", \\\"{x:1328,y:707,t:1526919030802};\\\", \\\"{x:1323,y:703,t:1526919030818};\\\", \\\"{x:1321,y:702,t:1526919030834};\\\", \\\"{x:1319,y:701,t:1526919030852};\\\", \\\"{x:1317,y:699,t:1526919030868};\\\", \\\"{x:1316,y:699,t:1526919030885};\\\", \\\"{x:1315,y:698,t:1526919030902};\\\", \\\"{x:1314,y:698,t:1526919031045};\\\", \\\"{x:1313,y:698,t:1526919031053};\\\", \\\"{x:1312,y:700,t:1526919031068};\\\", \\\"{x:1308,y:710,t:1526919031085};\\\", \\\"{x:1301,y:729,t:1526919031101};\\\", \\\"{x:1297,y:746,t:1526919031119};\\\", \\\"{x:1296,y:760,t:1526919031135};\\\", \\\"{x:1296,y:764,t:1526919031152};\\\", \\\"{x:1296,y:762,t:1526919031238};\\\", \\\"{x:1296,y:755,t:1526919031252};\\\", \\\"{x:1300,y:742,t:1526919031269};\\\", \\\"{x:1304,y:729,t:1526919031285};\\\", \\\"{x:1310,y:702,t:1526919031302};\\\", \\\"{x:1315,y:682,t:1526919031319};\\\", \\\"{x:1321,y:665,t:1526919031334};\\\", \\\"{x:1324,y:653,t:1526919031352};\\\", \\\"{x:1327,y:645,t:1526919031369};\\\", \\\"{x:1329,y:638,t:1526919031385};\\\", \\\"{x:1329,y:636,t:1526919031402};\\\", \\\"{x:1329,y:634,t:1526919031419};\\\", \\\"{x:1329,y:633,t:1526919031438};\\\", \\\"{x:1329,y:632,t:1526919031453};\\\", \\\"{x:1329,y:631,t:1526919031510};\\\", \\\"{x:1329,y:630,t:1526919031519};\\\", \\\"{x:1329,y:629,t:1526919031549};\\\", \\\"{x:1329,y:628,t:1526919031556};\\\", \\\"{x:1328,y:627,t:1526919031572};\\\", \\\"{x:1326,y:625,t:1526919031588};\\\", \\\"{x:1324,y:625,t:1526919031605};\\\", \\\"{x:1323,y:625,t:1526919031618};\\\", \\\"{x:1322,y:624,t:1526919031636};\\\", \\\"{x:1321,y:624,t:1526919031764};\\\", \\\"{x:1320,y:624,t:1526919031772};\\\", \\\"{x:1319,y:624,t:1526919031797};\\\", \\\"{x:1318,y:622,t:1526919031812};\\\", \\\"{x:1317,y:622,t:1526919031820};\\\", \\\"{x:1316,y:621,t:1526919031835};\\\", \\\"{x:1316,y:620,t:1526919031851};\\\", \\\"{x:1315,y:618,t:1526919031868};\\\", \\\"{x:1314,y:618,t:1526919031886};\\\", \\\"{x:1314,y:616,t:1526919031901};\\\", \\\"{x:1313,y:613,t:1526919031918};\\\", \\\"{x:1313,y:611,t:1526919031936};\\\", \\\"{x:1313,y:608,t:1526919031953};\\\", \\\"{x:1312,y:604,t:1526919031968};\\\", \\\"{x:1311,y:598,t:1526919031986};\\\", \\\"{x:1311,y:587,t:1526919032002};\\\", \\\"{x:1310,y:571,t:1526919032018};\\\", \\\"{x:1308,y:549,t:1526919032035};\\\", \\\"{x:1308,y:528,t:1526919032052};\\\", \\\"{x:1308,y:505,t:1526919032069};\\\", \\\"{x:1308,y:494,t:1526919032085};\\\", \\\"{x:1310,y:489,t:1526919032103};\\\", \\\"{x:1311,y:486,t:1526919032118};\\\", \\\"{x:1311,y:483,t:1526919032135};\\\", \\\"{x:1311,y:482,t:1526919032152};\\\", \\\"{x:1311,y:486,t:1526919032294};\\\", \\\"{x:1311,y:490,t:1526919032302};\\\", \\\"{x:1311,y:498,t:1526919032319};\\\", \\\"{x:1314,y:506,t:1526919032336};\\\", \\\"{x:1315,y:511,t:1526919032352};\\\", \\\"{x:1315,y:517,t:1526919032368};\\\", \\\"{x:1315,y:523,t:1526919032386};\\\", \\\"{x:1315,y:529,t:1526919032402};\\\", \\\"{x:1317,y:536,t:1526919032419};\\\", \\\"{x:1318,y:544,t:1526919032435};\\\", \\\"{x:1318,y:550,t:1526919032453};\\\", \\\"{x:1319,y:556,t:1526919032468};\\\", \\\"{x:1319,y:560,t:1526919032486};\\\", \\\"{x:1320,y:565,t:1526919032502};\\\", \\\"{x:1321,y:573,t:1526919032519};\\\", \\\"{x:1321,y:580,t:1526919032536};\\\", \\\"{x:1321,y:587,t:1526919032553};\\\", \\\"{x:1321,y:593,t:1526919032569};\\\", \\\"{x:1320,y:597,t:1526919032585};\\\", \\\"{x:1318,y:606,t:1526919032603};\\\", \\\"{x:1317,y:613,t:1526919032620};\\\", \\\"{x:1316,y:626,t:1526919032636};\\\", \\\"{x:1311,y:651,t:1526919032653};\\\", \\\"{x:1308,y:661,t:1526919032669};\\\", \\\"{x:1306,y:670,t:1526919032685};\\\", \\\"{x:1306,y:680,t:1526919032703};\\\", \\\"{x:1303,y:690,t:1526919032720};\\\", \\\"{x:1303,y:700,t:1526919032736};\\\", \\\"{x:1301,y:714,t:1526919032753};\\\", \\\"{x:1300,y:724,t:1526919032770};\\\", \\\"{x:1300,y:731,t:1526919032786};\\\", \\\"{x:1300,y:736,t:1526919032803};\\\", \\\"{x:1300,y:741,t:1526919032820};\\\", \\\"{x:1300,y:746,t:1526919032836};\\\", \\\"{x:1300,y:755,t:1526919032853};\\\", \\\"{x:1300,y:762,t:1526919032869};\\\", \\\"{x:1300,y:772,t:1526919032886};\\\", \\\"{x:1300,y:780,t:1526919032902};\\\", \\\"{x:1300,y:792,t:1526919032919};\\\", \\\"{x:1300,y:803,t:1526919032937};\\\", \\\"{x:1300,y:817,t:1526919032952};\\\", \\\"{x:1306,y:827,t:1526919032969};\\\", \\\"{x:1308,y:836,t:1526919032986};\\\", \\\"{x:1309,y:846,t:1526919033002};\\\", \\\"{x:1311,y:860,t:1526919033019};\\\", \\\"{x:1315,y:880,t:1526919033036};\\\", \\\"{x:1319,y:896,t:1526919033052};\\\", \\\"{x:1320,y:909,t:1526919033070};\\\", \\\"{x:1322,y:921,t:1526919033086};\\\", \\\"{x:1324,y:934,t:1526919033102};\\\", \\\"{x:1325,y:945,t:1526919033119};\\\", \\\"{x:1327,y:959,t:1526919033136};\\\", \\\"{x:1327,y:972,t:1526919033152};\\\", \\\"{x:1328,y:982,t:1526919033169};\\\", \\\"{x:1329,y:990,t:1526919033187};\\\", \\\"{x:1330,y:999,t:1526919033203};\\\", \\\"{x:1330,y:1002,t:1526919033220};\\\", \\\"{x:1330,y:1005,t:1526919033236};\\\", \\\"{x:1330,y:1006,t:1526919033253};\\\", \\\"{x:1330,y:1007,t:1526919033277};\\\", \\\"{x:1330,y:1006,t:1526919033574};\\\", \\\"{x:1330,y:1005,t:1526919033589};\\\", \\\"{x:1329,y:1004,t:1526919033604};\\\", \\\"{x:1327,y:998,t:1526919033620};\\\", \\\"{x:1325,y:992,t:1526919033638};\\\", \\\"{x:1325,y:991,t:1526919033654};\\\", \\\"{x:1325,y:989,t:1526919033670};\\\", \\\"{x:1321,y:988,t:1526919033854};\\\", \\\"{x:1301,y:988,t:1526919033871};\\\", \\\"{x:1271,y:988,t:1526919033887};\\\", \\\"{x:1216,y:985,t:1526919033904};\\\", \\\"{x:1116,y:967,t:1526919033921};\\\", \\\"{x:989,y:955,t:1526919033937};\\\", \\\"{x:809,y:925,t:1526919033954};\\\", \\\"{x:607,y:898,t:1526919033971};\\\", \\\"{x:433,y:871,t:1526919033987};\\\", \\\"{x:298,y:837,t:1526919034004};\\\", \\\"{x:161,y:780,t:1526919034021};\\\", \\\"{x:127,y:756,t:1526919034037};\\\", \\\"{x:104,y:735,t:1526919034053};\\\", \\\"{x:95,y:719,t:1526919034071};\\\", \\\"{x:91,y:701,t:1526919034087};\\\", \\\"{x:91,y:686,t:1526919034104};\\\", \\\"{x:91,y:671,t:1526919034120};\\\", \\\"{x:95,y:655,t:1526919034137};\\\", \\\"{x:101,y:643,t:1526919034155};\\\", \\\"{x:110,y:634,t:1526919034170};\\\", \\\"{x:130,y:623,t:1526919034186};\\\", \\\"{x:158,y:611,t:1526919034204};\\\", \\\"{x:196,y:603,t:1526919034219};\\\", \\\"{x:274,y:603,t:1526919034237};\\\", \\\"{x:330,y:603,t:1526919034254};\\\", \\\"{x:381,y:603,t:1526919034272};\\\", \\\"{x:417,y:614,t:1526919034289};\\\", \\\"{x:444,y:625,t:1526919034305};\\\", \\\"{x:458,y:633,t:1526919034321};\\\", \\\"{x:464,y:637,t:1526919034337};\\\", \\\"{x:469,y:644,t:1526919034354};\\\", \\\"{x:472,y:653,t:1526919034372};\\\", \\\"{x:478,y:666,t:1526919034388};\\\", \\\"{x:479,y:670,t:1526919034404};\\\", \\\"{x:480,y:671,t:1526919034421};\\\", \\\"{x:481,y:674,t:1526919034438};\\\", \\\"{x:482,y:679,t:1526919034454};\\\", \\\"{x:485,y:683,t:1526919034471};\\\", \\\"{x:485,y:687,t:1526919034488};\\\", \\\"{x:486,y:690,t:1526919034504};\\\", \\\"{x:489,y:694,t:1526919034521};\\\", \\\"{x:492,y:695,t:1526919034539};\\\", \\\"{x:493,y:697,t:1526919034554};\\\", \\\"{x:495,y:698,t:1526919034572};\\\", \\\"{x:496,y:699,t:1526919034588};\\\", \\\"{x:498,y:699,t:1526919034605};\\\", \\\"{x:499,y:701,t:1526919034638};\\\", \\\"{x:502,y:706,t:1526919034654};\\\", \\\"{x:502,y:711,t:1526919034671};\\\", \\\"{x:503,y:716,t:1526919034688};\\\", \\\"{x:505,y:718,t:1526919034704};\\\", \\\"{x:504,y:718,t:1526919035709};\\\", \\\"{x:503,y:718,t:1526919035733};\\\", \\\"{x:502,y:717,t:1526919035764};\\\" ] }, { \\\"rt\\\": 117842, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 534673, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -12 PM-I -I -H -Z -Z -Z -F -F -O -O -O -F -01 PM-H -H -01 PM-01 PM-H -H -U -O -O -12 PM-11 AM-O -H -J -H -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:711,t:1526919045217};\\\", \\\"{x:575,y:699,t:1526919045230};\\\", \\\"{x:685,y:676,t:1526919045246};\\\", \\\"{x:793,y:660,t:1526919045261};\\\", \\\"{x:906,y:648,t:1526919045277};\\\", \\\"{x:1017,y:648,t:1526919045294};\\\", \\\"{x:1122,y:646,t:1526919045312};\\\", \\\"{x:1219,y:646,t:1526919045328};\\\", \\\"{x:1368,y:653,t:1526919045344};\\\", \\\"{x:1454,y:664,t:1526919045361};\\\", \\\"{x:1552,y:680,t:1526919045377};\\\", \\\"{x:1646,y:691,t:1526919045395};\\\", \\\"{x:1737,y:705,t:1526919045412};\\\", \\\"{x:1843,y:721,t:1526919045427};\\\", \\\"{x:1919,y:734,t:1526919045445};\\\", \\\"{x:1919,y:752,t:1526919045462};\\\", \\\"{x:1919,y:770,t:1526919045483};\\\", \\\"{x:1919,y:773,t:1526919045501};\\\", \\\"{x:1919,y:775,t:1526919045517};\\\", \\\"{x:1919,y:781,t:1526919045533};\\\", \\\"{x:1916,y:788,t:1526919045550};\\\", \\\"{x:1907,y:793,t:1526919045568};\\\", \\\"{x:1889,y:794,t:1526919045584};\\\", \\\"{x:1848,y:794,t:1526919045601};\\\", \\\"{x:1801,y:781,t:1526919045618};\\\", \\\"{x:1753,y:758,t:1526919045633};\\\", \\\"{x:1719,y:735,t:1526919045650};\\\", \\\"{x:1698,y:712,t:1526919045668};\\\", \\\"{x:1679,y:678,t:1526919045684};\\\", \\\"{x:1672,y:636,t:1526919045701};\\\", \\\"{x:1672,y:591,t:1526919045718};\\\", \\\"{x:1679,y:538,t:1526919045734};\\\", \\\"{x:1688,y:466,t:1526919045750};\\\", \\\"{x:1701,y:387,t:1526919045768};\\\", \\\"{x:1707,y:327,t:1526919045784};\\\", \\\"{x:1709,y:242,t:1526919045800};\\\", \\\"{x:1709,y:206,t:1526919045818};\\\", \\\"{x:1701,y:175,t:1526919045834};\\\", \\\"{x:1687,y:146,t:1526919045851};\\\", \\\"{x:1677,y:129,t:1526919045868};\\\", \\\"{x:1665,y:120,t:1526919045884};\\\", \\\"{x:1654,y:116,t:1526919045900};\\\", \\\"{x:1640,y:115,t:1526919045918};\\\", \\\"{x:1623,y:115,t:1526919045934};\\\", \\\"{x:1609,y:115,t:1526919045951};\\\", \\\"{x:1586,y:126,t:1526919045968};\\\", \\\"{x:1570,y:131,t:1526919045985};\\\", \\\"{x:1556,y:138,t:1526919046001};\\\", \\\"{x:1544,y:146,t:1526919046018};\\\", \\\"{x:1538,y:159,t:1526919046034};\\\", \\\"{x:1536,y:176,t:1526919046051};\\\", \\\"{x:1536,y:198,t:1526919046068};\\\", \\\"{x:1548,y:230,t:1526919046085};\\\", \\\"{x:1566,y:271,t:1526919046101};\\\", \\\"{x:1585,y:318,t:1526919046118};\\\", \\\"{x:1597,y:355,t:1526919046135};\\\", \\\"{x:1609,y:390,t:1526919046151};\\\", \\\"{x:1622,y:432,t:1526919046168};\\\", \\\"{x:1631,y:463,t:1526919046184};\\\", \\\"{x:1645,y:512,t:1526919046201};\\\", \\\"{x:1653,y:535,t:1526919046218};\\\", \\\"{x:1655,y:557,t:1526919046235};\\\", \\\"{x:1658,y:579,t:1526919046251};\\\", \\\"{x:1659,y:596,t:1526919046268};\\\", \\\"{x:1659,y:608,t:1526919046285};\\\", \\\"{x:1659,y:619,t:1526919046301};\\\", \\\"{x:1658,y:626,t:1526919046318};\\\", \\\"{x:1657,y:630,t:1526919046336};\\\", \\\"{x:1656,y:632,t:1526919046351};\\\", \\\"{x:1655,y:634,t:1526919046440};\\\", \\\"{x:1654,y:634,t:1526919046450};\\\", \\\"{x:1651,y:636,t:1526919046468};\\\", \\\"{x:1648,y:637,t:1526919046485};\\\", \\\"{x:1646,y:638,t:1526919046500};\\\", \\\"{x:1643,y:639,t:1526919046518};\\\", \\\"{x:1641,y:641,t:1526919046535};\\\", \\\"{x:1639,y:643,t:1526919046551};\\\", \\\"{x:1637,y:644,t:1526919046568};\\\", \\\"{x:1634,y:647,t:1526919046584};\\\", \\\"{x:1633,y:649,t:1526919046601};\\\", \\\"{x:1631,y:651,t:1526919046618};\\\", \\\"{x:1630,y:655,t:1526919046635};\\\", \\\"{x:1626,y:659,t:1526919046651};\\\", \\\"{x:1625,y:661,t:1526919046668};\\\", \\\"{x:1622,y:660,t:1526919046713};\\\", \\\"{x:1617,y:656,t:1526919046720};\\\", \\\"{x:1612,y:651,t:1526919046735};\\\", \\\"{x:1592,y:641,t:1526919046753};\\\", \\\"{x:1584,y:637,t:1526919046768};\\\", \\\"{x:1564,y:626,t:1526919046785};\\\", \\\"{x:1549,y:619,t:1526919046801};\\\", \\\"{x:1536,y:608,t:1526919046818};\\\", \\\"{x:1518,y:595,t:1526919046835};\\\", \\\"{x:1497,y:577,t:1526919046852};\\\", \\\"{x:1478,y:563,t:1526919046868};\\\", \\\"{x:1464,y:554,t:1526919046885};\\\", \\\"{x:1454,y:548,t:1526919046902};\\\", \\\"{x:1440,y:542,t:1526919046918};\\\", \\\"{x:1427,y:540,t:1526919046935};\\\", \\\"{x:1414,y:540,t:1526919046952};\\\", \\\"{x:1393,y:540,t:1526919046969};\\\", \\\"{x:1381,y:540,t:1526919046985};\\\", \\\"{x:1369,y:539,t:1526919047002};\\\", \\\"{x:1359,y:535,t:1526919047018};\\\", \\\"{x:1352,y:533,t:1526919047035};\\\", \\\"{x:1348,y:533,t:1526919047052};\\\", \\\"{x:1345,y:530,t:1526919047068};\\\", \\\"{x:1341,y:530,t:1526919047085};\\\", \\\"{x:1336,y:527,t:1526919047102};\\\", \\\"{x:1333,y:524,t:1526919047118};\\\", \\\"{x:1332,y:522,t:1526919047135};\\\", \\\"{x:1332,y:517,t:1526919047152};\\\", \\\"{x:1330,y:507,t:1526919047168};\\\", \\\"{x:1330,y:502,t:1526919047186};\\\", \\\"{x:1330,y:501,t:1526919047203};\\\", \\\"{x:1330,y:500,t:1526919047218};\\\", \\\"{x:1330,y:499,t:1526919047235};\\\", \\\"{x:1330,y:497,t:1526919047257};\\\", \\\"{x:1330,y:496,t:1526919047314};\\\", \\\"{x:1329,y:496,t:1526919047329};\\\", \\\"{x:1328,y:496,t:1526919047337};\\\", \\\"{x:1327,y:496,t:1526919047352};\\\", \\\"{x:1326,y:496,t:1526919047369};\\\", \\\"{x:1324,y:496,t:1526919047386};\\\", \\\"{x:1323,y:497,t:1526919047409};\\\", \\\"{x:1322,y:497,t:1526919047424};\\\", \\\"{x:1321,y:498,t:1526919047435};\\\", \\\"{x:1320,y:498,t:1526919047771};\\\", \\\"{x:1319,y:498,t:1526919047816};\\\", \\\"{x:1318,y:498,t:1526919047849};\\\", \\\"{x:1318,y:497,t:1526919048073};\\\", \\\"{x:1318,y:496,t:1526919048113};\\\", \\\"{x:1317,y:495,t:1526919048145};\\\", \\\"{x:1316,y:495,t:1526919048257};\\\", \\\"{x:1316,y:494,t:1526919048272};\\\", \\\"{x:1315,y:494,t:1526919048338};\\\", \\\"{x:1314,y:494,t:1526919048352};\\\", \\\"{x:1313,y:494,t:1526919048392};\\\", \\\"{x:1312,y:495,t:1526919048424};\\\", \\\"{x:1311,y:496,t:1526919048436};\\\", \\\"{x:1311,y:497,t:1526919048451};\\\", \\\"{x:1310,y:498,t:1526919048469};\\\", \\\"{x:1311,y:498,t:1526919048953};\\\", \\\"{x:1312,y:498,t:1526919048976};\\\", \\\"{x:1313,y:498,t:1526919049441};\\\", \\\"{x:1314,y:497,t:1526919049537};\\\", \\\"{x:1315,y:496,t:1526919049577};\\\", \\\"{x:1316,y:495,t:1526919049586};\\\", \\\"{x:1317,y:495,t:1526919049616};\\\", \\\"{x:1317,y:494,t:1526919049624};\\\", \\\"{x:1318,y:494,t:1526919049689};\\\", \\\"{x:1318,y:496,t:1526919054065};\\\", \\\"{x:1318,y:498,t:1526919054072};\\\", \\\"{x:1318,y:505,t:1526919054090};\\\", \\\"{x:1318,y:510,t:1526919054105};\\\", \\\"{x:1319,y:515,t:1526919054122};\\\", \\\"{x:1322,y:522,t:1526919054140};\\\", \\\"{x:1323,y:529,t:1526919054155};\\\", \\\"{x:1327,y:540,t:1526919054172};\\\", \\\"{x:1328,y:546,t:1526919054189};\\\", \\\"{x:1331,y:554,t:1526919054205};\\\", \\\"{x:1333,y:562,t:1526919054222};\\\", \\\"{x:1336,y:571,t:1526919054240};\\\", \\\"{x:1339,y:577,t:1526919054256};\\\", \\\"{x:1340,y:583,t:1526919054273};\\\", \\\"{x:1340,y:588,t:1526919054289};\\\", \\\"{x:1340,y:594,t:1526919054305};\\\", \\\"{x:1341,y:598,t:1526919054322};\\\", \\\"{x:1341,y:602,t:1526919054342};\\\", \\\"{x:1343,y:605,t:1526919054356};\\\", \\\"{x:1343,y:611,t:1526919054372};\\\", \\\"{x:1343,y:616,t:1526919054389};\\\", \\\"{x:1343,y:620,t:1526919054406};\\\", \\\"{x:1341,y:626,t:1526919054422};\\\", \\\"{x:1340,y:628,t:1526919054439};\\\", \\\"{x:1339,y:633,t:1526919054457};\\\", \\\"{x:1339,y:639,t:1526919054473};\\\", \\\"{x:1336,y:646,t:1526919054489};\\\", \\\"{x:1334,y:653,t:1526919054506};\\\", \\\"{x:1330,y:660,t:1526919054523};\\\", \\\"{x:1326,y:668,t:1526919054541};\\\", \\\"{x:1324,y:676,t:1526919054557};\\\", \\\"{x:1323,y:682,t:1526919054573};\\\", \\\"{x:1321,y:690,t:1526919054589};\\\", \\\"{x:1318,y:702,t:1526919054607};\\\", \\\"{x:1316,y:715,t:1526919054622};\\\", \\\"{x:1315,y:732,t:1526919054639};\\\", \\\"{x:1311,y:752,t:1526919054657};\\\", \\\"{x:1311,y:764,t:1526919054673};\\\", \\\"{x:1311,y:779,t:1526919054689};\\\", \\\"{x:1311,y:793,t:1526919054707};\\\", \\\"{x:1311,y:807,t:1526919054722};\\\", \\\"{x:1311,y:821,t:1526919054740};\\\", \\\"{x:1311,y:833,t:1526919054757};\\\", \\\"{x:1309,y:849,t:1526919054773};\\\", \\\"{x:1306,y:862,t:1526919054790};\\\", \\\"{x:1306,y:875,t:1526919054806};\\\", \\\"{x:1306,y:886,t:1526919054822};\\\", \\\"{x:1306,y:895,t:1526919054840};\\\", \\\"{x:1305,y:902,t:1526919054857};\\\", \\\"{x:1305,y:907,t:1526919054873};\\\", \\\"{x:1305,y:913,t:1526919054889};\\\", \\\"{x:1305,y:916,t:1526919054907};\\\", \\\"{x:1305,y:920,t:1526919054923};\\\", \\\"{x:1305,y:921,t:1526919054940};\\\", \\\"{x:1305,y:923,t:1526919054956};\\\", \\\"{x:1305,y:926,t:1526919054973};\\\", \\\"{x:1305,y:927,t:1526919054992};\\\", \\\"{x:1306,y:928,t:1526919055006};\\\", \\\"{x:1306,y:929,t:1526919055022};\\\", \\\"{x:1307,y:932,t:1526919055040};\\\", \\\"{x:1307,y:935,t:1526919055057};\\\", \\\"{x:1308,y:936,t:1526919055074};\\\", \\\"{x:1308,y:935,t:1526919055297};\\\", \\\"{x:1310,y:931,t:1526919055307};\\\", \\\"{x:1312,y:918,t:1526919055324};\\\", \\\"{x:1315,y:896,t:1526919055341};\\\", \\\"{x:1317,y:873,t:1526919055357};\\\", \\\"{x:1318,y:847,t:1526919055374};\\\", \\\"{x:1318,y:813,t:1526919055390};\\\", \\\"{x:1318,y:769,t:1526919055407};\\\", \\\"{x:1318,y:737,t:1526919055423};\\\", \\\"{x:1321,y:716,t:1526919055440};\\\", \\\"{x:1323,y:695,t:1526919055456};\\\", \\\"{x:1326,y:681,t:1526919055473};\\\", \\\"{x:1327,y:672,t:1526919055489};\\\", \\\"{x:1328,y:665,t:1526919055506};\\\", \\\"{x:1328,y:661,t:1526919055523};\\\", \\\"{x:1330,y:653,t:1526919055540};\\\", \\\"{x:1330,y:648,t:1526919055556};\\\", \\\"{x:1331,y:643,t:1526919055574};\\\", \\\"{x:1331,y:636,t:1526919055589};\\\", \\\"{x:1331,y:632,t:1526919055606};\\\", \\\"{x:1332,y:628,t:1526919055623};\\\", \\\"{x:1332,y:627,t:1526919055640};\\\", \\\"{x:1331,y:627,t:1526919055737};\\\", \\\"{x:1328,y:627,t:1526919055753};\\\", \\\"{x:1325,y:627,t:1526919055761};\\\", \\\"{x:1323,y:627,t:1526919055774};\\\", \\\"{x:1319,y:627,t:1526919055791};\\\", \\\"{x:1318,y:627,t:1526919055806};\\\", \\\"{x:1317,y:627,t:1526919055824};\\\", \\\"{x:1317,y:626,t:1526919055985};\\\", \\\"{x:1317,y:627,t:1526919056090};\\\", \\\"{x:1317,y:629,t:1526919056106};\\\", \\\"{x:1317,y:632,t:1526919056123};\\\", \\\"{x:1316,y:636,t:1526919056143};\\\", \\\"{x:1315,y:638,t:1526919056157};\\\", \\\"{x:1314,y:641,t:1526919056173};\\\", \\\"{x:1314,y:643,t:1526919056191};\\\", \\\"{x:1314,y:645,t:1526919056207};\\\", \\\"{x:1314,y:647,t:1526919056223};\\\", \\\"{x:1314,y:650,t:1526919056241};\\\", \\\"{x:1314,y:654,t:1526919056257};\\\", \\\"{x:1314,y:659,t:1526919056273};\\\", \\\"{x:1314,y:663,t:1526919056290};\\\", \\\"{x:1314,y:668,t:1526919056306};\\\", \\\"{x:1313,y:672,t:1526919056324};\\\", \\\"{x:1313,y:678,t:1526919056343};\\\", \\\"{x:1313,y:682,t:1526919056357};\\\", \\\"{x:1313,y:689,t:1526919056373};\\\", \\\"{x:1313,y:699,t:1526919056390};\\\", \\\"{x:1313,y:707,t:1526919056407};\\\", \\\"{x:1313,y:716,t:1526919056423};\\\", \\\"{x:1313,y:728,t:1526919056440};\\\", \\\"{x:1313,y:738,t:1526919056457};\\\", \\\"{x:1313,y:747,t:1526919056472};\\\", \\\"{x:1314,y:754,t:1526919056490};\\\", \\\"{x:1315,y:760,t:1526919056507};\\\", \\\"{x:1316,y:766,t:1526919056523};\\\", \\\"{x:1317,y:771,t:1526919056540};\\\", \\\"{x:1318,y:775,t:1526919056557};\\\", \\\"{x:1318,y:778,t:1526919056573};\\\", \\\"{x:1318,y:780,t:1526919056590};\\\", \\\"{x:1318,y:781,t:1526919056607};\\\", \\\"{x:1318,y:783,t:1526919056623};\\\", \\\"{x:1319,y:787,t:1526919056639};\\\", \\\"{x:1319,y:790,t:1526919056657};\\\", \\\"{x:1320,y:792,t:1526919056673};\\\", \\\"{x:1320,y:793,t:1526919056704};\\\", \\\"{x:1320,y:794,t:1526919056727};\\\", \\\"{x:1320,y:795,t:1526919056751};\\\", \\\"{x:1320,y:796,t:1526919056759};\\\", \\\"{x:1320,y:797,t:1526919056773};\\\", \\\"{x:1320,y:799,t:1526919056790};\\\", \\\"{x:1320,y:803,t:1526919056807};\\\", \\\"{x:1320,y:810,t:1526919056823};\\\", \\\"{x:1321,y:818,t:1526919056840};\\\", \\\"{x:1322,y:822,t:1526919056858};\\\", \\\"{x:1323,y:826,t:1526919056873};\\\", \\\"{x:1323,y:829,t:1526919056890};\\\", \\\"{x:1323,y:832,t:1526919056907};\\\", \\\"{x:1324,y:835,t:1526919056924};\\\", \\\"{x:1325,y:839,t:1526919056940};\\\", \\\"{x:1325,y:843,t:1526919056958};\\\", \\\"{x:1325,y:847,t:1526919056973};\\\", \\\"{x:1325,y:850,t:1526919056990};\\\", \\\"{x:1325,y:855,t:1526919057007};\\\", \\\"{x:1325,y:864,t:1526919057024};\\\", \\\"{x:1325,y:868,t:1526919057040};\\\", \\\"{x:1326,y:872,t:1526919057058};\\\", \\\"{x:1326,y:879,t:1526919057075};\\\", \\\"{x:1328,y:885,t:1526919057090};\\\", \\\"{x:1328,y:889,t:1526919057108};\\\", \\\"{x:1329,y:896,t:1526919057125};\\\", \\\"{x:1329,y:900,t:1526919057141};\\\", \\\"{x:1329,y:904,t:1526919057158};\\\", \\\"{x:1329,y:910,t:1526919057174};\\\", \\\"{x:1329,y:918,t:1526919057190};\\\", \\\"{x:1329,y:927,t:1526919057208};\\\", \\\"{x:1329,y:947,t:1526919057224};\\\", \\\"{x:1329,y:954,t:1526919057240};\\\", \\\"{x:1329,y:960,t:1526919057257};\\\", \\\"{x:1329,y:967,t:1526919057274};\\\", \\\"{x:1329,y:968,t:1526919057290};\\\", \\\"{x:1328,y:972,t:1526919057308};\\\", \\\"{x:1328,y:975,t:1526919057325};\\\", \\\"{x:1325,y:980,t:1526919057341};\\\", \\\"{x:1324,y:983,t:1526919057357};\\\", \\\"{x:1323,y:986,t:1526919057374};\\\", \\\"{x:1322,y:987,t:1526919057390};\\\", \\\"{x:1322,y:986,t:1526919057489};\\\", \\\"{x:1322,y:985,t:1526919057497};\\\", \\\"{x:1322,y:983,t:1526919057507};\\\", \\\"{x:1322,y:981,t:1526919057524};\\\", \\\"{x:1322,y:980,t:1526919057540};\\\", \\\"{x:1322,y:979,t:1526919057556};\\\", \\\"{x:1322,y:978,t:1526919057777};\\\", \\\"{x:1321,y:976,t:1526919057808};\\\", \\\"{x:1321,y:973,t:1526919057825};\\\", \\\"{x:1319,y:970,t:1526919057841};\\\", \\\"{x:1317,y:966,t:1526919057857};\\\", \\\"{x:1316,y:961,t:1526919057874};\\\", \\\"{x:1313,y:958,t:1526919057892};\\\", \\\"{x:1313,y:957,t:1526919057908};\\\", \\\"{x:1313,y:956,t:1526919057924};\\\", \\\"{x:1313,y:957,t:1526919058097};\\\", \\\"{x:1313,y:958,t:1526919058113};\\\", \\\"{x:1313,y:960,t:1526919058125};\\\", \\\"{x:1313,y:962,t:1526919058141};\\\", \\\"{x:1313,y:963,t:1526919058159};\\\", \\\"{x:1313,y:964,t:1526919058174};\\\", \\\"{x:1313,y:966,t:1526919060073};\\\", \\\"{x:1313,y:967,t:1526919060177};\\\", \\\"{x:1312,y:967,t:1526919060729};\\\", \\\"{x:1311,y:967,t:1526919061369};\\\", \\\"{x:1311,y:966,t:1526919061392};\\\", \\\"{x:1311,y:962,t:1526919061410};\\\", \\\"{x:1310,y:955,t:1526919061427};\\\", \\\"{x:1308,y:945,t:1526919061444};\\\", \\\"{x:1306,y:938,t:1526919061460};\\\", \\\"{x:1306,y:933,t:1526919061477};\\\", \\\"{x:1305,y:927,t:1526919061494};\\\", \\\"{x:1305,y:919,t:1526919061509};\\\", \\\"{x:1303,y:910,t:1526919061527};\\\", \\\"{x:1302,y:901,t:1526919061544};\\\", \\\"{x:1302,y:885,t:1526919061560};\\\", \\\"{x:1302,y:857,t:1526919061576};\\\", \\\"{x:1302,y:841,t:1526919061594};\\\", \\\"{x:1302,y:828,t:1526919061610};\\\", \\\"{x:1302,y:812,t:1526919061627};\\\", \\\"{x:1301,y:795,t:1526919061643};\\\", \\\"{x:1300,y:779,t:1526919061660};\\\", \\\"{x:1300,y:762,t:1526919061677};\\\", \\\"{x:1298,y:742,t:1526919061694};\\\", \\\"{x:1295,y:718,t:1526919061710};\\\", \\\"{x:1290,y:694,t:1526919061727};\\\", \\\"{x:1284,y:666,t:1526919061743};\\\", \\\"{x:1281,y:644,t:1526919061760};\\\", \\\"{x:1274,y:606,t:1526919061777};\\\", \\\"{x:1273,y:582,t:1526919061793};\\\", \\\"{x:1273,y:563,t:1526919061809};\\\", \\\"{x:1273,y:546,t:1526919061827};\\\", \\\"{x:1273,y:533,t:1526919061844};\\\", \\\"{x:1275,y:518,t:1526919061859};\\\", \\\"{x:1277,y:507,t:1526919061877};\\\", \\\"{x:1281,y:495,t:1526919061894};\\\", \\\"{x:1286,y:487,t:1526919061909};\\\", \\\"{x:1288,y:485,t:1526919061927};\\\", \\\"{x:1290,y:484,t:1526919061944};\\\", \\\"{x:1294,y:484,t:1526919061960};\\\", \\\"{x:1298,y:484,t:1526919061976};\\\", \\\"{x:1302,y:487,t:1526919061994};\\\", \\\"{x:1303,y:488,t:1526919062010};\\\", \\\"{x:1304,y:488,t:1526919062027};\\\", \\\"{x:1306,y:490,t:1526919062043};\\\", \\\"{x:1309,y:493,t:1526919062060};\\\", \\\"{x:1310,y:494,t:1526919062077};\\\", \\\"{x:1312,y:497,t:1526919062094};\\\", \\\"{x:1313,y:497,t:1526919062345};\\\", \\\"{x:1313,y:498,t:1526919063009};\\\", \\\"{x:1313,y:499,t:1526919072129};\\\", \\\"{x:1315,y:501,t:1526919078264};\\\", \\\"{x:1315,y:503,t:1526919078273};\\\", \\\"{x:1315,y:504,t:1526919078286};\\\", \\\"{x:1316,y:506,t:1526919078303};\\\", \\\"{x:1313,y:506,t:1526919078551};\\\", \\\"{x:1306,y:505,t:1526919078569};\\\", \\\"{x:1300,y:502,t:1526919078586};\\\", \\\"{x:1294,y:501,t:1526919078602};\\\", \\\"{x:1290,y:499,t:1526919078619};\\\", \\\"{x:1291,y:499,t:1526919078976};\\\", \\\"{x:1292,y:499,t:1526919078986};\\\", \\\"{x:1298,y:499,t:1526919079003};\\\", \\\"{x:1305,y:499,t:1526919079019};\\\", \\\"{x:1314,y:499,t:1526919079036};\\\", \\\"{x:1317,y:499,t:1526919079053};\\\", \\\"{x:1319,y:499,t:1526919079069};\\\", \\\"{x:1320,y:499,t:1526919079410};\\\", \\\"{x:1323,y:501,t:1526919079420};\\\", \\\"{x:1328,y:506,t:1526919079436};\\\", \\\"{x:1331,y:510,t:1526919079453};\\\", \\\"{x:1334,y:513,t:1526919079470};\\\", \\\"{x:1335,y:514,t:1526919079486};\\\", \\\"{x:1336,y:516,t:1526919079527};\\\", \\\"{x:1336,y:517,t:1526919080056};\\\", \\\"{x:1345,y:521,t:1526919080070};\\\", \\\"{x:1369,y:527,t:1526919080087};\\\", \\\"{x:1394,y:534,t:1526919080103};\\\", \\\"{x:1429,y:543,t:1526919080120};\\\", \\\"{x:1450,y:548,t:1526919080137};\\\", \\\"{x:1464,y:552,t:1526919080153};\\\", \\\"{x:1469,y:555,t:1526919080170};\\\", \\\"{x:1473,y:558,t:1526919080187};\\\", \\\"{x:1475,y:560,t:1526919080203};\\\", \\\"{x:1476,y:561,t:1526919080220};\\\", \\\"{x:1478,y:562,t:1526919080237};\\\", \\\"{x:1479,y:563,t:1526919080256};\\\", \\\"{x:1480,y:564,t:1526919080296};\\\", \\\"{x:1481,y:564,t:1526919080313};\\\", \\\"{x:1480,y:565,t:1526919080329};\\\", \\\"{x:1476,y:568,t:1526919080338};\\\", \\\"{x:1463,y:572,t:1526919080353};\\\", \\\"{x:1450,y:574,t:1526919080370};\\\", \\\"{x:1441,y:574,t:1526919080387};\\\", \\\"{x:1435,y:576,t:1526919080402};\\\", \\\"{x:1430,y:576,t:1526919080420};\\\", \\\"{x:1428,y:576,t:1526919080437};\\\", \\\"{x:1427,y:575,t:1526919080472};\\\", \\\"{x:1427,y:574,t:1526919080495};\\\", \\\"{x:1427,y:573,t:1526919080512};\\\", \\\"{x:1427,y:572,t:1526919080520};\\\", \\\"{x:1426,y:570,t:1526919080632};\\\", \\\"{x:1425,y:569,t:1526919080656};\\\", \\\"{x:1424,y:568,t:1526919080672};\\\", \\\"{x:1421,y:567,t:1526919080687};\\\", \\\"{x:1417,y:567,t:1526919080704};\\\", \\\"{x:1415,y:567,t:1526919080720};\\\", \\\"{x:1413,y:567,t:1526919080736};\\\", \\\"{x:1411,y:567,t:1526919080754};\\\", \\\"{x:1410,y:566,t:1526919080944};\\\", \\\"{x:1410,y:565,t:1526919081232};\\\", \\\"{x:1410,y:563,t:1526919081240};\\\", \\\"{x:1409,y:564,t:1526919081505};\\\", \\\"{x:1408,y:566,t:1526919081523};\\\", \\\"{x:1407,y:567,t:1526919081537};\\\", \\\"{x:1404,y:571,t:1526919081554};\\\", \\\"{x:1402,y:574,t:1526919081572};\\\", \\\"{x:1399,y:580,t:1526919081587};\\\", \\\"{x:1396,y:585,t:1526919081604};\\\", \\\"{x:1393,y:592,t:1526919081621};\\\", \\\"{x:1392,y:598,t:1526919081637};\\\", \\\"{x:1392,y:611,t:1526919081655};\\\", \\\"{x:1392,y:622,t:1526919081671};\\\", \\\"{x:1391,y:633,t:1526919081688};\\\", \\\"{x:1388,y:647,t:1526919081704};\\\", \\\"{x:1386,y:653,t:1526919081722};\\\", \\\"{x:1384,y:661,t:1526919081737};\\\", \\\"{x:1383,y:665,t:1526919081754};\\\", \\\"{x:1383,y:669,t:1526919081772};\\\", \\\"{x:1383,y:675,t:1526919081787};\\\", \\\"{x:1383,y:683,t:1526919081804};\\\", \\\"{x:1383,y:692,t:1526919081821};\\\", \\\"{x:1385,y:706,t:1526919081838};\\\", \\\"{x:1389,y:719,t:1526919081855};\\\", \\\"{x:1391,y:732,t:1526919081871};\\\", \\\"{x:1396,y:748,t:1526919081887};\\\", \\\"{x:1402,y:769,t:1526919081904};\\\", \\\"{x:1404,y:777,t:1526919081921};\\\", \\\"{x:1404,y:782,t:1526919081939};\\\", \\\"{x:1405,y:786,t:1526919081954};\\\", \\\"{x:1405,y:792,t:1526919081971};\\\", \\\"{x:1405,y:797,t:1526919081989};\\\", \\\"{x:1404,y:803,t:1526919082004};\\\", \\\"{x:1402,y:809,t:1526919082021};\\\", \\\"{x:1401,y:811,t:1526919082038};\\\", \\\"{x:1400,y:811,t:1526919082054};\\\", \\\"{x:1399,y:811,t:1526919082072};\\\", \\\"{x:1398,y:811,t:1526919082089};\\\", \\\"{x:1395,y:807,t:1526919082104};\\\", \\\"{x:1390,y:797,t:1526919082121};\\\", \\\"{x:1383,y:785,t:1526919082139};\\\", \\\"{x:1376,y:774,t:1526919082155};\\\", \\\"{x:1373,y:767,t:1526919082172};\\\", \\\"{x:1372,y:765,t:1526919082188};\\\", \\\"{x:1370,y:762,t:1526919082204};\\\", \\\"{x:1369,y:757,t:1526919082221};\\\", \\\"{x:1368,y:751,t:1526919082239};\\\", \\\"{x:1364,y:739,t:1526919082254};\\\", \\\"{x:1351,y:708,t:1526919082272};\\\", \\\"{x:1340,y:685,t:1526919082288};\\\", \\\"{x:1332,y:669,t:1526919082305};\\\", \\\"{x:1327,y:655,t:1526919082322};\\\", \\\"{x:1325,y:644,t:1526919082340};\\\", \\\"{x:1324,y:640,t:1526919082354};\\\", \\\"{x:1327,y:643,t:1526919082464};\\\", \\\"{x:1329,y:647,t:1526919082471};\\\", \\\"{x:1336,y:659,t:1526919082488};\\\", \\\"{x:1343,y:678,t:1526919082504};\\\", \\\"{x:1348,y:695,t:1526919082521};\\\", \\\"{x:1353,y:710,t:1526919082539};\\\", \\\"{x:1358,y:724,t:1526919082555};\\\", \\\"{x:1360,y:735,t:1526919082571};\\\", \\\"{x:1364,y:749,t:1526919082589};\\\", \\\"{x:1367,y:760,t:1526919082605};\\\", \\\"{x:1368,y:770,t:1526919082621};\\\", \\\"{x:1369,y:777,t:1526919082638};\\\", \\\"{x:1369,y:786,t:1526919082656};\\\", \\\"{x:1369,y:793,t:1526919082672};\\\", \\\"{x:1369,y:803,t:1526919082688};\\\", \\\"{x:1368,y:810,t:1526919082705};\\\", \\\"{x:1366,y:818,t:1526919082722};\\\", \\\"{x:1364,y:824,t:1526919082738};\\\", \\\"{x:1359,y:832,t:1526919082755};\\\", \\\"{x:1357,y:839,t:1526919082771};\\\", \\\"{x:1354,y:848,t:1526919082788};\\\", \\\"{x:1353,y:857,t:1526919082806};\\\", \\\"{x:1351,y:868,t:1526919082821};\\\", \\\"{x:1351,y:877,t:1526919082839};\\\", \\\"{x:1351,y:895,t:1526919082856};\\\", \\\"{x:1351,y:899,t:1526919082872};\\\", \\\"{x:1350,y:913,t:1526919082889};\\\", \\\"{x:1350,y:919,t:1526919082905};\\\", \\\"{x:1350,y:924,t:1526919082922};\\\", \\\"{x:1350,y:925,t:1526919082938};\\\", \\\"{x:1350,y:926,t:1526919082955};\\\", \\\"{x:1349,y:924,t:1526919083105};\\\", \\\"{x:1346,y:916,t:1526919083122};\\\", \\\"{x:1345,y:909,t:1526919083139};\\\", \\\"{x:1345,y:905,t:1526919083156};\\\", \\\"{x:1345,y:900,t:1526919083172};\\\", \\\"{x:1345,y:897,t:1526919083188};\\\", \\\"{x:1345,y:894,t:1526919083205};\\\", \\\"{x:1345,y:893,t:1526919083222};\\\", \\\"{x:1345,y:892,t:1526919083257};\\\", \\\"{x:1345,y:891,t:1526919084233};\\\", \\\"{x:1346,y:890,t:1526919084240};\\\", \\\"{x:1346,y:889,t:1526919084264};\\\", \\\"{x:1346,y:888,t:1526919084272};\\\", \\\"{x:1346,y:887,t:1526919084289};\\\", \\\"{x:1347,y:885,t:1526919084305};\\\", \\\"{x:1347,y:884,t:1526919084322};\\\", \\\"{x:1347,y:881,t:1526919084341};\\\", \\\"{x:1347,y:878,t:1526919084355};\\\", \\\"{x:1347,y:874,t:1526919084373};\\\", \\\"{x:1342,y:866,t:1526919084389};\\\", \\\"{x:1340,y:862,t:1526919084406};\\\", \\\"{x:1340,y:861,t:1526919084423};\\\", \\\"{x:1340,y:858,t:1526919084440};\\\", \\\"{x:1340,y:851,t:1526919084456};\\\", \\\"{x:1340,y:845,t:1526919084473};\\\", \\\"{x:1342,y:835,t:1526919084490};\\\", \\\"{x:1345,y:824,t:1526919084506};\\\", \\\"{x:1352,y:813,t:1526919084523};\\\", \\\"{x:1362,y:800,t:1526919084541};\\\", \\\"{x:1367,y:789,t:1526919084557};\\\", \\\"{x:1372,y:778,t:1526919084573};\\\", \\\"{x:1375,y:769,t:1526919084589};\\\", \\\"{x:1378,y:765,t:1526919084607};\\\", \\\"{x:1379,y:762,t:1526919084622};\\\", \\\"{x:1380,y:761,t:1526919084640};\\\", \\\"{x:1380,y:757,t:1526919084657};\\\", \\\"{x:1380,y:756,t:1526919084673};\\\", \\\"{x:1380,y:752,t:1526919084689};\\\", \\\"{x:1380,y:747,t:1526919084707};\\\", \\\"{x:1380,y:741,t:1526919084723};\\\", \\\"{x:1379,y:732,t:1526919084742};\\\", \\\"{x:1376,y:719,t:1526919084756};\\\", \\\"{x:1367,y:704,t:1526919084773};\\\", \\\"{x:1352,y:685,t:1526919084790};\\\", \\\"{x:1339,y:671,t:1526919084807};\\\", \\\"{x:1329,y:660,t:1526919084823};\\\", \\\"{x:1319,y:649,t:1526919084840};\\\", \\\"{x:1308,y:633,t:1526919084856};\\\", \\\"{x:1303,y:625,t:1526919084872};\\\", \\\"{x:1299,y:620,t:1526919084890};\\\", \\\"{x:1296,y:613,t:1526919084906};\\\", \\\"{x:1293,y:608,t:1526919084922};\\\", \\\"{x:1293,y:607,t:1526919084952};\\\", \\\"{x:1293,y:606,t:1526919084976};\\\", \\\"{x:1293,y:605,t:1526919085016};\\\", \\\"{x:1295,y:604,t:1526919085065};\\\", \\\"{x:1296,y:604,t:1526919085081};\\\", \\\"{x:1298,y:604,t:1526919085090};\\\", \\\"{x:1303,y:604,t:1526919085107};\\\", \\\"{x:1310,y:606,t:1526919085124};\\\", \\\"{x:1314,y:607,t:1526919085140};\\\", \\\"{x:1317,y:608,t:1526919085157};\\\", \\\"{x:1321,y:611,t:1526919085174};\\\", \\\"{x:1324,y:614,t:1526919085190};\\\", \\\"{x:1327,y:618,t:1526919085207};\\\", \\\"{x:1330,y:620,t:1526919085224};\\\", \\\"{x:1333,y:627,t:1526919085240};\\\", \\\"{x:1337,y:634,t:1526919085257};\\\", \\\"{x:1342,y:645,t:1526919085274};\\\", \\\"{x:1350,y:658,t:1526919085290};\\\", \\\"{x:1360,y:673,t:1526919085307};\\\", \\\"{x:1368,y:687,t:1526919085323};\\\", \\\"{x:1373,y:696,t:1526919085341};\\\", \\\"{x:1375,y:704,t:1526919085357};\\\", \\\"{x:1379,y:712,t:1526919085373};\\\", \\\"{x:1383,y:720,t:1526919085389};\\\", \\\"{x:1384,y:726,t:1526919085406};\\\", \\\"{x:1386,y:733,t:1526919085423};\\\", \\\"{x:1387,y:737,t:1526919085439};\\\", \\\"{x:1388,y:739,t:1526919085456};\\\", \\\"{x:1388,y:740,t:1526919085473};\\\", \\\"{x:1388,y:741,t:1526919085496};\\\", \\\"{x:1389,y:742,t:1526919085506};\\\", \\\"{x:1389,y:743,t:1526919085527};\\\", \\\"{x:1388,y:741,t:1526919085600};\\\", \\\"{x:1384,y:737,t:1526919085608};\\\", \\\"{x:1363,y:718,t:1526919085623};\\\", \\\"{x:1337,y:694,t:1526919085639};\\\", \\\"{x:1304,y:674,t:1526919085656};\\\", \\\"{x:1284,y:658,t:1526919085673};\\\", \\\"{x:1271,y:646,t:1526919085691};\\\", \\\"{x:1269,y:642,t:1526919085706};\\\", \\\"{x:1269,y:640,t:1526919085723};\\\", \\\"{x:1269,y:637,t:1526919085740};\\\", \\\"{x:1269,y:634,t:1526919085756};\\\", \\\"{x:1269,y:633,t:1526919085773};\\\", \\\"{x:1269,y:632,t:1526919085790};\\\", \\\"{x:1269,y:631,t:1526919085808};\\\", \\\"{x:1269,y:630,t:1526919085832};\\\", \\\"{x:1269,y:629,t:1526919085849};\\\", \\\"{x:1269,y:628,t:1526919085857};\\\", \\\"{x:1270,y:627,t:1526919085874};\\\", \\\"{x:1271,y:627,t:1526919085905};\\\", \\\"{x:1272,y:627,t:1526919085928};\\\", \\\"{x:1273,y:627,t:1526919085944};\\\", \\\"{x:1274,y:627,t:1526919085968};\\\", \\\"{x:1275,y:627,t:1526919085992};\\\", \\\"{x:1277,y:627,t:1526919086016};\\\", \\\"{x:1278,y:627,t:1526919086048};\\\", \\\"{x:1280,y:627,t:1526919086137};\\\", \\\"{x:1284,y:628,t:1526919086144};\\\", \\\"{x:1288,y:629,t:1526919086157};\\\", \\\"{x:1300,y:633,t:1526919086174};\\\", \\\"{x:1313,y:636,t:1526919086191};\\\", \\\"{x:1322,y:639,t:1526919086207};\\\", \\\"{x:1328,y:641,t:1526919086224};\\\", \\\"{x:1328,y:642,t:1526919086272};\\\", \\\"{x:1328,y:643,t:1526919086328};\\\", \\\"{x:1328,y:644,t:1526919086345};\\\", \\\"{x:1326,y:644,t:1526919086455};\\\", \\\"{x:1325,y:644,t:1526919086479};\\\", \\\"{x:1324,y:644,t:1526919086490};\\\", \\\"{x:1323,y:643,t:1526919086507};\\\", \\\"{x:1322,y:643,t:1526919086720};\\\", \\\"{x:1321,y:643,t:1526919086752};\\\", \\\"{x:1319,y:641,t:1526919086768};\\\", \\\"{x:1317,y:641,t:1526919086800};\\\", \\\"{x:1316,y:640,t:1526919086817};\\\", \\\"{x:1315,y:640,t:1526919086848};\\\", \\\"{x:1315,y:639,t:1526919086889};\\\", \\\"{x:1315,y:638,t:1526919087112};\\\", \\\"{x:1315,y:637,t:1526919087136};\\\", \\\"{x:1315,y:636,t:1526919087160};\\\", \\\"{x:1315,y:635,t:1526919087192};\\\", \\\"{x:1315,y:634,t:1526919087472};\\\", \\\"{x:1315,y:633,t:1526919087488};\\\", \\\"{x:1315,y:632,t:1526919087504};\\\", \\\"{x:1315,y:631,t:1526919087568};\\\", \\\"{x:1315,y:630,t:1526919087584};\\\", \\\"{x:1315,y:629,t:1526919087608};\\\", \\\"{x:1315,y:627,t:1526919087639};\\\", \\\"{x:1315,y:626,t:1526919087656};\\\", \\\"{x:1316,y:625,t:1526919087664};\\\", \\\"{x:1316,y:624,t:1526919087675};\\\", \\\"{x:1317,y:623,t:1526919087691};\\\", \\\"{x:1319,y:618,t:1526919087708};\\\", \\\"{x:1321,y:615,t:1526919087725};\\\", \\\"{x:1323,y:611,t:1526919087742};\\\", \\\"{x:1325,y:604,t:1526919087758};\\\", \\\"{x:1327,y:597,t:1526919087775};\\\", \\\"{x:1329,y:580,t:1526919087792};\\\", \\\"{x:1329,y:573,t:1526919087808};\\\", \\\"{x:1330,y:570,t:1526919087824};\\\", \\\"{x:1331,y:567,t:1526919087842};\\\", \\\"{x:1331,y:566,t:1526919087858};\\\", \\\"{x:1332,y:564,t:1526919087875};\\\", \\\"{x:1333,y:562,t:1526919087892};\\\", \\\"{x:1333,y:559,t:1526919087908};\\\", \\\"{x:1335,y:555,t:1526919087925};\\\", \\\"{x:1336,y:552,t:1526919087942};\\\", \\\"{x:1339,y:547,t:1526919087958};\\\", \\\"{x:1343,y:543,t:1526919087975};\\\", \\\"{x:1350,y:536,t:1526919087992};\\\", \\\"{x:1357,y:532,t:1526919088008};\\\", \\\"{x:1368,y:527,t:1526919088025};\\\", \\\"{x:1381,y:522,t:1526919088042};\\\", \\\"{x:1393,y:520,t:1526919088058};\\\", \\\"{x:1402,y:520,t:1526919088075};\\\", \\\"{x:1407,y:520,t:1526919088092};\\\", \\\"{x:1411,y:520,t:1526919088108};\\\", \\\"{x:1413,y:520,t:1526919088124};\\\", \\\"{x:1414,y:520,t:1526919088153};\\\", \\\"{x:1415,y:522,t:1526919088160};\\\", \\\"{x:1417,y:524,t:1526919088175};\\\", \\\"{x:1421,y:535,t:1526919088192};\\\", \\\"{x:1423,y:542,t:1526919088208};\\\", \\\"{x:1423,y:549,t:1526919088225};\\\", \\\"{x:1425,y:557,t:1526919088242};\\\", \\\"{x:1425,y:561,t:1526919088258};\\\", \\\"{x:1425,y:565,t:1526919088275};\\\", \\\"{x:1425,y:568,t:1526919088292};\\\", \\\"{x:1425,y:569,t:1526919088309};\\\", \\\"{x:1425,y:570,t:1526919088325};\\\", \\\"{x:1425,y:571,t:1526919088342};\\\", \\\"{x:1425,y:572,t:1526919088360};\\\", \\\"{x:1424,y:572,t:1526919088457};\\\", \\\"{x:1423,y:572,t:1526919088464};\\\", \\\"{x:1420,y:572,t:1526919088475};\\\", \\\"{x:1417,y:572,t:1526919088492};\\\", \\\"{x:1409,y:572,t:1526919088509};\\\", \\\"{x:1401,y:574,t:1526919088524};\\\", \\\"{x:1388,y:578,t:1526919088541};\\\", \\\"{x:1371,y:585,t:1526919088558};\\\", \\\"{x:1356,y:592,t:1526919088574};\\\", \\\"{x:1344,y:606,t:1526919088591};\\\", \\\"{x:1337,y:616,t:1526919088608};\\\", \\\"{x:1333,y:621,t:1526919088624};\\\", \\\"{x:1333,y:623,t:1526919088642};\\\", \\\"{x:1332,y:626,t:1526919088658};\\\", \\\"{x:1332,y:627,t:1526919088679};\\\", \\\"{x:1332,y:628,t:1526919088691};\\\", \\\"{x:1331,y:629,t:1526919088708};\\\", \\\"{x:1330,y:631,t:1526919088725};\\\", \\\"{x:1329,y:632,t:1526919088741};\\\", \\\"{x:1329,y:633,t:1526919088758};\\\", \\\"{x:1328,y:634,t:1526919088775};\\\", \\\"{x:1326,y:634,t:1526919088792};\\\", \\\"{x:1323,y:635,t:1526919088808};\\\", \\\"{x:1321,y:635,t:1526919088832};\\\", \\\"{x:1320,y:635,t:1526919088842};\\\", \\\"{x:1318,y:635,t:1526919088859};\\\", \\\"{x:1317,y:635,t:1526919088913};\\\", \\\"{x:1316,y:633,t:1526919088944};\\\", \\\"{x:1315,y:632,t:1526919089024};\\\", \\\"{x:1315,y:631,t:1526919089408};\\\", \\\"{x:1314,y:631,t:1526919089426};\\\", \\\"{x:1316,y:637,t:1526919090241};\\\", \\\"{x:1325,y:648,t:1526919090260};\\\", \\\"{x:1333,y:656,t:1526919090275};\\\", \\\"{x:1338,y:665,t:1526919090293};\\\", \\\"{x:1343,y:672,t:1526919090310};\\\", \\\"{x:1345,y:676,t:1526919090325};\\\", \\\"{x:1347,y:679,t:1526919090343};\\\", \\\"{x:1350,y:683,t:1526919090359};\\\", \\\"{x:1350,y:688,t:1526919090375};\\\", \\\"{x:1353,y:697,t:1526919090393};\\\", \\\"{x:1356,y:703,t:1526919090410};\\\", \\\"{x:1356,y:711,t:1526919090425};\\\", \\\"{x:1359,y:718,t:1526919090443};\\\", \\\"{x:1361,y:724,t:1526919090460};\\\", \\\"{x:1364,y:732,t:1526919090476};\\\", \\\"{x:1365,y:737,t:1526919090493};\\\", \\\"{x:1368,y:747,t:1526919090509};\\\", \\\"{x:1370,y:760,t:1526919090525};\\\", \\\"{x:1373,y:776,t:1526919090543};\\\", \\\"{x:1381,y:803,t:1526919090559};\\\", \\\"{x:1389,y:816,t:1526919090576};\\\", \\\"{x:1396,y:835,t:1526919090593};\\\", \\\"{x:1405,y:857,t:1526919090609};\\\", \\\"{x:1417,y:880,t:1526919090625};\\\", \\\"{x:1427,y:903,t:1526919090642};\\\", \\\"{x:1432,y:917,t:1526919090659};\\\", \\\"{x:1434,y:930,t:1526919090676};\\\", \\\"{x:1437,y:943,t:1526919090692};\\\", \\\"{x:1438,y:954,t:1526919090710};\\\", \\\"{x:1439,y:968,t:1526919090726};\\\", \\\"{x:1439,y:981,t:1526919090743};\\\", \\\"{x:1439,y:989,t:1526919090759};\\\", \\\"{x:1439,y:994,t:1526919090776};\\\", \\\"{x:1438,y:996,t:1526919090792};\\\", \\\"{x:1434,y:1001,t:1526919090810};\\\", \\\"{x:1431,y:1002,t:1526919090825};\\\", \\\"{x:1427,y:1006,t:1526919090842};\\\", \\\"{x:1421,y:1006,t:1526919090860};\\\", \\\"{x:1416,y:1006,t:1526919090876};\\\", \\\"{x:1412,y:1006,t:1526919090893};\\\", \\\"{x:1407,y:1006,t:1526919090910};\\\", \\\"{x:1404,y:1003,t:1526919090927};\\\", \\\"{x:1402,y:1001,t:1526919090942};\\\", \\\"{x:1397,y:993,t:1526919090960};\\\", \\\"{x:1395,y:987,t:1526919090976};\\\", \\\"{x:1393,y:980,t:1526919090992};\\\", \\\"{x:1393,y:971,t:1526919091010};\\\", \\\"{x:1391,y:958,t:1526919091026};\\\", \\\"{x:1388,y:942,t:1526919091042};\\\", \\\"{x:1383,y:919,t:1526919091060};\\\", \\\"{x:1377,y:896,t:1526919091077};\\\", \\\"{x:1373,y:876,t:1526919091093};\\\", \\\"{x:1372,y:869,t:1526919091110};\\\", \\\"{x:1372,y:860,t:1526919091127};\\\", \\\"{x:1372,y:851,t:1526919091143};\\\", \\\"{x:1372,y:838,t:1526919091160};\\\", \\\"{x:1371,y:824,t:1526919091176};\\\", \\\"{x:1371,y:816,t:1526919091192};\\\", \\\"{x:1370,y:809,t:1526919091210};\\\", \\\"{x:1368,y:802,t:1526919091227};\\\", \\\"{x:1367,y:797,t:1526919091243};\\\", \\\"{x:1367,y:792,t:1526919091260};\\\", \\\"{x:1367,y:788,t:1526919091277};\\\", \\\"{x:1368,y:784,t:1526919091293};\\\", \\\"{x:1369,y:781,t:1526919091309};\\\", \\\"{x:1371,y:778,t:1526919091326};\\\", \\\"{x:1372,y:776,t:1526919091343};\\\", \\\"{x:1373,y:772,t:1526919091359};\\\", \\\"{x:1374,y:771,t:1526919091376};\\\", \\\"{x:1375,y:769,t:1526919091392};\\\", \\\"{x:1375,y:768,t:1526919091409};\\\", \\\"{x:1376,y:768,t:1526919091426};\\\", \\\"{x:1376,y:767,t:1526919091512};\\\", \\\"{x:1377,y:767,t:1526919091577};\\\", \\\"{x:1378,y:767,t:1526919091640};\\\", \\\"{x:1379,y:767,t:1526919091704};\\\", \\\"{x:1379,y:769,t:1526919091721};\\\", \\\"{x:1379,y:773,t:1526919091727};\\\", \\\"{x:1379,y:780,t:1526919091744};\\\", \\\"{x:1380,y:788,t:1526919091759};\\\", \\\"{x:1382,y:797,t:1526919091776};\\\", \\\"{x:1383,y:803,t:1526919091794};\\\", \\\"{x:1383,y:810,t:1526919091810};\\\", \\\"{x:1385,y:817,t:1526919091827};\\\", \\\"{x:1385,y:829,t:1526919091844};\\\", \\\"{x:1386,y:839,t:1526919091859};\\\", \\\"{x:1386,y:849,t:1526919091877};\\\", \\\"{x:1387,y:856,t:1526919091894};\\\", \\\"{x:1387,y:863,t:1526919091910};\\\", \\\"{x:1387,y:869,t:1526919091927};\\\", \\\"{x:1387,y:882,t:1526919091944};\\\", \\\"{x:1387,y:890,t:1526919091960};\\\", \\\"{x:1387,y:903,t:1526919091977};\\\", \\\"{x:1387,y:913,t:1526919091994};\\\", \\\"{x:1387,y:927,t:1526919092010};\\\", \\\"{x:1387,y:934,t:1526919092027};\\\", \\\"{x:1387,y:940,t:1526919092044};\\\", \\\"{x:1387,y:944,t:1526919092060};\\\", \\\"{x:1387,y:949,t:1526919092077};\\\", \\\"{x:1387,y:953,t:1526919092094};\\\", \\\"{x:1387,y:958,t:1526919092110};\\\", \\\"{x:1386,y:961,t:1526919092127};\\\", \\\"{x:1385,y:965,t:1526919092144};\\\", \\\"{x:1384,y:969,t:1526919092160};\\\", \\\"{x:1384,y:971,t:1526919092208};\\\", \\\"{x:1384,y:972,t:1526919092257};\\\", \\\"{x:1383,y:972,t:1526919092384};\\\", \\\"{x:1382,y:972,t:1526919092416};\\\", \\\"{x:1381,y:972,t:1526919092432};\\\", \\\"{x:1381,y:971,t:1526919092464};\\\", \\\"{x:1381,y:969,t:1526919092480};\\\", \\\"{x:1381,y:968,t:1526919092529};\\\", \\\"{x:1381,y:966,t:1526919092576};\\\", \\\"{x:1381,y:965,t:1526919092641};\\\", \\\"{x:1382,y:966,t:1526919093384};\\\", \\\"{x:1382,y:968,t:1526919093394};\\\", \\\"{x:1382,y:971,t:1526919093412};\\\", \\\"{x:1383,y:973,t:1526919093428};\\\", \\\"{x:1383,y:972,t:1526919093624};\\\", \\\"{x:1383,y:970,t:1526919093632};\\\", \\\"{x:1383,y:968,t:1526919093644};\\\", \\\"{x:1383,y:967,t:1526919093679};\\\", \\\"{x:1383,y:966,t:1526919097513};\\\", \\\"{x:1382,y:965,t:1526919097577};\\\", \\\"{x:1382,y:964,t:1526919100100};\\\", \\\"{x:1382,y:961,t:1526919100108};\\\", \\\"{x:1387,y:956,t:1526919100119};\\\", \\\"{x:1399,y:938,t:1526919100135};\\\", \\\"{x:1414,y:919,t:1526919100152};\\\", \\\"{x:1426,y:901,t:1526919100169};\\\", \\\"{x:1432,y:887,t:1526919100185};\\\", \\\"{x:1435,y:876,t:1526919100202};\\\", \\\"{x:1436,y:865,t:1526919100219};\\\", \\\"{x:1437,y:860,t:1526919100235};\\\", \\\"{x:1440,y:852,t:1526919100251};\\\", \\\"{x:1440,y:848,t:1526919100268};\\\", \\\"{x:1440,y:846,t:1526919100285};\\\", \\\"{x:1441,y:845,t:1526919100412};\\\", \\\"{x:1442,y:845,t:1526919100428};\\\", \\\"{x:1442,y:846,t:1526919100436};\\\", \\\"{x:1442,y:853,t:1526919100452};\\\", \\\"{x:1442,y:862,t:1526919100469};\\\", \\\"{x:1442,y:869,t:1526919100485};\\\", \\\"{x:1443,y:876,t:1526919100502};\\\", \\\"{x:1444,y:883,t:1526919100519};\\\", \\\"{x:1445,y:890,t:1526919100536};\\\", \\\"{x:1445,y:895,t:1526919100552};\\\", \\\"{x:1445,y:902,t:1526919100569};\\\", \\\"{x:1446,y:908,t:1526919100587};\\\", \\\"{x:1447,y:911,t:1526919100602};\\\", \\\"{x:1448,y:916,t:1526919100620};\\\", \\\"{x:1448,y:917,t:1526919100635};\\\", \\\"{x:1450,y:924,t:1526919100652};\\\", \\\"{x:1451,y:928,t:1526919100669};\\\", \\\"{x:1451,y:932,t:1526919100686};\\\", \\\"{x:1451,y:936,t:1526919100702};\\\", \\\"{x:1452,y:941,t:1526919100719};\\\", \\\"{x:1452,y:944,t:1526919100736};\\\", \\\"{x:1452,y:948,t:1526919100752};\\\", \\\"{x:1452,y:950,t:1526919100769};\\\", \\\"{x:1452,y:952,t:1526919100786};\\\", \\\"{x:1452,y:955,t:1526919100802};\\\", \\\"{x:1452,y:957,t:1526919100820};\\\", \\\"{x:1452,y:959,t:1526919100836};\\\", \\\"{x:1450,y:962,t:1526919100852};\\\", \\\"{x:1447,y:964,t:1526919100869};\\\", \\\"{x:1445,y:966,t:1526919100886};\\\", \\\"{x:1442,y:969,t:1526919100901};\\\", \\\"{x:1439,y:971,t:1526919100919};\\\", \\\"{x:1435,y:974,t:1526919100936};\\\", \\\"{x:1432,y:976,t:1526919100951};\\\", \\\"{x:1429,y:977,t:1526919100969};\\\", \\\"{x:1428,y:979,t:1526919100986};\\\", \\\"{x:1426,y:979,t:1526919101003};\\\", \\\"{x:1426,y:978,t:1526919101108};\\\", \\\"{x:1426,y:977,t:1526919101123};\\\", \\\"{x:1425,y:976,t:1526919101136};\\\", \\\"{x:1425,y:973,t:1526919101153};\\\", \\\"{x:1425,y:966,t:1526919101170};\\\", \\\"{x:1424,y:960,t:1526919101186};\\\", \\\"{x:1424,y:954,t:1526919101203};\\\", \\\"{x:1424,y:944,t:1526919101219};\\\", \\\"{x:1424,y:929,t:1526919101236};\\\", \\\"{x:1423,y:916,t:1526919101253};\\\", \\\"{x:1423,y:907,t:1526919101269};\\\", \\\"{x:1423,y:897,t:1526919101286};\\\", \\\"{x:1423,y:890,t:1526919101303};\\\", \\\"{x:1423,y:886,t:1526919101319};\\\", \\\"{x:1423,y:880,t:1526919101336};\\\", \\\"{x:1423,y:875,t:1526919101353};\\\", \\\"{x:1424,y:871,t:1526919101369};\\\", \\\"{x:1425,y:867,t:1526919101386};\\\", \\\"{x:1425,y:860,t:1526919101403};\\\", \\\"{x:1426,y:857,t:1526919101419};\\\", \\\"{x:1426,y:847,t:1526919101435};\\\", \\\"{x:1426,y:842,t:1526919101452};\\\", \\\"{x:1426,y:839,t:1526919101468};\\\", \\\"{x:1426,y:835,t:1526919101485};\\\", \\\"{x:1426,y:833,t:1526919101502};\\\", \\\"{x:1426,y:831,t:1526919101518};\\\", \\\"{x:1426,y:832,t:1526919101756};\\\", \\\"{x:1426,y:833,t:1526919101769};\\\", \\\"{x:1426,y:835,t:1526919101786};\\\", \\\"{x:1426,y:837,t:1526919101803};\\\", \\\"{x:1426,y:838,t:1526919101820};\\\", \\\"{x:1425,y:837,t:1526919101972};\\\", \\\"{x:1425,y:833,t:1526919101986};\\\", \\\"{x:1423,y:825,t:1526919102003};\\\", \\\"{x:1422,y:817,t:1526919102019};\\\", \\\"{x:1421,y:809,t:1526919102035};\\\", \\\"{x:1419,y:802,t:1526919102053};\\\", \\\"{x:1418,y:792,t:1526919102070};\\\", \\\"{x:1417,y:780,t:1526919102086};\\\", \\\"{x:1417,y:763,t:1526919102103};\\\", \\\"{x:1417,y:741,t:1526919102119};\\\", \\\"{x:1417,y:718,t:1526919102135};\\\", \\\"{x:1417,y:691,t:1526919102153};\\\", \\\"{x:1417,y:669,t:1526919102170};\\\", \\\"{x:1417,y:655,t:1526919102186};\\\", \\\"{x:1417,y:643,t:1526919102203};\\\", \\\"{x:1417,y:626,t:1526919102219};\\\", \\\"{x:1417,y:618,t:1526919102236};\\\", \\\"{x:1417,y:614,t:1526919102253};\\\", \\\"{x:1417,y:609,t:1526919102269};\\\", \\\"{x:1417,y:605,t:1526919102286};\\\", \\\"{x:1418,y:598,t:1526919102302};\\\", \\\"{x:1419,y:594,t:1526919102320};\\\", \\\"{x:1419,y:593,t:1526919102339};\\\", \\\"{x:1419,y:591,t:1526919102404};\\\", \\\"{x:1419,y:588,t:1526919102419};\\\", \\\"{x:1419,y:585,t:1526919102437};\\\", \\\"{x:1419,y:581,t:1526919102453};\\\", \\\"{x:1419,y:577,t:1526919102470};\\\", \\\"{x:1419,y:575,t:1526919102487};\\\", \\\"{x:1419,y:574,t:1526919102503};\\\", \\\"{x:1419,y:572,t:1526919102520};\\\", \\\"{x:1419,y:570,t:1526919102537};\\\", \\\"{x:1419,y:569,t:1526919102553};\\\", \\\"{x:1419,y:567,t:1526919102570};\\\", \\\"{x:1419,y:566,t:1526919102587};\\\", \\\"{x:1419,y:565,t:1526919102602};\\\", \\\"{x:1419,y:564,t:1526919102619};\\\", \\\"{x:1419,y:563,t:1526919102668};\\\", \\\"{x:1418,y:564,t:1526919103236};\\\", \\\"{x:1418,y:569,t:1526919103255};\\\", \\\"{x:1417,y:575,t:1526919103270};\\\", \\\"{x:1415,y:584,t:1526919103287};\\\", \\\"{x:1414,y:594,t:1526919103304};\\\", \\\"{x:1414,y:601,t:1526919103320};\\\", \\\"{x:1414,y:606,t:1526919103337};\\\", \\\"{x:1414,y:610,t:1526919103354};\\\", \\\"{x:1414,y:612,t:1526919103370};\\\", \\\"{x:1414,y:613,t:1526919103387};\\\", \\\"{x:1414,y:615,t:1526919103402};\\\", \\\"{x:1414,y:614,t:1526919103563};\\\", \\\"{x:1414,y:611,t:1526919103571};\\\", \\\"{x:1414,y:603,t:1526919103587};\\\", \\\"{x:1414,y:593,t:1526919103603};\\\", \\\"{x:1414,y:584,t:1526919103620};\\\", \\\"{x:1414,y:577,t:1526919103637};\\\", \\\"{x:1414,y:570,t:1526919103654};\\\", \\\"{x:1414,y:567,t:1526919103671};\\\", \\\"{x:1414,y:564,t:1526919103687};\\\", \\\"{x:1414,y:563,t:1526919103732};\\\", \\\"{x:1414,y:566,t:1526919103836};\\\", \\\"{x:1413,y:575,t:1526919103854};\\\", \\\"{x:1412,y:587,t:1526919103871};\\\", \\\"{x:1412,y:602,t:1526919103887};\\\", \\\"{x:1412,y:617,t:1526919103904};\\\", \\\"{x:1412,y:635,t:1526919103921};\\\", \\\"{x:1412,y:647,t:1526919103937};\\\", \\\"{x:1412,y:662,t:1526919103954};\\\", \\\"{x:1412,y:679,t:1526919103971};\\\", \\\"{x:1412,y:687,t:1526919103987};\\\", \\\"{x:1412,y:699,t:1526919104004};\\\", \\\"{x:1412,y:710,t:1526919104021};\\\", \\\"{x:1415,y:719,t:1526919104037};\\\", \\\"{x:1416,y:725,t:1526919104053};\\\", \\\"{x:1416,y:730,t:1526919104070};\\\", \\\"{x:1416,y:735,t:1526919104087};\\\", \\\"{x:1416,y:737,t:1526919104104};\\\", \\\"{x:1416,y:739,t:1526919104120};\\\", \\\"{x:1416,y:741,t:1526919104136};\\\", \\\"{x:1416,y:742,t:1526919104154};\\\", \\\"{x:1416,y:743,t:1526919104171};\\\", \\\"{x:1416,y:744,t:1526919104195};\\\", \\\"{x:1416,y:745,t:1526919104204};\\\", \\\"{x:1416,y:747,t:1526919104221};\\\", \\\"{x:1416,y:750,t:1526919104237};\\\", \\\"{x:1415,y:752,t:1526919104254};\\\", \\\"{x:1415,y:755,t:1526919104271};\\\", \\\"{x:1415,y:757,t:1526919104288};\\\", \\\"{x:1414,y:762,t:1526919104304};\\\", \\\"{x:1413,y:767,t:1526919104321};\\\", \\\"{x:1412,y:776,t:1526919104338};\\\", \\\"{x:1411,y:786,t:1526919104354};\\\", \\\"{x:1410,y:793,t:1526919104371};\\\", \\\"{x:1410,y:799,t:1526919104387};\\\", \\\"{x:1410,y:806,t:1526919104404};\\\", \\\"{x:1410,y:813,t:1526919104421};\\\", \\\"{x:1409,y:822,t:1526919104438};\\\", \\\"{x:1409,y:834,t:1526919104454};\\\", \\\"{x:1409,y:849,t:1526919104471};\\\", \\\"{x:1409,y:862,t:1526919104488};\\\", \\\"{x:1409,y:871,t:1526919104504};\\\", \\\"{x:1409,y:885,t:1526919104521};\\\", \\\"{x:1409,y:899,t:1526919104538};\\\", \\\"{x:1409,y:917,t:1526919104554};\\\", \\\"{x:1409,y:944,t:1526919104572};\\\", \\\"{x:1409,y:963,t:1526919104587};\\\", \\\"{x:1409,y:974,t:1526919104604};\\\", \\\"{x:1409,y:981,t:1526919104621};\\\", \\\"{x:1409,y:984,t:1526919104638};\\\", \\\"{x:1409,y:988,t:1526919104655};\\\", \\\"{x:1409,y:989,t:1526919104671};\\\", \\\"{x:1409,y:990,t:1526919104688};\\\", \\\"{x:1409,y:992,t:1526919104704};\\\", \\\"{x:1409,y:991,t:1526919104844};\\\", \\\"{x:1409,y:987,t:1526919104854};\\\", \\\"{x:1409,y:980,t:1526919104871};\\\", \\\"{x:1411,y:970,t:1526919104888};\\\", \\\"{x:1411,y:964,t:1526919104904};\\\", \\\"{x:1412,y:958,t:1526919104921};\\\", \\\"{x:1413,y:955,t:1526919104938};\\\", \\\"{x:1414,y:947,t:1526919104955};\\\", \\\"{x:1415,y:935,t:1526919104971};\\\", \\\"{x:1415,y:917,t:1526919104988};\\\", \\\"{x:1415,y:894,t:1526919105005};\\\", \\\"{x:1415,y:864,t:1526919105021};\\\", \\\"{x:1415,y:836,t:1526919105038};\\\", \\\"{x:1415,y:804,t:1526919105055};\\\", \\\"{x:1415,y:776,t:1526919105071};\\\", \\\"{x:1415,y:746,t:1526919105088};\\\", \\\"{x:1415,y:714,t:1526919105105};\\\", \\\"{x:1415,y:688,t:1526919105121};\\\", \\\"{x:1415,y:672,t:1526919105138};\\\", \\\"{x:1415,y:644,t:1526919105155};\\\", \\\"{x:1415,y:632,t:1526919105172};\\\", \\\"{x:1415,y:621,t:1526919105187};\\\", \\\"{x:1415,y:613,t:1526919105205};\\\", \\\"{x:1415,y:607,t:1526919105221};\\\", \\\"{x:1415,y:603,t:1526919105238};\\\", \\\"{x:1414,y:603,t:1526919105255};\\\", \\\"{x:1414,y:602,t:1526919105271};\\\", \\\"{x:1411,y:597,t:1526919105288};\\\", \\\"{x:1407,y:589,t:1526919105305};\\\", \\\"{x:1403,y:584,t:1526919105321};\\\", \\\"{x:1400,y:581,t:1526919105338};\\\", \\\"{x:1399,y:577,t:1526919105355};\\\", \\\"{x:1399,y:576,t:1526919105428};\\\", \\\"{x:1399,y:573,t:1526919105438};\\\", \\\"{x:1401,y:570,t:1526919105455};\\\", \\\"{x:1404,y:565,t:1526919105471};\\\", \\\"{x:1408,y:559,t:1526919105488};\\\", \\\"{x:1416,y:552,t:1526919105505};\\\", \\\"{x:1422,y:546,t:1526919105522};\\\", \\\"{x:1429,y:538,t:1526919105538};\\\", \\\"{x:1431,y:534,t:1526919105555};\\\", \\\"{x:1431,y:533,t:1526919105571};\\\", \\\"{x:1432,y:532,t:1526919105588};\\\", \\\"{x:1433,y:532,t:1526919105627};\\\", \\\"{x:1435,y:532,t:1526919105638};\\\", \\\"{x:1437,y:532,t:1526919105655};\\\", \\\"{x:1438,y:536,t:1526919105672};\\\", \\\"{x:1438,y:543,t:1526919105688};\\\", \\\"{x:1438,y:548,t:1526919105705};\\\", \\\"{x:1438,y:552,t:1526919105722};\\\", \\\"{x:1438,y:553,t:1526919105738};\\\", \\\"{x:1437,y:557,t:1526919105755};\\\", \\\"{x:1435,y:561,t:1526919105772};\\\", \\\"{x:1431,y:565,t:1526919105788};\\\", \\\"{x:1427,y:568,t:1526919105805};\\\", \\\"{x:1425,y:568,t:1526919105822};\\\", \\\"{x:1423,y:568,t:1526919105843};\\\", \\\"{x:1422,y:568,t:1526919105884};\\\", \\\"{x:1421,y:568,t:1526919105995};\\\", \\\"{x:1420,y:568,t:1526919106005};\\\", \\\"{x:1419,y:568,t:1526919106035};\\\", \\\"{x:1418,y:568,t:1526919106068};\\\", \\\"{x:1417,y:568,t:1526919106099};\\\", \\\"{x:1416,y:568,t:1526919106123};\\\", \\\"{x:1415,y:567,t:1526919106147};\\\", \\\"{x:1414,y:567,t:1526919106155};\\\", \\\"{x:1413,y:566,t:1526919106172};\\\", \\\"{x:1412,y:565,t:1526919106220};\\\", \\\"{x:1412,y:571,t:1526919111836};\\\", \\\"{x:1416,y:579,t:1526919111843};\\\", \\\"{x:1422,y:587,t:1526919111858};\\\", \\\"{x:1442,y:610,t:1526919111875};\\\", \\\"{x:1464,y:636,t:1526919111891};\\\", \\\"{x:1490,y:666,t:1526919111909};\\\", \\\"{x:1511,y:692,t:1526919111925};\\\", \\\"{x:1526,y:711,t:1526919111944};\\\", \\\"{x:1538,y:731,t:1526919111958};\\\", \\\"{x:1547,y:748,t:1526919111975};\\\", \\\"{x:1552,y:763,t:1526919111992};\\\", \\\"{x:1556,y:771,t:1526919112009};\\\", \\\"{x:1556,y:772,t:1526919112025};\\\", \\\"{x:1556,y:773,t:1526919112042};\\\", \\\"{x:1556,y:775,t:1526919112067};\\\", \\\"{x:1556,y:776,t:1526919112075};\\\", \\\"{x:1556,y:780,t:1526919112092};\\\", \\\"{x:1556,y:785,t:1526919112109};\\\", \\\"{x:1556,y:789,t:1526919112125};\\\", \\\"{x:1553,y:795,t:1526919112144};\\\", \\\"{x:1548,y:801,t:1526919112159};\\\", \\\"{x:1542,y:807,t:1526919112176};\\\", \\\"{x:1537,y:813,t:1526919112192};\\\", \\\"{x:1532,y:816,t:1526919112209};\\\", \\\"{x:1529,y:819,t:1526919112226};\\\", \\\"{x:1526,y:822,t:1526919112242};\\\", \\\"{x:1524,y:823,t:1526919112258};\\\", \\\"{x:1521,y:826,t:1526919112275};\\\", \\\"{x:1518,y:828,t:1526919112292};\\\", \\\"{x:1516,y:829,t:1526919112308};\\\", \\\"{x:1512,y:831,t:1526919112326};\\\", \\\"{x:1511,y:831,t:1526919112344};\\\", \\\"{x:1510,y:831,t:1526919112359};\\\", \\\"{x:1508,y:831,t:1526919112376};\\\", \\\"{x:1506,y:831,t:1526919112392};\\\", \\\"{x:1504,y:831,t:1526919112409};\\\", \\\"{x:1498,y:831,t:1526919112425};\\\", \\\"{x:1493,y:831,t:1526919112443};\\\", \\\"{x:1490,y:831,t:1526919112459};\\\", \\\"{x:1487,y:831,t:1526919112475};\\\", \\\"{x:1486,y:831,t:1526919112499};\\\", \\\"{x:1484,y:830,t:1526919112525};\\\", \\\"{x:1483,y:830,t:1526919112544};\\\", \\\"{x:1481,y:830,t:1526919112558};\\\", \\\"{x:1480,y:830,t:1526919112575};\\\", \\\"{x:1478,y:830,t:1526919112593};\\\", \\\"{x:1477,y:830,t:1526919117172};\\\", \\\"{x:1476,y:830,t:1526919117227};\\\", \\\"{x:1475,y:830,t:1526919117412};\\\", \\\"{x:1473,y:829,t:1526919117443};\\\", \\\"{x:1472,y:828,t:1526919117461};\\\", \\\"{x:1465,y:825,t:1526919117478};\\\", \\\"{x:1462,y:822,t:1526919117495};\\\", \\\"{x:1462,y:823,t:1526919117644};\\\", \\\"{x:1456,y:831,t:1526919117661};\\\", \\\"{x:1448,y:838,t:1526919117679};\\\", \\\"{x:1440,y:844,t:1526919117694};\\\", \\\"{x:1433,y:848,t:1526919117711};\\\", \\\"{x:1425,y:852,t:1526919117729};\\\", \\\"{x:1415,y:860,t:1526919117746};\\\", \\\"{x:1403,y:868,t:1526919117762};\\\", \\\"{x:1388,y:878,t:1526919117778};\\\", \\\"{x:1372,y:889,t:1526919117795};\\\", \\\"{x:1357,y:900,t:1526919117811};\\\", \\\"{x:1352,y:904,t:1526919117828};\\\", \\\"{x:1350,y:906,t:1526919117845};\\\", \\\"{x:1349,y:906,t:1526919117883};\\\", \\\"{x:1349,y:908,t:1526919117896};\\\", \\\"{x:1348,y:909,t:1526919117912};\\\", \\\"{x:1346,y:911,t:1526919117928};\\\", \\\"{x:1345,y:913,t:1526919117945};\\\", \\\"{x:1344,y:913,t:1526919117962};\\\", \\\"{x:1346,y:912,t:1526919118107};\\\", \\\"{x:1346,y:911,t:1526919118123};\\\", \\\"{x:1347,y:911,t:1526919118131};\\\", \\\"{x:1347,y:910,t:1526919118145};\\\", \\\"{x:1347,y:909,t:1526919118162};\\\", \\\"{x:1348,y:908,t:1526919118179};\\\", \\\"{x:1350,y:906,t:1526919118195};\\\", \\\"{x:1350,y:905,t:1526919118212};\\\", \\\"{x:1352,y:904,t:1526919118228};\\\", \\\"{x:1352,y:902,t:1526919118246};\\\", \\\"{x:1353,y:901,t:1526919118262};\\\", \\\"{x:1353,y:900,t:1526919118278};\\\", \\\"{x:1354,y:900,t:1526919118467};\\\", \\\"{x:1354,y:899,t:1526919118479};\\\", \\\"{x:1354,y:893,t:1526919118495};\\\", \\\"{x:1352,y:877,t:1526919118512};\\\", \\\"{x:1341,y:852,t:1526919118528};\\\", \\\"{x:1325,y:824,t:1526919118545};\\\", \\\"{x:1304,y:791,t:1526919118562};\\\", \\\"{x:1285,y:758,t:1526919118577};\\\", \\\"{x:1272,y:716,t:1526919118595};\\\", \\\"{x:1266,y:692,t:1526919118612};\\\", \\\"{x:1266,y:671,t:1526919118628};\\\", \\\"{x:1265,y:654,t:1526919118645};\\\", \\\"{x:1265,y:642,t:1526919118662};\\\", \\\"{x:1265,y:629,t:1526919118678};\\\", \\\"{x:1265,y:622,t:1526919118696};\\\", \\\"{x:1265,y:617,t:1526919118712};\\\", \\\"{x:1268,y:612,t:1526919118728};\\\", \\\"{x:1272,y:607,t:1526919118746};\\\", \\\"{x:1276,y:603,t:1526919118763};\\\", \\\"{x:1283,y:599,t:1526919118778};\\\", \\\"{x:1299,y:592,t:1526919118795};\\\", \\\"{x:1311,y:589,t:1526919118812};\\\", \\\"{x:1318,y:587,t:1526919118829};\\\", \\\"{x:1323,y:587,t:1526919118846};\\\", \\\"{x:1324,y:587,t:1526919118863};\\\", \\\"{x:1325,y:587,t:1526919118891};\\\", \\\"{x:1326,y:587,t:1526919118915};\\\", \\\"{x:1327,y:587,t:1526919119004};\\\", \\\"{x:1327,y:589,t:1526919119019};\\\", \\\"{x:1327,y:590,t:1526919119030};\\\", \\\"{x:1327,y:594,t:1526919119045};\\\", \\\"{x:1327,y:598,t:1526919119062};\\\", \\\"{x:1327,y:604,t:1526919119080};\\\", \\\"{x:1327,y:609,t:1526919119096};\\\", \\\"{x:1327,y:613,t:1526919119112};\\\", \\\"{x:1327,y:617,t:1526919119129};\\\", \\\"{x:1326,y:617,t:1526919119145};\\\", \\\"{x:1325,y:617,t:1526919119676};\\\", \\\"{x:1324,y:617,t:1526919120179};\\\", \\\"{x:1324,y:619,t:1526919120348};\\\", \\\"{x:1322,y:624,t:1526919120363};\\\", \\\"{x:1320,y:627,t:1526919120379};\\\", \\\"{x:1319,y:627,t:1526919120397};\\\", \\\"{x:1319,y:629,t:1526919120413};\\\", \\\"{x:1319,y:630,t:1526919120429};\\\", \\\"{x:1319,y:632,t:1526919120446};\\\", \\\"{x:1319,y:633,t:1526919120979};\\\", \\\"{x:1319,y:634,t:1526919121202};\\\", \\\"{x:1319,y:635,t:1526919121213};\\\", \\\"{x:1320,y:636,t:1526919121282};\\\", \\\"{x:1320,y:638,t:1526919121296};\\\", \\\"{x:1320,y:642,t:1526919121313};\\\", \\\"{x:1320,y:646,t:1526919121331};\\\", \\\"{x:1320,y:649,t:1526919121346};\\\", \\\"{x:1319,y:650,t:1526919121364};\\\", \\\"{x:1319,y:651,t:1526919121387};\\\", \\\"{x:1319,y:650,t:1526919121523};\\\", \\\"{x:1319,y:649,t:1526919121531};\\\", \\\"{x:1316,y:641,t:1526919121546};\\\", \\\"{x:1312,y:633,t:1526919121563};\\\", \\\"{x:1310,y:627,t:1526919121580};\\\", \\\"{x:1308,y:624,t:1526919121597};\\\", \\\"{x:1308,y:622,t:1526919121613};\\\", \\\"{x:1308,y:621,t:1526919121630};\\\", \\\"{x:1300,y:622,t:1526919124588};\\\", \\\"{x:1289,y:628,t:1526919124598};\\\", \\\"{x:1254,y:639,t:1526919124616};\\\", \\\"{x:1198,y:647,t:1526919124631};\\\", \\\"{x:1134,y:658,t:1526919124649};\\\", \\\"{x:1075,y:666,t:1526919124666};\\\", \\\"{x:993,y:673,t:1526919124681};\\\", \\\"{x:873,y:673,t:1526919124699};\\\", \\\"{x:791,y:666,t:1526919124715};\\\", \\\"{x:700,y:657,t:1526919124734};\\\", \\\"{x:639,y:650,t:1526919124748};\\\", \\\"{x:594,y:650,t:1526919124766};\\\", \\\"{x:567,y:649,t:1526919124784};\\\", \\\"{x:548,y:644,t:1526919124801};\\\", \\\"{x:537,y:637,t:1526919124818};\\\", \\\"{x:536,y:630,t:1526919124834};\\\", \\\"{x:536,y:624,t:1526919124851};\\\", \\\"{x:536,y:611,t:1526919124868};\\\", \\\"{x:541,y:599,t:1526919124884};\\\", \\\"{x:547,y:583,t:1526919124902};\\\", \\\"{x:553,y:567,t:1526919124919};\\\", \\\"{x:564,y:551,t:1526919124935};\\\", \\\"{x:575,y:538,t:1526919124951};\\\", \\\"{x:592,y:522,t:1526919124968};\\\", \\\"{x:611,y:507,t:1526919124984};\\\", \\\"{x:626,y:496,t:1526919125001};\\\", \\\"{x:630,y:492,t:1526919125018};\\\", \\\"{x:631,y:492,t:1526919125042};\\\", \\\"{x:632,y:492,t:1526919125051};\\\", \\\"{x:635,y:496,t:1526919125068};\\\", \\\"{x:635,y:501,t:1526919125084};\\\", \\\"{x:635,y:503,t:1526919125101};\\\", \\\"{x:635,y:507,t:1526919125118};\\\", \\\"{x:635,y:509,t:1526919125135};\\\", \\\"{x:633,y:514,t:1526919125151};\\\", \\\"{x:629,y:519,t:1526919125168};\\\", \\\"{x:626,y:524,t:1526919125186};\\\", \\\"{x:623,y:530,t:1526919125201};\\\", \\\"{x:623,y:531,t:1526919125217};\\\", \\\"{x:623,y:532,t:1526919125250};\\\", \\\"{x:623,y:533,t:1526919125266};\\\", \\\"{x:623,y:534,t:1526919125315};\\\", \\\"{x:622,y:535,t:1526919125339};\\\", \\\"{x:621,y:535,t:1526919125635};\\\", \\\"{x:620,y:535,t:1526919125666};\\\", \\\"{x:620,y:536,t:1526919125931};\\\", \\\"{x:620,y:540,t:1526919125938};\\\", \\\"{x:620,y:546,t:1526919125952};\\\", \\\"{x:620,y:558,t:1526919125970};\\\", \\\"{x:618,y:570,t:1526919125986};\\\", \\\"{x:612,y:591,t:1526919126002};\\\", \\\"{x:612,y:605,t:1526919126018};\\\", \\\"{x:610,y:618,t:1526919126035};\\\", \\\"{x:610,y:629,t:1526919126053};\\\", \\\"{x:610,y:638,t:1526919126068};\\\", \\\"{x:610,y:648,t:1526919126085};\\\", \\\"{x:611,y:659,t:1526919126102};\\\", \\\"{x:615,y:671,t:1526919126119};\\\", \\\"{x:616,y:682,t:1526919126135};\\\", \\\"{x:619,y:695,t:1526919126152};\\\", \\\"{x:619,y:705,t:1526919126169};\\\", \\\"{x:620,y:716,t:1526919126185};\\\", \\\"{x:620,y:727,t:1526919126201};\\\", \\\"{x:620,y:732,t:1526919126218};\\\", \\\"{x:620,y:737,t:1526919126235};\\\", \\\"{x:620,y:741,t:1526919126252};\\\", \\\"{x:620,y:744,t:1526919126269};\\\", \\\"{x:620,y:745,t:1526919126285};\\\", \\\"{x:620,y:746,t:1526919126302};\\\", \\\"{x:621,y:747,t:1526919126339};\\\", \\\"{x:620,y:747,t:1526919127099};\\\", \\\"{x:619,y:747,t:1526919127123};\\\", \\\"{x:617,y:747,t:1526919127136};\\\", \\\"{x:616,y:747,t:1526919127152};\\\", \\\"{x:613,y:746,t:1526919127169};\\\", \\\"{x:611,y:746,t:1526919127185};\\\", \\\"{x:609,y:746,t:1526919127202};\\\", \\\"{x:606,y:743,t:1526919127218};\\\", \\\"{x:604,y:743,t:1526919127235};\\\", \\\"{x:603,y:743,t:1526919127251};\\\", \\\"{x:603,y:742,t:1526919127299};\\\", \\\"{x:603,y:741,t:1526919127323};\\\", \\\"{x:604,y:737,t:1526919127335};\\\", \\\"{x:624,y:728,t:1526919127352};\\\", \\\"{x:676,y:709,t:1526919127369};\\\", \\\"{x:769,y:686,t:1526919127385};\\\", \\\"{x:912,y:654,t:1526919127402};\\\", \\\"{x:1127,y:622,t:1526919127419};\\\", \\\"{x:1265,y:603,t:1526919127435};\\\", \\\"{x:1381,y:590,t:1526919127452};\\\", \\\"{x:1474,y:583,t:1526919127469};\\\", \\\"{x:1536,y:583,t:1526919127485};\\\", \\\"{x:1564,y:584,t:1526919127502};\\\", \\\"{x:1579,y:588,t:1526919127519};\\\", \\\"{x:1584,y:591,t:1526919127535};\\\", \\\"{x:1586,y:596,t:1526919127551};\\\", \\\"{x:1588,y:600,t:1526919127569};\\\", \\\"{x:1589,y:605,t:1526919127584};\\\", \\\"{x:1589,y:610,t:1526919127602};\\\", \\\"{x:1589,y:620,t:1526919127619};\\\", \\\"{x:1587,y:630,t:1526919127635};\\\", \\\"{x:1584,y:637,t:1526919127653};\\\", \\\"{x:1583,y:640,t:1526919127669};\\\", \\\"{x:1581,y:644,t:1526919127685};\\\", \\\"{x:1578,y:646,t:1526919127702};\\\", \\\"{x:1567,y:648,t:1526919127719};\\\", \\\"{x:1547,y:650,t:1526919127735};\\\", \\\"{x:1527,y:650,t:1526919127752};\\\", \\\"{x:1500,y:650,t:1526919127769};\\\", \\\"{x:1473,y:650,t:1526919127784};\\\", \\\"{x:1451,y:650,t:1526919127801};\\\", \\\"{x:1424,y:650,t:1526919127818};\\\", \\\"{x:1411,y:650,t:1526919127834};\\\", \\\"{x:1407,y:650,t:1526919127851};\\\", \\\"{x:1406,y:650,t:1526919127874};\\\", \\\"{x:1404,y:650,t:1526919127963};\\\", \\\"{x:1402,y:652,t:1526919127978};\\\", \\\"{x:1399,y:652,t:1526919127987};\\\", \\\"{x:1396,y:652,t:1526919128002};\\\", \\\"{x:1373,y:654,t:1526919128018};\\\", \\\"{x:1347,y:654,t:1526919128035};\\\", \\\"{x:1294,y:654,t:1526919128052};\\\", \\\"{x:1214,y:654,t:1526919128068};\\\", \\\"{x:1118,y:650,t:1526919128084};\\\", \\\"{x:975,y:635,t:1526919128102};\\\", \\\"{x:804,y:610,t:1526919128119};\\\", \\\"{x:626,y:579,t:1526919128134};\\\", \\\"{x:485,y:559,t:1526919128151};\\\", \\\"{x:396,y:537,t:1526919128171};\\\", \\\"{x:374,y:523,t:1526919128188};\\\", \\\"{x:365,y:510,t:1526919128204};\\\", \\\"{x:362,y:499,t:1526919128220};\\\", \\\"{x:359,y:489,t:1526919128237};\\\", \\\"{x:358,y:483,t:1526919128253};\\\", \\\"{x:358,y:480,t:1526919128270};\\\", \\\"{x:358,y:476,t:1526919128287};\\\", \\\"{x:360,y:470,t:1526919128303};\\\", \\\"{x:364,y:466,t:1526919128320};\\\", \\\"{x:376,y:460,t:1526919128338};\\\", \\\"{x:399,y:455,t:1526919128353};\\\", \\\"{x:445,y:452,t:1526919128370};\\\", \\\"{x:475,y:458,t:1526919128387};\\\", \\\"{x:497,y:465,t:1526919128404};\\\", \\\"{x:514,y:471,t:1526919128421};\\\", \\\"{x:529,y:482,t:1526919128438};\\\", \\\"{x:537,y:489,t:1526919128455};\\\", \\\"{x:547,y:499,t:1526919128471};\\\", \\\"{x:552,y:507,t:1526919128487};\\\", \\\"{x:556,y:508,t:1526919128505};\\\", \\\"{x:558,y:509,t:1526919128521};\\\", \\\"{x:559,y:509,t:1526919128537};\\\", \\\"{x:564,y:509,t:1526919128554};\\\", \\\"{x:571,y:509,t:1526919128570};\\\", \\\"{x:580,y:510,t:1526919128588};\\\", \\\"{x:589,y:514,t:1526919128604};\\\", \\\"{x:597,y:517,t:1526919128621};\\\", \\\"{x:599,y:517,t:1526919128638};\\\", \\\"{x:604,y:518,t:1526919128655};\\\", \\\"{x:605,y:518,t:1526919128670};\\\", \\\"{x:609,y:518,t:1526919128687};\\\", \\\"{x:612,y:518,t:1526919128705};\\\", \\\"{x:618,y:518,t:1526919128722};\\\", \\\"{x:622,y:519,t:1526919128737};\\\", \\\"{x:626,y:519,t:1526919128754};\\\", \\\"{x:627,y:520,t:1526919128772};\\\", \\\"{x:630,y:520,t:1526919128788};\\\", \\\"{x:631,y:522,t:1526919128805};\\\", \\\"{x:633,y:525,t:1526919128823};\\\", \\\"{x:633,y:528,t:1526919128837};\\\", \\\"{x:633,y:531,t:1526919128854};\\\", \\\"{x:633,y:534,t:1526919128871};\\\", \\\"{x:631,y:538,t:1526919128887};\\\", \\\"{x:629,y:540,t:1526919128904};\\\", \\\"{x:627,y:540,t:1526919128921};\\\", \\\"{x:626,y:541,t:1526919128938};\\\", \\\"{x:625,y:541,t:1526919128954};\\\", \\\"{x:624,y:541,t:1526919128972};\\\", \\\"{x:622,y:541,t:1526919128987};\\\", \\\"{x:621,y:541,t:1526919129004};\\\", \\\"{x:620,y:541,t:1526919129021};\\\", \\\"{x:619,y:541,t:1526919129038};\\\", \\\"{x:618,y:540,t:1526919129055};\\\", \\\"{x:618,y:539,t:1526919129891};\\\", \\\"{x:624,y:538,t:1526919129906};\\\", \\\"{x:659,y:538,t:1526919129922};\\\", \\\"{x:826,y:541,t:1526919129938};\\\", \\\"{x:994,y:555,t:1526919129955};\\\", \\\"{x:1168,y:579,t:1526919129972};\\\", \\\"{x:1351,y:609,t:1526919129988};\\\", \\\"{x:1517,y:640,t:1526919130005};\\\", \\\"{x:1644,y:674,t:1526919130022};\\\", \\\"{x:1743,y:712,t:1526919130038};\\\", \\\"{x:1787,y:731,t:1526919130055};\\\", \\\"{x:1806,y:746,t:1526919130071};\\\", \\\"{x:1809,y:753,t:1526919130088};\\\", \\\"{x:1809,y:758,t:1526919130106};\\\", \\\"{x:1809,y:760,t:1526919130122};\\\", \\\"{x:1809,y:762,t:1526919130138};\\\", \\\"{x:1806,y:763,t:1526919130156};\\\", \\\"{x:1798,y:763,t:1526919130173};\\\", \\\"{x:1776,y:763,t:1526919130189};\\\", \\\"{x:1749,y:763,t:1526919130206};\\\", \\\"{x:1711,y:763,t:1526919130223};\\\", \\\"{x:1672,y:763,t:1526919130238};\\\", \\\"{x:1635,y:763,t:1526919130255};\\\", \\\"{x:1590,y:763,t:1526919130272};\\\", \\\"{x:1559,y:760,t:1526919130289};\\\", \\\"{x:1534,y:756,t:1526919130305};\\\", \\\"{x:1512,y:752,t:1526919130323};\\\", \\\"{x:1503,y:751,t:1526919130339};\\\", \\\"{x:1497,y:750,t:1526919130355};\\\", \\\"{x:1488,y:749,t:1526919130373};\\\", \\\"{x:1480,y:748,t:1526919130389};\\\", \\\"{x:1473,y:747,t:1526919130406};\\\", \\\"{x:1466,y:745,t:1526919130423};\\\", \\\"{x:1459,y:745,t:1526919130439};\\\", \\\"{x:1452,y:746,t:1526919130456};\\\", \\\"{x:1445,y:750,t:1526919130473};\\\", \\\"{x:1435,y:757,t:1526919130488};\\\", \\\"{x:1426,y:770,t:1526919130506};\\\", \\\"{x:1415,y:797,t:1526919130522};\\\", \\\"{x:1410,y:823,t:1526919130539};\\\", \\\"{x:1406,y:848,t:1526919130556};\\\", \\\"{x:1406,y:868,t:1526919130573};\\\", \\\"{x:1406,y:885,t:1526919130589};\\\", \\\"{x:1406,y:900,t:1526919130606};\\\", \\\"{x:1406,y:910,t:1526919130623};\\\", \\\"{x:1407,y:919,t:1526919130640};\\\", \\\"{x:1408,y:926,t:1526919130655};\\\", \\\"{x:1408,y:935,t:1526919130673};\\\", \\\"{x:1404,y:943,t:1526919130689};\\\", \\\"{x:1402,y:950,t:1526919130706};\\\", \\\"{x:1397,y:957,t:1526919130723};\\\", \\\"{x:1394,y:959,t:1526919130739};\\\", \\\"{x:1389,y:961,t:1526919130756};\\\", \\\"{x:1381,y:965,t:1526919130773};\\\", \\\"{x:1377,y:966,t:1526919130790};\\\", \\\"{x:1375,y:967,t:1526919130806};\\\", \\\"{x:1373,y:967,t:1526919130823};\\\", \\\"{x:1369,y:968,t:1526919130840};\\\", \\\"{x:1360,y:972,t:1526919130856};\\\", \\\"{x:1346,y:978,t:1526919130873};\\\", \\\"{x:1334,y:983,t:1526919130890};\\\", \\\"{x:1323,y:986,t:1526919130907};\\\", \\\"{x:1312,y:987,t:1526919130925};\\\", \\\"{x:1309,y:987,t:1526919130940};\\\", \\\"{x:1307,y:987,t:1526919130955};\\\", \\\"{x:1306,y:987,t:1526919131010};\\\", \\\"{x:1305,y:987,t:1526919131026};\\\", \\\"{x:1304,y:987,t:1526919131039};\\\", \\\"{x:1303,y:986,t:1526919131056};\\\", \\\"{x:1302,y:984,t:1526919131073};\\\", \\\"{x:1300,y:980,t:1526919131090};\\\", \\\"{x:1300,y:971,t:1526919131106};\\\", \\\"{x:1300,y:965,t:1526919131122};\\\", \\\"{x:1301,y:962,t:1526919131139};\\\", \\\"{x:1304,y:958,t:1526919131157};\\\", \\\"{x:1305,y:957,t:1526919131172};\\\", \\\"{x:1307,y:952,t:1526919131189};\\\", \\\"{x:1308,y:952,t:1526919131207};\\\", \\\"{x:1308,y:950,t:1526919131223};\\\", \\\"{x:1311,y:945,t:1526919131240};\\\", \\\"{x:1312,y:940,t:1526919131256};\\\", \\\"{x:1317,y:934,t:1526919131273};\\\", \\\"{x:1321,y:925,t:1526919131290};\\\", \\\"{x:1325,y:908,t:1526919131306};\\\", \\\"{x:1326,y:896,t:1526919131323};\\\", \\\"{x:1328,y:882,t:1526919131340};\\\", \\\"{x:1328,y:864,t:1526919131357};\\\", \\\"{x:1328,y:853,t:1526919131372};\\\", \\\"{x:1328,y:846,t:1526919131389};\\\", \\\"{x:1328,y:842,t:1526919131407};\\\", \\\"{x:1328,y:838,t:1526919131423};\\\", \\\"{x:1328,y:832,t:1526919131440};\\\", \\\"{x:1329,y:825,t:1526919131457};\\\", \\\"{x:1329,y:815,t:1526919131473};\\\", \\\"{x:1329,y:803,t:1526919131490};\\\", \\\"{x:1329,y:784,t:1526919131507};\\\", \\\"{x:1329,y:773,t:1526919131523};\\\", \\\"{x:1329,y:760,t:1526919131540};\\\", \\\"{x:1329,y:749,t:1526919131557};\\\", \\\"{x:1329,y:737,t:1526919131573};\\\", \\\"{x:1329,y:723,t:1526919131590};\\\", \\\"{x:1326,y:710,t:1526919131606};\\\", \\\"{x:1322,y:695,t:1526919131624};\\\", \\\"{x:1318,y:680,t:1526919131639};\\\", \\\"{x:1315,y:669,t:1526919131657};\\\", \\\"{x:1313,y:663,t:1526919131674};\\\", \\\"{x:1313,y:656,t:1526919131689};\\\", \\\"{x:1312,y:646,t:1526919131706};\\\", \\\"{x:1310,y:639,t:1526919131724};\\\", \\\"{x:1308,y:634,t:1526919131739};\\\", \\\"{x:1306,y:630,t:1526919131756};\\\", \\\"{x:1306,y:627,t:1526919131774};\\\", \\\"{x:1306,y:626,t:1526919131789};\\\", \\\"{x:1306,y:624,t:1526919131806};\\\", \\\"{x:1306,y:623,t:1526919131823};\\\", \\\"{x:1307,y:623,t:1526919132019};\\\", \\\"{x:1307,y:624,t:1526919132099};\\\", \\\"{x:1308,y:624,t:1526919132123};\\\", \\\"{x:1309,y:625,t:1526919132141};\\\", \\\"{x:1310,y:625,t:1526919132179};\\\", \\\"{x:1311,y:626,t:1526919132195};\\\", \\\"{x:1312,y:626,t:1526919132207};\\\", \\\"{x:1312,y:627,t:1526919132226};\\\", \\\"{x:1312,y:628,t:1526919132240};\\\", \\\"{x:1314,y:630,t:1526919132257};\\\", \\\"{x:1315,y:631,t:1526919132283};\\\", \\\"{x:1317,y:630,t:1526919143626};\\\", \\\"{x:1321,y:630,t:1526919143634};\\\", \\\"{x:1327,y:628,t:1526919143649};\\\", \\\"{x:1347,y:619,t:1526919143665};\\\", \\\"{x:1351,y:615,t:1526919143683};\\\", \\\"{x:1355,y:612,t:1526919143699};\\\", \\\"{x:1357,y:610,t:1526919143716};\\\", \\\"{x:1362,y:606,t:1526919143733};\\\", \\\"{x:1371,y:599,t:1526919143749};\\\", \\\"{x:1379,y:592,t:1526919143766};\\\", \\\"{x:1389,y:584,t:1526919143783};\\\", \\\"{x:1395,y:579,t:1526919143800};\\\", \\\"{x:1401,y:574,t:1526919143816};\\\", \\\"{x:1406,y:569,t:1526919143834};\\\", \\\"{x:1416,y:557,t:1526919143850};\\\", \\\"{x:1420,y:550,t:1526919143867};\\\", \\\"{x:1425,y:542,t:1526919143884};\\\", \\\"{x:1427,y:535,t:1526919143901};\\\", \\\"{x:1428,y:524,t:1526919143916};\\\", \\\"{x:1428,y:515,t:1526919143933};\\\", \\\"{x:1428,y:505,t:1526919143950};\\\", \\\"{x:1426,y:495,t:1526919143966};\\\", \\\"{x:1422,y:484,t:1526919143983};\\\", \\\"{x:1418,y:475,t:1526919144000};\\\", \\\"{x:1415,y:468,t:1526919144017};\\\", \\\"{x:1412,y:465,t:1526919144034};\\\", \\\"{x:1410,y:463,t:1526919144050};\\\", \\\"{x:1409,y:463,t:1526919144074};\\\", \\\"{x:1409,y:462,t:1526919144090};\\\", \\\"{x:1409,y:461,t:1526919144100};\\\", \\\"{x:1409,y:458,t:1526919144116};\\\", \\\"{x:1409,y:455,t:1526919144133};\\\", \\\"{x:1409,y:452,t:1526919144150};\\\", \\\"{x:1409,y:449,t:1526919144166};\\\", \\\"{x:1409,y:448,t:1526919144183};\\\", \\\"{x:1409,y:446,t:1526919144200};\\\", \\\"{x:1410,y:441,t:1526919144217};\\\", \\\"{x:1411,y:439,t:1526919144233};\\\", \\\"{x:1413,y:434,t:1526919144250};\\\", \\\"{x:1414,y:433,t:1526919144266};\\\", \\\"{x:1414,y:432,t:1526919144283};\\\", \\\"{x:1414,y:431,t:1526919144322};\\\", \\\"{x:1414,y:434,t:1526919144523};\\\", \\\"{x:1414,y:436,t:1526919144534};\\\", \\\"{x:1414,y:443,t:1526919144550};\\\", \\\"{x:1414,y:450,t:1526919144567};\\\", \\\"{x:1414,y:459,t:1526919144583};\\\", \\\"{x:1415,y:466,t:1526919144601};\\\", \\\"{x:1417,y:475,t:1526919144618};\\\", \\\"{x:1418,y:483,t:1526919144634};\\\", \\\"{x:1420,y:504,t:1526919144651};\\\", \\\"{x:1424,y:523,t:1526919144668};\\\", \\\"{x:1430,y:541,t:1526919144684};\\\", \\\"{x:1434,y:558,t:1526919144701};\\\", \\\"{x:1436,y:570,t:1526919144717};\\\", \\\"{x:1438,y:576,t:1526919144734};\\\", \\\"{x:1438,y:582,t:1526919144750};\\\", \\\"{x:1439,y:588,t:1526919144767};\\\", \\\"{x:1439,y:590,t:1526919144784};\\\", \\\"{x:1439,y:594,t:1526919144800};\\\", \\\"{x:1439,y:597,t:1526919144817};\\\", \\\"{x:1439,y:601,t:1526919144834};\\\", \\\"{x:1439,y:603,t:1526919144850};\\\", \\\"{x:1438,y:603,t:1526919144867};\\\", \\\"{x:1438,y:605,t:1526919144884};\\\", \\\"{x:1435,y:605,t:1526919144922};\\\", \\\"{x:1434,y:605,t:1526919144934};\\\", \\\"{x:1429,y:603,t:1526919144950};\\\", \\\"{x:1419,y:595,t:1526919144967};\\\", \\\"{x:1411,y:592,t:1526919144984};\\\", \\\"{x:1411,y:591,t:1526919145001};\\\", \\\"{x:1410,y:591,t:1526919145017};\\\", \\\"{x:1408,y:590,t:1526919145035};\\\", \\\"{x:1408,y:588,t:1526919145050};\\\", \\\"{x:1408,y:584,t:1526919145068};\\\", \\\"{x:1408,y:582,t:1526919145085};\\\", \\\"{x:1408,y:577,t:1526919145101};\\\", \\\"{x:1408,y:575,t:1526919145118};\\\", \\\"{x:1408,y:571,t:1526919145135};\\\", \\\"{x:1408,y:569,t:1526919145152};\\\", \\\"{x:1408,y:567,t:1526919145167};\\\", \\\"{x:1408,y:566,t:1526919145185};\\\", \\\"{x:1408,y:565,t:1526919145201};\\\", \\\"{x:1408,y:564,t:1526919145218};\\\", \\\"{x:1409,y:562,t:1526919145235};\\\", \\\"{x:1409,y:561,t:1526919145643};\\\", \\\"{x:1409,y:562,t:1526919145675};\\\", \\\"{x:1409,y:566,t:1526919145685};\\\", \\\"{x:1409,y:579,t:1526919145701};\\\", \\\"{x:1409,y:598,t:1526919145718};\\\", \\\"{x:1406,y:627,t:1526919145735};\\\", \\\"{x:1394,y:673,t:1526919145752};\\\", \\\"{x:1387,y:716,t:1526919145769};\\\", \\\"{x:1385,y:742,t:1526919145785};\\\", \\\"{x:1381,y:765,t:1526919145802};\\\", \\\"{x:1381,y:780,t:1526919145820};\\\", \\\"{x:1381,y:784,t:1526919145835};\\\", \\\"{x:1381,y:785,t:1526919145852};\\\", \\\"{x:1383,y:785,t:1526919145907};\\\", \\\"{x:1384,y:785,t:1526919145995};\\\", \\\"{x:1386,y:785,t:1526919146010};\\\", \\\"{x:1387,y:784,t:1526919146018};\\\", \\\"{x:1388,y:779,t:1526919146035};\\\", \\\"{x:1389,y:774,t:1526919146051};\\\", \\\"{x:1391,y:769,t:1526919146068};\\\", \\\"{x:1391,y:767,t:1526919146085};\\\", \\\"{x:1391,y:766,t:1526919146347};\\\", \\\"{x:1391,y:765,t:1526919147835};\\\", \\\"{x:1390,y:765,t:1526919147854};\\\", \\\"{x:1389,y:765,t:1526919147869};\\\", \\\"{x:1388,y:765,t:1526919147887};\\\", \\\"{x:1385,y:765,t:1526919147903};\\\", \\\"{x:1384,y:765,t:1526919147920};\\\", \\\"{x:1382,y:765,t:1526919152291};\\\", \\\"{x:1381,y:765,t:1526919152330};\\\", \\\"{x:1379,y:765,t:1526919152347};\\\", \\\"{x:1378,y:764,t:1526919152357};\\\", \\\"{x:1375,y:764,t:1526919152375};\\\", \\\"{x:1367,y:763,t:1526919152390};\\\", \\\"{x:1349,y:761,t:1526919152407};\\\", \\\"{x:1319,y:752,t:1526919152424};\\\", \\\"{x:1223,y:732,t:1526919152440};\\\", \\\"{x:1091,y:700,t:1526919152456};\\\", \\\"{x:966,y:681,t:1526919152474};\\\", \\\"{x:870,y:670,t:1526919152490};\\\", \\\"{x:766,y:651,t:1526919152507};\\\", \\\"{x:728,y:636,t:1526919152523};\\\", \\\"{x:704,y:622,t:1526919152542};\\\", \\\"{x:683,y:610,t:1526919152556};\\\", \\\"{x:664,y:597,t:1526919152573};\\\", \\\"{x:653,y:586,t:1526919152591};\\\", \\\"{x:651,y:575,t:1526919152606};\\\", \\\"{x:651,y:558,t:1526919152623};\\\", \\\"{x:660,y:539,t:1526919152641};\\\", \\\"{x:678,y:524,t:1526919152656};\\\", \\\"{x:705,y:515,t:1526919152673};\\\", \\\"{x:751,y:515,t:1526919152689};\\\", \\\"{x:771,y:519,t:1526919152707};\\\", \\\"{x:786,y:525,t:1526919152724};\\\", \\\"{x:799,y:528,t:1526919152740};\\\", \\\"{x:809,y:532,t:1526919152757};\\\", \\\"{x:813,y:535,t:1526919152773};\\\", \\\"{x:812,y:535,t:1526919152883};\\\", \\\"{x:811,y:535,t:1526919152898};\\\", \\\"{x:811,y:534,t:1526919152914};\\\", \\\"{x:811,y:533,t:1526919152931};\\\", \\\"{x:811,y:531,t:1526919152940};\\\", \\\"{x:812,y:530,t:1526919152958};\\\", \\\"{x:816,y:530,t:1526919152973};\\\", \\\"{x:821,y:529,t:1526919152991};\\\", \\\"{x:824,y:528,t:1526919153008};\\\", \\\"{x:826,y:528,t:1526919153023};\\\", \\\"{x:827,y:528,t:1526919153040};\\\", \\\"{x:829,y:528,t:1526919153073};\\\", \\\"{x:826,y:528,t:1526919153222};\\\", \\\"{x:824,y:528,t:1526919153240};\\\", \\\"{x:822,y:527,t:1526919153257};\\\", \\\"{x:816,y:529,t:1526919153274};\\\", \\\"{x:805,y:535,t:1526919153290};\\\", \\\"{x:789,y:548,t:1526919153307};\\\", \\\"{x:766,y:566,t:1526919153324};\\\", \\\"{x:731,y:594,t:1526919153341};\\\", \\\"{x:698,y:625,t:1526919153357};\\\", \\\"{x:675,y:645,t:1526919153375};\\\", \\\"{x:663,y:661,t:1526919153390};\\\", \\\"{x:654,y:677,t:1526919153408};\\\", \\\"{x:643,y:694,t:1526919153424};\\\", \\\"{x:631,y:709,t:1526919153440};\\\", \\\"{x:621,y:722,t:1526919153457};\\\", \\\"{x:594,y:739,t:1526919153474};\\\", \\\"{x:579,y:748,t:1526919153490};\\\", \\\"{x:570,y:754,t:1526919153508};\\\", \\\"{x:565,y:757,t:1526919153524};\\\", \\\"{x:561,y:760,t:1526919153540};\\\", \\\"{x:558,y:761,t:1526919153558};\\\", \\\"{x:556,y:762,t:1526919153574};\\\", \\\"{x:554,y:763,t:1526919153591};\\\", \\\"{x:552,y:763,t:1526919153607};\\\", \\\"{x:547,y:762,t:1526919153625};\\\", \\\"{x:539,y:758,t:1526919153641};\\\", \\\"{x:529,y:752,t:1526919153658};\\\", \\\"{x:527,y:749,t:1526919153675};\\\", \\\"{x:524,y:743,t:1526919153691};\\\", \\\"{x:523,y:739,t:1526919153707};\\\", \\\"{x:521,y:735,t:1526919153724};\\\", \\\"{x:521,y:732,t:1526919153741};\\\", \\\"{x:520,y:730,t:1526919153757};\\\", \\\"{x:520,y:729,t:1526919153778};\\\", \\\"{x:521,y:728,t:1526919155338};\\\", \\\"{x:527,y:731,t:1526919155345};\\\", \\\"{x:536,y:731,t:1526919155358};\\\", \\\"{x:555,y:732,t:1526919155375};\\\", \\\"{x:570,y:732,t:1526919155392};\\\", \\\"{x:577,y:730,t:1526919155407};\\\", \\\"{x:580,y:728,t:1526919155425};\\\", \\\"{x:584,y:725,t:1526919155442};\\\", \\\"{x:589,y:721,t:1526919155458};\\\", \\\"{x:592,y:719,t:1526919155475};\\\", \\\"{x:595,y:717,t:1526919155493};\\\", \\\"{x:596,y:717,t:1526919155529};\\\" ] }, { \\\"rt\\\": 17983, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 554234, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:596,y:716,t:1526919156288};\\\", \\\"{x:595,y:716,t:1526919158155};\\\", \\\"{x:594,y:716,t:1526919158162};\\\", \\\"{x:593,y:716,t:1526919158402};\\\", \\\"{x:593,y:715,t:1526919158426};\\\", \\\"{x:592,y:715,t:1526919158442};\\\", \\\"{x:591,y:714,t:1526919158474};\\\", \\\"{x:591,y:713,t:1526919158482};\\\", \\\"{x:590,y:713,t:1526919158531};\\\", \\\"{x:589,y:712,t:1526919158563};\\\", \\\"{x:587,y:711,t:1526919158594};\\\", \\\"{x:587,y:710,t:1526919158602};\\\", \\\"{x:586,y:710,t:1526919158612};\\\", \\\"{x:585,y:709,t:1526919158690};\\\", \\\"{x:584,y:709,t:1526919158721};\\\", \\\"{x:582,y:707,t:1526919158730};\\\", \\\"{x:580,y:705,t:1526919159099};\\\", \\\"{x:577,y:702,t:1526919159112};\\\", \\\"{x:572,y:699,t:1526919159129};\\\", \\\"{x:571,y:698,t:1526919159162};\\\", \\\"{x:572,y:698,t:1526919159234};\\\", \\\"{x:581,y:697,t:1526919159245};\\\", \\\"{x:602,y:693,t:1526919159262};\\\", \\\"{x:645,y:686,t:1526919159279};\\\", \\\"{x:727,y:681,t:1526919159296};\\\", \\\"{x:824,y:681,t:1526919159311};\\\", \\\"{x:927,y:681,t:1526919159329};\\\", \\\"{x:1074,y:679,t:1526919159347};\\\", \\\"{x:1163,y:679,t:1526919159363};\\\", \\\"{x:1233,y:677,t:1526919159379};\\\", \\\"{x:1292,y:669,t:1526919159396};\\\", \\\"{x:1337,y:661,t:1526919159412};\\\", \\\"{x:1364,y:658,t:1526919159430};\\\", \\\"{x:1381,y:656,t:1526919159446};\\\", \\\"{x:1383,y:655,t:1526919159462};\\\", \\\"{x:1385,y:654,t:1526919159531};\\\", \\\"{x:1385,y:648,t:1526919159548};\\\", \\\"{x:1380,y:637,t:1526919159563};\\\", \\\"{x:1366,y:623,t:1526919159579};\\\", \\\"{x:1348,y:614,t:1526919159596};\\\", \\\"{x:1329,y:608,t:1526919159612};\\\", \\\"{x:1306,y:603,t:1526919159629};\\\", \\\"{x:1279,y:599,t:1526919159646};\\\", \\\"{x:1258,y:596,t:1526919159662};\\\", \\\"{x:1242,y:596,t:1526919159679};\\\", \\\"{x:1234,y:596,t:1526919159697};\\\", \\\"{x:1228,y:596,t:1526919159713};\\\", \\\"{x:1226,y:596,t:1526919159731};\\\", \\\"{x:1223,y:596,t:1526919159759};\\\", \\\"{x:1219,y:596,t:1526919159767};\\\", \\\"{x:1208,y:596,t:1526919159784};\\\", \\\"{x:1191,y:593,t:1526919159800};\\\", \\\"{x:1166,y:589,t:1526919159817};\\\", \\\"{x:1140,y:582,t:1526919159833};\\\", \\\"{x:1113,y:578,t:1526919159851};\\\", \\\"{x:1095,y:574,t:1526919159867};\\\", \\\"{x:1088,y:571,t:1526919159884};\\\", \\\"{x:1084,y:569,t:1526919159900};\\\", \\\"{x:1081,y:568,t:1526919159917};\\\", \\\"{x:1077,y:568,t:1526919159934};\\\", \\\"{x:1072,y:567,t:1526919159950};\\\", \\\"{x:1069,y:566,t:1526919159968};\\\", \\\"{x:1069,y:565,t:1526919160327};\\\", \\\"{x:1070,y:565,t:1526919160335};\\\", \\\"{x:1082,y:564,t:1526919160352};\\\", \\\"{x:1107,y:561,t:1526919160368};\\\", \\\"{x:1132,y:561,t:1526919160384};\\\", \\\"{x:1156,y:561,t:1526919160400};\\\", \\\"{x:1173,y:561,t:1526919160417};\\\", \\\"{x:1188,y:561,t:1526919160434};\\\", \\\"{x:1195,y:561,t:1526919160450};\\\", \\\"{x:1199,y:560,t:1526919160468};\\\", \\\"{x:1205,y:560,t:1526919160484};\\\", \\\"{x:1213,y:560,t:1526919160501};\\\", \\\"{x:1225,y:560,t:1526919160517};\\\", \\\"{x:1248,y:560,t:1526919160535};\\\", \\\"{x:1260,y:560,t:1526919160552};\\\", \\\"{x:1273,y:560,t:1526919160567};\\\", \\\"{x:1277,y:560,t:1526919160587};\\\", \\\"{x:1279,y:560,t:1526919160600};\\\", \\\"{x:1280,y:560,t:1526919160622};\\\", \\\"{x:1282,y:560,t:1526919160646};\\\", \\\"{x:1283,y:560,t:1526919160653};\\\", \\\"{x:1285,y:560,t:1526919160667};\\\", \\\"{x:1290,y:560,t:1526919160684};\\\", \\\"{x:1295,y:560,t:1526919160701};\\\", \\\"{x:1301,y:559,t:1526919160717};\\\", \\\"{x:1308,y:559,t:1526919160734};\\\", \\\"{x:1310,y:559,t:1526919160751};\\\", \\\"{x:1313,y:559,t:1526919160767};\\\", \\\"{x:1315,y:558,t:1526919160784};\\\", \\\"{x:1318,y:557,t:1526919160801};\\\", \\\"{x:1323,y:557,t:1526919160818};\\\", \\\"{x:1331,y:556,t:1526919160834};\\\", \\\"{x:1339,y:556,t:1526919160851};\\\", \\\"{x:1354,y:556,t:1526919160867};\\\", \\\"{x:1368,y:556,t:1526919160884};\\\", \\\"{x:1379,y:556,t:1526919160902};\\\", \\\"{x:1388,y:556,t:1526919160917};\\\", \\\"{x:1395,y:556,t:1526919160934};\\\", \\\"{x:1398,y:556,t:1526919160950};\\\", \\\"{x:1403,y:556,t:1526919160967};\\\", \\\"{x:1410,y:556,t:1526919160984};\\\", \\\"{x:1416,y:556,t:1526919161001};\\\", \\\"{x:1421,y:556,t:1526919161017};\\\", \\\"{x:1422,y:555,t:1526919161034};\\\", \\\"{x:1424,y:555,t:1526919161052};\\\", \\\"{x:1427,y:555,t:1526919161068};\\\", \\\"{x:1428,y:555,t:1526919161085};\\\", \\\"{x:1431,y:555,t:1526919161101};\\\", \\\"{x:1433,y:555,t:1526919161119};\\\", \\\"{x:1434,y:555,t:1526919161167};\\\", \\\"{x:1434,y:557,t:1526919161183};\\\", \\\"{x:1434,y:559,t:1526919161191};\\\", \\\"{x:1432,y:562,t:1526919161201};\\\", \\\"{x:1424,y:572,t:1526919161219};\\\", \\\"{x:1407,y:585,t:1526919161235};\\\", \\\"{x:1366,y:601,t:1526919161252};\\\", \\\"{x:1307,y:612,t:1526919161268};\\\", \\\"{x:1239,y:624,t:1526919161285};\\\", \\\"{x:1183,y:633,t:1526919161302};\\\", \\\"{x:1127,y:641,t:1526919161318};\\\", \\\"{x:1075,y:651,t:1526919161335};\\\", \\\"{x:1050,y:660,t:1526919161353};\\\", \\\"{x:1025,y:667,t:1526919161368};\\\", \\\"{x:1000,y:674,t:1526919161384};\\\", \\\"{x:974,y:679,t:1526919161401};\\\", \\\"{x:944,y:688,t:1526919161419};\\\", \\\"{x:914,y:694,t:1526919161434};\\\", \\\"{x:882,y:701,t:1526919161451};\\\", \\\"{x:833,y:711,t:1526919161469};\\\", \\\"{x:806,y:711,t:1526919161484};\\\", \\\"{x:772,y:710,t:1526919161502};\\\", \\\"{x:714,y:686,t:1526919161518};\\\", \\\"{x:687,y:664,t:1526919161535};\\\", \\\"{x:667,y:636,t:1526919161553};\\\", \\\"{x:650,y:590,t:1526919161570};\\\", \\\"{x:644,y:560,t:1526919161585};\\\", \\\"{x:644,y:539,t:1526919161601};\\\", \\\"{x:647,y:500,t:1526919161633};\\\", \\\"{x:661,y:482,t:1526919161649};\\\", \\\"{x:675,y:468,t:1526919161668};\\\", \\\"{x:704,y:456,t:1526919161684};\\\", \\\"{x:738,y:450,t:1526919161702};\\\", \\\"{x:755,y:450,t:1526919161717};\\\", \\\"{x:764,y:450,t:1526919161735};\\\", \\\"{x:774,y:455,t:1526919161752};\\\", \\\"{x:784,y:464,t:1526919161768};\\\", \\\"{x:790,y:471,t:1526919161785};\\\", \\\"{x:795,y:482,t:1526919161802};\\\", \\\"{x:795,y:493,t:1526919161820};\\\", \\\"{x:795,y:505,t:1526919161834};\\\", \\\"{x:794,y:512,t:1526919161852};\\\", \\\"{x:791,y:515,t:1526919161868};\\\", \\\"{x:788,y:516,t:1526919161885};\\\", \\\"{x:775,y:516,t:1526919161901};\\\", \\\"{x:746,y:516,t:1526919161918};\\\", \\\"{x:730,y:516,t:1526919161935};\\\", \\\"{x:714,y:516,t:1526919161954};\\\", \\\"{x:700,y:516,t:1526919161968};\\\", \\\"{x:686,y:516,t:1526919161985};\\\", \\\"{x:674,y:516,t:1526919162002};\\\", \\\"{x:668,y:515,t:1526919162019};\\\", \\\"{x:665,y:514,t:1526919162035};\\\", \\\"{x:664,y:514,t:1526919162052};\\\", \\\"{x:664,y:513,t:1526919162069};\\\", \\\"{x:662,y:511,t:1526919162085};\\\", \\\"{x:658,y:510,t:1526919162102};\\\", \\\"{x:646,y:510,t:1526919162119};\\\", \\\"{x:633,y:510,t:1526919162135};\\\", \\\"{x:618,y:509,t:1526919162152};\\\", \\\"{x:610,y:507,t:1526919162169};\\\", \\\"{x:608,y:506,t:1526919162185};\\\", \\\"{x:606,y:505,t:1526919162201};\\\", \\\"{x:604,y:503,t:1526919162218};\\\", \\\"{x:603,y:503,t:1526919162246};\\\", \\\"{x:609,y:500,t:1526919162519};\\\", \\\"{x:620,y:498,t:1526919162535};\\\", \\\"{x:646,y:498,t:1526919162553};\\\", \\\"{x:679,y:498,t:1526919162568};\\\", \\\"{x:719,y:498,t:1526919162586};\\\", \\\"{x:751,y:504,t:1526919162603};\\\", \\\"{x:781,y:514,t:1526919162619};\\\", \\\"{x:800,y:522,t:1526919162636};\\\", \\\"{x:817,y:530,t:1526919162652};\\\", \\\"{x:825,y:531,t:1526919162669};\\\", \\\"{x:831,y:532,t:1526919162685};\\\", \\\"{x:839,y:534,t:1526919162702};\\\", \\\"{x:848,y:534,t:1526919162719};\\\", \\\"{x:853,y:535,t:1526919162736};\\\", \\\"{x:856,y:535,t:1526919162751};\\\", \\\"{x:858,y:535,t:1526919162798};\\\", \\\"{x:859,y:536,t:1526919162814};\\\", \\\"{x:859,y:537,t:1526919162830};\\\", \\\"{x:860,y:538,t:1526919162838};\\\", \\\"{x:860,y:540,t:1526919162853};\\\", \\\"{x:862,y:541,t:1526919162878};\\\", \\\"{x:862,y:542,t:1526919162918};\\\", \\\"{x:862,y:544,t:1526919162937};\\\", \\\"{x:861,y:545,t:1526919162953};\\\", \\\"{x:858,y:546,t:1526919162969};\\\", \\\"{x:854,y:547,t:1526919162987};\\\", \\\"{x:851,y:547,t:1526919163003};\\\", \\\"{x:848,y:547,t:1526919163020};\\\", \\\"{x:845,y:547,t:1526919163036};\\\", \\\"{x:841,y:545,t:1526919163054};\\\", \\\"{x:837,y:543,t:1526919163070};\\\", \\\"{x:834,y:542,t:1526919163086};\\\", \\\"{x:834,y:541,t:1526919163103};\\\", \\\"{x:833,y:541,t:1526919163120};\\\", \\\"{x:831,y:541,t:1526919164119};\\\", \\\"{x:828,y:542,t:1526919164126};\\\", \\\"{x:824,y:545,t:1526919164137};\\\", \\\"{x:820,y:545,t:1526919164155};\\\", \\\"{x:816,y:546,t:1526919164169};\\\", \\\"{x:813,y:546,t:1526919164187};\\\", \\\"{x:812,y:546,t:1526919164203};\\\", \\\"{x:810,y:546,t:1526919164220};\\\", \\\"{x:809,y:546,t:1526919164237};\\\", \\\"{x:798,y:546,t:1526919164254};\\\", \\\"{x:783,y:547,t:1526919164270};\\\", \\\"{x:769,y:547,t:1526919164287};\\\", \\\"{x:757,y:547,t:1526919164304};\\\", \\\"{x:738,y:547,t:1526919164320};\\\", \\\"{x:720,y:549,t:1526919164338};\\\", \\\"{x:694,y:549,t:1526919164354};\\\", \\\"{x:665,y:549,t:1526919164370};\\\", \\\"{x:636,y:549,t:1526919164388};\\\", \\\"{x:605,y:544,t:1526919164405};\\\", \\\"{x:576,y:536,t:1526919164420};\\\", \\\"{x:550,y:528,t:1526919164437};\\\", \\\"{x:534,y:519,t:1526919164454};\\\", \\\"{x:531,y:516,t:1526919164470};\\\", \\\"{x:531,y:515,t:1526919164494};\\\", \\\"{x:531,y:514,t:1526919164509};\\\", \\\"{x:531,y:513,t:1526919164520};\\\", \\\"{x:535,y:509,t:1526919164537};\\\", \\\"{x:550,y:504,t:1526919164554};\\\", \\\"{x:584,y:499,t:1526919164570};\\\", \\\"{x:626,y:499,t:1526919164588};\\\", \\\"{x:837,y:500,t:1526919164622};\\\", \\\"{x:894,y:510,t:1526919164637};\\\", \\\"{x:1059,y:532,t:1526919164654};\\\", \\\"{x:1170,y:550,t:1526919164670};\\\", \\\"{x:1278,y:562,t:1526919164687};\\\", \\\"{x:1357,y:566,t:1526919164704};\\\", \\\"{x:1404,y:572,t:1526919164721};\\\", \\\"{x:1437,y:578,t:1526919164737};\\\", \\\"{x:1464,y:583,t:1526919164754};\\\", \\\"{x:1478,y:583,t:1526919164771};\\\", \\\"{x:1479,y:583,t:1526919164788};\\\", \\\"{x:1480,y:584,t:1526919164804};\\\", \\\"{x:1480,y:585,t:1526919164838};\\\", \\\"{x:1478,y:587,t:1526919164854};\\\", \\\"{x:1469,y:589,t:1526919164871};\\\", \\\"{x:1454,y:591,t:1526919164889};\\\", \\\"{x:1433,y:591,t:1526919164904};\\\", \\\"{x:1407,y:591,t:1526919164921};\\\", \\\"{x:1380,y:591,t:1526919164939};\\\", \\\"{x:1356,y:590,t:1526919164955};\\\", \\\"{x:1332,y:587,t:1526919164971};\\\", \\\"{x:1311,y:581,t:1526919164989};\\\", \\\"{x:1293,y:577,t:1526919165005};\\\", \\\"{x:1281,y:576,t:1526919165021};\\\", \\\"{x:1273,y:574,t:1526919165038};\\\", \\\"{x:1269,y:574,t:1526919165055};\\\", \\\"{x:1263,y:574,t:1526919165072};\\\", \\\"{x:1251,y:574,t:1526919165088};\\\", \\\"{x:1233,y:574,t:1526919165106};\\\", \\\"{x:1212,y:572,t:1526919165122};\\\", \\\"{x:1196,y:570,t:1526919165138};\\\", \\\"{x:1187,y:568,t:1526919165155};\\\", \\\"{x:1180,y:567,t:1526919165173};\\\", \\\"{x:1175,y:567,t:1526919165189};\\\", \\\"{x:1170,y:567,t:1526919165206};\\\", \\\"{x:1160,y:568,t:1526919165228};\\\", \\\"{x:1155,y:569,t:1526919165257};\\\", \\\"{x:1157,y:568,t:1526919165317};\\\", \\\"{x:1164,y:565,t:1526919165326};\\\", \\\"{x:1174,y:563,t:1526919165339};\\\", \\\"{x:1206,y:561,t:1526919165355};\\\", \\\"{x:1255,y:558,t:1526919165372};\\\", \\\"{x:1305,y:558,t:1526919165389};\\\", \\\"{x:1347,y:558,t:1526919165405};\\\", \\\"{x:1378,y:558,t:1526919165421};\\\", \\\"{x:1383,y:558,t:1526919165439};\\\", \\\"{x:1384,y:558,t:1526919165495};\\\", \\\"{x:1385,y:558,t:1526919165507};\\\", \\\"{x:1387,y:558,t:1526919165526};\\\", \\\"{x:1388,y:558,t:1526919165539};\\\", \\\"{x:1392,y:559,t:1526919165556};\\\", \\\"{x:1397,y:559,t:1526919165572};\\\", \\\"{x:1400,y:559,t:1526919165590};\\\", \\\"{x:1410,y:559,t:1526919165606};\\\", \\\"{x:1415,y:559,t:1526919165623};\\\", \\\"{x:1421,y:559,t:1526919165640};\\\", \\\"{x:1430,y:559,t:1526919165657};\\\", \\\"{x:1439,y:559,t:1526919165674};\\\", \\\"{x:1444,y:559,t:1526919165689};\\\", \\\"{x:1449,y:559,t:1526919165706};\\\", \\\"{x:1450,y:559,t:1526919165724};\\\", \\\"{x:1451,y:559,t:1526919165791};\\\", \\\"{x:1452,y:560,t:1526919165925};\\\", \\\"{x:1452,y:561,t:1526919166152};\\\", \\\"{x:1453,y:561,t:1526919166158};\\\", \\\"{x:1455,y:561,t:1526919166174};\\\", \\\"{x:1460,y:561,t:1526919166191};\\\", \\\"{x:1463,y:561,t:1526919166208};\\\", \\\"{x:1466,y:561,t:1526919166225};\\\", \\\"{x:1467,y:560,t:1526919166241};\\\", \\\"{x:1469,y:560,t:1526919166258};\\\", \\\"{x:1470,y:560,t:1526919166275};\\\", \\\"{x:1472,y:560,t:1526919166292};\\\", \\\"{x:1473,y:560,t:1526919166310};\\\", \\\"{x:1475,y:560,t:1526919166325};\\\", \\\"{x:1476,y:560,t:1526919166342};\\\", \\\"{x:1477,y:560,t:1526919166358};\\\", \\\"{x:1478,y:560,t:1526919166382};\\\", \\\"{x:1479,y:560,t:1526919166392};\\\", \\\"{x:1479,y:561,t:1526919166415};\\\", \\\"{x:1480,y:563,t:1526919166425};\\\", \\\"{x:1480,y:568,t:1526919166442};\\\", \\\"{x:1480,y:572,t:1526919166458};\\\", \\\"{x:1479,y:577,t:1526919166474};\\\", \\\"{x:1470,y:585,t:1526919166491};\\\", \\\"{x:1458,y:592,t:1526919166508};\\\", \\\"{x:1439,y:600,t:1526919166524};\\\", \\\"{x:1414,y:606,t:1526919166541};\\\", \\\"{x:1349,y:610,t:1526919166557};\\\", \\\"{x:1303,y:617,t:1526919166575};\\\", \\\"{x:1266,y:624,t:1526919166591};\\\", \\\"{x:1235,y:629,t:1526919166608};\\\", \\\"{x:1192,y:641,t:1526919166625};\\\", \\\"{x:1135,y:650,t:1526919166641};\\\", \\\"{x:1069,y:659,t:1526919166658};\\\", \\\"{x:985,y:670,t:1526919166675};\\\", \\\"{x:902,y:681,t:1526919166692};\\\", \\\"{x:821,y:696,t:1526919166708};\\\", \\\"{x:756,y:708,t:1526919166725};\\\", \\\"{x:663,y:728,t:1526919166742};\\\", \\\"{x:627,y:738,t:1526919166759};\\\", \\\"{x:600,y:746,t:1526919166775};\\\", \\\"{x:586,y:752,t:1526919166792};\\\", \\\"{x:582,y:755,t:1526919166809};\\\", \\\"{x:579,y:757,t:1526919166825};\\\", \\\"{x:578,y:757,t:1526919166887};\\\", \\\"{x:578,y:759,t:1526919167615};\\\", \\\"{x:578,y:760,t:1526919167627};\\\", \\\"{x:577,y:761,t:1526919167758};\\\", \\\"{x:577,y:762,t:1526919167846};\\\", \\\"{x:575,y:764,t:1526919172991};\\\", \\\"{x:570,y:768,t:1526919173005};\\\", \\\"{x:555,y:780,t:1526919173022};\\\", \\\"{x:549,y:786,t:1526919173039};\\\", \\\"{x:544,y:791,t:1526919173056};\\\", \\\"{x:541,y:795,t:1526919173073};\\\", \\\"{x:535,y:805,t:1526919173089};\\\", \\\"{x:529,y:814,t:1526919173106};\\\", \\\"{x:523,y:821,t:1526919173123};\\\", \\\"{x:519,y:825,t:1526919173140};\\\", \\\"{x:514,y:832,t:1526919173156};\\\", \\\"{x:509,y:835,t:1526919173173};\\\", \\\"{x:500,y:838,t:1526919173189};\\\", \\\"{x:489,y:840,t:1526919173205};\\\", \\\"{x:480,y:840,t:1526919173222};\\\", \\\"{x:474,y:840,t:1526919173240};\\\", \\\"{x:467,y:840,t:1526919173257};\\\", \\\"{x:455,y:838,t:1526919173273};\\\", \\\"{x:440,y:828,t:1526919173290};\\\", \\\"{x:429,y:816,t:1526919173307};\\\", \\\"{x:423,y:801,t:1526919173323};\\\", \\\"{x:418,y:780,t:1526919173340};\\\", \\\"{x:418,y:761,t:1526919173357};\\\", \\\"{x:418,y:747,t:1526919173373};\\\", \\\"{x:418,y:739,t:1526919173390};\\\", \\\"{x:420,y:729,t:1526919173406};\\\", \\\"{x:423,y:724,t:1526919173424};\\\", \\\"{x:425,y:722,t:1526919173440};\\\", \\\"{x:426,y:720,t:1526919173457};\\\", \\\"{x:428,y:719,t:1526919173474};\\\", \\\"{x:430,y:719,t:1526919173490};\\\", \\\"{x:431,y:717,t:1526919173507};\\\", \\\"{x:432,y:717,t:1526919173524};\\\", \\\"{x:433,y:716,t:1526919173540};\\\", \\\"{x:434,y:715,t:1526919173556};\\\", \\\"{x:435,y:715,t:1526919173574};\\\", \\\"{x:437,y:714,t:1526919173591};\\\", \\\"{x:437,y:713,t:1526919173607};\\\", \\\"{x:439,y:713,t:1526919173624};\\\", \\\"{x:440,y:713,t:1526919173641};\\\", \\\"{x:442,y:713,t:1526919173656};\\\", \\\"{x:447,y:714,t:1526919173673};\\\", \\\"{x:452,y:716,t:1526919173691};\\\", \\\"{x:461,y:721,t:1526919173708};\\\", \\\"{x:467,y:724,t:1526919173723};\\\", \\\"{x:470,y:726,t:1526919173740};\\\", \\\"{x:471,y:727,t:1526919173755};\\\", \\\"{x:473,y:729,t:1526919173772};\\\", \\\"{x:473,y:730,t:1526919173788};\\\", \\\"{x:475,y:731,t:1526919173805};\\\", \\\"{x:476,y:732,t:1526919173822};\\\", \\\"{x:477,y:732,t:1526919174061};\\\" ] }, { \\\"rt\\\": 44189, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 599766, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -C -H -B -F -F -F -O -O -O -D \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:731,t:1526919179909};\\\", \\\"{x:476,y:730,t:1526919179921};\\\", \\\"{x:475,y:729,t:1526919179938};\\\", \\\"{x:474,y:726,t:1526919179954};\\\", \\\"{x:473,y:726,t:1526919179972};\\\", \\\"{x:472,y:725,t:1526919179989};\\\", \\\"{x:471,y:725,t:1526919180013};\\\", \\\"{x:474,y:725,t:1526919180717};\\\", \\\"{x:480,y:722,t:1526919180725};\\\", \\\"{x:488,y:721,t:1526919180739};\\\", \\\"{x:506,y:717,t:1526919180757};\\\", \\\"{x:534,y:712,t:1526919180773};\\\", \\\"{x:552,y:710,t:1526919180789};\\\", \\\"{x:561,y:710,t:1526919180799};\\\", \\\"{x:576,y:706,t:1526919180816};\\\", \\\"{x:597,y:704,t:1526919180832};\\\", \\\"{x:620,y:700,t:1526919180849};\\\", \\\"{x:646,y:696,t:1526919180866};\\\", \\\"{x:675,y:694,t:1526919180881};\\\", \\\"{x:704,y:690,t:1526919180898};\\\", \\\"{x:737,y:687,t:1526919180916};\\\", \\\"{x:776,y:684,t:1526919180931};\\\", \\\"{x:812,y:684,t:1526919180948};\\\", \\\"{x:873,y:680,t:1526919180965};\\\", \\\"{x:921,y:680,t:1526919180981};\\\", \\\"{x:968,y:680,t:1526919180999};\\\", \\\"{x:1012,y:675,t:1526919181016};\\\", \\\"{x:1050,y:673,t:1526919181032};\\\", \\\"{x:1085,y:670,t:1526919181049};\\\", \\\"{x:1128,y:667,t:1526919181066};\\\", \\\"{x:1184,y:667,t:1526919181081};\\\", \\\"{x:1253,y:660,t:1526919181099};\\\", \\\"{x:1322,y:653,t:1526919181115};\\\", \\\"{x:1375,y:646,t:1526919181132};\\\", \\\"{x:1418,y:644,t:1526919181148};\\\", \\\"{x:1472,y:644,t:1526919181166};\\\", \\\"{x:1495,y:644,t:1526919181182};\\\", \\\"{x:1517,y:644,t:1526919181199};\\\", \\\"{x:1530,y:644,t:1526919181216};\\\", \\\"{x:1538,y:644,t:1526919181231};\\\", \\\"{x:1541,y:645,t:1526919181248};\\\", \\\"{x:1542,y:646,t:1526919181278};\\\", \\\"{x:1542,y:647,t:1526919181293};\\\", \\\"{x:1542,y:646,t:1526919181397};\\\", \\\"{x:1541,y:645,t:1526919181405};\\\", \\\"{x:1538,y:644,t:1526919181549};\\\", \\\"{x:1526,y:644,t:1526919181565};\\\", \\\"{x:1517,y:644,t:1526919181583};\\\", \\\"{x:1515,y:644,t:1526919181598};\\\", \\\"{x:1514,y:644,t:1526919182078};\\\", \\\"{x:1514,y:643,t:1526919182101};\\\", \\\"{x:1513,y:642,t:1526919182115};\\\", \\\"{x:1510,y:640,t:1526919182133};\\\", \\\"{x:1510,y:638,t:1526919182149};\\\", \\\"{x:1508,y:638,t:1526919182173};\\\", \\\"{x:1507,y:637,t:1526919182183};\\\", \\\"{x:1500,y:634,t:1526919182198};\\\", \\\"{x:1490,y:631,t:1526919182216};\\\", \\\"{x:1481,y:631,t:1526919182232};\\\", \\\"{x:1472,y:631,t:1526919182250};\\\", \\\"{x:1452,y:635,t:1526919182265};\\\", \\\"{x:1432,y:643,t:1526919182282};\\\", \\\"{x:1412,y:650,t:1526919182299};\\\", \\\"{x:1394,y:660,t:1526919182316};\\\", \\\"{x:1381,y:668,t:1526919182332};\\\", \\\"{x:1375,y:670,t:1526919182349};\\\", \\\"{x:1372,y:671,t:1526919182366};\\\", \\\"{x:1364,y:672,t:1526919182383};\\\", \\\"{x:1351,y:672,t:1526919182399};\\\", \\\"{x:1336,y:672,t:1526919182416};\\\", \\\"{x:1319,y:672,t:1526919182433};\\\", \\\"{x:1304,y:669,t:1526919182449};\\\", \\\"{x:1287,y:666,t:1526919182466};\\\", \\\"{x:1263,y:661,t:1526919182482};\\\", \\\"{x:1239,y:659,t:1526919182500};\\\", \\\"{x:1211,y:656,t:1526919182515};\\\", \\\"{x:1187,y:653,t:1526919182533};\\\", \\\"{x:1160,y:648,t:1526919182549};\\\", \\\"{x:1153,y:647,t:1526919182565};\\\", \\\"{x:1148,y:646,t:1526919182582};\\\", \\\"{x:1145,y:646,t:1526919182600};\\\", \\\"{x:1141,y:645,t:1526919182616};\\\", \\\"{x:1135,y:644,t:1526919182632};\\\", \\\"{x:1129,y:643,t:1526919182650};\\\", \\\"{x:1121,y:641,t:1526919182665};\\\", \\\"{x:1112,y:640,t:1526919182682};\\\", \\\"{x:1107,y:637,t:1526919182700};\\\", \\\"{x:1104,y:636,t:1526919182715};\\\", \\\"{x:1101,y:635,t:1526919182733};\\\", \\\"{x:1100,y:634,t:1526919182749};\\\", \\\"{x:1098,y:632,t:1526919182773};\\\", \\\"{x:1097,y:631,t:1526919182822};\\\", \\\"{x:1096,y:630,t:1526919184317};\\\", \\\"{x:1106,y:628,t:1526919184333};\\\", \\\"{x:1122,y:626,t:1526919184349};\\\", \\\"{x:1151,y:624,t:1526919184366};\\\", \\\"{x:1182,y:620,t:1526919184383};\\\", \\\"{x:1212,y:619,t:1526919184400};\\\", \\\"{x:1247,y:619,t:1526919184417};\\\", \\\"{x:1292,y:619,t:1526919184434};\\\", \\\"{x:1331,y:614,t:1526919184450};\\\", \\\"{x:1362,y:613,t:1526919184466};\\\", \\\"{x:1385,y:613,t:1526919184483};\\\", \\\"{x:1404,y:612,t:1526919184500};\\\", \\\"{x:1426,y:612,t:1526919184516};\\\", \\\"{x:1459,y:607,t:1526919184533};\\\", \\\"{x:1480,y:607,t:1526919184550};\\\", \\\"{x:1504,y:607,t:1526919184567};\\\", \\\"{x:1531,y:606,t:1526919184584};\\\", \\\"{x:1554,y:606,t:1526919184599};\\\", \\\"{x:1577,y:606,t:1526919184616};\\\", \\\"{x:1595,y:606,t:1526919184633};\\\", \\\"{x:1610,y:605,t:1526919184650};\\\", \\\"{x:1620,y:605,t:1526919184667};\\\", \\\"{x:1625,y:605,t:1526919184684};\\\", \\\"{x:1626,y:605,t:1526919184701};\\\", \\\"{x:1627,y:605,t:1526919184717};\\\", \\\"{x:1628,y:605,t:1526919184733};\\\", \\\"{x:1629,y:605,t:1526919184773};\\\", \\\"{x:1630,y:605,t:1526919185005};\\\", \\\"{x:1630,y:606,t:1526919185045};\\\", \\\"{x:1630,y:607,t:1526919185069};\\\", \\\"{x:1630,y:608,t:1526919185084};\\\", \\\"{x:1631,y:609,t:1526919185100};\\\", \\\"{x:1631,y:610,t:1526919185117};\\\", \\\"{x:1631,y:611,t:1526919185134};\\\", \\\"{x:1631,y:612,t:1526919185151};\\\", \\\"{x:1631,y:615,t:1526919185166};\\\", \\\"{x:1631,y:616,t:1526919185184};\\\", \\\"{x:1631,y:617,t:1526919185200};\\\", \\\"{x:1628,y:619,t:1526919185217};\\\", \\\"{x:1626,y:620,t:1526919185234};\\\", \\\"{x:1622,y:622,t:1526919185251};\\\", \\\"{x:1615,y:623,t:1526919185266};\\\", \\\"{x:1609,y:624,t:1526919185284};\\\", \\\"{x:1603,y:626,t:1526919185301};\\\", \\\"{x:1595,y:626,t:1526919185317};\\\", \\\"{x:1583,y:627,t:1526919185334};\\\", \\\"{x:1576,y:627,t:1526919185351};\\\", \\\"{x:1568,y:628,t:1526919185367};\\\", \\\"{x:1559,y:630,t:1526919185384};\\\", \\\"{x:1551,y:633,t:1526919185401};\\\", \\\"{x:1544,y:636,t:1526919185417};\\\", \\\"{x:1538,y:639,t:1526919185434};\\\", \\\"{x:1536,y:640,t:1526919185451};\\\", \\\"{x:1535,y:640,t:1526919185467};\\\", \\\"{x:1533,y:641,t:1526919185549};\\\", \\\"{x:1532,y:641,t:1526919185565};\\\", \\\"{x:1531,y:641,t:1526919185573};\\\", \\\"{x:1529,y:641,t:1526919185583};\\\", \\\"{x:1519,y:641,t:1526919185601};\\\", \\\"{x:1501,y:641,t:1526919185618};\\\", \\\"{x:1482,y:641,t:1526919185634};\\\", \\\"{x:1465,y:638,t:1526919185650};\\\", \\\"{x:1447,y:635,t:1526919185668};\\\", \\\"{x:1433,y:633,t:1526919185684};\\\", \\\"{x:1423,y:631,t:1526919185701};\\\", \\\"{x:1416,y:631,t:1526919185717};\\\", \\\"{x:1415,y:631,t:1526919185805};\\\", \\\"{x:1413,y:631,t:1526919185821};\\\", \\\"{x:1412,y:631,t:1526919185833};\\\", \\\"{x:1409,y:631,t:1526919185851};\\\", \\\"{x:1408,y:631,t:1526919185868};\\\", \\\"{x:1406,y:631,t:1526919185884};\\\", \\\"{x:1407,y:629,t:1526919186349};\\\", \\\"{x:1410,y:628,t:1526919186357};\\\", \\\"{x:1414,y:627,t:1526919186368};\\\", \\\"{x:1427,y:625,t:1526919186384};\\\", \\\"{x:1442,y:624,t:1526919186401};\\\", \\\"{x:1459,y:623,t:1526919186418};\\\", \\\"{x:1477,y:623,t:1526919186434};\\\", \\\"{x:1495,y:623,t:1526919186451};\\\", \\\"{x:1506,y:623,t:1526919186467};\\\", \\\"{x:1514,y:623,t:1526919186485};\\\", \\\"{x:1521,y:623,t:1526919186501};\\\", \\\"{x:1529,y:623,t:1526919186518};\\\", \\\"{x:1533,y:623,t:1526919186535};\\\", \\\"{x:1538,y:623,t:1526919186551};\\\", \\\"{x:1543,y:623,t:1526919186568};\\\", \\\"{x:1546,y:623,t:1526919186585};\\\", \\\"{x:1548,y:623,t:1526919186601};\\\", \\\"{x:1551,y:623,t:1526919186618};\\\", \\\"{x:1553,y:623,t:1526919186635};\\\", \\\"{x:1554,y:623,t:1526919186651};\\\", \\\"{x:1556,y:623,t:1526919186668};\\\", \\\"{x:1559,y:623,t:1526919186685};\\\", \\\"{x:1563,y:623,t:1526919186701};\\\", \\\"{x:1578,y:624,t:1526919186718};\\\", \\\"{x:1587,y:624,t:1526919186735};\\\", \\\"{x:1595,y:624,t:1526919186751};\\\", \\\"{x:1597,y:624,t:1526919186768};\\\", \\\"{x:1598,y:624,t:1526919186789};\\\", \\\"{x:1599,y:624,t:1526919186829};\\\", \\\"{x:1601,y:624,t:1526919186845};\\\", \\\"{x:1602,y:624,t:1526919186869};\\\", \\\"{x:1603,y:624,t:1526919186884};\\\", \\\"{x:1605,y:625,t:1526919186901};\\\", \\\"{x:1611,y:627,t:1526919186918};\\\", \\\"{x:1612,y:628,t:1526919186941};\\\", \\\"{x:1613,y:628,t:1526919186973};\\\", \\\"{x:1614,y:629,t:1526919186985};\\\", \\\"{x:1615,y:630,t:1526919187001};\\\", \\\"{x:1615,y:631,t:1526919187017};\\\", \\\"{x:1616,y:632,t:1526919187078};\\\", \\\"{x:1616,y:633,t:1526919187165};\\\", \\\"{x:1615,y:634,t:1526919189158};\\\", \\\"{x:1613,y:635,t:1526919189169};\\\", \\\"{x:1606,y:638,t:1526919189185};\\\", \\\"{x:1601,y:639,t:1526919189201};\\\", \\\"{x:1597,y:641,t:1526919189219};\\\", \\\"{x:1592,y:642,t:1526919189236};\\\", \\\"{x:1587,y:643,t:1526919189252};\\\", \\\"{x:1579,y:646,t:1526919189269};\\\", \\\"{x:1575,y:647,t:1526919189286};\\\", \\\"{x:1573,y:648,t:1526919189302};\\\", \\\"{x:1571,y:649,t:1526919189319};\\\", \\\"{x:1570,y:649,t:1526919189336};\\\", \\\"{x:1569,y:650,t:1526919189352};\\\", \\\"{x:1566,y:652,t:1526919189369};\\\", \\\"{x:1561,y:655,t:1526919189386};\\\", \\\"{x:1557,y:657,t:1526919189402};\\\", \\\"{x:1550,y:662,t:1526919189419};\\\", \\\"{x:1542,y:666,t:1526919189436};\\\", \\\"{x:1533,y:674,t:1526919189451};\\\", \\\"{x:1526,y:678,t:1526919189469};\\\", \\\"{x:1517,y:683,t:1526919189485};\\\", \\\"{x:1505,y:689,t:1526919189502};\\\", \\\"{x:1492,y:694,t:1526919189519};\\\", \\\"{x:1479,y:700,t:1526919189535};\\\", \\\"{x:1467,y:707,t:1526919189552};\\\", \\\"{x:1452,y:712,t:1526919189569};\\\", \\\"{x:1439,y:714,t:1526919189586};\\\", \\\"{x:1427,y:718,t:1526919189602};\\\", \\\"{x:1412,y:719,t:1526919189619};\\\", \\\"{x:1400,y:719,t:1526919189636};\\\", \\\"{x:1389,y:719,t:1526919189652};\\\", \\\"{x:1381,y:718,t:1526919189669};\\\", \\\"{x:1374,y:717,t:1526919189686};\\\", \\\"{x:1365,y:714,t:1526919189702};\\\", \\\"{x:1361,y:713,t:1526919189719};\\\", \\\"{x:1360,y:712,t:1526919189736};\\\", \\\"{x:1357,y:711,t:1526919189752};\\\", \\\"{x:1356,y:710,t:1526919189769};\\\", \\\"{x:1354,y:708,t:1526919189786};\\\", \\\"{x:1354,y:707,t:1526919189803};\\\", \\\"{x:1353,y:707,t:1526919189818};\\\", \\\"{x:1353,y:706,t:1526919190022};\\\", \\\"{x:1362,y:706,t:1526919190036};\\\", \\\"{x:1388,y:706,t:1526919190053};\\\", \\\"{x:1415,y:706,t:1526919190069};\\\", \\\"{x:1459,y:710,t:1526919190086};\\\", \\\"{x:1483,y:711,t:1526919190102};\\\", \\\"{x:1498,y:711,t:1526919190119};\\\", \\\"{x:1508,y:711,t:1526919190136};\\\", \\\"{x:1515,y:711,t:1526919190153};\\\", \\\"{x:1519,y:711,t:1526919190169};\\\", \\\"{x:1525,y:709,t:1526919190185};\\\", \\\"{x:1531,y:709,t:1526919190203};\\\", \\\"{x:1536,y:709,t:1526919190219};\\\", \\\"{x:1546,y:709,t:1526919190236};\\\", \\\"{x:1556,y:709,t:1526919190253};\\\", \\\"{x:1568,y:708,t:1526919190269};\\\", \\\"{x:1584,y:705,t:1526919190286};\\\", \\\"{x:1589,y:704,t:1526919190302};\\\", \\\"{x:1591,y:704,t:1526919190319};\\\", \\\"{x:1592,y:703,t:1526919190336};\\\", \\\"{x:1590,y:703,t:1526919190694};\\\", \\\"{x:1582,y:703,t:1526919190703};\\\", \\\"{x:1556,y:705,t:1526919190720};\\\", \\\"{x:1513,y:707,t:1526919190736};\\\", \\\"{x:1460,y:707,t:1526919190753};\\\", \\\"{x:1428,y:708,t:1526919190770};\\\", \\\"{x:1403,y:708,t:1526919190786};\\\", \\\"{x:1388,y:708,t:1526919190803};\\\", \\\"{x:1380,y:711,t:1526919190820};\\\", \\\"{x:1379,y:711,t:1526919190836};\\\", \\\"{x:1378,y:711,t:1526919190869};\\\", \\\"{x:1378,y:712,t:1526919191037};\\\", \\\"{x:1376,y:712,t:1526919191061};\\\", \\\"{x:1374,y:711,t:1526919191070};\\\", \\\"{x:1364,y:710,t:1526919191085};\\\", \\\"{x:1352,y:708,t:1526919191103};\\\", \\\"{x:1341,y:706,t:1526919191120};\\\", \\\"{x:1331,y:705,t:1526919191136};\\\", \\\"{x:1327,y:705,t:1526919191153};\\\", \\\"{x:1325,y:705,t:1526919191170};\\\", \\\"{x:1322,y:705,t:1526919191230};\\\", \\\"{x:1320,y:705,t:1526919191237};\\\", \\\"{x:1312,y:705,t:1526919191253};\\\", \\\"{x:1299,y:705,t:1526919191270};\\\", \\\"{x:1287,y:705,t:1526919191285};\\\", \\\"{x:1270,y:705,t:1526919191303};\\\", \\\"{x:1253,y:702,t:1526919191320};\\\", \\\"{x:1235,y:700,t:1526919191337};\\\", \\\"{x:1221,y:697,t:1526919191353};\\\", \\\"{x:1207,y:696,t:1526919191370};\\\", \\\"{x:1197,y:695,t:1526919191387};\\\", \\\"{x:1186,y:692,t:1526919191403};\\\", \\\"{x:1178,y:692,t:1526919191419};\\\", \\\"{x:1158,y:691,t:1526919191437};\\\", \\\"{x:1144,y:691,t:1526919191453};\\\", \\\"{x:1129,y:690,t:1526919191470};\\\", \\\"{x:1116,y:690,t:1526919191487};\\\", \\\"{x:1108,y:690,t:1526919191502};\\\", \\\"{x:1103,y:690,t:1526919191520};\\\", \\\"{x:1099,y:690,t:1526919191536};\\\", \\\"{x:1097,y:690,t:1526919191553};\\\", \\\"{x:1094,y:690,t:1526919191570};\\\", \\\"{x:1093,y:690,t:1526919191587};\\\", \\\"{x:1090,y:690,t:1526919191603};\\\", \\\"{x:1090,y:688,t:1526919191701};\\\", \\\"{x:1090,y:687,t:1526919191709};\\\", \\\"{x:1090,y:684,t:1526919191720};\\\", \\\"{x:1090,y:680,t:1526919191737};\\\", \\\"{x:1092,y:676,t:1526919191753};\\\", \\\"{x:1094,y:669,t:1526919191770};\\\", \\\"{x:1095,y:665,t:1526919191787};\\\", \\\"{x:1097,y:661,t:1526919191803};\\\", \\\"{x:1098,y:659,t:1526919191820};\\\", \\\"{x:1101,y:653,t:1526919191837};\\\", \\\"{x:1104,y:650,t:1526919191854};\\\", \\\"{x:1107,y:646,t:1526919191870};\\\", \\\"{x:1111,y:643,t:1526919191887};\\\", \\\"{x:1114,y:641,t:1526919191903};\\\", \\\"{x:1115,y:641,t:1526919191921};\\\", \\\"{x:1116,y:640,t:1526919191938};\\\", \\\"{x:1117,y:639,t:1526919191953};\\\", \\\"{x:1118,y:637,t:1526919191970};\\\", \\\"{x:1120,y:635,t:1526919191987};\\\", \\\"{x:1121,y:635,t:1526919192003};\\\", \\\"{x:1123,y:633,t:1526919192019};\\\", \\\"{x:1125,y:632,t:1526919192036};\\\", \\\"{x:1126,y:632,t:1526919192053};\\\", \\\"{x:1130,y:631,t:1526919192070};\\\", \\\"{x:1136,y:630,t:1526919192087};\\\", \\\"{x:1148,y:630,t:1526919192103};\\\", \\\"{x:1173,y:630,t:1526919192120};\\\", \\\"{x:1195,y:630,t:1526919192137};\\\", \\\"{x:1210,y:630,t:1526919192153};\\\", \\\"{x:1222,y:630,t:1526919192170};\\\", \\\"{x:1229,y:629,t:1526919192187};\\\", \\\"{x:1236,y:628,t:1526919192204};\\\", \\\"{x:1240,y:627,t:1526919192220};\\\", \\\"{x:1242,y:627,t:1526919192236};\\\", \\\"{x:1243,y:626,t:1526919192253};\\\", \\\"{x:1238,y:626,t:1526919192397};\\\", \\\"{x:1233,y:626,t:1526919192405};\\\", \\\"{x:1230,y:626,t:1526919192420};\\\", \\\"{x:1216,y:626,t:1526919192437};\\\", \\\"{x:1207,y:628,t:1526919192454};\\\", \\\"{x:1200,y:630,t:1526919192470};\\\", \\\"{x:1192,y:632,t:1526919192487};\\\", \\\"{x:1188,y:632,t:1526919192504};\\\", \\\"{x:1186,y:634,t:1526919192520};\\\", \\\"{x:1183,y:634,t:1526919192537};\\\", \\\"{x:1179,y:634,t:1526919192554};\\\", \\\"{x:1175,y:634,t:1526919192570};\\\", \\\"{x:1174,y:634,t:1526919192587};\\\", \\\"{x:1173,y:635,t:1526919192604};\\\", \\\"{x:1171,y:635,t:1526919192797};\\\", \\\"{x:1170,y:635,t:1526919192804};\\\", \\\"{x:1167,y:635,t:1526919192820};\\\", \\\"{x:1157,y:634,t:1526919192837};\\\", \\\"{x:1154,y:634,t:1526919192853};\\\", \\\"{x:1152,y:634,t:1526919192870};\\\", \\\"{x:1146,y:634,t:1526919198781};\\\", \\\"{x:1134,y:634,t:1526919198790};\\\", \\\"{x:1099,y:634,t:1526919198806};\\\", \\\"{x:1035,y:634,t:1526919198823};\\\", \\\"{x:929,y:634,t:1526919198841};\\\", \\\"{x:810,y:634,t:1526919198856};\\\", \\\"{x:688,y:630,t:1526919198873};\\\", \\\"{x:578,y:624,t:1526919198890};\\\", \\\"{x:411,y:599,t:1526919198915};\\\", \\\"{x:308,y:584,t:1526919198931};\\\", \\\"{x:238,y:575,t:1526919198949};\\\", \\\"{x:198,y:568,t:1526919198964};\\\", \\\"{x:169,y:564,t:1526919198981};\\\", \\\"{x:163,y:563,t:1526919198997};\\\", \\\"{x:159,y:563,t:1526919199014};\\\", \\\"{x:156,y:563,t:1526919199031};\\\", \\\"{x:155,y:563,t:1526919199048};\\\", \\\"{x:154,y:563,t:1526919199064};\\\", \\\"{x:153,y:562,t:1526919199093};\\\", \\\"{x:150,y:559,t:1526919199101};\\\", \\\"{x:146,y:555,t:1526919199115};\\\", \\\"{x:137,y:545,t:1526919199131};\\\", \\\"{x:135,y:544,t:1526919199381};\\\", \\\"{x:135,y:541,t:1526919199398};\\\", \\\"{x:134,y:537,t:1526919199415};\\\", \\\"{x:134,y:534,t:1526919199431};\\\", \\\"{x:134,y:528,t:1526919199448};\\\", \\\"{x:134,y:524,t:1526919199466};\\\", \\\"{x:136,y:519,t:1526919199482};\\\", \\\"{x:142,y:514,t:1526919199499};\\\", \\\"{x:154,y:507,t:1526919199514};\\\", \\\"{x:168,y:502,t:1526919199531};\\\", \\\"{x:180,y:501,t:1526919199548};\\\", \\\"{x:196,y:501,t:1526919199565};\\\", \\\"{x:204,y:504,t:1526919199581};\\\", \\\"{x:208,y:510,t:1526919199598};\\\", \\\"{x:214,y:525,t:1526919199616};\\\", \\\"{x:221,y:537,t:1526919199631};\\\", \\\"{x:235,y:545,t:1526919199649};\\\", \\\"{x:254,y:545,t:1526919199665};\\\", \\\"{x:287,y:545,t:1526919199683};\\\", \\\"{x:373,y:545,t:1526919199698};\\\", \\\"{x:501,y:545,t:1526919199715};\\\", \\\"{x:642,y:544,t:1526919199732};\\\", \\\"{x:777,y:534,t:1526919199750};\\\", \\\"{x:874,y:534,t:1526919199765};\\\", \\\"{x:885,y:534,t:1526919199782};\\\", \\\"{x:877,y:537,t:1526919199821};\\\", \\\"{x:863,y:540,t:1526919199832};\\\", \\\"{x:830,y:545,t:1526919199848};\\\", \\\"{x:798,y:547,t:1526919199866};\\\", \\\"{x:779,y:547,t:1526919199882};\\\", \\\"{x:763,y:547,t:1526919199898};\\\", \\\"{x:753,y:543,t:1526919199915};\\\", \\\"{x:746,y:541,t:1526919199932};\\\", \\\"{x:742,y:540,t:1526919199948};\\\", \\\"{x:734,y:539,t:1526919199965};\\\", \\\"{x:726,y:539,t:1526919199982};\\\", \\\"{x:720,y:538,t:1526919199999};\\\", \\\"{x:719,y:538,t:1526919200015};\\\", \\\"{x:719,y:536,t:1526919200032};\\\", \\\"{x:721,y:532,t:1526919200049};\\\", \\\"{x:736,y:529,t:1526919200066};\\\", \\\"{x:773,y:528,t:1526919200082};\\\", \\\"{x:839,y:528,t:1526919200099};\\\", \\\"{x:898,y:528,t:1526919200116};\\\", \\\"{x:926,y:528,t:1526919200132};\\\", \\\"{x:936,y:528,t:1526919200149};\\\", \\\"{x:935,y:529,t:1526919200181};\\\", \\\"{x:934,y:529,t:1526919200189};\\\", \\\"{x:929,y:529,t:1526919200199};\\\", \\\"{x:920,y:529,t:1526919200215};\\\", \\\"{x:911,y:529,t:1526919200232};\\\", \\\"{x:897,y:526,t:1526919200250};\\\", \\\"{x:888,y:523,t:1526919200266};\\\", \\\"{x:883,y:522,t:1526919200283};\\\", \\\"{x:880,y:521,t:1526919200300};\\\", \\\"{x:874,y:519,t:1526919200315};\\\", \\\"{x:872,y:518,t:1526919200332};\\\", \\\"{x:869,y:518,t:1526919200349};\\\", \\\"{x:868,y:517,t:1526919200381};\\\", \\\"{x:866,y:516,t:1526919200399};\\\", \\\"{x:865,y:516,t:1526919200415};\\\", \\\"{x:864,y:514,t:1526919200432};\\\", \\\"{x:861,y:514,t:1526919200449};\\\", \\\"{x:859,y:512,t:1526919200466};\\\", \\\"{x:853,y:511,t:1526919200482};\\\", \\\"{x:843,y:510,t:1526919200500};\\\", \\\"{x:830,y:508,t:1526919200516};\\\", \\\"{x:821,y:506,t:1526919200533};\\\", \\\"{x:812,y:505,t:1526919200549};\\\", \\\"{x:810,y:505,t:1526919200566};\\\", \\\"{x:809,y:505,t:1526919200829};\\\", \\\"{x:809,y:504,t:1526919200845};\\\", \\\"{x:811,y:504,t:1526919200885};\\\", \\\"{x:812,y:504,t:1526919200909};\\\", \\\"{x:813,y:504,t:1526919200925};\\\", \\\"{x:815,y:504,t:1526919200941};\\\", \\\"{x:816,y:505,t:1526919200965};\\\", \\\"{x:817,y:505,t:1526919201005};\\\", \\\"{x:818,y:505,t:1526919201021};\\\", \\\"{x:818,y:506,t:1526919201033};\\\", \\\"{x:814,y:507,t:1526919201269};\\\", \\\"{x:803,y:508,t:1526919201283};\\\", \\\"{x:771,y:513,t:1526919201300};\\\", \\\"{x:723,y:513,t:1526919201318};\\\", \\\"{x:631,y:521,t:1526919201333};\\\", \\\"{x:589,y:529,t:1526919201351};\\\", \\\"{x:559,y:533,t:1526919201366};\\\", \\\"{x:520,y:536,t:1526919201383};\\\", \\\"{x:481,y:536,t:1526919201401};\\\", \\\"{x:436,y:536,t:1526919201416};\\\", \\\"{x:404,y:536,t:1526919201434};\\\", \\\"{x:379,y:536,t:1526919201450};\\\", \\\"{x:358,y:536,t:1526919201466};\\\", \\\"{x:339,y:536,t:1526919201483};\\\", \\\"{x:321,y:536,t:1526919201500};\\\", \\\"{x:301,y:536,t:1526919201516};\\\", \\\"{x:268,y:536,t:1526919201533};\\\", \\\"{x:252,y:536,t:1526919201550};\\\", \\\"{x:245,y:536,t:1526919201566};\\\", \\\"{x:244,y:536,t:1526919201584};\\\", \\\"{x:243,y:536,t:1526919201600};\\\", \\\"{x:241,y:536,t:1526919201616};\\\", \\\"{x:235,y:536,t:1526919201633};\\\", \\\"{x:230,y:536,t:1526919201651};\\\", \\\"{x:226,y:536,t:1526919201666};\\\", \\\"{x:220,y:536,t:1526919201683};\\\", \\\"{x:211,y:535,t:1526919201700};\\\", \\\"{x:196,y:535,t:1526919201716};\\\", \\\"{x:170,y:535,t:1526919201733};\\\", \\\"{x:148,y:535,t:1526919201751};\\\", \\\"{x:128,y:533,t:1526919201766};\\\", \\\"{x:115,y:530,t:1526919201783};\\\", \\\"{x:111,y:530,t:1526919201800};\\\", \\\"{x:110,y:530,t:1526919201902};\\\", \\\"{x:111,y:530,t:1526919202012};\\\", \\\"{x:113,y:530,t:1526919202021};\\\", \\\"{x:117,y:531,t:1526919202033};\\\", \\\"{x:127,y:532,t:1526919202050};\\\", \\\"{x:139,y:535,t:1526919202067};\\\", \\\"{x:144,y:536,t:1526919202084};\\\", \\\"{x:146,y:536,t:1526919202100};\\\", \\\"{x:147,y:537,t:1526919202117};\\\", \\\"{x:149,y:538,t:1526919202157};\\\", \\\"{x:150,y:539,t:1526919202200};\\\", \\\"{x:151,y:539,t:1526919202217};\\\", \\\"{x:152,y:541,t:1526919202233};\\\", \\\"{x:154,y:542,t:1526919202250};\\\", \\\"{x:154,y:543,t:1526919202269};\\\", \\\"{x:155,y:543,t:1526919202325};\\\", \\\"{x:155,y:544,t:1526919202501};\\\", \\\"{x:171,y:544,t:1526919202517};\\\", \\\"{x:210,y:544,t:1526919202534};\\\", \\\"{x:290,y:544,t:1526919202551};\\\", \\\"{x:390,y:544,t:1526919202568};\\\", \\\"{x:509,y:544,t:1526919202585};\\\", \\\"{x:645,y:544,t:1526919202601};\\\", \\\"{x:767,y:544,t:1526919202618};\\\", \\\"{x:872,y:544,t:1526919202634};\\\", \\\"{x:958,y:544,t:1526919202651};\\\", \\\"{x:1033,y:544,t:1526919202668};\\\", \\\"{x:1076,y:544,t:1526919202684};\\\", \\\"{x:1084,y:544,t:1526919202700};\\\", \\\"{x:1084,y:546,t:1526919202733};\\\", \\\"{x:1085,y:547,t:1526919202749};\\\", \\\"{x:1085,y:548,t:1526919202757};\\\", \\\"{x:1085,y:549,t:1526919202797};\\\", \\\"{x:1081,y:549,t:1526919202846};\\\", \\\"{x:1074,y:549,t:1526919202853};\\\", \\\"{x:1064,y:549,t:1526919202868};\\\", \\\"{x:1035,y:549,t:1526919202884};\\\", \\\"{x:972,y:541,t:1526919202901};\\\", \\\"{x:930,y:535,t:1526919202918};\\\", \\\"{x:899,y:529,t:1526919202934};\\\", \\\"{x:883,y:527,t:1526919202951};\\\", \\\"{x:875,y:524,t:1526919202968};\\\", \\\"{x:871,y:523,t:1526919202985};\\\", \\\"{x:870,y:522,t:1526919203045};\\\", \\\"{x:868,y:521,t:1526919203061};\\\", \\\"{x:868,y:520,t:1526919203085};\\\", \\\"{x:868,y:519,t:1526919203108};\\\", \\\"{x:868,y:518,t:1526919203118};\\\", \\\"{x:867,y:518,t:1526919203134};\\\", \\\"{x:866,y:516,t:1526919203152};\\\", \\\"{x:864,y:514,t:1526919203169};\\\", \\\"{x:859,y:511,t:1526919203184};\\\", \\\"{x:852,y:509,t:1526919203201};\\\", \\\"{x:845,y:506,t:1526919203218};\\\", \\\"{x:839,y:504,t:1526919203235};\\\", \\\"{x:836,y:502,t:1526919203251};\\\", \\\"{x:836,y:501,t:1526919203268};\\\", \\\"{x:834,y:501,t:1526919203285};\\\", \\\"{x:831,y:498,t:1526919203301};\\\", \\\"{x:830,y:498,t:1526919203349};\\\", \\\"{x:829,y:497,t:1526919203605};\\\", \\\"{x:848,y:497,t:1526919204181};\\\", \\\"{x:900,y:497,t:1526919204189};\\\", \\\"{x:978,y:498,t:1526919204203};\\\", \\\"{x:1148,y:509,t:1526919204219};\\\", \\\"{x:1320,y:536,t:1526919204235};\\\", \\\"{x:1524,y:559,t:1526919204253};\\\", \\\"{x:1709,y:584,t:1526919204269};\\\", \\\"{x:1905,y:620,t:1526919204286};\\\", \\\"{x:1919,y:640,t:1526919204302};\\\", \\\"{x:1919,y:660,t:1526919204319};\\\", \\\"{x:1919,y:682,t:1526919204335};\\\", \\\"{x:1919,y:704,t:1526919204352};\\\", \\\"{x:1919,y:724,t:1526919204370};\\\", \\\"{x:1913,y:740,t:1526919204385};\\\", \\\"{x:1906,y:755,t:1526919204402};\\\", \\\"{x:1898,y:769,t:1526919204420};\\\", \\\"{x:1889,y:776,t:1526919204436};\\\", \\\"{x:1868,y:778,t:1526919204452};\\\", \\\"{x:1831,y:782,t:1526919204469};\\\", \\\"{x:1805,y:784,t:1526919204486};\\\", \\\"{x:1769,y:784,t:1526919204503};\\\", \\\"{x:1711,y:784,t:1526919204519};\\\", \\\"{x:1641,y:784,t:1526919204535};\\\", \\\"{x:1571,y:784,t:1526919204552};\\\", \\\"{x:1527,y:784,t:1526919204569};\\\", \\\"{x:1476,y:784,t:1526919204585};\\\", \\\"{x:1446,y:784,t:1526919204602};\\\", \\\"{x:1412,y:784,t:1526919204619};\\\", \\\"{x:1384,y:784,t:1526919204635};\\\", \\\"{x:1365,y:776,t:1526919204652};\\\", \\\"{x:1350,y:767,t:1526919204669};\\\", \\\"{x:1343,y:761,t:1526919204686};\\\", \\\"{x:1325,y:750,t:1526919204703};\\\", \\\"{x:1310,y:739,t:1526919204719};\\\", \\\"{x:1303,y:735,t:1526919204735};\\\", \\\"{x:1301,y:730,t:1526919204753};\\\", \\\"{x:1298,y:725,t:1526919204769};\\\", \\\"{x:1298,y:713,t:1526919204785};\\\", \\\"{x:1298,y:697,t:1526919204802};\\\", \\\"{x:1305,y:680,t:1526919204819};\\\", \\\"{x:1312,y:666,t:1526919204836};\\\", \\\"{x:1321,y:658,t:1526919204853};\\\", \\\"{x:1334,y:650,t:1526919204869};\\\", \\\"{x:1338,y:647,t:1526919204886};\\\", \\\"{x:1341,y:647,t:1526919204903};\\\", \\\"{x:1343,y:647,t:1526919204920};\\\", \\\"{x:1344,y:647,t:1526919204936};\\\", \\\"{x:1345,y:647,t:1526919204952};\\\", \\\"{x:1347,y:648,t:1526919204969};\\\", \\\"{x:1350,y:655,t:1526919204986};\\\", \\\"{x:1352,y:664,t:1526919205002};\\\", \\\"{x:1356,y:678,t:1526919205019};\\\", \\\"{x:1357,y:690,t:1526919205036};\\\", \\\"{x:1360,y:703,t:1526919205053};\\\", \\\"{x:1362,y:722,t:1526919205069};\\\", \\\"{x:1362,y:731,t:1526919205086};\\\", \\\"{x:1362,y:737,t:1526919205103};\\\", \\\"{x:1362,y:739,t:1526919205119};\\\", \\\"{x:1362,y:741,t:1526919205137};\\\", \\\"{x:1362,y:743,t:1526919205152};\\\", \\\"{x:1362,y:744,t:1526919205170};\\\", \\\"{x:1362,y:746,t:1526919205186};\\\", \\\"{x:1362,y:747,t:1526919205203};\\\", \\\"{x:1362,y:748,t:1526919205219};\\\", \\\"{x:1362,y:749,t:1526919205237};\\\", \\\"{x:1364,y:750,t:1526919205252};\\\", \\\"{x:1363,y:745,t:1526919205445};\\\", \\\"{x:1360,y:741,t:1526919205453};\\\", \\\"{x:1355,y:730,t:1526919205469};\\\", \\\"{x:1350,y:717,t:1526919205487};\\\", \\\"{x:1349,y:711,t:1526919205504};\\\", \\\"{x:1348,y:706,t:1526919205519};\\\", \\\"{x:1346,y:700,t:1526919205537};\\\", \\\"{x:1346,y:696,t:1526919205554};\\\", \\\"{x:1346,y:695,t:1526919205570};\\\", \\\"{x:1346,y:693,t:1526919205586};\\\", \\\"{x:1346,y:692,t:1526919205605};\\\", \\\"{x:1346,y:690,t:1526919205629};\\\", \\\"{x:1346,y:689,t:1526919205661};\\\", \\\"{x:1347,y:689,t:1526919205820};\\\", \\\"{x:1349,y:690,t:1526919205836};\\\", \\\"{x:1353,y:699,t:1526919205854};\\\", \\\"{x:1358,y:710,t:1526919205870};\\\", \\\"{x:1363,y:724,t:1526919205886};\\\", \\\"{x:1366,y:735,t:1526919205903};\\\", \\\"{x:1369,y:745,t:1526919205921};\\\", \\\"{x:1369,y:750,t:1526919205937};\\\", \\\"{x:1370,y:756,t:1526919205953};\\\", \\\"{x:1370,y:760,t:1526919205971};\\\", \\\"{x:1372,y:762,t:1526919205986};\\\", \\\"{x:1372,y:765,t:1526919206003};\\\", \\\"{x:1372,y:766,t:1526919206021};\\\", \\\"{x:1372,y:767,t:1526919206037};\\\", \\\"{x:1372,y:769,t:1526919206054};\\\", \\\"{x:1372,y:770,t:1526919206381};\\\", \\\"{x:1373,y:771,t:1526919207589};\\\", \\\"{x:1373,y:772,t:1526919207701};\\\", \\\"{x:1374,y:772,t:1526919208469};\\\", \\\"{x:1375,y:772,t:1526919209229};\\\", \\\"{x:1380,y:772,t:1526919209693};\\\", \\\"{x:1390,y:772,t:1526919209706};\\\", \\\"{x:1415,y:771,t:1526919209723};\\\", \\\"{x:1446,y:770,t:1526919209740};\\\", \\\"{x:1482,y:768,t:1526919209756};\\\", \\\"{x:1501,y:768,t:1526919209773};\\\", \\\"{x:1517,y:765,t:1526919209790};\\\", \\\"{x:1523,y:764,t:1526919209807};\\\", \\\"{x:1527,y:763,t:1526919209822};\\\", \\\"{x:1528,y:763,t:1526919209840};\\\", \\\"{x:1529,y:763,t:1526919209856};\\\", \\\"{x:1528,y:763,t:1526919210045};\\\", \\\"{x:1525,y:763,t:1526919210057};\\\", \\\"{x:1521,y:763,t:1526919210073};\\\", \\\"{x:1517,y:765,t:1526919210090};\\\", \\\"{x:1516,y:768,t:1526919210107};\\\", \\\"{x:1515,y:770,t:1526919210124};\\\", \\\"{x:1515,y:771,t:1526919210140};\\\", \\\"{x:1514,y:775,t:1526919210157};\\\", \\\"{x:1513,y:777,t:1526919210182};\\\", \\\"{x:1513,y:779,t:1526919210190};\\\", \\\"{x:1512,y:782,t:1526919210207};\\\", \\\"{x:1510,y:787,t:1526919210224};\\\", \\\"{x:1509,y:790,t:1526919210240};\\\", \\\"{x:1509,y:792,t:1526919210256};\\\", \\\"{x:1508,y:796,t:1526919210273};\\\", \\\"{x:1506,y:799,t:1526919210290};\\\", \\\"{x:1506,y:802,t:1526919210306};\\\", \\\"{x:1506,y:803,t:1526919210323};\\\", \\\"{x:1506,y:805,t:1526919210340};\\\", \\\"{x:1506,y:808,t:1526919210356};\\\", \\\"{x:1506,y:809,t:1526919210374};\\\", \\\"{x:1506,y:812,t:1526919210390};\\\", \\\"{x:1506,y:815,t:1526919210407};\\\", \\\"{x:1506,y:818,t:1526919210424};\\\", \\\"{x:1506,y:823,t:1526919210439};\\\", \\\"{x:1506,y:829,t:1526919210456};\\\", \\\"{x:1505,y:834,t:1526919210473};\\\", \\\"{x:1504,y:838,t:1526919210490};\\\", \\\"{x:1503,y:843,t:1526919210506};\\\", \\\"{x:1503,y:847,t:1526919210524};\\\", \\\"{x:1501,y:851,t:1526919210540};\\\", \\\"{x:1500,y:858,t:1526919210556};\\\", \\\"{x:1499,y:863,t:1526919210574};\\\", \\\"{x:1498,y:867,t:1526919210590};\\\", \\\"{x:1498,y:869,t:1526919210607};\\\", \\\"{x:1497,y:872,t:1526919210624};\\\", \\\"{x:1496,y:874,t:1526919210641};\\\", \\\"{x:1496,y:876,t:1526919210657};\\\", \\\"{x:1494,y:878,t:1526919210674};\\\", \\\"{x:1494,y:879,t:1526919210691};\\\", \\\"{x:1493,y:881,t:1526919210707};\\\", \\\"{x:1492,y:881,t:1526919210724};\\\", \\\"{x:1490,y:882,t:1526919210741};\\\", \\\"{x:1489,y:882,t:1526919210852};\\\", \\\"{x:1488,y:882,t:1526919210885};\\\", \\\"{x:1487,y:881,t:1526919210893};\\\", \\\"{x:1486,y:875,t:1526919210906};\\\", \\\"{x:1483,y:870,t:1526919210924};\\\", \\\"{x:1479,y:860,t:1526919210941};\\\", \\\"{x:1474,y:850,t:1526919210957};\\\", \\\"{x:1470,y:841,t:1526919210974};\\\", \\\"{x:1465,y:833,t:1526919210990};\\\", \\\"{x:1460,y:821,t:1526919211006};\\\", \\\"{x:1457,y:805,t:1526919211023};\\\", \\\"{x:1457,y:789,t:1526919211041};\\\", \\\"{x:1460,y:774,t:1526919211057};\\\", \\\"{x:1467,y:766,t:1526919211074};\\\", \\\"{x:1475,y:758,t:1526919211091};\\\", \\\"{x:1485,y:750,t:1526919211108};\\\", \\\"{x:1492,y:747,t:1526919211123};\\\", \\\"{x:1498,y:746,t:1526919211140};\\\", \\\"{x:1502,y:746,t:1526919211157};\\\", \\\"{x:1505,y:746,t:1526919211174};\\\", \\\"{x:1507,y:746,t:1526919211190};\\\", \\\"{x:1510,y:747,t:1526919211208};\\\", \\\"{x:1513,y:747,t:1526919211223};\\\", \\\"{x:1515,y:748,t:1526919211240};\\\", \\\"{x:1517,y:749,t:1526919211257};\\\", \\\"{x:1521,y:751,t:1526919211274};\\\", \\\"{x:1525,y:751,t:1526919211291};\\\", \\\"{x:1531,y:754,t:1526919211308};\\\", \\\"{x:1537,y:755,t:1526919211323};\\\", \\\"{x:1545,y:758,t:1526919211340};\\\", \\\"{x:1547,y:758,t:1526919211357};\\\", \\\"{x:1549,y:759,t:1526919211374};\\\", \\\"{x:1552,y:759,t:1526919211390};\\\", \\\"{x:1555,y:760,t:1526919211408};\\\", \\\"{x:1558,y:761,t:1526919211424};\\\", \\\"{x:1559,y:762,t:1526919211440};\\\", \\\"{x:1561,y:762,t:1526919211458};\\\", \\\"{x:1562,y:762,t:1526919211474};\\\", \\\"{x:1563,y:762,t:1526919211493};\\\", \\\"{x:1564,y:762,t:1526919211509};\\\", \\\"{x:1565,y:762,t:1526919211524};\\\", \\\"{x:1567,y:763,t:1526919211548};\\\", \\\"{x:1568,y:764,t:1526919211573};\\\", \\\"{x:1569,y:765,t:1526919211668};\\\", \\\"{x:1570,y:765,t:1526919211677};\\\", \\\"{x:1572,y:766,t:1526919211691};\\\", \\\"{x:1574,y:767,t:1526919211708};\\\", \\\"{x:1587,y:773,t:1526919211724};\\\", \\\"{x:1594,y:773,t:1526919211741};\\\", \\\"{x:1603,y:775,t:1526919211757};\\\", \\\"{x:1612,y:778,t:1526919211775};\\\", \\\"{x:1622,y:781,t:1526919211790};\\\", \\\"{x:1634,y:782,t:1526919211808};\\\", \\\"{x:1648,y:783,t:1526919211825};\\\", \\\"{x:1661,y:786,t:1526919211840};\\\", \\\"{x:1671,y:787,t:1526919211857};\\\", \\\"{x:1681,y:790,t:1526919211875};\\\", \\\"{x:1690,y:792,t:1526919211890};\\\", \\\"{x:1697,y:795,t:1526919211907};\\\", \\\"{x:1705,y:796,t:1526919211924};\\\", \\\"{x:1710,y:798,t:1526919211940};\\\", \\\"{x:1714,y:799,t:1526919211957};\\\", \\\"{x:1723,y:801,t:1526919211975};\\\", \\\"{x:1728,y:803,t:1526919211992};\\\", \\\"{x:1733,y:805,t:1526919212008};\\\", \\\"{x:1737,y:807,t:1526919212025};\\\", \\\"{x:1745,y:811,t:1526919212042};\\\", \\\"{x:1752,y:814,t:1526919212058};\\\", \\\"{x:1755,y:815,t:1526919212075};\\\", \\\"{x:1756,y:816,t:1526919212091};\\\", \\\"{x:1757,y:817,t:1526919212124};\\\", \\\"{x:1757,y:818,t:1526919212148};\\\", \\\"{x:1758,y:818,t:1526919212158};\\\", \\\"{x:1758,y:821,t:1526919212175};\\\", \\\"{x:1758,y:822,t:1526919212197};\\\", \\\"{x:1758,y:823,t:1526919212213};\\\", \\\"{x:1758,y:824,t:1526919212237};\\\", \\\"{x:1758,y:825,t:1526919212252};\\\", \\\"{x:1758,y:827,t:1526919212260};\\\", \\\"{x:1758,y:828,t:1526919212324};\\\", \\\"{x:1758,y:830,t:1526919212342};\\\", \\\"{x:1758,y:831,t:1526919212358};\\\", \\\"{x:1756,y:832,t:1526919212375};\\\", \\\"{x:1754,y:833,t:1526919212391};\\\", \\\"{x:1753,y:834,t:1526919212407};\\\", \\\"{x:1753,y:836,t:1526919212429};\\\", \\\"{x:1752,y:836,t:1526919212441};\\\", \\\"{x:1751,y:839,t:1526919212459};\\\", \\\"{x:1751,y:840,t:1526919212475};\\\", \\\"{x:1751,y:841,t:1526919212492};\\\", \\\"{x:1751,y:842,t:1526919212541};\\\", \\\"{x:1750,y:843,t:1526919212621};\\\", \\\"{x:1748,y:843,t:1526919212629};\\\", \\\"{x:1744,y:842,t:1526919212642};\\\", \\\"{x:1739,y:841,t:1526919212659};\\\", \\\"{x:1727,y:841,t:1526919212675};\\\", \\\"{x:1717,y:840,t:1526919212691};\\\", \\\"{x:1703,y:840,t:1526919212709};\\\", \\\"{x:1697,y:840,t:1526919212724};\\\", \\\"{x:1694,y:840,t:1526919212742};\\\", \\\"{x:1691,y:842,t:1526919212759};\\\", \\\"{x:1689,y:843,t:1526919212774};\\\", \\\"{x:1686,y:846,t:1526919212792};\\\", \\\"{x:1683,y:846,t:1526919212808};\\\", \\\"{x:1681,y:848,t:1526919212824};\\\", \\\"{x:1679,y:850,t:1526919212841};\\\", \\\"{x:1677,y:852,t:1526919212859};\\\", \\\"{x:1675,y:853,t:1526919212874};\\\", \\\"{x:1671,y:856,t:1526919212892};\\\", \\\"{x:1668,y:858,t:1526919212909};\\\", \\\"{x:1667,y:858,t:1526919212924};\\\", \\\"{x:1666,y:859,t:1526919212942};\\\", \\\"{x:1666,y:860,t:1526919212959};\\\", \\\"{x:1664,y:861,t:1526919212976};\\\", \\\"{x:1663,y:862,t:1526919212991};\\\", \\\"{x:1662,y:863,t:1526919213008};\\\", \\\"{x:1660,y:866,t:1526919213026};\\\", \\\"{x:1657,y:869,t:1526919213041};\\\", \\\"{x:1656,y:869,t:1526919213058};\\\", \\\"{x:1653,y:871,t:1526919213075};\\\", \\\"{x:1652,y:872,t:1526919213092};\\\", \\\"{x:1651,y:872,t:1526919213132};\\\", \\\"{x:1650,y:873,t:1526919213148};\\\", \\\"{x:1649,y:873,t:1526919216765};\\\", \\\"{x:1648,y:873,t:1526919216853};\\\", \\\"{x:1647,y:873,t:1526919216877};\\\", \\\"{x:1646,y:873,t:1526919216901};\\\", \\\"{x:1645,y:873,t:1526919216941};\\\", \\\"{x:1644,y:873,t:1526919216972};\\\", \\\"{x:1643,y:873,t:1526919216997};\\\", \\\"{x:1642,y:872,t:1526919217012};\\\", \\\"{x:1641,y:872,t:1526919217028};\\\", \\\"{x:1640,y:872,t:1526919217045};\\\", \\\"{x:1637,y:872,t:1526919217062};\\\", \\\"{x:1629,y:872,t:1526919217078};\\\", \\\"{x:1617,y:872,t:1526919217095};\\\", \\\"{x:1591,y:872,t:1526919217111};\\\", \\\"{x:1541,y:871,t:1526919217128};\\\", \\\"{x:1450,y:861,t:1526919217145};\\\", \\\"{x:1319,y:840,t:1526919217162};\\\", \\\"{x:1165,y:825,t:1526919217177};\\\", \\\"{x:991,y:803,t:1526919217195};\\\", \\\"{x:812,y:803,t:1526919217212};\\\", \\\"{x:565,y:796,t:1526919217228};\\\", \\\"{x:418,y:774,t:1526919217244};\\\", \\\"{x:271,y:748,t:1526919217262};\\\", \\\"{x:146,y:710,t:1526919217279};\\\", \\\"{x:50,y:670,t:1526919217295};\\\", \\\"{x:0,y:623,t:1526919217312};\\\", \\\"{x:0,y:590,t:1526919217329};\\\", \\\"{x:0,y:567,t:1526919217344};\\\", \\\"{x:0,y:559,t:1526919217361};\\\", \\\"{x:0,y:555,t:1526919217379};\\\", \\\"{x:0,y:554,t:1526919217395};\\\", \\\"{x:0,y:551,t:1526919217412};\\\", \\\"{x:13,y:548,t:1526919217429};\\\", \\\"{x:36,y:548,t:1526919217444};\\\", \\\"{x:77,y:548,t:1526919217463};\\\", \\\"{x:134,y:550,t:1526919217479};\\\", \\\"{x:198,y:550,t:1526919217495};\\\", \\\"{x:252,y:557,t:1526919217512};\\\", \\\"{x:300,y:573,t:1526919217529};\\\", \\\"{x:324,y:584,t:1526919217544};\\\", \\\"{x:344,y:595,t:1526919217562};\\\", \\\"{x:361,y:610,t:1526919217581};\\\", \\\"{x:374,y:628,t:1526919217595};\\\", \\\"{x:402,y:659,t:1526919217613};\\\", \\\"{x:423,y:675,t:1526919217630};\\\", \\\"{x:440,y:686,t:1526919217646};\\\", \\\"{x:448,y:690,t:1526919217663};\\\", \\\"{x:451,y:691,t:1526919217680};\\\", \\\"{x:452,y:691,t:1526919217756};\\\", \\\"{x:453,y:693,t:1526919217772};\\\", \\\"{x:456,y:693,t:1526919217781};\\\", \\\"{x:460,y:693,t:1526919217796};\\\", \\\"{x:466,y:693,t:1526919217813};\\\", \\\"{x:475,y:694,t:1526919217830};\\\", \\\"{x:484,y:695,t:1526919217847};\\\", \\\"{x:492,y:695,t:1526919217863};\\\", \\\"{x:496,y:695,t:1526919217880};\\\", \\\"{x:498,y:695,t:1526919217897};\\\", \\\"{x:499,y:695,t:1526919217916};\\\", \\\"{x:500,y:695,t:1526919217932};\\\", \\\"{x:501,y:695,t:1526919217947};\\\", \\\"{x:502,y:695,t:1526919217964};\\\", \\\"{x:503,y:695,t:1526919217988};\\\", \\\"{x:504,y:695,t:1526919217997};\\\", \\\"{x:505,y:695,t:1526919218020};\\\", \\\"{x:507,y:695,t:1526919218036};\\\", \\\"{x:509,y:697,t:1526919218047};\\\", \\\"{x:510,y:699,t:1526919218063};\\\", \\\"{x:512,y:701,t:1526919218080};\\\", \\\"{x:513,y:702,t:1526919218109};\\\", \\\"{x:513,y:703,t:1526919218132};\\\", \\\"{x:513,y:704,t:1526919218147};\\\", \\\"{x:513,y:706,t:1526919218197};\\\", \\\"{x:515,y:708,t:1526919218214};\\\", \\\"{x:515,y:710,t:1526919218230};\\\", \\\"{x:516,y:714,t:1526919218247};\\\", \\\"{x:516,y:717,t:1526919218263};\\\", \\\"{x:517,y:722,t:1526919218280};\\\", \\\"{x:521,y:731,t:1526919218297};\\\", \\\"{x:524,y:738,t:1526919218313};\\\", \\\"{x:526,y:741,t:1526919218330};\\\", \\\"{x:526,y:742,t:1526919218365};\\\", \\\"{x:526,y:743,t:1526919218380};\\\" ] }, { \\\"rt\\\": 74133, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 675102, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -B -B -B -B -X -X -B -B -J -I -I -I -X -I -J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:737,t:1526919221632};\\\", \\\"{x:517,y:732,t:1526919221647};\\\", \\\"{x:512,y:728,t:1526919221652};\\\", \\\"{x:496,y:717,t:1526919221669};\\\", \\\"{x:477,y:705,t:1526919221686};\\\", \\\"{x:455,y:693,t:1526919221702};\\\", \\\"{x:437,y:686,t:1526919221720};\\\", \\\"{x:421,y:676,t:1526919221735};\\\", \\\"{x:414,y:672,t:1526919221752};\\\", \\\"{x:408,y:667,t:1526919221769};\\\", \\\"{x:398,y:660,t:1526919221786};\\\", \\\"{x:385,y:648,t:1526919221803};\\\", \\\"{x:372,y:637,t:1526919221820};\\\", \\\"{x:361,y:623,t:1526919221836};\\\", \\\"{x:339,y:602,t:1526919221852};\\\", \\\"{x:322,y:581,t:1526919221869};\\\", \\\"{x:308,y:563,t:1526919221887};\\\", \\\"{x:294,y:544,t:1526919221903};\\\", \\\"{x:286,y:530,t:1526919221919};\\\", \\\"{x:279,y:516,t:1526919221936};\\\", \\\"{x:279,y:514,t:1526919221952};\\\", \\\"{x:279,y:513,t:1526919221969};\\\", \\\"{x:279,y:510,t:1526919221986};\\\", \\\"{x:279,y:503,t:1526919222003};\\\", \\\"{x:285,y:498,t:1526919222019};\\\", \\\"{x:297,y:491,t:1526919222036};\\\", \\\"{x:312,y:487,t:1526919222053};\\\", \\\"{x:327,y:484,t:1526919222070};\\\", \\\"{x:340,y:483,t:1526919222086};\\\", \\\"{x:354,y:483,t:1526919222103};\\\", \\\"{x:366,y:483,t:1526919222119};\\\", \\\"{x:382,y:484,t:1526919222136};\\\", \\\"{x:390,y:485,t:1526919222153};\\\", \\\"{x:398,y:486,t:1526919222169};\\\", \\\"{x:402,y:486,t:1526919222186};\\\", \\\"{x:404,y:486,t:1526919222203};\\\", \\\"{x:406,y:486,t:1526919222219};\\\", \\\"{x:407,y:485,t:1526919222400};\\\", \\\"{x:405,y:483,t:1526919222415};\\\", \\\"{x:400,y:481,t:1526919222431};\\\", \\\"{x:392,y:481,t:1526919222440};\\\", \\\"{x:386,y:481,t:1526919222453};\\\", \\\"{x:367,y:481,t:1526919222470};\\\", \\\"{x:349,y:481,t:1526919222486};\\\", \\\"{x:335,y:481,t:1526919222504};\\\", \\\"{x:330,y:481,t:1526919222519};\\\", \\\"{x:328,y:481,t:1526919222536};\\\", \\\"{x:327,y:481,t:1526919222553};\\\", \\\"{x:326,y:481,t:1526919222570};\\\", \\\"{x:325,y:481,t:1526919222587};\\\", \\\"{x:325,y:480,t:1526919222664};\\\", \\\"{x:325,y:479,t:1526919222672};\\\", \\\"{x:325,y:477,t:1526919222687};\\\", \\\"{x:325,y:476,t:1526919222703};\\\", \\\"{x:328,y:474,t:1526919222720};\\\", \\\"{x:331,y:471,t:1526919222737};\\\", \\\"{x:335,y:470,t:1526919222753};\\\", \\\"{x:344,y:469,t:1526919222770};\\\", \\\"{x:356,y:467,t:1526919222787};\\\", \\\"{x:370,y:467,t:1526919222803};\\\", \\\"{x:385,y:467,t:1526919222820};\\\", \\\"{x:399,y:467,t:1526919222837};\\\", \\\"{x:409,y:467,t:1526919222853};\\\", \\\"{x:419,y:467,t:1526919222870};\\\", \\\"{x:430,y:467,t:1526919222887};\\\", \\\"{x:442,y:467,t:1526919222903};\\\", \\\"{x:449,y:467,t:1526919222920};\\\", \\\"{x:455,y:467,t:1526919222937};\\\", \\\"{x:460,y:467,t:1526919222954};\\\", \\\"{x:467,y:467,t:1526919222970};\\\", \\\"{x:471,y:467,t:1526919222987};\\\", \\\"{x:474,y:467,t:1526919223005};\\\", \\\"{x:475,y:467,t:1526919223020};\\\", \\\"{x:476,y:467,t:1526919223048};\\\", \\\"{x:477,y:467,t:1526919223064};\\\", \\\"{x:478,y:466,t:1526919223071};\\\", \\\"{x:480,y:466,t:1526919223087};\\\", \\\"{x:483,y:466,t:1526919223104};\\\", \\\"{x:484,y:466,t:1526919223120};\\\", \\\"{x:486,y:466,t:1526919223137};\\\", \\\"{x:487,y:466,t:1526919223280};\\\", \\\"{x:487,y:464,t:1526919223352};\\\", \\\"{x:488,y:463,t:1526919223367};\\\", \\\"{x:489,y:463,t:1526919223376};\\\", \\\"{x:490,y:462,t:1526919223387};\\\", \\\"{x:493,y:461,t:1526919223404};\\\", \\\"{x:496,y:459,t:1526919223421};\\\", \\\"{x:502,y:457,t:1526919223438};\\\", \\\"{x:508,y:456,t:1526919223454};\\\", \\\"{x:520,y:454,t:1526919223471};\\\", \\\"{x:531,y:452,t:1526919223487};\\\", \\\"{x:547,y:451,t:1526919223504};\\\", \\\"{x:555,y:451,t:1526919223521};\\\", \\\"{x:564,y:451,t:1526919223538};\\\", \\\"{x:577,y:450,t:1526919223554};\\\", \\\"{x:593,y:450,t:1526919223571};\\\", \\\"{x:612,y:449,t:1526919223588};\\\", \\\"{x:632,y:449,t:1526919223604};\\\", \\\"{x:660,y:446,t:1526919223622};\\\", \\\"{x:694,y:443,t:1526919223638};\\\", \\\"{x:747,y:443,t:1526919223654};\\\", \\\"{x:801,y:440,t:1526919223671};\\\", \\\"{x:918,y:438,t:1526919223687};\\\", \\\"{x:1013,y:438,t:1526919223705};\\\", \\\"{x:1124,y:436,t:1526919223721};\\\", \\\"{x:1260,y:430,t:1526919223738};\\\", \\\"{x:1414,y:419,t:1526919223754};\\\", \\\"{x:1563,y:404,t:1526919223772};\\\", \\\"{x:1693,y:387,t:1526919223788};\\\", \\\"{x:1800,y:375,t:1526919223805};\\\", \\\"{x:1880,y:356,t:1526919223822};\\\", \\\"{x:1919,y:341,t:1526919223838};\\\", \\\"{x:1919,y:331,t:1526919223854};\\\", \\\"{x:1919,y:324,t:1526919223870};\\\", \\\"{x:1919,y:320,t:1526919223887};\\\", \\\"{x:1919,y:318,t:1526919223904};\\\", \\\"{x:1919,y:317,t:1526919223920};\\\", \\\"{x:1919,y:315,t:1526919223976};\\\", \\\"{x:1919,y:314,t:1526919223991};\\\", \\\"{x:1919,y:312,t:1526919224015};\\\", \\\"{x:1919,y:311,t:1526919224032};\\\", \\\"{x:1918,y:311,t:1526919224040};\\\", \\\"{x:1917,y:309,t:1526919224054};\\\", \\\"{x:1912,y:307,t:1526919224071};\\\", \\\"{x:1902,y:306,t:1526919224088};\\\", \\\"{x:1873,y:303,t:1526919224104};\\\", \\\"{x:1848,y:303,t:1526919224121};\\\", \\\"{x:1824,y:301,t:1526919224138};\\\", \\\"{x:1802,y:298,t:1526919224154};\\\", \\\"{x:1781,y:297,t:1526919224171};\\\", \\\"{x:1753,y:297,t:1526919224188};\\\", \\\"{x:1730,y:297,t:1526919224204};\\\", \\\"{x:1709,y:297,t:1526919224222};\\\", \\\"{x:1693,y:297,t:1526919224238};\\\", \\\"{x:1678,y:303,t:1526919224254};\\\", \\\"{x:1653,y:309,t:1526919224272};\\\", \\\"{x:1638,y:311,t:1526919224288};\\\", \\\"{x:1621,y:314,t:1526919224305};\\\", \\\"{x:1605,y:314,t:1526919224322};\\\", \\\"{x:1590,y:314,t:1526919224338};\\\", \\\"{x:1574,y:318,t:1526919224354};\\\", \\\"{x:1559,y:325,t:1526919224371};\\\", \\\"{x:1542,y:334,t:1526919224388};\\\", \\\"{x:1514,y:352,t:1526919224404};\\\", \\\"{x:1478,y:383,t:1526919224422};\\\", \\\"{x:1409,y:416,t:1526919224438};\\\", \\\"{x:1325,y:459,t:1526919224455};\\\", \\\"{x:1207,y:530,t:1526919224471};\\\", \\\"{x:1154,y:566,t:1526919224488};\\\", \\\"{x:1118,y:588,t:1526919224505};\\\", \\\"{x:1102,y:597,t:1526919224522};\\\", \\\"{x:1097,y:602,t:1526919224539};\\\", \\\"{x:1096,y:602,t:1526919224555};\\\", \\\"{x:1094,y:601,t:1526919224616};\\\", \\\"{x:1093,y:599,t:1526919224623};\\\", \\\"{x:1092,y:597,t:1526919224638};\\\", \\\"{x:1088,y:584,t:1526919224655};\\\", \\\"{x:1088,y:569,t:1526919224671};\\\", \\\"{x:1090,y:553,t:1526919224689};\\\", \\\"{x:1096,y:535,t:1526919224705};\\\", \\\"{x:1102,y:522,t:1526919224721};\\\", \\\"{x:1107,y:513,t:1526919224738};\\\", \\\"{x:1110,y:509,t:1526919224755};\\\", \\\"{x:1111,y:507,t:1526919224771};\\\", \\\"{x:1113,y:505,t:1526919224789};\\\", \\\"{x:1114,y:505,t:1526919224805};\\\", \\\"{x:1115,y:505,t:1526919224872};\\\", \\\"{x:1116,y:505,t:1526919224888};\\\", \\\"{x:1117,y:504,t:1526919225560};\\\", \\\"{x:1119,y:501,t:1526919226720};\\\", \\\"{x:1122,y:501,t:1526919226727};\\\", \\\"{x:1128,y:501,t:1526919226739};\\\", \\\"{x:1145,y:497,t:1526919226757};\\\", \\\"{x:1168,y:495,t:1526919226773};\\\", \\\"{x:1192,y:495,t:1526919226790};\\\", \\\"{x:1215,y:495,t:1526919226807};\\\", \\\"{x:1251,y:495,t:1526919226823};\\\", \\\"{x:1276,y:495,t:1526919226839};\\\", \\\"{x:1297,y:495,t:1526919226856};\\\", \\\"{x:1316,y:495,t:1526919226873};\\\", \\\"{x:1334,y:495,t:1526919226889};\\\", \\\"{x:1350,y:495,t:1526919226907};\\\", \\\"{x:1361,y:495,t:1526919226923};\\\", \\\"{x:1372,y:495,t:1526919226940};\\\", \\\"{x:1379,y:495,t:1526919226957};\\\", \\\"{x:1387,y:495,t:1526919226973};\\\", \\\"{x:1394,y:495,t:1526919226991};\\\", \\\"{x:1400,y:495,t:1526919227006};\\\", \\\"{x:1408,y:497,t:1526919227023};\\\", \\\"{x:1412,y:497,t:1526919227040};\\\", \\\"{x:1420,y:497,t:1526919227056};\\\", \\\"{x:1429,y:497,t:1526919227073};\\\", \\\"{x:1442,y:496,t:1526919227090};\\\", \\\"{x:1448,y:495,t:1526919227107};\\\", \\\"{x:1452,y:493,t:1526919227123};\\\", \\\"{x:1451,y:493,t:1526919227192};\\\", \\\"{x:1446,y:494,t:1526919227207};\\\", \\\"{x:1425,y:501,t:1526919227224};\\\", \\\"{x:1408,y:506,t:1526919227240};\\\", \\\"{x:1388,y:510,t:1526919227257};\\\", \\\"{x:1369,y:512,t:1526919227273};\\\", \\\"{x:1361,y:514,t:1526919227290};\\\", \\\"{x:1358,y:514,t:1526919227306};\\\", \\\"{x:1357,y:514,t:1526919227324};\\\", \\\"{x:1355,y:514,t:1526919227344};\\\", \\\"{x:1356,y:514,t:1526919227632};\\\", \\\"{x:1358,y:516,t:1526919227641};\\\", \\\"{x:1363,y:522,t:1526919227658};\\\", \\\"{x:1367,y:525,t:1526919227673};\\\", \\\"{x:1371,y:530,t:1526919227691};\\\", \\\"{x:1374,y:531,t:1526919227708};\\\", \\\"{x:1376,y:533,t:1526919227724};\\\", \\\"{x:1377,y:534,t:1526919227741};\\\", \\\"{x:1380,y:534,t:1526919227959};\\\", \\\"{x:1390,y:534,t:1526919227974};\\\", \\\"{x:1425,y:530,t:1526919227990};\\\", \\\"{x:1563,y:522,t:1526919228007};\\\", \\\"{x:1671,y:522,t:1526919228024};\\\", \\\"{x:1776,y:522,t:1526919228040};\\\", \\\"{x:1860,y:522,t:1526919228057};\\\", \\\"{x:1910,y:522,t:1526919228075};\\\", \\\"{x:1919,y:522,t:1526919228091};\\\", \\\"{x:1917,y:523,t:1526919228199};\\\", \\\"{x:1906,y:527,t:1526919228207};\\\", \\\"{x:1879,y:530,t:1526919228225};\\\", \\\"{x:1823,y:532,t:1526919228241};\\\", \\\"{x:1756,y:534,t:1526919228257};\\\", \\\"{x:1700,y:534,t:1526919228274};\\\", \\\"{x:1669,y:534,t:1526919228291};\\\", \\\"{x:1648,y:534,t:1526919228308};\\\", \\\"{x:1639,y:534,t:1526919228324};\\\", \\\"{x:1634,y:534,t:1526919228342};\\\", \\\"{x:1629,y:534,t:1526919228357};\\\", \\\"{x:1621,y:534,t:1526919228374};\\\", \\\"{x:1603,y:534,t:1526919228391};\\\", \\\"{x:1593,y:534,t:1526919228408};\\\", \\\"{x:1581,y:534,t:1526919228424};\\\", \\\"{x:1570,y:534,t:1526919228441};\\\", \\\"{x:1558,y:534,t:1526919228458};\\\", \\\"{x:1549,y:534,t:1526919228474};\\\", \\\"{x:1539,y:534,t:1526919228492};\\\", \\\"{x:1530,y:534,t:1526919228508};\\\", \\\"{x:1516,y:536,t:1526919228524};\\\", \\\"{x:1502,y:540,t:1526919228542};\\\", \\\"{x:1495,y:541,t:1526919228559};\\\", \\\"{x:1487,y:543,t:1526919228574};\\\", \\\"{x:1475,y:544,t:1526919228591};\\\", \\\"{x:1471,y:545,t:1526919228609};\\\", \\\"{x:1468,y:545,t:1526919228625};\\\", \\\"{x:1466,y:545,t:1526919228642};\\\", \\\"{x:1465,y:545,t:1526919228671};\\\", \\\"{x:1464,y:545,t:1526919229368};\\\", \\\"{x:1463,y:545,t:1526919229391};\\\", \\\"{x:1461,y:546,t:1526919230711};\\\", \\\"{x:1461,y:547,t:1526919230726};\\\", \\\"{x:1461,y:549,t:1526919230742};\\\", \\\"{x:1461,y:559,t:1526919230759};\\\", \\\"{x:1461,y:571,t:1526919230776};\\\", \\\"{x:1461,y:586,t:1526919230793};\\\", \\\"{x:1458,y:603,t:1526919230809};\\\", \\\"{x:1458,y:615,t:1526919230826};\\\", \\\"{x:1458,y:626,t:1526919230842};\\\", \\\"{x:1456,y:639,t:1526919230859};\\\", \\\"{x:1451,y:652,t:1526919230876};\\\", \\\"{x:1445,y:665,t:1526919230893};\\\", \\\"{x:1441,y:673,t:1526919230909};\\\", \\\"{x:1438,y:682,t:1526919230926};\\\", \\\"{x:1432,y:698,t:1526919230943};\\\", \\\"{x:1426,y:708,t:1526919230959};\\\", \\\"{x:1422,y:715,t:1526919230976};\\\", \\\"{x:1414,y:727,t:1526919230994};\\\", \\\"{x:1407,y:736,t:1526919231009};\\\", \\\"{x:1404,y:741,t:1526919231026};\\\", \\\"{x:1400,y:745,t:1526919231044};\\\", \\\"{x:1398,y:747,t:1526919231060};\\\", \\\"{x:1397,y:749,t:1526919231076};\\\", \\\"{x:1396,y:752,t:1526919231094};\\\", \\\"{x:1393,y:756,t:1526919231109};\\\", \\\"{x:1390,y:760,t:1526919231127};\\\", \\\"{x:1387,y:763,t:1526919231144};\\\", \\\"{x:1386,y:765,t:1526919231159};\\\", \\\"{x:1385,y:766,t:1526919231176};\\\", \\\"{x:1384,y:766,t:1526919231194};\\\", \\\"{x:1383,y:766,t:1526919231223};\\\", \\\"{x:1380,y:766,t:1526919231240};\\\", \\\"{x:1377,y:765,t:1526919231247};\\\", \\\"{x:1373,y:764,t:1526919231259};\\\", \\\"{x:1368,y:762,t:1526919231276};\\\", \\\"{x:1365,y:760,t:1526919231293};\\\", \\\"{x:1361,y:759,t:1526919231309};\\\", \\\"{x:1354,y:758,t:1526919231326};\\\", \\\"{x:1347,y:757,t:1526919231343};\\\", \\\"{x:1343,y:757,t:1526919231360};\\\", \\\"{x:1340,y:757,t:1526919231376};\\\", \\\"{x:1339,y:757,t:1526919231393};\\\", \\\"{x:1338,y:757,t:1526919231439};\\\", \\\"{x:1338,y:758,t:1526919231455};\\\", \\\"{x:1339,y:759,t:1526919231463};\\\", \\\"{x:1339,y:760,t:1526919231476};\\\", \\\"{x:1341,y:762,t:1526919231493};\\\", \\\"{x:1342,y:762,t:1526919231511};\\\", \\\"{x:1343,y:762,t:1526919231544};\\\", \\\"{x:1344,y:762,t:1526919232296};\\\", \\\"{x:1346,y:764,t:1526919232311};\\\", \\\"{x:1347,y:765,t:1526919232367};\\\", \\\"{x:1348,y:765,t:1526919232383};\\\", \\\"{x:1349,y:765,t:1526919232408};\\\", \\\"{x:1349,y:766,t:1526919232415};\\\", \\\"{x:1351,y:766,t:1526919232428};\\\", \\\"{x:1353,y:767,t:1526919232445};\\\", \\\"{x:1354,y:768,t:1526919232460};\\\", \\\"{x:1355,y:768,t:1526919232477};\\\", \\\"{x:1357,y:768,t:1526919232495};\\\", \\\"{x:1358,y:768,t:1526919233040};\\\", \\\"{x:1358,y:767,t:1526919233136};\\\", \\\"{x:1358,y:766,t:1526919233144};\\\", \\\"{x:1358,y:765,t:1526919233161};\\\", \\\"{x:1358,y:764,t:1526919233177};\\\", \\\"{x:1358,y:763,t:1526919233195};\\\", \\\"{x:1358,y:762,t:1526919233231};\\\", \\\"{x:1358,y:761,t:1526919233279};\\\", \\\"{x:1358,y:760,t:1526919233416};\\\", \\\"{x:1358,y:759,t:1526919233880};\\\", \\\"{x:1358,y:760,t:1526919234159};\\\", \\\"{x:1358,y:761,t:1526919234175};\\\", \\\"{x:1358,y:762,t:1526919234184};\\\", \\\"{x:1358,y:764,t:1526919234195};\\\", \\\"{x:1358,y:768,t:1526919234212};\\\", \\\"{x:1359,y:770,t:1526919234229};\\\", \\\"{x:1361,y:774,t:1526919234246};\\\", \\\"{x:1362,y:776,t:1526919234262};\\\", \\\"{x:1363,y:778,t:1526919234279};\\\", \\\"{x:1365,y:783,t:1526919234296};\\\", \\\"{x:1366,y:786,t:1526919234313};\\\", \\\"{x:1367,y:787,t:1526919234328};\\\", \\\"{x:1368,y:789,t:1526919234346};\\\", \\\"{x:1369,y:792,t:1526919234363};\\\", \\\"{x:1370,y:793,t:1526919234378};\\\", \\\"{x:1371,y:794,t:1526919234396};\\\", \\\"{x:1372,y:796,t:1526919234412};\\\", \\\"{x:1373,y:796,t:1526919234429};\\\", \\\"{x:1373,y:797,t:1526919234446};\\\", \\\"{x:1374,y:797,t:1526919234462};\\\", \\\"{x:1374,y:796,t:1526919235527};\\\", \\\"{x:1374,y:795,t:1526919235535};\\\", \\\"{x:1374,y:794,t:1526919235547};\\\", \\\"{x:1375,y:792,t:1526919235563};\\\", \\\"{x:1376,y:790,t:1526919235580};\\\", \\\"{x:1377,y:789,t:1526919235597};\\\", \\\"{x:1378,y:788,t:1526919235613};\\\", \\\"{x:1377,y:788,t:1526919235768};\\\", \\\"{x:1374,y:787,t:1526919235784};\\\", \\\"{x:1372,y:786,t:1526919235797};\\\", \\\"{x:1367,y:785,t:1526919235814};\\\", \\\"{x:1366,y:783,t:1526919235830};\\\", \\\"{x:1364,y:781,t:1526919235847};\\\", \\\"{x:1364,y:777,t:1526919235864};\\\", \\\"{x:1363,y:775,t:1526919235880};\\\", \\\"{x:1362,y:773,t:1526919235897};\\\", \\\"{x:1361,y:770,t:1526919235914};\\\", \\\"{x:1361,y:769,t:1526919235930};\\\", \\\"{x:1360,y:767,t:1526919235947};\\\", \\\"{x:1360,y:766,t:1526919235964};\\\", \\\"{x:1360,y:764,t:1526919235980};\\\", \\\"{x:1360,y:763,t:1526919235997};\\\", \\\"{x:1360,y:762,t:1526919236014};\\\", \\\"{x:1360,y:760,t:1526919236030};\\\", \\\"{x:1359,y:760,t:1526919236121};\\\", \\\"{x:1359,y:761,t:1526919236505};\\\", \\\"{x:1359,y:760,t:1526919236785};\\\", \\\"{x:1359,y:758,t:1526919236798};\\\", \\\"{x:1358,y:754,t:1526919236814};\\\", \\\"{x:1358,y:753,t:1526919236831};\\\", \\\"{x:1357,y:753,t:1526919236848};\\\", \\\"{x:1356,y:753,t:1526919237137};\\\", \\\"{x:1355,y:753,t:1526919237148};\\\", \\\"{x:1354,y:753,t:1526919237745};\\\", \\\"{x:1353,y:753,t:1526919237753};\\\", \\\"{x:1352,y:753,t:1526919237769};\\\", \\\"{x:1351,y:753,t:1526919237809};\\\", \\\"{x:1350,y:753,t:1526919237841};\\\", \\\"{x:1349,y:753,t:1526919237856};\\\", \\\"{x:1348,y:752,t:1526919237929};\\\", \\\"{x:1347,y:752,t:1526919237985};\\\", \\\"{x:1346,y:752,t:1526919237999};\\\", \\\"{x:1346,y:753,t:1526919238464};\\\", \\\"{x:1346,y:754,t:1526919238479};\\\", \\\"{x:1346,y:756,t:1526919238488};\\\", \\\"{x:1347,y:757,t:1526919238499};\\\", \\\"{x:1348,y:758,t:1526919238516};\\\", \\\"{x:1348,y:759,t:1526919238532};\\\", \\\"{x:1349,y:759,t:1526919238993};\\\", \\\"{x:1350,y:759,t:1526919239000};\\\", \\\"{x:1352,y:759,t:1526919239017};\\\", \\\"{x:1355,y:760,t:1526919239035};\\\", \\\"{x:1358,y:761,t:1526919239050};\\\", \\\"{x:1359,y:761,t:1526919239073};\\\", \\\"{x:1360,y:761,t:1526919239096};\\\", \\\"{x:1361,y:761,t:1526919239241};\\\", \\\"{x:1363,y:761,t:1526919239256};\\\", \\\"{x:1365,y:761,t:1526919239267};\\\", \\\"{x:1368,y:760,t:1526919239283};\\\", \\\"{x:1375,y:758,t:1526919239299};\\\", \\\"{x:1383,y:758,t:1526919239317};\\\", \\\"{x:1387,y:758,t:1526919239334};\\\", \\\"{x:1396,y:758,t:1526919239349};\\\", \\\"{x:1410,y:758,t:1526919239366};\\\", \\\"{x:1423,y:761,t:1526919239383};\\\", \\\"{x:1438,y:764,t:1526919239399};\\\", \\\"{x:1451,y:770,t:1526919239416};\\\", \\\"{x:1454,y:772,t:1526919239434};\\\", \\\"{x:1456,y:774,t:1526919239450};\\\", \\\"{x:1458,y:778,t:1526919239466};\\\", \\\"{x:1460,y:782,t:1526919239484};\\\", \\\"{x:1462,y:785,t:1526919239501};\\\", \\\"{x:1464,y:789,t:1526919239517};\\\", \\\"{x:1466,y:791,t:1526919239533};\\\", \\\"{x:1468,y:794,t:1526919239550};\\\", \\\"{x:1468,y:795,t:1526919239567};\\\", \\\"{x:1469,y:796,t:1526919239608};\\\", \\\"{x:1469,y:797,t:1526919239616};\\\", \\\"{x:1470,y:798,t:1526919239634};\\\", \\\"{x:1470,y:801,t:1526919239650};\\\", \\\"{x:1471,y:803,t:1526919239667};\\\", \\\"{x:1472,y:804,t:1526919239683};\\\", \\\"{x:1474,y:806,t:1526919239700};\\\", \\\"{x:1474,y:807,t:1526919239716};\\\", \\\"{x:1474,y:808,t:1526919239736};\\\", \\\"{x:1474,y:809,t:1526919239751};\\\", \\\"{x:1475,y:810,t:1526919239766};\\\", \\\"{x:1476,y:812,t:1526919239783};\\\", \\\"{x:1477,y:813,t:1526919239800};\\\", \\\"{x:1477,y:815,t:1526919239816};\\\", \\\"{x:1479,y:817,t:1526919239834};\\\", \\\"{x:1479,y:819,t:1526919239851};\\\", \\\"{x:1480,y:821,t:1526919239866};\\\", \\\"{x:1480,y:822,t:1526919239884};\\\", \\\"{x:1481,y:824,t:1526919239900};\\\", \\\"{x:1481,y:825,t:1526919239986};\\\", \\\"{x:1482,y:826,t:1526919242417};\\\", \\\"{x:1481,y:826,t:1526919246408};\\\", \\\"{x:1480,y:826,t:1526919246479};\\\", \\\"{x:1479,y:826,t:1526919246519};\\\", \\\"{x:1478,y:826,t:1526919246535};\\\", \\\"{x:1477,y:826,t:1526919246727};\\\", \\\"{x:1476,y:826,t:1526919247152};\\\", \\\"{x:1475,y:826,t:1526919247191};\\\", \\\"{x:1474,y:826,t:1526919247408};\\\", \\\"{x:1473,y:826,t:1526919247422};\\\", \\\"{x:1472,y:826,t:1526919247438};\\\", \\\"{x:1467,y:822,t:1526919247455};\\\", \\\"{x:1459,y:814,t:1526919247472};\\\", \\\"{x:1458,y:810,t:1526919247488};\\\", \\\"{x:1455,y:802,t:1526919247505};\\\", \\\"{x:1454,y:797,t:1526919247522};\\\", \\\"{x:1452,y:794,t:1526919247539};\\\", \\\"{x:1451,y:793,t:1526919247555};\\\", \\\"{x:1449,y:793,t:1526919247583};\\\", \\\"{x:1449,y:792,t:1526919247591};\\\", \\\"{x:1448,y:792,t:1526919247607};\\\", \\\"{x:1446,y:790,t:1526919247622};\\\", \\\"{x:1440,y:787,t:1526919247639};\\\", \\\"{x:1427,y:780,t:1526919247655};\\\", \\\"{x:1417,y:776,t:1526919247672};\\\", \\\"{x:1409,y:771,t:1526919247689};\\\", \\\"{x:1403,y:768,t:1526919247705};\\\", \\\"{x:1400,y:767,t:1526919247722};\\\", \\\"{x:1396,y:766,t:1526919247739};\\\", \\\"{x:1395,y:766,t:1526919247754};\\\", \\\"{x:1391,y:766,t:1526919247772};\\\", \\\"{x:1389,y:766,t:1526919247789};\\\", \\\"{x:1385,y:766,t:1526919247805};\\\", \\\"{x:1380,y:768,t:1526919247822};\\\", \\\"{x:1378,y:769,t:1526919247839};\\\", \\\"{x:1377,y:769,t:1526919247896};\\\", \\\"{x:1375,y:771,t:1526919247905};\\\", \\\"{x:1372,y:773,t:1526919247922};\\\", \\\"{x:1371,y:774,t:1526919247939};\\\", \\\"{x:1370,y:774,t:1526919247983};\\\", \\\"{x:1369,y:774,t:1526919247991};\\\", \\\"{x:1367,y:775,t:1526919248005};\\\", \\\"{x:1365,y:775,t:1526919248022};\\\", \\\"{x:1360,y:775,t:1526919248039};\\\", \\\"{x:1358,y:775,t:1526919248056};\\\", \\\"{x:1355,y:771,t:1526919248072};\\\", \\\"{x:1354,y:769,t:1526919248103};\\\", \\\"{x:1354,y:768,t:1526919248111};\\\", \\\"{x:1353,y:767,t:1526919248123};\\\", \\\"{x:1353,y:764,t:1526919248139};\\\", \\\"{x:1352,y:762,t:1526919248157};\\\", \\\"{x:1351,y:760,t:1526919248172};\\\", \\\"{x:1351,y:758,t:1526919248232};\\\", \\\"{x:1351,y:757,t:1526919248239};\\\", \\\"{x:1351,y:756,t:1526919248257};\\\", \\\"{x:1351,y:755,t:1526919248272};\\\", \\\"{x:1350,y:755,t:1526919248290};\\\", \\\"{x:1349,y:755,t:1526919248864};\\\", \\\"{x:1348,y:753,t:1526919255160};\\\", \\\"{x:1347,y:747,t:1526919255167};\\\", \\\"{x:1346,y:742,t:1526919255178};\\\", \\\"{x:1343,y:726,t:1526919255195};\\\", \\\"{x:1342,y:715,t:1526919255212};\\\", \\\"{x:1337,y:698,t:1526919255227};\\\", \\\"{x:1334,y:685,t:1526919255244};\\\", \\\"{x:1331,y:674,t:1526919255261};\\\", \\\"{x:1327,y:661,t:1526919255277};\\\", \\\"{x:1323,y:652,t:1526919255294};\\\", \\\"{x:1319,y:639,t:1526919255311};\\\", \\\"{x:1315,y:632,t:1526919255327};\\\", \\\"{x:1313,y:626,t:1526919255345};\\\", \\\"{x:1308,y:618,t:1526919255361};\\\", \\\"{x:1303,y:610,t:1526919255377};\\\", \\\"{x:1296,y:600,t:1526919255394};\\\", \\\"{x:1285,y:590,t:1526919255411};\\\", \\\"{x:1277,y:585,t:1526919255427};\\\", \\\"{x:1273,y:580,t:1526919255445};\\\", \\\"{x:1272,y:575,t:1526919255462};\\\", \\\"{x:1270,y:568,t:1526919255477};\\\", \\\"{x:1268,y:562,t:1526919255494};\\\", \\\"{x:1261,y:554,t:1526919255511};\\\", \\\"{x:1259,y:551,t:1526919255527};\\\", \\\"{x:1257,y:549,t:1526919255544};\\\", \\\"{x:1257,y:548,t:1526919255583};\\\", \\\"{x:1257,y:549,t:1526919255991};\\\", \\\"{x:1257,y:553,t:1526919255998};\\\", \\\"{x:1257,y:560,t:1526919256011};\\\", \\\"{x:1259,y:573,t:1526919256028};\\\", \\\"{x:1262,y:594,t:1526919256045};\\\", \\\"{x:1265,y:616,t:1526919256061};\\\", \\\"{x:1269,y:638,t:1526919256078};\\\", \\\"{x:1271,y:668,t:1526919256095};\\\", \\\"{x:1271,y:686,t:1526919256111};\\\", \\\"{x:1271,y:705,t:1526919256128};\\\", \\\"{x:1271,y:723,t:1526919256145};\\\", \\\"{x:1269,y:741,t:1526919256161};\\\", \\\"{x:1265,y:757,t:1526919256179};\\\", \\\"{x:1261,y:772,t:1526919256195};\\\", \\\"{x:1255,y:791,t:1526919256212};\\\", \\\"{x:1251,y:803,t:1526919256229};\\\", \\\"{x:1246,y:822,t:1526919256246};\\\", \\\"{x:1240,y:837,t:1526919256261};\\\", \\\"{x:1237,y:847,t:1526919256278};\\\", \\\"{x:1234,y:852,t:1526919256295};\\\", \\\"{x:1233,y:852,t:1526919256311};\\\", \\\"{x:1232,y:852,t:1526919256423};\\\", \\\"{x:1230,y:849,t:1526919256431};\\\", \\\"{x:1230,y:847,t:1526919256446};\\\", \\\"{x:1226,y:839,t:1526919256461};\\\", \\\"{x:1222,y:829,t:1526919256478};\\\", \\\"{x:1214,y:811,t:1526919256495};\\\", \\\"{x:1208,y:798,t:1526919256512};\\\", \\\"{x:1206,y:793,t:1526919256529};\\\", \\\"{x:1203,y:789,t:1526919256545};\\\", \\\"{x:1202,y:788,t:1526919256562};\\\", \\\"{x:1202,y:786,t:1526919256579};\\\", \\\"{x:1202,y:785,t:1526919256595};\\\", \\\"{x:1202,y:784,t:1526919256614};\\\", \\\"{x:1200,y:782,t:1526919257023};\\\", \\\"{x:1199,y:782,t:1526919257030};\\\", \\\"{x:1195,y:781,t:1526919257046};\\\", \\\"{x:1193,y:781,t:1526919257062};\\\", \\\"{x:1183,y:778,t:1526919257079};\\\", \\\"{x:1169,y:775,t:1526919257096};\\\", \\\"{x:1152,y:771,t:1526919257112};\\\", \\\"{x:1129,y:764,t:1526919257130};\\\", \\\"{x:1088,y:747,t:1526919257146};\\\", \\\"{x:1042,y:730,t:1526919257162};\\\", \\\"{x:1001,y:714,t:1526919257180};\\\", \\\"{x:969,y:697,t:1526919257195};\\\", \\\"{x:945,y:676,t:1526919257213};\\\", \\\"{x:923,y:653,t:1526919257229};\\\", \\\"{x:894,y:620,t:1526919257245};\\\", \\\"{x:843,y:582,t:1526919257264};\\\", \\\"{x:816,y:566,t:1526919257279};\\\", \\\"{x:783,y:553,t:1526919257297};\\\", \\\"{x:732,y:537,t:1526919257315};\\\", \\\"{x:695,y:525,t:1526919257332};\\\", \\\"{x:670,y:520,t:1526919257348};\\\", \\\"{x:657,y:515,t:1526919257364};\\\", \\\"{x:645,y:510,t:1526919257382};\\\", \\\"{x:633,y:506,t:1526919257397};\\\", \\\"{x:618,y:503,t:1526919257415};\\\", \\\"{x:597,y:500,t:1526919257431};\\\", \\\"{x:583,y:500,t:1526919257448};\\\", \\\"{x:579,y:502,t:1526919257465};\\\", \\\"{x:580,y:500,t:1526919257559};\\\", \\\"{x:582,y:499,t:1526919257639};\\\", \\\"{x:583,y:499,t:1526919257647};\\\", \\\"{x:586,y:499,t:1526919257665};\\\", \\\"{x:590,y:499,t:1526919257681};\\\", \\\"{x:594,y:498,t:1526919257698};\\\", \\\"{x:600,y:498,t:1526919257714};\\\", \\\"{x:609,y:498,t:1526919257732};\\\", \\\"{x:613,y:498,t:1526919257747};\\\", \\\"{x:614,y:498,t:1526919257764};\\\", \\\"{x:616,y:498,t:1526919257782};\\\", \\\"{x:619,y:501,t:1526919257799};\\\", \\\"{x:620,y:502,t:1526919257814};\\\", \\\"{x:621,y:503,t:1526919257832};\\\", \\\"{x:621,y:504,t:1526919258047};\\\", \\\"{x:621,y:504,t:1526919258066};\\\", \\\"{x:619,y:504,t:1526919258099};\\\", \\\"{x:617,y:504,t:1526919258114};\\\", \\\"{x:609,y:504,t:1526919258132};\\\", \\\"{x:590,y:506,t:1526919258149};\\\", \\\"{x:570,y:510,t:1526919258165};\\\", \\\"{x:543,y:510,t:1526919258181};\\\", \\\"{x:485,y:510,t:1526919258199};\\\", \\\"{x:443,y:506,t:1526919258215};\\\", \\\"{x:411,y:501,t:1526919258232};\\\", \\\"{x:392,y:497,t:1526919258248};\\\", \\\"{x:376,y:495,t:1526919258265};\\\", \\\"{x:360,y:492,t:1526919258282};\\\", \\\"{x:351,y:492,t:1526919258298};\\\", \\\"{x:341,y:492,t:1526919258315};\\\", \\\"{x:334,y:492,t:1526919258331};\\\", \\\"{x:328,y:492,t:1526919258348};\\\", \\\"{x:325,y:492,t:1526919258365};\\\", \\\"{x:320,y:492,t:1526919258382};\\\", \\\"{x:310,y:492,t:1526919258398};\\\", \\\"{x:295,y:492,t:1526919258415};\\\", \\\"{x:291,y:492,t:1526919258431};\\\", \\\"{x:289,y:492,t:1526919258519};\\\", \\\"{x:288,y:492,t:1526919258532};\\\", \\\"{x:275,y:492,t:1526919258548};\\\", \\\"{x:255,y:492,t:1526919258566};\\\", \\\"{x:230,y:492,t:1526919258582};\\\", \\\"{x:211,y:492,t:1526919258598};\\\", \\\"{x:197,y:492,t:1526919258615};\\\", \\\"{x:192,y:492,t:1526919258633};\\\", \\\"{x:190,y:492,t:1526919258648};\\\", \\\"{x:189,y:492,t:1526919258666};\\\", \\\"{x:187,y:492,t:1526919258807};\\\", \\\"{x:184,y:493,t:1526919258816};\\\", \\\"{x:174,y:498,t:1526919258833};\\\", \\\"{x:160,y:504,t:1526919258849};\\\", \\\"{x:151,y:508,t:1526919258866};\\\", \\\"{x:145,y:508,t:1526919258883};\\\", \\\"{x:144,y:508,t:1526919258935};\\\", \\\"{x:143,y:508,t:1526919258950};\\\", \\\"{x:142,y:508,t:1526919259079};\\\", \\\"{x:142,y:508,t:1526919259079};\\\", \\\"{x:142,y:507,t:1526919259094};\\\", \\\"{x:142,y:506,t:1526919259110};\\\", \\\"{x:143,y:506,t:1526919259119};\\\", \\\"{x:145,y:504,t:1526919259132};\\\", \\\"{x:151,y:501,t:1526919259149};\\\", \\\"{x:164,y:498,t:1526919259166};\\\", \\\"{x:197,y:496,t:1526919259183};\\\", \\\"{x:216,y:496,t:1526919259199};\\\", \\\"{x:234,y:496,t:1526919259215};\\\", \\\"{x:262,y:498,t:1526919259233};\\\", \\\"{x:294,y:507,t:1526919259249};\\\", \\\"{x:321,y:510,t:1526919259266};\\\", \\\"{x:349,y:515,t:1526919259282};\\\", \\\"{x:375,y:522,t:1526919259300};\\\", \\\"{x:389,y:526,t:1526919259316};\\\", \\\"{x:399,y:530,t:1526919259332};\\\", \\\"{x:403,y:530,t:1526919259349};\\\", \\\"{x:404,y:530,t:1526919259365};\\\", \\\"{x:402,y:530,t:1526919259431};\\\", \\\"{x:397,y:530,t:1526919259438};\\\", \\\"{x:393,y:530,t:1526919259449};\\\", \\\"{x:384,y:530,t:1526919259467};\\\", \\\"{x:378,y:526,t:1526919259483};\\\", \\\"{x:374,y:520,t:1526919259501};\\\", \\\"{x:371,y:516,t:1526919259517};\\\", \\\"{x:371,y:513,t:1526919259533};\\\", \\\"{x:371,y:511,t:1526919259549};\\\", \\\"{x:371,y:508,t:1526919259566};\\\", \\\"{x:371,y:506,t:1526919259583};\\\", \\\"{x:374,y:502,t:1526919259599};\\\", \\\"{x:375,y:500,t:1526919259616};\\\", \\\"{x:380,y:498,t:1526919259632};\\\", \\\"{x:381,y:497,t:1526919259649};\\\", \\\"{x:382,y:496,t:1526919259667};\\\", \\\"{x:383,y:496,t:1526919259695};\\\", \\\"{x:384,y:496,t:1526919259703};\\\", \\\"{x:385,y:497,t:1526919259726};\\\", \\\"{x:386,y:497,t:1526919259743};\\\", \\\"{x:387,y:497,t:1526919259751};\\\", \\\"{x:388,y:497,t:1526919259766};\\\", \\\"{x:389,y:498,t:1526919259783};\\\", \\\"{x:391,y:499,t:1526919259800};\\\", \\\"{x:390,y:499,t:1526919259975};\\\", \\\"{x:385,y:501,t:1526919259990};\\\", \\\"{x:378,y:502,t:1526919260000};\\\", \\\"{x:355,y:508,t:1526919260017};\\\", \\\"{x:320,y:512,t:1526919260034};\\\", \\\"{x:266,y:516,t:1526919260050};\\\", \\\"{x:208,y:521,t:1526919260066};\\\", \\\"{x:166,y:527,t:1526919260084};\\\", \\\"{x:147,y:528,t:1526919260099};\\\", \\\"{x:141,y:528,t:1526919260116};\\\", \\\"{x:138,y:528,t:1526919260133};\\\", \\\"{x:137,y:528,t:1526919260207};\\\", \\\"{x:138,y:525,t:1526919260223};\\\", \\\"{x:140,y:523,t:1526919260234};\\\", \\\"{x:147,y:520,t:1526919260250};\\\", \\\"{x:156,y:516,t:1526919260267};\\\", \\\"{x:159,y:516,t:1526919260283};\\\", \\\"{x:162,y:515,t:1526919260300};\\\", \\\"{x:163,y:515,t:1526919260317};\\\", \\\"{x:165,y:515,t:1526919260335};\\\", \\\"{x:165,y:516,t:1526919260351};\\\", \\\"{x:166,y:516,t:1526919260367};\\\", \\\"{x:173,y:516,t:1526919260383};\\\", \\\"{x:174,y:516,t:1526919260400};\\\", \\\"{x:175,y:516,t:1526919260416};\\\", \\\"{x:175,y:515,t:1526919260519};\\\", \\\"{x:175,y:514,t:1526919260534};\\\", \\\"{x:175,y:509,t:1526919260551};\\\", \\\"{x:174,y:508,t:1526919260567};\\\", \\\"{x:171,y:504,t:1526919260584};\\\", \\\"{x:169,y:502,t:1526919260600};\\\", \\\"{x:167,y:501,t:1526919260618};\\\", \\\"{x:166,y:499,t:1526919260634};\\\", \\\"{x:165,y:499,t:1526919260655};\\\", \\\"{x:165,y:498,t:1526919260671};\\\", \\\"{x:163,y:498,t:1526919261215};\\\", \\\"{x:161,y:498,t:1526919261231};\\\", \\\"{x:159,y:498,t:1526919261247};\\\", \\\"{x:157,y:497,t:1526919261263};\\\", \\\"{x:156,y:496,t:1526919261270};\\\", \\\"{x:160,y:496,t:1526919261319};\\\", \\\"{x:188,y:493,t:1526919261334};\\\", \\\"{x:223,y:491,t:1526919261350};\\\", \\\"{x:311,y:491,t:1526919261368};\\\", \\\"{x:425,y:491,t:1526919261383};\\\", \\\"{x:572,y:497,t:1526919261401};\\\", \\\"{x:733,y:523,t:1526919261417};\\\", \\\"{x:886,y:545,t:1526919261434};\\\", \\\"{x:1011,y:568,t:1526919261451};\\\", \\\"{x:1115,y:592,t:1526919261468};\\\", \\\"{x:1187,y:609,t:1526919261485};\\\", \\\"{x:1230,y:626,t:1526919261501};\\\", \\\"{x:1242,y:634,t:1526919261517};\\\", \\\"{x:1244,y:642,t:1526919261535};\\\", \\\"{x:1244,y:648,t:1526919261550};\\\", \\\"{x:1243,y:656,t:1526919261568};\\\", \\\"{x:1237,y:666,t:1526919261585};\\\", \\\"{x:1230,y:677,t:1526919261600};\\\", \\\"{x:1224,y:692,t:1526919261617};\\\", \\\"{x:1219,y:707,t:1526919261634};\\\", \\\"{x:1214,y:722,t:1526919261651};\\\", \\\"{x:1206,y:733,t:1526919261667};\\\", \\\"{x:1200,y:738,t:1526919261685};\\\", \\\"{x:1193,y:741,t:1526919261701};\\\", \\\"{x:1186,y:747,t:1526919261718};\\\", \\\"{x:1182,y:755,t:1526919261735};\\\", \\\"{x:1181,y:762,t:1526919261751};\\\", \\\"{x:1181,y:766,t:1526919261768};\\\", \\\"{x:1181,y:771,t:1526919261785};\\\", \\\"{x:1181,y:774,t:1526919261801};\\\", \\\"{x:1182,y:778,t:1526919261818};\\\", \\\"{x:1183,y:779,t:1526919261835};\\\", \\\"{x:1183,y:780,t:1526919261855};\\\", \\\"{x:1183,y:781,t:1526919261871};\\\", \\\"{x:1183,y:780,t:1526919261927};\\\", \\\"{x:1183,y:777,t:1526919261943};\\\", \\\"{x:1183,y:774,t:1526919261951};\\\", \\\"{x:1186,y:766,t:1526919261968};\\\", \\\"{x:1187,y:760,t:1526919261985};\\\", \\\"{x:1188,y:756,t:1526919262002};\\\", \\\"{x:1190,y:753,t:1526919262018};\\\", \\\"{x:1191,y:751,t:1526919262035};\\\", \\\"{x:1192,y:750,t:1526919262087};\\\", \\\"{x:1193,y:750,t:1526919262102};\\\", \\\"{x:1193,y:752,t:1526919262174};\\\", \\\"{x:1193,y:754,t:1526919262185};\\\", \\\"{x:1191,y:757,t:1526919262202};\\\", \\\"{x:1188,y:759,t:1526919262219};\\\", \\\"{x:1188,y:760,t:1526919262235};\\\", \\\"{x:1186,y:761,t:1526919262311};\\\", \\\"{x:1185,y:762,t:1526919262342};\\\", \\\"{x:1184,y:762,t:1526919262551};\\\", \\\"{x:1183,y:762,t:1526919262591};\\\", \\\"{x:1182,y:762,t:1526919262862};\\\", \\\"{x:1181,y:762,t:1526919264767};\\\", \\\"{x:1181,y:761,t:1526919268703};\\\", \\\"{x:1186,y:760,t:1526919268710};\\\", \\\"{x:1193,y:757,t:1526919268723};\\\", \\\"{x:1213,y:752,t:1526919268740};\\\", \\\"{x:1243,y:744,t:1526919268756};\\\", \\\"{x:1280,y:737,t:1526919268773};\\\", \\\"{x:1330,y:731,t:1526919268790};\\\", \\\"{x:1369,y:727,t:1526919268806};\\\", \\\"{x:1430,y:727,t:1526919268823};\\\", \\\"{x:1462,y:727,t:1526919268840};\\\", \\\"{x:1488,y:731,t:1526919268857};\\\", \\\"{x:1508,y:736,t:1526919268873};\\\", \\\"{x:1524,y:741,t:1526919268890};\\\", \\\"{x:1537,y:746,t:1526919268907};\\\", \\\"{x:1539,y:747,t:1526919268923};\\\", \\\"{x:1541,y:750,t:1526919268940};\\\", \\\"{x:1542,y:753,t:1526919268957};\\\", \\\"{x:1542,y:756,t:1526919268973};\\\", \\\"{x:1542,y:760,t:1526919268989};\\\", \\\"{x:1542,y:769,t:1526919269006};\\\", \\\"{x:1542,y:775,t:1526919269023};\\\", \\\"{x:1540,y:781,t:1526919269040};\\\", \\\"{x:1536,y:788,t:1526919269057};\\\", \\\"{x:1531,y:798,t:1526919269073};\\\", \\\"{x:1526,y:805,t:1526919269090};\\\", \\\"{x:1525,y:807,t:1526919269107};\\\", \\\"{x:1523,y:810,t:1526919269123};\\\", \\\"{x:1521,y:813,t:1526919269140};\\\", \\\"{x:1519,y:815,t:1526919269157};\\\", \\\"{x:1516,y:818,t:1526919269173};\\\", \\\"{x:1511,y:821,t:1526919269190};\\\", \\\"{x:1508,y:823,t:1526919269207};\\\", \\\"{x:1505,y:825,t:1526919269223};\\\", \\\"{x:1498,y:827,t:1526919269240};\\\", \\\"{x:1490,y:827,t:1526919269257};\\\", \\\"{x:1483,y:827,t:1526919269274};\\\", \\\"{x:1478,y:827,t:1526919269290};\\\", \\\"{x:1477,y:827,t:1526919269307};\\\", \\\"{x:1477,y:828,t:1526919269591};\\\", \\\"{x:1479,y:828,t:1526919269871};\\\", \\\"{x:1480,y:829,t:1526919276703};\\\", \\\"{x:1479,y:829,t:1526919279891};\\\", \\\"{x:1478,y:829,t:1526919279939};\\\", \\\"{x:1477,y:829,t:1526919279955};\\\", \\\"{x:1476,y:828,t:1526919279970};\\\", \\\"{x:1474,y:828,t:1526919279985};\\\", \\\"{x:1469,y:827,t:1526919280002};\\\", \\\"{x:1461,y:825,t:1526919280018};\\\", \\\"{x:1445,y:822,t:1526919280036};\\\", \\\"{x:1432,y:822,t:1526919280052};\\\", \\\"{x:1418,y:822,t:1526919280068};\\\", \\\"{x:1400,y:822,t:1526919280086};\\\", \\\"{x:1388,y:822,t:1526919280103};\\\", \\\"{x:1379,y:822,t:1526919280118};\\\", \\\"{x:1375,y:821,t:1526919280135};\\\", \\\"{x:1372,y:819,t:1526919280152};\\\", \\\"{x:1366,y:817,t:1526919280169};\\\", \\\"{x:1363,y:817,t:1526919280186};\\\", \\\"{x:1342,y:817,t:1526919280203};\\\", \\\"{x:1330,y:817,t:1526919280219};\\\", \\\"{x:1321,y:817,t:1526919280235};\\\", \\\"{x:1310,y:817,t:1526919280252};\\\", \\\"{x:1300,y:817,t:1526919280269};\\\", \\\"{x:1288,y:815,t:1526919280286};\\\", \\\"{x:1275,y:815,t:1526919280303};\\\", \\\"{x:1262,y:814,t:1526919280320};\\\", \\\"{x:1243,y:814,t:1526919280335};\\\", \\\"{x:1224,y:813,t:1526919280353};\\\", \\\"{x:1207,y:809,t:1526919280369};\\\", \\\"{x:1196,y:808,t:1526919280385};\\\", \\\"{x:1191,y:805,t:1526919280402};\\\", \\\"{x:1190,y:799,t:1526919280420};\\\", \\\"{x:1190,y:793,t:1526919280435};\\\", \\\"{x:1190,y:787,t:1526919280452};\\\", \\\"{x:1189,y:782,t:1526919280469};\\\", \\\"{x:1189,y:780,t:1526919280485};\\\", \\\"{x:1188,y:778,t:1526919280502};\\\", \\\"{x:1188,y:777,t:1526919280519};\\\", \\\"{x:1188,y:775,t:1526919280539};\\\", \\\"{x:1188,y:773,t:1526919280553};\\\", \\\"{x:1188,y:770,t:1526919280569};\\\", \\\"{x:1188,y:767,t:1526919280586};\\\", \\\"{x:1188,y:766,t:1526919280602};\\\", \\\"{x:1188,y:765,t:1526919280786};\\\", \\\"{x:1187,y:765,t:1526919280803};\\\", \\\"{x:1186,y:765,t:1526919280875};\\\", \\\"{x:1185,y:765,t:1526919280886};\\\", \\\"{x:1184,y:765,t:1526919280903};\\\", \\\"{x:1182,y:763,t:1526919280919};\\\", \\\"{x:1181,y:763,t:1526919280962};\\\", \\\"{x:1180,y:762,t:1526919280986};\\\", \\\"{x:1179,y:762,t:1526919281018};\\\", \\\"{x:1178,y:762,t:1526919281083};\\\", \\\"{x:1177,y:762,t:1526919281138};\\\", \\\"{x:1177,y:763,t:1526919283610};\\\", \\\"{x:1178,y:764,t:1526919283621};\\\", \\\"{x:1183,y:771,t:1526919283639};\\\", \\\"{x:1191,y:780,t:1526919283654};\\\", \\\"{x:1200,y:792,t:1526919283671};\\\", \\\"{x:1207,y:801,t:1526919283688};\\\", \\\"{x:1214,y:809,t:1526919283704};\\\", \\\"{x:1219,y:816,t:1526919283721};\\\", \\\"{x:1230,y:832,t:1526919283738};\\\", \\\"{x:1240,y:844,t:1526919283755};\\\", \\\"{x:1247,y:853,t:1526919283771};\\\", \\\"{x:1255,y:862,t:1526919283788};\\\", \\\"{x:1261,y:870,t:1526919283805};\\\", \\\"{x:1267,y:879,t:1526919283821};\\\", \\\"{x:1269,y:887,t:1526919283839};\\\", \\\"{x:1275,y:896,t:1526919283855};\\\", \\\"{x:1281,y:903,t:1526919283871};\\\", \\\"{x:1286,y:910,t:1526919283889};\\\", \\\"{x:1288,y:912,t:1526919283904};\\\", \\\"{x:1289,y:914,t:1526919283921};\\\", \\\"{x:1290,y:916,t:1526919283938};\\\", \\\"{x:1290,y:917,t:1526919283954};\\\", \\\"{x:1291,y:921,t:1526919283972};\\\", \\\"{x:1292,y:923,t:1526919283988};\\\", \\\"{x:1293,y:927,t:1526919284005};\\\", \\\"{x:1294,y:930,t:1526919284022};\\\", \\\"{x:1294,y:932,t:1526919284038};\\\", \\\"{x:1295,y:933,t:1526919284055};\\\", \\\"{x:1295,y:935,t:1526919284071};\\\", \\\"{x:1295,y:937,t:1526919284089};\\\", \\\"{x:1295,y:939,t:1526919284106};\\\", \\\"{x:1295,y:941,t:1526919284121};\\\", \\\"{x:1295,y:943,t:1526919284138};\\\", \\\"{x:1295,y:945,t:1526919284156};\\\", \\\"{x:1296,y:947,t:1526919284172};\\\", \\\"{x:1296,y:949,t:1526919284188};\\\", \\\"{x:1296,y:950,t:1526919284205};\\\", \\\"{x:1296,y:951,t:1526919284221};\\\", \\\"{x:1296,y:952,t:1526919284238};\\\", \\\"{x:1296,y:953,t:1526919284371};\\\", \\\"{x:1296,y:954,t:1526919284379};\\\", \\\"{x:1296,y:955,t:1526919284410};\\\", \\\"{x:1296,y:956,t:1526919284427};\\\", \\\"{x:1296,y:957,t:1526919284442};\\\", \\\"{x:1296,y:956,t:1526919285442};\\\", \\\"{x:1294,y:954,t:1526919285456};\\\", \\\"{x:1292,y:952,t:1526919285472};\\\", \\\"{x:1291,y:950,t:1526919285490};\\\", \\\"{x:1290,y:947,t:1526919285506};\\\", \\\"{x:1289,y:946,t:1526919285523};\\\", \\\"{x:1288,y:945,t:1526919285539};\\\", \\\"{x:1288,y:941,t:1526919285557};\\\", \\\"{x:1286,y:938,t:1526919285573};\\\", \\\"{x:1286,y:936,t:1526919285590};\\\", \\\"{x:1286,y:935,t:1526919285606};\\\", \\\"{x:1286,y:933,t:1526919285623};\\\", \\\"{x:1286,y:932,t:1526919285639};\\\", \\\"{x:1286,y:931,t:1526919285657};\\\", \\\"{x:1286,y:930,t:1526919285672};\\\", \\\"{x:1286,y:929,t:1526919285691};\\\", \\\"{x:1285,y:929,t:1526919285730};\\\", \\\"{x:1285,y:928,t:1526919285778};\\\", \\\"{x:1285,y:927,t:1526919285811};\\\", \\\"{x:1285,y:926,t:1526919285826};\\\", \\\"{x:1285,y:925,t:1526919285850};\\\", \\\"{x:1285,y:924,t:1526919285858};\\\", \\\"{x:1285,y:923,t:1526919285872};\\\", \\\"{x:1285,y:920,t:1526919285889};\\\", \\\"{x:1285,y:916,t:1526919285907};\\\", \\\"{x:1285,y:914,t:1526919285923};\\\", \\\"{x:1285,y:913,t:1526919285939};\\\", \\\"{x:1285,y:912,t:1526919285956};\\\", \\\"{x:1285,y:910,t:1526919285973};\\\", \\\"{x:1283,y:908,t:1526919285990};\\\", \\\"{x:1282,y:904,t:1526919286007};\\\", \\\"{x:1282,y:902,t:1526919286023};\\\", \\\"{x:1281,y:899,t:1526919286039};\\\", \\\"{x:1279,y:893,t:1526919286056};\\\", \\\"{x:1276,y:886,t:1526919286073};\\\", \\\"{x:1274,y:883,t:1526919286089};\\\", \\\"{x:1272,y:875,t:1526919286107};\\\", \\\"{x:1270,y:869,t:1526919286123};\\\", \\\"{x:1270,y:863,t:1526919286140};\\\", \\\"{x:1268,y:858,t:1526919286156};\\\", \\\"{x:1268,y:854,t:1526919286173};\\\", \\\"{x:1267,y:851,t:1526919286190};\\\", \\\"{x:1267,y:850,t:1526919286206};\\\", \\\"{x:1267,y:849,t:1526919286224};\\\", \\\"{x:1265,y:849,t:1526919286474};\\\", \\\"{x:1264,y:849,t:1526919286490};\\\", \\\"{x:1261,y:849,t:1526919286507};\\\", \\\"{x:1255,y:849,t:1526919286523};\\\", \\\"{x:1252,y:850,t:1526919286541};\\\", \\\"{x:1248,y:850,t:1526919286556};\\\", \\\"{x:1246,y:849,t:1526919286573};\\\", \\\"{x:1244,y:849,t:1526919286591};\\\", \\\"{x:1239,y:846,t:1526919286607};\\\", \\\"{x:1235,y:844,t:1526919286623};\\\", \\\"{x:1230,y:842,t:1526919286641};\\\", \\\"{x:1224,y:840,t:1526919286656};\\\", \\\"{x:1222,y:839,t:1526919286673};\\\", \\\"{x:1220,y:838,t:1526919286691};\\\", \\\"{x:1220,y:836,t:1526919286923};\\\", \\\"{x:1219,y:835,t:1526919286938};\\\", \\\"{x:1218,y:835,t:1526919286954};\\\", \\\"{x:1218,y:831,t:1526919287531};\\\", \\\"{x:1218,y:829,t:1526919287540};\\\", \\\"{x:1223,y:821,t:1526919287557};\\\", \\\"{x:1232,y:813,t:1526919287575};\\\", \\\"{x:1241,y:806,t:1526919287590};\\\", \\\"{x:1249,y:802,t:1526919287608};\\\", \\\"{x:1253,y:801,t:1526919287625};\\\", \\\"{x:1257,y:800,t:1526919287640};\\\", \\\"{x:1263,y:800,t:1526919287658};\\\", \\\"{x:1270,y:798,t:1526919287674};\\\", \\\"{x:1279,y:796,t:1526919287690};\\\", \\\"{x:1288,y:794,t:1526919287708};\\\", \\\"{x:1304,y:790,t:1526919287724};\\\", \\\"{x:1319,y:788,t:1526919287740};\\\", \\\"{x:1339,y:782,t:1526919287758};\\\", \\\"{x:1349,y:779,t:1526919287775};\\\", \\\"{x:1356,y:777,t:1526919287791};\\\", \\\"{x:1356,y:776,t:1526919287807};\\\", \\\"{x:1357,y:775,t:1526919287883};\\\", \\\"{x:1358,y:774,t:1526919288035};\\\", \\\"{x:1358,y:773,t:1526919288042};\\\", \\\"{x:1358,y:772,t:1526919288058};\\\", \\\"{x:1358,y:770,t:1526919288074};\\\", \\\"{x:1358,y:769,t:1526919288091};\\\", \\\"{x:1358,y:767,t:1526919288108};\\\", \\\"{x:1358,y:766,t:1526919288124};\\\", \\\"{x:1358,y:765,t:1526919288154};\\\", \\\"{x:1357,y:764,t:1526919288171};\\\", \\\"{x:1356,y:764,t:1526919288211};\\\", \\\"{x:1355,y:763,t:1526919288225};\\\", \\\"{x:1354,y:763,t:1526919288242};\\\", \\\"{x:1353,y:762,t:1526919288257};\\\", \\\"{x:1352,y:762,t:1526919288275};\\\", \\\"{x:1351,y:762,t:1526919288346};\\\", \\\"{x:1351,y:761,t:1526919288386};\\\", \\\"{x:1350,y:761,t:1526919288394};\\\", \\\"{x:1349,y:760,t:1526919288411};\\\", \\\"{x:1349,y:759,t:1526919288442};\\\", \\\"{x:1347,y:757,t:1526919289955};\\\", \\\"{x:1342,y:751,t:1526919289962};\\\", \\\"{x:1338,y:746,t:1526919289975};\\\", \\\"{x:1330,y:733,t:1526919289993};\\\", \\\"{x:1323,y:722,t:1526919290010};\\\", \\\"{x:1317,y:712,t:1526919290027};\\\", \\\"{x:1312,y:705,t:1526919290042};\\\", \\\"{x:1307,y:696,t:1526919290060};\\\", \\\"{x:1299,y:686,t:1526919290076};\\\", \\\"{x:1293,y:676,t:1526919290093};\\\", \\\"{x:1288,y:666,t:1526919290110};\\\", \\\"{x:1280,y:649,t:1526919290125};\\\", \\\"{x:1273,y:626,t:1526919290142};\\\", \\\"{x:1264,y:610,t:1526919290160};\\\", \\\"{x:1260,y:598,t:1526919290176};\\\", \\\"{x:1258,y:589,t:1526919290193};\\\", \\\"{x:1257,y:584,t:1526919290210};\\\", \\\"{x:1255,y:576,t:1526919290226};\\\", \\\"{x:1255,y:569,t:1526919290242};\\\", \\\"{x:1255,y:564,t:1526919290259};\\\", \\\"{x:1255,y:559,t:1526919290276};\\\", \\\"{x:1255,y:557,t:1526919290293};\\\", \\\"{x:1255,y:556,t:1526919290314};\\\", \\\"{x:1255,y:558,t:1526919290467};\\\", \\\"{x:1255,y:561,t:1526919290477};\\\", \\\"{x:1255,y:570,t:1526919290492};\\\", \\\"{x:1249,y:590,t:1526919290510};\\\", \\\"{x:1233,y:617,t:1526919290527};\\\", \\\"{x:1191,y:655,t:1526919290543};\\\", \\\"{x:1137,y:686,t:1526919290559};\\\", \\\"{x:1076,y:702,t:1526919290577};\\\", \\\"{x:999,y:712,t:1526919290593};\\\", \\\"{x:910,y:712,t:1526919290609};\\\", \\\"{x:762,y:711,t:1526919290626};\\\", \\\"{x:659,y:693,t:1526919290643};\\\", \\\"{x:543,y:660,t:1526919290660};\\\", \\\"{x:422,y:631,t:1526919290677};\\\", \\\"{x:297,y:592,t:1526919290694};\\\", \\\"{x:217,y:554,t:1526919290711};\\\", \\\"{x:166,y:519,t:1526919290723};\\\", \\\"{x:145,y:497,t:1526919290739};\\\", \\\"{x:140,y:480,t:1526919290762};\\\", \\\"{x:140,y:466,t:1526919290778};\\\", \\\"{x:143,y:455,t:1526919290795};\\\", \\\"{x:151,y:446,t:1526919290811};\\\", \\\"{x:170,y:434,t:1526919290829};\\\", \\\"{x:197,y:425,t:1526919290844};\\\", \\\"{x:217,y:419,t:1526919290862};\\\", \\\"{x:233,y:418,t:1526919290878};\\\", \\\"{x:243,y:418,t:1526919290895};\\\", \\\"{x:255,y:420,t:1526919290911};\\\", \\\"{x:264,y:428,t:1526919290929};\\\", \\\"{x:276,y:440,t:1526919290944};\\\", \\\"{x:295,y:451,t:1526919290962};\\\", \\\"{x:334,y:464,t:1526919290978};\\\", \\\"{x:364,y:469,t:1526919290995};\\\", \\\"{x:394,y:474,t:1526919291011};\\\", \\\"{x:415,y:478,t:1526919291029};\\\", \\\"{x:425,y:480,t:1526919291045};\\\", \\\"{x:429,y:482,t:1526919291062};\\\", \\\"{x:430,y:485,t:1526919291079};\\\", \\\"{x:431,y:491,t:1526919291095};\\\", \\\"{x:431,y:495,t:1526919291112};\\\", \\\"{x:431,y:496,t:1526919291128};\\\", \\\"{x:430,y:498,t:1526919291146};\\\", \\\"{x:428,y:500,t:1526919291163};\\\", \\\"{x:425,y:501,t:1526919291178};\\\", \\\"{x:413,y:502,t:1526919291195};\\\", \\\"{x:396,y:502,t:1526919291212};\\\", \\\"{x:384,y:502,t:1526919291229};\\\", \\\"{x:372,y:499,t:1526919291246};\\\", \\\"{x:371,y:497,t:1526919291263};\\\", \\\"{x:369,y:495,t:1526919291278};\\\", \\\"{x:370,y:495,t:1526919291402};\\\", \\\"{x:371,y:495,t:1526919291418};\\\", \\\"{x:372,y:496,t:1526919291429};\\\", \\\"{x:374,y:497,t:1526919291445};\\\", \\\"{x:375,y:497,t:1526919291462};\\\", \\\"{x:376,y:497,t:1526919291499};\\\", \\\"{x:376,y:498,t:1526919291755};\\\", \\\"{x:370,y:498,t:1526919291762};\\\", \\\"{x:341,y:501,t:1526919291779};\\\", \\\"{x:313,y:503,t:1526919291795};\\\", \\\"{x:291,y:506,t:1526919291812};\\\", \\\"{x:274,y:506,t:1526919291829};\\\", \\\"{x:261,y:506,t:1526919291846};\\\", \\\"{x:252,y:506,t:1526919291862};\\\", \\\"{x:246,y:506,t:1526919291879};\\\", \\\"{x:236,y:506,t:1526919291896};\\\", \\\"{x:225,y:506,t:1526919291913};\\\", \\\"{x:212,y:506,t:1526919291930};\\\", \\\"{x:202,y:506,t:1526919291946};\\\", \\\"{x:195,y:506,t:1526919291963};\\\", \\\"{x:191,y:506,t:1526919291979};\\\", \\\"{x:190,y:506,t:1526919292026};\\\", \\\"{x:188,y:506,t:1526919292042};\\\", \\\"{x:184,y:504,t:1526919292058};\\\", \\\"{x:182,y:503,t:1526919292066};\\\", \\\"{x:179,y:502,t:1526919292080};\\\", \\\"{x:173,y:500,t:1526919292096};\\\", \\\"{x:167,y:498,t:1526919292113};\\\", \\\"{x:164,y:497,t:1526919292130};\\\", \\\"{x:162,y:496,t:1526919292146};\\\", \\\"{x:159,y:495,t:1526919292162};\\\", \\\"{x:158,y:495,t:1526919292186};\\\", \\\"{x:161,y:495,t:1526919292410};\\\", \\\"{x:168,y:496,t:1526919292418};\\\", \\\"{x:178,y:501,t:1526919292430};\\\", \\\"{x:208,y:520,t:1526919292446};\\\", \\\"{x:249,y:546,t:1526919292463};\\\", \\\"{x:301,y:578,t:1526919292480};\\\", \\\"{x:361,y:621,t:1526919292497};\\\", \\\"{x:425,y:670,t:1526919292513};\\\", \\\"{x:480,y:714,t:1526919292530};\\\", \\\"{x:513,y:741,t:1526919292546};\\\", \\\"{x:527,y:753,t:1526919292563};\\\", \\\"{x:530,y:758,t:1526919292580};\\\", \\\"{x:532,y:760,t:1526919292596};\\\", \\\"{x:532,y:764,t:1526919292613};\\\", \\\"{x:535,y:773,t:1526919292630};\\\", \\\"{x:535,y:783,t:1526919292647};\\\", \\\"{x:537,y:797,t:1526919292664};\\\", \\\"{x:541,y:809,t:1526919292680};\\\", \\\"{x:542,y:812,t:1526919292697};\\\", \\\"{x:542,y:813,t:1526919292722};\\\", \\\"{x:542,y:810,t:1526919292795};\\\", \\\"{x:542,y:805,t:1526919292801};\\\", \\\"{x:539,y:798,t:1526919292814};\\\", \\\"{x:534,y:785,t:1526919292830};\\\", \\\"{x:529,y:770,t:1526919292847};\\\", \\\"{x:525,y:757,t:1526919292864};\\\", \\\"{x:524,y:752,t:1526919292880};\\\", \\\"{x:522,y:747,t:1526919292896};\\\", \\\"{x:521,y:742,t:1526919292914};\\\", \\\"{x:520,y:740,t:1526919292930};\\\", \\\"{x:519,y:736,t:1526919292947};\\\", \\\"{x:519,y:735,t:1526919292964};\\\", \\\"{x:519,y:734,t:1526919292979};\\\", \\\"{x:519,y:733,t:1526919292996};\\\", \\\"{x:519,y:732,t:1526919293014};\\\", \\\"{x:519,y:731,t:1526919293074};\\\", \\\"{x:518,y:731,t:1526919293690};\\\", \\\"{x:517,y:730,t:1526919293722};\\\", \\\"{x:516,y:730,t:1526919294818};\\\", \\\"{x:515,y:730,t:1526919295410};\\\", \\\"{x:514,y:730,t:1526919295578};\\\", \\\"{x:513,y:730,t:1526919295706};\\\", \\\"{x:512,y:730,t:1526919295716};\\\", \\\"{x:510,y:728,t:1526919295732};\\\", \\\"{x:509,y:727,t:1526919295749};\\\", \\\"{x:507,y:727,t:1526919295766};\\\", \\\"{x:505,y:727,t:1526919295802};\\\", \\\"{x:505,y:726,t:1526919295842};\\\", \\\"{x:504,y:726,t:1526919295866};\\\", \\\"{x:502,y:724,t:1526919295882};\\\", \\\"{x:501,y:724,t:1526919296290};\\\", \\\"{x:499,y:724,t:1526919296322};\\\" ] }, { \\\"rt\\\": 27620, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 704232, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -J -I -I -12 PM-01 PM-12 PM-1\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:722,t:1526919298890};\\\", \\\"{x:504,y:720,t:1526919298901};\\\", \\\"{x:506,y:720,t:1526919298918};\\\", \\\"{x:509,y:720,t:1526919298935};\\\", \\\"{x:513,y:718,t:1526919298951};\\\", \\\"{x:514,y:718,t:1526919298968};\\\", \\\"{x:516,y:717,t:1526919298985};\\\", \\\"{x:527,y:712,t:1526919299002};\\\", \\\"{x:545,y:707,t:1526919299018};\\\", \\\"{x:564,y:704,t:1526919299034};\\\", \\\"{x:585,y:701,t:1526919299052};\\\", \\\"{x:606,y:696,t:1526919299068};\\\", \\\"{x:628,y:695,t:1526919299085};\\\", \\\"{x:644,y:692,t:1526919299102};\\\", \\\"{x:661,y:690,t:1526919299118};\\\", \\\"{x:679,y:689,t:1526919299134};\\\", \\\"{x:696,y:687,t:1526919299152};\\\", \\\"{x:708,y:685,t:1526919299169};\\\", \\\"{x:719,y:685,t:1526919299185};\\\", \\\"{x:736,y:685,t:1526919299202};\\\", \\\"{x:749,y:685,t:1526919299219};\\\", \\\"{x:762,y:685,t:1526919299235};\\\", \\\"{x:783,y:685,t:1526919299252};\\\", \\\"{x:805,y:687,t:1526919299269};\\\", \\\"{x:837,y:687,t:1526919299285};\\\", \\\"{x:879,y:687,t:1526919299302};\\\", \\\"{x:924,y:687,t:1526919299319};\\\", \\\"{x:969,y:687,t:1526919299335};\\\", \\\"{x:1022,y:687,t:1526919299352};\\\", \\\"{x:1088,y:687,t:1526919299369};\\\", \\\"{x:1177,y:687,t:1526919299386};\\\", \\\"{x:1302,y:698,t:1526919299402};\\\", \\\"{x:1383,y:724,t:1526919299419};\\\", \\\"{x:1452,y:753,t:1526919299435};\\\", \\\"{x:1492,y:772,t:1526919299452};\\\", \\\"{x:1522,y:792,t:1526919299469};\\\", \\\"{x:1543,y:808,t:1526919299485};\\\", \\\"{x:1557,y:821,t:1526919299502};\\\", \\\"{x:1564,y:831,t:1526919299519};\\\", \\\"{x:1568,y:841,t:1526919299535};\\\", \\\"{x:1571,y:849,t:1526919299552};\\\", \\\"{x:1571,y:853,t:1526919299569};\\\", \\\"{x:1571,y:854,t:1526919299585};\\\", \\\"{x:1571,y:855,t:1526919299650};\\\", \\\"{x:1570,y:855,t:1526919299666};\\\", \\\"{x:1568,y:855,t:1526919299674};\\\", \\\"{x:1565,y:855,t:1526919299686};\\\", \\\"{x:1555,y:855,t:1526919299702};\\\", \\\"{x:1543,y:853,t:1526919299719};\\\", \\\"{x:1531,y:848,t:1526919299736};\\\", \\\"{x:1515,y:843,t:1526919299752};\\\", \\\"{x:1506,y:839,t:1526919299769};\\\", \\\"{x:1490,y:832,t:1526919299786};\\\", \\\"{x:1485,y:831,t:1526919299802};\\\", \\\"{x:1483,y:830,t:1526919299819};\\\", \\\"{x:1481,y:830,t:1526919299836};\\\", \\\"{x:1480,y:830,t:1526919299852};\\\", \\\"{x:1478,y:830,t:1526919299882};\\\", \\\"{x:1477,y:830,t:1526919299897};\\\", \\\"{x:1475,y:830,t:1526919299922};\\\", \\\"{x:1474,y:830,t:1526919299994};\\\", \\\"{x:1472,y:829,t:1526919300043};\\\", \\\"{x:1470,y:829,t:1526919300053};\\\", \\\"{x:1469,y:828,t:1526919300069};\\\", \\\"{x:1467,y:827,t:1526919300086};\\\", \\\"{x:1465,y:826,t:1526919300103};\\\", \\\"{x:1462,y:826,t:1526919300119};\\\", \\\"{x:1458,y:825,t:1526919300136};\\\", \\\"{x:1453,y:825,t:1526919300153};\\\", \\\"{x:1449,y:824,t:1526919300169};\\\", \\\"{x:1448,y:823,t:1526919300186};\\\", \\\"{x:1447,y:823,t:1526919300482};\\\", \\\"{x:1447,y:822,t:1526919300522};\\\", \\\"{x:1446,y:822,t:1526919300536};\\\", \\\"{x:1444,y:821,t:1526919300554};\\\", \\\"{x:1441,y:820,t:1526919300570};\\\", \\\"{x:1440,y:820,t:1526919300587};\\\", \\\"{x:1438,y:820,t:1526919300603};\\\", \\\"{x:1436,y:819,t:1526919300620};\\\", \\\"{x:1436,y:818,t:1526919300827};\\\", \\\"{x:1434,y:818,t:1526919300898};\\\", \\\"{x:1433,y:818,t:1526919300922};\\\", \\\"{x:1431,y:819,t:1526919300937};\\\", \\\"{x:1431,y:826,t:1526919300954};\\\", \\\"{x:1424,y:852,t:1526919300971};\\\", \\\"{x:1423,y:876,t:1526919300987};\\\", \\\"{x:1422,y:905,t:1526919301003};\\\", \\\"{x:1422,y:923,t:1526919301020};\\\", \\\"{x:1422,y:932,t:1526919301037};\\\", \\\"{x:1422,y:936,t:1526919301053};\\\", \\\"{x:1422,y:937,t:1526919301071};\\\", \\\"{x:1422,y:939,t:1526919301098};\\\", \\\"{x:1422,y:940,t:1526919301122};\\\", \\\"{x:1421,y:940,t:1526919301154};\\\", \\\"{x:1420,y:940,t:1526919301170};\\\", \\\"{x:1417,y:939,t:1526919301187};\\\", \\\"{x:1412,y:936,t:1526919301203};\\\", \\\"{x:1408,y:934,t:1526919301221};\\\", \\\"{x:1404,y:931,t:1526919301237};\\\", \\\"{x:1396,y:927,t:1526919301253};\\\", \\\"{x:1390,y:923,t:1526919301270};\\\", \\\"{x:1379,y:917,t:1526919301288};\\\", \\\"{x:1366,y:912,t:1526919301303};\\\", \\\"{x:1352,y:906,t:1526919301321};\\\", \\\"{x:1332,y:902,t:1526919301337};\\\", \\\"{x:1306,y:893,t:1526919301354};\\\", \\\"{x:1289,y:887,t:1526919301370};\\\", \\\"{x:1270,y:881,t:1526919301387};\\\", \\\"{x:1249,y:877,t:1526919301404};\\\", \\\"{x:1233,y:875,t:1526919301420};\\\", \\\"{x:1219,y:874,t:1526919301437};\\\", \\\"{x:1209,y:871,t:1526919301454};\\\", \\\"{x:1204,y:870,t:1526919301470};\\\", \\\"{x:1197,y:870,t:1526919301487};\\\", \\\"{x:1191,y:867,t:1526919301504};\\\", \\\"{x:1186,y:866,t:1526919301520};\\\", \\\"{x:1182,y:864,t:1526919301537};\\\", \\\"{x:1181,y:863,t:1526919301554};\\\", \\\"{x:1181,y:861,t:1526919301570};\\\", \\\"{x:1181,y:860,t:1526919301587};\\\", \\\"{x:1181,y:858,t:1526919301604};\\\", \\\"{x:1181,y:857,t:1526919301626};\\\", \\\"{x:1181,y:855,t:1526919301637};\\\", \\\"{x:1195,y:848,t:1526919301654};\\\", \\\"{x:1215,y:840,t:1526919301670};\\\", \\\"{x:1232,y:834,t:1526919301687};\\\", \\\"{x:1241,y:832,t:1526919301705};\\\", \\\"{x:1249,y:829,t:1526919301720};\\\", \\\"{x:1250,y:829,t:1526919301738};\\\", \\\"{x:1250,y:830,t:1526919301803};\\\", \\\"{x:1249,y:830,t:1526919301810};\\\", \\\"{x:1244,y:832,t:1526919301821};\\\", \\\"{x:1236,y:832,t:1526919301837};\\\", \\\"{x:1227,y:832,t:1526919301854};\\\", \\\"{x:1215,y:830,t:1526919301871};\\\", \\\"{x:1208,y:826,t:1526919301888};\\\", \\\"{x:1199,y:819,t:1526919301905};\\\", \\\"{x:1196,y:814,t:1526919301922};\\\", \\\"{x:1194,y:810,t:1526919301938};\\\", \\\"{x:1193,y:802,t:1526919301954};\\\", \\\"{x:1193,y:797,t:1526919301970};\\\", \\\"{x:1193,y:793,t:1526919301987};\\\", \\\"{x:1192,y:790,t:1526919302005};\\\", \\\"{x:1192,y:786,t:1526919302022};\\\", \\\"{x:1191,y:782,t:1526919302038};\\\", \\\"{x:1189,y:777,t:1526919302055};\\\", \\\"{x:1188,y:775,t:1526919302072};\\\", \\\"{x:1185,y:773,t:1526919302088};\\\", \\\"{x:1182,y:770,t:1526919302105};\\\", \\\"{x:1178,y:767,t:1526919302121};\\\", \\\"{x:1175,y:766,t:1526919302138};\\\", \\\"{x:1166,y:763,t:1526919302155};\\\", \\\"{x:1160,y:763,t:1526919302171};\\\", \\\"{x:1158,y:763,t:1526919302188};\\\", \\\"{x:1158,y:762,t:1526919302227};\\\", \\\"{x:1159,y:762,t:1526919302394};\\\", \\\"{x:1159,y:761,t:1526919302404};\\\", \\\"{x:1160,y:761,t:1526919302490};\\\", \\\"{x:1161,y:761,t:1526919302530};\\\", \\\"{x:1162,y:761,t:1526919302554};\\\", \\\"{x:1163,y:761,t:1526919302578};\\\", \\\"{x:1164,y:761,t:1526919302594};\\\", \\\"{x:1165,y:761,t:1526919302609};\\\", \\\"{x:1166,y:761,t:1526919302634};\\\", \\\"{x:1167,y:761,t:1526919302650};\\\", \\\"{x:1168,y:762,t:1526919302666};\\\", \\\"{x:1169,y:763,t:1526919302698};\\\", \\\"{x:1171,y:763,t:1526919302706};\\\", \\\"{x:1171,y:764,t:1526919302722};\\\", \\\"{x:1172,y:764,t:1526919302834};\\\", \\\"{x:1173,y:764,t:1526919302875};\\\", \\\"{x:1174,y:765,t:1526919302890};\\\", \\\"{x:1174,y:766,t:1526919302906};\\\", \\\"{x:1174,y:767,t:1526919302946};\\\", \\\"{x:1175,y:767,t:1526919303090};\\\", \\\"{x:1176,y:767,t:1526919303106};\\\", \\\"{x:1178,y:767,t:1526919303122};\\\", \\\"{x:1178,y:766,t:1526919303155};\\\", \\\"{x:1179,y:765,t:1526919303258};\\\", \\\"{x:1179,y:763,t:1526919303283};\\\", \\\"{x:1180,y:763,t:1526919303306};\\\", \\\"{x:1181,y:762,t:1526919303321};\\\", \\\"{x:1181,y:761,t:1526919304067};\\\", \\\"{x:1181,y:760,t:1526919304082};\\\", \\\"{x:1181,y:759,t:1526919307058};\\\", \\\"{x:1181,y:761,t:1526919313283};\\\", \\\"{x:1181,y:764,t:1526919313298};\\\", \\\"{x:1181,y:771,t:1526919313315};\\\", \\\"{x:1182,y:776,t:1526919313330};\\\", \\\"{x:1184,y:786,t:1526919313347};\\\", \\\"{x:1185,y:795,t:1526919313364};\\\", \\\"{x:1187,y:804,t:1526919313380};\\\", \\\"{x:1190,y:814,t:1526919313398};\\\", \\\"{x:1193,y:823,t:1526919313414};\\\", \\\"{x:1194,y:831,t:1526919313431};\\\", \\\"{x:1194,y:835,t:1526919313447};\\\", \\\"{x:1194,y:839,t:1526919313464};\\\", \\\"{x:1195,y:844,t:1526919313481};\\\", \\\"{x:1195,y:847,t:1526919313498};\\\", \\\"{x:1195,y:851,t:1526919313514};\\\", \\\"{x:1195,y:857,t:1526919313531};\\\", \\\"{x:1195,y:865,t:1526919313548};\\\", \\\"{x:1194,y:873,t:1526919313565};\\\", \\\"{x:1192,y:882,t:1526919313581};\\\", \\\"{x:1191,y:888,t:1526919313598};\\\", \\\"{x:1188,y:895,t:1526919313614};\\\", \\\"{x:1187,y:902,t:1526919313630};\\\", \\\"{x:1185,y:906,t:1526919313648};\\\", \\\"{x:1184,y:909,t:1526919313665};\\\", \\\"{x:1184,y:910,t:1526919313681};\\\", \\\"{x:1183,y:912,t:1526919313698};\\\", \\\"{x:1183,y:914,t:1526919313715};\\\", \\\"{x:1182,y:915,t:1526919313731};\\\", \\\"{x:1181,y:916,t:1526919313747};\\\", \\\"{x:1181,y:917,t:1526919313765};\\\", \\\"{x:1181,y:916,t:1526919313875};\\\", \\\"{x:1181,y:913,t:1526919313883};\\\", \\\"{x:1181,y:909,t:1526919313897};\\\", \\\"{x:1181,y:905,t:1526919313915};\\\", \\\"{x:1181,y:900,t:1526919313931};\\\", \\\"{x:1181,y:898,t:1526919313948};\\\", \\\"{x:1182,y:897,t:1526919313965};\\\", \\\"{x:1182,y:896,t:1526919314052};\\\", \\\"{x:1182,y:895,t:1526919314188};\\\", \\\"{x:1182,y:894,t:1526919314268};\\\", \\\"{x:1182,y:893,t:1526919314291};\\\", \\\"{x:1183,y:892,t:1526919314299};\\\", \\\"{x:1184,y:892,t:1526919314451};\\\", \\\"{x:1185,y:892,t:1526919314466};\\\", \\\"{x:1185,y:894,t:1526919314482};\\\", \\\"{x:1185,y:896,t:1526919314498};\\\", \\\"{x:1186,y:903,t:1526919314514};\\\", \\\"{x:1186,y:910,t:1526919314531};\\\", \\\"{x:1186,y:917,t:1526919314548};\\\", \\\"{x:1186,y:923,t:1526919314564};\\\", \\\"{x:1186,y:929,t:1526919314581};\\\", \\\"{x:1186,y:934,t:1526919314598};\\\", \\\"{x:1188,y:939,t:1526919314615};\\\", \\\"{x:1188,y:944,t:1526919314631};\\\", \\\"{x:1188,y:946,t:1526919314649};\\\", \\\"{x:1188,y:949,t:1526919314666};\\\", \\\"{x:1188,y:951,t:1526919314681};\\\", \\\"{x:1188,y:952,t:1526919314698};\\\", \\\"{x:1188,y:954,t:1526919314715};\\\", \\\"{x:1188,y:955,t:1526919314755};\\\", \\\"{x:1188,y:957,t:1526919314771};\\\", \\\"{x:1188,y:958,t:1526919314843};\\\", \\\"{x:1188,y:959,t:1526919314851};\\\", \\\"{x:1188,y:960,t:1526919314865};\\\", \\\"{x:1187,y:964,t:1526919314882};\\\", \\\"{x:1185,y:966,t:1526919314898};\\\", \\\"{x:1184,y:968,t:1526919314916};\\\", \\\"{x:1183,y:969,t:1526919314931};\\\", \\\"{x:1181,y:971,t:1526919314949};\\\", \\\"{x:1180,y:971,t:1526919315147};\\\", \\\"{x:1180,y:969,t:1526919315165};\\\", \\\"{x:1180,y:967,t:1526919315183};\\\", \\\"{x:1180,y:965,t:1526919315198};\\\", \\\"{x:1179,y:964,t:1526919315216};\\\", \\\"{x:1181,y:964,t:1526919316460};\\\", \\\"{x:1185,y:964,t:1526919316467};\\\", \\\"{x:1199,y:964,t:1526919316483};\\\", \\\"{x:1215,y:964,t:1526919316500};\\\", \\\"{x:1229,y:964,t:1526919316517};\\\", \\\"{x:1236,y:965,t:1526919316534};\\\", \\\"{x:1238,y:965,t:1526919316550};\\\", \\\"{x:1239,y:965,t:1526919316566};\\\", \\\"{x:1240,y:966,t:1526919316716};\\\", \\\"{x:1241,y:966,t:1526919316876};\\\", \\\"{x:1242,y:966,t:1526919316883};\\\", \\\"{x:1246,y:965,t:1526919316900};\\\", \\\"{x:1248,y:965,t:1526919316917};\\\", \\\"{x:1252,y:965,t:1526919317100};\\\", \\\"{x:1266,y:965,t:1526919317116};\\\", \\\"{x:1289,y:965,t:1526919317133};\\\", \\\"{x:1314,y:965,t:1526919317151};\\\", \\\"{x:1338,y:965,t:1526919317166};\\\", \\\"{x:1355,y:964,t:1526919317183};\\\", \\\"{x:1361,y:964,t:1526919317200};\\\", \\\"{x:1362,y:964,t:1526919317216};\\\", \\\"{x:1362,y:965,t:1526919317290};\\\", \\\"{x:1361,y:966,t:1526919317300};\\\", \\\"{x:1359,y:969,t:1526919317318};\\\", \\\"{x:1357,y:970,t:1526919317333};\\\", \\\"{x:1353,y:972,t:1526919317350};\\\", \\\"{x:1349,y:974,t:1526919317367};\\\", \\\"{x:1346,y:975,t:1526919317383};\\\", \\\"{x:1343,y:975,t:1526919317401};\\\", \\\"{x:1340,y:975,t:1526919317417};\\\", \\\"{x:1333,y:973,t:1526919317434};\\\", \\\"{x:1330,y:969,t:1526919317450};\\\", \\\"{x:1330,y:968,t:1526919317467};\\\", \\\"{x:1329,y:967,t:1526919317491};\\\", \\\"{x:1329,y:966,t:1526919317501};\\\", \\\"{x:1329,y:965,t:1526919317517};\\\", \\\"{x:1327,y:964,t:1526919317534};\\\", \\\"{x:1326,y:964,t:1526919317588};\\\", \\\"{x:1324,y:964,t:1526919317601};\\\", \\\"{x:1321,y:963,t:1526919317618};\\\", \\\"{x:1315,y:961,t:1526919317634};\\\", \\\"{x:1313,y:961,t:1526919317650};\\\", \\\"{x:1312,y:961,t:1526919317667};\\\", \\\"{x:1312,y:960,t:1526919317715};\\\", \\\"{x:1311,y:960,t:1526919317755};\\\", \\\"{x:1312,y:960,t:1526919317955};\\\", \\\"{x:1313,y:961,t:1526919317971};\\\", \\\"{x:1314,y:961,t:1526919318067};\\\", \\\"{x:1315,y:961,t:1526919318123};\\\", \\\"{x:1316,y:961,t:1526919318171};\\\", \\\"{x:1317,y:962,t:1526919318203};\\\", \\\"{x:1318,y:962,t:1526919318307};\\\", \\\"{x:1320,y:962,t:1526919318466};\\\", \\\"{x:1322,y:962,t:1526919318474};\\\", \\\"{x:1325,y:961,t:1526919318484};\\\", \\\"{x:1331,y:960,t:1526919318501};\\\", \\\"{x:1342,y:960,t:1526919318518};\\\", \\\"{x:1353,y:959,t:1526919318534};\\\", \\\"{x:1366,y:959,t:1526919318551};\\\", \\\"{x:1378,y:959,t:1526919318568};\\\", \\\"{x:1389,y:959,t:1526919318584};\\\", \\\"{x:1396,y:959,t:1526919318601};\\\", \\\"{x:1400,y:960,t:1526919318618};\\\", \\\"{x:1402,y:962,t:1526919318642};\\\", \\\"{x:1402,y:964,t:1526919318651};\\\", \\\"{x:1402,y:966,t:1526919318669};\\\", \\\"{x:1402,y:967,t:1526919318684};\\\", \\\"{x:1402,y:969,t:1526919318702};\\\", \\\"{x:1402,y:970,t:1526919318718};\\\", \\\"{x:1402,y:971,t:1526919318779};\\\", \\\"{x:1400,y:971,t:1526919318819};\\\", \\\"{x:1396,y:971,t:1526919318835};\\\", \\\"{x:1386,y:971,t:1526919318852};\\\", \\\"{x:1367,y:969,t:1526919318869};\\\", \\\"{x:1336,y:966,t:1526919318885};\\\", \\\"{x:1303,y:961,t:1526919318902};\\\", \\\"{x:1275,y:954,t:1526919318919};\\\", \\\"{x:1249,y:948,t:1526919318935};\\\", \\\"{x:1225,y:940,t:1526919318952};\\\", \\\"{x:1197,y:934,t:1526919318969};\\\", \\\"{x:1162,y:925,t:1526919318984};\\\", \\\"{x:1115,y:912,t:1526919319002};\\\", \\\"{x:1058,y:904,t:1526919319019};\\\", \\\"{x:1027,y:897,t:1526919319035};\\\", \\\"{x:1001,y:892,t:1526919319051};\\\", \\\"{x:988,y:888,t:1526919319069};\\\", \\\"{x:983,y:887,t:1526919319086};\\\", \\\"{x:984,y:888,t:1526919319139};\\\", \\\"{x:988,y:890,t:1526919319152};\\\", \\\"{x:996,y:892,t:1526919319168};\\\", \\\"{x:997,y:892,t:1526919319186};\\\", \\\"{x:998,y:891,t:1526919319500};\\\", \\\"{x:998,y:890,t:1526919319539};\\\", \\\"{x:997,y:889,t:1526919319553};\\\", \\\"{x:994,y:889,t:1526919319569};\\\", \\\"{x:992,y:889,t:1526919319585};\\\", \\\"{x:988,y:888,t:1526919319602};\\\", \\\"{x:986,y:887,t:1526919319619};\\\", \\\"{x:986,y:886,t:1526919319636};\\\", \\\"{x:984,y:885,t:1526919319653};\\\", \\\"{x:982,y:885,t:1526919319675};\\\", \\\"{x:980,y:883,t:1526919319686};\\\", \\\"{x:978,y:882,t:1526919319707};\\\", \\\"{x:977,y:882,t:1526919319719};\\\", \\\"{x:973,y:881,t:1526919319736};\\\", \\\"{x:969,y:880,t:1526919319752};\\\", \\\"{x:966,y:879,t:1526919319769};\\\", \\\"{x:965,y:878,t:1526919319786};\\\", \\\"{x:963,y:878,t:1526919319802};\\\", \\\"{x:962,y:878,t:1526919319818};\\\", \\\"{x:962,y:877,t:1526919319835};\\\", \\\"{x:961,y:877,t:1526919319853};\\\", \\\"{x:959,y:877,t:1526919319869};\\\", \\\"{x:958,y:877,t:1526919319885};\\\", \\\"{x:956,y:876,t:1526919319931};\\\", \\\"{x:955,y:875,t:1526919320027};\\\", \\\"{x:954,y:875,t:1526919320036};\\\", \\\"{x:953,y:875,t:1526919320082};\\\", \\\"{x:953,y:874,t:1526919320105};\\\", \\\"{x:952,y:874,t:1526919320122};\\\", \\\"{x:951,y:874,t:1526919320153};\\\", \\\"{x:949,y:874,t:1526919320169};\\\", \\\"{x:944,y:874,t:1526919320185};\\\", \\\"{x:939,y:874,t:1526919320201};\\\", \\\"{x:937,y:873,t:1526919320219};\\\", \\\"{x:936,y:873,t:1526919320235};\\\", \\\"{x:935,y:873,t:1526919320251};\\\", \\\"{x:934,y:872,t:1526919320269};\\\", \\\"{x:933,y:872,t:1526919320298};\\\", \\\"{x:932,y:871,t:1526919320330};\\\", \\\"{x:931,y:870,t:1526919320354};\\\", \\\"{x:931,y:869,t:1526919320370};\\\", \\\"{x:929,y:867,t:1526919320386};\\\", \\\"{x:923,y:866,t:1526919320402};\\\", \\\"{x:909,y:865,t:1526919320419};\\\", \\\"{x:893,y:865,t:1526919320436};\\\", \\\"{x:870,y:865,t:1526919320452};\\\", \\\"{x:849,y:862,t:1526919320469};\\\", \\\"{x:830,y:860,t:1526919320487};\\\", \\\"{x:802,y:856,t:1526919320502};\\\", \\\"{x:757,y:849,t:1526919320519};\\\", \\\"{x:714,y:842,t:1526919320536};\\\", \\\"{x:682,y:836,t:1526919320552};\\\", \\\"{x:649,y:827,t:1526919320569};\\\", \\\"{x:612,y:812,t:1526919320586};\\\", \\\"{x:590,y:804,t:1526919320603};\\\", \\\"{x:577,y:801,t:1526919320619};\\\", \\\"{x:573,y:799,t:1526919320636};\\\", \\\"{x:573,y:797,t:1526919320707};\\\", \\\"{x:572,y:796,t:1526919320723};\\\", \\\"{x:572,y:795,t:1526919320737};\\\", \\\"{x:571,y:794,t:1526919320947};\\\", \\\"{x:566,y:793,t:1526919320954};\\\", \\\"{x:563,y:793,t:1526919320969};\\\", \\\"{x:531,y:785,t:1526919320986};\\\", \\\"{x:500,y:771,t:1526919321003};\\\", \\\"{x:469,y:755,t:1526919321019};\\\", \\\"{x:404,y:723,t:1526919321036};\\\", \\\"{x:359,y:701,t:1526919321053};\\\", \\\"{x:324,y:682,t:1526919321069};\\\", \\\"{x:304,y:666,t:1526919321088};\\\", \\\"{x:284,y:653,t:1526919321103};\\\", \\\"{x:273,y:642,t:1526919321119};\\\", \\\"{x:266,y:626,t:1526919321136};\\\", \\\"{x:256,y:609,t:1526919321153};\\\", \\\"{x:242,y:588,t:1526919321170};\\\", \\\"{x:225,y:559,t:1526919321186};\\\", \\\"{x:216,y:547,t:1526919321204};\\\", \\\"{x:213,y:534,t:1526919321220};\\\", \\\"{x:210,y:524,t:1526919321236};\\\", \\\"{x:210,y:517,t:1526919321253};\\\", \\\"{x:210,y:511,t:1526919321270};\\\", \\\"{x:210,y:506,t:1526919321286};\\\", \\\"{x:211,y:504,t:1526919321303};\\\", \\\"{x:211,y:503,t:1526919321320};\\\", \\\"{x:211,y:502,t:1526919321346};\\\", \\\"{x:209,y:502,t:1526919321354};\\\", \\\"{x:203,y:501,t:1526919321370};\\\", \\\"{x:196,y:500,t:1526919321386};\\\", \\\"{x:188,y:497,t:1526919321403};\\\", \\\"{x:179,y:497,t:1526919321421};\\\", \\\"{x:168,y:497,t:1526919321436};\\\", \\\"{x:161,y:497,t:1526919321453};\\\", \\\"{x:152,y:499,t:1526919321471};\\\", \\\"{x:148,y:499,t:1526919321487};\\\", \\\"{x:144,y:499,t:1526919321503};\\\", \\\"{x:142,y:499,t:1526919321545};\\\", \\\"{x:145,y:499,t:1526919321772};\\\", \\\"{x:153,y:500,t:1526919321789};\\\", \\\"{x:169,y:504,t:1526919321803};\\\", \\\"{x:190,y:510,t:1526919321821};\\\", \\\"{x:213,y:522,t:1526919321838};\\\", \\\"{x:235,y:537,t:1526919321853};\\\", \\\"{x:259,y:556,t:1526919321870};\\\", \\\"{x:293,y:583,t:1526919321888};\\\", \\\"{x:329,y:617,t:1526919321903};\\\", \\\"{x:365,y:644,t:1526919321920};\\\", \\\"{x:389,y:662,t:1526919321938};\\\", \\\"{x:421,y:686,t:1526919321954};\\\", \\\"{x:435,y:699,t:1526919321970};\\\", \\\"{x:446,y:708,t:1526919321987};\\\", \\\"{x:453,y:716,t:1526919322003};\\\", \\\"{x:455,y:718,t:1526919322020};\\\", \\\"{x:454,y:718,t:1526919322066};\\\", \\\"{x:453,y:718,t:1526919322074};\\\", \\\"{x:450,y:717,t:1526919322088};\\\", \\\"{x:430,y:707,t:1526919322103};\\\", \\\"{x:392,y:682,t:1526919322121};\\\", \\\"{x:326,y:640,t:1526919322138};\\\", \\\"{x:223,y:588,t:1526919322154};\\\", \\\"{x:77,y:517,t:1526919322172};\\\", \\\"{x:17,y:493,t:1526919322188};\\\", \\\"{x:0,y:480,t:1526919322205};\\\", \\\"{x:0,y:472,t:1526919322220};\\\", \\\"{x:0,y:469,t:1526919322237};\\\", \\\"{x:0,y:468,t:1526919322316};\\\", \\\"{x:3,y:467,t:1526919322323};\\\", \\\"{x:15,y:466,t:1526919322338};\\\", \\\"{x:36,y:466,t:1526919322354};\\\", \\\"{x:66,y:466,t:1526919322372};\\\", \\\"{x:94,y:472,t:1526919322389};\\\", \\\"{x:119,y:481,t:1526919322405};\\\", \\\"{x:134,y:492,t:1526919322422};\\\", \\\"{x:142,y:501,t:1526919322439};\\\", \\\"{x:145,y:506,t:1526919322454};\\\", \\\"{x:146,y:510,t:1526919322471};\\\", \\\"{x:147,y:511,t:1526919322487};\\\", \\\"{x:147,y:512,t:1526919322506};\\\", \\\"{x:147,y:513,t:1526919322538};\\\", \\\"{x:147,y:512,t:1526919322658};\\\", \\\"{x:148,y:510,t:1526919322674};\\\", \\\"{x:151,y:507,t:1526919322691};\\\", \\\"{x:153,y:507,t:1526919322708};\\\", \\\"{x:154,y:507,t:1526919322721};\\\", \\\"{x:155,y:506,t:1526919322738};\\\", \\\"{x:156,y:505,t:1526919322842};\\\", \\\"{x:156,y:504,t:1526919322854};\\\", \\\"{x:158,y:504,t:1526919322871};\\\", \\\"{x:159,y:503,t:1526919322888};\\\", \\\"{x:160,y:503,t:1526919323027};\\\", \\\"{x:160,y:503,t:1526919323105};\\\", \\\"{x:161,y:503,t:1526919323307};\\\", \\\"{x:165,y:503,t:1526919323321};\\\", \\\"{x:176,y:505,t:1526919323339};\\\", \\\"{x:189,y:507,t:1526919323355};\\\", \\\"{x:211,y:508,t:1526919323371};\\\", \\\"{x:231,y:511,t:1526919323388};\\\", \\\"{x:254,y:514,t:1526919323405};\\\", \\\"{x:276,y:519,t:1526919323421};\\\", \\\"{x:300,y:528,t:1526919323439};\\\", \\\"{x:325,y:539,t:1526919323455};\\\", \\\"{x:353,y:550,t:1526919323471};\\\", \\\"{x:379,y:563,t:1526919323489};\\\", \\\"{x:402,y:581,t:1526919323506};\\\", \\\"{x:421,y:598,t:1526919323522};\\\", \\\"{x:454,y:625,t:1526919323538};\\\", \\\"{x:471,y:645,t:1526919323556};\\\", \\\"{x:482,y:665,t:1526919323571};\\\", \\\"{x:493,y:684,t:1526919323588};\\\", \\\"{x:505,y:700,t:1526919323605};\\\", \\\"{x:509,y:713,t:1526919323623};\\\", \\\"{x:513,y:725,t:1526919323639};\\\", \\\"{x:516,y:738,t:1526919323656};\\\", \\\"{x:519,y:748,t:1526919323673};\\\", \\\"{x:523,y:757,t:1526919323689};\\\", \\\"{x:525,y:762,t:1526919323705};\\\", \\\"{x:526,y:770,t:1526919323722};\\\", \\\"{x:527,y:774,t:1526919323738};\\\", \\\"{x:527,y:780,t:1526919323755};\\\", \\\"{x:527,y:781,t:1526919323771};\\\", \\\"{x:527,y:783,t:1526919323788};\\\", \\\"{x:527,y:784,t:1526919323859};\\\", \\\"{x:526,y:784,t:1526919323872};\\\", \\\"{x:522,y:781,t:1526919323888};\\\", \\\"{x:517,y:774,t:1526919323905};\\\", \\\"{x:509,y:764,t:1526919323923};\\\", \\\"{x:505,y:759,t:1526919323938};\\\", \\\"{x:502,y:754,t:1526919323956};\\\", \\\"{x:501,y:751,t:1526919323972};\\\", \\\"{x:501,y:750,t:1526919323988};\\\", \\\"{x:501,y:749,t:1526919324005};\\\", \\\"{x:501,y:747,t:1526919324022};\\\", \\\"{x:500,y:745,t:1526919324039};\\\", \\\"{x:500,y:744,t:1526919324055};\\\", \\\"{x:500,y:742,t:1526919324073};\\\", \\\"{x:499,y:742,t:1526919325195};\\\" ] }, { \\\"rt\\\": 62335, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 767810, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B -12 PM-F -F -F -F -B -01 PM-01 PM-03 PM-02 PM-12 PM-X -X -O -M -B -01 PM-M -C -C -11 AM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:742,t:1526919326097};\\\", \\\"{x:497,y:742,t:1526919326130};\\\", \\\"{x:496,y:742,t:1526919326140};\\\", \\\"{x:495,y:742,t:1526919326235};\\\", \\\"{x:496,y:742,t:1526919326330};\\\", \\\"{x:498,y:742,t:1526919326340};\\\", \\\"{x:499,y:742,t:1526919326357};\\\", \\\"{x:500,y:746,t:1526919326374};\\\", \\\"{x:500,y:748,t:1526919326391};\\\", \\\"{x:501,y:748,t:1526919327283};\\\", \\\"{x:505,y:749,t:1526919327291};\\\", \\\"{x:507,y:749,t:1526919327308};\\\", \\\"{x:509,y:749,t:1526919327325};\\\", \\\"{x:519,y:752,t:1526919327342};\\\", \\\"{x:540,y:754,t:1526919327358};\\\", \\\"{x:568,y:759,t:1526919327376};\\\", \\\"{x:596,y:760,t:1526919327391};\\\", \\\"{x:621,y:761,t:1526919327407};\\\", \\\"{x:642,y:761,t:1526919327424};\\\", \\\"{x:661,y:761,t:1526919327441};\\\", \\\"{x:690,y:763,t:1526919327458};\\\", \\\"{x:710,y:764,t:1526919327474};\\\", \\\"{x:727,y:764,t:1526919327491};\\\", \\\"{x:752,y:764,t:1526919327508};\\\", \\\"{x:779,y:766,t:1526919327524};\\\", \\\"{x:814,y:769,t:1526919327541};\\\", \\\"{x:858,y:769,t:1526919327558};\\\", \\\"{x:907,y:771,t:1526919327575};\\\", \\\"{x:962,y:771,t:1526919327591};\\\", \\\"{x:1026,y:771,t:1526919327609};\\\", \\\"{x:1080,y:770,t:1526919327626};\\\", \\\"{x:1148,y:765,t:1526919327641};\\\", \\\"{x:1253,y:749,t:1526919327659};\\\", \\\"{x:1334,y:738,t:1526919327675};\\\", \\\"{x:1389,y:732,t:1526919327691};\\\", \\\"{x:1445,y:724,t:1526919327709};\\\", \\\"{x:1473,y:719,t:1526919327726};\\\", \\\"{x:1493,y:715,t:1526919327742};\\\", \\\"{x:1506,y:712,t:1526919327759};\\\", \\\"{x:1514,y:708,t:1526919327776};\\\", \\\"{x:1519,y:704,t:1526919327792};\\\", \\\"{x:1524,y:700,t:1526919327809};\\\", \\\"{x:1530,y:697,t:1526919327826};\\\", \\\"{x:1531,y:696,t:1526919327842};\\\", \\\"{x:1529,y:697,t:1526919328116};\\\", \\\"{x:1527,y:699,t:1526919328126};\\\", \\\"{x:1523,y:700,t:1526919328143};\\\", \\\"{x:1520,y:701,t:1526919328159};\\\", \\\"{x:1519,y:701,t:1526919328187};\\\", \\\"{x:1519,y:702,t:1526919328195};\\\", \\\"{x:1518,y:702,t:1526919328267};\\\", \\\"{x:1516,y:704,t:1526919328277};\\\", \\\"{x:1512,y:707,t:1526919328293};\\\", \\\"{x:1506,y:711,t:1526919328309};\\\", \\\"{x:1503,y:714,t:1526919328326};\\\", \\\"{x:1497,y:717,t:1526919328343};\\\", \\\"{x:1490,y:720,t:1526919328360};\\\", \\\"{x:1478,y:722,t:1526919328376};\\\", \\\"{x:1466,y:725,t:1526919328393};\\\", \\\"{x:1455,y:726,t:1526919328410};\\\", \\\"{x:1441,y:726,t:1526919328427};\\\", \\\"{x:1423,y:726,t:1526919328443};\\\", \\\"{x:1404,y:725,t:1526919328460};\\\", \\\"{x:1381,y:718,t:1526919328476};\\\", \\\"{x:1356,y:711,t:1526919328493};\\\", \\\"{x:1329,y:704,t:1526919328510};\\\", \\\"{x:1302,y:696,t:1526919328527};\\\", \\\"{x:1287,y:694,t:1526919328543};\\\", \\\"{x:1284,y:693,t:1526919328560};\\\", \\\"{x:1285,y:693,t:1526919328628};\\\", \\\"{x:1286,y:693,t:1526919328643};\\\", \\\"{x:1288,y:693,t:1526919328667};\\\", \\\"{x:1289,y:693,t:1526919328676};\\\", \\\"{x:1290,y:693,t:1526919328699};\\\", \\\"{x:1293,y:694,t:1526919328710};\\\", \\\"{x:1296,y:694,t:1526919328726};\\\", \\\"{x:1303,y:694,t:1526919328744};\\\", \\\"{x:1314,y:693,t:1526919328760};\\\", \\\"{x:1327,y:690,t:1526919328776};\\\", \\\"{x:1344,y:689,t:1526919328794};\\\", \\\"{x:1362,y:689,t:1526919328811};\\\", \\\"{x:1371,y:689,t:1526919328826};\\\", \\\"{x:1372,y:689,t:1526919328843};\\\", \\\"{x:1373,y:690,t:1526919328860};\\\", \\\"{x:1375,y:691,t:1526919328877};\\\", \\\"{x:1376,y:693,t:1526919328893};\\\", \\\"{x:1378,y:694,t:1526919328911};\\\", \\\"{x:1379,y:695,t:1526919328955};\\\", \\\"{x:1379,y:696,t:1526919329012};\\\", \\\"{x:1379,y:697,t:1526919329027};\\\", \\\"{x:1375,y:698,t:1526919329043};\\\", \\\"{x:1373,y:699,t:1526919329060};\\\", \\\"{x:1371,y:699,t:1526919329077};\\\", \\\"{x:1368,y:699,t:1526919329093};\\\", \\\"{x:1365,y:700,t:1526919329110};\\\", \\\"{x:1364,y:701,t:1526919329138};\\\", \\\"{x:1363,y:701,t:1526919329163};\\\", \\\"{x:1362,y:703,t:1526919329187};\\\", \\\"{x:1361,y:703,t:1526919329308};\\\", \\\"{x:1360,y:703,t:1526919329323};\\\", \\\"{x:1359,y:703,t:1526919329338};\\\", \\\"{x:1358,y:703,t:1526919329371};\\\", \\\"{x:1356,y:703,t:1526919329386};\\\", \\\"{x:1355,y:702,t:1526919329402};\\\", \\\"{x:1354,y:702,t:1526919329443};\\\", \\\"{x:1353,y:701,t:1526919329460};\\\", \\\"{x:1352,y:701,t:1526919329476};\\\", \\\"{x:1351,y:701,t:1526919329531};\\\", \\\"{x:1350,y:700,t:1526919329634};\\\", \\\"{x:1349,y:700,t:1526919329955};\\\", \\\"{x:1348,y:700,t:1526919330059};\\\", \\\"{x:1347,y:699,t:1526919330083};\\\", \\\"{x:1346,y:699,t:1526919330131};\\\", \\\"{x:1346,y:700,t:1526919330347};\\\", \\\"{x:1346,y:704,t:1526919330362};\\\", \\\"{x:1346,y:711,t:1526919330378};\\\", \\\"{x:1346,y:719,t:1526919330395};\\\", \\\"{x:1346,y:725,t:1526919330411};\\\", \\\"{x:1346,y:728,t:1526919330428};\\\", \\\"{x:1348,y:730,t:1526919330446};\\\", \\\"{x:1348,y:734,t:1526919330461};\\\", \\\"{x:1348,y:739,t:1526919330478};\\\", \\\"{x:1350,y:746,t:1526919330495};\\\", \\\"{x:1350,y:751,t:1526919330511};\\\", \\\"{x:1352,y:757,t:1526919330528};\\\", \\\"{x:1352,y:766,t:1526919330545};\\\", \\\"{x:1355,y:780,t:1526919330562};\\\", \\\"{x:1357,y:795,t:1526919330578};\\\", \\\"{x:1362,y:813,t:1526919330595};\\\", \\\"{x:1362,y:822,t:1526919330611};\\\", \\\"{x:1365,y:826,t:1526919330628};\\\", \\\"{x:1365,y:830,t:1526919330646};\\\", \\\"{x:1365,y:834,t:1526919330661};\\\", \\\"{x:1365,y:839,t:1526919330678};\\\", \\\"{x:1365,y:845,t:1526919330695};\\\", \\\"{x:1366,y:852,t:1526919330711};\\\", \\\"{x:1366,y:857,t:1526919330728};\\\", \\\"{x:1366,y:863,t:1526919330745};\\\", \\\"{x:1366,y:872,t:1526919330761};\\\", \\\"{x:1368,y:883,t:1526919330778};\\\", \\\"{x:1368,y:894,t:1526919330795};\\\", \\\"{x:1368,y:898,t:1526919330812};\\\", \\\"{x:1368,y:902,t:1526919330828};\\\", \\\"{x:1368,y:907,t:1526919330845};\\\", \\\"{x:1368,y:913,t:1526919330862};\\\", \\\"{x:1368,y:917,t:1526919330878};\\\", \\\"{x:1368,y:923,t:1526919330895};\\\", \\\"{x:1368,y:928,t:1526919330912};\\\", \\\"{x:1367,y:932,t:1526919330928};\\\", \\\"{x:1366,y:937,t:1526919330945};\\\", \\\"{x:1365,y:942,t:1526919330962};\\\", \\\"{x:1365,y:946,t:1526919330978};\\\", \\\"{x:1364,y:951,t:1526919330995};\\\", \\\"{x:1363,y:954,t:1526919331012};\\\", \\\"{x:1362,y:958,t:1526919331028};\\\", \\\"{x:1361,y:961,t:1526919331045};\\\", \\\"{x:1360,y:963,t:1526919331062};\\\", \\\"{x:1360,y:965,t:1526919331078};\\\", \\\"{x:1358,y:967,t:1526919331095};\\\", \\\"{x:1358,y:970,t:1526919331113};\\\", \\\"{x:1357,y:971,t:1526919331128};\\\", \\\"{x:1356,y:972,t:1526919331145};\\\", \\\"{x:1355,y:973,t:1526919331163};\\\", \\\"{x:1354,y:973,t:1526919331187};\\\", \\\"{x:1354,y:974,t:1526919331275};\\\", \\\"{x:1353,y:974,t:1526919331307};\\\", \\\"{x:1352,y:973,t:1526919331371};\\\", \\\"{x:1351,y:973,t:1526919331451};\\\", \\\"{x:1351,y:972,t:1526919331462};\\\", \\\"{x:1351,y:969,t:1526919331479};\\\", \\\"{x:1351,y:968,t:1526919331496};\\\", \\\"{x:1350,y:965,t:1526919331512};\\\", \\\"{x:1350,y:964,t:1526919331530};\\\", \\\"{x:1349,y:962,t:1526919331546};\\\", \\\"{x:1349,y:961,t:1526919336547};\\\", \\\"{x:1349,y:959,t:1526919336555};\\\", \\\"{x:1349,y:953,t:1526919336567};\\\", \\\"{x:1348,y:939,t:1526919336584};\\\", \\\"{x:1346,y:921,t:1526919336601};\\\", \\\"{x:1343,y:902,t:1526919336616};\\\", \\\"{x:1343,y:885,t:1526919336634};\\\", \\\"{x:1343,y:867,t:1526919336651};\\\", \\\"{x:1343,y:858,t:1526919336666};\\\", \\\"{x:1342,y:845,t:1526919336683};\\\", \\\"{x:1341,y:834,t:1526919336701};\\\", \\\"{x:1341,y:822,t:1526919336716};\\\", \\\"{x:1338,y:815,t:1526919336733};\\\", \\\"{x:1338,y:807,t:1526919336750};\\\", \\\"{x:1336,y:800,t:1526919336767};\\\", \\\"{x:1336,y:793,t:1526919336783};\\\", \\\"{x:1336,y:784,t:1526919336801};\\\", \\\"{x:1336,y:775,t:1526919336816};\\\", \\\"{x:1336,y:768,t:1526919336833};\\\", \\\"{x:1336,y:759,t:1526919336850};\\\", \\\"{x:1338,y:750,t:1526919336867};\\\", \\\"{x:1340,y:739,t:1526919336883};\\\", \\\"{x:1344,y:728,t:1526919336901};\\\", \\\"{x:1348,y:717,t:1526919336917};\\\", \\\"{x:1351,y:707,t:1526919336934};\\\", \\\"{x:1353,y:694,t:1526919336951};\\\", \\\"{x:1354,y:687,t:1526919336969};\\\", \\\"{x:1355,y:682,t:1526919336983};\\\", \\\"{x:1356,y:680,t:1526919337000};\\\", \\\"{x:1356,y:679,t:1526919337017};\\\", \\\"{x:1356,y:677,t:1526919337034};\\\", \\\"{x:1358,y:674,t:1526919337051};\\\", \\\"{x:1358,y:673,t:1526919337067};\\\", \\\"{x:1358,y:672,t:1526919337139};\\\", \\\"{x:1358,y:675,t:1526919337163};\\\", \\\"{x:1358,y:678,t:1526919337171};\\\", \\\"{x:1358,y:681,t:1526919337184};\\\", \\\"{x:1358,y:692,t:1526919337200};\\\", \\\"{x:1358,y:701,t:1526919337217};\\\", \\\"{x:1357,y:707,t:1526919337233};\\\", \\\"{x:1356,y:710,t:1526919337250};\\\", \\\"{x:1356,y:711,t:1526919337266};\\\", \\\"{x:1355,y:712,t:1526919337284};\\\", \\\"{x:1355,y:711,t:1526919337546};\\\", \\\"{x:1355,y:709,t:1526919337562};\\\", \\\"{x:1355,y:708,t:1526919337586};\\\", \\\"{x:1355,y:707,t:1526919337602};\\\", \\\"{x:1355,y:706,t:1526919337617};\\\", \\\"{x:1355,y:705,t:1526919337634};\\\", \\\"{x:1355,y:703,t:1526919337650};\\\", \\\"{x:1355,y:702,t:1526919337763};\\\", \\\"{x:1353,y:700,t:1526919338107};\\\", \\\"{x:1353,y:698,t:1526919338123};\\\", \\\"{x:1351,y:695,t:1526919338134};\\\", \\\"{x:1349,y:692,t:1526919338152};\\\", \\\"{x:1348,y:691,t:1526919338171};\\\", \\\"{x:1348,y:692,t:1526919338500};\\\", \\\"{x:1348,y:694,t:1526919338531};\\\", \\\"{x:1348,y:695,t:1526919339259};\\\", \\\"{x:1348,y:700,t:1526919340623};\\\", \\\"{x:1348,y:719,t:1526919340641};\\\", \\\"{x:1348,y:760,t:1526919340657};\\\", \\\"{x:1353,y:810,t:1526919340675};\\\", \\\"{x:1369,y:865,t:1526919340690};\\\", \\\"{x:1391,y:935,t:1526919340707};\\\", \\\"{x:1404,y:983,t:1526919340724};\\\", \\\"{x:1414,y:1009,t:1526919340746};\\\", \\\"{x:1415,y:1014,t:1526919340757};\\\", \\\"{x:1419,y:1027,t:1526919340773};\\\", \\\"{x:1420,y:1032,t:1526919340789};\\\", \\\"{x:1420,y:1033,t:1526919340806};\\\", \\\"{x:1420,y:1031,t:1526919340894};\\\", \\\"{x:1420,y:1029,t:1526919340906};\\\", \\\"{x:1422,y:1023,t:1526919340924};\\\", \\\"{x:1422,y:1019,t:1526919340940};\\\", \\\"{x:1422,y:1014,t:1526919340957};\\\", \\\"{x:1422,y:1009,t:1526919340973};\\\", \\\"{x:1422,y:1005,t:1526919340990};\\\", \\\"{x:1422,y:1001,t:1526919341007};\\\", \\\"{x:1422,y:998,t:1526919341023};\\\", \\\"{x:1422,y:995,t:1526919341041};\\\", \\\"{x:1423,y:994,t:1526919341057};\\\", \\\"{x:1423,y:991,t:1526919341073};\\\", \\\"{x:1423,y:989,t:1526919341091};\\\", \\\"{x:1423,y:987,t:1526919341106};\\\", \\\"{x:1423,y:985,t:1526919341124};\\\", \\\"{x:1423,y:984,t:1526919341142};\\\", \\\"{x:1423,y:982,t:1526919341156};\\\", \\\"{x:1425,y:980,t:1526919341262};\\\", \\\"{x:1427,y:978,t:1526919341274};\\\", \\\"{x:1432,y:974,t:1526919341291};\\\", \\\"{x:1441,y:972,t:1526919341307};\\\", \\\"{x:1453,y:968,t:1526919341324};\\\", \\\"{x:1463,y:967,t:1526919341340};\\\", \\\"{x:1476,y:965,t:1526919341356};\\\", \\\"{x:1494,y:965,t:1526919341373};\\\", \\\"{x:1502,y:965,t:1526919341391};\\\", \\\"{x:1507,y:965,t:1526919341407};\\\", \\\"{x:1509,y:965,t:1526919341424};\\\", \\\"{x:1510,y:965,t:1526919341441};\\\", \\\"{x:1511,y:965,t:1526919341525};\\\", \\\"{x:1512,y:965,t:1526919341574};\\\", \\\"{x:1514,y:965,t:1526919341694};\\\", \\\"{x:1516,y:965,t:1526919341709};\\\", \\\"{x:1525,y:965,t:1526919341724};\\\", \\\"{x:1534,y:965,t:1526919341740};\\\", \\\"{x:1545,y:965,t:1526919341758};\\\", \\\"{x:1547,y:965,t:1526919341775};\\\", \\\"{x:1548,y:965,t:1526919341814};\\\", \\\"{x:1550,y:965,t:1526919341830};\\\", \\\"{x:1551,y:965,t:1526919341841};\\\", \\\"{x:1556,y:965,t:1526919341857};\\\", \\\"{x:1560,y:965,t:1526919341875};\\\", \\\"{x:1561,y:965,t:1526919341891};\\\", \\\"{x:1563,y:965,t:1526919341908};\\\", \\\"{x:1564,y:965,t:1526919342038};\\\", \\\"{x:1568,y:965,t:1526919342046};\\\", \\\"{x:1573,y:965,t:1526919342057};\\\", \\\"{x:1586,y:965,t:1526919342074};\\\", \\\"{x:1602,y:965,t:1526919342090};\\\", \\\"{x:1611,y:965,t:1526919342108};\\\", \\\"{x:1618,y:965,t:1526919342125};\\\", \\\"{x:1607,y:966,t:1526919347350};\\\", \\\"{x:1594,y:967,t:1526919347362};\\\", \\\"{x:1574,y:969,t:1526919347379};\\\", \\\"{x:1555,y:969,t:1526919347396};\\\", \\\"{x:1545,y:969,t:1526919347412};\\\", \\\"{x:1543,y:969,t:1526919347428};\\\", \\\"{x:1542,y:969,t:1526919347469};\\\", \\\"{x:1540,y:970,t:1526919347479};\\\", \\\"{x:1535,y:970,t:1526919347495};\\\", \\\"{x:1530,y:971,t:1526919347513};\\\", \\\"{x:1525,y:971,t:1526919347529};\\\", \\\"{x:1523,y:971,t:1526919347546};\\\", \\\"{x:1519,y:973,t:1526919347562};\\\", \\\"{x:1517,y:973,t:1526919347579};\\\", \\\"{x:1513,y:975,t:1526919347596};\\\", \\\"{x:1510,y:976,t:1526919347613};\\\", \\\"{x:1506,y:978,t:1526919347629};\\\", \\\"{x:1498,y:982,t:1526919347646};\\\", \\\"{x:1491,y:986,t:1526919347663};\\\", \\\"{x:1484,y:990,t:1526919347679};\\\", \\\"{x:1475,y:994,t:1526919347696};\\\", \\\"{x:1465,y:998,t:1526919347712};\\\", \\\"{x:1462,y:999,t:1526919347729};\\\", \\\"{x:1454,y:1000,t:1526919347746};\\\", \\\"{x:1442,y:1002,t:1526919347763};\\\", \\\"{x:1431,y:1002,t:1526919347779};\\\", \\\"{x:1419,y:1002,t:1526919347796};\\\", \\\"{x:1411,y:1002,t:1526919347813};\\\", \\\"{x:1401,y:997,t:1526919347829};\\\", \\\"{x:1390,y:988,t:1526919347846};\\\", \\\"{x:1385,y:982,t:1526919347863};\\\", \\\"{x:1378,y:973,t:1526919347879};\\\", \\\"{x:1371,y:965,t:1526919347896};\\\", \\\"{x:1365,y:960,t:1526919347914};\\\", \\\"{x:1361,y:956,t:1526919347931};\\\", \\\"{x:1357,y:953,t:1526919347946};\\\", \\\"{x:1351,y:950,t:1526919347963};\\\", \\\"{x:1346,y:949,t:1526919347980};\\\", \\\"{x:1338,y:946,t:1526919347996};\\\", \\\"{x:1332,y:946,t:1526919348013};\\\", \\\"{x:1330,y:946,t:1526919348030};\\\", \\\"{x:1329,y:946,t:1526919348046};\\\", \\\"{x:1328,y:946,t:1526919348063};\\\", \\\"{x:1327,y:946,t:1526919348110};\\\", \\\"{x:1329,y:948,t:1526919348358};\\\", \\\"{x:1329,y:949,t:1526919348366};\\\", \\\"{x:1332,y:951,t:1526919348379};\\\", \\\"{x:1336,y:956,t:1526919348397};\\\", \\\"{x:1344,y:962,t:1526919348413};\\\", \\\"{x:1352,y:969,t:1526919348429};\\\", \\\"{x:1356,y:971,t:1526919348447};\\\", \\\"{x:1357,y:973,t:1526919348463};\\\", \\\"{x:1359,y:973,t:1526919348479};\\\", \\\"{x:1361,y:974,t:1526919348496};\\\", \\\"{x:1362,y:974,t:1526919348525};\\\", \\\"{x:1364,y:974,t:1526919348533};\\\", \\\"{x:1366,y:974,t:1526919348547};\\\", \\\"{x:1372,y:973,t:1526919348563};\\\", \\\"{x:1375,y:973,t:1526919348580};\\\", \\\"{x:1379,y:972,t:1526919348596};\\\", \\\"{x:1383,y:971,t:1526919348613};\\\", \\\"{x:1386,y:970,t:1526919348629};\\\", \\\"{x:1389,y:969,t:1526919348647};\\\", \\\"{x:1392,y:965,t:1526919348662};\\\", \\\"{x:1393,y:965,t:1526919348680};\\\", \\\"{x:1393,y:963,t:1526919348710};\\\", \\\"{x:1394,y:961,t:1526919348743};\\\", \\\"{x:1395,y:961,t:1526919348750};\\\", \\\"{x:1395,y:960,t:1526919348763};\\\", \\\"{x:1395,y:959,t:1526919348780};\\\", \\\"{x:1396,y:958,t:1526919348797};\\\", \\\"{x:1397,y:956,t:1526919348814};\\\", \\\"{x:1397,y:955,t:1526919348830};\\\", \\\"{x:1399,y:953,t:1526919348847};\\\", \\\"{x:1400,y:951,t:1526919348864};\\\", \\\"{x:1402,y:949,t:1526919348880};\\\", \\\"{x:1405,y:947,t:1526919348898};\\\", \\\"{x:1407,y:945,t:1526919348915};\\\", \\\"{x:1409,y:943,t:1526919348931};\\\", \\\"{x:1412,y:942,t:1526919348948};\\\", \\\"{x:1415,y:940,t:1526919348964};\\\", \\\"{x:1419,y:938,t:1526919348981};\\\", \\\"{x:1424,y:934,t:1526919348997};\\\", \\\"{x:1431,y:930,t:1526919349014};\\\", \\\"{x:1434,y:928,t:1526919349030};\\\", \\\"{x:1436,y:926,t:1526919349047};\\\", \\\"{x:1441,y:923,t:1526919349065};\\\", \\\"{x:1445,y:920,t:1526919349080};\\\", \\\"{x:1452,y:913,t:1526919349098};\\\", \\\"{x:1458,y:907,t:1526919349115};\\\", \\\"{x:1463,y:902,t:1526919349132};\\\", \\\"{x:1465,y:900,t:1526919349147};\\\", \\\"{x:1468,y:896,t:1526919349164};\\\", \\\"{x:1471,y:892,t:1526919349182};\\\", \\\"{x:1475,y:886,t:1526919349198};\\\", \\\"{x:1481,y:880,t:1526919349214};\\\", \\\"{x:1483,y:876,t:1526919349232};\\\", \\\"{x:1486,y:872,t:1526919349248};\\\", \\\"{x:1487,y:868,t:1526919349265};\\\", \\\"{x:1490,y:862,t:1526919349281};\\\", \\\"{x:1490,y:857,t:1526919349298};\\\", \\\"{x:1490,y:855,t:1526919349314};\\\", \\\"{x:1490,y:853,t:1526919349331};\\\", \\\"{x:1490,y:851,t:1526919349348};\\\", \\\"{x:1490,y:849,t:1526919349364};\\\", \\\"{x:1490,y:845,t:1526919349381};\\\", \\\"{x:1490,y:844,t:1526919349398};\\\", \\\"{x:1490,y:841,t:1526919349414};\\\", \\\"{x:1490,y:839,t:1526919349438};\\\", \\\"{x:1490,y:838,t:1526919349478};\\\", \\\"{x:1490,y:836,t:1526919349519};\\\", \\\"{x:1490,y:835,t:1526919349566};\\\", \\\"{x:1490,y:833,t:1526919349598};\\\", \\\"{x:1490,y:832,t:1526919349622};\\\", \\\"{x:1489,y:831,t:1526919349663};\\\", \\\"{x:1489,y:830,t:1526919349670};\\\", \\\"{x:1488,y:829,t:1526919349702};\\\", \\\"{x:1487,y:829,t:1526919349878};\\\", \\\"{x:1486,y:829,t:1526919349886};\\\", \\\"{x:1486,y:830,t:1526919349914};\\\", \\\"{x:1486,y:831,t:1526919349931};\\\", \\\"{x:1485,y:832,t:1526919349982};\\\", \\\"{x:1478,y:833,t:1526919350334};\\\", \\\"{x:1462,y:838,t:1526919350349};\\\", \\\"{x:1342,y:848,t:1526919350365};\\\", \\\"{x:1223,y:848,t:1526919350381};\\\", \\\"{x:1084,y:843,t:1526919350398};\\\", \\\"{x:927,y:823,t:1526919350415};\\\", \\\"{x:742,y:799,t:1526919350431};\\\", \\\"{x:557,y:774,t:1526919350448};\\\", \\\"{x:376,y:765,t:1526919350465};\\\", \\\"{x:245,y:768,t:1526919350481};\\\", \\\"{x:158,y:763,t:1526919350498};\\\", \\\"{x:127,y:744,t:1526919350515};\\\", \\\"{x:110,y:730,t:1526919350532};\\\", \\\"{x:99,y:723,t:1526919350547};\\\", \\\"{x:84,y:717,t:1526919350564};\\\", \\\"{x:60,y:708,t:1526919350581};\\\", \\\"{x:45,y:704,t:1526919350598};\\\", \\\"{x:38,y:702,t:1526919350615};\\\", \\\"{x:34,y:696,t:1526919350632};\\\", \\\"{x:31,y:687,t:1526919350649};\\\", \\\"{x:30,y:673,t:1526919350665};\\\", \\\"{x:30,y:660,t:1526919350682};\\\", \\\"{x:33,y:652,t:1526919350698};\\\", \\\"{x:46,y:638,t:1526919350715};\\\", \\\"{x:61,y:627,t:1526919350733};\\\", \\\"{x:84,y:616,t:1526919350749};\\\", \\\"{x:96,y:611,t:1526919350765};\\\", \\\"{x:103,y:610,t:1526919350780};\\\", \\\"{x:123,y:610,t:1526919350797};\\\", \\\"{x:139,y:610,t:1526919350812};\\\", \\\"{x:155,y:614,t:1526919350830};\\\", \\\"{x:178,y:623,t:1526919350847};\\\", \\\"{x:211,y:636,t:1526919350865};\\\", \\\"{x:245,y:648,t:1526919350882};\\\", \\\"{x:272,y:654,t:1526919350897};\\\", \\\"{x:292,y:655,t:1526919350914};\\\", \\\"{x:311,y:655,t:1526919350931};\\\", \\\"{x:325,y:654,t:1526919350947};\\\", \\\"{x:334,y:652,t:1526919350964};\\\", \\\"{x:341,y:647,t:1526919350981};\\\", \\\"{x:341,y:645,t:1526919350997};\\\", \\\"{x:341,y:642,t:1526919351014};\\\", \\\"{x:341,y:637,t:1526919351032};\\\", \\\"{x:341,y:632,t:1526919351047};\\\", \\\"{x:343,y:624,t:1526919351066};\\\", \\\"{x:345,y:620,t:1526919351080};\\\", \\\"{x:345,y:617,t:1526919351098};\\\", \\\"{x:347,y:612,t:1526919351114};\\\", \\\"{x:351,y:605,t:1526919351131};\\\", \\\"{x:359,y:594,t:1526919351148};\\\", \\\"{x:371,y:583,t:1526919351164};\\\", \\\"{x:382,y:572,t:1526919351181};\\\", \\\"{x:388,y:568,t:1526919351197};\\\", \\\"{x:391,y:568,t:1526919351213};\\\", \\\"{x:395,y:568,t:1526919351231};\\\", \\\"{x:399,y:570,t:1526919351248};\\\", \\\"{x:408,y:576,t:1526919351264};\\\", \\\"{x:418,y:579,t:1526919351281};\\\", \\\"{x:436,y:583,t:1526919351298};\\\", \\\"{x:453,y:584,t:1526919351314};\\\", \\\"{x:469,y:584,t:1526919351331};\\\", \\\"{x:491,y:584,t:1526919351348};\\\", \\\"{x:510,y:584,t:1526919351364};\\\", \\\"{x:538,y:582,t:1526919351380};\\\", \\\"{x:555,y:578,t:1526919351397};\\\", \\\"{x:564,y:577,t:1526919351414};\\\", \\\"{x:571,y:577,t:1526919351431};\\\", \\\"{x:575,y:577,t:1526919351448};\\\", \\\"{x:576,y:577,t:1526919351464};\\\", \\\"{x:577,y:577,t:1526919351493};\\\", \\\"{x:579,y:577,t:1526919351533};\\\", \\\"{x:582,y:577,t:1526919351548};\\\", \\\"{x:595,y:578,t:1526919351565};\\\", \\\"{x:605,y:578,t:1526919351581};\\\", \\\"{x:616,y:579,t:1526919351598};\\\", \\\"{x:620,y:579,t:1526919351614};\\\", \\\"{x:623,y:579,t:1526919351631};\\\", \\\"{x:624,y:578,t:1526919351648};\\\", \\\"{x:625,y:578,t:1526919351685};\\\", \\\"{x:626,y:578,t:1526919351702};\\\", \\\"{x:625,y:578,t:1526919351934};\\\", \\\"{x:624,y:578,t:1526919351948};\\\", \\\"{x:623,y:578,t:1526919351964};\\\", \\\"{x:622,y:578,t:1526919351981};\\\", \\\"{x:621,y:578,t:1526919351998};\\\", \\\"{x:620,y:578,t:1526919352039};\\\", \\\"{x:619,y:577,t:1526919352053};\\\", \\\"{x:618,y:577,t:1526919352118};\\\", \\\"{x:617,y:576,t:1526919352238};\\\", \\\"{x:626,y:576,t:1526919353303};\\\", \\\"{x:643,y:576,t:1526919353317};\\\", \\\"{x:715,y:576,t:1526919353333};\\\", \\\"{x:777,y:578,t:1526919353350};\\\", \\\"{x:844,y:586,t:1526919353366};\\\", \\\"{x:903,y:596,t:1526919353383};\\\", \\\"{x:973,y:608,t:1526919353398};\\\", \\\"{x:1057,y:621,t:1526919353416};\\\", \\\"{x:1143,y:633,t:1526919353433};\\\", \\\"{x:1221,y:645,t:1526919353448};\\\", \\\"{x:1288,y:656,t:1526919353466};\\\", \\\"{x:1350,y:666,t:1526919353482};\\\", \\\"{x:1415,y:678,t:1526919353499};\\\", \\\"{x:1470,y:691,t:1526919353516};\\\", \\\"{x:1554,y:708,t:1526919353533};\\\", \\\"{x:1583,y:718,t:1526919353549};\\\", \\\"{x:1603,y:726,t:1526919353566};\\\", \\\"{x:1618,y:733,t:1526919353582};\\\", \\\"{x:1632,y:741,t:1526919353599};\\\", \\\"{x:1639,y:746,t:1526919353616};\\\", \\\"{x:1643,y:750,t:1526919353632};\\\", \\\"{x:1646,y:751,t:1526919353649};\\\", \\\"{x:1646,y:752,t:1526919353666};\\\", \\\"{x:1647,y:754,t:1526919353686};\\\", \\\"{x:1648,y:757,t:1526919353699};\\\", \\\"{x:1648,y:763,t:1526919353716};\\\", \\\"{x:1649,y:774,t:1526919353733};\\\", \\\"{x:1648,y:791,t:1526919353749};\\\", \\\"{x:1646,y:805,t:1526919353766};\\\", \\\"{x:1638,y:820,t:1526919353783};\\\", \\\"{x:1632,y:832,t:1526919353799};\\\", \\\"{x:1627,y:841,t:1526919353816};\\\", \\\"{x:1623,y:847,t:1526919353832};\\\", \\\"{x:1619,y:852,t:1526919353850};\\\", \\\"{x:1617,y:858,t:1526919353866};\\\", \\\"{x:1614,y:860,t:1526919353883};\\\", \\\"{x:1612,y:862,t:1526919353899};\\\", \\\"{x:1608,y:864,t:1526919353916};\\\", \\\"{x:1601,y:865,t:1526919353932};\\\", \\\"{x:1595,y:866,t:1526919353948};\\\", \\\"{x:1589,y:868,t:1526919353965};\\\", \\\"{x:1582,y:868,t:1526919353982};\\\", \\\"{x:1577,y:868,t:1526919353999};\\\", \\\"{x:1572,y:868,t:1526919354016};\\\", \\\"{x:1567,y:868,t:1526919354032};\\\", \\\"{x:1562,y:868,t:1526919354049};\\\", \\\"{x:1554,y:868,t:1526919354066};\\\", \\\"{x:1548,y:868,t:1526919354083};\\\", \\\"{x:1544,y:868,t:1526919354099};\\\", \\\"{x:1538,y:867,t:1526919354116};\\\", \\\"{x:1532,y:867,t:1526919354133};\\\", \\\"{x:1527,y:866,t:1526919354150};\\\", \\\"{x:1525,y:866,t:1526919354166};\\\", \\\"{x:1524,y:865,t:1526919354182};\\\", \\\"{x:1523,y:865,t:1526919354200};\\\", \\\"{x:1522,y:865,t:1526919354217};\\\", \\\"{x:1522,y:864,t:1526919354391};\\\", \\\"{x:1521,y:864,t:1526919354400};\\\", \\\"{x:1518,y:863,t:1526919354417};\\\", \\\"{x:1515,y:862,t:1526919354433};\\\", \\\"{x:1510,y:860,t:1526919354450};\\\", \\\"{x:1503,y:858,t:1526919354466};\\\", \\\"{x:1494,y:855,t:1526919354483};\\\", \\\"{x:1489,y:853,t:1526919354499};\\\", \\\"{x:1488,y:853,t:1526919354516};\\\", \\\"{x:1487,y:853,t:1526919354532};\\\", \\\"{x:1487,y:852,t:1526919354549};\\\", \\\"{x:1486,y:851,t:1526919354573};\\\", \\\"{x:1485,y:850,t:1526919354589};\\\", \\\"{x:1484,y:848,t:1526919354605};\\\", \\\"{x:1483,y:847,t:1526919354617};\\\", \\\"{x:1483,y:846,t:1526919354637};\\\", \\\"{x:1482,y:845,t:1526919354661};\\\", \\\"{x:1481,y:843,t:1526919354670};\\\", \\\"{x:1479,y:841,t:1526919354685};\\\", \\\"{x:1478,y:840,t:1526919354718};\\\", \\\"{x:1477,y:840,t:1526919354734};\\\", \\\"{x:1476,y:840,t:1526919354749};\\\", \\\"{x:1475,y:839,t:1526919354766};\\\", \\\"{x:1474,y:838,t:1526919354894};\\\", \\\"{x:1474,y:836,t:1526919354902};\\\", \\\"{x:1475,y:836,t:1526919354917};\\\", \\\"{x:1479,y:830,t:1526919354933};\\\", \\\"{x:1487,y:823,t:1526919354950};\\\", \\\"{x:1493,y:817,t:1526919354966};\\\", \\\"{x:1496,y:814,t:1526919354982};\\\", \\\"{x:1498,y:812,t:1526919355000};\\\", \\\"{x:1499,y:808,t:1526919355016};\\\", \\\"{x:1499,y:806,t:1526919355032};\\\", \\\"{x:1501,y:802,t:1526919355049};\\\", \\\"{x:1503,y:797,t:1526919355066};\\\", \\\"{x:1504,y:793,t:1526919355082};\\\", \\\"{x:1504,y:792,t:1526919355099};\\\", \\\"{x:1504,y:790,t:1526919355125};\\\", \\\"{x:1504,y:788,t:1526919355133};\\\", \\\"{x:1504,y:785,t:1526919355149};\\\", \\\"{x:1504,y:777,t:1526919355166};\\\", \\\"{x:1504,y:775,t:1526919355183};\\\", \\\"{x:1504,y:774,t:1526919355199};\\\", \\\"{x:1504,y:773,t:1526919355216};\\\", \\\"{x:1503,y:772,t:1526919355262};\\\", \\\"{x:1503,y:771,t:1526919355374};\\\", \\\"{x:1503,y:770,t:1526919355383};\\\", \\\"{x:1503,y:769,t:1526919355399};\\\", \\\"{x:1505,y:767,t:1526919355417};\\\", \\\"{x:1507,y:765,t:1526919355432};\\\", \\\"{x:1509,y:763,t:1526919355449};\\\", \\\"{x:1513,y:760,t:1526919355466};\\\", \\\"{x:1514,y:760,t:1526919355492};\\\", \\\"{x:1514,y:763,t:1526919356182};\\\", \\\"{x:1514,y:765,t:1526919356199};\\\", \\\"{x:1513,y:768,t:1526919356216};\\\", \\\"{x:1513,y:771,t:1526919356233};\\\", \\\"{x:1512,y:777,t:1526919356250};\\\", \\\"{x:1512,y:781,t:1526919356267};\\\", \\\"{x:1512,y:785,t:1526919356283};\\\", \\\"{x:1511,y:789,t:1526919356300};\\\", \\\"{x:1510,y:793,t:1526919356316};\\\", \\\"{x:1510,y:797,t:1526919356333};\\\", \\\"{x:1507,y:802,t:1526919356350};\\\", \\\"{x:1506,y:807,t:1526919356366};\\\", \\\"{x:1504,y:810,t:1526919356383};\\\", \\\"{x:1500,y:815,t:1526919356400};\\\", \\\"{x:1496,y:821,t:1526919356417};\\\", \\\"{x:1489,y:829,t:1526919356432};\\\", \\\"{x:1476,y:839,t:1526919356450};\\\", \\\"{x:1461,y:850,t:1526919356467};\\\", \\\"{x:1447,y:859,t:1526919356483};\\\", \\\"{x:1432,y:870,t:1526919356500};\\\", \\\"{x:1421,y:877,t:1526919356517};\\\", \\\"{x:1413,y:881,t:1526919356532};\\\", \\\"{x:1400,y:890,t:1526919356550};\\\", \\\"{x:1399,y:891,t:1526919356573};\\\", \\\"{x:1398,y:892,t:1526919356718};\\\", \\\"{x:1397,y:893,t:1526919356733};\\\", \\\"{x:1396,y:894,t:1526919356758};\\\", \\\"{x:1396,y:895,t:1526919356767};\\\", \\\"{x:1396,y:896,t:1526919356782};\\\", \\\"{x:1395,y:897,t:1526919356800};\\\", \\\"{x:1394,y:897,t:1526919356817};\\\", \\\"{x:1394,y:898,t:1526919356832};\\\", \\\"{x:1393,y:898,t:1526919356849};\\\", \\\"{x:1391,y:899,t:1526919356866};\\\", \\\"{x:1390,y:899,t:1526919356883};\\\", \\\"{x:1388,y:899,t:1526919356899};\\\", \\\"{x:1387,y:899,t:1526919356959};\\\", \\\"{x:1386,y:899,t:1526919356982};\\\", \\\"{x:1385,y:899,t:1526919356999};\\\", \\\"{x:1384,y:899,t:1526919357016};\\\", \\\"{x:1383,y:898,t:1526919357694};\\\", \\\"{x:1382,y:897,t:1526919357701};\\\", \\\"{x:1381,y:897,t:1526919357717};\\\", \\\"{x:1380,y:896,t:1526919357733};\\\", \\\"{x:1380,y:894,t:1526919357750};\\\", \\\"{x:1379,y:894,t:1526919359518};\\\", \\\"{x:1379,y:892,t:1526919359532};\\\", \\\"{x:1372,y:878,t:1526919359550};\\\", \\\"{x:1369,y:870,t:1526919359566};\\\", \\\"{x:1363,y:861,t:1526919359583};\\\", \\\"{x:1359,y:850,t:1526919359600};\\\", \\\"{x:1355,y:842,t:1526919359617};\\\", \\\"{x:1354,y:835,t:1526919359633};\\\", \\\"{x:1353,y:830,t:1526919359650};\\\", \\\"{x:1350,y:821,t:1526919359667};\\\", \\\"{x:1350,y:813,t:1526919359683};\\\", \\\"{x:1349,y:804,t:1526919359699};\\\", \\\"{x:1349,y:797,t:1526919359717};\\\", \\\"{x:1347,y:792,t:1526919359733};\\\", \\\"{x:1346,y:788,t:1526919359750};\\\", \\\"{x:1346,y:787,t:1526919359766};\\\", \\\"{x:1346,y:786,t:1526919359783};\\\", \\\"{x:1346,y:785,t:1526919359886};\\\", \\\"{x:1347,y:783,t:1526919359902};\\\", \\\"{x:1347,y:782,t:1526919359926};\\\", \\\"{x:1348,y:782,t:1526919359950};\\\", \\\"{x:1348,y:780,t:1526919359974};\\\", \\\"{x:1349,y:779,t:1526919359983};\\\", \\\"{x:1350,y:779,t:1526919359999};\\\", \\\"{x:1350,y:777,t:1526919360021};\\\", \\\"{x:1351,y:775,t:1526919360045};\\\", \\\"{x:1352,y:773,t:1526919360070};\\\", \\\"{x:1352,y:772,t:1526919360150};\\\", \\\"{x:1352,y:770,t:1526919360167};\\\", \\\"{x:1352,y:768,t:1526919360183};\\\", \\\"{x:1352,y:766,t:1526919360200};\\\", \\\"{x:1352,y:765,t:1526919360216};\\\", \\\"{x:1352,y:764,t:1526919360232};\\\", \\\"{x:1351,y:763,t:1526919360261};\\\", \\\"{x:1351,y:762,t:1526919360838};\\\", \\\"{x:1350,y:762,t:1526919360894};\\\", \\\"{x:1350,y:761,t:1526919360982};\\\", \\\"{x:1350,y:760,t:1526919361005};\\\", \\\"{x:1349,y:760,t:1526919361054};\\\", \\\"{x:1349,y:761,t:1526919361710};\\\", \\\"{x:1349,y:763,t:1526919361726};\\\", \\\"{x:1349,y:764,t:1526919361749};\\\", \\\"{x:1349,y:766,t:1526919361782};\\\", \\\"{x:1349,y:767,t:1526919361805};\\\", \\\"{x:1349,y:773,t:1526919362886};\\\", \\\"{x:1349,y:780,t:1526919362899};\\\", \\\"{x:1350,y:792,t:1526919362917};\\\", \\\"{x:1362,y:811,t:1526919362933};\\\", \\\"{x:1379,y:837,t:1526919362950};\\\", \\\"{x:1387,y:851,t:1526919362967};\\\", \\\"{x:1395,y:863,t:1526919362983};\\\", \\\"{x:1399,y:869,t:1526919363000};\\\", \\\"{x:1403,y:877,t:1526919363017};\\\", \\\"{x:1406,y:884,t:1526919363033};\\\", \\\"{x:1411,y:894,t:1526919363049};\\\", \\\"{x:1416,y:904,t:1526919363066};\\\", \\\"{x:1419,y:913,t:1526919363083};\\\", \\\"{x:1422,y:919,t:1526919363099};\\\", \\\"{x:1425,y:923,t:1526919363117};\\\", \\\"{x:1426,y:924,t:1526919363133};\\\", \\\"{x:1426,y:925,t:1526919363150};\\\", \\\"{x:1426,y:926,t:1526919363167};\\\", \\\"{x:1426,y:927,t:1526919363183};\\\", \\\"{x:1426,y:928,t:1526919363200};\\\", \\\"{x:1426,y:929,t:1526919363216};\\\", \\\"{x:1426,y:930,t:1526919363238};\\\", \\\"{x:1426,y:931,t:1526919363261};\\\", \\\"{x:1426,y:932,t:1526919363270};\\\", \\\"{x:1426,y:934,t:1526919363286};\\\", \\\"{x:1426,y:935,t:1526919363300};\\\", \\\"{x:1426,y:937,t:1526919363317};\\\", \\\"{x:1426,y:941,t:1526919363333};\\\", \\\"{x:1425,y:946,t:1526919363350};\\\", \\\"{x:1423,y:951,t:1526919363367};\\\", \\\"{x:1422,y:954,t:1526919363383};\\\", \\\"{x:1421,y:956,t:1526919363400};\\\", \\\"{x:1421,y:959,t:1526919363416};\\\", \\\"{x:1421,y:961,t:1526919363438};\\\", \\\"{x:1421,y:962,t:1526919363450};\\\", \\\"{x:1420,y:962,t:1526919363466};\\\", \\\"{x:1420,y:964,t:1526919363483};\\\", \\\"{x:1420,y:965,t:1526919363499};\\\", \\\"{x:1420,y:967,t:1526919363525};\\\", \\\"{x:1420,y:968,t:1526919363540};\\\", \\\"{x:1419,y:969,t:1526919363549};\\\", \\\"{x:1418,y:970,t:1526919363567};\\\", \\\"{x:1418,y:971,t:1526919363588};\\\", \\\"{x:1418,y:972,t:1526919363637};\\\", \\\"{x:1417,y:974,t:1526919363650};\\\", \\\"{x:1418,y:973,t:1526919363910};\\\", \\\"{x:1421,y:973,t:1526919363918};\\\", \\\"{x:1424,y:973,t:1526919363933};\\\", \\\"{x:1439,y:970,t:1526919363950};\\\", \\\"{x:1447,y:970,t:1526919363967};\\\", \\\"{x:1451,y:970,t:1526919363983};\\\", \\\"{x:1452,y:970,t:1526919364000};\\\", \\\"{x:1453,y:970,t:1526919364017};\\\", \\\"{x:1454,y:970,t:1526919364037};\\\", \\\"{x:1455,y:969,t:1526919364054};\\\", \\\"{x:1456,y:969,t:1526919364067};\\\", \\\"{x:1457,y:969,t:1526919364083};\\\", \\\"{x:1458,y:968,t:1526919364099};\\\", \\\"{x:1460,y:968,t:1526919364117};\\\", \\\"{x:1463,y:968,t:1526919364133};\\\", \\\"{x:1467,y:968,t:1526919364150};\\\", \\\"{x:1468,y:968,t:1526919364167};\\\", \\\"{x:1469,y:968,t:1526919364183};\\\", \\\"{x:1471,y:967,t:1526919364214};\\\", \\\"{x:1472,y:967,t:1526919364221};\\\", \\\"{x:1473,y:967,t:1526919364233};\\\", \\\"{x:1477,y:967,t:1526919364250};\\\", \\\"{x:1481,y:966,t:1526919364267};\\\", \\\"{x:1484,y:966,t:1526919364283};\\\", \\\"{x:1486,y:966,t:1526919364300};\\\", \\\"{x:1487,y:966,t:1526919364550};\\\", \\\"{x:1490,y:964,t:1526919364568};\\\", \\\"{x:1500,y:963,t:1526919364583};\\\", \\\"{x:1508,y:963,t:1526919364600};\\\", \\\"{x:1519,y:963,t:1526919364617};\\\", \\\"{x:1532,y:962,t:1526919364633};\\\", \\\"{x:1542,y:961,t:1526919364650};\\\", \\\"{x:1549,y:961,t:1526919364667};\\\", \\\"{x:1553,y:960,t:1526919364684};\\\", \\\"{x:1557,y:959,t:1526919364699};\\\", \\\"{x:1560,y:959,t:1526919364717};\\\", \\\"{x:1564,y:959,t:1526919364733};\\\", \\\"{x:1568,y:959,t:1526919364750};\\\", \\\"{x:1574,y:958,t:1526919364766};\\\", \\\"{x:1577,y:958,t:1526919364783};\\\", \\\"{x:1579,y:956,t:1526919364800};\\\", \\\"{x:1581,y:956,t:1526919364817};\\\", \\\"{x:1582,y:956,t:1526919364833};\\\", \\\"{x:1584,y:956,t:1526919364850};\\\", \\\"{x:1587,y:956,t:1526919364867};\\\", \\\"{x:1590,y:956,t:1526919364883};\\\", \\\"{x:1591,y:956,t:1526919364900};\\\", \\\"{x:1592,y:956,t:1526919364917};\\\", \\\"{x:1593,y:956,t:1526919365038};\\\", \\\"{x:1594,y:956,t:1526919365389};\\\", \\\"{x:1594,y:958,t:1526919366094};\\\", \\\"{x:1594,y:960,t:1526919366270};\\\", \\\"{x:1593,y:962,t:1526919366302};\\\", \\\"{x:1592,y:962,t:1526919366317};\\\", \\\"{x:1591,y:962,t:1526919366333};\\\", \\\"{x:1589,y:962,t:1526919366350};\\\", \\\"{x:1587,y:962,t:1526919366367};\\\", \\\"{x:1585,y:962,t:1526919366383};\\\", \\\"{x:1582,y:962,t:1526919366400};\\\", \\\"{x:1579,y:961,t:1526919366417};\\\", \\\"{x:1577,y:961,t:1526919366433};\\\", \\\"{x:1576,y:961,t:1526919366450};\\\", \\\"{x:1575,y:961,t:1526919366469};\\\", \\\"{x:1574,y:960,t:1526919366483};\\\", \\\"{x:1573,y:960,t:1526919366525};\\\", \\\"{x:1572,y:959,t:1526919366534};\\\", \\\"{x:1571,y:959,t:1526919366574};\\\", \\\"{x:1570,y:959,t:1526919366630};\\\", \\\"{x:1568,y:959,t:1526919366646};\\\", \\\"{x:1566,y:956,t:1526919366654};\\\", \\\"{x:1564,y:955,t:1526919366667};\\\", \\\"{x:1556,y:955,t:1526919366683};\\\", \\\"{x:1544,y:952,t:1526919366700};\\\", \\\"{x:1536,y:949,t:1526919366717};\\\", \\\"{x:1529,y:947,t:1526919366733};\\\", \\\"{x:1512,y:942,t:1526919366749};\\\", \\\"{x:1502,y:938,t:1526919366766};\\\", \\\"{x:1491,y:936,t:1526919366783};\\\", \\\"{x:1480,y:933,t:1526919366800};\\\", \\\"{x:1471,y:931,t:1526919366816};\\\", \\\"{x:1462,y:926,t:1526919366834};\\\", \\\"{x:1449,y:919,t:1526919366850};\\\", \\\"{x:1434,y:913,t:1526919366866};\\\", \\\"{x:1410,y:905,t:1526919366883};\\\", \\\"{x:1381,y:893,t:1526919366900};\\\", \\\"{x:1344,y:874,t:1526919366918};\\\", \\\"{x:1313,y:860,t:1526919366933};\\\", \\\"{x:1289,y:844,t:1526919366950};\\\", \\\"{x:1284,y:834,t:1526919366967};\\\", \\\"{x:1274,y:821,t:1526919366983};\\\", \\\"{x:1273,y:807,t:1526919367000};\\\", \\\"{x:1273,y:792,t:1526919367017};\\\", \\\"{x:1277,y:773,t:1526919367033};\\\", \\\"{x:1285,y:753,t:1526919367050};\\\", \\\"{x:1295,y:731,t:1526919367067};\\\", \\\"{x:1309,y:703,t:1526919367082};\\\", \\\"{x:1326,y:669,t:1526919367100};\\\", \\\"{x:1338,y:653,t:1526919367117};\\\", \\\"{x:1347,y:644,t:1526919367132};\\\", \\\"{x:1356,y:635,t:1526919367150};\\\", \\\"{x:1363,y:628,t:1526919367167};\\\", \\\"{x:1375,y:617,t:1526919367183};\\\", \\\"{x:1385,y:611,t:1526919367200};\\\", \\\"{x:1393,y:606,t:1526919367217};\\\", \\\"{x:1398,y:604,t:1526919367233};\\\", \\\"{x:1402,y:601,t:1526919367249};\\\", \\\"{x:1403,y:600,t:1526919367267};\\\", \\\"{x:1405,y:600,t:1526919367283};\\\", \\\"{x:1407,y:600,t:1526919367300};\\\", \\\"{x:1408,y:600,t:1526919367317};\\\", \\\"{x:1410,y:600,t:1526919367334};\\\", \\\"{x:1411,y:600,t:1526919367382};\\\", \\\"{x:1412,y:601,t:1526919367413};\\\", \\\"{x:1413,y:601,t:1526919367548};\\\", \\\"{x:1413,y:599,t:1526919367567};\\\", \\\"{x:1413,y:598,t:1526919367583};\\\", \\\"{x:1414,y:594,t:1526919367600};\\\", \\\"{x:1414,y:592,t:1526919367617};\\\", \\\"{x:1414,y:591,t:1526919367633};\\\", \\\"{x:1415,y:588,t:1526919367649};\\\", \\\"{x:1415,y:586,t:1526919367667};\\\", \\\"{x:1415,y:585,t:1526919367682};\\\", \\\"{x:1415,y:583,t:1526919367699};\\\", \\\"{x:1415,y:579,t:1526919367717};\\\", \\\"{x:1415,y:577,t:1526919367733};\\\", \\\"{x:1415,y:573,t:1526919367750};\\\", \\\"{x:1415,y:572,t:1526919367767};\\\", \\\"{x:1415,y:570,t:1526919367782};\\\", \\\"{x:1415,y:569,t:1526919367799};\\\", \\\"{x:1415,y:572,t:1526919369390};\\\", \\\"{x:1415,y:573,t:1526919369406};\\\", \\\"{x:1416,y:574,t:1526919369417};\\\", \\\"{x:1416,y:576,t:1526919369433};\\\", \\\"{x:1417,y:578,t:1526919369450};\\\", \\\"{x:1417,y:579,t:1526919369467};\\\", \\\"{x:1418,y:582,t:1526919369483};\\\", \\\"{x:1420,y:586,t:1526919369500};\\\", \\\"{x:1424,y:591,t:1526919369517};\\\", \\\"{x:1428,y:596,t:1526919369534};\\\", \\\"{x:1429,y:598,t:1526919369549};\\\", \\\"{x:1432,y:601,t:1526919369566};\\\", \\\"{x:1434,y:605,t:1526919369583};\\\", \\\"{x:1437,y:609,t:1526919369600};\\\", \\\"{x:1439,y:612,t:1526919369616};\\\", \\\"{x:1440,y:615,t:1526919369633};\\\", \\\"{x:1441,y:617,t:1526919369650};\\\", \\\"{x:1443,y:620,t:1526919369667};\\\", \\\"{x:1444,y:622,t:1526919369683};\\\", \\\"{x:1444,y:623,t:1526919369700};\\\", \\\"{x:1446,y:626,t:1526919369718};\\\", \\\"{x:1447,y:628,t:1526919369733};\\\", \\\"{x:1448,y:629,t:1526919369750};\\\", \\\"{x:1448,y:630,t:1526919369767};\\\", \\\"{x:1449,y:632,t:1526919369783};\\\", \\\"{x:1449,y:634,t:1526919369799};\\\", \\\"{x:1450,y:636,t:1526919369818};\\\", \\\"{x:1451,y:637,t:1526919369833};\\\", \\\"{x:1451,y:638,t:1526919369850};\\\", \\\"{x:1452,y:639,t:1526919369866};\\\", \\\"{x:1453,y:643,t:1526919369883};\\\", \\\"{x:1454,y:645,t:1526919369900};\\\", \\\"{x:1455,y:646,t:1526919370006};\\\", \\\"{x:1455,y:647,t:1526919370021};\\\", \\\"{x:1455,y:648,t:1526919370033};\\\", \\\"{x:1455,y:653,t:1526919370050};\\\", \\\"{x:1455,y:659,t:1526919370066};\\\", \\\"{x:1455,y:667,t:1526919370083};\\\", \\\"{x:1455,y:679,t:1526919370100};\\\", \\\"{x:1455,y:699,t:1526919370116};\\\", \\\"{x:1455,y:735,t:1526919370133};\\\", \\\"{x:1455,y:757,t:1526919370150};\\\", \\\"{x:1455,y:777,t:1526919370167};\\\", \\\"{x:1455,y:795,t:1526919370183};\\\", \\\"{x:1455,y:808,t:1526919370200};\\\", \\\"{x:1455,y:824,t:1526919370216};\\\", \\\"{x:1454,y:834,t:1526919370233};\\\", \\\"{x:1454,y:842,t:1526919370250};\\\", \\\"{x:1454,y:845,t:1526919370266};\\\", \\\"{x:1454,y:849,t:1526919370283};\\\", \\\"{x:1454,y:853,t:1526919370300};\\\", \\\"{x:1453,y:858,t:1526919370316};\\\", \\\"{x:1453,y:861,t:1526919370333};\\\", \\\"{x:1453,y:863,t:1526919370350};\\\", \\\"{x:1451,y:867,t:1526919370366};\\\", \\\"{x:1450,y:869,t:1526919370383};\\\", \\\"{x:1448,y:875,t:1526919370400};\\\", \\\"{x:1445,y:877,t:1526919370416};\\\", \\\"{x:1441,y:881,t:1526919370433};\\\", \\\"{x:1435,y:890,t:1526919370450};\\\", \\\"{x:1428,y:897,t:1526919370467};\\\", \\\"{x:1419,y:903,t:1526919370482};\\\", \\\"{x:1410,y:908,t:1526919370499};\\\", \\\"{x:1399,y:915,t:1526919370517};\\\", \\\"{x:1394,y:919,t:1526919370533};\\\", \\\"{x:1387,y:923,t:1526919370550};\\\", \\\"{x:1380,y:927,t:1526919370566};\\\", \\\"{x:1378,y:927,t:1526919370583};\\\", \\\"{x:1377,y:928,t:1526919370599};\\\", \\\"{x:1375,y:928,t:1526919370616};\\\", \\\"{x:1374,y:928,t:1526919370685};\\\", \\\"{x:1373,y:928,t:1526919370700};\\\", \\\"{x:1372,y:924,t:1526919370716};\\\", \\\"{x:1372,y:916,t:1526919370733};\\\", \\\"{x:1372,y:912,t:1526919370749};\\\", \\\"{x:1372,y:910,t:1526919370767};\\\", \\\"{x:1372,y:909,t:1526919370782};\\\", \\\"{x:1372,y:908,t:1526919370800};\\\", \\\"{x:1372,y:907,t:1526919370821};\\\", \\\"{x:1373,y:907,t:1526919370833};\\\", \\\"{x:1374,y:906,t:1526919370853};\\\", \\\"{x:1375,y:906,t:1526919370869};\\\", \\\"{x:1376,y:906,t:1526919370883};\\\", \\\"{x:1379,y:905,t:1526919370900};\\\", \\\"{x:1382,y:904,t:1526919370916};\\\", \\\"{x:1384,y:903,t:1526919370934};\\\", \\\"{x:1386,y:903,t:1526919371014};\\\", \\\"{x:1387,y:903,t:1526919371199};\\\", \\\"{x:1387,y:904,t:1526919371886};\\\", \\\"{x:1387,y:908,t:1526919371900};\\\", \\\"{x:1384,y:915,t:1526919371917};\\\", \\\"{x:1371,y:930,t:1526919371934};\\\", \\\"{x:1361,y:941,t:1526919371949};\\\", \\\"{x:1357,y:947,t:1526919371967};\\\", \\\"{x:1344,y:956,t:1526919371983};\\\", \\\"{x:1336,y:961,t:1526919372001};\\\", \\\"{x:1332,y:963,t:1526919372017};\\\", \\\"{x:1328,y:964,t:1526919372033};\\\", \\\"{x:1325,y:966,t:1526919372051};\\\", \\\"{x:1323,y:967,t:1526919372066};\\\", \\\"{x:1322,y:967,t:1526919372083};\\\", \\\"{x:1319,y:969,t:1526919372100};\\\", \\\"{x:1317,y:969,t:1526919372134};\\\", \\\"{x:1315,y:969,t:1526919372150};\\\", \\\"{x:1313,y:969,t:1526919372167};\\\", \\\"{x:1308,y:969,t:1526919372183};\\\", \\\"{x:1303,y:969,t:1526919372200};\\\", \\\"{x:1299,y:969,t:1526919372217};\\\", \\\"{x:1294,y:969,t:1526919372233};\\\", \\\"{x:1288,y:967,t:1526919372251};\\\", \\\"{x:1284,y:967,t:1526919372267};\\\", \\\"{x:1281,y:967,t:1526919372283};\\\", \\\"{x:1279,y:967,t:1526919372301};\\\", \\\"{x:1277,y:967,t:1526919372317};\\\", \\\"{x:1274,y:967,t:1526919372334};\\\", \\\"{x:1273,y:967,t:1526919372350};\\\", \\\"{x:1272,y:968,t:1526919372367};\\\", \\\"{x:1271,y:969,t:1526919372383};\\\", \\\"{x:1271,y:966,t:1526919372447};\\\", \\\"{x:1271,y:962,t:1526919372453};\\\", \\\"{x:1271,y:956,t:1526919372466};\\\", \\\"{x:1271,y:936,t:1526919372483};\\\", \\\"{x:1271,y:916,t:1526919372500};\\\", \\\"{x:1271,y:892,t:1526919372516};\\\", \\\"{x:1268,y:844,t:1526919372534};\\\", \\\"{x:1263,y:802,t:1526919372550};\\\", \\\"{x:1257,y:752,t:1526919372566};\\\", \\\"{x:1254,y:714,t:1526919372583};\\\", \\\"{x:1253,y:676,t:1526919372600};\\\", \\\"{x:1250,y:650,t:1526919372616};\\\", \\\"{x:1250,y:631,t:1526919372633};\\\", \\\"{x:1250,y:618,t:1526919372650};\\\", \\\"{x:1250,y:604,t:1526919372666};\\\", \\\"{x:1250,y:594,t:1526919372683};\\\", \\\"{x:1250,y:587,t:1526919372701};\\\", \\\"{x:1249,y:578,t:1526919372717};\\\", \\\"{x:1248,y:568,t:1526919372733};\\\", \\\"{x:1246,y:562,t:1526919372750};\\\", \\\"{x:1246,y:557,t:1526919372766};\\\", \\\"{x:1246,y:554,t:1526919372783};\\\", \\\"{x:1246,y:552,t:1526919372800};\\\", \\\"{x:1246,y:551,t:1526919372846};\\\", \\\"{x:1250,y:554,t:1526919372862};\\\", \\\"{x:1254,y:560,t:1526919372870};\\\", \\\"{x:1261,y:570,t:1526919372884};\\\", \\\"{x:1276,y:602,t:1526919372900};\\\", \\\"{x:1303,y:661,t:1526919372917};\\\", \\\"{x:1341,y:750,t:1526919372933};\\\", \\\"{x:1358,y:794,t:1526919372950};\\\", \\\"{x:1373,y:827,t:1526919372966};\\\", \\\"{x:1386,y:874,t:1526919372984};\\\", \\\"{x:1401,y:920,t:1526919373000};\\\", \\\"{x:1413,y:962,t:1526919373016};\\\", \\\"{x:1419,y:993,t:1526919373033};\\\", \\\"{x:1419,y:1019,t:1526919373050};\\\", \\\"{x:1419,y:1045,t:1526919373066};\\\", \\\"{x:1419,y:1069,t:1526919373083};\\\", \\\"{x:1418,y:1085,t:1526919373100};\\\", \\\"{x:1414,y:1094,t:1526919373116};\\\", \\\"{x:1412,y:1098,t:1526919373134};\\\", \\\"{x:1410,y:1099,t:1526919373149};\\\", \\\"{x:1407,y:1099,t:1526919373166};\\\", \\\"{x:1401,y:1098,t:1526919373183};\\\", \\\"{x:1397,y:1097,t:1526919373200};\\\", \\\"{x:1390,y:1092,t:1526919373216};\\\", \\\"{x:1376,y:1080,t:1526919373233};\\\", \\\"{x:1363,y:1068,t:1526919373250};\\\", \\\"{x:1350,y:1056,t:1526919373266};\\\", \\\"{x:1343,y:1043,t:1526919373284};\\\", \\\"{x:1335,y:1026,t:1526919373300};\\\", \\\"{x:1329,y:1011,t:1526919373316};\\\", \\\"{x:1323,y:1004,t:1526919373333};\\\", \\\"{x:1321,y:1003,t:1526919373350};\\\", \\\"{x:1318,y:1002,t:1526919373366};\\\", \\\"{x:1313,y:1000,t:1526919373383};\\\", \\\"{x:1311,y:999,t:1526919373400};\\\", \\\"{x:1309,y:998,t:1526919373420};\\\", \\\"{x:1307,y:998,t:1526919373433};\\\", \\\"{x:1304,y:995,t:1526919373449};\\\", \\\"{x:1299,y:992,t:1526919373466};\\\", \\\"{x:1297,y:990,t:1526919373482};\\\", \\\"{x:1296,y:988,t:1526919373499};\\\", \\\"{x:1295,y:985,t:1526919373515};\\\", \\\"{x:1292,y:978,t:1526919373533};\\\", \\\"{x:1290,y:976,t:1526919373550};\\\", \\\"{x:1288,y:975,t:1526919373566};\\\", \\\"{x:1286,y:973,t:1526919373583};\\\", \\\"{x:1285,y:971,t:1526919373600};\\\", \\\"{x:1285,y:968,t:1526919373617};\\\", \\\"{x:1283,y:966,t:1526919373633};\\\", \\\"{x:1283,y:963,t:1526919373650};\\\", \\\"{x:1283,y:959,t:1526919373666};\\\", \\\"{x:1281,y:956,t:1526919373683};\\\", \\\"{x:1281,y:954,t:1526919373700};\\\", \\\"{x:1281,y:953,t:1526919373716};\\\", \\\"{x:1280,y:951,t:1526919373733};\\\", \\\"{x:1282,y:951,t:1526919374510};\\\", \\\"{x:1288,y:951,t:1526919374517};\\\", \\\"{x:1303,y:951,t:1526919374534};\\\", \\\"{x:1323,y:951,t:1526919374550};\\\", \\\"{x:1336,y:951,t:1526919374566};\\\", \\\"{x:1342,y:951,t:1526919374583};\\\", \\\"{x:1343,y:951,t:1526919374600};\\\", \\\"{x:1344,y:951,t:1526919374670};\\\", \\\"{x:1344,y:952,t:1526919374693};\\\", \\\"{x:1344,y:953,t:1526919374718};\\\", \\\"{x:1344,y:954,t:1526919374741};\\\", \\\"{x:1344,y:955,t:1526919374757};\\\", \\\"{x:1344,y:957,t:1526919374766};\\\", \\\"{x:1342,y:959,t:1526919374783};\\\", \\\"{x:1339,y:960,t:1526919374801};\\\", \\\"{x:1335,y:961,t:1526919374817};\\\", \\\"{x:1332,y:961,t:1526919374834};\\\", \\\"{x:1328,y:962,t:1526919374850};\\\", \\\"{x:1324,y:962,t:1526919374867};\\\", \\\"{x:1321,y:962,t:1526919374884};\\\", \\\"{x:1320,y:962,t:1526919374900};\\\", \\\"{x:1319,y:962,t:1526919374916};\\\", \\\"{x:1324,y:961,t:1526919375302};\\\", \\\"{x:1328,y:960,t:1526919375317};\\\", \\\"{x:1340,y:959,t:1526919375333};\\\", \\\"{x:1341,y:959,t:1526919375350};\\\", \\\"{x:1343,y:959,t:1526919375421};\\\", \\\"{x:1344,y:959,t:1526919375461};\\\", \\\"{x:1345,y:959,t:1526919375484};\\\", \\\"{x:1346,y:960,t:1526919375499};\\\", \\\"{x:1347,y:960,t:1526919375548};\\\", \\\"{x:1352,y:960,t:1526919376142};\\\", \\\"{x:1358,y:960,t:1526919376150};\\\", \\\"{x:1371,y:960,t:1526919376166};\\\", \\\"{x:1381,y:960,t:1526919376184};\\\", \\\"{x:1390,y:960,t:1526919376200};\\\", \\\"{x:1396,y:960,t:1526919376216};\\\", \\\"{x:1399,y:961,t:1526919376233};\\\", \\\"{x:1400,y:961,t:1526919376250};\\\", \\\"{x:1402,y:961,t:1526919376266};\\\", \\\"{x:1403,y:961,t:1526919376283};\\\", \\\"{x:1408,y:961,t:1526919376299};\\\", \\\"{x:1414,y:961,t:1526919376316};\\\", \\\"{x:1420,y:961,t:1526919376332};\\\", \\\"{x:1425,y:961,t:1526919376350};\\\", \\\"{x:1427,y:961,t:1526919376365};\\\", \\\"{x:1428,y:961,t:1526919376383};\\\", \\\"{x:1429,y:962,t:1526919376541};\\\", \\\"{x:1429,y:963,t:1526919376551};\\\", \\\"{x:1427,y:964,t:1526919376566};\\\", \\\"{x:1426,y:965,t:1526919376590};\\\", \\\"{x:1425,y:965,t:1526919376601};\\\", \\\"{x:1423,y:966,t:1526919376616};\\\", \\\"{x:1421,y:966,t:1526919376633};\\\", \\\"{x:1419,y:966,t:1526919376650};\\\", \\\"{x:1418,y:966,t:1526919376734};\\\", \\\"{x:1417,y:966,t:1526919376805};\\\", \\\"{x:1418,y:965,t:1526919376981};\\\", \\\"{x:1420,y:965,t:1526919376989};\\\", \\\"{x:1426,y:963,t:1526919377001};\\\", \\\"{x:1439,y:962,t:1526919377016};\\\", \\\"{x:1457,y:962,t:1526919377033};\\\", \\\"{x:1467,y:962,t:1526919377050};\\\", \\\"{x:1472,y:962,t:1526919377066};\\\", \\\"{x:1474,y:962,t:1526919377084};\\\", \\\"{x:1475,y:962,t:1526919377198};\\\", \\\"{x:1477,y:962,t:1526919377502};\\\", \\\"{x:1482,y:962,t:1526919377517};\\\", \\\"{x:1504,y:962,t:1526919377534};\\\", \\\"{x:1521,y:962,t:1526919377550};\\\", \\\"{x:1532,y:962,t:1526919377567};\\\", \\\"{x:1540,y:963,t:1526919377584};\\\", \\\"{x:1541,y:963,t:1526919377601};\\\", \\\"{x:1542,y:963,t:1526919377616};\\\", \\\"{x:1543,y:963,t:1526919377633};\\\", \\\"{x:1544,y:963,t:1526919377650};\\\", \\\"{x:1545,y:963,t:1526919377982};\\\", \\\"{x:1550,y:963,t:1526919377990};\\\", \\\"{x:1556,y:963,t:1526919378001};\\\", \\\"{x:1572,y:963,t:1526919378017};\\\", \\\"{x:1590,y:963,t:1526919378034};\\\", \\\"{x:1609,y:963,t:1526919378050};\\\", \\\"{x:1622,y:963,t:1526919378066};\\\", \\\"{x:1627,y:963,t:1526919378083};\\\", \\\"{x:1630,y:963,t:1526919378101};\\\", \\\"{x:1631,y:963,t:1526919378422};\\\", \\\"{x:1634,y:963,t:1526919378434};\\\", \\\"{x:1648,y:963,t:1526919378451};\\\", \\\"{x:1660,y:963,t:1526919378467};\\\", \\\"{x:1668,y:963,t:1526919378483};\\\", \\\"{x:1674,y:963,t:1526919378500};\\\", \\\"{x:1675,y:963,t:1526919378517};\\\", \\\"{x:1676,y:963,t:1526919378646};\\\", \\\"{x:1677,y:963,t:1526919378677};\\\", \\\"{x:1678,y:963,t:1526919379254};\\\", \\\"{x:1678,y:964,t:1526919379944};\\\", \\\"{x:1677,y:964,t:1526919379957};\\\", \\\"{x:1674,y:964,t:1526919379967};\\\", \\\"{x:1670,y:964,t:1526919379983};\\\", \\\"{x:1666,y:964,t:1526919380001};\\\", \\\"{x:1659,y:964,t:1526919380016};\\\", \\\"{x:1654,y:964,t:1526919380033};\\\", \\\"{x:1646,y:964,t:1526919380050};\\\", \\\"{x:1632,y:963,t:1526919380067};\\\", \\\"{x:1620,y:960,t:1526919380084};\\\", \\\"{x:1609,y:959,t:1526919380101};\\\", \\\"{x:1600,y:958,t:1526919380117};\\\", \\\"{x:1596,y:956,t:1526919380133};\\\", \\\"{x:1592,y:955,t:1526919380151};\\\", \\\"{x:1584,y:954,t:1526919380166};\\\", \\\"{x:1569,y:952,t:1526919380184};\\\", \\\"{x:1551,y:950,t:1526919380200};\\\", \\\"{x:1536,y:950,t:1526919380215};\\\", \\\"{x:1524,y:949,t:1526919380232};\\\", \\\"{x:1515,y:947,t:1526919380250};\\\", \\\"{x:1509,y:946,t:1526919380266};\\\", \\\"{x:1497,y:946,t:1526919380283};\\\", \\\"{x:1480,y:946,t:1526919380299};\\\", \\\"{x:1457,y:946,t:1526919380316};\\\", \\\"{x:1412,y:946,t:1526919380333};\\\", \\\"{x:1381,y:946,t:1526919380350};\\\", \\\"{x:1333,y:946,t:1526919380366};\\\", \\\"{x:1294,y:946,t:1526919380383};\\\", \\\"{x:1268,y:946,t:1526919380400};\\\", \\\"{x:1254,y:946,t:1526919380416};\\\", \\\"{x:1244,y:946,t:1526919380433};\\\", \\\"{x:1239,y:946,t:1526919380450};\\\", \\\"{x:1230,y:946,t:1526919380466};\\\", \\\"{x:1210,y:946,t:1526919380483};\\\", \\\"{x:1180,y:946,t:1526919380500};\\\", \\\"{x:1132,y:946,t:1526919380516};\\\", \\\"{x:992,y:938,t:1526919380532};\\\", \\\"{x:868,y:924,t:1526919380551};\\\", \\\"{x:745,y:903,t:1526919380566};\\\", \\\"{x:654,y:892,t:1526919380582};\\\", \\\"{x:579,y:883,t:1526919380600};\\\", \\\"{x:510,y:874,t:1526919380616};\\\", \\\"{x:446,y:866,t:1526919380633};\\\", \\\"{x:380,y:850,t:1526919380650};\\\", \\\"{x:324,y:834,t:1526919380667};\\\", \\\"{x:275,y:817,t:1526919380683};\\\", \\\"{x:221,y:795,t:1526919380701};\\\", \\\"{x:160,y:771,t:1526919380717};\\\", \\\"{x:92,y:738,t:1526919380733};\\\", \\\"{x:77,y:724,t:1526919380750};\\\", \\\"{x:72,y:712,t:1526919380767};\\\", \\\"{x:72,y:703,t:1526919380783};\\\", \\\"{x:72,y:694,t:1526919380800};\\\", \\\"{x:79,y:686,t:1526919380816};\\\", \\\"{x:84,y:683,t:1526919380833};\\\", \\\"{x:93,y:680,t:1526919380850};\\\", \\\"{x:108,y:680,t:1526919380866};\\\", \\\"{x:133,y:680,t:1526919380883};\\\", \\\"{x:157,y:680,t:1526919380900};\\\", \\\"{x:213,y:688,t:1526919380917};\\\", \\\"{x:335,y:710,t:1526919380932};\\\", \\\"{x:419,y:725,t:1526919380950};\\\", \\\"{x:482,y:739,t:1526919380967};\\\", \\\"{x:511,y:749,t:1526919380982};\\\", \\\"{x:522,y:753,t:1526919380999};\\\", \\\"{x:524,y:754,t:1526919381021};\\\", \\\"{x:524,y:755,t:1526919381141};\\\", \\\"{x:521,y:754,t:1526919381173};\\\", \\\"{x:518,y:753,t:1526919381187};\\\", \\\"{x:507,y:748,t:1526919381204};\\\", \\\"{x:503,y:747,t:1526919381221};\\\", \\\"{x:501,y:745,t:1526919381238};\\\", \\\"{x:500,y:745,t:1526919381269};\\\", \\\"{x:500,y:744,t:1526919381293};\\\", \\\"{x:500,y:743,t:1526919381334};\\\", \\\"{x:500,y:742,t:1526919381342};\\\", \\\"{x:501,y:741,t:1526919381357};\\\", \\\"{x:503,y:740,t:1526919381373};\\\", \\\"{x:504,y:738,t:1526919381388};\\\", \\\"{x:505,y:737,t:1526919381405};\\\", \\\"{x:506,y:737,t:1526919381566};\\\", \\\"{x:506,y:735,t:1526919381654};\\\", \\\"{x:506,y:733,t:1526919381669};\\\", \\\"{x:504,y:733,t:1526919388629};\\\" ] }, { \\\"rt\\\": 17717, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 787046, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-E -12 PM-4-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:732,t:1526919389364};\\\", \\\"{x:502,y:731,t:1526919389484};\\\", \\\"{x:501,y:730,t:1526919389533};\\\", \\\"{x:499,y:730,t:1526919390269};\\\", \\\"{x:495,y:730,t:1526919390279};\\\", \\\"{x:494,y:730,t:1526919392278};\\\", \\\"{x:493,y:730,t:1526919392477};\\\", \\\"{x:492,y:730,t:1526919392541};\\\", \\\"{x:492,y:731,t:1526919392693};\\\", \\\"{x:493,y:732,t:1526919392701};\\\", \\\"{x:495,y:732,t:1526919392716};\\\", \\\"{x:497,y:732,t:1526919392731};\\\", \\\"{x:499,y:732,t:1526919392748};\\\", \\\"{x:501,y:732,t:1526919392764};\\\", \\\"{x:504,y:732,t:1526919392781};\\\", \\\"{x:506,y:732,t:1526919392798};\\\", \\\"{x:512,y:732,t:1526919392814};\\\", \\\"{x:519,y:732,t:1526919392831};\\\", \\\"{x:526,y:730,t:1526919392847};\\\", \\\"{x:532,y:730,t:1526919392864};\\\", \\\"{x:539,y:729,t:1526919392881};\\\", \\\"{x:552,y:729,t:1526919392897};\\\", \\\"{x:574,y:729,t:1526919392914};\\\", \\\"{x:601,y:729,t:1526919392930};\\\", \\\"{x:631,y:729,t:1526919392947};\\\", \\\"{x:694,y:731,t:1526919392964};\\\", \\\"{x:725,y:736,t:1526919392980};\\\", \\\"{x:748,y:738,t:1526919392997};\\\", \\\"{x:769,y:741,t:1526919393014};\\\", \\\"{x:786,y:742,t:1526919393030};\\\", \\\"{x:805,y:747,t:1526919393047};\\\", \\\"{x:826,y:748,t:1526919393065};\\\", \\\"{x:850,y:748,t:1526919393080};\\\", \\\"{x:882,y:748,t:1526919393097};\\\", \\\"{x:909,y:749,t:1526919393114};\\\", \\\"{x:943,y:753,t:1526919393130};\\\", \\\"{x:972,y:756,t:1526919393148};\\\", \\\"{x:1023,y:763,t:1526919393164};\\\", \\\"{x:1051,y:767,t:1526919393180};\\\", \\\"{x:1090,y:774,t:1526919393198};\\\", \\\"{x:1129,y:779,t:1526919393215};\\\", \\\"{x:1166,y:785,t:1526919393231};\\\", \\\"{x:1209,y:792,t:1526919393248};\\\", \\\"{x:1241,y:795,t:1526919393265};\\\", \\\"{x:1268,y:805,t:1526919393282};\\\", \\\"{x:1299,y:813,t:1526919393298};\\\", \\\"{x:1335,y:826,t:1526919393315};\\\", \\\"{x:1360,y:832,t:1526919393332};\\\", \\\"{x:1380,y:844,t:1526919393348};\\\", \\\"{x:1397,y:860,t:1526919393364};\\\", \\\"{x:1403,y:877,t:1526919393382};\\\", \\\"{x:1409,y:896,t:1526919393398};\\\", \\\"{x:1413,y:917,t:1526919393415};\\\", \\\"{x:1418,y:935,t:1526919393432};\\\", \\\"{x:1421,y:947,t:1526919393448};\\\", \\\"{x:1424,y:955,t:1526919393465};\\\", \\\"{x:1424,y:958,t:1526919393482};\\\", \\\"{x:1424,y:961,t:1526919393498};\\\", \\\"{x:1423,y:964,t:1526919393516};\\\", \\\"{x:1421,y:967,t:1526919393532};\\\", \\\"{x:1420,y:971,t:1526919393549};\\\", \\\"{x:1415,y:980,t:1526919393564};\\\", \\\"{x:1413,y:986,t:1526919393583};\\\", \\\"{x:1409,y:992,t:1526919393598};\\\", \\\"{x:1405,y:999,t:1526919393615};\\\", \\\"{x:1403,y:1001,t:1526919393632};\\\", \\\"{x:1400,y:1005,t:1526919393648};\\\", \\\"{x:1397,y:1008,t:1526919393665};\\\", \\\"{x:1393,y:1011,t:1526919393682};\\\", \\\"{x:1390,y:1011,t:1526919393698};\\\", \\\"{x:1386,y:1014,t:1526919393714};\\\", \\\"{x:1384,y:1014,t:1526919393788};\\\", \\\"{x:1383,y:1014,t:1526919393805};\\\", \\\"{x:1381,y:1014,t:1526919393821};\\\", \\\"{x:1380,y:1014,t:1526919393844};\\\", \\\"{x:1378,y:1014,t:1526919393861};\\\", \\\"{x:1377,y:1014,t:1526919393869};\\\", \\\"{x:1375,y:1014,t:1526919393881};\\\", \\\"{x:1374,y:1014,t:1526919393899};\\\", \\\"{x:1373,y:1014,t:1526919393957};\\\", \\\"{x:1372,y:1014,t:1526919393988};\\\", \\\"{x:1371,y:1014,t:1526919393999};\\\", \\\"{x:1369,y:1014,t:1526919394060};\\\", \\\"{x:1368,y:1015,t:1526919394109};\\\", \\\"{x:1367,y:1015,t:1526919394214};\\\", \\\"{x:1365,y:1015,t:1526919394221};\\\", \\\"{x:1364,y:1015,t:1526919394231};\\\", \\\"{x:1358,y:1013,t:1526919394249};\\\", \\\"{x:1353,y:1009,t:1526919394266};\\\", \\\"{x:1351,y:1009,t:1526919394282};\\\", \\\"{x:1349,y:1008,t:1526919394299};\\\", \\\"{x:1348,y:1008,t:1526919394316};\\\", \\\"{x:1347,y:1007,t:1526919394332};\\\", \\\"{x:1346,y:1006,t:1526919394349};\\\", \\\"{x:1346,y:1005,t:1526919394374};\\\", \\\"{x:1346,y:1004,t:1526919394470};\\\", \\\"{x:1346,y:1003,t:1526919394501};\\\", \\\"{x:1346,y:1002,t:1526919394525};\\\", \\\"{x:1346,y:1001,t:1526919394541};\\\", \\\"{x:1346,y:1000,t:1526919394549};\\\", \\\"{x:1346,y:998,t:1526919394565};\\\", \\\"{x:1345,y:996,t:1526919394582};\\\", \\\"{x:1345,y:994,t:1526919394599};\\\", \\\"{x:1345,y:992,t:1526919394616};\\\", \\\"{x:1345,y:990,t:1526919394632};\\\", \\\"{x:1345,y:989,t:1526919394649};\\\", \\\"{x:1344,y:985,t:1526919394666};\\\", \\\"{x:1343,y:983,t:1526919394683};\\\", \\\"{x:1342,y:981,t:1526919394699};\\\", \\\"{x:1342,y:980,t:1526919394716};\\\", \\\"{x:1342,y:979,t:1526919394741};\\\", \\\"{x:1342,y:978,t:1526919394757};\\\", \\\"{x:1342,y:977,t:1526919394766};\\\", \\\"{x:1342,y:975,t:1526919394783};\\\", \\\"{x:1342,y:972,t:1526919394799};\\\", \\\"{x:1342,y:969,t:1526919394816};\\\", \\\"{x:1342,y:967,t:1526919394834};\\\", \\\"{x:1343,y:965,t:1526919394849};\\\", \\\"{x:1345,y:963,t:1526919394866};\\\", \\\"{x:1346,y:960,t:1526919394883};\\\", \\\"{x:1347,y:960,t:1526919394899};\\\", \\\"{x:1349,y:960,t:1526919394998};\\\", \\\"{x:1350,y:960,t:1526919395029};\\\", \\\"{x:1350,y:959,t:1526919395166};\\\", \\\"{x:1350,y:958,t:1526919395183};\\\", \\\"{x:1351,y:956,t:1526919395200};\\\", \\\"{x:1351,y:955,t:1526919395326};\\\", \\\"{x:1351,y:954,t:1526919395341};\\\", \\\"{x:1351,y:953,t:1526919395357};\\\", \\\"{x:1351,y:952,t:1526919395367};\\\", \\\"{x:1351,y:951,t:1526919395389};\\\", \\\"{x:1351,y:950,t:1526919395400};\\\", \\\"{x:1351,y:949,t:1526919395416};\\\", \\\"{x:1350,y:947,t:1526919395433};\\\", \\\"{x:1347,y:945,t:1526919395450};\\\", \\\"{x:1338,y:941,t:1526919395466};\\\", \\\"{x:1321,y:937,t:1526919395483};\\\", \\\"{x:1296,y:931,t:1526919395499};\\\", \\\"{x:1266,y:928,t:1526919395516};\\\", \\\"{x:1179,y:911,t:1526919395532};\\\", \\\"{x:1122,y:900,t:1526919395549};\\\", \\\"{x:1081,y:897,t:1526919395565};\\\", \\\"{x:1053,y:897,t:1526919395582};\\\", \\\"{x:1026,y:892,t:1526919395599};\\\", \\\"{x:1003,y:890,t:1526919395616};\\\", \\\"{x:979,y:885,t:1526919395632};\\\", \\\"{x:954,y:879,t:1526919395650};\\\", \\\"{x:923,y:869,t:1526919395666};\\\", \\\"{x:886,y:856,t:1526919395683};\\\", \\\"{x:841,y:844,t:1526919395699};\\\", \\\"{x:774,y:815,t:1526919395716};\\\", \\\"{x:739,y:787,t:1526919395732};\\\", \\\"{x:687,y:746,t:1526919395750};\\\", \\\"{x:627,y:694,t:1526919395767};\\\", \\\"{x:585,y:658,t:1526919395783};\\\", \\\"{x:563,y:634,t:1526919395800};\\\", \\\"{x:549,y:613,t:1526919395819};\\\", \\\"{x:538,y:592,t:1526919395833};\\\", \\\"{x:527,y:574,t:1526919395849};\\\", \\\"{x:517,y:557,t:1526919395867};\\\", \\\"{x:508,y:546,t:1526919395884};\\\", \\\"{x:503,y:537,t:1526919395899};\\\", \\\"{x:497,y:526,t:1526919395917};\\\", \\\"{x:494,y:520,t:1526919395934};\\\", \\\"{x:493,y:512,t:1526919395950};\\\", \\\"{x:489,y:502,t:1526919395966};\\\", \\\"{x:488,y:496,t:1526919395984};\\\", \\\"{x:488,y:493,t:1526919396000};\\\", \\\"{x:490,y:492,t:1526919396017};\\\", \\\"{x:504,y:492,t:1526919396034};\\\", \\\"{x:526,y:488,t:1526919396050};\\\", \\\"{x:547,y:487,t:1526919396066};\\\", \\\"{x:565,y:487,t:1526919396083};\\\", \\\"{x:586,y:489,t:1526919396100};\\\", \\\"{x:598,y:493,t:1526919396117};\\\", \\\"{x:602,y:494,t:1526919396134};\\\", \\\"{x:607,y:494,t:1526919396151};\\\", \\\"{x:614,y:495,t:1526919396167};\\\", \\\"{x:629,y:497,t:1526919396183};\\\", \\\"{x:656,y:497,t:1526919396200};\\\", \\\"{x:712,y:497,t:1526919396217};\\\", \\\"{x:788,y:495,t:1526919396234};\\\", \\\"{x:830,y:493,t:1526919396251};\\\", \\\"{x:870,y:493,t:1526919396267};\\\", \\\"{x:893,y:493,t:1526919396284};\\\", \\\"{x:902,y:493,t:1526919396300};\\\", \\\"{x:902,y:494,t:1526919396324};\\\", \\\"{x:902,y:496,t:1526919396333};\\\", \\\"{x:900,y:502,t:1526919396351};\\\", \\\"{x:899,y:507,t:1526919396367};\\\", \\\"{x:898,y:509,t:1526919396383};\\\", \\\"{x:897,y:511,t:1526919396401};\\\", \\\"{x:895,y:511,t:1526919396421};\\\", \\\"{x:893,y:511,t:1526919396434};\\\", \\\"{x:886,y:511,t:1526919396451};\\\", \\\"{x:870,y:511,t:1526919396466};\\\", \\\"{x:848,y:506,t:1526919396485};\\\", \\\"{x:813,y:500,t:1526919396501};\\\", \\\"{x:799,y:497,t:1526919396517};\\\", \\\"{x:795,y:496,t:1526919396534};\\\", \\\"{x:796,y:496,t:1526919396669};\\\", \\\"{x:798,y:497,t:1526919396684};\\\", \\\"{x:799,y:498,t:1526919396701};\\\", \\\"{x:801,y:499,t:1526919396717};\\\", \\\"{x:802,y:499,t:1526919396735};\\\", \\\"{x:804,y:499,t:1526919396893};\\\", \\\"{x:805,y:499,t:1526919396901};\\\", \\\"{x:810,y:499,t:1526919396919};\\\", \\\"{x:813,y:499,t:1526919396935};\\\", \\\"{x:815,y:499,t:1526919396952};\\\", \\\"{x:817,y:499,t:1526919396969};\\\", \\\"{x:819,y:499,t:1526919396984};\\\", \\\"{x:823,y:501,t:1526919397002};\\\", \\\"{x:825,y:501,t:1526919397019};\\\", \\\"{x:827,y:502,t:1526919397037};\\\", \\\"{x:829,y:502,t:1526919397051};\\\", \\\"{x:830,y:502,t:1526919397076};\\\", \\\"{x:831,y:502,t:1526919397172};\\\", \\\"{x:832,y:503,t:1526919397185};\\\", \\\"{x:832,y:504,t:1526919397237};\\\", \\\"{x:829,y:504,t:1526919397468};\\\", \\\"{x:821,y:508,t:1526919397484};\\\", \\\"{x:808,y:514,t:1526919397501};\\\", \\\"{x:772,y:521,t:1526919397518};\\\", \\\"{x:721,y:531,t:1526919397535};\\\", \\\"{x:640,y:544,t:1526919397552};\\\", \\\"{x:553,y:549,t:1526919397568};\\\", \\\"{x:466,y:555,t:1526919397585};\\\", \\\"{x:398,y:559,t:1526919397602};\\\", \\\"{x:353,y:559,t:1526919397617};\\\", \\\"{x:326,y:562,t:1526919397635};\\\", \\\"{x:310,y:564,t:1526919397651};\\\", \\\"{x:308,y:566,t:1526919397668};\\\", \\\"{x:307,y:567,t:1526919397685};\\\", \\\"{x:306,y:567,t:1526919397797};\\\", \\\"{x:306,y:566,t:1526919397813};\\\", \\\"{x:305,y:563,t:1526919397829};\\\", \\\"{x:304,y:562,t:1526919397837};\\\", \\\"{x:301,y:559,t:1526919397852};\\\", \\\"{x:298,y:559,t:1526919397868};\\\", \\\"{x:275,y:552,t:1526919397885};\\\", \\\"{x:251,y:549,t:1526919397902};\\\", \\\"{x:224,y:547,t:1526919397918};\\\", \\\"{x:204,y:546,t:1526919397934};\\\", \\\"{x:192,y:546,t:1526919397952};\\\", \\\"{x:185,y:546,t:1526919397969};\\\", \\\"{x:183,y:546,t:1526919397984};\\\", \\\"{x:182,y:546,t:1526919398005};\\\", \\\"{x:181,y:544,t:1526919398245};\\\", \\\"{x:176,y:543,t:1526919398253};\\\", \\\"{x:169,y:542,t:1526919398269};\\\", \\\"{x:162,y:540,t:1526919398285};\\\", \\\"{x:156,y:539,t:1526919398301};\\\", \\\"{x:149,y:538,t:1526919398319};\\\", \\\"{x:148,y:537,t:1526919398350};\\\", \\\"{x:149,y:537,t:1526919398677};\\\", \\\"{x:150,y:537,t:1526919398685};\\\", \\\"{x:151,y:537,t:1526919398701};\\\", \\\"{x:154,y:537,t:1526919399037};\\\", \\\"{x:157,y:536,t:1526919399052};\\\", \\\"{x:187,y:530,t:1526919399069};\\\", \\\"{x:217,y:523,t:1526919399087};\\\", \\\"{x:262,y:516,t:1526919399102};\\\", \\\"{x:335,y:505,t:1526919399120};\\\", \\\"{x:423,y:496,t:1526919399135};\\\", \\\"{x:522,y:486,t:1526919399152};\\\", \\\"{x:611,y:475,t:1526919399170};\\\", \\\"{x:687,y:470,t:1526919399185};\\\", \\\"{x:752,y:466,t:1526919399203};\\\", \\\"{x:838,y:459,t:1526919399218};\\\", \\\"{x:920,y:454,t:1526919399235};\\\", \\\"{x:1023,y:452,t:1526919399252};\\\", \\\"{x:1071,y:452,t:1526919399270};\\\", \\\"{x:1114,y:455,t:1526919399286};\\\", \\\"{x:1156,y:467,t:1526919399303};\\\", \\\"{x:1195,y:484,t:1526919399320};\\\", \\\"{x:1230,y:504,t:1526919399336};\\\", \\\"{x:1252,y:523,t:1526919399353};\\\", \\\"{x:1266,y:538,t:1526919399370};\\\", \\\"{x:1281,y:557,t:1526919399386};\\\", \\\"{x:1301,y:574,t:1526919399404};\\\", \\\"{x:1328,y:593,t:1526919399420};\\\", \\\"{x:1344,y:605,t:1526919399436};\\\", \\\"{x:1365,y:619,t:1526919399453};\\\", \\\"{x:1382,y:629,t:1526919399469};\\\", \\\"{x:1402,y:640,t:1526919399485};\\\", \\\"{x:1421,y:651,t:1526919399502};\\\", \\\"{x:1441,y:667,t:1526919399520};\\\", \\\"{x:1459,y:685,t:1526919399535};\\\", \\\"{x:1471,y:708,t:1526919399553};\\\", \\\"{x:1476,y:730,t:1526919399570};\\\", \\\"{x:1477,y:753,t:1526919399585};\\\", \\\"{x:1477,y:774,t:1526919399603};\\\", \\\"{x:1477,y:793,t:1526919399620};\\\", \\\"{x:1472,y:806,t:1526919399636};\\\", \\\"{x:1465,y:825,t:1526919399653};\\\", \\\"{x:1460,y:833,t:1526919399670};\\\", \\\"{x:1453,y:840,t:1526919399686};\\\", \\\"{x:1445,y:844,t:1526919399703};\\\", \\\"{x:1436,y:845,t:1526919399720};\\\", \\\"{x:1429,y:852,t:1526919399737};\\\", \\\"{x:1418,y:858,t:1526919399753};\\\", \\\"{x:1412,y:864,t:1526919399769};\\\", \\\"{x:1408,y:870,t:1526919399786};\\\", \\\"{x:1405,y:883,t:1526919399803};\\\", \\\"{x:1401,y:903,t:1526919399820};\\\", \\\"{x:1395,y:934,t:1526919399837};\\\", \\\"{x:1393,y:952,t:1526919399853};\\\", \\\"{x:1392,y:964,t:1526919399870};\\\", \\\"{x:1390,y:978,t:1526919399888};\\\", \\\"{x:1389,y:990,t:1526919399902};\\\", \\\"{x:1387,y:1004,t:1526919399920};\\\", \\\"{x:1386,y:1013,t:1526919399936};\\\", \\\"{x:1384,y:1019,t:1526919399956};\\\", \\\"{x:1383,y:1021,t:1526919399974};\\\", \\\"{x:1381,y:1024,t:1526919399990};\\\", \\\"{x:1376,y:1025,t:1526919400007};\\\", \\\"{x:1369,y:1025,t:1526919400023};\\\", \\\"{x:1354,y:1025,t:1526919400041};\\\", \\\"{x:1346,y:1020,t:1526919400058};\\\", \\\"{x:1340,y:1012,t:1526919400073};\\\", \\\"{x:1339,y:1002,t:1526919400091};\\\", \\\"{x:1336,y:990,t:1526919400107};\\\", \\\"{x:1336,y:983,t:1526919400124};\\\", \\\"{x:1336,y:979,t:1526919400140};\\\", \\\"{x:1336,y:978,t:1526919400161};\\\", \\\"{x:1337,y:976,t:1526919400193};\\\", \\\"{x:1339,y:975,t:1526919400241};\\\", \\\"{x:1340,y:973,t:1526919400258};\\\", \\\"{x:1341,y:968,t:1526919400274};\\\", \\\"{x:1342,y:961,t:1526919400291};\\\", \\\"{x:1342,y:957,t:1526919400308};\\\", \\\"{x:1343,y:950,t:1526919400323};\\\", \\\"{x:1343,y:940,t:1526919400341};\\\", \\\"{x:1343,y:932,t:1526919400358};\\\", \\\"{x:1341,y:919,t:1526919400374};\\\", \\\"{x:1338,y:907,t:1526919400391};\\\", \\\"{x:1337,y:901,t:1526919400408};\\\", \\\"{x:1337,y:897,t:1526919400424};\\\", \\\"{x:1337,y:896,t:1526919400441};\\\", \\\"{x:1337,y:893,t:1526919400458};\\\", \\\"{x:1337,y:890,t:1526919400474};\\\", \\\"{x:1337,y:887,t:1526919400490};\\\", \\\"{x:1337,y:884,t:1526919400507};\\\", \\\"{x:1337,y:879,t:1526919400523};\\\", \\\"{x:1337,y:876,t:1526919400541};\\\", \\\"{x:1337,y:869,t:1526919400557};\\\", \\\"{x:1338,y:861,t:1526919400575};\\\", \\\"{x:1338,y:851,t:1526919400590};\\\", \\\"{x:1338,y:841,t:1526919400607};\\\", \\\"{x:1336,y:824,t:1526919400623};\\\", \\\"{x:1333,y:815,t:1526919400641};\\\", \\\"{x:1331,y:809,t:1526919400657};\\\", \\\"{x:1328,y:800,t:1526919400674};\\\", \\\"{x:1325,y:788,t:1526919400691};\\\", \\\"{x:1323,y:779,t:1526919400708};\\\", \\\"{x:1322,y:773,t:1526919400725};\\\", \\\"{x:1319,y:765,t:1526919400741};\\\", \\\"{x:1319,y:760,t:1526919400758};\\\", \\\"{x:1319,y:755,t:1526919400775};\\\", \\\"{x:1319,y:751,t:1526919400791};\\\", \\\"{x:1319,y:747,t:1526919400808};\\\", \\\"{x:1320,y:742,t:1526919400824};\\\", \\\"{x:1320,y:737,t:1526919400841};\\\", \\\"{x:1322,y:733,t:1526919400858};\\\", \\\"{x:1323,y:727,t:1526919400875};\\\", \\\"{x:1324,y:721,t:1526919400890};\\\", \\\"{x:1324,y:717,t:1526919400907};\\\", \\\"{x:1326,y:710,t:1526919400925};\\\", \\\"{x:1328,y:705,t:1526919400941};\\\", \\\"{x:1328,y:702,t:1526919400958};\\\", \\\"{x:1330,y:697,t:1526919400975};\\\", \\\"{x:1330,y:695,t:1526919400991};\\\", \\\"{x:1330,y:692,t:1526919401008};\\\", \\\"{x:1330,y:687,t:1526919401024};\\\", \\\"{x:1331,y:683,t:1526919401042};\\\", \\\"{x:1331,y:681,t:1526919401058};\\\", \\\"{x:1331,y:678,t:1526919401075};\\\", \\\"{x:1331,y:677,t:1526919401092};\\\", \\\"{x:1331,y:675,t:1526919401108};\\\", \\\"{x:1331,y:674,t:1526919401125};\\\", \\\"{x:1330,y:674,t:1526919401521};\\\", \\\"{x:1327,y:675,t:1526919401528};\\\", \\\"{x:1326,y:676,t:1526919401542};\\\", \\\"{x:1326,y:677,t:1526919401761};\\\", \\\"{x:1328,y:678,t:1526919401775};\\\", \\\"{x:1330,y:678,t:1526919401792};\\\", \\\"{x:1326,y:678,t:1526919401809};\\\", \\\"{x:1319,y:677,t:1526919401824};\\\", \\\"{x:1313,y:677,t:1526919401842};\\\", \\\"{x:1301,y:675,t:1526919401859};\\\", \\\"{x:1288,y:675,t:1526919401875};\\\", \\\"{x:1276,y:675,t:1526919401892};\\\", \\\"{x:1261,y:675,t:1526919401909};\\\", \\\"{x:1247,y:673,t:1526919401926};\\\", \\\"{x:1230,y:673,t:1526919401942};\\\", \\\"{x:1215,y:673,t:1526919401959};\\\", \\\"{x:1182,y:673,t:1526919401976};\\\", \\\"{x:1153,y:674,t:1526919401992};\\\", \\\"{x:1106,y:682,t:1526919402008};\\\", \\\"{x:1081,y:685,t:1526919402026};\\\", \\\"{x:1061,y:691,t:1526919402043};\\\", \\\"{x:1040,y:696,t:1526919402059};\\\", \\\"{x:1011,y:705,t:1526919402076};\\\", \\\"{x:982,y:714,t:1526919402091};\\\", \\\"{x:955,y:723,t:1526919402109};\\\", \\\"{x:937,y:731,t:1526919402126};\\\", \\\"{x:923,y:736,t:1526919402141};\\\", \\\"{x:918,y:737,t:1526919402159};\\\", \\\"{x:918,y:738,t:1526919402175};\\\", \\\"{x:917,y:738,t:1526919402273};\\\", \\\"{x:917,y:739,t:1526919402281};\\\", \\\"{x:917,y:740,t:1526919402688};\\\", \\\"{x:917,y:743,t:1526919402880};\\\", \\\"{x:919,y:749,t:1526919402892};\\\", \\\"{x:945,y:770,t:1526919402910};\\\", \\\"{x:999,y:797,t:1526919402925};\\\", \\\"{x:1080,y:825,t:1526919402942};\\\", \\\"{x:1190,y:867,t:1526919402960};\\\", \\\"{x:1308,y:913,t:1526919402975};\\\", \\\"{x:1440,y:980,t:1526919402992};\\\", \\\"{x:1478,y:1015,t:1526919403009};\\\", \\\"{x:1488,y:1036,t:1526919403026};\\\", \\\"{x:1490,y:1054,t:1526919403043};\\\", \\\"{x:1490,y:1070,t:1526919403060};\\\", \\\"{x:1488,y:1074,t:1526919403076};\\\", \\\"{x:1488,y:1075,t:1526919403121};\\\", \\\"{x:1488,y:1073,t:1526919403136};\\\", \\\"{x:1488,y:1070,t:1526919403144};\\\", \\\"{x:1488,y:1069,t:1526919403160};\\\", \\\"{x:1488,y:1062,t:1526919403175};\\\", \\\"{x:1485,y:1048,t:1526919403193};\\\", \\\"{x:1473,y:1038,t:1526919403210};\\\", \\\"{x:1455,y:1027,t:1526919403227};\\\", \\\"{x:1435,y:1022,t:1526919403244};\\\", \\\"{x:1417,y:1016,t:1526919403260};\\\", \\\"{x:1402,y:1011,t:1526919403278};\\\", \\\"{x:1394,y:1009,t:1526919403293};\\\", \\\"{x:1393,y:1008,t:1526919403310};\\\", \\\"{x:1392,y:1007,t:1526919403327};\\\", \\\"{x:1392,y:1005,t:1526919403352};\\\", \\\"{x:1390,y:1004,t:1526919403360};\\\", \\\"{x:1388,y:1003,t:1526919403376};\\\", \\\"{x:1384,y:1001,t:1526919403393};\\\", \\\"{x:1382,y:1000,t:1526919403409};\\\", \\\"{x:1382,y:999,t:1526919403426};\\\", \\\"{x:1381,y:998,t:1526919403443};\\\", \\\"{x:1380,y:997,t:1526919403460};\\\", \\\"{x:1378,y:994,t:1526919403478};\\\", \\\"{x:1378,y:991,t:1526919403493};\\\", \\\"{x:1375,y:988,t:1526919403510};\\\", \\\"{x:1371,y:984,t:1526919403527};\\\", \\\"{x:1364,y:979,t:1526919403544};\\\", \\\"{x:1359,y:975,t:1526919403560};\\\", \\\"{x:1355,y:971,t:1526919403576};\\\", \\\"{x:1353,y:965,t:1526919403593};\\\", \\\"{x:1352,y:959,t:1526919403610};\\\", \\\"{x:1351,y:950,t:1526919403626};\\\", \\\"{x:1349,y:938,t:1526919403643};\\\", \\\"{x:1346,y:921,t:1526919403660};\\\", \\\"{x:1342,y:900,t:1526919403677};\\\", \\\"{x:1339,y:874,t:1526919403694};\\\", \\\"{x:1332,y:850,t:1526919403709};\\\", \\\"{x:1324,y:826,t:1526919403726};\\\", \\\"{x:1307,y:791,t:1526919403743};\\\", \\\"{x:1273,y:758,t:1526919403759};\\\", \\\"{x:1209,y:726,t:1526919403776};\\\", \\\"{x:1163,y:716,t:1526919403793};\\\", \\\"{x:1129,y:712,t:1526919403809};\\\", \\\"{x:1098,y:712,t:1526919403826};\\\", \\\"{x:1071,y:712,t:1526919403843};\\\", \\\"{x:1038,y:714,t:1526919403859};\\\", \\\"{x:991,y:720,t:1526919403877};\\\", \\\"{x:940,y:721,t:1526919403893};\\\", \\\"{x:873,y:721,t:1526919403910};\\\", \\\"{x:784,y:721,t:1526919403926};\\\", \\\"{x:693,y:721,t:1526919403943};\\\", \\\"{x:620,y:732,t:1526919403959};\\\", \\\"{x:582,y:755,t:1526919403977};\\\", \\\"{x:567,y:766,t:1526919403994};\\\", \\\"{x:561,y:773,t:1526919404010};\\\", \\\"{x:557,y:779,t:1526919404027};\\\", \\\"{x:554,y:784,t:1526919404044};\\\", \\\"{x:546,y:792,t:1526919404060};\\\", \\\"{x:537,y:802,t:1526919404078};\\\", \\\"{x:521,y:808,t:1526919404093};\\\", \\\"{x:502,y:811,t:1526919404110};\\\", \\\"{x:481,y:811,t:1526919404127};\\\", \\\"{x:458,y:809,t:1526919404143};\\\", \\\"{x:427,y:800,t:1526919404160};\\\", \\\"{x:419,y:795,t:1526919404177};\\\", \\\"{x:416,y:788,t:1526919404193};\\\", \\\"{x:416,y:782,t:1526919404211};\\\", \\\"{x:416,y:773,t:1526919404227};\\\", \\\"{x:416,y:762,t:1526919404244};\\\", \\\"{x:423,y:750,t:1526919404261};\\\", \\\"{x:433,y:737,t:1526919404278};\\\", \\\"{x:440,y:731,t:1526919404294};\\\", \\\"{x:445,y:728,t:1526919404311};\\\", \\\"{x:447,y:727,t:1526919404327};\\\", \\\"{x:451,y:726,t:1526919404343};\\\", \\\"{x:457,y:726,t:1526919404360};\\\", \\\"{x:466,y:725,t:1526919404376};\\\", \\\"{x:475,y:725,t:1526919404393};\\\", \\\"{x:478,y:725,t:1526919404410};\\\", \\\"{x:480,y:725,t:1526919404428};\\\", \\\"{x:482,y:725,t:1526919404443};\\\", \\\"{x:485,y:726,t:1526919404460};\\\", \\\"{x:486,y:727,t:1526919404477};\\\", \\\"{x:487,y:727,t:1526919404493};\\\", \\\"{x:488,y:727,t:1526919404519};\\\", \\\"{x:489,y:729,t:1526919404528};\\\", \\\"{x:491,y:730,t:1526919404543};\\\", \\\"{x:493,y:733,t:1526919404561};\\\", \\\"{x:494,y:733,t:1526919404577};\\\", \\\"{x:494,y:735,t:1526919404593};\\\", \\\"{x:495,y:736,t:1526919404610};\\\", \\\"{x:494,y:736,t:1526919405185};\\\", \\\"{x:489,y:736,t:1526919405195};\\\", \\\"{x:472,y:733,t:1526919405211};\\\", \\\"{x:450,y:727,t:1526919405227};\\\", \\\"{x:428,y:720,t:1526919405246};\\\", \\\"{x:424,y:719,t:1526919405261};\\\", \\\"{x:421,y:719,t:1526919405360};\\\", \\\"{x:417,y:719,t:1526919405367};\\\", \\\"{x:411,y:718,t:1526919405377};\\\", \\\"{x:391,y:711,t:1526919405395};\\\", \\\"{x:356,y:695,t:1526919405411};\\\", \\\"{x:296,y:669,t:1526919405429};\\\", \\\"{x:272,y:651,t:1526919405446};\\\", \\\"{x:252,y:627,t:1526919405462};\\\", \\\"{x:239,y:602,t:1526919405477};\\\", \\\"{x:229,y:581,t:1526919405495};\\\", \\\"{x:225,y:569,t:1526919405511};\\\", \\\"{x:224,y:565,t:1526919405527};\\\", \\\"{x:223,y:562,t:1526919405545};\\\", \\\"{x:222,y:560,t:1526919405562};\\\", \\\"{x:221,y:559,t:1526919405583};\\\", \\\"{x:221,y:558,t:1526919405599};\\\", \\\"{x:220,y:557,t:1526919405612};\\\", \\\"{x:214,y:555,t:1526919405628};\\\", \\\"{x:208,y:553,t:1526919405644};\\\", \\\"{x:197,y:550,t:1526919405661};\\\", \\\"{x:194,y:550,t:1526919405678};\\\", \\\"{x:194,y:549,t:1526919405735};\\\", \\\"{x:192,y:549,t:1526919405752};\\\", \\\"{x:190,y:549,t:1526919405762};\\\", \\\"{x:186,y:549,t:1526919405778};\\\", \\\"{x:181,y:549,t:1526919405794};\\\", \\\"{x:174,y:549,t:1526919405811};\\\", \\\"{x:169,y:549,t:1526919405829};\\\", \\\"{x:168,y:549,t:1526919405844};\\\", \\\"{x:167,y:548,t:1526919405863};\\\", \\\"{x:166,y:548,t:1526919405879};\\\", \\\"{x:165,y:546,t:1526919405894};\\\", \\\"{x:164,y:545,t:1526919405952};\\\", \\\"{x:171,y:545,t:1526919406216};\\\", \\\"{x:179,y:545,t:1526919406228};\\\", \\\"{x:210,y:549,t:1526919406246};\\\", \\\"{x:270,y:572,t:1526919406262};\\\", \\\"{x:333,y:598,t:1526919406279};\\\", \\\"{x:397,y:642,t:1526919406295};\\\", \\\"{x:435,y:670,t:1526919406312};\\\", \\\"{x:466,y:690,t:1526919406328};\\\", \\\"{x:487,y:711,t:1526919406346};\\\", \\\"{x:501,y:725,t:1526919406362};\\\", \\\"{x:507,y:732,t:1526919406379};\\\", \\\"{x:512,y:739,t:1526919406396};\\\", \\\"{x:519,y:748,t:1526919406411};\\\", \\\"{x:524,y:755,t:1526919406429};\\\", \\\"{x:526,y:759,t:1526919406445};\\\", \\\"{x:527,y:761,t:1526919406462};\\\", \\\"{x:527,y:762,t:1526919406479};\\\", \\\"{x:527,y:763,t:1526919406536};\\\", \\\"{x:526,y:762,t:1526919406625};\\\", \\\"{x:524,y:759,t:1526919406632};\\\", \\\"{x:522,y:757,t:1526919406646};\\\", \\\"{x:519,y:750,t:1526919406663};\\\", \\\"{x:517,y:746,t:1526919406678};\\\", \\\"{x:515,y:738,t:1526919406696};\\\", \\\"{x:514,y:733,t:1526919406712};\\\", \\\"{x:514,y:731,t:1526919406729};\\\", \\\"{x:512,y:730,t:1526919407608};\\\" ] }, { \\\"rt\\\": 7450, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 795714, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:729,t:1526919408920};\\\", \\\"{x:511,y:722,t:1526919411321};\\\", \\\"{x:524,y:712,t:1526919411339};\\\", \\\"{x:544,y:697,t:1526919411355};\\\", \\\"{x:576,y:668,t:1526919411371};\\\", \\\"{x:618,y:629,t:1526919411387};\\\", \\\"{x:651,y:600,t:1526919411400};\\\", \\\"{x:674,y:577,t:1526919411416};\\\", \\\"{x:681,y:571,t:1526919411433};\\\", \\\"{x:683,y:569,t:1526919411449};\\\", \\\"{x:684,y:567,t:1526919411465};\\\", \\\"{x:686,y:563,t:1526919411482};\\\", \\\"{x:687,y:562,t:1526919411499};\\\", \\\"{x:689,y:558,t:1526919411516};\\\", \\\"{x:692,y:554,t:1526919411532};\\\", \\\"{x:696,y:549,t:1526919411549};\\\", \\\"{x:697,y:548,t:1526919411565};\\\", \\\"{x:697,y:547,t:1526919411583};\\\", \\\"{x:697,y:546,t:1526919411599};\\\", \\\"{x:686,y:546,t:1526919411615};\\\", \\\"{x:656,y:549,t:1526919411633};\\\", \\\"{x:585,y:554,t:1526919411649};\\\", \\\"{x:494,y:561,t:1526919411667};\\\", \\\"{x:416,y:574,t:1526919411683};\\\", \\\"{x:363,y:582,t:1526919411700};\\\", \\\"{x:335,y:583,t:1526919411717};\\\", \\\"{x:322,y:583,t:1526919411733};\\\", \\\"{x:317,y:584,t:1526919411750};\\\", \\\"{x:316,y:585,t:1526919411767};\\\", \\\"{x:315,y:585,t:1526919411800};\\\", \\\"{x:314,y:585,t:1526919411815};\\\", \\\"{x:313,y:585,t:1526919411832};\\\", \\\"{x:311,y:585,t:1526919411850};\\\", \\\"{x:309,y:585,t:1526919411866};\\\", \\\"{x:306,y:585,t:1526919411883};\\\", \\\"{x:293,y:585,t:1526919411899};\\\", \\\"{x:280,y:585,t:1526919411917};\\\", \\\"{x:267,y:585,t:1526919411934};\\\", \\\"{x:262,y:585,t:1526919411949};\\\", \\\"{x:258,y:585,t:1526919411966};\\\", \\\"{x:257,y:584,t:1526919411982};\\\", \\\"{x:255,y:583,t:1526919411999};\\\", \\\"{x:251,y:582,t:1526919412017};\\\", \\\"{x:245,y:581,t:1526919412033};\\\", \\\"{x:232,y:579,t:1526919412050};\\\", \\\"{x:214,y:574,t:1526919412066};\\\", \\\"{x:202,y:569,t:1526919412083};\\\", \\\"{x:188,y:563,t:1526919412100};\\\", \\\"{x:182,y:559,t:1526919412117};\\\", \\\"{x:177,y:556,t:1526919412133};\\\", \\\"{x:171,y:550,t:1526919412150};\\\", \\\"{x:166,y:544,t:1526919412167};\\\", \\\"{x:161,y:539,t:1526919412183};\\\", \\\"{x:159,y:536,t:1526919412199};\\\", \\\"{x:158,y:534,t:1526919412217};\\\", \\\"{x:157,y:533,t:1526919412232};\\\", \\\"{x:157,y:532,t:1526919412249};\\\", \\\"{x:158,y:532,t:1526919412366};\\\", \\\"{x:160,y:532,t:1526919412383};\\\", \\\"{x:160,y:532,t:1526919412460};\\\", \\\"{x:161,y:532,t:1526919412551};\\\", \\\"{x:166,y:532,t:1526919412566};\\\", \\\"{x:195,y:539,t:1526919412583};\\\", \\\"{x:237,y:555,t:1526919412599};\\\", \\\"{x:308,y:584,t:1526919412617};\\\", \\\"{x:395,y:615,t:1526919412634};\\\", \\\"{x:494,y:651,t:1526919412650};\\\", \\\"{x:575,y:696,t:1526919412667};\\\", \\\"{x:643,y:730,t:1526919412684};\\\", \\\"{x:678,y:751,t:1526919412699};\\\", \\\"{x:692,y:762,t:1526919412716};\\\", \\\"{x:697,y:768,t:1526919412734};\\\", \\\"{x:697,y:771,t:1526919412751};\\\", \\\"{x:697,y:773,t:1526919412767};\\\", \\\"{x:697,y:776,t:1526919412784};\\\", \\\"{x:697,y:778,t:1526919412800};\\\", \\\"{x:696,y:781,t:1526919412816};\\\", \\\"{x:692,y:784,t:1526919412834};\\\", \\\"{x:678,y:784,t:1526919412851};\\\", \\\"{x:654,y:784,t:1526919412866};\\\", \\\"{x:619,y:777,t:1526919412884};\\\", \\\"{x:577,y:765,t:1526919412901};\\\", \\\"{x:547,y:752,t:1526919412917};\\\", \\\"{x:519,y:740,t:1526919412934};\\\", \\\"{x:504,y:735,t:1526919412950};\\\", \\\"{x:498,y:733,t:1526919412967};\\\", \\\"{x:492,y:733,t:1526919412983};\\\", \\\"{x:488,y:733,t:1526919413001};\\\", \\\"{x:483,y:735,t:1526919413017};\\\", \\\"{x:482,y:736,t:1526919413034};\\\", \\\"{x:483,y:736,t:1526919413192};\\\", \\\"{x:485,y:736,t:1526919413201};\\\", \\\"{x:487,y:735,t:1526919413218};\\\", \\\"{x:490,y:734,t:1526919413234};\\\", \\\"{x:490,y:733,t:1526919413251};\\\", \\\"{x:491,y:732,t:1526919413328};\\\", \\\"{x:492,y:732,t:1526919413697};\\\", \\\"{x:493,y:732,t:1526919413704};\\\", \\\"{x:493,y:733,t:1526919413717};\\\", \\\"{x:494,y:733,t:1526919413735};\\\", \\\"{x:496,y:734,t:1526919413752};\\\", \\\"{x:497,y:735,t:1526919414088};\\\", \\\"{x:498,y:735,t:1526919414104};\\\", \\\"{x:499,y:736,t:1526919414118};\\\", \\\"{x:500,y:736,t:1526919414143};\\\", \\\"{x:501,y:736,t:1526919414152};\\\", \\\"{x:501,y:737,t:1526919414223};\\\", \\\"{x:500,y:737,t:1526919414904};\\\", \\\"{x:499,y:737,t:1526919415016};\\\", \\\"{x:498,y:737,t:1526919415089};\\\", \\\"{x:497,y:737,t:1526919415129};\\\", \\\"{x:496,y:736,t:1526919415144};\\\", \\\"{x:496,y:735,t:1526919416120};\\\", \\\"{x:495,y:734,t:1526919416273};\\\", \\\"{x:493,y:734,t:1526919416286};\\\", \\\"{x:485,y:731,t:1526919416303};\\\", \\\"{x:479,y:730,t:1526919416320};\\\" ] }, { \\\"rt\\\": 72855, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 869831, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-05 PM-04 PM-03 PM-04 PM-Z -Z -X -02 PM-11 AM-X -X -X -X -X -M -B -B -G -C -C -C -X -O -O -Z -X -C -M -M -B -B -B -B -02 PM-03 PM-03 PM-02 PM-01 PM-12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:728,t:1526919419944};\\\", \\\"{x:479,y:727,t:1526919419959};\\\", \\\"{x:479,y:725,t:1526919419975};\\\", \\\"{x:481,y:723,t:1526919419991};\\\", \\\"{x:483,y:721,t:1526919420007};\\\", \\\"{x:484,y:721,t:1526919420095};\\\", \\\"{x:483,y:722,t:1526919420119};\\\", \\\"{x:483,y:721,t:1526919420217};\\\", \\\"{x:483,y:719,t:1526919420233};\\\", \\\"{x:483,y:717,t:1526919420242};\\\", \\\"{x:484,y:716,t:1526919420258};\\\", \\\"{x:490,y:713,t:1526919420275};\\\", \\\"{x:500,y:709,t:1526919420290};\\\", \\\"{x:517,y:704,t:1526919420306};\\\", \\\"{x:538,y:699,t:1526919420322};\\\", \\\"{x:565,y:697,t:1526919420340};\\\", \\\"{x:593,y:691,t:1526919420355};\\\", \\\"{x:625,y:686,t:1526919420373};\\\", \\\"{x:665,y:679,t:1526919420389};\\\", \\\"{x:726,y:671,t:1526919420406};\\\", \\\"{x:804,y:660,t:1526919420423};\\\", \\\"{x:954,y:642,t:1526919420439};\\\", \\\"{x:1047,y:635,t:1526919420456};\\\", \\\"{x:1112,y:633,t:1526919420473};\\\", \\\"{x:1171,y:633,t:1526919420490};\\\", \\\"{x:1229,y:633,t:1526919420506};\\\", \\\"{x:1305,y:634,t:1526919420523};\\\", \\\"{x:1359,y:643,t:1526919420540};\\\", \\\"{x:1398,y:650,t:1526919420557};\\\", \\\"{x:1432,y:655,t:1526919420573};\\\", \\\"{x:1463,y:661,t:1526919420590};\\\", \\\"{x:1496,y:665,t:1526919420607};\\\", \\\"{x:1529,y:670,t:1526919420623};\\\", \\\"{x:1595,y:687,t:1526919420640};\\\", \\\"{x:1653,y:703,t:1526919420657};\\\", \\\"{x:1714,y:719,t:1526919420673};\\\", \\\"{x:1775,y:737,t:1526919420690};\\\", \\\"{x:1831,y:754,t:1526919420707};\\\", \\\"{x:1886,y:775,t:1526919420723};\\\", \\\"{x:1912,y:786,t:1526919420741};\\\", \\\"{x:1919,y:797,t:1526919420757};\\\", \\\"{x:1919,y:811,t:1526919420773};\\\", \\\"{x:1919,y:833,t:1526919420790};\\\", \\\"{x:1919,y:858,t:1526919420807};\\\", \\\"{x:1919,y:881,t:1526919420823};\\\", \\\"{x:1919,y:904,t:1526919420840};\\\", \\\"{x:1919,y:915,t:1526919420857};\\\", \\\"{x:1910,y:927,t:1526919420873};\\\", \\\"{x:1898,y:940,t:1526919420890};\\\", \\\"{x:1882,y:952,t:1526919420908};\\\", \\\"{x:1869,y:957,t:1526919420923};\\\", \\\"{x:1856,y:959,t:1526919420941};\\\", \\\"{x:1848,y:961,t:1526919420957};\\\", \\\"{x:1838,y:962,t:1526919420973};\\\", \\\"{x:1832,y:964,t:1526919420990};\\\", \\\"{x:1826,y:965,t:1526919421008};\\\", \\\"{x:1809,y:966,t:1526919421024};\\\", \\\"{x:1790,y:968,t:1526919421040};\\\", \\\"{x:1765,y:971,t:1526919421057};\\\", \\\"{x:1741,y:971,t:1526919421073};\\\", \\\"{x:1711,y:971,t:1526919421091};\\\", \\\"{x:1681,y:974,t:1526919421107};\\\", \\\"{x:1654,y:974,t:1526919421124};\\\", \\\"{x:1632,y:974,t:1526919421140};\\\", \\\"{x:1613,y:974,t:1526919421157};\\\", \\\"{x:1591,y:974,t:1526919421174};\\\", \\\"{x:1571,y:974,t:1526919421190};\\\", \\\"{x:1540,y:974,t:1526919421208};\\\", \\\"{x:1519,y:965,t:1526919421223};\\\", \\\"{x:1489,y:956,t:1526919421240};\\\", \\\"{x:1466,y:951,t:1526919421256};\\\", \\\"{x:1446,y:948,t:1526919421274};\\\", \\\"{x:1435,y:948,t:1526919421290};\\\", \\\"{x:1427,y:948,t:1526919421307};\\\", \\\"{x:1420,y:948,t:1526919421324};\\\", \\\"{x:1416,y:946,t:1526919421340};\\\", \\\"{x:1411,y:942,t:1526919421357};\\\", \\\"{x:1405,y:936,t:1526919421374};\\\", \\\"{x:1397,y:931,t:1526919421390};\\\", \\\"{x:1383,y:922,t:1526919421407};\\\", \\\"{x:1376,y:917,t:1526919421424};\\\", \\\"{x:1372,y:910,t:1526919421440};\\\", \\\"{x:1367,y:901,t:1526919421457};\\\", \\\"{x:1362,y:892,t:1526919421474};\\\", \\\"{x:1355,y:884,t:1526919421491};\\\", \\\"{x:1348,y:876,t:1526919421507};\\\", \\\"{x:1344,y:874,t:1526919421525};\\\", \\\"{x:1341,y:872,t:1526919421541};\\\", \\\"{x:1337,y:871,t:1526919421557};\\\", \\\"{x:1322,y:865,t:1526919421574};\\\", \\\"{x:1297,y:860,t:1526919421591};\\\", \\\"{x:1267,y:850,t:1526919421607};\\\", \\\"{x:1225,y:838,t:1526919421624};\\\", \\\"{x:1206,y:828,t:1526919421642};\\\", \\\"{x:1191,y:815,t:1526919421657};\\\", \\\"{x:1172,y:798,t:1526919421674};\\\", \\\"{x:1156,y:783,t:1526919421691};\\\", \\\"{x:1145,y:776,t:1526919421708};\\\", \\\"{x:1143,y:773,t:1526919421724};\\\", \\\"{x:1142,y:771,t:1526919421742};\\\", \\\"{x:1142,y:768,t:1526919421757};\\\", \\\"{x:1141,y:761,t:1526919421774};\\\", \\\"{x:1141,y:748,t:1526919421791};\\\", \\\"{x:1141,y:737,t:1526919421807};\\\", \\\"{x:1148,y:719,t:1526919421824};\\\", \\\"{x:1156,y:705,t:1526919421842};\\\", \\\"{x:1164,y:692,t:1526919421858};\\\", \\\"{x:1179,y:676,t:1526919421874};\\\", \\\"{x:1198,y:661,t:1526919421891};\\\", \\\"{x:1213,y:649,t:1526919421907};\\\", \\\"{x:1223,y:639,t:1526919421925};\\\", \\\"{x:1231,y:629,t:1526919421942};\\\", \\\"{x:1233,y:625,t:1526919421958};\\\", \\\"{x:1236,y:618,t:1526919421974};\\\", \\\"{x:1237,y:606,t:1526919421991};\\\", \\\"{x:1238,y:575,t:1526919422008};\\\", \\\"{x:1238,y:556,t:1526919422024};\\\", \\\"{x:1240,y:538,t:1526919422041};\\\", \\\"{x:1240,y:519,t:1526919422059};\\\", \\\"{x:1240,y:504,t:1526919422075};\\\", \\\"{x:1240,y:489,t:1526919422091};\\\", \\\"{x:1240,y:479,t:1526919422108};\\\", \\\"{x:1240,y:474,t:1526919422124};\\\", \\\"{x:1241,y:465,t:1526919422142};\\\", \\\"{x:1243,y:457,t:1526919422159};\\\", \\\"{x:1245,y:451,t:1526919422175};\\\", \\\"{x:1249,y:442,t:1526919422192};\\\", \\\"{x:1254,y:436,t:1526919422208};\\\", \\\"{x:1257,y:433,t:1526919422224};\\\", \\\"{x:1262,y:428,t:1526919422241};\\\", \\\"{x:1272,y:423,t:1526919422258};\\\", \\\"{x:1280,y:420,t:1526919422275};\\\", \\\"{x:1286,y:418,t:1526919422292};\\\", \\\"{x:1290,y:416,t:1526919422309};\\\", \\\"{x:1292,y:415,t:1526919422325};\\\", \\\"{x:1292,y:414,t:1526919422341};\\\", \\\"{x:1294,y:414,t:1526919422457};\\\", \\\"{x:1295,y:412,t:1526919422464};\\\", \\\"{x:1296,y:410,t:1526919422475};\\\", \\\"{x:1300,y:403,t:1526919422491};\\\", \\\"{x:1311,y:391,t:1526919422509};\\\", \\\"{x:1329,y:375,t:1526919422526};\\\", \\\"{x:1355,y:351,t:1526919422541};\\\", \\\"{x:1384,y:330,t:1526919422559};\\\", \\\"{x:1436,y:293,t:1526919422576};\\\", \\\"{x:1450,y:282,t:1526919422592};\\\", \\\"{x:1493,y:251,t:1526919422609};\\\", \\\"{x:1515,y:235,t:1526919422626};\\\", \\\"{x:1530,y:223,t:1526919422642};\\\", \\\"{x:1544,y:211,t:1526919422658};\\\", \\\"{x:1553,y:207,t:1526919422675};\\\", \\\"{x:1555,y:205,t:1526919422692};\\\", \\\"{x:1556,y:205,t:1526919422728};\\\", \\\"{x:1558,y:205,t:1526919422744};\\\", \\\"{x:1559,y:206,t:1526919422760};\\\", \\\"{x:1559,y:207,t:1526919422778};\\\", \\\"{x:1559,y:210,t:1526919422792};\\\", \\\"{x:1559,y:218,t:1526919422808};\\\", \\\"{x:1559,y:230,t:1526919422826};\\\", \\\"{x:1559,y:250,t:1526919422842};\\\", \\\"{x:1559,y:279,t:1526919422859};\\\", \\\"{x:1559,y:313,t:1526919422875};\\\", \\\"{x:1572,y:355,t:1526919422892};\\\", \\\"{x:1599,y:402,t:1526919422909};\\\", \\\"{x:1631,y:451,t:1526919422926};\\\", \\\"{x:1670,y:496,t:1526919422943};\\\", \\\"{x:1713,y:539,t:1526919422959};\\\", \\\"{x:1792,y:607,t:1526919422975};\\\", \\\"{x:1835,y:649,t:1526919422992};\\\", \\\"{x:1861,y:682,t:1526919423009};\\\", \\\"{x:1886,y:723,t:1526919423027};\\\", \\\"{x:1900,y:761,t:1526919423043};\\\", \\\"{x:1910,y:795,t:1526919423058};\\\", \\\"{x:1914,y:826,t:1526919423076};\\\", \\\"{x:1914,y:858,t:1526919423093};\\\", \\\"{x:1914,y:885,t:1526919423110};\\\", \\\"{x:1909,y:903,t:1526919423125};\\\", \\\"{x:1898,y:921,t:1526919423143};\\\", \\\"{x:1886,y:939,t:1526919423160};\\\", \\\"{x:1878,y:949,t:1526919423176};\\\", \\\"{x:1873,y:957,t:1526919423193};\\\", \\\"{x:1869,y:962,t:1526919423209};\\\", \\\"{x:1868,y:963,t:1526919423226};\\\", \\\"{x:1867,y:963,t:1526919423529};\\\", \\\"{x:1866,y:963,t:1526919423543};\\\", \\\"{x:1865,y:963,t:1526919423559};\\\", \\\"{x:1864,y:963,t:1526919423576};\\\", \\\"{x:1863,y:963,t:1526919423593};\\\", \\\"{x:1862,y:962,t:1526919423624};\\\", \\\"{x:1861,y:962,t:1526919423642};\\\", \\\"{x:1857,y:960,t:1526919423660};\\\", \\\"{x:1855,y:958,t:1526919423676};\\\", \\\"{x:1850,y:957,t:1526919423693};\\\", \\\"{x:1849,y:955,t:1526919423709};\\\", \\\"{x:1847,y:955,t:1526919423727};\\\", \\\"{x:1846,y:954,t:1526919423743};\\\", \\\"{x:1843,y:953,t:1526919423760};\\\", \\\"{x:1839,y:952,t:1526919423777};\\\", \\\"{x:1834,y:951,t:1526919423793};\\\", \\\"{x:1831,y:951,t:1526919423810};\\\", \\\"{x:1829,y:950,t:1526919423826};\\\", \\\"{x:1828,y:949,t:1526919423842};\\\", \\\"{x:1827,y:949,t:1526919423860};\\\", \\\"{x:1823,y:949,t:1526919425113};\\\", \\\"{x:1815,y:949,t:1526919425127};\\\", \\\"{x:1786,y:949,t:1526919425144};\\\", \\\"{x:1768,y:949,t:1526919425160};\\\", \\\"{x:1759,y:949,t:1526919425178};\\\", \\\"{x:1754,y:949,t:1526919425194};\\\", \\\"{x:1749,y:949,t:1526919425211};\\\", \\\"{x:1746,y:949,t:1526919425228};\\\", \\\"{x:1742,y:950,t:1526919425243};\\\", \\\"{x:1733,y:950,t:1526919425261};\\\", \\\"{x:1721,y:950,t:1526919425277};\\\", \\\"{x:1710,y:950,t:1526919425294};\\\", \\\"{x:1701,y:950,t:1526919425311};\\\", \\\"{x:1689,y:950,t:1526919425328};\\\", \\\"{x:1674,y:950,t:1526919425344};\\\", \\\"{x:1654,y:950,t:1526919425361};\\\", \\\"{x:1635,y:950,t:1526919425378};\\\", \\\"{x:1615,y:950,t:1526919425394};\\\", \\\"{x:1589,y:950,t:1526919425410};\\\", \\\"{x:1566,y:950,t:1526919425428};\\\", \\\"{x:1546,y:950,t:1526919425444};\\\", \\\"{x:1512,y:950,t:1526919425461};\\\", \\\"{x:1456,y:950,t:1526919425478};\\\", \\\"{x:1408,y:943,t:1526919425494};\\\", \\\"{x:1377,y:942,t:1526919425511};\\\", \\\"{x:1340,y:938,t:1526919425528};\\\", \\\"{x:1324,y:937,t:1526919425544};\\\", \\\"{x:1311,y:934,t:1526919425561};\\\", \\\"{x:1295,y:931,t:1526919425578};\\\", \\\"{x:1284,y:930,t:1526919425594};\\\", \\\"{x:1274,y:929,t:1526919425611};\\\", \\\"{x:1262,y:927,t:1526919425627};\\\", \\\"{x:1248,y:925,t:1526919425645};\\\", \\\"{x:1230,y:920,t:1526919425661};\\\", \\\"{x:1209,y:914,t:1526919425678};\\\", \\\"{x:1195,y:912,t:1526919425695};\\\", \\\"{x:1185,y:907,t:1526919425711};\\\", \\\"{x:1182,y:904,t:1526919425727};\\\", \\\"{x:1181,y:902,t:1526919425744};\\\", \\\"{x:1180,y:901,t:1526919425761};\\\", \\\"{x:1180,y:900,t:1526919425778};\\\", \\\"{x:1180,y:899,t:1526919425795};\\\", \\\"{x:1180,y:898,t:1526919426737};\\\", \\\"{x:1180,y:897,t:1526919429537};\\\", \\\"{x:1179,y:897,t:1526919429547};\\\", \\\"{x:1177,y:897,t:1526919429564};\\\", \\\"{x:1176,y:895,t:1526919429581};\\\", \\\"{x:1175,y:895,t:1526919429616};\\\", \\\"{x:1175,y:894,t:1526919429631};\\\", \\\"{x:1176,y:889,t:1526919429647};\\\", \\\"{x:1180,y:880,t:1526919429664};\\\", \\\"{x:1183,y:873,t:1526919429680};\\\", \\\"{x:1184,y:872,t:1526919429697};\\\", \\\"{x:1184,y:871,t:1526919429713};\\\", \\\"{x:1188,y:871,t:1526919431345};\\\", \\\"{x:1201,y:868,t:1526919431351};\\\", \\\"{x:1221,y:868,t:1526919431364};\\\", \\\"{x:1281,y:865,t:1526919431382};\\\", \\\"{x:1336,y:865,t:1526919431399};\\\", \\\"{x:1401,y:863,t:1526919431415};\\\", \\\"{x:1512,y:863,t:1526919431432};\\\", \\\"{x:1585,y:863,t:1526919431448};\\\", \\\"{x:1646,y:863,t:1526919431465};\\\", \\\"{x:1688,y:863,t:1526919431482};\\\", \\\"{x:1712,y:859,t:1526919431499};\\\", \\\"{x:1726,y:857,t:1526919431514};\\\", \\\"{x:1733,y:854,t:1526919431531};\\\", \\\"{x:1734,y:853,t:1526919431549};\\\", \\\"{x:1735,y:853,t:1526919431565};\\\", \\\"{x:1735,y:847,t:1526919431581};\\\", \\\"{x:1735,y:837,t:1526919431598};\\\", \\\"{x:1735,y:824,t:1526919431615};\\\", \\\"{x:1728,y:800,t:1526919431631};\\\", \\\"{x:1721,y:783,t:1526919431649};\\\", \\\"{x:1711,y:769,t:1526919431664};\\\", \\\"{x:1697,y:761,t:1526919431681};\\\", \\\"{x:1686,y:759,t:1526919431698};\\\", \\\"{x:1680,y:761,t:1526919431714};\\\", \\\"{x:1672,y:771,t:1526919431731};\\\", \\\"{x:1668,y:785,t:1526919431749};\\\", \\\"{x:1667,y:802,t:1526919431765};\\\", \\\"{x:1667,y:822,t:1526919431782};\\\", \\\"{x:1667,y:844,t:1526919431799};\\\", \\\"{x:1663,y:873,t:1526919431815};\\\", \\\"{x:1663,y:892,t:1526919431832};\\\", \\\"{x:1663,y:909,t:1526919431848};\\\", \\\"{x:1663,y:920,t:1526919431866};\\\", \\\"{x:1663,y:931,t:1526919431882};\\\", \\\"{x:1663,y:940,t:1526919431899};\\\", \\\"{x:1658,y:951,t:1526919431916};\\\", \\\"{x:1650,y:963,t:1526919431933};\\\", \\\"{x:1641,y:972,t:1526919431949};\\\", \\\"{x:1633,y:977,t:1526919431966};\\\", \\\"{x:1625,y:981,t:1526919431981};\\\", \\\"{x:1621,y:983,t:1526919431998};\\\", \\\"{x:1620,y:983,t:1526919432016};\\\", \\\"{x:1620,y:982,t:1526919432048};\\\", \\\"{x:1620,y:980,t:1526919432136};\\\", \\\"{x:1621,y:979,t:1526919432149};\\\", \\\"{x:1629,y:972,t:1526919432166};\\\", \\\"{x:1635,y:965,t:1526919432182};\\\", \\\"{x:1642,y:958,t:1526919432199};\\\", \\\"{x:1645,y:946,t:1526919432216};\\\", \\\"{x:1647,y:933,t:1526919432232};\\\", \\\"{x:1647,y:922,t:1526919432249};\\\", \\\"{x:1647,y:911,t:1526919432266};\\\", \\\"{x:1648,y:888,t:1526919432283};\\\", \\\"{x:1648,y:862,t:1526919432298};\\\", \\\"{x:1648,y:832,t:1526919432316};\\\", \\\"{x:1647,y:806,t:1526919432333};\\\", \\\"{x:1645,y:790,t:1526919432349};\\\", \\\"{x:1643,y:775,t:1526919432365};\\\", \\\"{x:1641,y:767,t:1526919432382};\\\", \\\"{x:1640,y:757,t:1526919432398};\\\", \\\"{x:1637,y:748,t:1526919432415};\\\", \\\"{x:1636,y:742,t:1526919432433};\\\", \\\"{x:1633,y:737,t:1526919432449};\\\", \\\"{x:1632,y:732,t:1526919432465};\\\", \\\"{x:1632,y:728,t:1526919432482};\\\", \\\"{x:1630,y:723,t:1526919432499};\\\", \\\"{x:1629,y:720,t:1526919432516};\\\", \\\"{x:1629,y:718,t:1526919432533};\\\", \\\"{x:1628,y:717,t:1526919432552};\\\", \\\"{x:1628,y:716,t:1526919432566};\\\", \\\"{x:1627,y:715,t:1526919432583};\\\", \\\"{x:1627,y:713,t:1526919432599};\\\", \\\"{x:1626,y:710,t:1526919432616};\\\", \\\"{x:1624,y:706,t:1526919432633};\\\", \\\"{x:1624,y:705,t:1526919432656};\\\", \\\"{x:1624,y:704,t:1526919432666};\\\", \\\"{x:1623,y:703,t:1526919432683};\\\", \\\"{x:1623,y:702,t:1526919432745};\\\", \\\"{x:1622,y:702,t:1526919432848};\\\", \\\"{x:1621,y:703,t:1526919432864};\\\", \\\"{x:1621,y:704,t:1526919432872};\\\", \\\"{x:1621,y:706,t:1526919432883};\\\", \\\"{x:1620,y:708,t:1526919432900};\\\", \\\"{x:1620,y:713,t:1526919432916};\\\", \\\"{x:1620,y:717,t:1526919432933};\\\", \\\"{x:1620,y:721,t:1526919432950};\\\", \\\"{x:1620,y:724,t:1526919432966};\\\", \\\"{x:1620,y:727,t:1526919432983};\\\", \\\"{x:1620,y:730,t:1526919433000};\\\", \\\"{x:1620,y:732,t:1526919433016};\\\", \\\"{x:1620,y:736,t:1526919433034};\\\", \\\"{x:1620,y:739,t:1526919433050};\\\", \\\"{x:1620,y:744,t:1526919433066};\\\", \\\"{x:1620,y:746,t:1526919433083};\\\", \\\"{x:1620,y:748,t:1526919433100};\\\", \\\"{x:1620,y:749,t:1526919433116};\\\", \\\"{x:1620,y:754,t:1526919433133};\\\", \\\"{x:1620,y:758,t:1526919433150};\\\", \\\"{x:1620,y:762,t:1526919433166};\\\", \\\"{x:1620,y:764,t:1526919433183};\\\", \\\"{x:1620,y:771,t:1526919433200};\\\", \\\"{x:1620,y:774,t:1526919433217};\\\", \\\"{x:1620,y:783,t:1526919433233};\\\", \\\"{x:1620,y:795,t:1526919433250};\\\", \\\"{x:1620,y:807,t:1526919433268};\\\", \\\"{x:1620,y:819,t:1526919433283};\\\", \\\"{x:1621,y:837,t:1526919433301};\\\", \\\"{x:1621,y:853,t:1526919433317};\\\", \\\"{x:1621,y:870,t:1526919433333};\\\", \\\"{x:1619,y:885,t:1526919433350};\\\", \\\"{x:1619,y:897,t:1526919433367};\\\", \\\"{x:1619,y:904,t:1526919433383};\\\", \\\"{x:1619,y:914,t:1526919433400};\\\", \\\"{x:1619,y:921,t:1526919433417};\\\", \\\"{x:1617,y:927,t:1526919433433};\\\", \\\"{x:1617,y:930,t:1526919433450};\\\", \\\"{x:1617,y:933,t:1526919433467};\\\", \\\"{x:1617,y:937,t:1526919433483};\\\", \\\"{x:1618,y:941,t:1526919433500};\\\", \\\"{x:1620,y:944,t:1526919433517};\\\", \\\"{x:1620,y:948,t:1526919433533};\\\", \\\"{x:1620,y:951,t:1526919433550};\\\", \\\"{x:1620,y:954,t:1526919433568};\\\", \\\"{x:1620,y:957,t:1526919433583};\\\", \\\"{x:1621,y:961,t:1526919433600};\\\", \\\"{x:1621,y:962,t:1526919433688};\\\", \\\"{x:1621,y:963,t:1526919433751};\\\", \\\"{x:1621,y:964,t:1526919433766};\\\", \\\"{x:1619,y:965,t:1526919433784};\\\", \\\"{x:1618,y:965,t:1526919434008};\\\", \\\"{x:1617,y:965,t:1526919434017};\\\", \\\"{x:1617,y:964,t:1526919434034};\\\", \\\"{x:1616,y:963,t:1526919434905};\\\", \\\"{x:1616,y:962,t:1526919434936};\\\", \\\"{x:1615,y:962,t:1526919434952};\\\", \\\"{x:1614,y:962,t:1526919434984};\\\", \\\"{x:1615,y:962,t:1526919435489};\\\", \\\"{x:1616,y:962,t:1526919435576};\\\", \\\"{x:1617,y:963,t:1526919435616};\\\", \\\"{x:1618,y:964,t:1526919435688};\\\", \\\"{x:1618,y:965,t:1526919435720};\\\", \\\"{x:1618,y:966,t:1526919435736};\\\", \\\"{x:1618,y:967,t:1526919435752};\\\", \\\"{x:1618,y:968,t:1526919435792};\\\", \\\"{x:1618,y:966,t:1526919435945};\\\", \\\"{x:1618,y:963,t:1526919435952};\\\", \\\"{x:1618,y:955,t:1526919435969};\\\", \\\"{x:1618,y:941,t:1526919435985};\\\", \\\"{x:1621,y:930,t:1526919436002};\\\", \\\"{x:1624,y:918,t:1526919436018};\\\", \\\"{x:1629,y:905,t:1526919436035};\\\", \\\"{x:1634,y:889,t:1526919436052};\\\", \\\"{x:1639,y:875,t:1526919436068};\\\", \\\"{x:1644,y:858,t:1526919436085};\\\", \\\"{x:1647,y:843,t:1526919436102};\\\", \\\"{x:1649,y:829,t:1526919436119};\\\", \\\"{x:1649,y:820,t:1526919436135};\\\", \\\"{x:1649,y:808,t:1526919436152};\\\", \\\"{x:1649,y:800,t:1526919436169};\\\", \\\"{x:1649,y:790,t:1526919436185};\\\", \\\"{x:1647,y:781,t:1526919436203};\\\", \\\"{x:1642,y:770,t:1526919436219};\\\", \\\"{x:1637,y:757,t:1526919436235};\\\", \\\"{x:1631,y:745,t:1526919436253};\\\", \\\"{x:1621,y:725,t:1526919436270};\\\", \\\"{x:1613,y:711,t:1526919436285};\\\", \\\"{x:1609,y:705,t:1526919436302};\\\", \\\"{x:1608,y:703,t:1526919436319};\\\", \\\"{x:1607,y:702,t:1526919436335};\\\", \\\"{x:1607,y:699,t:1526919436352};\\\", \\\"{x:1607,y:698,t:1526919436370};\\\", \\\"{x:1607,y:696,t:1526919436386};\\\", \\\"{x:1607,y:695,t:1526919436432};\\\", \\\"{x:1608,y:694,t:1526919436527};\\\", \\\"{x:1609,y:694,t:1526919436584};\\\", \\\"{x:1610,y:694,t:1526919436619};\\\", \\\"{x:1611,y:695,t:1526919436639};\\\", \\\"{x:1613,y:695,t:1526919436696};\\\", \\\"{x:1613,y:696,t:1526919436704};\\\", \\\"{x:1614,y:696,t:1526919444432};\\\", \\\"{x:1614,y:700,t:1526919444442};\\\", \\\"{x:1613,y:708,t:1526919444460};\\\", \\\"{x:1612,y:718,t:1526919444475};\\\", \\\"{x:1611,y:725,t:1526919444491};\\\", \\\"{x:1611,y:734,t:1526919444508};\\\", \\\"{x:1611,y:746,t:1526919444525};\\\", \\\"{x:1611,y:757,t:1526919444542};\\\", \\\"{x:1611,y:771,t:1526919444559};\\\", \\\"{x:1611,y:789,t:1526919444574};\\\", \\\"{x:1616,y:819,t:1526919444591};\\\", \\\"{x:1620,y:843,t:1526919444609};\\\", \\\"{x:1622,y:863,t:1526919444624};\\\", \\\"{x:1627,y:880,t:1526919444642};\\\", \\\"{x:1632,y:896,t:1526919444658};\\\", \\\"{x:1633,y:909,t:1526919444675};\\\", \\\"{x:1637,y:927,t:1526919444691};\\\", \\\"{x:1641,y:946,t:1526919444709};\\\", \\\"{x:1643,y:963,t:1526919444725};\\\", \\\"{x:1644,y:977,t:1526919444742};\\\", \\\"{x:1647,y:990,t:1526919444758};\\\", \\\"{x:1648,y:1001,t:1526919444776};\\\", \\\"{x:1648,y:1005,t:1526919444792};\\\", \\\"{x:1648,y:1006,t:1526919444816};\\\", \\\"{x:1649,y:1008,t:1526919444832};\\\", \\\"{x:1650,y:1008,t:1526919444842};\\\", \\\"{x:1650,y:1009,t:1526919444864};\\\", \\\"{x:1650,y:1010,t:1526919444875};\\\", \\\"{x:1649,y:1011,t:1526919444892};\\\", \\\"{x:1648,y:1011,t:1526919445008};\\\", \\\"{x:1647,y:1011,t:1526919445026};\\\", \\\"{x:1644,y:1009,t:1526919445042};\\\", \\\"{x:1638,y:997,t:1526919445059};\\\", \\\"{x:1633,y:985,t:1526919445076};\\\", \\\"{x:1629,y:965,t:1526919445091};\\\", \\\"{x:1625,y:938,t:1526919445109};\\\", \\\"{x:1616,y:896,t:1526919445126};\\\", \\\"{x:1610,y:851,t:1526919445143};\\\", \\\"{x:1606,y:813,t:1526919445159};\\\", \\\"{x:1605,y:772,t:1526919445176};\\\", \\\"{x:1605,y:752,t:1526919445191};\\\", \\\"{x:1605,y:740,t:1526919445208};\\\", \\\"{x:1603,y:733,t:1526919445225};\\\", \\\"{x:1602,y:727,t:1526919445242};\\\", \\\"{x:1602,y:723,t:1526919445258};\\\", \\\"{x:1602,y:720,t:1526919445276};\\\", \\\"{x:1602,y:718,t:1526919445293};\\\", \\\"{x:1603,y:713,t:1526919445308};\\\", \\\"{x:1603,y:711,t:1526919445326};\\\", \\\"{x:1603,y:709,t:1526919445342};\\\", \\\"{x:1603,y:708,t:1526919445359};\\\", \\\"{x:1604,y:705,t:1526919445376};\\\", \\\"{x:1605,y:704,t:1526919445416};\\\", \\\"{x:1606,y:702,t:1526919445425};\\\", \\\"{x:1606,y:701,t:1526919445443};\\\", \\\"{x:1607,y:699,t:1526919445459};\\\", \\\"{x:1607,y:698,t:1526919445476};\\\", \\\"{x:1608,y:697,t:1526919445568};\\\", \\\"{x:1609,y:697,t:1526919445593};\\\", \\\"{x:1610,y:697,t:1526919445631};\\\", \\\"{x:1611,y:697,t:1526919445655};\\\", \\\"{x:1612,y:697,t:1526919445704};\\\", \\\"{x:1613,y:698,t:1526919445712};\\\", \\\"{x:1614,y:698,t:1526919445744};\\\", \\\"{x:1616,y:699,t:1526919445759};\\\", \\\"{x:1616,y:702,t:1526919447840};\\\", \\\"{x:1614,y:703,t:1526919447848};\\\", \\\"{x:1609,y:706,t:1526919447861};\\\", \\\"{x:1595,y:712,t:1526919447878};\\\", \\\"{x:1589,y:715,t:1526919447894};\\\", \\\"{x:1582,y:717,t:1526919447910};\\\", \\\"{x:1567,y:725,t:1526919447928};\\\", \\\"{x:1559,y:731,t:1526919447944};\\\", \\\"{x:1552,y:739,t:1526919447961};\\\", \\\"{x:1545,y:747,t:1526919447978};\\\", \\\"{x:1540,y:754,t:1526919447994};\\\", \\\"{x:1536,y:760,t:1526919448010};\\\", \\\"{x:1533,y:764,t:1526919448028};\\\", \\\"{x:1530,y:769,t:1526919448045};\\\", \\\"{x:1529,y:771,t:1526919448060};\\\", \\\"{x:1526,y:777,t:1526919448077};\\\", \\\"{x:1525,y:781,t:1526919448095};\\\", \\\"{x:1523,y:789,t:1526919448110};\\\", \\\"{x:1521,y:795,t:1526919448128};\\\", \\\"{x:1520,y:801,t:1526919448144};\\\", \\\"{x:1518,y:808,t:1526919448161};\\\", \\\"{x:1517,y:813,t:1526919448180};\\\", \\\"{x:1512,y:820,t:1526919448194};\\\", \\\"{x:1507,y:825,t:1526919448210};\\\", \\\"{x:1500,y:830,t:1526919448227};\\\", \\\"{x:1490,y:833,t:1526919448244};\\\", \\\"{x:1483,y:834,t:1526919448260};\\\", \\\"{x:1480,y:834,t:1526919448277};\\\", \\\"{x:1479,y:834,t:1526919448351};\\\", \\\"{x:1478,y:834,t:1526919448375};\\\", \\\"{x:1478,y:836,t:1526919448497};\\\", \\\"{x:1478,y:838,t:1526919448511};\\\", \\\"{x:1478,y:843,t:1526919448528};\\\", \\\"{x:1478,y:846,t:1526919448544};\\\", \\\"{x:1478,y:850,t:1526919448561};\\\", \\\"{x:1479,y:851,t:1526919448577};\\\", \\\"{x:1480,y:853,t:1526919448594};\\\", \\\"{x:1480,y:855,t:1526919448612};\\\", \\\"{x:1480,y:858,t:1526919448627};\\\", \\\"{x:1480,y:862,t:1526919448644};\\\", \\\"{x:1480,y:865,t:1526919448661};\\\", \\\"{x:1480,y:867,t:1526919448678};\\\", \\\"{x:1480,y:869,t:1526919448695};\\\", \\\"{x:1480,y:874,t:1526919448712};\\\", \\\"{x:1479,y:878,t:1526919448727};\\\", \\\"{x:1479,y:882,t:1526919448745};\\\", \\\"{x:1478,y:889,t:1526919448761};\\\", \\\"{x:1478,y:892,t:1526919448776};\\\", \\\"{x:1476,y:904,t:1526919448794};\\\", \\\"{x:1473,y:915,t:1526919448811};\\\", \\\"{x:1471,y:928,t:1526919448827};\\\", \\\"{x:1469,y:939,t:1526919448844};\\\", \\\"{x:1469,y:946,t:1526919448862};\\\", \\\"{x:1469,y:952,t:1526919448877};\\\", \\\"{x:1469,y:959,t:1526919448894};\\\", \\\"{x:1469,y:966,t:1526919448911};\\\", \\\"{x:1469,y:971,t:1526919448928};\\\", \\\"{x:1469,y:975,t:1526919448944};\\\", \\\"{x:1469,y:978,t:1526919448962};\\\", \\\"{x:1469,y:980,t:1526919448979};\\\", \\\"{x:1469,y:983,t:1526919448994};\\\", \\\"{x:1469,y:986,t:1526919449012};\\\", \\\"{x:1464,y:991,t:1526919449028};\\\", \\\"{x:1452,y:998,t:1526919449044};\\\", \\\"{x:1431,y:1005,t:1526919449061};\\\", \\\"{x:1411,y:1008,t:1526919449078};\\\", \\\"{x:1392,y:1009,t:1526919449095};\\\", \\\"{x:1340,y:995,t:1526919449111};\\\", \\\"{x:1268,y:979,t:1526919449128};\\\", \\\"{x:1212,y:961,t:1526919449145};\\\", \\\"{x:1180,y:955,t:1526919449161};\\\", \\\"{x:1160,y:950,t:1526919449179};\\\", \\\"{x:1133,y:947,t:1526919449195};\\\", \\\"{x:1102,y:943,t:1526919449212};\\\", \\\"{x:1047,y:929,t:1526919449228};\\\", \\\"{x:944,y:896,t:1526919449245};\\\", \\\"{x:821,y:850,t:1526919449261};\\\", \\\"{x:693,y:811,t:1526919449278};\\\", \\\"{x:595,y:779,t:1526919449294};\\\", \\\"{x:495,y:727,t:1526919449313};\\\", \\\"{x:449,y:693,t:1526919449328};\\\", \\\"{x:420,y:662,t:1526919449346};\\\", \\\"{x:387,y:628,t:1526919449359};\\\", \\\"{x:363,y:598,t:1526919449376};\\\", \\\"{x:355,y:577,t:1526919449397};\\\", \\\"{x:353,y:559,t:1526919449413};\\\", \\\"{x:353,y:541,t:1526919449431};\\\", \\\"{x:353,y:519,t:1526919449446};\\\", \\\"{x:353,y:496,t:1526919449463};\\\", \\\"{x:353,y:487,t:1526919449479};\\\", \\\"{x:355,y:483,t:1526919449496};\\\", \\\"{x:365,y:482,t:1526919449513};\\\", \\\"{x:383,y:482,t:1526919449530};\\\", \\\"{x:421,y:486,t:1526919449546};\\\", \\\"{x:467,y:493,t:1526919449564};\\\", \\\"{x:510,y:498,t:1526919449581};\\\", \\\"{x:540,y:499,t:1526919449596};\\\", \\\"{x:552,y:501,t:1526919449613};\\\", \\\"{x:552,y:502,t:1526919449629};\\\", \\\"{x:552,y:508,t:1526919449646};\\\", \\\"{x:539,y:526,t:1526919449663};\\\", \\\"{x:522,y:537,t:1526919449679};\\\", \\\"{x:504,y:543,t:1526919449696};\\\", \\\"{x:485,y:545,t:1526919449714};\\\", \\\"{x:467,y:548,t:1526919449729};\\\", \\\"{x:456,y:548,t:1526919449745};\\\", \\\"{x:451,y:548,t:1526919449763};\\\", \\\"{x:445,y:548,t:1526919449780};\\\", \\\"{x:442,y:548,t:1526919449796};\\\", \\\"{x:441,y:548,t:1526919449813};\\\", \\\"{x:439,y:548,t:1526919449830};\\\", \\\"{x:438,y:548,t:1526919449871};\\\", \\\"{x:437,y:547,t:1526919449944};\\\", \\\"{x:436,y:547,t:1526919449959};\\\", \\\"{x:436,y:546,t:1526919449975};\\\", \\\"{x:435,y:546,t:1526919449983};\\\", \\\"{x:433,y:546,t:1526919450000};\\\", \\\"{x:430,y:545,t:1526919450016};\\\", \\\"{x:427,y:545,t:1526919450030};\\\", \\\"{x:419,y:543,t:1526919450047};\\\", \\\"{x:415,y:543,t:1526919450064};\\\", \\\"{x:411,y:543,t:1526919450080};\\\", \\\"{x:410,y:543,t:1526919450097};\\\", \\\"{x:410,y:542,t:1526919450113};\\\", \\\"{x:408,y:542,t:1526919450131};\\\", \\\"{x:405,y:542,t:1526919450148};\\\", \\\"{x:396,y:541,t:1526919450163};\\\", \\\"{x:389,y:541,t:1526919450181};\\\", \\\"{x:385,y:541,t:1526919450197};\\\", \\\"{x:382,y:541,t:1526919450213};\\\", \\\"{x:381,y:541,t:1526919450230};\\\", \\\"{x:376,y:541,t:1526919450247};\\\", \\\"{x:367,y:541,t:1526919450264};\\\", \\\"{x:360,y:541,t:1526919450280};\\\", \\\"{x:355,y:541,t:1526919450298};\\\", \\\"{x:350,y:541,t:1526919450313};\\\", \\\"{x:348,y:541,t:1526919450335};\\\", \\\"{x:346,y:542,t:1526919450347};\\\", \\\"{x:342,y:543,t:1526919450363};\\\", \\\"{x:339,y:544,t:1526919450381};\\\", \\\"{x:338,y:544,t:1526919450397};\\\", \\\"{x:336,y:545,t:1526919450415};\\\", \\\"{x:334,y:546,t:1526919450431};\\\", \\\"{x:326,y:547,t:1526919450447};\\\", \\\"{x:312,y:547,t:1526919450463};\\\", \\\"{x:303,y:547,t:1526919450480};\\\", \\\"{x:286,y:547,t:1526919450498};\\\", \\\"{x:266,y:548,t:1526919450517};\\\", \\\"{x:245,y:548,t:1526919450530};\\\", \\\"{x:228,y:551,t:1526919450547};\\\", \\\"{x:213,y:551,t:1526919450564};\\\", \\\"{x:202,y:551,t:1526919450580};\\\", \\\"{x:194,y:551,t:1526919450597};\\\", \\\"{x:187,y:551,t:1526919450614};\\\", \\\"{x:178,y:551,t:1526919450630};\\\", \\\"{x:169,y:552,t:1526919450647};\\\", \\\"{x:168,y:552,t:1526919450720};\\\", \\\"{x:166,y:554,t:1526919450730};\\\", \\\"{x:166,y:555,t:1526919450747};\\\", \\\"{x:166,y:557,t:1526919450808};\\\", \\\"{x:168,y:559,t:1526919450814};\\\", \\\"{x:168,y:561,t:1526919450830};\\\", \\\"{x:168,y:566,t:1526919450847};\\\", \\\"{x:171,y:571,t:1526919450864};\\\", \\\"{x:171,y:573,t:1526919450881};\\\", \\\"{x:171,y:575,t:1526919450897};\\\", \\\"{x:171,y:577,t:1526919450914};\\\", \\\"{x:171,y:579,t:1526919450931};\\\", \\\"{x:170,y:580,t:1526919450947};\\\", \\\"{x:170,y:581,t:1526919450964};\\\", \\\"{x:170,y:583,t:1526919450981};\\\", \\\"{x:170,y:585,t:1526919450997};\\\", \\\"{x:170,y:589,t:1526919451015};\\\", \\\"{x:170,y:592,t:1526919451031};\\\", \\\"{x:170,y:594,t:1526919451048};\\\", \\\"{x:172,y:598,t:1526919451064};\\\", \\\"{x:174,y:603,t:1526919451082};\\\", \\\"{x:178,y:606,t:1526919451098};\\\", \\\"{x:179,y:609,t:1526919451113};\\\", \\\"{x:181,y:610,t:1526919451131};\\\", \\\"{x:193,y:613,t:1526919451147};\\\", \\\"{x:215,y:616,t:1526919451164};\\\", \\\"{x:250,y:621,t:1526919451181};\\\", \\\"{x:298,y:627,t:1526919451197};\\\", \\\"{x:342,y:633,t:1526919451214};\\\", \\\"{x:412,y:633,t:1526919451230};\\\", \\\"{x:452,y:633,t:1526919451248};\\\", \\\"{x:488,y:633,t:1526919451264};\\\", \\\"{x:526,y:631,t:1526919451282};\\\", \\\"{x:552,y:625,t:1526919451298};\\\", \\\"{x:573,y:620,t:1526919451314};\\\", \\\"{x:592,y:613,t:1526919451331};\\\", \\\"{x:607,y:610,t:1526919451349};\\\", \\\"{x:617,y:610,t:1526919451364};\\\", \\\"{x:624,y:610,t:1526919451381};\\\", \\\"{x:633,y:610,t:1526919451398};\\\", \\\"{x:639,y:611,t:1526919451414};\\\", \\\"{x:641,y:612,t:1526919451431};\\\", \\\"{x:643,y:612,t:1526919451448};\\\", \\\"{x:645,y:614,t:1526919451465};\\\", \\\"{x:650,y:618,t:1526919451481};\\\", \\\"{x:657,y:618,t:1526919451498};\\\", \\\"{x:661,y:619,t:1526919451514};\\\", \\\"{x:662,y:619,t:1526919451531};\\\", \\\"{x:662,y:617,t:1526919451583};\\\", \\\"{x:662,y:614,t:1526919451599};\\\", \\\"{x:654,y:598,t:1526919451616};\\\", \\\"{x:650,y:594,t:1526919451631};\\\", \\\"{x:647,y:593,t:1526919451649};\\\", \\\"{x:643,y:592,t:1526919451665};\\\", \\\"{x:638,y:591,t:1526919451681};\\\", \\\"{x:628,y:590,t:1526919451698};\\\", \\\"{x:619,y:589,t:1526919451716};\\\", \\\"{x:611,y:588,t:1526919451731};\\\", \\\"{x:609,y:586,t:1526919451749};\\\", \\\"{x:608,y:586,t:1526919451765};\\\", \\\"{x:607,y:586,t:1526919451856};\\\", \\\"{x:606,y:585,t:1526919451866};\\\", \\\"{x:606,y:584,t:1526919452000};\\\", \\\"{x:607,y:584,t:1526919452639};\\\", \\\"{x:615,y:585,t:1526919452649};\\\", \\\"{x:675,y:602,t:1526919452667};\\\", \\\"{x:769,y:627,t:1526919452682};\\\", \\\"{x:884,y:652,t:1526919452699};\\\", \\\"{x:999,y:679,t:1526919452715};\\\", \\\"{x:1107,y:693,t:1526919452732};\\\", \\\"{x:1177,y:712,t:1526919452749};\\\", \\\"{x:1214,y:724,t:1526919452765};\\\", \\\"{x:1243,y:737,t:1526919452782};\\\", \\\"{x:1265,y:753,t:1526919452798};\\\", \\\"{x:1280,y:763,t:1526919452815};\\\", \\\"{x:1302,y:781,t:1526919452832};\\\", \\\"{x:1323,y:797,t:1526919452849};\\\", \\\"{x:1345,y:814,t:1526919452865};\\\", \\\"{x:1363,y:826,t:1526919452883};\\\", \\\"{x:1379,y:832,t:1526919452900};\\\", \\\"{x:1385,y:835,t:1526919452915};\\\", \\\"{x:1387,y:835,t:1526919452932};\\\", \\\"{x:1389,y:835,t:1526919452983};\\\", \\\"{x:1402,y:835,t:1526919452999};\\\", \\\"{x:1427,y:834,t:1526919453015};\\\", \\\"{x:1458,y:828,t:1526919453033};\\\", \\\"{x:1485,y:821,t:1526919453050};\\\", \\\"{x:1502,y:815,t:1526919453067};\\\", \\\"{x:1508,y:812,t:1526919453083};\\\", \\\"{x:1509,y:812,t:1526919453099};\\\", \\\"{x:1510,y:812,t:1526919453143};\\\", \\\"{x:1509,y:815,t:1526919453239};\\\", \\\"{x:1507,y:816,t:1526919453249};\\\", \\\"{x:1493,y:820,t:1526919453266};\\\", \\\"{x:1478,y:821,t:1526919453282};\\\", \\\"{x:1471,y:822,t:1526919453300};\\\", \\\"{x:1469,y:822,t:1526919453316};\\\", \\\"{x:1469,y:823,t:1526919453616};\\\", \\\"{x:1469,y:824,t:1526919454040};\\\", \\\"{x:1471,y:824,t:1526919454248};\\\", \\\"{x:1471,y:825,t:1526919454271};\\\", \\\"{x:1472,y:825,t:1526919454303};\\\", \\\"{x:1473,y:825,t:1526919454327};\\\", \\\"{x:1474,y:825,t:1526919454344};\\\", \\\"{x:1475,y:827,t:1526919454359};\\\", \\\"{x:1476,y:827,t:1526919454440};\\\", \\\"{x:1476,y:828,t:1526919454583};\\\", \\\"{x:1476,y:830,t:1526919454601};\\\", \\\"{x:1476,y:833,t:1526919454619};\\\", \\\"{x:1476,y:835,t:1526919454633};\\\", \\\"{x:1476,y:837,t:1526919454650};\\\", \\\"{x:1476,y:838,t:1526919454668};\\\", \\\"{x:1476,y:840,t:1526919454684};\\\", \\\"{x:1476,y:841,t:1526919454701};\\\", \\\"{x:1476,y:842,t:1526919454718};\\\", \\\"{x:1476,y:839,t:1526919454904};\\\", \\\"{x:1476,y:838,t:1526919454918};\\\", \\\"{x:1476,y:835,t:1526919454934};\\\", \\\"{x:1476,y:834,t:1526919454960};\\\", \\\"{x:1476,y:833,t:1526919454976};\\\", \\\"{x:1476,y:832,t:1526919454985};\\\", \\\"{x:1476,y:831,t:1526919455031};\\\", \\\"{x:1477,y:831,t:1526919455232};\\\", \\\"{x:1478,y:831,t:1526919456048};\\\", \\\"{x:1478,y:832,t:1526919456151};\\\", \\\"{x:1478,y:830,t:1526919456696};\\\", \\\"{x:1478,y:829,t:1526919457039};\\\", \\\"{x:1478,y:827,t:1526919457055};\\\", \\\"{x:1479,y:826,t:1526919457071};\\\", \\\"{x:1479,y:824,t:1526919457104};\\\", \\\"{x:1478,y:824,t:1526919457912};\\\", \\\"{x:1478,y:825,t:1526919457928};\\\", \\\"{x:1475,y:827,t:1526919457954};\\\", \\\"{x:1474,y:828,t:1526919457970};\\\", \\\"{x:1472,y:830,t:1526919457987};\\\", \\\"{x:1470,y:831,t:1526919458003};\\\", \\\"{x:1470,y:833,t:1526919458020};\\\", \\\"{x:1470,y:836,t:1526919458037};\\\", \\\"{x:1470,y:842,t:1526919458053};\\\", \\\"{x:1467,y:846,t:1526919458070};\\\", \\\"{x:1464,y:852,t:1526919458087};\\\", \\\"{x:1464,y:854,t:1526919458103};\\\", \\\"{x:1459,y:861,t:1526919458120};\\\", \\\"{x:1457,y:866,t:1526919458137};\\\", \\\"{x:1453,y:871,t:1526919458153};\\\", \\\"{x:1451,y:874,t:1526919458170};\\\", \\\"{x:1446,y:879,t:1526919458187};\\\", \\\"{x:1443,y:884,t:1526919458203};\\\", \\\"{x:1438,y:890,t:1526919458220};\\\", \\\"{x:1433,y:895,t:1526919458237};\\\", \\\"{x:1428,y:900,t:1526919458253};\\\", \\\"{x:1418,y:907,t:1526919458270};\\\", \\\"{x:1411,y:917,t:1526919458287};\\\", \\\"{x:1399,y:928,t:1526919458303};\\\", \\\"{x:1395,y:929,t:1526919458320};\\\", \\\"{x:1393,y:929,t:1526919458408};\\\", \\\"{x:1392,y:928,t:1526919458432};\\\", \\\"{x:1392,y:927,t:1526919458440};\\\", \\\"{x:1392,y:925,t:1526919458454};\\\", \\\"{x:1391,y:923,t:1526919458470};\\\", \\\"{x:1391,y:921,t:1526919458487};\\\", \\\"{x:1389,y:918,t:1526919458504};\\\", \\\"{x:1388,y:915,t:1526919458520};\\\", \\\"{x:1387,y:912,t:1526919458537};\\\", \\\"{x:1383,y:907,t:1526919458554};\\\", \\\"{x:1379,y:902,t:1526919458570};\\\", \\\"{x:1377,y:899,t:1526919458588};\\\", \\\"{x:1376,y:897,t:1526919458604};\\\", \\\"{x:1374,y:894,t:1526919458621};\\\", \\\"{x:1373,y:891,t:1526919458637};\\\", \\\"{x:1370,y:886,t:1526919458654};\\\", \\\"{x:1368,y:880,t:1526919458670};\\\", \\\"{x:1366,y:871,t:1526919458687};\\\", \\\"{x:1366,y:865,t:1526919458704};\\\", \\\"{x:1365,y:861,t:1526919458720};\\\", \\\"{x:1364,y:856,t:1526919458737};\\\", \\\"{x:1363,y:851,t:1526919458754};\\\", \\\"{x:1362,y:848,t:1526919458771};\\\", \\\"{x:1361,y:845,t:1526919458786};\\\", \\\"{x:1361,y:844,t:1526919458804};\\\", \\\"{x:1359,y:840,t:1526919458820};\\\", \\\"{x:1358,y:836,t:1526919458836};\\\", \\\"{x:1353,y:827,t:1526919458854};\\\", \\\"{x:1344,y:809,t:1526919458870};\\\", \\\"{x:1342,y:798,t:1526919458887};\\\", \\\"{x:1339,y:785,t:1526919458903};\\\", \\\"{x:1337,y:769,t:1526919458921};\\\", \\\"{x:1335,y:757,t:1526919458937};\\\", \\\"{x:1334,y:747,t:1526919458953};\\\", \\\"{x:1334,y:739,t:1526919458971};\\\", \\\"{x:1334,y:733,t:1526919458987};\\\", \\\"{x:1334,y:729,t:1526919459004};\\\", \\\"{x:1334,y:727,t:1526919459021};\\\", \\\"{x:1334,y:729,t:1526919459160};\\\", \\\"{x:1335,y:730,t:1526919459170};\\\", \\\"{x:1335,y:733,t:1526919459187};\\\", \\\"{x:1338,y:738,t:1526919459204};\\\", \\\"{x:1339,y:742,t:1526919459221};\\\", \\\"{x:1340,y:744,t:1526919459238};\\\", \\\"{x:1341,y:747,t:1526919459254};\\\", \\\"{x:1342,y:748,t:1526919459271};\\\", \\\"{x:1342,y:750,t:1526919459288};\\\", \\\"{x:1343,y:751,t:1526919459312};\\\", \\\"{x:1343,y:752,t:1526919459321};\\\", \\\"{x:1343,y:753,t:1526919459338};\\\", \\\"{x:1344,y:754,t:1526919459383};\\\", \\\"{x:1344,y:755,t:1526919459391};\\\", \\\"{x:1344,y:756,t:1526919459431};\\\", \\\"{x:1345,y:756,t:1526919459439};\\\", \\\"{x:1345,y:757,t:1526919459454};\\\", \\\"{x:1345,y:760,t:1526919459472};\\\", \\\"{x:1346,y:763,t:1526919459487};\\\", \\\"{x:1346,y:765,t:1526919459511};\\\", \\\"{x:1346,y:766,t:1526919460011};\\\", \\\"{x:1345,y:766,t:1526919460027};\\\", \\\"{x:1345,y:765,t:1526919460060};\\\", \\\"{x:1344,y:765,t:1526919460083};\\\", \\\"{x:1343,y:765,t:1526919460099};\\\", \\\"{x:1341,y:762,t:1526919460116};\\\", \\\"{x:1340,y:762,t:1526919460124};\\\", \\\"{x:1337,y:758,t:1526919460142};\\\", \\\"{x:1334,y:755,t:1526919460158};\\\", \\\"{x:1331,y:752,t:1526919460176};\\\", \\\"{x:1328,y:750,t:1526919460192};\\\", \\\"{x:1327,y:749,t:1526919460209};\\\", \\\"{x:1324,y:748,t:1526919460226};\\\", \\\"{x:1322,y:745,t:1526919460241};\\\", \\\"{x:1318,y:741,t:1526919460259};\\\", \\\"{x:1316,y:738,t:1526919460275};\\\", \\\"{x:1315,y:737,t:1526919460292};\\\", \\\"{x:1313,y:735,t:1526919460309};\\\", \\\"{x:1312,y:734,t:1526919460364};\\\", \\\"{x:1312,y:733,t:1526919460376};\\\", \\\"{x:1311,y:732,t:1526919460392};\\\", \\\"{x:1311,y:730,t:1526919460452};\\\", \\\"{x:1310,y:729,t:1526919460459};\\\", \\\"{x:1310,y:728,t:1526919460491};\\\", \\\"{x:1310,y:726,t:1526919460509};\\\", \\\"{x:1310,y:723,t:1526919460526};\\\", \\\"{x:1310,y:720,t:1526919460542};\\\", \\\"{x:1310,y:717,t:1526919460559};\\\", \\\"{x:1310,y:713,t:1526919460576};\\\", \\\"{x:1310,y:709,t:1526919460592};\\\", \\\"{x:1312,y:704,t:1526919460608};\\\", \\\"{x:1316,y:700,t:1526919460626};\\\", \\\"{x:1324,y:691,t:1526919460642};\\\", \\\"{x:1342,y:673,t:1526919460659};\\\", \\\"{x:1354,y:661,t:1526919460676};\\\", \\\"{x:1369,y:650,t:1526919460693};\\\", \\\"{x:1379,y:642,t:1526919460709};\\\", \\\"{x:1384,y:637,t:1526919460726};\\\", \\\"{x:1391,y:630,t:1526919460743};\\\", \\\"{x:1396,y:623,t:1526919460759};\\\", \\\"{x:1403,y:613,t:1526919460776};\\\", \\\"{x:1407,y:605,t:1526919460792};\\\", \\\"{x:1409,y:598,t:1526919460809};\\\", \\\"{x:1411,y:592,t:1526919460825};\\\", \\\"{x:1413,y:587,t:1526919460842};\\\", \\\"{x:1413,y:585,t:1526919460858};\\\", \\\"{x:1413,y:584,t:1526919460876};\\\", \\\"{x:1413,y:582,t:1526919460922};\\\", \\\"{x:1413,y:581,t:1526919460939};\\\", \\\"{x:1413,y:579,t:1526919460955};\\\", \\\"{x:1413,y:578,t:1526919460971};\\\", \\\"{x:1413,y:576,t:1526919460995};\\\", \\\"{x:1413,y:575,t:1526919461011};\\\", \\\"{x:1413,y:573,t:1526919461027};\\\", \\\"{x:1414,y:572,t:1526919461044};\\\", \\\"{x:1414,y:570,t:1526919461059};\\\", \\\"{x:1414,y:568,t:1526919461083};\\\", \\\"{x:1416,y:566,t:1526919461108};\\\", \\\"{x:1416,y:563,t:1526919461131};\\\", \\\"{x:1417,y:563,t:1526919462924};\\\", \\\"{x:1418,y:563,t:1526919462939};\\\", \\\"{x:1418,y:564,t:1526919462947};\\\", \\\"{x:1418,y:567,t:1526919462961};\\\", \\\"{x:1421,y:574,t:1526919462978};\\\", \\\"{x:1425,y:582,t:1526919462993};\\\", \\\"{x:1430,y:592,t:1526919463010};\\\", \\\"{x:1435,y:600,t:1526919463028};\\\", \\\"{x:1440,y:609,t:1526919463043};\\\", \\\"{x:1443,y:615,t:1526919463060};\\\", \\\"{x:1447,y:620,t:1526919463077};\\\", \\\"{x:1450,y:626,t:1526919463094};\\\", \\\"{x:1451,y:630,t:1526919463110};\\\", \\\"{x:1453,y:635,t:1526919463128};\\\", \\\"{x:1455,y:639,t:1526919463143};\\\", \\\"{x:1457,y:643,t:1526919463160};\\\", \\\"{x:1458,y:645,t:1526919463178};\\\", \\\"{x:1459,y:646,t:1526919463195};\\\", \\\"{x:1458,y:646,t:1526919463419};\\\", \\\"{x:1458,y:645,t:1526919463428};\\\", \\\"{x:1458,y:642,t:1526919463444};\\\", \\\"{x:1457,y:641,t:1526919463461};\\\", \\\"{x:1457,y:639,t:1526919463478};\\\", \\\"{x:1457,y:638,t:1526919463531};\\\", \\\"{x:1456,y:638,t:1526919463545};\\\", \\\"{x:1455,y:637,t:1526919463571};\\\", \\\"{x:1455,y:636,t:1526919464316};\\\", \\\"{x:1454,y:635,t:1526919464347};\\\", \\\"{x:1454,y:634,t:1526919464396};\\\", \\\"{x:1452,y:632,t:1526919464420};\\\", \\\"{x:1452,y:631,t:1526919465076};\\\", \\\"{x:1451,y:631,t:1526919465196};\\\", \\\"{x:1450,y:630,t:1526919465379};\\\", \\\"{x:1449,y:630,t:1526919465587};\\\", \\\"{x:1448,y:630,t:1526919465667};\\\", \\\"{x:1446,y:629,t:1526919465691};\\\", \\\"{x:1445,y:629,t:1526919465731};\\\", \\\"{x:1444,y:628,t:1526919465763};\\\", \\\"{x:1442,y:628,t:1526919465779};\\\", \\\"{x:1440,y:628,t:1526919465804};\\\", \\\"{x:1440,y:627,t:1526919467316};\\\", \\\"{x:1440,y:625,t:1526919467732};\\\", \\\"{x:1439,y:625,t:1526919467980};\\\", \\\"{x:1437,y:625,t:1526919468387};\\\", \\\"{x:1436,y:625,t:1526919468540};\\\", \\\"{x:1437,y:627,t:1526919468635};\\\", \\\"{x:1438,y:632,t:1526919468648};\\\", \\\"{x:1439,y:637,t:1526919468666};\\\", \\\"{x:1441,y:642,t:1526919468681};\\\", \\\"{x:1442,y:650,t:1526919468699};\\\", \\\"{x:1446,y:670,t:1526919468716};\\\", \\\"{x:1451,y:692,t:1526919468732};\\\", \\\"{x:1453,y:716,t:1526919468748};\\\", \\\"{x:1458,y:743,t:1526919468765};\\\", \\\"{x:1463,y:767,t:1526919468783};\\\", \\\"{x:1470,y:798,t:1526919468798};\\\", \\\"{x:1473,y:831,t:1526919468815};\\\", \\\"{x:1482,y:874,t:1526919468832};\\\", \\\"{x:1497,y:913,t:1526919468848};\\\", \\\"{x:1508,y:932,t:1526919468865};\\\", \\\"{x:1521,y:945,t:1526919468890};\\\", \\\"{x:1524,y:946,t:1526919468898};\\\", \\\"{x:1527,y:949,t:1526919468915};\\\", \\\"{x:1527,y:950,t:1526919468938};\\\", \\\"{x:1529,y:950,t:1526919468986};\\\", \\\"{x:1529,y:948,t:1526919468998};\\\", \\\"{x:1529,y:945,t:1526919469015};\\\", \\\"{x:1529,y:940,t:1526919469031};\\\", \\\"{x:1529,y:933,t:1526919469047};\\\", \\\"{x:1529,y:926,t:1526919469065};\\\", \\\"{x:1529,y:917,t:1526919469082};\\\", \\\"{x:1528,y:910,t:1526919469098};\\\", \\\"{x:1523,y:898,t:1526919469115};\\\", \\\"{x:1523,y:889,t:1526919469132};\\\", \\\"{x:1519,y:877,t:1526919469148};\\\", \\\"{x:1516,y:864,t:1526919469165};\\\", \\\"{x:1510,y:848,t:1526919469182};\\\", \\\"{x:1506,y:831,t:1526919469198};\\\", \\\"{x:1503,y:821,t:1526919469215};\\\", \\\"{x:1503,y:816,t:1526919469232};\\\", \\\"{x:1503,y:814,t:1526919469248};\\\", \\\"{x:1503,y:812,t:1526919469265};\\\", \\\"{x:1501,y:809,t:1526919469281};\\\", \\\"{x:1500,y:809,t:1526919469371};\\\", \\\"{x:1498,y:810,t:1526919469383};\\\", \\\"{x:1496,y:813,t:1526919469400};\\\", \\\"{x:1493,y:817,t:1526919469415};\\\", \\\"{x:1489,y:823,t:1526919469433};\\\", \\\"{x:1488,y:824,t:1526919469449};\\\", \\\"{x:1487,y:825,t:1526919469465};\\\", \\\"{x:1487,y:826,t:1526919469636};\\\", \\\"{x:1487,y:827,t:1526919469780};\\\", \\\"{x:1487,y:828,t:1526919469787};\\\", \\\"{x:1487,y:830,t:1526919469799};\\\", \\\"{x:1485,y:831,t:1526919469817};\\\", \\\"{x:1484,y:832,t:1526919469832};\\\", \\\"{x:1483,y:832,t:1526919469915};\\\", \\\"{x:1482,y:832,t:1526919469987};\\\", \\\"{x:1481,y:832,t:1526919470010};\\\", \\\"{x:1480,y:832,t:1526919470267};\\\", \\\"{x:1479,y:831,t:1526919470283};\\\", \\\"{x:1479,y:830,t:1526919471067};\\\", \\\"{x:1480,y:830,t:1526919471123};\\\", \\\"{x:1481,y:830,t:1526919471155};\\\", \\\"{x:1482,y:830,t:1526919471167};\\\", \\\"{x:1487,y:830,t:1526919471184};\\\", \\\"{x:1490,y:830,t:1526919471200};\\\", \\\"{x:1493,y:830,t:1526919471217};\\\", \\\"{x:1501,y:830,t:1526919471233};\\\", \\\"{x:1512,y:830,t:1526919471251};\\\", \\\"{x:1545,y:830,t:1526919471267};\\\", \\\"{x:1559,y:830,t:1526919471283};\\\", \\\"{x:1566,y:830,t:1526919471300};\\\", \\\"{x:1567,y:830,t:1526919471323};\\\", \\\"{x:1568,y:830,t:1526919471380};\\\", \\\"{x:1569,y:830,t:1526919471731};\\\", \\\"{x:1573,y:831,t:1526919471739};\\\", \\\"{x:1577,y:831,t:1526919471750};\\\", \\\"{x:1586,y:833,t:1526919471767};\\\", \\\"{x:1599,y:835,t:1526919471784};\\\", \\\"{x:1613,y:836,t:1526919471800};\\\", \\\"{x:1631,y:838,t:1526919471817};\\\", \\\"{x:1642,y:838,t:1526919471835};\\\", \\\"{x:1646,y:838,t:1526919471851};\\\", \\\"{x:1651,y:838,t:1526919471867};\\\", \\\"{x:1653,y:838,t:1526919471884};\\\", \\\"{x:1654,y:838,t:1526919471900};\\\", \\\"{x:1655,y:838,t:1526919471917};\\\", \\\"{x:1656,y:838,t:1526919471996};\\\", \\\"{x:1657,y:839,t:1526919472019};\\\", \\\"{x:1657,y:840,t:1526919472091};\\\", \\\"{x:1655,y:840,t:1526919472555};\\\", \\\"{x:1646,y:837,t:1526919472568};\\\", \\\"{x:1626,y:827,t:1526919472585};\\\", \\\"{x:1598,y:813,t:1526919472602};\\\", \\\"{x:1575,y:799,t:1526919472619};\\\", \\\"{x:1561,y:789,t:1526919472634};\\\", \\\"{x:1555,y:780,t:1526919472651};\\\", \\\"{x:1554,y:777,t:1526919472668};\\\", \\\"{x:1553,y:776,t:1526919472684};\\\", \\\"{x:1551,y:774,t:1526919472701};\\\", \\\"{x:1546,y:769,t:1526919472719};\\\", \\\"{x:1543,y:767,t:1526919472735};\\\", \\\"{x:1541,y:766,t:1526919472752};\\\", \\\"{x:1537,y:764,t:1526919472769};\\\", \\\"{x:1534,y:762,t:1526919472785};\\\", \\\"{x:1532,y:762,t:1526919472802};\\\", \\\"{x:1530,y:762,t:1526919472819};\\\", \\\"{x:1528,y:761,t:1526919472835};\\\", \\\"{x:1526,y:761,t:1526919472851};\\\", \\\"{x:1524,y:761,t:1526919472869};\\\", \\\"{x:1521,y:761,t:1526919472884};\\\", \\\"{x:1517,y:761,t:1526919472901};\\\", \\\"{x:1514,y:760,t:1526919472918};\\\", \\\"{x:1511,y:759,t:1526919472934};\\\", \\\"{x:1510,y:759,t:1526919472951};\\\", \\\"{x:1510,y:758,t:1526919473492};\\\", \\\"{x:1510,y:757,t:1526919473502};\\\", \\\"{x:1511,y:757,t:1526919473518};\\\", \\\"{x:1513,y:756,t:1526919473535};\\\", \\\"{x:1514,y:754,t:1526919473553};\\\", \\\"{x:1520,y:752,t:1526919473568};\\\", \\\"{x:1524,y:750,t:1526919473585};\\\", \\\"{x:1530,y:748,t:1526919473602};\\\", \\\"{x:1535,y:746,t:1526919473618};\\\", \\\"{x:1543,y:743,t:1526919473635};\\\", \\\"{x:1548,y:742,t:1526919473653};\\\", \\\"{x:1554,y:739,t:1526919473668};\\\", \\\"{x:1562,y:735,t:1526919473685};\\\", \\\"{x:1569,y:733,t:1526919473702};\\\", \\\"{x:1578,y:730,t:1526919473718};\\\", \\\"{x:1588,y:725,t:1526919473736};\\\", \\\"{x:1595,y:724,t:1526919473752};\\\", \\\"{x:1604,y:720,t:1526919473768};\\\", \\\"{x:1606,y:719,t:1526919473785};\\\", \\\"{x:1609,y:717,t:1526919473802};\\\", \\\"{x:1610,y:717,t:1526919473818};\\\", \\\"{x:1614,y:715,t:1526919473834};\\\", \\\"{x:1618,y:713,t:1526919473852};\\\", \\\"{x:1622,y:711,t:1526919473867};\\\", \\\"{x:1625,y:710,t:1526919473885};\\\", \\\"{x:1626,y:709,t:1526919473971};\\\", \\\"{x:1627,y:708,t:1526919473985};\\\", \\\"{x:1628,y:707,t:1526919474002};\\\", \\\"{x:1628,y:705,t:1526919474019};\\\", \\\"{x:1629,y:704,t:1526919474035};\\\", \\\"{x:1629,y:703,t:1526919474052};\\\", \\\"{x:1629,y:702,t:1526919474069};\\\", \\\"{x:1629,y:700,t:1526919474085};\\\", \\\"{x:1629,y:698,t:1526919474102};\\\", \\\"{x:1629,y:695,t:1526919474120};\\\", \\\"{x:1629,y:694,t:1526919474171};\\\", \\\"{x:1627,y:694,t:1526919474211};\\\", \\\"{x:1627,y:692,t:1526919474219};\\\", \\\"{x:1626,y:692,t:1526919474235};\\\", \\\"{x:1625,y:692,t:1526919474253};\\\", \\\"{x:1624,y:692,t:1526919474270};\\\", \\\"{x:1624,y:691,t:1526919474299};\\\", \\\"{x:1623,y:691,t:1526919474307};\\\", \\\"{x:1622,y:690,t:1526919474323};\\\", \\\"{x:1621,y:689,t:1526919474336};\\\", \\\"{x:1620,y:688,t:1526919474355};\\\", \\\"{x:1619,y:688,t:1526919474371};\\\", \\\"{x:1618,y:687,t:1526919474386};\\\", \\\"{x:1612,y:686,t:1526919474402};\\\", \\\"{x:1602,y:685,t:1526919474419};\\\", \\\"{x:1596,y:684,t:1526919474437};\\\", \\\"{x:1590,y:683,t:1526919474453};\\\", \\\"{x:1587,y:682,t:1526919474469};\\\", \\\"{x:1585,y:682,t:1526919474486};\\\", \\\"{x:1581,y:682,t:1526919474503};\\\", \\\"{x:1576,y:682,t:1526919474520};\\\", \\\"{x:1568,y:682,t:1526919474536};\\\", \\\"{x:1555,y:682,t:1526919474553};\\\", \\\"{x:1546,y:682,t:1526919474570};\\\", \\\"{x:1538,y:681,t:1526919474587};\\\", \\\"{x:1533,y:680,t:1526919474603};\\\", \\\"{x:1532,y:680,t:1526919474619};\\\", \\\"{x:1531,y:680,t:1526919474637};\\\", \\\"{x:1525,y:682,t:1526919474652};\\\", \\\"{x:1521,y:689,t:1526919474670};\\\", \\\"{x:1516,y:698,t:1526919474686};\\\", \\\"{x:1509,y:710,t:1526919474703};\\\", \\\"{x:1503,y:724,t:1526919474720};\\\", \\\"{x:1497,y:743,t:1526919474736};\\\", \\\"{x:1495,y:763,t:1526919474752};\\\", \\\"{x:1494,y:775,t:1526919474770};\\\", \\\"{x:1493,y:786,t:1526919474787};\\\", \\\"{x:1492,y:796,t:1526919474802};\\\", \\\"{x:1490,y:815,t:1526919474820};\\\", \\\"{x:1488,y:825,t:1526919474837};\\\", \\\"{x:1488,y:837,t:1526919474852};\\\", \\\"{x:1488,y:847,t:1526919474870};\\\", \\\"{x:1488,y:851,t:1526919474886};\\\", \\\"{x:1488,y:852,t:1526919474902};\\\", \\\"{x:1488,y:854,t:1526919474920};\\\", \\\"{x:1488,y:856,t:1526919474937};\\\", \\\"{x:1488,y:858,t:1526919474953};\\\", \\\"{x:1488,y:860,t:1526919474970};\\\", \\\"{x:1488,y:861,t:1526919475026};\\\", \\\"{x:1486,y:860,t:1526919475075};\\\", \\\"{x:1485,y:858,t:1526919475086};\\\", \\\"{x:1482,y:853,t:1526919475103};\\\", \\\"{x:1478,y:847,t:1526919475119};\\\", \\\"{x:1474,y:840,t:1526919475136};\\\", \\\"{x:1470,y:835,t:1526919475153};\\\", \\\"{x:1466,y:830,t:1526919475170};\\\", \\\"{x:1464,y:828,t:1526919475186};\\\", \\\"{x:1463,y:828,t:1526919475371};\\\", \\\"{x:1463,y:826,t:1526919475387};\\\", \\\"{x:1465,y:825,t:1526919475402};\\\", \\\"{x:1470,y:825,t:1526919475420};\\\", \\\"{x:1471,y:825,t:1526919475437};\\\", \\\"{x:1473,y:825,t:1526919475507};\\\", \\\"{x:1474,y:825,t:1526919475595};\\\", \\\"{x:1475,y:826,t:1526919475699};\\\", \\\"{x:1476,y:826,t:1526919475731};\\\", \\\"{x:1477,y:826,t:1526919475747};\\\", \\\"{x:1477,y:829,t:1526919475771};\\\", \\\"{x:1477,y:831,t:1526919475787};\\\", \\\"{x:1477,y:835,t:1526919475804};\\\", \\\"{x:1477,y:838,t:1526919475820};\\\", \\\"{x:1477,y:842,t:1526919475837};\\\", \\\"{x:1476,y:846,t:1526919475854};\\\", \\\"{x:1472,y:854,t:1526919475871};\\\", \\\"{x:1468,y:862,t:1526919475887};\\\", \\\"{x:1464,y:870,t:1526919475904};\\\", \\\"{x:1462,y:875,t:1526919475920};\\\", \\\"{x:1459,y:880,t:1526919475938};\\\", \\\"{x:1456,y:888,t:1526919475954};\\\", \\\"{x:1451,y:898,t:1526919475971};\\\", \\\"{x:1450,y:912,t:1526919475987};\\\", \\\"{x:1446,y:925,t:1526919476004};\\\", \\\"{x:1444,y:935,t:1526919476021};\\\", \\\"{x:1444,y:942,t:1526919476038};\\\", \\\"{x:1444,y:948,t:1526919476054};\\\", \\\"{x:1444,y:953,t:1526919476071};\\\", \\\"{x:1444,y:957,t:1526919476088};\\\", \\\"{x:1444,y:960,t:1526919476104};\\\", \\\"{x:1444,y:961,t:1526919476121};\\\", \\\"{x:1444,y:964,t:1526919476138};\\\", \\\"{x:1444,y:966,t:1526919476155};\\\", \\\"{x:1445,y:968,t:1526919476171};\\\", \\\"{x:1445,y:971,t:1526919476187};\\\", \\\"{x:1445,y:974,t:1526919476204};\\\", \\\"{x:1446,y:975,t:1526919476220};\\\", \\\"{x:1446,y:976,t:1526919476291};\\\", \\\"{x:1446,y:973,t:1526919476303};\\\", \\\"{x:1444,y:954,t:1526919476321};\\\", \\\"{x:1435,y:925,t:1526919476338};\\\", \\\"{x:1411,y:868,t:1526919476355};\\\", \\\"{x:1401,y:839,t:1526919476371};\\\", \\\"{x:1399,y:812,t:1526919476387};\\\", \\\"{x:1399,y:781,t:1526919476404};\\\", \\\"{x:1399,y:752,t:1526919476421};\\\", \\\"{x:1403,y:726,t:1526919476438};\\\", \\\"{x:1410,y:701,t:1526919476454};\\\", \\\"{x:1414,y:685,t:1526919476470};\\\", \\\"{x:1420,y:673,t:1526919476488};\\\", \\\"{x:1424,y:664,t:1526919476505};\\\", \\\"{x:1426,y:656,t:1526919476521};\\\", \\\"{x:1431,y:646,t:1526919476538};\\\", \\\"{x:1437,y:634,t:1526919476555};\\\", \\\"{x:1440,y:629,t:1526919476571};\\\", \\\"{x:1442,y:627,t:1526919476587};\\\", \\\"{x:1442,y:628,t:1526919476834};\\\", \\\"{x:1442,y:638,t:1526919476855};\\\", \\\"{x:1442,y:652,t:1526919476871};\\\", \\\"{x:1442,y:679,t:1526919476887};\\\", \\\"{x:1442,y:711,t:1526919476904};\\\", \\\"{x:1442,y:764,t:1526919476921};\\\", \\\"{x:1442,y:842,t:1526919476937};\\\", \\\"{x:1442,y:895,t:1526919476954};\\\", \\\"{x:1442,y:915,t:1526919476970};\\\", \\\"{x:1444,y:930,t:1526919476987};\\\", \\\"{x:1445,y:943,t:1526919477004};\\\", \\\"{x:1447,y:953,t:1526919477021};\\\", \\\"{x:1449,y:963,t:1526919477037};\\\", \\\"{x:1449,y:971,t:1526919477054};\\\", \\\"{x:1449,y:975,t:1526919477071};\\\", \\\"{x:1449,y:978,t:1526919477087};\\\", \\\"{x:1447,y:978,t:1526919477104};\\\", \\\"{x:1445,y:978,t:1526919477130};\\\", \\\"{x:1442,y:978,t:1526919477139};\\\", \\\"{x:1436,y:972,t:1526919477154};\\\", \\\"{x:1428,y:960,t:1526919477171};\\\", \\\"{x:1426,y:951,t:1526919477188};\\\", \\\"{x:1422,y:942,t:1526919477205};\\\", \\\"{x:1419,y:933,t:1526919477221};\\\", \\\"{x:1418,y:924,t:1526919477238};\\\", \\\"{x:1415,y:917,t:1526919477255};\\\", \\\"{x:1414,y:912,t:1526919477272};\\\", \\\"{x:1414,y:910,t:1526919477288};\\\", \\\"{x:1414,y:907,t:1526919477304};\\\", \\\"{x:1414,y:904,t:1526919477322};\\\", \\\"{x:1414,y:901,t:1526919477339};\\\", \\\"{x:1414,y:900,t:1526919477354};\\\", \\\"{x:1414,y:899,t:1526919477371};\\\", \\\"{x:1413,y:899,t:1526919477459};\\\", \\\"{x:1412,y:899,t:1526919477472};\\\", \\\"{x:1405,y:899,t:1526919477489};\\\", \\\"{x:1397,y:902,t:1526919477505};\\\", \\\"{x:1390,y:902,t:1526919477521};\\\", \\\"{x:1388,y:902,t:1526919477539};\\\", \\\"{x:1387,y:902,t:1526919477555};\\\", \\\"{x:1386,y:901,t:1526919478067};\\\", \\\"{x:1385,y:901,t:1526919478075};\\\", \\\"{x:1384,y:900,t:1526919478091};\\\", \\\"{x:1384,y:899,t:1526919478603};\\\", \\\"{x:1383,y:899,t:1526919478610};\\\", \\\"{x:1382,y:899,t:1526919478622};\\\", \\\"{x:1381,y:898,t:1526919478639};\\\", \\\"{x:1380,y:897,t:1526919478656};\\\", \\\"{x:1377,y:895,t:1526919478946};\\\", \\\"{x:1377,y:892,t:1526919478956};\\\", \\\"{x:1376,y:882,t:1526919478972};\\\", \\\"{x:1373,y:873,t:1526919478990};\\\", \\\"{x:1368,y:864,t:1526919479006};\\\", \\\"{x:1367,y:857,t:1526919479022};\\\", \\\"{x:1367,y:849,t:1526919479039};\\\", \\\"{x:1365,y:841,t:1526919479056};\\\", \\\"{x:1365,y:835,t:1526919479072};\\\", \\\"{x:1365,y:830,t:1526919479089};\\\", \\\"{x:1365,y:828,t:1526919479106};\\\", \\\"{x:1365,y:823,t:1526919479123};\\\", \\\"{x:1364,y:820,t:1526919479139};\\\", \\\"{x:1363,y:815,t:1526919479155};\\\", \\\"{x:1362,y:807,t:1526919479173};\\\", \\\"{x:1361,y:798,t:1526919479190};\\\", \\\"{x:1360,y:791,t:1526919479207};\\\", \\\"{x:1358,y:784,t:1526919479223};\\\", \\\"{x:1355,y:777,t:1526919479240};\\\", \\\"{x:1352,y:771,t:1526919479257};\\\", \\\"{x:1349,y:764,t:1526919479273};\\\", \\\"{x:1345,y:757,t:1526919479290};\\\", \\\"{x:1341,y:749,t:1526919479307};\\\", \\\"{x:1338,y:745,t:1526919479322};\\\", \\\"{x:1338,y:743,t:1526919479339};\\\", \\\"{x:1336,y:740,t:1526919479356};\\\", \\\"{x:1336,y:738,t:1526919479379};\\\", \\\"{x:1335,y:736,t:1526919479389};\\\", \\\"{x:1334,y:735,t:1526919479406};\\\", \\\"{x:1334,y:734,t:1526919479423};\\\", \\\"{x:1333,y:733,t:1526919479443};\\\", \\\"{x:1333,y:732,t:1526919479474};\\\", \\\"{x:1333,y:731,t:1526919479490};\\\", \\\"{x:1333,y:730,t:1526919479514};\\\", \\\"{x:1333,y:729,t:1526919479522};\\\", \\\"{x:1333,y:728,t:1526919479562};\\\", \\\"{x:1333,y:729,t:1526919479746};\\\", \\\"{x:1333,y:730,t:1526919479770};\\\", \\\"{x:1333,y:732,t:1526919479786};\\\", \\\"{x:1334,y:735,t:1526919479794};\\\", \\\"{x:1338,y:740,t:1526919479806};\\\", \\\"{x:1341,y:749,t:1526919479823};\\\", \\\"{x:1343,y:755,t:1526919479839};\\\", \\\"{x:1345,y:759,t:1526919479856};\\\", \\\"{x:1346,y:761,t:1526919479874};\\\", \\\"{x:1346,y:763,t:1526919479890};\\\", \\\"{x:1346,y:764,t:1526919479915};\\\", \\\"{x:1346,y:766,t:1526919479946};\\\", \\\"{x:1347,y:766,t:1526919480004};\\\", \\\"{x:1348,y:768,t:1526919481595};\\\", \\\"{x:1349,y:770,t:1526919481609};\\\", \\\"{x:1350,y:775,t:1526919481625};\\\", \\\"{x:1354,y:783,t:1526919481642};\\\", \\\"{x:1358,y:791,t:1526919481658};\\\", \\\"{x:1369,y:817,t:1526919481674};\\\", \\\"{x:1378,y:838,t:1526919481690};\\\", \\\"{x:1390,y:862,t:1526919481708};\\\", \\\"{x:1400,y:881,t:1526919481725};\\\", \\\"{x:1413,y:899,t:1526919481742};\\\", \\\"{x:1421,y:911,t:1526919481757};\\\", \\\"{x:1428,y:921,t:1526919481774};\\\", \\\"{x:1429,y:928,t:1526919481792};\\\", \\\"{x:1432,y:934,t:1526919481808};\\\", \\\"{x:1433,y:935,t:1526919481824};\\\", \\\"{x:1433,y:937,t:1526919481841};\\\", \\\"{x:1434,y:937,t:1526919481858};\\\", \\\"{x:1434,y:938,t:1526919481875};\\\", \\\"{x:1434,y:940,t:1526919481892};\\\", \\\"{x:1434,y:942,t:1526919481907};\\\", \\\"{x:1434,y:944,t:1526919481925};\\\", \\\"{x:1434,y:945,t:1526919482012};\\\", \\\"{x:1433,y:946,t:1526919482025};\\\", \\\"{x:1432,y:947,t:1526919482042};\\\", \\\"{x:1429,y:953,t:1526919482059};\\\", \\\"{x:1427,y:956,t:1526919482074};\\\", \\\"{x:1425,y:958,t:1526919482091};\\\", \\\"{x:1424,y:960,t:1526919482109};\\\", \\\"{x:1423,y:961,t:1526919482124};\\\", \\\"{x:1422,y:962,t:1526919482147};\\\", \\\"{x:1420,y:963,t:1526919482164};\\\", \\\"{x:1419,y:964,t:1526919482179};\\\", \\\"{x:1417,y:964,t:1526919482195};\\\", \\\"{x:1416,y:964,t:1526919482219};\\\", \\\"{x:1417,y:964,t:1526919482611};\\\", \\\"{x:1425,y:964,t:1526919482625};\\\", \\\"{x:1442,y:964,t:1526919482641};\\\", \\\"{x:1471,y:964,t:1526919482659};\\\", \\\"{x:1482,y:965,t:1526919482676};\\\", \\\"{x:1489,y:967,t:1526919482693};\\\", \\\"{x:1490,y:968,t:1526919482708};\\\", \\\"{x:1491,y:968,t:1526919482803};\\\", \\\"{x:1492,y:968,t:1526919482819};\\\", \\\"{x:1492,y:969,t:1526919482843};\\\", \\\"{x:1493,y:969,t:1526919482875};\\\", \\\"{x:1495,y:969,t:1526919483107};\\\", \\\"{x:1497,y:969,t:1526919483114};\\\", \\\"{x:1501,y:969,t:1526919483125};\\\", \\\"{x:1513,y:969,t:1526919483144};\\\", \\\"{x:1525,y:969,t:1526919483159};\\\", \\\"{x:1534,y:969,t:1526919483176};\\\", \\\"{x:1545,y:969,t:1526919483193};\\\", \\\"{x:1551,y:970,t:1526919483208};\\\", \\\"{x:1558,y:971,t:1526919483226};\\\", \\\"{x:1567,y:973,t:1526919483243};\\\", \\\"{x:1571,y:974,t:1526919483260};\\\", \\\"{x:1573,y:975,t:1526919483276};\\\", \\\"{x:1575,y:976,t:1526919483292};\\\", \\\"{x:1577,y:976,t:1526919483309};\\\", \\\"{x:1578,y:976,t:1526919483326};\\\", \\\"{x:1580,y:977,t:1526919483342};\\\", \\\"{x:1582,y:979,t:1526919483358};\\\", \\\"{x:1583,y:979,t:1526919483376};\\\", \\\"{x:1585,y:979,t:1526919483393};\\\", \\\"{x:1586,y:979,t:1526919483408};\\\", \\\"{x:1587,y:979,t:1526919483426};\\\", \\\"{x:1588,y:981,t:1526919483931};\\\", \\\"{x:1587,y:982,t:1526919483955};\\\", \\\"{x:1583,y:982,t:1526919483962};\\\", \\\"{x:1578,y:982,t:1526919483977};\\\", \\\"{x:1561,y:982,t:1526919483993};\\\", \\\"{x:1538,y:982,t:1526919484010};\\\", \\\"{x:1502,y:979,t:1526919484027};\\\", \\\"{x:1486,y:975,t:1526919484043};\\\", \\\"{x:1477,y:975,t:1526919484060};\\\", \\\"{x:1473,y:975,t:1526919484077};\\\", \\\"{x:1472,y:975,t:1526919484092};\\\", \\\"{x:1469,y:975,t:1526919484110};\\\", \\\"{x:1469,y:976,t:1526919484127};\\\", \\\"{x:1467,y:976,t:1526919484143};\\\", \\\"{x:1465,y:977,t:1526919484159};\\\", \\\"{x:1464,y:978,t:1526919484177};\\\", \\\"{x:1463,y:979,t:1526919484193};\\\", \\\"{x:1459,y:981,t:1526919484211};\\\", \\\"{x:1453,y:982,t:1526919484227};\\\", \\\"{x:1444,y:983,t:1526919484243};\\\", \\\"{x:1433,y:983,t:1526919484260};\\\", \\\"{x:1421,y:983,t:1526919484277};\\\", \\\"{x:1405,y:982,t:1526919484293};\\\", \\\"{x:1390,y:979,t:1526919484310};\\\", \\\"{x:1368,y:978,t:1526919484327};\\\", \\\"{x:1353,y:976,t:1526919484343};\\\", \\\"{x:1343,y:974,t:1526919484360};\\\", \\\"{x:1334,y:971,t:1526919484377};\\\", \\\"{x:1332,y:970,t:1526919484392};\\\", \\\"{x:1329,y:967,t:1526919484409};\\\", \\\"{x:1326,y:957,t:1526919484426};\\\", \\\"{x:1325,y:952,t:1526919484443};\\\", \\\"{x:1325,y:948,t:1526919484460};\\\", \\\"{x:1325,y:943,t:1526919484476};\\\", \\\"{x:1325,y:939,t:1526919484493};\\\", \\\"{x:1325,y:930,t:1526919484510};\\\", \\\"{x:1325,y:919,t:1526919484526};\\\", \\\"{x:1328,y:904,t:1526919484544};\\\", \\\"{x:1334,y:888,t:1526919484560};\\\", \\\"{x:1334,y:873,t:1526919484576};\\\", \\\"{x:1334,y:858,t:1526919484593};\\\", \\\"{x:1335,y:828,t:1526919484609};\\\", \\\"{x:1333,y:764,t:1526919484626};\\\", \\\"{x:1333,y:746,t:1526919484643};\\\", \\\"{x:1332,y:735,t:1526919484659};\\\", \\\"{x:1331,y:726,t:1526919484677};\\\", \\\"{x:1331,y:723,t:1526919484694};\\\", \\\"{x:1331,y:721,t:1526919484710};\\\", \\\"{x:1331,y:718,t:1526919484727};\\\", \\\"{x:1331,y:717,t:1526919484747};\\\", \\\"{x:1331,y:715,t:1526919484760};\\\", \\\"{x:1332,y:714,t:1526919484777};\\\", \\\"{x:1332,y:711,t:1526919484794};\\\", \\\"{x:1332,y:708,t:1526919484810};\\\", \\\"{x:1333,y:703,t:1526919484826};\\\", \\\"{x:1333,y:702,t:1526919484844};\\\", \\\"{x:1333,y:701,t:1526919484860};\\\", \\\"{x:1333,y:700,t:1526919484915};\\\", \\\"{x:1333,y:699,t:1526919484930};\\\", \\\"{x:1333,y:698,t:1526919484963};\\\", \\\"{x:1334,y:698,t:1526919485003};\\\", \\\"{x:1335,y:698,t:1526919485011};\\\", \\\"{x:1336,y:698,t:1526919485043};\\\", \\\"{x:1337,y:698,t:1526919485067};\\\", \\\"{x:1339,y:698,t:1526919485077};\\\", \\\"{x:1341,y:698,t:1526919485094};\\\", \\\"{x:1342,y:698,t:1526919485112};\\\", \\\"{x:1344,y:699,t:1526919485127};\\\", \\\"{x:1345,y:699,t:1526919485146};\\\", \\\"{x:1345,y:700,t:1526919485162};\\\", \\\"{x:1346,y:700,t:1526919485178};\\\", \\\"{x:1339,y:701,t:1526919485332};\\\", \\\"{x:1330,y:701,t:1526919485344};\\\", \\\"{x:1296,y:701,t:1526919485361};\\\", \\\"{x:1227,y:701,t:1526919485378};\\\", \\\"{x:1130,y:701,t:1526919485394};\\\", \\\"{x:991,y:691,t:1526919485410};\\\", \\\"{x:869,y:674,t:1526919485427};\\\", \\\"{x:745,y:636,t:1526919485443};\\\", \\\"{x:631,y:586,t:1526919485462};\\\", \\\"{x:526,y:551,t:1526919485477};\\\", \\\"{x:428,y:521,t:1526919485493};\\\", \\\"{x:320,y:491,t:1526919485530};\\\", \\\"{x:301,y:486,t:1526919485546};\\\", \\\"{x:297,y:484,t:1526919485562};\\\", \\\"{x:296,y:482,t:1526919485579};\\\", \\\"{x:296,y:479,t:1526919485595};\\\", \\\"{x:296,y:477,t:1526919485613};\\\", \\\"{x:296,y:473,t:1526919485629};\\\", \\\"{x:296,y:471,t:1526919485645};\\\", \\\"{x:301,y:469,t:1526919485662};\\\", \\\"{x:304,y:468,t:1526919485679};\\\", \\\"{x:310,y:465,t:1526919485696};\\\", \\\"{x:323,y:465,t:1526919485713};\\\", \\\"{x:338,y:470,t:1526919485730};\\\", \\\"{x:359,y:482,t:1526919485745};\\\", \\\"{x:394,y:504,t:1526919485763};\\\", \\\"{x:407,y:511,t:1526919485780};\\\", \\\"{x:413,y:515,t:1526919485796};\\\", \\\"{x:417,y:516,t:1526919485812};\\\", \\\"{x:425,y:520,t:1526919485830};\\\", \\\"{x:442,y:525,t:1526919485847};\\\", \\\"{x:478,y:526,t:1526919485862};\\\", \\\"{x:561,y:526,t:1526919485880};\\\", \\\"{x:675,y:526,t:1526919485896};\\\", \\\"{x:791,y:526,t:1526919485913};\\\", \\\"{x:886,y:526,t:1526919485929};\\\", \\\"{x:974,y:526,t:1526919485947};\\\", \\\"{x:1000,y:526,t:1526919485962};\\\", \\\"{x:1011,y:527,t:1526919485979};\\\", \\\"{x:1008,y:525,t:1526919486107};\\\", \\\"{x:996,y:522,t:1526919486115};\\\", \\\"{x:976,y:518,t:1526919486130};\\\", \\\"{x:931,y:509,t:1526919486150};\\\", \\\"{x:910,y:503,t:1526919486163};\\\", \\\"{x:899,y:499,t:1526919486179};\\\", \\\"{x:894,y:497,t:1526919486196};\\\", \\\"{x:892,y:497,t:1526919486249};\\\", \\\"{x:890,y:497,t:1526919486263};\\\", \\\"{x:884,y:497,t:1526919486279};\\\", \\\"{x:884,y:498,t:1526919486296};\\\", \\\"{x:883,y:498,t:1526919486314};\\\", \\\"{x:882,y:498,t:1526919486370};\\\", \\\"{x:882,y:499,t:1526919486381};\\\", \\\"{x:882,y:500,t:1526919486396};\\\", \\\"{x:881,y:500,t:1526919486451};\\\", \\\"{x:880,y:500,t:1526919486463};\\\", \\\"{x:876,y:500,t:1526919486481};\\\", \\\"{x:869,y:500,t:1526919486496};\\\", \\\"{x:862,y:499,t:1526919486515};\\\", \\\"{x:857,y:499,t:1526919486530};\\\", \\\"{x:854,y:499,t:1526919486546};\\\", \\\"{x:851,y:499,t:1526919486563};\\\", \\\"{x:848,y:499,t:1526919486579};\\\", \\\"{x:844,y:499,t:1526919486596};\\\", \\\"{x:843,y:499,t:1526919486613};\\\", \\\"{x:842,y:499,t:1526919486698};\\\", \\\"{x:841,y:499,t:1526919486714};\\\", \\\"{x:839,y:499,t:1526919486739};\\\", \\\"{x:839,y:500,t:1526919486746};\\\", \\\"{x:838,y:500,t:1526919486778};\\\", \\\"{x:837,y:500,t:1526919486851};\\\", \\\"{x:836,y:500,t:1526919487371};\\\", \\\"{x:836,y:501,t:1526919487382};\\\", \\\"{x:836,y:502,t:1526919487397};\\\", \\\"{x:835,y:506,t:1526919487414};\\\", \\\"{x:834,y:510,t:1526919487430};\\\", \\\"{x:834,y:513,t:1526919487448};\\\", \\\"{x:833,y:525,t:1526919487466};\\\", \\\"{x:827,y:543,t:1526919487482};\\\", \\\"{x:818,y:570,t:1526919487498};\\\", \\\"{x:805,y:598,t:1526919487513};\\\", \\\"{x:789,y:631,t:1526919487530};\\\", \\\"{x:778,y:650,t:1526919487547};\\\", \\\"{x:765,y:666,t:1526919487565};\\\", \\\"{x:749,y:684,t:1526919487581};\\\", \\\"{x:732,y:702,t:1526919487597};\\\", \\\"{x:717,y:718,t:1526919487615};\\\", \\\"{x:701,y:726,t:1526919487630};\\\", \\\"{x:689,y:731,t:1526919487647};\\\", \\\"{x:674,y:732,t:1526919487664};\\\", \\\"{x:659,y:735,t:1526919487680};\\\", \\\"{x:652,y:736,t:1526919487697};\\\", \\\"{x:649,y:737,t:1526919487714};\\\", \\\"{x:648,y:737,t:1526919487763};\\\", \\\"{x:645,y:737,t:1526919487778};\\\", \\\"{x:644,y:737,t:1526919487787};\\\", \\\"{x:641,y:737,t:1526919487798};\\\", \\\"{x:634,y:736,t:1526919487814};\\\", \\\"{x:619,y:736,t:1526919487830};\\\", \\\"{x:601,y:736,t:1526919487847};\\\", \\\"{x:583,y:736,t:1526919487864};\\\", \\\"{x:571,y:736,t:1526919487880};\\\", \\\"{x:562,y:736,t:1526919487898};\\\", \\\"{x:555,y:736,t:1526919487914};\\\", \\\"{x:551,y:736,t:1526919487932};\\\", \\\"{x:549,y:736,t:1526919487947};\\\", \\\"{x:548,y:736,t:1526919487969};\\\", \\\"{x:547,y:735,t:1526919487982};\\\", \\\"{x:546,y:735,t:1526919488002};\\\", \\\"{x:545,y:735,t:1526919488014};\\\", \\\"{x:534,y:735,t:1526919488032};\\\", \\\"{x:517,y:735,t:1526919488048};\\\", \\\"{x:514,y:734,t:1526919488065};\\\", \\\"{x:513,y:734,t:1526919488081};\\\", \\\"{x:511,y:734,t:1526919488106};\\\", \\\"{x:509,y:734,t:1526919488114};\\\", \\\"{x:502,y:735,t:1526919488131};\\\", \\\"{x:498,y:737,t:1526919488149};\\\", \\\"{x:497,y:738,t:1526919488165};\\\", \\\"{x:497,y:739,t:1526919488771};\\\", \\\"{x:495,y:739,t:1526919488995};\\\", \\\"{x:495,y:738,t:1526919489123};\\\", \\\"{x:494,y:738,t:1526919490283};\\\", \\\"{x:491,y:738,t:1526919490683};\\\", \\\"{x:476,y:728,t:1526919490700};\\\", \\\"{x:468,y:721,t:1526919490717};\\\", \\\"{x:468,y:718,t:1526919490734};\\\", \\\"{x:468,y:716,t:1526919490750};\\\", \\\"{x:468,y:714,t:1526919490766};\\\", \\\"{x:469,y:714,t:1526919490784};\\\", \\\"{x:469,y:713,t:1526919490842};\\\", \\\"{x:469,y:712,t:1526919490850};\\\", \\\"{x:469,y:710,t:1526919491178};\\\" ] }, { \\\"rt\\\": 21708, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 893151, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-B -B -11 AM-11 AM-12 PM-11 AM-10 AM-09 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:472,y:713,t:1526919493339};\\\", \\\"{x:477,y:717,t:1526919493352};\\\", \\\"{x:485,y:722,t:1526919493370};\\\", \\\"{x:499,y:726,t:1526919493385};\\\", \\\"{x:520,y:726,t:1526919493401};\\\", \\\"{x:566,y:722,t:1526919493419};\\\", \\\"{x:647,y:709,t:1526919493435};\\\", \\\"{x:750,y:693,t:1526919493452};\\\", \\\"{x:872,y:679,t:1526919493468};\\\", \\\"{x:1007,y:662,t:1526919493486};\\\", \\\"{x:1142,y:647,t:1526919493502};\\\", \\\"{x:1259,y:647,t:1526919493519};\\\", \\\"{x:1378,y:647,t:1526919493535};\\\", \\\"{x:1511,y:647,t:1526919493551};\\\", \\\"{x:1633,y:669,t:1526919493568};\\\", \\\"{x:1776,y:717,t:1526919493586};\\\", \\\"{x:1832,y:744,t:1526919493602};\\\", \\\"{x:1863,y:764,t:1526919493619};\\\", \\\"{x:1878,y:777,t:1526919493636};\\\", \\\"{x:1885,y:791,t:1526919493652};\\\", \\\"{x:1888,y:804,t:1526919493669};\\\", \\\"{x:1888,y:819,t:1526919493686};\\\", \\\"{x:1888,y:835,t:1526919493703};\\\", \\\"{x:1888,y:848,t:1526919493719};\\\", \\\"{x:1886,y:857,t:1526919493736};\\\", \\\"{x:1877,y:873,t:1526919493753};\\\", \\\"{x:1859,y:903,t:1526919493769};\\\", \\\"{x:1838,y:940,t:1526919493787};\\\", \\\"{x:1826,y:951,t:1526919493802};\\\", \\\"{x:1821,y:954,t:1526919493819};\\\", \\\"{x:1815,y:959,t:1526919493836};\\\", \\\"{x:1807,y:964,t:1526919493853};\\\", \\\"{x:1800,y:965,t:1526919493870};\\\", \\\"{x:1791,y:966,t:1526919493886};\\\", \\\"{x:1775,y:969,t:1526919493903};\\\", \\\"{x:1758,y:971,t:1526919493919};\\\", \\\"{x:1742,y:974,t:1526919493936};\\\", \\\"{x:1726,y:977,t:1526919493954};\\\", \\\"{x:1713,y:982,t:1526919493969};\\\", \\\"{x:1681,y:986,t:1526919493986};\\\", \\\"{x:1660,y:989,t:1526919494002};\\\", \\\"{x:1646,y:992,t:1526919494019};\\\", \\\"{x:1626,y:998,t:1526919494036};\\\", \\\"{x:1607,y:1003,t:1526919494053};\\\", \\\"{x:1590,y:1007,t:1526919494069};\\\", \\\"{x:1577,y:1012,t:1526919494086};\\\", \\\"{x:1565,y:1014,t:1526919494103};\\\", \\\"{x:1554,y:1016,t:1526919494119};\\\", \\\"{x:1543,y:1018,t:1526919494136};\\\", \\\"{x:1529,y:1021,t:1526919494153};\\\", \\\"{x:1504,y:1023,t:1526919494170};\\\", \\\"{x:1488,y:1023,t:1526919494186};\\\", \\\"{x:1473,y:1023,t:1526919494203};\\\", \\\"{x:1459,y:1023,t:1526919494220};\\\", \\\"{x:1451,y:1023,t:1526919494236};\\\", \\\"{x:1442,y:1023,t:1526919494253};\\\", \\\"{x:1438,y:1023,t:1526919494270};\\\", \\\"{x:1432,y:1022,t:1526919494286};\\\", \\\"{x:1428,y:1021,t:1526919494303};\\\", \\\"{x:1426,y:1020,t:1526919494320};\\\", \\\"{x:1420,y:1018,t:1526919494336};\\\", \\\"{x:1417,y:1016,t:1526919494353};\\\", \\\"{x:1410,y:1014,t:1526919494370};\\\", \\\"{x:1407,y:1014,t:1526919494387};\\\", \\\"{x:1405,y:1013,t:1526919494403};\\\", \\\"{x:1404,y:1012,t:1526919494421};\\\", \\\"{x:1403,y:1010,t:1526919494436};\\\", \\\"{x:1402,y:1010,t:1526919494454};\\\", \\\"{x:1401,y:1009,t:1526919494470};\\\", \\\"{x:1398,y:1008,t:1526919494486};\\\", \\\"{x:1397,y:1007,t:1526919494503};\\\", \\\"{x:1395,y:1007,t:1526919494520};\\\", \\\"{x:1393,y:1007,t:1526919494537};\\\", \\\"{x:1392,y:1007,t:1526919494553};\\\", \\\"{x:1391,y:1007,t:1526919494627};\\\", \\\"{x:1390,y:1006,t:1526919494637};\\\", \\\"{x:1389,y:1006,t:1526919494653};\\\", \\\"{x:1388,y:1005,t:1526919494670};\\\", \\\"{x:1387,y:1003,t:1526919494691};\\\", \\\"{x:1386,y:1002,t:1526919494703};\\\", \\\"{x:1383,y:1001,t:1526919494720};\\\", \\\"{x:1382,y:999,t:1526919494737};\\\", \\\"{x:1379,y:994,t:1526919494753};\\\", \\\"{x:1379,y:987,t:1526919494771};\\\", \\\"{x:1379,y:972,t:1526919494786};\\\", \\\"{x:1379,y:951,t:1526919494803};\\\", \\\"{x:1374,y:929,t:1526919494821};\\\", \\\"{x:1372,y:912,t:1526919494837};\\\", \\\"{x:1366,y:900,t:1526919494853};\\\", \\\"{x:1356,y:884,t:1526919494870};\\\", \\\"{x:1350,y:871,t:1526919494888};\\\", \\\"{x:1346,y:854,t:1526919494904};\\\", \\\"{x:1343,y:832,t:1526919494920};\\\", \\\"{x:1341,y:817,t:1526919494938};\\\", \\\"{x:1340,y:810,t:1526919494953};\\\", \\\"{x:1338,y:804,t:1526919494970};\\\", \\\"{x:1337,y:794,t:1526919494987};\\\", \\\"{x:1337,y:790,t:1526919495003};\\\", \\\"{x:1337,y:787,t:1526919495020};\\\", \\\"{x:1336,y:783,t:1526919495038};\\\", \\\"{x:1335,y:779,t:1526919495054};\\\", \\\"{x:1332,y:773,t:1526919495070};\\\", \\\"{x:1330,y:771,t:1526919495087};\\\", \\\"{x:1330,y:768,t:1526919495104};\\\", \\\"{x:1329,y:767,t:1526919495120};\\\", \\\"{x:1329,y:765,t:1526919495137};\\\", \\\"{x:1329,y:764,t:1526919495163};\\\", \\\"{x:1330,y:763,t:1526919495178};\\\", \\\"{x:1332,y:762,t:1526919495188};\\\", \\\"{x:1336,y:761,t:1526919495205};\\\", \\\"{x:1338,y:761,t:1526919495221};\\\", \\\"{x:1340,y:761,t:1526919495237};\\\", \\\"{x:1342,y:761,t:1526919495254};\\\", \\\"{x:1345,y:763,t:1526919495272};\\\", \\\"{x:1348,y:771,t:1526919495287};\\\", \\\"{x:1348,y:777,t:1526919495303};\\\", \\\"{x:1348,y:780,t:1526919495319};\\\", \\\"{x:1349,y:785,t:1526919495336};\\\", \\\"{x:1351,y:799,t:1526919495354};\\\", \\\"{x:1352,y:819,t:1526919495369};\\\", \\\"{x:1352,y:836,t:1526919495387};\\\", \\\"{x:1354,y:858,t:1526919495404};\\\", \\\"{x:1357,y:879,t:1526919495420};\\\", \\\"{x:1357,y:897,t:1526919495437};\\\", \\\"{x:1357,y:910,t:1526919495454};\\\", \\\"{x:1359,y:926,t:1526919495469};\\\", \\\"{x:1359,y:933,t:1526919495486};\\\", \\\"{x:1361,y:940,t:1526919495504};\\\", \\\"{x:1363,y:944,t:1526919495520};\\\", \\\"{x:1363,y:950,t:1526919495537};\\\", \\\"{x:1365,y:960,t:1526919495554};\\\", \\\"{x:1365,y:963,t:1526919495570};\\\", \\\"{x:1365,y:965,t:1526919495588};\\\", \\\"{x:1365,y:967,t:1526919495603};\\\", \\\"{x:1365,y:963,t:1526919495707};\\\", \\\"{x:1365,y:955,t:1526919495722};\\\", \\\"{x:1365,y:930,t:1526919495737};\\\", \\\"{x:1365,y:892,t:1526919495755};\\\", \\\"{x:1365,y:872,t:1526919495771};\\\", \\\"{x:1365,y:861,t:1526919495788};\\\", \\\"{x:1365,y:854,t:1526919495804};\\\", \\\"{x:1365,y:850,t:1526919495821};\\\", \\\"{x:1365,y:849,t:1526919495838};\\\", \\\"{x:1365,y:847,t:1526919495854};\\\", \\\"{x:1366,y:847,t:1526919495872};\\\", \\\"{x:1366,y:844,t:1526919495887};\\\", \\\"{x:1366,y:841,t:1526919495905};\\\", \\\"{x:1365,y:838,t:1526919495921};\\\", \\\"{x:1364,y:833,t:1526919495937};\\\", \\\"{x:1360,y:824,t:1526919495955};\\\", \\\"{x:1356,y:816,t:1526919495971};\\\", \\\"{x:1354,y:809,t:1526919495987};\\\", \\\"{x:1352,y:802,t:1526919496004};\\\", \\\"{x:1349,y:796,t:1526919496021};\\\", \\\"{x:1349,y:790,t:1526919496039};\\\", \\\"{x:1349,y:788,t:1526919496054};\\\", \\\"{x:1349,y:785,t:1526919496071};\\\", \\\"{x:1348,y:783,t:1526919496088};\\\", \\\"{x:1348,y:782,t:1526919496115};\\\", \\\"{x:1348,y:781,t:1526919496139};\\\", \\\"{x:1348,y:779,t:1526919496154};\\\", \\\"{x:1347,y:777,t:1526919496170};\\\", \\\"{x:1347,y:775,t:1526919496188};\\\", \\\"{x:1346,y:775,t:1526919496204};\\\", \\\"{x:1345,y:774,t:1526919496402};\\\", \\\"{x:1345,y:773,t:1526919496419};\\\", \\\"{x:1345,y:772,t:1526919496427};\\\", \\\"{x:1345,y:769,t:1526919496439};\\\", \\\"{x:1345,y:768,t:1526919496455};\\\", \\\"{x:1345,y:766,t:1526919496471};\\\", \\\"{x:1345,y:764,t:1526919496488};\\\", \\\"{x:1345,y:763,t:1526919496505};\\\", \\\"{x:1345,y:762,t:1526919496521};\\\", \\\"{x:1345,y:761,t:1526919496987};\\\", \\\"{x:1341,y:761,t:1526919497131};\\\", \\\"{x:1333,y:764,t:1526919497139};\\\", \\\"{x:1317,y:766,t:1526919497155};\\\", \\\"{x:1287,y:774,t:1526919497172};\\\", \\\"{x:1248,y:778,t:1526919497188};\\\", \\\"{x:1217,y:782,t:1526919497205};\\\", \\\"{x:1174,y:783,t:1526919497223};\\\", \\\"{x:1137,y:783,t:1526919497238};\\\", \\\"{x:1095,y:783,t:1526919497255};\\\", \\\"{x:1045,y:783,t:1526919497273};\\\", \\\"{x:981,y:783,t:1526919497288};\\\", \\\"{x:901,y:783,t:1526919497306};\\\", \\\"{x:814,y:783,t:1526919497322};\\\", \\\"{x:772,y:783,t:1526919497338};\\\", \\\"{x:730,y:783,t:1526919497355};\\\", \\\"{x:691,y:780,t:1526919497372};\\\", \\\"{x:644,y:774,t:1526919497388};\\\", \\\"{x:617,y:772,t:1526919497405};\\\", \\\"{x:597,y:768,t:1526919497422};\\\", \\\"{x:586,y:767,t:1526919497438};\\\", \\\"{x:580,y:767,t:1526919497455};\\\", \\\"{x:576,y:764,t:1526919497472};\\\", \\\"{x:570,y:763,t:1526919497489};\\\", \\\"{x:552,y:758,t:1526919497505};\\\", \\\"{x:522,y:749,t:1526919497523};\\\", \\\"{x:509,y:743,t:1526919497538};\\\", \\\"{x:501,y:736,t:1526919497555};\\\", \\\"{x:487,y:724,t:1526919497571};\\\", \\\"{x:470,y:712,t:1526919497589};\\\", \\\"{x:450,y:704,t:1526919497606};\\\", \\\"{x:429,y:693,t:1526919497621};\\\", \\\"{x:409,y:681,t:1526919497639};\\\", \\\"{x:386,y:669,t:1526919497657};\\\", \\\"{x:368,y:657,t:1526919497672};\\\", \\\"{x:353,y:645,t:1526919497689};\\\", \\\"{x:336,y:623,t:1526919497706};\\\", \\\"{x:328,y:610,t:1526919497722};\\\", \\\"{x:326,y:596,t:1526919497739};\\\", \\\"{x:326,y:578,t:1526919497756};\\\", \\\"{x:336,y:556,t:1526919497772};\\\", \\\"{x:363,y:524,t:1526919497789};\\\", \\\"{x:415,y:494,t:1526919497806};\\\", \\\"{x:491,y:456,t:1526919497822};\\\", \\\"{x:572,y:441,t:1526919497838};\\\", \\\"{x:628,y:433,t:1526919497856};\\\", \\\"{x:699,y:438,t:1526919497872};\\\", \\\"{x:730,y:442,t:1526919497889};\\\", \\\"{x:746,y:451,t:1526919497905};\\\", \\\"{x:752,y:458,t:1526919497921};\\\", \\\"{x:754,y:465,t:1526919497939};\\\", \\\"{x:756,y:472,t:1526919497956};\\\", \\\"{x:757,y:479,t:1526919497971};\\\", \\\"{x:757,y:488,t:1526919497990};\\\", \\\"{x:758,y:500,t:1526919498005};\\\", \\\"{x:759,y:510,t:1526919498022};\\\", \\\"{x:755,y:518,t:1526919498040};\\\", \\\"{x:745,y:529,t:1526919498057};\\\", \\\"{x:725,y:542,t:1526919498072};\\\", \\\"{x:702,y:551,t:1526919498089};\\\", \\\"{x:665,y:565,t:1526919498108};\\\", \\\"{x:635,y:573,t:1526919498123};\\\", \\\"{x:599,y:578,t:1526919498139};\\\", \\\"{x:557,y:583,t:1526919498155};\\\", \\\"{x:504,y:583,t:1526919498173};\\\", \\\"{x:448,y:583,t:1526919498189};\\\", \\\"{x:357,y:583,t:1526919498205};\\\", \\\"{x:263,y:583,t:1526919498224};\\\", \\\"{x:168,y:583,t:1526919498239};\\\", \\\"{x:85,y:583,t:1526919498256};\\\", \\\"{x:26,y:583,t:1526919498273};\\\", \\\"{x:0,y:580,t:1526919498289};\\\", \\\"{x:0,y:577,t:1526919498305};\\\", \\\"{x:0,y:576,t:1526919498370};\\\", \\\"{x:2,y:575,t:1526919498377};\\\", \\\"{x:5,y:573,t:1526919498388};\\\", \\\"{x:17,y:571,t:1526919498406};\\\", \\\"{x:39,y:567,t:1526919498423};\\\", \\\"{x:68,y:565,t:1526919498440};\\\", \\\"{x:97,y:563,t:1526919498456};\\\", \\\"{x:120,y:563,t:1526919498472};\\\", \\\"{x:135,y:563,t:1526919498489};\\\", \\\"{x:142,y:563,t:1526919498505};\\\", \\\"{x:143,y:563,t:1526919498570};\\\", \\\"{x:144,y:563,t:1526919498586};\\\", \\\"{x:145,y:562,t:1526919498595};\\\", \\\"{x:146,y:559,t:1526919498690};\\\", \\\"{x:146,y:556,t:1526919498705};\\\", \\\"{x:148,y:554,t:1526919498723};\\\", \\\"{x:148,y:553,t:1526919498740};\\\", \\\"{x:148,y:552,t:1526919498756};\\\", \\\"{x:149,y:551,t:1526919498891};\\\", \\\"{x:149,y:550,t:1526919498906};\\\", \\\"{x:149,y:549,t:1526919498938};\\\", \\\"{x:152,y:549,t:1526919505099};\\\", \\\"{x:160,y:549,t:1526919505111};\\\", \\\"{x:177,y:551,t:1526919505129};\\\", \\\"{x:194,y:553,t:1526919505143};\\\", \\\"{x:214,y:556,t:1526919505161};\\\", \\\"{x:232,y:562,t:1526919505175};\\\", \\\"{x:257,y:567,t:1526919505192};\\\", \\\"{x:287,y:575,t:1526919505210};\\\", \\\"{x:338,y:592,t:1526919505228};\\\", \\\"{x:366,y:600,t:1526919505246};\\\", \\\"{x:395,y:607,t:1526919505262};\\\", \\\"{x:419,y:615,t:1526919505278};\\\", \\\"{x:439,y:622,t:1526919505295};\\\", \\\"{x:451,y:629,t:1526919505311};\\\", \\\"{x:471,y:640,t:1526919505329};\\\", \\\"{x:489,y:655,t:1526919505345};\\\", \\\"{x:518,y:681,t:1526919505362};\\\", \\\"{x:546,y:702,t:1526919505378};\\\", \\\"{x:575,y:725,t:1526919505395};\\\", \\\"{x:644,y:768,t:1526919505412};\\\", \\\"{x:719,y:799,t:1526919505428};\\\", \\\"{x:796,y:821,t:1526919505445};\\\", \\\"{x:887,y:840,t:1526919505462};\\\", \\\"{x:988,y:862,t:1526919505478};\\\", \\\"{x:1102,y:881,t:1526919505495};\\\", \\\"{x:1207,y:894,t:1526919505512};\\\", \\\"{x:1312,y:921,t:1526919505528};\\\", \\\"{x:1417,y:951,t:1526919505545};\\\", \\\"{x:1535,y:990,t:1526919505563};\\\", \\\"{x:1571,y:1006,t:1526919505579};\\\", \\\"{x:1590,y:1018,t:1526919505596};\\\", \\\"{x:1605,y:1024,t:1526919505612};\\\", \\\"{x:1615,y:1031,t:1526919505628};\\\", \\\"{x:1624,y:1036,t:1526919505646};\\\", \\\"{x:1630,y:1041,t:1526919505663};\\\", \\\"{x:1631,y:1042,t:1526919505678};\\\", \\\"{x:1627,y:1042,t:1526919505723};\\\", \\\"{x:1618,y:1042,t:1526919505730};\\\", \\\"{x:1608,y:1039,t:1526919505746};\\\", \\\"{x:1572,y:1038,t:1526919505762};\\\", \\\"{x:1535,y:1038,t:1526919505779};\\\", \\\"{x:1485,y:1038,t:1526919505796};\\\", \\\"{x:1424,y:1038,t:1526919505813};\\\", \\\"{x:1382,y:1038,t:1526919505830};\\\", \\\"{x:1356,y:1038,t:1526919505846};\\\", \\\"{x:1341,y:1038,t:1526919505863};\\\", \\\"{x:1332,y:1038,t:1526919505880};\\\", \\\"{x:1326,y:1037,t:1526919505896};\\\", \\\"{x:1314,y:1033,t:1526919505912};\\\", \\\"{x:1305,y:1028,t:1526919505930};\\\", \\\"{x:1294,y:1020,t:1526919505945};\\\", \\\"{x:1278,y:1007,t:1526919505962};\\\", \\\"{x:1273,y:1000,t:1526919505979};\\\", \\\"{x:1273,y:994,t:1526919505995};\\\", \\\"{x:1273,y:989,t:1526919506012};\\\", \\\"{x:1273,y:982,t:1526919506030};\\\", \\\"{x:1270,y:975,t:1526919506046};\\\", \\\"{x:1268,y:969,t:1526919506063};\\\", \\\"{x:1265,y:964,t:1526919506080};\\\", \\\"{x:1263,y:963,t:1526919506096};\\\", \\\"{x:1262,y:962,t:1526919506113};\\\", \\\"{x:1255,y:961,t:1526919506130};\\\", \\\"{x:1233,y:957,t:1526919506146};\\\", \\\"{x:1220,y:957,t:1526919506163};\\\", \\\"{x:1209,y:956,t:1526919506180};\\\", \\\"{x:1205,y:956,t:1526919506196};\\\", \\\"{x:1203,y:955,t:1526919506213};\\\", \\\"{x:1205,y:955,t:1526919506323};\\\", \\\"{x:1210,y:955,t:1526919506330};\\\", \\\"{x:1226,y:955,t:1526919506347};\\\", \\\"{x:1246,y:955,t:1526919506362};\\\", \\\"{x:1265,y:958,t:1526919506380};\\\", \\\"{x:1280,y:963,t:1526919506397};\\\", \\\"{x:1284,y:965,t:1526919506413};\\\", \\\"{x:1284,y:966,t:1526919506451};\\\", \\\"{x:1284,y:967,t:1526919506474};\\\", \\\"{x:1284,y:968,t:1526919506498};\\\", \\\"{x:1284,y:969,t:1526919506531};\\\", \\\"{x:1284,y:970,t:1526919506587};\\\", \\\"{x:1283,y:970,t:1526919506691};\\\", \\\"{x:1282,y:969,t:1526919506714};\\\", \\\"{x:1281,y:969,t:1526919506842};\\\", \\\"{x:1281,y:968,t:1526919506875};\\\", \\\"{x:1280,y:968,t:1526919506955};\\\", \\\"{x:1279,y:967,t:1526919507019};\\\", \\\"{x:1280,y:967,t:1526919507475};\\\", \\\"{x:1283,y:967,t:1526919507483};\\\", \\\"{x:1285,y:967,t:1526919507498};\\\", \\\"{x:1296,y:967,t:1526919507514};\\\", \\\"{x:1308,y:967,t:1526919507531};\\\", \\\"{x:1315,y:967,t:1526919507548};\\\", \\\"{x:1321,y:967,t:1526919507564};\\\", \\\"{x:1325,y:967,t:1526919507581};\\\", \\\"{x:1329,y:967,t:1526919507597};\\\", \\\"{x:1331,y:967,t:1526919507614};\\\", \\\"{x:1333,y:967,t:1526919507630};\\\", \\\"{x:1338,y:967,t:1526919507648};\\\", \\\"{x:1341,y:967,t:1526919507665};\\\", \\\"{x:1345,y:967,t:1526919507680};\\\", \\\"{x:1347,y:967,t:1526919507698};\\\", \\\"{x:1346,y:967,t:1526919508627};\\\", \\\"{x:1345,y:967,t:1526919508635};\\\", \\\"{x:1342,y:968,t:1526919508649};\\\", \\\"{x:1330,y:970,t:1526919508666};\\\", \\\"{x:1307,y:970,t:1526919508682};\\\", \\\"{x:1263,y:970,t:1526919508698};\\\", \\\"{x:1235,y:970,t:1526919508715};\\\", \\\"{x:1209,y:971,t:1526919508731};\\\", \\\"{x:1194,y:971,t:1526919508749};\\\", \\\"{x:1188,y:971,t:1526919508765};\\\", \\\"{x:1185,y:971,t:1526919508782};\\\", \\\"{x:1183,y:971,t:1526919508798};\\\", \\\"{x:1182,y:971,t:1526919508815};\\\", \\\"{x:1179,y:971,t:1526919508831};\\\", \\\"{x:1173,y:971,t:1526919508848};\\\", \\\"{x:1167,y:971,t:1526919508866};\\\", \\\"{x:1161,y:970,t:1526919508881};\\\", \\\"{x:1160,y:970,t:1526919508898};\\\", \\\"{x:1159,y:970,t:1526919508962};\\\", \\\"{x:1157,y:970,t:1526919508969};\\\", \\\"{x:1156,y:970,t:1526919508985};\\\", \\\"{x:1155,y:970,t:1526919508999};\\\", \\\"{x:1154,y:970,t:1526919509042};\\\", \\\"{x:1154,y:969,t:1526919509123};\\\", \\\"{x:1153,y:969,t:1526919509202};\\\", \\\"{x:1153,y:968,t:1526919509219};\\\", \\\"{x:1153,y:967,t:1526919509235};\\\", \\\"{x:1153,y:966,t:1526919509248};\\\", \\\"{x:1157,y:964,t:1526919509266};\\\", \\\"{x:1170,y:963,t:1526919509282};\\\", \\\"{x:1181,y:962,t:1526919509299};\\\", \\\"{x:1193,y:962,t:1526919509316};\\\", \\\"{x:1199,y:962,t:1526919509333};\\\", \\\"{x:1205,y:962,t:1526919509349};\\\", \\\"{x:1207,y:962,t:1526919509366};\\\", \\\"{x:1209,y:962,t:1526919509383};\\\", \\\"{x:1212,y:962,t:1526919509398};\\\", \\\"{x:1213,y:962,t:1526919509416};\\\", \\\"{x:1214,y:962,t:1526919509433};\\\", \\\"{x:1215,y:962,t:1526919509491};\\\", \\\"{x:1216,y:963,t:1526919510291};\\\", \\\"{x:1216,y:964,t:1526919510674};\\\", \\\"{x:1216,y:965,t:1526919510706};\\\", \\\"{x:1215,y:965,t:1526919510723};\\\", \\\"{x:1215,y:966,t:1526919510734};\\\", \\\"{x:1214,y:966,t:1526919510751};\\\", \\\"{x:1213,y:966,t:1526919510778};\\\", \\\"{x:1212,y:966,t:1526919510842};\\\", \\\"{x:1211,y:966,t:1526919511099};\\\", \\\"{x:1210,y:966,t:1526919511186};\\\", \\\"{x:1208,y:966,t:1526919511201};\\\", \\\"{x:1203,y:962,t:1526919511219};\\\", \\\"{x:1203,y:960,t:1526919511234};\\\", \\\"{x:1202,y:960,t:1526919511251};\\\", \\\"{x:1202,y:959,t:1526919511531};\\\", \\\"{x:1202,y:958,t:1526919511539};\\\", \\\"{x:1204,y:956,t:1526919511551};\\\", \\\"{x:1210,y:953,t:1526919511568};\\\", \\\"{x:1216,y:951,t:1526919511585};\\\", \\\"{x:1222,y:949,t:1526919511601};\\\", \\\"{x:1237,y:946,t:1526919511618};\\\", \\\"{x:1247,y:944,t:1526919511634};\\\", \\\"{x:1255,y:944,t:1526919511651};\\\", \\\"{x:1261,y:944,t:1526919511668};\\\", \\\"{x:1264,y:944,t:1526919511685};\\\", \\\"{x:1268,y:946,t:1526919511701};\\\", \\\"{x:1272,y:949,t:1526919511718};\\\", \\\"{x:1277,y:953,t:1526919511735};\\\", \\\"{x:1282,y:957,t:1526919511751};\\\", \\\"{x:1285,y:961,t:1526919511768};\\\", \\\"{x:1286,y:963,t:1526919511786};\\\", \\\"{x:1288,y:964,t:1526919511801};\\\", \\\"{x:1288,y:967,t:1526919511818};\\\", \\\"{x:1288,y:968,t:1526919511835};\\\", \\\"{x:1288,y:969,t:1526919511853};\\\", \\\"{x:1287,y:969,t:1526919512043};\\\", \\\"{x:1287,y:968,t:1526919512059};\\\", \\\"{x:1286,y:967,t:1526919512068};\\\", \\\"{x:1285,y:967,t:1526919512085};\\\", \\\"{x:1282,y:966,t:1526919512101};\\\", \\\"{x:1277,y:965,t:1526919512118};\\\", \\\"{x:1267,y:965,t:1526919512135};\\\", \\\"{x:1257,y:965,t:1526919512152};\\\", \\\"{x:1244,y:965,t:1526919512168};\\\", \\\"{x:1224,y:961,t:1526919512185};\\\", \\\"{x:1162,y:953,t:1526919512202};\\\", \\\"{x:1074,y:928,t:1526919512218};\\\", \\\"{x:971,y:900,t:1526919512235};\\\", \\\"{x:880,y:877,t:1526919512252};\\\", \\\"{x:816,y:858,t:1526919512269};\\\", \\\"{x:781,y:844,t:1526919512285};\\\", \\\"{x:767,y:837,t:1526919512302};\\\", \\\"{x:764,y:834,t:1526919512319};\\\", \\\"{x:763,y:834,t:1526919512334};\\\", \\\"{x:763,y:832,t:1526919512352};\\\", \\\"{x:762,y:831,t:1526919512369};\\\", \\\"{x:758,y:829,t:1526919512384};\\\", \\\"{x:751,y:828,t:1526919512402};\\\", \\\"{x:740,y:824,t:1526919512418};\\\", \\\"{x:724,y:819,t:1526919512434};\\\", \\\"{x:705,y:813,t:1526919512452};\\\", \\\"{x:688,y:809,t:1526919512469};\\\", \\\"{x:661,y:807,t:1526919512485};\\\", \\\"{x:627,y:802,t:1526919512501};\\\", \\\"{x:597,y:797,t:1526919512519};\\\", \\\"{x:581,y:794,t:1526919512534};\\\", \\\"{x:570,y:791,t:1526919512552};\\\", \\\"{x:564,y:786,t:1526919512569};\\\", \\\"{x:558,y:783,t:1526919512584};\\\", \\\"{x:547,y:775,t:1526919512602};\\\", \\\"{x:542,y:771,t:1526919512619};\\\", \\\"{x:536,y:766,t:1526919512635};\\\", \\\"{x:531,y:759,t:1526919512652};\\\", \\\"{x:530,y:754,t:1526919512669};\\\", \\\"{x:528,y:750,t:1526919512685};\\\", \\\"{x:527,y:745,t:1526919512701};\\\", \\\"{x:527,y:742,t:1526919512715};\\\", \\\"{x:527,y:738,t:1526919512731};\\\", \\\"{x:527,y:736,t:1526919512748};\\\", \\\"{x:525,y:736,t:1526919513659};\\\", \\\"{x:525,y:735,t:1526919513669};\\\", \\\"{x:528,y:735,t:1526919513882};\\\", \\\"{x:535,y:731,t:1526919513889};\\\", \\\"{x:545,y:730,t:1526919513902};\\\", \\\"{x:563,y:730,t:1526919513918};\\\", \\\"{x:579,y:730,t:1526919513935};\\\", \\\"{x:594,y:729,t:1526919513951};\\\", \\\"{x:609,y:729,t:1526919513968};\\\", \\\"{x:625,y:729,t:1526919513985};\\\", \\\"{x:633,y:729,t:1526919514002};\\\", \\\"{x:644,y:729,t:1526919514019};\\\", \\\"{x:654,y:729,t:1526919514035};\\\", \\\"{x:665,y:729,t:1526919514051};\\\", \\\"{x:680,y:729,t:1526919514068};\\\", \\\"{x:695,y:729,t:1526919514085};\\\", \\\"{x:709,y:729,t:1526919514101};\\\", \\\"{x:719,y:729,t:1526919514118};\\\", \\\"{x:721,y:729,t:1526919514135};\\\" ] }, { \\\"rt\\\": 55783, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 950186, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-10 AM-J -12 PM-11 AM-E -I -10 AM-11 AM-10 AM-11 AM-12 PM-11 AM-12 PM-01 PM-M -B -B -M -12 PM-M -M -F -F -G -02 PM-01 PM-02 PM-02 PM-01 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:731,y:729,t:1526919517874};\\\", \\\"{x:747,y:729,t:1526919517887};\\\", \\\"{x:806,y:729,t:1526919517905};\\\", \\\"{x:906,y:729,t:1526919517922};\\\", \\\"{x:969,y:733,t:1526919517938};\\\", \\\"{x:1014,y:741,t:1526919517956};\\\", \\\"{x:1044,y:747,t:1526919517972};\\\", \\\"{x:1066,y:749,t:1526919517989};\\\", \\\"{x:1084,y:752,t:1526919518005};\\\", \\\"{x:1103,y:754,t:1526919518022};\\\", \\\"{x:1119,y:758,t:1526919518039};\\\", \\\"{x:1130,y:762,t:1526919518055};\\\", \\\"{x:1142,y:765,t:1526919518072};\\\", \\\"{x:1159,y:773,t:1526919518090};\\\", \\\"{x:1177,y:778,t:1526919518105};\\\", \\\"{x:1196,y:785,t:1526919518122};\\\", \\\"{x:1208,y:791,t:1526919518138};\\\", \\\"{x:1219,y:800,t:1526919518155};\\\", \\\"{x:1227,y:806,t:1526919518172};\\\", \\\"{x:1237,y:813,t:1526919518189};\\\", \\\"{x:1242,y:818,t:1526919518205};\\\", \\\"{x:1247,y:822,t:1526919518223};\\\", \\\"{x:1249,y:824,t:1526919518239};\\\", \\\"{x:1252,y:828,t:1526919518255};\\\", \\\"{x:1252,y:829,t:1526919518272};\\\", \\\"{x:1253,y:833,t:1526919518289};\\\", \\\"{x:1254,y:835,t:1526919518305};\\\", \\\"{x:1254,y:839,t:1526919518322};\\\", \\\"{x:1254,y:842,t:1526919518339};\\\", \\\"{x:1254,y:843,t:1526919518355};\\\", \\\"{x:1254,y:845,t:1526919518372};\\\", \\\"{x:1254,y:846,t:1526919518389};\\\", \\\"{x:1254,y:848,t:1526919518405};\\\", \\\"{x:1254,y:850,t:1526919518422};\\\", \\\"{x:1254,y:854,t:1526919518439};\\\", \\\"{x:1254,y:856,t:1526919518456};\\\", \\\"{x:1254,y:858,t:1526919518472};\\\", \\\"{x:1253,y:860,t:1526919518489};\\\", \\\"{x:1252,y:865,t:1526919518506};\\\", \\\"{x:1251,y:868,t:1526919518523};\\\", \\\"{x:1250,y:871,t:1526919518539};\\\", \\\"{x:1250,y:874,t:1526919518556};\\\", \\\"{x:1250,y:877,t:1526919518572};\\\", \\\"{x:1250,y:881,t:1526919518589};\\\", \\\"{x:1250,y:884,t:1526919518606};\\\", \\\"{x:1250,y:888,t:1526919518622};\\\", \\\"{x:1250,y:889,t:1526919518640};\\\", \\\"{x:1250,y:892,t:1526919518656};\\\", \\\"{x:1250,y:895,t:1526919518672};\\\", \\\"{x:1250,y:896,t:1526919518689};\\\", \\\"{x:1250,y:899,t:1526919518706};\\\", \\\"{x:1250,y:901,t:1526919518722};\\\", \\\"{x:1250,y:906,t:1526919518739};\\\", \\\"{x:1250,y:912,t:1526919518756};\\\", \\\"{x:1250,y:917,t:1526919518772};\\\", \\\"{x:1251,y:923,t:1526919518789};\\\", \\\"{x:1251,y:926,t:1526919518806};\\\", \\\"{x:1252,y:931,t:1526919518822};\\\", \\\"{x:1253,y:935,t:1526919518839};\\\", \\\"{x:1255,y:942,t:1526919518856};\\\", \\\"{x:1256,y:947,t:1526919518873};\\\", \\\"{x:1257,y:953,t:1526919518889};\\\", \\\"{x:1259,y:962,t:1526919518906};\\\", \\\"{x:1260,y:966,t:1526919518922};\\\", \\\"{x:1260,y:970,t:1526919518939};\\\", \\\"{x:1260,y:974,t:1526919518956};\\\", \\\"{x:1260,y:977,t:1526919518973};\\\", \\\"{x:1261,y:980,t:1526919518989};\\\", \\\"{x:1262,y:980,t:1526919519006};\\\", \\\"{x:1262,y:981,t:1526919519023};\\\", \\\"{x:1262,y:982,t:1526919519039};\\\", \\\"{x:1263,y:983,t:1526919519202};\\\", \\\"{x:1263,y:984,t:1526919519618};\\\", \\\"{x:1263,y:985,t:1526919519659};\\\", \\\"{x:1261,y:985,t:1526919521758};\\\", \\\"{x:1256,y:985,t:1526919521766};\\\", \\\"{x:1253,y:985,t:1526919521778};\\\", \\\"{x:1247,y:985,t:1526919521795};\\\", \\\"{x:1244,y:985,t:1526919521812};\\\", \\\"{x:1243,y:985,t:1526919521829};\\\", \\\"{x:1242,y:985,t:1526919521846};\\\", \\\"{x:1241,y:985,t:1526919521862};\\\", \\\"{x:1235,y:985,t:1526919521879};\\\", \\\"{x:1231,y:986,t:1526919521895};\\\", \\\"{x:1227,y:986,t:1526919521912};\\\", \\\"{x:1226,y:987,t:1526919521929};\\\", \\\"{x:1223,y:987,t:1526919521945};\\\", \\\"{x:1220,y:989,t:1526919521962};\\\", \\\"{x:1218,y:989,t:1526919521979};\\\", \\\"{x:1216,y:990,t:1526919521995};\\\", \\\"{x:1214,y:990,t:1526919522012};\\\", \\\"{x:1213,y:990,t:1526919522029};\\\", \\\"{x:1212,y:991,t:1526919522046};\\\", \\\"{x:1211,y:991,t:1526919522062};\\\", \\\"{x:1209,y:992,t:1526919522079};\\\", \\\"{x:1208,y:992,t:1526919522110};\\\", \\\"{x:1207,y:992,t:1526919522118};\\\", \\\"{x:1206,y:992,t:1526919522239};\\\", \\\"{x:1206,y:991,t:1526919522262};\\\", \\\"{x:1206,y:990,t:1526919522279};\\\", \\\"{x:1205,y:988,t:1526919522296};\\\", \\\"{x:1205,y:987,t:1526919522312};\\\", \\\"{x:1205,y:986,t:1526919522367};\\\", \\\"{x:1205,y:985,t:1526919522479};\\\", \\\"{x:1205,y:984,t:1526919522496};\\\", \\\"{x:1205,y:983,t:1526919522526};\\\", \\\"{x:1205,y:982,t:1526919522534};\\\", \\\"{x:1205,y:981,t:1526919522546};\\\", \\\"{x:1205,y:980,t:1526919522581};\\\", \\\"{x:1205,y:979,t:1526919522596};\\\", \\\"{x:1205,y:978,t:1526919522614};\\\", \\\"{x:1205,y:977,t:1526919522630};\\\", \\\"{x:1205,y:975,t:1526919522646};\\\", \\\"{x:1205,y:974,t:1526919522678};\\\", \\\"{x:1205,y:973,t:1526919522702};\\\", \\\"{x:1206,y:972,t:1526919522712};\\\", \\\"{x:1206,y:970,t:1526919522729};\\\", \\\"{x:1207,y:970,t:1526919522750};\\\", \\\"{x:1207,y:969,t:1526919522814};\\\", \\\"{x:1207,y:968,t:1526919522831};\\\", \\\"{x:1207,y:967,t:1526919522878};\\\", \\\"{x:1207,y:965,t:1526919522896};\\\", \\\"{x:1208,y:964,t:1526919522913};\\\", \\\"{x:1208,y:963,t:1526919522929};\\\", \\\"{x:1208,y:958,t:1526919522946};\\\", \\\"{x:1207,y:954,t:1526919522963};\\\", \\\"{x:1207,y:952,t:1526919522979};\\\", \\\"{x:1206,y:941,t:1526919523008};\\\", \\\"{x:1206,y:940,t:1526919523014};\\\", \\\"{x:1204,y:928,t:1526919523064};\\\", \\\"{x:1204,y:924,t:1526919523079};\\\", \\\"{x:1204,y:920,t:1526919523095};\\\", \\\"{x:1204,y:916,t:1526919523113};\\\", \\\"{x:1204,y:912,t:1526919523129};\\\", \\\"{x:1204,y:908,t:1526919523145};\\\", \\\"{x:1204,y:904,t:1526919523163};\\\", \\\"{x:1204,y:899,t:1526919523180};\\\", \\\"{x:1204,y:894,t:1526919523195};\\\", \\\"{x:1204,y:889,t:1526919523213};\\\", \\\"{x:1204,y:881,t:1526919523229};\\\", \\\"{x:1204,y:877,t:1526919523245};\\\", \\\"{x:1204,y:872,t:1526919523263};\\\", \\\"{x:1204,y:869,t:1526919523279};\\\", \\\"{x:1204,y:867,t:1526919523296};\\\", \\\"{x:1204,y:864,t:1526919523313};\\\", \\\"{x:1204,y:860,t:1526919523330};\\\", \\\"{x:1204,y:857,t:1526919523345};\\\", \\\"{x:1204,y:854,t:1526919523362};\\\", \\\"{x:1204,y:853,t:1526919523381};\\\", \\\"{x:1204,y:852,t:1526919523397};\\\", \\\"{x:1204,y:851,t:1526919523413};\\\", \\\"{x:1204,y:850,t:1526919523437};\\\", \\\"{x:1204,y:849,t:1526919523453};\\\", \\\"{x:1204,y:848,t:1526919523469};\\\", \\\"{x:1204,y:847,t:1526919523485};\\\", \\\"{x:1204,y:846,t:1526919523495};\\\", \\\"{x:1204,y:845,t:1526919523513};\\\", \\\"{x:1204,y:844,t:1526919523529};\\\", \\\"{x:1204,y:843,t:1526919523545};\\\", \\\"{x:1204,y:841,t:1526919523562};\\\", \\\"{x:1205,y:840,t:1526919523580};\\\", \\\"{x:1205,y:839,t:1526919523596};\\\", \\\"{x:1205,y:838,t:1526919523612};\\\", \\\"{x:1207,y:835,t:1526919523629};\\\", \\\"{x:1208,y:835,t:1526919523654};\\\", \\\"{x:1210,y:831,t:1526919523705};\\\", \\\"{x:1210,y:830,t:1526919523729};\\\", \\\"{x:1211,y:830,t:1526919523747};\\\", \\\"{x:1211,y:829,t:1526919523763};\\\", \\\"{x:1213,y:828,t:1526919523779};\\\", \\\"{x:1213,y:827,t:1526919523797};\\\", \\\"{x:1214,y:827,t:1526919524447};\\\", \\\"{x:1216,y:829,t:1526919524463};\\\", \\\"{x:1221,y:831,t:1526919524480};\\\", \\\"{x:1230,y:835,t:1526919524497};\\\", \\\"{x:1244,y:843,t:1526919524513};\\\", \\\"{x:1261,y:850,t:1526919524529};\\\", \\\"{x:1280,y:858,t:1526919524546};\\\", \\\"{x:1298,y:867,t:1526919524563};\\\", \\\"{x:1313,y:876,t:1526919524580};\\\", \\\"{x:1326,y:886,t:1526919524597};\\\", \\\"{x:1337,y:903,t:1526919524613};\\\", \\\"{x:1342,y:911,t:1526919524630};\\\", \\\"{x:1344,y:915,t:1526919524647};\\\", \\\"{x:1345,y:921,t:1526919524664};\\\", \\\"{x:1346,y:926,t:1526919524681};\\\", \\\"{x:1346,y:933,t:1526919524696};\\\", \\\"{x:1349,y:939,t:1526919524714};\\\", \\\"{x:1349,y:946,t:1526919524731};\\\", \\\"{x:1347,y:953,t:1526919524746};\\\", \\\"{x:1345,y:958,t:1526919524764};\\\", \\\"{x:1339,y:966,t:1526919524781};\\\", \\\"{x:1335,y:972,t:1526919524797};\\\", \\\"{x:1328,y:977,t:1526919524814};\\\", \\\"{x:1325,y:979,t:1526919524830};\\\", \\\"{x:1322,y:980,t:1526919524846};\\\", \\\"{x:1318,y:982,t:1526919524864};\\\", \\\"{x:1316,y:982,t:1526919524881};\\\", \\\"{x:1311,y:982,t:1526919524897};\\\", \\\"{x:1307,y:982,t:1526919524914};\\\", \\\"{x:1301,y:982,t:1526919524931};\\\", \\\"{x:1296,y:981,t:1526919524947};\\\", \\\"{x:1293,y:978,t:1526919524964};\\\", \\\"{x:1289,y:977,t:1526919524981};\\\", \\\"{x:1287,y:975,t:1526919524997};\\\", \\\"{x:1286,y:972,t:1526919525014};\\\", \\\"{x:1285,y:970,t:1526919525031};\\\", \\\"{x:1285,y:969,t:1526919525047};\\\", \\\"{x:1285,y:968,t:1526919525078};\\\", \\\"{x:1285,y:967,t:1526919525102};\\\", \\\"{x:1285,y:966,t:1526919525142};\\\", \\\"{x:1287,y:964,t:1526919525367};\\\", \\\"{x:1287,y:963,t:1526919525382};\\\", \\\"{x:1287,y:961,t:1526919525398};\\\", \\\"{x:1287,y:958,t:1526919525414};\\\", \\\"{x:1286,y:954,t:1526919525431};\\\", \\\"{x:1285,y:951,t:1526919525449};\\\", \\\"{x:1284,y:946,t:1526919525464};\\\", \\\"{x:1284,y:944,t:1526919525481};\\\", \\\"{x:1284,y:941,t:1526919525498};\\\", \\\"{x:1282,y:937,t:1526919525514};\\\", \\\"{x:1282,y:935,t:1526919525531};\\\", \\\"{x:1282,y:931,t:1526919525548};\\\", \\\"{x:1282,y:928,t:1526919525565};\\\", \\\"{x:1282,y:923,t:1526919525582};\\\", \\\"{x:1282,y:916,t:1526919525598};\\\", \\\"{x:1280,y:908,t:1526919525615};\\\", \\\"{x:1279,y:902,t:1526919525631};\\\", \\\"{x:1277,y:896,t:1526919525649};\\\", \\\"{x:1275,y:892,t:1526919525666};\\\", \\\"{x:1274,y:884,t:1526919525681};\\\", \\\"{x:1272,y:875,t:1526919525698};\\\", \\\"{x:1271,y:865,t:1526919525715};\\\", \\\"{x:1270,y:857,t:1526919525731};\\\", \\\"{x:1268,y:846,t:1526919525748};\\\", \\\"{x:1265,y:836,t:1526919525765};\\\", \\\"{x:1262,y:829,t:1526919525780};\\\", \\\"{x:1262,y:824,t:1526919525798};\\\", \\\"{x:1262,y:821,t:1526919525815};\\\", \\\"{x:1262,y:820,t:1526919525831};\\\", \\\"{x:1262,y:817,t:1526919525847};\\\", \\\"{x:1262,y:815,t:1526919525865};\\\", \\\"{x:1262,y:811,t:1526919525880};\\\", \\\"{x:1262,y:810,t:1526919525898};\\\", \\\"{x:1262,y:808,t:1526919525915};\\\", \\\"{x:1262,y:806,t:1526919525931};\\\", \\\"{x:1262,y:805,t:1526919525947};\\\", \\\"{x:1262,y:802,t:1526919525964};\\\", \\\"{x:1262,y:800,t:1526919525981};\\\", \\\"{x:1262,y:798,t:1526919525998};\\\", \\\"{x:1262,y:795,t:1526919526015};\\\", \\\"{x:1262,y:794,t:1526919526031};\\\", \\\"{x:1262,y:792,t:1526919526048};\\\", \\\"{x:1262,y:789,t:1526919526065};\\\", \\\"{x:1262,y:788,t:1526919526082};\\\", \\\"{x:1262,y:784,t:1526919526098};\\\", \\\"{x:1261,y:780,t:1526919526115};\\\", \\\"{x:1261,y:775,t:1526919526132};\\\", \\\"{x:1261,y:770,t:1526919526148};\\\", \\\"{x:1261,y:767,t:1526919526165};\\\", \\\"{x:1261,y:762,t:1526919526182};\\\", \\\"{x:1261,y:760,t:1526919526198};\\\", \\\"{x:1261,y:758,t:1526919526215};\\\", \\\"{x:1261,y:757,t:1526919526232};\\\", \\\"{x:1261,y:756,t:1526919526249};\\\", \\\"{x:1261,y:755,t:1526919526265};\\\", \\\"{x:1261,y:753,t:1526919526282};\\\", \\\"{x:1261,y:752,t:1526919526302};\\\", \\\"{x:1262,y:752,t:1526919526315};\\\", \\\"{x:1262,y:751,t:1526919527454};\\\", \\\"{x:1261,y:751,t:1526919527478};\\\", \\\"{x:1259,y:749,t:1526919527485};\\\", \\\"{x:1259,y:746,t:1526919527499};\\\", \\\"{x:1259,y:735,t:1526919527516};\\\", \\\"{x:1259,y:726,t:1526919527534};\\\", \\\"{x:1259,y:720,t:1526919527549};\\\", \\\"{x:1257,y:706,t:1526919527566};\\\", \\\"{x:1255,y:698,t:1526919527583};\\\", \\\"{x:1254,y:689,t:1526919527599};\\\", \\\"{x:1253,y:679,t:1526919527616};\\\", \\\"{x:1253,y:671,t:1526919527633};\\\", \\\"{x:1253,y:664,t:1526919527649};\\\", \\\"{x:1253,y:658,t:1526919527666};\\\", \\\"{x:1253,y:654,t:1526919527684};\\\", \\\"{x:1253,y:649,t:1526919527700};\\\", \\\"{x:1254,y:643,t:1526919527717};\\\", \\\"{x:1254,y:638,t:1526919527734};\\\", \\\"{x:1255,y:630,t:1526919527750};\\\", \\\"{x:1258,y:618,t:1526919527766};\\\", \\\"{x:1258,y:613,t:1526919527784};\\\", \\\"{x:1259,y:606,t:1526919527800};\\\", \\\"{x:1259,y:601,t:1526919527817};\\\", \\\"{x:1260,y:594,t:1526919527834};\\\", \\\"{x:1262,y:590,t:1526919527849};\\\", \\\"{x:1263,y:585,t:1526919527866};\\\", \\\"{x:1266,y:580,t:1526919527883};\\\", \\\"{x:1268,y:576,t:1526919527899};\\\", \\\"{x:1271,y:573,t:1526919527916};\\\", \\\"{x:1271,y:572,t:1526919527933};\\\", \\\"{x:1272,y:571,t:1526919527949};\\\", \\\"{x:1273,y:570,t:1526919527967};\\\", \\\"{x:1274,y:569,t:1526919527983};\\\", \\\"{x:1275,y:568,t:1526919528086};\\\", \\\"{x:1276,y:568,t:1526919528222};\\\", \\\"{x:1277,y:567,t:1526919528246};\\\", \\\"{x:1278,y:567,t:1526919528302};\\\", \\\"{x:1279,y:567,t:1526919528334};\\\", \\\"{x:1279,y:566,t:1526919528695};\\\", \\\"{x:1280,y:565,t:1526919528718};\\\", \\\"{x:1279,y:565,t:1526919529846};\\\", \\\"{x:1279,y:566,t:1526919529854};\\\", \\\"{x:1279,y:568,t:1526919529867};\\\", \\\"{x:1278,y:574,t:1526919529886};\\\", \\\"{x:1278,y:585,t:1526919529902};\\\", \\\"{x:1278,y:594,t:1526919529917};\\\", \\\"{x:1278,y:606,t:1526919529934};\\\", \\\"{x:1278,y:617,t:1526919529952};\\\", \\\"{x:1278,y:630,t:1526919529969};\\\", \\\"{x:1278,y:641,t:1526919529984};\\\", \\\"{x:1279,y:651,t:1526919530001};\\\", \\\"{x:1280,y:658,t:1526919530018};\\\", \\\"{x:1281,y:667,t:1526919530034};\\\", \\\"{x:1282,y:671,t:1526919530052};\\\", \\\"{x:1282,y:675,t:1526919530069};\\\", \\\"{x:1284,y:677,t:1526919530084};\\\", \\\"{x:1284,y:680,t:1526919530101};\\\", \\\"{x:1284,y:684,t:1526919530117};\\\", \\\"{x:1284,y:686,t:1526919530134};\\\", \\\"{x:1283,y:688,t:1526919530152};\\\", \\\"{x:1282,y:692,t:1526919530169};\\\", \\\"{x:1282,y:694,t:1526919530184};\\\", \\\"{x:1281,y:698,t:1526919530202};\\\", \\\"{x:1279,y:702,t:1526919530218};\\\", \\\"{x:1279,y:706,t:1526919530234};\\\", \\\"{x:1279,y:707,t:1526919530251};\\\", \\\"{x:1277,y:709,t:1526919530268};\\\", \\\"{x:1277,y:710,t:1526919530285};\\\", \\\"{x:1276,y:713,t:1526919530301};\\\", \\\"{x:1275,y:718,t:1526919530318};\\\", \\\"{x:1272,y:723,t:1526919530335};\\\", \\\"{x:1269,y:731,t:1526919530351};\\\", \\\"{x:1265,y:737,t:1526919530369};\\\", \\\"{x:1262,y:744,t:1526919530385};\\\", \\\"{x:1258,y:749,t:1526919530402};\\\", \\\"{x:1254,y:757,t:1526919530418};\\\", \\\"{x:1250,y:762,t:1526919530436};\\\", \\\"{x:1246,y:766,t:1526919530452};\\\", \\\"{x:1242,y:770,t:1526919530470};\\\", \\\"{x:1234,y:774,t:1526919530486};\\\", \\\"{x:1227,y:775,t:1526919530501};\\\", \\\"{x:1219,y:777,t:1526919530518};\\\", \\\"{x:1211,y:777,t:1526919530536};\\\", \\\"{x:1203,y:778,t:1526919530551};\\\", \\\"{x:1195,y:779,t:1526919530568};\\\", \\\"{x:1187,y:781,t:1526919530585};\\\", \\\"{x:1177,y:781,t:1526919530601};\\\", \\\"{x:1171,y:781,t:1526919530619};\\\", \\\"{x:1165,y:781,t:1526919530636};\\\", \\\"{x:1163,y:781,t:1526919530652};\\\", \\\"{x:1162,y:781,t:1526919530668};\\\", \\\"{x:1161,y:781,t:1526919530710};\\\", \\\"{x:1161,y:779,t:1526919530726};\\\", \\\"{x:1161,y:778,t:1526919530735};\\\", \\\"{x:1161,y:776,t:1526919530751};\\\", \\\"{x:1161,y:775,t:1526919530769};\\\", \\\"{x:1161,y:773,t:1526919530786};\\\", \\\"{x:1162,y:771,t:1526919530801};\\\", \\\"{x:1163,y:770,t:1526919530818};\\\", \\\"{x:1165,y:768,t:1526919530836};\\\", \\\"{x:1170,y:767,t:1526919530852};\\\", \\\"{x:1173,y:765,t:1526919530869};\\\", \\\"{x:1180,y:764,t:1526919530886};\\\", \\\"{x:1181,y:764,t:1526919530902};\\\", \\\"{x:1182,y:764,t:1526919530919};\\\", \\\"{x:1183,y:764,t:1526919530950};\\\", \\\"{x:1184,y:764,t:1526919530989};\\\", \\\"{x:1185,y:764,t:1526919531014};\\\", \\\"{x:1187,y:764,t:1526919531039};\\\", \\\"{x:1187,y:765,t:1526919531110};\\\", \\\"{x:1187,y:766,t:1526919531126};\\\", \\\"{x:1187,y:768,t:1526919531136};\\\", \\\"{x:1188,y:771,t:1526919531152};\\\", \\\"{x:1188,y:773,t:1526919531169};\\\", \\\"{x:1188,y:776,t:1526919531186};\\\", \\\"{x:1188,y:779,t:1526919531203};\\\", \\\"{x:1190,y:785,t:1526919531219};\\\", \\\"{x:1190,y:792,t:1526919531236};\\\", \\\"{x:1191,y:800,t:1526919531252};\\\", \\\"{x:1192,y:812,t:1526919531269};\\\", \\\"{x:1194,y:824,t:1526919531285};\\\", \\\"{x:1195,y:832,t:1526919531302};\\\", \\\"{x:1197,y:842,t:1526919531319};\\\", \\\"{x:1199,y:859,t:1526919531336};\\\", \\\"{x:1201,y:878,t:1526919531353};\\\", \\\"{x:1201,y:884,t:1526919531369};\\\", \\\"{x:1201,y:896,t:1526919531386};\\\", \\\"{x:1203,y:902,t:1526919531403};\\\", \\\"{x:1203,y:908,t:1526919531420};\\\", \\\"{x:1203,y:912,t:1526919531434};\\\", \\\"{x:1203,y:915,t:1526919531452};\\\", \\\"{x:1203,y:916,t:1526919531469};\\\", \\\"{x:1203,y:918,t:1526919531485};\\\", \\\"{x:1203,y:919,t:1526919531502};\\\", \\\"{x:1203,y:921,t:1526919531519};\\\", \\\"{x:1203,y:924,t:1526919531535};\\\", \\\"{x:1203,y:925,t:1526919531552};\\\", \\\"{x:1203,y:929,t:1526919531568};\\\", \\\"{x:1204,y:934,t:1526919531585};\\\", \\\"{x:1204,y:941,t:1526919531602};\\\", \\\"{x:1205,y:949,t:1526919531619};\\\", \\\"{x:1205,y:954,t:1526919531635};\\\", \\\"{x:1206,y:959,t:1526919531653};\\\", \\\"{x:1207,y:961,t:1526919531670};\\\", \\\"{x:1208,y:962,t:1526919532029};\\\", \\\"{x:1211,y:961,t:1526919532037};\\\", \\\"{x:1221,y:956,t:1526919532052};\\\", \\\"{x:1256,y:939,t:1526919532069};\\\", \\\"{x:1287,y:925,t:1526919532086};\\\", \\\"{x:1305,y:916,t:1526919532103};\\\", \\\"{x:1310,y:915,t:1526919532120};\\\", \\\"{x:1313,y:914,t:1526919532136};\\\", \\\"{x:1313,y:916,t:1526919532198};\\\", \\\"{x:1313,y:920,t:1526919532214};\\\", \\\"{x:1313,y:922,t:1526919532221};\\\", \\\"{x:1312,y:924,t:1526919532237};\\\", \\\"{x:1309,y:930,t:1526919532253};\\\", \\\"{x:1306,y:936,t:1526919532270};\\\", \\\"{x:1303,y:942,t:1526919532287};\\\", \\\"{x:1300,y:944,t:1526919532303};\\\", \\\"{x:1294,y:948,t:1526919532320};\\\", \\\"{x:1286,y:950,t:1526919532336};\\\", \\\"{x:1280,y:954,t:1526919532353};\\\", \\\"{x:1271,y:959,t:1526919532370};\\\", \\\"{x:1266,y:961,t:1526919532386};\\\", \\\"{x:1263,y:962,t:1526919532403};\\\", \\\"{x:1262,y:962,t:1526919532430};\\\", \\\"{x:1261,y:962,t:1526919532486};\\\", \\\"{x:1259,y:960,t:1526919532504};\\\", \\\"{x:1259,y:958,t:1526919532520};\\\", \\\"{x:1257,y:956,t:1526919532537};\\\", \\\"{x:1257,y:955,t:1526919532554};\\\", \\\"{x:1257,y:954,t:1526919532570};\\\", \\\"{x:1257,y:953,t:1526919532678};\\\", \\\"{x:1253,y:954,t:1526919532686};\\\", \\\"{x:1241,y:958,t:1526919532704};\\\", \\\"{x:1236,y:959,t:1526919532721};\\\", \\\"{x:1231,y:960,t:1526919532737};\\\", \\\"{x:1229,y:961,t:1526919532754};\\\", \\\"{x:1228,y:961,t:1526919532771};\\\", \\\"{x:1226,y:961,t:1526919532787};\\\", \\\"{x:1222,y:961,t:1526919532804};\\\", \\\"{x:1218,y:961,t:1526919532822};\\\", \\\"{x:1217,y:961,t:1526919532837};\\\", \\\"{x:1215,y:959,t:1526919532854};\\\", \\\"{x:1214,y:953,t:1526919532870};\\\", \\\"{x:1212,y:946,t:1526919532886};\\\", \\\"{x:1210,y:938,t:1526919532903};\\\", \\\"{x:1206,y:928,t:1526919532920};\\\", \\\"{x:1202,y:914,t:1526919532937};\\\", \\\"{x:1196,y:901,t:1526919532954};\\\", \\\"{x:1188,y:885,t:1526919532971};\\\", \\\"{x:1180,y:864,t:1526919532987};\\\", \\\"{x:1167,y:838,t:1526919533003};\\\", \\\"{x:1151,y:805,t:1526919533021};\\\", \\\"{x:1142,y:780,t:1526919533037};\\\", \\\"{x:1135,y:757,t:1526919533054};\\\", \\\"{x:1134,y:747,t:1526919533070};\\\", \\\"{x:1134,y:739,t:1526919533087};\\\", \\\"{x:1134,y:732,t:1526919533104};\\\", \\\"{x:1134,y:729,t:1526919533120};\\\", \\\"{x:1134,y:728,t:1526919533137};\\\", \\\"{x:1134,y:729,t:1526919533702};\\\", \\\"{x:1135,y:733,t:1526919533709};\\\", \\\"{x:1139,y:740,t:1526919533720};\\\", \\\"{x:1149,y:755,t:1526919533738};\\\", \\\"{x:1159,y:768,t:1526919533755};\\\", \\\"{x:1170,y:780,t:1526919533771};\\\", \\\"{x:1178,y:791,t:1526919533788};\\\", \\\"{x:1189,y:808,t:1526919533805};\\\", \\\"{x:1195,y:824,t:1526919533821};\\\", \\\"{x:1199,y:842,t:1526919533837};\\\", \\\"{x:1201,y:849,t:1526919533854};\\\", \\\"{x:1201,y:853,t:1526919533870};\\\", \\\"{x:1201,y:864,t:1526919533887};\\\", \\\"{x:1199,y:873,t:1526919533904};\\\", \\\"{x:1199,y:884,t:1526919533920};\\\", \\\"{x:1197,y:897,t:1526919533937};\\\", \\\"{x:1197,y:908,t:1526919533954};\\\", \\\"{x:1196,y:926,t:1526919533970};\\\", \\\"{x:1196,y:942,t:1526919533987};\\\", \\\"{x:1193,y:962,t:1526919534004};\\\", \\\"{x:1191,y:972,t:1526919534020};\\\", \\\"{x:1190,y:975,t:1526919534037};\\\", \\\"{x:1189,y:975,t:1526919534525};\\\", \\\"{x:1189,y:973,t:1526919534573};\\\", \\\"{x:1189,y:972,t:1526919534662};\\\", \\\"{x:1187,y:971,t:1526919534671};\\\", \\\"{x:1187,y:970,t:1526919534688};\\\", \\\"{x:1187,y:969,t:1526919534710};\\\", \\\"{x:1186,y:969,t:1526919534725};\\\", \\\"{x:1186,y:968,t:1526919534741};\\\", \\\"{x:1187,y:968,t:1526919534918};\\\", \\\"{x:1188,y:969,t:1526919534959};\\\", \\\"{x:1188,y:970,t:1526919534974};\\\", \\\"{x:1189,y:970,t:1526919535182};\\\", \\\"{x:1190,y:970,t:1526919535189};\\\", \\\"{x:1194,y:969,t:1526919535206};\\\", \\\"{x:1197,y:968,t:1526919535221};\\\", \\\"{x:1198,y:968,t:1526919535238};\\\", \\\"{x:1200,y:968,t:1526919535262};\\\", \\\"{x:1200,y:969,t:1526919535278};\\\", \\\"{x:1201,y:969,t:1526919535288};\\\", \\\"{x:1202,y:969,t:1526919535306};\\\", \\\"{x:1203,y:969,t:1526919535322};\\\", \\\"{x:1204,y:970,t:1526919535374};\\\", \\\"{x:1205,y:970,t:1526919535397};\\\", \\\"{x:1206,y:970,t:1526919535414};\\\", \\\"{x:1206,y:971,t:1526919535430};\\\", \\\"{x:1207,y:971,t:1526919535478};\\\", \\\"{x:1208,y:971,t:1526919535488};\\\", \\\"{x:1210,y:972,t:1526919535526};\\\", \\\"{x:1211,y:972,t:1526919535630};\\\", \\\"{x:1212,y:972,t:1526919535653};\\\", \\\"{x:1213,y:972,t:1526919535669};\\\", \\\"{x:1215,y:972,t:1526919535686};\\\", \\\"{x:1216,y:972,t:1526919535702};\\\", \\\"{x:1219,y:972,t:1526919535710};\\\", \\\"{x:1220,y:972,t:1526919535722};\\\", \\\"{x:1224,y:972,t:1526919535739};\\\", \\\"{x:1226,y:971,t:1526919535755};\\\", \\\"{x:1229,y:970,t:1526919535772};\\\", \\\"{x:1230,y:970,t:1526919535813};\\\", \\\"{x:1231,y:970,t:1526919535830};\\\", \\\"{x:1232,y:970,t:1526919535845};\\\", \\\"{x:1234,y:970,t:1526919535862};\\\", \\\"{x:1235,y:970,t:1526919535877};\\\", \\\"{x:1236,y:970,t:1526919535910};\\\", \\\"{x:1237,y:970,t:1526919535926};\\\", \\\"{x:1238,y:970,t:1526919535950};\\\", \\\"{x:1239,y:970,t:1526919536014};\\\", \\\"{x:1240,y:970,t:1526919536054};\\\", \\\"{x:1241,y:970,t:1526919536094};\\\", \\\"{x:1241,y:971,t:1526919536106};\\\", \\\"{x:1242,y:971,t:1526919536294};\\\", \\\"{x:1244,y:971,t:1526919536305};\\\", \\\"{x:1247,y:971,t:1526919536323};\\\", \\\"{x:1254,y:971,t:1526919536340};\\\", \\\"{x:1267,y:969,t:1526919536355};\\\", \\\"{x:1278,y:969,t:1526919536373};\\\", \\\"{x:1287,y:969,t:1526919536389};\\\", \\\"{x:1292,y:969,t:1526919536406};\\\", \\\"{x:1297,y:969,t:1526919536423};\\\", \\\"{x:1298,y:969,t:1526919536461};\\\", \\\"{x:1298,y:968,t:1526919536575};\\\", \\\"{x:1298,y:967,t:1526919536590};\\\", \\\"{x:1300,y:965,t:1526919536606};\\\", \\\"{x:1301,y:965,t:1526919536622};\\\", \\\"{x:1304,y:963,t:1526919536639};\\\", \\\"{x:1305,y:963,t:1526919536656};\\\", \\\"{x:1306,y:963,t:1526919536693};\\\", \\\"{x:1308,y:963,t:1526919536709};\\\", \\\"{x:1309,y:961,t:1526919536725};\\\", \\\"{x:1310,y:961,t:1526919536741};\\\", \\\"{x:1311,y:961,t:1526919536806};\\\", \\\"{x:1312,y:961,t:1526919536822};\\\", \\\"{x:1313,y:961,t:1526919536839};\\\", \\\"{x:1314,y:961,t:1526919536857};\\\", \\\"{x:1315,y:961,t:1526919536894};\\\", \\\"{x:1316,y:961,t:1526919536907};\\\", \\\"{x:1320,y:961,t:1526919536923};\\\", \\\"{x:1324,y:961,t:1526919536940};\\\", \\\"{x:1328,y:961,t:1526919536957};\\\", \\\"{x:1336,y:961,t:1526919536973};\\\", \\\"{x:1353,y:962,t:1526919536989};\\\", \\\"{x:1365,y:963,t:1526919537007};\\\", \\\"{x:1372,y:963,t:1526919537023};\\\", \\\"{x:1376,y:963,t:1526919537040};\\\", \\\"{x:1380,y:963,t:1526919537057};\\\", \\\"{x:1383,y:963,t:1526919537074};\\\", \\\"{x:1386,y:963,t:1526919537090};\\\", \\\"{x:1387,y:963,t:1526919537110};\\\", \\\"{x:1386,y:963,t:1526919537366};\\\", \\\"{x:1383,y:966,t:1526919537374};\\\", \\\"{x:1375,y:966,t:1526919537390};\\\", \\\"{x:1366,y:966,t:1526919537407};\\\", \\\"{x:1351,y:966,t:1526919537424};\\\", \\\"{x:1337,y:965,t:1526919537440};\\\", \\\"{x:1325,y:963,t:1526919537457};\\\", \\\"{x:1313,y:961,t:1526919537473};\\\", \\\"{x:1301,y:960,t:1526919537491};\\\", \\\"{x:1294,y:960,t:1526919537507};\\\", \\\"{x:1289,y:960,t:1526919537524};\\\", \\\"{x:1285,y:960,t:1526919537541};\\\", \\\"{x:1283,y:960,t:1526919537557};\\\", \\\"{x:1275,y:962,t:1526919537574};\\\", \\\"{x:1265,y:965,t:1526919537590};\\\", \\\"{x:1256,y:965,t:1526919537607};\\\", \\\"{x:1249,y:966,t:1526919537624};\\\", \\\"{x:1244,y:966,t:1526919537641};\\\", \\\"{x:1239,y:966,t:1526919537657};\\\", \\\"{x:1236,y:966,t:1526919537674};\\\", \\\"{x:1232,y:966,t:1526919537691};\\\", \\\"{x:1230,y:967,t:1526919537707};\\\", \\\"{x:1227,y:968,t:1526919537723};\\\", \\\"{x:1224,y:968,t:1526919537741};\\\", \\\"{x:1220,y:969,t:1526919537757};\\\", \\\"{x:1214,y:969,t:1526919537774};\\\", \\\"{x:1213,y:969,t:1526919537790};\\\", \\\"{x:1211,y:970,t:1526919537806};\\\", \\\"{x:1210,y:971,t:1526919537823};\\\", \\\"{x:1209,y:971,t:1526919537846};\\\", \\\"{x:1208,y:971,t:1526919537862};\\\", \\\"{x:1207,y:971,t:1526919537873};\\\", \\\"{x:1207,y:972,t:1526919537957};\\\", \\\"{x:1208,y:970,t:1526919538166};\\\", \\\"{x:1212,y:970,t:1526919538174};\\\", \\\"{x:1221,y:969,t:1526919538191};\\\", \\\"{x:1235,y:967,t:1526919538209};\\\", \\\"{x:1245,y:967,t:1526919538223};\\\", \\\"{x:1254,y:967,t:1526919538240};\\\", \\\"{x:1260,y:967,t:1526919538257};\\\", \\\"{x:1263,y:967,t:1526919538273};\\\", \\\"{x:1267,y:967,t:1526919538290};\\\", \\\"{x:1270,y:967,t:1526919538307};\\\", \\\"{x:1271,y:967,t:1526919538323};\\\", \\\"{x:1274,y:968,t:1526919538340};\\\", \\\"{x:1278,y:970,t:1526919538357};\\\", \\\"{x:1279,y:970,t:1526919538374};\\\", \\\"{x:1281,y:970,t:1526919538391};\\\", \\\"{x:1283,y:971,t:1526919538407};\\\", \\\"{x:1286,y:971,t:1526919538423};\\\", \\\"{x:1291,y:971,t:1526919538440};\\\", \\\"{x:1297,y:971,t:1526919538457};\\\", \\\"{x:1303,y:971,t:1526919538475};\\\", \\\"{x:1310,y:970,t:1526919538491};\\\", \\\"{x:1318,y:969,t:1526919538508};\\\", \\\"{x:1329,y:966,t:1526919538524};\\\", \\\"{x:1333,y:965,t:1526919538541};\\\", \\\"{x:1339,y:963,t:1526919538558};\\\", \\\"{x:1341,y:963,t:1526919538575};\\\", \\\"{x:1342,y:963,t:1526919538590};\\\", \\\"{x:1342,y:965,t:1526919539582};\\\", \\\"{x:1339,y:968,t:1526919539592};\\\", \\\"{x:1331,y:973,t:1526919539609};\\\", \\\"{x:1321,y:975,t:1526919539625};\\\", \\\"{x:1308,y:979,t:1526919539642};\\\", \\\"{x:1302,y:979,t:1526919539658};\\\", \\\"{x:1301,y:979,t:1526919539675};\\\", \\\"{x:1300,y:979,t:1526919539691};\\\", \\\"{x:1298,y:981,t:1526919539709};\\\", \\\"{x:1296,y:982,t:1526919539725};\\\", \\\"{x:1295,y:982,t:1526919539742};\\\", \\\"{x:1294,y:982,t:1526919539758};\\\", \\\"{x:1293,y:982,t:1526919539894};\\\", \\\"{x:1291,y:982,t:1526919539910};\\\", \\\"{x:1289,y:981,t:1526919539925};\\\", \\\"{x:1286,y:978,t:1526919539941};\\\", \\\"{x:1280,y:976,t:1526919539958};\\\", \\\"{x:1275,y:973,t:1526919539975};\\\", \\\"{x:1271,y:971,t:1526919539991};\\\", \\\"{x:1270,y:971,t:1526919540009};\\\", \\\"{x:1271,y:970,t:1526919540982};\\\", \\\"{x:1272,y:969,t:1526919540993};\\\", \\\"{x:1272,y:968,t:1526919541011};\\\", \\\"{x:1273,y:968,t:1526919541026};\\\", \\\"{x:1273,y:967,t:1526919541043};\\\", \\\"{x:1274,y:966,t:1526919542422};\\\", \\\"{x:1275,y:966,t:1526919542589};\\\", \\\"{x:1276,y:966,t:1526919542604};\\\", \\\"{x:1277,y:966,t:1526919542629};\\\", \\\"{x:1278,y:966,t:1526919542678};\\\", \\\"{x:1279,y:967,t:1526919542742};\\\", \\\"{x:1280,y:967,t:1526919542766};\\\", \\\"{x:1281,y:967,t:1526919542829};\\\", \\\"{x:1282,y:967,t:1526919542854};\\\", \\\"{x:1283,y:968,t:1526919542878};\\\", \\\"{x:1284,y:968,t:1526919544038};\\\", \\\"{x:1288,y:968,t:1526919544046};\\\", \\\"{x:1296,y:968,t:1526919544062};\\\", \\\"{x:1307,y:968,t:1526919544077};\\\", \\\"{x:1316,y:969,t:1526919544095};\\\", \\\"{x:1323,y:971,t:1526919544112};\\\", \\\"{x:1329,y:971,t:1526919544128};\\\", \\\"{x:1332,y:972,t:1526919544145};\\\", \\\"{x:1333,y:972,t:1526919544165};\\\", \\\"{x:1335,y:972,t:1526919544198};\\\", \\\"{x:1336,y:972,t:1526919544229};\\\", \\\"{x:1337,y:972,t:1526919544293};\\\", \\\"{x:1338,y:972,t:1526919544381};\\\", \\\"{x:1339,y:972,t:1526919544394};\\\", \\\"{x:1343,y:972,t:1526919544412};\\\", \\\"{x:1347,y:971,t:1526919544428};\\\", \\\"{x:1350,y:971,t:1526919544444};\\\", \\\"{x:1355,y:971,t:1526919544461};\\\", \\\"{x:1356,y:971,t:1526919544478};\\\", \\\"{x:1356,y:970,t:1526919545774};\\\", \\\"{x:1364,y:970,t:1526919546158};\\\", \\\"{x:1375,y:970,t:1526919546166};\\\", \\\"{x:1383,y:970,t:1526919546180};\\\", \\\"{x:1409,y:970,t:1526919546197};\\\", \\\"{x:1414,y:970,t:1526919546212};\\\", \\\"{x:1422,y:970,t:1526919546230};\\\", \\\"{x:1423,y:970,t:1526919546246};\\\", \\\"{x:1422,y:970,t:1526919546525};\\\", \\\"{x:1426,y:968,t:1526919546711};\\\", \\\"{x:1430,y:968,t:1526919546717};\\\", \\\"{x:1437,y:967,t:1526919546730};\\\", \\\"{x:1451,y:966,t:1526919546747};\\\", \\\"{x:1458,y:966,t:1526919546765};\\\", \\\"{x:1460,y:966,t:1526919546780};\\\", \\\"{x:1461,y:966,t:1526919546910};\\\", \\\"{x:1463,y:966,t:1526919546918};\\\", \\\"{x:1465,y:965,t:1526919546933};\\\", \\\"{x:1466,y:965,t:1526919547054};\\\", \\\"{x:1468,y:965,t:1526919547102};\\\", \\\"{x:1469,y:965,t:1526919547114};\\\", \\\"{x:1472,y:965,t:1526919547131};\\\", \\\"{x:1477,y:963,t:1526919547148};\\\", \\\"{x:1481,y:962,t:1526919547165};\\\", \\\"{x:1486,y:961,t:1526919547182};\\\", \\\"{x:1484,y:961,t:1526919548022};\\\", \\\"{x:1479,y:961,t:1526919548031};\\\", \\\"{x:1461,y:963,t:1526919548049};\\\", \\\"{x:1439,y:965,t:1526919548065};\\\", \\\"{x:1400,y:965,t:1526919548081};\\\", \\\"{x:1333,y:955,t:1526919548099};\\\", \\\"{x:1247,y:940,t:1526919548115};\\\", \\\"{x:1135,y:920,t:1526919548131};\\\", \\\"{x:1008,y:884,t:1526919548148};\\\", \\\"{x:835,y:830,t:1526919548165};\\\", \\\"{x:769,y:803,t:1526919548181};\\\", \\\"{x:747,y:783,t:1526919548197};\\\", \\\"{x:741,y:766,t:1526919548215};\\\", \\\"{x:741,y:747,t:1526919548231};\\\", \\\"{x:741,y:720,t:1526919548248};\\\", \\\"{x:748,y:688,t:1526919548266};\\\", \\\"{x:749,y:672,t:1526919548281};\\\", \\\"{x:749,y:665,t:1526919548298};\\\", \\\"{x:739,y:657,t:1526919548315};\\\", \\\"{x:720,y:651,t:1526919548330};\\\", \\\"{x:687,y:641,t:1526919548349};\\\", \\\"{x:580,y:612,t:1526919548365};\\\", \\\"{x:485,y:584,t:1526919548381};\\\", \\\"{x:401,y:554,t:1526919548400};\\\", \\\"{x:353,y:532,t:1526919548416};\\\", \\\"{x:325,y:518,t:1526919548434};\\\", \\\"{x:307,y:505,t:1526919548450};\\\", \\\"{x:292,y:493,t:1526919548466};\\\", \\\"{x:284,y:484,t:1526919548483};\\\", \\\"{x:283,y:481,t:1526919548500};\\\", \\\"{x:282,y:478,t:1526919548516};\\\", \\\"{x:282,y:477,t:1526919548534};\\\", \\\"{x:282,y:476,t:1526919548549};\\\", \\\"{x:282,y:475,t:1526919548567};\\\", \\\"{x:282,y:474,t:1526919548589};\\\", \\\"{x:282,y:473,t:1526919548621};\\\", \\\"{x:284,y:473,t:1526919548633};\\\", \\\"{x:288,y:473,t:1526919548649};\\\", \\\"{x:292,y:473,t:1526919548667};\\\", \\\"{x:294,y:474,t:1526919548684};\\\", \\\"{x:295,y:475,t:1526919548701};\\\", \\\"{x:298,y:475,t:1526919549142};\\\", \\\"{x:307,y:476,t:1526919549151};\\\", \\\"{x:339,y:476,t:1526919549168};\\\", \\\"{x:372,y:476,t:1526919549183};\\\", \\\"{x:404,y:476,t:1526919549201};\\\", \\\"{x:442,y:476,t:1526919549218};\\\", \\\"{x:471,y:476,t:1526919549234};\\\", \\\"{x:496,y:476,t:1526919549251};\\\", \\\"{x:505,y:476,t:1526919549267};\\\", \\\"{x:511,y:476,t:1526919549284};\\\", \\\"{x:519,y:478,t:1526919549301};\\\", \\\"{x:520,y:479,t:1526919549318};\\\", \\\"{x:522,y:481,t:1526919549334};\\\", \\\"{x:523,y:485,t:1526919549351};\\\", \\\"{x:525,y:491,t:1526919549368};\\\", \\\"{x:525,y:501,t:1526919549385};\\\", \\\"{x:525,y:511,t:1526919549400};\\\", \\\"{x:523,y:518,t:1526919549417};\\\", \\\"{x:521,y:521,t:1526919549435};\\\", \\\"{x:517,y:525,t:1526919549450};\\\", \\\"{x:509,y:528,t:1526919549467};\\\", \\\"{x:486,y:534,t:1526919549484};\\\", \\\"{x:462,y:538,t:1526919549501};\\\", \\\"{x:436,y:538,t:1526919549517};\\\", \\\"{x:390,y:543,t:1526919549535};\\\", \\\"{x:348,y:543,t:1526919549550};\\\", \\\"{x:316,y:544,t:1526919549567};\\\", \\\"{x:295,y:544,t:1526919549584};\\\", \\\"{x:279,y:544,t:1526919549601};\\\", \\\"{x:260,y:544,t:1526919549619};\\\", \\\"{x:245,y:544,t:1526919549633};\\\", \\\"{x:229,y:545,t:1526919549650};\\\", \\\"{x:218,y:547,t:1526919549668};\\\", \\\"{x:213,y:548,t:1526919549683};\\\", \\\"{x:207,y:551,t:1526919549701};\\\", \\\"{x:206,y:553,t:1526919549717};\\\", \\\"{x:204,y:556,t:1526919549734};\\\", \\\"{x:204,y:557,t:1526919549797};\\\", \\\"{x:202,y:559,t:1526919549805};\\\", \\\"{x:202,y:560,t:1526919549817};\\\", \\\"{x:201,y:560,t:1526919549834};\\\", \\\"{x:200,y:561,t:1526919549850};\\\", \\\"{x:203,y:560,t:1526919549893};\\\", \\\"{x:211,y:557,t:1526919549901};\\\", \\\"{x:248,y:550,t:1526919549918};\\\", \\\"{x:333,y:543,t:1526919549935};\\\", \\\"{x:463,y:543,t:1526919549950};\\\", \\\"{x:574,y:543,t:1526919549968};\\\", \\\"{x:668,y:543,t:1526919549985};\\\", \\\"{x:752,y:543,t:1526919550002};\\\", \\\"{x:790,y:544,t:1526919550018};\\\", \\\"{x:814,y:549,t:1526919550034};\\\", \\\"{x:829,y:551,t:1526919550051};\\\", \\\"{x:845,y:555,t:1526919550067};\\\", \\\"{x:870,y:560,t:1526919550085};\\\", \\\"{x:891,y:562,t:1526919550102};\\\", \\\"{x:914,y:566,t:1526919550117};\\\", \\\"{x:924,y:566,t:1526919550134};\\\", \\\"{x:932,y:566,t:1526919550151};\\\", \\\"{x:930,y:566,t:1526919550214};\\\", \\\"{x:923,y:566,t:1526919550222};\\\", \\\"{x:912,y:566,t:1526919550234};\\\", \\\"{x:870,y:566,t:1526919550251};\\\", \\\"{x:794,y:562,t:1526919550267};\\\", \\\"{x:709,y:544,t:1526919550284};\\\", \\\"{x:682,y:538,t:1526919550302};\\\", \\\"{x:671,y:532,t:1526919550318};\\\", \\\"{x:666,y:528,t:1526919550335};\\\", \\\"{x:663,y:527,t:1526919550352};\\\", \\\"{x:662,y:526,t:1526919550367};\\\", \\\"{x:661,y:525,t:1526919550384};\\\", \\\"{x:660,y:524,t:1526919550402};\\\", \\\"{x:655,y:522,t:1526919550418};\\\", \\\"{x:645,y:518,t:1526919550435};\\\", \\\"{x:632,y:517,t:1526919550453};\\\", \\\"{x:626,y:514,t:1526919550467};\\\", \\\"{x:623,y:514,t:1526919550484};\\\", \\\"{x:621,y:514,t:1526919550501};\\\", \\\"{x:620,y:514,t:1526919550518};\\\", \\\"{x:618,y:514,t:1526919550535};\\\", \\\"{x:614,y:514,t:1526919550552};\\\", \\\"{x:611,y:513,t:1526919550569};\\\", \\\"{x:609,y:512,t:1526919550584};\\\", \\\"{x:610,y:511,t:1526919551085};\\\", \\\"{x:632,y:511,t:1526919551102};\\\", \\\"{x:662,y:511,t:1526919551119};\\\", \\\"{x:712,y:513,t:1526919551135};\\\", \\\"{x:789,y:520,t:1526919551153};\\\", \\\"{x:865,y:522,t:1526919551169};\\\", \\\"{x:930,y:527,t:1526919551186};\\\", \\\"{x:985,y:532,t:1526919551202};\\\", \\\"{x:1034,y:536,t:1526919551219};\\\", \\\"{x:1068,y:539,t:1526919551235};\\\", \\\"{x:1106,y:544,t:1526919551253};\\\", \\\"{x:1122,y:544,t:1526919551269};\\\", \\\"{x:1136,y:544,t:1526919551286};\\\", \\\"{x:1145,y:544,t:1526919551303};\\\", \\\"{x:1153,y:544,t:1526919551319};\\\", \\\"{x:1157,y:544,t:1526919551336};\\\", \\\"{x:1158,y:544,t:1526919551353};\\\", \\\"{x:1160,y:544,t:1526919551405};\\\", \\\"{x:1163,y:544,t:1526919551419};\\\", \\\"{x:1172,y:544,t:1526919551436};\\\", \\\"{x:1198,y:544,t:1526919551453};\\\", \\\"{x:1219,y:544,t:1526919551470};\\\", \\\"{x:1241,y:549,t:1526919551486};\\\", \\\"{x:1264,y:553,t:1526919551503};\\\", \\\"{x:1285,y:558,t:1526919551519};\\\", \\\"{x:1304,y:563,t:1526919551537};\\\", \\\"{x:1321,y:570,t:1526919551553};\\\", \\\"{x:1345,y:578,t:1526919551569};\\\", \\\"{x:1369,y:588,t:1526919551586};\\\", \\\"{x:1392,y:600,t:1526919551603};\\\", \\\"{x:1415,y:612,t:1526919551620};\\\", \\\"{x:1434,y:628,t:1526919551636};\\\", \\\"{x:1463,y:656,t:1526919551653};\\\", \\\"{x:1482,y:688,t:1526919551669};\\\", \\\"{x:1491,y:716,t:1526919551686};\\\", \\\"{x:1496,y:744,t:1526919551704};\\\", \\\"{x:1497,y:772,t:1526919551720};\\\", \\\"{x:1497,y:800,t:1526919551736};\\\", \\\"{x:1497,y:821,t:1526919551753};\\\", \\\"{x:1495,y:834,t:1526919551770};\\\", \\\"{x:1492,y:842,t:1526919551787};\\\", \\\"{x:1482,y:850,t:1526919551803};\\\", \\\"{x:1467,y:857,t:1526919551821};\\\", \\\"{x:1448,y:869,t:1526919551836};\\\", \\\"{x:1425,y:879,t:1526919551853};\\\", \\\"{x:1415,y:882,t:1526919551870};\\\", \\\"{x:1409,y:882,t:1526919551887};\\\", \\\"{x:1404,y:882,t:1526919551903};\\\", \\\"{x:1399,y:882,t:1526919551920};\\\", \\\"{x:1393,y:881,t:1526919551938};\\\", \\\"{x:1385,y:878,t:1526919551953};\\\", \\\"{x:1378,y:876,t:1526919551971};\\\", \\\"{x:1367,y:868,t:1526919551988};\\\", \\\"{x:1361,y:861,t:1526919552004};\\\", \\\"{x:1355,y:855,t:1526919552020};\\\", \\\"{x:1352,y:847,t:1526919552037};\\\", \\\"{x:1348,y:841,t:1526919552054};\\\", \\\"{x:1345,y:833,t:1526919552070};\\\", \\\"{x:1338,y:818,t:1526919552087};\\\", \\\"{x:1333,y:804,t:1526919552104};\\\", \\\"{x:1332,y:788,t:1526919552120};\\\", \\\"{x:1330,y:779,t:1526919552137};\\\", \\\"{x:1329,y:772,t:1526919552153};\\\", \\\"{x:1329,y:767,t:1526919552170};\\\", \\\"{x:1328,y:763,t:1526919552187};\\\", \\\"{x:1328,y:759,t:1526919552205};\\\", \\\"{x:1329,y:753,t:1526919552221};\\\", \\\"{x:1329,y:752,t:1526919552237};\\\", \\\"{x:1329,y:748,t:1526919552254};\\\", \\\"{x:1329,y:746,t:1526919552270};\\\", \\\"{x:1330,y:744,t:1526919552288};\\\", \\\"{x:1330,y:743,t:1526919552304};\\\", \\\"{x:1330,y:742,t:1526919552320};\\\", \\\"{x:1330,y:741,t:1526919552338};\\\", \\\"{x:1330,y:740,t:1526919552354};\\\", \\\"{x:1331,y:740,t:1526919552398};\\\", \\\"{x:1333,y:740,t:1526919552414};\\\", \\\"{x:1335,y:741,t:1526919552421};\\\", \\\"{x:1339,y:745,t:1526919552437};\\\", \\\"{x:1343,y:748,t:1526919552454};\\\", \\\"{x:1345,y:750,t:1526919552470};\\\", \\\"{x:1347,y:751,t:1526919552487};\\\", \\\"{x:1348,y:753,t:1526919552504};\\\", \\\"{x:1348,y:755,t:1526919552520};\\\", \\\"{x:1349,y:755,t:1526919552557};\\\", \\\"{x:1350,y:756,t:1526919552614};\\\", \\\"{x:1350,y:757,t:1526919552654};\\\", \\\"{x:1350,y:758,t:1526919552671};\\\", \\\"{x:1350,y:760,t:1526919552687};\\\", \\\"{x:1350,y:763,t:1526919552704};\\\", \\\"{x:1350,y:764,t:1526919552734};\\\", \\\"{x:1350,y:769,t:1526919554078};\\\", \\\"{x:1356,y:778,t:1526919554089};\\\", \\\"{x:1361,y:793,t:1526919554106};\\\", \\\"{x:1366,y:806,t:1526919554122};\\\", \\\"{x:1370,y:821,t:1526919554139};\\\", \\\"{x:1374,y:838,t:1526919554156};\\\", \\\"{x:1378,y:857,t:1526919554172};\\\", \\\"{x:1384,y:881,t:1526919554189};\\\", \\\"{x:1388,y:893,t:1526919554207};\\\", \\\"{x:1392,y:907,t:1526919554222};\\\", \\\"{x:1392,y:916,t:1526919554239};\\\", \\\"{x:1392,y:925,t:1526919554256};\\\", \\\"{x:1392,y:933,t:1526919554272};\\\", \\\"{x:1391,y:940,t:1526919554289};\\\", \\\"{x:1388,y:946,t:1526919554306};\\\", \\\"{x:1384,y:949,t:1526919554322};\\\", \\\"{x:1380,y:952,t:1526919554339};\\\", \\\"{x:1373,y:958,t:1526919554356};\\\", \\\"{x:1368,y:961,t:1526919554372};\\\", \\\"{x:1362,y:964,t:1526919554389};\\\", \\\"{x:1358,y:965,t:1526919554406};\\\", \\\"{x:1354,y:965,t:1526919554423};\\\", \\\"{x:1349,y:965,t:1526919554438};\\\", \\\"{x:1347,y:964,t:1526919554456};\\\", \\\"{x:1346,y:963,t:1526919554473};\\\", \\\"{x:1345,y:963,t:1526919554574};\\\", \\\"{x:1345,y:964,t:1526919554590};\\\", \\\"{x:1345,y:965,t:1526919554606};\\\", \\\"{x:1346,y:966,t:1526919554623};\\\", \\\"{x:1346,y:967,t:1526919554639};\\\", \\\"{x:1347,y:968,t:1526919554661};\\\", \\\"{x:1348,y:969,t:1526919554678};\\\", \\\"{x:1350,y:969,t:1526919554741};\\\", \\\"{x:1352,y:969,t:1526919554756};\\\", \\\"{x:1365,y:969,t:1526919554773};\\\", \\\"{x:1375,y:967,t:1526919554790};\\\", \\\"{x:1386,y:966,t:1526919554806};\\\", \\\"{x:1397,y:965,t:1526919554823};\\\", \\\"{x:1403,y:964,t:1526919554841};\\\", \\\"{x:1407,y:964,t:1526919554856};\\\", \\\"{x:1410,y:964,t:1526919554873};\\\", \\\"{x:1412,y:964,t:1526919554890};\\\", \\\"{x:1413,y:964,t:1526919554917};\\\", \\\"{x:1414,y:964,t:1526919554926};\\\", \\\"{x:1415,y:964,t:1526919554940};\\\", \\\"{x:1416,y:964,t:1526919554956};\\\", \\\"{x:1419,y:964,t:1526919554973};\\\", \\\"{x:1420,y:965,t:1526919554991};\\\", \\\"{x:1417,y:964,t:1526919555438};\\\", \\\"{x:1416,y:964,t:1526919555446};\\\", \\\"{x:1414,y:962,t:1526919555457};\\\", \\\"{x:1407,y:956,t:1526919555475};\\\", \\\"{x:1403,y:952,t:1526919555490};\\\", \\\"{x:1398,y:944,t:1526919555508};\\\", \\\"{x:1391,y:929,t:1526919555525};\\\", \\\"{x:1387,y:918,t:1526919555540};\\\", \\\"{x:1383,y:905,t:1526919555557};\\\", \\\"{x:1382,y:893,t:1526919555574};\\\", \\\"{x:1379,y:888,t:1526919555592};\\\", \\\"{x:1378,y:883,t:1526919555607};\\\", \\\"{x:1377,y:876,t:1526919555625};\\\", \\\"{x:1375,y:870,t:1526919555641};\\\", \\\"{x:1373,y:862,t:1526919555658};\\\", \\\"{x:1370,y:852,t:1526919555674};\\\", \\\"{x:1366,y:840,t:1526919555692};\\\", \\\"{x:1360,y:828,t:1526919555708};\\\", \\\"{x:1354,y:809,t:1526919555724};\\\", \\\"{x:1348,y:788,t:1526919555741};\\\", \\\"{x:1343,y:769,t:1526919555757};\\\", \\\"{x:1342,y:757,t:1526919555775};\\\", \\\"{x:1339,y:746,t:1526919555792};\\\", \\\"{x:1336,y:736,t:1526919555807};\\\", \\\"{x:1334,y:728,t:1526919555825};\\\", \\\"{x:1332,y:723,t:1526919555840};\\\", \\\"{x:1331,y:719,t:1526919555857};\\\", \\\"{x:1331,y:713,t:1526919555874};\\\", \\\"{x:1331,y:707,t:1526919555891};\\\", \\\"{x:1330,y:703,t:1526919555907};\\\", \\\"{x:1328,y:700,t:1526919555924};\\\", \\\"{x:1328,y:697,t:1526919555940};\\\", \\\"{x:1328,y:696,t:1526919555957};\\\", \\\"{x:1328,y:694,t:1526919555974};\\\", \\\"{x:1329,y:691,t:1526919555991};\\\", \\\"{x:1329,y:690,t:1526919556008};\\\", \\\"{x:1331,y:688,t:1526919556062};\\\", \\\"{x:1332,y:688,t:1526919556110};\\\", \\\"{x:1333,y:688,t:1526919556133};\\\", \\\"{x:1334,y:688,t:1526919556158};\\\", \\\"{x:1335,y:688,t:1526919556206};\\\", \\\"{x:1336,y:688,t:1526919556213};\\\", \\\"{x:1336,y:689,t:1526919556224};\\\", \\\"{x:1337,y:689,t:1526919556241};\\\", \\\"{x:1337,y:690,t:1526919556258};\\\", \\\"{x:1338,y:691,t:1526919556274};\\\", \\\"{x:1340,y:692,t:1526919556292};\\\", \\\"{x:1341,y:693,t:1526919556308};\\\", \\\"{x:1343,y:695,t:1526919556326};\\\", \\\"{x:1344,y:696,t:1526919556341};\\\", \\\"{x:1345,y:696,t:1526919556422};\\\", \\\"{x:1345,y:693,t:1526919560676};\\\", \\\"{x:1346,y:691,t:1526919560684};\\\", \\\"{x:1351,y:686,t:1526919560696};\\\", \\\"{x:1358,y:679,t:1526919560712};\\\", \\\"{x:1364,y:674,t:1526919560729};\\\", \\\"{x:1370,y:669,t:1526919560745};\\\", \\\"{x:1375,y:666,t:1526919560763};\\\", \\\"{x:1377,y:663,t:1526919560779};\\\", \\\"{x:1381,y:659,t:1526919560796};\\\", \\\"{x:1388,y:648,t:1526919560812};\\\", \\\"{x:1394,y:641,t:1526919560829};\\\", \\\"{x:1402,y:635,t:1526919560845};\\\", \\\"{x:1409,y:626,t:1526919560863};\\\", \\\"{x:1413,y:620,t:1526919560879};\\\", \\\"{x:1417,y:613,t:1526919560896};\\\", \\\"{x:1420,y:607,t:1526919560913};\\\", \\\"{x:1422,y:601,t:1526919560929};\\\", \\\"{x:1423,y:598,t:1526919560946};\\\", \\\"{x:1424,y:597,t:1526919560963};\\\", \\\"{x:1425,y:595,t:1526919560981};\\\", \\\"{x:1425,y:594,t:1526919560996};\\\", \\\"{x:1425,y:591,t:1526919561012};\\\", \\\"{x:1425,y:589,t:1526919561029};\\\", \\\"{x:1424,y:585,t:1526919561046};\\\", \\\"{x:1424,y:582,t:1526919561063};\\\", \\\"{x:1422,y:579,t:1526919561081};\\\", \\\"{x:1422,y:577,t:1526919561096};\\\", \\\"{x:1421,y:574,t:1526919561114};\\\", \\\"{x:1420,y:572,t:1526919561131};\\\", \\\"{x:1420,y:570,t:1526919561146};\\\", \\\"{x:1420,y:568,t:1526919561164};\\\", \\\"{x:1420,y:567,t:1526919561180};\\\", \\\"{x:1420,y:566,t:1526919561197};\\\", \\\"{x:1420,y:565,t:1526919561214};\\\", \\\"{x:1420,y:564,t:1526919561278};\\\", \\\"{x:1420,y:562,t:1526919561296};\\\", \\\"{x:1419,y:562,t:1526919561313};\\\", \\\"{x:1418,y:561,t:1526919561331};\\\", \\\"{x:1418,y:560,t:1526919561381};\\\", \\\"{x:1418,y:563,t:1526919561494};\\\", \\\"{x:1418,y:566,t:1526919561501};\\\", \\\"{x:1418,y:572,t:1526919561514};\\\", \\\"{x:1423,y:598,t:1526919561531};\\\", \\\"{x:1427,y:631,t:1526919561547};\\\", \\\"{x:1430,y:662,t:1526919561564};\\\", \\\"{x:1441,y:705,t:1526919561581};\\\", \\\"{x:1455,y:781,t:1526919561598};\\\", \\\"{x:1461,y:815,t:1526919561614};\\\", \\\"{x:1469,y:851,t:1526919561631};\\\", \\\"{x:1477,y:881,t:1526919561648};\\\", \\\"{x:1480,y:906,t:1526919561664};\\\", \\\"{x:1484,y:932,t:1526919561681};\\\", \\\"{x:1486,y:950,t:1526919561698};\\\", \\\"{x:1486,y:965,t:1526919561715};\\\", \\\"{x:1486,y:980,t:1526919561731};\\\", \\\"{x:1486,y:995,t:1526919561748};\\\", \\\"{x:1483,y:1010,t:1526919561764};\\\", \\\"{x:1477,y:1022,t:1526919561781};\\\", \\\"{x:1469,y:1031,t:1526919561797};\\\", \\\"{x:1465,y:1033,t:1526919561814};\\\", \\\"{x:1463,y:1033,t:1526919561830};\\\", \\\"{x:1461,y:1033,t:1526919561847};\\\", \\\"{x:1457,y:1026,t:1526919561864};\\\", \\\"{x:1454,y:1021,t:1526919561880};\\\", \\\"{x:1451,y:1017,t:1526919561897};\\\", \\\"{x:1445,y:1010,t:1526919561914};\\\", \\\"{x:1443,y:1006,t:1526919561930};\\\", \\\"{x:1442,y:1003,t:1526919561947};\\\", \\\"{x:1440,y:998,t:1526919561964};\\\", \\\"{x:1437,y:991,t:1526919561981};\\\", \\\"{x:1435,y:987,t:1526919561997};\\\", \\\"{x:1433,y:985,t:1526919562014};\\\", \\\"{x:1433,y:982,t:1526919562032};\\\", \\\"{x:1431,y:979,t:1526919562047};\\\", \\\"{x:1430,y:977,t:1526919562064};\\\", \\\"{x:1428,y:975,t:1526919562081};\\\", \\\"{x:1427,y:975,t:1526919562109};\\\", \\\"{x:1427,y:973,t:1526919562117};\\\", \\\"{x:1426,y:973,t:1526919562131};\\\", \\\"{x:1424,y:971,t:1526919562148};\\\", \\\"{x:1422,y:970,t:1526919562165};\\\", \\\"{x:1419,y:967,t:1526919562181};\\\", \\\"{x:1418,y:965,t:1526919562198};\\\", \\\"{x:1417,y:963,t:1526919562215};\\\", \\\"{x:1417,y:962,t:1526919562238};\\\", \\\"{x:1416,y:962,t:1526919562248};\\\", \\\"{x:1416,y:961,t:1526919562265};\\\", \\\"{x:1416,y:960,t:1526919562281};\\\", \\\"{x:1417,y:960,t:1526919563310};\\\", \\\"{x:1422,y:959,t:1526919563317};\\\", \\\"{x:1429,y:958,t:1526919563333};\\\", \\\"{x:1442,y:958,t:1526919563349};\\\", \\\"{x:1444,y:956,t:1526919563366};\\\", \\\"{x:1446,y:956,t:1526919563383};\\\", \\\"{x:1447,y:956,t:1526919563399};\\\", \\\"{x:1448,y:956,t:1526919563422};\\\", \\\"{x:1449,y:956,t:1526919563433};\\\", \\\"{x:1451,y:956,t:1526919563450};\\\", \\\"{x:1454,y:956,t:1526919563466};\\\", \\\"{x:1455,y:957,t:1526919563483};\\\", \\\"{x:1458,y:957,t:1526919563500};\\\", \\\"{x:1459,y:957,t:1526919563516};\\\", \\\"{x:1460,y:957,t:1526919563532};\\\", \\\"{x:1461,y:957,t:1526919563565};\\\", \\\"{x:1462,y:958,t:1526919563581};\\\", \\\"{x:1464,y:960,t:1526919563600};\\\", \\\"{x:1466,y:960,t:1526919563617};\\\", \\\"{x:1467,y:962,t:1526919563633};\\\", \\\"{x:1468,y:962,t:1526919563650};\\\", \\\"{x:1469,y:963,t:1526919563677};\\\", \\\"{x:1470,y:963,t:1526919563694};\\\", \\\"{x:1471,y:964,t:1526919563702};\\\", \\\"{x:1472,y:965,t:1526919563717};\\\", \\\"{x:1473,y:965,t:1526919563741};\\\", \\\"{x:1474,y:966,t:1526919563750};\\\", \\\"{x:1475,y:967,t:1526919563767};\\\", \\\"{x:1475,y:968,t:1526919563783};\\\", \\\"{x:1476,y:968,t:1526919563800};\\\", \\\"{x:1476,y:969,t:1526919563838};\\\", \\\"{x:1477,y:969,t:1526919565286};\\\", \\\"{x:1478,y:967,t:1526919565309};\\\", \\\"{x:1478,y:966,t:1526919565325};\\\", \\\"{x:1478,y:965,t:1526919565341};\\\", \\\"{x:1478,y:964,t:1526919565352};\\\", \\\"{x:1479,y:964,t:1526919565367};\\\", \\\"{x:1479,y:963,t:1526919565893};\\\", \\\"{x:1479,y:965,t:1526919567238};\\\", \\\"{x:1476,y:966,t:1526919567253};\\\", \\\"{x:1473,y:968,t:1526919567270};\\\", \\\"{x:1468,y:969,t:1526919567287};\\\", \\\"{x:1466,y:970,t:1526919567304};\\\", \\\"{x:1464,y:971,t:1526919567320};\\\", \\\"{x:1463,y:971,t:1526919567337};\\\", \\\"{x:1460,y:971,t:1526919567354};\\\", \\\"{x:1458,y:971,t:1526919567370};\\\", \\\"{x:1457,y:973,t:1526919567387};\\\", \\\"{x:1455,y:973,t:1526919567404};\\\", \\\"{x:1452,y:973,t:1526919567421};\\\", \\\"{x:1449,y:974,t:1526919567438};\\\", \\\"{x:1448,y:974,t:1526919567453};\\\", \\\"{x:1447,y:974,t:1526919567471};\\\", \\\"{x:1445,y:974,t:1526919567486};\\\", \\\"{x:1441,y:973,t:1526919567504};\\\", \\\"{x:1438,y:973,t:1526919567521};\\\", \\\"{x:1436,y:972,t:1526919567536};\\\", \\\"{x:1434,y:972,t:1526919567554};\\\", \\\"{x:1432,y:972,t:1526919567571};\\\", \\\"{x:1431,y:972,t:1526919567587};\\\", \\\"{x:1430,y:972,t:1526919567604};\\\", \\\"{x:1429,y:972,t:1526919567645};\\\", \\\"{x:1428,y:972,t:1526919567661};\\\", \\\"{x:1427,y:973,t:1526919567717};\\\", \\\"{x:1426,y:973,t:1526919567902};\\\", \\\"{x:1425,y:973,t:1526919568541};\\\", \\\"{x:1424,y:973,t:1526919568646};\\\", \\\"{x:1423,y:973,t:1526919568677};\\\", \\\"{x:1421,y:969,t:1526919568693};\\\", \\\"{x:1420,y:966,t:1526919568706};\\\", \\\"{x:1420,y:963,t:1526919568722};\\\", \\\"{x:1419,y:957,t:1526919568739};\\\", \\\"{x:1418,y:953,t:1526919568754};\\\", \\\"{x:1417,y:950,t:1526919568772};\\\", \\\"{x:1417,y:944,t:1526919568789};\\\", \\\"{x:1417,y:939,t:1526919568805};\\\", \\\"{x:1417,y:931,t:1526919568822};\\\", \\\"{x:1420,y:922,t:1526919568839};\\\", \\\"{x:1420,y:913,t:1526919568856};\\\", \\\"{x:1421,y:899,t:1526919568872};\\\", \\\"{x:1421,y:890,t:1526919568888};\\\", \\\"{x:1421,y:886,t:1526919568905};\\\", \\\"{x:1421,y:883,t:1526919568921};\\\", \\\"{x:1421,y:882,t:1526919568956};\\\", \\\"{x:1419,y:881,t:1526919568971};\\\", \\\"{x:1403,y:881,t:1526919568988};\\\", \\\"{x:1382,y:881,t:1526919569005};\\\", \\\"{x:1350,y:876,t:1526919569022};\\\", \\\"{x:1299,y:869,t:1526919569038};\\\", \\\"{x:1224,y:858,t:1526919569055};\\\", \\\"{x:1144,y:849,t:1526919569071};\\\", \\\"{x:1083,y:840,t:1526919569088};\\\", \\\"{x:1019,y:832,t:1526919569106};\\\", \\\"{x:968,y:824,t:1526919569122};\\\", \\\"{x:932,y:821,t:1526919569138};\\\", \\\"{x:909,y:819,t:1526919569156};\\\", \\\"{x:892,y:814,t:1526919569172};\\\", \\\"{x:868,y:808,t:1526919569189};\\\", \\\"{x:839,y:804,t:1526919569205};\\\", \\\"{x:797,y:797,t:1526919569222};\\\", \\\"{x:734,y:792,t:1526919569238};\\\", \\\"{x:654,y:783,t:1526919569256};\\\", \\\"{x:575,y:779,t:1526919569272};\\\", \\\"{x:508,y:771,t:1526919569289};\\\", \\\"{x:457,y:769,t:1526919569306};\\\", \\\"{x:431,y:769,t:1526919569322};\\\", \\\"{x:412,y:769,t:1526919569338};\\\", \\\"{x:396,y:769,t:1526919569355};\\\", \\\"{x:375,y:769,t:1526919569372};\\\", \\\"{x:363,y:769,t:1526919569389};\\\", \\\"{x:348,y:769,t:1526919569406};\\\", \\\"{x:337,y:767,t:1526919569423};\\\", \\\"{x:327,y:763,t:1526919569439};\\\", \\\"{x:326,y:761,t:1526919569455};\\\", \\\"{x:326,y:757,t:1526919569473};\\\", \\\"{x:331,y:750,t:1526919569489};\\\", \\\"{x:343,y:745,t:1526919569506};\\\", \\\"{x:356,y:742,t:1526919569522};\\\", \\\"{x:376,y:736,t:1526919569539};\\\", \\\"{x:401,y:734,t:1526919569556};\\\", \\\"{x:436,y:733,t:1526919569573};\\\", \\\"{x:461,y:733,t:1526919569588};\\\", \\\"{x:489,y:737,t:1526919569607};\\\", \\\"{x:518,y:741,t:1526919569622};\\\", \\\"{x:542,y:748,t:1526919569639};\\\", \\\"{x:549,y:748,t:1526919569649};\\\", \\\"{x:553,y:750,t:1526919569666};\\\", \\\"{x:551,y:750,t:1526919569804};\\\", \\\"{x:549,y:749,t:1526919569817};\\\", \\\"{x:546,y:747,t:1526919569833};\\\", \\\"{x:540,y:746,t:1526919569850};\\\", \\\"{x:538,y:746,t:1526919569867};\\\", \\\"{x:537,y:746,t:1526919569883};\\\", \\\"{x:536,y:745,t:1526919569900};\\\", \\\"{x:535,y:744,t:1526919569916};\\\", \\\"{x:534,y:743,t:1526919569941};\\\", \\\"{x:533,y:743,t:1526919569989};\\\" ] }, { \\\"rt\\\": 30693, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 982198, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"LOOK AT THE X-AXIS FOR 12 pm AND GO UP THE GRAPH\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11887, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USSA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 995091, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 18528, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1014644, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 6639, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1022611, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"Z5Z7P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"Z5Z7P\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 125, dom: 632, initialDom: 692",
  "javascriptErrors": []
}