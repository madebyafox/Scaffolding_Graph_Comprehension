var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f6e38771e6e1af1f866f80b87cb925fa",
  "created": "2018-05-21T09:19:31.0386389-07:00",
  "lastActivity": "2018-05-21T09:20:45.3786389-07:00",
  "pageViews": [
    {
      "id": "05213183b378978095ebbf995cd40e385d140b83",
      "startTime": "2018-05-21T09:19:31.0386389-07:00",
      "endTime": "2018-05-21T09:20:45.3786389-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 74340,
      "engagementTime": 74189,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 74340,
  "engagementTime": 74189,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=Z5Z7P",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "70ef5fa64af0ea81f6b7a59beff9f663",
  "gdpr": false
}