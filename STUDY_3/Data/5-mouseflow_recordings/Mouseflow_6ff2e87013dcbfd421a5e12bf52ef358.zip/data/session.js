var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6ff2e87013dcbfd421a5e12bf52ef358",
  "created": "2018-05-29T16:17:08.4113247-07:00",
  "lastActivity": "2018-05-29T16:17:31.8573247-07:00",
  "pageViews": [
    {
      "id": "05290827ab07dede2ebc4208dc0e8ee935c3d112",
      "startTime": "2018-05-29T16:17:08.4113247-07:00",
      "endTime": "2018-05-29T16:17:31.8573247-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 23446,
      "engagementTime": 23376,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 23446,
  "engagementTime": 23376,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SQ6AK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "716b5a012aba5b5d03f6b7350d3efd99",
  "gdpr": false
}