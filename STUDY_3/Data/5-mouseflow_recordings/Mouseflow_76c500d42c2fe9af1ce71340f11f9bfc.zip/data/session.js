var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "76c500d42c2fe9af1ce71340f11f9bfc",
  "created": "2018-05-22T16:04:03.323579-07:00",
  "lastActivity": "2018-05-22T16:05:57.686579-07:00",
  "pageViews": [
    {
      "id": "052203420daffdfc643cf0f8cfc56085a9bda716",
      "startTime": "2018-05-22T16:04:03.323579-07:00",
      "endTime": "2018-05-22T16:05:57.686579-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 114363,
      "engagementTime": 86816,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 114363,
  "engagementTime": 86816,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3fef5d37a3f4ca33ab7dc8c6c7ca2cd9",
  "gdpr": false
}