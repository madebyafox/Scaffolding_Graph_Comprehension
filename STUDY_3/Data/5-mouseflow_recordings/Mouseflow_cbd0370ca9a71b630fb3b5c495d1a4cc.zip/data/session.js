var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cbd0370ca9a71b630fb3b5c495d1a4cc",
  "created": "2018-06-04T13:21:53.7634786-07:00",
  "lastActivity": "2018-06-04T13:22:04.21433-07:00",
  "pageViews": [
    {
      "id": "060453779463a1017dab8f2107518d59f49ba42c",
      "startTime": "2018-06-04T13:21:53.7634786-07:00",
      "endTime": "2018-06-04T13:22:04.21433-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 10510,
      "engagementTime": 10411,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10510,
  "engagementTime": 10411,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K0CNH",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9ae4c9450eb3a8591277ca159d3bdd2a",
  "gdpr": false
}