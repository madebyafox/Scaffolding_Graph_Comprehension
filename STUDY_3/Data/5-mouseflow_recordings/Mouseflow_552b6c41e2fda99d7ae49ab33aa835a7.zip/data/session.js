var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "552b6c41e2fda99d7ae49ab33aa835a7",
  "created": "2018-06-01T10:17:13.0741509-07:00",
  "lastActivity": "2018-06-01T10:18:15.1163923-07:00",
  "pageViews": [
    {
      "id": "060113824f57c25987e1900d193503a56a8dc5a8",
      "startTime": "2018-06-01T10:17:13.3787326-07:00",
      "endTime": "2018-06-01T10:18:15.1163923-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 61941,
      "engagementTime": 61941,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 61941,
  "engagementTime": 61941,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MWJFN",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b15ce76edaae73b5c27f0df48fb44445",
  "gdpr": false
}