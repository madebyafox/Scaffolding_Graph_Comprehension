var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9ba87551d519ba15cb50abcd2f9c139c",
  "created": "2018-06-04T12:19:32.7843607-07:00",
  "lastActivity": "2018-06-04T12:19:44.8103607-07:00",
  "pageViews": [
    {
      "id": "06043323cfd1c3ebbff3f3323f014a3adebae63d",
      "startTime": "2018-06-04T12:19:32.7843607-07:00",
      "endTime": "2018-06-04T12:19:44.8103607-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 12026,
      "engagementTime": 12009,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12026,
  "engagementTime": 12009,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=02TJQ",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "459e1da8fd1938b886c6176694c1cb0e",
  "gdpr": false
}