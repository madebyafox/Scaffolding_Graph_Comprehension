var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a5b8b07ab6da08fc5286416d47d807d1",
  "created": "2018-05-24T12:15:45.8604126-07:00",
  "lastActivity": "2018-05-24T12:16:55.8574126-07:00",
  "pageViews": [
    {
      "id": "052446547dedd78f9ec397458357f0eacb7ec72b",
      "startTime": "2018-05-24T12:15:45.8604126-07:00",
      "endTime": "2018-05-24T12:16:55.8574126-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 69997,
      "engagementTime": 65968,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 69997,
  "engagementTime": 65968,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=WBR05",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "47e27d6fc6c92c4d92f56b876b84a2a9",
  "gdpr": false
}