var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5286cb7b32b893e0fdaf6b9ea2c5ece6",
  "created": "2018-05-21T09:05:59.3126482-07:00",
  "lastActivity": "2018-05-21T09:07:15.6722546-07:00",
  "pageViews": [
    {
      "id": "0521593913356e15d02b042c68dce84288fe3e05",
      "startTime": "2018-05-21T09:05:59.3126482-07:00",
      "endTime": "2018-05-21T09:07:15.6722546-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 76631,
      "engagementTime": 52683,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 76631,
  "engagementTime": 52683,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6950be165dd41ca3dbec1d4187f8e228",
  "gdpr": false
}