var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "93f5070115f9bea37254cf3faec1eb59",
  "created": "2018-05-29T12:13:29.2080553-07:00",
  "lastActivity": "2018-05-29T12:13:40.0360553-07:00",
  "pageViews": [
    {
      "id": "05292991c5a3c7dcc60845e5aa7da2e5bc5d47fe",
      "startTime": "2018-05-29T12:13:29.2080553-07:00",
      "endTime": "2018-05-29T12:13:40.0360553-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 10828,
      "engagementTime": 10812,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10828,
  "engagementTime": 10812,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G8P43",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bb396f7cb83c3cde1475da80dbe2f980",
  "gdpr": false
}