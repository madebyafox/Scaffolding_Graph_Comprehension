var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06045239b4ac9ef3ff21dc2aa9baf3918a226e2b"] = {
  "startTime": "2018-06-04T19:19:52.3644488Z",
  "websitePageUrl": "/16",
  "visitTime": 103390,
  "engagementTime": 79869,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a7ebddecd7381f8b9ed895d05d5da2e0",
    "created": "2018-06-04T19:19:52.1566364+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=CKDM5",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0a0c232f2633dda68def9850d41ea999",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a7ebddecd7381f8b9ed895d05d5da2e0/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 183,
      "e": 183,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 549,
      "y": 762
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 546,
      "y": 762
    },
    {
      "t": 500,
      "e": 500,
      "ty": 41,
      "x": 50461,
      "y": 41769,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 688,
      "e": 688,
      "ty": 2,
      "x": 544,
      "y": 763
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 50236,
      "y": 41880,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 544,
      "y": 764
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 544,
      "y": 717
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 522,
      "y": 607
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 47763,
      "y": 62883,
      "ta": "#.strategy"
    },
    {
      "t": 1047,
      "e": 1047,
      "ty": 6,
      "x": 514,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 506,
      "y": 595
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 476,
      "y": 558
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 42255,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1276,
      "e": 1276,
      "ty": 3,
      "x": 473,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1277,
      "e": 1277,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 473,
      "y": 557
    },
    {
      "t": 1371,
      "e": 1371,
      "ty": 4,
      "x": 42255,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1372,
      "e": 1372,
      "ty": 5,
      "x": 473,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 294,
      "y": 578
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 22134,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2531,
      "e": 2531,
      "ty": 7,
      "x": 74,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 0,
      "y": 559
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 0,
      "y": 30967,
      "ta": "html"
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 42,
      "y": 551
    },
    {
      "t": 2965,
      "e": 2965,
      "ty": 6,
      "x": 103,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 128,
      "y": 571
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 3474,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 143,
      "y": 573
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 5160,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 177,
      "y": 556
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 263,
      "y": 569
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 18649,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3567,
      "e": 3567,
      "ty": 7,
      "x": 559,
      "y": 627,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 829,
      "y": 678
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1015,
      "y": 713
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 16138,
      "y": 41183,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1016,
      "y": 714
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1091,
      "y": 750
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 24171,
      "y": 44907,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1179,
      "y": 781
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1229,
      "y": 804
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 2,
      "x": 1243,
      "y": 822
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 32204,
      "y": 48990,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1206,
      "y": 863
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1104,
      "y": 901
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 22057,
      "y": 54863,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1105,
      "y": 915
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1177,
      "y": 954
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1197,
      "y": 972
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 28963,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1191,
      "y": 976
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1188,
      "y": 977
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 28047,
      "y": 60091,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1176,
      "y": 975
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1168,
      "y": 972
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1166,
      "y": 972
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 53570,
      "y": 12543,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1161,
      "y": 970
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1158,
      "y": 969
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 26003,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1154,
      "y": 965
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1151,
      "y": 956
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1150,
      "y": 953
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 25651,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1140,
      "y": 953
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1133,
      "y": 961
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 24242,
      "y": 59518,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1130,
      "y": 971
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1132,
      "y": 973
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 1160,
      "y": 967
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 26356,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1164,
      "y": 965
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1165,
      "y": 965
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 26708,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1161,
      "y": 965
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1160,
      "y": 965
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 26356,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1159,
      "y": 965
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 26285,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1157,
      "y": 965
    },
    {
      "t": 8702,
      "e": 8702,
      "ty": 2,
      "x": 1156,
      "y": 965
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 26074,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33491,
      "e": 13752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 33989,
      "e": 14250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34022,
      "e": 14283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34055,
      "e": 14316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34066,
      "e": 14327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34066,
      "e": 14327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34185,
      "e": 14446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 34201,
      "e": 14462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 34322,
      "e": 14583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34322,
      "e": 14583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34473,
      "e": 14734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 34538,
      "e": 14799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34538,
      "e": 14799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34713,
      "e": 14974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 34962,
      "e": 15223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34963,
      "e": 15224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35121,
      "e": 15382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 40004,
      "e": 20265,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 43426,
      "e": 20382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43427,
      "e": 20383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43605,
      "e": 20561,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The l"
    },
    {
      "t": 43633,
      "e": 20589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 44866,
      "e": 21822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44867,
      "e": 21823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45005,
      "e": 21961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The li"
    },
    {
      "t": 45017,
      "e": 21973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45338,
      "e": 22294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 45338,
      "e": 22294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45537,
      "e": 22493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 49641,
      "e": 26597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49737,
      "e": 26693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The li"
    },
    {
      "t": 49825,
      "e": 26781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49826,
      "e": 26782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49914,
      "e": 26870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50004,
      "e": 26960,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50081,
      "e": 27037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50145,
      "e": 27101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The li"
    },
    {
      "t": 50216,
      "e": 27172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50297,
      "e": 27253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The l"
    },
    {
      "t": 50401,
      "e": 27357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50506,
      "e": 27462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 50802,
      "e": 27758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50802,
      "e": 27758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50929,
      "e": 27885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 50936,
      "e": 27892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50938,
      "e": 27894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51017,
      "e": 27973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51017,
      "e": 27973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51033,
      "e": 27989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ia"
    },
    {
      "t": 51114,
      "e": 28070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51234,
      "e": 28190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 51235,
      "e": 28191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51321,
      "e": 28277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51321,
      "e": 28277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51345,
      "e": 28301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 51425,
      "e": 28381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51425,
      "e": 28381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51457,
      "e": 28413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 51585,
      "e": 28541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51586,
      "e": 28542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51588,
      "e": 28544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51697,
      "e": 28653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 51697,
      "e": 28653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51721,
      "e": 28677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 51833,
      "e": 28789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51834,
      "e": 28790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51834,
      "e": 28790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51945,
      "e": 28901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52122,
      "e": 29078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52123,
      "e": 29079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52209,
      "e": 29165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52362,
      "e": 29318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52362,
      "e": 29318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52473,
      "e": 29429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52994,
      "e": 29950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52995,
      "e": 29951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53161,
      "e": 30117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53898,
      "e": 30854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53899,
      "e": 30855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54006,
      "e": 30962,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line"
    },
    {
      "t": 54010,
      "e": 30966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54018,
      "e": 30974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54018,
      "e": 30974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54145,
      "e": 31101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54153,
      "e": 31109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54153,
      "e": 31109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54250,
      "e": 31206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54250,
      "e": 31206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54280,
      "e": 31236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 54345,
      "e": 31301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54345,
      "e": 31301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54361,
      "e": 31317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54433,
      "e": 31389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54434,
      "e": 31390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54481,
      "e": 31437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54577,
      "e": 31533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54618,
      "e": 31574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54618,
      "e": 31574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54807,
      "e": 31763,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that "
    },
    {
      "t": 54811,
      "e": 31767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54834,
      "e": 31790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 54834,
      "e": 31790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54977,
      "e": 31933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 54985,
      "e": 31941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 54985,
      "e": 31941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55137,
      "e": 32093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55426,
      "e": 32382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55427,
      "e": 32383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55569,
      "e": 32525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55569,
      "e": 32525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55625,
      "e": 32581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 55714,
      "e": 32670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56034,
      "e": 32990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56035,
      "e": 32991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56176,
      "e": 33132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56330,
      "e": 33286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56331,
      "e": 33287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56465,
      "e": 33421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56473,
      "e": 33429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56474,
      "e": 33430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56605,
      "e": 33561,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes th"
    },
    {
      "t": 56617,
      "e": 33573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 56641,
      "e": 33597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 56641,
      "e": 33597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56737,
      "e": 33693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56738,
      "e": 33694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56777,
      "e": 33733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 56865,
      "e": 33821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 56865,
      "e": 33821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56873,
      "e": 33829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 56986,
      "e": 33942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57002,
      "e": 33958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 57003,
      "e": 33959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57105,
      "e": 34061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57105,
      "e": 34061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57129,
      "e": 34085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 57266,
      "e": 34222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57266,
      "e": 34222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57312,
      "e": 34268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57465,
      "e": 34421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58937,
      "e": 35893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59073,
      "e": 36029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 59075,
      "e": 36031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59206,
      "e": 36162,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M"
    },
    {
      "t": 59249,
      "e": 36205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 59274,
      "e": 36230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59497,
      "e": 36453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59498,
      "e": 36454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59605,
      "e": 36455,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M "
    },
    {
      "t": 59649,
      "e": 36499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60098,
      "e": 36948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60098,
      "e": 36948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60201,
      "e": 37051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 60233,
      "e": 37083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60234,
      "e": 37084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60345,
      "e": 37195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 60345,
      "e": 37195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60392,
      "e": 37242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 60449,
      "e": 37299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60489,
      "e": 37339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60490,
      "e": 37340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60605,
      "e": 37455,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and "
    },
    {
      "t": 60617,
      "e": 37467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60641,
      "e": 37491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60738,
      "e": 37588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60738,
      "e": 37588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60816,
      "e": 37666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 60897,
      "e": 37747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61017,
      "e": 37867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61018,
      "e": 37868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61153,
      "e": 38003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61346,
      "e": 38196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61346,
      "e": 38196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61465,
      "e": 38315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61465,
      "e": 38315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61489,
      "e": 38339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 61585,
      "e": 38435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61594,
      "e": 38444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 61594,
      "e": 38444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61688,
      "e": 38538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 61721,
      "e": 38571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61721,
      "e": 38571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61817,
      "e": 38667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 61817,
      "e": 38667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61825,
      "e": 38675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ic"
    },
    {
      "t": 61905,
      "e": 38755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61906,
      "e": 38756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61921,
      "e": 38771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62041,
      "e": 38891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62137,
      "e": 38987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62138,
      "e": 38988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62257,
      "e": 39107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62257,
      "e": 39107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62305,
      "e": 39155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 62401,
      "e": 39251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62402,
      "e": 39252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62417,
      "e": 39267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62488,
      "e": 39338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62489,
      "e": 39339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62513,
      "e": 39363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 62610,
      "e": 39460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 62610,
      "e": 39460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62616,
      "e": 39466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 62737,
      "e": 39587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62737,
      "e": 39587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62744,
      "e": 39594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62857,
      "e": 39707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62857,
      "e": 39707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62889,
      "e": 39739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63001,
      "e": 39851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63009,
      "e": 39859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63010,
      "e": 39860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63170,
      "e": 40020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63186,
      "e": 40036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63186,
      "e": 40036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63297,
      "e": 40147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63299,
      "e": 40149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63344,
      "e": 40194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 63416,
      "e": 40266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63417,
      "e": 40267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63440,
      "e": 40290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63521,
      "e": 40371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63521,
      "e": 40371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63529,
      "e": 40379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63657,
      "e": 40507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63658,
      "e": 40508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63681,
      "e": 40531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63761,
      "e": 40611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63761,
      "e": 40611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63809,
      "e": 40659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63865,
      "e": 40715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63866,
      "e": 40716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63873,
      "e": 40723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 64005,
      "e": 40855,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and L indicate that those t"
    },
    {
      "t": 64012,
      "e": 40862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64012,
      "e": 40862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64056,
      "e": 40906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64081,
      "e": 40931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 64081,
      "e": 40931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64153,
      "e": 41003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 64201,
      "e": 41051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64201,
      "e": 41051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64202,
      "e": 41052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64296,
      "e": 41146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64305,
      "e": 41155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 64305,
      "e": 41155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64385,
      "e": 41235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 64385,
      "e": 41235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64417,
      "e": 41267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 64521,
      "e": 41371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64523,
      "e": 41373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64544,
      "e": 41394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 64577,
      "e": 41427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 64577,
      "e": 41427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64649,
      "e": 41499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 64697,
      "e": 41547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64890,
      "e": 41740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64890,
      "e": 41740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65006,
      "e": 41741,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and L indicate that those two shift"
    },
    {
      "t": 65065,
      "e": 41800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65065,
      "e": 41800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65089,
      "e": 41824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 65137,
      "e": 41872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65754,
      "e": 42489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65754,
      "e": 42489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65864,
      "e": 42599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65897,
      "e": 42632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65897,
      "e": 42632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66006,
      "e": 42741,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and L indicate that those two shifts s"
    },
    {
      "t": 66025,
      "e": 42760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66025,
      "e": 42760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66033,
      "e": 42768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 66169,
      "e": 42904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66170,
      "e": 42905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66172,
      "e": 42907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66281,
      "e": 43016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66281,
      "e": 43016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66305,
      "e": 43040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 66385,
      "e": 43120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66465,
      "e": 43200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66466,
      "e": 43201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66605,
      "e": 43340,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and L indicate that those two shifts start"
    },
    {
      "t": 66617,
      "e": 43352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66617,
      "e": 43352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66625,
      "e": 43360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 66729,
      "e": 43464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66731,
      "e": 43466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66744,
      "e": 43479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 66833,
      "e": 43568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66833,
      "e": 43568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66864,
      "e": 43599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66937,
      "e": 43672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66938,
      "e": 43673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66945,
      "e": 43680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67089,
      "e": 43824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67186,
      "e": 43921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 67186,
      "e": 43921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67298,
      "e": 44033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 67299,
      "e": 44034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67313,
      "e": 44048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 67433,
      "e": 44168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68514,
      "e": 45249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 68514,
      "e": 45249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68601,
      "e": 45336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 68913,
      "e": 45648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 68914,
      "e": 45649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68993,
      "e": 45728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 69122,
      "e": 45857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 69123,
      "e": 45858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69241,
      "e": 45976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 70503,
      "e": 47238,
      "ty": 2,
      "x": 593,
      "y": 932
    },
    {
      "t": 70504,
      "e": 47239,
      "ty": 41,
      "x": 55744,
      "y": 51187,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 70603,
      "e": 47338,
      "ty": 2,
      "x": 0,
      "y": 764
    },
    {
      "t": 70704,
      "e": 47439,
      "ty": 2,
      "x": 5,
      "y": 759
    },
    {
      "t": 70753,
      "e": 47488,
      "ty": 41,
      "x": 654,
      "y": 41104,
      "ta": "> div.stimulus"
    },
    {
      "t": 70803,
      "e": 47538,
      "ty": 2,
      "x": 260,
      "y": 723
    },
    {
      "t": 70903,
      "e": 47638,
      "ty": 2,
      "x": 339,
      "y": 712
    },
    {
      "t": 71004,
      "e": 47739,
      "ty": 2,
      "x": 340,
      "y": 710
    },
    {
      "t": 71004,
      "e": 47739,
      "ty": 41,
      "x": 10020,
      "y": 57844,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 71091,
      "e": 47826,
      "ty": 6,
      "x": 387,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 71104,
      "e": 47839,
      "ty": 2,
      "x": 387,
      "y": 688
    },
    {
      "t": 71190,
      "e": 47925,
      "ty": 7,
      "x": 383,
      "y": 651,
      "ta": "#strategyButton"
    },
    {
      "t": 71203,
      "e": 47938,
      "ty": 2,
      "x": 383,
      "y": 651
    },
    {
      "t": 71253,
      "e": 47988,
      "ty": 41,
      "x": 30149,
      "y": 17868,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 71304,
      "e": 48039,
      "ty": 2,
      "x": 383,
      "y": 649
    },
    {
      "t": 71503,
      "e": 48238,
      "ty": 2,
      "x": 379,
      "y": 653
    },
    {
      "t": 71504,
      "e": 48239,
      "ty": 41,
      "x": 28276,
      "y": 20489,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 71830,
      "e": 48565,
      "ty": 6,
      "x": 379,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 71903,
      "e": 48638,
      "ty": 2,
      "x": 379,
      "y": 661
    },
    {
      "t": 72004,
      "e": 48739,
      "ty": 2,
      "x": 379,
      "y": 662
    },
    {
      "t": 72004,
      "e": 48739,
      "ty": 41,
      "x": 22066,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 72103,
      "e": 48838,
      "ty": 2,
      "x": 379,
      "y": 669
    },
    {
      "t": 72204,
      "e": 48939,
      "ty": 2,
      "x": 386,
      "y": 674
    },
    {
      "t": 72253,
      "e": 48988,
      "ty": 41,
      "x": 25889,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 73086,
      "e": 49821,
      "ty": 3,
      "x": 386,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 73087,
      "e": 49822,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The diagonal line that goes through M and L indicate that those two shifts start at 12pm."
    },
    {
      "t": 73089,
      "e": 49824,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73089,
      "e": 49824,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 73164,
      "e": 49899,
      "ty": 4,
      "x": 25889,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 73175,
      "e": 49910,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 73177,
      "e": 49912,
      "ty": 5,
      "x": 386,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 73185,
      "e": 49920,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 74183,
      "e": 50918,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 74903,
      "e": 51638,
      "ty": 2,
      "x": 388,
      "y": 674
    },
    {
      "t": 75004,
      "e": 51739,
      "ty": 2,
      "x": 610,
      "y": 612
    },
    {
      "t": 75004,
      "e": 51739,
      "ty": 41,
      "x": 20731,
      "y": 33459,
      "ta": "html > body"
    },
    {
      "t": 75104,
      "e": 51739,
      "ty": 2,
      "x": 789,
      "y": 578
    },
    {
      "t": 75109,
      "e": 51744,
      "ty": 6,
      "x": 814,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75203,
      "e": 51838,
      "ty": 2,
      "x": 820,
      "y": 570
    },
    {
      "t": 75253,
      "e": 51888,
      "ty": 41,
      "x": 4542,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75304,
      "e": 51939,
      "ty": 2,
      "x": 851,
      "y": 570
    },
    {
      "t": 75390,
      "e": 52025,
      "ty": 3,
      "x": 868,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75390,
      "e": 52025,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75404,
      "e": 52039,
      "ty": 2,
      "x": 868,
      "y": 570
    },
    {
      "t": 75493,
      "e": 52128,
      "ty": 4,
      "x": 13193,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75494,
      "e": 52129,
      "ty": 5,
      "x": 869,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75504,
      "e": 52139,
      "ty": 2,
      "x": 869,
      "y": 570
    },
    {
      "t": 75504,
      "e": 52139,
      "ty": 41,
      "x": 13193,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77392,
      "e": 54027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 77393,
      "e": 54028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77504,
      "e": 54139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 77521,
      "e": 54156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 77521,
      "e": 54156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77601,
      "e": 54236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 78197,
      "e": 54832,
      "ty": 7,
      "x": 869,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78203,
      "e": 54838,
      "ty": 2,
      "x": 869,
      "y": 582
    },
    {
      "t": 78254,
      "e": 54889,
      "ty": 41,
      "x": 14707,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78262,
      "e": 54897,
      "ty": 6,
      "x": 878,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78303,
      "e": 54938,
      "ty": 2,
      "x": 882,
      "y": 663
    },
    {
      "t": 78404,
      "e": 55039,
      "ty": 2,
      "x": 883,
      "y": 665
    },
    {
      "t": 78504,
      "e": 55139,
      "ty": 41,
      "x": 16221,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78524,
      "e": 55159,
      "ty": 3,
      "x": 883,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78525,
      "e": 55160,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 78526,
      "e": 55161,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78526,
      "e": 55161,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78653,
      "e": 55288,
      "ty": 4,
      "x": 16221,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78654,
      "e": 55289,
      "ty": 5,
      "x": 883,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79658,
      "e": 56293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79721,
      "e": 56356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 79722,
      "e": 56357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79832,
      "e": 56467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 79849,
      "e": 56484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 79905,
      "e": 56540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 79905,
      "e": 56540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80009,
      "e": 56644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 80009,
      "e": 56644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80057,
      "e": 56692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 80089,
      "e": 56724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 80089,
      "e": 56724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80120,
      "e": 56755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 80161,
      "e": 56796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 80161,
      "e": 56796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80209,
      "e": 56844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 80289,
      "e": 56924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 80401,
      "e": 57036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 80402,
      "e": 57037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80480,
      "e": 57115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 80512,
      "e": 57147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 80512,
      "e": 57147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80561,
      "e": 57196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80609,
      "e": 57244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 80673,
      "e": 57308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 80674,
      "e": 57309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80777,
      "e": 57412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 80833,
      "e": 57468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 80954,
      "e": 57589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 80954,
      "e": 57589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81040,
      "e": 57675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 81040,
      "e": 57675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81048,
      "e": 57683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 81145,
      "e": 57780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81145,
      "e": 57780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81177,
      "e": 57812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 81209,
      "e": 57844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 81210,
      "e": 57845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81265,
      "e": 57900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 81321,
      "e": 57956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 81321,
      "e": 57956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81369,
      "e": 58004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 81449,
      "e": 58084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82004,
      "e": 58639,
      "ty": 2,
      "x": 886,
      "y": 667
    },
    {
      "t": 82005,
      "e": 58640,
      "ty": 41,
      "x": 16870,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82016,
      "e": 58651,
      "ty": 7,
      "x": 886,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82104,
      "e": 58739,
      "ty": 2,
      "x": 894,
      "y": 673
    },
    {
      "t": 82166,
      "e": 58801,
      "ty": 6,
      "x": 919,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82204,
      "e": 58839,
      "ty": 2,
      "x": 934,
      "y": 685
    },
    {
      "t": 82254,
      "e": 58889,
      "ty": 41,
      "x": 20140,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82304,
      "e": 58939,
      "ty": 2,
      "x": 935,
      "y": 685
    },
    {
      "t": 82366,
      "e": 59001,
      "ty": 3,
      "x": 935,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82366,
      "e": 59001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 82367,
      "e": 59002,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82367,
      "e": 59002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82468,
      "e": 59103,
      "ty": 4,
      "x": 20140,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82469,
      "e": 59104,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82470,
      "e": 59105,
      "ty": 5,
      "x": 935,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82470,
      "e": 59105,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 83488,
      "e": 60123,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 84403,
      "e": 61038,
      "ty": 2,
      "x": 935,
      "y": 669
    },
    {
      "t": 84503,
      "e": 61138,
      "ty": 2,
      "x": 919,
      "y": 520
    },
    {
      "t": 84503,
      "e": 61138,
      "ty": 41,
      "x": 23157,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 84603,
      "e": 61238,
      "ty": 2,
      "x": 870,
      "y": 406
    },
    {
      "t": 84703,
      "e": 61338,
      "ty": 2,
      "x": 844,
      "y": 294
    },
    {
      "t": 84753,
      "e": 61388,
      "ty": 41,
      "x": 15672,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 84803,
      "e": 61438,
      "ty": 2,
      "x": 843,
      "y": 251
    },
    {
      "t": 84903,
      "e": 61538,
      "ty": 2,
      "x": 850,
      "y": 246
    },
    {
      "t": 85004,
      "e": 61538,
      "ty": 41,
      "x": 23401,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85203,
      "e": 61737,
      "ty": 2,
      "x": 856,
      "y": 243
    },
    {
      "t": 85253,
      "e": 61787,
      "ty": 41,
      "x": 28314,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85293,
      "e": 61827,
      "ty": 3,
      "x": 856,
      "y": 243,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85430,
      "e": 61964,
      "ty": 4,
      "x": 28314,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85430,
      "e": 61964,
      "ty": 5,
      "x": 856,
      "y": 243,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85431,
      "e": 61965,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 85435,
      "e": 61969,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 85603,
      "e": 62137,
      "ty": 2,
      "x": 857,
      "y": 243
    },
    {
      "t": 85703,
      "e": 62237,
      "ty": 2,
      "x": 857,
      "y": 261
    },
    {
      "t": 85753,
      "e": 62287,
      "ty": 41,
      "x": 8680,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 85803,
      "e": 62337,
      "ty": 2,
      "x": 859,
      "y": 291
    },
    {
      "t": 85903,
      "e": 62437,
      "ty": 2,
      "x": 863,
      "y": 303
    },
    {
      "t": 86003,
      "e": 62537,
      "ty": 2,
      "x": 865,
      "y": 326
    },
    {
      "t": 86003,
      "e": 62537,
      "ty": 41,
      "x": 43260,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86103,
      "e": 62637,
      "ty": 2,
      "x": 848,
      "y": 404
    },
    {
      "t": 86203,
      "e": 62737,
      "ty": 2,
      "x": 842,
      "y": 425
    },
    {
      "t": 86253,
      "e": 62787,
      "ty": 41,
      "x": 4646,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 86303,
      "e": 62837,
      "ty": 2,
      "x": 841,
      "y": 429
    },
    {
      "t": 86503,
      "e": 63037,
      "ty": 2,
      "x": 844,
      "y": 422
    },
    {
      "t": 86503,
      "e": 63037,
      "ty": 41,
      "x": 26429,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 86603,
      "e": 63137,
      "ty": 2,
      "x": 845,
      "y": 419
    },
    {
      "t": 86638,
      "e": 63172,
      "ty": 3,
      "x": 845,
      "y": 419,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 86639,
      "e": 63173,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 86749,
      "e": 63283,
      "ty": 4,
      "x": 27600,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 86750,
      "e": 63284,
      "ty": 5,
      "x": 845,
      "y": 419,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 86751,
      "e": 63285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86753,
      "e": 63287,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 86754,
      "e": 63288,
      "ty": 41,
      "x": 27600,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 87004,
      "e": 63538,
      "ty": 2,
      "x": 857,
      "y": 463
    },
    {
      "t": 87004,
      "e": 63538,
      "ty": 41,
      "x": 37606,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 87104,
      "e": 63638,
      "ty": 2,
      "x": 888,
      "y": 554
    },
    {
      "t": 87203,
      "e": 63737,
      "ty": 2,
      "x": 893,
      "y": 596
    },
    {
      "t": 87254,
      "e": 63788,
      "ty": 41,
      "x": 17224,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 87304,
      "e": 63838,
      "ty": 2,
      "x": 891,
      "y": 648
    },
    {
      "t": 87403,
      "e": 63937,
      "ty": 2,
      "x": 889,
      "y": 649
    },
    {
      "t": 87503,
      "e": 64037,
      "ty": 41,
      "x": 16037,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 88203,
      "e": 64737,
      "ty": 2,
      "x": 886,
      "y": 651
    },
    {
      "t": 88253,
      "e": 64787,
      "ty": 41,
      "x": 14376,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 88303,
      "e": 64837,
      "ty": 2,
      "x": 882,
      "y": 655
    },
    {
      "t": 88403,
      "e": 64937,
      "ty": 2,
      "x": 880,
      "y": 657
    },
    {
      "t": 88506,
      "e": 65040,
      "ty": 2,
      "x": 880,
      "y": 660
    },
    {
      "t": 88506,
      "e": 65040,
      "ty": 41,
      "x": 13902,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 88607,
      "e": 65141,
      "ty": 2,
      "x": 879,
      "y": 663
    },
    {
      "t": 88707,
      "e": 65241,
      "ty": 2,
      "x": 878,
      "y": 667
    },
    {
      "t": 88757,
      "e": 65242,
      "ty": 41,
      "x": 15191,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 88807,
      "e": 65292,
      "ty": 2,
      "x": 879,
      "y": 669
    },
    {
      "t": 88824,
      "e": 65309,
      "ty": 3,
      "x": 880,
      "y": 670,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 88825,
      "e": 65310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 88904,
      "e": 65389,
      "ty": 4,
      "x": 15728,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 88904,
      "e": 65389,
      "ty": 5,
      "x": 880,
      "y": 670,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 88904,
      "e": 65389,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 88905,
      "e": 65390,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 88906,
      "e": 65391,
      "ty": 2,
      "x": 880,
      "y": 670
    },
    {
      "t": 89007,
      "e": 65492,
      "ty": 2,
      "x": 882,
      "y": 670
    },
    {
      "t": 89007,
      "e": 65492,
      "ty": 41,
      "x": 16265,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 89106,
      "e": 65591,
      "ty": 2,
      "x": 882,
      "y": 673
    },
    {
      "t": 89256,
      "e": 65741,
      "ty": 41,
      "x": 16265,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 89907,
      "e": 66392,
      "ty": 2,
      "x": 884,
      "y": 694
    },
    {
      "t": 90007,
      "e": 66492,
      "ty": 2,
      "x": 903,
      "y": 764
    },
    {
      "t": 90007,
      "e": 66492,
      "ty": 41,
      "x": 34038,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 90106,
      "e": 66591,
      "ty": 2,
      "x": 915,
      "y": 804
    },
    {
      "t": 90257,
      "e": 66742,
      "ty": 41,
      "x": 51268,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 90306,
      "e": 66791,
      "ty": 2,
      "x": 911,
      "y": 789
    },
    {
      "t": 90507,
      "e": 66992,
      "ty": 41,
      "x": 50148,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 90607,
      "e": 67092,
      "ty": 2,
      "x": 911,
      "y": 768
    },
    {
      "t": 90756,
      "e": 67241,
      "ty": 41,
      "x": 37376,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 91207,
      "e": 67692,
      "ty": 2,
      "x": 911,
      "y": 767
    },
    {
      "t": 91257,
      "e": 67742,
      "ty": 41,
      "x": 37376,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 92107,
      "e": 68592,
      "ty": 2,
      "x": 967,
      "y": 776
    },
    {
      "t": 92206,
      "e": 68691,
      "ty": 2,
      "x": 976,
      "y": 777
    },
    {
      "t": 92257,
      "e": 68742,
      "ty": 41,
      "x": 35498,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 92306,
      "e": 68791,
      "ty": 2,
      "x": 963,
      "y": 783
    },
    {
      "t": 92407,
      "e": 68892,
      "ty": 2,
      "x": 938,
      "y": 787
    },
    {
      "t": 92506,
      "e": 68991,
      "ty": 2,
      "x": 918,
      "y": 789
    },
    {
      "t": 92506,
      "e": 68991,
      "ty": 41,
      "x": 54067,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 92606,
      "e": 69091,
      "ty": 2,
      "x": 917,
      "y": 789
    },
    {
      "t": 92706,
      "e": 69191,
      "ty": 2,
      "x": 916,
      "y": 789
    },
    {
      "t": 92757,
      "e": 69242,
      "ty": 41,
      "x": 52947,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 93006,
      "e": 69491,
      "ty": 2,
      "x": 914,
      "y": 789
    },
    {
      "t": 93006,
      "e": 69491,
      "ty": 41,
      "x": 51827,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 93106,
      "e": 69591,
      "ty": 2,
      "x": 913,
      "y": 789
    },
    {
      "t": 93257,
      "e": 69742,
      "ty": 41,
      "x": 51268,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 93407,
      "e": 69892,
      "ty": 2,
      "x": 911,
      "y": 789
    },
    {
      "t": 93507,
      "e": 69992,
      "ty": 2,
      "x": 910,
      "y": 787
    },
    {
      "t": 93507,
      "e": 69992,
      "ty": 41,
      "x": 49588,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 95159,
      "e": 71644,
      "ty": 3,
      "x": 910,
      "y": 787,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 95160,
      "e": 71645,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 95231,
      "e": 71716,
      "ty": 4,
      "x": 49588,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 95231,
      "e": 71716,
      "ty": 5,
      "x": 910,
      "y": 787,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 95232,
      "e": 71717,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 95233,
      "e": 71718,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 95507,
      "e": 71992,
      "ty": 2,
      "x": 916,
      "y": 807
    },
    {
      "t": 95507,
      "e": 71992,
      "ty": 41,
      "x": 55823,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 95607,
      "e": 72092,
      "ty": 2,
      "x": 917,
      "y": 812
    },
    {
      "t": 95757,
      "e": 72242,
      "ty": 41,
      "x": 56413,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 96207,
      "e": 72692,
      "ty": 2,
      "x": 918,
      "y": 816
    },
    {
      "t": 96257,
      "e": 72742,
      "ty": 41,
      "x": 23157,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 96307,
      "e": 72792,
      "ty": 2,
      "x": 905,
      "y": 868
    },
    {
      "t": 96407,
      "e": 72892,
      "ty": 2,
      "x": 850,
      "y": 990
    },
    {
      "t": 96414,
      "e": 72893,
      "ty": 6,
      "x": 842,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 96446,
      "e": 72925,
      "ty": 7,
      "x": 826,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 96507,
      "e": 72986,
      "ty": 2,
      "x": 820,
      "y": 1014
    },
    {
      "t": 96507,
      "e": 72986,
      "ty": 41,
      "x": 27963,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 96546,
      "e": 73025,
      "ty": 6,
      "x": 827,
      "y": 994,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 96580,
      "e": 73059,
      "ty": 7,
      "x": 835,
      "y": 977,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 96607,
      "e": 73086,
      "ty": 2,
      "x": 836,
      "y": 973
    },
    {
      "t": 96707,
      "e": 73186,
      "ty": 2,
      "x": 863,
      "y": 929
    },
    {
      "t": 96757,
      "e": 73236,
      "ty": 41,
      "x": 45413,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 96882,
      "e": 73361,
      "ty": 3,
      "x": 863,
      "y": 929,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 96882,
      "e": 73361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 96984,
      "e": 73463,
      "ty": 4,
      "x": 45413,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 96984,
      "e": 73463,
      "ty": 5,
      "x": 863,
      "y": 929,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 96984,
      "e": 73463,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 96985,
      "e": 73464,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 97106,
      "e": 73585,
      "ty": 2,
      "x": 899,
      "y": 997
    },
    {
      "t": 97131,
      "e": 73610,
      "ty": 6,
      "x": 907,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97207,
      "e": 73686,
      "ty": 2,
      "x": 908,
      "y": 1014
    },
    {
      "t": 97257,
      "e": 73736,
      "ty": 41,
      "x": 40498,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97337,
      "e": 73816,
      "ty": 3,
      "x": 908,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97338,
      "e": 73817,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 97339,
      "e": 73818,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97416,
      "e": 73895,
      "ty": 4,
      "x": 40498,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97416,
      "e": 73895,
      "ty": 5,
      "x": 908,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97418,
      "e": 73897,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 97419,
      "e": 73898,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 97420,
      "e": 73899,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 97507,
      "e": 73986,
      "ty": 2,
      "x": 911,
      "y": 1015
    },
    {
      "t": 97507,
      "e": 73986,
      "ty": 41,
      "x": 31097,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 97706,
      "e": 74185,
      "ty": 2,
      "x": 887,
      "y": 946
    },
    {
      "t": 97757,
      "e": 74236,
      "ty": 41,
      "x": 29582,
      "y": 48694,
      "ta": "html > body"
    },
    {
      "t": 97806,
      "e": 74285,
      "ty": 2,
      "x": 818,
      "y": 833
    },
    {
      "t": 97907,
      "e": 74386,
      "ty": 2,
      "x": 747,
      "y": 796
    },
    {
      "t": 98007,
      "e": 74486,
      "ty": 41,
      "x": 25449,
      "y": 43653,
      "ta": "html > body"
    },
    {
      "t": 98507,
      "e": 74986,
      "ty": 2,
      "x": 746,
      "y": 795
    },
    {
      "t": 98507,
      "e": 74986,
      "ty": 41,
      "x": 25415,
      "y": 43597,
      "ta": "html > body"
    },
    {
      "t": 98756,
      "e": 75235,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 98906,
      "e": 75385,
      "ty": 2,
      "x": 745,
      "y": 795
    },
    {
      "t": 99007,
      "e": 75486,
      "ty": 41,
      "x": 22214,
      "y": 53321,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 99257,
      "e": 75736,
      "ty": 41,
      "x": 22755,
      "y": 9965,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 99307,
      "e": 75786,
      "ty": 2,
      "x": 843,
      "y": 869
    },
    {
      "t": 99407,
      "e": 75886,
      "ty": 2,
      "x": 962,
      "y": 958
    },
    {
      "t": 99507,
      "e": 75986,
      "ty": 2,
      "x": 994,
      "y": 1050
    },
    {
      "t": 99507,
      "e": 75986,
      "ty": 41,
      "x": 34464,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 99607,
      "e": 76086,
      "ty": 2,
      "x": 989,
      "y": 1069
    },
    {
      "t": 99617,
      "e": 76096,
      "ty": 6,
      "x": 986,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 99707,
      "e": 76186,
      "ty": 2,
      "x": 978,
      "y": 1081
    },
    {
      "t": 99757,
      "e": 76236,
      "ty": 41,
      "x": 36863,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 99806,
      "e": 76285,
      "ty": 2,
      "x": 973,
      "y": 1086
    },
    {
      "t": 99907,
      "e": 76386,
      "ty": 2,
      "x": 967,
      "y": 1091
    },
    {
      "t": 100007,
      "e": 76486,
      "ty": 2,
      "x": 966,
      "y": 1091
    },
    {
      "t": 100007,
      "e": 76486,
      "ty": 41,
      "x": 30856,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 100107,
      "e": 76586,
      "ty": 2,
      "x": 963,
      "y": 1091
    },
    {
      "t": 100207,
      "e": 76686,
      "ty": 2,
      "x": 962,
      "y": 1090
    },
    {
      "t": 100257,
      "e": 76736,
      "ty": 41,
      "x": 28125,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 100307,
      "e": 76786,
      "ty": 2,
      "x": 961,
      "y": 1089
    },
    {
      "t": 100507,
      "e": 76986,
      "ty": 2,
      "x": 960,
      "y": 1089
    },
    {
      "t": 100508,
      "e": 76987,
      "ty": 41,
      "x": 27579,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 100593,
      "e": 77072,
      "ty": 3,
      "x": 960,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 100594,
      "e": 77073,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100800,
      "e": 77279,
      "ty": 4,
      "x": 27579,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 100801,
      "e": 77280,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100802,
      "e": 77281,
      "ty": 5,
      "x": 960,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 100802,
      "e": 77281,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 101257,
      "e": 77736,
      "ty": 41,
      "x": 32784,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 101307,
      "e": 77786,
      "ty": 2,
      "x": 959,
      "y": 1088
    },
    {
      "t": 101407,
      "e": 77886,
      "ty": 2,
      "x": 954,
      "y": 1082
    },
    {
      "t": 101507,
      "e": 77986,
      "ty": 41,
      "x": 32578,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 101607,
      "e": 78086,
      "ty": 2,
      "x": 953,
      "y": 1081
    },
    {
      "t": 101757,
      "e": 78236,
      "ty": 41,
      "x": 32543,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 101838,
      "e": 78317,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 102703,
      "e": 79182,
      "ty": 2,
      "x": 951,
      "y": 1071
    },
    {
      "t": 102703,
      "e": 79182,
      "ty": 41,
      "x": 32354,
      "y": 32864,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 102766,
      "e": 79245,
      "ty": 2,
      "x": 951,
      "y": 1067
    },
    {
      "t": 102767,
      "e": 79246,
      "ty": 41,
      "x": 32354,
      "y": 32864,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 102807,
      "e": 79286,
      "ty": 2,
      "x": 952,
      "y": 1066
    },
    {
      "t": 102907,
      "e": 79386,
      "ty": 2,
      "x": 953,
      "y": 1064
    },
    {
      "t": 103007,
      "e": 79486,
      "ty": 2,
      "x": 957,
      "y": 1062
    },
    {
      "t": 103007,
      "e": 79486,
      "ty": 41,
      "x": 32646,
      "y": 32863,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 103107,
      "e": 79586,
      "ty": 2,
      "x": 959,
      "y": 1058
    },
    {
      "t": 103207,
      "e": 79686,
      "ty": 2,
      "x": 960,
      "y": 1057
    },
    {
      "t": 103258,
      "e": 79737,
      "ty": 41,
      "x": 32792,
      "y": 32862,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 103390,
      "e": 79869,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 440969, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 440975, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11123, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 453443, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7520, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"yankee\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 461970, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 23566, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 486628, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 18844, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 506474, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 70003, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 577842, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -A -A -A -A -A -A -A -A -A -A -C -C -Z -Z -O -H -K -K -Z -Z -Z -Z -K -K -K -E -E -E -F -10 AM-11 AM-C -C -C -F -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1100,y:899,t:1528139571912};\\\", \\\"{x:1100,y:890,t:1528139571925};\\\", \\\"{x:1101,y:876,t:1528139571941};\\\", \\\"{x:1101,y:860,t:1528139571958};\\\", \\\"{x:1099,y:846,t:1528139571975};\\\", \\\"{x:1099,y:838,t:1528139571992};\\\", \\\"{x:1096,y:824,t:1528139572009};\\\", \\\"{x:1095,y:810,t:1528139572025};\\\", \\\"{x:1091,y:798,t:1528139572042};\\\", \\\"{x:1087,y:786,t:1528139572058};\\\", \\\"{x:1084,y:767,t:1528139572076};\\\", \\\"{x:1080,y:751,t:1528139572091};\\\", \\\"{x:1077,y:738,t:1528139572108};\\\", \\\"{x:1074,y:720,t:1528139572125};\\\", \\\"{x:1071,y:702,t:1528139572141};\\\", \\\"{x:1070,y:684,t:1528139572158};\\\", \\\"{x:1066,y:662,t:1528139572175};\\\", \\\"{x:1065,y:641,t:1528139572191};\\\", \\\"{x:1060,y:611,t:1528139572208};\\\", \\\"{x:1055,y:591,t:1528139572225};\\\", \\\"{x:1046,y:561,t:1528139572241};\\\", \\\"{x:1017,y:521,t:1528139572259};\\\", \\\"{x:965,y:476,t:1528139572275};\\\", \\\"{x:912,y:418,t:1528139572291};\\\", \\\"{x:861,y:357,t:1528139572308};\\\", \\\"{x:836,y:339,t:1528139572325};\\\", \\\"{x:837,y:340,t:1528139574536};\\\", \\\"{x:840,y:345,t:1528139574544};\\\", \\\"{x:843,y:350,t:1528139574560};\\\", \\\"{x:857,y:374,t:1528139574576};\\\", \\\"{x:872,y:394,t:1528139574594};\\\", \\\"{x:913,y:445,t:1528139574610};\\\", \\\"{x:956,y:497,t:1528139574626};\\\", \\\"{x:1003,y:557,t:1528139574644};\\\", \\\"{x:1049,y:631,t:1528139574661};\\\", \\\"{x:1113,y:716,t:1528139574676};\\\", \\\"{x:1172,y:770,t:1528139574693};\\\", \\\"{x:1210,y:817,t:1528139574710};\\\", \\\"{x:1235,y:841,t:1528139574726};\\\", \\\"{x:1246,y:858,t:1528139574743};\\\", \\\"{x:1252,y:865,t:1528139574760};\\\", \\\"{x:1256,y:870,t:1528139574776};\\\", \\\"{x:1268,y:876,t:1528139574794};\\\", \\\"{x:1281,y:882,t:1528139574810};\\\", \\\"{x:1284,y:883,t:1528139574827};\\\", \\\"{x:1284,y:882,t:1528139574953};\\\", \\\"{x:1284,y:880,t:1528139574961};\\\", \\\"{x:1282,y:878,t:1528139574978};\\\", \\\"{x:1277,y:875,t:1528139574994};\\\", \\\"{x:1275,y:872,t:1528139575010};\\\", \\\"{x:1271,y:867,t:1528139575027};\\\", \\\"{x:1268,y:864,t:1528139575043};\\\", \\\"{x:1267,y:862,t:1528139575061};\\\", \\\"{x:1265,y:859,t:1528139575078};\\\", \\\"{x:1264,y:858,t:1528139575096};\\\", \\\"{x:1264,y:857,t:1528139575120};\\\", \\\"{x:1264,y:856,t:1528139575129};\\\", \\\"{x:1264,y:855,t:1528139575144};\\\", \\\"{x:1264,y:854,t:1528139575161};\\\", \\\"{x:1267,y:851,t:1528139575178};\\\", \\\"{x:1271,y:848,t:1528139575194};\\\", \\\"{x:1275,y:845,t:1528139575211};\\\", \\\"{x:1281,y:841,t:1528139575228};\\\", \\\"{x:1283,y:840,t:1528139575249};\\\", \\\"{x:1284,y:839,t:1528139575261};\\\", \\\"{x:1285,y:838,t:1528139575278};\\\", \\\"{x:1285,y:837,t:1528139575304};\\\", \\\"{x:1286,y:837,t:1528139575321};\\\", \\\"{x:1286,y:835,t:1528139575337};\\\", \\\"{x:1286,y:834,t:1528139575376};\\\", \\\"{x:1286,y:832,t:1528139575403};\\\", \\\"{x:1286,y:828,t:1528139575444};\\\", \\\"{x:1286,y:827,t:1528139575536};\\\", \\\"{x:1286,y:826,t:1528139575553};\\\", \\\"{x:1285,y:826,t:1528139575569};\\\", \\\"{x:1285,y:825,t:1528139575595};\\\", \\\"{x:1283,y:824,t:1528139575611};\\\", \\\"{x:1282,y:824,t:1528139575628};\\\", \\\"{x:1281,y:823,t:1528139575664};\\\", \\\"{x:1280,y:823,t:1528139575696};\\\", \\\"{x:1280,y:824,t:1528139575937};\\\", \\\"{x:1280,y:825,t:1528139575947};\\\", \\\"{x:1279,y:828,t:1528139575962};\\\", \\\"{x:1278,y:830,t:1528139575978};\\\", \\\"{x:1278,y:832,t:1528139575994};\\\", \\\"{x:1278,y:833,t:1528139576015};\\\", \\\"{x:1278,y:834,t:1528139576055};\\\", \\\"{x:1276,y:835,t:1528139577169};\\\", \\\"{x:1276,y:836,t:1528139577289};\\\", \\\"{x:1276,y:837,t:1528139577497};\\\", \\\"{x:1276,y:838,t:1528139577513};\\\", \\\"{x:1275,y:838,t:1528139577585};\\\", \\\"{x:1275,y:839,t:1528139578233};\\\", \\\"{x:1274,y:839,t:1528139578465};\\\", \\\"{x:1273,y:841,t:1528139578481};\\\", \\\"{x:1271,y:842,t:1528139578529};\\\", \\\"{x:1270,y:842,t:1528139578569};\\\", \\\"{x:1269,y:842,t:1528139578601};\\\", \\\"{x:1267,y:842,t:1528139578650};\\\", \\\"{x:1265,y:843,t:1528139578833};\\\", \\\"{x:1264,y:844,t:1528139578848};\\\", \\\"{x:1263,y:845,t:1528139578864};\\\", \\\"{x:1263,y:846,t:1528139578881};\\\", \\\"{x:1262,y:846,t:1528139578898};\\\", \\\"{x:1261,y:846,t:1528139578915};\\\", \\\"{x:1260,y:846,t:1528139578931};\\\", \\\"{x:1259,y:847,t:1528139579001};\\\", \\\"{x:1258,y:847,t:1528139579017};\\\", \\\"{x:1257,y:848,t:1528139579033};\\\", \\\"{x:1256,y:848,t:1528139579057};\\\", \\\"{x:1255,y:848,t:1528139579065};\\\", \\\"{x:1254,y:848,t:1528139579081};\\\", \\\"{x:1253,y:849,t:1528139579098};\\\", \\\"{x:1252,y:849,t:1528139579120};\\\", \\\"{x:1251,y:849,t:1528139579131};\\\", \\\"{x:1250,y:850,t:1528139579148};\\\", \\\"{x:1249,y:850,t:1528139579165};\\\", \\\"{x:1248,y:851,t:1528139579182};\\\", \\\"{x:1246,y:852,t:1528139579198};\\\", \\\"{x:1245,y:852,t:1528139579215};\\\", \\\"{x:1244,y:852,t:1528139579232};\\\", \\\"{x:1241,y:853,t:1528139579249};\\\", \\\"{x:1240,y:853,t:1528139579264};\\\", \\\"{x:1238,y:854,t:1528139579282};\\\", \\\"{x:1236,y:854,t:1528139579299};\\\", \\\"{x:1235,y:855,t:1528139579316};\\\", \\\"{x:1234,y:855,t:1528139579392};\\\", \\\"{x:1233,y:855,t:1528139579407};\\\", \\\"{x:1232,y:855,t:1528139579416};\\\", \\\"{x:1231,y:857,t:1528139579432};\\\", \\\"{x:1230,y:857,t:1528139579447};\\\", \\\"{x:1229,y:857,t:1528139579464};\\\", \\\"{x:1227,y:857,t:1528139579496};\\\", \\\"{x:1227,y:858,t:1528139579520};\\\", \\\"{x:1225,y:858,t:1528139579536};\\\", \\\"{x:1224,y:858,t:1528139579548};\\\", \\\"{x:1223,y:858,t:1528139579565};\\\", \\\"{x:1222,y:860,t:1528139579582};\\\", \\\"{x:1220,y:860,t:1528139579599};\\\", \\\"{x:1219,y:860,t:1528139579615};\\\", \\\"{x:1217,y:861,t:1528139579633};\\\", \\\"{x:1215,y:862,t:1528139579657};\\\", \\\"{x:1214,y:863,t:1528139579674};\\\", \\\"{x:1213,y:863,t:1528139579682};\\\", \\\"{x:1212,y:863,t:1528139579703};\\\", \\\"{x:1211,y:864,t:1528139579714};\\\", \\\"{x:1210,y:864,t:1528139579731};\\\", \\\"{x:1208,y:865,t:1528139579748};\\\", \\\"{x:1207,y:866,t:1528139579764};\\\", \\\"{x:1206,y:866,t:1528139579781};\\\", \\\"{x:1205,y:867,t:1528139579799};\\\", \\\"{x:1204,y:867,t:1528139579816};\\\", \\\"{x:1203,y:868,t:1528139579831};\\\", \\\"{x:1201,y:869,t:1528139579857};\\\", \\\"{x:1200,y:869,t:1528139579872};\\\", \\\"{x:1200,y:870,t:1528139579882};\\\", \\\"{x:1198,y:870,t:1528139579899};\\\", \\\"{x:1195,y:871,t:1528139579915};\\\", \\\"{x:1194,y:871,t:1528139579933};\\\", \\\"{x:1191,y:871,t:1528139579949};\\\", \\\"{x:1189,y:873,t:1528139579965};\\\", \\\"{x:1188,y:873,t:1528139579982};\\\", \\\"{x:1187,y:873,t:1528139579999};\\\", \\\"{x:1186,y:873,t:1528139580025};\\\", \\\"{x:1185,y:873,t:1528139580097};\\\", \\\"{x:1184,y:874,t:1528139580201};\\\", \\\"{x:1182,y:874,t:1528139580265};\\\", \\\"{x:1181,y:874,t:1528139580401};\\\", \\\"{x:1181,y:876,t:1528139580857};\\\", \\\"{x:1182,y:876,t:1528139580897};\\\", \\\"{x:1185,y:876,t:1528139580913};\\\", \\\"{x:1186,y:877,t:1528139580920};\\\", \\\"{x:1189,y:877,t:1528139580933};\\\", \\\"{x:1190,y:881,t:1528139580950};\\\", \\\"{x:1194,y:882,t:1528139580966};\\\", \\\"{x:1196,y:882,t:1528139580983};\\\", \\\"{x:1197,y:882,t:1528139581089};\\\", \\\"{x:1198,y:882,t:1528139581313};\\\", \\\"{x:1199,y:882,t:1528139581321};\\\", \\\"{x:1200,y:882,t:1528139581333};\\\", \\\"{x:1201,y:882,t:1528139581350};\\\", \\\"{x:1202,y:882,t:1528139581369};\\\", \\\"{x:1204,y:881,t:1528139581383};\\\", \\\"{x:1206,y:880,t:1528139581400};\\\", \\\"{x:1209,y:879,t:1528139581416};\\\", \\\"{x:1212,y:878,t:1528139581433};\\\", \\\"{x:1213,y:877,t:1528139581480};\\\", \\\"{x:1214,y:876,t:1528139581569};\\\", \\\"{x:1215,y:876,t:1528139581641};\\\", \\\"{x:1218,y:876,t:1528139581651};\\\", \\\"{x:1223,y:878,t:1528139581667};\\\", \\\"{x:1228,y:880,t:1528139581684};\\\", \\\"{x:1234,y:882,t:1528139581700};\\\", \\\"{x:1239,y:885,t:1528139581717};\\\", \\\"{x:1243,y:888,t:1528139581735};\\\", \\\"{x:1244,y:888,t:1528139581750};\\\", \\\"{x:1245,y:888,t:1528139581777};\\\", \\\"{x:1246,y:889,t:1528139581842};\\\", \\\"{x:1247,y:889,t:1528139581881};\\\", \\\"{x:1247,y:890,t:1528139581897};\\\", \\\"{x:1248,y:891,t:1528139581921};\\\", \\\"{x:1249,y:891,t:1528139581978};\\\", \\\"{x:1251,y:891,t:1528139581993};\\\", \\\"{x:1252,y:891,t:1528139582017};\\\", \\\"{x:1257,y:891,t:1528139582034};\\\", \\\"{x:1264,y:889,t:1528139582050};\\\", \\\"{x:1267,y:886,t:1528139582068};\\\", \\\"{x:1270,y:884,t:1528139582084};\\\", \\\"{x:1272,y:882,t:1528139582101};\\\", \\\"{x:1274,y:881,t:1528139582117};\\\", \\\"{x:1275,y:879,t:1528139582134};\\\", \\\"{x:1276,y:878,t:1528139582152};\\\", \\\"{x:1276,y:877,t:1528139582168};\\\", \\\"{x:1278,y:874,t:1528139582184};\\\", \\\"{x:1280,y:870,t:1528139582201};\\\", \\\"{x:1280,y:867,t:1528139582217};\\\", \\\"{x:1281,y:866,t:1528139582234};\\\", \\\"{x:1281,y:864,t:1528139582251};\\\", \\\"{x:1281,y:863,t:1528139582267};\\\", \\\"{x:1281,y:861,t:1528139582285};\\\", \\\"{x:1281,y:860,t:1528139582301};\\\", \\\"{x:1282,y:858,t:1528139582317};\\\", \\\"{x:1282,y:857,t:1528139582335};\\\", \\\"{x:1282,y:854,t:1528139582351};\\\", \\\"{x:1282,y:853,t:1528139582376};\\\", \\\"{x:1283,y:853,t:1528139582393};\\\", \\\"{x:1283,y:852,t:1528139582401};\\\", \\\"{x:1284,y:850,t:1528139582418};\\\", \\\"{x:1285,y:848,t:1528139582434};\\\", \\\"{x:1285,y:847,t:1528139582451};\\\", \\\"{x:1285,y:846,t:1528139582467};\\\", \\\"{x:1285,y:845,t:1528139582485};\\\", \\\"{x:1286,y:842,t:1528139582501};\\\", \\\"{x:1287,y:841,t:1528139582518};\\\", \\\"{x:1288,y:840,t:1528139582537};\\\", \\\"{x:1288,y:839,t:1528139582551};\\\", \\\"{x:1288,y:838,t:1528139582568};\\\", \\\"{x:1288,y:836,t:1528139582650};\\\", \\\"{x:1288,y:835,t:1528139582674};\\\", \\\"{x:1288,y:834,t:1528139582696};\\\", \\\"{x:1288,y:833,t:1528139582769};\\\", \\\"{x:1288,y:832,t:1528139582784};\\\", \\\"{x:1288,y:831,t:1528139582801};\\\", \\\"{x:1288,y:830,t:1528139582897};\\\", \\\"{x:1288,y:829,t:1528139582921};\\\", \\\"{x:1288,y:828,t:1528139582937};\\\", \\\"{x:1288,y:826,t:1528139582952};\\\", \\\"{x:1288,y:825,t:1528139582985};\\\", \\\"{x:1287,y:825,t:1528139583081};\\\", \\\"{x:1286,y:825,t:1528139583121};\\\", \\\"{x:1284,y:825,t:1528139583141};\\\", \\\"{x:1281,y:825,t:1528139583168};\\\", \\\"{x:1280,y:825,t:1528139583185};\\\", \\\"{x:1279,y:826,t:1528139583201};\\\", \\\"{x:1278,y:826,t:1528139583320};\\\", \\\"{x:1277,y:827,t:1528139583333};\\\", \\\"{x:1276,y:827,t:1528139584449};\\\", \\\"{x:1277,y:828,t:1528139588953};\\\", \\\"{x:1280,y:829,t:1528139588984};\\\", \\\"{x:1282,y:830,t:1528139589001};\\\", \\\"{x:1282,y:831,t:1528139591505};\\\", \\\"{x:1282,y:832,t:1528139591553};\\\", \\\"{x:1281,y:832,t:1528139593249};\\\", \\\"{x:1281,y:831,t:1528139593260};\\\", \\\"{x:1281,y:829,t:1528139593276};\\\", \\\"{x:1281,y:826,t:1528139593293};\\\", \\\"{x:1281,y:825,t:1528139593310};\\\", \\\"{x:1281,y:824,t:1528139593329};\\\", \\\"{x:1281,y:823,t:1528139593343};\\\", \\\"{x:1281,y:821,t:1528139593383};\\\", \\\"{x:1281,y:820,t:1528139593408};\\\", \\\"{x:1281,y:818,t:1528139593440};\\\", \\\"{x:1281,y:817,t:1528139593480};\\\", \\\"{x:1281,y:816,t:1528139593504};\\\", \\\"{x:1282,y:815,t:1528139593641};\\\", \\\"{x:1282,y:814,t:1528139593697};\\\", \\\"{x:1282,y:812,t:1528139593729};\\\", \\\"{x:1282,y:811,t:1528139593752};\\\", \\\"{x:1282,y:809,t:1528139593809};\\\", \\\"{x:1281,y:808,t:1528139594601};\\\", \\\"{x:1280,y:808,t:1528139594633};\\\", \\\"{x:1280,y:811,t:1528139594643};\\\", \\\"{x:1279,y:815,t:1528139594660};\\\", \\\"{x:1278,y:816,t:1528139594677};\\\", \\\"{x:1278,y:818,t:1528139594693};\\\", \\\"{x:1277,y:818,t:1528139594710};\\\", \\\"{x:1277,y:819,t:1528139594727};\\\", \\\"{x:1276,y:819,t:1528139594825};\\\", \\\"{x:1276,y:821,t:1528139594839};\\\", \\\"{x:1276,y:822,t:1528139594855};\\\", \\\"{x:1276,y:823,t:1528139594863};\\\", \\\"{x:1276,y:824,t:1528139594876};\\\", \\\"{x:1276,y:825,t:1528139594904};\\\", \\\"{x:1276,y:826,t:1528139594920};\\\", \\\"{x:1276,y:827,t:1528139594929};\\\", \\\"{x:1276,y:831,t:1528139594959};\\\", \\\"{x:1276,y:833,t:1528139594978};\\\", \\\"{x:1276,y:834,t:1528139594993};\\\", \\\"{x:1276,y:836,t:1528139595010};\\\", \\\"{x:1276,y:838,t:1528139595027};\\\", \\\"{x:1277,y:842,t:1528139595064};\\\", \\\"{x:1277,y:843,t:1528139595096};\\\", \\\"{x:1278,y:844,t:1528139595110};\\\", \\\"{x:1278,y:846,t:1528139595128};\\\", \\\"{x:1278,y:847,t:1528139595144};\\\", \\\"{x:1279,y:848,t:1528139595161};\\\", \\\"{x:1280,y:850,t:1528139595178};\\\", \\\"{x:1281,y:854,t:1528139595193};\\\", \\\"{x:1281,y:855,t:1528139595211};\\\", \\\"{x:1281,y:858,t:1528139595228};\\\", \\\"{x:1283,y:859,t:1528139595244};\\\", \\\"{x:1283,y:860,t:1528139595261};\\\", \\\"{x:1283,y:861,t:1528139595278};\\\", \\\"{x:1283,y:860,t:1528139595401};\\\", \\\"{x:1283,y:857,t:1528139595410};\\\", \\\"{x:1283,y:855,t:1528139595428};\\\", \\\"{x:1283,y:850,t:1528139595444};\\\", \\\"{x:1283,y:845,t:1528139595461};\\\", \\\"{x:1284,y:841,t:1528139595478};\\\", \\\"{x:1284,y:838,t:1528139595494};\\\", \\\"{x:1284,y:836,t:1528139595697};\\\", \\\"{x:1284,y:833,t:1528139595717};\\\", \\\"{x:1284,y:832,t:1528139595744};\\\", \\\"{x:1284,y:828,t:1528139595761};\\\", \\\"{x:1283,y:826,t:1528139595778};\\\", \\\"{x:1283,y:825,t:1528139595794};\\\", \\\"{x:1282,y:824,t:1528139595811};\\\", \\\"{x:1282,y:822,t:1528139595831};\\\", \\\"{x:1280,y:822,t:1528139596153};\\\", \\\"{x:1279,y:823,t:1528139596169};\\\", \\\"{x:1279,y:824,t:1528139596178};\\\", \\\"{x:1279,y:825,t:1528139596199};\\\", \\\"{x:1279,y:827,t:1528139596211};\\\", \\\"{x:1279,y:828,t:1528139596228};\\\", \\\"{x:1277,y:829,t:1528139600579};\\\", \\\"{x:1266,y:832,t:1528139600603};\\\", \\\"{x:1255,y:832,t:1528139600619};\\\", \\\"{x:1249,y:832,t:1528139600632};\\\", \\\"{x:1227,y:832,t:1528139600650};\\\", \\\"{x:1217,y:832,t:1528139600667};\\\", \\\"{x:1213,y:831,t:1528139600683};\\\", \\\"{x:1208,y:831,t:1528139600701};\\\", \\\"{x:1206,y:831,t:1528139600717};\\\", \\\"{x:1203,y:831,t:1528139600734};\\\", \\\"{x:1202,y:831,t:1528139600750};\\\", \\\"{x:1202,y:830,t:1528139600866};\\\", \\\"{x:1204,y:828,t:1528139600884};\\\", \\\"{x:1207,y:827,t:1528139600901};\\\", \\\"{x:1208,y:827,t:1528139600931};\\\", \\\"{x:1210,y:825,t:1528139600947};\\\", \\\"{x:1212,y:825,t:1528139600958};\\\", \\\"{x:1213,y:825,t:1528139601034};\\\", \\\"{x:1216,y:825,t:1528139604195};\\\", \\\"{x:1222,y:826,t:1528139604209};\\\", \\\"{x:1230,y:826,t:1528139604224};\\\", \\\"{x:1244,y:831,t:1528139604241};\\\", \\\"{x:1249,y:832,t:1528139604252};\\\", \\\"{x:1252,y:833,t:1528139604269};\\\", \\\"{x:1254,y:834,t:1528139604287};\\\", \\\"{x:1255,y:835,t:1528139604303};\\\", \\\"{x:1256,y:835,t:1528139604330};\\\", \\\"{x:1257,y:835,t:1528139604338};\\\", \\\"{x:1258,y:835,t:1528139604353};\\\", \\\"{x:1261,y:835,t:1528139604370};\\\", \\\"{x:1262,y:835,t:1528139604411};\\\", \\\"{x:1263,y:835,t:1528139604459};\\\", \\\"{x:1264,y:835,t:1528139604475};\\\", \\\"{x:1265,y:835,t:1528139604515};\\\", \\\"{x:1267,y:835,t:1528139604523};\\\", \\\"{x:1268,y:835,t:1528139604538};\\\", \\\"{x:1271,y:835,t:1528139604554};\\\", \\\"{x:1280,y:838,t:1528139604571};\\\", \\\"{x:1292,y:843,t:1528139604588};\\\", \\\"{x:1299,y:848,t:1528139604604};\\\", \\\"{x:1304,y:855,t:1528139604620};\\\", \\\"{x:1311,y:866,t:1528139604638};\\\", \\\"{x:1318,y:880,t:1528139604655};\\\", \\\"{x:1329,y:898,t:1528139604670};\\\", \\\"{x:1338,y:915,t:1528139604688};\\\", \\\"{x:1345,y:923,t:1528139604704};\\\", \\\"{x:1350,y:930,t:1528139604720};\\\", \\\"{x:1356,y:934,t:1528139604737};\\\", \\\"{x:1357,y:935,t:1528139604755};\\\", \\\"{x:1358,y:935,t:1528139604787};\\\", \\\"{x:1361,y:928,t:1528139604805};\\\", \\\"{x:1365,y:917,t:1528139604821};\\\", \\\"{x:1367,y:905,t:1528139604838};\\\", \\\"{x:1371,y:899,t:1528139604855};\\\", \\\"{x:1371,y:897,t:1528139604871};\\\", \\\"{x:1371,y:895,t:1528139604888};\\\", \\\"{x:1368,y:895,t:1528139604905};\\\", \\\"{x:1366,y:895,t:1528139604921};\\\", \\\"{x:1363,y:895,t:1528139604937};\\\", \\\"{x:1360,y:895,t:1528139604955};\\\", \\\"{x:1357,y:895,t:1528139604971};\\\", \\\"{x:1356,y:895,t:1528139604988};\\\", \\\"{x:1355,y:895,t:1528139605005};\\\", \\\"{x:1354,y:895,t:1528139605116};\\\", \\\"{x:1353,y:895,t:1528139605135};\\\", \\\"{x:1351,y:894,t:1528139605153};\\\", \\\"{x:1350,y:893,t:1528139605242};\\\", \\\"{x:1348,y:893,t:1528139605298};\\\", \\\"{x:1347,y:893,t:1528139605306};\\\", \\\"{x:1346,y:892,t:1528139605322};\\\", \\\"{x:1345,y:892,t:1528139605371};\\\", \\\"{x:1344,y:890,t:1528139606062};\\\", \\\"{x:1344,y:882,t:1528139606071};\\\", \\\"{x:1343,y:862,t:1528139606088};\\\", \\\"{x:1340,y:836,t:1528139606105};\\\", \\\"{x:1338,y:815,t:1528139606121};\\\", \\\"{x:1341,y:772,t:1528139606138};\\\", \\\"{x:1342,y:746,t:1528139606155};\\\", \\\"{x:1343,y:719,t:1528139606171};\\\", \\\"{x:1339,y:696,t:1528139606188};\\\", \\\"{x:1333,y:682,t:1528139606205};\\\", \\\"{x:1329,y:670,t:1528139606221};\\\", \\\"{x:1328,y:660,t:1528139606238};\\\", \\\"{x:1328,y:655,t:1528139606255};\\\", \\\"{x:1326,y:652,t:1528139606271};\\\", \\\"{x:1325,y:647,t:1528139606288};\\\", \\\"{x:1324,y:643,t:1528139606305};\\\", \\\"{x:1324,y:642,t:1528139606321};\\\", \\\"{x:1324,y:639,t:1528139606338};\\\", \\\"{x:1324,y:638,t:1528139606356};\\\", \\\"{x:1324,y:637,t:1528139606371};\\\", \\\"{x:1323,y:637,t:1528139606388};\\\", \\\"{x:1323,y:636,t:1528139606406};\\\", \\\"{x:1323,y:635,t:1528139606423};\\\", \\\"{x:1322,y:634,t:1528139606439};\\\", \\\"{x:1322,y:633,t:1528139606455};\\\", \\\"{x:1321,y:632,t:1528139606472};\\\", \\\"{x:1321,y:630,t:1528139606489};\\\", \\\"{x:1320,y:628,t:1528139606509};\\\", \\\"{x:1319,y:628,t:1528139606586};\\\", \\\"{x:1319,y:626,t:1528139609963};\\\", \\\"{x:1326,y:619,t:1528139609977};\\\", \\\"{x:1333,y:617,t:1528139609991};\\\", \\\"{x:1361,y:605,t:1528139610008};\\\", \\\"{x:1374,y:599,t:1528139610024};\\\", \\\"{x:1383,y:594,t:1528139610041};\\\", \\\"{x:1388,y:592,t:1528139610058};\\\", \\\"{x:1389,y:592,t:1528139610074};\\\", \\\"{x:1390,y:591,t:1528139610235};\\\", \\\"{x:1391,y:590,t:1528139610251};\\\", \\\"{x:1392,y:590,t:1528139610259};\\\", \\\"{x:1394,y:589,t:1528139610276};\\\", \\\"{x:1395,y:588,t:1528139610356};\\\", \\\"{x:1396,y:588,t:1528139610363};\\\", \\\"{x:1398,y:586,t:1528139610378};\\\", \\\"{x:1399,y:586,t:1528139610392};\\\", \\\"{x:1402,y:583,t:1528139610409};\\\", \\\"{x:1403,y:583,t:1528139610426};\\\", \\\"{x:1405,y:582,t:1528139610442};\\\", \\\"{x:1405,y:581,t:1528139610458};\\\", \\\"{x:1407,y:580,t:1528139610483};\\\", \\\"{x:1407,y:578,t:1528139610523};\\\", \\\"{x:1408,y:577,t:1528139610531};\\\", \\\"{x:1408,y:576,t:1528139610595};\\\", \\\"{x:1409,y:576,t:1528139610619};\\\", \\\"{x:1410,y:576,t:1528139610627};\\\", \\\"{x:1411,y:575,t:1528139610643};\\\", \\\"{x:1412,y:574,t:1528139610683};\\\", \\\"{x:1413,y:573,t:1528139610723};\\\", \\\"{x:1414,y:570,t:1528139610731};\\\", \\\"{x:1415,y:570,t:1528139610742};\\\", \\\"{x:1415,y:568,t:1528139610763};\\\", \\\"{x:1416,y:565,t:1528139610774};\\\", \\\"{x:1417,y:564,t:1528139610792};\\\", \\\"{x:1424,y:569,t:1528139611949};\\\", \\\"{x:1433,y:576,t:1528139611959};\\\", \\\"{x:1450,y:583,t:1528139611976};\\\", \\\"{x:1463,y:591,t:1528139611992};\\\", \\\"{x:1476,y:596,t:1528139612009};\\\", \\\"{x:1492,y:604,t:1528139612025};\\\", \\\"{x:1495,y:608,t:1528139612043};\\\", \\\"{x:1496,y:613,t:1528139612059};\\\", \\\"{x:1498,y:616,t:1528139612077};\\\", \\\"{x:1499,y:617,t:1528139612094};\\\", \\\"{x:1500,y:617,t:1528139612122};\\\", \\\"{x:1501,y:619,t:1528139612210};\\\", \\\"{x:1501,y:621,t:1528139612226};\\\", \\\"{x:1501,y:622,t:1528139612258};\\\", \\\"{x:1502,y:623,t:1528139612266};\\\", \\\"{x:1504,y:623,t:1528139612283};\\\", \\\"{x:1506,y:624,t:1528139612294};\\\", \\\"{x:1509,y:624,t:1528139612310};\\\", \\\"{x:1513,y:624,t:1528139612326};\\\", \\\"{x:1515,y:624,t:1528139612345};\\\", \\\"{x:1515,y:625,t:1528139612360};\\\", \\\"{x:1516,y:626,t:1528139612376};\\\", \\\"{x:1518,y:629,t:1528139612393};\\\", \\\"{x:1519,y:630,t:1528139612410};\\\", \\\"{x:1519,y:632,t:1528139613259};\\\", \\\"{x:1519,y:633,t:1528139613275};\\\", \\\"{x:1519,y:634,t:1528139613285};\\\", \\\"{x:1518,y:636,t:1528139613297};\\\", \\\"{x:1516,y:637,t:1528139613314};\\\", \\\"{x:1515,y:638,t:1528139613378};\\\", \\\"{x:1513,y:640,t:1528139613394};\\\", \\\"{x:1511,y:643,t:1528139613411};\\\", \\\"{x:1508,y:648,t:1528139613428};\\\", \\\"{x:1503,y:661,t:1528139613444};\\\", \\\"{x:1497,y:676,t:1528139613460};\\\", \\\"{x:1495,y:684,t:1528139613478};\\\", \\\"{x:1493,y:695,t:1528139613494};\\\", \\\"{x:1493,y:706,t:1528139613511};\\\", \\\"{x:1493,y:716,t:1528139613528};\\\", \\\"{x:1493,y:720,t:1528139613544};\\\", \\\"{x:1493,y:723,t:1528139613560};\\\", \\\"{x:1493,y:724,t:1528139613577};\\\", \\\"{x:1493,y:726,t:1528139613595};\\\", \\\"{x:1492,y:727,t:1528139613859};\\\", \\\"{x:1491,y:727,t:1528139613891};\\\", \\\"{x:1489,y:727,t:1528139613923};\\\", \\\"{x:1488,y:728,t:1528139613931};\\\", \\\"{x:1487,y:729,t:1528139613962};\\\", \\\"{x:1485,y:731,t:1528139613987};\\\", \\\"{x:1484,y:731,t:1528139614002};\\\", \\\"{x:1483,y:733,t:1528139614012};\\\", \\\"{x:1481,y:734,t:1528139614028};\\\", \\\"{x:1480,y:736,t:1528139614045};\\\", \\\"{x:1479,y:738,t:1528139614062};\\\", \\\"{x:1478,y:740,t:1528139614099};\\\", \\\"{x:1478,y:747,t:1528139614115};\\\", \\\"{x:1478,y:751,t:1528139614128};\\\", \\\"{x:1478,y:756,t:1528139614145};\\\", \\\"{x:1479,y:758,t:1528139614162};\\\", \\\"{x:1479,y:761,t:1528139614178};\\\", \\\"{x:1480,y:762,t:1528139614211};\\\", \\\"{x:1480,y:763,t:1528139614228};\\\", \\\"{x:1480,y:764,t:1528139614245};\\\", \\\"{x:1481,y:768,t:1528139614262};\\\", \\\"{x:1483,y:773,t:1528139614279};\\\", \\\"{x:1485,y:782,t:1528139614295};\\\", \\\"{x:1486,y:782,t:1528139614312};\\\", \\\"{x:1486,y:783,t:1528139614410};\\\", \\\"{x:1487,y:784,t:1528139614490};\\\", \\\"{x:1487,y:785,t:1528139614522};\\\", \\\"{x:1488,y:785,t:1528139614571};\\\", \\\"{x:1488,y:786,t:1528139614819};\\\", \\\"{x:1486,y:787,t:1528139614829};\\\", \\\"{x:1480,y:788,t:1528139614846};\\\", \\\"{x:1472,y:793,t:1528139614863};\\\", \\\"{x:1462,y:799,t:1528139614879};\\\", \\\"{x:1451,y:806,t:1528139614896};\\\", \\\"{x:1436,y:817,t:1528139614912};\\\", \\\"{x:1425,y:828,t:1528139614929};\\\", \\\"{x:1416,y:837,t:1528139614947};\\\", \\\"{x:1409,y:844,t:1528139614963};\\\", \\\"{x:1401,y:851,t:1528139614979};\\\", \\\"{x:1398,y:855,t:1528139614996};\\\", \\\"{x:1397,y:858,t:1528139615013};\\\", \\\"{x:1391,y:862,t:1528139615029};\\\", \\\"{x:1388,y:867,t:1528139615046};\\\", \\\"{x:1381,y:871,t:1528139615062};\\\", \\\"{x:1366,y:878,t:1528139615078};\\\", \\\"{x:1353,y:883,t:1528139615095};\\\", \\\"{x:1345,y:888,t:1528139615113};\\\", \\\"{x:1335,y:892,t:1528139615128};\\\", \\\"{x:1332,y:894,t:1528139615146};\\\", \\\"{x:1328,y:896,t:1528139615162};\\\", \\\"{x:1327,y:896,t:1528139615178};\\\", \\\"{x:1326,y:897,t:1528139615195};\\\", \\\"{x:1326,y:898,t:1528139615299};\\\", \\\"{x:1326,y:900,t:1528139615314};\\\", \\\"{x:1331,y:900,t:1528139615331};\\\", \\\"{x:1336,y:900,t:1528139615346};\\\", \\\"{x:1350,y:900,t:1528139615367};\\\", \\\"{x:1358,y:900,t:1528139615380};\\\", \\\"{x:1365,y:900,t:1528139615395};\\\", \\\"{x:1369,y:900,t:1528139615412};\\\", \\\"{x:1370,y:900,t:1528139615429};\\\", \\\"{x:1369,y:900,t:1528139615522};\\\", \\\"{x:1365,y:901,t:1528139615530};\\\", \\\"{x:1360,y:901,t:1528139615545};\\\", \\\"{x:1350,y:904,t:1528139615563};\\\", \\\"{x:1345,y:904,t:1528139615579};\\\", \\\"{x:1344,y:905,t:1528139615691};\\\", \\\"{x:1342,y:906,t:1528139615698};\\\", \\\"{x:1341,y:906,t:1528139615713};\\\", \\\"{x:1340,y:906,t:1528139615852};\\\", \\\"{x:1341,y:906,t:1528139615955};\\\", \\\"{x:1342,y:906,t:1528139615978};\\\", \\\"{x:1345,y:906,t:1528139615996};\\\", \\\"{x:1346,y:906,t:1528139616013};\\\", \\\"{x:1348,y:906,t:1528139616030};\\\", \\\"{x:1350,y:906,t:1528139616045};\\\", \\\"{x:1351,y:906,t:1528139616063};\\\", \\\"{x:1352,y:906,t:1528139616099};\\\", \\\"{x:1353,y:906,t:1528139616113};\\\", \\\"{x:1354,y:904,t:1528139616131};\\\", \\\"{x:1358,y:903,t:1528139616147};\\\", \\\"{x:1358,y:901,t:1528139616163};\\\", \\\"{x:1359,y:900,t:1528139616203};\\\", \\\"{x:1359,y:898,t:1528139616213};\\\", \\\"{x:1360,y:897,t:1528139616230};\\\", \\\"{x:1359,y:897,t:1528139616627};\\\", \\\"{x:1357,y:897,t:1528139616635};\\\", \\\"{x:1357,y:898,t:1528139616647};\\\", \\\"{x:1355,y:898,t:1528139616665};\\\", \\\"{x:1352,y:898,t:1528139616681};\\\", \\\"{x:1350,y:898,t:1528139616696};\\\", \\\"{x:1347,y:898,t:1528139616712};\\\", \\\"{x:1345,y:898,t:1528139616729};\\\", \\\"{x:1344,y:898,t:1528139616810};\\\", \\\"{x:1343,y:898,t:1528139617211};\\\", \\\"{x:1343,y:897,t:1528139617243};\\\", \\\"{x:1344,y:896,t:1528139617250};\\\", \\\"{x:1345,y:895,t:1528139617274};\\\", \\\"{x:1345,y:894,t:1528139617315};\\\", \\\"{x:1345,y:893,t:1528139617362};\\\", \\\"{x:1345,y:892,t:1528139617770};\\\", \\\"{x:1346,y:892,t:1528139619091};\\\", \\\"{x:1347,y:892,t:1528139619171};\\\", \\\"{x:1349,y:892,t:1528139619667};\\\", \\\"{x:1350,y:892,t:1528139619683};\\\", \\\"{x:1351,y:892,t:1528139620267};\\\", \\\"{x:1352,y:892,t:1528139620342};\\\", \\\"{x:1353,y:892,t:1528139620418};\\\", \\\"{x:1353,y:891,t:1528139620466};\\\", \\\"{x:1352,y:891,t:1528139620659};\\\", \\\"{x:1350,y:890,t:1528139620667};\\\", \\\"{x:1346,y:886,t:1528139620682};\\\", \\\"{x:1347,y:879,t:1528139620700};\\\", \\\"{x:1348,y:877,t:1528139620717};\\\", \\\"{x:1349,y:874,t:1528139620733};\\\", \\\"{x:1352,y:868,t:1528139620750};\\\", \\\"{x:1355,y:861,t:1528139620767};\\\", \\\"{x:1359,y:853,t:1528139620783};\\\", \\\"{x:1368,y:841,t:1528139620800};\\\", \\\"{x:1376,y:830,t:1528139620818};\\\", \\\"{x:1385,y:818,t:1528139620834};\\\", \\\"{x:1394,y:811,t:1528139620850};\\\", \\\"{x:1402,y:801,t:1528139620866};\\\", \\\"{x:1412,y:787,t:1528139620883};\\\", \\\"{x:1420,y:776,t:1528139620900};\\\", \\\"{x:1430,y:762,t:1528139620916};\\\", \\\"{x:1444,y:746,t:1528139620933};\\\", \\\"{x:1455,y:732,t:1528139620950};\\\", \\\"{x:1465,y:721,t:1528139620967};\\\", \\\"{x:1470,y:712,t:1528139620983};\\\", \\\"{x:1475,y:704,t:1528139621000};\\\", \\\"{x:1476,y:698,t:1528139621017};\\\", \\\"{x:1479,y:691,t:1528139621033};\\\", \\\"{x:1484,y:679,t:1528139621050};\\\", \\\"{x:1489,y:670,t:1528139621067};\\\", \\\"{x:1495,y:660,t:1528139621083};\\\", \\\"{x:1498,y:652,t:1528139621101};\\\", \\\"{x:1501,y:644,t:1528139621117};\\\", \\\"{x:1503,y:639,t:1528139621134};\\\", \\\"{x:1503,y:637,t:1528139621150};\\\", \\\"{x:1503,y:635,t:1528139621171};\\\", \\\"{x:1505,y:634,t:1528139621187};\\\", \\\"{x:1506,y:633,t:1528139621201};\\\", \\\"{x:1507,y:631,t:1528139621218};\\\", \\\"{x:1509,y:629,t:1528139621238};\\\", \\\"{x:1510,y:628,t:1528139621250};\\\", \\\"{x:1510,y:627,t:1528139621337};\\\", \\\"{x:1511,y:627,t:1528139621354};\\\", \\\"{x:1512,y:627,t:1528139621418};\\\", \\\"{x:1516,y:627,t:1528139621434};\\\", \\\"{x:1518,y:627,t:1528139621451};\\\", \\\"{x:1520,y:627,t:1528139621469};\\\", \\\"{x:1519,y:627,t:1528139622062};\\\", \\\"{x:1516,y:627,t:1528139622084};\\\", \\\"{x:1515,y:627,t:1528139622100};\\\", \\\"{x:1514,y:627,t:1528139622118};\\\", \\\"{x:1513,y:626,t:1528139622134};\\\", \\\"{x:1512,y:626,t:1528139622154};\\\", \\\"{x:1512,y:625,t:1528139622177};\\\", \\\"{x:1514,y:623,t:1528139622252};\\\", \\\"{x:1519,y:618,t:1528139622268};\\\", \\\"{x:1531,y:608,t:1528139622285};\\\", \\\"{x:1541,y:595,t:1528139622301};\\\", \\\"{x:1548,y:589,t:1528139622318};\\\", \\\"{x:1553,y:584,t:1528139622335};\\\", \\\"{x:1558,y:581,t:1528139622350};\\\", \\\"{x:1563,y:577,t:1528139622368};\\\", \\\"{x:1567,y:574,t:1528139622385};\\\", \\\"{x:1570,y:571,t:1528139622400};\\\", \\\"{x:1574,y:568,t:1528139622417};\\\", \\\"{x:1576,y:568,t:1528139622435};\\\", \\\"{x:1581,y:564,t:1528139622451};\\\", \\\"{x:1583,y:563,t:1528139622468};\\\", \\\"{x:1584,y:562,t:1528139622486};\\\", \\\"{x:1585,y:561,t:1528139622501};\\\", \\\"{x:1589,y:558,t:1528139622563};\\\", \\\"{x:1590,y:557,t:1528139622571};\\\", \\\"{x:1593,y:556,t:1528139622588};\\\", \\\"{x:1598,y:553,t:1528139622601};\\\", \\\"{x:1601,y:550,t:1528139622618};\\\", \\\"{x:1603,y:550,t:1528139622634};\\\", \\\"{x:1604,y:550,t:1528139622706};\\\", \\\"{x:1605,y:550,t:1528139622787};\\\", \\\"{x:1605,y:551,t:1528139622802};\\\", \\\"{x:1606,y:553,t:1528139622818};\\\", \\\"{x:1607,y:553,t:1528139622851};\\\", \\\"{x:1607,y:554,t:1528139622859};\\\", \\\"{x:1609,y:556,t:1528139622875};\\\", \\\"{x:1610,y:557,t:1528139622886};\\\", \\\"{x:1612,y:557,t:1528139622902};\\\", \\\"{x:1613,y:558,t:1528139622931};\\\", \\\"{x:1615,y:559,t:1528139622969};\\\", \\\"{x:1617,y:561,t:1528139622984};\\\", \\\"{x:1621,y:564,t:1528139623002};\\\", \\\"{x:1624,y:565,t:1528139623017};\\\", \\\"{x:1627,y:566,t:1528139623035};\\\", \\\"{x:1625,y:566,t:1528139623347};\\\", \\\"{x:1624,y:566,t:1528139623355};\\\", \\\"{x:1622,y:566,t:1528139623370};\\\", \\\"{x:1620,y:566,t:1528139623385};\\\", \\\"{x:1618,y:564,t:1528139623407};\\\", \\\"{x:1617,y:563,t:1528139623529};\\\", \\\"{x:1617,y:562,t:1528139623650};\\\", \\\"{x:1617,y:561,t:1528139623706};\\\", \\\"{x:1616,y:561,t:1528139623754};\\\", \\\"{x:1612,y:561,t:1528139623818};\\\", \\\"{x:1601,y:569,t:1528139623837};\\\", \\\"{x:1585,y:585,t:1528139623851};\\\", \\\"{x:1567,y:604,t:1528139623869};\\\", \\\"{x:1545,y:633,t:1528139623886};\\\", \\\"{x:1513,y:676,t:1528139623902};\\\", \\\"{x:1472,y:749,t:1528139623919};\\\", \\\"{x:1427,y:816,t:1528139623935};\\\", \\\"{x:1387,y:868,t:1528139623953};\\\", \\\"{x:1345,y:908,t:1528139623969};\\\", \\\"{x:1304,y:947,t:1528139623986};\\\", \\\"{x:1274,y:965,t:1528139624003};\\\", \\\"{x:1259,y:981,t:1528139624019};\\\", \\\"{x:1242,y:995,t:1528139624036};\\\", \\\"{x:1234,y:1000,t:1528139624053};\\\", \\\"{x:1230,y:1004,t:1528139624069};\\\", \\\"{x:1225,y:1006,t:1528139624087};\\\", \\\"{x:1224,y:1008,t:1528139624103};\\\", \\\"{x:1223,y:1009,t:1528139624120};\\\", \\\"{x:1224,y:1008,t:1528139624195};\\\", \\\"{x:1230,y:1003,t:1528139624203};\\\", \\\"{x:1243,y:990,t:1528139624220};\\\", \\\"{x:1260,y:977,t:1528139624237};\\\", \\\"{x:1281,y:957,t:1528139624254};\\\", \\\"{x:1296,y:942,t:1528139624270};\\\", \\\"{x:1308,y:928,t:1528139624287};\\\", \\\"{x:1314,y:919,t:1528139624304};\\\", \\\"{x:1317,y:913,t:1528139624320};\\\", \\\"{x:1320,y:906,t:1528139624337};\\\", \\\"{x:1322,y:898,t:1528139624353};\\\", \\\"{x:1325,y:893,t:1528139624369};\\\", \\\"{x:1329,y:886,t:1528139624387};\\\", \\\"{x:1330,y:882,t:1528139624403};\\\", \\\"{x:1333,y:878,t:1528139624420};\\\", \\\"{x:1337,y:869,t:1528139624437};\\\", \\\"{x:1343,y:861,t:1528139624453};\\\", \\\"{x:1346,y:856,t:1528139624470};\\\", \\\"{x:1348,y:852,t:1528139624486};\\\", \\\"{x:1349,y:850,t:1528139624504};\\\", \\\"{x:1350,y:849,t:1528139624520};\\\", \\\"{x:1351,y:845,t:1528139624536};\\\", \\\"{x:1353,y:840,t:1528139624554};\\\", \\\"{x:1354,y:835,t:1528139624571};\\\", \\\"{x:1356,y:831,t:1528139624586};\\\", \\\"{x:1358,y:827,t:1528139624604};\\\", \\\"{x:1360,y:821,t:1528139624621};\\\", \\\"{x:1362,y:814,t:1528139624637};\\\", \\\"{x:1363,y:807,t:1528139624653};\\\", \\\"{x:1366,y:798,t:1528139624670};\\\", \\\"{x:1369,y:790,t:1528139624686};\\\", \\\"{x:1370,y:783,t:1528139624703};\\\", \\\"{x:1373,y:779,t:1528139624720};\\\", \\\"{x:1374,y:777,t:1528139624736};\\\", \\\"{x:1375,y:773,t:1528139624754};\\\", \\\"{x:1377,y:770,t:1528139624770};\\\", \\\"{x:1377,y:767,t:1528139624790};\\\", \\\"{x:1378,y:764,t:1528139624803};\\\", \\\"{x:1379,y:763,t:1528139624820};\\\", \\\"{x:1379,y:761,t:1528139624836};\\\", \\\"{x:1380,y:760,t:1528139624853};\\\", \\\"{x:1380,y:759,t:1528139624930};\\\", \\\"{x:1381,y:759,t:1528139624946};\\\", \\\"{x:1382,y:759,t:1528139624954};\\\", \\\"{x:1382,y:758,t:1528139625795};\\\", \\\"{x:1381,y:758,t:1528139625875};\\\", \\\"{x:1379,y:758,t:1528139625947};\\\", \\\"{x:1378,y:758,t:1528139626011};\\\", \\\"{x:1377,y:758,t:1528139626024};\\\", \\\"{x:1375,y:758,t:1528139626037};\\\", \\\"{x:1367,y:759,t:1528139626053};\\\", \\\"{x:1349,y:762,t:1528139626071};\\\", \\\"{x:1325,y:763,t:1528139626086};\\\", \\\"{x:1297,y:763,t:1528139626104};\\\", \\\"{x:1223,y:758,t:1528139626121};\\\", \\\"{x:1113,y:746,t:1528139626137};\\\", \\\"{x:887,y:713,t:1528139626154};\\\", \\\"{x:719,y:693,t:1528139626171};\\\", \\\"{x:550,y:665,t:1528139626189};\\\", \\\"{x:374,y:629,t:1528139626205};\\\", \\\"{x:224,y:602,t:1528139626222};\\\", \\\"{x:107,y:582,t:1528139626238};\\\", \\\"{x:15,y:565,t:1528139626255};\\\", \\\"{x:0,y:552,t:1528139626271};\\\", \\\"{x:0,y:549,t:1528139626288};\\\", \\\"{x:0,y:546,t:1528139626304};\\\", \\\"{x:0,y:545,t:1528139626339};\\\", \\\"{x:7,y:542,t:1528139626355};\\\", \\\"{x:12,y:540,t:1528139626371};\\\", \\\"{x:21,y:538,t:1528139626388};\\\", \\\"{x:26,y:534,t:1528139626405};\\\", \\\"{x:33,y:530,t:1528139626421};\\\", \\\"{x:38,y:528,t:1528139626439};\\\", \\\"{x:45,y:526,t:1528139626455};\\\", \\\"{x:60,y:526,t:1528139626472};\\\", \\\"{x:76,y:526,t:1528139626488};\\\", \\\"{x:100,y:533,t:1528139626505};\\\", \\\"{x:144,y:551,t:1528139626524};\\\", \\\"{x:173,y:568,t:1528139626537};\\\", \\\"{x:200,y:582,t:1528139626555};\\\", \\\"{x:225,y:594,t:1528139626571};\\\", \\\"{x:242,y:599,t:1528139626588};\\\", \\\"{x:260,y:602,t:1528139626604};\\\", \\\"{x:273,y:603,t:1528139626623};\\\", \\\"{x:276,y:603,t:1528139626638};\\\", \\\"{x:277,y:603,t:1528139626655};\\\", \\\"{x:278,y:603,t:1528139626706};\\\", \\\"{x:279,y:603,t:1528139626721};\\\", \\\"{x:283,y:602,t:1528139626737};\\\", \\\"{x:285,y:602,t:1528139626755};\\\", \\\"{x:291,y:600,t:1528139626771};\\\", \\\"{x:296,y:597,t:1528139626788};\\\", \\\"{x:302,y:595,t:1528139626805};\\\", \\\"{x:304,y:594,t:1528139626821};\\\", \\\"{x:305,y:594,t:1528139626838};\\\", \\\"{x:307,y:594,t:1528139626856};\\\", \\\"{x:309,y:594,t:1528139626873};\\\", \\\"{x:310,y:594,t:1528139626888};\\\", \\\"{x:313,y:593,t:1528139626905};\\\", \\\"{x:317,y:592,t:1528139626922};\\\", \\\"{x:320,y:592,t:1528139626939};\\\", \\\"{x:324,y:592,t:1528139626955};\\\", \\\"{x:328,y:592,t:1528139626972};\\\", \\\"{x:330,y:592,t:1528139626989};\\\", \\\"{x:336,y:592,t:1528139627005};\\\", \\\"{x:342,y:592,t:1528139627022};\\\", \\\"{x:352,y:592,t:1528139627038};\\\", \\\"{x:358,y:592,t:1528139627055};\\\", \\\"{x:363,y:592,t:1528139627072};\\\", \\\"{x:367,y:592,t:1528139627088};\\\", \\\"{x:368,y:592,t:1528139627105};\\\", \\\"{x:369,y:591,t:1528139627122};\\\", \\\"{x:370,y:591,t:1528139627162};\\\", \\\"{x:372,y:591,t:1528139627186};\\\", \\\"{x:373,y:591,t:1528139627194};\\\", \\\"{x:375,y:591,t:1528139627283};\\\", \\\"{x:376,y:591,t:1528139627305};\\\", \\\"{x:378,y:591,t:1528139627730};\\\", \\\"{x:383,y:591,t:1528139627739};\\\", \\\"{x:398,y:591,t:1528139627755};\\\", \\\"{x:416,y:594,t:1528139627772};\\\", \\\"{x:435,y:596,t:1528139627790};\\\", \\\"{x:467,y:602,t:1528139627806};\\\", \\\"{x:503,y:614,t:1528139627823};\\\", \\\"{x:561,y:627,t:1528139627840};\\\", \\\"{x:619,y:646,t:1528139627855};\\\", \\\"{x:675,y:662,t:1528139627873};\\\", \\\"{x:723,y:678,t:1528139627889};\\\", \\\"{x:787,y:704,t:1528139627906};\\\", \\\"{x:876,y:742,t:1528139627922};\\\", \\\"{x:926,y:775,t:1528139627939};\\\", \\\"{x:977,y:800,t:1528139627956};\\\", \\\"{x:1021,y:828,t:1528139627972};\\\", \\\"{x:1065,y:857,t:1528139627989};\\\", \\\"{x:1104,y:891,t:1528139628005};\\\", \\\"{x:1140,y:914,t:1528139628023};\\\", \\\"{x:1167,y:935,t:1528139628039};\\\", \\\"{x:1186,y:950,t:1528139628055};\\\", \\\"{x:1197,y:957,t:1528139628072};\\\", \\\"{x:1208,y:972,t:1528139628090};\\\", \\\"{x:1221,y:988,t:1528139628106};\\\", \\\"{x:1250,y:1004,t:1528139628123};\\\", \\\"{x:1255,y:1007,t:1528139628140};\\\", \\\"{x:1261,y:1009,t:1528139628155};\\\", \\\"{x:1263,y:1011,t:1528139628173};\\\", \\\"{x:1265,y:1011,t:1528139628194};\\\", \\\"{x:1266,y:1011,t:1528139628206};\\\", \\\"{x:1266,y:1009,t:1528139628259};\\\", \\\"{x:1266,y:1007,t:1528139628273};\\\", \\\"{x:1266,y:1002,t:1528139628289};\\\", \\\"{x:1266,y:1001,t:1528139628306};\\\", \\\"{x:1266,y:995,t:1528139628322};\\\", \\\"{x:1267,y:993,t:1528139628339};\\\", \\\"{x:1268,y:989,t:1528139628356};\\\", \\\"{x:1269,y:989,t:1528139628373};\\\", \\\"{x:1270,y:987,t:1528139628389};\\\", \\\"{x:1271,y:986,t:1528139628411};\\\", \\\"{x:1271,y:985,t:1528139628426};\\\", \\\"{x:1271,y:984,t:1528139628439};\\\", \\\"{x:1273,y:982,t:1528139628456};\\\", \\\"{x:1278,y:979,t:1528139628473};\\\", \\\"{x:1280,y:978,t:1528139628488};\\\", \\\"{x:1280,y:977,t:1528139628505};\\\", \\\"{x:1280,y:975,t:1528139628523};\\\", \\\"{x:1280,y:974,t:1528139628554};\\\", \\\"{x:1280,y:973,t:1528139628659};\\\", \\\"{x:1282,y:972,t:1528139628707};\\\", \\\"{x:1283,y:968,t:1528139628723};\\\", \\\"{x:1283,y:967,t:1528139628738};\\\", \\\"{x:1285,y:965,t:1528139628756};\\\", \\\"{x:1286,y:963,t:1528139628772};\\\", \\\"{x:1287,y:960,t:1528139628789};\\\", \\\"{x:1288,y:958,t:1528139628806};\\\", \\\"{x:1288,y:955,t:1528139628822};\\\", \\\"{x:1288,y:952,t:1528139628839};\\\", \\\"{x:1289,y:947,t:1528139628856};\\\", \\\"{x:1289,y:945,t:1528139628872};\\\", \\\"{x:1289,y:939,t:1528139628889};\\\", \\\"{x:1288,y:934,t:1528139628905};\\\", \\\"{x:1287,y:931,t:1528139628921};\\\", \\\"{x:1283,y:924,t:1528139628938};\\\", \\\"{x:1276,y:916,t:1528139628955};\\\", \\\"{x:1269,y:910,t:1528139628971};\\\", \\\"{x:1260,y:904,t:1528139628989};\\\", \\\"{x:1253,y:899,t:1528139629005};\\\", \\\"{x:1246,y:893,t:1528139629021};\\\", \\\"{x:1240,y:887,t:1528139629039};\\\", \\\"{x:1233,y:879,t:1528139629055};\\\", \\\"{x:1227,y:869,t:1528139629072};\\\", \\\"{x:1223,y:864,t:1528139629088};\\\", \\\"{x:1221,y:861,t:1528139629105};\\\", \\\"{x:1219,y:858,t:1528139629122};\\\", \\\"{x:1219,y:856,t:1528139629139};\\\", \\\"{x:1219,y:854,t:1528139629155};\\\", \\\"{x:1219,y:851,t:1528139629172};\\\", \\\"{x:1219,y:850,t:1528139629203};\\\", \\\"{x:1219,y:849,t:1528139629210};\\\", \\\"{x:1219,y:848,t:1528139629222};\\\", \\\"{x:1219,y:846,t:1528139629242};\\\", \\\"{x:1219,y:845,t:1528139629283};\\\", \\\"{x:1219,y:843,t:1528139629291};\\\", \\\"{x:1219,y:840,t:1528139629307};\\\", \\\"{x:1219,y:839,t:1528139629321};\\\", \\\"{x:1219,y:835,t:1528139629339};\\\", \\\"{x:1219,y:832,t:1528139629359};\\\", \\\"{x:1219,y:830,t:1528139629371};\\\", \\\"{x:1218,y:830,t:1528139629388};\\\", \\\"{x:1218,y:829,t:1528139629466};\\\", \\\"{x:1217,y:827,t:1528139629514};\\\", \\\"{x:1217,y:826,t:1528139629578};\\\", \\\"{x:1216,y:826,t:1528139629591};\\\", \\\"{x:1215,y:824,t:1528139629620};\\\", \\\"{x:1215,y:823,t:1528139629641};\\\", \\\"{x:1214,y:822,t:1528139629689};\\\", \\\"{x:1213,y:822,t:1528139630043};\\\", \\\"{x:1217,y:830,t:1528139630071};\\\", \\\"{x:1235,y:849,t:1528139630091};\\\", \\\"{x:1246,y:857,t:1528139630107};\\\", \\\"{x:1253,y:862,t:1528139630124};\\\", \\\"{x:1257,y:864,t:1528139630141};\\\", \\\"{x:1260,y:865,t:1528139630157};\\\", \\\"{x:1261,y:865,t:1528139630174};\\\", \\\"{x:1264,y:865,t:1528139630192};\\\", \\\"{x:1266,y:865,t:1528139630207};\\\", \\\"{x:1268,y:863,t:1528139630224};\\\", \\\"{x:1272,y:862,t:1528139630241};\\\", \\\"{x:1278,y:858,t:1528139630257};\\\", \\\"{x:1283,y:851,t:1528139630274};\\\", \\\"{x:1284,y:845,t:1528139630291};\\\", \\\"{x:1287,y:841,t:1528139630307};\\\", \\\"{x:1288,y:836,t:1528139630325};\\\", \\\"{x:1289,y:836,t:1528139630341};\\\", \\\"{x:1290,y:832,t:1528139630358};\\\", \\\"{x:1294,y:829,t:1528139630374};\\\", \\\"{x:1295,y:827,t:1528139630391};\\\", \\\"{x:1296,y:826,t:1528139630408};\\\", \\\"{x:1301,y:823,t:1528139630424};\\\", \\\"{x:1305,y:821,t:1528139630441};\\\", \\\"{x:1315,y:814,t:1528139630458};\\\", \\\"{x:1331,y:810,t:1528139630475};\\\", \\\"{x:1339,y:804,t:1528139630492};\\\", \\\"{x:1342,y:802,t:1528139630507};\\\", \\\"{x:1347,y:800,t:1528139630525};\\\", \\\"{x:1349,y:799,t:1528139630542};\\\", \\\"{x:1352,y:797,t:1528139630558};\\\", \\\"{x:1355,y:796,t:1528139630575};\\\", \\\"{x:1362,y:791,t:1528139630592};\\\", \\\"{x:1365,y:789,t:1528139630608};\\\", \\\"{x:1367,y:788,t:1528139630625};\\\", \\\"{x:1368,y:787,t:1528139630642};\\\", \\\"{x:1370,y:785,t:1528139630659};\\\", \\\"{x:1371,y:783,t:1528139630674};\\\", \\\"{x:1373,y:781,t:1528139630691};\\\", \\\"{x:1375,y:778,t:1528139630708};\\\", \\\"{x:1377,y:775,t:1528139630724};\\\", \\\"{x:1380,y:771,t:1528139630741};\\\", \\\"{x:1382,y:766,t:1528139630760};\\\", \\\"{x:1385,y:759,t:1528139630774};\\\", \\\"{x:1388,y:756,t:1528139630792};\\\", \\\"{x:1388,y:755,t:1528139630808};\\\", \\\"{x:1390,y:755,t:1528139630824};\\\", \\\"{x:1393,y:752,t:1528139630841};\\\", \\\"{x:1393,y:751,t:1528139630930};\\\", \\\"{x:1393,y:750,t:1528139631067};\\\", \\\"{x:1394,y:750,t:1528139631076};\\\", \\\"{x:1397,y:745,t:1528139631091};\\\", \\\"{x:1400,y:740,t:1528139631109};\\\", \\\"{x:1402,y:734,t:1528139631126};\\\", \\\"{x:1406,y:727,t:1528139631141};\\\", \\\"{x:1410,y:723,t:1528139631158};\\\", \\\"{x:1412,y:718,t:1528139631176};\\\", \\\"{x:1415,y:712,t:1528139631192};\\\", \\\"{x:1419,y:704,t:1528139631209};\\\", \\\"{x:1424,y:691,t:1528139631227};\\\", \\\"{x:1426,y:687,t:1528139631242};\\\", \\\"{x:1427,y:681,t:1528139631259};\\\", \\\"{x:1429,y:676,t:1528139631276};\\\", \\\"{x:1430,y:674,t:1528139631291};\\\", \\\"{x:1433,y:666,t:1528139631309};\\\", \\\"{x:1434,y:660,t:1528139631325};\\\", \\\"{x:1434,y:655,t:1528139631342};\\\", \\\"{x:1438,y:649,t:1528139631359};\\\", \\\"{x:1439,y:643,t:1528139631375};\\\", \\\"{x:1442,y:638,t:1528139631392};\\\", \\\"{x:1443,y:633,t:1528139631409};\\\", \\\"{x:1444,y:627,t:1528139631426};\\\", \\\"{x:1445,y:626,t:1528139631442};\\\", \\\"{x:1445,y:621,t:1528139631458};\\\", \\\"{x:1445,y:613,t:1528139631475};\\\", \\\"{x:1445,y:604,t:1528139631493};\\\", \\\"{x:1445,y:591,t:1528139631509};\\\", \\\"{x:1445,y:575,t:1528139631526};\\\", \\\"{x:1444,y:559,t:1528139631543};\\\", \\\"{x:1444,y:546,t:1528139631559};\\\", \\\"{x:1450,y:530,t:1528139631576};\\\", \\\"{x:1460,y:515,t:1528139631593};\\\", \\\"{x:1470,y:497,t:1528139631609};\\\", \\\"{x:1478,y:479,t:1528139631626};\\\", \\\"{x:1484,y:469,t:1528139631643};\\\", \\\"{x:1487,y:463,t:1528139631659};\\\", \\\"{x:1490,y:455,t:1528139631676};\\\", \\\"{x:1492,y:451,t:1528139631693};\\\", \\\"{x:1495,y:447,t:1528139631708};\\\", \\\"{x:1500,y:444,t:1528139631725};\\\", \\\"{x:1504,y:440,t:1528139631742};\\\", \\\"{x:1508,y:436,t:1528139631758};\\\", \\\"{x:1513,y:431,t:1528139631775};\\\", \\\"{x:1517,y:426,t:1528139631792};\\\", \\\"{x:1519,y:421,t:1528139631808};\\\", \\\"{x:1524,y:416,t:1528139631825};\\\", \\\"{x:1529,y:412,t:1528139631842};\\\", \\\"{x:1531,y:409,t:1528139631858};\\\", \\\"{x:1533,y:407,t:1528139631875};\\\", \\\"{x:1537,y:404,t:1528139631893};\\\", \\\"{x:1540,y:402,t:1528139631909};\\\", \\\"{x:1543,y:399,t:1528139631925};\\\", \\\"{x:1547,y:396,t:1528139631942};\\\", \\\"{x:1552,y:393,t:1528139631959};\\\", \\\"{x:1557,y:389,t:1528139631975};\\\", \\\"{x:1564,y:383,t:1528139631993};\\\", \\\"{x:1572,y:376,t:1528139632010};\\\", \\\"{x:1581,y:368,t:1528139632026};\\\", \\\"{x:1586,y:363,t:1528139632043};\\\", \\\"{x:1589,y:360,t:1528139632060};\\\", \\\"{x:1591,y:358,t:1528139632077};\\\", \\\"{x:1592,y:357,t:1528139632093};\\\", \\\"{x:1593,y:355,t:1528139632110};\\\", \\\"{x:1593,y:354,t:1528139632126};\\\", \\\"{x:1594,y:354,t:1528139632143};\\\", \\\"{x:1594,y:353,t:1528139632483};\\\", \\\"{x:1592,y:353,t:1528139632515};\\\", \\\"{x:1592,y:355,t:1528139632527};\\\", \\\"{x:1588,y:361,t:1528139632543};\\\", \\\"{x:1586,y:365,t:1528139632560};\\\", \\\"{x:1580,y:373,t:1528139632577};\\\", \\\"{x:1576,y:384,t:1528139632593};\\\", \\\"{x:1571,y:393,t:1528139632610};\\\", \\\"{x:1566,y:402,t:1528139632627};\\\", \\\"{x:1563,y:407,t:1528139632643};\\\", \\\"{x:1560,y:411,t:1528139632660};\\\", \\\"{x:1556,y:416,t:1528139632678};\\\", \\\"{x:1555,y:421,t:1528139632694};\\\", \\\"{x:1553,y:426,t:1528139632710};\\\", \\\"{x:1550,y:432,t:1528139632727};\\\", \\\"{x:1547,y:437,t:1528139632744};\\\", \\\"{x:1543,y:442,t:1528139632760};\\\", \\\"{x:1539,y:455,t:1528139632777};\\\", \\\"{x:1533,y:466,t:1528139632794};\\\", \\\"{x:1527,y:483,t:1528139632810};\\\", \\\"{x:1522,y:500,t:1528139632827};\\\", \\\"{x:1518,y:511,t:1528139632844};\\\", \\\"{x:1517,y:514,t:1528139632860};\\\", \\\"{x:1517,y:515,t:1528139632876};\\\", \\\"{x:1517,y:516,t:1528139632930};\\\", \\\"{x:1519,y:516,t:1528139632944};\\\", \\\"{x:1526,y:514,t:1528139632959};\\\", \\\"{x:1535,y:508,t:1528139632976};\\\", \\\"{x:1543,y:502,t:1528139632994};\\\", \\\"{x:1555,y:495,t:1528139633010};\\\", \\\"{x:1558,y:493,t:1528139633026};\\\", \\\"{x:1559,y:492,t:1528139633099};\\\", \\\"{x:1560,y:492,t:1528139633323};\\\", \\\"{x:1561,y:491,t:1528139633355};\\\", \\\"{x:1565,y:488,t:1528139633371};\\\", \\\"{x:1572,y:488,t:1528139633379};\\\", \\\"{x:1577,y:487,t:1528139633394};\\\", \\\"{x:1580,y:483,t:1528139633411};\\\", \\\"{x:1581,y:482,t:1528139633443};\\\", \\\"{x:1581,y:481,t:1528139633484};\\\", \\\"{x:1582,y:481,t:1528139633507};\\\", \\\"{x:1583,y:479,t:1528139633523};\\\", \\\"{x:1583,y:477,t:1528139633547};\\\", \\\"{x:1583,y:475,t:1528139633563};\\\", \\\"{x:1585,y:474,t:1528139633579};\\\", \\\"{x:1585,y:473,t:1528139633594};\\\", \\\"{x:1589,y:469,t:1528139633611};\\\", \\\"{x:1590,y:467,t:1528139633627};\\\", \\\"{x:1592,y:463,t:1528139633644};\\\", \\\"{x:1594,y:461,t:1528139633661};\\\", \\\"{x:1596,y:457,t:1528139633678};\\\", \\\"{x:1597,y:454,t:1528139633694};\\\", \\\"{x:1597,y:453,t:1528139633711};\\\", \\\"{x:1598,y:452,t:1528139633738};\\\", \\\"{x:1599,y:451,t:1528139633754};\\\", \\\"{x:1600,y:451,t:1528139633761};\\\", \\\"{x:1601,y:450,t:1528139633777};\\\", \\\"{x:1601,y:448,t:1528139633793};\\\", \\\"{x:1602,y:446,t:1528139633826};\\\", \\\"{x:1603,y:445,t:1528139633833};\\\", \\\"{x:1605,y:443,t:1528139633843};\\\", \\\"{x:1607,y:439,t:1528139633861};\\\", \\\"{x:1611,y:434,t:1528139633878};\\\", \\\"{x:1613,y:431,t:1528139633893};\\\", \\\"{x:1615,y:429,t:1528139633910};\\\", \\\"{x:1616,y:427,t:1528139633929};\\\", \\\"{x:1617,y:427,t:1528139633945};\\\", \\\"{x:1618,y:426,t:1528139633960};\\\", \\\"{x:1618,y:425,t:1528139633978};\\\", \\\"{x:1617,y:425,t:1528139634755};\\\", \\\"{x:1616,y:425,t:1528139634787};\\\", \\\"{x:1615,y:425,t:1528139634851};\\\", \\\"{x:1615,y:426,t:1528139634862};\\\", \\\"{x:1614,y:426,t:1528139634882};\\\", \\\"{x:1613,y:426,t:1528139634899};\\\", \\\"{x:1611,y:427,t:1528139634923};\\\", \\\"{x:1610,y:428,t:1528139634939};\\\", \\\"{x:1607,y:430,t:1528139634962};\\\", \\\"{x:1599,y:434,t:1528139634977};\\\", \\\"{x:1576,y:447,t:1528139634994};\\\", \\\"{x:1521,y:468,t:1528139635011};\\\", \\\"{x:1433,y:487,t:1528139635028};\\\", \\\"{x:1308,y:508,t:1528139635045};\\\", \\\"{x:1157,y:524,t:1528139635061};\\\", \\\"{x:993,y:530,t:1528139635078};\\\", \\\"{x:829,y:539,t:1528139635094};\\\", \\\"{x:659,y:545,t:1528139635111};\\\", \\\"{x:512,y:549,t:1528139635129};\\\", \\\"{x:402,y:556,t:1528139635145};\\\", \\\"{x:310,y:561,t:1528139635162};\\\", \\\"{x:289,y:563,t:1528139635178};\\\", \\\"{x:276,y:566,t:1528139635195};\\\", \\\"{x:274,y:568,t:1528139635212};\\\", \\\"{x:272,y:569,t:1528139635230};\\\", \\\"{x:270,y:573,t:1528139635244};\\\", \\\"{x:266,y:580,t:1528139635262};\\\", \\\"{x:261,y:588,t:1528139635278};\\\", \\\"{x:250,y:602,t:1528139635295};\\\", \\\"{x:244,y:611,t:1528139635312};\\\", \\\"{x:238,y:620,t:1528139635329};\\\", \\\"{x:232,y:628,t:1528139635345};\\\", \\\"{x:225,y:645,t:1528139635362};\\\", \\\"{x:223,y:651,t:1528139635379};\\\", \\\"{x:223,y:655,t:1528139635395};\\\", \\\"{x:223,y:657,t:1528139635412};\\\", \\\"{x:228,y:661,t:1528139635428};\\\", \\\"{x:241,y:668,t:1528139635445};\\\", \\\"{x:252,y:671,t:1528139635462};\\\", \\\"{x:267,y:675,t:1528139635478};\\\", \\\"{x:279,y:681,t:1528139635496};\\\", \\\"{x:292,y:686,t:1528139635511};\\\", \\\"{x:298,y:691,t:1528139635528};\\\", \\\"{x:313,y:698,t:1528139635546};\\\", \\\"{x:319,y:700,t:1528139635562};\\\", \\\"{x:332,y:707,t:1528139635579};\\\", \\\"{x:338,y:709,t:1528139635595};\\\", \\\"{x:346,y:711,t:1528139635611};\\\", \\\"{x:350,y:713,t:1528139635628};\\\", \\\"{x:354,y:716,t:1528139635645};\\\", \\\"{x:358,y:717,t:1528139635662};\\\", \\\"{x:359,y:717,t:1528139635679};\\\", \\\"{x:359,y:718,t:1528139635695};\\\", \\\"{x:359,y:719,t:1528139635712};\\\", \\\"{x:360,y:719,t:1528139635729};\\\", \\\"{x:361,y:720,t:1528139635803};\\\", \\\"{x:361,y:722,t:1528139635851};\\\", \\\"{x:362,y:722,t:1528139635863};\\\", \\\"{x:362,y:724,t:1528139635879};\\\", \\\"{x:362,y:725,t:1528139635896};\\\", \\\"{x:362,y:727,t:1528139635913};\\\", \\\"{x:362,y:729,t:1528139635929};\\\", \\\"{x:362,y:730,t:1528139635946};\\\", \\\"{x:362,y:732,t:1528139635962};\\\", \\\"{x:363,y:734,t:1528139635980};\\\", \\\"{x:364,y:736,t:1528139635996};\\\", \\\"{x:364,y:738,t:1528139636013};\\\", \\\"{x:364,y:741,t:1528139636030};\\\", \\\"{x:364,y:743,t:1528139636046};\\\", \\\"{x:366,y:745,t:1528139636063};\\\", \\\"{x:367,y:746,t:1528139636082};\\\", \\\"{x:367,y:747,t:1528139636095};\\\", \\\"{x:368,y:748,t:1528139636112};\\\", \\\"{x:369,y:750,t:1528139636130};\\\", \\\"{x:369,y:751,t:1528139636161};\\\", \\\"{x:369,y:752,t:1528139636178};\\\", \\\"{x:370,y:753,t:1528139636194};\\\", \\\"{x:371,y:754,t:1528139636226};\\\", \\\"{x:372,y:754,t:1528139636233};\\\", \\\"{x:372,y:755,t:1528139636246};\\\", \\\"{x:375,y:758,t:1528139636263};\\\", \\\"{x:377,y:760,t:1528139636279};\\\", \\\"{x:378,y:760,t:1528139636296};\\\", \\\"{x:380,y:761,t:1528139636313};\\\", \\\"{x:384,y:765,t:1528139636330};\\\", \\\"{x:389,y:767,t:1528139636346};\\\", \\\"{x:394,y:771,t:1528139636362};\\\", \\\"{x:397,y:773,t:1528139636379};\\\", \\\"{x:401,y:775,t:1528139636397};\\\", \\\"{x:407,y:777,t:1528139636413};\\\", \\\"{x:414,y:779,t:1528139636430};\\\", \\\"{x:416,y:780,t:1528139636446};\\\", \\\"{x:418,y:781,t:1528139636462};\\\", \\\"{x:419,y:781,t:1528139636480};\\\", \\\"{x:420,y:782,t:1528139636497};\\\", \\\"{x:421,y:782,t:1528139637010};\\\", \\\"{x:422,y:782,t:1528139637026};\\\", \\\"{x:423,y:782,t:1528139637034};\\\", \\\"{x:424,y:782,t:1528139637047};\\\", \\\"{x:428,y:783,t:1528139637064};\\\", \\\"{x:434,y:783,t:1528139637081};\\\", \\\"{x:441,y:785,t:1528139637097};\\\", \\\"{x:450,y:787,t:1528139637114};\\\", \\\"{x:452,y:787,t:1528139637131};\\\", \\\"{x:453,y:787,t:1528139637147};\\\", \\\"{x:455,y:787,t:1528139637251};\\\", \\\"{x:456,y:787,t:1528139637274};\\\", \\\"{x:458,y:787,t:1528139637307};\\\", \\\"{x:459,y:787,t:1528139637315};\\\", \\\"{x:462,y:787,t:1528139637331};\\\", \\\"{x:467,y:787,t:1528139637348};\\\", \\\"{x:469,y:787,t:1528139637364};\\\", \\\"{x:468,y:787,t:1528139637381};\\\", \\\"{x:468,y:786,t:1528139637483};\\\", \\\"{x:474,y:779,t:1528139637498};\\\", \\\"{x:475,y:777,t:1528139637514};\\\", \\\"{x:477,y:776,t:1528139637539};\\\", \\\"{x:477,y:775,t:1528139637548};\\\", \\\"{x:478,y:773,t:1528139637565};\\\", \\\"{x:478,y:772,t:1528139637581};\\\", \\\"{x:480,y:769,t:1528139637599};\\\", \\\"{x:482,y:764,t:1528139637615};\\\", \\\"{x:483,y:762,t:1528139637633};\\\", \\\"{x:483,y:761,t:1528139637650};\\\", \\\"{x:484,y:760,t:1528139637681};\\\", \\\"{x:485,y:759,t:1528139637778};\\\" ] }, { \\\"rt\\\": 21532, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 601061, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -K -D -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:758,t:1528139642674};\\\", \\\"{x:485,y:757,t:1528139642754};\\\", \\\"{x:485,y:755,t:1528139642882};\\\", \\\"{x:485,y:754,t:1528139642889};\\\", \\\"{x:491,y:753,t:1528139642902};\\\", \\\"{x:495,y:753,t:1528139642918};\\\", \\\"{x:501,y:755,t:1528139642934};\\\", \\\"{x:504,y:755,t:1528139642952};\\\", \\\"{x:506,y:755,t:1528139642968};\\\", \\\"{x:523,y:757,t:1528139642984};\\\", \\\"{x:549,y:763,t:1528139643002};\\\", \\\"{x:559,y:763,t:1528139643019};\\\", \\\"{x:566,y:763,t:1528139643036};\\\", \\\"{x:578,y:765,t:1528139643051};\\\", \\\"{x:584,y:765,t:1528139643069};\\\", \\\"{x:587,y:765,t:1528139643084};\\\", \\\"{x:591,y:765,t:1528139643101};\\\", \\\"{x:602,y:766,t:1528139643118};\\\", \\\"{x:615,y:766,t:1528139643135};\\\", \\\"{x:629,y:766,t:1528139643151};\\\", \\\"{x:638,y:766,t:1528139643168};\\\", \\\"{x:642,y:766,t:1528139643185};\\\", \\\"{x:647,y:766,t:1528139643201};\\\", \\\"{x:675,y:766,t:1528139643217};\\\", \\\"{x:690,y:766,t:1528139643235};\\\", \\\"{x:718,y:766,t:1528139643252};\\\", \\\"{x:753,y:766,t:1528139643267};\\\", \\\"{x:803,y:767,t:1528139643284};\\\", \\\"{x:844,y:774,t:1528139643302};\\\", \\\"{x:867,y:772,t:1528139643318};\\\", \\\"{x:883,y:772,t:1528139643334};\\\", \\\"{x:915,y:772,t:1528139643352};\\\", \\\"{x:951,y:772,t:1528139643367};\\\", \\\"{x:970,y:772,t:1528139643385};\\\", \\\"{x:1006,y:767,t:1528139643402};\\\", \\\"{x:1055,y:748,t:1528139643418};\\\", \\\"{x:1106,y:730,t:1528139643435};\\\", \\\"{x:1157,y:714,t:1528139643452};\\\", \\\"{x:1217,y:690,t:1528139643468};\\\", \\\"{x:1297,y:656,t:1528139643485};\\\", \\\"{x:1397,y:626,t:1528139643502};\\\", \\\"{x:1492,y:596,t:1528139643518};\\\", \\\"{x:1605,y:563,t:1528139643535};\\\", \\\"{x:1697,y:531,t:1528139643553};\\\", \\\"{x:1772,y:498,t:1528139643569};\\\", \\\"{x:1824,y:477,t:1528139643585};\\\", \\\"{x:1897,y:440,t:1528139643602};\\\", \\\"{x:1917,y:428,t:1528139643618};\\\", \\\"{x:1919,y:423,t:1528139643635};\\\", \\\"{x:1919,y:421,t:1528139643652};\\\", \\\"{x:1919,y:420,t:1528139643668};\\\", \\\"{x:1919,y:418,t:1528139643685};\\\", \\\"{x:1919,y:417,t:1528139643714};\\\", \\\"{x:1918,y:417,t:1528139643722};\\\", \\\"{x:1915,y:417,t:1528139643735};\\\", \\\"{x:1910,y:417,t:1528139643752};\\\", \\\"{x:1904,y:417,t:1528139643769};\\\", \\\"{x:1891,y:419,t:1528139643785};\\\", \\\"{x:1878,y:421,t:1528139643803};\\\", \\\"{x:1872,y:422,t:1528139643819};\\\", \\\"{x:1864,y:422,t:1528139643835};\\\", \\\"{x:1855,y:423,t:1528139643852};\\\", \\\"{x:1847,y:425,t:1528139643869};\\\", \\\"{x:1836,y:425,t:1528139643886};\\\", \\\"{x:1823,y:427,t:1528139643902};\\\", \\\"{x:1810,y:427,t:1528139643920};\\\", \\\"{x:1802,y:427,t:1528139643935};\\\", \\\"{x:1793,y:427,t:1528139643952};\\\", \\\"{x:1783,y:427,t:1528139643969};\\\", \\\"{x:1775,y:427,t:1528139643985};\\\", \\\"{x:1762,y:427,t:1528139644003};\\\", \\\"{x:1753,y:427,t:1528139644019};\\\", \\\"{x:1743,y:427,t:1528139644035};\\\", \\\"{x:1732,y:427,t:1528139644052};\\\", \\\"{x:1717,y:427,t:1528139644069};\\\", \\\"{x:1701,y:428,t:1528139644087};\\\", \\\"{x:1685,y:431,t:1528139644102};\\\", \\\"{x:1665,y:435,t:1528139644119};\\\", \\\"{x:1647,y:435,t:1528139644136};\\\", \\\"{x:1626,y:439,t:1528139644152};\\\", \\\"{x:1610,y:442,t:1528139644170};\\\", \\\"{x:1594,y:446,t:1528139644187};\\\", \\\"{x:1584,y:447,t:1528139644202};\\\", \\\"{x:1573,y:449,t:1528139644219};\\\", \\\"{x:1566,y:449,t:1528139644236};\\\", \\\"{x:1564,y:449,t:1528139644252};\\\", \\\"{x:1563,y:449,t:1528139644282};\\\", \\\"{x:1563,y:450,t:1528139644427};\\\", \\\"{x:1564,y:450,t:1528139644435};\\\", \\\"{x:1568,y:450,t:1528139644453};\\\", \\\"{x:1572,y:450,t:1528139644469};\\\", \\\"{x:1575,y:449,t:1528139644486};\\\", \\\"{x:1582,y:447,t:1528139644503};\\\", \\\"{x:1589,y:443,t:1528139644518};\\\", \\\"{x:1593,y:440,t:1528139644536};\\\", \\\"{x:1597,y:437,t:1528139644553};\\\", \\\"{x:1601,y:435,t:1528139644568};\\\", \\\"{x:1609,y:432,t:1528139644589};\\\", \\\"{x:1614,y:429,t:1528139644602};\\\", \\\"{x:1619,y:427,t:1528139644619};\\\", \\\"{x:1620,y:427,t:1528139644637};\\\", \\\"{x:1619,y:427,t:1528139645182};\\\", \\\"{x:1618,y:428,t:1528139645220};\\\", \\\"{x:1617,y:429,t:1528139647794};\\\", \\\"{x:1616,y:429,t:1528139647834};\\\", \\\"{x:1615,y:429,t:1528139647850};\\\", \\\"{x:1615,y:430,t:1528139647891};\\\", \\\"{x:1613,y:430,t:1528139647930};\\\", \\\"{x:1613,y:431,t:1528139647962};\\\", \\\"{x:1611,y:433,t:1528139647978};\\\", \\\"{x:1610,y:434,t:1528139648005};\\\", \\\"{x:1608,y:436,t:1528139648030};\\\", \\\"{x:1606,y:440,t:1528139648054};\\\", \\\"{x:1604,y:442,t:1528139648072};\\\", \\\"{x:1602,y:447,t:1528139648088};\\\", \\\"{x:1601,y:449,t:1528139648104};\\\", \\\"{x:1598,y:454,t:1528139648121};\\\", \\\"{x:1596,y:459,t:1528139648138};\\\", \\\"{x:1594,y:462,t:1528139648155};\\\", \\\"{x:1591,y:467,t:1528139648171};\\\", \\\"{x:1590,y:473,t:1528139648188};\\\", \\\"{x:1587,y:479,t:1528139648205};\\\", \\\"{x:1584,y:485,t:1528139648222};\\\", \\\"{x:1582,y:487,t:1528139648239};\\\", \\\"{x:1579,y:493,t:1528139648255};\\\", \\\"{x:1578,y:496,t:1528139648273};\\\", \\\"{x:1575,y:502,t:1528139648289};\\\", \\\"{x:1574,y:506,t:1528139648306};\\\", \\\"{x:1571,y:513,t:1528139648322};\\\", \\\"{x:1570,y:515,t:1528139648338};\\\", \\\"{x:1570,y:520,t:1528139648356};\\\", \\\"{x:1568,y:523,t:1528139648373};\\\", \\\"{x:1566,y:528,t:1528139648388};\\\", \\\"{x:1566,y:530,t:1528139648405};\\\", \\\"{x:1564,y:533,t:1528139648422};\\\", \\\"{x:1563,y:539,t:1528139648438};\\\", \\\"{x:1559,y:548,t:1528139648456};\\\", \\\"{x:1558,y:556,t:1528139648472};\\\", \\\"{x:1554,y:564,t:1528139648488};\\\", \\\"{x:1551,y:571,t:1528139648505};\\\", \\\"{x:1547,y:578,t:1528139648522};\\\", \\\"{x:1546,y:581,t:1528139648539};\\\", \\\"{x:1545,y:584,t:1528139648556};\\\", \\\"{x:1543,y:586,t:1528139648573};\\\", \\\"{x:1543,y:587,t:1528139648590};\\\", \\\"{x:1542,y:588,t:1528139648606};\\\", \\\"{x:1542,y:589,t:1528139648622};\\\", \\\"{x:1542,y:590,t:1528139648639};\\\", \\\"{x:1540,y:592,t:1528139648655};\\\", \\\"{x:1540,y:593,t:1528139648672};\\\", \\\"{x:1539,y:594,t:1528139648698};\\\", \\\"{x:1539,y:595,t:1528139648714};\\\", \\\"{x:1536,y:598,t:1528139648738};\\\", \\\"{x:1536,y:599,t:1528139648762};\\\", \\\"{x:1535,y:600,t:1528139648778};\\\", \\\"{x:1534,y:601,t:1528139648827};\\\", \\\"{x:1533,y:602,t:1528139648897};\\\", \\\"{x:1533,y:603,t:1528139648922};\\\", \\\"{x:1532,y:605,t:1528139648938};\\\", \\\"{x:1530,y:606,t:1528139648978};\\\", \\\"{x:1530,y:607,t:1528139649002};\\\", \\\"{x:1529,y:609,t:1528139649025};\\\", \\\"{x:1528,y:610,t:1528139649042};\\\", \\\"{x:1528,y:611,t:1528139649056};\\\", \\\"{x:1527,y:612,t:1528139649072};\\\", \\\"{x:1526,y:612,t:1528139649089};\\\", \\\"{x:1526,y:613,t:1528139649121};\\\", \\\"{x:1526,y:614,t:1528139649145};\\\", \\\"{x:1525,y:615,t:1528139649178};\\\", \\\"{x:1525,y:616,t:1528139649210};\\\", \\\"{x:1525,y:617,t:1528139649226};\\\", \\\"{x:1524,y:617,t:1528139649242};\\\", \\\"{x:1523,y:618,t:1528139649257};\\\", \\\"{x:1523,y:620,t:1528139649272};\\\", \\\"{x:1521,y:622,t:1528139649290};\\\", \\\"{x:1520,y:623,t:1528139649314};\\\", \\\"{x:1520,y:624,t:1528139649363};\\\", \\\"{x:1519,y:625,t:1528139649386};\\\", \\\"{x:1518,y:626,t:1528139649404};\\\", \\\"{x:1517,y:627,t:1528139649422};\\\", \\\"{x:1516,y:627,t:1528139649498};\\\", \\\"{x:1514,y:628,t:1528139649530};\\\", \\\"{x:1514,y:629,t:1528139649561};\\\", \\\"{x:1514,y:626,t:1528139650105};\\\", \\\"{x:1520,y:618,t:1528139650114};\\\", \\\"{x:1525,y:612,t:1528139650123};\\\", \\\"{x:1537,y:596,t:1528139650140};\\\", \\\"{x:1549,y:577,t:1528139650157};\\\", \\\"{x:1559,y:560,t:1528139650173};\\\", \\\"{x:1565,y:552,t:1528139650190};\\\", \\\"{x:1569,y:543,t:1528139650207};\\\", \\\"{x:1574,y:533,t:1528139650223};\\\", \\\"{x:1578,y:527,t:1528139650240};\\\", \\\"{x:1585,y:516,t:1528139650258};\\\", \\\"{x:1586,y:515,t:1528139650273};\\\", \\\"{x:1588,y:512,t:1528139650290};\\\", \\\"{x:1590,y:510,t:1528139650323};\\\", \\\"{x:1590,y:509,t:1528139650330};\\\", \\\"{x:1590,y:507,t:1528139650341};\\\", \\\"{x:1591,y:503,t:1528139650357};\\\", \\\"{x:1594,y:494,t:1528139650374};\\\", \\\"{x:1597,y:486,t:1528139650390};\\\", \\\"{x:1602,y:477,t:1528139650408};\\\", \\\"{x:1606,y:470,t:1528139650425};\\\", \\\"{x:1609,y:464,t:1528139650441};\\\", \\\"{x:1611,y:457,t:1528139650459};\\\", \\\"{x:1614,y:453,t:1528139650475};\\\", \\\"{x:1615,y:448,t:1528139650490};\\\", \\\"{x:1616,y:446,t:1528139650508};\\\", \\\"{x:1617,y:444,t:1528139650524};\\\", \\\"{x:1617,y:443,t:1528139650541};\\\", \\\"{x:1618,y:443,t:1528139650558};\\\", \\\"{x:1618,y:440,t:1528139650575};\\\", \\\"{x:1618,y:439,t:1528139650618};\\\", \\\"{x:1618,y:438,t:1528139650626};\\\", \\\"{x:1618,y:437,t:1528139650666};\\\", \\\"{x:1618,y:436,t:1528139650674};\\\", \\\"{x:1620,y:434,t:1528139650691};\\\", \\\"{x:1620,y:433,t:1528139650779};\\\", \\\"{x:1619,y:432,t:1528139650798};\\\", \\\"{x:1619,y:431,t:1528139650824};\\\", \\\"{x:1619,y:430,t:1528139650857};\\\", \\\"{x:1619,y:429,t:1528139650889};\\\", \\\"{x:1618,y:429,t:1528139653275};\\\", \\\"{x:1615,y:432,t:1528139653282};\\\", \\\"{x:1612,y:441,t:1528139653295};\\\", \\\"{x:1609,y:449,t:1528139653309};\\\", \\\"{x:1605,y:462,t:1528139653326};\\\", \\\"{x:1602,y:473,t:1528139653342};\\\", \\\"{x:1597,y:488,t:1528139653359};\\\", \\\"{x:1596,y:498,t:1528139653376};\\\", \\\"{x:1592,y:505,t:1528139653392};\\\", \\\"{x:1591,y:512,t:1528139653409};\\\", \\\"{x:1588,y:518,t:1528139653425};\\\", \\\"{x:1585,y:526,t:1528139653442};\\\", \\\"{x:1581,y:534,t:1528139653459};\\\", \\\"{x:1577,y:542,t:1528139653476};\\\", \\\"{x:1572,y:554,t:1528139653492};\\\", \\\"{x:1565,y:565,t:1528139653509};\\\", \\\"{x:1561,y:572,t:1528139653526};\\\", \\\"{x:1558,y:577,t:1528139653543};\\\", \\\"{x:1557,y:580,t:1528139653559};\\\", \\\"{x:1555,y:584,t:1528139653576};\\\", \\\"{x:1553,y:587,t:1528139653593};\\\", \\\"{x:1552,y:590,t:1528139653610};\\\", \\\"{x:1549,y:595,t:1528139653626};\\\", \\\"{x:1546,y:598,t:1528139653643};\\\", \\\"{x:1543,y:603,t:1528139653660};\\\", \\\"{x:1541,y:606,t:1528139653676};\\\", \\\"{x:1540,y:607,t:1528139653693};\\\", \\\"{x:1537,y:610,t:1528139653710};\\\", \\\"{x:1533,y:613,t:1528139653726};\\\", \\\"{x:1530,y:616,t:1528139653743};\\\", \\\"{x:1527,y:617,t:1528139653760};\\\", \\\"{x:1526,y:618,t:1528139653777};\\\", \\\"{x:1525,y:620,t:1528139653793};\\\", \\\"{x:1521,y:621,t:1528139653810};\\\", \\\"{x:1520,y:623,t:1528139653827};\\\", \\\"{x:1517,y:624,t:1528139653843};\\\", \\\"{x:1516,y:625,t:1528139653894};\\\", \\\"{x:1516,y:626,t:1528139653977};\\\", \\\"{x:1515,y:626,t:1528139654001};\\\", \\\"{x:1515,y:627,t:1528139654025};\\\", \\\"{x:1514,y:627,t:1528139654251};\\\", \\\"{x:1513,y:629,t:1528139654290};\\\", \\\"{x:1512,y:629,t:1528139654322};\\\", \\\"{x:1512,y:630,t:1528139654338};\\\", \\\"{x:1511,y:630,t:1528139654362};\\\", \\\"{x:1510,y:631,t:1528139654377};\\\", \\\"{x:1510,y:632,t:1528139654402};\\\", \\\"{x:1509,y:632,t:1528139654410};\\\", \\\"{x:1508,y:632,t:1528139654453};\\\", \\\"{x:1508,y:633,t:1528139654489};\\\", \\\"{x:1507,y:633,t:1528139654530};\\\", \\\"{x:1506,y:633,t:1528139654553};\\\", \\\"{x:1506,y:632,t:1528139654907};\\\", \\\"{x:1506,y:631,t:1528139654923};\\\", \\\"{x:1507,y:630,t:1528139654930};\\\", \\\"{x:1507,y:629,t:1528139654947};\\\", \\\"{x:1507,y:628,t:1528139655074};\\\", \\\"{x:1507,y:626,t:1528139655227};\\\", \\\"{x:1496,y:626,t:1528139655245};\\\", \\\"{x:1473,y:626,t:1528139655262};\\\", \\\"{x:1410,y:617,t:1528139655278};\\\", \\\"{x:1321,y:616,t:1528139655295};\\\", \\\"{x:1205,y:605,t:1528139655312};\\\", \\\"{x:1082,y:595,t:1528139655328};\\\", \\\"{x:954,y:574,t:1528139655344};\\\", \\\"{x:762,y:549,t:1528139655364};\\\", \\\"{x:656,y:533,t:1528139655378};\\\", \\\"{x:562,y:522,t:1528139655394};\\\", \\\"{x:490,y:513,t:1528139655411};\\\", \\\"{x:449,y:509,t:1528139655427};\\\", \\\"{x:433,y:507,t:1528139655444};\\\", \\\"{x:425,y:507,t:1528139655461};\\\", \\\"{x:424,y:507,t:1528139655521};\\\", \\\"{x:423,y:507,t:1528139655674};\\\", \\\"{x:421,y:507,t:1528139655730};\\\", \\\"{x:418,y:507,t:1528139655745};\\\", \\\"{x:411,y:507,t:1528139655762};\\\", \\\"{x:403,y:510,t:1528139655778};\\\", \\\"{x:391,y:523,t:1528139655794};\\\", \\\"{x:379,y:537,t:1528139655812};\\\", \\\"{x:367,y:553,t:1528139655830};\\\", \\\"{x:360,y:561,t:1528139655844};\\\", \\\"{x:359,y:563,t:1528139655862};\\\", \\\"{x:359,y:564,t:1528139655889};\\\", \\\"{x:359,y:566,t:1528139655897};\\\", \\\"{x:359,y:567,t:1528139655913};\\\", \\\"{x:359,y:569,t:1528139655928};\\\", \\\"{x:359,y:574,t:1528139655945};\\\", \\\"{x:364,y:580,t:1528139655962};\\\", \\\"{x:366,y:583,t:1528139655978};\\\", \\\"{x:369,y:585,t:1528139655995};\\\", \\\"{x:371,y:585,t:1528139656011};\\\", \\\"{x:373,y:585,t:1528139656028};\\\", \\\"{x:374,y:585,t:1528139656045};\\\", \\\"{x:376,y:585,t:1528139656074};\\\", \\\"{x:377,y:585,t:1528139656097};\\\", \\\"{x:380,y:585,t:1528139656112};\\\", \\\"{x:382,y:585,t:1528139656129};\\\", \\\"{x:387,y:585,t:1528139656146};\\\", \\\"{x:396,y:585,t:1528139656161};\\\", \\\"{x:413,y:586,t:1528139656178};\\\", \\\"{x:428,y:587,t:1528139656196};\\\", \\\"{x:446,y:591,t:1528139656212};\\\", \\\"{x:460,y:595,t:1528139656229};\\\", \\\"{x:480,y:598,t:1528139656245};\\\", \\\"{x:503,y:602,t:1528139656262};\\\", \\\"{x:523,y:606,t:1528139656278};\\\", \\\"{x:541,y:611,t:1528139656295};\\\", \\\"{x:558,y:616,t:1528139656311};\\\", \\\"{x:570,y:621,t:1528139656329};\\\", \\\"{x:588,y:627,t:1528139656345};\\\", \\\"{x:597,y:629,t:1528139656361};\\\", \\\"{x:606,y:632,t:1528139656378};\\\", \\\"{x:611,y:632,t:1528139656396};\\\", \\\"{x:615,y:634,t:1528139656411};\\\", \\\"{x:616,y:635,t:1528139656428};\\\", \\\"{x:617,y:635,t:1528139656482};\\\", \\\"{x:617,y:636,t:1528139656530};\\\", \\\"{x:614,y:639,t:1528139656545};\\\", \\\"{x:606,y:644,t:1528139656562};\\\", \\\"{x:592,y:652,t:1528139656580};\\\", \\\"{x:570,y:659,t:1528139656596};\\\", \\\"{x:540,y:660,t:1528139656612};\\\", \\\"{x:502,y:660,t:1528139656629};\\\", \\\"{x:474,y:659,t:1528139656646};\\\", \\\"{x:443,y:650,t:1528139656662};\\\", \\\"{x:395,y:643,t:1528139656679};\\\", \\\"{x:355,y:632,t:1528139656695};\\\", \\\"{x:314,y:628,t:1528139656712};\\\", \\\"{x:285,y:620,t:1528139656728};\\\", \\\"{x:252,y:612,t:1528139656745};\\\", \\\"{x:238,y:608,t:1528139656763};\\\", \\\"{x:231,y:606,t:1528139656778};\\\", \\\"{x:225,y:603,t:1528139656795};\\\", \\\"{x:222,y:603,t:1528139656812};\\\", \\\"{x:222,y:602,t:1528139656829};\\\", \\\"{x:221,y:602,t:1528139656849};\\\", \\\"{x:219,y:602,t:1528139656881};\\\", \\\"{x:219,y:601,t:1528139656897};\\\", \\\"{x:219,y:600,t:1528139656913};\\\", \\\"{x:218,y:600,t:1528139656929};\\\", \\\"{x:215,y:598,t:1528139656945};\\\", \\\"{x:214,y:598,t:1528139656963};\\\", \\\"{x:213,y:598,t:1528139656986};\\\", \\\"{x:212,y:598,t:1528139657002};\\\", \\\"{x:211,y:598,t:1528139657012};\\\", \\\"{x:210,y:598,t:1528139657030};\\\", \\\"{x:209,y:601,t:1528139657045};\\\", \\\"{x:209,y:603,t:1528139657062};\\\", \\\"{x:211,y:604,t:1528139657080};\\\", \\\"{x:216,y:604,t:1528139657095};\\\", \\\"{x:226,y:604,t:1528139657112};\\\", \\\"{x:258,y:604,t:1528139657130};\\\", \\\"{x:286,y:605,t:1528139657147};\\\", \\\"{x:316,y:606,t:1528139657163};\\\", \\\"{x:342,y:607,t:1528139657179};\\\", \\\"{x:359,y:609,t:1528139657195};\\\", \\\"{x:370,y:611,t:1528139657213};\\\", \\\"{x:371,y:613,t:1528139657230};\\\", \\\"{x:371,y:614,t:1528139657245};\\\", \\\"{x:372,y:614,t:1528139657354};\\\", \\\"{x:373,y:616,t:1528139657362};\\\", \\\"{x:375,y:619,t:1528139657381};\\\", \\\"{x:377,y:621,t:1528139657396};\\\", \\\"{x:378,y:623,t:1528139657413};\\\", \\\"{x:381,y:626,t:1528139657430};\\\", \\\"{x:382,y:627,t:1528139657446};\\\", \\\"{x:382,y:628,t:1528139657481};\\\", \\\"{x:383,y:629,t:1528139657498};\\\", \\\"{x:384,y:631,t:1528139657512};\\\", \\\"{x:384,y:633,t:1528139657529};\\\", \\\"{x:385,y:634,t:1528139657562};\\\", \\\"{x:385,y:635,t:1528139657707};\\\", \\\"{x:385,y:636,t:1528139657730};\\\", \\\"{x:386,y:636,t:1528139657778};\\\", \\\"{x:386,y:637,t:1528139657858};\\\", \\\"{x:386,y:638,t:1528139660083};\\\", \\\"{x:388,y:640,t:1528139660098};\\\", \\\"{x:392,y:644,t:1528139660115};\\\", \\\"{x:397,y:648,t:1528139660133};\\\", \\\"{x:405,y:656,t:1528139660149};\\\", \\\"{x:431,y:674,t:1528139660181};\\\", \\\"{x:441,y:681,t:1528139660198};\\\", \\\"{x:449,y:687,t:1528139660215};\\\", \\\"{x:459,y:694,t:1528139660231};\\\", \\\"{x:463,y:697,t:1528139660248};\\\", \\\"{x:468,y:701,t:1528139660264};\\\", \\\"{x:470,y:703,t:1528139660285};\\\", \\\"{x:472,y:705,t:1528139660302};\\\", \\\"{x:473,y:707,t:1528139660318};\\\", \\\"{x:475,y:710,t:1528139660335};\\\", \\\"{x:477,y:711,t:1528139660352};\\\", \\\"{x:478,y:713,t:1528139660369};\\\", \\\"{x:480,y:716,t:1528139660385};\\\", \\\"{x:482,y:718,t:1528139660403};\\\", \\\"{x:485,y:721,t:1528139660419};\\\", \\\"{x:489,y:724,t:1528139660435};\\\", \\\"{x:493,y:728,t:1528139660452};\\\", \\\"{x:497,y:731,t:1528139660469};\\\", \\\"{x:498,y:732,t:1528139660486};\\\", \\\"{x:501,y:734,t:1528139660502};\\\", \\\"{x:503,y:735,t:1528139660519};\\\", \\\"{x:503,y:736,t:1528139660536};\\\", \\\"{x:504,y:736,t:1528139660552};\\\", \\\"{x:505,y:737,t:1528139660575};\\\", \\\"{x:506,y:737,t:1528139660589};\\\", \\\"{x:507,y:738,t:1528139660613};\\\", \\\"{x:507,y:739,t:1528139660628};\\\", \\\"{x:508,y:740,t:1528139660637};\\\", \\\"{x:509,y:742,t:1528139660653};\\\", \\\"{x:510,y:742,t:1528139660669};\\\", \\\"{x:510,y:743,t:1528139660685};\\\", \\\"{x:510,y:745,t:1528139660702};\\\", \\\"{x:511,y:745,t:1528139660719};\\\", \\\"{x:511,y:747,t:1528139660735};\\\", \\\"{x:513,y:749,t:1528139660752};\\\", \\\"{x:513,y:750,t:1528139660769};\\\", \\\"{x:514,y:752,t:1528139660785};\\\" ] }, { \\\"rt\\\": 14921, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 617309, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:752,t:1528139663430};\\\", \\\"{x:512,y:752,t:1528139663438};\\\", \\\"{x:512,y:751,t:1528139663477};\\\", \\\"{x:512,y:750,t:1528139663488};\\\", \\\"{x:512,y:748,t:1528139663504};\\\", \\\"{x:513,y:748,t:1528139663522};\\\", \\\"{x:518,y:744,t:1528139663537};\\\", \\\"{x:524,y:741,t:1528139663554};\\\", \\\"{x:528,y:739,t:1528139663572};\\\", \\\"{x:533,y:738,t:1528139663588};\\\", \\\"{x:540,y:735,t:1528139663605};\\\", \\\"{x:541,y:735,t:1528139663622};\\\", \\\"{x:544,y:733,t:1528139663639};\\\", \\\"{x:548,y:732,t:1528139663654};\\\", \\\"{x:553,y:729,t:1528139663672};\\\", \\\"{x:559,y:726,t:1528139663689};\\\", \\\"{x:567,y:723,t:1528139663705};\\\", \\\"{x:578,y:722,t:1528139663722};\\\", \\\"{x:594,y:722,t:1528139663739};\\\", \\\"{x:618,y:722,t:1528139663755};\\\", \\\"{x:640,y:722,t:1528139663772};\\\", \\\"{x:664,y:722,t:1528139663788};\\\", \\\"{x:707,y:722,t:1528139663805};\\\", \\\"{x:769,y:722,t:1528139663822};\\\", \\\"{x:808,y:722,t:1528139663839};\\\", \\\"{x:839,y:722,t:1528139663854};\\\", \\\"{x:872,y:722,t:1528139663871};\\\", \\\"{x:908,y:723,t:1528139663888};\\\", \\\"{x:950,y:730,t:1528139663904};\\\", \\\"{x:982,y:735,t:1528139663921};\\\", \\\"{x:1003,y:737,t:1528139663939};\\\", \\\"{x:1018,y:739,t:1528139663954};\\\", \\\"{x:1030,y:740,t:1528139663971};\\\", \\\"{x:1039,y:742,t:1528139663988};\\\", \\\"{x:1042,y:744,t:1528139664004};\\\", \\\"{x:1043,y:744,t:1528139664150};\\\", \\\"{x:1042,y:745,t:1528139664207};\\\", \\\"{x:1041,y:745,t:1528139664263};\\\", \\\"{x:1039,y:745,t:1528139664302};\\\", \\\"{x:1038,y:745,t:1528139664525};\\\", \\\"{x:1040,y:742,t:1528139665238};\\\", \\\"{x:1049,y:738,t:1528139665246};\\\", \\\"{x:1053,y:738,t:1528139665256};\\\", \\\"{x:1059,y:734,t:1528139665273};\\\", \\\"{x:1064,y:733,t:1528139665290};\\\", \\\"{x:1063,y:733,t:1528139665838};\\\", \\\"{x:1060,y:733,t:1528139665854};\\\", \\\"{x:1059,y:733,t:1528139665861};\\\", \\\"{x:1056,y:733,t:1528139665874};\\\", \\\"{x:1052,y:733,t:1528139665890};\\\", \\\"{x:1048,y:733,t:1528139665907};\\\", \\\"{x:1042,y:733,t:1528139665924};\\\", \\\"{x:1037,y:733,t:1528139665940};\\\", \\\"{x:1029,y:733,t:1528139665958};\\\", \\\"{x:1014,y:733,t:1528139665974};\\\", \\\"{x:1007,y:733,t:1528139665990};\\\", \\\"{x:1002,y:733,t:1528139666007};\\\", \\\"{x:998,y:733,t:1528139666024};\\\", \\\"{x:995,y:732,t:1528139666040};\\\", \\\"{x:994,y:731,t:1528139666057};\\\", \\\"{x:993,y:731,t:1528139666074};\\\", \\\"{x:995,y:731,t:1528139666422};\\\", \\\"{x:996,y:731,t:1528139666430};\\\", \\\"{x:997,y:731,t:1528139666441};\\\", \\\"{x:1005,y:739,t:1528139666458};\\\", \\\"{x:1009,y:742,t:1528139666474};\\\", \\\"{x:1018,y:748,t:1528139666491};\\\", \\\"{x:1029,y:755,t:1528139666508};\\\", \\\"{x:1041,y:760,t:1528139666524};\\\", \\\"{x:1050,y:760,t:1528139666541};\\\", \\\"{x:1058,y:761,t:1528139666558};\\\", \\\"{x:1079,y:770,t:1528139666575};\\\", \\\"{x:1089,y:776,t:1528139666591};\\\", \\\"{x:1106,y:780,t:1528139666608};\\\", \\\"{x:1121,y:783,t:1528139666624};\\\", \\\"{x:1130,y:786,t:1528139666641};\\\", \\\"{x:1142,y:792,t:1528139666657};\\\", \\\"{x:1147,y:795,t:1528139666673};\\\", \\\"{x:1152,y:801,t:1528139666692};\\\", \\\"{x:1162,y:808,t:1528139666708};\\\", \\\"{x:1170,y:811,t:1528139666724};\\\", \\\"{x:1175,y:813,t:1528139666741};\\\", \\\"{x:1177,y:815,t:1528139666758};\\\", \\\"{x:1178,y:817,t:1528139666774};\\\", \\\"{x:1180,y:819,t:1528139666792};\\\", \\\"{x:1180,y:820,t:1528139666808};\\\", \\\"{x:1181,y:821,t:1528139666824};\\\", \\\"{x:1182,y:822,t:1528139666854};\\\", \\\"{x:1183,y:823,t:1528139666862};\\\", \\\"{x:1184,y:824,t:1528139666874};\\\", \\\"{x:1185,y:824,t:1528139666973};\\\", \\\"{x:1187,y:824,t:1528139666990};\\\", \\\"{x:1191,y:824,t:1528139667008};\\\", \\\"{x:1194,y:824,t:1528139667024};\\\", \\\"{x:1195,y:824,t:1528139667041};\\\", \\\"{x:1196,y:824,t:1528139667101};\\\", \\\"{x:1197,y:823,t:1528139667117};\\\", \\\"{x:1199,y:823,t:1528139667141};\\\", \\\"{x:1201,y:823,t:1528139667206};\\\", \\\"{x:1201,y:824,t:1528139667214};\\\", \\\"{x:1204,y:825,t:1528139667225};\\\", \\\"{x:1205,y:825,t:1528139667246};\\\", \\\"{x:1206,y:826,t:1528139667258};\\\", \\\"{x:1210,y:826,t:1528139667286};\\\", \\\"{x:1212,y:827,t:1528139667308};\\\", \\\"{x:1213,y:827,t:1528139667324};\\\", \\\"{x:1214,y:827,t:1528139667372};\\\", \\\"{x:1215,y:827,t:1528139667541};\\\", \\\"{x:1216,y:827,t:1528139667558};\\\", \\\"{x:1217,y:827,t:1528139669454};\\\", \\\"{x:1218,y:827,t:1528139670646};\\\", \\\"{x:1219,y:828,t:1528139670660};\\\", \\\"{x:1220,y:831,t:1528139670677};\\\", \\\"{x:1220,y:833,t:1528139670697};\\\", \\\"{x:1221,y:835,t:1528139670712};\\\", \\\"{x:1221,y:840,t:1528139670726};\\\", \\\"{x:1222,y:843,t:1528139670744};\\\", \\\"{x:1224,y:847,t:1528139670761};\\\", \\\"{x:1224,y:850,t:1528139670777};\\\", \\\"{x:1226,y:853,t:1528139670794};\\\", \\\"{x:1227,y:857,t:1528139670810};\\\", \\\"{x:1228,y:862,t:1528139670827};\\\", \\\"{x:1230,y:866,t:1528139670844};\\\", \\\"{x:1230,y:873,t:1528139670861};\\\", \\\"{x:1236,y:883,t:1528139670878};\\\", \\\"{x:1236,y:887,t:1528139670894};\\\", \\\"{x:1237,y:894,t:1528139670911};\\\", \\\"{x:1239,y:898,t:1528139670927};\\\", \\\"{x:1242,y:904,t:1528139670944};\\\", \\\"{x:1244,y:906,t:1528139670961};\\\", \\\"{x:1244,y:908,t:1528139670977};\\\", \\\"{x:1246,y:912,t:1528139671014};\\\", \\\"{x:1246,y:913,t:1528139671038};\\\", \\\"{x:1248,y:914,t:1528139671070};\\\", \\\"{x:1252,y:913,t:1528139671230};\\\", \\\"{x:1252,y:912,t:1528139671246};\\\", \\\"{x:1255,y:910,t:1528139671262};\\\", \\\"{x:1260,y:908,t:1528139671279};\\\", \\\"{x:1264,y:905,t:1528139671294};\\\", \\\"{x:1272,y:902,t:1528139671311};\\\", \\\"{x:1281,y:897,t:1528139671328};\\\", \\\"{x:1286,y:893,t:1528139671345};\\\", \\\"{x:1291,y:892,t:1528139671362};\\\", \\\"{x:1295,y:889,t:1528139671378};\\\", \\\"{x:1299,y:887,t:1528139671394};\\\", \\\"{x:1301,y:885,t:1528139671411};\\\", \\\"{x:1304,y:881,t:1528139671429};\\\", \\\"{x:1307,y:879,t:1528139671445};\\\", \\\"{x:1312,y:875,t:1528139671462};\\\", \\\"{x:1314,y:871,t:1528139671478};\\\", \\\"{x:1317,y:867,t:1528139671495};\\\", \\\"{x:1319,y:865,t:1528139671512};\\\", \\\"{x:1322,y:862,t:1528139671529};\\\", \\\"{x:1323,y:862,t:1528139671546};\\\", \\\"{x:1325,y:860,t:1528139671562};\\\", \\\"{x:1326,y:859,t:1528139671578};\\\", \\\"{x:1328,y:856,t:1528139671595};\\\", \\\"{x:1331,y:853,t:1528139671612};\\\", \\\"{x:1332,y:850,t:1528139671628};\\\", \\\"{x:1335,y:847,t:1528139671646};\\\", \\\"{x:1339,y:842,t:1528139671662};\\\", \\\"{x:1342,y:837,t:1528139671680};\\\", \\\"{x:1346,y:831,t:1528139671695};\\\", \\\"{x:1351,y:825,t:1528139671712};\\\", \\\"{x:1354,y:822,t:1528139671728};\\\", \\\"{x:1356,y:819,t:1528139671745};\\\", \\\"{x:1358,y:818,t:1528139671762};\\\", \\\"{x:1359,y:816,t:1528139671779};\\\", \\\"{x:1359,y:814,t:1528139671795};\\\", \\\"{x:1361,y:813,t:1528139671811};\\\", \\\"{x:1362,y:809,t:1528139671829};\\\", \\\"{x:1365,y:805,t:1528139671845};\\\", \\\"{x:1367,y:804,t:1528139671862};\\\", \\\"{x:1367,y:802,t:1528139671878};\\\", \\\"{x:1368,y:801,t:1528139671896};\\\", \\\"{x:1368,y:800,t:1528139671912};\\\", \\\"{x:1369,y:798,t:1528139671928};\\\", \\\"{x:1369,y:796,t:1528139671945};\\\", \\\"{x:1371,y:794,t:1528139671963};\\\", \\\"{x:1372,y:791,t:1528139671979};\\\", \\\"{x:1373,y:789,t:1528139671995};\\\", \\\"{x:1373,y:788,t:1528139672012};\\\", \\\"{x:1373,y:786,t:1528139672029};\\\", \\\"{x:1375,y:782,t:1528139672046};\\\", \\\"{x:1376,y:781,t:1528139672062};\\\", \\\"{x:1377,y:776,t:1528139672080};\\\", \\\"{x:1379,y:772,t:1528139672096};\\\", \\\"{x:1380,y:769,t:1528139672112};\\\", \\\"{x:1382,y:767,t:1528139672133};\\\", \\\"{x:1382,y:765,t:1528139672162};\\\", \\\"{x:1382,y:764,t:1528139672221};\\\", \\\"{x:1383,y:763,t:1528139672438};\\\", \\\"{x:1381,y:763,t:1528139673518};\\\", \\\"{x:1372,y:763,t:1528139673531};\\\", \\\"{x:1342,y:757,t:1528139673546};\\\", \\\"{x:1286,y:747,t:1528139673563};\\\", \\\"{x:1199,y:730,t:1528139673580};\\\", \\\"{x:1093,y:712,t:1528139673596};\\\", \\\"{x:894,y:676,t:1528139673613};\\\", \\\"{x:763,y:651,t:1528139673630};\\\", \\\"{x:628,y:614,t:1528139673646};\\\", \\\"{x:494,y:591,t:1528139673664};\\\", \\\"{x:373,y:564,t:1528139673681};\\\", \\\"{x:256,y:541,t:1528139673696};\\\", \\\"{x:161,y:524,t:1528139673712};\\\", \\\"{x:91,y:515,t:1528139673729};\\\", \\\"{x:38,y:506,t:1528139673746};\\\", \\\"{x:0,y:499,t:1528139673763};\\\", \\\"{x:0,y:496,t:1528139673780};\\\", \\\"{x:0,y:495,t:1528139673796};\\\", \\\"{x:0,y:494,t:1528139673813};\\\", \\\"{x:0,y:504,t:1528139673990};\\\", \\\"{x:2,y:511,t:1528139673998};\\\", \\\"{x:4,y:518,t:1528139674014};\\\", \\\"{x:14,y:541,t:1528139674030};\\\", \\\"{x:21,y:553,t:1528139674047};\\\", \\\"{x:32,y:568,t:1528139674063};\\\", \\\"{x:42,y:579,t:1528139674080};\\\", \\\"{x:45,y:580,t:1528139674097};\\\", \\\"{x:54,y:583,t:1528139674115};\\\", \\\"{x:68,y:595,t:1528139674130};\\\", \\\"{x:80,y:602,t:1528139674146};\\\", \\\"{x:91,y:608,t:1528139674162};\\\", \\\"{x:102,y:610,t:1528139674179};\\\", \\\"{x:117,y:613,t:1528139674197};\\\", \\\"{x:128,y:617,t:1528139674211};\\\", \\\"{x:147,y:623,t:1528139674231};\\\", \\\"{x:159,y:625,t:1528139674247};\\\", \\\"{x:170,y:625,t:1528139674263};\\\", \\\"{x:180,y:625,t:1528139674280};\\\", \\\"{x:188,y:623,t:1528139674297};\\\", \\\"{x:195,y:622,t:1528139674313};\\\", \\\"{x:205,y:620,t:1528139674330};\\\", \\\"{x:213,y:618,t:1528139674347};\\\", \\\"{x:214,y:618,t:1528139674363};\\\", \\\"{x:215,y:618,t:1528139674380};\\\", \\\"{x:224,y:617,t:1528139674397};\\\", \\\"{x:228,y:617,t:1528139674413};\\\", \\\"{x:234,y:616,t:1528139674430};\\\", \\\"{x:244,y:616,t:1528139674447};\\\", \\\"{x:262,y:616,t:1528139674463};\\\", \\\"{x:281,y:616,t:1528139674480};\\\", \\\"{x:298,y:616,t:1528139674497};\\\", \\\"{x:314,y:616,t:1528139674513};\\\", \\\"{x:333,y:614,t:1528139674530};\\\", \\\"{x:343,y:614,t:1528139674547};\\\", \\\"{x:354,y:614,t:1528139674564};\\\", \\\"{x:360,y:613,t:1528139674580};\\\", \\\"{x:366,y:613,t:1528139674597};\\\", \\\"{x:367,y:613,t:1528139674614};\\\", \\\"{x:369,y:613,t:1528139674654};\\\", \\\"{x:371,y:613,t:1528139674678};\\\", \\\"{x:371,y:612,t:1528139674686};\\\", \\\"{x:372,y:611,t:1528139674700};\\\", \\\"{x:373,y:610,t:1528139674717};\\\", \\\"{x:375,y:610,t:1528139674748};\\\", \\\"{x:376,y:610,t:1528139674765};\\\", \\\"{x:377,y:609,t:1528139674781};\\\", \\\"{x:378,y:608,t:1528139674797};\\\", \\\"{x:379,y:608,t:1528139674814};\\\", \\\"{x:379,y:607,t:1528139674830};\\\", \\\"{x:380,y:606,t:1528139674910};\\\", \\\"{x:381,y:603,t:1528139675478};\\\", \\\"{x:381,y:601,t:1528139675494};\\\", \\\"{x:381,y:600,t:1528139675502};\\\", \\\"{x:383,y:598,t:1528139675514};\\\", \\\"{x:383,y:597,t:1528139675532};\\\", \\\"{x:383,y:595,t:1528139675548};\\\", \\\"{x:384,y:593,t:1528139675566};\\\", \\\"{x:388,y:600,t:1528139676286};\\\", \\\"{x:395,y:610,t:1528139676299};\\\", \\\"{x:408,y:626,t:1528139676316};\\\", \\\"{x:420,y:643,t:1528139676333};\\\", \\\"{x:436,y:656,t:1528139676348};\\\", \\\"{x:459,y:675,t:1528139676365};\\\", \\\"{x:474,y:683,t:1528139676382};\\\", \\\"{x:485,y:691,t:1528139676398};\\\", \\\"{x:495,y:697,t:1528139676415};\\\", \\\"{x:503,y:704,t:1528139676432};\\\", \\\"{x:505,y:707,t:1528139676448};\\\", \\\"{x:506,y:709,t:1528139676465};\\\", \\\"{x:506,y:710,t:1528139676492};\\\", \\\"{x:507,y:711,t:1528139676501};\\\", \\\"{x:507,y:712,t:1528139676525};\\\", \\\"{x:507,y:713,t:1528139676533};\\\", \\\"{x:508,y:714,t:1528139676548};\\\", \\\"{x:509,y:718,t:1528139676565};\\\", \\\"{x:509,y:720,t:1528139676581};\\\", \\\"{x:509,y:721,t:1528139676598};\\\", \\\"{x:509,y:723,t:1528139676615};\\\", \\\"{x:509,y:724,t:1528139676631};\\\", \\\"{x:509,y:726,t:1528139676649};\\\", \\\"{x:509,y:727,t:1528139676670};\\\", \\\"{x:509,y:728,t:1528139676681};\\\", \\\"{x:509,y:729,t:1528139676698};\\\", \\\"{x:509,y:730,t:1528139676715};\\\", \\\"{x:509,y:732,t:1528139676731};\\\", \\\"{x:509,y:733,t:1528139676749};\\\", \\\"{x:506,y:736,t:1528139676766};\\\", \\\"{x:506,y:737,t:1528139676783};\\\", \\\"{x:505,y:738,t:1528139676798};\\\", \\\"{x:503,y:740,t:1528139676815};\\\", \\\"{x:502,y:741,t:1528139676837};\\\", \\\"{x:502,y:742,t:1528139676849};\\\", \\\"{x:501,y:743,t:1528139676893};\\\", \\\"{x:500,y:744,t:1528139677038};\\\", \\\"{x:499,y:745,t:1528139678094};\\\", \\\"{x:499,y:743,t:1528139678109};\\\", \\\"{x:499,y:741,t:1528139678118};\\\", \\\"{x:499,y:735,t:1528139678134};\\\", \\\"{x:499,y:729,t:1528139678149};\\\", \\\"{x:497,y:722,t:1528139678167};\\\", \\\"{x:497,y:719,t:1528139678183};\\\", \\\"{x:496,y:718,t:1528139678200};\\\", \\\"{x:496,y:715,t:1528139678216};\\\", \\\"{x:496,y:714,t:1528139678262};\\\", \\\"{x:495,y:713,t:1528139678278};\\\", \\\"{x:495,y:711,t:1528139678430};\\\", \\\"{x:495,y:710,t:1528139678437};\\\", \\\"{x:495,y:709,t:1528139678450};\\\", \\\"{x:495,y:708,t:1528139678466};\\\", \\\"{x:495,y:707,t:1528139678484};\\\", \\\"{x:495,y:706,t:1528139678515};\\\" ] }, { \\\"rt\\\": 16254, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 634859, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-03 PM-H -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:688,t:1528139678778};\\\", \\\"{x:495,y:685,t:1528139678805};\\\", \\\"{x:495,y:684,t:1528139678861};\\\", \\\"{x:495,y:683,t:1528139678941};\\\", \\\"{x:495,y:682,t:1528139680086};\\\", \\\"{x:521,y:669,t:1528139680104};\\\", \\\"{x:553,y:659,t:1528139680118};\\\", \\\"{x:582,y:653,t:1528139680134};\\\", \\\"{x:608,y:655,t:1528139680151};\\\", \\\"{x:621,y:660,t:1528139680169};\\\", \\\"{x:625,y:664,t:1528139680184};\\\", \\\"{x:626,y:666,t:1528139680838};\\\", \\\"{x:629,y:667,t:1528139680853};\\\", \\\"{x:642,y:667,t:1528139680868};\\\", \\\"{x:670,y:676,t:1528139680885};\\\", \\\"{x:690,y:682,t:1528139680902};\\\", \\\"{x:709,y:692,t:1528139680918};\\\", \\\"{x:728,y:701,t:1528139680935};\\\", \\\"{x:753,y:710,t:1528139680952};\\\", \\\"{x:808,y:729,t:1528139680968};\\\", \\\"{x:907,y:755,t:1528139680985};\\\", \\\"{x:952,y:767,t:1528139681002};\\\", \\\"{x:1067,y:796,t:1528139681018};\\\", \\\"{x:1196,y:823,t:1528139681036};\\\", \\\"{x:1324,y:848,t:1528139681052};\\\", \\\"{x:1441,y:869,t:1528139681069};\\\", \\\"{x:1580,y:908,t:1528139681086};\\\", \\\"{x:1637,y:930,t:1528139681103};\\\", \\\"{x:1681,y:948,t:1528139681119};\\\", \\\"{x:1717,y:965,t:1528139681136};\\\", \\\"{x:1738,y:977,t:1528139681153};\\\", \\\"{x:1755,y:985,t:1528139681170};\\\", \\\"{x:1761,y:987,t:1528139681186};\\\", \\\"{x:1762,y:988,t:1528139681202};\\\", \\\"{x:1763,y:989,t:1528139681262};\\\", \\\"{x:1767,y:991,t:1528139681269};\\\", \\\"{x:1769,y:994,t:1528139681286};\\\", \\\"{x:1770,y:996,t:1528139681303};\\\", \\\"{x:1770,y:997,t:1528139681320};\\\", \\\"{x:1769,y:998,t:1528139681366};\\\", \\\"{x:1767,y:1000,t:1528139681374};\\\", \\\"{x:1765,y:1000,t:1528139681386};\\\", \\\"{x:1750,y:1002,t:1528139681403};\\\", \\\"{x:1720,y:1002,t:1528139681420};\\\", \\\"{x:1690,y:999,t:1528139681436};\\\", \\\"{x:1630,y:988,t:1528139681452};\\\", \\\"{x:1543,y:970,t:1528139681469};\\\", \\\"{x:1518,y:964,t:1528139681486};\\\", \\\"{x:1497,y:960,t:1528139681502};\\\", \\\"{x:1487,y:956,t:1528139681519};\\\", \\\"{x:1483,y:955,t:1528139681536};\\\", \\\"{x:1483,y:953,t:1528139681605};\\\", \\\"{x:1484,y:952,t:1528139681620};\\\", \\\"{x:1492,y:947,t:1528139681636};\\\", \\\"{x:1505,y:942,t:1528139681653};\\\", \\\"{x:1537,y:936,t:1528139681669};\\\", \\\"{x:1561,y:930,t:1528139681687};\\\", \\\"{x:1578,y:925,t:1528139681703};\\\", \\\"{x:1587,y:923,t:1528139681720};\\\", \\\"{x:1595,y:923,t:1528139681737};\\\", \\\"{x:1599,y:923,t:1528139681753};\\\", \\\"{x:1606,y:923,t:1528139681770};\\\", \\\"{x:1607,y:923,t:1528139681814};\\\", \\\"{x:1608,y:923,t:1528139681854};\\\", \\\"{x:1615,y:927,t:1528139681869};\\\", \\\"{x:1616,y:931,t:1528139681887};\\\", \\\"{x:1621,y:935,t:1528139681903};\\\", \\\"{x:1622,y:936,t:1528139681920};\\\", \\\"{x:1623,y:937,t:1528139681937};\\\", \\\"{x:1623,y:939,t:1528139681974};\\\", \\\"{x:1623,y:941,t:1528139681987};\\\", \\\"{x:1617,y:946,t:1528139682004};\\\", \\\"{x:1610,y:950,t:1528139682020};\\\", \\\"{x:1606,y:952,t:1528139682037};\\\", \\\"{x:1605,y:953,t:1528139682053};\\\", \\\"{x:1604,y:953,t:1528139682198};\\\", \\\"{x:1603,y:949,t:1528139682214};\\\", \\\"{x:1603,y:946,t:1528139682222};\\\", \\\"{x:1602,y:944,t:1528139682237};\\\", \\\"{x:1601,y:938,t:1528139682254};\\\", \\\"{x:1601,y:936,t:1528139682270};\\\", \\\"{x:1599,y:931,t:1528139682288};\\\", \\\"{x:1597,y:926,t:1528139682304};\\\", \\\"{x:1596,y:922,t:1528139682320};\\\", \\\"{x:1593,y:917,t:1528139682337};\\\", \\\"{x:1591,y:913,t:1528139682354};\\\", \\\"{x:1590,y:907,t:1528139682370};\\\", \\\"{x:1587,y:902,t:1528139682387};\\\", \\\"{x:1585,y:895,t:1528139682404};\\\", \\\"{x:1580,y:882,t:1528139682420};\\\", \\\"{x:1576,y:868,t:1528139682437};\\\", \\\"{x:1566,y:837,t:1528139682453};\\\", \\\"{x:1558,y:818,t:1528139682470};\\\", \\\"{x:1551,y:803,t:1528139682487};\\\", \\\"{x:1546,y:791,t:1528139682504};\\\", \\\"{x:1542,y:777,t:1528139682520};\\\", \\\"{x:1537,y:761,t:1528139682537};\\\", \\\"{x:1532,y:749,t:1528139682554};\\\", \\\"{x:1528,y:731,t:1528139682571};\\\", \\\"{x:1521,y:711,t:1528139682587};\\\", \\\"{x:1517,y:696,t:1528139682605};\\\", \\\"{x:1514,y:684,t:1528139682621};\\\", \\\"{x:1512,y:675,t:1528139682638};\\\", \\\"{x:1508,y:665,t:1528139682654};\\\", \\\"{x:1506,y:661,t:1528139682671};\\\", \\\"{x:1505,y:657,t:1528139682687};\\\", \\\"{x:1503,y:655,t:1528139682704};\\\", \\\"{x:1500,y:651,t:1528139682721};\\\", \\\"{x:1499,y:650,t:1528139682738};\\\", \\\"{x:1493,y:645,t:1528139682754};\\\", \\\"{x:1489,y:642,t:1528139682771};\\\", \\\"{x:1486,y:639,t:1528139682787};\\\", \\\"{x:1482,y:634,t:1528139682803};\\\", \\\"{x:1476,y:626,t:1528139682821};\\\", \\\"{x:1468,y:616,t:1528139682837};\\\", \\\"{x:1460,y:604,t:1528139682854};\\\", \\\"{x:1456,y:597,t:1528139682871};\\\", \\\"{x:1453,y:592,t:1528139682887};\\\", \\\"{x:1450,y:588,t:1528139682904};\\\", \\\"{x:1446,y:584,t:1528139682921};\\\", \\\"{x:1443,y:580,t:1528139682938};\\\", \\\"{x:1441,y:578,t:1528139682954};\\\", \\\"{x:1441,y:577,t:1528139682971};\\\", \\\"{x:1441,y:576,t:1528139682987};\\\", \\\"{x:1440,y:576,t:1528139683004};\\\", \\\"{x:1438,y:575,t:1528139683021};\\\", \\\"{x:1436,y:574,t:1528139683038};\\\", \\\"{x:1427,y:572,t:1528139683054};\\\", \\\"{x:1419,y:570,t:1528139683071};\\\", \\\"{x:1415,y:568,t:1528139683094};\\\", \\\"{x:1414,y:567,t:1528139683120};\\\", \\\"{x:1412,y:566,t:1528139683148};\\\", \\\"{x:1292,y:604,t:1528139689843};\\\", \\\"{x:1118,y:656,t:1528139689858};\\\", \\\"{x:1018,y:670,t:1528139689875};\\\", \\\"{x:942,y:671,t:1528139689893};\\\", \\\"{x:918,y:671,t:1528139689909};\\\", \\\"{x:911,y:671,t:1528139689925};\\\", \\\"{x:910,y:671,t:1528139689942};\\\", \\\"{x:909,y:671,t:1528139690182};\\\", \\\"{x:919,y:672,t:1528139690222};\\\", \\\"{x:973,y:672,t:1528139690229};\\\", \\\"{x:1020,y:672,t:1528139690243};\\\", \\\"{x:1110,y:665,t:1528139690260};\\\", \\\"{x:1198,y:670,t:1528139690276};\\\", \\\"{x:1255,y:666,t:1528139690293};\\\", \\\"{x:1277,y:665,t:1528139690309};\\\", \\\"{x:1286,y:665,t:1528139690327};\\\", \\\"{x:1287,y:665,t:1528139690343};\\\", \\\"{x:1288,y:665,t:1528139690361};\\\", \\\"{x:1289,y:665,t:1528139690414};\\\", \\\"{x:1290,y:663,t:1528139690427};\\\", \\\"{x:1291,y:663,t:1528139690443};\\\", \\\"{x:1293,y:663,t:1528139690470};\\\", \\\"{x:1295,y:663,t:1528139690510};\\\", \\\"{x:1294,y:659,t:1528139690527};\\\", \\\"{x:1296,y:655,t:1528139690543};\\\", \\\"{x:1297,y:650,t:1528139690560};\\\", \\\"{x:1297,y:649,t:1528139690606};\\\", \\\"{x:1297,y:648,t:1528139690782};\\\", \\\"{x:1300,y:643,t:1528139690798};\\\", \\\"{x:1306,y:638,t:1528139690810};\\\", \\\"{x:1312,y:633,t:1528139690831};\\\", \\\"{x:1317,y:629,t:1528139690842};\\\", \\\"{x:1321,y:629,t:1528139690861};\\\", \\\"{x:1327,y:623,t:1528139690877};\\\", \\\"{x:1328,y:621,t:1528139690893};\\\", \\\"{x:1329,y:620,t:1528139690909};\\\", \\\"{x:1329,y:618,t:1528139691021};\\\", \\\"{x:1333,y:614,t:1528139691029};\\\", \\\"{x:1334,y:614,t:1528139691044};\\\", \\\"{x:1337,y:613,t:1528139691060};\\\", \\\"{x:1340,y:610,t:1528139691077};\\\", \\\"{x:1341,y:610,t:1528139691094};\\\", \\\"{x:1343,y:608,t:1528139691111};\\\", \\\"{x:1344,y:607,t:1528139691127};\\\", \\\"{x:1349,y:604,t:1528139691144};\\\", \\\"{x:1357,y:599,t:1528139691160};\\\", \\\"{x:1360,y:598,t:1528139691177};\\\", \\\"{x:1364,y:596,t:1528139691194};\\\", \\\"{x:1369,y:592,t:1528139691211};\\\", \\\"{x:1371,y:590,t:1528139691227};\\\", \\\"{x:1373,y:589,t:1528139691244};\\\", \\\"{x:1375,y:588,t:1528139691260};\\\", \\\"{x:1379,y:587,t:1528139691277};\\\", \\\"{x:1381,y:587,t:1528139691295};\\\", \\\"{x:1383,y:586,t:1528139691312};\\\", \\\"{x:1385,y:585,t:1528139691331};\\\", \\\"{x:1386,y:584,t:1528139691344};\\\", \\\"{x:1391,y:582,t:1528139691361};\\\", \\\"{x:1401,y:579,t:1528139691377};\\\", \\\"{x:1412,y:576,t:1528139691394};\\\", \\\"{x:1422,y:575,t:1528139691411};\\\", \\\"{x:1434,y:573,t:1528139691427};\\\", \\\"{x:1438,y:572,t:1528139691443};\\\", \\\"{x:1439,y:572,t:1528139691493};\\\", \\\"{x:1441,y:572,t:1528139691732};\\\", \\\"{x:1442,y:572,t:1528139691749};\\\", \\\"{x:1444,y:571,t:1528139691761};\\\", \\\"{x:1446,y:569,t:1528139691778};\\\", \\\"{x:1447,y:569,t:1528139691793};\\\", \\\"{x:1447,y:568,t:1528139691810};\\\", \\\"{x:1442,y:570,t:1528139692175};\\\", \\\"{x:1408,y:576,t:1528139692182};\\\", \\\"{x:1379,y:579,t:1528139692195};\\\", \\\"{x:1261,y:606,t:1528139692211};\\\", \\\"{x:1106,y:652,t:1528139692228};\\\", \\\"{x:806,y:726,t:1528139692246};\\\", \\\"{x:552,y:769,t:1528139692263};\\\", \\\"{x:292,y:802,t:1528139692280};\\\", \\\"{x:51,y:821,t:1528139692293};\\\", \\\"{x:0,y:820,t:1528139692310};\\\", \\\"{x:0,y:810,t:1528139692326};\\\", \\\"{x:0,y:800,t:1528139692343};\\\", \\\"{x:0,y:791,t:1528139692360};\\\", \\\"{x:0,y:785,t:1528139692377};\\\", \\\"{x:0,y:783,t:1528139692393};\\\", \\\"{x:0,y:782,t:1528139692410};\\\", \\\"{x:0,y:781,t:1528139692574};\\\", \\\"{x:1,y:779,t:1528139692582};\\\", \\\"{x:0,y:779,t:1528139692822};\\\", \\\"{x:0,y:776,t:1528139692837};\\\", \\\"{x:0,y:775,t:1528139692845};\\\", \\\"{x:0,y:774,t:1528139692860};\\\", \\\"{x:0,y:767,t:1528139692876};\\\", \\\"{x:0,y:765,t:1528139692893};\\\", \\\"{x:0,y:764,t:1528139692910};\\\", \\\"{x:0,y:762,t:1528139692927};\\\", \\\"{x:0,y:760,t:1528139692957};\\\", \\\"{x:0,y:759,t:1528139693014};\\\", \\\"{x:2,y:756,t:1528139693026};\\\", \\\"{x:8,y:754,t:1528139693043};\\\", \\\"{x:16,y:749,t:1528139693060};\\\", \\\"{x:18,y:747,t:1528139693076};\\\", \\\"{x:28,y:738,t:1528139693094};\\\", \\\"{x:40,y:729,t:1528139693109};\\\", \\\"{x:55,y:722,t:1528139693126};\\\", \\\"{x:61,y:720,t:1528139693143};\\\", \\\"{x:71,y:716,t:1528139693160};\\\", \\\"{x:90,y:707,t:1528139693176};\\\", \\\"{x:136,y:690,t:1528139693193};\\\", \\\"{x:156,y:682,t:1528139693211};\\\", \\\"{x:170,y:678,t:1528139693227};\\\", \\\"{x:180,y:674,t:1528139693245};\\\", \\\"{x:190,y:671,t:1528139693262};\\\", \\\"{x:199,y:668,t:1528139693280};\\\", \\\"{x:207,y:667,t:1528139693296};\\\", \\\"{x:218,y:665,t:1528139693312};\\\", \\\"{x:232,y:663,t:1528139693329};\\\", \\\"{x:255,y:660,t:1528139693344};\\\", \\\"{x:282,y:657,t:1528139693363};\\\", \\\"{x:317,y:651,t:1528139693380};\\\", \\\"{x:377,y:644,t:1528139693396};\\\", \\\"{x:445,y:639,t:1528139693413};\\\", \\\"{x:520,y:628,t:1528139693430};\\\", \\\"{x:560,y:620,t:1528139693446};\\\", \\\"{x:579,y:616,t:1528139693462};\\\", \\\"{x:593,y:609,t:1528139693480};\\\", \\\"{x:603,y:605,t:1528139693496};\\\", \\\"{x:613,y:601,t:1528139693511};\\\", \\\"{x:621,y:598,t:1528139693529};\\\", \\\"{x:624,y:596,t:1528139693544};\\\", \\\"{x:626,y:595,t:1528139693561};\\\", \\\"{x:629,y:593,t:1528139693579};\\\", \\\"{x:631,y:593,t:1528139693595};\\\", \\\"{x:631,y:592,t:1528139693611};\\\", \\\"{x:628,y:592,t:1528139693766};\\\", \\\"{x:627,y:593,t:1528139693782};\\\", \\\"{x:626,y:593,t:1528139693797};\\\", \\\"{x:624,y:594,t:1528139693813};\\\", \\\"{x:624,y:595,t:1528139693829};\\\", \\\"{x:622,y:595,t:1528139694221};\\\", \\\"{x:619,y:599,t:1528139694230};\\\", \\\"{x:615,y:613,t:1528139694246};\\\", \\\"{x:614,y:631,t:1528139694264};\\\", \\\"{x:614,y:650,t:1528139694280};\\\", \\\"{x:615,y:667,t:1528139694296};\\\", \\\"{x:627,y:683,t:1528139694313};\\\", \\\"{x:645,y:695,t:1528139694331};\\\", \\\"{x:665,y:705,t:1528139694346};\\\", \\\"{x:682,y:716,t:1528139694363};\\\", \\\"{x:704,y:725,t:1528139694379};\\\", \\\"{x:719,y:734,t:1528139694397};\\\", \\\"{x:730,y:745,t:1528139694413};\\\", \\\"{x:731,y:752,t:1528139694430};\\\", \\\"{x:731,y:759,t:1528139694446};\\\", \\\"{x:727,y:769,t:1528139694463};\\\", \\\"{x:719,y:780,t:1528139694479};\\\", \\\"{x:706,y:794,t:1528139694497};\\\", \\\"{x:689,y:802,t:1528139694513};\\\", \\\"{x:665,y:809,t:1528139694529};\\\", \\\"{x:636,y:813,t:1528139694546};\\\", \\\"{x:604,y:814,t:1528139694562};\\\", \\\"{x:573,y:811,t:1528139694579};\\\", \\\"{x:548,y:806,t:1528139694597};\\\", \\\"{x:527,y:798,t:1528139694612};\\\", \\\"{x:515,y:791,t:1528139694629};\\\", \\\"{x:513,y:788,t:1528139694646};\\\", \\\"{x:513,y:787,t:1528139694662};\\\", \\\"{x:512,y:785,t:1528139694679};\\\", \\\"{x:511,y:782,t:1528139694701};\\\", \\\"{x:511,y:781,t:1528139694713};\\\", \\\"{x:510,y:778,t:1528139694729};\\\", \\\"{x:509,y:773,t:1528139694746};\\\", \\\"{x:509,y:769,t:1528139694763};\\\", \\\"{x:509,y:767,t:1528139694779};\\\", \\\"{x:509,y:766,t:1528139694845};\\\", \\\"{x:507,y:765,t:1528139695238};\\\", \\\"{x:506,y:764,t:1528139696080};\\\" ] }, { \\\"rt\\\": 33956, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 670033, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O -O -O -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:764,t:1528139696253};\\\", \\\"{x:504,y:763,t:1528139696317};\\\", \\\"{x:504,y:762,t:1528139696356};\\\", \\\"{x:504,y:761,t:1528139696426};\\\", \\\"{x:504,y:760,t:1528139696460};\\\", \\\"{x:503,y:759,t:1528139696813};\\\", \\\"{x:501,y:755,t:1528139697550};\\\", \\\"{x:499,y:753,t:1528139697566};\\\", \\\"{x:496,y:748,t:1528139697584};\\\", \\\"{x:491,y:742,t:1528139697599};\\\", \\\"{x:488,y:738,t:1528139697615};\\\", \\\"{x:487,y:736,t:1528139697636};\\\", \\\"{x:487,y:735,t:1528139697648};\\\", \\\"{x:485,y:733,t:1528139697667};\\\", \\\"{x:482,y:722,t:1528139697682};\\\", \\\"{x:478,y:700,t:1528139697700};\\\", \\\"{x:471,y:674,t:1528139697715};\\\", \\\"{x:467,y:649,t:1528139697733};\\\", \\\"{x:463,y:629,t:1528139697749};\\\", \\\"{x:463,y:622,t:1528139697766};\\\", \\\"{x:463,y:621,t:1528139697782};\\\", \\\"{x:463,y:615,t:1528139697799};\\\", \\\"{x:461,y:603,t:1528139697815};\\\", \\\"{x:457,y:589,t:1528139697833};\\\", \\\"{x:454,y:583,t:1528139697850};\\\", \\\"{x:454,y:578,t:1528139697865};\\\", \\\"{x:454,y:576,t:1528139697882};\\\", \\\"{x:454,y:574,t:1528139697899};\\\", \\\"{x:454,y:573,t:1528139697916};\\\", \\\"{x:454,y:571,t:1528139697933};\\\", \\\"{x:455,y:567,t:1528139697949};\\\", \\\"{x:455,y:563,t:1528139697966};\\\", \\\"{x:455,y:562,t:1528139697982};\\\", \\\"{x:455,y:560,t:1528139697999};\\\", \\\"{x:455,y:558,t:1528139698022};\\\", \\\"{x:456,y:557,t:1528139698070};\\\", \\\"{x:457,y:556,t:1528139698117};\\\", \\\"{x:458,y:555,t:1528139698143};\\\", \\\"{x:460,y:553,t:1528139698165};\\\", \\\"{x:460,y:552,t:1528139698173};\\\", \\\"{x:460,y:551,t:1528139698205};\\\", \\\"{x:461,y:550,t:1528139698216};\\\", \\\"{x:464,y:548,t:1528139698236};\\\", \\\"{x:464,y:547,t:1528139698249};\\\", \\\"{x:465,y:546,t:1528139698267};\\\", \\\"{x:465,y:545,t:1528139698301};\\\", \\\"{x:467,y:544,t:1528139698694};\\\", \\\"{x:470,y:543,t:1528139698702};\\\", \\\"{x:475,y:543,t:1528139698719};\\\", \\\"{x:476,y:541,t:1528139698736};\\\", \\\"{x:477,y:541,t:1528139698757};\\\", \\\"{x:478,y:541,t:1528139698773};\\\", \\\"{x:480,y:541,t:1528139698789};\\\", \\\"{x:482,y:540,t:1528139698802};\\\", \\\"{x:490,y:540,t:1528139698819};\\\", \\\"{x:504,y:539,t:1528139698836};\\\", \\\"{x:514,y:539,t:1528139698852};\\\", \\\"{x:524,y:536,t:1528139698870};\\\", \\\"{x:529,y:536,t:1528139698886};\\\", \\\"{x:531,y:536,t:1528139698903};\\\", \\\"{x:537,y:536,t:1528139698920};\\\", \\\"{x:544,y:536,t:1528139698937};\\\", \\\"{x:549,y:536,t:1528139698954};\\\", \\\"{x:554,y:536,t:1528139698969};\\\", \\\"{x:556,y:536,t:1528139698987};\\\", \\\"{x:558,y:536,t:1528139699003};\\\", \\\"{x:559,y:535,t:1528139699286};\\\", \\\"{x:559,y:534,t:1528139699301};\\\", \\\"{x:558,y:534,t:1528139699333};\\\", \\\"{x:557,y:534,t:1528139699342};\\\", \\\"{x:556,y:534,t:1528139699354};\\\", \\\"{x:555,y:534,t:1528139699371};\\\", \\\"{x:553,y:534,t:1528139699388};\\\", \\\"{x:552,y:534,t:1528139699404};\\\", \\\"{x:550,y:534,t:1528139699429};\\\", \\\"{x:549,y:534,t:1528139699469};\\\", \\\"{x:547,y:534,t:1528139699493};\\\", \\\"{x:546,y:534,t:1528139699508};\\\", \\\"{x:544,y:534,t:1528139699532};\\\", \\\"{x:542,y:534,t:1528139699540};\\\", \\\"{x:539,y:534,t:1528139699556};\\\", \\\"{x:537,y:534,t:1528139699572};\\\", \\\"{x:532,y:534,t:1528139699588};\\\", \\\"{x:530,y:534,t:1528139699605};\\\", \\\"{x:529,y:535,t:1528139699622};\\\", \\\"{x:527,y:535,t:1528139699639};\\\", \\\"{x:525,y:536,t:1528139699657};\\\", \\\"{x:523,y:536,t:1528139699672};\\\", \\\"{x:522,y:536,t:1528139699689};\\\", \\\"{x:521,y:536,t:1528139699710};\\\", \\\"{x:519,y:537,t:1528139699723};\\\", \\\"{x:518,y:538,t:1528139699773};\\\", \\\"{x:517,y:538,t:1528139699790};\\\", \\\"{x:516,y:538,t:1528139699806};\\\", \\\"{x:513,y:538,t:1528139699830};\\\", \\\"{x:513,y:539,t:1528139699841};\\\", \\\"{x:511,y:540,t:1528139699857};\\\", \\\"{x:509,y:540,t:1528139699873};\\\", \\\"{x:507,y:541,t:1528139699890};\\\", \\\"{x:504,y:541,t:1528139699907};\\\", \\\"{x:501,y:543,t:1528139699924};\\\", \\\"{x:499,y:544,t:1528139699941};\\\", \\\"{x:495,y:545,t:1528139699958};\\\", \\\"{x:493,y:546,t:1528139699974};\\\", \\\"{x:490,y:548,t:1528139699990};\\\", \\\"{x:486,y:549,t:1528139700008};\\\", \\\"{x:483,y:551,t:1528139700025};\\\", \\\"{x:482,y:551,t:1528139700045};\\\", \\\"{x:480,y:552,t:1528139700077};\\\", \\\"{x:476,y:553,t:1528139700116};\\\", \\\"{x:475,y:553,t:1528139700253};\\\", \\\"{x:475,y:554,t:1528139700261};\\\", \\\"{x:473,y:554,t:1528139700285};\\\", \\\"{x:473,y:555,t:1528139700317};\\\", \\\"{x:472,y:555,t:1528139700349};\\\", \\\"{x:470,y:555,t:1528139700710};\\\", \\\"{x:469,y:556,t:1528139700910};\\\", \\\"{x:468,y:556,t:1528139701004};\\\", \\\"{x:467,y:556,t:1528139701126};\\\", \\\"{x:466,y:556,t:1528139701573};\\\", \\\"{x:461,y:556,t:1528139701585};\\\", \\\"{x:454,y:547,t:1528139701602};\\\", \\\"{x:448,y:541,t:1528139701618};\\\", \\\"{x:439,y:531,t:1528139701635};\\\", \\\"{x:431,y:525,t:1528139701653};\\\", \\\"{x:426,y:521,t:1528139701668};\\\", \\\"{x:418,y:511,t:1528139701685};\\\", \\\"{x:412,y:507,t:1528139701703};\\\", \\\"{x:409,y:504,t:1528139701719};\\\", \\\"{x:408,y:503,t:1528139701735};\\\", \\\"{x:408,y:502,t:1528139702181};\\\", \\\"{x:407,y:502,t:1528139702237};\\\", \\\"{x:406,y:502,t:1528139702950};\\\", \\\"{x:405,y:502,t:1528139702982};\\\", \\\"{x:404,y:502,t:1528139703038};\\\", \\\"{x:406,y:504,t:1528139703174};\\\", \\\"{x:415,y:508,t:1528139703187};\\\", \\\"{x:436,y:520,t:1528139703204};\\\", \\\"{x:457,y:527,t:1528139703221};\\\", \\\"{x:501,y:541,t:1528139703237};\\\", \\\"{x:538,y:552,t:1528139703253};\\\", \\\"{x:560,y:556,t:1528139703272};\\\", \\\"{x:584,y:560,t:1528139703286};\\\", \\\"{x:614,y:565,t:1528139703303};\\\", \\\"{x:624,y:568,t:1528139703320};\\\", \\\"{x:628,y:569,t:1528139703336};\\\", \\\"{x:631,y:569,t:1528139703353};\\\", \\\"{x:633,y:569,t:1528139703370};\\\", \\\"{x:633,y:570,t:1528139703386};\\\", \\\"{x:634,y:570,t:1528139703534};\\\", \\\"{x:636,y:570,t:1528139703557};\\\", \\\"{x:637,y:570,t:1528139703606};\\\", \\\"{x:639,y:570,t:1528139703631};\\\", \\\"{x:640,y:570,t:1528139703636};\\\", \\\"{x:645,y:572,t:1528139703653};\\\", \\\"{x:651,y:576,t:1528139703670};\\\", \\\"{x:654,y:578,t:1528139703687};\\\", \\\"{x:658,y:579,t:1528139703703};\\\", \\\"{x:666,y:581,t:1528139703720};\\\", \\\"{x:672,y:582,t:1528139703737};\\\", \\\"{x:676,y:584,t:1528139703753};\\\", \\\"{x:682,y:585,t:1528139703770};\\\", \\\"{x:686,y:586,t:1528139703787};\\\", \\\"{x:691,y:588,t:1528139703804};\\\", \\\"{x:696,y:590,t:1528139703821};\\\", \\\"{x:699,y:591,t:1528139703838};\\\", \\\"{x:699,y:592,t:1528139703942};\\\", \\\"{x:700,y:592,t:1528139704030};\\\", \\\"{x:701,y:593,t:1528139704037};\\\", \\\"{x:707,y:596,t:1528139704057};\\\", \\\"{x:709,y:596,t:1528139704071};\\\", \\\"{x:712,y:598,t:1528139704088};\\\", \\\"{x:713,y:599,t:1528139704116};\\\", \\\"{x:714,y:599,t:1528139704125};\\\", \\\"{x:715,y:599,t:1528139704137};\\\", \\\"{x:719,y:600,t:1528139704155};\\\", \\\"{x:726,y:603,t:1528139704171};\\\", \\\"{x:731,y:606,t:1528139704187};\\\", \\\"{x:736,y:606,t:1528139704204};\\\", \\\"{x:739,y:607,t:1528139704221};\\\", \\\"{x:746,y:608,t:1528139704237};\\\", \\\"{x:747,y:609,t:1528139704254};\\\", \\\"{x:750,y:610,t:1528139704270};\\\", \\\"{x:752,y:611,t:1528139704287};\\\", \\\"{x:752,y:612,t:1528139704309};\\\", \\\"{x:753,y:612,t:1528139704446};\\\", \\\"{x:753,y:613,t:1528139704454};\\\", \\\"{x:755,y:614,t:1528139704470};\\\", \\\"{x:755,y:615,t:1528139704540};\\\", \\\"{x:759,y:616,t:1528139704556};\\\", \\\"{x:765,y:617,t:1528139704571};\\\", \\\"{x:772,y:620,t:1528139704588};\\\", \\\"{x:779,y:621,t:1528139704605};\\\", \\\"{x:795,y:626,t:1528139704621};\\\", \\\"{x:804,y:632,t:1528139704639};\\\", \\\"{x:815,y:640,t:1528139704654};\\\", \\\"{x:816,y:640,t:1528139705270};\\\", \\\"{x:819,y:640,t:1528139705277};\\\", \\\"{x:826,y:640,t:1528139705289};\\\", \\\"{x:836,y:639,t:1528139705305};\\\", \\\"{x:845,y:638,t:1528139705321};\\\", \\\"{x:856,y:637,t:1528139705336};\\\", \\\"{x:871,y:634,t:1528139705354};\\\", \\\"{x:887,y:632,t:1528139705369};\\\", \\\"{x:907,y:629,t:1528139705389};\\\", \\\"{x:922,y:629,t:1528139705404};\\\", \\\"{x:943,y:628,t:1528139705421};\\\", \\\"{x:967,y:628,t:1528139705439};\\\", \\\"{x:997,y:627,t:1528139705455};\\\", \\\"{x:1072,y:627,t:1528139705472};\\\", \\\"{x:1153,y:627,t:1528139705488};\\\", \\\"{x:1198,y:627,t:1528139705505};\\\", \\\"{x:1234,y:626,t:1528139705521};\\\", \\\"{x:1266,y:626,t:1528139705539};\\\", \\\"{x:1293,y:626,t:1528139705556};\\\", \\\"{x:1308,y:626,t:1528139705571};\\\", \\\"{x:1326,y:626,t:1528139705589};\\\", \\\"{x:1351,y:626,t:1528139705605};\\\", \\\"{x:1363,y:626,t:1528139705622};\\\", \\\"{x:1367,y:626,t:1528139705638};\\\", \\\"{x:1368,y:626,t:1528139705655};\\\", \\\"{x:1370,y:626,t:1528139705686};\\\", \\\"{x:1371,y:625,t:1528139705790};\\\", \\\"{x:1371,y:620,t:1528139705806};\\\", \\\"{x:1370,y:613,t:1528139705823};\\\", \\\"{x:1367,y:607,t:1528139705839};\\\", \\\"{x:1366,y:603,t:1528139705856};\\\", \\\"{x:1363,y:598,t:1528139705873};\\\", \\\"{x:1362,y:593,t:1528139705889};\\\", \\\"{x:1359,y:589,t:1528139705906};\\\", \\\"{x:1358,y:585,t:1528139705923};\\\", \\\"{x:1357,y:582,t:1528139705940};\\\", \\\"{x:1356,y:579,t:1528139705956};\\\", \\\"{x:1353,y:575,t:1528139705974};\\\", \\\"{x:1351,y:570,t:1528139705990};\\\", \\\"{x:1349,y:553,t:1528139706006};\\\", \\\"{x:1344,y:538,t:1528139706023};\\\", \\\"{x:1336,y:527,t:1528139706041};\\\", \\\"{x:1332,y:520,t:1528139706056};\\\", \\\"{x:1328,y:514,t:1528139706073};\\\", \\\"{x:1327,y:510,t:1528139706090};\\\", \\\"{x:1326,y:509,t:1528139706106};\\\", \\\"{x:1326,y:508,t:1528139706123};\\\", \\\"{x:1326,y:507,t:1528139706140};\\\", \\\"{x:1326,y:506,t:1528139706157};\\\", \\\"{x:1325,y:505,t:1528139706206};\\\", \\\"{x:1324,y:504,t:1528139706223};\\\", \\\"{x:1324,y:502,t:1528139706240};\\\", \\\"{x:1323,y:500,t:1528139706257};\\\", \\\"{x:1321,y:497,t:1528139706273};\\\", \\\"{x:1319,y:492,t:1528139706290};\\\", \\\"{x:1313,y:485,t:1528139706307};\\\", \\\"{x:1311,y:482,t:1528139706323};\\\", \\\"{x:1310,y:480,t:1528139706340};\\\", \\\"{x:1310,y:481,t:1528139706613};\\\", \\\"{x:1310,y:482,t:1528139706629};\\\", \\\"{x:1310,y:483,t:1528139706640};\\\", \\\"{x:1311,y:484,t:1528139706657};\\\", \\\"{x:1312,y:487,t:1528139706674};\\\", \\\"{x:1314,y:489,t:1528139706743};\\\", \\\"{x:1315,y:491,t:1528139706764};\\\", \\\"{x:1316,y:492,t:1528139706789};\\\", \\\"{x:1316,y:495,t:1528139706806};\\\", \\\"{x:1318,y:497,t:1528139706822};\\\", \\\"{x:1319,y:500,t:1528139706839};\\\", \\\"{x:1321,y:503,t:1528139706857};\\\", \\\"{x:1322,y:504,t:1528139706872};\\\", \\\"{x:1322,y:505,t:1528139706889};\\\", \\\"{x:1323,y:506,t:1528139706907};\\\", \\\"{x:1323,y:504,t:1528139707310};\\\", \\\"{x:1323,y:502,t:1528139707324};\\\", \\\"{x:1321,y:498,t:1528139707339};\\\", \\\"{x:1318,y:493,t:1528139707362};\\\", \\\"{x:1317,y:493,t:1528139707373};\\\", \\\"{x:1317,y:492,t:1528139707396};\\\", \\\"{x:1316,y:491,t:1528139707477};\\\", \\\"{x:1315,y:491,t:1528139710430};\\\", \\\"{x:1314,y:495,t:1528139710442};\\\", \\\"{x:1313,y:505,t:1528139710461};\\\", \\\"{x:1308,y:515,t:1528139710475};\\\", \\\"{x:1308,y:518,t:1528139710491};\\\", \\\"{x:1307,y:522,t:1528139710509};\\\", \\\"{x:1307,y:524,t:1528139710525};\\\", \\\"{x:1307,y:526,t:1528139710543};\\\", \\\"{x:1307,y:529,t:1528139710559};\\\", \\\"{x:1307,y:532,t:1528139710575};\\\", \\\"{x:1307,y:534,t:1528139710593};\\\", \\\"{x:1307,y:535,t:1528139710609};\\\", \\\"{x:1307,y:537,t:1528139710626};\\\", \\\"{x:1308,y:539,t:1528139710642};\\\", \\\"{x:1309,y:541,t:1528139710660};\\\", \\\"{x:1309,y:542,t:1528139710676};\\\", \\\"{x:1311,y:547,t:1528139710693};\\\", \\\"{x:1313,y:549,t:1528139710710};\\\", \\\"{x:1313,y:551,t:1528139710726};\\\", \\\"{x:1314,y:553,t:1528139710743};\\\", \\\"{x:1315,y:555,t:1528139710760};\\\", \\\"{x:1316,y:557,t:1528139710775};\\\", \\\"{x:1317,y:557,t:1528139710793};\\\", \\\"{x:1317,y:558,t:1528139710810};\\\", \\\"{x:1318,y:559,t:1528139710826};\\\", \\\"{x:1318,y:560,t:1528139710843};\\\", \\\"{x:1319,y:561,t:1528139710860};\\\", \\\"{x:1319,y:563,t:1528139710877};\\\", \\\"{x:1319,y:566,t:1528139710893};\\\", \\\"{x:1320,y:568,t:1528139710910};\\\", \\\"{x:1320,y:570,t:1528139710926};\\\", \\\"{x:1320,y:573,t:1528139710943};\\\", \\\"{x:1320,y:577,t:1528139710959};\\\", \\\"{x:1320,y:581,t:1528139710976};\\\", \\\"{x:1320,y:584,t:1528139710993};\\\", \\\"{x:1319,y:587,t:1528139711010};\\\", \\\"{x:1319,y:589,t:1528139711026};\\\", \\\"{x:1318,y:591,t:1528139711043};\\\", \\\"{x:1318,y:592,t:1528139711077};\\\", \\\"{x:1318,y:593,t:1528139711093};\\\", \\\"{x:1318,y:594,t:1528139711110};\\\", \\\"{x:1318,y:595,t:1528139711127};\\\", \\\"{x:1318,y:597,t:1528139711144};\\\", \\\"{x:1318,y:600,t:1528139711166};\\\", \\\"{x:1318,y:602,t:1528139711190};\\\", \\\"{x:1317,y:603,t:1528139711198};\\\", \\\"{x:1316,y:605,t:1528139711210};\\\", \\\"{x:1316,y:606,t:1528139711227};\\\", \\\"{x:1315,y:608,t:1528139711243};\\\", \\\"{x:1315,y:609,t:1528139711270};\\\", \\\"{x:1314,y:610,t:1528139711278};\\\", \\\"{x:1314,y:611,t:1528139711326};\\\", \\\"{x:1314,y:612,t:1528139711350};\\\", \\\"{x:1314,y:613,t:1528139711365};\\\", \\\"{x:1314,y:614,t:1528139711422};\\\", \\\"{x:1314,y:615,t:1528139711429};\\\", \\\"{x:1314,y:616,t:1528139711445};\\\", \\\"{x:1314,y:617,t:1528139711460};\\\", \\\"{x:1313,y:619,t:1528139711478};\\\", \\\"{x:1313,y:620,t:1528139711510};\\\", \\\"{x:1313,y:621,t:1528139711541};\\\", \\\"{x:1313,y:622,t:1528139711582};\\\", \\\"{x:1313,y:623,t:1528139711646};\\\", \\\"{x:1313,y:624,t:1528139711669};\\\", \\\"{x:1312,y:625,t:1528139711697};\\\", \\\"{x:1312,y:627,t:1528139711709};\\\", \\\"{x:1312,y:629,t:1528139711726};\\\", \\\"{x:1312,y:631,t:1528139711744};\\\", \\\"{x:1312,y:632,t:1528139711759};\\\", \\\"{x:1312,y:633,t:1528139711776};\\\", \\\"{x:1312,y:634,t:1528139711794};\\\", \\\"{x:1312,y:635,t:1528139711810};\\\", \\\"{x:1312,y:638,t:1528139711844};\\\", \\\"{x:1312,y:639,t:1528139711860};\\\", \\\"{x:1312,y:640,t:1528139711909};\\\", \\\"{x:1312,y:638,t:1528139712230};\\\", \\\"{x:1312,y:637,t:1528139712253};\\\", \\\"{x:1313,y:634,t:1528139712265};\\\", \\\"{x:1314,y:633,t:1528139712293};\\\", \\\"{x:1314,y:632,t:1528139712311};\\\", \\\"{x:1314,y:631,t:1528139712328};\\\", \\\"{x:1314,y:630,t:1528139712357};\\\", \\\"{x:1315,y:629,t:1528139712364};\\\", \\\"{x:1316,y:628,t:1528139712381};\\\", \\\"{x:1316,y:625,t:1528139712396};\\\", \\\"{x:1315,y:624,t:1528139713558};\\\", \\\"{x:1315,y:619,t:1528139713578};\\\", \\\"{x:1315,y:613,t:1528139713595};\\\", \\\"{x:1315,y:606,t:1528139713611};\\\", \\\"{x:1315,y:603,t:1528139713628};\\\", \\\"{x:1315,y:599,t:1528139713645};\\\", \\\"{x:1316,y:598,t:1528139713662};\\\", \\\"{x:1316,y:597,t:1528139713685};\\\", \\\"{x:1317,y:595,t:1528139713694};\\\", \\\"{x:1317,y:593,t:1528139713717};\\\", \\\"{x:1317,y:592,t:1528139713728};\\\", \\\"{x:1319,y:586,t:1528139713745};\\\", \\\"{x:1320,y:582,t:1528139713762};\\\", \\\"{x:1321,y:576,t:1528139713779};\\\", \\\"{x:1323,y:570,t:1528139713795};\\\", \\\"{x:1324,y:565,t:1528139713812};\\\", \\\"{x:1325,y:558,t:1528139713829};\\\", \\\"{x:1327,y:556,t:1528139713845};\\\", \\\"{x:1327,y:551,t:1528139713862};\\\", \\\"{x:1328,y:547,t:1528139713879};\\\", \\\"{x:1328,y:541,t:1528139713895};\\\", \\\"{x:1328,y:536,t:1528139713912};\\\", \\\"{x:1328,y:532,t:1528139713929};\\\", \\\"{x:1328,y:529,t:1528139713945};\\\", \\\"{x:1328,y:523,t:1528139713962};\\\", \\\"{x:1328,y:518,t:1528139713980};\\\", \\\"{x:1328,y:515,t:1528139713996};\\\", \\\"{x:1328,y:511,t:1528139714012};\\\", \\\"{x:1328,y:508,t:1528139714029};\\\", \\\"{x:1328,y:506,t:1528139714045};\\\", \\\"{x:1328,y:504,t:1528139714063};\\\", \\\"{x:1328,y:503,t:1528139714085};\\\", \\\"{x:1328,y:502,t:1528139714095};\\\", \\\"{x:1328,y:501,t:1528139714125};\\\", \\\"{x:1328,y:500,t:1528139714166};\\\", \\\"{x:1328,y:499,t:1528139714179};\\\", \\\"{x:1328,y:498,t:1528139714195};\\\", \\\"{x:1328,y:496,t:1528139714213};\\\", \\\"{x:1328,y:495,t:1528139714230};\\\", \\\"{x:1327,y:493,t:1528139714246};\\\", \\\"{x:1327,y:492,t:1528139714263};\\\", \\\"{x:1327,y:491,t:1528139714280};\\\", \\\"{x:1325,y:488,t:1528139714296};\\\", \\\"{x:1324,y:486,t:1528139714313};\\\", \\\"{x:1323,y:486,t:1528139714366};\\\", \\\"{x:1322,y:486,t:1528139714661};\\\", \\\"{x:1321,y:486,t:1528139714678};\\\", \\\"{x:1319,y:490,t:1528139714695};\\\", \\\"{x:1318,y:493,t:1528139714714};\\\", \\\"{x:1317,y:494,t:1528139714729};\\\", \\\"{x:1315,y:495,t:1528139715526};\\\", \\\"{x:1313,y:498,t:1528139715533};\\\", \\\"{x:1311,y:512,t:1528139715563};\\\", \\\"{x:1310,y:518,t:1528139715580};\\\", \\\"{x:1310,y:527,t:1528139715596};\\\", \\\"{x:1310,y:533,t:1528139715613};\\\", \\\"{x:1310,y:537,t:1528139715630};\\\", \\\"{x:1310,y:539,t:1528139715647};\\\", \\\"{x:1310,y:540,t:1528139715663};\\\", \\\"{x:1310,y:542,t:1528139715733};\\\", \\\"{x:1310,y:544,t:1528139715749};\\\", \\\"{x:1310,y:546,t:1528139715764};\\\", \\\"{x:1310,y:550,t:1528139715780};\\\", \\\"{x:1310,y:559,t:1528139715797};\\\", \\\"{x:1310,y:566,t:1528139715813};\\\", \\\"{x:1310,y:571,t:1528139715830};\\\", \\\"{x:1310,y:582,t:1528139715847};\\\", \\\"{x:1312,y:592,t:1528139715864};\\\", \\\"{x:1312,y:602,t:1528139715880};\\\", \\\"{x:1312,y:612,t:1528139715897};\\\", \\\"{x:1312,y:621,t:1528139715914};\\\", \\\"{x:1312,y:626,t:1528139715934};\\\", \\\"{x:1314,y:628,t:1528139715947};\\\", \\\"{x:1314,y:629,t:1528139715964};\\\", \\\"{x:1314,y:630,t:1528139715980};\\\", \\\"{x:1314,y:631,t:1528139716117};\\\", \\\"{x:1314,y:632,t:1528139716149};\\\", \\\"{x:1314,y:633,t:1528139716164};\\\", \\\"{x:1314,y:634,t:1528139716181};\\\", \\\"{x:1314,y:635,t:1528139716205};\\\", \\\"{x:1314,y:637,t:1528139716223};\\\", \\\"{x:1315,y:637,t:1528139716230};\\\", \\\"{x:1315,y:638,t:1528139716247};\\\", \\\"{x:1315,y:640,t:1528139716264};\\\", \\\"{x:1315,y:642,t:1528139717166};\\\", \\\"{x:1315,y:643,t:1528139717181};\\\", \\\"{x:1315,y:645,t:1528139717198};\\\", \\\"{x:1315,y:646,t:1528139717215};\\\", \\\"{x:1317,y:649,t:1528139717231};\\\", \\\"{x:1317,y:650,t:1528139717248};\\\", \\\"{x:1317,y:652,t:1528139717265};\\\", \\\"{x:1317,y:653,t:1528139717286};\\\", \\\"{x:1317,y:654,t:1528139717298};\\\", \\\"{x:1317,y:655,t:1528139717316};\\\", \\\"{x:1317,y:657,t:1528139717332};\\\", \\\"{x:1317,y:658,t:1528139717348};\\\", \\\"{x:1318,y:661,t:1528139717366};\\\", \\\"{x:1318,y:662,t:1528139717381};\\\", \\\"{x:1318,y:664,t:1528139717399};\\\", \\\"{x:1319,y:664,t:1528139717415};\\\", \\\"{x:1319,y:667,t:1528139717432};\\\", \\\"{x:1320,y:667,t:1528139717454};\\\", \\\"{x:1320,y:668,t:1528139717469};\\\", \\\"{x:1320,y:669,t:1528139717481};\\\", \\\"{x:1320,y:671,t:1528139717499};\\\", \\\"{x:1320,y:674,t:1528139717515};\\\", \\\"{x:1320,y:678,t:1528139717531};\\\", \\\"{x:1321,y:680,t:1528139717549};\\\", \\\"{x:1321,y:682,t:1528139717567};\\\", \\\"{x:1321,y:684,t:1528139717582};\\\", \\\"{x:1321,y:685,t:1528139717599};\\\", \\\"{x:1322,y:688,t:1528139717616};\\\", \\\"{x:1322,y:690,t:1528139717632};\\\", \\\"{x:1322,y:691,t:1528139717648};\\\", \\\"{x:1322,y:694,t:1528139717665};\\\", \\\"{x:1322,y:697,t:1528139717682};\\\", \\\"{x:1322,y:704,t:1528139717698};\\\", \\\"{x:1322,y:708,t:1528139717716};\\\", \\\"{x:1322,y:711,t:1528139717732};\\\", \\\"{x:1322,y:716,t:1528139717748};\\\", \\\"{x:1322,y:721,t:1528139717766};\\\", \\\"{x:1322,y:726,t:1528139717781};\\\", \\\"{x:1322,y:729,t:1528139717799};\\\", \\\"{x:1322,y:733,t:1528139717816};\\\", \\\"{x:1322,y:736,t:1528139717832};\\\", \\\"{x:1322,y:740,t:1528139717848};\\\", \\\"{x:1322,y:743,t:1528139717866};\\\", \\\"{x:1321,y:748,t:1528139717882};\\\", \\\"{x:1319,y:752,t:1528139717899};\\\", \\\"{x:1317,y:758,t:1528139717917};\\\", \\\"{x:1316,y:762,t:1528139717933};\\\", \\\"{x:1315,y:767,t:1528139717949};\\\", \\\"{x:1312,y:776,t:1528139717966};\\\", \\\"{x:1311,y:785,t:1528139717983};\\\", \\\"{x:1311,y:786,t:1528139717999};\\\", \\\"{x:1311,y:788,t:1528139718015};\\\", \\\"{x:1309,y:791,t:1528139718033};\\\", \\\"{x:1309,y:793,t:1528139718049};\\\", \\\"{x:1308,y:798,t:1528139718067};\\\", \\\"{x:1308,y:805,t:1528139718083};\\\", \\\"{x:1308,y:812,t:1528139718099};\\\", \\\"{x:1308,y:820,t:1528139718115};\\\", \\\"{x:1308,y:827,t:1528139718133};\\\", \\\"{x:1308,y:831,t:1528139718149};\\\", \\\"{x:1308,y:838,t:1528139718166};\\\", \\\"{x:1308,y:841,t:1528139718182};\\\", \\\"{x:1308,y:843,t:1528139718199};\\\", \\\"{x:1308,y:845,t:1528139718215};\\\", \\\"{x:1308,y:850,t:1528139718232};\\\", \\\"{x:1308,y:857,t:1528139718249};\\\", \\\"{x:1308,y:861,t:1528139718265};\\\", \\\"{x:1308,y:865,t:1528139718282};\\\", \\\"{x:1308,y:868,t:1528139718300};\\\", \\\"{x:1308,y:869,t:1528139718316};\\\", \\\"{x:1308,y:871,t:1528139718333};\\\", \\\"{x:1308,y:876,t:1528139718350};\\\", \\\"{x:1308,y:881,t:1528139718366};\\\", \\\"{x:1308,y:886,t:1528139718383};\\\", \\\"{x:1309,y:889,t:1528139718400};\\\", \\\"{x:1309,y:890,t:1528139718416};\\\", \\\"{x:1309,y:891,t:1528139718433};\\\", \\\"{x:1309,y:892,t:1528139718453};\\\", \\\"{x:1310,y:893,t:1528139718470};\\\", \\\"{x:1310,y:894,t:1528139718509};\\\", \\\"{x:1310,y:895,t:1528139718525};\\\", \\\"{x:1310,y:896,t:1528139718542};\\\", \\\"{x:1310,y:898,t:1528139718599};\\\", \\\"{x:1310,y:899,t:1528139718606};\\\", \\\"{x:1310,y:900,t:1528139718615};\\\", \\\"{x:1310,y:903,t:1528139718632};\\\", \\\"{x:1310,y:909,t:1528139718649};\\\", \\\"{x:1310,y:913,t:1528139718665};\\\", \\\"{x:1310,y:916,t:1528139718682};\\\", \\\"{x:1310,y:920,t:1528139718699};\\\", \\\"{x:1310,y:923,t:1528139718715};\\\", \\\"{x:1310,y:926,t:1528139718732};\\\", \\\"{x:1310,y:931,t:1528139718749};\\\", \\\"{x:1309,y:935,t:1528139718766};\\\", \\\"{x:1308,y:941,t:1528139718782};\\\", \\\"{x:1308,y:946,t:1528139718800};\\\", \\\"{x:1308,y:950,t:1528139718816};\\\", \\\"{x:1307,y:954,t:1528139718832};\\\", \\\"{x:1305,y:959,t:1528139718849};\\\", \\\"{x:1305,y:965,t:1528139718866};\\\", \\\"{x:1305,y:972,t:1528139718882};\\\", \\\"{x:1305,y:975,t:1528139718899};\\\", \\\"{x:1305,y:978,t:1528139718916};\\\", \\\"{x:1305,y:979,t:1528139718932};\\\", \\\"{x:1305,y:981,t:1528139718948};\\\", \\\"{x:1305,y:982,t:1528139718966};\\\", \\\"{x:1305,y:985,t:1528139718983};\\\", \\\"{x:1306,y:989,t:1528139718999};\\\", \\\"{x:1308,y:992,t:1528139719016};\\\", \\\"{x:1308,y:994,t:1528139719032};\\\", \\\"{x:1308,y:996,t:1528139719049};\\\", \\\"{x:1309,y:998,t:1528139719067};\\\", \\\"{x:1312,y:1003,t:1528139719082};\\\", \\\"{x:1312,y:1006,t:1528139719099};\\\", \\\"{x:1313,y:1009,t:1528139719116};\\\", \\\"{x:1315,y:1013,t:1528139719132};\\\", \\\"{x:1317,y:1017,t:1528139719149};\\\", \\\"{x:1317,y:1018,t:1528139719206};\\\", \\\"{x:1316,y:1018,t:1528139719397};\\\", \\\"{x:1314,y:1016,t:1528139719406};\\\", \\\"{x:1312,y:1014,t:1528139719416};\\\", \\\"{x:1304,y:1008,t:1528139719433};\\\", \\\"{x:1294,y:1001,t:1528139719449};\\\", \\\"{x:1276,y:991,t:1528139719468};\\\", \\\"{x:1257,y:979,t:1528139719484};\\\", \\\"{x:1237,y:968,t:1528139719499};\\\", \\\"{x:1221,y:959,t:1528139719515};\\\", \\\"{x:1195,y:947,t:1528139719533};\\\", \\\"{x:1173,y:937,t:1528139719549};\\\", \\\"{x:1143,y:924,t:1528139719566};\\\", \\\"{x:1106,y:911,t:1528139719583};\\\", \\\"{x:1066,y:898,t:1528139719600};\\\", \\\"{x:1004,y:880,t:1528139719616};\\\", \\\"{x:948,y:861,t:1528139719633};\\\", \\\"{x:884,y:842,t:1528139719649};\\\", \\\"{x:842,y:823,t:1528139719667};\\\", \\\"{x:794,y:809,t:1528139719683};\\\", \\\"{x:761,y:797,t:1528139719700};\\\", \\\"{x:727,y:788,t:1528139719716};\\\", \\\"{x:688,y:775,t:1528139719732};\\\", \\\"{x:671,y:766,t:1528139719750};\\\", \\\"{x:653,y:759,t:1528139719766};\\\", \\\"{x:641,y:753,t:1528139719783};\\\", \\\"{x:632,y:747,t:1528139719800};\\\", \\\"{x:622,y:741,t:1528139719816};\\\", \\\"{x:614,y:737,t:1528139719833};\\\", \\\"{x:609,y:735,t:1528139719850};\\\", \\\"{x:606,y:733,t:1528139719867};\\\", \\\"{x:605,y:732,t:1528139719883};\\\", \\\"{x:603,y:731,t:1528139719900};\\\", \\\"{x:602,y:730,t:1528139719917};\\\", \\\"{x:601,y:729,t:1528139719933};\\\", \\\"{x:601,y:728,t:1528139719957};\\\", \\\"{x:601,y:725,t:1528139719973};\\\", \\\"{x:608,y:723,t:1528139719983};\\\", \\\"{x:632,y:712,t:1528139720001};\\\", \\\"{x:650,y:701,t:1528139720017};\\\", \\\"{x:672,y:689,t:1528139720035};\\\", \\\"{x:695,y:675,t:1528139720050};\\\", \\\"{x:733,y:661,t:1528139720067};\\\", \\\"{x:807,y:645,t:1528139720083};\\\", \\\"{x:866,y:628,t:1528139720100};\\\", \\\"{x:901,y:621,t:1528139720117};\\\", \\\"{x:908,y:619,t:1528139720133};\\\", \\\"{x:915,y:618,t:1528139720150};\\\", \\\"{x:921,y:617,t:1528139720167};\\\", \\\"{x:921,y:615,t:1528139720196};\\\", \\\"{x:921,y:614,t:1528139720204};\\\", \\\"{x:918,y:611,t:1528139720217};\\\", \\\"{x:911,y:605,t:1528139720233};\\\", \\\"{x:903,y:597,t:1528139720250};\\\", \\\"{x:900,y:590,t:1528139720268};\\\", \\\"{x:898,y:583,t:1528139720285};\\\", \\\"{x:898,y:580,t:1528139720302};\\\", \\\"{x:898,y:574,t:1528139720319};\\\", \\\"{x:897,y:573,t:1528139720359};\\\", \\\"{x:896,y:573,t:1528139720370};\\\", \\\"{x:891,y:571,t:1528139720387};\\\", \\\"{x:879,y:567,t:1528139720403};\\\", \\\"{x:866,y:564,t:1528139720420};\\\", \\\"{x:852,y:562,t:1528139720437};\\\", \\\"{x:843,y:560,t:1528139720453};\\\", \\\"{x:836,y:560,t:1528139720470};\\\", \\\"{x:833,y:560,t:1528139720486};\\\", \\\"{x:829,y:560,t:1528139720504};\\\", \\\"{x:826,y:561,t:1528139720519};\\\", \\\"{x:823,y:561,t:1528139720537};\\\", \\\"{x:821,y:562,t:1528139720553};\\\", \\\"{x:821,y:563,t:1528139720576};\\\", \\\"{x:821,y:570,t:1528139722057};\\\", \\\"{x:821,y:587,t:1528139722073};\\\", \\\"{x:821,y:597,t:1528139722090};\\\", \\\"{x:819,y:610,t:1528139722105};\\\", \\\"{x:817,y:620,t:1528139722121};\\\", \\\"{x:817,y:633,t:1528139722138};\\\", \\\"{x:817,y:635,t:1528139722154};\\\", \\\"{x:817,y:637,t:1528139722170};\\\", \\\"{x:817,y:638,t:1528139722188};\\\", \\\"{x:817,y:639,t:1528139722205};\\\", \\\"{x:817,y:640,t:1528139722320};\\\", \\\"{x:823,y:634,t:1528139722327};\\\", \\\"{x:829,y:624,t:1528139722340};\\\", \\\"{x:840,y:607,t:1528139722356};\\\", \\\"{x:847,y:591,t:1528139722373};\\\", \\\"{x:852,y:581,t:1528139722389};\\\", \\\"{x:856,y:574,t:1528139722405};\\\", \\\"{x:858,y:572,t:1528139722421};\\\", \\\"{x:859,y:572,t:1528139722438};\\\", \\\"{x:860,y:570,t:1528139722456};\\\", \\\"{x:858,y:570,t:1528139723224};\\\", \\\"{x:856,y:573,t:1528139723240};\\\", \\\"{x:853,y:576,t:1528139723256};\\\", \\\"{x:851,y:578,t:1528139723272};\\\", \\\"{x:848,y:583,t:1528139723290};\\\", \\\"{x:846,y:586,t:1528139723305};\\\", \\\"{x:843,y:589,t:1528139723322};\\\", \\\"{x:841,y:591,t:1528139723339};\\\", \\\"{x:840,y:592,t:1528139723355};\\\", \\\"{x:839,y:595,t:1528139723372};\\\", \\\"{x:836,y:598,t:1528139723390};\\\", \\\"{x:831,y:600,t:1528139723406};\\\", \\\"{x:831,y:601,t:1528139723422};\\\", \\\"{x:831,y:603,t:1528139723552};\\\", \\\"{x:831,y:605,t:1528139723560};\\\", \\\"{x:831,y:606,t:1528139723576};\\\", \\\"{x:831,y:608,t:1528139723608};\\\", \\\"{x:831,y:609,t:1528139724368};\\\", \\\"{x:830,y:610,t:1528139724377};\\\", \\\"{x:829,y:610,t:1528139724400};\\\", \\\"{x:828,y:611,t:1528139724416};\\\", \\\"{x:826,y:612,t:1528139725185};\\\", \\\"{x:822,y:613,t:1528139725207};\\\", \\\"{x:821,y:613,t:1528139725224};\\\", \\\"{x:819,y:613,t:1528139725240};\\\", \\\"{x:818,y:614,t:1528139725257};\\\", \\\"{x:817,y:614,t:1528139725288};\\\", \\\"{x:816,y:614,t:1528139725303};\\\", \\\"{x:815,y:615,t:1528139725328};\\\", \\\"{x:814,y:616,t:1528139725360};\\\", \\\"{x:813,y:616,t:1528139725384};\\\", \\\"{x:812,y:616,t:1528139725424};\\\", \\\"{x:811,y:616,t:1528139725442};\\\", \\\"{x:810,y:618,t:1528139725458};\\\", \\\"{x:808,y:618,t:1528139725476};\\\", \\\"{x:806,y:618,t:1528139725492};\\\", \\\"{x:805,y:618,t:1528139725536};\\\", \\\"{x:803,y:619,t:1528139725552};\\\", \\\"{x:803,y:620,t:1528139725600};\\\", \\\"{x:802,y:620,t:1528139725616};\\\", \\\"{x:801,y:620,t:1528139725648};\\\", \\\"{x:800,y:620,t:1528139725696};\\\", \\\"{x:798,y:620,t:1528139725720};\\\", \\\"{x:797,y:620,t:1528139725752};\\\", \\\"{x:797,y:621,t:1528139725760};\\\", \\\"{x:796,y:621,t:1528139725792};\\\", \\\"{x:795,y:621,t:1528139725849};\\\", \\\"{x:794,y:621,t:1528139725904};\\\", \\\"{x:793,y:622,t:1528139725944};\\\", \\\"{x:792,y:622,t:1528139726049};\\\", \\\"{x:791,y:622,t:1528139726135};\\\", \\\"{x:790,y:622,t:1528139726272};\\\", \\\"{x:789,y:623,t:1528139726288};\\\", \\\"{x:788,y:624,t:1528139726295};\\\", \\\"{x:787,y:625,t:1528139726370};\\\", \\\"{x:786,y:625,t:1528139726391};\\\", \\\"{x:785,y:625,t:1528139726431};\\\", \\\"{x:785,y:626,t:1528139726441};\\\", \\\"{x:784,y:627,t:1528139726459};\\\", \\\"{x:783,y:627,t:1528139726504};\\\", \\\"{x:783,y:628,t:1528139726625};\\\", \\\"{x:782,y:628,t:1528139726672};\\\", \\\"{x:781,y:628,t:1528139726713};\\\", \\\"{x:779,y:629,t:1528139726728};\\\", \\\"{x:779,y:630,t:1528139726752};\\\", \\\"{x:777,y:630,t:1528139726801};\\\", \\\"{x:776,y:631,t:1528139726848};\\\", \\\"{x:774,y:631,t:1528139726952};\\\", \\\"{x:773,y:632,t:1528139726986};\\\", \\\"{x:769,y:634,t:1528139728952};\\\", \\\"{x:762,y:638,t:1528139728960};\\\", \\\"{x:750,y:644,t:1528139728977};\\\", \\\"{x:740,y:647,t:1528139728993};\\\", \\\"{x:732,y:653,t:1528139729010};\\\", \\\"{x:723,y:656,t:1528139729029};\\\", \\\"{x:715,y:658,t:1528139729044};\\\", \\\"{x:708,y:659,t:1528139729060};\\\", \\\"{x:704,y:660,t:1528139729076};\\\", \\\"{x:701,y:660,t:1528139729093};\\\", \\\"{x:699,y:661,t:1528139729110};\\\", \\\"{x:694,y:663,t:1528139729128};\\\", \\\"{x:692,y:664,t:1528139729143};\\\", \\\"{x:691,y:665,t:1528139729160};\\\", \\\"{x:687,y:666,t:1528139729177};\\\", \\\"{x:685,y:668,t:1528139729193};\\\", \\\"{x:679,y:670,t:1528139729211};\\\", \\\"{x:671,y:674,t:1528139729227};\\\", \\\"{x:667,y:674,t:1528139729244};\\\", \\\"{x:660,y:677,t:1528139729260};\\\", \\\"{x:654,y:678,t:1528139729277};\\\", \\\"{x:648,y:682,t:1528139729294};\\\", \\\"{x:638,y:684,t:1528139729311};\\\", \\\"{x:630,y:687,t:1528139729328};\\\", \\\"{x:625,y:689,t:1528139729344};\\\", \\\"{x:619,y:691,t:1528139729361};\\\", \\\"{x:617,y:691,t:1528139729377};\\\", \\\"{x:615,y:693,t:1528139729393};\\\", \\\"{x:611,y:695,t:1528139729411};\\\", \\\"{x:608,y:695,t:1528139729428};\\\", \\\"{x:607,y:697,t:1528139729445};\\\", \\\"{x:604,y:698,t:1528139729460};\\\", \\\"{x:601,y:700,t:1528139729477};\\\", \\\"{x:596,y:703,t:1528139729494};\\\", \\\"{x:594,y:704,t:1528139729510};\\\", \\\"{x:590,y:705,t:1528139729527};\\\", \\\"{x:583,y:709,t:1528139729545};\\\", \\\"{x:579,y:711,t:1528139729560};\\\", \\\"{x:575,y:713,t:1528139729577};\\\", \\\"{x:573,y:715,t:1528139729595};\\\", \\\"{x:572,y:715,t:1528139729610};\\\", \\\"{x:569,y:717,t:1528139729627};\\\", \\\"{x:568,y:718,t:1528139729644};\\\", \\\"{x:565,y:722,t:1528139729661};\\\", \\\"{x:561,y:724,t:1528139729678};\\\", \\\"{x:557,y:727,t:1528139729694};\\\", \\\"{x:552,y:731,t:1528139729711};\\\", \\\"{x:548,y:737,t:1528139729728};\\\", \\\"{x:543,y:741,t:1528139729744};\\\", \\\"{x:536,y:747,t:1528139729761};\\\", \\\"{x:531,y:750,t:1528139729778};\\\", \\\"{x:528,y:753,t:1528139729796};\\\", \\\"{x:525,y:756,t:1528139729810};\\\", \\\"{x:523,y:758,t:1528139729828};\\\", \\\"{x:519,y:761,t:1528139729845};\\\", \\\"{x:518,y:762,t:1528139729861};\\\", \\\"{x:515,y:764,t:1528139729878};\\\", \\\"{x:514,y:765,t:1528139729896};\\\", \\\"{x:513,y:766,t:1528139729911};\\\", \\\"{x:512,y:766,t:1528139729960};\\\" ] }, { \\\"rt\\\": 9380, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 680641, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:766,t:1528139732433};\\\", \\\"{x:509,y:766,t:1528139732447};\\\", \\\"{x:505,y:765,t:1528139732463};\\\", \\\"{x:499,y:761,t:1528139732481};\\\", \\\"{x:496,y:760,t:1528139732497};\\\", \\\"{x:494,y:759,t:1528139732513};\\\", \\\"{x:493,y:759,t:1528139732530};\\\", \\\"{x:492,y:759,t:1528139732577};\\\", \\\"{x:492,y:758,t:1528139732584};\\\", \\\"{x:491,y:758,t:1528139732769};\\\", \\\"{x:490,y:758,t:1528139732792};\\\", \\\"{x:489,y:758,t:1528139732840};\\\", \\\"{x:488,y:758,t:1528139732993};\\\", \\\"{x:487,y:758,t:1528139733041};\\\", \\\"{x:486,y:758,t:1528139733088};\\\", \\\"{x:486,y:757,t:1528139733616};\\\", \\\"{x:486,y:756,t:1528139733632};\\\", \\\"{x:496,y:761,t:1528139733648};\\\", \\\"{x:509,y:763,t:1528139733664};\\\", \\\"{x:519,y:765,t:1528139733681};\\\", \\\"{x:525,y:769,t:1528139733698};\\\", \\\"{x:544,y:776,t:1528139733714};\\\", \\\"{x:566,y:780,t:1528139733731};\\\", \\\"{x:580,y:781,t:1528139733748};\\\", \\\"{x:594,y:781,t:1528139733764};\\\", \\\"{x:603,y:782,t:1528139733781};\\\", \\\"{x:613,y:785,t:1528139733798};\\\", \\\"{x:624,y:786,t:1528139733814};\\\", \\\"{x:628,y:787,t:1528139733831};\\\", \\\"{x:634,y:789,t:1528139733848};\\\", \\\"{x:635,y:789,t:1528139733864};\\\", \\\"{x:638,y:790,t:1528139733881};\\\", \\\"{x:640,y:790,t:1528139733904};\\\", \\\"{x:641,y:790,t:1528139733920};\\\", \\\"{x:644,y:791,t:1528139733936};\\\", \\\"{x:645,y:792,t:1528139733948};\\\", \\\"{x:650,y:792,t:1528139733964};\\\", \\\"{x:656,y:792,t:1528139733981};\\\", \\\"{x:660,y:792,t:1528139733998};\\\", \\\"{x:665,y:792,t:1528139734015};\\\", \\\"{x:670,y:793,t:1528139734031};\\\", \\\"{x:686,y:794,t:1528139734048};\\\", \\\"{x:696,y:796,t:1528139734064};\\\", \\\"{x:713,y:798,t:1528139734081};\\\", \\\"{x:731,y:803,t:1528139734098};\\\", \\\"{x:750,y:804,t:1528139734114};\\\", \\\"{x:775,y:804,t:1528139734130};\\\", \\\"{x:802,y:804,t:1528139734148};\\\", \\\"{x:831,y:804,t:1528139734164};\\\", \\\"{x:858,y:804,t:1528139734181};\\\", \\\"{x:878,y:803,t:1528139734198};\\\", \\\"{x:902,y:795,t:1528139734215};\\\", \\\"{x:950,y:779,t:1528139734231};\\\", \\\"{x:1038,y:736,t:1528139734247};\\\", \\\"{x:1060,y:724,t:1528139734264};\\\", \\\"{x:1080,y:707,t:1528139734281};\\\", \\\"{x:1096,y:693,t:1528139734298};\\\", \\\"{x:1108,y:681,t:1528139734315};\\\", \\\"{x:1114,y:674,t:1528139734331};\\\", \\\"{x:1117,y:670,t:1528139734347};\\\", \\\"{x:1119,y:667,t:1528139734365};\\\", \\\"{x:1120,y:665,t:1528139734381};\\\", \\\"{x:1120,y:663,t:1528139734398};\\\", \\\"{x:1120,y:660,t:1528139734415};\\\", \\\"{x:1120,y:655,t:1528139734431};\\\", \\\"{x:1115,y:644,t:1528139734448};\\\", \\\"{x:1109,y:636,t:1528139734466};\\\", \\\"{x:1101,y:628,t:1528139734481};\\\", \\\"{x:1094,y:618,t:1528139734499};\\\", \\\"{x:1086,y:610,t:1528139734515};\\\", \\\"{x:1082,y:605,t:1528139734531};\\\", \\\"{x:1081,y:602,t:1528139734547};\\\", \\\"{x:1080,y:601,t:1528139734565};\\\", \\\"{x:1079,y:599,t:1528139734582};\\\", \\\"{x:1079,y:597,t:1528139734597};\\\", \\\"{x:1079,y:595,t:1528139734615};\\\", \\\"{x:1079,y:589,t:1528139734631};\\\", \\\"{x:1080,y:584,t:1528139734647};\\\", \\\"{x:1083,y:578,t:1528139734665};\\\", \\\"{x:1086,y:577,t:1528139734682};\\\", \\\"{x:1087,y:575,t:1528139734698};\\\", \\\"{x:1088,y:574,t:1528139734715};\\\", \\\"{x:1089,y:574,t:1528139734732};\\\", \\\"{x:1089,y:573,t:1528139734760};\\\", \\\"{x:1090,y:572,t:1528139734768};\\\", \\\"{x:1092,y:572,t:1528139734783};\\\", \\\"{x:1096,y:570,t:1528139734799};\\\", \\\"{x:1098,y:570,t:1528139734815};\\\", \\\"{x:1106,y:570,t:1528139734833};\\\", \\\"{x:1112,y:570,t:1528139734849};\\\", \\\"{x:1127,y:570,t:1528139734865};\\\", \\\"{x:1142,y:570,t:1528139734882};\\\", \\\"{x:1156,y:570,t:1528139734898};\\\", \\\"{x:1169,y:570,t:1528139734916};\\\", \\\"{x:1177,y:570,t:1528139734932};\\\", \\\"{x:1188,y:570,t:1528139734948};\\\", \\\"{x:1201,y:569,t:1528139734965};\\\", \\\"{x:1216,y:568,t:1528139734983};\\\", \\\"{x:1231,y:568,t:1528139734999};\\\", \\\"{x:1241,y:568,t:1528139735015};\\\", \\\"{x:1253,y:568,t:1528139735033};\\\", \\\"{x:1263,y:568,t:1528139735049};\\\", \\\"{x:1267,y:567,t:1528139735065};\\\", \\\"{x:1269,y:566,t:1528139735082};\\\", \\\"{x:1270,y:566,t:1528139735099};\\\", \\\"{x:1273,y:566,t:1528139735115};\\\", \\\"{x:1277,y:566,t:1528139735135};\\\", \\\"{x:1280,y:565,t:1528139735149};\\\", \\\"{x:1283,y:565,t:1528139735165};\\\", \\\"{x:1285,y:565,t:1528139735181};\\\", \\\"{x:1287,y:565,t:1528139735199};\\\", \\\"{x:1288,y:565,t:1528139735215};\\\", \\\"{x:1290,y:565,t:1528139735232};\\\", \\\"{x:1293,y:565,t:1528139735249};\\\", \\\"{x:1295,y:565,t:1528139735265};\\\", \\\"{x:1296,y:565,t:1528139735288};\\\", \\\"{x:1298,y:565,t:1528139735304};\\\", \\\"{x:1299,y:565,t:1528139735315};\\\", \\\"{x:1303,y:565,t:1528139735332};\\\", \\\"{x:1309,y:565,t:1528139735349};\\\", \\\"{x:1314,y:563,t:1528139735365};\\\", \\\"{x:1318,y:563,t:1528139735382};\\\", \\\"{x:1329,y:562,t:1528139735400};\\\", \\\"{x:1339,y:562,t:1528139735416};\\\", \\\"{x:1357,y:562,t:1528139735432};\\\", \\\"{x:1368,y:562,t:1528139735449};\\\", \\\"{x:1381,y:562,t:1528139735465};\\\", \\\"{x:1392,y:561,t:1528139735482};\\\", \\\"{x:1399,y:561,t:1528139735499};\\\", \\\"{x:1406,y:561,t:1528139735516};\\\", \\\"{x:1413,y:560,t:1528139735533};\\\", \\\"{x:1419,y:559,t:1528139735550};\\\", \\\"{x:1421,y:558,t:1528139735566};\\\", \\\"{x:1422,y:558,t:1528139735582};\\\", \\\"{x:1423,y:558,t:1528139735599};\\\", \\\"{x:1425,y:558,t:1528139735616};\\\", \\\"{x:1426,y:558,t:1528139735640};\\\", \\\"{x:1428,y:558,t:1528139735656};\\\", \\\"{x:1429,y:558,t:1528139735672};\\\", \\\"{x:1431,y:558,t:1528139735682};\\\", \\\"{x:1439,y:558,t:1528139735700};\\\", \\\"{x:1449,y:558,t:1528139735716};\\\", \\\"{x:1456,y:558,t:1528139735732};\\\", \\\"{x:1468,y:558,t:1528139735750};\\\", \\\"{x:1473,y:558,t:1528139735766};\\\", \\\"{x:1477,y:558,t:1528139735783};\\\", \\\"{x:1480,y:558,t:1528139735800};\\\", \\\"{x:1486,y:558,t:1528139735817};\\\", \\\"{x:1488,y:559,t:1528139735833};\\\", \\\"{x:1491,y:560,t:1528139735849};\\\", \\\"{x:1496,y:562,t:1528139735867};\\\", \\\"{x:1504,y:562,t:1528139735883};\\\", \\\"{x:1518,y:563,t:1528139735900};\\\", \\\"{x:1528,y:564,t:1528139735917};\\\", \\\"{x:1542,y:568,t:1528139735933};\\\", \\\"{x:1559,y:572,t:1528139735949};\\\", \\\"{x:1581,y:574,t:1528139735967};\\\", \\\"{x:1603,y:579,t:1528139735982};\\\", \\\"{x:1639,y:583,t:1528139736000};\\\", \\\"{x:1653,y:586,t:1528139736016};\\\", \\\"{x:1666,y:586,t:1528139736033};\\\", \\\"{x:1672,y:586,t:1528139736050};\\\", \\\"{x:1674,y:586,t:1528139736067};\\\", \\\"{x:1675,y:586,t:1528139736083};\\\", \\\"{x:1674,y:586,t:1528139736128};\\\", \\\"{x:1670,y:586,t:1528139736136};\\\", \\\"{x:1663,y:585,t:1528139736150};\\\", \\\"{x:1644,y:577,t:1528139736166};\\\", \\\"{x:1621,y:573,t:1528139736183};\\\", \\\"{x:1594,y:569,t:1528139736198};\\\", \\\"{x:1558,y:569,t:1528139736215};\\\", \\\"{x:1522,y:569,t:1528139736233};\\\", \\\"{x:1463,y:569,t:1528139736249};\\\", \\\"{x:1383,y:569,t:1528139736266};\\\", \\\"{x:1294,y:569,t:1528139736283};\\\", \\\"{x:1222,y:569,t:1528139736298};\\\", \\\"{x:1144,y:569,t:1528139736316};\\\", \\\"{x:1055,y:569,t:1528139736333};\\\", \\\"{x:972,y:569,t:1528139736349};\\\", \\\"{x:888,y:569,t:1528139736366};\\\", \\\"{x:826,y:566,t:1528139736383};\\\", \\\"{x:777,y:562,t:1528139736399};\\\", \\\"{x:696,y:562,t:1528139736416};\\\", \\\"{x:654,y:562,t:1528139736432};\\\", \\\"{x:619,y:562,t:1528139736449};\\\", \\\"{x:588,y:559,t:1528139736466};\\\", \\\"{x:565,y:556,t:1528139736482};\\\", \\\"{x:537,y:553,t:1528139736501};\\\", \\\"{x:522,y:551,t:1528139736515};\\\", \\\"{x:509,y:548,t:1528139736533};\\\", \\\"{x:497,y:546,t:1528139736551};\\\", \\\"{x:490,y:543,t:1528139736566};\\\", \\\"{x:486,y:542,t:1528139736583};\\\", \\\"{x:484,y:541,t:1528139736600};\\\", \\\"{x:483,y:541,t:1528139736617};\\\", \\\"{x:483,y:540,t:1528139736640};\\\", \\\"{x:483,y:539,t:1528139736650};\\\", \\\"{x:494,y:531,t:1528139736667};\\\", \\\"{x:515,y:523,t:1528139736684};\\\", \\\"{x:568,y:512,t:1528139736700};\\\", \\\"{x:625,y:502,t:1528139736717};\\\", \\\"{x:647,y:497,t:1528139736733};\\\", \\\"{x:662,y:491,t:1528139736750};\\\", \\\"{x:664,y:491,t:1528139736766};\\\", \\\"{x:665,y:491,t:1528139736783};\\\", \\\"{x:662,y:492,t:1528139736928};\\\", \\\"{x:661,y:493,t:1528139736936};\\\", \\\"{x:660,y:493,t:1528139736950};\\\", \\\"{x:656,y:495,t:1528139736967};\\\", \\\"{x:651,y:496,t:1528139736983};\\\", \\\"{x:649,y:496,t:1528139737008};\\\", \\\"{x:646,y:496,t:1528139737593};\\\", \\\"{x:641,y:496,t:1528139737603};\\\", \\\"{x:630,y:496,t:1528139737618};\\\", \\\"{x:619,y:496,t:1528139737633};\\\", \\\"{x:611,y:498,t:1528139737650};\\\", \\\"{x:605,y:499,t:1528139737667};\\\", \\\"{x:604,y:499,t:1528139737684};\\\", \\\"{x:603,y:499,t:1528139737701};\\\", \\\"{x:602,y:499,t:1528139737717};\\\", \\\"{x:601,y:503,t:1528139738440};\\\", \\\"{x:601,y:507,t:1528139738451};\\\", \\\"{x:602,y:513,t:1528139738468};\\\", \\\"{x:624,y:517,t:1528139738486};\\\", \\\"{x:647,y:518,t:1528139738502};\\\", \\\"{x:702,y:522,t:1528139738517};\\\", \\\"{x:749,y:522,t:1528139738535};\\\", \\\"{x:776,y:522,t:1528139738551};\\\", \\\"{x:790,y:522,t:1528139738568};\\\", \\\"{x:794,y:523,t:1528139738585};\\\", \\\"{x:799,y:526,t:1528139738602};\\\", \\\"{x:801,y:527,t:1528139738618};\\\", \\\"{x:802,y:527,t:1528139738635};\\\", \\\"{x:803,y:529,t:1528139738651};\\\", \\\"{x:803,y:530,t:1528139738668};\\\", \\\"{x:808,y:534,t:1528139738685};\\\", \\\"{x:811,y:536,t:1528139738701};\\\", \\\"{x:812,y:537,t:1528139738718};\\\", \\\"{x:814,y:537,t:1528139738735};\\\", \\\"{x:815,y:537,t:1528139738752};\\\", \\\"{x:818,y:538,t:1528139738768};\\\", \\\"{x:825,y:540,t:1528139738786};\\\", \\\"{x:832,y:542,t:1528139738801};\\\", \\\"{x:843,y:545,t:1528139738817};\\\", \\\"{x:851,y:548,t:1528139738835};\\\", \\\"{x:853,y:548,t:1528139738852};\\\", \\\"{x:855,y:549,t:1528139738868};\\\", \\\"{x:854,y:549,t:1528139739072};\\\", \\\"{x:853,y:549,t:1528139739085};\\\", \\\"{x:851,y:549,t:1528139739102};\\\", \\\"{x:849,y:549,t:1528139739118};\\\", \\\"{x:848,y:549,t:1528139739135};\\\", \\\"{x:847,y:549,t:1528139739152};\\\", \\\"{x:845,y:548,t:1528139739281};\\\", \\\"{x:844,y:548,t:1528139739305};\\\", \\\"{x:843,y:548,t:1528139739360};\\\", \\\"{x:836,y:551,t:1528139740088};\\\", \\\"{x:821,y:567,t:1528139740103};\\\", \\\"{x:809,y:583,t:1528139740118};\\\", \\\"{x:794,y:604,t:1528139740136};\\\", \\\"{x:783,y:616,t:1528139740153};\\\", \\\"{x:773,y:627,t:1528139740169};\\\", \\\"{x:755,y:641,t:1528139740186};\\\", \\\"{x:743,y:656,t:1528139740202};\\\", \\\"{x:733,y:666,t:1528139740219};\\\", \\\"{x:720,y:676,t:1528139740236};\\\", \\\"{x:705,y:691,t:1528139740253};\\\", \\\"{x:691,y:702,t:1528139740269};\\\", \\\"{x:679,y:712,t:1528139740286};\\\", \\\"{x:669,y:718,t:1528139740303};\\\", \\\"{x:660,y:726,t:1528139740319};\\\", \\\"{x:648,y:732,t:1528139740336};\\\", \\\"{x:632,y:739,t:1528139740353};\\\", \\\"{x:625,y:741,t:1528139740370};\\\", \\\"{x:616,y:744,t:1528139740386};\\\", \\\"{x:605,y:745,t:1528139740403};\\\", \\\"{x:596,y:746,t:1528139740420};\\\", \\\"{x:587,y:746,t:1528139740436};\\\", \\\"{x:580,y:748,t:1528139740453};\\\", \\\"{x:573,y:748,t:1528139740470};\\\", \\\"{x:564,y:748,t:1528139740489};\\\", \\\"{x:560,y:748,t:1528139740503};\\\", \\\"{x:553,y:748,t:1528139740519};\\\", \\\"{x:544,y:747,t:1528139740535};\\\", \\\"{x:536,y:745,t:1528139740553};\\\", \\\"{x:533,y:744,t:1528139740570};\\\", \\\"{x:532,y:743,t:1528139740586};\\\", \\\"{x:531,y:743,t:1528139740602};\\\" ] }, { \\\"rt\\\": 39093, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 720991, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -O -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:742,t:1528139742824};\\\", \\\"{x:506,y:735,t:1528139742838};\\\", \\\"{x:393,y:719,t:1528139742856};\\\", \\\"{x:309,y:702,t:1528139742871};\\\", \\\"{x:179,y:686,t:1528139742888};\\\", \\\"{x:28,y:673,t:1528139742904};\\\", \\\"{x:0,y:649,t:1528139742921};\\\", \\\"{x:0,y:618,t:1528139742938};\\\", \\\"{x:0,y:596,t:1528139742954};\\\", \\\"{x:0,y:574,t:1528139742971};\\\", \\\"{x:0,y:558,t:1528139742988};\\\", \\\"{x:0,y:543,t:1528139743005};\\\", \\\"{x:0,y:538,t:1528139743021};\\\", \\\"{x:0,y:536,t:1528139743038};\\\", \\\"{x:0,y:534,t:1528139743056};\\\", \\\"{x:0,y:531,t:1528139743071};\\\", \\\"{x:9,y:515,t:1528139743087};\\\", \\\"{x:13,y:514,t:1528139743105};\\\", \\\"{x:17,y:514,t:1528139743121};\\\", \\\"{x:19,y:514,t:1528139743138};\\\", \\\"{x:84,y:511,t:1528139743156};\\\", \\\"{x:204,y:519,t:1528139743172};\\\", \\\"{x:316,y:539,t:1528139743189};\\\", \\\"{x:401,y:549,t:1528139743206};\\\", \\\"{x:513,y:567,t:1528139743223};\\\", \\\"{x:552,y:568,t:1528139743238};\\\", \\\"{x:578,y:571,t:1528139743255};\\\", \\\"{x:577,y:569,t:1528139743271};\\\", \\\"{x:578,y:569,t:1528139743288};\\\", \\\"{x:581,y:569,t:1528139743305};\\\", \\\"{x:580,y:569,t:1528139745440};\\\", \\\"{x:579,y:569,t:1528139745480};\\\", \\\"{x:578,y:569,t:1528139745521};\\\", \\\"{x:577,y:569,t:1528139745625};\\\", \\\"{x:576,y:569,t:1528139745640};\\\", \\\"{x:575,y:568,t:1528139745680};\\\", \\\"{x:573,y:568,t:1528139745728};\\\", \\\"{x:572,y:568,t:1528139745743};\\\", \\\"{x:571,y:568,t:1528139745768};\\\", \\\"{x:570,y:568,t:1528139745781};\\\", \\\"{x:569,y:568,t:1528139745807};\\\", \\\"{x:568,y:568,t:1528139745832};\\\", \\\"{x:567,y:568,t:1528139745921};\\\", \\\"{x:566,y:568,t:1528139745944};\\\", \\\"{x:565,y:568,t:1528139745960};\\\", \\\"{x:564,y:568,t:1528139745968};\\\", \\\"{x:563,y:568,t:1528139745982};\\\", \\\"{x:562,y:568,t:1528139746016};\\\", \\\"{x:561,y:568,t:1528139746232};\\\", \\\"{x:560,y:568,t:1528139746272};\\\", \\\"{x:559,y:568,t:1528139746296};\\\", \\\"{x:558,y:568,t:1528139746304};\\\", \\\"{x:557,y:568,t:1528139746320};\\\", \\\"{x:556,y:568,t:1528139746360};\\\", \\\"{x:554,y:568,t:1528139746448};\\\", \\\"{x:553,y:568,t:1528139747152};\\\", \\\"{x:553,y:567,t:1528139747192};\\\", \\\"{x:553,y:566,t:1528139747200};\\\", \\\"{x:553,y:565,t:1528139747289};\\\", \\\"{x:555,y:564,t:1528139747320};\\\", \\\"{x:555,y:563,t:1528139747360};\\\", \\\"{x:557,y:563,t:1528139747378};\\\", \\\"{x:558,y:563,t:1528139747400};\\\", \\\"{x:561,y:563,t:1528139747410};\\\", \\\"{x:564,y:565,t:1528139747428};\\\", \\\"{x:573,y:570,t:1528139747444};\\\", \\\"{x:580,y:574,t:1528139747461};\\\", \\\"{x:591,y:581,t:1528139747478};\\\", \\\"{x:601,y:587,t:1528139747495};\\\", \\\"{x:613,y:594,t:1528139747512};\\\", \\\"{x:650,y:613,t:1528139747544};\\\", \\\"{x:658,y:617,t:1528139747558};\\\", \\\"{x:664,y:618,t:1528139747575};\\\", \\\"{x:674,y:620,t:1528139747593};\\\", \\\"{x:685,y:622,t:1528139747608};\\\", \\\"{x:686,y:624,t:1528139747625};\\\", \\\"{x:693,y:628,t:1528139747642};\\\", \\\"{x:694,y:629,t:1528139747658};\\\", \\\"{x:695,y:629,t:1528139747696};\\\", \\\"{x:699,y:629,t:1528139747708};\\\", \\\"{x:707,y:629,t:1528139747725};\\\", \\\"{x:708,y:632,t:1528139747744};\\\", \\\"{x:709,y:633,t:1528139747760};\\\", \\\"{x:711,y:633,t:1528139747775};\\\", \\\"{x:714,y:635,t:1528139747824};\\\", \\\"{x:716,y:636,t:1528139747832};\\\", \\\"{x:716,y:637,t:1528139747856};\\\", \\\"{x:717,y:637,t:1528139747872};\\\", \\\"{x:719,y:637,t:1528139747880};\\\", \\\"{x:724,y:637,t:1528139747891};\\\", \\\"{x:742,y:637,t:1528139747909};\\\", \\\"{x:756,y:637,t:1528139747925};\\\", \\\"{x:777,y:637,t:1528139747942};\\\", \\\"{x:806,y:641,t:1528139747959};\\\", \\\"{x:826,y:646,t:1528139747975};\\\", \\\"{x:858,y:648,t:1528139747991};\\\", \\\"{x:887,y:653,t:1528139748008};\\\", \\\"{x:908,y:657,t:1528139748025};\\\", \\\"{x:926,y:661,t:1528139748042};\\\", \\\"{x:967,y:666,t:1528139748059};\\\", \\\"{x:987,y:666,t:1528139748075};\\\", \\\"{x:1005,y:666,t:1528139748092};\\\", \\\"{x:1012,y:666,t:1528139748109};\\\", \\\"{x:1022,y:666,t:1528139748125};\\\", \\\"{x:1025,y:666,t:1528139748142};\\\", \\\"{x:1035,y:666,t:1528139748158};\\\", \\\"{x:1043,y:666,t:1528139748175};\\\", \\\"{x:1066,y:668,t:1528139748192};\\\", \\\"{x:1081,y:669,t:1528139748208};\\\", \\\"{x:1099,y:669,t:1528139748225};\\\", \\\"{x:1112,y:669,t:1528139748242};\\\", \\\"{x:1132,y:669,t:1528139748258};\\\", \\\"{x:1155,y:669,t:1528139748275};\\\", \\\"{x:1174,y:669,t:1528139748292};\\\", \\\"{x:1193,y:668,t:1528139748307};\\\", \\\"{x:1208,y:666,t:1528139748325};\\\", \\\"{x:1218,y:666,t:1528139748342};\\\", \\\"{x:1231,y:663,t:1528139748358};\\\", \\\"{x:1237,y:663,t:1528139748376};\\\", \\\"{x:1239,y:663,t:1528139748391};\\\", \\\"{x:1242,y:661,t:1528139748408};\\\", \\\"{x:1246,y:660,t:1528139748424};\\\", \\\"{x:1250,y:659,t:1528139748440};\\\", \\\"{x:1253,y:659,t:1528139748458};\\\", \\\"{x:1255,y:658,t:1528139748475};\\\", \\\"{x:1256,y:658,t:1528139748491};\\\", \\\"{x:1258,y:657,t:1528139748508};\\\", \\\"{x:1260,y:656,t:1528139748528};\\\", \\\"{x:1261,y:655,t:1528139748568};\\\", \\\"{x:1261,y:653,t:1528139748673};\\\", \\\"{x:1261,y:651,t:1528139748680};\\\", \\\"{x:1259,y:649,t:1528139748691};\\\", \\\"{x:1254,y:644,t:1528139748708};\\\", \\\"{x:1254,y:643,t:1528139748724};\\\", \\\"{x:1252,y:641,t:1528139748742};\\\", \\\"{x:1251,y:639,t:1528139748758};\\\", \\\"{x:1251,y:638,t:1528139748774};\\\", \\\"{x:1251,y:635,t:1528139749040};\\\", \\\"{x:1251,y:634,t:1528139749064};\\\", \\\"{x:1251,y:632,t:1528139749074};\\\", \\\"{x:1252,y:630,t:1528139749096};\\\", \\\"{x:1252,y:629,t:1528139749113};\\\", \\\"{x:1253,y:628,t:1528139749128};\\\", \\\"{x:1254,y:627,t:1528139749140};\\\", \\\"{x:1255,y:627,t:1528139749157};\\\", \\\"{x:1255,y:626,t:1528139749201};\\\", \\\"{x:1256,y:626,t:1528139749265};\\\", \\\"{x:1257,y:625,t:1528139749352};\\\", \\\"{x:1258,y:624,t:1528139749368};\\\", \\\"{x:1259,y:623,t:1528139749376};\\\", \\\"{x:1260,y:622,t:1528139749390};\\\", \\\"{x:1261,y:621,t:1528139749407};\\\", \\\"{x:1262,y:620,t:1528139749423};\\\", \\\"{x:1263,y:619,t:1528139749440};\\\", \\\"{x:1264,y:618,t:1528139749456};\\\", \\\"{x:1265,y:618,t:1528139749497};\\\", \\\"{x:1266,y:618,t:1528139749507};\\\", \\\"{x:1267,y:617,t:1528139749523};\\\", \\\"{x:1268,y:616,t:1528139749543};\\\", \\\"{x:1269,y:615,t:1528139749575};\\\", \\\"{x:1270,y:615,t:1528139749591};\\\", \\\"{x:1271,y:615,t:1528139749631};\\\", \\\"{x:1272,y:615,t:1528139749648};\\\", \\\"{x:1273,y:615,t:1528139749672};\\\", \\\"{x:1274,y:615,t:1528139749769};\\\", \\\"{x:1275,y:614,t:1528139749880};\\\", \\\"{x:1276,y:614,t:1528139749961};\\\", \\\"{x:1277,y:614,t:1528139749973};\\\", \\\"{x:1280,y:614,t:1528139749989};\\\", \\\"{x:1282,y:614,t:1528139750006};\\\", \\\"{x:1286,y:614,t:1528139750023};\\\", \\\"{x:1288,y:614,t:1528139750039};\\\", \\\"{x:1290,y:614,t:1528139750056};\\\", \\\"{x:1291,y:613,t:1528139750073};\\\", \\\"{x:1292,y:613,t:1528139750521};\\\", \\\"{x:1291,y:616,t:1528139750544};\\\", \\\"{x:1290,y:618,t:1528139750555};\\\", \\\"{x:1288,y:621,t:1528139750572};\\\", \\\"{x:1284,y:623,t:1528139750589};\\\", \\\"{x:1283,y:625,t:1528139750605};\\\", \\\"{x:1282,y:625,t:1528139750622};\\\", \\\"{x:1281,y:626,t:1528139750639};\\\", \\\"{x:1281,y:627,t:1528139750656};\\\", \\\"{x:1281,y:628,t:1528139750697};\\\", \\\"{x:1279,y:629,t:1528139750712};\\\", \\\"{x:1279,y:630,t:1528139750745};\\\", \\\"{x:1278,y:631,t:1528139750756};\\\", \\\"{x:1278,y:633,t:1528139750772};\\\", \\\"{x:1276,y:635,t:1528139750792};\\\", \\\"{x:1275,y:636,t:1528139750816};\\\", \\\"{x:1275,y:637,t:1528139750840};\\\", \\\"{x:1274,y:637,t:1528139750864};\\\", \\\"{x:1274,y:639,t:1528139750896};\\\", \\\"{x:1274,y:640,t:1528139750912};\\\", \\\"{x:1273,y:640,t:1528139750929};\\\", \\\"{x:1272,y:642,t:1528139750944};\\\", \\\"{x:1271,y:644,t:1528139750960};\\\", \\\"{x:1270,y:645,t:1528139750972};\\\", \\\"{x:1269,y:646,t:1528139750988};\\\", \\\"{x:1267,y:648,t:1528139751005};\\\", \\\"{x:1265,y:650,t:1528139751021};\\\", \\\"{x:1265,y:652,t:1528139751038};\\\", \\\"{x:1264,y:653,t:1528139751055};\\\", \\\"{x:1263,y:654,t:1528139751071};\\\", \\\"{x:1263,y:655,t:1528139751120};\\\", \\\"{x:1263,y:656,t:1528139751144};\\\", \\\"{x:1262,y:656,t:1528139751155};\\\", \\\"{x:1262,y:657,t:1528139751176};\\\", \\\"{x:1262,y:658,t:1528139751189};\\\", \\\"{x:1262,y:659,t:1528139751273};\\\", \\\"{x:1261,y:660,t:1528139751401};\\\", \\\"{x:1260,y:661,t:1528139751497};\\\", \\\"{x:1259,y:662,t:1528139751951};\\\", \\\"{x:1259,y:663,t:1528139752047};\\\", \\\"{x:1259,y:664,t:1528139752513};\\\", \\\"{x:1257,y:663,t:1528139752968};\\\", \\\"{x:1255,y:660,t:1528139752975};\\\", \\\"{x:1254,y:658,t:1528139752985};\\\", \\\"{x:1252,y:653,t:1528139753002};\\\", \\\"{x:1248,y:645,t:1528139753018};\\\", \\\"{x:1247,y:642,t:1528139753036};\\\", \\\"{x:1247,y:641,t:1528139753052};\\\", \\\"{x:1247,y:640,t:1528139753069};\\\", \\\"{x:1246,y:640,t:1528139753297};\\\", \\\"{x:1245,y:639,t:1528139753304};\\\", \\\"{x:1244,y:638,t:1528139753328};\\\", \\\"{x:1243,y:638,t:1528139753344};\\\", \\\"{x:1242,y:637,t:1528139753360};\\\", \\\"{x:1241,y:637,t:1528139753385};\\\", \\\"{x:1239,y:637,t:1528139753402};\\\", \\\"{x:1237,y:637,t:1528139753418};\\\", \\\"{x:1235,y:637,t:1528139753436};\\\", \\\"{x:1232,y:637,t:1528139753452};\\\", \\\"{x:1230,y:638,t:1528139753468};\\\", \\\"{x:1228,y:639,t:1528139753486};\\\", \\\"{x:1225,y:641,t:1528139753502};\\\", \\\"{x:1223,y:643,t:1528139753518};\\\", \\\"{x:1221,y:645,t:1528139753535};\\\", \\\"{x:1220,y:646,t:1528139753552};\\\", \\\"{x:1219,y:647,t:1528139753568};\\\", \\\"{x:1218,y:648,t:1528139753592};\\\", \\\"{x:1218,y:649,t:1528139753608};\\\", \\\"{x:1218,y:650,t:1528139753633};\\\", \\\"{x:1218,y:651,t:1528139753640};\\\", \\\"{x:1216,y:652,t:1528139753664};\\\", \\\"{x:1216,y:653,t:1528139753680};\\\", \\\"{x:1216,y:654,t:1528139753688};\\\", \\\"{x:1216,y:656,t:1528139753704};\\\", \\\"{x:1216,y:660,t:1528139753718};\\\", \\\"{x:1215,y:660,t:1528139753736};\\\", \\\"{x:1214,y:661,t:1528139753752};\\\", \\\"{x:1214,y:663,t:1528139753800};\\\", \\\"{x:1214,y:664,t:1528139753818};\\\", \\\"{x:1214,y:666,t:1528139753834};\\\", \\\"{x:1215,y:669,t:1528139753851};\\\", \\\"{x:1217,y:672,t:1528139753868};\\\", \\\"{x:1221,y:679,t:1528139753888};\\\", \\\"{x:1221,y:680,t:1528139753900};\\\", \\\"{x:1224,y:685,t:1528139753917};\\\", \\\"{x:1227,y:690,t:1528139753933};\\\", \\\"{x:1228,y:691,t:1528139753950};\\\", \\\"{x:1231,y:695,t:1528139753967};\\\", \\\"{x:1232,y:696,t:1528139753984};\\\", \\\"{x:1233,y:697,t:1528139754001};\\\", \\\"{x:1236,y:697,t:1528139754017};\\\", \\\"{x:1238,y:697,t:1528139754034};\\\", \\\"{x:1240,y:697,t:1528139754051};\\\", \\\"{x:1241,y:697,t:1528139754068};\\\", \\\"{x:1242,y:697,t:1528139754088};\\\", \\\"{x:1244,y:697,t:1528139754101};\\\", \\\"{x:1249,y:699,t:1528139754117};\\\", \\\"{x:1253,y:699,t:1528139754134};\\\", \\\"{x:1257,y:699,t:1528139754151};\\\", \\\"{x:1258,y:699,t:1528139754166};\\\", \\\"{x:1261,y:699,t:1528139754183};\\\", \\\"{x:1262,y:699,t:1528139754200};\\\", \\\"{x:1264,y:699,t:1528139754217};\\\", \\\"{x:1267,y:699,t:1528139754234};\\\", \\\"{x:1271,y:699,t:1528139754251};\\\", \\\"{x:1275,y:700,t:1528139754267};\\\", \\\"{x:1278,y:700,t:1528139754285};\\\", \\\"{x:1281,y:700,t:1528139754301};\\\", \\\"{x:1285,y:700,t:1528139754316};\\\", \\\"{x:1289,y:701,t:1528139754333};\\\", \\\"{x:1295,y:701,t:1528139754350};\\\", \\\"{x:1297,y:701,t:1528139754367};\\\", \\\"{x:1301,y:701,t:1528139754384};\\\", \\\"{x:1304,y:702,t:1528139754400};\\\", \\\"{x:1305,y:702,t:1528139754417};\\\", \\\"{x:1306,y:702,t:1528139754434};\\\", \\\"{x:1307,y:702,t:1528139754450};\\\", \\\"{x:1309,y:702,t:1528139754467};\\\", \\\"{x:1311,y:702,t:1528139754488};\\\", \\\"{x:1312,y:702,t:1528139754512};\\\", \\\"{x:1314,y:702,t:1528139754551};\\\", \\\"{x:1315,y:702,t:1528139754567};\\\", \\\"{x:1317,y:702,t:1528139754583};\\\", \\\"{x:1319,y:702,t:1528139754599};\\\", \\\"{x:1321,y:702,t:1528139754617};\\\", \\\"{x:1322,y:702,t:1528139754632};\\\", \\\"{x:1323,y:702,t:1528139754649};\\\", \\\"{x:1326,y:700,t:1528139754667};\\\", \\\"{x:1327,y:700,t:1528139754682};\\\", \\\"{x:1328,y:700,t:1528139754720};\\\", \\\"{x:1329,y:700,t:1528139754752};\\\", \\\"{x:1330,y:700,t:1528139754768};\\\", \\\"{x:1332,y:699,t:1528139754792};\\\", \\\"{x:1334,y:698,t:1528139754816};\\\", \\\"{x:1334,y:697,t:1528139754840};\\\", \\\"{x:1335,y:696,t:1528139754872};\\\", \\\"{x:1336,y:696,t:1528139754888};\\\", \\\"{x:1337,y:695,t:1528139754905};\\\", \\\"{x:1337,y:694,t:1528139755961};\\\", \\\"{x:1336,y:694,t:1528139756713};\\\", \\\"{x:1335,y:694,t:1528139756721};\\\", \\\"{x:1334,y:694,t:1528139756736};\\\", \\\"{x:1334,y:695,t:1528139756760};\\\", \\\"{x:1333,y:695,t:1528139756776};\\\", \\\"{x:1333,y:696,t:1528139756793};\\\", \\\"{x:1331,y:697,t:1528139756832};\\\", \\\"{x:1330,y:698,t:1528139756953};\\\", \\\"{x:1329,y:699,t:1528139756965};\\\", \\\"{x:1328,y:700,t:1528139756984};\\\", \\\"{x:1327,y:700,t:1528139757000};\\\", \\\"{x:1325,y:701,t:1528139757016};\\\", \\\"{x:1325,y:702,t:1528139757073};\\\", \\\"{x:1326,y:703,t:1528139757440};\\\", \\\"{x:1327,y:703,t:1528139757793};\\\", \\\"{x:1336,y:706,t:1528139757800};\\\", \\\"{x:1345,y:706,t:1528139757813};\\\", \\\"{x:1357,y:708,t:1528139757829};\\\", \\\"{x:1374,y:713,t:1528139757846};\\\", \\\"{x:1400,y:719,t:1528139757864};\\\", \\\"{x:1416,y:724,t:1528139757880};\\\", \\\"{x:1436,y:730,t:1528139757896};\\\", \\\"{x:1456,y:736,t:1528139757914};\\\", \\\"{x:1471,y:740,t:1528139757930};\\\", \\\"{x:1480,y:743,t:1528139757946};\\\", \\\"{x:1482,y:744,t:1528139757963};\\\", \\\"{x:1488,y:747,t:1528139757979};\\\", \\\"{x:1491,y:749,t:1528139757997};\\\", \\\"{x:1492,y:749,t:1528139758065};\\\", \\\"{x:1495,y:751,t:1528139758080};\\\", \\\"{x:1496,y:752,t:1528139758119};\\\", \\\"{x:1498,y:752,t:1528139758183};\\\", \\\"{x:1501,y:752,t:1528139758196};\\\", \\\"{x:1503,y:752,t:1528139758212};\\\", \\\"{x:1505,y:753,t:1528139758229};\\\", \\\"{x:1509,y:754,t:1528139758245};\\\", \\\"{x:1511,y:755,t:1528139758262};\\\", \\\"{x:1512,y:755,t:1528139758384};\\\", \\\"{x:1513,y:755,t:1528139758440};\\\", \\\"{x:1514,y:756,t:1528139758447};\\\", \\\"{x:1515,y:757,t:1528139758462};\\\", \\\"{x:1517,y:757,t:1528139758480};\\\", \\\"{x:1518,y:758,t:1528139758498};\\\", \\\"{x:1519,y:758,t:1528139758537};\\\", \\\"{x:1521,y:759,t:1528139758546};\\\", \\\"{x:1524,y:759,t:1528139758563};\\\", \\\"{x:1525,y:759,t:1528139758579};\\\", \\\"{x:1526,y:760,t:1528139758760};\\\", \\\"{x:1526,y:761,t:1528139758778};\\\", \\\"{x:1526,y:762,t:1528139758808};\\\", \\\"{x:1525,y:762,t:1528139758816};\\\", \\\"{x:1524,y:762,t:1528139758832};\\\", \\\"{x:1523,y:762,t:1528139758848};\\\", \\\"{x:1522,y:762,t:1528139758944};\\\", \\\"{x:1521,y:762,t:1528139759001};\\\", \\\"{x:1520,y:762,t:1528139759018};\\\", \\\"{x:1519,y:762,t:1528139759028};\\\", \\\"{x:1518,y:762,t:1528139759044};\\\", \\\"{x:1517,y:762,t:1528139759061};\\\", \\\"{x:1516,y:762,t:1528139759078};\\\", \\\"{x:1515,y:762,t:1528139759120};\\\", \\\"{x:1514,y:762,t:1528139759200};\\\", \\\"{x:1513,y:762,t:1528139759224};\\\", \\\"{x:1512,y:762,t:1528139759329};\\\", \\\"{x:1511,y:762,t:1528139759345};\\\", \\\"{x:1512,y:768,t:1528139760009};\\\", \\\"{x:1515,y:775,t:1528139760018};\\\", \\\"{x:1516,y:785,t:1528139760027};\\\", \\\"{x:1527,y:810,t:1528139760043};\\\", \\\"{x:1535,y:841,t:1528139760061};\\\", \\\"{x:1543,y:865,t:1528139760077};\\\", \\\"{x:1545,y:873,t:1528139760094};\\\", \\\"{x:1545,y:874,t:1528139760110};\\\", \\\"{x:1542,y:872,t:1528139760169};\\\", \\\"{x:1540,y:867,t:1528139760177};\\\", \\\"{x:1534,y:857,t:1528139760193};\\\", \\\"{x:1531,y:847,t:1528139760211};\\\", \\\"{x:1530,y:833,t:1528139760226};\\\", \\\"{x:1529,y:818,t:1528139760243};\\\", \\\"{x:1528,y:808,t:1528139760261};\\\", \\\"{x:1526,y:803,t:1528139760277};\\\", \\\"{x:1526,y:797,t:1528139760294};\\\", \\\"{x:1526,y:793,t:1528139760309};\\\", \\\"{x:1526,y:791,t:1528139760327};\\\", \\\"{x:1526,y:790,t:1528139760344};\\\", \\\"{x:1526,y:787,t:1528139760360};\\\", \\\"{x:1526,y:784,t:1528139760377};\\\", \\\"{x:1526,y:782,t:1528139760394};\\\", \\\"{x:1526,y:781,t:1528139760410};\\\", \\\"{x:1526,y:780,t:1528139760426};\\\", \\\"{x:1526,y:779,t:1528139760448};\\\", \\\"{x:1526,y:778,t:1528139760488};\\\", \\\"{x:1526,y:777,t:1528139760544};\\\", \\\"{x:1526,y:775,t:1528139760560};\\\", \\\"{x:1526,y:773,t:1528139760592};\\\", \\\"{x:1525,y:769,t:1528139760610};\\\", \\\"{x:1524,y:765,t:1528139760627};\\\", \\\"{x:1522,y:761,t:1528139760642};\\\", \\\"{x:1521,y:759,t:1528139760660};\\\", \\\"{x:1521,y:758,t:1528139760676};\\\", \\\"{x:1519,y:755,t:1528139760692};\\\", \\\"{x:1518,y:754,t:1528139760709};\\\", \\\"{x:1518,y:756,t:1528139761088};\\\", \\\"{x:1517,y:758,t:1528139761097};\\\", \\\"{x:1516,y:759,t:1528139761108};\\\", \\\"{x:1514,y:761,t:1528139761125};\\\", \\\"{x:1513,y:761,t:1528139761142};\\\", \\\"{x:1511,y:764,t:1528139761384};\\\", \\\"{x:1510,y:767,t:1528139761392};\\\", \\\"{x:1506,y:783,t:1528139761409};\\\", \\\"{x:1493,y:808,t:1528139761425};\\\", \\\"{x:1479,y:831,t:1528139761442};\\\", \\\"{x:1470,y:853,t:1528139761460};\\\", \\\"{x:1461,y:868,t:1528139761476};\\\", \\\"{x:1457,y:873,t:1528139761492};\\\", \\\"{x:1456,y:874,t:1528139761509};\\\", \\\"{x:1456,y:873,t:1528139761808};\\\", \\\"{x:1456,y:869,t:1528139761825};\\\", \\\"{x:1459,y:865,t:1528139761842};\\\", \\\"{x:1459,y:860,t:1528139761857};\\\", \\\"{x:1462,y:854,t:1528139761874};\\\", \\\"{x:1462,y:852,t:1528139761891};\\\", \\\"{x:1463,y:849,t:1528139761907};\\\", \\\"{x:1465,y:847,t:1528139761924};\\\", \\\"{x:1465,y:843,t:1528139761941};\\\", \\\"{x:1465,y:839,t:1528139761957};\\\", \\\"{x:1465,y:837,t:1528139761974};\\\", \\\"{x:1466,y:834,t:1528139761991};\\\", \\\"{x:1466,y:833,t:1528139762007};\\\", \\\"{x:1467,y:832,t:1528139762024};\\\", \\\"{x:1469,y:830,t:1528139762080};\\\", \\\"{x:1472,y:829,t:1528139762185};\\\", \\\"{x:1473,y:829,t:1528139762193};\\\", \\\"{x:1476,y:829,t:1528139762208};\\\", \\\"{x:1479,y:829,t:1528139762224};\\\", \\\"{x:1484,y:828,t:1528139762240};\\\", \\\"{x:1485,y:828,t:1528139762258};\\\", \\\"{x:1486,y:828,t:1528139762275};\\\", \\\"{x:1486,y:829,t:1528139762648};\\\", \\\"{x:1486,y:830,t:1528139762656};\\\", \\\"{x:1485,y:832,t:1528139762673};\\\", \\\"{x:1484,y:833,t:1528139762691};\\\", \\\"{x:1483,y:834,t:1528139762707};\\\", \\\"{x:1482,y:834,t:1528139762736};\\\", \\\"{x:1481,y:835,t:1528139762744};\\\", \\\"{x:1479,y:837,t:1528139762769};\\\", \\\"{x:1478,y:837,t:1528139762800};\\\", \\\"{x:1477,y:837,t:1528139762816};\\\", \\\"{x:1475,y:838,t:1528139762832};\\\", \\\"{x:1474,y:839,t:1528139762895};\\\", \\\"{x:1473,y:839,t:1528139766168};\\\", \\\"{x:1468,y:839,t:1528139766185};\\\", \\\"{x:1455,y:840,t:1528139766203};\\\", \\\"{x:1441,y:842,t:1528139766220};\\\", \\\"{x:1422,y:844,t:1528139766236};\\\", \\\"{x:1406,y:844,t:1528139766253};\\\", \\\"{x:1368,y:841,t:1528139766268};\\\", \\\"{x:1273,y:825,t:1528139766287};\\\", \\\"{x:1171,y:797,t:1528139766302};\\\", \\\"{x:1053,y:770,t:1528139766319};\\\", \\\"{x:863,y:722,t:1528139766336};\\\", \\\"{x:732,y:701,t:1528139766352};\\\", \\\"{x:607,y:680,t:1528139766369};\\\", \\\"{x:501,y:660,t:1528139766385};\\\", \\\"{x:394,y:638,t:1528139766403};\\\", \\\"{x:325,y:618,t:1528139766419};\\\", \\\"{x:278,y:606,t:1528139766435};\\\", \\\"{x:255,y:601,t:1528139766452};\\\", \\\"{x:237,y:597,t:1528139766474};\\\", \\\"{x:235,y:596,t:1528139766491};\\\", \\\"{x:235,y:594,t:1528139766616};\\\", \\\"{x:235,y:590,t:1528139766624};\\\", \\\"{x:242,y:587,t:1528139766640};\\\", \\\"{x:249,y:583,t:1528139766657};\\\", \\\"{x:253,y:582,t:1528139766675};\\\", \\\"{x:254,y:581,t:1528139766691};\\\", \\\"{x:255,y:580,t:1528139766707};\\\", \\\"{x:256,y:579,t:1528139766727};\\\", \\\"{x:257,y:579,t:1528139766741};\\\", \\\"{x:261,y:576,t:1528139766758};\\\", \\\"{x:265,y:576,t:1528139766775};\\\", \\\"{x:274,y:576,t:1528139766792};\\\", \\\"{x:301,y:573,t:1528139766807};\\\", \\\"{x:313,y:572,t:1528139766824};\\\", \\\"{x:340,y:572,t:1528139766840};\\\", \\\"{x:404,y:581,t:1528139766857};\\\", \\\"{x:461,y:594,t:1528139766874};\\\", \\\"{x:520,y:603,t:1528139766890};\\\", \\\"{x:552,y:609,t:1528139766907};\\\", \\\"{x:590,y:615,t:1528139766924};\\\", \\\"{x:606,y:621,t:1528139766940};\\\", \\\"{x:629,y:626,t:1528139766957};\\\", \\\"{x:650,y:629,t:1528139766975};\\\", \\\"{x:685,y:633,t:1528139766991};\\\", \\\"{x:697,y:635,t:1528139767007};\\\", \\\"{x:700,y:635,t:1528139767025};\\\", \\\"{x:701,y:635,t:1528139767041};\\\", \\\"{x:702,y:635,t:1528139767057};\\\", \\\"{x:699,y:632,t:1528139767192};\\\", \\\"{x:682,y:620,t:1528139767209};\\\", \\\"{x:656,y:611,t:1528139767224};\\\", \\\"{x:631,y:599,t:1528139767241};\\\", \\\"{x:594,y:588,t:1528139767258};\\\", \\\"{x:569,y:586,t:1528139767274};\\\", \\\"{x:560,y:583,t:1528139767291};\\\", \\\"{x:559,y:582,t:1528139767307};\\\", \\\"{x:560,y:581,t:1528139767343};\\\", \\\"{x:565,y:579,t:1528139767357};\\\", \\\"{x:588,y:579,t:1528139767374};\\\", \\\"{x:663,y:591,t:1528139767391};\\\", \\\"{x:687,y:593,t:1528139767409};\\\", \\\"{x:703,y:594,t:1528139767425};\\\", \\\"{x:713,y:595,t:1528139767441};\\\", \\\"{x:717,y:596,t:1528139767458};\\\", \\\"{x:718,y:596,t:1528139767560};\\\", \\\"{x:719,y:596,t:1528139767575};\\\", \\\"{x:727,y:596,t:1528139767592};\\\", \\\"{x:730,y:596,t:1528139767608};\\\", \\\"{x:730,y:595,t:1528139767665};\\\", \\\"{x:733,y:595,t:1528139767680};\\\", \\\"{x:734,y:595,t:1528139767696};\\\", \\\"{x:735,y:595,t:1528139767712};\\\", \\\"{x:737,y:595,t:1528139767725};\\\", \\\"{x:744,y:593,t:1528139767744};\\\", \\\"{x:767,y:584,t:1528139767758};\\\", \\\"{x:784,y:579,t:1528139767775};\\\", \\\"{x:789,y:578,t:1528139767791};\\\", \\\"{x:799,y:577,t:1528139767809};\\\", \\\"{x:809,y:575,t:1528139767825};\\\", \\\"{x:815,y:574,t:1528139767841};\\\", \\\"{x:817,y:574,t:1528139767858};\\\", \\\"{x:819,y:574,t:1528139767875};\\\", \\\"{x:820,y:573,t:1528139767892};\\\", \\\"{x:822,y:573,t:1528139767936};\\\", \\\"{x:824,y:572,t:1528139767953};\\\", \\\"{x:826,y:572,t:1528139767992};\\\", \\\"{x:825,y:572,t:1528139768399};\\\", \\\"{x:816,y:572,t:1528139768409};\\\", \\\"{x:774,y:579,t:1528139768425};\\\", \\\"{x:711,y:585,t:1528139768444};\\\", \\\"{x:626,y:591,t:1528139768458};\\\", \\\"{x:546,y:600,t:1528139768476};\\\", \\\"{x:466,y:600,t:1528139768493};\\\", \\\"{x:391,y:594,t:1528139768508};\\\", \\\"{x:321,y:591,t:1528139768526};\\\", \\\"{x:270,y:583,t:1528139768543};\\\", \\\"{x:242,y:575,t:1528139768558};\\\", \\\"{x:226,y:572,t:1528139768576};\\\", \\\"{x:223,y:572,t:1528139768593};\\\", \\\"{x:222,y:571,t:1528139768616};\\\", \\\"{x:220,y:571,t:1528139768848};\\\", \\\"{x:219,y:572,t:1528139768859};\\\", \\\"{x:218,y:574,t:1528139768875};\\\", \\\"{x:216,y:576,t:1528139768892};\\\", \\\"{x:216,y:577,t:1528139768910};\\\", \\\"{x:215,y:579,t:1528139768926};\\\", \\\"{x:215,y:580,t:1528139768944};\\\", \\\"{x:215,y:582,t:1528139768960};\\\", \\\"{x:215,y:587,t:1528139768976};\\\", \\\"{x:216,y:592,t:1528139768992};\\\", \\\"{x:224,y:600,t:1528139769011};\\\", \\\"{x:237,y:606,t:1528139769026};\\\", \\\"{x:260,y:610,t:1528139769040};\\\", \\\"{x:284,y:610,t:1528139769057};\\\", \\\"{x:335,y:613,t:1528139769074};\\\", \\\"{x:417,y:614,t:1528139769092};\\\", \\\"{x:445,y:604,t:1528139769109};\\\", \\\"{x:481,y:591,t:1528139769126};\\\", \\\"{x:531,y:574,t:1528139769143};\\\", \\\"{x:536,y:571,t:1528139769159};\\\", \\\"{x:544,y:566,t:1528139769176};\\\", \\\"{x:541,y:566,t:1528139769296};\\\", \\\"{x:540,y:567,t:1528139769310};\\\", \\\"{x:536,y:570,t:1528139769326};\\\", \\\"{x:535,y:570,t:1528139769343};\\\", \\\"{x:534,y:571,t:1528139769536};\\\", \\\"{x:535,y:572,t:1528139769566};\\\", \\\"{x:536,y:572,t:1528139769576};\\\", \\\"{x:537,y:572,t:1528139769593};\\\", \\\"{x:539,y:573,t:1528139769610};\\\", \\\"{x:541,y:573,t:1528139769627};\\\", \\\"{x:542,y:573,t:1528139769643};\\\", \\\"{x:547,y:574,t:1528139769660};\\\", \\\"{x:551,y:576,t:1528139769677};\\\", \\\"{x:555,y:577,t:1528139769693};\\\", \\\"{x:560,y:577,t:1528139769710};\\\", \\\"{x:564,y:577,t:1528139769727};\\\", \\\"{x:565,y:577,t:1528139769744};\\\", \\\"{x:566,y:578,t:1528139770072};\\\", \\\"{x:567,y:579,t:1528139770080};\\\", \\\"{x:568,y:579,t:1528139770094};\\\", \\\"{x:570,y:579,t:1528139770111};\\\", \\\"{x:576,y:581,t:1528139770128};\\\", \\\"{x:581,y:582,t:1528139770145};\\\", \\\"{x:584,y:582,t:1528139770162};\\\", \\\"{x:585,y:582,t:1528139770177};\\\", \\\"{x:587,y:582,t:1528139770195};\\\", \\\"{x:590,y:583,t:1528139770211};\\\", \\\"{x:596,y:583,t:1528139770228};\\\", \\\"{x:608,y:584,t:1528139770245};\\\", \\\"{x:623,y:584,t:1528139770262};\\\", \\\"{x:639,y:582,t:1528139770276};\\\", \\\"{x:647,y:579,t:1528139770293};\\\", \\\"{x:648,y:577,t:1528139770310};\\\", \\\"{x:646,y:577,t:1528139770496};\\\", \\\"{x:644,y:576,t:1528139770511};\\\", \\\"{x:632,y:572,t:1528139770529};\\\", \\\"{x:626,y:570,t:1528139770543};\\\", \\\"{x:620,y:567,t:1528139770560};\\\", \\\"{x:616,y:565,t:1528139770578};\\\", \\\"{x:612,y:565,t:1528139770593};\\\", \\\"{x:611,y:564,t:1528139770611};\\\", \\\"{x:610,y:564,t:1528139770627};\\\", \\\"{x:609,y:564,t:1528139771048};\\\", \\\"{x:609,y:565,t:1528139771061};\\\", \\\"{x:609,y:569,t:1528139771078};\\\", \\\"{x:609,y:571,t:1528139771095};\\\", \\\"{x:609,y:572,t:1528139771110};\\\", \\\"{x:609,y:574,t:1528139771127};\\\", \\\"{x:609,y:575,t:1528139771151};\\\", \\\"{x:609,y:576,t:1528139771168};\\\", \\\"{x:608,y:576,t:1528139771535};\\\", \\\"{x:608,y:577,t:1528139771808};\\\", \\\"{x:606,y:580,t:1528139771816};\\\", \\\"{x:604,y:588,t:1528139771829};\\\", \\\"{x:601,y:595,t:1528139771846};\\\", \\\"{x:598,y:600,t:1528139771862};\\\", \\\"{x:598,y:602,t:1528139771879};\\\", \\\"{x:597,y:606,t:1528139771895};\\\", \\\"{x:596,y:609,t:1528139771910};\\\", \\\"{x:596,y:611,t:1528139771934};\\\", \\\"{x:596,y:614,t:1528139771951};\\\", \\\"{x:595,y:614,t:1528139771961};\\\", \\\"{x:594,y:621,t:1528139771979};\\\", \\\"{x:593,y:626,t:1528139771994};\\\", \\\"{x:593,y:633,t:1528139772011};\\\", \\\"{x:590,y:640,t:1528139772028};\\\", \\\"{x:586,y:652,t:1528139772045};\\\", \\\"{x:583,y:673,t:1528139772062};\\\", \\\"{x:577,y:694,t:1528139772079};\\\", \\\"{x:572,y:716,t:1528139772094};\\\", \\\"{x:559,y:743,t:1528139772111};\\\", \\\"{x:552,y:756,t:1528139772129};\\\", \\\"{x:548,y:764,t:1528139772145};\\\", \\\"{x:546,y:769,t:1528139772162};\\\", \\\"{x:544,y:772,t:1528139772179};\\\", \\\"{x:543,y:773,t:1528139772196};\\\", \\\"{x:543,y:774,t:1528139772231};\\\", \\\"{x:542,y:774,t:1528139772288};\\\", \\\"{x:540,y:774,t:1528139772304};\\\", \\\"{x:538,y:774,t:1528139772328};\\\", \\\"{x:537,y:774,t:1528139772336};\\\", \\\"{x:536,y:774,t:1528139772360};\\\", \\\"{x:535,y:774,t:1528139772367};\\\", \\\"{x:534,y:774,t:1528139772391};\\\", \\\"{x:532,y:772,t:1528139772407};\\\", \\\"{x:531,y:771,t:1528139772440};\\\", \\\"{x:531,y:770,t:1528139772455};\\\", \\\"{x:531,y:769,t:1528139772480};\\\", \\\"{x:530,y:767,t:1528139772568};\\\", \\\"{x:529,y:766,t:1528139772600};\\\", \\\"{x:529,y:765,t:1528139772688};\\\", \\\"{x:528,y:765,t:1528139772728};\\\", \\\"{x:528,y:764,t:1528139773056};\\\", \\\"{x:527,y:762,t:1528139780827};\\\", \\\"{x:527,y:760,t:1528139780842};\\\", \\\"{x:527,y:758,t:1528139780859};\\\", \\\"{x:527,y:756,t:1528139780875};\\\", \\\"{x:526,y:755,t:1528139780898};\\\", \\\"{x:526,y:754,t:1528139780956};\\\", \\\"{x:526,y:750,t:1528139780976};\\\", \\\"{x:526,y:745,t:1528139780991};\\\", \\\"{x:526,y:742,t:1528139781003};\\\" ] }, { \\\"rt\\\": 104844, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 827149, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 11, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\", \\\"E\\\", \\\"F\\\", \\\"G\\\", \\\"C\\\", \\\"O\\\", \\\"H\\\", \\\"Z\\\", \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-F -B -B -12 PM-11 AM-11 AM-5-X -N -D -X -B -B -B -B -10 AM-F -G -E -X -X -X -X -X -03 PM-G -G -G -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:741,t:1528139782482};\\\", \\\"{x:520,y:738,t:1528139783299};\\\", \\\"{x:513,y:733,t:1528139783307};\\\", \\\"{x:499,y:733,t:1528139783324};\\\", \\\"{x:488,y:732,t:1528139783340};\\\", \\\"{x:480,y:729,t:1528139783357};\\\", \\\"{x:474,y:727,t:1528139783374};\\\", \\\"{x:464,y:722,t:1528139783390};\\\", \\\"{x:458,y:720,t:1528139783407};\\\", \\\"{x:454,y:718,t:1528139783425};\\\", \\\"{x:443,y:714,t:1528139783440};\\\", \\\"{x:439,y:712,t:1528139783457};\\\", \\\"{x:422,y:705,t:1528139783474};\\\", \\\"{x:396,y:695,t:1528139783489};\\\", \\\"{x:350,y:680,t:1528139783507};\\\", \\\"{x:346,y:678,t:1528139783524};\\\", \\\"{x:345,y:678,t:1528139784347};\\\", \\\"{x:344,y:678,t:1528139784358};\\\", \\\"{x:343,y:672,t:1528139784411};\\\", \\\"{x:343,y:667,t:1528139784426};\\\", \\\"{x:343,y:651,t:1528139784441};\\\", \\\"{x:343,y:631,t:1528139784458};\\\", \\\"{x:343,y:618,t:1528139784473};\\\", \\\"{x:343,y:607,t:1528139784491};\\\", \\\"{x:344,y:600,t:1528139784508};\\\", \\\"{x:345,y:593,t:1528139784524};\\\", \\\"{x:346,y:588,t:1528139784541};\\\", \\\"{x:347,y:580,t:1528139784558};\\\", \\\"{x:348,y:576,t:1528139784575};\\\", \\\"{x:348,y:569,t:1528139784590};\\\", \\\"{x:349,y:562,t:1528139784608};\\\", \\\"{x:349,y:555,t:1528139784626};\\\", \\\"{x:349,y:551,t:1528139784641};\\\", \\\"{x:349,y:547,t:1528139784658};\\\", \\\"{x:349,y:545,t:1528139784675};\\\", \\\"{x:349,y:542,t:1528139784691};\\\", \\\"{x:349,y:541,t:1528139784708};\\\", \\\"{x:349,y:540,t:1528139784738};\\\", \\\"{x:349,y:538,t:1528139784770};\\\", \\\"{x:348,y:537,t:1528139784778};\\\", \\\"{x:348,y:536,t:1528139784791};\\\", \\\"{x:347,y:534,t:1528139784808};\\\", \\\"{x:345,y:532,t:1528139784825};\\\", \\\"{x:345,y:531,t:1528139784890};\\\", \\\"{x:345,y:530,t:1528139784909};\\\", \\\"{x:344,y:530,t:1528139784926};\\\", \\\"{x:344,y:529,t:1528139784946};\\\", \\\"{x:342,y:527,t:1528139784963};\\\", \\\"{x:340,y:526,t:1528139784975};\\\", \\\"{x:332,y:514,t:1528139784994};\\\", \\\"{x:325,y:502,t:1528139785008};\\\", \\\"{x:310,y:491,t:1528139785024};\\\", \\\"{x:295,y:481,t:1528139785041};\\\", \\\"{x:282,y:472,t:1528139785057};\\\", \\\"{x:271,y:467,t:1528139785075};\\\", \\\"{x:262,y:461,t:1528139785092};\\\", \\\"{x:255,y:457,t:1528139785108};\\\", \\\"{x:253,y:456,t:1528139785124};\\\", \\\"{x:251,y:455,t:1528139785141};\\\", \\\"{x:250,y:454,t:1528139785659};\\\", \\\"{x:264,y:446,t:1528139785676};\\\", \\\"{x:285,y:443,t:1528139785692};\\\", \\\"{x:309,y:443,t:1528139785709};\\\", \\\"{x:341,y:443,t:1528139785725};\\\", \\\"{x:363,y:445,t:1528139785742};\\\", \\\"{x:388,y:451,t:1528139785759};\\\", \\\"{x:411,y:454,t:1528139785775};\\\", \\\"{x:442,y:460,t:1528139785792};\\\", \\\"{x:480,y:470,t:1528139785810};\\\", \\\"{x:526,y:479,t:1528139785826};\\\", \\\"{x:578,y:487,t:1528139785844};\\\", \\\"{x:600,y:490,t:1528139785859};\\\", \\\"{x:607,y:491,t:1528139785876};\\\", \\\"{x:608,y:492,t:1528139785891};\\\", \\\"{x:611,y:492,t:1528139789027};\\\", \\\"{x:624,y:497,t:1528139789034};\\\", \\\"{x:642,y:498,t:1528139789049};\\\", \\\"{x:688,y:508,t:1528139789067};\\\", \\\"{x:806,y:523,t:1528139789082};\\\", \\\"{x:858,y:531,t:1528139789098};\\\", \\\"{x:938,y:543,t:1528139789121};\\\", \\\"{x:1062,y:562,t:1528139789138};\\\", \\\"{x:1124,y:572,t:1528139789161};\\\", \\\"{x:1187,y:581,t:1528139789178};\\\", \\\"{x:1203,y:584,t:1528139789194};\\\", \\\"{x:1208,y:584,t:1528139789211};\\\", \\\"{x:1210,y:584,t:1528139789228};\\\", \\\"{x:1210,y:585,t:1528139789411};\\\", \\\"{x:1208,y:586,t:1528139789433};\\\", \\\"{x:1207,y:586,t:1528139789466};\\\", \\\"{x:1206,y:587,t:1528139789490};\\\", \\\"{x:1205,y:587,t:1528139789530};\\\", \\\"{x:1205,y:588,t:1528139789545};\\\", \\\"{x:1205,y:589,t:1528139790387};\\\", \\\"{x:1205,y:590,t:1528139790397};\\\", \\\"{x:1205,y:594,t:1528139790413};\\\", \\\"{x:1208,y:596,t:1528139790429};\\\", \\\"{x:1210,y:599,t:1528139790447};\\\", \\\"{x:1213,y:601,t:1528139790463};\\\", \\\"{x:1213,y:602,t:1528139790480};\\\", \\\"{x:1215,y:603,t:1528139790497};\\\", \\\"{x:1215,y:604,t:1528139791330};\\\", \\\"{x:1216,y:604,t:1528139791378};\\\", \\\"{x:1218,y:605,t:1528139791403};\\\", \\\"{x:1219,y:606,t:1528139791427};\\\", \\\"{x:1219,y:607,t:1528139791451};\\\", \\\"{x:1220,y:607,t:1528139791463};\\\", \\\"{x:1220,y:608,t:1528139791507};\\\", \\\"{x:1221,y:608,t:1528139791523};\\\", \\\"{x:1221,y:609,t:1528139791538};\\\", \\\"{x:1222,y:610,t:1528139791547};\\\", \\\"{x:1223,y:610,t:1528139791564};\\\", \\\"{x:1224,y:612,t:1528139791581};\\\", \\\"{x:1225,y:614,t:1528139791597};\\\", \\\"{x:1227,y:615,t:1528139791614};\\\", \\\"{x:1229,y:617,t:1528139791631};\\\", \\\"{x:1230,y:617,t:1528139791647};\\\", \\\"{x:1232,y:618,t:1528139791664};\\\", \\\"{x:1234,y:619,t:1528139791680};\\\", \\\"{x:1237,y:620,t:1528139791698};\\\", \\\"{x:1240,y:621,t:1528139791714};\\\", \\\"{x:1244,y:623,t:1528139791730};\\\", \\\"{x:1248,y:624,t:1528139791748};\\\", \\\"{x:1253,y:626,t:1528139791764};\\\", \\\"{x:1259,y:629,t:1528139791780};\\\", \\\"{x:1266,y:631,t:1528139791798};\\\", \\\"{x:1272,y:633,t:1528139791814};\\\", \\\"{x:1276,y:635,t:1528139791831};\\\", \\\"{x:1283,y:636,t:1528139791848};\\\", \\\"{x:1285,y:637,t:1528139791864};\\\", \\\"{x:1287,y:639,t:1528139791881};\\\", \\\"{x:1289,y:640,t:1528139791898};\\\", \\\"{x:1291,y:642,t:1528139791915};\\\", \\\"{x:1299,y:650,t:1528139791930};\\\", \\\"{x:1306,y:657,t:1528139791947};\\\", \\\"{x:1312,y:665,t:1528139791964};\\\", \\\"{x:1313,y:667,t:1528139791981};\\\", \\\"{x:1321,y:670,t:1528139791997};\\\", \\\"{x:1327,y:674,t:1528139792014};\\\", \\\"{x:1334,y:681,t:1528139792031};\\\", \\\"{x:1346,y:691,t:1528139792048};\\\", \\\"{x:1359,y:698,t:1528139792065};\\\", \\\"{x:1373,y:705,t:1528139792080};\\\", \\\"{x:1387,y:716,t:1528139792097};\\\", \\\"{x:1404,y:728,t:1528139792113};\\\", \\\"{x:1411,y:738,t:1528139792130};\\\", \\\"{x:1415,y:743,t:1528139792147};\\\", \\\"{x:1417,y:754,t:1528139792165};\\\", \\\"{x:1418,y:762,t:1528139792180};\\\", \\\"{x:1418,y:768,t:1528139792198};\\\", \\\"{x:1419,y:772,t:1528139792215};\\\", \\\"{x:1419,y:774,t:1528139792233};\\\", \\\"{x:1419,y:775,t:1528139792249};\\\", \\\"{x:1419,y:776,t:1528139792273};\\\", \\\"{x:1418,y:776,t:1528139792282};\\\", \\\"{x:1415,y:776,t:1528139792297};\\\", \\\"{x:1409,y:776,t:1528139792314};\\\", \\\"{x:1404,y:775,t:1528139792330};\\\", \\\"{x:1400,y:773,t:1528139792348};\\\", \\\"{x:1397,y:773,t:1528139792364};\\\", \\\"{x:1396,y:771,t:1528139792380};\\\", \\\"{x:1395,y:771,t:1528139792398};\\\", \\\"{x:1394,y:771,t:1528139792426};\\\", \\\"{x:1393,y:771,t:1528139792435};\\\", \\\"{x:1392,y:770,t:1528139792448};\\\", \\\"{x:1391,y:770,t:1528139792465};\\\", \\\"{x:1389,y:770,t:1528139792481};\\\", \\\"{x:1385,y:770,t:1528139792499};\\\", \\\"{x:1382,y:770,t:1528139792517};\\\", \\\"{x:1379,y:768,t:1528139792532};\\\", \\\"{x:1374,y:767,t:1528139792547};\\\", \\\"{x:1368,y:767,t:1528139792564};\\\", \\\"{x:1363,y:767,t:1528139792581};\\\", \\\"{x:1358,y:767,t:1528139792597};\\\", \\\"{x:1356,y:767,t:1528139792614};\\\", \\\"{x:1355,y:766,t:1528139792631};\\\", \\\"{x:1353,y:765,t:1528139792650};\\\", \\\"{x:1352,y:764,t:1528139792698};\\\", \\\"{x:1351,y:764,t:1528139792762};\\\", \\\"{x:1351,y:763,t:1528139792770};\\\", \\\"{x:1350,y:763,t:1528139792786};\\\", \\\"{x:1350,y:762,t:1528139792798};\\\", \\\"{x:1349,y:762,t:1528139792815};\\\", \\\"{x:1349,y:761,t:1528139792835};\\\", \\\"{x:1348,y:761,t:1528139792848};\\\", \\\"{x:1347,y:761,t:1528139792865};\\\", \\\"{x:1346,y:761,t:1528139792979};\\\", \\\"{x:1345,y:761,t:1528139794722};\\\", \\\"{x:1344,y:761,t:1528139794738};\\\", \\\"{x:1343,y:762,t:1528139794770};\\\", \\\"{x:1342,y:763,t:1528139794995};\\\", \\\"{x:1341,y:764,t:1528139795236};\\\", \\\"{x:1341,y:765,t:1528139795274};\\\", \\\"{x:1340,y:765,t:1528139795283};\\\", \\\"{x:1339,y:767,t:1528139795300};\\\", \\\"{x:1339,y:768,t:1528139795316};\\\", \\\"{x:1339,y:770,t:1528139795379};\\\", \\\"{x:1338,y:771,t:1528139795387};\\\", \\\"{x:1337,y:772,t:1528139795451};\\\", \\\"{x:1337,y:773,t:1528139795466};\\\", \\\"{x:1337,y:774,t:1528139795499};\\\", \\\"{x:1337,y:775,t:1528139795507};\\\", \\\"{x:1338,y:775,t:1528139795531};\\\", \\\"{x:1338,y:776,t:1528139795571};\\\", \\\"{x:1338,y:777,t:1528139795603};\\\", \\\"{x:1338,y:778,t:1528139795651};\\\", \\\"{x:1338,y:779,t:1528139795667};\\\", \\\"{x:1338,y:780,t:1528139795819};\\\", \\\"{x:1338,y:779,t:1528139796291};\\\", \\\"{x:1338,y:777,t:1528139796306};\\\", \\\"{x:1338,y:776,t:1528139796339};\\\", \\\"{x:1338,y:775,t:1528139796351};\\\", \\\"{x:1339,y:773,t:1528139796368};\\\", \\\"{x:1341,y:772,t:1528139796384};\\\", \\\"{x:1342,y:770,t:1528139796402};\\\", \\\"{x:1345,y:766,t:1528139796419};\\\", \\\"{x:1348,y:763,t:1528139796434};\\\", \\\"{x:1350,y:762,t:1528139796451};\\\", \\\"{x:1351,y:761,t:1528139796474};\\\", \\\"{x:1351,y:760,t:1528139796485};\\\", \\\"{x:1352,y:759,t:1528139796531};\\\", \\\"{x:1352,y:760,t:1528139796978};\\\", \\\"{x:1352,y:761,t:1528139797010};\\\", \\\"{x:1351,y:763,t:1528139797043};\\\", \\\"{x:1350,y:764,t:1528139797082};\\\", \\\"{x:1349,y:766,t:1528139797114};\\\", \\\"{x:1349,y:767,t:1528139797419};\\\", \\\"{x:1349,y:768,t:1528139797474};\\\", \\\"{x:1348,y:768,t:1528139797490};\\\", \\\"{x:1347,y:769,t:1528139797503};\\\", \\\"{x:1347,y:770,t:1528139797519};\\\", \\\"{x:1346,y:771,t:1528139797535};\\\", \\\"{x:1345,y:772,t:1528139797595};\\\", \\\"{x:1344,y:773,t:1528139797667};\\\", \\\"{x:1344,y:774,t:1528139797698};\\\", \\\"{x:1344,y:776,t:1528139797715};\\\", \\\"{x:1344,y:777,t:1528139797739};\\\", \\\"{x:1344,y:778,t:1528139797755};\\\", \\\"{x:1344,y:779,t:1528139797769};\\\", \\\"{x:1344,y:780,t:1528139797843};\\\", \\\"{x:1344,y:781,t:1528139797852};\\\", \\\"{x:1344,y:782,t:1528139797869};\\\", \\\"{x:1344,y:783,t:1528139797886};\\\", \\\"{x:1344,y:785,t:1528139797902};\\\", \\\"{x:1344,y:786,t:1528139797919};\\\", \\\"{x:1344,y:787,t:1528139797936};\\\", \\\"{x:1341,y:791,t:1528139797952};\\\", \\\"{x:1339,y:793,t:1528139797969};\\\", \\\"{x:1336,y:800,t:1528139797987};\\\", \\\"{x:1335,y:803,t:1528139798002};\\\", \\\"{x:1333,y:806,t:1528139798019};\\\", \\\"{x:1331,y:809,t:1528139798036};\\\", \\\"{x:1330,y:812,t:1528139798052};\\\", \\\"{x:1329,y:814,t:1528139798069};\\\", \\\"{x:1328,y:816,t:1528139798087};\\\", \\\"{x:1328,y:817,t:1528139798102};\\\", \\\"{x:1327,y:818,t:1528139798119};\\\", \\\"{x:1327,y:819,t:1528139798138};\\\", \\\"{x:1326,y:820,t:1528139798152};\\\", \\\"{x:1326,y:821,t:1528139798171};\\\", \\\"{x:1326,y:822,t:1528139798186};\\\", \\\"{x:1325,y:824,t:1528139798203};\\\", \\\"{x:1323,y:825,t:1528139798219};\\\", \\\"{x:1322,y:827,t:1528139798236};\\\", \\\"{x:1320,y:830,t:1528139798252};\\\", \\\"{x:1319,y:831,t:1528139798269};\\\", \\\"{x:1319,y:833,t:1528139798286};\\\", \\\"{x:1318,y:834,t:1528139798303};\\\", \\\"{x:1317,y:836,t:1528139798319};\\\", \\\"{x:1316,y:836,t:1528139798338};\\\", \\\"{x:1316,y:837,t:1528139798362};\\\", \\\"{x:1316,y:838,t:1528139798394};\\\", \\\"{x:1316,y:839,t:1528139798411};\\\", \\\"{x:1315,y:839,t:1528139798427};\\\", \\\"{x:1315,y:840,t:1528139798475};\\\", \\\"{x:1314,y:840,t:1528139798571};\\\", \\\"{x:1314,y:841,t:1528139798611};\\\", \\\"{x:1314,y:839,t:1528139798802};\\\", \\\"{x:1316,y:835,t:1528139798820};\\\", \\\"{x:1320,y:829,t:1528139798836};\\\", \\\"{x:1322,y:825,t:1528139798853};\\\", \\\"{x:1326,y:819,t:1528139798870};\\\", \\\"{x:1327,y:815,t:1528139798887};\\\", \\\"{x:1331,y:808,t:1528139798903};\\\", \\\"{x:1331,y:804,t:1528139798920};\\\", \\\"{x:1333,y:801,t:1528139798936};\\\", \\\"{x:1334,y:799,t:1528139798954};\\\", \\\"{x:1333,y:800,t:1528139799187};\\\", \\\"{x:1331,y:805,t:1528139799203};\\\", \\\"{x:1330,y:807,t:1528139799220};\\\", \\\"{x:1329,y:809,t:1528139799238};\\\", \\\"{x:1326,y:813,t:1528139799253};\\\", \\\"{x:1326,y:814,t:1528139799271};\\\", \\\"{x:1324,y:816,t:1528139799287};\\\", \\\"{x:1324,y:817,t:1528139799303};\\\", \\\"{x:1323,y:818,t:1528139799321};\\\", \\\"{x:1322,y:820,t:1528139799363};\\\", \\\"{x:1322,y:821,t:1528139799379};\\\", \\\"{x:1321,y:822,t:1528139799387};\\\", \\\"{x:1320,y:824,t:1528139799403};\\\", \\\"{x:1320,y:825,t:1528139799420};\\\", \\\"{x:1320,y:826,t:1528139799437};\\\", \\\"{x:1319,y:827,t:1528139799453};\\\", \\\"{x:1319,y:829,t:1528139799470};\\\", \\\"{x:1318,y:830,t:1528139799487};\\\", \\\"{x:1317,y:830,t:1528139799506};\\\", \\\"{x:1317,y:831,t:1528139799931};\\\", \\\"{x:1317,y:832,t:1528139800019};\\\", \\\"{x:1316,y:833,t:1528139800034};\\\", \\\"{x:1315,y:834,t:1528139800115};\\\", \\\"{x:1314,y:835,t:1528139800179};\\\", \\\"{x:1314,y:836,t:1528139800363};\\\", \\\"{x:1314,y:837,t:1528139800379};\\\", \\\"{x:1314,y:838,t:1528139800387};\\\", \\\"{x:1313,y:838,t:1528139800404};\\\", \\\"{x:1313,y:839,t:1528139800421};\\\", \\\"{x:1312,y:840,t:1528139800442};\\\", \\\"{x:1312,y:841,t:1528139800499};\\\", \\\"{x:1312,y:842,t:1528139800642};\\\", \\\"{x:1312,y:843,t:1528139800667};\\\", \\\"{x:1311,y:844,t:1528139800699};\\\", \\\"{x:1310,y:844,t:1528139800714};\\\", \\\"{x:1310,y:845,t:1528139800730};\\\", \\\"{x:1310,y:847,t:1528139800746};\\\", \\\"{x:1309,y:848,t:1528139800762};\\\", \\\"{x:1308,y:849,t:1528139800786};\\\", \\\"{x:1307,y:850,t:1528139800802};\\\", \\\"{x:1307,y:851,t:1528139800835};\\\", \\\"{x:1306,y:851,t:1528139800850};\\\", \\\"{x:1305,y:852,t:1528139800858};\\\", \\\"{x:1305,y:853,t:1528139800871};\\\", \\\"{x:1304,y:854,t:1528139800907};\\\", \\\"{x:1304,y:855,t:1528139800923};\\\", \\\"{x:1303,y:855,t:1528139800938};\\\", \\\"{x:1303,y:857,t:1528139800954};\\\", \\\"{x:1302,y:857,t:1528139801019};\\\", \\\"{x:1301,y:858,t:1528139801059};\\\", \\\"{x:1299,y:859,t:1528139801071};\\\", \\\"{x:1299,y:860,t:1528139801147};\\\", \\\"{x:1298,y:861,t:1528139801267};\\\", \\\"{x:1298,y:862,t:1528139801386};\\\", \\\"{x:1297,y:863,t:1528139801451};\\\", \\\"{x:1296,y:863,t:1528139801490};\\\", \\\"{x:1296,y:864,t:1528139801595};\\\", \\\"{x:1296,y:865,t:1528139801795};\\\", \\\"{x:1296,y:866,t:1528139801805};\\\", \\\"{x:1296,y:867,t:1528139801826};\\\", \\\"{x:1296,y:868,t:1528139801838};\\\", \\\"{x:1295,y:869,t:1528139801855};\\\", \\\"{x:1295,y:870,t:1528139801872};\\\", \\\"{x:1294,y:870,t:1528139801889};\\\", \\\"{x:1293,y:871,t:1528139801906};\\\", \\\"{x:1293,y:872,t:1528139802043};\\\", \\\"{x:1292,y:872,t:1528139802067};\\\", \\\"{x:1292,y:873,t:1528139802139};\\\", \\\"{x:1290,y:875,t:1528139802155};\\\", \\\"{x:1289,y:875,t:1528139802179};\\\", \\\"{x:1289,y:877,t:1528139802195};\\\", \\\"{x:1287,y:878,t:1528139802209};\\\", \\\"{x:1287,y:879,t:1528139802221};\\\", \\\"{x:1286,y:880,t:1528139802239};\\\", \\\"{x:1285,y:881,t:1528139802256};\\\", \\\"{x:1284,y:882,t:1528139802271};\\\", \\\"{x:1283,y:882,t:1528139802289};\\\", \\\"{x:1283,y:883,t:1528139802321};\\\", \\\"{x:1282,y:883,t:1528139802474};\\\", \\\"{x:1282,y:884,t:1528139802610};\\\", \\\"{x:1281,y:884,t:1528139802675};\\\", \\\"{x:1280,y:885,t:1528139802739};\\\", \\\"{x:1280,y:886,t:1528139802756};\\\", \\\"{x:1279,y:887,t:1528139802773};\\\", \\\"{x:1278,y:888,t:1528139802790};\\\", \\\"{x:1278,y:889,t:1528139802807};\\\", \\\"{x:1277,y:890,t:1528139802823};\\\", \\\"{x:1277,y:892,t:1528139802851};\\\", \\\"{x:1275,y:894,t:1528139802873};\\\", \\\"{x:1275,y:896,t:1528139802897};\\\", \\\"{x:1274,y:898,t:1528139802922};\\\", \\\"{x:1274,y:899,t:1528139802938};\\\", \\\"{x:1274,y:900,t:1528139802953};\\\", \\\"{x:1274,y:901,t:1528139802961};\\\", \\\"{x:1274,y:902,t:1528139802972};\\\", \\\"{x:1273,y:903,t:1528139802989};\\\", \\\"{x:1273,y:905,t:1528139803006};\\\", \\\"{x:1272,y:906,t:1528139803023};\\\", \\\"{x:1272,y:907,t:1528139803039};\\\", \\\"{x:1270,y:910,t:1528139803056};\\\", \\\"{x:1270,y:912,t:1528139803073};\\\", \\\"{x:1269,y:914,t:1528139803090};\\\", \\\"{x:1268,y:914,t:1528139803123};\\\", \\\"{x:1268,y:915,t:1528139803187};\\\", \\\"{x:1268,y:916,t:1528139803203};\\\", \\\"{x:1268,y:917,t:1528139803235};\\\", \\\"{x:1268,y:918,t:1528139803242};\\\", \\\"{x:1267,y:919,t:1528139803283};\\\", \\\"{x:1267,y:921,t:1528139803307};\\\", \\\"{x:1265,y:923,t:1528139803323};\\\", \\\"{x:1264,y:924,t:1528139803371};\\\", \\\"{x:1264,y:925,t:1528139803571};\\\", \\\"{x:1264,y:927,t:1528139803586};\\\", \\\"{x:1264,y:929,t:1528139803610};\\\", \\\"{x:1263,y:929,t:1528139803624};\\\", \\\"{x:1262,y:931,t:1528139803641};\\\", \\\"{x:1262,y:932,t:1528139803715};\\\", \\\"{x:1261,y:933,t:1528139803723};\\\", \\\"{x:1260,y:933,t:1528139803746};\\\", \\\"{x:1260,y:934,t:1528139803757};\\\", \\\"{x:1260,y:935,t:1528139803779};\\\", \\\"{x:1259,y:936,t:1528139803791};\\\", \\\"{x:1257,y:938,t:1528139803867};\\\", \\\"{x:1257,y:939,t:1528139803915};\\\", \\\"{x:1257,y:940,t:1528139803962};\\\", \\\"{x:1257,y:941,t:1528139804051};\\\", \\\"{x:1256,y:942,t:1528139804058};\\\", \\\"{x:1256,y:943,t:1528139804099};\\\", \\\"{x:1255,y:944,t:1528139804130};\\\", \\\"{x:1255,y:945,t:1528139804298};\\\", \\\"{x:1255,y:946,t:1528139804307};\\\", \\\"{x:1255,y:947,t:1528139804346};\\\", \\\"{x:1255,y:948,t:1528139804370};\\\", \\\"{x:1255,y:949,t:1528139804746};\\\", \\\"{x:1255,y:950,t:1528139804763};\\\", \\\"{x:1253,y:951,t:1528139805819};\\\", \\\"{x:1252,y:953,t:1528139805827};\\\", \\\"{x:1251,y:954,t:1528139805842};\\\", \\\"{x:1250,y:954,t:1528139805859};\\\", \\\"{x:1248,y:957,t:1528139805875};\\\", \\\"{x:1246,y:957,t:1528139805892};\\\", \\\"{x:1245,y:958,t:1528139805908};\\\", \\\"{x:1244,y:959,t:1528139805947};\\\", \\\"{x:1243,y:960,t:1528139806315};\\\", \\\"{x:1243,y:962,t:1528139806347};\\\", \\\"{x:1243,y:963,t:1528139806395};\\\", \\\"{x:1243,y:964,t:1528139807402};\\\", \\\"{x:1245,y:964,t:1528139807434};\\\", \\\"{x:1247,y:965,t:1528139807467};\\\", \\\"{x:1248,y:965,t:1528139807507};\\\", \\\"{x:1249,y:965,t:1528139807514};\\\", \\\"{x:1250,y:965,t:1528139807531};\\\", \\\"{x:1251,y:965,t:1528139807544};\\\", \\\"{x:1252,y:965,t:1528139807561};\\\", \\\"{x:1254,y:965,t:1528139807577};\\\", \\\"{x:1255,y:965,t:1528139807593};\\\", \\\"{x:1259,y:965,t:1528139807610};\\\", \\\"{x:1262,y:965,t:1528139807626};\\\", \\\"{x:1264,y:965,t:1528139807643};\\\", \\\"{x:1265,y:965,t:1528139807661};\\\", \\\"{x:1267,y:965,t:1528139807715};\\\", \\\"{x:1268,y:965,t:1528139807755};\\\", \\\"{x:1270,y:965,t:1528139807795};\\\", \\\"{x:1271,y:964,t:1528139807827};\\\", \\\"{x:1272,y:963,t:1528139807843};\\\", \\\"{x:1274,y:963,t:1528139807922};\\\", \\\"{x:1275,y:963,t:1528139807938};\\\", \\\"{x:1277,y:963,t:1528139807946};\\\", \\\"{x:1281,y:963,t:1528139807961};\\\", \\\"{x:1288,y:962,t:1528139807978};\\\", \\\"{x:1300,y:959,t:1528139807994};\\\", \\\"{x:1324,y:956,t:1528139808011};\\\", \\\"{x:1335,y:956,t:1528139808028};\\\", \\\"{x:1345,y:956,t:1528139808044};\\\", \\\"{x:1357,y:956,t:1528139808061};\\\", \\\"{x:1366,y:955,t:1528139808078};\\\", \\\"{x:1369,y:953,t:1528139808093};\\\", \\\"{x:1373,y:953,t:1528139808110};\\\", \\\"{x:1376,y:953,t:1528139808128};\\\", \\\"{x:1377,y:953,t:1528139808144};\\\", \\\"{x:1380,y:953,t:1528139808160};\\\", \\\"{x:1383,y:950,t:1528139808178};\\\", \\\"{x:1386,y:950,t:1528139808194};\\\", \\\"{x:1389,y:950,t:1528139808210};\\\", \\\"{x:1390,y:950,t:1528139808227};\\\", \\\"{x:1392,y:950,t:1528139808243};\\\", \\\"{x:1395,y:950,t:1528139808260};\\\", \\\"{x:1396,y:950,t:1528139808278};\\\", \\\"{x:1399,y:950,t:1528139808294};\\\", \\\"{x:1402,y:950,t:1528139808311};\\\", \\\"{x:1405,y:950,t:1528139808328};\\\", \\\"{x:1407,y:950,t:1528139808344};\\\", \\\"{x:1412,y:950,t:1528139808360};\\\", \\\"{x:1414,y:950,t:1528139808378};\\\", \\\"{x:1420,y:950,t:1528139808395};\\\", \\\"{x:1424,y:950,t:1528139808410};\\\", \\\"{x:1430,y:950,t:1528139808428};\\\", \\\"{x:1435,y:950,t:1528139808444};\\\", \\\"{x:1437,y:950,t:1528139808460};\\\", \\\"{x:1440,y:950,t:1528139808477};\\\", \\\"{x:1442,y:950,t:1528139808494};\\\", \\\"{x:1444,y:951,t:1528139808510};\\\", \\\"{x:1447,y:951,t:1528139808527};\\\", \\\"{x:1449,y:953,t:1528139808545};\\\", \\\"{x:1451,y:954,t:1528139808561};\\\", \\\"{x:1452,y:954,t:1528139808643};\\\", \\\"{x:1453,y:956,t:1528139808650};\\\", \\\"{x:1454,y:958,t:1528139808661};\\\", \\\"{x:1456,y:960,t:1528139808677};\\\", \\\"{x:1457,y:961,t:1528139808694};\\\", \\\"{x:1457,y:962,t:1528139808711};\\\", \\\"{x:1457,y:963,t:1528139808729};\\\", \\\"{x:1456,y:963,t:1528139809075};\\\", \\\"{x:1455,y:963,t:1528139809106};\\\", \\\"{x:1454,y:963,t:1528139809163};\\\", \\\"{x:1453,y:964,t:1528139809178};\\\", \\\"{x:1451,y:964,t:1528139809194};\\\", \\\"{x:1449,y:965,t:1528139809218};\\\", \\\"{x:1448,y:965,t:1528139809227};\\\", \\\"{x:1447,y:965,t:1528139809245};\\\", \\\"{x:1446,y:965,t:1528139809314};\\\", \\\"{x:1445,y:965,t:1528139809986};\\\", \\\"{x:1441,y:965,t:1528139809996};\\\", \\\"{x:1435,y:965,t:1528139810011};\\\", \\\"{x:1430,y:965,t:1528139810028};\\\", \\\"{x:1424,y:965,t:1528139810045};\\\", \\\"{x:1419,y:965,t:1528139810062};\\\", \\\"{x:1412,y:966,t:1528139810078};\\\", \\\"{x:1408,y:966,t:1528139810096};\\\", \\\"{x:1402,y:966,t:1528139810111};\\\", \\\"{x:1400,y:967,t:1528139810128};\\\", \\\"{x:1395,y:967,t:1528139810146};\\\", \\\"{x:1390,y:968,t:1528139810161};\\\", \\\"{x:1384,y:969,t:1528139810178};\\\", \\\"{x:1379,y:969,t:1528139810195};\\\", \\\"{x:1375,y:970,t:1528139810212};\\\", \\\"{x:1371,y:971,t:1528139810228};\\\", \\\"{x:1370,y:971,t:1528139810246};\\\", \\\"{x:1365,y:971,t:1528139810262};\\\", \\\"{x:1363,y:971,t:1528139810331};\\\", \\\"{x:1359,y:971,t:1528139810354};\\\", \\\"{x:1359,y:972,t:1528139810362};\\\", \\\"{x:1357,y:972,t:1528139810378};\\\", \\\"{x:1354,y:972,t:1528139810395};\\\", \\\"{x:1349,y:972,t:1528139810413};\\\", \\\"{x:1346,y:972,t:1528139810429};\\\", \\\"{x:1342,y:972,t:1528139810446};\\\", \\\"{x:1340,y:972,t:1528139810463};\\\", \\\"{x:1336,y:972,t:1528139810479};\\\", \\\"{x:1335,y:972,t:1528139810496};\\\", \\\"{x:1333,y:972,t:1528139810513};\\\", \\\"{x:1330,y:972,t:1528139810529};\\\", \\\"{x:1326,y:972,t:1528139810547};\\\", \\\"{x:1324,y:972,t:1528139810562};\\\", \\\"{x:1320,y:972,t:1528139810579};\\\", \\\"{x:1317,y:972,t:1528139810595};\\\", \\\"{x:1312,y:974,t:1528139810613};\\\", \\\"{x:1305,y:975,t:1528139810630};\\\", \\\"{x:1297,y:977,t:1528139810646};\\\", \\\"{x:1289,y:980,t:1528139810662};\\\", \\\"{x:1283,y:981,t:1528139810680};\\\", \\\"{x:1274,y:984,t:1528139810695};\\\", \\\"{x:1272,y:984,t:1528139810713};\\\", \\\"{x:1270,y:985,t:1528139810731};\\\", \\\"{x:1267,y:985,t:1528139810746};\\\", \\\"{x:1266,y:985,t:1528139810762};\\\", \\\"{x:1264,y:986,t:1528139810780};\\\", \\\"{x:1263,y:986,t:1528139811202};\\\", \\\"{x:1263,y:984,t:1528139811539};\\\", \\\"{x:1263,y:983,t:1528139811546};\\\", \\\"{x:1263,y:980,t:1528139811564};\\\", \\\"{x:1263,y:978,t:1528139811580};\\\", \\\"{x:1262,y:976,t:1528139811597};\\\", \\\"{x:1262,y:974,t:1528139811614};\\\", \\\"{x:1261,y:973,t:1528139811631};\\\", \\\"{x:1261,y:971,t:1528139811843};\\\", \\\"{x:1261,y:970,t:1528139811899};\\\", \\\"{x:1259,y:970,t:1528139811922};\\\", \\\"{x:1258,y:970,t:1528139811938};\\\", \\\"{x:1258,y:969,t:1528139811947};\\\", \\\"{x:1257,y:969,t:1528139811963};\\\", \\\"{x:1256,y:968,t:1528139811981};\\\", \\\"{x:1255,y:967,t:1528139812155};\\\", \\\"{x:1254,y:967,t:1528139812163};\\\", \\\"{x:1254,y:965,t:1528139812187};\\\", \\\"{x:1252,y:965,t:1528139812490};\\\", \\\"{x:1251,y:965,t:1528139812539};\\\", \\\"{x:1249,y:965,t:1528139812548};\\\", \\\"{x:1248,y:965,t:1528139812723};\\\", \\\"{x:1246,y:965,t:1528139812763};\\\", \\\"{x:1245,y:965,t:1528139812794};\\\", \\\"{x:1244,y:965,t:1528139812890};\\\", \\\"{x:1231,y:964,t:1528139820707};\\\", \\\"{x:1193,y:955,t:1528139820721};\\\", \\\"{x:1077,y:924,t:1528139820737};\\\", \\\"{x:860,y:874,t:1528139820754};\\\", \\\"{x:712,y:823,t:1528139820770};\\\", \\\"{x:569,y:759,t:1528139820787};\\\", \\\"{x:423,y:700,t:1528139820803};\\\", \\\"{x:288,y:636,t:1528139820821};\\\", \\\"{x:158,y:578,t:1528139820839};\\\", \\\"{x:33,y:518,t:1528139820854};\\\", \\\"{x:0,y:477,t:1528139820870};\\\", \\\"{x:0,y:451,t:1528139820888};\\\", \\\"{x:0,y:429,t:1528139820903};\\\", \\\"{x:0,y:403,t:1528139820920};\\\", \\\"{x:0,y:390,t:1528139820937};\\\", \\\"{x:0,y:384,t:1528139820955};\\\", \\\"{x:0,y:382,t:1528139820970};\\\", \\\"{x:0,y:381,t:1528139820987};\\\", \\\"{x:0,y:379,t:1528139821005};\\\", \\\"{x:0,y:376,t:1528139821041};\\\", \\\"{x:1,y:375,t:1528139821055};\\\", \\\"{x:14,y:371,t:1528139821071};\\\", \\\"{x:33,y:367,t:1528139821087};\\\", \\\"{x:55,y:373,t:1528139821104};\\\", \\\"{x:86,y:405,t:1528139821122};\\\", \\\"{x:108,y:432,t:1528139821139};\\\", \\\"{x:128,y:458,t:1528139821155};\\\", \\\"{x:145,y:485,t:1528139821172};\\\", \\\"{x:150,y:494,t:1528139821190};\\\", \\\"{x:152,y:498,t:1528139821205};\\\", \\\"{x:153,y:502,t:1528139821221};\\\", \\\"{x:152,y:503,t:1528139821290};\\\", \\\"{x:151,y:505,t:1528139821304};\\\", \\\"{x:148,y:515,t:1528139821320};\\\", \\\"{x:148,y:524,t:1528139821339};\\\", \\\"{x:148,y:525,t:1528139821370};\\\", \\\"{x:149,y:525,t:1528139821387};\\\", \\\"{x:153,y:525,t:1528139821403};\\\", \\\"{x:160,y:518,t:1528139821421};\\\", \\\"{x:168,y:504,t:1528139821438};\\\", \\\"{x:174,y:492,t:1528139821457};\\\", \\\"{x:175,y:487,t:1528139821471};\\\", \\\"{x:177,y:484,t:1528139821488};\\\", \\\"{x:177,y:483,t:1528139821626};\\\", \\\"{x:175,y:483,t:1528139821658};\\\", \\\"{x:174,y:483,t:1528139821671};\\\", \\\"{x:173,y:484,t:1528139821688};\\\", \\\"{x:172,y:485,t:1528139821706};\\\", \\\"{x:172,y:487,t:1528139821722};\\\", \\\"{x:171,y:490,t:1528139821738};\\\", \\\"{x:171,y:493,t:1528139821755};\\\", \\\"{x:171,y:494,t:1528139821772};\\\", \\\"{x:170,y:495,t:1528139821866};\\\", \\\"{x:169,y:497,t:1528139821937};\\\", \\\"{x:168,y:497,t:1528139821978};\\\", \\\"{x:171,y:497,t:1528139822329};\\\", \\\"{x:175,y:497,t:1528139822338};\\\", \\\"{x:197,y:502,t:1528139822355};\\\", \\\"{x:258,y:510,t:1528139822372};\\\", \\\"{x:315,y:515,t:1528139822389};\\\", \\\"{x:358,y:522,t:1528139822406};\\\", \\\"{x:399,y:532,t:1528139822423};\\\", \\\"{x:452,y:540,t:1528139822439};\\\", \\\"{x:476,y:546,t:1528139822455};\\\", \\\"{x:493,y:548,t:1528139822472};\\\", \\\"{x:496,y:549,t:1528139822488};\\\", \\\"{x:498,y:549,t:1528139822504};\\\", \\\"{x:496,y:549,t:1528139822642};\\\", \\\"{x:493,y:546,t:1528139822655};\\\", \\\"{x:487,y:543,t:1528139822671};\\\", \\\"{x:482,y:537,t:1528139822688};\\\", \\\"{x:476,y:533,t:1528139822705};\\\", \\\"{x:470,y:530,t:1528139822721};\\\", \\\"{x:463,y:526,t:1528139822738};\\\", \\\"{x:456,y:522,t:1528139822756};\\\", \\\"{x:453,y:521,t:1528139822771};\\\", \\\"{x:451,y:520,t:1528139822788};\\\", \\\"{x:447,y:519,t:1528139822805};\\\", \\\"{x:445,y:519,t:1528139822821};\\\", \\\"{x:444,y:518,t:1528139822838};\\\", \\\"{x:442,y:518,t:1528139822855};\\\", \\\"{x:440,y:517,t:1528139822872};\\\", \\\"{x:437,y:516,t:1528139822889};\\\", \\\"{x:431,y:515,t:1528139822905};\\\", \\\"{x:427,y:514,t:1528139822922};\\\", \\\"{x:425,y:514,t:1528139822939};\\\", \\\"{x:421,y:511,t:1528139822956};\\\", \\\"{x:419,y:511,t:1528139822971};\\\", \\\"{x:414,y:511,t:1528139822989};\\\", \\\"{x:407,y:511,t:1528139823005};\\\", \\\"{x:404,y:510,t:1528139823021};\\\", \\\"{x:398,y:508,t:1528139823038};\\\", \\\"{x:393,y:508,t:1528139823056};\\\", \\\"{x:390,y:508,t:1528139823072};\\\", \\\"{x:387,y:507,t:1528139823089};\\\", \\\"{x:385,y:506,t:1528139823106};\\\", \\\"{x:384,y:506,t:1528139823163};\\\", \\\"{x:382,y:506,t:1528139823178};\\\", \\\"{x:381,y:505,t:1528139823189};\\\", \\\"{x:379,y:504,t:1528139823206};\\\", \\\"{x:378,y:504,t:1528139823222};\\\", \\\"{x:377,y:504,t:1528139823239};\\\", \\\"{x:376,y:503,t:1528139823256};\\\", \\\"{x:376,y:505,t:1528139823754};\\\", \\\"{x:407,y:514,t:1528139823763};\\\", \\\"{x:470,y:531,t:1528139823774};\\\", \\\"{x:615,y:557,t:1528139823790};\\\", \\\"{x:762,y:578,t:1528139823806};\\\", \\\"{x:909,y:602,t:1528139823823};\\\", \\\"{x:1057,y:635,t:1528139823840};\\\", \\\"{x:1224,y:673,t:1528139823856};\\\", \\\"{x:1397,y:708,t:1528139823872};\\\", \\\"{x:1650,y:767,t:1528139823889};\\\", \\\"{x:1774,y:796,t:1528139823905};\\\", \\\"{x:1875,y:820,t:1528139823922};\\\", \\\"{x:1919,y:838,t:1528139823940};\\\", \\\"{x:1919,y:848,t:1528139823955};\\\", \\\"{x:1919,y:854,t:1528139823973};\\\", \\\"{x:1917,y:854,t:1528139824033};\\\", \\\"{x:1913,y:854,t:1528139824042};\\\", \\\"{x:1909,y:854,t:1528139824056};\\\", \\\"{x:1895,y:854,t:1528139824073};\\\", \\\"{x:1876,y:850,t:1528139824090};\\\", \\\"{x:1861,y:845,t:1528139824106};\\\", \\\"{x:1843,y:840,t:1528139824122};\\\", \\\"{x:1818,y:834,t:1528139824140};\\\", \\\"{x:1793,y:829,t:1528139824156};\\\", \\\"{x:1762,y:824,t:1528139824173};\\\", \\\"{x:1739,y:819,t:1528139824190};\\\", \\\"{x:1712,y:816,t:1528139824207};\\\", \\\"{x:1680,y:810,t:1528139824223};\\\", \\\"{x:1656,y:804,t:1528139824240};\\\", \\\"{x:1636,y:804,t:1528139824257};\\\", \\\"{x:1622,y:804,t:1528139824273};\\\", \\\"{x:1614,y:804,t:1528139824291};\\\", \\\"{x:1611,y:804,t:1528139824307};\\\", \\\"{x:1610,y:804,t:1528139824355};\\\", \\\"{x:1610,y:805,t:1528139824362};\\\", \\\"{x:1610,y:806,t:1528139824373};\\\", \\\"{x:1610,y:810,t:1528139824391};\\\", \\\"{x:1610,y:819,t:1528139824407};\\\", \\\"{x:1608,y:830,t:1528139824424};\\\", \\\"{x:1606,y:840,t:1528139824441};\\\", \\\"{x:1605,y:846,t:1528139824458};\\\", \\\"{x:1605,y:854,t:1528139824474};\\\", \\\"{x:1610,y:866,t:1528139824490};\\\", \\\"{x:1615,y:873,t:1528139824508};\\\", \\\"{x:1621,y:880,t:1528139824523};\\\", \\\"{x:1634,y:891,t:1528139824540};\\\", \\\"{x:1649,y:901,t:1528139824557};\\\", \\\"{x:1662,y:912,t:1528139824573};\\\", \\\"{x:1676,y:919,t:1528139824590};\\\", \\\"{x:1688,y:925,t:1528139824607};\\\", \\\"{x:1702,y:932,t:1528139824624};\\\", \\\"{x:1709,y:933,t:1528139824640};\\\", \\\"{x:1711,y:934,t:1528139824658};\\\", \\\"{x:1708,y:932,t:1528139824739};\\\", \\\"{x:1699,y:927,t:1528139824746};\\\", \\\"{x:1689,y:923,t:1528139824758};\\\", \\\"{x:1668,y:910,t:1528139824775};\\\", \\\"{x:1638,y:898,t:1528139824790};\\\", \\\"{x:1613,y:887,t:1528139824807};\\\", \\\"{x:1591,y:876,t:1528139824824};\\\", \\\"{x:1567,y:868,t:1528139824840};\\\", \\\"{x:1543,y:857,t:1528139824858};\\\", \\\"{x:1506,y:846,t:1528139824874};\\\", \\\"{x:1489,y:840,t:1528139824891};\\\", \\\"{x:1477,y:837,t:1528139824908};\\\", \\\"{x:1472,y:835,t:1528139824925};\\\", \\\"{x:1471,y:835,t:1528139824941};\\\", \\\"{x:1470,y:835,t:1528139825074};\\\", \\\"{x:1469,y:835,t:1528139825091};\\\", \\\"{x:1468,y:835,t:1528139825107};\\\", \\\"{x:1467,y:835,t:1528139825125};\\\", \\\"{x:1465,y:838,t:1528139825141};\\\", \\\"{x:1464,y:840,t:1528139825162};\\\", \\\"{x:1463,y:841,t:1528139825175};\\\", \\\"{x:1461,y:843,t:1528139825192};\\\", \\\"{x:1458,y:846,t:1528139825208};\\\", \\\"{x:1457,y:847,t:1528139825224};\\\", \\\"{x:1457,y:849,t:1528139825241};\\\", \\\"{x:1455,y:850,t:1528139825258};\\\", \\\"{x:1453,y:851,t:1528139825274};\\\", \\\"{x:1452,y:853,t:1528139825291};\\\", \\\"{x:1451,y:854,t:1528139825371};\\\", \\\"{x:1451,y:853,t:1528139825538};\\\", \\\"{x:1451,y:852,t:1528139825562};\\\", \\\"{x:1451,y:851,t:1528139825586};\\\", \\\"{x:1453,y:850,t:1528139825714};\\\", \\\"{x:1453,y:848,t:1528139825724};\\\", \\\"{x:1457,y:842,t:1528139825741};\\\", \\\"{x:1462,y:834,t:1528139825758};\\\", \\\"{x:1470,y:825,t:1528139825775};\\\", \\\"{x:1475,y:821,t:1528139825792};\\\", \\\"{x:1484,y:817,t:1528139825808};\\\", \\\"{x:1490,y:816,t:1528139825825};\\\", \\\"{x:1498,y:813,t:1528139825841};\\\", \\\"{x:1503,y:813,t:1528139825859};\\\", \\\"{x:1505,y:813,t:1528139825874};\\\", \\\"{x:1506,y:813,t:1528139825923};\\\", \\\"{x:1508,y:813,t:1528139825946};\\\", \\\"{x:1511,y:812,t:1528139825958};\\\", \\\"{x:1517,y:812,t:1528139825975};\\\", \\\"{x:1529,y:812,t:1528139825991};\\\", \\\"{x:1544,y:812,t:1528139826009};\\\", \\\"{x:1555,y:812,t:1528139826025};\\\", \\\"{x:1596,y:812,t:1528139826042};\\\", \\\"{x:1631,y:816,t:1528139826058};\\\", \\\"{x:1679,y:823,t:1528139826076};\\\", \\\"{x:1724,y:829,t:1528139826092};\\\", \\\"{x:1759,y:836,t:1528139826108};\\\", \\\"{x:1782,y:836,t:1528139826125};\\\", \\\"{x:1797,y:836,t:1528139826141};\\\", \\\"{x:1800,y:836,t:1528139826159};\\\", \\\"{x:1800,y:835,t:1528139826176};\\\", \\\"{x:1800,y:832,t:1528139826235};\\\", \\\"{x:1795,y:829,t:1528139826242};\\\", \\\"{x:1784,y:823,t:1528139826258};\\\", \\\"{x:1776,y:820,t:1528139826276};\\\", \\\"{x:1761,y:812,t:1528139826293};\\\", \\\"{x:1743,y:811,t:1528139826308};\\\", \\\"{x:1713,y:806,t:1528139826326};\\\", \\\"{x:1675,y:805,t:1528139826343};\\\", \\\"{x:1647,y:799,t:1528139826358};\\\", \\\"{x:1613,y:799,t:1528139826376};\\\", \\\"{x:1583,y:794,t:1528139826392};\\\", \\\"{x:1558,y:790,t:1528139826409};\\\", \\\"{x:1545,y:786,t:1528139826426};\\\", \\\"{x:1530,y:781,t:1528139826443};\\\", \\\"{x:1527,y:780,t:1528139826458};\\\", \\\"{x:1525,y:780,t:1528139826476};\\\", \\\"{x:1523,y:780,t:1528139826650};\\\", \\\"{x:1522,y:780,t:1528139826660};\\\", \\\"{x:1519,y:785,t:1528139826676};\\\", \\\"{x:1517,y:787,t:1528139826692};\\\", \\\"{x:1516,y:788,t:1528139826709};\\\", \\\"{x:1515,y:792,t:1528139826726};\\\", \\\"{x:1513,y:794,t:1528139826743};\\\", \\\"{x:1512,y:795,t:1528139826759};\\\", \\\"{x:1512,y:796,t:1528139826775};\\\", \\\"{x:1512,y:797,t:1528139826792};\\\", \\\"{x:1511,y:798,t:1528139826809};\\\", \\\"{x:1511,y:799,t:1528139826826};\\\", \\\"{x:1509,y:802,t:1528139826842};\\\", \\\"{x:1507,y:805,t:1528139826859};\\\", \\\"{x:1505,y:808,t:1528139826876};\\\", \\\"{x:1504,y:811,t:1528139826892};\\\", \\\"{x:1502,y:814,t:1528139826910};\\\", \\\"{x:1500,y:817,t:1528139826925};\\\", \\\"{x:1497,y:823,t:1528139826942};\\\", \\\"{x:1493,y:827,t:1528139826960};\\\", \\\"{x:1489,y:832,t:1528139826977};\\\", \\\"{x:1484,y:838,t:1528139826992};\\\", \\\"{x:1479,y:841,t:1528139827009};\\\", \\\"{x:1477,y:843,t:1528139827026};\\\", \\\"{x:1476,y:843,t:1528139827042};\\\", \\\"{x:1476,y:842,t:1528139827179};\\\", \\\"{x:1476,y:839,t:1528139827192};\\\", \\\"{x:1477,y:837,t:1528139827210};\\\", \\\"{x:1477,y:835,t:1528139827226};\\\", \\\"{x:1477,y:834,t:1528139827258};\\\", \\\"{x:1477,y:833,t:1528139827891};\\\", \\\"{x:1479,y:833,t:1528139827971};\\\", \\\"{x:1480,y:833,t:1528139828002};\\\", \\\"{x:1482,y:833,t:1528139828010};\\\", \\\"{x:1483,y:832,t:1528139828050};\\\", \\\"{x:1487,y:832,t:1528139833163};\\\", \\\"{x:1491,y:840,t:1528139833182};\\\", \\\"{x:1494,y:845,t:1528139833198};\\\", \\\"{x:1498,y:851,t:1528139833215};\\\", \\\"{x:1500,y:855,t:1528139833232};\\\", \\\"{x:1500,y:856,t:1528139833248};\\\", \\\"{x:1503,y:859,t:1528139833265};\\\", \\\"{x:1506,y:862,t:1528139833282};\\\", \\\"{x:1507,y:863,t:1528139833298};\\\", \\\"{x:1507,y:866,t:1528139833314};\\\", \\\"{x:1509,y:868,t:1528139833332};\\\", \\\"{x:1510,y:870,t:1528139833348};\\\", \\\"{x:1511,y:872,t:1528139833365};\\\", \\\"{x:1515,y:874,t:1528139833382};\\\", \\\"{x:1516,y:876,t:1528139833398};\\\", \\\"{x:1517,y:879,t:1528139833414};\\\", \\\"{x:1518,y:881,t:1528139833431};\\\", \\\"{x:1521,y:886,t:1528139833448};\\\", \\\"{x:1522,y:889,t:1528139833464};\\\", \\\"{x:1524,y:893,t:1528139833482};\\\", \\\"{x:1525,y:895,t:1528139833498};\\\", \\\"{x:1527,y:899,t:1528139833515};\\\", \\\"{x:1529,y:902,t:1528139833531};\\\", \\\"{x:1531,y:906,t:1528139833549};\\\", \\\"{x:1531,y:908,t:1528139833564};\\\", \\\"{x:1534,y:912,t:1528139833582};\\\", \\\"{x:1535,y:915,t:1528139833599};\\\", \\\"{x:1537,y:917,t:1528139833615};\\\", \\\"{x:1538,y:920,t:1528139833632};\\\", \\\"{x:1539,y:922,t:1528139833648};\\\", \\\"{x:1541,y:924,t:1528139833665};\\\", \\\"{x:1542,y:926,t:1528139833682};\\\", \\\"{x:1544,y:929,t:1528139833699};\\\", \\\"{x:1544,y:930,t:1528139833715};\\\", \\\"{x:1545,y:931,t:1528139833732};\\\", \\\"{x:1546,y:933,t:1528139833749};\\\", \\\"{x:1546,y:934,t:1528139833770};\\\", \\\"{x:1547,y:936,t:1528139833786};\\\", \\\"{x:1548,y:937,t:1528139833802};\\\", \\\"{x:1549,y:938,t:1528139833826};\\\", \\\"{x:1549,y:939,t:1528139833850};\\\", \\\"{x:1550,y:940,t:1528139833865};\\\", \\\"{x:1551,y:941,t:1528139833882};\\\", \\\"{x:1553,y:944,t:1528139833898};\\\", \\\"{x:1554,y:945,t:1528139833915};\\\", \\\"{x:1556,y:946,t:1528139833954};\\\", \\\"{x:1556,y:947,t:1528139833965};\\\", \\\"{x:1557,y:948,t:1528139833982};\\\", \\\"{x:1558,y:949,t:1528139833999};\\\", \\\"{x:1558,y:950,t:1528139834015};\\\", \\\"{x:1560,y:952,t:1528139834031};\\\", \\\"{x:1561,y:954,t:1528139834048};\\\", \\\"{x:1561,y:955,t:1528139834066};\\\", \\\"{x:1563,y:956,t:1528139834081};\\\", \\\"{x:1563,y:957,t:1528139834098};\\\", \\\"{x:1563,y:958,t:1528139834115};\\\", \\\"{x:1564,y:959,t:1528139834153};\\\", \\\"{x:1564,y:960,t:1528139834203};\\\", \\\"{x:1564,y:961,t:1528139834226};\\\", \\\"{x:1565,y:961,t:1528139834338};\\\", \\\"{x:1566,y:961,t:1528139834362};\\\", \\\"{x:1567,y:961,t:1528139834378};\\\", \\\"{x:1567,y:962,t:1528139834386};\\\", \\\"{x:1568,y:963,t:1528139834403};\\\", \\\"{x:1565,y:963,t:1528139834881};\\\", \\\"{x:1564,y:963,t:1528139834889};\\\", \\\"{x:1562,y:962,t:1528139834899};\\\", \\\"{x:1562,y:958,t:1528139834915};\\\", \\\"{x:1560,y:956,t:1528139834932};\\\", \\\"{x:1559,y:955,t:1528139834949};\\\", \\\"{x:1559,y:954,t:1528139834965};\\\", \\\"{x:1558,y:954,t:1528139835009};\\\", \\\"{x:1558,y:953,t:1528139835058};\\\", \\\"{x:1558,y:952,t:1528139835090};\\\", \\\"{x:1558,y:951,t:1528139835100};\\\", \\\"{x:1555,y:949,t:1528139835116};\\\", \\\"{x:1555,y:947,t:1528139835133};\\\", \\\"{x:1553,y:943,t:1528139835150};\\\", \\\"{x:1552,y:939,t:1528139835167};\\\", \\\"{x:1549,y:934,t:1528139835183};\\\", \\\"{x:1547,y:929,t:1528139835201};\\\", \\\"{x:1546,y:923,t:1528139835217};\\\", \\\"{x:1544,y:920,t:1528139835233};\\\", \\\"{x:1544,y:919,t:1528139835250};\\\", \\\"{x:1544,y:917,t:1528139835323};\\\", \\\"{x:1544,y:916,t:1528139835333};\\\", \\\"{x:1543,y:910,t:1528139835349};\\\", \\\"{x:1540,y:904,t:1528139835367};\\\", \\\"{x:1539,y:893,t:1528139835383};\\\", \\\"{x:1537,y:880,t:1528139835400};\\\", \\\"{x:1537,y:873,t:1528139835417};\\\", \\\"{x:1536,y:866,t:1528139835433};\\\", \\\"{x:1535,y:862,t:1528139835450};\\\", \\\"{x:1535,y:861,t:1528139835490};\\\", \\\"{x:1535,y:860,t:1528139835522};\\\", \\\"{x:1534,y:859,t:1528139835554};\\\", \\\"{x:1534,y:858,t:1528139835578};\\\", \\\"{x:1534,y:856,t:1528139835586};\\\", \\\"{x:1534,y:855,t:1528139835600};\\\", \\\"{x:1533,y:851,t:1528139835617};\\\", \\\"{x:1531,y:842,t:1528139835634};\\\", \\\"{x:1531,y:836,t:1528139835650};\\\", \\\"{x:1530,y:830,t:1528139835667};\\\", \\\"{x:1528,y:825,t:1528139835684};\\\", \\\"{x:1528,y:823,t:1528139835700};\\\", \\\"{x:1528,y:822,t:1528139835717};\\\", \\\"{x:1528,y:821,t:1528139835738};\\\", \\\"{x:1528,y:820,t:1528139835750};\\\", \\\"{x:1527,y:819,t:1528139835767};\\\", \\\"{x:1527,y:816,t:1528139835783};\\\", \\\"{x:1526,y:815,t:1528139835799};\\\", \\\"{x:1526,y:814,t:1528139835818};\\\", \\\"{x:1526,y:813,t:1528139835842};\\\", \\\"{x:1526,y:811,t:1528139835899};\\\", \\\"{x:1525,y:811,t:1528139836251};\\\", \\\"{x:1525,y:810,t:1528139837026};\\\", \\\"{x:1525,y:809,t:1528139837082};\\\", \\\"{x:1525,y:807,t:1528139837090};\\\", \\\"{x:1526,y:806,t:1528139837101};\\\", \\\"{x:1526,y:802,t:1528139837118};\\\", \\\"{x:1526,y:799,t:1528139837135};\\\", \\\"{x:1526,y:797,t:1528139837151};\\\", \\\"{x:1526,y:794,t:1528139837168};\\\", \\\"{x:1526,y:792,t:1528139837185};\\\", \\\"{x:1528,y:788,t:1528139837202};\\\", \\\"{x:1528,y:787,t:1528139837226};\\\", \\\"{x:1528,y:786,t:1528139837242};\\\", \\\"{x:1528,y:785,t:1528139837259};\\\", \\\"{x:1528,y:784,t:1528139837268};\\\", \\\"{x:1528,y:783,t:1528139837290};\\\", \\\"{x:1528,y:782,t:1528139837302};\\\", \\\"{x:1527,y:780,t:1528139837318};\\\", \\\"{x:1527,y:779,t:1528139837339};\\\", \\\"{x:1527,y:778,t:1528139837352};\\\", \\\"{x:1527,y:777,t:1528139837368};\\\", \\\"{x:1527,y:775,t:1528139837385};\\\", \\\"{x:1527,y:773,t:1528139837402};\\\", \\\"{x:1527,y:772,t:1528139837418};\\\", \\\"{x:1527,y:771,t:1528139837441};\\\", \\\"{x:1527,y:770,t:1528139837457};\\\", \\\"{x:1526,y:770,t:1528139837489};\\\", \\\"{x:1526,y:769,t:1528139837502};\\\", \\\"{x:1526,y:768,t:1528139837643};\\\", \\\"{x:1525,y:767,t:1528139838082};\\\", \\\"{x:1524,y:768,t:1528139838138};\\\", \\\"{x:1523,y:770,t:1528139838650};\\\", \\\"{x:1521,y:771,t:1528139838755};\\\", \\\"{x:1520,y:771,t:1528139838931};\\\", \\\"{x:1519,y:771,t:1528139839002};\\\", \\\"{x:1511,y:771,t:1528139840074};\\\", \\\"{x:1500,y:771,t:1528139840087};\\\", \\\"{x:1476,y:773,t:1528139840104};\\\", \\\"{x:1447,y:773,t:1528139840121};\\\", \\\"{x:1419,y:774,t:1528139840137};\\\", \\\"{x:1393,y:774,t:1528139840153};\\\", \\\"{x:1378,y:774,t:1528139840171};\\\", \\\"{x:1365,y:774,t:1528139840187};\\\", \\\"{x:1361,y:774,t:1528139840203};\\\", \\\"{x:1359,y:774,t:1528139840220};\\\", \\\"{x:1358,y:775,t:1528139840257};\\\", \\\"{x:1357,y:776,t:1528139840613};\\\", \\\"{x:1356,y:775,t:1528139840646};\\\", \\\"{x:1353,y:772,t:1528139840657};\\\", \\\"{x:1345,y:766,t:1528139840674};\\\", \\\"{x:1339,y:762,t:1528139840692};\\\", \\\"{x:1329,y:754,t:1528139840707};\\\", \\\"{x:1315,y:748,t:1528139840725};\\\", \\\"{x:1301,y:742,t:1528139840741};\\\", \\\"{x:1294,y:738,t:1528139840757};\\\", \\\"{x:1293,y:738,t:1528139841077};\\\", \\\"{x:1294,y:739,t:1528139841091};\\\", \\\"{x:1297,y:741,t:1528139841108};\\\", \\\"{x:1303,y:746,t:1528139841124};\\\", \\\"{x:1312,y:754,t:1528139841141};\\\", \\\"{x:1320,y:760,t:1528139841157};\\\", \\\"{x:1327,y:765,t:1528139841175};\\\", \\\"{x:1329,y:766,t:1528139841191};\\\", \\\"{x:1333,y:770,t:1528139841208};\\\", \\\"{x:1334,y:770,t:1528139841224};\\\", \\\"{x:1334,y:771,t:1528139841241};\\\", \\\"{x:1333,y:772,t:1528139841846};\\\", \\\"{x:1329,y:771,t:1528139841858};\\\", \\\"{x:1302,y:764,t:1528139841876};\\\", \\\"{x:1247,y:742,t:1528139841892};\\\", \\\"{x:1131,y:711,t:1528139841909};\\\", \\\"{x:918,y:648,t:1528139841925};\\\", \\\"{x:764,y:611,t:1528139841943};\\\", \\\"{x:593,y:566,t:1528139841959};\\\", \\\"{x:285,y:489,t:1528139841992};\\\", \\\"{x:243,y:473,t:1528139842002};\\\", \\\"{x:232,y:462,t:1528139842019};\\\", \\\"{x:231,y:462,t:1528139842036};\\\", \\\"{x:233,y:462,t:1528139842100};\\\", \\\"{x:235,y:461,t:1528139842108};\\\", \\\"{x:238,y:459,t:1528139842124};\\\", \\\"{x:241,y:459,t:1528139842135};\\\", \\\"{x:246,y:463,t:1528139842152};\\\", \\\"{x:254,y:469,t:1528139842169};\\\", \\\"{x:260,y:471,t:1528139842186};\\\", \\\"{x:272,y:476,t:1528139842201};\\\", \\\"{x:290,y:479,t:1528139842219};\\\", \\\"{x:319,y:489,t:1528139842237};\\\", \\\"{x:375,y:509,t:1528139842252};\\\", \\\"{x:423,y:525,t:1528139842270};\\\", \\\"{x:482,y:543,t:1528139842285};\\\", \\\"{x:564,y:562,t:1528139842308};\\\", \\\"{x:639,y:582,t:1528139842324};\\\", \\\"{x:719,y:596,t:1528139842341};\\\", \\\"{x:751,y:602,t:1528139842358};\\\", \\\"{x:759,y:605,t:1528139842374};\\\", \\\"{x:756,y:605,t:1528139842444};\\\", \\\"{x:750,y:604,t:1528139842457};\\\", \\\"{x:736,y:600,t:1528139842475};\\\", \\\"{x:713,y:593,t:1528139842492};\\\", \\\"{x:684,y:587,t:1528139842507};\\\", \\\"{x:626,y:587,t:1528139842525};\\\", \\\"{x:573,y:587,t:1528139842541};\\\", \\\"{x:521,y:583,t:1528139842557};\\\", \\\"{x:486,y:576,t:1528139842575};\\\", \\\"{x:457,y:570,t:1528139842591};\\\", \\\"{x:432,y:565,t:1528139842607};\\\", \\\"{x:411,y:561,t:1528139842625};\\\", \\\"{x:397,y:558,t:1528139842641};\\\", \\\"{x:392,y:557,t:1528139842658};\\\", \\\"{x:390,y:556,t:1528139842674};\\\", \\\"{x:389,y:556,t:1528139842690};\\\", \\\"{x:388,y:556,t:1528139842765};\\\", \\\"{x:386,y:556,t:1528139842775};\\\", \\\"{x:380,y:556,t:1528139842791};\\\", \\\"{x:371,y:557,t:1528139842808};\\\", \\\"{x:360,y:560,t:1528139842825};\\\", \\\"{x:345,y:561,t:1528139842841};\\\", \\\"{x:327,y:561,t:1528139842858};\\\", \\\"{x:300,y:561,t:1528139842875};\\\", \\\"{x:270,y:561,t:1528139842892};\\\", \\\"{x:257,y:561,t:1528139842908};\\\", \\\"{x:256,y:561,t:1528139842925};\\\", \\\"{x:255,y:561,t:1528139842941};\\\", \\\"{x:258,y:561,t:1528139843045};\\\", \\\"{x:265,y:559,t:1528139843058};\\\", \\\"{x:286,y:554,t:1528139843077};\\\", \\\"{x:312,y:551,t:1528139843091};\\\", \\\"{x:330,y:548,t:1528139843108};\\\", \\\"{x:357,y:544,t:1528139843124};\\\", \\\"{x:363,y:542,t:1528139843141};\\\", \\\"{x:367,y:542,t:1528139843158};\\\", \\\"{x:368,y:542,t:1528139843174};\\\", \\\"{x:370,y:542,t:1528139843191};\\\", \\\"{x:370,y:541,t:1528139843207};\\\", \\\"{x:373,y:541,t:1528139843225};\\\", \\\"{x:377,y:540,t:1528139843241};\\\", \\\"{x:383,y:539,t:1528139843257};\\\", \\\"{x:390,y:538,t:1528139843275};\\\", \\\"{x:403,y:535,t:1528139843292};\\\", \\\"{x:422,y:532,t:1528139843309};\\\", \\\"{x:459,y:528,t:1528139843325};\\\", \\\"{x:469,y:527,t:1528139843341};\\\", \\\"{x:474,y:527,t:1528139843358};\\\", \\\"{x:481,y:524,t:1528139843376};\\\", \\\"{x:488,y:521,t:1528139843391};\\\", \\\"{x:493,y:519,t:1528139843407};\\\", \\\"{x:495,y:519,t:1528139843436};\\\", \\\"{x:497,y:517,t:1528139843445};\\\", \\\"{x:498,y:516,t:1528139843459};\\\", \\\"{x:500,y:515,t:1528139843476};\\\", \\\"{x:504,y:512,t:1528139843492};\\\", \\\"{x:510,y:511,t:1528139843508};\\\", \\\"{x:510,y:510,t:1528139843525};\\\", \\\"{x:515,y:510,t:1528139843541};\\\", \\\"{x:519,y:510,t:1528139843558};\\\", \\\"{x:521,y:510,t:1528139843575};\\\", \\\"{x:523,y:510,t:1528139843592};\\\", \\\"{x:527,y:511,t:1528139843609};\\\", \\\"{x:530,y:512,t:1528139843625};\\\", \\\"{x:534,y:513,t:1528139843642};\\\", \\\"{x:535,y:514,t:1528139843659};\\\", \\\"{x:536,y:515,t:1528139843675};\\\", \\\"{x:539,y:517,t:1528139843693};\\\", \\\"{x:544,y:518,t:1528139843710};\\\", \\\"{x:547,y:520,t:1528139843725};\\\", \\\"{x:553,y:521,t:1528139843742};\\\", \\\"{x:556,y:521,t:1528139843759};\\\", \\\"{x:560,y:521,t:1528139843775};\\\", \\\"{x:566,y:521,t:1528139843792};\\\", \\\"{x:569,y:521,t:1528139843809};\\\", \\\"{x:575,y:518,t:1528139843824};\\\", \\\"{x:581,y:515,t:1528139843843};\\\", \\\"{x:592,y:510,t:1528139843858};\\\", \\\"{x:601,y:506,t:1528139843875};\\\", \\\"{x:606,y:505,t:1528139843892};\\\", \\\"{x:607,y:504,t:1528139843909};\\\", \\\"{x:608,y:504,t:1528139843924};\\\", \\\"{x:609,y:504,t:1528139843972};\\\", \\\"{x:611,y:504,t:1528139843988};\\\", \\\"{x:613,y:503,t:1528139843997};\\\", \\\"{x:615,y:503,t:1528139844009};\\\", \\\"{x:618,y:503,t:1528139844026};\\\", \\\"{x:619,y:502,t:1528139844042};\\\", \\\"{x:620,y:502,t:1528139844357};\\\", \\\"{x:630,y:502,t:1528139845390};\\\", \\\"{x:647,y:508,t:1528139845398};\\\", \\\"{x:673,y:519,t:1528139845410};\\\", \\\"{x:740,y:550,t:1528139845427};\\\", \\\"{x:802,y:574,t:1528139845443};\\\", \\\"{x:868,y:601,t:1528139845461};\\\", \\\"{x:991,y:641,t:1528139845476};\\\", \\\"{x:1097,y:673,t:1528139845493};\\\", \\\"{x:1190,y:706,t:1528139845510};\\\", \\\"{x:1280,y:738,t:1528139845527};\\\", \\\"{x:1355,y:760,t:1528139845543};\\\", \\\"{x:1421,y:779,t:1528139845559};\\\", \\\"{x:1466,y:791,t:1528139845576};\\\", \\\"{x:1491,y:796,t:1528139845593};\\\", \\\"{x:1506,y:797,t:1528139845610};\\\", \\\"{x:1510,y:797,t:1528139845626};\\\", \\\"{x:1511,y:797,t:1528139845643};\\\", \\\"{x:1507,y:797,t:1528139845789};\\\", \\\"{x:1499,y:797,t:1528139845797};\\\", \\\"{x:1491,y:793,t:1528139845810};\\\", \\\"{x:1477,y:789,t:1528139845826};\\\", \\\"{x:1460,y:785,t:1528139845842};\\\", \\\"{x:1443,y:782,t:1528139845859};\\\", \\\"{x:1427,y:777,t:1528139845876};\\\", \\\"{x:1420,y:774,t:1528139845893};\\\", \\\"{x:1418,y:774,t:1528139845917};\\\", \\\"{x:1417,y:774,t:1528139845997};\\\", \\\"{x:1415,y:774,t:1528139846009};\\\", \\\"{x:1411,y:773,t:1528139846025};\\\", \\\"{x:1407,y:771,t:1528139846042};\\\", \\\"{x:1403,y:770,t:1528139846058};\\\", \\\"{x:1397,y:766,t:1528139846075};\\\", \\\"{x:1392,y:765,t:1528139846092};\\\", \\\"{x:1386,y:764,t:1528139846108};\\\", \\\"{x:1375,y:762,t:1528139846125};\\\", \\\"{x:1368,y:761,t:1528139846141};\\\", \\\"{x:1352,y:758,t:1528139846158};\\\", \\\"{x:1343,y:756,t:1528139846176};\\\", \\\"{x:1339,y:756,t:1528139846192};\\\", \\\"{x:1338,y:756,t:1528139846208};\\\", \\\"{x:1337,y:754,t:1528139846493};\\\", \\\"{x:1337,y:752,t:1528139846509};\\\", \\\"{x:1338,y:751,t:1528139846525};\\\", \\\"{x:1338,y:750,t:1528139846541};\\\", \\\"{x:1339,y:750,t:1528139846790};\\\", \\\"{x:1342,y:748,t:1528139846806};\\\", \\\"{x:1342,y:749,t:1528139846893};\\\", \\\"{x:1342,y:750,t:1528139847094};\\\", \\\"{x:1342,y:751,t:1528139847126};\\\", \\\"{x:1342,y:752,t:1528139847165};\\\", \\\"{x:1342,y:753,t:1528139847189};\\\", \\\"{x:1342,y:754,t:1528139847206};\\\", \\\"{x:1342,y:755,t:1528139847222};\\\", \\\"{x:1342,y:756,t:1528139847238};\\\", \\\"{x:1342,y:757,t:1528139847269};\\\", \\\"{x:1342,y:758,t:1528139847278};\\\", \\\"{x:1342,y:759,t:1528139847310};\\\", \\\"{x:1342,y:761,t:1528139847333};\\\", \\\"{x:1343,y:762,t:1528139847350};\\\", \\\"{x:1343,y:763,t:1528139847380};\\\", \\\"{x:1344,y:764,t:1528139847598};\\\", \\\"{x:1345,y:764,t:1528139847605};\\\", \\\"{x:1346,y:764,t:1528139847653};\\\", \\\"{x:1346,y:763,t:1528139847661};\\\", \\\"{x:1347,y:762,t:1528139847685};\\\", \\\"{x:1348,y:761,t:1528139847693};\\\", \\\"{x:1348,y:760,t:1528139847709};\\\", \\\"{x:1348,y:759,t:1528139847725};\\\", \\\"{x:1348,y:758,t:1528139847741};\\\", \\\"{x:1348,y:757,t:1528139847756};\\\", \\\"{x:1348,y:755,t:1528139847770};\\\", \\\"{x:1348,y:753,t:1528139847787};\\\", \\\"{x:1348,y:750,t:1528139847806};\\\", \\\"{x:1348,y:749,t:1528139847821};\\\", \\\"{x:1348,y:747,t:1528139847837};\\\", \\\"{x:1348,y:746,t:1528139847853};\\\", \\\"{x:1348,y:743,t:1528139847871};\\\", \\\"{x:1348,y:741,t:1528139847893};\\\", \\\"{x:1348,y:739,t:1528139847904};\\\", \\\"{x:1348,y:736,t:1528139847920};\\\", \\\"{x:1348,y:733,t:1528139847938};\\\", \\\"{x:1348,y:731,t:1528139847954};\\\", \\\"{x:1348,y:727,t:1528139847970};\\\", \\\"{x:1347,y:725,t:1528139847986};\\\", \\\"{x:1347,y:723,t:1528139848006};\\\", \\\"{x:1347,y:721,t:1528139848021};\\\", \\\"{x:1347,y:718,t:1528139848037};\\\", \\\"{x:1347,y:717,t:1528139848054};\\\", \\\"{x:1347,y:715,t:1528139848070};\\\", \\\"{x:1347,y:714,t:1528139848109};\\\", \\\"{x:1347,y:712,t:1528139848125};\\\", \\\"{x:1347,y:711,t:1528139848157};\\\", \\\"{x:1347,y:710,t:1528139848169};\\\", \\\"{x:1346,y:710,t:1528139848187};\\\", \\\"{x:1345,y:709,t:1528139848206};\\\", \\\"{x:1343,y:709,t:1528139848229};\\\", \\\"{x:1341,y:709,t:1528139848237};\\\", \\\"{x:1337,y:708,t:1528139848253};\\\", \\\"{x:1319,y:706,t:1528139848270};\\\", \\\"{x:1295,y:697,t:1528139848286};\\\", \\\"{x:1249,y:686,t:1528139848302};\\\", \\\"{x:1165,y:664,t:1528139848320};\\\", \\\"{x:1077,y:639,t:1528139848336};\\\", \\\"{x:968,y:619,t:1528139848353};\\\", \\\"{x:855,y:592,t:1528139848370};\\\", \\\"{x:753,y:568,t:1528139848385};\\\", \\\"{x:672,y:542,t:1528139848397};\\\", \\\"{x:602,y:516,t:1528139848413};\\\", \\\"{x:563,y:507,t:1528139848429};\\\", \\\"{x:548,y:500,t:1528139848445};\\\", \\\"{x:545,y:498,t:1528139848462};\\\", \\\"{x:544,y:498,t:1528139848564};\\\", \\\"{x:542,y:498,t:1528139848579};\\\", \\\"{x:526,y:500,t:1528139848597};\\\", \\\"{x:516,y:505,t:1528139848613};\\\", \\\"{x:498,y:513,t:1528139848630};\\\", \\\"{x:493,y:516,t:1528139848647};\\\", \\\"{x:490,y:516,t:1528139848662};\\\", \\\"{x:486,y:517,t:1528139848680};\\\", \\\"{x:485,y:518,t:1528139848697};\\\", \\\"{x:485,y:519,t:1528139848713};\\\", \\\"{x:484,y:519,t:1528139848741};\\\", \\\"{x:483,y:519,t:1528139848749};\\\", \\\"{x:483,y:520,t:1528139848763};\\\", \\\"{x:480,y:522,t:1528139848780};\\\", \\\"{x:476,y:523,t:1528139848796};\\\", \\\"{x:465,y:527,t:1528139848814};\\\", \\\"{x:451,y:532,t:1528139848829};\\\", \\\"{x:426,y:538,t:1528139848845};\\\", \\\"{x:400,y:543,t:1528139848863};\\\", \\\"{x:371,y:543,t:1528139848880};\\\", \\\"{x:344,y:543,t:1528139848896};\\\", \\\"{x:328,y:542,t:1528139848913};\\\", \\\"{x:322,y:541,t:1528139848929};\\\", \\\"{x:321,y:541,t:1528139848946};\\\", \\\"{x:319,y:541,t:1528139848988};\\\", \\\"{x:316,y:540,t:1528139849004};\\\", \\\"{x:313,y:537,t:1528139849012};\\\", \\\"{x:312,y:537,t:1528139849029};\\\", \\\"{x:310,y:536,t:1528139849101};\\\", \\\"{x:285,y:538,t:1528139849113};\\\", \\\"{x:222,y:551,t:1528139849131};\\\", \\\"{x:179,y:559,t:1528139849146};\\\", \\\"{x:170,y:561,t:1528139849163};\\\", \\\"{x:169,y:561,t:1528139849245};\\\", \\\"{x:171,y:560,t:1528139849253};\\\", \\\"{x:174,y:558,t:1528139849262};\\\", \\\"{x:195,y:558,t:1528139849279};\\\", \\\"{x:224,y:563,t:1528139849296};\\\", \\\"{x:255,y:566,t:1528139849312};\\\", \\\"{x:282,y:570,t:1528139849330};\\\", \\\"{x:300,y:570,t:1528139849346};\\\", \\\"{x:318,y:571,t:1528139849363};\\\", \\\"{x:352,y:572,t:1528139849380};\\\", \\\"{x:374,y:574,t:1528139849397};\\\", \\\"{x:390,y:576,t:1528139849413};\\\", \\\"{x:411,y:576,t:1528139849430};\\\", \\\"{x:431,y:576,t:1528139849447};\\\", \\\"{x:446,y:576,t:1528139849463};\\\", \\\"{x:460,y:576,t:1528139849480};\\\", \\\"{x:474,y:577,t:1528139849496};\\\", \\\"{x:486,y:578,t:1528139849512};\\\", \\\"{x:504,y:580,t:1528139849531};\\\", \\\"{x:517,y:581,t:1528139849546};\\\", \\\"{x:536,y:581,t:1528139849563};\\\", \\\"{x:554,y:581,t:1528139849580};\\\", \\\"{x:563,y:581,t:1528139849597};\\\", \\\"{x:567,y:581,t:1528139849613};\\\", \\\"{x:568,y:581,t:1528139849630};\\\", \\\"{x:569,y:581,t:1528139849661};\\\", \\\"{x:570,y:581,t:1528139849676};\\\", \\\"{x:572,y:579,t:1528139849685};\\\", \\\"{x:574,y:576,t:1528139849697};\\\", \\\"{x:576,y:573,t:1528139849713};\\\", \\\"{x:582,y:564,t:1528139849730};\\\", \\\"{x:587,y:560,t:1528139849748};\\\", \\\"{x:591,y:559,t:1528139849763};\\\", \\\"{x:600,y:553,t:1528139849782};\\\", \\\"{x:603,y:552,t:1528139849797};\\\", \\\"{x:606,y:551,t:1528139849813};\\\", \\\"{x:607,y:551,t:1528139849830};\\\", \\\"{x:608,y:551,t:1528139849941};\\\", \\\"{x:610,y:551,t:1528139849997};\\\", \\\"{x:614,y:551,t:1528139850014};\\\", \\\"{x:618,y:552,t:1528139850031};\\\", \\\"{x:624,y:552,t:1528139850046};\\\", \\\"{x:635,y:553,t:1528139850064};\\\", \\\"{x:653,y:553,t:1528139850080};\\\", \\\"{x:666,y:554,t:1528139850097};\\\", \\\"{x:678,y:554,t:1528139850114};\\\", \\\"{x:689,y:554,t:1528139850130};\\\", \\\"{x:696,y:554,t:1528139850147};\\\", \\\"{x:709,y:553,t:1528139850163};\\\", \\\"{x:714,y:553,t:1528139850180};\\\", \\\"{x:725,y:551,t:1528139850197};\\\", \\\"{x:730,y:551,t:1528139850214};\\\", \\\"{x:737,y:549,t:1528139850230};\\\", \\\"{x:742,y:547,t:1528139850247};\\\", \\\"{x:749,y:543,t:1528139850264};\\\", \\\"{x:757,y:540,t:1528139850280};\\\", \\\"{x:764,y:539,t:1528139850297};\\\", \\\"{x:768,y:538,t:1528139850314};\\\", \\\"{x:771,y:536,t:1528139850331};\\\", \\\"{x:775,y:535,t:1528139850347};\\\", \\\"{x:782,y:532,t:1528139850365};\\\", \\\"{x:785,y:531,t:1528139850380};\\\", \\\"{x:786,y:531,t:1528139850398};\\\", \\\"{x:790,y:529,t:1528139850414};\\\", \\\"{x:793,y:528,t:1528139850430};\\\", \\\"{x:796,y:527,t:1528139850447};\\\", \\\"{x:800,y:525,t:1528139850464};\\\", \\\"{x:805,y:522,t:1528139850481};\\\", \\\"{x:808,y:520,t:1528139850497};\\\", \\\"{x:812,y:518,t:1528139850514};\\\", \\\"{x:815,y:517,t:1528139850531};\\\", \\\"{x:817,y:516,t:1528139850547};\\\", \\\"{x:823,y:512,t:1528139850564};\\\", \\\"{x:825,y:511,t:1528139850580};\\\", \\\"{x:828,y:509,t:1528139850597};\\\", \\\"{x:831,y:507,t:1528139850614};\\\", \\\"{x:833,y:505,t:1528139850631};\\\", \\\"{x:834,y:504,t:1528139850647};\\\", \\\"{x:835,y:502,t:1528139850664};\\\", \\\"{x:835,y:501,t:1528139850681};\\\", \\\"{x:838,y:502,t:1528139851108};\\\", \\\"{x:850,y:507,t:1528139851116};\\\", \\\"{x:863,y:514,t:1528139851132};\\\", \\\"{x:912,y:544,t:1528139851149};\\\", \\\"{x:966,y:571,t:1528139851165};\\\", \\\"{x:1022,y:598,t:1528139851182};\\\", \\\"{x:1089,y:631,t:1528139851198};\\\", \\\"{x:1148,y:662,t:1528139851214};\\\", \\\"{x:1217,y:693,t:1528139851231};\\\", \\\"{x:1273,y:720,t:1528139851249};\\\", \\\"{x:1312,y:737,t:1528139851264};\\\", \\\"{x:1336,y:753,t:1528139851282};\\\", \\\"{x:1355,y:764,t:1528139851299};\\\", \\\"{x:1360,y:767,t:1528139851315};\\\", \\\"{x:1361,y:767,t:1528139851332};\\\", \\\"{x:1363,y:768,t:1528139851349};\\\", \\\"{x:1363,y:771,t:1528139851582};\\\", \\\"{x:1346,y:782,t:1528139851599};\\\", \\\"{x:1327,y:793,t:1528139851615};\\\", \\\"{x:1314,y:806,t:1528139851631};\\\", \\\"{x:1301,y:815,t:1528139851649};\\\", \\\"{x:1292,y:824,t:1528139851665};\\\", \\\"{x:1283,y:830,t:1528139851681};\\\", \\\"{x:1278,y:834,t:1528139851699};\\\", \\\"{x:1273,y:839,t:1528139851715};\\\", \\\"{x:1271,y:844,t:1528139851731};\\\", \\\"{x:1266,y:848,t:1528139851748};\\\", \\\"{x:1259,y:852,t:1528139851765};\\\", \\\"{x:1254,y:853,t:1528139851781};\\\", \\\"{x:1252,y:854,t:1528139851799};\\\", \\\"{x:1251,y:855,t:1528139851829};\\\", \\\"{x:1249,y:856,t:1528139851870};\\\", \\\"{x:1244,y:857,t:1528139851882};\\\", \\\"{x:1239,y:860,t:1528139851898};\\\", \\\"{x:1236,y:861,t:1528139851915};\\\", \\\"{x:1234,y:862,t:1528139851933};\\\", \\\"{x:1234,y:866,t:1528139852062};\\\", \\\"{x:1233,y:868,t:1528139852069};\\\", \\\"{x:1233,y:874,t:1528139852083};\\\", \\\"{x:1233,y:893,t:1528139852099};\\\", \\\"{x:1233,y:922,t:1528139852115};\\\", \\\"{x:1235,y:955,t:1528139852133};\\\", \\\"{x:1236,y:970,t:1528139852149};\\\", \\\"{x:1236,y:973,t:1528139852165};\\\", \\\"{x:1235,y:972,t:1528139852222};\\\", \\\"{x:1235,y:967,t:1528139852234};\\\", \\\"{x:1235,y:964,t:1528139852249};\\\", \\\"{x:1236,y:961,t:1528139852266};\\\", \\\"{x:1237,y:952,t:1528139852283};\\\", \\\"{x:1240,y:945,t:1528139852299};\\\", \\\"{x:1242,y:937,t:1528139852316};\\\", \\\"{x:1247,y:922,t:1528139852333};\\\", \\\"{x:1254,y:906,t:1528139852349};\\\", \\\"{x:1262,y:888,t:1528139852366};\\\", \\\"{x:1266,y:873,t:1528139852383};\\\", \\\"{x:1270,y:860,t:1528139852400};\\\", \\\"{x:1272,y:851,t:1528139852416};\\\", \\\"{x:1275,y:846,t:1528139852433};\\\", \\\"{x:1277,y:837,t:1528139852449};\\\", \\\"{x:1280,y:828,t:1528139852466};\\\", \\\"{x:1282,y:815,t:1528139852483};\\\", \\\"{x:1283,y:804,t:1528139852500};\\\", \\\"{x:1283,y:801,t:1528139852516};\\\", \\\"{x:1284,y:797,t:1528139852533};\\\", \\\"{x:1285,y:793,t:1528139852549};\\\", \\\"{x:1285,y:790,t:1528139852566};\\\", \\\"{x:1285,y:786,t:1528139852583};\\\", \\\"{x:1285,y:784,t:1528139852600};\\\", \\\"{x:1285,y:782,t:1528139852616};\\\", \\\"{x:1287,y:779,t:1528139852633};\\\", \\\"{x:1287,y:778,t:1528139852650};\\\", \\\"{x:1288,y:777,t:1528139852666};\\\", \\\"{x:1291,y:774,t:1528139852683};\\\", \\\"{x:1291,y:773,t:1528139852700};\\\", \\\"{x:1293,y:770,t:1528139852716};\\\", \\\"{x:1296,y:765,t:1528139852734};\\\", \\\"{x:1298,y:762,t:1528139852749};\\\", \\\"{x:1299,y:759,t:1528139852766};\\\", \\\"{x:1301,y:757,t:1528139852783};\\\", \\\"{x:1302,y:755,t:1528139852800};\\\", \\\"{x:1302,y:754,t:1528139852817};\\\", \\\"{x:1305,y:752,t:1528139852832};\\\", \\\"{x:1305,y:751,t:1528139852869};\\\", \\\"{x:1306,y:749,t:1528139852894};\\\", \\\"{x:1307,y:748,t:1528139852901};\\\", \\\"{x:1308,y:747,t:1528139852918};\\\", \\\"{x:1309,y:746,t:1528139852933};\\\", \\\"{x:1310,y:744,t:1528139852949};\\\", \\\"{x:1312,y:742,t:1528139852967};\\\", \\\"{x:1312,y:741,t:1528139852983};\\\", \\\"{x:1314,y:739,t:1528139853000};\\\", \\\"{x:1314,y:738,t:1528139853021};\\\", \\\"{x:1315,y:736,t:1528139853053};\\\", \\\"{x:1316,y:736,t:1528139853077};\\\", \\\"{x:1316,y:734,t:1528139853085};\\\", \\\"{x:1317,y:734,t:1528139853100};\\\", \\\"{x:1318,y:733,t:1528139853117};\\\", \\\"{x:1319,y:732,t:1528139853133};\\\", \\\"{x:1319,y:731,t:1528139853166};\\\", \\\"{x:1320,y:731,t:1528139853173};\\\", \\\"{x:1320,y:730,t:1528139853189};\\\", \\\"{x:1321,y:730,t:1528139853213};\\\", \\\"{x:1322,y:728,t:1528139853221};\\\", \\\"{x:1322,y:727,t:1528139853246};\\\", \\\"{x:1323,y:726,t:1528139853261};\\\", \\\"{x:1324,y:725,t:1528139853285};\\\", \\\"{x:1325,y:725,t:1528139853300};\\\", \\\"{x:1326,y:722,t:1528139853317};\\\", \\\"{x:1326,y:721,t:1528139853334};\\\", \\\"{x:1327,y:719,t:1528139853357};\\\", \\\"{x:1327,y:718,t:1528139853367};\\\", \\\"{x:1328,y:716,t:1528139853384};\\\", \\\"{x:1330,y:714,t:1528139853400};\\\", \\\"{x:1331,y:709,t:1528139853417};\\\", \\\"{x:1334,y:703,t:1528139853434};\\\", \\\"{x:1338,y:696,t:1528139853450};\\\", \\\"{x:1342,y:690,t:1528139853468};\\\", \\\"{x:1343,y:688,t:1528139853484};\\\", \\\"{x:1345,y:685,t:1528139853499};\\\", \\\"{x:1346,y:683,t:1528139853517};\\\", \\\"{x:1347,y:682,t:1528139853533};\\\", \\\"{x:1347,y:681,t:1528139853550};\\\", \\\"{x:1349,y:679,t:1528139853567};\\\", \\\"{x:1349,y:676,t:1528139853584};\\\", \\\"{x:1351,y:674,t:1528139853600};\\\", \\\"{x:1352,y:672,t:1528139853617};\\\", \\\"{x:1353,y:668,t:1528139853634};\\\", \\\"{x:1355,y:665,t:1528139853650};\\\", \\\"{x:1356,y:661,t:1528139853667};\\\", \\\"{x:1358,y:657,t:1528139853684};\\\", \\\"{x:1360,y:652,t:1528139853701};\\\", \\\"{x:1362,y:649,t:1528139853718};\\\", \\\"{x:1362,y:647,t:1528139853733};\\\", \\\"{x:1366,y:643,t:1528139853750};\\\", \\\"{x:1366,y:639,t:1528139853767};\\\", \\\"{x:1367,y:638,t:1528139853789};\\\", \\\"{x:1367,y:637,t:1528139853801};\\\", \\\"{x:1368,y:635,t:1528139853817};\\\", \\\"{x:1369,y:633,t:1528139853834};\\\", \\\"{x:1370,y:631,t:1528139853851};\\\", \\\"{x:1371,y:629,t:1528139853867};\\\", \\\"{x:1373,y:626,t:1528139853884};\\\", \\\"{x:1374,y:624,t:1528139853901};\\\", \\\"{x:1375,y:622,t:1528139853917};\\\", \\\"{x:1376,y:621,t:1528139853934};\\\", \\\"{x:1377,y:619,t:1528139853957};\\\", \\\"{x:1378,y:619,t:1528139853967};\\\", \\\"{x:1380,y:617,t:1528139853984};\\\", \\\"{x:1382,y:615,t:1528139854001};\\\", \\\"{x:1383,y:612,t:1528139854018};\\\", \\\"{x:1386,y:609,t:1528139854034};\\\", \\\"{x:1388,y:607,t:1528139854051};\\\", \\\"{x:1390,y:606,t:1528139854067};\\\", \\\"{x:1390,y:605,t:1528139854083};\\\", \\\"{x:1392,y:602,t:1528139854101};\\\", \\\"{x:1393,y:602,t:1528139854117};\\\", \\\"{x:1394,y:600,t:1528139854134};\\\", \\\"{x:1394,y:599,t:1528139854157};\\\", \\\"{x:1395,y:599,t:1528139854168};\\\", \\\"{x:1396,y:597,t:1528139854184};\\\", \\\"{x:1397,y:596,t:1528139854201};\\\", \\\"{x:1397,y:595,t:1528139854237};\\\", \\\"{x:1398,y:594,t:1528139854251};\\\", \\\"{x:1398,y:593,t:1528139854268};\\\", \\\"{x:1400,y:592,t:1528139854284};\\\", \\\"{x:1401,y:590,t:1528139854301};\\\", \\\"{x:1403,y:588,t:1528139854317};\\\", \\\"{x:1403,y:587,t:1528139854334};\\\", \\\"{x:1404,y:587,t:1528139854365};\\\", \\\"{x:1404,y:586,t:1528139854406};\\\", \\\"{x:1405,y:586,t:1528139854454};\\\", \\\"{x:1405,y:585,t:1528139854526};\\\", \\\"{x:1406,y:585,t:1528139854565};\\\", \\\"{x:1406,y:584,t:1528139854581};\\\", \\\"{x:1406,y:583,t:1528139854589};\\\", \\\"{x:1407,y:582,t:1528139854613};\\\", \\\"{x:1408,y:581,t:1528139854661};\\\", \\\"{x:1409,y:580,t:1528139854668};\\\", \\\"{x:1409,y:579,t:1528139854684};\\\", \\\"{x:1409,y:578,t:1528139854700};\\\", \\\"{x:1410,y:576,t:1528139854717};\\\", \\\"{x:1411,y:575,t:1528139854797};\\\", \\\"{x:1412,y:574,t:1528139854854};\\\", \\\"{x:1413,y:573,t:1528139854958};\\\", \\\"{x:1414,y:572,t:1528139855013};\\\", \\\"{x:1414,y:571,t:1528139855021};\\\", \\\"{x:1415,y:571,t:1528139855045};\\\", \\\"{x:1416,y:570,t:1528139855061};\\\", \\\"{x:1417,y:569,t:1528139855350};\\\", \\\"{x:1418,y:569,t:1528139855406};\\\", \\\"{x:1418,y:568,t:1528139855419};\\\", \\\"{x:1419,y:567,t:1528139855434};\\\", \\\"{x:1420,y:566,t:1528139855453};\\\", \\\"{x:1420,y:565,t:1528139855838};\\\", \\\"{x:1419,y:565,t:1528139855958};\\\", \\\"{x:1417,y:565,t:1528139855986};\\\", \\\"{x:1416,y:565,t:1528139856286};\\\", \\\"{x:1415,y:565,t:1528139856349};\\\", \\\"{x:1414,y:565,t:1528139856381};\\\", \\\"{x:1404,y:568,t:1528139856844};\\\", \\\"{x:1395,y:571,t:1528139856852};\\\", \\\"{x:1366,y:577,t:1528139856870};\\\", \\\"{x:1277,y:577,t:1528139856885};\\\", \\\"{x:1164,y:577,t:1528139856902};\\\", \\\"{x:1050,y:577,t:1528139856920};\\\", \\\"{x:947,y:576,t:1528139856935};\\\", \\\"{x:857,y:557,t:1528139856952};\\\", \\\"{x:787,y:549,t:1528139856969};\\\", \\\"{x:731,y:541,t:1528139856985};\\\", \\\"{x:706,y:541,t:1528139857003};\\\", \\\"{x:694,y:540,t:1528139857018};\\\", \\\"{x:687,y:540,t:1528139857035};\\\", \\\"{x:683,y:540,t:1528139857052};\\\", \\\"{x:682,y:540,t:1528139857070};\\\", \\\"{x:678,y:540,t:1528139857086};\\\", \\\"{x:673,y:541,t:1528139857103};\\\", \\\"{x:666,y:542,t:1528139857120};\\\", \\\"{x:658,y:544,t:1528139857136};\\\", \\\"{x:645,y:545,t:1528139857152};\\\", \\\"{x:631,y:547,t:1528139857170};\\\", \\\"{x:617,y:547,t:1528139857185};\\\", \\\"{x:599,y:547,t:1528139857203};\\\", \\\"{x:583,y:547,t:1528139857220};\\\", \\\"{x:563,y:550,t:1528139857236};\\\", \\\"{x:556,y:551,t:1528139857252};\\\", \\\"{x:550,y:554,t:1528139857269};\\\", \\\"{x:543,y:555,t:1528139857287};\\\", \\\"{x:528,y:559,t:1528139857303};\\\", \\\"{x:518,y:560,t:1528139857320};\\\", \\\"{x:496,y:561,t:1528139857337};\\\", \\\"{x:471,y:565,t:1528139857353};\\\", \\\"{x:451,y:565,t:1528139857370};\\\", \\\"{x:422,y:565,t:1528139857387};\\\", \\\"{x:394,y:565,t:1528139857403};\\\", \\\"{x:366,y:565,t:1528139857420};\\\", \\\"{x:329,y:561,t:1528139857437};\\\", \\\"{x:311,y:558,t:1528139857453};\\\", \\\"{x:301,y:556,t:1528139857469};\\\", \\\"{x:297,y:554,t:1528139857487};\\\", \\\"{x:296,y:554,t:1528139857533};\\\", \\\"{x:294,y:554,t:1528139857540};\\\", \\\"{x:293,y:554,t:1528139857556};\\\", \\\"{x:292,y:554,t:1528139857573};\\\", \\\"{x:290,y:554,t:1528139857587};\\\", \\\"{x:278,y:556,t:1528139857605};\\\", \\\"{x:274,y:558,t:1528139857619};\\\", \\\"{x:257,y:564,t:1528139857636};\\\", \\\"{x:248,y:568,t:1528139857653};\\\", \\\"{x:240,y:572,t:1528139857669};\\\", \\\"{x:237,y:574,t:1528139857686};\\\", \\\"{x:236,y:575,t:1528139857708};\\\", \\\"{x:237,y:576,t:1528139857764};\\\", \\\"{x:240,y:576,t:1528139857772};\\\", \\\"{x:246,y:574,t:1528139857786};\\\", \\\"{x:277,y:564,t:1528139857805};\\\", \\\"{x:294,y:563,t:1528139857820};\\\", \\\"{x:353,y:562,t:1528139857837};\\\", \\\"{x:388,y:562,t:1528139857853};\\\", \\\"{x:429,y:562,t:1528139857870};\\\", \\\"{x:493,y:571,t:1528139857886};\\\", \\\"{x:569,y:585,t:1528139857904};\\\", \\\"{x:630,y:600,t:1528139857921};\\\", \\\"{x:708,y:611,t:1528139857937};\\\", \\\"{x:777,y:620,t:1528139857954};\\\", \\\"{x:841,y:628,t:1528139857969};\\\", \\\"{x:881,y:631,t:1528139857986};\\\", \\\"{x:913,y:636,t:1528139858005};\\\", \\\"{x:919,y:637,t:1528139858020};\\\", \\\"{x:921,y:637,t:1528139858036};\\\", \\\"{x:922,y:631,t:1528139858166};\\\", \\\"{x:922,y:617,t:1528139858187};\\\", \\\"{x:916,y:595,t:1528139858204};\\\", \\\"{x:910,y:579,t:1528139858220};\\\", \\\"{x:904,y:567,t:1528139858237};\\\", \\\"{x:902,y:562,t:1528139858254};\\\", \\\"{x:901,y:560,t:1528139858270};\\\", \\\"{x:900,y:559,t:1528139858365};\\\", \\\"{x:898,y:559,t:1528139858396};\\\", \\\"{x:896,y:558,t:1528139858405};\\\", \\\"{x:892,y:557,t:1528139858420};\\\", \\\"{x:887,y:556,t:1528139858437};\\\", \\\"{x:880,y:556,t:1528139858454};\\\", \\\"{x:872,y:554,t:1528139858471};\\\", \\\"{x:864,y:554,t:1528139858487};\\\", \\\"{x:852,y:554,t:1528139858503};\\\", \\\"{x:844,y:554,t:1528139858520};\\\", \\\"{x:839,y:554,t:1528139858537};\\\", \\\"{x:836,y:553,t:1528139858554};\\\", \\\"{x:835,y:553,t:1528139858571};\\\", \\\"{x:834,y:552,t:1528139858645};\\\", \\\"{x:834,y:551,t:1528139858670};\\\", \\\"{x:834,y:550,t:1528139858687};\\\", \\\"{x:834,y:546,t:1528139858703};\\\", \\\"{x:834,y:544,t:1528139858721};\\\", \\\"{x:834,y:543,t:1528139858737};\\\", \\\"{x:834,y:542,t:1528139858753};\\\", \\\"{x:834,y:541,t:1528139859269};\\\", \\\"{x:835,y:540,t:1528139859277};\\\", \\\"{x:837,y:539,t:1528139859288};\\\", \\\"{x:846,y:539,t:1528139859305};\\\", \\\"{x:868,y:539,t:1528139859321};\\\", \\\"{x:898,y:539,t:1528139859339};\\\", \\\"{x:943,y:539,t:1528139859355};\\\", \\\"{x:1018,y:539,t:1528139859373};\\\", \\\"{x:1095,y:544,t:1528139859389};\\\", \\\"{x:1205,y:553,t:1528139859405};\\\", \\\"{x:1283,y:562,t:1528139859422};\\\", \\\"{x:1339,y:570,t:1528139859439};\\\", \\\"{x:1388,y:578,t:1528139859455};\\\", \\\"{x:1425,y:585,t:1528139859473};\\\", \\\"{x:1460,y:585,t:1528139859489};\\\", \\\"{x:1479,y:586,t:1528139859505};\\\", \\\"{x:1495,y:586,t:1528139859522};\\\", \\\"{x:1499,y:586,t:1528139859538};\\\", \\\"{x:1500,y:586,t:1528139859565};\\\", \\\"{x:1499,y:586,t:1528139859676};\\\", \\\"{x:1496,y:588,t:1528139859688};\\\", \\\"{x:1492,y:588,t:1528139859704};\\\", \\\"{x:1473,y:586,t:1528139859721};\\\", \\\"{x:1443,y:581,t:1528139859739};\\\", \\\"{x:1398,y:574,t:1528139859754};\\\", \\\"{x:1367,y:568,t:1528139859771};\\\", \\\"{x:1352,y:564,t:1528139859788};\\\", \\\"{x:1349,y:563,t:1528139859805};\\\", \\\"{x:1348,y:563,t:1528139859822};\\\", \\\"{x:1348,y:561,t:1528139859894};\\\", \\\"{x:1349,y:560,t:1528139859909};\\\", \\\"{x:1350,y:559,t:1528139859921};\\\", \\\"{x:1354,y:558,t:1528139859939};\\\", \\\"{x:1361,y:555,t:1528139859955};\\\", \\\"{x:1370,y:552,t:1528139859971};\\\", \\\"{x:1379,y:547,t:1528139859988};\\\", \\\"{x:1382,y:547,t:1528139860004};\\\", \\\"{x:1384,y:545,t:1528139860022};\\\", \\\"{x:1386,y:545,t:1528139860286};\\\", \\\"{x:1387,y:545,t:1528139860293};\\\", \\\"{x:1388,y:545,t:1528139860306};\\\", \\\"{x:1390,y:546,t:1528139860322};\\\", \\\"{x:1394,y:552,t:1528139860339};\\\", \\\"{x:1399,y:557,t:1528139860357};\\\", \\\"{x:1404,y:563,t:1528139860372};\\\", \\\"{x:1411,y:571,t:1528139860390};\\\", \\\"{x:1417,y:576,t:1528139860406};\\\", \\\"{x:1422,y:581,t:1528139860423};\\\", \\\"{x:1430,y:591,t:1528139860439};\\\", \\\"{x:1439,y:599,t:1528139860456};\\\", \\\"{x:1448,y:607,t:1528139860473};\\\", \\\"{x:1457,y:614,t:1528139860489};\\\", \\\"{x:1465,y:620,t:1528139860506};\\\", \\\"{x:1473,y:625,t:1528139860523};\\\", \\\"{x:1480,y:633,t:1528139860539};\\\", \\\"{x:1489,y:643,t:1528139860556};\\\", \\\"{x:1502,y:658,t:1528139860573};\\\", \\\"{x:1512,y:671,t:1528139860589};\\\", \\\"{x:1523,y:681,t:1528139860606};\\\", \\\"{x:1527,y:687,t:1528139860623};\\\", \\\"{x:1532,y:694,t:1528139860639};\\\", \\\"{x:1538,y:701,t:1528139860656};\\\", \\\"{x:1544,y:708,t:1528139860673};\\\", \\\"{x:1551,y:714,t:1528139860689};\\\", \\\"{x:1554,y:721,t:1528139860706};\\\", \\\"{x:1560,y:729,t:1528139860723};\\\", \\\"{x:1565,y:736,t:1528139860740};\\\", \\\"{x:1570,y:740,t:1528139860757};\\\", \\\"{x:1577,y:745,t:1528139860774};\\\", \\\"{x:1581,y:752,t:1528139860789};\\\", \\\"{x:1587,y:757,t:1528139860806};\\\", \\\"{x:1587,y:758,t:1528139860823};\\\", \\\"{x:1587,y:759,t:1528139861085};\\\", \\\"{x:1586,y:761,t:1528139861117};\\\", \\\"{x:1585,y:762,t:1528139861133};\\\", \\\"{x:1582,y:765,t:1528139861142};\\\", \\\"{x:1581,y:766,t:1528139861157};\\\", \\\"{x:1574,y:773,t:1528139861173};\\\", \\\"{x:1572,y:778,t:1528139861190};\\\", \\\"{x:1570,y:783,t:1528139861206};\\\", \\\"{x:1567,y:788,t:1528139861223};\\\", \\\"{x:1565,y:792,t:1528139861240};\\\", \\\"{x:1560,y:799,t:1528139861256};\\\", \\\"{x:1559,y:801,t:1528139861273};\\\", \\\"{x:1556,y:804,t:1528139861290};\\\", \\\"{x:1553,y:809,t:1528139861306};\\\", \\\"{x:1547,y:812,t:1528139861323};\\\", \\\"{x:1542,y:812,t:1528139861341};\\\", \\\"{x:1535,y:813,t:1528139861356};\\\", \\\"{x:1521,y:816,t:1528139861373};\\\", \\\"{x:1515,y:816,t:1528139861390};\\\", \\\"{x:1509,y:816,t:1528139861407};\\\", \\\"{x:1508,y:816,t:1528139861424};\\\", \\\"{x:1507,y:816,t:1528139861440};\\\", \\\"{x:1506,y:816,t:1528139861460};\\\", \\\"{x:1503,y:817,t:1528139861501};\\\", \\\"{x:1501,y:819,t:1528139861509};\\\", \\\"{x:1498,y:821,t:1528139861523};\\\", \\\"{x:1493,y:825,t:1528139861541};\\\", \\\"{x:1490,y:828,t:1528139861558};\\\", \\\"{x:1489,y:828,t:1528139861573};\\\", \\\"{x:1489,y:829,t:1528139861597};\\\", \\\"{x:1489,y:830,t:1528139861629};\\\", \\\"{x:1487,y:831,t:1528139861641};\\\", \\\"{x:1486,y:832,t:1528139861658};\\\", \\\"{x:1486,y:833,t:1528139861675};\\\", \\\"{x:1485,y:834,t:1528139861691};\\\", \\\"{x:1484,y:834,t:1528139861797};\\\", \\\"{x:1483,y:834,t:1528139861813};\\\", \\\"{x:1482,y:832,t:1528139861828};\\\", \\\"{x:1480,y:831,t:1528139861840};\\\", \\\"{x:1480,y:830,t:1528139861857};\\\", \\\"{x:1480,y:828,t:1528139861874};\\\", \\\"{x:1478,y:825,t:1528139861890};\\\", \\\"{x:1476,y:823,t:1528139861908};\\\", \\\"{x:1476,y:821,t:1528139861925};\\\", \\\"{x:1475,y:820,t:1528139861940};\\\", \\\"{x:1475,y:819,t:1528139862013};\\\", \\\"{x:1475,y:818,t:1528139862029};\\\", \\\"{x:1475,y:817,t:1528139862040};\\\", \\\"{x:1475,y:816,t:1528139862057};\\\", \\\"{x:1474,y:814,t:1528139862074};\\\", \\\"{x:1471,y:810,t:1528139862092};\\\", \\\"{x:1469,y:806,t:1528139862107};\\\", \\\"{x:1464,y:798,t:1528139862125};\\\", \\\"{x:1460,y:793,t:1528139862141};\\\", \\\"{x:1450,y:779,t:1528139862157};\\\", \\\"{x:1441,y:769,t:1528139862174};\\\", \\\"{x:1437,y:761,t:1528139862191};\\\", \\\"{x:1433,y:754,t:1528139862207};\\\", \\\"{x:1428,y:748,t:1528139862224};\\\", \\\"{x:1426,y:745,t:1528139862242};\\\", \\\"{x:1423,y:738,t:1528139862257};\\\", \\\"{x:1420,y:733,t:1528139862275};\\\", \\\"{x:1416,y:728,t:1528139862291};\\\", \\\"{x:1413,y:725,t:1528139862307};\\\", \\\"{x:1404,y:713,t:1528139862325};\\\", \\\"{x:1399,y:707,t:1528139862342};\\\", \\\"{x:1395,y:699,t:1528139862357};\\\", \\\"{x:1389,y:690,t:1528139862374};\\\", \\\"{x:1386,y:682,t:1528139862391};\\\", \\\"{x:1385,y:678,t:1528139862407};\\\", \\\"{x:1383,y:675,t:1528139862424};\\\", \\\"{x:1384,y:678,t:1528139862548};\\\", \\\"{x:1390,y:685,t:1528139862558};\\\", \\\"{x:1396,y:693,t:1528139862574};\\\", \\\"{x:1400,y:702,t:1528139862591};\\\", \\\"{x:1408,y:715,t:1528139862608};\\\", \\\"{x:1418,y:727,t:1528139862623};\\\", \\\"{x:1425,y:737,t:1528139862640};\\\", \\\"{x:1429,y:743,t:1528139862657};\\\", \\\"{x:1433,y:749,t:1528139862675};\\\", \\\"{x:1437,y:754,t:1528139862691};\\\", \\\"{x:1441,y:761,t:1528139862708};\\\", \\\"{x:1448,y:769,t:1528139862724};\\\", \\\"{x:1453,y:778,t:1528139862741};\\\", \\\"{x:1457,y:784,t:1528139862758};\\\", \\\"{x:1459,y:789,t:1528139862774};\\\", \\\"{x:1463,y:795,t:1528139862791};\\\", \\\"{x:1466,y:801,t:1528139862809};\\\", \\\"{x:1471,y:807,t:1528139862824};\\\", \\\"{x:1474,y:816,t:1528139862841};\\\", \\\"{x:1477,y:820,t:1528139862858};\\\", \\\"{x:1479,y:825,t:1528139862875};\\\", \\\"{x:1484,y:833,t:1528139862891};\\\", \\\"{x:1490,y:842,t:1528139862909};\\\", \\\"{x:1491,y:845,t:1528139862925};\\\", \\\"{x:1496,y:851,t:1528139862941};\\\", \\\"{x:1499,y:857,t:1528139862958};\\\", \\\"{x:1503,y:864,t:1528139862976};\\\", \\\"{x:1508,y:871,t:1528139862992};\\\", \\\"{x:1512,y:878,t:1528139863008};\\\", \\\"{x:1516,y:886,t:1528139863025};\\\", \\\"{x:1520,y:895,t:1528139863042};\\\", \\\"{x:1527,y:905,t:1528139863058};\\\", \\\"{x:1534,y:917,t:1528139863075};\\\", \\\"{x:1540,y:926,t:1528139863092};\\\", \\\"{x:1544,y:932,t:1528139863108};\\\", \\\"{x:1546,y:937,t:1528139863124};\\\", \\\"{x:1549,y:942,t:1528139863141};\\\", \\\"{x:1549,y:944,t:1528139863158};\\\", \\\"{x:1549,y:945,t:1528139863176};\\\", \\\"{x:1549,y:946,t:1528139863206};\\\", \\\"{x:1549,y:947,t:1528139863213};\\\", \\\"{x:1551,y:949,t:1528139863225};\\\", \\\"{x:1552,y:950,t:1528139863252};\\\", \\\"{x:1553,y:951,t:1528139863268};\\\", \\\"{x:1554,y:952,t:1528139863292};\\\", \\\"{x:1555,y:953,t:1528139863324};\\\", \\\"{x:1557,y:959,t:1528139863341};\\\", \\\"{x:1558,y:963,t:1528139863358};\\\", \\\"{x:1559,y:965,t:1528139863375};\\\", \\\"{x:1560,y:969,t:1528139863392};\\\", \\\"{x:1560,y:967,t:1528139863566};\\\", \\\"{x:1560,y:966,t:1528139863575};\\\", \\\"{x:1556,y:958,t:1528139863593};\\\", \\\"{x:1552,y:950,t:1528139863608};\\\", \\\"{x:1548,y:944,t:1528139863625};\\\", \\\"{x:1539,y:928,t:1528139863642};\\\", \\\"{x:1534,y:919,t:1528139863658};\\\", \\\"{x:1529,y:909,t:1528139863675};\\\", \\\"{x:1524,y:899,t:1528139863692};\\\", \\\"{x:1518,y:889,t:1528139863708};\\\", \\\"{x:1515,y:882,t:1528139863726};\\\", \\\"{x:1514,y:877,t:1528139863742};\\\", \\\"{x:1511,y:869,t:1528139863758};\\\", \\\"{x:1509,y:855,t:1528139863775};\\\", \\\"{x:1503,y:838,t:1528139863792};\\\", \\\"{x:1500,y:822,t:1528139863809};\\\", \\\"{x:1496,y:806,t:1528139863825};\\\", \\\"{x:1491,y:791,t:1528139863842};\\\", \\\"{x:1490,y:775,t:1528139863860};\\\", \\\"{x:1488,y:751,t:1528139863875};\\\", \\\"{x:1484,y:734,t:1528139863892};\\\", \\\"{x:1483,y:724,t:1528139863909};\\\", \\\"{x:1483,y:718,t:1528139863925};\\\", \\\"{x:1483,y:714,t:1528139863943};\\\", \\\"{x:1483,y:709,t:1528139863960};\\\", \\\"{x:1483,y:705,t:1528139863975};\\\", \\\"{x:1483,y:699,t:1528139863992};\\\", \\\"{x:1480,y:695,t:1528139864010};\\\", \\\"{x:1479,y:691,t:1528139864026};\\\", \\\"{x:1478,y:690,t:1528139864042};\\\", \\\"{x:1478,y:688,t:1528139864060};\\\", \\\"{x:1476,y:686,t:1528139864075};\\\", \\\"{x:1475,y:683,t:1528139864093};\\\", \\\"{x:1471,y:677,t:1528139864109};\\\", \\\"{x:1470,y:676,t:1528139864126};\\\", \\\"{x:1469,y:675,t:1528139864142};\\\", \\\"{x:1469,y:674,t:1528139864160};\\\", \\\"{x:1468,y:673,t:1528139864176};\\\", \\\"{x:1468,y:672,t:1528139864238};\\\", \\\"{x:1467,y:671,t:1528139864261};\\\", \\\"{x:1467,y:670,t:1528139864277};\\\", \\\"{x:1466,y:668,t:1528139864293};\\\", \\\"{x:1466,y:667,t:1528139864309};\\\", \\\"{x:1464,y:665,t:1528139864327};\\\", \\\"{x:1463,y:664,t:1528139864343};\\\", \\\"{x:1463,y:662,t:1528139864360};\\\", \\\"{x:1462,y:661,t:1528139864376};\\\", \\\"{x:1462,y:660,t:1528139864397};\\\", \\\"{x:1460,y:659,t:1528139864412};\\\", \\\"{x:1460,y:657,t:1528139864427};\\\", \\\"{x:1458,y:654,t:1528139864442};\\\", \\\"{x:1457,y:653,t:1528139864459};\\\", \\\"{x:1455,y:652,t:1528139864476};\\\", \\\"{x:1454,y:650,t:1528139864492};\\\", \\\"{x:1451,y:648,t:1528139864509};\\\", \\\"{x:1447,y:646,t:1528139864527};\\\", \\\"{x:1445,y:644,t:1528139864543};\\\", \\\"{x:1440,y:641,t:1528139864559};\\\", \\\"{x:1439,y:640,t:1528139864577};\\\", \\\"{x:1435,y:638,t:1528139864593};\\\", \\\"{x:1433,y:637,t:1528139864609};\\\", \\\"{x:1430,y:636,t:1528139864626};\\\", \\\"{x:1429,y:636,t:1528139864644};\\\", \\\"{x:1428,y:636,t:1528139864658};\\\", \\\"{x:1427,y:634,t:1528139864676};\\\", \\\"{x:1425,y:634,t:1528139864692};\\\", \\\"{x:1425,y:633,t:1528139864716};\\\", \\\"{x:1423,y:633,t:1528139864748};\\\", \\\"{x:1423,y:632,t:1528139864759};\\\", \\\"{x:1422,y:632,t:1528139864788};\\\", \\\"{x:1421,y:631,t:1528139864812};\\\", \\\"{x:1420,y:630,t:1528139864828};\\\", \\\"{x:1419,y:630,t:1528139864876};\\\", \\\"{x:1418,y:629,t:1528139864893};\\\", \\\"{x:1417,y:628,t:1528139864908};\\\", \\\"{x:1416,y:627,t:1528139864925};\\\", \\\"{x:1415,y:626,t:1528139864943};\\\", \\\"{x:1414,y:625,t:1528139864959};\\\", \\\"{x:1413,y:624,t:1528139864976};\\\", \\\"{x:1413,y:623,t:1528139864993};\\\", \\\"{x:1410,y:619,t:1528139865010};\\\", \\\"{x:1410,y:618,t:1528139865026};\\\", \\\"{x:1409,y:616,t:1528139865043};\\\", \\\"{x:1409,y:614,t:1528139865060};\\\", \\\"{x:1407,y:613,t:1528139865085};\\\", \\\"{x:1406,y:612,t:1528139865109};\\\", \\\"{x:1405,y:611,t:1528139865133};\\\", \\\"{x:1404,y:610,t:1528139865165};\\\", \\\"{x:1403,y:608,t:1528139865197};\\\", \\\"{x:1402,y:608,t:1528139865221};\\\", \\\"{x:1401,y:608,t:1528139865230};\\\", \\\"{x:1401,y:607,t:1528139865243};\\\", \\\"{x:1400,y:606,t:1528139865261};\\\", \\\"{x:1399,y:605,t:1528139865277};\\\", \\\"{x:1398,y:604,t:1528139865373};\\\", \\\"{x:1397,y:603,t:1528139865389};\\\", \\\"{x:1397,y:602,t:1528139865397};\\\", \\\"{x:1396,y:602,t:1528139865410};\\\", \\\"{x:1396,y:601,t:1528139865427};\\\", \\\"{x:1395,y:600,t:1528139865444};\\\", \\\"{x:1394,y:599,t:1528139865469};\\\", \\\"{x:1394,y:598,t:1528139865485};\\\", \\\"{x:1394,y:597,t:1528139865526};\\\", \\\"{x:1394,y:596,t:1528139865541};\\\", \\\"{x:1393,y:594,t:1528139865549};\\\", \\\"{x:1393,y:593,t:1528139865606};\\\", \\\"{x:1392,y:592,t:1528139865628};\\\", \\\"{x:1391,y:591,t:1528139865652};\\\", \\\"{x:1390,y:590,t:1528139865668};\\\", \\\"{x:1389,y:590,t:1528139865692};\\\", \\\"{x:1388,y:589,t:1528139865724};\\\", \\\"{x:1388,y:588,t:1528139865732};\\\", \\\"{x:1388,y:586,t:1528139865756};\\\", \\\"{x:1388,y:584,t:1528139865764};\\\", \\\"{x:1388,y:580,t:1528139865777};\\\", \\\"{x:1390,y:577,t:1528139865793};\\\", \\\"{x:1392,y:572,t:1528139865810};\\\", \\\"{x:1395,y:570,t:1528139865827};\\\", \\\"{x:1399,y:567,t:1528139865843};\\\", \\\"{x:1403,y:566,t:1528139865860};\\\", \\\"{x:1405,y:564,t:1528139865876};\\\", \\\"{x:1408,y:563,t:1528139865894};\\\", \\\"{x:1409,y:562,t:1528139865910};\\\", \\\"{x:1410,y:562,t:1528139865927};\\\", \\\"{x:1412,y:562,t:1528139865964};\\\", \\\"{x:1414,y:562,t:1528139865976};\\\", \\\"{x:1416,y:562,t:1528139865994};\\\", \\\"{x:1418,y:562,t:1528139866010};\\\", \\\"{x:1419,y:562,t:1528139866027};\\\", \\\"{x:1422,y:564,t:1528139866045};\\\", \\\"{x:1427,y:573,t:1528139866061};\\\", \\\"{x:1438,y:587,t:1528139866077};\\\", \\\"{x:1443,y:594,t:1528139866094};\\\", \\\"{x:1449,y:602,t:1528139866110};\\\", \\\"{x:1456,y:610,t:1528139866127};\\\", \\\"{x:1457,y:613,t:1528139866144};\\\", \\\"{x:1458,y:615,t:1528139866161};\\\", \\\"{x:1459,y:616,t:1528139866178};\\\", \\\"{x:1458,y:616,t:1528139866325};\\\", \\\"{x:1456,y:611,t:1528139866333};\\\", \\\"{x:1454,y:608,t:1528139866344};\\\", \\\"{x:1450,y:602,t:1528139866362};\\\", \\\"{x:1442,y:589,t:1528139866377};\\\", \\\"{x:1435,y:582,t:1528139866394};\\\", \\\"{x:1427,y:573,t:1528139866412};\\\", \\\"{x:1417,y:567,t:1528139866427};\\\", \\\"{x:1410,y:563,t:1528139866445};\\\", \\\"{x:1407,y:560,t:1528139866462};\\\", \\\"{x:1406,y:559,t:1528139866478};\\\", \\\"{x:1405,y:558,t:1528139866495};\\\", \\\"{x:1409,y:563,t:1528139867526};\\\", \\\"{x:1416,y:567,t:1528139867546};\\\", \\\"{x:1422,y:573,t:1528139867564};\\\", \\\"{x:1427,y:576,t:1528139867579};\\\", \\\"{x:1429,y:578,t:1528139867596};\\\", \\\"{x:1430,y:579,t:1528139867613};\\\", \\\"{x:1431,y:579,t:1528139867678};\\\", \\\"{x:1431,y:580,t:1528139867696};\\\", \\\"{x:1432,y:582,t:1528139867712};\\\", \\\"{x:1434,y:583,t:1528139867728};\\\", \\\"{x:1435,y:585,t:1528139867745};\\\", \\\"{x:1437,y:587,t:1528139867762};\\\", \\\"{x:1438,y:588,t:1528139867779};\\\", \\\"{x:1439,y:591,t:1528139867796};\\\", \\\"{x:1441,y:595,t:1528139867813};\\\", \\\"{x:1442,y:596,t:1528139867829};\\\", \\\"{x:1443,y:599,t:1528139867845};\\\", \\\"{x:1444,y:601,t:1528139867863};\\\", \\\"{x:1446,y:603,t:1528139867880};\\\", \\\"{x:1446,y:604,t:1528139867895};\\\", \\\"{x:1447,y:606,t:1528139867925};\\\", \\\"{x:1447,y:607,t:1528139867949};\\\", \\\"{x:1447,y:608,t:1528139867962};\\\", \\\"{x:1448,y:608,t:1528139867980};\\\", \\\"{x:1448,y:609,t:1528139867996};\\\", \\\"{x:1448,y:610,t:1528139868085};\\\", \\\"{x:1447,y:611,t:1528139868286};\\\", \\\"{x:1441,y:611,t:1528139868297};\\\", \\\"{x:1437,y:611,t:1528139868313};\\\", \\\"{x:1434,y:611,t:1528139868329};\\\", \\\"{x:1434,y:613,t:1528139868717};\\\", \\\"{x:1433,y:613,t:1528139868730};\\\", \\\"{x:1433,y:614,t:1528139868747};\\\", \\\"{x:1433,y:615,t:1528139868829};\\\", \\\"{x:1425,y:615,t:1528139869765};\\\", \\\"{x:1368,y:615,t:1528139869781};\\\", \\\"{x:1261,y:608,t:1528139869797};\\\", \\\"{x:1149,y:588,t:1528139869814};\\\", \\\"{x:1021,y:567,t:1528139869831};\\\", \\\"{x:882,y:542,t:1528139869849};\\\", \\\"{x:747,y:510,t:1528139869865};\\\", \\\"{x:626,y:476,t:1528139869881};\\\", \\\"{x:535,y:453,t:1528139869897};\\\", \\\"{x:490,y:441,t:1528139869914};\\\", \\\"{x:476,y:438,t:1528139869931};\\\", \\\"{x:474,y:438,t:1528139869947};\\\", \\\"{x:473,y:438,t:1528139870013};\\\", \\\"{x:471,y:438,t:1528139870028};\\\", \\\"{x:468,y:438,t:1528139870037};\\\", \\\"{x:463,y:440,t:1528139870047};\\\", \\\"{x:440,y:445,t:1528139870065};\\\", \\\"{x:409,y:450,t:1528139870080};\\\", \\\"{x:353,y:460,t:1528139870097};\\\", \\\"{x:299,y:468,t:1528139870115};\\\", \\\"{x:257,y:475,t:1528139870130};\\\", \\\"{x:230,y:482,t:1528139870148};\\\", \\\"{x:201,y:486,t:1528139870164};\\\", \\\"{x:184,y:489,t:1528139870182};\\\", \\\"{x:176,y:490,t:1528139870198};\\\", \\\"{x:173,y:491,t:1528139870214};\\\", \\\"{x:170,y:492,t:1528139870236};\\\", \\\"{x:170,y:493,t:1528139870246};\\\", \\\"{x:168,y:494,t:1528139870262};\\\", \\\"{x:167,y:494,t:1528139870279};\\\", \\\"{x:164,y:497,t:1528139870296};\\\", \\\"{x:160,y:499,t:1528139870312};\\\", \\\"{x:156,y:501,t:1528139870329};\\\", \\\"{x:156,y:502,t:1528139870348};\\\", \\\"{x:155,y:502,t:1528139870364};\\\", \\\"{x:155,y:503,t:1528139870379};\\\", \\\"{x:153,y:507,t:1528139870396};\\\", \\\"{x:152,y:510,t:1528139870413};\\\", \\\"{x:152,y:514,t:1528139870429};\\\", \\\"{x:151,y:519,t:1528139870447};\\\", \\\"{x:151,y:525,t:1528139870463};\\\", \\\"{x:151,y:528,t:1528139870480};\\\", \\\"{x:151,y:532,t:1528139870497};\\\", \\\"{x:151,y:535,t:1528139870513};\\\", \\\"{x:155,y:540,t:1528139870530};\\\", \\\"{x:160,y:546,t:1528139870546};\\\", \\\"{x:163,y:552,t:1528139870563};\\\", \\\"{x:166,y:559,t:1528139870581};\\\", \\\"{x:169,y:565,t:1528139870597};\\\", \\\"{x:169,y:567,t:1528139870613};\\\", \\\"{x:170,y:572,t:1528139870630};\\\", \\\"{x:170,y:576,t:1528139870647};\\\", \\\"{x:170,y:581,t:1528139870663};\\\", \\\"{x:170,y:583,t:1528139870680};\\\", \\\"{x:170,y:589,t:1528139870697};\\\", \\\"{x:170,y:593,t:1528139870713};\\\", \\\"{x:170,y:594,t:1528139870732};\\\", \\\"{x:170,y:595,t:1528139870772};\\\", \\\"{x:169,y:594,t:1528139870828};\\\", \\\"{x:167,y:592,t:1528139870837};\\\", \\\"{x:166,y:588,t:1528139870848};\\\", \\\"{x:164,y:585,t:1528139870864};\\\", \\\"{x:162,y:581,t:1528139870879};\\\", \\\"{x:161,y:580,t:1528139870897};\\\", \\\"{x:165,y:577,t:1528139872253};\\\", \\\"{x:172,y:575,t:1528139872266};\\\", \\\"{x:197,y:571,t:1528139872282};\\\", \\\"{x:224,y:570,t:1528139872298};\\\", \\\"{x:258,y:570,t:1528139872315};\\\", \\\"{x:311,y:570,t:1528139872331};\\\", \\\"{x:411,y:570,t:1528139872348};\\\", \\\"{x:483,y:570,t:1528139872366};\\\", \\\"{x:565,y:570,t:1528139872382};\\\", \\\"{x:614,y:575,t:1528139872398};\\\", \\\"{x:644,y:580,t:1528139872415};\\\", \\\"{x:668,y:581,t:1528139872430};\\\", \\\"{x:685,y:581,t:1528139872448};\\\", \\\"{x:693,y:582,t:1528139872465};\\\", \\\"{x:697,y:582,t:1528139872481};\\\", \\\"{x:701,y:582,t:1528139872498};\\\", \\\"{x:705,y:582,t:1528139872515};\\\", \\\"{x:706,y:582,t:1528139872531};\\\", \\\"{x:708,y:582,t:1528139872548};\\\", \\\"{x:709,y:582,t:1528139872565};\\\", \\\"{x:710,y:582,t:1528139872582};\\\", \\\"{x:712,y:581,t:1528139872605};\\\", \\\"{x:715,y:580,t:1528139872615};\\\", \\\"{x:721,y:577,t:1528139872633};\\\", \\\"{x:727,y:576,t:1528139872650};\\\", \\\"{x:736,y:573,t:1528139872665};\\\", \\\"{x:747,y:571,t:1528139872681};\\\", \\\"{x:762,y:570,t:1528139872698};\\\", \\\"{x:773,y:567,t:1528139872715};\\\", \\\"{x:791,y:567,t:1528139872732};\\\", \\\"{x:804,y:568,t:1528139872748};\\\", \\\"{x:816,y:571,t:1528139872765};\\\", \\\"{x:826,y:572,t:1528139872783};\\\", \\\"{x:829,y:574,t:1528139872798};\\\", \\\"{x:831,y:574,t:1528139872815};\\\", \\\"{x:832,y:574,t:1528139872877};\\\", \\\"{x:832,y:575,t:1528139872908};\\\", \\\"{x:832,y:576,t:1528139872940};\\\", \\\"{x:826,y:579,t:1528139874581};\\\", \\\"{x:813,y:579,t:1528139874590};\\\", \\\"{x:805,y:579,t:1528139874600};\\\", \\\"{x:778,y:579,t:1528139874616};\\\", \\\"{x:725,y:579,t:1528139874633};\\\", \\\"{x:681,y:577,t:1528139874650};\\\", \\\"{x:652,y:570,t:1528139874667};\\\", \\\"{x:626,y:565,t:1528139874683};\\\", \\\"{x:593,y:558,t:1528139874700};\\\", \\\"{x:584,y:556,t:1528139874716};\\\", \\\"{x:581,y:554,t:1528139874734};\\\", \\\"{x:578,y:554,t:1528139874750};\\\", \\\"{x:575,y:554,t:1528139874767};\\\", \\\"{x:572,y:554,t:1528139874784};\\\", \\\"{x:567,y:554,t:1528139874800};\\\", \\\"{x:556,y:554,t:1528139874817};\\\", \\\"{x:542,y:552,t:1528139874833};\\\", \\\"{x:516,y:550,t:1528139874850};\\\", \\\"{x:488,y:548,t:1528139874869};\\\", \\\"{x:462,y:542,t:1528139874883};\\\", \\\"{x:416,y:534,t:1528139874901};\\\", \\\"{x:395,y:529,t:1528139874917};\\\", \\\"{x:377,y:526,t:1528139874933};\\\", \\\"{x:362,y:524,t:1528139874951};\\\", \\\"{x:353,y:522,t:1528139874967};\\\", \\\"{x:346,y:522,t:1528139874983};\\\", \\\"{x:343,y:522,t:1528139875000};\\\", \\\"{x:342,y:522,t:1528139875017};\\\", \\\"{x:340,y:522,t:1528139875034};\\\", \\\"{x:339,y:522,t:1528139875050};\\\", \\\"{x:334,y:522,t:1528139875067};\\\", \\\"{x:324,y:523,t:1528139875084};\\\", \\\"{x:320,y:524,t:1528139875100};\\\", \\\"{x:317,y:525,t:1528139875118};\\\", \\\"{x:313,y:527,t:1528139875135};\\\", \\\"{x:312,y:528,t:1528139875189};\\\", \\\"{x:311,y:530,t:1528139875205};\\\", \\\"{x:311,y:533,t:1528139875218};\\\", \\\"{x:309,y:536,t:1528139875234};\\\", \\\"{x:307,y:542,t:1528139875251};\\\", \\\"{x:306,y:545,t:1528139875267};\\\", \\\"{x:303,y:550,t:1528139875285};\\\", \\\"{x:301,y:553,t:1528139875300};\\\", \\\"{x:301,y:556,t:1528139875318};\\\", \\\"{x:301,y:559,t:1528139875335};\\\", \\\"{x:301,y:562,t:1528139875351};\\\", \\\"{x:301,y:563,t:1528139875368};\\\", \\\"{x:301,y:565,t:1528139875384};\\\", \\\"{x:301,y:566,t:1528139875420};\\\", \\\"{x:301,y:567,t:1528139875460};\\\", \\\"{x:302,y:568,t:1528139875477};\\\", \\\"{x:307,y:569,t:1528139875485};\\\", \\\"{x:319,y:573,t:1528139875501};\\\", \\\"{x:333,y:576,t:1528139875518};\\\", \\\"{x:355,y:581,t:1528139875534};\\\", \\\"{x:380,y:585,t:1528139875551};\\\", \\\"{x:407,y:591,t:1528139875567};\\\", \\\"{x:437,y:596,t:1528139875585};\\\", \\\"{x:466,y:597,t:1528139875600};\\\", \\\"{x:495,y:598,t:1528139875617};\\\", \\\"{x:511,y:598,t:1528139875634};\\\", \\\"{x:523,y:597,t:1528139875651};\\\", \\\"{x:527,y:595,t:1528139875667};\\\", \\\"{x:529,y:595,t:1528139875684};\\\", \\\"{x:530,y:594,t:1528139875701};\\\", \\\"{x:532,y:592,t:1528139875717};\\\", \\\"{x:537,y:591,t:1528139875735};\\\", \\\"{x:541,y:588,t:1528139875751};\\\", \\\"{x:547,y:584,t:1528139875767};\\\", \\\"{x:552,y:582,t:1528139875784};\\\", \\\"{x:560,y:577,t:1528139875801};\\\", \\\"{x:568,y:573,t:1528139875818};\\\", \\\"{x:572,y:569,t:1528139875835};\\\", \\\"{x:576,y:568,t:1528139875852};\\\", \\\"{x:581,y:568,t:1528139875868};\\\", \\\"{x:587,y:568,t:1528139875885};\\\", \\\"{x:593,y:568,t:1528139875901};\\\", \\\"{x:598,y:571,t:1528139875918};\\\", \\\"{x:607,y:581,t:1528139875935};\\\", \\\"{x:612,y:595,t:1528139875952};\\\", \\\"{x:619,y:608,t:1528139875967};\\\", \\\"{x:626,y:622,t:1528139875984};\\\", \\\"{x:629,y:629,t:1528139876001};\\\", \\\"{x:631,y:633,t:1528139876018};\\\", \\\"{x:628,y:633,t:1528139876229};\\\", \\\"{x:626,y:631,t:1528139876238};\\\", \\\"{x:625,y:627,t:1528139876251};\\\", \\\"{x:623,y:625,t:1528139876269};\\\", \\\"{x:622,y:623,t:1528139876284};\\\", \\\"{x:621,y:623,t:1528139876324};\\\", \\\"{x:619,y:622,t:1528139876421};\\\", \\\"{x:618,y:621,t:1528139876629};\\\", \\\"{x:617,y:621,t:1528139877220};\\\", \\\"{x:610,y:621,t:1528139877236};\\\", \\\"{x:565,y:624,t:1528139877252};\\\", \\\"{x:520,y:625,t:1528139877268};\\\", \\\"{x:472,y:625,t:1528139877286};\\\", \\\"{x:430,y:625,t:1528139877302};\\\", \\\"{x:377,y:625,t:1528139877319};\\\", \\\"{x:335,y:625,t:1528139877336};\\\", \\\"{x:297,y:625,t:1528139877352};\\\", \\\"{x:277,y:625,t:1528139877368};\\\", \\\"{x:262,y:625,t:1528139877386};\\\", \\\"{x:260,y:625,t:1528139877402};\\\", \\\"{x:258,y:625,t:1528139877492};\\\", \\\"{x:256,y:625,t:1528139877516};\\\", \\\"{x:254,y:625,t:1528139877557};\\\", \\\"{x:254,y:624,t:1528139877572};\\\", \\\"{x:253,y:623,t:1528139877586};\\\", \\\"{x:253,y:622,t:1528139877602};\\\", \\\"{x:253,y:616,t:1528139877620};\\\", \\\"{x:253,y:611,t:1528139877635};\\\", \\\"{x:252,y:602,t:1528139877652};\\\", \\\"{x:252,y:593,t:1528139877671};\\\", \\\"{x:252,y:587,t:1528139877686};\\\", \\\"{x:252,y:579,t:1528139877702};\\\", \\\"{x:252,y:572,t:1528139877720};\\\", \\\"{x:252,y:567,t:1528139877736};\\\", \\\"{x:250,y:563,t:1528139877752};\\\", \\\"{x:248,y:562,t:1528139877771};\\\", \\\"{x:248,y:561,t:1528139877786};\\\", \\\"{x:247,y:560,t:1528139877846};\\\", \\\"{x:247,y:559,t:1528139877861};\\\", \\\"{x:249,y:557,t:1528139877870};\\\", \\\"{x:261,y:554,t:1528139877888};\\\", \\\"{x:278,y:553,t:1528139877902};\\\", \\\"{x:298,y:553,t:1528139877920};\\\", \\\"{x:324,y:553,t:1528139877936};\\\", \\\"{x:349,y:553,t:1528139877953};\\\", \\\"{x:367,y:554,t:1528139877969};\\\", \\\"{x:386,y:559,t:1528139877987};\\\", \\\"{x:402,y:565,t:1528139878003};\\\", \\\"{x:417,y:572,t:1528139878020};\\\", \\\"{x:445,y:583,t:1528139878036};\\\", \\\"{x:462,y:591,t:1528139878052};\\\", \\\"{x:470,y:596,t:1528139878070};\\\", \\\"{x:479,y:599,t:1528139878086};\\\", \\\"{x:487,y:606,t:1528139878102};\\\", \\\"{x:495,y:611,t:1528139878119};\\\", \\\"{x:499,y:614,t:1528139878137};\\\", \\\"{x:502,y:618,t:1528139878153};\\\", \\\"{x:503,y:619,t:1528139878169};\\\", \\\"{x:504,y:619,t:1528139878204};\\\", \\\"{x:504,y:620,t:1528139878219};\\\", \\\"{x:506,y:620,t:1528139878253};\\\", \\\"{x:510,y:619,t:1528139878269};\\\", \\\"{x:517,y:612,t:1528139878286};\\\", \\\"{x:527,y:608,t:1528139878302};\\\", \\\"{x:541,y:601,t:1528139878319};\\\", \\\"{x:559,y:594,t:1528139878337};\\\", \\\"{x:576,y:588,t:1528139878355};\\\", \\\"{x:593,y:583,t:1528139878370};\\\", \\\"{x:607,y:579,t:1528139878387};\\\", \\\"{x:625,y:576,t:1528139878403};\\\", \\\"{x:639,y:574,t:1528139878419};\\\", \\\"{x:651,y:573,t:1528139878437};\\\", \\\"{x:656,y:571,t:1528139878454};\\\", \\\"{x:659,y:571,t:1528139878470};\\\", \\\"{x:660,y:570,t:1528139878525};\\\", \\\"{x:660,y:571,t:1528139878628};\\\", \\\"{x:663,y:571,t:1528139878701};\\\", \\\"{x:670,y:571,t:1528139878708};\\\", \\\"{x:676,y:571,t:1528139878719};\\\", \\\"{x:686,y:570,t:1528139878737};\\\", \\\"{x:697,y:569,t:1528139878754};\\\", \\\"{x:707,y:568,t:1528139878771};\\\", \\\"{x:721,y:568,t:1528139878786};\\\", \\\"{x:735,y:568,t:1528139878806};\\\", \\\"{x:744,y:568,t:1528139878820};\\\", \\\"{x:753,y:569,t:1528139878836};\\\", \\\"{x:762,y:572,t:1528139878853};\\\", \\\"{x:766,y:574,t:1528139878870};\\\", \\\"{x:770,y:575,t:1528139878886};\\\", \\\"{x:773,y:576,t:1528139878904};\\\", \\\"{x:775,y:577,t:1528139878921};\\\", \\\"{x:776,y:577,t:1528139878940};\\\", \\\"{x:776,y:578,t:1528139878953};\\\", \\\"{x:777,y:578,t:1528139878970};\\\", \\\"{x:779,y:578,t:1528139878986};\\\", \\\"{x:782,y:582,t:1528139879004};\\\", \\\"{x:784,y:587,t:1528139879020};\\\", \\\"{x:787,y:593,t:1528139879037};\\\", \\\"{x:791,y:602,t:1528139879055};\\\", \\\"{x:795,y:606,t:1528139879070};\\\", \\\"{x:796,y:607,t:1528139879086};\\\", \\\"{x:798,y:608,t:1528139879103};\\\", \\\"{x:798,y:609,t:1528139879120};\\\", \\\"{x:799,y:610,t:1528139879148};\\\", \\\"{x:800,y:611,t:1528139879156};\\\", \\\"{x:801,y:611,t:1528139879171};\\\", \\\"{x:804,y:613,t:1528139879187};\\\", \\\"{x:806,y:613,t:1528139879203};\\\", \\\"{x:809,y:613,t:1528139879220};\\\", \\\"{x:811,y:613,t:1528139879238};\\\", \\\"{x:812,y:614,t:1528139879254};\\\", \\\"{x:819,y:616,t:1528139879270};\\\", \\\"{x:828,y:618,t:1528139879288};\\\", \\\"{x:835,y:620,t:1528139879303};\\\", \\\"{x:837,y:622,t:1528139879320};\\\", \\\"{x:838,y:622,t:1528139879337};\\\", \\\"{x:839,y:622,t:1528139879353};\\\", \\\"{x:830,y:622,t:1528139881996};\\\", \\\"{x:817,y:620,t:1528139882006};\\\", \\\"{x:788,y:615,t:1528139882022};\\\", \\\"{x:746,y:604,t:1528139882040};\\\", \\\"{x:696,y:590,t:1528139882057};\\\", \\\"{x:641,y:575,t:1528139882073};\\\", \\\"{x:596,y:563,t:1528139882090};\\\", \\\"{x:559,y:553,t:1528139882107};\\\", \\\"{x:524,y:545,t:1528139882123};\\\", \\\"{x:500,y:538,t:1528139882140};\\\", \\\"{x:480,y:533,t:1528139882156};\\\", \\\"{x:477,y:533,t:1528139882173};\\\", \\\"{x:475,y:533,t:1528139882190};\\\", \\\"{x:474,y:533,t:1528139882237};\\\", \\\"{x:472,y:533,t:1528139882285};\\\", \\\"{x:471,y:533,t:1528139882301};\\\", \\\"{x:467,y:533,t:1528139882308};\\\", \\\"{x:465,y:534,t:1528139882323};\\\", \\\"{x:461,y:536,t:1528139882340};\\\", \\\"{x:452,y:540,t:1528139882357};\\\", \\\"{x:445,y:543,t:1528139882372};\\\", \\\"{x:437,y:547,t:1528139882390};\\\", \\\"{x:427,y:551,t:1528139882407};\\\", \\\"{x:420,y:554,t:1528139882423};\\\", \\\"{x:414,y:556,t:1528139882441};\\\", \\\"{x:410,y:558,t:1528139882457};\\\", \\\"{x:408,y:560,t:1528139882473};\\\", \\\"{x:407,y:560,t:1528139882490};\\\", \\\"{x:406,y:561,t:1528139882508};\\\", \\\"{x:404,y:563,t:1528139882524};\\\", \\\"{x:400,y:570,t:1528139882540};\\\", \\\"{x:397,y:575,t:1528139882556};\\\", \\\"{x:394,y:584,t:1528139882573};\\\", \\\"{x:387,y:597,t:1528139882590};\\\", \\\"{x:384,y:607,t:1528139882607};\\\", \\\"{x:382,y:612,t:1528139882623};\\\", \\\"{x:380,y:616,t:1528139882639};\\\", \\\"{x:379,y:619,t:1528139882657};\\\", \\\"{x:377,y:621,t:1528139882673};\\\", \\\"{x:376,y:623,t:1528139882691};\\\", \\\"{x:375,y:623,t:1528139882707};\\\", \\\"{x:374,y:624,t:1528139882733};\\\", \\\"{x:371,y:624,t:1528139882748};\\\", \\\"{x:369,y:624,t:1528139882757};\\\", \\\"{x:362,y:624,t:1528139882774};\\\", \\\"{x:352,y:622,t:1528139882789};\\\", \\\"{x:340,y:621,t:1528139882807};\\\", \\\"{x:326,y:617,t:1528139882824};\\\", \\\"{x:305,y:615,t:1528139882841};\\\", \\\"{x:288,y:612,t:1528139882857};\\\", \\\"{x:272,y:611,t:1528139882874};\\\", \\\"{x:262,y:609,t:1528139882890};\\\", \\\"{x:254,y:609,t:1528139882906};\\\", \\\"{x:251,y:607,t:1528139882924};\\\", \\\"{x:249,y:607,t:1528139882939};\\\", \\\"{x:246,y:607,t:1528139882972};\\\", \\\"{x:244,y:608,t:1528139883013};\\\", \\\"{x:243,y:608,t:1528139883023};\\\", \\\"{x:240,y:609,t:1528139883039};\\\", \\\"{x:239,y:610,t:1528139883057};\\\", \\\"{x:236,y:612,t:1528139883074};\\\", \\\"{x:231,y:615,t:1528139883090};\\\", \\\"{x:228,y:616,t:1528139883107};\\\", \\\"{x:227,y:618,t:1528139883124};\\\", \\\"{x:226,y:618,t:1528139883140};\\\", \\\"{x:226,y:619,t:1528139883325};\\\", \\\"{x:224,y:627,t:1528139883340};\\\", \\\"{x:222,y:633,t:1528139883358};\\\", \\\"{x:217,y:639,t:1528139883374};\\\", \\\"{x:211,y:644,t:1528139883391};\\\", \\\"{x:199,y:651,t:1528139883408};\\\", \\\"{x:189,y:654,t:1528139883423};\\\", \\\"{x:181,y:657,t:1528139883440};\\\", \\\"{x:174,y:658,t:1528139883457};\\\", \\\"{x:167,y:659,t:1528139883474};\\\", \\\"{x:162,y:660,t:1528139883490};\\\", \\\"{x:161,y:661,t:1528139883507};\\\", \\\"{x:159,y:661,t:1528139883524};\\\", \\\"{x:158,y:661,t:1528139883669};\\\", \\\"{x:158,y:660,t:1528139883692};\\\", \\\"{x:158,y:659,t:1528139883781};\\\", \\\"{x:159,y:657,t:1528139884989};\\\", \\\"{x:160,y:653,t:1528139884997};\\\", \\\"{x:162,y:652,t:1528139885009};\\\", \\\"{x:167,y:646,t:1528139885025};\\\", \\\"{x:170,y:642,t:1528139885043};\\\", \\\"{x:174,y:640,t:1528139885060};\\\", \\\"{x:175,y:639,t:1528139885074};\\\", \\\"{x:179,y:636,t:1528139885092};\\\", \\\"{x:180,y:635,t:1528139885108};\\\", \\\"{x:181,y:633,t:1528139885124};\\\", \\\"{x:185,y:629,t:1528139885142};\\\", \\\"{x:189,y:626,t:1528139885159};\\\", \\\"{x:191,y:625,t:1528139885175};\\\", \\\"{x:195,y:621,t:1528139885197};\\\", \\\"{x:197,y:619,t:1528139885208};\\\", \\\"{x:199,y:616,t:1528139885225};\\\", \\\"{x:203,y:611,t:1528139885242};\\\", \\\"{x:205,y:607,t:1528139885259};\\\", \\\"{x:208,y:604,t:1528139885275};\\\", \\\"{x:208,y:602,t:1528139885291};\\\", \\\"{x:209,y:600,t:1528139885308};\\\", \\\"{x:210,y:598,t:1528139885325};\\\", \\\"{x:210,y:596,t:1528139885348};\\\", \\\"{x:210,y:595,t:1528139885380};\\\", \\\"{x:210,y:593,t:1528139885397};\\\", \\\"{x:210,y:592,t:1528139885408};\\\", \\\"{x:211,y:590,t:1528139885425};\\\", \\\"{x:211,y:587,t:1528139885443};\\\", \\\"{x:212,y:583,t:1528139885458};\\\", \\\"{x:212,y:580,t:1528139885476};\\\", \\\"{x:212,y:576,t:1528139885492};\\\", \\\"{x:212,y:569,t:1528139885509};\\\", \\\"{x:212,y:563,t:1528139885525};\\\", \\\"{x:212,y:559,t:1528139885544};\\\", \\\"{x:212,y:557,t:1528139885559};\\\", \\\"{x:212,y:556,t:1528139885577};\\\", \\\"{x:212,y:555,t:1528139885606};\\\", \\\"{x:214,y:553,t:1528139885611};\\\", \\\"{x:217,y:550,t:1528139885627};\\\", \\\"{x:220,y:548,t:1528139885643};\\\", \\\"{x:232,y:543,t:1528139885659};\\\", \\\"{x:254,y:532,t:1528139885676};\\\", \\\"{x:266,y:527,t:1528139885692};\\\", \\\"{x:280,y:520,t:1528139885709};\\\", \\\"{x:290,y:517,t:1528139885726};\\\", \\\"{x:300,y:515,t:1528139885742};\\\", \\\"{x:324,y:516,t:1528139885759};\\\", \\\"{x:350,y:522,t:1528139885777};\\\", \\\"{x:378,y:524,t:1528139885793};\\\", \\\"{x:398,y:528,t:1528139885810};\\\", \\\"{x:412,y:531,t:1528139885826};\\\", \\\"{x:420,y:533,t:1528139885843};\\\", \\\"{x:432,y:538,t:1528139885859};\\\", \\\"{x:451,y:544,t:1528139885876};\\\", \\\"{x:458,y:547,t:1528139885892};\\\", \\\"{x:459,y:548,t:1528139885909};\\\", \\\"{x:462,y:550,t:1528139885926};\\\", \\\"{x:463,y:552,t:1528139885942};\\\", \\\"{x:465,y:557,t:1528139885959};\\\", \\\"{x:465,y:560,t:1528139885976};\\\", \\\"{x:465,y:566,t:1528139885994};\\\", \\\"{x:465,y:574,t:1528139886009};\\\", \\\"{x:460,y:584,t:1528139886025};\\\", \\\"{x:452,y:592,t:1528139886043};\\\", \\\"{x:442,y:600,t:1528139886060};\\\", \\\"{x:424,y:612,t:1528139886076};\\\", \\\"{x:415,y:622,t:1528139886093};\\\", \\\"{x:409,y:633,t:1528139886109};\\\", \\\"{x:406,y:639,t:1528139886126};\\\", \\\"{x:406,y:642,t:1528139886143};\\\", \\\"{x:406,y:644,t:1528139886159};\\\", \\\"{x:406,y:646,t:1528139886176};\\\", \\\"{x:406,y:647,t:1528139886204};\\\", \\\"{x:406,y:648,t:1528139886236};\\\", \\\"{x:405,y:650,t:1528139886244};\\\", \\\"{x:404,y:650,t:1528139886260};\\\", \\\"{x:401,y:651,t:1528139886276};\\\", \\\"{x:399,y:651,t:1528139886293};\\\", \\\"{x:393,y:654,t:1528139886310};\\\", \\\"{x:390,y:654,t:1528139886325};\\\", \\\"{x:389,y:654,t:1528139886460};\\\", \\\"{x:389,y:654,t:1528139886569};\\\", \\\"{x:393,y:659,t:1528139886684};\\\", \\\"{x:396,y:662,t:1528139886693};\\\", \\\"{x:426,y:683,t:1528139886711};\\\", \\\"{x:459,y:703,t:1528139886727};\\\", \\\"{x:490,y:723,t:1528139886744};\\\", \\\"{x:513,y:743,t:1528139886760};\\\", \\\"{x:533,y:761,t:1528139886778};\\\", \\\"{x:548,y:772,t:1528139886793};\\\", \\\"{x:559,y:778,t:1528139886810};\\\", \\\"{x:563,y:779,t:1528139886827};\\\", \\\"{x:562,y:779,t:1528139886893};\\\", \\\"{x:559,y:777,t:1528139886910};\\\", \\\"{x:555,y:774,t:1528139886928};\\\", \\\"{x:554,y:770,t:1528139886943};\\\", \\\"{x:552,y:768,t:1528139886960};\\\", \\\"{x:550,y:767,t:1528139886977};\\\", \\\"{x:549,y:765,t:1528139886993};\\\", \\\"{x:547,y:763,t:1528139887010};\\\", \\\"{x:545,y:762,t:1528139887028};\\\", \\\"{x:541,y:759,t:1528139887043};\\\", \\\"{x:540,y:756,t:1528139887060};\\\", \\\"{x:538,y:754,t:1528139887077};\\\", \\\"{x:538,y:753,t:1528139887093};\\\", \\\"{x:537,y:752,t:1528139887111};\\\", \\\"{x:535,y:748,t:1528139887127};\\\", \\\"{x:534,y:741,t:1528139887144};\\\", \\\"{x:533,y:736,t:1528139887161};\\\", \\\"{x:533,y:734,t:1528139887885};\\\", \\\"{x:532,y:734,t:1528139888077};\\\", \\\"{x:532,y:733,t:1528139888101};\\\", \\\"{x:531,y:732,t:1528139888111};\\\", \\\"{x:531,y:731,t:1528139888157};\\\", \\\"{x:531,y:730,t:1528139888324};\\\" ] }, { \\\"rt\\\": 35788, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 864497, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -M -3-J -J -J -E -J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:725,t:1528139889788};\\\", \\\"{x:507,y:717,t:1528139889798};\\\", \\\"{x:446,y:687,t:1528139889813};\\\", \\\"{x:384,y:669,t:1528139889829};\\\", \\\"{x:355,y:660,t:1528139889846};\\\", \\\"{x:321,y:650,t:1528139889862};\\\", \\\"{x:283,y:640,t:1528139889878};\\\", \\\"{x:258,y:636,t:1528139889897};\\\", \\\"{x:236,y:631,t:1528139889913};\\\", \\\"{x:226,y:628,t:1528139889928};\\\", \\\"{x:218,y:624,t:1528139889946};\\\", \\\"{x:213,y:620,t:1528139889962};\\\", \\\"{x:211,y:616,t:1528139889979};\\\", \\\"{x:212,y:607,t:1528139889996};\\\", \\\"{x:228,y:594,t:1528139890013};\\\", \\\"{x:246,y:581,t:1528139890030};\\\", \\\"{x:266,y:567,t:1528139890046};\\\", \\\"{x:284,y:556,t:1528139890062};\\\", \\\"{x:303,y:545,t:1528139890080};\\\", \\\"{x:310,y:540,t:1528139890095};\\\", \\\"{x:315,y:537,t:1528139890111};\\\", \\\"{x:322,y:534,t:1528139890128};\\\", \\\"{x:339,y:533,t:1528139890146};\\\", \\\"{x:346,y:531,t:1528139890162};\\\", \\\"{x:353,y:529,t:1528139890179};\\\", \\\"{x:366,y:527,t:1528139890196};\\\", \\\"{x:373,y:523,t:1528139890214};\\\", \\\"{x:375,y:523,t:1528139890229};\\\", \\\"{x:377,y:521,t:1528139890246};\\\", \\\"{x:378,y:521,t:1528139890262};\\\", \\\"{x:380,y:520,t:1528139890279};\\\", \\\"{x:380,y:519,t:1528139890296};\\\", \\\"{x:383,y:517,t:1528139890313};\\\", \\\"{x:386,y:515,t:1528139890329};\\\", \\\"{x:391,y:511,t:1528139890347};\\\", \\\"{x:401,y:508,t:1528139890364};\\\", \\\"{x:410,y:504,t:1528139890379};\\\", \\\"{x:418,y:500,t:1528139890396};\\\", \\\"{x:423,y:498,t:1528139890413};\\\", \\\"{x:429,y:496,t:1528139890429};\\\", \\\"{x:437,y:494,t:1528139890446};\\\", \\\"{x:448,y:491,t:1528139890463};\\\", \\\"{x:459,y:490,t:1528139890480};\\\", \\\"{x:471,y:486,t:1528139890497};\\\", \\\"{x:484,y:485,t:1528139890519};\\\", \\\"{x:491,y:483,t:1528139890529};\\\", \\\"{x:513,y:480,t:1528139890546};\\\", \\\"{x:553,y:476,t:1528139890563};\\\", \\\"{x:579,y:474,t:1528139890579};\\\", \\\"{x:599,y:474,t:1528139890595};\\\", \\\"{x:620,y:474,t:1528139890613};\\\", \\\"{x:638,y:474,t:1528139890630};\\\", \\\"{x:657,y:474,t:1528139890646};\\\", \\\"{x:669,y:474,t:1528139890663};\\\", \\\"{x:680,y:474,t:1528139890680};\\\", \\\"{x:686,y:474,t:1528139890696};\\\", \\\"{x:688,y:474,t:1528139890713};\\\", \\\"{x:692,y:474,t:1528139890730};\\\", \\\"{x:694,y:474,t:1528139890746};\\\", \\\"{x:696,y:474,t:1528139890763};\\\", \\\"{x:704,y:474,t:1528139890780};\\\", \\\"{x:713,y:474,t:1528139890796};\\\", \\\"{x:721,y:475,t:1528139890813};\\\", \\\"{x:730,y:477,t:1528139890831};\\\", \\\"{x:739,y:481,t:1528139890848};\\\", \\\"{x:754,y:485,t:1528139890864};\\\", \\\"{x:772,y:491,t:1528139890881};\\\", \\\"{x:792,y:497,t:1528139890896};\\\", \\\"{x:813,y:505,t:1528139890913};\\\", \\\"{x:836,y:514,t:1528139890929};\\\", \\\"{x:851,y:520,t:1528139890947};\\\", \\\"{x:867,y:525,t:1528139890963};\\\", \\\"{x:883,y:534,t:1528139890980};\\\", \\\"{x:888,y:535,t:1528139890996};\\\", \\\"{x:897,y:538,t:1528139891012};\\\", \\\"{x:902,y:541,t:1528139891030};\\\", \\\"{x:904,y:542,t:1528139891908};\\\", \\\"{x:909,y:545,t:1528139891916};\\\", \\\"{x:910,y:545,t:1528139891931};\\\", \\\"{x:911,y:547,t:1528139891949};\\\", \\\"{x:911,y:549,t:1528139891964};\\\", \\\"{x:917,y:553,t:1528139891981};\\\", \\\"{x:921,y:555,t:1528139891997};\\\", \\\"{x:923,y:557,t:1528139892015};\\\", \\\"{x:928,y:561,t:1528139892031};\\\", \\\"{x:937,y:564,t:1528139892044};\\\", \\\"{x:946,y:567,t:1528139892061};\\\", \\\"{x:953,y:570,t:1528139892077};\\\", \\\"{x:962,y:576,t:1528139892093};\\\", \\\"{x:974,y:581,t:1528139892114};\\\", \\\"{x:984,y:585,t:1528139892131};\\\", \\\"{x:997,y:591,t:1528139892146};\\\", \\\"{x:1014,y:606,t:1528139892164};\\\", \\\"{x:1029,y:616,t:1528139892182};\\\", \\\"{x:1047,y:627,t:1528139892197};\\\", \\\"{x:1061,y:638,t:1528139892214};\\\", \\\"{x:1080,y:648,t:1528139892231};\\\", \\\"{x:1100,y:660,t:1528139892247};\\\", \\\"{x:1113,y:667,t:1528139892264};\\\", \\\"{x:1124,y:673,t:1528139892281};\\\", \\\"{x:1135,y:679,t:1528139892298};\\\", \\\"{x:1140,y:681,t:1528139892314};\\\", \\\"{x:1144,y:683,t:1528139892332};\\\", \\\"{x:1148,y:684,t:1528139892349};\\\", \\\"{x:1150,y:684,t:1528139892365};\\\", \\\"{x:1151,y:686,t:1528139892382};\\\", \\\"{x:1149,y:686,t:1528139892501};\\\", \\\"{x:1147,y:686,t:1528139892514};\\\", \\\"{x:1133,y:682,t:1528139892531};\\\", \\\"{x:1111,y:671,t:1528139892548};\\\", \\\"{x:1095,y:664,t:1528139892565};\\\", \\\"{x:1078,y:658,t:1528139892582};\\\", \\\"{x:1057,y:654,t:1528139892599};\\\", \\\"{x:1027,y:645,t:1528139892615};\\\", \\\"{x:992,y:634,t:1528139892632};\\\", \\\"{x:963,y:626,t:1528139892648};\\\", \\\"{x:920,y:612,t:1528139892666};\\\", \\\"{x:876,y:598,t:1528139892681};\\\", \\\"{x:833,y:583,t:1528139892698};\\\", \\\"{x:779,y:567,t:1528139892715};\\\", \\\"{x:749,y:556,t:1528139892732};\\\", \\\"{x:729,y:549,t:1528139892748};\\\", \\\"{x:727,y:547,t:1528139892764};\\\", \\\"{x:726,y:547,t:1528139892788};\\\", \\\"{x:726,y:546,t:1528139892860};\\\", \\\"{x:727,y:546,t:1528139892868};\\\", \\\"{x:730,y:546,t:1528139892881};\\\", \\\"{x:733,y:544,t:1528139892898};\\\", \\\"{x:737,y:544,t:1528139892914};\\\", \\\"{x:747,y:545,t:1528139892931};\\\", \\\"{x:778,y:563,t:1528139892949};\\\", \\\"{x:797,y:579,t:1528139892964};\\\", \\\"{x:832,y:599,t:1528139892982};\\\", \\\"{x:877,y:621,t:1528139892998};\\\", \\\"{x:932,y:644,t:1528139893015};\\\", \\\"{x:967,y:666,t:1528139893031};\\\", \\\"{x:1002,y:680,t:1528139893048};\\\", \\\"{x:1035,y:693,t:1528139893065};\\\", \\\"{x:1054,y:709,t:1528139893081};\\\", \\\"{x:1082,y:718,t:1528139893098};\\\", \\\"{x:1094,y:724,t:1528139893115};\\\", \\\"{x:1104,y:731,t:1528139893131};\\\", \\\"{x:1111,y:734,t:1528139893148};\\\", \\\"{x:1112,y:736,t:1528139893165};\\\", \\\"{x:1114,y:737,t:1528139893181};\\\", \\\"{x:1114,y:738,t:1528139893199};\\\", \\\"{x:1116,y:740,t:1528139893215};\\\", \\\"{x:1117,y:742,t:1528139893233};\\\", \\\"{x:1118,y:744,t:1528139893248};\\\", \\\"{x:1122,y:748,t:1528139893265};\\\", \\\"{x:1129,y:756,t:1528139893283};\\\", \\\"{x:1139,y:766,t:1528139893299};\\\", \\\"{x:1151,y:775,t:1528139893315};\\\", \\\"{x:1175,y:794,t:1528139893333};\\\", \\\"{x:1187,y:806,t:1528139893349};\\\", \\\"{x:1202,y:814,t:1528139893366};\\\", \\\"{x:1218,y:825,t:1528139893385};\\\", \\\"{x:1236,y:834,t:1528139893398};\\\", \\\"{x:1250,y:841,t:1528139893415};\\\", \\\"{x:1262,y:845,t:1528139893432};\\\", \\\"{x:1274,y:850,t:1528139893448};\\\", \\\"{x:1281,y:852,t:1528139893465};\\\", \\\"{x:1285,y:854,t:1528139893482};\\\", \\\"{x:1286,y:855,t:1528139893565};\\\", \\\"{x:1286,y:856,t:1528139893669};\\\", \\\"{x:1285,y:856,t:1528139893701};\\\", \\\"{x:1284,y:856,t:1528139893821};\\\", \\\"{x:1283,y:856,t:1528139893852};\\\", \\\"{x:1282,y:857,t:1528139893869};\\\", \\\"{x:1281,y:858,t:1528139893893};\\\", \\\"{x:1279,y:859,t:1528139893900};\\\", \\\"{x:1278,y:860,t:1528139893924};\\\", \\\"{x:1274,y:861,t:1528139893941};\\\", \\\"{x:1273,y:862,t:1528139893949};\\\", \\\"{x:1271,y:864,t:1528139893966};\\\", \\\"{x:1268,y:866,t:1528139893983};\\\", \\\"{x:1264,y:870,t:1528139893999};\\\", \\\"{x:1260,y:873,t:1528139894016};\\\", \\\"{x:1259,y:875,t:1528139894033};\\\", \\\"{x:1257,y:877,t:1528139894050};\\\", \\\"{x:1256,y:877,t:1528139894069};\\\", \\\"{x:1257,y:877,t:1528139894245};\\\", \\\"{x:1259,y:877,t:1528139894261};\\\", \\\"{x:1261,y:876,t:1528139894268};\\\", \\\"{x:1262,y:874,t:1528139894285};\\\", \\\"{x:1263,y:874,t:1528139894300};\\\", \\\"{x:1265,y:874,t:1528139894316};\\\", \\\"{x:1266,y:873,t:1528139894333};\\\", \\\"{x:1267,y:872,t:1528139894381};\\\", \\\"{x:1269,y:871,t:1528139894413};\\\", \\\"{x:1270,y:870,t:1528139894420};\\\", \\\"{x:1271,y:870,t:1528139894432};\\\", \\\"{x:1275,y:867,t:1528139894450};\\\", \\\"{x:1277,y:867,t:1528139894467};\\\", \\\"{x:1278,y:866,t:1528139894482};\\\", \\\"{x:1282,y:865,t:1528139894499};\\\", \\\"{x:1284,y:863,t:1528139894516};\\\", \\\"{x:1285,y:863,t:1528139894533};\\\", \\\"{x:1287,y:863,t:1528139894653};\\\", \\\"{x:1293,y:863,t:1528139894666};\\\", \\\"{x:1299,y:869,t:1528139894684};\\\", \\\"{x:1310,y:876,t:1528139894700};\\\", \\\"{x:1329,y:890,t:1528139894717};\\\", \\\"{x:1337,y:896,t:1528139894734};\\\", \\\"{x:1346,y:901,t:1528139894751};\\\", \\\"{x:1349,y:904,t:1528139894767};\\\", \\\"{x:1352,y:905,t:1528139894784};\\\", \\\"{x:1353,y:906,t:1528139894800};\\\", \\\"{x:1353,y:907,t:1528139894885};\\\", \\\"{x:1353,y:908,t:1528139894900};\\\", \\\"{x:1356,y:907,t:1528139895028};\\\", \\\"{x:1358,y:902,t:1528139895036};\\\", \\\"{x:1362,y:898,t:1528139895050};\\\", \\\"{x:1372,y:889,t:1528139895066};\\\", \\\"{x:1379,y:884,t:1528139895083};\\\", \\\"{x:1385,y:878,t:1528139895099};\\\", \\\"{x:1385,y:877,t:1528139895116};\\\", \\\"{x:1387,y:875,t:1528139895134};\\\", \\\"{x:1387,y:873,t:1528139895151};\\\", \\\"{x:1385,y:869,t:1528139895166};\\\", \\\"{x:1371,y:860,t:1528139895183};\\\", \\\"{x:1346,y:851,t:1528139895201};\\\", \\\"{x:1299,y:833,t:1528139895216};\\\", \\\"{x:1229,y:809,t:1528139895234};\\\", \\\"{x:1145,y:785,t:1528139895250};\\\", \\\"{x:1096,y:768,t:1528139895267};\\\", \\\"{x:1057,y:756,t:1528139895284};\\\", \\\"{x:1027,y:752,t:1528139895302};\\\", \\\"{x:1026,y:752,t:1528139895317};\\\", \\\"{x:1026,y:751,t:1528139895334};\\\", \\\"{x:1026,y:753,t:1528139895389};\\\", \\\"{x:1031,y:758,t:1528139895400};\\\", \\\"{x:1044,y:771,t:1528139895417};\\\", \\\"{x:1051,y:777,t:1528139895434};\\\", \\\"{x:1062,y:789,t:1528139895451};\\\", \\\"{x:1079,y:796,t:1528139895467};\\\", \\\"{x:1094,y:802,t:1528139895484};\\\", \\\"{x:1108,y:808,t:1528139895500};\\\", \\\"{x:1115,y:811,t:1528139895518};\\\", \\\"{x:1119,y:811,t:1528139895533};\\\", \\\"{x:1123,y:813,t:1528139895550};\\\", \\\"{x:1125,y:815,t:1528139895568};\\\", \\\"{x:1128,y:816,t:1528139895584};\\\", \\\"{x:1129,y:818,t:1528139895600};\\\", \\\"{x:1131,y:818,t:1528139895620};\\\", \\\"{x:1135,y:819,t:1528139895633};\\\", \\\"{x:1143,y:822,t:1528139895651};\\\", \\\"{x:1151,y:823,t:1528139895667};\\\", \\\"{x:1158,y:826,t:1528139895684};\\\", \\\"{x:1163,y:827,t:1528139895701};\\\", \\\"{x:1171,y:830,t:1528139895717};\\\", \\\"{x:1180,y:832,t:1528139895734};\\\", \\\"{x:1187,y:836,t:1528139895751};\\\", \\\"{x:1190,y:838,t:1528139895768};\\\", \\\"{x:1192,y:838,t:1528139895784};\\\", \\\"{x:1194,y:838,t:1528139895805};\\\", \\\"{x:1195,y:838,t:1528139895818};\\\", \\\"{x:1197,y:838,t:1528139895836};\\\", \\\"{x:1198,y:838,t:1528139895869};\\\", \\\"{x:1200,y:838,t:1528139895949};\\\", \\\"{x:1201,y:838,t:1528139895997};\\\", \\\"{x:1203,y:838,t:1528139896005};\\\", \\\"{x:1205,y:838,t:1528139896018};\\\", \\\"{x:1210,y:837,t:1528139896034};\\\", \\\"{x:1213,y:835,t:1528139896051};\\\", \\\"{x:1215,y:835,t:1528139896067};\\\", \\\"{x:1216,y:835,t:1528139896149};\\\", \\\"{x:1214,y:832,t:1528139901120};\\\", \\\"{x:1209,y:827,t:1528139901127};\\\", \\\"{x:1203,y:820,t:1528139901142};\\\", \\\"{x:1180,y:804,t:1528139901158};\\\", \\\"{x:1164,y:792,t:1528139901175};\\\", \\\"{x:1149,y:783,t:1528139901192};\\\", \\\"{x:1143,y:778,t:1528139901208};\\\", \\\"{x:1142,y:778,t:1528139901225};\\\", \\\"{x:1141,y:777,t:1528139901272};\\\", \\\"{x:1142,y:777,t:1528139901568};\\\", \\\"{x:1144,y:779,t:1528139901576};\\\", \\\"{x:1150,y:786,t:1528139901592};\\\", \\\"{x:1164,y:800,t:1528139901608};\\\", \\\"{x:1178,y:812,t:1528139901625};\\\", \\\"{x:1194,y:823,t:1528139901642};\\\", \\\"{x:1212,y:833,t:1528139901659};\\\", \\\"{x:1231,y:840,t:1528139901676};\\\", \\\"{x:1240,y:845,t:1528139901693};\\\", \\\"{x:1246,y:848,t:1528139901709};\\\", \\\"{x:1245,y:848,t:1528139901800};\\\", \\\"{x:1241,y:848,t:1528139901809};\\\", \\\"{x:1234,y:845,t:1528139901825};\\\", \\\"{x:1224,y:842,t:1528139901842};\\\", \\\"{x:1214,y:838,t:1528139901859};\\\", \\\"{x:1210,y:834,t:1528139901875};\\\", \\\"{x:1206,y:832,t:1528139901892};\\\", \\\"{x:1205,y:830,t:1528139901909};\\\", \\\"{x:1204,y:830,t:1528139901925};\\\", \\\"{x:1203,y:829,t:1528139902000};\\\", \\\"{x:1203,y:828,t:1528139902496};\\\", \\\"{x:1204,y:827,t:1528139902536};\\\", \\\"{x:1204,y:826,t:1528139902544};\\\", \\\"{x:1205,y:824,t:1528139902559};\\\", \\\"{x:1208,y:818,t:1528139902576};\\\", \\\"{x:1210,y:813,t:1528139902594};\\\", \\\"{x:1211,y:808,t:1528139902610};\\\", \\\"{x:1213,y:799,t:1528139902627};\\\", \\\"{x:1216,y:791,t:1528139902643};\\\", \\\"{x:1219,y:779,t:1528139902659};\\\", \\\"{x:1222,y:766,t:1528139902677};\\\", \\\"{x:1227,y:755,t:1528139902693};\\\", \\\"{x:1235,y:742,t:1528139902710};\\\", \\\"{x:1240,y:733,t:1528139902727};\\\", \\\"{x:1246,y:719,t:1528139902744};\\\", \\\"{x:1250,y:707,t:1528139902760};\\\", \\\"{x:1254,y:697,t:1528139902776};\\\", \\\"{x:1257,y:685,t:1528139902794};\\\", \\\"{x:1259,y:678,t:1528139902809};\\\", \\\"{x:1260,y:676,t:1528139902826};\\\", \\\"{x:1262,y:674,t:1528139902843};\\\", \\\"{x:1262,y:673,t:1528139902859};\\\", \\\"{x:1262,y:667,t:1528139903504};\\\", \\\"{x:1261,y:665,t:1528139903512};\\\", \\\"{x:1260,y:662,t:1528139903528};\\\", \\\"{x:1260,y:659,t:1528139903543};\\\", \\\"{x:1259,y:658,t:1528139903560};\\\", \\\"{x:1258,y:657,t:1528139903584};\\\", \\\"{x:1258,y:656,t:1528139903615};\\\", \\\"{x:1258,y:654,t:1528139903648};\\\", \\\"{x:1258,y:652,t:1528139903672};\\\", \\\"{x:1258,y:648,t:1528139903687};\\\", \\\"{x:1260,y:643,t:1528139903695};\\\", \\\"{x:1263,y:638,t:1528139903710};\\\", \\\"{x:1267,y:628,t:1528139903727};\\\", \\\"{x:1269,y:625,t:1528139903743};\\\", \\\"{x:1269,y:622,t:1528139903763};\\\", \\\"{x:1272,y:617,t:1528139903777};\\\", \\\"{x:1272,y:616,t:1528139903793};\\\", \\\"{x:1273,y:613,t:1528139903810};\\\", \\\"{x:1274,y:608,t:1528139903827};\\\", \\\"{x:1275,y:606,t:1528139903844};\\\", \\\"{x:1275,y:603,t:1528139903861};\\\", \\\"{x:1276,y:601,t:1528139903877};\\\", \\\"{x:1278,y:599,t:1528139903895};\\\", \\\"{x:1278,y:598,t:1528139903910};\\\", \\\"{x:1278,y:593,t:1528139903927};\\\", \\\"{x:1279,y:590,t:1528139903944};\\\", \\\"{x:1279,y:589,t:1528139903962};\\\", \\\"{x:1280,y:586,t:1528139903978};\\\", \\\"{x:1281,y:584,t:1528139903994};\\\", \\\"{x:1282,y:582,t:1528139904010};\\\", \\\"{x:1282,y:580,t:1528139904080};\\\", \\\"{x:1282,y:579,t:1528139904120};\\\", \\\"{x:1283,y:578,t:1528139904128};\\\", \\\"{x:1283,y:577,t:1528139904144};\\\", \\\"{x:1283,y:575,t:1528139904320};\\\", \\\"{x:1283,y:572,t:1528139904327};\\\", \\\"{x:1283,y:565,t:1528139904344};\\\", \\\"{x:1283,y:562,t:1528139904362};\\\", \\\"{x:1283,y:561,t:1528139904377};\\\", \\\"{x:1283,y:564,t:1528139905704};\\\", \\\"{x:1285,y:570,t:1528139905712};\\\", \\\"{x:1286,y:579,t:1528139905729};\\\", \\\"{x:1287,y:586,t:1528139905745};\\\", \\\"{x:1288,y:591,t:1528139905762};\\\", \\\"{x:1289,y:595,t:1528139905778};\\\", \\\"{x:1290,y:597,t:1528139905795};\\\", \\\"{x:1290,y:601,t:1528139905812};\\\", \\\"{x:1291,y:604,t:1528139905828};\\\", \\\"{x:1291,y:608,t:1528139905846};\\\", \\\"{x:1291,y:611,t:1528139905863};\\\", \\\"{x:1293,y:615,t:1528139905878};\\\", \\\"{x:1294,y:619,t:1528139905896};\\\", \\\"{x:1296,y:623,t:1528139905912};\\\", \\\"{x:1296,y:626,t:1528139905928};\\\", \\\"{x:1298,y:630,t:1528139905946};\\\", \\\"{x:1299,y:636,t:1528139905964};\\\", \\\"{x:1301,y:640,t:1528139905978};\\\", \\\"{x:1304,y:648,t:1528139905995};\\\", \\\"{x:1307,y:654,t:1528139906012};\\\", \\\"{x:1310,y:660,t:1528139906029};\\\", \\\"{x:1314,y:666,t:1528139906045};\\\", \\\"{x:1318,y:672,t:1528139906062};\\\", \\\"{x:1322,y:680,t:1528139906079};\\\", \\\"{x:1322,y:683,t:1528139906095};\\\", \\\"{x:1324,y:685,t:1528139906112};\\\", \\\"{x:1325,y:686,t:1528139906129};\\\", \\\"{x:1326,y:686,t:1528139906145};\\\", \\\"{x:1326,y:688,t:1528139906162};\\\", \\\"{x:1327,y:690,t:1528139906179};\\\", \\\"{x:1329,y:699,t:1528139906195};\\\", \\\"{x:1332,y:714,t:1528139906213};\\\", \\\"{x:1334,y:732,t:1528139906229};\\\", \\\"{x:1338,y:749,t:1528139906245};\\\", \\\"{x:1340,y:766,t:1528139906263};\\\", \\\"{x:1344,y:785,t:1528139906279};\\\", \\\"{x:1344,y:788,t:1528139906296};\\\", \\\"{x:1344,y:789,t:1528139906312};\\\", \\\"{x:1345,y:790,t:1528139906408};\\\", \\\"{x:1346,y:790,t:1528139906423};\\\", \\\"{x:1347,y:790,t:1528139906431};\\\", \\\"{x:1350,y:790,t:1528139906445};\\\", \\\"{x:1353,y:789,t:1528139906462};\\\", \\\"{x:1355,y:788,t:1528139906479};\\\", \\\"{x:1356,y:786,t:1528139906495};\\\", \\\"{x:1356,y:785,t:1528139906543};\\\", \\\"{x:1356,y:784,t:1528139906551};\\\", \\\"{x:1356,y:783,t:1528139906576};\\\", \\\"{x:1355,y:783,t:1528139906592};\\\", \\\"{x:1354,y:781,t:1528139906600};\\\", \\\"{x:1353,y:780,t:1528139906632};\\\", \\\"{x:1351,y:779,t:1528139906646};\\\", \\\"{x:1350,y:778,t:1528139906664};\\\", \\\"{x:1348,y:774,t:1528139906680};\\\", \\\"{x:1346,y:772,t:1528139906696};\\\", \\\"{x:1343,y:767,t:1528139906712};\\\", \\\"{x:1342,y:761,t:1528139906729};\\\", \\\"{x:1338,y:749,t:1528139906747};\\\", \\\"{x:1333,y:739,t:1528139906762};\\\", \\\"{x:1330,y:731,t:1528139906779};\\\", \\\"{x:1328,y:725,t:1528139906796};\\\", \\\"{x:1328,y:720,t:1528139906812};\\\", \\\"{x:1328,y:718,t:1528139906829};\\\", \\\"{x:1328,y:717,t:1528139906847};\\\", \\\"{x:1328,y:716,t:1528139906862};\\\", \\\"{x:1327,y:715,t:1528139907024};\\\", \\\"{x:1325,y:713,t:1528139907072};\\\", \\\"{x:1324,y:713,t:1528139907079};\\\", \\\"{x:1322,y:711,t:1528139907097};\\\", \\\"{x:1320,y:710,t:1528139907113};\\\", \\\"{x:1320,y:709,t:1528139907130};\\\", \\\"{x:1317,y:708,t:1528139907152};\\\", \\\"{x:1316,y:708,t:1528139907164};\\\", \\\"{x:1313,y:712,t:1528139907832};\\\", \\\"{x:1310,y:721,t:1528139907847};\\\", \\\"{x:1301,y:736,t:1528139907864};\\\", \\\"{x:1297,y:739,t:1528139907881};\\\", \\\"{x:1293,y:741,t:1528139907898};\\\", \\\"{x:1265,y:741,t:1528139907914};\\\", \\\"{x:1198,y:741,t:1528139907931};\\\", \\\"{x:1071,y:704,t:1528139907947};\\\", \\\"{x:922,y:666,t:1528139907964};\\\", \\\"{x:773,y:625,t:1528139907981};\\\", \\\"{x:620,y:599,t:1528139907997};\\\", \\\"{x:487,y:577,t:1528139908013};\\\", \\\"{x:242,y:542,t:1528139908047};\\\", \\\"{x:204,y:537,t:1528139908064};\\\", \\\"{x:190,y:537,t:1528139908080};\\\", \\\"{x:189,y:537,t:1528139908103};\\\", \\\"{x:188,y:540,t:1528139908143};\\\", \\\"{x:188,y:553,t:1528139908151};\\\", \\\"{x:188,y:564,t:1528139908164};\\\", \\\"{x:196,y:596,t:1528139908180};\\\", \\\"{x:215,y:620,t:1528139908197};\\\", \\\"{x:237,y:643,t:1528139908214};\\\", \\\"{x:256,y:655,t:1528139908230};\\\", \\\"{x:296,y:676,t:1528139908247};\\\", \\\"{x:334,y:687,t:1528139908262};\\\", \\\"{x:369,y:700,t:1528139908280};\\\", \\\"{x:414,y:712,t:1528139908297};\\\", \\\"{x:461,y:734,t:1528139908315};\\\", \\\"{x:488,y:745,t:1528139908330};\\\", \\\"{x:503,y:751,t:1528139908346};\\\", \\\"{x:506,y:753,t:1528139908364};\\\", \\\"{x:507,y:753,t:1528139908380};\\\", \\\"{x:508,y:753,t:1528139908431};\\\", \\\"{x:511,y:753,t:1528139908447};\\\", \\\"{x:513,y:753,t:1528139908511};\\\", \\\"{x:514,y:753,t:1528139908518};\\\", \\\"{x:515,y:752,t:1528139908543};\\\", \\\"{x:516,y:751,t:1528139908615};\\\", \\\"{x:516,y:750,t:1528139908736};\\\", \\\"{x:517,y:749,t:1528139908747};\\\", \\\"{x:524,y:745,t:1528139908764};\\\", \\\"{x:536,y:738,t:1528139908781};\\\", \\\"{x:559,y:722,t:1528139908798};\\\", \\\"{x:590,y:710,t:1528139908816};\\\", \\\"{x:660,y:692,t:1528139908831};\\\", \\\"{x:714,y:687,t:1528139908847};\\\", \\\"{x:759,y:687,t:1528139908864};\\\", \\\"{x:811,y:689,t:1528139908881};\\\", \\\"{x:864,y:697,t:1528139908898};\\\", \\\"{x:890,y:704,t:1528139908914};\\\", \\\"{x:916,y:713,t:1528139908931};\\\", \\\"{x:938,y:719,t:1528139908948};\\\", \\\"{x:954,y:726,t:1528139908964};\\\", \\\"{x:968,y:731,t:1528139908981};\\\", \\\"{x:982,y:737,t:1528139908998};\\\", \\\"{x:1000,y:745,t:1528139909014};\\\", \\\"{x:1016,y:755,t:1528139909032};\\\", \\\"{x:1031,y:763,t:1528139909049};\\\", \\\"{x:1049,y:774,t:1528139909064};\\\", \\\"{x:1074,y:790,t:1528139909081};\\\", \\\"{x:1099,y:798,t:1528139909098};\\\", \\\"{x:1120,y:806,t:1528139909114};\\\", \\\"{x:1140,y:809,t:1528139909131};\\\", \\\"{x:1161,y:815,t:1528139909148};\\\", \\\"{x:1174,y:819,t:1528139909164};\\\", \\\"{x:1192,y:823,t:1528139909181};\\\", \\\"{x:1208,y:826,t:1528139909198};\\\", \\\"{x:1221,y:827,t:1528139909215};\\\", \\\"{x:1228,y:827,t:1528139909231};\\\", \\\"{x:1228,y:826,t:1528139909248};\\\", \\\"{x:1229,y:825,t:1528139909271};\\\", \\\"{x:1229,y:823,t:1528139909288};\\\", \\\"{x:1229,y:821,t:1528139909299};\\\", \\\"{x:1229,y:820,t:1528139909316};\\\", \\\"{x:1229,y:819,t:1528139909336};\\\", \\\"{x:1229,y:818,t:1528139909361};\\\", \\\"{x:1227,y:818,t:1528139909416};\\\", \\\"{x:1222,y:818,t:1528139909432};\\\", \\\"{x:1216,y:818,t:1528139909448};\\\", \\\"{x:1211,y:818,t:1528139909465};\\\", \\\"{x:1207,y:818,t:1528139909482};\\\", \\\"{x:1206,y:818,t:1528139909512};\\\", \\\"{x:1204,y:818,t:1528139909736};\\\", \\\"{x:1200,y:816,t:1528139909748};\\\", \\\"{x:1192,y:814,t:1528139909766};\\\", \\\"{x:1181,y:812,t:1528139909782};\\\", \\\"{x:1172,y:811,t:1528139909798};\\\", \\\"{x:1160,y:811,t:1528139909815};\\\", \\\"{x:1157,y:811,t:1528139909832};\\\", \\\"{x:1156,y:811,t:1528139909849};\\\", \\\"{x:1154,y:812,t:1528139909866};\\\", \\\"{x:1153,y:814,t:1528139909882};\\\", \\\"{x:1152,y:817,t:1528139909898};\\\", \\\"{x:1152,y:818,t:1528139909916};\\\", \\\"{x:1152,y:821,t:1528139909933};\\\", \\\"{x:1152,y:823,t:1528139909950};\\\", \\\"{x:1157,y:827,t:1528139909965};\\\", \\\"{x:1163,y:830,t:1528139909983};\\\", \\\"{x:1168,y:831,t:1528139910000};\\\", \\\"{x:1172,y:831,t:1528139910015};\\\", \\\"{x:1177,y:831,t:1528139910033};\\\", \\\"{x:1182,y:833,t:1528139910050};\\\", \\\"{x:1183,y:833,t:1528139910066};\\\", \\\"{x:1184,y:833,t:1528139910248};\\\", \\\"{x:1185,y:833,t:1528139910255};\\\", \\\"{x:1186,y:833,t:1528139910266};\\\", \\\"{x:1187,y:832,t:1528139910288};\\\", \\\"{x:1188,y:832,t:1528139910327};\\\", \\\"{x:1189,y:832,t:1528139910343};\\\", \\\"{x:1190,y:832,t:1528139910384};\\\", \\\"{x:1192,y:832,t:1528139910400};\\\", \\\"{x:1193,y:832,t:1528139911008};\\\", \\\"{x:1194,y:831,t:1528139911056};\\\", \\\"{x:1194,y:830,t:1528139911072};\\\", \\\"{x:1195,y:829,t:1528139911084};\\\", \\\"{x:1195,y:828,t:1528139911101};\\\", \\\"{x:1195,y:827,t:1528139911116};\\\", \\\"{x:1196,y:826,t:1528139911134};\\\", \\\"{x:1196,y:825,t:1528139911151};\\\", \\\"{x:1197,y:824,t:1528139911184};\\\", \\\"{x:1198,y:825,t:1528139913224};\\\", \\\"{x:1199,y:826,t:1528139913236};\\\", \\\"{x:1201,y:826,t:1528139913328};\\\", \\\"{x:1203,y:826,t:1528139913335};\\\", \\\"{x:1205,y:826,t:1528139913352};\\\", \\\"{x:1206,y:826,t:1528139913375};\\\", \\\"{x:1207,y:827,t:1528139913528};\\\", \\\"{x:1208,y:828,t:1528139913552};\\\", \\\"{x:1209,y:828,t:1528139913584};\\\", \\\"{x:1210,y:828,t:1528139913603};\\\", \\\"{x:1211,y:828,t:1528139913620};\\\", \\\"{x:1212,y:829,t:1528139913663};\\\", \\\"{x:1212,y:830,t:1528139913672};\\\", \\\"{x:1212,y:831,t:1528139913686};\\\", \\\"{x:1212,y:832,t:1528139913703};\\\", \\\"{x:1212,y:836,t:1528139913721};\\\", \\\"{x:1212,y:840,t:1528139913736};\\\", \\\"{x:1208,y:845,t:1528139913753};\\\", \\\"{x:1203,y:853,t:1528139913770};\\\", \\\"{x:1200,y:858,t:1528139913786};\\\", \\\"{x:1196,y:865,t:1528139913803};\\\", \\\"{x:1191,y:872,t:1528139913819};\\\", \\\"{x:1186,y:880,t:1528139913836};\\\", \\\"{x:1181,y:888,t:1528139913853};\\\", \\\"{x:1176,y:895,t:1528139913870};\\\", \\\"{x:1173,y:902,t:1528139913886};\\\", \\\"{x:1169,y:906,t:1528139913903};\\\", \\\"{x:1166,y:911,t:1528139913919};\\\", \\\"{x:1166,y:912,t:1528139913937};\\\", \\\"{x:1165,y:913,t:1528139913952};\\\", \\\"{x:1165,y:916,t:1528139913969};\\\", \\\"{x:1164,y:917,t:1528139913999};\\\", \\\"{x:1163,y:918,t:1528139914008};\\\", \\\"{x:1163,y:919,t:1528139914023};\\\", \\\"{x:1162,y:921,t:1528139914048};\\\", \\\"{x:1161,y:924,t:1528139914056};\\\", \\\"{x:1161,y:927,t:1528139914069};\\\", \\\"{x:1158,y:930,t:1528139914087};\\\", \\\"{x:1156,y:935,t:1528139914103};\\\", \\\"{x:1156,y:936,t:1528139914135};\\\", \\\"{x:1156,y:937,t:1528139914240};\\\", \\\"{x:1156,y:939,t:1528139914256};\\\", \\\"{x:1156,y:940,t:1528139914271};\\\", \\\"{x:1156,y:942,t:1528139914287};\\\", \\\"{x:1156,y:943,t:1528139914303};\\\", \\\"{x:1156,y:945,t:1528139914327};\\\", \\\"{x:1155,y:946,t:1528139914337};\\\", \\\"{x:1155,y:947,t:1528139914384};\\\", \\\"{x:1155,y:948,t:1528139914391};\\\", \\\"{x:1155,y:950,t:1528139914416};\\\", \\\"{x:1155,y:951,t:1528139914488};\\\", \\\"{x:1154,y:952,t:1528139914511};\\\", \\\"{x:1153,y:953,t:1528139914527};\\\", \\\"{x:1152,y:954,t:1528139914537};\\\", \\\"{x:1151,y:956,t:1528139914553};\\\", \\\"{x:1150,y:957,t:1528139914570};\\\", \\\"{x:1146,y:960,t:1528139914587};\\\", \\\"{x:1145,y:961,t:1528139914604};\\\", \\\"{x:1144,y:962,t:1528139914621};\\\", \\\"{x:1143,y:963,t:1528139914640};\\\", \\\"{x:1143,y:964,t:1528139914663};\\\", \\\"{x:1142,y:965,t:1528139914726};\\\", \\\"{x:1141,y:965,t:1528139914736};\\\", \\\"{x:1141,y:966,t:1528139914775};\\\", \\\"{x:1140,y:966,t:1528139914920};\\\", \\\"{x:1139,y:966,t:1528139914960};\\\", \\\"{x:1137,y:966,t:1528139915000};\\\", \\\"{x:1136,y:966,t:1528139915016};\\\", \\\"{x:1135,y:966,t:1528139915080};\\\", \\\"{x:1134,y:966,t:1528139915128};\\\", \\\"{x:1133,y:966,t:1528139915192};\\\", \\\"{x:1132,y:966,t:1528139915352};\\\", \\\"{x:1131,y:966,t:1528139915408};\\\", \\\"{x:1129,y:966,t:1528139915464};\\\", \\\"{x:1128,y:964,t:1528139915471};\\\", \\\"{x:1126,y:962,t:1528139915491};\\\", \\\"{x:1124,y:961,t:1528139915504};\\\", \\\"{x:1122,y:958,t:1528139915520};\\\", \\\"{x:1118,y:955,t:1528139915537};\\\", \\\"{x:1114,y:952,t:1528139915555};\\\", \\\"{x:1112,y:951,t:1528139915571};\\\", \\\"{x:1110,y:951,t:1528139915588};\\\", \\\"{x:1109,y:949,t:1528139915604};\\\", \\\"{x:1107,y:947,t:1528139915824};\\\", \\\"{x:1106,y:945,t:1528139915840};\\\", \\\"{x:1106,y:944,t:1528139915855};\\\", \\\"{x:1105,y:943,t:1528139915887};\\\", \\\"{x:1105,y:942,t:1528139915944};\\\", \\\"{x:1105,y:941,t:1528139916040};\\\", \\\"{x:1105,y:939,t:1528139916056};\\\", \\\"{x:1105,y:936,t:1528139916071};\\\", \\\"{x:1105,y:933,t:1528139916089};\\\", \\\"{x:1105,y:927,t:1528139916104};\\\", \\\"{x:1105,y:925,t:1528139916127};\\\", \\\"{x:1108,y:921,t:1528139916139};\\\", \\\"{x:1110,y:917,t:1528139916155};\\\", \\\"{x:1111,y:913,t:1528139916172};\\\", \\\"{x:1112,y:910,t:1528139916189};\\\", \\\"{x:1113,y:908,t:1528139916205};\\\", \\\"{x:1114,y:905,t:1528139916222};\\\", \\\"{x:1116,y:898,t:1528139916239};\\\", \\\"{x:1120,y:889,t:1528139916256};\\\", \\\"{x:1123,y:882,t:1528139916272};\\\", \\\"{x:1127,y:871,t:1528139916289};\\\", \\\"{x:1133,y:862,t:1528139916306};\\\", \\\"{x:1138,y:849,t:1528139916322};\\\", \\\"{x:1143,y:838,t:1528139916339};\\\", \\\"{x:1149,y:826,t:1528139916355};\\\", \\\"{x:1153,y:818,t:1528139916371};\\\", \\\"{x:1156,y:810,t:1528139916389};\\\", \\\"{x:1160,y:803,t:1528139916405};\\\", \\\"{x:1161,y:796,t:1528139916422};\\\", \\\"{x:1162,y:794,t:1528139916439};\\\", \\\"{x:1162,y:791,t:1528139916455};\\\", \\\"{x:1164,y:789,t:1528139916471};\\\", \\\"{x:1164,y:788,t:1528139916489};\\\", \\\"{x:1165,y:786,t:1528139916506};\\\", \\\"{x:1165,y:783,t:1528139916522};\\\", \\\"{x:1168,y:777,t:1528139916539};\\\", \\\"{x:1169,y:775,t:1528139916556};\\\", \\\"{x:1171,y:772,t:1528139916572};\\\", \\\"{x:1172,y:768,t:1528139916588};\\\", \\\"{x:1172,y:767,t:1528139916608};\\\", \\\"{x:1172,y:766,t:1528139916632};\\\", \\\"{x:1173,y:766,t:1528139916648};\\\", \\\"{x:1174,y:765,t:1528139916655};\\\", \\\"{x:1174,y:764,t:1528139916727};\\\", \\\"{x:1174,y:763,t:1528139916800};\\\", \\\"{x:1176,y:762,t:1528139916807};\\\", \\\"{x:1176,y:760,t:1528139916823};\\\", \\\"{x:1177,y:760,t:1528139916839};\\\", \\\"{x:1177,y:759,t:1528139916856};\\\", \\\"{x:1179,y:758,t:1528139918200};\\\", \\\"{x:1184,y:756,t:1528139918208};\\\", \\\"{x:1194,y:754,t:1528139918224};\\\", \\\"{x:1227,y:758,t:1528139918241};\\\", \\\"{x:1249,y:760,t:1528139918257};\\\", \\\"{x:1263,y:763,t:1528139918274};\\\", \\\"{x:1272,y:765,t:1528139918291};\\\", \\\"{x:1277,y:768,t:1528139918307};\\\", \\\"{x:1282,y:770,t:1528139918324};\\\", \\\"{x:1291,y:773,t:1528139918341};\\\", \\\"{x:1297,y:777,t:1528139918357};\\\", \\\"{x:1302,y:779,t:1528139918374};\\\", \\\"{x:1303,y:780,t:1528139918391};\\\", \\\"{x:1303,y:781,t:1528139918406};\\\", \\\"{x:1306,y:784,t:1528139918423};\\\", \\\"{x:1309,y:788,t:1528139918440};\\\", \\\"{x:1312,y:791,t:1528139918458};\\\", \\\"{x:1315,y:794,t:1528139918473};\\\", \\\"{x:1319,y:795,t:1528139918491};\\\", \\\"{x:1323,y:795,t:1528139918506};\\\", \\\"{x:1326,y:795,t:1528139918523};\\\", \\\"{x:1331,y:795,t:1528139918540};\\\", \\\"{x:1335,y:790,t:1528139918558};\\\", \\\"{x:1339,y:784,t:1528139918573};\\\", \\\"{x:1339,y:783,t:1528139918590};\\\", \\\"{x:1347,y:774,t:1528139918606};\\\", \\\"{x:1350,y:771,t:1528139918624};\\\", \\\"{x:1351,y:770,t:1528139918641};\\\", \\\"{x:1349,y:770,t:1528139918792};\\\", \\\"{x:1346,y:772,t:1528139918807};\\\", \\\"{x:1342,y:777,t:1528139918823};\\\", \\\"{x:1339,y:781,t:1528139918841};\\\", \\\"{x:1339,y:785,t:1528139918858};\\\", \\\"{x:1336,y:790,t:1528139918874};\\\", \\\"{x:1333,y:796,t:1528139918891};\\\", \\\"{x:1331,y:803,t:1528139918909};\\\", \\\"{x:1331,y:806,t:1528139918925};\\\", \\\"{x:1329,y:810,t:1528139918940};\\\", \\\"{x:1329,y:813,t:1528139918958};\\\", \\\"{x:1327,y:817,t:1528139918975};\\\", \\\"{x:1326,y:820,t:1528139918990};\\\", \\\"{x:1325,y:823,t:1528139919007};\\\", \\\"{x:1323,y:825,t:1528139919024};\\\", \\\"{x:1323,y:827,t:1528139919041};\\\", \\\"{x:1321,y:830,t:1528139919058};\\\", \\\"{x:1319,y:833,t:1528139919075};\\\", \\\"{x:1319,y:836,t:1528139919091};\\\", \\\"{x:1317,y:839,t:1528139919108};\\\", \\\"{x:1315,y:842,t:1528139919125};\\\", \\\"{x:1313,y:845,t:1528139919141};\\\", \\\"{x:1310,y:850,t:1528139919158};\\\", \\\"{x:1309,y:852,t:1528139919175};\\\", \\\"{x:1309,y:853,t:1528139919191};\\\", \\\"{x:1308,y:854,t:1528139919208};\\\", \\\"{x:1307,y:855,t:1528139919225};\\\", \\\"{x:1306,y:857,t:1528139919242};\\\", \\\"{x:1305,y:859,t:1528139919258};\\\", \\\"{x:1305,y:860,t:1528139919275};\\\", \\\"{x:1302,y:864,t:1528139919292};\\\", \\\"{x:1301,y:865,t:1528139919309};\\\", \\\"{x:1298,y:869,t:1528139919325};\\\", \\\"{x:1295,y:873,t:1528139919342};\\\", \\\"{x:1292,y:875,t:1528139919358};\\\", \\\"{x:1289,y:879,t:1528139919375};\\\", \\\"{x:1285,y:883,t:1528139919392};\\\", \\\"{x:1284,y:884,t:1528139919407};\\\", \\\"{x:1282,y:887,t:1528139919424};\\\", \\\"{x:1281,y:888,t:1528139919447};\\\", \\\"{x:1280,y:889,t:1528139919479};\\\", \\\"{x:1280,y:890,t:1528139919491};\\\", \\\"{x:1278,y:892,t:1528139919508};\\\", \\\"{x:1277,y:893,t:1528139919524};\\\", \\\"{x:1275,y:898,t:1528139919541};\\\", \\\"{x:1273,y:902,t:1528139919558};\\\", \\\"{x:1269,y:908,t:1528139919575};\\\", \\\"{x:1265,y:914,t:1528139919591};\\\", \\\"{x:1262,y:920,t:1528139919609};\\\", \\\"{x:1257,y:928,t:1528139919625};\\\", \\\"{x:1253,y:933,t:1528139919642};\\\", \\\"{x:1249,y:940,t:1528139919659};\\\", \\\"{x:1247,y:942,t:1528139919675};\\\", \\\"{x:1246,y:943,t:1528139919692};\\\", \\\"{x:1246,y:944,t:1528139919709};\\\", \\\"{x:1246,y:945,t:1528139919742};\\\", \\\"{x:1246,y:946,t:1528139919759};\\\", \\\"{x:1245,y:947,t:1528139919774};\\\", \\\"{x:1245,y:949,t:1528139919791};\\\", \\\"{x:1245,y:950,t:1528139919808};\\\", \\\"{x:1244,y:951,t:1528139919825};\\\", \\\"{x:1244,y:952,t:1528139919895};\\\", \\\"{x:1243,y:954,t:1528139919909};\\\", \\\"{x:1243,y:955,t:1528139919936};\\\", \\\"{x:1242,y:956,t:1528139919959};\\\", \\\"{x:1241,y:958,t:1528139919991};\\\", \\\"{x:1240,y:960,t:1528139920009};\\\", \\\"{x:1239,y:960,t:1528139920026};\\\", \\\"{x:1239,y:961,t:1528139920063};\\\", \\\"{x:1239,y:962,t:1528139920216};\\\", \\\"{x:1239,y:963,t:1528139920232};\\\", \\\"{x:1240,y:963,t:1528139920242};\\\", \\\"{x:1241,y:964,t:1528139920296};\\\", \\\"{x:1242,y:964,t:1528139920663};\\\", \\\"{x:1243,y:964,t:1528139920676};\\\", \\\"{x:1245,y:965,t:1528139920693};\\\", \\\"{x:1246,y:965,t:1528139920710};\\\", \\\"{x:1247,y:966,t:1528139920727};\\\", \\\"{x:1247,y:967,t:1528139920800};\\\", \\\"{x:1248,y:967,t:1528139920824};\\\", \\\"{x:1247,y:961,t:1528139921264};\\\", \\\"{x:1243,y:948,t:1528139921277};\\\", \\\"{x:1239,y:924,t:1528139921293};\\\", \\\"{x:1226,y:885,t:1528139921311};\\\", \\\"{x:1204,y:829,t:1528139921328};\\\", \\\"{x:1190,y:798,t:1528139921344};\\\", \\\"{x:1180,y:778,t:1528139921360};\\\", \\\"{x:1175,y:766,t:1528139921377};\\\", \\\"{x:1174,y:763,t:1528139921395};\\\", \\\"{x:1173,y:759,t:1528139921411};\\\", \\\"{x:1172,y:755,t:1528139921427};\\\", \\\"{x:1171,y:752,t:1528139921445};\\\", \\\"{x:1171,y:751,t:1528139921471};\\\", \\\"{x:1171,y:752,t:1528139921744};\\\", \\\"{x:1172,y:757,t:1528139921762};\\\", \\\"{x:1175,y:762,t:1528139921777};\\\", \\\"{x:1178,y:770,t:1528139921794};\\\", \\\"{x:1185,y:782,t:1528139921811};\\\", \\\"{x:1192,y:794,t:1528139921828};\\\", \\\"{x:1195,y:801,t:1528139921845};\\\", \\\"{x:1198,y:807,t:1528139921861};\\\", \\\"{x:1201,y:814,t:1528139921877};\\\", \\\"{x:1206,y:823,t:1528139921894};\\\", \\\"{x:1215,y:840,t:1528139921911};\\\", \\\"{x:1220,y:847,t:1528139921928};\\\", \\\"{x:1225,y:854,t:1528139921944};\\\", \\\"{x:1230,y:859,t:1528139921962};\\\", \\\"{x:1234,y:863,t:1528139921977};\\\", \\\"{x:1236,y:869,t:1528139921994};\\\", \\\"{x:1240,y:875,t:1528139922012};\\\", \\\"{x:1242,y:881,t:1528139922027};\\\", \\\"{x:1245,y:885,t:1528139922044};\\\", \\\"{x:1247,y:888,t:1528139922061};\\\", \\\"{x:1241,y:887,t:1528139922144};\\\", \\\"{x:1208,y:866,t:1528139922162};\\\", \\\"{x:1133,y:812,t:1528139922178};\\\", \\\"{x:1022,y:735,t:1528139922194};\\\", \\\"{x:881,y:649,t:1528139922211};\\\", \\\"{x:733,y:559,t:1528139922228};\\\", \\\"{x:597,y:491,t:1528139922245};\\\", \\\"{x:481,y:438,t:1528139922261};\\\", \\\"{x:393,y:401,t:1528139922277};\\\", \\\"{x:361,y:393,t:1528139922289};\\\", \\\"{x:351,y:391,t:1528139922306};\\\", \\\"{x:351,y:390,t:1528139922366};\\\", \\\"{x:350,y:390,t:1528139922414};\\\", \\\"{x:345,y:390,t:1528139922423};\\\", \\\"{x:325,y:405,t:1528139922440};\\\", \\\"{x:311,y:420,t:1528139922457};\\\", \\\"{x:299,y:434,t:1528139922473};\\\", \\\"{x:288,y:455,t:1528139922489};\\\", \\\"{x:277,y:470,t:1528139922506};\\\", \\\"{x:268,y:481,t:1528139922522};\\\", \\\"{x:259,y:491,t:1528139922541};\\\", \\\"{x:250,y:498,t:1528139922557};\\\", \\\"{x:240,y:509,t:1528139922575};\\\", \\\"{x:239,y:511,t:1528139922591};\\\", \\\"{x:237,y:511,t:1528139922608};\\\", \\\"{x:236,y:511,t:1528139922625};\\\", \\\"{x:232,y:513,t:1528139922642};\\\", \\\"{x:230,y:513,t:1528139922664};\\\", \\\"{x:229,y:513,t:1528139922679};\\\", \\\"{x:227,y:513,t:1528139922692};\\\", \\\"{x:225,y:513,t:1528139922709};\\\", \\\"{x:225,y:512,t:1528139922728};\\\", \\\"{x:223,y:509,t:1528139922743};\\\", \\\"{x:222,y:506,t:1528139922759};\\\", \\\"{x:220,y:504,t:1528139922776};\\\", \\\"{x:219,y:504,t:1528139922793};\\\", \\\"{x:218,y:503,t:1528139922809};\\\", \\\"{x:217,y:503,t:1528139922839};\\\", \\\"{x:215,y:503,t:1528139922855};\\\", \\\"{x:213,y:503,t:1528139922863};\\\", \\\"{x:212,y:503,t:1528139922876};\\\", \\\"{x:201,y:503,t:1528139922893};\\\", \\\"{x:190,y:503,t:1528139922910};\\\", \\\"{x:175,y:503,t:1528139922927};\\\", \\\"{x:150,y:503,t:1528139922943};\\\", \\\"{x:135,y:501,t:1528139922959};\\\", \\\"{x:130,y:500,t:1528139922975};\\\", \\\"{x:127,y:498,t:1528139922992};\\\", \\\"{x:130,y:498,t:1528139923151};\\\", \\\"{x:131,y:498,t:1528139923160};\\\", \\\"{x:139,y:500,t:1528139923175};\\\", \\\"{x:142,y:501,t:1528139923193};\\\", \\\"{x:143,y:502,t:1528139923208};\\\", \\\"{x:144,y:502,t:1528139923232};\\\", \\\"{x:145,y:502,t:1528139923263};\\\", \\\"{x:148,y:502,t:1528139923280};\\\", \\\"{x:149,y:502,t:1528139923293};\\\", \\\"{x:152,y:503,t:1528139923309};\\\", \\\"{x:153,y:503,t:1528139923328};\\\", \\\"{x:153,y:504,t:1528139923703};\\\", \\\"{x:155,y:507,t:1528139923710};\\\", \\\"{x:174,y:520,t:1528139923726};\\\", \\\"{x:257,y:569,t:1528139923743};\\\", \\\"{x:317,y:597,t:1528139923760};\\\", \\\"{x:343,y:623,t:1528139923776};\\\", \\\"{x:407,y:655,t:1528139923793};\\\", \\\"{x:417,y:661,t:1528139923809};\\\", \\\"{x:417,y:664,t:1528139923825};\\\", \\\"{x:420,y:664,t:1528139923843};\\\", \\\"{x:417,y:664,t:1528139923927};\\\", \\\"{x:402,y:660,t:1528139923942};\\\", \\\"{x:381,y:651,t:1528139923960};\\\", \\\"{x:360,y:648,t:1528139923976};\\\", \\\"{x:350,y:646,t:1528139923993};\\\", \\\"{x:343,y:644,t:1528139924010};\\\", \\\"{x:342,y:644,t:1528139924026};\\\", \\\"{x:342,y:648,t:1528139924111};\\\", \\\"{x:346,y:652,t:1528139924127};\\\", \\\"{x:352,y:659,t:1528139924144};\\\", \\\"{x:361,y:667,t:1528139924162};\\\", \\\"{x:373,y:675,t:1528139924177};\\\", \\\"{x:388,y:687,t:1528139924193};\\\", \\\"{x:401,y:694,t:1528139924210};\\\", \\\"{x:408,y:699,t:1528139924226};\\\", \\\"{x:414,y:703,t:1528139924243};\\\", \\\"{x:416,y:706,t:1528139924260};\\\", \\\"{x:420,y:709,t:1528139924277};\\\", \\\"{x:427,y:713,t:1528139924294};\\\", \\\"{x:431,y:715,t:1528139924310};\\\", \\\"{x:434,y:717,t:1528139924328};\\\", \\\"{x:437,y:718,t:1528139924344};\\\", \\\"{x:441,y:719,t:1528139924362};\\\", \\\"{x:449,y:721,t:1528139924378};\\\", \\\"{x:461,y:726,t:1528139924392};\\\", \\\"{x:478,y:734,t:1528139924410};\\\", \\\"{x:491,y:739,t:1528139924426};\\\", \\\"{x:504,y:743,t:1528139924443};\\\", \\\"{x:515,y:746,t:1528139924459};\\\", \\\"{x:524,y:749,t:1528139924476};\\\", \\\"{x:530,y:751,t:1528139924493};\\\", \\\"{x:535,y:752,t:1528139924509};\\\", \\\"{x:538,y:753,t:1528139924527};\\\", \\\"{x:537,y:753,t:1528139924854};\\\", \\\"{x:536,y:751,t:1528139924863};\\\", \\\"{x:535,y:750,t:1528139924877};\\\", \\\"{x:534,y:746,t:1528139924894};\\\", \\\"{x:531,y:743,t:1528139924909};\\\", \\\"{x:529,y:741,t:1528139924927};\\\", \\\"{x:528,y:740,t:1528139924944};\\\", \\\"{x:527,y:740,t:1528139924961};\\\", \\\"{x:527,y:738,t:1528139924977};\\\", \\\"{x:526,y:736,t:1528139924994};\\\", \\\"{x:526,y:735,t:1528139925011};\\\", \\\"{x:526,y:732,t:1528139925027};\\\", \\\"{x:525,y:726,t:1528139925044};\\\", \\\"{x:525,y:721,t:1528139925061};\\\", \\\"{x:524,y:709,t:1528139925077};\\\", \\\"{x:522,y:688,t:1528139925094};\\\", \\\"{x:521,y:686,t:1528139925111};\\\", \\\"{x:521,y:685,t:1528139925423};\\\" ] }, { \\\"rt\\\": 9695, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 875582, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:683,t:1528139927544};\\\", \\\"{x:525,y:682,t:1528139927551};\\\", \\\"{x:533,y:678,t:1528139927562};\\\", \\\"{x:538,y:677,t:1528139927578};\\\", \\\"{x:542,y:675,t:1528139927596};\\\", \\\"{x:545,y:674,t:1528139927612};\\\", \\\"{x:548,y:672,t:1528139927629};\\\", \\\"{x:554,y:669,t:1528139927646};\\\", \\\"{x:562,y:666,t:1528139927662};\\\", \\\"{x:576,y:660,t:1528139927679};\\\", \\\"{x:588,y:655,t:1528139927696};\\\", \\\"{x:602,y:648,t:1528139927713};\\\", \\\"{x:617,y:641,t:1528139927729};\\\", \\\"{x:631,y:631,t:1528139927747};\\\", \\\"{x:641,y:622,t:1528139927763};\\\", \\\"{x:682,y:604,t:1528139927796};\\\", \\\"{x:708,y:594,t:1528139927813};\\\", \\\"{x:735,y:590,t:1528139927830};\\\", \\\"{x:756,y:588,t:1528139927846};\\\", \\\"{x:811,y:591,t:1528139927862};\\\", \\\"{x:862,y:599,t:1528139927879};\\\", \\\"{x:888,y:604,t:1528139927896};\\\", \\\"{x:915,y:608,t:1528139927913};\\\", \\\"{x:951,y:618,t:1528139927930};\\\", \\\"{x:977,y:626,t:1528139927946};\\\", \\\"{x:1002,y:633,t:1528139927963};\\\", \\\"{x:1021,y:640,t:1528139927979};\\\", \\\"{x:1039,y:649,t:1528139927995};\\\", \\\"{x:1051,y:654,t:1528139928013};\\\", \\\"{x:1056,y:656,t:1528139928030};\\\", \\\"{x:1057,y:657,t:1528139928046};\\\", \\\"{x:1056,y:658,t:1528139928615};\\\", \\\"{x:1055,y:659,t:1528139928630};\\\", \\\"{x:1056,y:669,t:1528139928645};\\\", \\\"{x:1057,y:678,t:1528139928663};\\\", \\\"{x:1059,y:682,t:1528139928680};\\\", \\\"{x:1061,y:686,t:1528139928696};\\\", \\\"{x:1064,y:689,t:1528139928713};\\\", \\\"{x:1069,y:696,t:1528139928730};\\\", \\\"{x:1076,y:704,t:1528139928746};\\\", \\\"{x:1084,y:713,t:1528139928764};\\\", \\\"{x:1104,y:729,t:1528139928780};\\\", \\\"{x:1123,y:742,t:1528139928797};\\\", \\\"{x:1141,y:753,t:1528139928813};\\\", \\\"{x:1157,y:763,t:1528139928831};\\\", \\\"{x:1186,y:778,t:1528139928848};\\\", \\\"{x:1209,y:785,t:1528139928864};\\\", \\\"{x:1229,y:792,t:1528139928881};\\\", \\\"{x:1241,y:797,t:1528139928896};\\\", \\\"{x:1253,y:801,t:1528139928913};\\\", \\\"{x:1255,y:801,t:1528139928930};\\\", \\\"{x:1257,y:801,t:1528139928947};\\\", \\\"{x:1257,y:802,t:1528139928963};\\\", \\\"{x:1259,y:803,t:1528139928981};\\\", \\\"{x:1261,y:812,t:1528139928997};\\\", \\\"{x:1267,y:840,t:1528139929014};\\\", \\\"{x:1270,y:869,t:1528139929031};\\\", \\\"{x:1270,y:885,t:1528139929047};\\\", \\\"{x:1267,y:893,t:1528139929063};\\\", \\\"{x:1264,y:897,t:1528139929080};\\\", \\\"{x:1262,y:898,t:1528139929097};\\\", \\\"{x:1261,y:898,t:1528139929113};\\\", \\\"{x:1261,y:899,t:1528139929130};\\\", \\\"{x:1266,y:891,t:1528139929375};\\\", \\\"{x:1270,y:885,t:1528139929383};\\\", \\\"{x:1273,y:879,t:1528139929398};\\\", \\\"{x:1278,y:870,t:1528139929414};\\\", \\\"{x:1285,y:862,t:1528139929431};\\\", \\\"{x:1290,y:856,t:1528139929448};\\\", \\\"{x:1291,y:854,t:1528139929463};\\\", \\\"{x:1293,y:851,t:1528139929480};\\\", \\\"{x:1296,y:846,t:1528139929497};\\\", \\\"{x:1297,y:843,t:1528139929513};\\\", \\\"{x:1299,y:840,t:1528139929530};\\\", \\\"{x:1300,y:838,t:1528139929547};\\\", \\\"{x:1301,y:836,t:1528139929563};\\\", \\\"{x:1302,y:832,t:1528139929581};\\\", \\\"{x:1304,y:825,t:1528139929597};\\\", \\\"{x:1305,y:816,t:1528139929613};\\\", \\\"{x:1309,y:807,t:1528139929630};\\\", \\\"{x:1314,y:783,t:1528139929647};\\\", \\\"{x:1319,y:764,t:1528139929663};\\\", \\\"{x:1321,y:744,t:1528139929680};\\\", \\\"{x:1324,y:729,t:1528139929698};\\\", \\\"{x:1326,y:726,t:1528139929713};\\\", \\\"{x:1326,y:724,t:1528139929729};\\\", \\\"{x:1326,y:722,t:1528139929747};\\\", \\\"{x:1326,y:721,t:1528139929763};\\\", \\\"{x:1329,y:717,t:1528139929780};\\\", \\\"{x:1332,y:714,t:1528139929797};\\\", \\\"{x:1334,y:712,t:1528139929813};\\\", \\\"{x:1336,y:709,t:1528139929830};\\\", \\\"{x:1338,y:706,t:1528139929846};\\\", \\\"{x:1339,y:706,t:1528139929982};\\\", \\\"{x:1339,y:705,t:1528139930015};\\\", \\\"{x:1339,y:703,t:1528139930030};\\\", \\\"{x:1344,y:695,t:1528139930047};\\\", \\\"{x:1346,y:692,t:1528139930064};\\\", \\\"{x:1347,y:692,t:1528139930288};\\\", \\\"{x:1349,y:691,t:1528139930304};\\\", \\\"{x:1350,y:690,t:1528139930315};\\\", \\\"{x:1353,y:688,t:1528139930330};\\\", \\\"{x:1354,y:688,t:1528139930352};\\\", \\\"{x:1356,y:688,t:1528139930464};\\\", \\\"{x:1357,y:690,t:1528139930481};\\\", \\\"{x:1358,y:692,t:1528139930498};\\\", \\\"{x:1360,y:694,t:1528139930515};\\\", \\\"{x:1360,y:695,t:1528139930535};\\\", \\\"{x:1360,y:696,t:1528139930548};\\\", \\\"{x:1359,y:697,t:1528139930664};\\\", \\\"{x:1358,y:697,t:1528139930703};\\\", \\\"{x:1356,y:697,t:1528139930714};\\\", \\\"{x:1354,y:697,t:1528139930730};\\\", \\\"{x:1351,y:696,t:1528139930748};\\\", \\\"{x:1349,y:694,t:1528139930764};\\\", \\\"{x:1348,y:692,t:1528139930781};\\\", \\\"{x:1347,y:691,t:1528139930798};\\\", \\\"{x:1345,y:690,t:1528139930814};\\\", \\\"{x:1344,y:687,t:1528139930830};\\\", \\\"{x:1340,y:678,t:1528139930848};\\\", \\\"{x:1337,y:673,t:1528139930865};\\\", \\\"{x:1334,y:667,t:1528139930881};\\\", \\\"{x:1332,y:663,t:1528139930897};\\\", \\\"{x:1330,y:660,t:1528139930915};\\\", \\\"{x:1330,y:658,t:1528139930931};\\\", \\\"{x:1329,y:656,t:1528139930948};\\\", \\\"{x:1327,y:654,t:1528139930964};\\\", \\\"{x:1326,y:652,t:1528139930980};\\\", \\\"{x:1325,y:651,t:1528139930996};\\\", \\\"{x:1324,y:649,t:1528139931014};\\\", \\\"{x:1320,y:644,t:1528139931031};\\\", \\\"{x:1319,y:641,t:1528139931047};\\\", \\\"{x:1318,y:640,t:1528139931064};\\\", \\\"{x:1318,y:641,t:1528139931416};\\\", \\\"{x:1321,y:648,t:1528139931431};\\\", \\\"{x:1335,y:668,t:1528139931447};\\\", \\\"{x:1343,y:680,t:1528139931465};\\\", \\\"{x:1352,y:691,t:1528139931482};\\\", \\\"{x:1360,y:702,t:1528139931498};\\\", \\\"{x:1365,y:709,t:1528139931514};\\\", \\\"{x:1369,y:712,t:1528139931531};\\\", \\\"{x:1371,y:715,t:1528139931548};\\\", \\\"{x:1373,y:718,t:1528139931564};\\\", \\\"{x:1373,y:719,t:1528139931582};\\\", \\\"{x:1374,y:721,t:1528139931598};\\\", \\\"{x:1375,y:725,t:1528139931614};\\\", \\\"{x:1379,y:735,t:1528139931631};\\\", \\\"{x:1381,y:738,t:1528139931648};\\\", \\\"{x:1383,y:744,t:1528139931665};\\\", \\\"{x:1387,y:749,t:1528139931681};\\\", \\\"{x:1389,y:754,t:1528139931698};\\\", \\\"{x:1393,y:760,t:1528139931714};\\\", \\\"{x:1395,y:763,t:1528139931732};\\\", \\\"{x:1397,y:766,t:1528139931748};\\\", \\\"{x:1398,y:770,t:1528139931764};\\\", \\\"{x:1399,y:772,t:1528139931782};\\\", \\\"{x:1401,y:775,t:1528139931798};\\\", \\\"{x:1402,y:776,t:1528139931815};\\\", \\\"{x:1404,y:778,t:1528139931831};\\\", \\\"{x:1406,y:780,t:1528139931848};\\\", \\\"{x:1407,y:782,t:1528139931865};\\\", \\\"{x:1408,y:785,t:1528139931882};\\\", \\\"{x:1409,y:787,t:1528139931897};\\\", \\\"{x:1409,y:788,t:1528139931919};\\\", \\\"{x:1410,y:789,t:1528139931932};\\\", \\\"{x:1411,y:791,t:1528139931948};\\\", \\\"{x:1411,y:794,t:1528139931965};\\\", \\\"{x:1411,y:796,t:1528139931982};\\\", \\\"{x:1413,y:798,t:1528139931998};\\\", \\\"{x:1413,y:800,t:1528139932080};\\\", \\\"{x:1410,y:800,t:1528139932087};\\\", \\\"{x:1409,y:800,t:1528139932098};\\\", \\\"{x:1401,y:799,t:1528139932115};\\\", \\\"{x:1374,y:792,t:1528139932131};\\\", \\\"{x:1326,y:776,t:1528139932149};\\\", \\\"{x:1274,y:757,t:1528139932165};\\\", \\\"{x:1194,y:736,t:1528139932181};\\\", \\\"{x:1142,y:722,t:1528139932199};\\\", \\\"{x:1048,y:697,t:1528139932215};\\\", \\\"{x:894,y:661,t:1528139932231};\\\", \\\"{x:797,y:652,t:1528139932248};\\\", \\\"{x:711,y:638,t:1528139932265};\\\", \\\"{x:640,y:620,t:1528139932283};\\\", \\\"{x:584,y:606,t:1528139932298};\\\", \\\"{x:543,y:596,t:1528139932315};\\\", \\\"{x:516,y:588,t:1528139932334};\\\", \\\"{x:498,y:583,t:1528139932350};\\\", \\\"{x:477,y:578,t:1528139932366};\\\", \\\"{x:445,y:569,t:1528139932383};\\\", \\\"{x:426,y:564,t:1528139932400};\\\", \\\"{x:417,y:561,t:1528139932416};\\\", \\\"{x:413,y:560,t:1528139932433};\\\", \\\"{x:409,y:559,t:1528139932450};\\\", \\\"{x:401,y:556,t:1528139932466};\\\", \\\"{x:400,y:555,t:1528139932483};\\\", \\\"{x:397,y:554,t:1528139932500};\\\", \\\"{x:394,y:552,t:1528139932516};\\\", \\\"{x:389,y:550,t:1528139932534};\\\", \\\"{x:384,y:549,t:1528139932550};\\\", \\\"{x:382,y:549,t:1528139932566};\\\", \\\"{x:381,y:549,t:1528139932583};\\\", \\\"{x:380,y:549,t:1528139932615};\\\", \\\"{x:379,y:548,t:1528139932663};\\\", \\\"{x:381,y:548,t:1528139932671};\\\", \\\"{x:385,y:548,t:1528139932683};\\\", \\\"{x:393,y:543,t:1528139932701};\\\", \\\"{x:406,y:539,t:1528139932717};\\\", \\\"{x:419,y:534,t:1528139932734};\\\", \\\"{x:433,y:529,t:1528139932750};\\\", \\\"{x:461,y:518,t:1528139932766};\\\", \\\"{x:474,y:512,t:1528139932784};\\\", \\\"{x:485,y:507,t:1528139932800};\\\", \\\"{x:492,y:504,t:1528139932816};\\\", \\\"{x:504,y:503,t:1528139932834};\\\", \\\"{x:516,y:503,t:1528139932850};\\\", \\\"{x:528,y:502,t:1528139932866};\\\", \\\"{x:533,y:500,t:1528139932883};\\\", \\\"{x:539,y:498,t:1528139932900};\\\", \\\"{x:546,y:495,t:1528139932916};\\\", \\\"{x:553,y:491,t:1528139932933};\\\", \\\"{x:557,y:491,t:1528139932950};\\\", \\\"{x:565,y:490,t:1528139932966};\\\", \\\"{x:572,y:490,t:1528139932983};\\\", \\\"{x:573,y:490,t:1528139933000};\\\", \\\"{x:573,y:492,t:1528139933023};\\\", \\\"{x:573,y:494,t:1528139933033};\\\", \\\"{x:577,y:498,t:1528139933050};\\\", \\\"{x:580,y:502,t:1528139933066};\\\", \\\"{x:583,y:503,t:1528139933084};\\\", \\\"{x:587,y:505,t:1528139933099};\\\", \\\"{x:589,y:506,t:1528139933116};\\\", \\\"{x:593,y:508,t:1528139933134};\\\", \\\"{x:594,y:508,t:1528139933149};\\\", \\\"{x:595,y:508,t:1528139933175};\\\", \\\"{x:595,y:509,t:1528139933183};\\\", \\\"{x:596,y:509,t:1528139933200};\\\", \\\"{x:598,y:509,t:1528139933216};\\\", \\\"{x:599,y:509,t:1528139933233};\\\", \\\"{x:600,y:510,t:1528139933688};\\\", \\\"{x:600,y:522,t:1528139933700};\\\", \\\"{x:600,y:554,t:1528139933718};\\\", \\\"{x:596,y:588,t:1528139933735};\\\", \\\"{x:587,y:621,t:1528139933751};\\\", \\\"{x:582,y:649,t:1528139933768};\\\", \\\"{x:582,y:651,t:1528139933784};\\\", \\\"{x:582,y:655,t:1528139933800};\\\", \\\"{x:582,y:657,t:1528139933817};\\\", \\\"{x:582,y:662,t:1528139933834};\\\", \\\"{x:582,y:673,t:1528139933851};\\\", \\\"{x:581,y:679,t:1528139933867};\\\", \\\"{x:579,y:684,t:1528139933884};\\\", \\\"{x:579,y:686,t:1528139933902};\\\", \\\"{x:579,y:683,t:1528139933942};\\\", \\\"{x:579,y:675,t:1528139933951};\\\", \\\"{x:579,y:653,t:1528139933967};\\\", \\\"{x:579,y:623,t:1528139933984};\\\", \\\"{x:590,y:571,t:1528139934001};\\\", \\\"{x:594,y:542,t:1528139934018};\\\", \\\"{x:598,y:521,t:1528139934035};\\\", \\\"{x:601,y:509,t:1528139934051};\\\", \\\"{x:601,y:505,t:1528139934067};\\\", \\\"{x:602,y:502,t:1528139934084};\\\", \\\"{x:602,y:499,t:1528139934101};\\\", \\\"{x:603,y:498,t:1528139934117};\\\", \\\"{x:603,y:497,t:1528139934134};\\\", \\\"{x:603,y:495,t:1528139934150};\\\", \\\"{x:604,y:495,t:1528139934199};\\\", \\\"{x:605,y:495,t:1528139934672};\\\", \\\"{x:605,y:496,t:1528139934734};\\\", \\\"{x:606,y:498,t:1528139934751};\\\", \\\"{x:606,y:503,t:1528139934768};\\\", \\\"{x:608,y:509,t:1528139934785};\\\", \\\"{x:608,y:516,t:1528139934802};\\\", \\\"{x:610,y:527,t:1528139934819};\\\", \\\"{x:610,y:542,t:1528139934835};\\\", \\\"{x:610,y:555,t:1528139934851};\\\", \\\"{x:608,y:568,t:1528139934869};\\\", \\\"{x:606,y:580,t:1528139934885};\\\", \\\"{x:602,y:588,t:1528139934901};\\\", \\\"{x:596,y:600,t:1528139934919};\\\", \\\"{x:593,y:606,t:1528139934935};\\\", \\\"{x:592,y:614,t:1528139934951};\\\", \\\"{x:592,y:621,t:1528139934968};\\\", \\\"{x:591,y:629,t:1528139934985};\\\", \\\"{x:589,y:634,t:1528139935002};\\\", \\\"{x:587,y:640,t:1528139935018};\\\", \\\"{x:586,y:644,t:1528139935035};\\\", \\\"{x:584,y:649,t:1528139935052};\\\", \\\"{x:581,y:655,t:1528139935068};\\\", \\\"{x:576,y:665,t:1528139935085};\\\", \\\"{x:570,y:680,t:1528139935102};\\\", \\\"{x:562,y:691,t:1528139935118};\\\", \\\"{x:549,y:707,t:1528139935135};\\\", \\\"{x:541,y:716,t:1528139935153};\\\", \\\"{x:538,y:719,t:1528139935169};\\\", \\\"{x:536,y:720,t:1528139935187};\\\", \\\"{x:535,y:720,t:1528139935246};\\\", \\\"{x:534,y:721,t:1528139935262};\\\", \\\"{x:533,y:722,t:1528139935294};\\\", \\\"{x:533,y:723,t:1528139935302};\\\", \\\"{x:531,y:724,t:1528139935319};\\\", \\\"{x:526,y:726,t:1528139935336};\\\", \\\"{x:520,y:732,t:1528139935352};\\\", \\\"{x:515,y:736,t:1528139935369};\\\", \\\"{x:508,y:739,t:1528139935385};\\\", \\\"{x:505,y:740,t:1528139935403};\\\", \\\"{x:504,y:740,t:1528139935419};\\\", \\\"{x:502,y:740,t:1528139935518};\\\" ] }, { \\\"rt\\\": 8303, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 885099, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:734,t:1528139937799};\\\", \\\"{x:496,y:728,t:1528139937809};\\\", \\\"{x:487,y:717,t:1528139937823};\\\", \\\"{x:481,y:704,t:1528139937838};\\\", \\\"{x:469,y:683,t:1528139937855};\\\", \\\"{x:459,y:663,t:1528139937870};\\\", \\\"{x:451,y:643,t:1528139937887};\\\", \\\"{x:447,y:632,t:1528139937904};\\\", \\\"{x:441,y:617,t:1528139937921};\\\", \\\"{x:438,y:607,t:1528139937937};\\\", \\\"{x:437,y:599,t:1528139937955};\\\", \\\"{x:433,y:589,t:1528139937971};\\\", \\\"{x:432,y:580,t:1528139937987};\\\", \\\"{x:431,y:574,t:1528139938004};\\\", \\\"{x:431,y:569,t:1528139938020};\\\", \\\"{x:431,y:565,t:1528139938037};\\\", \\\"{x:431,y:558,t:1528139938055};\\\", \\\"{x:431,y:552,t:1528139938071};\\\", \\\"{x:431,y:547,t:1528139938087};\\\", \\\"{x:431,y:543,t:1528139938104};\\\", \\\"{x:431,y:537,t:1528139938120};\\\", \\\"{x:433,y:533,t:1528139938137};\\\", \\\"{x:435,y:526,t:1528139938154};\\\", \\\"{x:439,y:521,t:1528139938172};\\\", \\\"{x:442,y:516,t:1528139938189};\\\", \\\"{x:446,y:512,t:1528139938204};\\\", \\\"{x:447,y:510,t:1528139938221};\\\", \\\"{x:449,y:507,t:1528139938237};\\\", \\\"{x:450,y:504,t:1528139938255};\\\", \\\"{x:452,y:501,t:1528139938270};\\\", \\\"{x:454,y:500,t:1528139938287};\\\", \\\"{x:456,y:496,t:1528139938304};\\\", \\\"{x:460,y:493,t:1528139938321};\\\", \\\"{x:462,y:492,t:1528139938337};\\\", \\\"{x:466,y:489,t:1528139938354};\\\", \\\"{x:467,y:488,t:1528139938371};\\\", \\\"{x:468,y:488,t:1528139938388};\\\", \\\"{x:475,y:484,t:1528139938406};\\\", \\\"{x:478,y:484,t:1528139938421};\\\", \\\"{x:487,y:483,t:1528139938438};\\\", \\\"{x:503,y:480,t:1528139938455};\\\", \\\"{x:513,y:479,t:1528139938472};\\\", \\\"{x:526,y:479,t:1528139938488};\\\", \\\"{x:535,y:479,t:1528139938504};\\\", \\\"{x:544,y:479,t:1528139938520};\\\", \\\"{x:553,y:479,t:1528139938538};\\\", \\\"{x:561,y:479,t:1528139938555};\\\", \\\"{x:567,y:479,t:1528139938570};\\\", \\\"{x:570,y:479,t:1528139938588};\\\", \\\"{x:572,y:480,t:1528139938605};\\\", \\\"{x:573,y:480,t:1528139938660};\\\", \\\"{x:574,y:481,t:1528139938759};\\\", \\\"{x:575,y:481,t:1528139938807};\\\", \\\"{x:577,y:482,t:1528139938822};\\\", \\\"{x:579,y:484,t:1528139938837};\\\", \\\"{x:589,y:488,t:1528139938856};\\\", \\\"{x:598,y:493,t:1528139938870};\\\", \\\"{x:618,y:501,t:1528139938888};\\\", \\\"{x:642,y:509,t:1528139938905};\\\", \\\"{x:674,y:517,t:1528139938922};\\\", \\\"{x:740,y:537,t:1528139938939};\\\", \\\"{x:810,y:550,t:1528139938955};\\\", \\\"{x:841,y:556,t:1528139938972};\\\", \\\"{x:850,y:554,t:1528139938988};\\\", \\\"{x:851,y:553,t:1528139939006};\\\", \\\"{x:853,y:554,t:1528139939021};\\\", \\\"{x:854,y:555,t:1528139939648};\\\", \\\"{x:855,y:556,t:1528139939658};\\\", \\\"{x:865,y:563,t:1528139939674};\\\", \\\"{x:877,y:568,t:1528139939689};\\\", \\\"{x:883,y:574,t:1528139939705};\\\", \\\"{x:903,y:580,t:1528139939722};\\\", \\\"{x:915,y:588,t:1528139939739};\\\", \\\"{x:928,y:594,t:1528139939756};\\\", \\\"{x:938,y:602,t:1528139939773};\\\", \\\"{x:952,y:610,t:1528139939789};\\\", \\\"{x:971,y:621,t:1528139939805};\\\", \\\"{x:1001,y:647,t:1528139939822};\\\", \\\"{x:1017,y:661,t:1528139939839};\\\", \\\"{x:1034,y:678,t:1528139939855};\\\", \\\"{x:1048,y:695,t:1528139939872};\\\", \\\"{x:1064,y:710,t:1528139939889};\\\", \\\"{x:1083,y:729,t:1528139939905};\\\", \\\"{x:1100,y:746,t:1528139939923};\\\", \\\"{x:1114,y:762,t:1528139939940};\\\", \\\"{x:1126,y:774,t:1528139939956};\\\", \\\"{x:1146,y:795,t:1528139939973};\\\", \\\"{x:1170,y:814,t:1528139939989};\\\", \\\"{x:1194,y:834,t:1528139940005};\\\", \\\"{x:1229,y:860,t:1528139940023};\\\", \\\"{x:1241,y:875,t:1528139940040};\\\", \\\"{x:1250,y:883,t:1528139940055};\\\", \\\"{x:1261,y:891,t:1528139940072};\\\", \\\"{x:1264,y:895,t:1528139940090};\\\", \\\"{x:1271,y:902,t:1528139940106};\\\", \\\"{x:1278,y:908,t:1528139940123};\\\", \\\"{x:1286,y:914,t:1528139940139};\\\", \\\"{x:1293,y:920,t:1528139940156};\\\", \\\"{x:1297,y:922,t:1528139940173};\\\", \\\"{x:1297,y:923,t:1528139940199};\\\", \\\"{x:1298,y:924,t:1528139940207};\\\", \\\"{x:1300,y:927,t:1528139940247};\\\", \\\"{x:1303,y:933,t:1528139940257};\\\", \\\"{x:1309,y:945,t:1528139940273};\\\", \\\"{x:1317,y:950,t:1528139940290};\\\", \\\"{x:1320,y:957,t:1528139940306};\\\", \\\"{x:1324,y:962,t:1528139940323};\\\", \\\"{x:1327,y:965,t:1528139940340};\\\", \\\"{x:1329,y:968,t:1528139940357};\\\", \\\"{x:1332,y:971,t:1528139940373};\\\", \\\"{x:1334,y:974,t:1528139940390};\\\", \\\"{x:1339,y:975,t:1528139940408};\\\", \\\"{x:1340,y:976,t:1528139940423};\\\", \\\"{x:1341,y:976,t:1528139940472};\\\", \\\"{x:1342,y:976,t:1528139940479};\\\", \\\"{x:1343,y:976,t:1528139940489};\\\", \\\"{x:1348,y:970,t:1528139940507};\\\", \\\"{x:1351,y:965,t:1528139940524};\\\", \\\"{x:1357,y:952,t:1528139940540};\\\", \\\"{x:1362,y:939,t:1528139940557};\\\", \\\"{x:1370,y:929,t:1528139940573};\\\", \\\"{x:1372,y:925,t:1528139940589};\\\", \\\"{x:1373,y:924,t:1528139940615};\\\", \\\"{x:1373,y:923,t:1528139940631};\\\", \\\"{x:1373,y:921,t:1528139940647};\\\", \\\"{x:1375,y:918,t:1528139940657};\\\", \\\"{x:1375,y:916,t:1528139940674};\\\", \\\"{x:1377,y:914,t:1528139940690};\\\", \\\"{x:1378,y:912,t:1528139940707};\\\", \\\"{x:1380,y:909,t:1528139940723};\\\", \\\"{x:1382,y:905,t:1528139940740};\\\", \\\"{x:1386,y:899,t:1528139940760};\\\", \\\"{x:1386,y:897,t:1528139940773};\\\", \\\"{x:1388,y:894,t:1528139940790};\\\", \\\"{x:1389,y:891,t:1528139940806};\\\", \\\"{x:1390,y:886,t:1528139940824};\\\", \\\"{x:1392,y:881,t:1528139940839};\\\", \\\"{x:1394,y:876,t:1528139940856};\\\", \\\"{x:1397,y:870,t:1528139940873};\\\", \\\"{x:1399,y:867,t:1528139940889};\\\", \\\"{x:1402,y:862,t:1528139940907};\\\", \\\"{x:1404,y:853,t:1528139940923};\\\", \\\"{x:1410,y:843,t:1528139940940};\\\", \\\"{x:1413,y:837,t:1528139940956};\\\", \\\"{x:1418,y:827,t:1528139940974};\\\", \\\"{x:1424,y:817,t:1528139940990};\\\", \\\"{x:1434,y:796,t:1528139941007};\\\", \\\"{x:1442,y:782,t:1528139941023};\\\", \\\"{x:1448,y:769,t:1528139941040};\\\", \\\"{x:1454,y:757,t:1528139941057};\\\", \\\"{x:1460,y:743,t:1528139941074};\\\", \\\"{x:1466,y:728,t:1528139941090};\\\", \\\"{x:1476,y:711,t:1528139941107};\\\", \\\"{x:1486,y:691,t:1528139941124};\\\", \\\"{x:1494,y:673,t:1528139941140};\\\", \\\"{x:1501,y:654,t:1528139941157};\\\", \\\"{x:1507,y:638,t:1528139941175};\\\", \\\"{x:1510,y:623,t:1528139941190};\\\", \\\"{x:1519,y:606,t:1528139941207};\\\", \\\"{x:1520,y:600,t:1528139941224};\\\", \\\"{x:1524,y:592,t:1528139941241};\\\", \\\"{x:1527,y:583,t:1528139941257};\\\", \\\"{x:1528,y:576,t:1528139941274};\\\", \\\"{x:1528,y:572,t:1528139941290};\\\", \\\"{x:1530,y:568,t:1528139941307};\\\", \\\"{x:1531,y:565,t:1528139941324};\\\", \\\"{x:1531,y:564,t:1528139941343};\\\", \\\"{x:1531,y:563,t:1528139941358};\\\", \\\"{x:1532,y:561,t:1528139941374};\\\", \\\"{x:1536,y:553,t:1528139941391};\\\", \\\"{x:1545,y:536,t:1528139941408};\\\", \\\"{x:1554,y:521,t:1528139941424};\\\", \\\"{x:1559,y:512,t:1528139941442};\\\", \\\"{x:1564,y:505,t:1528139941457};\\\", \\\"{x:1568,y:499,t:1528139941474};\\\", \\\"{x:1570,y:496,t:1528139941492};\\\", \\\"{x:1571,y:495,t:1528139941507};\\\", \\\"{x:1571,y:496,t:1528139941576};\\\", \\\"{x:1557,y:511,t:1528139941591};\\\", \\\"{x:1499,y:550,t:1528139941608};\\\", \\\"{x:1394,y:617,t:1528139941624};\\\", \\\"{x:1290,y:684,t:1528139941641};\\\", \\\"{x:1176,y:757,t:1528139941659};\\\", \\\"{x:1052,y:837,t:1528139941674};\\\", \\\"{x:938,y:899,t:1528139941691};\\\", \\\"{x:854,y:928,t:1528139941708};\\\", \\\"{x:787,y:938,t:1528139941723};\\\", \\\"{x:745,y:938,t:1528139941740};\\\", \\\"{x:694,y:931,t:1528139941758};\\\", \\\"{x:644,y:915,t:1528139941774};\\\", \\\"{x:549,y:889,t:1528139941792};\\\", \\\"{x:478,y:864,t:1528139941807};\\\", \\\"{x:417,y:846,t:1528139941824};\\\", \\\"{x:362,y:831,t:1528139941841};\\\", \\\"{x:337,y:822,t:1528139941858};\\\", \\\"{x:311,y:814,t:1528139941873};\\\", \\\"{x:292,y:806,t:1528139941891};\\\", \\\"{x:279,y:799,t:1528139941907};\\\", \\\"{x:274,y:797,t:1528139941924};\\\", \\\"{x:271,y:796,t:1528139941941};\\\", \\\"{x:270,y:795,t:1528139942159};\\\", \\\"{x:275,y:759,t:1528139942175};\\\", \\\"{x:284,y:724,t:1528139942191};\\\", \\\"{x:297,y:692,t:1528139942207};\\\", \\\"{x:310,y:659,t:1528139942226};\\\", \\\"{x:331,y:617,t:1528139942242};\\\", \\\"{x:352,y:567,t:1528139942258};\\\", \\\"{x:362,y:549,t:1528139942275};\\\", \\\"{x:369,y:537,t:1528139942290};\\\", \\\"{x:374,y:529,t:1528139942308};\\\", \\\"{x:376,y:524,t:1528139942325};\\\", \\\"{x:378,y:521,t:1528139942340};\\\", \\\"{x:378,y:519,t:1528139942358};\\\", \\\"{x:379,y:519,t:1528139942375};\\\", \\\"{x:384,y:519,t:1528139942470};\\\", \\\"{x:390,y:520,t:1528139942479};\\\", \\\"{x:391,y:520,t:1528139942495};\\\", \\\"{x:392,y:522,t:1528139942508};\\\", \\\"{x:394,y:530,t:1528139942526};\\\", \\\"{x:394,y:535,t:1528139942541};\\\", \\\"{x:394,y:538,t:1528139942557};\\\", \\\"{x:394,y:539,t:1528139942575};\\\", \\\"{x:392,y:540,t:1528139942662};\\\", \\\"{x:391,y:540,t:1528139942678};\\\", \\\"{x:389,y:540,t:1528139942694};\\\", \\\"{x:387,y:540,t:1528139942708};\\\", \\\"{x:384,y:540,t:1528139942724};\\\", \\\"{x:380,y:540,t:1528139942742};\\\", \\\"{x:378,y:540,t:1528139942758};\\\", \\\"{x:376,y:540,t:1528139942774};\\\", \\\"{x:375,y:540,t:1528139942793};\\\", \\\"{x:374,y:540,t:1528139942808};\\\", \\\"{x:373,y:540,t:1528139943094};\\\", \\\"{x:373,y:552,t:1528139943109};\\\", \\\"{x:374,y:592,t:1528139943125};\\\", \\\"{x:376,y:624,t:1528139943142};\\\", \\\"{x:376,y:666,t:1528139943158};\\\", \\\"{x:376,y:688,t:1528139943175};\\\", \\\"{x:376,y:696,t:1528139943192};\\\", \\\"{x:376,y:700,t:1528139943208};\\\", \\\"{x:376,y:701,t:1528139943246};\\\", \\\"{x:376,y:700,t:1528139943335};\\\", \\\"{x:376,y:694,t:1528139943343};\\\", \\\"{x:376,y:687,t:1528139943358};\\\", \\\"{x:382,y:668,t:1528139943375};\\\", \\\"{x:385,y:655,t:1528139943391};\\\", \\\"{x:389,y:646,t:1528139943408};\\\", \\\"{x:389,y:642,t:1528139943424};\\\", \\\"{x:389,y:640,t:1528139943511};\\\", \\\"{x:389,y:639,t:1528139943527};\\\", \\\"{x:389,y:635,t:1528139943542};\\\", \\\"{x:389,y:624,t:1528139943559};\\\", \\\"{x:388,y:616,t:1528139943575};\\\", \\\"{x:386,y:610,t:1528139943592};\\\", \\\"{x:386,y:607,t:1528139943609};\\\", \\\"{x:386,y:606,t:1528139943626};\\\", \\\"{x:387,y:610,t:1528139944608};\\\", \\\"{x:390,y:617,t:1528139944615};\\\", \\\"{x:394,y:623,t:1528139944626};\\\", \\\"{x:402,y:635,t:1528139944644};\\\", \\\"{x:408,y:644,t:1528139944660};\\\", \\\"{x:410,y:647,t:1528139944676};\\\", \\\"{x:413,y:653,t:1528139944692};\\\", \\\"{x:420,y:661,t:1528139944710};\\\", \\\"{x:424,y:667,t:1528139944726};\\\", \\\"{x:429,y:675,t:1528139944743};\\\", \\\"{x:432,y:678,t:1528139944759};\\\", \\\"{x:433,y:680,t:1528139944776};\\\", \\\"{x:434,y:683,t:1528139944792};\\\", \\\"{x:436,y:684,t:1528139944810};\\\", \\\"{x:438,y:686,t:1528139944826};\\\", \\\"{x:439,y:686,t:1528139944846};\\\", \\\"{x:440,y:687,t:1528139944860};\\\", \\\"{x:443,y:689,t:1528139944876};\\\", \\\"{x:446,y:691,t:1528139944893};\\\", \\\"{x:452,y:696,t:1528139944909};\\\", \\\"{x:456,y:697,t:1528139944926};\\\", \\\"{x:461,y:700,t:1528139944943};\\\", \\\"{x:465,y:701,t:1528139944959};\\\", \\\"{x:474,y:704,t:1528139944976};\\\", \\\"{x:483,y:709,t:1528139944993};\\\", \\\"{x:495,y:719,t:1528139945010};\\\", \\\"{x:506,y:729,t:1528139945028};\\\", \\\"{x:512,y:735,t:1528139945043};\\\", \\\"{x:517,y:741,t:1528139945060};\\\", \\\"{x:518,y:741,t:1528139945077};\\\", \\\"{x:518,y:742,t:1528139945968};\\\", \\\"{x:517,y:742,t:1528139946087};\\\" ] }, { \\\"rt\\\": 6647, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 893033, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-I -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:742,t:1528139946563};\\\", \\\"{x:517,y:735,t:1528139947367};\\\", \\\"{x:534,y:727,t:1528139947378};\\\", \\\"{x:604,y:708,t:1528139947396};\\\", \\\"{x:701,y:690,t:1528139947412};\\\", \\\"{x:803,y:682,t:1528139947429};\\\", \\\"{x:897,y:682,t:1528139947444};\\\", \\\"{x:981,y:683,t:1528139947462};\\\", \\\"{x:1057,y:693,t:1528139947478};\\\", \\\"{x:1083,y:696,t:1528139947495};\\\", \\\"{x:1105,y:699,t:1528139947512};\\\", \\\"{x:1116,y:702,t:1528139947529};\\\", \\\"{x:1117,y:702,t:1528139947544};\\\", \\\"{x:1118,y:702,t:1528139947607};\\\", \\\"{x:1119,y:702,t:1528139947615};\\\", \\\"{x:1123,y:704,t:1528139947629};\\\", \\\"{x:1135,y:716,t:1528139947646};\\\", \\\"{x:1148,y:726,t:1528139947662};\\\", \\\"{x:1168,y:746,t:1528139947679};\\\", \\\"{x:1183,y:765,t:1528139947698};\\\", \\\"{x:1194,y:779,t:1528139947712};\\\", \\\"{x:1204,y:795,t:1528139947729};\\\", \\\"{x:1213,y:810,t:1528139947745};\\\", \\\"{x:1221,y:823,t:1528139947762};\\\", \\\"{x:1226,y:832,t:1528139947778};\\\", \\\"{x:1228,y:836,t:1528139947796};\\\", \\\"{x:1233,y:848,t:1528139947811};\\\", \\\"{x:1240,y:860,t:1528139947828};\\\", \\\"{x:1251,y:875,t:1528139947846};\\\", \\\"{x:1262,y:885,t:1528139947862};\\\", \\\"{x:1283,y:896,t:1528139947879};\\\", \\\"{x:1302,y:903,t:1528139947896};\\\", \\\"{x:1317,y:909,t:1528139947912};\\\", \\\"{x:1342,y:912,t:1528139947929};\\\", \\\"{x:1380,y:912,t:1528139947946};\\\", \\\"{x:1412,y:912,t:1528139947962};\\\", \\\"{x:1438,y:912,t:1528139947979};\\\", \\\"{x:1457,y:910,t:1528139947996};\\\", \\\"{x:1477,y:903,t:1528139948013};\\\", \\\"{x:1498,y:895,t:1528139948029};\\\", \\\"{x:1503,y:891,t:1528139948046};\\\", \\\"{x:1506,y:883,t:1528139948062};\\\", \\\"{x:1504,y:865,t:1528139948079};\\\", \\\"{x:1493,y:851,t:1528139948096};\\\", \\\"{x:1483,y:839,t:1528139948112};\\\", \\\"{x:1468,y:824,t:1528139948129};\\\", \\\"{x:1453,y:809,t:1528139948147};\\\", \\\"{x:1435,y:791,t:1528139948162};\\\", \\\"{x:1408,y:769,t:1528139948179};\\\", \\\"{x:1388,y:754,t:1528139948197};\\\", \\\"{x:1377,y:747,t:1528139948212};\\\", \\\"{x:1369,y:743,t:1528139948229};\\\", \\\"{x:1366,y:741,t:1528139948246};\\\", \\\"{x:1365,y:741,t:1528139948263};\\\", \\\"{x:1364,y:741,t:1528139948320};\\\", \\\"{x:1363,y:740,t:1528139948368};\\\", \\\"{x:1362,y:740,t:1528139948416};\\\", \\\"{x:1361,y:737,t:1528139948430};\\\", \\\"{x:1356,y:733,t:1528139948447};\\\", \\\"{x:1353,y:731,t:1528139948463};\\\", \\\"{x:1350,y:731,t:1528139948479};\\\", \\\"{x:1346,y:731,t:1528139948496};\\\", \\\"{x:1337,y:731,t:1528139948513};\\\", \\\"{x:1327,y:738,t:1528139948530};\\\", \\\"{x:1314,y:751,t:1528139948547};\\\", \\\"{x:1302,y:767,t:1528139948563};\\\", \\\"{x:1290,y:781,t:1528139948580};\\\", \\\"{x:1282,y:792,t:1528139948596};\\\", \\\"{x:1273,y:802,t:1528139948613};\\\", \\\"{x:1267,y:808,t:1528139948630};\\\", \\\"{x:1266,y:810,t:1528139948647};\\\", \\\"{x:1263,y:816,t:1528139948663};\\\", \\\"{x:1262,y:821,t:1528139948680};\\\", \\\"{x:1259,y:827,t:1528139948696};\\\", \\\"{x:1258,y:833,t:1528139948713};\\\", \\\"{x:1256,y:838,t:1528139948730};\\\", \\\"{x:1247,y:854,t:1528139948747};\\\", \\\"{x:1240,y:868,t:1528139948764};\\\", \\\"{x:1231,y:883,t:1528139948780};\\\", \\\"{x:1226,y:896,t:1528139948797};\\\", \\\"{x:1223,y:905,t:1528139948813};\\\", \\\"{x:1222,y:909,t:1528139948830};\\\", \\\"{x:1220,y:912,t:1528139948846};\\\", \\\"{x:1220,y:915,t:1528139948864};\\\", \\\"{x:1220,y:916,t:1528139948880};\\\", \\\"{x:1219,y:917,t:1528139948896};\\\", \\\"{x:1219,y:908,t:1528139949000};\\\", \\\"{x:1221,y:900,t:1528139949014};\\\", \\\"{x:1232,y:878,t:1528139949031};\\\", \\\"{x:1249,y:851,t:1528139949047};\\\", \\\"{x:1258,y:836,t:1528139949063};\\\", \\\"{x:1266,y:825,t:1528139949080};\\\", \\\"{x:1272,y:816,t:1528139949097};\\\", \\\"{x:1274,y:810,t:1528139949114};\\\", \\\"{x:1282,y:800,t:1528139949130};\\\", \\\"{x:1293,y:788,t:1528139949148};\\\", \\\"{x:1299,y:780,t:1528139949163};\\\", \\\"{x:1307,y:771,t:1528139949181};\\\", \\\"{x:1309,y:768,t:1528139949197};\\\", \\\"{x:1310,y:768,t:1528139949214};\\\", \\\"{x:1310,y:766,t:1528139949230};\\\", \\\"{x:1311,y:765,t:1528139949256};\\\", \\\"{x:1311,y:763,t:1528139949304};\\\", \\\"{x:1312,y:762,t:1528139949313};\\\", \\\"{x:1313,y:760,t:1528139949330};\\\", \\\"{x:1314,y:757,t:1528139949347};\\\", \\\"{x:1314,y:756,t:1528139949363};\\\", \\\"{x:1316,y:752,t:1528139949380};\\\", \\\"{x:1320,y:747,t:1528139949397};\\\", \\\"{x:1323,y:740,t:1528139949413};\\\", \\\"{x:1325,y:738,t:1528139949430};\\\", \\\"{x:1328,y:729,t:1528139949446};\\\", \\\"{x:1329,y:726,t:1528139949463};\\\", \\\"{x:1331,y:722,t:1528139949480};\\\", \\\"{x:1332,y:717,t:1528139949497};\\\", \\\"{x:1335,y:711,t:1528139949514};\\\", \\\"{x:1337,y:705,t:1528139949530};\\\", \\\"{x:1340,y:701,t:1528139949547};\\\", \\\"{x:1341,y:698,t:1528139949563};\\\", \\\"{x:1343,y:696,t:1528139949580};\\\", \\\"{x:1344,y:694,t:1528139949597};\\\", \\\"{x:1346,y:691,t:1528139949616};\\\", \\\"{x:1349,y:688,t:1528139949630};\\\", \\\"{x:1353,y:685,t:1528139949647};\\\", \\\"{x:1353,y:684,t:1528139949664};\\\", \\\"{x:1354,y:683,t:1528139949680};\\\", \\\"{x:1355,y:681,t:1528139949697};\\\", \\\"{x:1356,y:679,t:1528139949727};\\\", \\\"{x:1357,y:678,t:1528139949743};\\\", \\\"{x:1357,y:677,t:1528139949751};\\\", \\\"{x:1358,y:676,t:1528139949767};\\\", \\\"{x:1358,y:675,t:1528139949780};\\\", \\\"{x:1359,y:674,t:1528139949798};\\\", \\\"{x:1360,y:674,t:1528139949815};\\\", \\\"{x:1360,y:672,t:1528139949831};\\\", \\\"{x:1363,y:667,t:1528139949847};\\\", \\\"{x:1367,y:662,t:1528139949864};\\\", \\\"{x:1369,y:657,t:1528139949880};\\\", \\\"{x:1372,y:655,t:1528139949898};\\\", \\\"{x:1376,y:653,t:1528139949915};\\\", \\\"{x:1378,y:650,t:1528139949930};\\\", \\\"{x:1379,y:648,t:1528139949948};\\\", \\\"{x:1380,y:647,t:1528139949965};\\\", \\\"{x:1381,y:645,t:1528139949981};\\\", \\\"{x:1382,y:644,t:1528139949998};\\\", \\\"{x:1382,y:643,t:1528139950015};\\\", \\\"{x:1384,y:641,t:1528139950031};\\\", \\\"{x:1385,y:638,t:1528139950048};\\\", \\\"{x:1387,y:635,t:1528139950065};\\\", \\\"{x:1389,y:631,t:1528139950082};\\\", \\\"{x:1390,y:629,t:1528139950098};\\\", \\\"{x:1392,y:624,t:1528139950115};\\\", \\\"{x:1393,y:622,t:1528139950131};\\\", \\\"{x:1395,y:620,t:1528139950148};\\\", \\\"{x:1396,y:618,t:1528139950164};\\\", \\\"{x:1397,y:616,t:1528139950199};\\\", \\\"{x:1398,y:616,t:1528139950215};\\\", \\\"{x:1398,y:615,t:1528139950231};\\\", \\\"{x:1400,y:613,t:1528139950248};\\\", \\\"{x:1400,y:611,t:1528139950265};\\\", \\\"{x:1401,y:609,t:1528139950282};\\\", \\\"{x:1403,y:607,t:1528139950297};\\\", \\\"{x:1403,y:606,t:1528139950315};\\\", \\\"{x:1403,y:605,t:1528139950331};\\\", \\\"{x:1404,y:603,t:1528139950347};\\\", \\\"{x:1405,y:603,t:1528139950375};\\\", \\\"{x:1406,y:603,t:1528139950391};\\\", \\\"{x:1406,y:601,t:1528139950415};\\\", \\\"{x:1394,y:598,t:1528139950430};\\\", \\\"{x:1372,y:594,t:1528139950448};\\\", \\\"{x:1340,y:590,t:1528139950463};\\\", \\\"{x:1275,y:585,t:1528139950481};\\\", \\\"{x:1196,y:581,t:1528139950498};\\\", \\\"{x:1106,y:573,t:1528139950514};\\\", \\\"{x:1012,y:564,t:1528139950531};\\\", \\\"{x:920,y:550,t:1528139950549};\\\", \\\"{x:845,y:538,t:1528139950564};\\\", \\\"{x:782,y:533,t:1528139950581};\\\", \\\"{x:723,y:526,t:1528139950598};\\\", \\\"{x:679,y:526,t:1528139950614};\\\", \\\"{x:641,y:526,t:1528139950631};\\\", \\\"{x:622,y:526,t:1528139950648};\\\", \\\"{x:608,y:526,t:1528139950664};\\\", \\\"{x:598,y:528,t:1528139950681};\\\", \\\"{x:589,y:529,t:1528139950698};\\\", \\\"{x:580,y:530,t:1528139950714};\\\", \\\"{x:565,y:534,t:1528139950731};\\\", \\\"{x:549,y:540,t:1528139950748};\\\", \\\"{x:535,y:543,t:1528139950764};\\\", \\\"{x:518,y:546,t:1528139950781};\\\", \\\"{x:505,y:550,t:1528139950798};\\\", \\\"{x:494,y:552,t:1528139950816};\\\", \\\"{x:489,y:553,t:1528139950831};\\\", \\\"{x:487,y:554,t:1528139950848};\\\", \\\"{x:483,y:555,t:1528139950865};\\\", \\\"{x:480,y:556,t:1528139950883};\\\", \\\"{x:475,y:558,t:1528139950898};\\\", \\\"{x:467,y:558,t:1528139950914};\\\", \\\"{x:459,y:560,t:1528139950931};\\\", \\\"{x:448,y:560,t:1528139950947};\\\", \\\"{x:434,y:561,t:1528139950964};\\\", \\\"{x:415,y:561,t:1528139950981};\\\", \\\"{x:404,y:561,t:1528139950998};\\\", \\\"{x:378,y:561,t:1528139951015};\\\", \\\"{x:369,y:561,t:1528139951031};\\\", \\\"{x:362,y:561,t:1528139951048};\\\", \\\"{x:356,y:561,t:1528139951065};\\\", \\\"{x:352,y:562,t:1528139951081};\\\", \\\"{x:345,y:563,t:1528139951099};\\\", \\\"{x:340,y:564,t:1528139951115};\\\", \\\"{x:336,y:564,t:1528139951131};\\\", \\\"{x:339,y:564,t:1528139951199};\\\", \\\"{x:353,y:562,t:1528139951216};\\\", \\\"{x:369,y:553,t:1528139951232};\\\", \\\"{x:388,y:547,t:1528139951248};\\\", \\\"{x:403,y:538,t:1528139951265};\\\", \\\"{x:412,y:534,t:1528139951281};\\\", \\\"{x:416,y:533,t:1528139951298};\\\", \\\"{x:416,y:532,t:1528139951342};\\\", \\\"{x:418,y:532,t:1528139951350};\\\", \\\"{x:421,y:530,t:1528139951365};\\\", \\\"{x:434,y:528,t:1528139951381};\\\", \\\"{x:456,y:530,t:1528139951398};\\\", \\\"{x:488,y:530,t:1528139951414};\\\", \\\"{x:526,y:532,t:1528139951432};\\\", \\\"{x:565,y:532,t:1528139951448};\\\", \\\"{x:600,y:533,t:1528139951465};\\\", \\\"{x:630,y:538,t:1528139951482};\\\", \\\"{x:651,y:544,t:1528139951498};\\\", \\\"{x:667,y:548,t:1528139951515};\\\", \\\"{x:678,y:553,t:1528139951532};\\\", \\\"{x:682,y:554,t:1528139951548};\\\", \\\"{x:684,y:556,t:1528139951566};\\\", \\\"{x:685,y:556,t:1528139951679};\\\", \\\"{x:688,y:556,t:1528139951687};\\\", \\\"{x:693,y:556,t:1528139951699};\\\", \\\"{x:701,y:556,t:1528139951716};\\\", \\\"{x:711,y:556,t:1528139951732};\\\", \\\"{x:730,y:556,t:1528139951749};\\\", \\\"{x:749,y:556,t:1528139951765};\\\", \\\"{x:763,y:556,t:1528139951782};\\\", \\\"{x:765,y:556,t:1528139951798};\\\", \\\"{x:776,y:556,t:1528139951815};\\\", \\\"{x:779,y:556,t:1528139951832};\\\", \\\"{x:782,y:556,t:1528139951849};\\\", \\\"{x:787,y:556,t:1528139951866};\\\", \\\"{x:790,y:556,t:1528139951882};\\\", \\\"{x:791,y:556,t:1528139951899};\\\", \\\"{x:792,y:556,t:1528139951927};\\\", \\\"{x:793,y:555,t:1528139951936};\\\", \\\"{x:794,y:555,t:1528139951949};\\\", \\\"{x:797,y:554,t:1528139951966};\\\", \\\"{x:802,y:551,t:1528139951982};\\\", \\\"{x:807,y:550,t:1528139951998};\\\", \\\"{x:811,y:548,t:1528139952016};\\\", \\\"{x:815,y:547,t:1528139952031};\\\", \\\"{x:818,y:546,t:1528139952049};\\\", \\\"{x:819,y:545,t:1528139952066};\\\", \\\"{x:822,y:543,t:1528139952082};\\\", \\\"{x:824,y:543,t:1528139952100};\\\", \\\"{x:825,y:543,t:1528139952119};\\\", \\\"{x:826,y:544,t:1528139952494};\\\", \\\"{x:822,y:554,t:1528139952503};\\\", \\\"{x:817,y:558,t:1528139952516};\\\", \\\"{x:806,y:574,t:1528139952533};\\\", \\\"{x:789,y:594,t:1528139952549};\\\", \\\"{x:769,y:617,t:1528139952567};\\\", \\\"{x:743,y:640,t:1528139952583};\\\", \\\"{x:729,y:652,t:1528139952599};\\\", \\\"{x:719,y:661,t:1528139952616};\\\", \\\"{x:711,y:669,t:1528139952631};\\\", \\\"{x:707,y:671,t:1528139952649};\\\", \\\"{x:702,y:674,t:1528139952666};\\\", \\\"{x:697,y:679,t:1528139952682};\\\", \\\"{x:689,y:684,t:1528139952699};\\\", \\\"{x:674,y:694,t:1528139952716};\\\", \\\"{x:670,y:699,t:1528139952731};\\\", \\\"{x:659,y:705,t:1528139952749};\\\", \\\"{x:651,y:709,t:1528139952766};\\\", \\\"{x:646,y:711,t:1528139952782};\\\", \\\"{x:643,y:713,t:1528139952799};\\\", \\\"{x:641,y:714,t:1528139952816};\\\", \\\"{x:639,y:715,t:1528139952833};\\\", \\\"{x:638,y:715,t:1528139952850};\\\", \\\"{x:636,y:716,t:1528139952865};\\\", \\\"{x:632,y:717,t:1528139952882};\\\", \\\"{x:629,y:719,t:1528139952900};\\\", \\\"{x:621,y:721,t:1528139952915};\\\", \\\"{x:612,y:724,t:1528139952932};\\\", \\\"{x:599,y:727,t:1528139952949};\\\", \\\"{x:585,y:732,t:1528139952966};\\\", \\\"{x:562,y:739,t:1528139952984};\\\", \\\"{x:543,y:742,t:1528139952998};\\\", \\\"{x:530,y:742,t:1528139953015};\\\", \\\"{x:526,y:742,t:1528139953033};\\\", \\\"{x:523,y:742,t:1528139953050};\\\", \\\"{x:521,y:742,t:1528139953066};\\\", \\\"{x:520,y:742,t:1528139953528};\\\", \\\"{x:520,y:743,t:1528139953535};\\\", \\\"{x:518,y:743,t:1528139953550};\\\", \\\"{x:499,y:734,t:1528139953567};\\\", \\\"{x:497,y:724,t:1528139953583};\\\" ] }, { \\\"rt\\\": 15294, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 909603, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:722,t:1528139956208};\\\", \\\"{x:512,y:717,t:1528139956223};\\\", \\\"{x:586,y:712,t:1528139956237};\\\", \\\"{x:726,y:710,t:1528139956257};\\\", \\\"{x:773,y:710,t:1528139956269};\\\", \\\"{x:925,y:710,t:1528139956286};\\\", \\\"{x:1014,y:710,t:1528139956302};\\\", \\\"{x:1078,y:710,t:1528139956319};\\\", \\\"{x:1130,y:711,t:1528139956336};\\\", \\\"{x:1154,y:711,t:1528139956352};\\\", \\\"{x:1166,y:711,t:1528139956369};\\\", \\\"{x:1169,y:711,t:1528139956386};\\\", \\\"{x:1179,y:712,t:1528139956879};\\\", \\\"{x:1205,y:718,t:1528139956887};\\\", \\\"{x:1297,y:729,t:1528139956904};\\\", \\\"{x:1423,y:757,t:1528139956921};\\\", \\\"{x:1566,y:774,t:1528139956936};\\\", \\\"{x:1705,y:793,t:1528139956954};\\\", \\\"{x:1835,y:814,t:1528139956971};\\\", \\\"{x:1919,y:836,t:1528139956987};\\\", \\\"{x:1919,y:860,t:1528139957004};\\\", \\\"{x:1919,y:879,t:1528139957019};\\\", \\\"{x:1919,y:895,t:1528139957037};\\\", \\\"{x:1919,y:903,t:1528139957052};\\\", \\\"{x:1919,y:909,t:1528139957070};\\\", \\\"{x:1919,y:912,t:1528139957086};\\\", \\\"{x:1919,y:913,t:1528139957192};\\\", \\\"{x:1917,y:915,t:1528139957204};\\\", \\\"{x:1911,y:917,t:1528139957219};\\\", \\\"{x:1893,y:920,t:1528139957237};\\\", \\\"{x:1872,y:921,t:1528139957253};\\\", \\\"{x:1852,y:921,t:1528139957269};\\\", \\\"{x:1816,y:921,t:1528139957286};\\\", \\\"{x:1790,y:921,t:1528139957303};\\\", \\\"{x:1770,y:921,t:1528139957319};\\\", \\\"{x:1756,y:921,t:1528139957336};\\\", \\\"{x:1741,y:921,t:1528139957353};\\\", \\\"{x:1730,y:921,t:1528139957369};\\\", \\\"{x:1726,y:921,t:1528139957386};\\\", \\\"{x:1723,y:921,t:1528139957403};\\\", \\\"{x:1719,y:921,t:1528139957421};\\\", \\\"{x:1713,y:922,t:1528139957436};\\\", \\\"{x:1705,y:925,t:1528139957454};\\\", \\\"{x:1693,y:930,t:1528139957470};\\\", \\\"{x:1681,y:937,t:1528139957487};\\\", \\\"{x:1670,y:940,t:1528139957504};\\\", \\\"{x:1660,y:944,t:1528139957521};\\\", \\\"{x:1649,y:947,t:1528139957537};\\\", \\\"{x:1641,y:947,t:1528139957553};\\\", \\\"{x:1635,y:947,t:1528139957571};\\\", \\\"{x:1631,y:947,t:1528139957587};\\\", \\\"{x:1629,y:947,t:1528139957604};\\\", \\\"{x:1628,y:947,t:1528139957621};\\\", \\\"{x:1628,y:946,t:1528139957648};\\\", \\\"{x:1626,y:942,t:1528139957663};\\\", \\\"{x:1626,y:940,t:1528139957671};\\\", \\\"{x:1622,y:928,t:1528139957688};\\\", \\\"{x:1620,y:922,t:1528139957703};\\\", \\\"{x:1619,y:914,t:1528139957721};\\\", \\\"{x:1618,y:906,t:1528139957737};\\\", \\\"{x:1617,y:898,t:1528139957754};\\\", \\\"{x:1613,y:893,t:1528139957771};\\\", \\\"{x:1610,y:886,t:1528139957787};\\\", \\\"{x:1607,y:880,t:1528139957804};\\\", \\\"{x:1605,y:877,t:1528139957821};\\\", \\\"{x:1604,y:872,t:1528139957837};\\\", \\\"{x:1604,y:870,t:1528139957854};\\\", \\\"{x:1603,y:863,t:1528139957871};\\\", \\\"{x:1603,y:859,t:1528139957888};\\\", \\\"{x:1603,y:852,t:1528139957903};\\\", \\\"{x:1603,y:847,t:1528139957921};\\\", \\\"{x:1604,y:841,t:1528139957938};\\\", \\\"{x:1604,y:836,t:1528139957953};\\\", \\\"{x:1608,y:826,t:1528139957971};\\\", \\\"{x:1608,y:822,t:1528139957988};\\\", \\\"{x:1608,y:819,t:1528139958004};\\\", \\\"{x:1606,y:810,t:1528139958021};\\\", \\\"{x:1602,y:798,t:1528139958037};\\\", \\\"{x:1598,y:790,t:1528139958054};\\\", \\\"{x:1593,y:781,t:1528139958071};\\\", \\\"{x:1590,y:779,t:1528139958087};\\\", \\\"{x:1588,y:776,t:1528139958105};\\\", \\\"{x:1586,y:775,t:1528139958121};\\\", \\\"{x:1583,y:774,t:1528139958138};\\\", \\\"{x:1580,y:774,t:1528139958154};\\\", \\\"{x:1574,y:773,t:1528139958171};\\\", \\\"{x:1570,y:773,t:1528139958188};\\\", \\\"{x:1563,y:773,t:1528139958204};\\\", \\\"{x:1557,y:773,t:1528139958221};\\\", \\\"{x:1549,y:773,t:1528139958238};\\\", \\\"{x:1539,y:773,t:1528139958254};\\\", \\\"{x:1527,y:773,t:1528139958271};\\\", \\\"{x:1526,y:773,t:1528139958287};\\\", \\\"{x:1524,y:773,t:1528139958304};\\\", \\\"{x:1524,y:772,t:1528139958368};\\\", \\\"{x:1523,y:772,t:1528139958400};\\\", \\\"{x:1523,y:770,t:1528139958408};\\\", \\\"{x:1522,y:766,t:1528139958420};\\\", \\\"{x:1519,y:759,t:1528139958438};\\\", \\\"{x:1517,y:750,t:1528139958455};\\\", \\\"{x:1513,y:743,t:1528139958471};\\\", \\\"{x:1510,y:735,t:1528139958487};\\\", \\\"{x:1509,y:731,t:1528139958504};\\\", \\\"{x:1507,y:728,t:1528139958521};\\\", \\\"{x:1506,y:727,t:1528139958567};\\\", \\\"{x:1501,y:727,t:1528139958583};\\\", \\\"{x:1492,y:727,t:1528139958591};\\\", \\\"{x:1478,y:729,t:1528139958605};\\\", \\\"{x:1453,y:736,t:1528139958621};\\\", \\\"{x:1421,y:746,t:1528139958638};\\\", \\\"{x:1366,y:760,t:1528139958655};\\\", \\\"{x:1321,y:769,t:1528139958671};\\\", \\\"{x:1281,y:774,t:1528139958688};\\\", \\\"{x:1243,y:783,t:1528139958705};\\\", \\\"{x:1215,y:785,t:1528139958722};\\\", \\\"{x:1197,y:788,t:1528139958737};\\\", \\\"{x:1190,y:789,t:1528139958755};\\\", \\\"{x:1189,y:789,t:1528139958775};\\\", \\\"{x:1198,y:787,t:1528139959063};\\\", \\\"{x:1220,y:771,t:1528139959071};\\\", \\\"{x:1303,y:754,t:1528139959089};\\\", \\\"{x:1401,y:738,t:1528139959105};\\\", \\\"{x:1433,y:731,t:1528139959122};\\\", \\\"{x:1445,y:726,t:1528139959139};\\\", \\\"{x:1449,y:725,t:1528139959155};\\\", \\\"{x:1452,y:725,t:1528139959172};\\\", \\\"{x:1455,y:722,t:1528139959189};\\\", \\\"{x:1456,y:722,t:1528139959205};\\\", \\\"{x:1457,y:722,t:1528139959255};\\\", \\\"{x:1458,y:719,t:1528139959423};\\\", \\\"{x:1458,y:713,t:1528139959439};\\\", \\\"{x:1458,y:702,t:1528139959455};\\\", \\\"{x:1458,y:683,t:1528139959472};\\\", \\\"{x:1458,y:661,t:1528139959490};\\\", \\\"{x:1458,y:642,t:1528139959505};\\\", \\\"{x:1458,y:622,t:1528139959521};\\\", \\\"{x:1458,y:608,t:1528139959539};\\\", \\\"{x:1459,y:598,t:1528139959556};\\\", \\\"{x:1461,y:590,t:1528139959572};\\\", \\\"{x:1463,y:582,t:1528139959589};\\\", \\\"{x:1465,y:577,t:1528139959606};\\\", \\\"{x:1466,y:572,t:1528139959622};\\\", \\\"{x:1467,y:569,t:1528139959639};\\\", \\\"{x:1467,y:567,t:1528139959663};\\\", \\\"{x:1467,y:566,t:1528139959695};\\\", \\\"{x:1465,y:567,t:1528139960056};\\\", \\\"{x:1460,y:572,t:1528139960072};\\\", \\\"{x:1457,y:577,t:1528139960088};\\\", \\\"{x:1454,y:583,t:1528139960105};\\\", \\\"{x:1449,y:591,t:1528139960122};\\\", \\\"{x:1448,y:596,t:1528139960139};\\\", \\\"{x:1445,y:604,t:1528139960155};\\\", \\\"{x:1440,y:613,t:1528139960172};\\\", \\\"{x:1440,y:617,t:1528139960189};\\\", \\\"{x:1439,y:620,t:1528139960205};\\\", \\\"{x:1437,y:625,t:1528139960222};\\\", \\\"{x:1437,y:627,t:1528139960240};\\\", \\\"{x:1437,y:630,t:1528139960256};\\\", \\\"{x:1437,y:631,t:1528139960273};\\\", \\\"{x:1437,y:634,t:1528139960289};\\\", \\\"{x:1437,y:638,t:1528139960306};\\\", \\\"{x:1437,y:641,t:1528139960322};\\\", \\\"{x:1437,y:647,t:1528139960339};\\\", \\\"{x:1437,y:653,t:1528139960355};\\\", \\\"{x:1437,y:660,t:1528139960372};\\\", \\\"{x:1437,y:673,t:1528139960389};\\\", \\\"{x:1437,y:684,t:1528139960406};\\\", \\\"{x:1438,y:704,t:1528139960423};\\\", \\\"{x:1439,y:714,t:1528139960439};\\\", \\\"{x:1441,y:728,t:1528139960456};\\\", \\\"{x:1443,y:740,t:1528139960472};\\\", \\\"{x:1448,y:750,t:1528139960490};\\\", \\\"{x:1449,y:756,t:1528139960506};\\\", \\\"{x:1453,y:764,t:1528139960522};\\\", \\\"{x:1457,y:773,t:1528139960540};\\\", \\\"{x:1461,y:781,t:1528139960556};\\\", \\\"{x:1465,y:792,t:1528139960573};\\\", \\\"{x:1475,y:806,t:1528139960590};\\\", \\\"{x:1486,y:825,t:1528139960605};\\\", \\\"{x:1499,y:841,t:1528139960623};\\\", \\\"{x:1506,y:853,t:1528139960640};\\\", \\\"{x:1511,y:861,t:1528139960657};\\\", \\\"{x:1514,y:867,t:1528139960673};\\\", \\\"{x:1518,y:871,t:1528139960690};\\\", \\\"{x:1520,y:874,t:1528139960707};\\\", \\\"{x:1524,y:880,t:1528139960722};\\\", \\\"{x:1525,y:883,t:1528139960740};\\\", \\\"{x:1526,y:884,t:1528139960757};\\\", \\\"{x:1527,y:884,t:1528139960777};\\\", \\\"{x:1527,y:885,t:1528139960794};\\\", \\\"{x:1528,y:886,t:1528139960811};\\\", \\\"{x:1530,y:886,t:1528139960827};\\\", \\\"{x:1531,y:886,t:1528139960932};\\\", \\\"{x:1532,y:886,t:1528139960944};\\\", \\\"{x:1533,y:886,t:1528139960961};\\\", \\\"{x:1534,y:886,t:1528139961364};\\\", \\\"{x:1534,y:879,t:1528139961378};\\\", \\\"{x:1539,y:864,t:1528139961394};\\\", \\\"{x:1557,y:825,t:1528139961411};\\\", \\\"{x:1571,y:798,t:1528139961427};\\\", \\\"{x:1581,y:779,t:1528139961446};\\\", \\\"{x:1588,y:760,t:1528139961461};\\\", \\\"{x:1596,y:739,t:1528139961478};\\\", \\\"{x:1600,y:725,t:1528139961495};\\\", \\\"{x:1602,y:716,t:1528139961512};\\\", \\\"{x:1607,y:707,t:1528139961528};\\\", \\\"{x:1607,y:704,t:1528139961546};\\\", \\\"{x:1610,y:697,t:1528139961563};\\\", \\\"{x:1611,y:696,t:1528139961594};\\\", \\\"{x:1609,y:697,t:1528139961715};\\\", \\\"{x:1608,y:701,t:1528139961728};\\\", \\\"{x:1604,y:708,t:1528139961744};\\\", \\\"{x:1602,y:717,t:1528139961760};\\\", \\\"{x:1599,y:728,t:1528139961777};\\\", \\\"{x:1599,y:738,t:1528139961794};\\\", \\\"{x:1598,y:741,t:1528139961810};\\\", \\\"{x:1598,y:743,t:1528139961827};\\\", \\\"{x:1598,y:746,t:1528139961844};\\\", \\\"{x:1598,y:750,t:1528139961861};\\\", \\\"{x:1598,y:754,t:1528139961878};\\\", \\\"{x:1598,y:758,t:1528139961894};\\\", \\\"{x:1598,y:761,t:1528139961911};\\\", \\\"{x:1598,y:764,t:1528139961928};\\\", \\\"{x:1597,y:766,t:1528139961945};\\\", \\\"{x:1595,y:769,t:1528139961961};\\\", \\\"{x:1594,y:773,t:1528139961978};\\\", \\\"{x:1592,y:776,t:1528139961994};\\\", \\\"{x:1591,y:779,t:1528139962011};\\\", \\\"{x:1589,y:782,t:1528139962028};\\\", \\\"{x:1588,y:784,t:1528139962045};\\\", \\\"{x:1586,y:788,t:1528139962062};\\\", \\\"{x:1583,y:792,t:1528139962077};\\\", \\\"{x:1581,y:796,t:1528139962095};\\\", \\\"{x:1579,y:800,t:1528139962112};\\\", \\\"{x:1578,y:802,t:1528139962128};\\\", \\\"{x:1578,y:803,t:1528139962145};\\\", \\\"{x:1578,y:804,t:1528139962162};\\\", \\\"{x:1576,y:807,t:1528139962203};\\\", \\\"{x:1574,y:808,t:1528139962220};\\\", \\\"{x:1571,y:813,t:1528139962235};\\\", \\\"{x:1569,y:814,t:1528139962245};\\\", \\\"{x:1566,y:818,t:1528139962261};\\\", \\\"{x:1563,y:822,t:1528139962278};\\\", \\\"{x:1562,y:824,t:1528139962294};\\\", \\\"{x:1561,y:825,t:1528139962311};\\\", \\\"{x:1560,y:826,t:1528139962328};\\\", \\\"{x:1559,y:829,t:1528139962345};\\\", \\\"{x:1558,y:832,t:1528139962362};\\\", \\\"{x:1558,y:835,t:1528139962378};\\\", \\\"{x:1557,y:839,t:1528139962395};\\\", \\\"{x:1557,y:842,t:1528139962412};\\\", \\\"{x:1556,y:846,t:1528139962429};\\\", \\\"{x:1553,y:851,t:1528139962445};\\\", \\\"{x:1550,y:858,t:1528139962462};\\\", \\\"{x:1546,y:865,t:1528139962479};\\\", \\\"{x:1545,y:869,t:1528139962495};\\\", \\\"{x:1543,y:870,t:1528139962512};\\\", \\\"{x:1543,y:872,t:1528139962529};\\\", \\\"{x:1541,y:874,t:1528139962545};\\\", \\\"{x:1540,y:875,t:1528139962562};\\\", \\\"{x:1538,y:877,t:1528139962579};\\\", \\\"{x:1538,y:878,t:1528139962611};\\\", \\\"{x:1537,y:879,t:1528139962629};\\\", \\\"{x:1537,y:880,t:1528139962651};\\\", \\\"{x:1536,y:881,t:1528139962683};\\\", \\\"{x:1535,y:881,t:1528139962695};\\\", \\\"{x:1535,y:882,t:1528139962712};\\\", \\\"{x:1535,y:883,t:1528139962729};\\\", \\\"{x:1534,y:885,t:1528139962746};\\\", \\\"{x:1534,y:886,t:1528139962762};\\\", \\\"{x:1534,y:888,t:1528139962779};\\\", \\\"{x:1534,y:889,t:1528139962796};\\\", \\\"{x:1532,y:888,t:1528139962874};\\\", \\\"{x:1532,y:887,t:1528139962890};\\\", \\\"{x:1532,y:884,t:1528139962898};\\\", \\\"{x:1532,y:882,t:1528139962911};\\\", \\\"{x:1532,y:877,t:1528139962928};\\\", \\\"{x:1532,y:871,t:1528139962945};\\\", \\\"{x:1532,y:865,t:1528139962962};\\\", \\\"{x:1532,y:856,t:1528139962978};\\\", \\\"{x:1532,y:852,t:1528139962995};\\\", \\\"{x:1534,y:845,t:1528139963012};\\\", \\\"{x:1536,y:841,t:1528139963028};\\\", \\\"{x:1536,y:836,t:1528139963046};\\\", \\\"{x:1538,y:832,t:1528139963063};\\\", \\\"{x:1539,y:828,t:1528139963079};\\\", \\\"{x:1539,y:827,t:1528139963096};\\\", \\\"{x:1539,y:826,t:1528139964650};\\\", \\\"{x:1539,y:829,t:1528139964665};\\\", \\\"{x:1539,y:832,t:1528139964680};\\\", \\\"{x:1539,y:836,t:1528139964696};\\\", \\\"{x:1540,y:840,t:1528139964714};\\\", \\\"{x:1543,y:849,t:1528139964730};\\\", \\\"{x:1544,y:851,t:1528139964747};\\\", \\\"{x:1544,y:852,t:1528139964763};\\\", \\\"{x:1544,y:853,t:1528139964947};\\\", \\\"{x:1544,y:855,t:1528139964964};\\\", \\\"{x:1544,y:857,t:1528139964980};\\\", \\\"{x:1544,y:858,t:1528139964996};\\\", \\\"{x:1543,y:861,t:1528139965013};\\\", \\\"{x:1543,y:862,t:1528139965030};\\\", \\\"{x:1543,y:863,t:1528139965046};\\\", \\\"{x:1542,y:865,t:1528139965063};\\\", \\\"{x:1542,y:866,t:1528139965081};\\\", \\\"{x:1542,y:867,t:1528139965098};\\\", \\\"{x:1541,y:870,t:1528139965114};\\\", \\\"{x:1541,y:871,t:1528139965130};\\\", \\\"{x:1539,y:875,t:1528139965148};\\\", \\\"{x:1536,y:881,t:1528139965164};\\\", \\\"{x:1533,y:886,t:1528139965180};\\\", \\\"{x:1529,y:892,t:1528139965197};\\\", \\\"{x:1526,y:898,t:1528139965213};\\\", \\\"{x:1521,y:904,t:1528139965231};\\\", \\\"{x:1515,y:910,t:1528139965247};\\\", \\\"{x:1514,y:913,t:1528139965263};\\\", \\\"{x:1511,y:916,t:1528139965280};\\\", \\\"{x:1508,y:921,t:1528139965298};\\\", \\\"{x:1507,y:922,t:1528139965314};\\\", \\\"{x:1507,y:924,t:1528139965330};\\\", \\\"{x:1507,y:925,t:1528139965370};\\\", \\\"{x:1505,y:925,t:1528139965386};\\\", \\\"{x:1505,y:927,t:1528139965434};\\\", \\\"{x:1505,y:928,t:1528139965450};\\\", \\\"{x:1504,y:930,t:1528139965466};\\\", \\\"{x:1504,y:931,t:1528139965480};\\\", \\\"{x:1501,y:935,t:1528139965497};\\\", \\\"{x:1498,y:940,t:1528139965513};\\\", \\\"{x:1498,y:942,t:1528139965530};\\\", \\\"{x:1496,y:945,t:1528139965547};\\\", \\\"{x:1495,y:945,t:1528139965564};\\\", \\\"{x:1495,y:947,t:1528139965594};\\\", \\\"{x:1495,y:948,t:1528139965626};\\\", \\\"{x:1495,y:949,t:1528139965649};\\\", \\\"{x:1495,y:951,t:1528139965664};\\\", \\\"{x:1495,y:952,t:1528139965681};\\\", \\\"{x:1495,y:953,t:1528139965697};\\\", \\\"{x:1495,y:955,t:1528139965714};\\\", \\\"{x:1496,y:955,t:1528139965730};\\\", \\\"{x:1497,y:955,t:1528139965747};\\\", \\\"{x:1498,y:957,t:1528139965764};\\\", \\\"{x:1498,y:958,t:1528139965780};\\\", \\\"{x:1498,y:957,t:1528139965994};\\\", \\\"{x:1497,y:954,t:1528139966001};\\\", \\\"{x:1497,y:951,t:1528139966014};\\\", \\\"{x:1492,y:942,t:1528139966031};\\\", \\\"{x:1485,y:928,t:1528139966047};\\\", \\\"{x:1474,y:913,t:1528139966064};\\\", \\\"{x:1460,y:898,t:1528139966082};\\\", \\\"{x:1442,y:888,t:1528139966097};\\\", \\\"{x:1418,y:872,t:1528139966115};\\\", \\\"{x:1405,y:863,t:1528139966131};\\\", \\\"{x:1388,y:854,t:1528139966147};\\\", \\\"{x:1367,y:846,t:1528139966164};\\\", \\\"{x:1351,y:831,t:1528139966181};\\\", \\\"{x:1324,y:817,t:1528139966197};\\\", \\\"{x:1287,y:796,t:1528139966214};\\\", \\\"{x:1238,y:771,t:1528139966231};\\\", \\\"{x:1184,y:740,t:1528139966247};\\\", \\\"{x:1118,y:711,t:1528139966264};\\\", \\\"{x:1047,y:686,t:1528139966281};\\\", \\\"{x:973,y:656,t:1528139966298};\\\", \\\"{x:919,y:629,t:1528139966314};\\\", \\\"{x:908,y:628,t:1528139966331};\\\", \\\"{x:899,y:625,t:1528139966348};\\\", \\\"{x:897,y:625,t:1528139966362};\\\", \\\"{x:885,y:624,t:1528139966379};\\\", \\\"{x:855,y:624,t:1528139966397};\\\", \\\"{x:831,y:624,t:1528139966412};\\\", \\\"{x:804,y:624,t:1528139966431};\\\", \\\"{x:791,y:624,t:1528139966447};\\\", \\\"{x:775,y:624,t:1528139966465};\\\", \\\"{x:765,y:620,t:1528139966480};\\\", \\\"{x:759,y:620,t:1528139966497};\\\", \\\"{x:755,y:620,t:1528139966514};\\\", \\\"{x:753,y:620,t:1528139966890};\\\", \\\"{x:746,y:615,t:1528139966897};\\\", \\\"{x:722,y:600,t:1528139966915};\\\", \\\"{x:663,y:580,t:1528139966932};\\\", \\\"{x:582,y:553,t:1528139966948};\\\", \\\"{x:536,y:536,t:1528139966964};\\\", \\\"{x:496,y:517,t:1528139966982};\\\", \\\"{x:476,y:505,t:1528139966997};\\\", \\\"{x:460,y:494,t:1528139967015};\\\", \\\"{x:449,y:485,t:1528139967032};\\\", \\\"{x:439,y:477,t:1528139967049};\\\", \\\"{x:432,y:472,t:1528139967065};\\\", \\\"{x:427,y:468,t:1528139967082};\\\", \\\"{x:426,y:467,t:1528139967098};\\\", \\\"{x:425,y:466,t:1528139967115};\\\", \\\"{x:424,y:466,t:1528139967131};\\\", \\\"{x:423,y:466,t:1528139967148};\\\", \\\"{x:422,y:466,t:1528139967164};\\\", \\\"{x:421,y:466,t:1528139967194};\\\", \\\"{x:419,y:467,t:1528139967202};\\\", \\\"{x:418,y:469,t:1528139967215};\\\", \\\"{x:416,y:475,t:1528139967231};\\\", \\\"{x:416,y:477,t:1528139967249};\\\", \\\"{x:423,y:481,t:1528139967264};\\\", \\\"{x:431,y:481,t:1528139967282};\\\", \\\"{x:452,y:481,t:1528139967298};\\\", \\\"{x:459,y:481,t:1528139967315};\\\", \\\"{x:468,y:481,t:1528139967332};\\\", \\\"{x:484,y:485,t:1528139967347};\\\", \\\"{x:503,y:486,t:1528139967364};\\\", \\\"{x:517,y:488,t:1528139967382};\\\", \\\"{x:524,y:489,t:1528139967398};\\\", \\\"{x:527,y:490,t:1528139967415};\\\", \\\"{x:532,y:492,t:1528139967431};\\\", \\\"{x:538,y:493,t:1528139967448};\\\", \\\"{x:539,y:493,t:1528139967464};\\\", \\\"{x:540,y:493,t:1528139967481};\\\", \\\"{x:541,y:493,t:1528139967498};\\\", \\\"{x:543,y:493,t:1528139967522};\\\", \\\"{x:544,y:494,t:1528139967531};\\\", \\\"{x:549,y:496,t:1528139967549};\\\", \\\"{x:554,y:497,t:1528139967565};\\\", \\\"{x:565,y:500,t:1528139967581};\\\", \\\"{x:576,y:502,t:1528139967598};\\\", \\\"{x:587,y:503,t:1528139967615};\\\", \\\"{x:596,y:503,t:1528139967631};\\\", \\\"{x:601,y:503,t:1528139967648};\\\", \\\"{x:605,y:505,t:1528139967665};\\\", \\\"{x:608,y:505,t:1528139967681};\\\", \\\"{x:609,y:505,t:1528139967705};\\\", \\\"{x:611,y:505,t:1528139968106};\\\", \\\"{x:617,y:506,t:1528139968116};\\\", \\\"{x:629,y:508,t:1528139968133};\\\", \\\"{x:641,y:510,t:1528139968148};\\\", \\\"{x:662,y:511,t:1528139968166};\\\", \\\"{x:677,y:511,t:1528139968183};\\\", \\\"{x:693,y:511,t:1528139968199};\\\", \\\"{x:702,y:511,t:1528139968216};\\\", \\\"{x:710,y:511,t:1528139968233};\\\", \\\"{x:718,y:511,t:1528139968248};\\\", \\\"{x:727,y:510,t:1528139968266};\\\", \\\"{x:747,y:509,t:1528139968282};\\\", \\\"{x:761,y:508,t:1528139968298};\\\", \\\"{x:781,y:508,t:1528139968316};\\\", \\\"{x:794,y:508,t:1528139968332};\\\", \\\"{x:803,y:508,t:1528139968349};\\\", \\\"{x:809,y:507,t:1528139968365};\\\", \\\"{x:812,y:507,t:1528139968382};\\\", \\\"{x:813,y:507,t:1528139968458};\\\", \\\"{x:813,y:506,t:1528139968538};\\\", \\\"{x:813,y:505,t:1528139968554};\\\", \\\"{x:814,y:505,t:1528139968566};\\\", \\\"{x:817,y:502,t:1528139968583};\\\", \\\"{x:820,y:500,t:1528139968600};\\\", \\\"{x:823,y:499,t:1528139968615};\\\", \\\"{x:824,y:498,t:1528139968633};\\\", \\\"{x:826,y:498,t:1528139968650};\\\", \\\"{x:827,y:498,t:1528139968826};\\\", \\\"{x:827,y:498,t:1528139968830};\\\", \\\"{x:829,y:497,t:1528139968850};\\\", \\\"{x:834,y:497,t:1528139968962};\\\", \\\"{x:836,y:497,t:1528139968970};\\\", \\\"{x:839,y:497,t:1528139968983};\\\", \\\"{x:842,y:497,t:1528139968999};\\\", \\\"{x:846,y:497,t:1528139969016};\\\", \\\"{x:849,y:498,t:1528139969033};\\\", \\\"{x:849,y:499,t:1528139969105};\\\", \\\"{x:849,y:501,t:1528139969202};\\\", \\\"{x:846,y:507,t:1528139969216};\\\", \\\"{x:829,y:526,t:1528139969233};\\\", \\\"{x:762,y:644,t:1528139969250};\\\", \\\"{x:713,y:734,t:1528139969266};\\\", \\\"{x:662,y:796,t:1528139969282};\\\", \\\"{x:622,y:829,t:1528139969300};\\\", \\\"{x:611,y:834,t:1528139969316};\\\", \\\"{x:600,y:838,t:1528139969333};\\\", \\\"{x:594,y:838,t:1528139969349};\\\", \\\"{x:588,y:838,t:1528139969366};\\\", \\\"{x:583,y:836,t:1528139969384};\\\", \\\"{x:577,y:833,t:1528139969399};\\\", \\\"{x:567,y:826,t:1528139969416};\\\", \\\"{x:556,y:818,t:1528139969433};\\\", \\\"{x:546,y:805,t:1528139969450};\\\", \\\"{x:535,y:785,t:1528139969467};\\\", \\\"{x:531,y:777,t:1528139969483};\\\", \\\"{x:531,y:770,t:1528139969500};\\\", \\\"{x:529,y:765,t:1528139969517};\\\", \\\"{x:529,y:759,t:1528139969534};\\\", \\\"{x:528,y:755,t:1528139969549};\\\", \\\"{x:528,y:754,t:1528139969566};\\\", \\\"{x:527,y:752,t:1528139969583};\\\", \\\"{x:527,y:750,t:1528139969599};\\\", \\\"{x:526,y:741,t:1528139969616};\\\", \\\"{x:522,y:733,t:1528139969634};\\\", \\\"{x:520,y:730,t:1528139969650};\\\", \\\"{x:519,y:729,t:1528139969690};\\\", \\\"{x:518,y:728,t:1528139969705};\\\", \\\"{x:518,y:728,t:1528139969799};\\\" ] }, { \\\"rt\\\": 7856, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 918842, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:726,t:1528139973282};\\\", \\\"{x:517,y:725,t:1528139973289};\\\", \\\"{x:517,y:724,t:1528139973306};\\\", \\\"{x:518,y:717,t:1528139973322};\\\", \\\"{x:528,y:710,t:1528139973339};\\\", \\\"{x:543,y:703,t:1528139973355};\\\", \\\"{x:565,y:689,t:1528139973370};\\\", \\\"{x:572,y:682,t:1528139973386};\\\", \\\"{x:577,y:675,t:1528139973402};\\\", \\\"{x:583,y:671,t:1528139973419};\\\", \\\"{x:589,y:667,t:1528139973436};\\\", \\\"{x:596,y:663,t:1528139973453};\\\", \\\"{x:652,y:648,t:1528139973469};\\\", \\\"{x:708,y:639,t:1528139973486};\\\", \\\"{x:751,y:633,t:1528139973503};\\\", \\\"{x:810,y:622,t:1528139973520};\\\", \\\"{x:841,y:613,t:1528139973537};\\\", \\\"{x:869,y:607,t:1528139973553};\\\", \\\"{x:887,y:613,t:1528139974402};\\\", \\\"{x:902,y:618,t:1528139974409};\\\", \\\"{x:913,y:620,t:1528139974421};\\\", \\\"{x:955,y:634,t:1528139974437};\\\", \\\"{x:985,y:640,t:1528139974454};\\\", \\\"{x:1008,y:648,t:1528139974471};\\\", \\\"{x:1033,y:659,t:1528139974487};\\\", \\\"{x:1056,y:670,t:1528139974504};\\\", \\\"{x:1089,y:685,t:1528139974521};\\\", \\\"{x:1138,y:716,t:1528139974538};\\\", \\\"{x:1162,y:735,t:1528139974554};\\\", \\\"{x:1184,y:754,t:1528139974571};\\\", \\\"{x:1204,y:771,t:1528139974587};\\\", \\\"{x:1218,y:784,t:1528139974604};\\\", \\\"{x:1235,y:797,t:1528139974621};\\\", \\\"{x:1255,y:819,t:1528139974638};\\\", \\\"{x:1286,y:853,t:1528139974654};\\\", \\\"{x:1313,y:885,t:1528139974671};\\\", \\\"{x:1340,y:919,t:1528139974688};\\\", \\\"{x:1364,y:945,t:1528139974704};\\\", \\\"{x:1386,y:963,t:1528139974722};\\\", \\\"{x:1418,y:994,t:1528139974738};\\\", \\\"{x:1436,y:1008,t:1528139974755};\\\", \\\"{x:1456,y:1021,t:1528139974771};\\\", \\\"{x:1475,y:1032,t:1528139974789};\\\", \\\"{x:1489,y:1038,t:1528139974803};\\\", \\\"{x:1493,y:1039,t:1528139974820};\\\", \\\"{x:1496,y:1039,t:1528139974838};\\\", \\\"{x:1497,y:1039,t:1528139974930};\\\", \\\"{x:1499,y:1037,t:1528139974938};\\\", \\\"{x:1505,y:1030,t:1528139974954};\\\", \\\"{x:1509,y:1024,t:1528139974971};\\\", \\\"{x:1514,y:1017,t:1528139974988};\\\", \\\"{x:1519,y:1008,t:1528139975004};\\\", \\\"{x:1522,y:1001,t:1528139975021};\\\", \\\"{x:1523,y:997,t:1528139975038};\\\", \\\"{x:1523,y:996,t:1528139975055};\\\", \\\"{x:1524,y:995,t:1528139975071};\\\", \\\"{x:1527,y:992,t:1528139975267};\\\", \\\"{x:1527,y:990,t:1528139975275};\\\", \\\"{x:1528,y:989,t:1528139975289};\\\", \\\"{x:1528,y:988,t:1528139975305};\\\", \\\"{x:1529,y:987,t:1528139975322};\\\", \\\"{x:1531,y:984,t:1528139975339};\\\", \\\"{x:1532,y:982,t:1528139975354};\\\", \\\"{x:1533,y:980,t:1528139975371};\\\", \\\"{x:1534,y:980,t:1528139975403};\\\", \\\"{x:1535,y:979,t:1528139975410};\\\", \\\"{x:1536,y:977,t:1528139975421};\\\", \\\"{x:1537,y:974,t:1528139975439};\\\", \\\"{x:1537,y:973,t:1528139975455};\\\", \\\"{x:1538,y:972,t:1528139975472};\\\", \\\"{x:1539,y:970,t:1528139975488};\\\", \\\"{x:1541,y:969,t:1528139975504};\\\", \\\"{x:1543,y:967,t:1528139975522};\\\", \\\"{x:1543,y:966,t:1528139975546};\\\", \\\"{x:1544,y:965,t:1528139975642};\\\", \\\"{x:1544,y:964,t:1528139975658};\\\", \\\"{x:1544,y:963,t:1528139975690};\\\", \\\"{x:1544,y:962,t:1528139975722};\\\", \\\"{x:1544,y:961,t:1528139975738};\\\", \\\"{x:1543,y:959,t:1528139975754};\\\", \\\"{x:1541,y:959,t:1528139975772};\\\", \\\"{x:1537,y:957,t:1528139975788};\\\", \\\"{x:1533,y:955,t:1528139975804};\\\", \\\"{x:1531,y:954,t:1528139975821};\\\", \\\"{x:1529,y:951,t:1528139975838};\\\", \\\"{x:1526,y:948,t:1528139975855};\\\", \\\"{x:1523,y:944,t:1528139975871};\\\", \\\"{x:1515,y:935,t:1528139975889};\\\", \\\"{x:1507,y:925,t:1528139975905};\\\", \\\"{x:1496,y:916,t:1528139975922};\\\", \\\"{x:1491,y:910,t:1528139975938};\\\", \\\"{x:1489,y:908,t:1528139975955};\\\", \\\"{x:1489,y:906,t:1528139975971};\\\", \\\"{x:1486,y:902,t:1528139975989};\\\", \\\"{x:1486,y:901,t:1528139976005};\\\", \\\"{x:1486,y:899,t:1528139976022};\\\", \\\"{x:1485,y:895,t:1528139976039};\\\", \\\"{x:1483,y:893,t:1528139976055};\\\", \\\"{x:1483,y:892,t:1528139976072};\\\", \\\"{x:1483,y:891,t:1528139976089};\\\", \\\"{x:1481,y:888,t:1528139976105};\\\", \\\"{x:1478,y:883,t:1528139976121};\\\", \\\"{x:1474,y:881,t:1528139976138};\\\", \\\"{x:1470,y:878,t:1528139976155};\\\", \\\"{x:1467,y:870,t:1528139976172};\\\", \\\"{x:1462,y:865,t:1528139976189};\\\", \\\"{x:1459,y:860,t:1528139976204};\\\", \\\"{x:1457,y:856,t:1528139976222};\\\", \\\"{x:1453,y:852,t:1528139976238};\\\", \\\"{x:1451,y:844,t:1528139976255};\\\", \\\"{x:1449,y:839,t:1528139976272};\\\", \\\"{x:1448,y:834,t:1528139976289};\\\", \\\"{x:1447,y:831,t:1528139976305};\\\", \\\"{x:1447,y:830,t:1528139976322};\\\", \\\"{x:1447,y:828,t:1528139976339};\\\", \\\"{x:1448,y:822,t:1528139976356};\\\", \\\"{x:1454,y:798,t:1528139976372};\\\", \\\"{x:1456,y:786,t:1528139976389};\\\", \\\"{x:1456,y:782,t:1528139976406};\\\", \\\"{x:1454,y:772,t:1528139976422};\\\", \\\"{x:1446,y:757,t:1528139976439};\\\", \\\"{x:1431,y:740,t:1528139976456};\\\", \\\"{x:1409,y:723,t:1528139976472};\\\", \\\"{x:1369,y:700,t:1528139976489};\\\", \\\"{x:1300,y:659,t:1528139976506};\\\", \\\"{x:1244,y:634,t:1528139976522};\\\", \\\"{x:1173,y:607,t:1528139976539};\\\", \\\"{x:1098,y:581,t:1528139976556};\\\", \\\"{x:1000,y:551,t:1528139976572};\\\", \\\"{x:904,y:528,t:1528139976590};\\\", \\\"{x:804,y:500,t:1528139976607};\\\", \\\"{x:699,y:469,t:1528139976622};\\\", \\\"{x:614,y:448,t:1528139976639};\\\", \\\"{x:528,y:426,t:1528139976656};\\\", \\\"{x:460,y:414,t:1528139976672};\\\", \\\"{x:417,y:405,t:1528139976689};\\\", \\\"{x:372,y:397,t:1528139976706};\\\", \\\"{x:339,y:393,t:1528139976722};\\\", \\\"{x:318,y:390,t:1528139976738};\\\", \\\"{x:299,y:390,t:1528139976755};\\\", \\\"{x:288,y:390,t:1528139976772};\\\", \\\"{x:278,y:393,t:1528139976789};\\\", \\\"{x:267,y:400,t:1528139976806};\\\", \\\"{x:253,y:408,t:1528139976822};\\\", \\\"{x:227,y:423,t:1528139976839};\\\", \\\"{x:171,y:459,t:1528139976856};\\\", \\\"{x:158,y:475,t:1528139976873};\\\", \\\"{x:147,y:487,t:1528139976890};\\\", \\\"{x:141,y:500,t:1528139976906};\\\", \\\"{x:139,y:501,t:1528139976945};\\\", \\\"{x:138,y:501,t:1528139976962};\\\", \\\"{x:137,y:501,t:1528139976973};\\\", \\\"{x:135,y:504,t:1528139976989};\\\", \\\"{x:133,y:505,t:1528139977050};\\\", \\\"{x:132,y:507,t:1528139977058};\\\", \\\"{x:131,y:510,t:1528139977073};\\\", \\\"{x:129,y:513,t:1528139977090};\\\", \\\"{x:128,y:517,t:1528139977106};\\\", \\\"{x:124,y:521,t:1528139977123};\\\", \\\"{x:124,y:522,t:1528139977140};\\\", \\\"{x:123,y:524,t:1528139977157};\\\", \\\"{x:123,y:526,t:1528139977196};\\\", \\\"{x:124,y:528,t:1528139977210};\\\", \\\"{x:130,y:535,t:1528139977226};\\\", \\\"{x:136,y:540,t:1528139977240};\\\", \\\"{x:151,y:550,t:1528139977256};\\\", \\\"{x:171,y:560,t:1528139977273};\\\", \\\"{x:209,y:579,t:1528139977290};\\\", \\\"{x:244,y:592,t:1528139977306};\\\", \\\"{x:276,y:604,t:1528139977324};\\\", \\\"{x:306,y:611,t:1528139977340};\\\", \\\"{x:340,y:622,t:1528139977355};\\\", \\\"{x:375,y:630,t:1528139977373};\\\", \\\"{x:403,y:634,t:1528139977390};\\\", \\\"{x:428,y:638,t:1528139977406};\\\", \\\"{x:450,y:643,t:1528139977423};\\\", \\\"{x:473,y:643,t:1528139977440};\\\", \\\"{x:502,y:647,t:1528139977457};\\\", \\\"{x:537,y:649,t:1528139977473};\\\", \\\"{x:588,y:649,t:1528139977490};\\\", \\\"{x:616,y:649,t:1528139977506};\\\", \\\"{x:645,y:649,t:1528139977524};\\\", \\\"{x:673,y:649,t:1528139977540};\\\", \\\"{x:695,y:649,t:1528139977556};\\\", \\\"{x:712,y:645,t:1528139977573};\\\", \\\"{x:725,y:640,t:1528139977590};\\\", \\\"{x:732,y:636,t:1528139977606};\\\", \\\"{x:736,y:635,t:1528139977624};\\\", \\\"{x:739,y:633,t:1528139977641};\\\", \\\"{x:742,y:632,t:1528139977657};\\\", \\\"{x:746,y:629,t:1528139977674};\\\", \\\"{x:751,y:625,t:1528139977690};\\\", \\\"{x:752,y:621,t:1528139977707};\\\", \\\"{x:752,y:620,t:1528139977723};\\\", \\\"{x:752,y:619,t:1528139977746};\\\", \\\"{x:751,y:618,t:1528139977757};\\\", \\\"{x:746,y:615,t:1528139977773};\\\", \\\"{x:732,y:610,t:1528139977790};\\\", \\\"{x:711,y:604,t:1528139977808};\\\", \\\"{x:688,y:598,t:1528139977823};\\\", \\\"{x:657,y:591,t:1528139977841};\\\", \\\"{x:634,y:584,t:1528139977857};\\\", \\\"{x:616,y:578,t:1528139977873};\\\", \\\"{x:601,y:574,t:1528139977890};\\\", \\\"{x:597,y:572,t:1528139977908};\\\", \\\"{x:593,y:570,t:1528139977924};\\\", \\\"{x:595,y:570,t:1528139978139};\\\", \\\"{x:596,y:570,t:1528139978146};\\\", \\\"{x:598,y:570,t:1528139978158};\\\", \\\"{x:602,y:570,t:1528139978175};\\\", \\\"{x:603,y:570,t:1528139978190};\\\", \\\"{x:604,y:571,t:1528139978522};\\\", \\\"{x:602,y:578,t:1528139978530};\\\", \\\"{x:602,y:586,t:1528139978541};\\\", \\\"{x:597,y:601,t:1528139978558};\\\", \\\"{x:591,y:614,t:1528139978574};\\\", \\\"{x:580,y:638,t:1528139978592};\\\", \\\"{x:573,y:662,t:1528139978607};\\\", \\\"{x:564,y:685,t:1528139978624};\\\", \\\"{x:554,y:698,t:1528139978641};\\\", \\\"{x:547,y:713,t:1528139978657};\\\", \\\"{x:541,y:721,t:1528139978674};\\\", \\\"{x:540,y:723,t:1528139978691};\\\", \\\"{x:539,y:724,t:1528139978708};\\\", \\\"{x:538,y:725,t:1528139978819};\\\", \\\"{x:536,y:725,t:1528139978827};\\\", \\\"{x:533,y:726,t:1528139978843};\\\", \\\"{x:531,y:727,t:1528139978859};\\\", \\\"{x:529,y:728,t:1528139978874};\\\", \\\"{x:529,y:729,t:1528139978946};\\\", \\\"{x:529,y:729,t:1528139979037};\\\" ] }, { \\\"rt\\\": 11009, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 931204, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:729,t:1528139981203};\\\", \\\"{x:515,y:726,t:1528139981210};\\\", \\\"{x:499,y:720,t:1528139981226};\\\", \\\"{x:465,y:710,t:1528139981243};\\\", \\\"{x:438,y:703,t:1528139981259};\\\", \\\"{x:413,y:700,t:1528139981277};\\\", \\\"{x:396,y:696,t:1528139981293};\\\", \\\"{x:385,y:692,t:1528139981310};\\\", \\\"{x:381,y:692,t:1528139981327};\\\", \\\"{x:380,y:691,t:1528139981342};\\\", \\\"{x:379,y:691,t:1528139981360};\\\", \\\"{x:378,y:689,t:1528139981376};\\\", \\\"{x:377,y:679,t:1528139981395};\\\", \\\"{x:378,y:668,t:1528139981409};\\\", \\\"{x:382,y:662,t:1528139981426};\\\", \\\"{x:384,y:658,t:1528139981443};\\\", \\\"{x:387,y:654,t:1528139981459};\\\", \\\"{x:387,y:648,t:1528139981476};\\\", \\\"{x:388,y:643,t:1528139981494};\\\", \\\"{x:390,y:637,t:1528139981509};\\\", \\\"{x:391,y:631,t:1528139981526};\\\", \\\"{x:396,y:622,t:1528139981543};\\\", \\\"{x:401,y:610,t:1528139981561};\\\", \\\"{x:406,y:602,t:1528139981577};\\\", \\\"{x:408,y:599,t:1528139981593};\\\", \\\"{x:408,y:598,t:1528139981634};\\\", \\\"{x:411,y:598,t:1528139981899};\\\", \\\"{x:414,y:598,t:1528139981911};\\\", \\\"{x:434,y:599,t:1528139981928};\\\", \\\"{x:442,y:599,t:1528139981944};\\\", \\\"{x:446,y:599,t:1528139981961};\\\", \\\"{x:458,y:599,t:1528139981978};\\\", \\\"{x:472,y:599,t:1528139981993};\\\", \\\"{x:494,y:598,t:1528139982011};\\\", \\\"{x:507,y:599,t:1528139982029};\\\", \\\"{x:522,y:600,t:1528139982043};\\\", \\\"{x:530,y:602,t:1528139982060};\\\", \\\"{x:534,y:602,t:1528139982077};\\\", \\\"{x:539,y:602,t:1528139982093};\\\", \\\"{x:542,y:602,t:1528139982110};\\\", \\\"{x:544,y:602,t:1528139982127};\\\", \\\"{x:547,y:602,t:1528139982143};\\\", \\\"{x:547,y:600,t:1528139982339};\\\", \\\"{x:543,y:599,t:1528139982346};\\\", \\\"{x:535,y:596,t:1528139982361};\\\", \\\"{x:524,y:593,t:1528139982377};\\\", \\\"{x:507,y:587,t:1528139982394};\\\", \\\"{x:470,y:578,t:1528139982412};\\\", \\\"{x:448,y:574,t:1528139982428};\\\", \\\"{x:434,y:569,t:1528139982443};\\\", \\\"{x:422,y:566,t:1528139982461};\\\", \\\"{x:416,y:563,t:1528139982477};\\\", \\\"{x:414,y:563,t:1528139982494};\\\", \\\"{x:410,y:562,t:1528139982510};\\\", \\\"{x:408,y:561,t:1528139982527};\\\", \\\"{x:406,y:561,t:1528139982544};\\\", \\\"{x:404,y:559,t:1528139982560};\\\", \\\"{x:402,y:559,t:1528139982578};\\\", \\\"{x:400,y:559,t:1528139982595};\\\", \\\"{x:397,y:557,t:1528139982610};\\\", \\\"{x:392,y:556,t:1528139982628};\\\", \\\"{x:389,y:556,t:1528139982645};\\\", \\\"{x:389,y:555,t:1528139982660};\\\", \\\"{x:388,y:555,t:1528139982678};\\\", \\\"{x:385,y:554,t:1528139982695};\\\", \\\"{x:383,y:551,t:1528139982710};\\\", \\\"{x:382,y:547,t:1528139982727};\\\", \\\"{x:382,y:544,t:1528139982745};\\\", \\\"{x:382,y:540,t:1528139982761};\\\", \\\"{x:383,y:536,t:1528139982778};\\\", \\\"{x:391,y:531,t:1528139982794};\\\", \\\"{x:399,y:526,t:1528139982810};\\\", \\\"{x:410,y:520,t:1528139982827};\\\", \\\"{x:422,y:514,t:1528139982845};\\\", \\\"{x:435,y:509,t:1528139982861};\\\", \\\"{x:445,y:505,t:1528139982877};\\\", \\\"{x:454,y:501,t:1528139982894};\\\", \\\"{x:461,y:497,t:1528139982911};\\\", \\\"{x:468,y:494,t:1528139982928};\\\", \\\"{x:477,y:492,t:1528139982944};\\\", \\\"{x:499,y:492,t:1528139982960};\\\", \\\"{x:515,y:491,t:1528139982978};\\\", \\\"{x:544,y:500,t:1528139982994};\\\", \\\"{x:555,y:500,t:1528139983010};\\\", \\\"{x:561,y:500,t:1528139983028};\\\", \\\"{x:562,y:500,t:1528139983045};\\\", \\\"{x:563,y:500,t:1528139983062};\\\", \\\"{x:564,y:500,t:1528139983123};\\\", \\\"{x:566,y:500,t:1528139983131};\\\", \\\"{x:567,y:501,t:1528139983146};\\\", \\\"{x:568,y:502,t:1528139983161};\\\", \\\"{x:570,y:504,t:1528139983178};\\\", \\\"{x:576,y:504,t:1528139983194};\\\", \\\"{x:580,y:504,t:1528139983212};\\\", \\\"{x:585,y:504,t:1528139983227};\\\", \\\"{x:597,y:508,t:1528139983244};\\\", \\\"{x:608,y:511,t:1528139983262};\\\", \\\"{x:619,y:515,t:1528139983277};\\\", \\\"{x:635,y:519,t:1528139983295};\\\", \\\"{x:650,y:520,t:1528139983312};\\\", \\\"{x:662,y:521,t:1528139983327};\\\", \\\"{x:673,y:523,t:1528139983345};\\\", \\\"{x:685,y:528,t:1528139983361};\\\", \\\"{x:696,y:529,t:1528139983377};\\\", \\\"{x:717,y:531,t:1528139983395};\\\", \\\"{x:738,y:535,t:1528139983413};\\\", \\\"{x:762,y:543,t:1528139983429};\\\", \\\"{x:788,y:548,t:1528139983445};\\\", \\\"{x:807,y:555,t:1528139983461};\\\", \\\"{x:824,y:563,t:1528139983479};\\\", \\\"{x:838,y:564,t:1528139983494};\\\", \\\"{x:839,y:564,t:1528139983511};\\\", \\\"{x:841,y:564,t:1528139983875};\\\", \\\"{x:843,y:568,t:1528139983884};\\\", \\\"{x:843,y:576,t:1528139983896};\\\", \\\"{x:909,y:603,t:1528139983912};\\\", \\\"{x:968,y:628,t:1528139983928};\\\", \\\"{x:1006,y:652,t:1528139983946};\\\", \\\"{x:1033,y:674,t:1528139983961};\\\", \\\"{x:1073,y:720,t:1528139983978};\\\", \\\"{x:1117,y:775,t:1528139983995};\\\", \\\"{x:1169,y:838,t:1528139984011};\\\", \\\"{x:1203,y:876,t:1528139984028};\\\", \\\"{x:1214,y:900,t:1528139984045};\\\", \\\"{x:1220,y:912,t:1528139984061};\\\", \\\"{x:1228,y:928,t:1528139984078};\\\", \\\"{x:1234,y:943,t:1528139984095};\\\", \\\"{x:1242,y:955,t:1528139984111};\\\", \\\"{x:1247,y:963,t:1528139984129};\\\", \\\"{x:1249,y:965,t:1528139984145};\\\", \\\"{x:1250,y:966,t:1528139984162};\\\", \\\"{x:1252,y:968,t:1528139984179};\\\", \\\"{x:1256,y:971,t:1528139984196};\\\", \\\"{x:1261,y:973,t:1528139984212};\\\", \\\"{x:1266,y:974,t:1528139984229};\\\", \\\"{x:1274,y:975,t:1528139984245};\\\", \\\"{x:1281,y:975,t:1528139984262};\\\", \\\"{x:1291,y:975,t:1528139984279};\\\", \\\"{x:1303,y:975,t:1528139984296};\\\", \\\"{x:1319,y:978,t:1528139984313};\\\", \\\"{x:1330,y:979,t:1528139984329};\\\", \\\"{x:1341,y:980,t:1528139984346};\\\", \\\"{x:1357,y:980,t:1528139984363};\\\", \\\"{x:1364,y:980,t:1528139984379};\\\", \\\"{x:1372,y:980,t:1528139984396};\\\", \\\"{x:1378,y:980,t:1528139984413};\\\", \\\"{x:1383,y:980,t:1528139984429};\\\", \\\"{x:1388,y:979,t:1528139984446};\\\", \\\"{x:1393,y:977,t:1528139984463};\\\", \\\"{x:1399,y:975,t:1528139984480};\\\", \\\"{x:1406,y:973,t:1528139984496};\\\", \\\"{x:1416,y:969,t:1528139984513};\\\", \\\"{x:1422,y:966,t:1528139984530};\\\", \\\"{x:1427,y:965,t:1528139984546};\\\", \\\"{x:1442,y:960,t:1528139984563};\\\", \\\"{x:1451,y:958,t:1528139984579};\\\", \\\"{x:1458,y:956,t:1528139984596};\\\", \\\"{x:1463,y:956,t:1528139984613};\\\", \\\"{x:1475,y:953,t:1528139984629};\\\", \\\"{x:1481,y:952,t:1528139984646};\\\", \\\"{x:1484,y:954,t:1528139984810};\\\", \\\"{x:1485,y:956,t:1528139984818};\\\", \\\"{x:1487,y:960,t:1528139984829};\\\", \\\"{x:1488,y:964,t:1528139984845};\\\", \\\"{x:1490,y:966,t:1528139984862};\\\", \\\"{x:1491,y:968,t:1528139984879};\\\", \\\"{x:1492,y:968,t:1528139984895};\\\", \\\"{x:1492,y:969,t:1528139985090};\\\", \\\"{x:1491,y:969,t:1528139985098};\\\", \\\"{x:1489,y:967,t:1528139985112};\\\", \\\"{x:1488,y:966,t:1528139985130};\\\", \\\"{x:1488,y:965,t:1528139985154};\\\", \\\"{x:1487,y:964,t:1528139985203};\\\", \\\"{x:1487,y:962,t:1528139985219};\\\", \\\"{x:1487,y:961,t:1528139985229};\\\", \\\"{x:1487,y:960,t:1528139985247};\\\", \\\"{x:1487,y:959,t:1528139985263};\\\", \\\"{x:1487,y:958,t:1528139985280};\\\", \\\"{x:1486,y:956,t:1528139985296};\\\", \\\"{x:1485,y:954,t:1528139985312};\\\", \\\"{x:1484,y:951,t:1528139985329};\\\", \\\"{x:1480,y:936,t:1528139985346};\\\", \\\"{x:1474,y:923,t:1528139985363};\\\", \\\"{x:1463,y:905,t:1528139985380};\\\", \\\"{x:1457,y:895,t:1528139985396};\\\", \\\"{x:1456,y:892,t:1528139985412};\\\", \\\"{x:1456,y:890,t:1528139985430};\\\", \\\"{x:1456,y:889,t:1528139985446};\\\", \\\"{x:1456,y:888,t:1528139985482};\\\", \\\"{x:1456,y:887,t:1528139985496};\\\", \\\"{x:1456,y:885,t:1528139985512};\\\", \\\"{x:1456,y:883,t:1528139985530};\\\", \\\"{x:1456,y:880,t:1528139985547};\\\", \\\"{x:1456,y:879,t:1528139985563};\\\", \\\"{x:1456,y:875,t:1528139985580};\\\", \\\"{x:1457,y:871,t:1528139985597};\\\", \\\"{x:1459,y:866,t:1528139985613};\\\", \\\"{x:1461,y:861,t:1528139985630};\\\", \\\"{x:1464,y:856,t:1528139985646};\\\", \\\"{x:1464,y:854,t:1528139985662};\\\", \\\"{x:1466,y:851,t:1528139985679};\\\", \\\"{x:1467,y:849,t:1528139985697};\\\", \\\"{x:1468,y:845,t:1528139985713};\\\", \\\"{x:1470,y:838,t:1528139985729};\\\", \\\"{x:1471,y:832,t:1528139985747};\\\", \\\"{x:1471,y:828,t:1528139985763};\\\", \\\"{x:1472,y:824,t:1528139985780};\\\", \\\"{x:1472,y:821,t:1528139985797};\\\", \\\"{x:1472,y:818,t:1528139985814};\\\", \\\"{x:1472,y:816,t:1528139985830};\\\", \\\"{x:1472,y:814,t:1528139985847};\\\", \\\"{x:1472,y:813,t:1528139985864};\\\", \\\"{x:1472,y:811,t:1528139985880};\\\", \\\"{x:1472,y:809,t:1528139985897};\\\", \\\"{x:1472,y:808,t:1528139985914};\\\", \\\"{x:1472,y:805,t:1528139985930};\\\", \\\"{x:1472,y:802,t:1528139985946};\\\", \\\"{x:1472,y:801,t:1528139985964};\\\", \\\"{x:1472,y:798,t:1528139985981};\\\", \\\"{x:1472,y:795,t:1528139985998};\\\", \\\"{x:1472,y:790,t:1528139986014};\\\", \\\"{x:1473,y:786,t:1528139986030};\\\", \\\"{x:1473,y:781,t:1528139986047};\\\", \\\"{x:1474,y:780,t:1528139986064};\\\", \\\"{x:1474,y:776,t:1528139986080};\\\", \\\"{x:1474,y:773,t:1528139986097};\\\", \\\"{x:1474,y:771,t:1528139986115};\\\", \\\"{x:1474,y:770,t:1528139986130};\\\", \\\"{x:1474,y:767,t:1528139986147};\\\", \\\"{x:1474,y:765,t:1528139986171};\\\", \\\"{x:1475,y:764,t:1528139986180};\\\", \\\"{x:1475,y:762,t:1528139986197};\\\", \\\"{x:1475,y:760,t:1528139986214};\\\", \\\"{x:1475,y:758,t:1528139986231};\\\", \\\"{x:1475,y:756,t:1528139986251};\\\", \\\"{x:1475,y:755,t:1528139986264};\\\", \\\"{x:1475,y:753,t:1528139986281};\\\", \\\"{x:1475,y:751,t:1528139986298};\\\", \\\"{x:1475,y:750,t:1528139986314};\\\", \\\"{x:1475,y:748,t:1528139986332};\\\", \\\"{x:1475,y:745,t:1528139986347};\\\", \\\"{x:1475,y:743,t:1528139986364};\\\", \\\"{x:1475,y:741,t:1528139986381};\\\", \\\"{x:1475,y:738,t:1528139986397};\\\", \\\"{x:1475,y:734,t:1528139986414};\\\", \\\"{x:1475,y:731,t:1528139986431};\\\", \\\"{x:1475,y:727,t:1528139986447};\\\", \\\"{x:1475,y:723,t:1528139986464};\\\", \\\"{x:1475,y:719,t:1528139986480};\\\", \\\"{x:1475,y:717,t:1528139986497};\\\", \\\"{x:1475,y:713,t:1528139986514};\\\", \\\"{x:1477,y:710,t:1528139986530};\\\", \\\"{x:1477,y:707,t:1528139986547};\\\", \\\"{x:1477,y:705,t:1528139986563};\\\", \\\"{x:1477,y:703,t:1528139986581};\\\", \\\"{x:1477,y:702,t:1528139986596};\\\", \\\"{x:1477,y:701,t:1528139986614};\\\", \\\"{x:1477,y:699,t:1528139986631};\\\", \\\"{x:1478,y:697,t:1528139986648};\\\", \\\"{x:1478,y:696,t:1528139986665};\\\", \\\"{x:1478,y:695,t:1528139986680};\\\", \\\"{x:1478,y:693,t:1528139986697};\\\", \\\"{x:1478,y:692,t:1528139986713};\\\", \\\"{x:1479,y:689,t:1528139986730};\\\", \\\"{x:1479,y:688,t:1528139986810};\\\", \\\"{x:1479,y:687,t:1528139986817};\\\", \\\"{x:1480,y:687,t:1528139986830};\\\", \\\"{x:1480,y:686,t:1528139986849};\\\", \\\"{x:1480,y:685,t:1528139986866};\\\", \\\"{x:1480,y:684,t:1528139986881};\\\", \\\"{x:1480,y:682,t:1528139986897};\\\", \\\"{x:1480,y:681,t:1528139986914};\\\", \\\"{x:1480,y:679,t:1528139986931};\\\", \\\"{x:1480,y:677,t:1528139986947};\\\", \\\"{x:1480,y:676,t:1528139986964};\\\", \\\"{x:1480,y:674,t:1528139986980};\\\", \\\"{x:1479,y:673,t:1528139987194};\\\", \\\"{x:1477,y:672,t:1528139987250};\\\", \\\"{x:1474,y:672,t:1528139987265};\\\", \\\"{x:1472,y:670,t:1528139987280};\\\", \\\"{x:1466,y:669,t:1528139987297};\\\", \\\"{x:1434,y:663,t:1528139987313};\\\", \\\"{x:1385,y:659,t:1528139987331};\\\", \\\"{x:1305,y:654,t:1528139987348};\\\", \\\"{x:1197,y:654,t:1528139987364};\\\", \\\"{x:1059,y:654,t:1528139987380};\\\", \\\"{x:915,y:654,t:1528139987398};\\\", \\\"{x:774,y:654,t:1528139987415};\\\", \\\"{x:657,y:647,t:1528139987430};\\\", \\\"{x:559,y:646,t:1528139987448};\\\", \\\"{x:495,y:644,t:1528139987465};\\\", \\\"{x:473,y:642,t:1528139987480};\\\", \\\"{x:464,y:642,t:1528139987497};\\\", \\\"{x:462,y:642,t:1528139987514};\\\", \\\"{x:461,y:642,t:1528139987531};\\\", \\\"{x:460,y:642,t:1528139987562};\\\", \\\"{x:457,y:643,t:1528139987570};\\\", \\\"{x:455,y:644,t:1528139987581};\\\", \\\"{x:442,y:648,t:1528139987600};\\\", \\\"{x:428,y:652,t:1528139987614};\\\", \\\"{x:411,y:654,t:1528139987631};\\\", \\\"{x:392,y:656,t:1528139987648};\\\", \\\"{x:377,y:657,t:1528139987665};\\\", \\\"{x:361,y:659,t:1528139987681};\\\", \\\"{x:351,y:659,t:1528139987698};\\\", \\\"{x:338,y:659,t:1528139987715};\\\", \\\"{x:336,y:660,t:1528139987732};\\\", \\\"{x:335,y:660,t:1528139987747};\\\", \\\"{x:333,y:660,t:1528139987786};\\\", \\\"{x:332,y:660,t:1528139987826};\\\", \\\"{x:329,y:660,t:1528139987834};\\\", \\\"{x:328,y:659,t:1528139987848};\\\", \\\"{x:326,y:659,t:1528139987864};\\\", \\\"{x:322,y:658,t:1528139987880};\\\", \\\"{x:318,y:656,t:1528139987898};\\\", \\\"{x:305,y:651,t:1528139987916};\\\", \\\"{x:294,y:646,t:1528139987931};\\\", \\\"{x:279,y:640,t:1528139987948};\\\", \\\"{x:268,y:636,t:1528139987966};\\\", \\\"{x:262,y:632,t:1528139987981};\\\", \\\"{x:258,y:632,t:1528139987998};\\\", \\\"{x:255,y:631,t:1528139988014};\\\", \\\"{x:254,y:631,t:1528139988031};\\\", \\\"{x:252,y:631,t:1528139988049};\\\", \\\"{x:251,y:631,t:1528139988065};\\\", \\\"{x:253,y:631,t:1528139988130};\\\", \\\"{x:259,y:628,t:1528139988138};\\\", \\\"{x:261,y:627,t:1528139988148};\\\", \\\"{x:280,y:627,t:1528139988165};\\\", \\\"{x:330,y:627,t:1528139988181};\\\", \\\"{x:391,y:627,t:1528139988199};\\\", \\\"{x:460,y:627,t:1528139988216};\\\", \\\"{x:527,y:627,t:1528139988233};\\\", \\\"{x:584,y:626,t:1528139988249};\\\", \\\"{x:634,y:626,t:1528139988266};\\\", \\\"{x:684,y:626,t:1528139988282};\\\", \\\"{x:726,y:625,t:1528139988300};\\\", \\\"{x:740,y:623,t:1528139988315};\\\", \\\"{x:750,y:622,t:1528139988331};\\\", \\\"{x:755,y:621,t:1528139988349};\\\", \\\"{x:759,y:620,t:1528139988365};\\\", \\\"{x:764,y:619,t:1528139988381};\\\", \\\"{x:775,y:616,t:1528139988399};\\\", \\\"{x:780,y:614,t:1528139988416};\\\", \\\"{x:784,y:612,t:1528139988432};\\\", \\\"{x:785,y:612,t:1528139988449};\\\", \\\"{x:786,y:611,t:1528139988466};\\\", \\\"{x:786,y:610,t:1528139988514};\\\", \\\"{x:785,y:610,t:1528139988522};\\\", \\\"{x:778,y:610,t:1528139988533};\\\", \\\"{x:761,y:610,t:1528139988550};\\\", \\\"{x:742,y:610,t:1528139988566};\\\", \\\"{x:723,y:610,t:1528139988583};\\\", \\\"{x:712,y:610,t:1528139988600};\\\", \\\"{x:690,y:612,t:1528139988618};\\\", \\\"{x:665,y:616,t:1528139988634};\\\", \\\"{x:642,y:618,t:1528139988651};\\\", \\\"{x:616,y:618,t:1528139988665};\\\", \\\"{x:602,y:618,t:1528139988682};\\\", \\\"{x:600,y:618,t:1528139988699};\\\", \\\"{x:598,y:617,t:1528139988851};\\\", \\\"{x:598,y:616,t:1528139988866};\\\", \\\"{x:599,y:612,t:1528139988884};\\\", \\\"{x:600,y:611,t:1528139988899};\\\", \\\"{x:600,y:608,t:1528139988915};\\\", \\\"{x:602,y:607,t:1528139988933};\\\", \\\"{x:603,y:606,t:1528139988954};\\\", \\\"{x:605,y:605,t:1528139988970};\\\", \\\"{x:605,y:604,t:1528139988982};\\\", \\\"{x:607,y:600,t:1528139989000};\\\", \\\"{x:608,y:599,t:1528139989016};\\\", \\\"{x:610,y:597,t:1528139989033};\\\", \\\"{x:611,y:597,t:1528139989050};\\\", \\\"{x:611,y:596,t:1528139989082};\\\", \\\"{x:607,y:595,t:1528139989715};\\\", \\\"{x:589,y:592,t:1528139989724};\\\", \\\"{x:571,y:589,t:1528139989732};\\\", \\\"{x:521,y:583,t:1528139989749};\\\", \\\"{x:478,y:583,t:1528139989767};\\\", \\\"{x:447,y:578,t:1528139989782};\\\", \\\"{x:432,y:575,t:1528139989800};\\\", \\\"{x:424,y:573,t:1528139989816};\\\", \\\"{x:423,y:573,t:1528139989833};\\\", \\\"{x:422,y:572,t:1528139989850};\\\", \\\"{x:421,y:572,t:1528139989979};\\\", \\\"{x:420,y:572,t:1528139989987};\\\", \\\"{x:417,y:572,t:1528139990000};\\\", \\\"{x:416,y:573,t:1528139990019};\\\", \\\"{x:415,y:573,t:1528139990042};\\\", \\\"{x:414,y:573,t:1528139990066};\\\", \\\"{x:413,y:574,t:1528139990086};\\\", \\\"{x:411,y:575,t:1528139990099};\\\", \\\"{x:403,y:583,t:1528139990117};\\\", \\\"{x:400,y:587,t:1528139990133};\\\", \\\"{x:399,y:588,t:1528139990149};\\\", \\\"{x:397,y:588,t:1528139990170};\\\", \\\"{x:397,y:589,t:1528139990183};\\\", \\\"{x:395,y:590,t:1528139990199};\\\", \\\"{x:394,y:590,t:1528139990217};\\\", \\\"{x:393,y:591,t:1528139990242};\\\", \\\"{x:392,y:591,t:1528139990258};\\\", \\\"{x:391,y:591,t:1528139990266};\\\", \\\"{x:390,y:591,t:1528139990283};\\\", \\\"{x:389,y:591,t:1528139990300};\\\", \\\"{x:388,y:594,t:1528139990538};\\\", \\\"{x:390,y:609,t:1528139990551};\\\", \\\"{x:409,y:638,t:1528139990567};\\\", \\\"{x:435,y:686,t:1528139990584};\\\", \\\"{x:470,y:744,t:1528139990601};\\\", \\\"{x:498,y:784,t:1528139990618};\\\", \\\"{x:537,y:818,t:1528139990634};\\\", \\\"{x:552,y:833,t:1528139990650};\\\", \\\"{x:564,y:842,t:1528139990667};\\\", \\\"{x:570,y:843,t:1528139990683};\\\", \\\"{x:570,y:842,t:1528139990802};\\\", \\\"{x:570,y:837,t:1528139990818};\\\", \\\"{x:563,y:819,t:1528139990834};\\\", \\\"{x:556,y:806,t:1528139990851};\\\", \\\"{x:551,y:792,t:1528139990869};\\\", \\\"{x:546,y:783,t:1528139990884};\\\", \\\"{x:544,y:778,t:1528139990901};\\\", \\\"{x:541,y:774,t:1528139990918};\\\", \\\"{x:541,y:773,t:1528139990935};\\\", \\\"{x:540,y:771,t:1528139990951};\\\", \\\"{x:540,y:770,t:1528139990968};\\\", \\\"{x:540,y:769,t:1528139990985};\\\", \\\"{x:541,y:765,t:1528139991162};\\\", \\\"{x:545,y:764,t:1528139991169};\\\", \\\"{x:550,y:762,t:1528139991184};\\\", \\\"{x:551,y:761,t:1528139991201};\\\" ] }, { \\\"rt\\\": 72985, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1005428, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The diagonal line that goes through M and L indicate that those two shifts start at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8286, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1014721, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13931, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1029669, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 2050, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1033052, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"CKDM5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"CKDM5\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 128, dom: 621, initialDom: 922",
  "javascriptErrors": []
}