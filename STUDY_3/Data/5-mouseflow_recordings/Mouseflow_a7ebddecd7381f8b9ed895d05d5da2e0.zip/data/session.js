var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a7ebddecd7381f8b9ed895d05d5da2e0",
  "created": "2018-06-04T12:19:52.1566364-07:00",
  "lastActivity": "2018-06-04T12:21:35.5072939-07:00",
  "pageViews": [
    {
      "id": "06045239b4ac9ef3ff21dc2aa9baf3918a226e2b",
      "startTime": "2018-06-04T12:19:52.3644488-07:00",
      "endTime": "2018-06-04T12:21:35.5072939-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 103390,
      "engagementTime": 79869,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 103390,
  "engagementTime": 79869,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=CKDM5",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0a0c232f2633dda68def9850d41ea999",
  "gdpr": false
}