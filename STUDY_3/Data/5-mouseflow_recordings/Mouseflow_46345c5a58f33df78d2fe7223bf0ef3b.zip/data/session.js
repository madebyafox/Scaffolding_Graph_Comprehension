var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "46345c5a58f33df78d2fe7223bf0ef3b",
  "created": "2018-05-18T11:11:08.7832654-07:00",
  "lastActivity": "2018-05-18T11:11:46.8412654-07:00",
  "pageViews": [
    {
      "id": "0518082953f183f5506eb0c7f587d34eb2475df7",
      "startTime": "2018-05-18T11:11:08.7832654-07:00",
      "endTime": "2018-05-18T11:11:46.8412654-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 38058,
      "engagementTime": 37660,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38058,
  "engagementTime": 37660,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TCH5L",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d82e9dcda8e3920b64b2751dff96c658",
  "gdpr": false
}