var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1bd1ca416e73430dc7bba2d74ecbf866",
  "created": "2018-06-01T11:23:08.0003503-07:00",
  "lastActivity": "2018-06-01T11:23:57.721864-07:00",
  "pageViews": [
    {
      "id": "06010877f3c909107811631135e9fe1794b04418",
      "startTime": "2018-06-01T11:23:08.0869837-07:00",
      "endTime": "2018-06-01T11:23:57.721864-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 49736,
      "engagementTime": 45633,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49736,
  "engagementTime": 45633,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CE3B9",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1bb22a047602c32a6b46fcdeb7331736",
  "gdpr": false
}