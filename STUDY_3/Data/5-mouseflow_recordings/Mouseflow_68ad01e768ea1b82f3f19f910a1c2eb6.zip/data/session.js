var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "68ad01e768ea1b82f3f19f910a1c2eb6",
  "created": "2018-05-21T12:10:52.0960359-07:00",
  "lastActivity": "2018-05-21T12:11:20.9890359-07:00",
  "pageViews": [
    {
      "id": "05215204705443e9eda4e9c99938546f27a3df61",
      "startTime": "2018-05-21T12:10:52.0960359-07:00",
      "endTime": "2018-05-21T12:11:20.9890359-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 28893,
      "engagementTime": 28894,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28893,
  "engagementTime": 28894,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X9PTQ",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6c152417b835b12dfe728ac38a137fbd",
  "gdpr": false
}