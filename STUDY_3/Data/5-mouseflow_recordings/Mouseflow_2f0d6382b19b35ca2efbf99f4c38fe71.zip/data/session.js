var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2f0d6382b19b35ca2efbf99f4c38fe71",
  "created": "2018-05-15T17:00:51.8440943-07:00",
  "lastActivity": "2018-05-15T17:02:37.8171328-07:00",
  "pageViews": [
    {
      "id": "051551736430c1d938d4aaa04b840ea2d1284d96",
      "startTime": "2018-05-15T17:00:51.8440943-07:00",
      "endTime": "2018-05-15T17:02:37.8171328-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 106304,
      "engagementTime": 41446,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 106304,
  "engagementTime": 41446,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "15a942f6fc4134bf34dfc0239c3edaa6",
  "gdpr": false
}