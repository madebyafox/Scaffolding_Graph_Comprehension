var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "34f93fb2b38cbef230cb54fe99a01afe",
  "created": "2018-05-22T16:00:45.9154397-07:00",
  "lastActivity": "2018-05-22T16:05:43.4193633-07:00",
  "pageViews": [
    {
      "id": "052245429875328eb853359e1e333db921a38049",
      "startTime": "2018-05-22T16:00:46.1360616-07:00",
      "endTime": "2018-05-22T16:05:43.4193633-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 297342,
      "engagementTime": 90028,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 297342,
  "engagementTime": 90028,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f3cb0968dd941114c9f5a0946f314d49",
  "gdpr": false
}