var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b8f3b0d18b0aa1eb54cfec6e547ae1ec",
  "created": "2018-05-21T13:24:37.8242369-07:00",
  "lastActivity": "2018-05-21T13:28:49.3132629-07:00",
  "pageViews": [
    {
      "id": "052137724eb47f6ebf0082070c2f1c8174565531",
      "startTime": "2018-05-21T13:24:37.9246186-07:00",
      "endTime": "2018-05-21T13:28:49.3132629-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 251762,
      "engagementTime": 176778,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 251762,
  "engagementTime": 176778,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ELUPZ",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0cfb9c798776adfd95d000b80e7b902d",
  "gdpr": false
}