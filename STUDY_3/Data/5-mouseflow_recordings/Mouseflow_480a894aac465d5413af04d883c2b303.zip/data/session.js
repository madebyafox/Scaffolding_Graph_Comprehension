var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "480a894aac465d5413af04d883c2b303",
  "created": "2018-06-01T10:13:04.3260811-07:00",
  "lastActivity": "2018-06-01T10:13:12.5754729-07:00",
  "pageViews": [
    {
      "id": "06010402585b9ae82a446d24333cebcf5b8380d1",
      "startTime": "2018-06-01T10:13:04.3754729-07:00",
      "endTime": "2018-06-01T10:13:12.5754729-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 8200,
      "engagementTime": 6627,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8200,
  "engagementTime": 6627,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GZ705",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "92a837c728239f7acf0d8bbac5a28f5b",
  "gdpr": false
}