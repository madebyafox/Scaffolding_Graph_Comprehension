var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "09c47dfa9dd8820708f55835fff2305b",
  "created": "2018-05-31T12:06:48.1276704-07:00",
  "lastActivity": "2018-05-31T12:08:14.6286704-07:00",
  "pageViews": [
    {
      "id": "0531489076402bea181b3678002cc0c4e860b8c3",
      "startTime": "2018-05-31T12:06:48.1276704-07:00",
      "endTime": "2018-05-31T12:08:14.6286704-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 86501,
      "engagementTime": 86502,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 86501,
  "engagementTime": 86502,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PWFDZ",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ae9491ee5ef669b5b3e9e2d3536da04a",
  "gdpr": false
}