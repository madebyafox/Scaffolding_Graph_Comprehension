var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "724b3a280d68b3b0544857d711c5f540",
  "created": "2018-05-15T14:03:50.6870294-07:00",
  "lastActivity": "2018-05-15T14:04:28.930944-07:00",
  "pageViews": [
    {
      "id": "05155038bdbf3bc189f4711009e55a2dc592685e",
      "startTime": "2018-05-15T14:03:50.6870294-07:00",
      "endTime": "2018-05-15T14:04:28.930944-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 38313,
      "engagementTime": 36940,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38313,
  "engagementTime": 36940,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DD3DE",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f11427bedb235f985e59e4a58c81e6c0",
  "gdpr": false
}