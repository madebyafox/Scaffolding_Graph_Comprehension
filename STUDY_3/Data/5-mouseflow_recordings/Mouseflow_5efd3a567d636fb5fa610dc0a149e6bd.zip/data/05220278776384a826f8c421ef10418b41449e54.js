var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220278776384a826f8c421ef10418b41449e54"] = {
  "startTime": "2018-05-22T20:14:02.4249515Z",
  "websitePageUrl": "/16",
  "visitTime": 90312,
  "engagementTime": 88018,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5efd3a567d636fb5fa610dc0a149e6bd",
    "created": "2018-05-22T20:14:02.4249515+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=39GMD",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9ef6f0e5b92d792f1395e990d0835feb",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5efd3a567d636fb5fa610dc0a149e6bd/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 967,
      "e": 967,
      "ty": 6,
      "x": 499,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 493,
      "y": 550
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 44503,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 489,
      "y": 529
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 44616,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 508,
      "y": 558
    },
    {
      "t": 1399,
      "e": 1399,
      "ty": 3,
      "x": 508,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1485,
      "e": 1485,
      "ty": 4,
      "x": 46189,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1486,
      "e": 1486,
      "ty": 5,
      "x": 508,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 46189,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8301,
      "e": 6501,
      "ty": 2,
      "x": 508,
      "y": 559
    },
    {
      "t": 8340,
      "e": 6540,
      "ty": 7,
      "x": 676,
      "y": 676,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8402,
      "e": 6602,
      "ty": 2,
      "x": 1124,
      "y": 1036
    },
    {
      "t": 8502,
      "e": 6702,
      "ty": 2,
      "x": 1239,
      "y": 1137
    },
    {
      "t": 8502,
      "e": 6702,
      "ty": 41,
      "x": 42392,
      "y": 62543,
      "ta": "> div.stimulus"
    },
    {
      "t": 8601,
      "e": 6801,
      "ty": 2,
      "x": 1237,
      "y": 1137
    },
    {
      "t": 8702,
      "e": 6902,
      "ty": 2,
      "x": 1222,
      "y": 1048
    },
    {
      "t": 8752,
      "e": 6952,
      "ty": 41,
      "x": 28963,
      "y": 60521,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8802,
      "e": 7002,
      "ty": 2,
      "x": 1191,
      "y": 975
    },
    {
      "t": 8902,
      "e": 7102,
      "ty": 2,
      "x": 1172,
      "y": 981
    },
    {
      "t": 9001,
      "e": 7201,
      "ty": 2,
      "x": 1164,
      "y": 989
    },
    {
      "t": 9003,
      "e": 7203,
      "ty": 41,
      "x": 26637,
      "y": 60951,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9202,
      "e": 7402,
      "ty": 2,
      "x": 1163,
      "y": 975
    },
    {
      "t": 9252,
      "e": 7452,
      "ty": 41,
      "x": 47090,
      "y": 12543,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 9301,
      "e": 7501,
      "ty": 2,
      "x": 1161,
      "y": 970
    },
    {
      "t": 9402,
      "e": 7602,
      "ty": 2,
      "x": 1156,
      "y": 967
    },
    {
      "t": 9502,
      "e": 7702,
      "ty": 41,
      "x": 26074,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9701,
      "e": 7901,
      "ty": 2,
      "x": 1155,
      "y": 963
    },
    {
      "t": 9752,
      "e": 7952,
      "ty": 41,
      "x": 26003,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9802,
      "e": 8002,
      "ty": 2,
      "x": 1155,
      "y": 958
    },
    {
      "t": 10001,
      "e": 8201,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10004,
      "e": 8204,
      "ty": 41,
      "x": 577,
      "y": 64920,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 10102,
      "e": 8302,
      "ty": 2,
      "x": 1153,
      "y": 936
    },
    {
      "t": 10201,
      "e": 8401,
      "ty": 2,
      "x": 1151,
      "y": 910
    },
    {
      "t": 10252,
      "e": 8452,
      "ty": 41,
      "x": 25721,
      "y": 54505,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10302,
      "e": 8502,
      "ty": 2,
      "x": 1151,
      "y": 888
    },
    {
      "t": 10402,
      "e": 8602,
      "ty": 2,
      "x": 1151,
      "y": 868
    },
    {
      "t": 10502,
      "e": 8702,
      "ty": 2,
      "x": 1151,
      "y": 855
    },
    {
      "t": 10503,
      "e": 8703,
      "ty": 41,
      "x": 25721,
      "y": 51353,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10601,
      "e": 8801,
      "ty": 2,
      "x": 1151,
      "y": 842
    },
    {
      "t": 10702,
      "e": 8902,
      "ty": 2,
      "x": 1151,
      "y": 824
    },
    {
      "t": 10753,
      "e": 8953,
      "ty": 41,
      "x": 25721,
      "y": 48202,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10801,
      "e": 9001,
      "ty": 2,
      "x": 1151,
      "y": 798
    },
    {
      "t": 10901,
      "e": 9101,
      "ty": 2,
      "x": 1151,
      "y": 774
    },
    {
      "t": 11002,
      "e": 9202,
      "ty": 2,
      "x": 1151,
      "y": 760
    },
    {
      "t": 11002,
      "e": 9202,
      "ty": 41,
      "x": 23750,
      "y": 16383,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > circle"
    },
    {
      "t": 11102,
      "e": 9302,
      "ty": 2,
      "x": 1151,
      "y": 759
    },
    {
      "t": 11252,
      "e": 9452,
      "ty": 41,
      "x": 23750,
      "y": 10922,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > circle"
    },
    {
      "t": 14101,
      "e": 12301,
      "ty": 2,
      "x": 1150,
      "y": 769
    },
    {
      "t": 14201,
      "e": 12401,
      "ty": 2,
      "x": 1146,
      "y": 801
    },
    {
      "t": 14251,
      "e": 12451,
      "ty": 41,
      "x": 25017,
      "y": 49921,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14301,
      "e": 12501,
      "ty": 2,
      "x": 1138,
      "y": 885
    },
    {
      "t": 14401,
      "e": 12601,
      "ty": 2,
      "x": 1138,
      "y": 948
    },
    {
      "t": 14501,
      "e": 12701,
      "ty": 2,
      "x": 1152,
      "y": 1000
    },
    {
      "t": 14502,
      "e": 12702,
      "ty": 41,
      "x": 25792,
      "y": 61738,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14751,
      "e": 12951,
      "ty": 41,
      "x": 25792,
      "y": 60664,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14801,
      "e": 13001,
      "ty": 2,
      "x": 1152,
      "y": 979
    },
    {
      "t": 15001,
      "e": 13201,
      "ty": 2,
      "x": 1153,
      "y": 978
    },
    {
      "t": 15001,
      "e": 13201,
      "ty": 41,
      "x": 32510,
      "y": 37119,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 15101,
      "e": 13301,
      "ty": 2,
      "x": 1154,
      "y": 966
    },
    {
      "t": 15201,
      "e": 13401,
      "ty": 2,
      "x": 1155,
      "y": 965
    },
    {
      "t": 15252,
      "e": 13452,
      "ty": 41,
      "x": 26003,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 15501,
      "e": 13701,
      "ty": 2,
      "x": 1150,
      "y": 964
    },
    {
      "t": 15501,
      "e": 13701,
      "ty": 41,
      "x": 21586,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 17801,
      "e": 16001,
      "ty": 2,
      "x": 1150,
      "y": 954
    },
    {
      "t": 17902,
      "e": 16102,
      "ty": 2,
      "x": 1151,
      "y": 848
    },
    {
      "t": 18001,
      "e": 16201,
      "ty": 2,
      "x": 1156,
      "y": 778
    },
    {
      "t": 18002,
      "e": 16202,
      "ty": 41,
      "x": 26074,
      "y": 45838,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 18102,
      "e": 16302,
      "ty": 2,
      "x": 1152,
      "y": 716
    },
    {
      "t": 18202,
      "e": 16402,
      "ty": 2,
      "x": 1144,
      "y": 662
    },
    {
      "t": 18251,
      "e": 16451,
      "ty": 41,
      "x": 25228,
      "y": 37387,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 18301,
      "e": 16501,
      "ty": 2,
      "x": 1144,
      "y": 660
    },
    {
      "t": 18701,
      "e": 16901,
      "ty": 2,
      "x": 1109,
      "y": 666
    },
    {
      "t": 18752,
      "e": 16952,
      "ty": 41,
      "x": 15504,
      "y": 39679,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 18801,
      "e": 17001,
      "ty": 2,
      "x": 559,
      "y": 713
    },
    {
      "t": 18901,
      "e": 17101,
      "ty": 2,
      "x": 289,
      "y": 688
    },
    {
      "t": 19001,
      "e": 17201,
      "ty": 2,
      "x": 289,
      "y": 675
    },
    {
      "t": 19001,
      "e": 17201,
      "ty": 41,
      "x": 21572,
      "y": 36949,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 19082,
      "e": 17282,
      "ty": 6,
      "x": 339,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19101,
      "e": 17301,
      "ty": 2,
      "x": 347,
      "y": 594
    },
    {
      "t": 19201,
      "e": 17401,
      "ty": 2,
      "x": 364,
      "y": 583
    },
    {
      "t": 19251,
      "e": 17451,
      "ty": 41,
      "x": 30452,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19301,
      "e": 17501,
      "ty": 2,
      "x": 369,
      "y": 582
    },
    {
      "t": 19382,
      "e": 17582,
      "ty": 3,
      "x": 370,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19401,
      "e": 17601,
      "ty": 2,
      "x": 370,
      "y": 582
    },
    {
      "t": 19469,
      "e": 17669,
      "ty": 4,
      "x": 30902,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19469,
      "e": 17669,
      "ty": 5,
      "x": 372,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19501,
      "e": 17701,
      "ty": 2,
      "x": 372,
      "y": 582
    },
    {
      "t": 19501,
      "e": 17701,
      "ty": 41,
      "x": 30902,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19601,
      "e": 17801,
      "ty": 2,
      "x": 373,
      "y": 583
    },
    {
      "t": 19701,
      "e": 17901,
      "ty": 2,
      "x": 414,
      "y": 583
    },
    {
      "t": 19732,
      "e": 17932,
      "ty": 7,
      "x": 529,
      "y": 610,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19751,
      "e": 17951,
      "ty": 41,
      "x": 59004,
      "y": 34401,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 19802,
      "e": 18002,
      "ty": 2,
      "x": 874,
      "y": 668
    },
    {
      "t": 19901,
      "e": 18101,
      "ty": 2,
      "x": 968,
      "y": 691
    },
    {
      "t": 20001,
      "e": 18201,
      "ty": 2,
      "x": 968,
      "y": 693
    },
    {
      "t": 20002,
      "e": 18202,
      "ty": 41,
      "x": 12826,
      "y": 39750,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20002,
      "e": 18202,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20501,
      "e": 18701,
      "ty": 2,
      "x": 1000,
      "y": 694
    },
    {
      "t": 20501,
      "e": 18701,
      "ty": 41,
      "x": 15081,
      "y": 39822,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20601,
      "e": 18801,
      "ty": 2,
      "x": 1005,
      "y": 693
    },
    {
      "t": 20751,
      "e": 18951,
      "ty": 41,
      "x": 15433,
      "y": 39750,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 21202,
      "e": 19402,
      "ty": 2,
      "x": 1456,
      "y": 688
    },
    {
      "t": 21251,
      "e": 19451,
      "ty": 41,
      "x": 58841,
      "y": 39392,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 21302,
      "e": 19502,
      "ty": 2,
      "x": 1663,
      "y": 685
    },
    {
      "t": 21502,
      "e": 19702,
      "ty": 41,
      "x": 61801,
      "y": 39177,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 22962,
      "e": 21162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23122,
      "e": 21322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23122,
      "e": 21322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23193,
      "e": 21393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 23249,
      "e": 21449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 23305,
      "e": 21505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23305,
      "e": 21505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23385,
      "e": 21585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 25322,
      "e": 23522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25322,
      "e": 23522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25401,
      "e": 23601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I u"
    },
    {
      "t": 25425,
      "e": 23625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25425,
      "e": 23625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25505,
      "e": 23705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I us"
    },
    {
      "t": 25611,
      "e": 23811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25611,
      "e": 23811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25673,
      "e": 23873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25769,
      "e": 23969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25769,
      "e": 23969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25841,
      "e": 24041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25913,
      "e": 24113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25913,
      "e": 24113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26017,
      "e": 24217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26042,
      "e": 24242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26043,
      "e": 24243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26121,
      "e": 24321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26185,
      "e": 24385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26186,
      "e": 24386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26266,
      "e": 24466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26298,
      "e": 24498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26298,
      "e": 24498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26376,
      "e": 24576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26538,
      "e": 24738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26538,
      "e": 24738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26633,
      "e": 24833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 26722,
      "e": 24922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26722,
      "e": 24922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26858,
      "e": 25058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26874,
      "e": 25074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 26875,
      "e": 25075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26970,
      "e": 25170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 27009,
      "e": 25209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27010,
      "e": 25210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27090,
      "e": 25290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27194,
      "e": 25394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27195,
      "e": 25395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27249,
      "e": 25449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27321,
      "e": 25521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27322,
      "e": 25522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27401,
      "e": 25601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27889,
      "e": 26089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27890,
      "e": 26090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27977,
      "e": 26177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28041,
      "e": 26241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28042,
      "e": 26242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28105,
      "e": 26305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28186,
      "e": 26386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28186,
      "e": 26386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28264,
      "e": 26464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29835,
      "e": 28035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29835,
      "e": 28035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29945,
      "e": 28145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 30001,
      "e": 28201,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30049,
      "e": 28249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30050,
      "e": 28250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30113,
      "e": 28313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30249,
      "e": 28449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30249,
      "e": 28449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30321,
      "e": 28521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30370,
      "e": 28570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30370,
      "e": 28570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30433,
      "e": 28633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30594,
      "e": 28794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 30595,
      "e": 28795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30665,
      "e": 28865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 30929,
      "e": 29129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30993,
      "e": 29193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line"
    },
    {
      "t": 31681,
      "e": 29881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31683,
      "e": 29883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31761,
      "e": 29961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31890,
      "e": 30090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 31891,
      "e": 30091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31984,
      "e": 30184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 32097,
      "e": 30297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32097,
      "e": 30297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32201,
      "e": 30401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32250,
      "e": 30450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32250,
      "e": 30450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32345,
      "e": 30545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35801,
      "e": 34001,
      "ty": 2,
      "x": 1664,
      "y": 685
    },
    {
      "t": 36002,
      "e": 34202,
      "ty": 41,
      "x": 61871,
      "y": 39177,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36857,
      "e": 35057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 36859,
      "e": 35059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36945,
      "e": 35145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 37017,
      "e": 35217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37017,
      "e": 35217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37097,
      "e": 35297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 37098,
      "e": 35298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37098,
      "e": 35298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37169,
      "e": 35369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37192,
      "e": 35392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37193,
      "e": 35393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37273,
      "e": 35473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 37338,
      "e": 35538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37339,
      "e": 35539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37408,
      "e": 35608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37481,
      "e": 35681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37481,
      "e": 35681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37570,
      "e": 35770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37618,
      "e": 35818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37618,
      "e": 35818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37706,
      "e": 35906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38066,
      "e": 36266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38121,
      "e": 36321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where "
    },
    {
      "t": 38193,
      "e": 36393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38194,
      "e": 36394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38257,
      "e": 36457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38296,
      "e": 36496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38297,
      "e": 36497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38401,
      "e": 36601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38576,
      "e": 36776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38577,
      "e": 36777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38664,
      "e": 36864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38705,
      "e": 36905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38705,
      "e": 36905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38785,
      "e": 36985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38930,
      "e": 37130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38931,
      "e": 37131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38993,
      "e": 37193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39089,
      "e": 37289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39090,
      "e": 37290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39137,
      "e": 37337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39538,
      "e": 37738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39585,
      "e": 37785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a let"
    },
    {
      "t": 39705,
      "e": 37905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39745,
      "e": 37945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a le"
    },
    {
      "t": 39867,
      "e": 38067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39897,
      "e": 38097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a l"
    },
    {
      "t": 40002,
      "e": 38202,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40004,
      "e": 38204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a l"
    },
    {
      "t": 40017,
      "e": 38217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40073,
      "e": 38273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a "
    },
    {
      "t": 40204,
      "e": 38404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a "
    },
    {
      "t": 40536,
      "e": 38736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40537,
      "e": 38737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40625,
      "e": 38825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40641,
      "e": 38841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40641,
      "e": 38841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40736,
      "e": 38936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40745,
      "e": 38945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40745,
      "e": 38945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40824,
      "e": 39024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40913,
      "e": 39113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 40913,
      "e": 39113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40994,
      "e": 39194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 41105,
      "e": 39305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41106,
      "e": 39306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41185,
      "e": 39385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41569,
      "e": 39769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41625,
      "e": 39825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a shif"
    },
    {
      "t": 41730,
      "e": 39930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41785,
      "e": 39985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a shi"
    },
    {
      "t": 41889,
      "e": 40089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41962,
      "e": 40162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a sh"
    },
    {
      "t": 42074,
      "e": 40274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42113,
      "e": 40313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a s"
    },
    {
      "t": 42233,
      "e": 40433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42305,
      "e": 40505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a "
    },
    {
      "t": 42705,
      "e": 40905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42706,
      "e": 40906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42770,
      "e": 40970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 42842,
      "e": 41042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42842,
      "e": 41042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42905,
      "e": 41105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43033,
      "e": 41233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43034,
      "e": 41234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43090,
      "e": 41290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43178,
      "e": 41378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43178,
      "e": 41378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43241,
      "e": 41441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43354,
      "e": 41554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43355,
      "e": 41555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43424,
      "e": 41624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43529,
      "e": 41729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 43530,
      "e": 41730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43617,
      "e": 41817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 45193,
      "e": 43393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45194,
      "e": 43394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45265,
      "e": 43465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46701,
      "e": 44901,
      "ty": 2,
      "x": 1677,
      "y": 685
    },
    {
      "t": 46751,
      "e": 44951,
      "ty": 41,
      "x": 59514,
      "y": 37134,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 46802,
      "e": 45002,
      "ty": 2,
      "x": 1717,
      "y": 660
    },
    {
      "t": 47002,
      "e": 45202,
      "ty": 41,
      "x": 59514,
      "y": 37063,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 47301,
      "e": 45501,
      "ty": 2,
      "x": 1269,
      "y": 658
    },
    {
      "t": 47401,
      "e": 45601,
      "ty": 2,
      "x": 1240,
      "y": 627
    },
    {
      "t": 47501,
      "e": 45701,
      "ty": 2,
      "x": 1316,
      "y": 597
    },
    {
      "t": 47502,
      "e": 45702,
      "ty": 41,
      "x": 37349,
      "y": 32874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47602,
      "e": 45802,
      "ty": 2,
      "x": 654,
      "y": 691
    },
    {
      "t": 47702,
      "e": 45902,
      "ty": 2,
      "x": 597,
      "y": 689
    },
    {
      "t": 47752,
      "e": 45952,
      "ty": 41,
      "x": 56306,
      "y": 37337,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47802,
      "e": 46002,
      "ty": 2,
      "x": 382,
      "y": 615
    },
    {
      "t": 47807,
      "e": 46007,
      "ty": 6,
      "x": 320,
      "y": 592,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47901,
      "e": 46101,
      "ty": 2,
      "x": 325,
      "y": 553
    },
    {
      "t": 48002,
      "e": 46202,
      "ty": 2,
      "x": 383,
      "y": 542
    },
    {
      "t": 48002,
      "e": 46202,
      "ty": 41,
      "x": 32138,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48101,
      "e": 46301,
      "ty": 2,
      "x": 502,
      "y": 558
    },
    {
      "t": 48202,
      "e": 46402,
      "ty": 2,
      "x": 508,
      "y": 557
    },
    {
      "t": 48252,
      "e": 46452,
      "ty": 41,
      "x": 46189,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48440,
      "e": 46640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48441,
      "e": 46641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48577,
      "e": 46777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 48658,
      "e": 46858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48658,
      "e": 46858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48745,
      "e": 46945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 48786,
      "e": 46986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 48787,
      "e": 46987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48888,
      "e": 47088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 48912,
      "e": 47112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48913,
      "e": 47113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49009,
      "e": 47209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49025,
      "e": 47225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49025,
      "e": 47225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49097,
      "e": 47297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49129,
      "e": 47329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49130,
      "e": 47330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49208,
      "e": 47408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 49257,
      "e": 47457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49257,
      "e": 47457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49338,
      "e": 47538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49361,
      "e": 47561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49362,
      "e": 47562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49434,
      "e": 47634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49931,
      "e": 48131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49931,
      "e": 48131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50003,
      "e": 48132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50065,
      "e": 48194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50065,
      "e": 48194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50137,
      "e": 48266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 50265,
      "e": 48394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50266,
      "e": 48395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50360,
      "e": 48489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 50417,
      "e": 48546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50417,
      "e": 48546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50481,
      "e": 48610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50603,
      "e": 48732,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time"
    },
    {
      "t": 50609,
      "e": 48738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50609,
      "e": 48738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50673,
      "e": 48802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50803,
      "e": 48932,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time "
    },
    {
      "t": 50897,
      "e": 49026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50899,
      "e": 49028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50952,
      "e": 49081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 50985,
      "e": 49114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50985,
      "e": 49114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51041,
      "e": 49170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51129,
      "e": 49258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51130,
      "e": 49259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51193,
      "e": 49322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51266,
      "e": 49395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51266,
      "e": 49395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51338,
      "e": 49467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51961,
      "e": 50090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51964,
      "e": 50093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52017,
      "e": 50146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52209,
      "e": 50338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52210,
      "e": 50339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52290,
      "e": 50419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 52377,
      "e": 50506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52378,
      "e": 50507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52457,
      "e": 50586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52504,
      "e": 50633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52505,
      "e": 50634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52553,
      "e": 50682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52553,
      "e": 50682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52593,
      "e": 50722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 52650,
      "e": 50779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52690,
      "e": 50819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52690,
      "e": 50819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52769,
      "e": 50898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52777,
      "e": 50906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52778,
      "e": 50907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52833,
      "e": 50962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52873,
      "e": 51002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52874,
      "e": 51003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52969,
      "e": 51098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53033,
      "e": 51162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 53033,
      "e": 51162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53097,
      "e": 51226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 53199,
      "e": 51328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53200,
      "e": 51329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53254,
      "e": 51383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 53327,
      "e": 51456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53328,
      "e": 51457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53390,
      "e": 51519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53423,
      "e": 51552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53423,
      "e": 51552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53495,
      "e": 51624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53601,
      "e": 51730,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time meet on the grap"
    },
    {
      "t": 53615,
      "e": 51744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53616,
      "e": 51745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53678,
      "e": 51807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 53801,
      "e": 51930,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time meet on the graph"
    },
    {
      "t": 54249,
      "e": 52378,
      "ty": 41,
      "x": 49337,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54300,
      "e": 52429,
      "ty": 2,
      "x": 536,
      "y": 545
    },
    {
      "t": 54961,
      "e": 53090,
      "ty": 7,
      "x": 525,
      "y": 624,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54999,
      "e": 53128,
      "ty": 2,
      "x": 523,
      "y": 651
    },
    {
      "t": 55000,
      "e": 53129,
      "ty": 41,
      "x": 47876,
      "y": 35620,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 55099,
      "e": 53228,
      "ty": 2,
      "x": 503,
      "y": 658
    },
    {
      "t": 55200,
      "e": 53329,
      "ty": 2,
      "x": 384,
      "y": 609
    },
    {
      "t": 55211,
      "e": 53340,
      "ty": 6,
      "x": 385,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55250,
      "e": 53379,
      "ty": 41,
      "x": 38321,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55260,
      "e": 53389,
      "ty": 7,
      "x": 486,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55299,
      "e": 53428,
      "ty": 2,
      "x": 541,
      "y": 501
    },
    {
      "t": 55361,
      "e": 53490,
      "ty": 6,
      "x": 557,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55398,
      "e": 53527,
      "ty": 2,
      "x": 562,
      "y": 599
    },
    {
      "t": 55410,
      "e": 53539,
      "ty": 7,
      "x": 559,
      "y": 632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55500,
      "e": 53629,
      "ty": 2,
      "x": 533,
      "y": 686
    },
    {
      "t": 55500,
      "e": 53629,
      "ty": 41,
      "x": 49000,
      "y": 37559,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 55600,
      "e": 53729,
      "ty": 2,
      "x": 528,
      "y": 708
    },
    {
      "t": 55699,
      "e": 53828,
      "ty": 2,
      "x": 497,
      "y": 664
    },
    {
      "t": 55745,
      "e": 53874,
      "ty": 6,
      "x": 477,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55749,
      "e": 53878,
      "ty": 41,
      "x": 42705,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55800,
      "e": 53929,
      "ty": 2,
      "x": 474,
      "y": 557
    },
    {
      "t": 55900,
      "e": 54029,
      "ty": 2,
      "x": 460,
      "y": 540
    },
    {
      "t": 55999,
      "e": 54128,
      "ty": 2,
      "x": 400,
      "y": 539
    },
    {
      "t": 55999,
      "e": 54128,
      "ty": 41,
      "x": 34049,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56100,
      "e": 54229,
      "ty": 2,
      "x": 383,
      "y": 536
    },
    {
      "t": 56199,
      "e": 54328,
      "ty": 2,
      "x": 378,
      "y": 535
    },
    {
      "t": 56249,
      "e": 54378,
      "ty": 41,
      "x": 31913,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56299,
      "e": 54428,
      "ty": 2,
      "x": 438,
      "y": 531
    },
    {
      "t": 56399,
      "e": 54528,
      "ty": 2,
      "x": 459,
      "y": 531
    },
    {
      "t": 56499,
      "e": 54628,
      "ty": 41,
      "x": 40681,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56599,
      "e": 54728,
      "ty": 2,
      "x": 455,
      "y": 531
    },
    {
      "t": 56699,
      "e": 54828,
      "ty": 2,
      "x": 453,
      "y": 531
    },
    {
      "t": 56749,
      "e": 54878,
      "ty": 41,
      "x": 39782,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56756,
      "e": 54885,
      "ty": 3,
      "x": 451,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56799,
      "e": 54928,
      "ty": 2,
      "x": 451,
      "y": 531
    },
    {
      "t": 56852,
      "e": 54981,
      "ty": 4,
      "x": 39782,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56852,
      "e": 54981,
      "ty": 5,
      "x": 451,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56922,
      "e": 55051,
      "ty": 3,
      "x": 451,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57003,
      "e": 55052,
      "ty": 4,
      "x": 39782,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57004,
      "e": 55053,
      "ty": 5,
      "x": 451,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57046,
      "e": 55095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57046,
      "e": 55095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57134,
      "e": 55183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and atime meet on the graph"
    },
    {
      "t": 57178,
      "e": 55227,
      "ty": 7,
      "x": 462,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57199,
      "e": 55248,
      "ty": 2,
      "x": 499,
      "y": 731
    },
    {
      "t": 57249,
      "e": 55298,
      "ty": 41,
      "x": 48550,
      "y": 43209,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 57298,
      "e": 55347,
      "ty": 2,
      "x": 536,
      "y": 790
    },
    {
      "t": 57399,
      "e": 55448,
      "ty": 2,
      "x": 547,
      "y": 770
    },
    {
      "t": 57499,
      "e": 55548,
      "ty": 2,
      "x": 559,
      "y": 680
    },
    {
      "t": 57499,
      "e": 55548,
      "ty": 41,
      "x": 51922,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 57559,
      "e": 55608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57560,
      "e": 55609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57599,
      "e": 55648,
      "ty": 2,
      "x": 564,
      "y": 663
    },
    {
      "t": 57622,
      "e": 55671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and a time meet on the graph"
    },
    {
      "t": 57698,
      "e": 55747,
      "ty": 2,
      "x": 564,
      "y": 662
    },
    {
      "t": 57749,
      "e": 55798,
      "ty": 41,
      "x": 52484,
      "y": 36229,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 57898,
      "e": 55947,
      "ty": 2,
      "x": 541,
      "y": 623
    },
    {
      "t": 57946,
      "e": 55995,
      "ty": 6,
      "x": 518,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57999,
      "e": 56048,
      "ty": 2,
      "x": 479,
      "y": 557
    },
    {
      "t": 57999,
      "e": 56048,
      "ty": 41,
      "x": 42930,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58098,
      "e": 56147,
      "ty": 2,
      "x": 430,
      "y": 543
    },
    {
      "t": 58199,
      "e": 56248,
      "ty": 2,
      "x": 428,
      "y": 541
    },
    {
      "t": 58249,
      "e": 56298,
      "ty": 41,
      "x": 37197,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58599,
      "e": 56648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58663,
      "e": 56712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and atime meet on the graph"
    },
    {
      "t": 58759,
      "e": 56808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58822,
      "e": 56871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and time meet on the graph"
    },
    {
      "t": 58967,
      "e": 57016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58968,
      "e": 57017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59031,
      "e": 57080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and ttime meet on the graph"
    },
    {
      "t": 59102,
      "e": 57151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59103,
      "e": 57152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59158,
      "e": 57207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and thtime meet on the graph"
    },
    {
      "t": 59231,
      "e": 57280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59232,
      "e": 57281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59295,
      "e": 57344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and thetime meet on the graph"
    },
    {
      "t": 59401,
      "e": 57450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and thetime meet on the graph"
    },
    {
      "t": 59464,
      "e": 57513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59464,
      "e": 57513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59503,
      "e": 57552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time meet on the graph"
    },
    {
      "t": 59931,
      "e": 57980,
      "ty": 7,
      "x": 423,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59999,
      "e": 58048,
      "ty": 2,
      "x": 421,
      "y": 728
    },
    {
      "t": 59999,
      "e": 58048,
      "ty": 41,
      "x": 36410,
      "y": 39886,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 60098,
      "e": 58147,
      "ty": 2,
      "x": 407,
      "y": 750
    },
    {
      "t": 60199,
      "e": 58248,
      "ty": 2,
      "x": 400,
      "y": 734
    },
    {
      "t": 60250,
      "e": 58299,
      "ty": 41,
      "x": 38106,
      "y": 63087,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 60299,
      "e": 58348,
      "ty": 6,
      "x": 418,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 60301,
      "e": 58350,
      "ty": 2,
      "x": 418,
      "y": 681
    },
    {
      "t": 60395,
      "e": 58444,
      "ty": 3,
      "x": 424,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 60396,
      "e": 58445,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I use the mouse to line up where a letter and the time meet on the graph"
    },
    {
      "t": 60396,
      "e": 58445,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60397,
      "e": 58446,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 60399,
      "e": 58448,
      "ty": 2,
      "x": 424,
      "y": 667
    },
    {
      "t": 60491,
      "e": 58540,
      "ty": 4,
      "x": 46642,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 60500,
      "e": 58549,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 60501,
      "e": 58550,
      "ty": 5,
      "x": 424,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 60507,
      "e": 58556,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 60509,
      "e": 58558,
      "ty": 41,
      "x": 14326,
      "y": 36506,
      "ta": "html > body"
    },
    {
      "t": 60749,
      "e": 58798,
      "ty": 41,
      "x": 14704,
      "y": 36839,
      "ta": "html > body"
    },
    {
      "t": 60800,
      "e": 58849,
      "ty": 2,
      "x": 568,
      "y": 749
    },
    {
      "t": 60899,
      "e": 58948,
      "ty": 2,
      "x": 746,
      "y": 767
    },
    {
      "t": 60999,
      "e": 59048,
      "ty": 41,
      "x": 25415,
      "y": 42046,
      "ta": "html > body"
    },
    {
      "t": 61499,
      "e": 59548,
      "ty": 2,
      "x": 697,
      "y": 932
    },
    {
      "t": 61500,
      "e": 59549,
      "ty": 41,
      "x": 23727,
      "y": 51187,
      "ta": "html > body"
    },
    {
      "t": 61509,
      "e": 59558,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 61599,
      "e": 59648,
      "ty": 2,
      "x": 686,
      "y": 952
    },
    {
      "t": 61749,
      "e": 59798,
      "ty": 41,
      "x": 23348,
      "y": 52295,
      "ta": "html > body"
    },
    {
      "t": 62099,
      "e": 60148,
      "ty": 2,
      "x": 687,
      "y": 952
    },
    {
      "t": 62165,
      "e": 60214,
      "ty": 6,
      "x": 827,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62182,
      "e": 60231,
      "ty": 7,
      "x": 872,
      "y": 579,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62199,
      "e": 60248,
      "ty": 2,
      "x": 872,
      "y": 579
    },
    {
      "t": 62249,
      "e": 60298,
      "ty": 41,
      "x": 32027,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 62299,
      "e": 60348,
      "ty": 2,
      "x": 940,
      "y": 450
    },
    {
      "t": 62399,
      "e": 60448,
      "ty": 2,
      "x": 945,
      "y": 485
    },
    {
      "t": 62499,
      "e": 60548,
      "ty": 2,
      "x": 963,
      "y": 534
    },
    {
      "t": 62499,
      "e": 60548,
      "ty": 41,
      "x": 33524,
      "y": 60853,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 62533,
      "e": 60582,
      "ty": 6,
      "x": 971,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62599,
      "e": 60648,
      "ty": 2,
      "x": 973,
      "y": 568
    },
    {
      "t": 62750,
      "e": 60799,
      "ty": 41,
      "x": 36119,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62796,
      "e": 60845,
      "ty": 3,
      "x": 975,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62797,
      "e": 60846,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62799,
      "e": 60848,
      "ty": 2,
      "x": 975,
      "y": 567
    },
    {
      "t": 62890,
      "e": 60939,
      "ty": 4,
      "x": 36119,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62890,
      "e": 60939,
      "ty": 5,
      "x": 975,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63431,
      "e": 61480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 63432,
      "e": 61481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63510,
      "e": 61559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 63615,
      "e": 61664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "101"
    },
    {
      "t": 63615,
      "e": 61664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63671,
      "e": 61720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "25"
    },
    {
      "t": 63760,
      "e": 61809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 63760,
      "e": 61809,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "25"
    },
    {
      "t": 63761,
      "e": 61810,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63761,
      "e": 61810,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63823,
      "e": 61872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 64111,
      "e": 62160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 64367,
      "e": 62416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 64543,
      "e": 62592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 64543,
      "e": 62592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64606,
      "e": 62655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "t"
    },
    {
      "t": 64630,
      "e": 62679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 64631,
      "e": 62680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64702,
      "e": 62751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "th"
    },
    {
      "t": 64759,
      "e": 62808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 64759,
      "e": 62808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64839,
      "e": 62888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the"
    },
    {
      "t": 64879,
      "e": 62928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 64880,
      "e": 62929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64950,
      "e": 62999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the "
    },
    {
      "t": 64983,
      "e": 63032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 65095,
      "e": 63144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 65096,
      "e": 63145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65159,
      "e": 63208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||P"
    },
    {
      "t": 65183,
      "e": 63232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 65279,
      "e": 63328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 65280,
      "e": 63329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65359,
      "e": 63408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||h"
    },
    {
      "t": 65422,
      "e": 63471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 65423,
      "e": 63472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65487,
      "e": 63536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 65600,
      "e": 63649,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the Phi"
    },
    {
      "t": 65607,
      "e": 63656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 65608,
      "e": 63657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65654,
      "e": 63703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||l"
    },
    {
      "t": 65750,
      "e": 63799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 65751,
      "e": 63800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65831,
      "e": 63880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 66663,
      "e": 64712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 66663,
      "e": 64712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66726,
      "e": 64775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 66799,
      "e": 64848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 66799,
      "e": 64848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66855,
      "e": 64904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 66951,
      "e": 65000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 66951,
      "e": 65000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67007,
      "e": 65056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 67135,
      "e": 65184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 67136,
      "e": 65185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67190,
      "e": 65239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 67230,
      "e": 65279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 67230,
      "e": 65279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67287,
      "e": 65336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 67401,
      "e": 65450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the Philippine"
    },
    {
      "t": 67407,
      "e": 65456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 67408,
      "e": 65457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67462,
      "e": 65511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 67600,
      "e": 65649,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the Philippines"
    },
    {
      "t": 67972,
      "e": 66021,
      "ty": 7,
      "x": 984,
      "y": 618,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67999,
      "e": 66048,
      "ty": 2,
      "x": 986,
      "y": 626
    },
    {
      "t": 68000,
      "e": 66049,
      "ty": 41,
      "x": 38499,
      "y": 58513,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 68099,
      "e": 66148,
      "ty": 2,
      "x": 984,
      "y": 640
    },
    {
      "t": 68106,
      "e": 66155,
      "ty": 6,
      "x": 981,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68122,
      "e": 66171,
      "ty": 7,
      "x": 973,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68122,
      "e": 66171,
      "ty": 6,
      "x": 973,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68156,
      "e": 66205,
      "ty": 7,
      "x": 958,
      "y": 714,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68200,
      "e": 66206,
      "ty": 2,
      "x": 957,
      "y": 714
    },
    {
      "t": 68249,
      "e": 66255,
      "ty": 41,
      "x": 32681,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 68256,
      "e": 66262,
      "ty": 6,
      "x": 961,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68299,
      "e": 66305,
      "ty": 2,
      "x": 969,
      "y": 681
    },
    {
      "t": 68322,
      "e": 66328,
      "ty": 7,
      "x": 971,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68400,
      "e": 66406,
      "ty": 2,
      "x": 971,
      "y": 673
    },
    {
      "t": 68421,
      "e": 66427,
      "ty": 6,
      "x": 971,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68500,
      "e": 66506,
      "ty": 2,
      "x": 971,
      "y": 702
    },
    {
      "t": 68500,
      "e": 66506,
      "ty": 41,
      "x": 38694,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68599,
      "e": 66605,
      "ty": 2,
      "x": 972,
      "y": 702
    },
    {
      "t": 68699,
      "e": 66705,
      "ty": 2,
      "x": 973,
      "y": 702
    },
    {
      "t": 68731,
      "e": 66737,
      "ty": 3,
      "x": 973,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68732,
      "e": 66738,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the Philippines"
    },
    {
      "t": 68733,
      "e": 66739,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68733,
      "e": 66739,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68749,
      "e": 66755,
      "ty": 41,
      "x": 39725,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68810,
      "e": 66816,
      "ty": 4,
      "x": 39725,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68810,
      "e": 66816,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68811,
      "e": 66817,
      "ty": 5,
      "x": 973,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68811,
      "e": 66817,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 69100,
      "e": 67106,
      "ty": 2,
      "x": 973,
      "y": 712
    },
    {
      "t": 69200,
      "e": 67206,
      "ty": 2,
      "x": 999,
      "y": 802
    },
    {
      "t": 69250,
      "e": 67256,
      "ty": 41,
      "x": 34162,
      "y": 44040,
      "ta": "html > body"
    },
    {
      "t": 69300,
      "e": 67306,
      "ty": 2,
      "x": 1001,
      "y": 804
    },
    {
      "t": 69399,
      "e": 67405,
      "ty": 2,
      "x": 1009,
      "y": 782
    },
    {
      "t": 69499,
      "e": 67505,
      "ty": 2,
      "x": 996,
      "y": 725
    },
    {
      "t": 69499,
      "e": 67505,
      "ty": 41,
      "x": 34024,
      "y": 39719,
      "ta": "html > body"
    },
    {
      "t": 69599,
      "e": 67605,
      "ty": 2,
      "x": 966,
      "y": 653
    },
    {
      "t": 69750,
      "e": 67756,
      "ty": 41,
      "x": 32991,
      "y": 35731,
      "ta": "html > body"
    },
    {
      "t": 69829,
      "e": 67835,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 70399,
      "e": 68405,
      "ty": 2,
      "x": 967,
      "y": 581
    },
    {
      "t": 70500,
      "e": 68506,
      "ty": 2,
      "x": 944,
      "y": 439
    },
    {
      "t": 70500,
      "e": 68506,
      "ty": 41,
      "x": 29090,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 70600,
      "e": 68606,
      "ty": 2,
      "x": 931,
      "y": 383
    },
    {
      "t": 70699,
      "e": 68705,
      "ty": 2,
      "x": 1054,
      "y": 167
    },
    {
      "t": 70750,
      "e": 68756,
      "ty": 41,
      "x": 36435,
      "y": 7423,
      "ta": "html > body"
    },
    {
      "t": 70799,
      "e": 68805,
      "ty": 2,
      "x": 1018,
      "y": 141
    },
    {
      "t": 70900,
      "e": 68906,
      "ty": 2,
      "x": 819,
      "y": 189
    },
    {
      "t": 71000,
      "e": 69006,
      "ty": 2,
      "x": 822,
      "y": 241
    },
    {
      "t": 71000,
      "e": 69006,
      "ty": 41,
      "x": 473,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71099,
      "e": 69105,
      "ty": 2,
      "x": 845,
      "y": 251
    },
    {
      "t": 71199,
      "e": 69205,
      "ty": 2,
      "x": 858,
      "y": 243
    },
    {
      "t": 71250,
      "e": 69256,
      "ty": 41,
      "x": 31590,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71300,
      "e": 69306,
      "ty": 2,
      "x": 861,
      "y": 243
    },
    {
      "t": 71399,
      "e": 69405,
      "ty": 2,
      "x": 881,
      "y": 305
    },
    {
      "t": 71499,
      "e": 69505,
      "ty": 2,
      "x": 882,
      "y": 312
    },
    {
      "t": 71500,
      "e": 69506,
      "ty": 41,
      "x": 14376,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 71599,
      "e": 69605,
      "ty": 2,
      "x": 882,
      "y": 314
    },
    {
      "t": 71699,
      "e": 69705,
      "ty": 2,
      "x": 874,
      "y": 318
    },
    {
      "t": 71750,
      "e": 69756,
      "ty": 41,
      "x": 51202,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71764,
      "e": 69770,
      "ty": 3,
      "x": 873,
      "y": 318,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71799,
      "e": 69805,
      "ty": 2,
      "x": 873,
      "y": 318
    },
    {
      "t": 71851,
      "e": 69857,
      "ty": 4,
      "x": 51202,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71851,
      "e": 69857,
      "ty": 5,
      "x": 873,
      "y": 318,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71853,
      "e": 69859,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 71855,
      "e": 69861,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 71999,
      "e": 70005,
      "ty": 2,
      "x": 873,
      "y": 327
    },
    {
      "t": 72000,
      "e": 70006,
      "ty": 41,
      "x": 51202,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 72100,
      "e": 70106,
      "ty": 2,
      "x": 883,
      "y": 390
    },
    {
      "t": 72199,
      "e": 70205,
      "ty": 2,
      "x": 884,
      "y": 508
    },
    {
      "t": 72250,
      "e": 70256,
      "ty": 41,
      "x": 14851,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 72400,
      "e": 70406,
      "ty": 2,
      "x": 900,
      "y": 419
    },
    {
      "t": 72500,
      "e": 70506,
      "ty": 2,
      "x": 901,
      "y": 415
    },
    {
      "t": 72500,
      "e": 70506,
      "ty": 41,
      "x": 18885,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 72600,
      "e": 70606,
      "ty": 2,
      "x": 902,
      "y": 414
    },
    {
      "t": 72699,
      "e": 70705,
      "ty": 2,
      "x": 915,
      "y": 388
    },
    {
      "t": 72749,
      "e": 70755,
      "ty": 41,
      "x": 22683,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 72800,
      "e": 70806,
      "ty": 2,
      "x": 926,
      "y": 386
    },
    {
      "t": 72900,
      "e": 70906,
      "ty": 2,
      "x": 967,
      "y": 387
    },
    {
      "t": 73000,
      "e": 71006,
      "ty": 2,
      "x": 930,
      "y": 384
    },
    {
      "t": 73000,
      "e": 71006,
      "ty": 41,
      "x": 25768,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 73100,
      "e": 71106,
      "ty": 2,
      "x": 879,
      "y": 455
    },
    {
      "t": 73200,
      "e": 71206,
      "ty": 2,
      "x": 910,
      "y": 519
    },
    {
      "t": 73250,
      "e": 71256,
      "ty": 41,
      "x": 21496,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 73300,
      "e": 71306,
      "ty": 2,
      "x": 911,
      "y": 532
    },
    {
      "t": 73399,
      "e": 71405,
      "ty": 2,
      "x": 900,
      "y": 533
    },
    {
      "t": 73500,
      "e": 71506,
      "ty": 2,
      "x": 883,
      "y": 533
    },
    {
      "t": 73500,
      "e": 71506,
      "ty": 41,
      "x": 14614,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 73600,
      "e": 71606,
      "ty": 2,
      "x": 875,
      "y": 536
    },
    {
      "t": 73700,
      "e": 71706,
      "ty": 2,
      "x": 874,
      "y": 524
    },
    {
      "t": 73750,
      "e": 71706,
      "ty": 41,
      "x": 61530,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 74099,
      "e": 72055,
      "ty": 2,
      "x": 881,
      "y": 546
    },
    {
      "t": 74199,
      "e": 72155,
      "ty": 2,
      "x": 886,
      "y": 564
    },
    {
      "t": 74250,
      "e": 72206,
      "ty": 41,
      "x": 15563,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 74300,
      "e": 72256,
      "ty": 2,
      "x": 890,
      "y": 564
    },
    {
      "t": 74399,
      "e": 72355,
      "ty": 2,
      "x": 890,
      "y": 507
    },
    {
      "t": 74499,
      "e": 72455,
      "ty": 2,
      "x": 886,
      "y": 483
    },
    {
      "t": 74500,
      "e": 72456,
      "ty": 41,
      "x": 15325,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 74600,
      "e": 72556,
      "ty": 2,
      "x": 881,
      "y": 519
    },
    {
      "t": 74700,
      "e": 72656,
      "ty": 2,
      "x": 878,
      "y": 530
    },
    {
      "t": 74750,
      "e": 72706,
      "ty": 41,
      "x": 13427,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 74900,
      "e": 72856,
      "ty": 2,
      "x": 870,
      "y": 512
    },
    {
      "t": 75000,
      "e": 72956,
      "ty": 2,
      "x": 868,
      "y": 509
    },
    {
      "t": 75000,
      "e": 72956,
      "ty": 41,
      "x": 11054,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 75199,
      "e": 73155,
      "ty": 2,
      "x": 868,
      "y": 517
    },
    {
      "t": 75250,
      "e": 73206,
      "ty": 41,
      "x": 54508,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 75400,
      "e": 73356,
      "ty": 2,
      "x": 872,
      "y": 501
    },
    {
      "t": 75499,
      "e": 73455,
      "ty": 2,
      "x": 875,
      "y": 495
    },
    {
      "t": 75499,
      "e": 73455,
      "ty": 41,
      "x": 48088,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 75699,
      "e": 73655,
      "ty": 2,
      "x": 878,
      "y": 495
    },
    {
      "t": 75750,
      "e": 73706,
      "ty": 41,
      "x": 50781,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 76099,
      "e": 74055,
      "ty": 2,
      "x": 894,
      "y": 501
    },
    {
      "t": 76250,
      "e": 74206,
      "ty": 41,
      "x": 65142,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 76900,
      "e": 74856,
      "ty": 2,
      "x": 884,
      "y": 517
    },
    {
      "t": 77000,
      "e": 74956,
      "ty": 2,
      "x": 878,
      "y": 517
    },
    {
      "t": 77000,
      "e": 74956,
      "ty": 41,
      "x": 13427,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 77100,
      "e": 75056,
      "ty": 2,
      "x": 875,
      "y": 517
    },
    {
      "t": 77107,
      "e": 75063,
      "ty": 3,
      "x": 875,
      "y": 517,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77108,
      "e": 75064,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 77211,
      "e": 75167,
      "ty": 4,
      "x": 62700,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77211,
      "e": 75167,
      "ty": 5,
      "x": 875,
      "y": 517,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77212,
      "e": 75168,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 77214,
      "e": 75170,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 77249,
      "e": 75205,
      "ty": 41,
      "x": 62700,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77499,
      "e": 75455,
      "ty": 2,
      "x": 1022,
      "y": 571
    },
    {
      "t": 77499,
      "e": 75455,
      "ty": 41,
      "x": 47602,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 77598,
      "e": 75554,
      "ty": 2,
      "x": 1143,
      "y": 556
    },
    {
      "t": 77700,
      "e": 75656,
      "ty": 2,
      "x": 1149,
      "y": 499
    },
    {
      "t": 77749,
      "e": 75705,
      "ty": 41,
      "x": 39327,
      "y": 26867,
      "ta": "html > body"
    },
    {
      "t": 77798,
      "e": 75754,
      "ty": 2,
      "x": 1152,
      "y": 490
    },
    {
      "t": 77900,
      "e": 75856,
      "ty": 2,
      "x": 1154,
      "y": 489
    },
    {
      "t": 77900,
      "e": 75856,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 77999,
      "e": 75955,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 77999,
      "e": 75955,
      "ty": 41,
      "x": 39465,
      "y": 26646,
      "ta": "html > body"
    },
    {
      "t": 78100,
      "e": 76056,
      "ty": 2,
      "x": 1139,
      "y": 527
    },
    {
      "t": 78199,
      "e": 76155,
      "ty": 2,
      "x": 1117,
      "y": 553
    },
    {
      "t": 78249,
      "e": 76205,
      "ty": 41,
      "x": 38191,
      "y": 30191,
      "ta": "html > body"
    },
    {
      "t": 78299,
      "e": 76255,
      "ty": 2,
      "x": 1114,
      "y": 566
    },
    {
      "t": 78399,
      "e": 76355,
      "ty": 2,
      "x": 966,
      "y": 778
    },
    {
      "t": 78499,
      "e": 76455,
      "ty": 2,
      "x": 931,
      "y": 812
    },
    {
      "t": 78499,
      "e": 76455,
      "ty": 41,
      "x": 64677,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 78600,
      "e": 76556,
      "ty": 2,
      "x": 935,
      "y": 716
    },
    {
      "t": 78699,
      "e": 76655,
      "ty": 2,
      "x": 934,
      "y": 692
    },
    {
      "t": 78749,
      "e": 76705,
      "ty": 41,
      "x": 26717,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 78799,
      "e": 76755,
      "ty": 2,
      "x": 934,
      "y": 689
    },
    {
      "t": 78899,
      "e": 76855,
      "ty": 2,
      "x": 939,
      "y": 678
    },
    {
      "t": 78999,
      "e": 76955,
      "ty": 2,
      "x": 909,
      "y": 735
    },
    {
      "t": 78999,
      "e": 76955,
      "ty": 41,
      "x": 21980,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 79099,
      "e": 77055,
      "ty": 2,
      "x": 902,
      "y": 748
    },
    {
      "t": 79199,
      "e": 77155,
      "ty": 2,
      "x": 891,
      "y": 767
    },
    {
      "t": 79251,
      "e": 77157,
      "ty": 41,
      "x": 35592,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 79299,
      "e": 77205,
      "ty": 2,
      "x": 881,
      "y": 783
    },
    {
      "t": 79399,
      "e": 77305,
      "ty": 2,
      "x": 881,
      "y": 784
    },
    {
      "t": 79499,
      "e": 77405,
      "ty": 2,
      "x": 899,
      "y": 750
    },
    {
      "t": 79499,
      "e": 77405,
      "ty": 41,
      "x": 32369,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 79599,
      "e": 77505,
      "ty": 2,
      "x": 920,
      "y": 719
    },
    {
      "t": 79699,
      "e": 77605,
      "ty": 2,
      "x": 935,
      "y": 697
    },
    {
      "t": 79749,
      "e": 77655,
      "ty": 41,
      "x": 28378,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 79799,
      "e": 77705,
      "ty": 2,
      "x": 942,
      "y": 688
    },
    {
      "t": 79999,
      "e": 77905,
      "ty": 2,
      "x": 943,
      "y": 687
    },
    {
      "t": 79999,
      "e": 77905,
      "ty": 41,
      "x": 28853,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 80249,
      "e": 78155,
      "ty": 41,
      "x": 29328,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 80299,
      "e": 78205,
      "ty": 2,
      "x": 945,
      "y": 688
    },
    {
      "t": 80400,
      "e": 78306,
      "ty": 2,
      "x": 945,
      "y": 693
    },
    {
      "t": 80499,
      "e": 78405,
      "ty": 2,
      "x": 945,
      "y": 707
    },
    {
      "t": 80499,
      "e": 78405,
      "ty": 41,
      "x": 31139,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80635,
      "e": 78541,
      "ty": 3,
      "x": 945,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80636,
      "e": 78542,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 80722,
      "e": 78628,
      "ty": 4,
      "x": 31139,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80722,
      "e": 78628,
      "ty": 5,
      "x": 945,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80722,
      "e": 78628,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80723,
      "e": 78629,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 81099,
      "e": 79005,
      "ty": 2,
      "x": 1251,
      "y": 800
    },
    {
      "t": 81199,
      "e": 79105,
      "ty": 2,
      "x": 1287,
      "y": 808
    },
    {
      "t": 81249,
      "e": 79155,
      "ty": 41,
      "x": 44045,
      "y": 44373,
      "ta": "html > body"
    },
    {
      "t": 81299,
      "e": 79205,
      "ty": 2,
      "x": 1287,
      "y": 809
    },
    {
      "t": 81700,
      "e": 79606,
      "ty": 2,
      "x": 1155,
      "y": 892
    },
    {
      "t": 81749,
      "e": 79655,
      "ty": 41,
      "x": 60655,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 81799,
      "e": 79705,
      "ty": 2,
      "x": 1031,
      "y": 940
    },
    {
      "t": 81899,
      "e": 79805,
      "ty": 2,
      "x": 937,
      "y": 950
    },
    {
      "t": 81999,
      "e": 79905,
      "ty": 2,
      "x": 808,
      "y": 955
    },
    {
      "t": 81999,
      "e": 79905,
      "ty": 41,
      "x": 27377,
      "y": 52516,
      "ta": "html > body"
    },
    {
      "t": 82099,
      "e": 80005,
      "ty": 2,
      "x": 798,
      "y": 964
    },
    {
      "t": 82199,
      "e": 80105,
      "ty": 2,
      "x": 835,
      "y": 972
    },
    {
      "t": 82250,
      "e": 80156,
      "ty": 41,
      "x": 32015,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 82299,
      "e": 80205,
      "ty": 2,
      "x": 863,
      "y": 962
    },
    {
      "t": 82396,
      "e": 80302,
      "ty": 3,
      "x": 863,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 82397,
      "e": 80303,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82466,
      "e": 80372,
      "ty": 4,
      "x": 33633,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 82466,
      "e": 80372,
      "ty": 5,
      "x": 863,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 82467,
      "e": 80373,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 82467,
      "e": 80373,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 82499,
      "e": 80405,
      "ty": 41,
      "x": 33633,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 82684,
      "e": 80590,
      "ty": 6,
      "x": 880,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82699,
      "e": 80605,
      "ty": 2,
      "x": 880,
      "y": 1014
    },
    {
      "t": 82749,
      "e": 80655,
      "ty": 41,
      "x": 27098,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82799,
      "e": 80705,
      "ty": 2,
      "x": 882,
      "y": 1017
    },
    {
      "t": 82899,
      "e": 80805,
      "ty": 2,
      "x": 883,
      "y": 1019
    },
    {
      "t": 82999,
      "e": 80905,
      "ty": 2,
      "x": 884,
      "y": 1020
    },
    {
      "t": 82999,
      "e": 80905,
      "ty": 41,
      "x": 28128,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83200,
      "e": 80906,
      "ty": 2,
      "x": 884,
      "y": 1021
    },
    {
      "t": 83249,
      "e": 80955,
      "ty": 41,
      "x": 28128,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83508,
      "e": 81214,
      "ty": 3,
      "x": 884,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83509,
      "e": 81215,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 83509,
      "e": 81215,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83562,
      "e": 81268,
      "ty": 4,
      "x": 28644,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83562,
      "e": 81268,
      "ty": 5,
      "x": 885,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83565,
      "e": 81271,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 83565,
      "e": 81271,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 83566,
      "e": 81272,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 83599,
      "e": 81305,
      "ty": 2,
      "x": 885,
      "y": 1022
    },
    {
      "t": 83699,
      "e": 81405,
      "ty": 2,
      "x": 884,
      "y": 1023
    },
    {
      "t": 83750,
      "e": 81456,
      "ty": 41,
      "x": 30167,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 83999,
      "e": 81705,
      "ty": 2,
      "x": 1295,
      "y": 934
    },
    {
      "t": 84000,
      "e": 81706,
      "ty": 41,
      "x": 44321,
      "y": 51297,
      "ta": "html > body"
    },
    {
      "t": 84099,
      "e": 81805,
      "ty": 2,
      "x": 1355,
      "y": 845
    },
    {
      "t": 84199,
      "e": 81905,
      "ty": 2,
      "x": 1109,
      "y": 649
    },
    {
      "t": 84250,
      "e": 81956,
      "ty": 41,
      "x": 32991,
      "y": 30579,
      "ta": "html > body"
    },
    {
      "t": 84299,
      "e": 82005,
      "ty": 2,
      "x": 922,
      "y": 528
    },
    {
      "t": 84399,
      "e": 82105,
      "ty": 2,
      "x": 916,
      "y": 518
    },
    {
      "t": 84499,
      "e": 82205,
      "ty": 2,
      "x": 915,
      "y": 517
    },
    {
      "t": 84499,
      "e": 82205,
      "ty": 41,
      "x": 31235,
      "y": 28197,
      "ta": "html > body"
    },
    {
      "t": 84913,
      "e": 82619,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 84999,
      "e": 82705,
      "ty": 2,
      "x": 915,
      "y": 516
    },
    {
      "t": 84999,
      "e": 82705,
      "ty": 41,
      "x": 30578,
      "y": 13074,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85499,
      "e": 83205,
      "ty": 2,
      "x": 858,
      "y": 529
    },
    {
      "t": 85500,
      "e": 83206,
      "ty": 41,
      "x": 27774,
      "y": 18145,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85600,
      "e": 83306,
      "ty": 2,
      "x": 526,
      "y": 663
    },
    {
      "t": 85699,
      "e": 83405,
      "ty": 2,
      "x": 533,
      "y": 670
    },
    {
      "t": 85750,
      "e": 83456,
      "ty": 41,
      "x": 13802,
      "y": 2642,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85799,
      "e": 83505,
      "ty": 2,
      "x": 586,
      "y": 671
    },
    {
      "t": 85899,
      "e": 83605,
      "ty": 2,
      "x": 610,
      "y": 725
    },
    {
      "t": 85999,
      "e": 83705,
      "ty": 2,
      "x": 856,
      "y": 1145
    },
    {
      "t": 86000,
      "e": 83706,
      "ty": 41,
      "x": 29203,
      "y": 62986,
      "ta": "> div.masterdiv"
    },
    {
      "t": 86099,
      "e": 83805,
      "ty": 2,
      "x": 931,
      "y": 1197
    },
    {
      "t": 86199,
      "e": 83905,
      "ty": 2,
      "x": 1010,
      "y": 1208
    },
    {
      "t": 86250,
      "e": 83956,
      "ty": 41,
      "x": 62024,
      "y": 61111,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86299,
      "e": 84005,
      "ty": 2,
      "x": 1032,
      "y": 1137
    },
    {
      "t": 86400,
      "e": 84106,
      "ty": 2,
      "x": 1032,
      "y": 1121
    },
    {
      "t": 86499,
      "e": 84205,
      "ty": 2,
      "x": 997,
      "y": 1109
    },
    {
      "t": 86500,
      "e": 84206,
      "ty": 41,
      "x": 50321,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86505,
      "e": 84211,
      "ty": 6,
      "x": 987,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 86599,
      "e": 84305,
      "ty": 2,
      "x": 981,
      "y": 1103
    },
    {
      "t": 86699,
      "e": 84405,
      "ty": 2,
      "x": 981,
      "y": 1101
    },
    {
      "t": 86749,
      "e": 84455,
      "ty": 41,
      "x": 39594,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 86799,
      "e": 84505,
      "ty": 2,
      "x": 982,
      "y": 1101
    },
    {
      "t": 87714,
      "e": 85420,
      "ty": 3,
      "x": 982,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 87716,
      "e": 85422,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87762,
      "e": 85468,
      "ty": 4,
      "x": 39594,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 87762,
      "e": 85468,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87763,
      "e": 85469,
      "ty": 5,
      "x": 982,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 87763,
      "e": 85469,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88799,
      "e": 86505,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 90000,
      "e": 87706,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90312,
      "e": 88018,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 80298, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 80302, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 17594, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 99217, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8538, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"golf\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 108761, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 46211, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 156068, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 20466, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 177536, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 51939, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 231084, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-10 AM-11 AM-11 AM-11 AM-11 AM-C -C -11 AM-O -A -12 PM-F -I -A -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:895,y:1025,t:1527019558351};\\\", \\\"{x:900,y:1023,t:1527019558360};\\\", \\\"{x:908,y:1022,t:1527019558377};\\\", \\\"{x:909,y:1022,t:1527019558406};\\\", \\\"{x:913,y:1022,t:1527019559566};\\\", \\\"{x:919,y:1024,t:1527019559578};\\\", \\\"{x:946,y:1033,t:1527019559594};\\\", \\\"{x:991,y:1040,t:1527019559611};\\\", \\\"{x:1060,y:1047,t:1527019559628};\\\", \\\"{x:1128,y:1052,t:1527019559645};\\\", \\\"{x:1212,y:1052,t:1527019559661};\\\", \\\"{x:1337,y:1052,t:1527019559678};\\\", \\\"{x:1409,y:1052,t:1527019559694};\\\", \\\"{x:1462,y:1052,t:1527019559711};\\\", \\\"{x:1490,y:1052,t:1527019559728};\\\", \\\"{x:1502,y:1053,t:1527019559745};\\\", \\\"{x:1508,y:1053,t:1527019559761};\\\", \\\"{x:1510,y:1053,t:1527019559778};\\\", \\\"{x:1513,y:1053,t:1527019559794};\\\", \\\"{x:1515,y:1053,t:1527019559810};\\\", \\\"{x:1520,y:1051,t:1527019559827};\\\", \\\"{x:1525,y:1049,t:1527019559844};\\\", \\\"{x:1529,y:1047,t:1527019559861};\\\", \\\"{x:1534,y:1045,t:1527019559877};\\\", \\\"{x:1536,y:1044,t:1527019559894};\\\", \\\"{x:1540,y:1041,t:1527019559911};\\\", \\\"{x:1543,y:1041,t:1527019559927};\\\", \\\"{x:1545,y:1039,t:1527019559945};\\\", \\\"{x:1546,y:1038,t:1527019559962};\\\", \\\"{x:1548,y:1036,t:1527019559977};\\\", \\\"{x:1549,y:1036,t:1527019559995};\\\", \\\"{x:1549,y:1035,t:1527019560011};\\\", \\\"{x:1548,y:1032,t:1527019560045};\\\", \\\"{x:1530,y:1024,t:1527019560061};\\\", \\\"{x:1504,y:1020,t:1527019560077};\\\", \\\"{x:1447,y:1012,t:1527019560094};\\\", \\\"{x:1381,y:1003,t:1527019560111};\\\", \\\"{x:1319,y:995,t:1527019560127};\\\", \\\"{x:1275,y:989,t:1527019560144};\\\", \\\"{x:1245,y:986,t:1527019560161};\\\", \\\"{x:1221,y:981,t:1527019560178};\\\", \\\"{x:1203,y:978,t:1527019560194};\\\", \\\"{x:1194,y:976,t:1527019560212};\\\", \\\"{x:1192,y:976,t:1527019560227};\\\", \\\"{x:1190,y:976,t:1527019560461};\\\", \\\"{x:1188,y:976,t:1527019560478};\\\", \\\"{x:1187,y:976,t:1527019560495};\\\", \\\"{x:1188,y:976,t:1527019560597};\\\", \\\"{x:1191,y:976,t:1527019560611};\\\", \\\"{x:1197,y:976,t:1527019560629};\\\", \\\"{x:1204,y:975,t:1527019560644};\\\", \\\"{x:1216,y:973,t:1527019560662};\\\", \\\"{x:1226,y:973,t:1527019560678};\\\", \\\"{x:1234,y:973,t:1527019560694};\\\", \\\"{x:1244,y:973,t:1527019560713};\\\", \\\"{x:1255,y:973,t:1527019560729};\\\", \\\"{x:1264,y:973,t:1527019560745};\\\", \\\"{x:1266,y:973,t:1527019560761};\\\", \\\"{x:1268,y:973,t:1527019560779};\\\", \\\"{x:1269,y:974,t:1527019560990};\\\", \\\"{x:1270,y:975,t:1527019561006};\\\", \\\"{x:1272,y:976,t:1527019561014};\\\", \\\"{x:1274,y:976,t:1527019561030};\\\", \\\"{x:1278,y:976,t:1527019561046};\\\", \\\"{x:1279,y:976,t:1527019561062};\\\", \\\"{x:1280,y:976,t:1527019561079};\\\", \\\"{x:1281,y:976,t:1527019561096};\\\", \\\"{x:1282,y:976,t:1527019561112};\\\", \\\"{x:1283,y:974,t:1527019561326};\\\", \\\"{x:1283,y:973,t:1527019561342};\\\", \\\"{x:1283,y:971,t:1527019561350};\\\", \\\"{x:1283,y:970,t:1527019561366};\\\", \\\"{x:1283,y:968,t:1527019561379};\\\", \\\"{x:1282,y:965,t:1527019561396};\\\", \\\"{x:1282,y:964,t:1527019561412};\\\", \\\"{x:1282,y:963,t:1527019561446};\\\", \\\"{x:1281,y:962,t:1527019561687};\\\", \\\"{x:1281,y:960,t:1527019561696};\\\", \\\"{x:1278,y:958,t:1527019561713};\\\", \\\"{x:1278,y:957,t:1527019561741};\\\", \\\"{x:1277,y:956,t:1527019561870};\\\", \\\"{x:1276,y:956,t:1527019561999};\\\", \\\"{x:1275,y:956,t:1527019562013};\\\", \\\"{x:1271,y:957,t:1527019562030};\\\", \\\"{x:1269,y:958,t:1527019562046};\\\", \\\"{x:1270,y:959,t:1527019562559};\\\", \\\"{x:1272,y:961,t:1527019562566};\\\", \\\"{x:1273,y:961,t:1527019562590};\\\", \\\"{x:1275,y:962,t:1527019562605};\\\", \\\"{x:1275,y:963,t:1527019562742};\\\", \\\"{x:1275,y:964,t:1527019562758};\\\", \\\"{x:1275,y:966,t:1527019562773};\\\", \\\"{x:1275,y:967,t:1527019562789};\\\", \\\"{x:1274,y:969,t:1527019562806};\\\", \\\"{x:1274,y:970,t:1527019562813};\\\", \\\"{x:1274,y:976,t:1527019562830};\\\", \\\"{x:1274,y:983,t:1527019562847};\\\", \\\"{x:1274,y:988,t:1527019562865};\\\", \\\"{x:1274,y:992,t:1527019562880};\\\", \\\"{x:1275,y:992,t:1527019563150};\\\", \\\"{x:1275,y:991,t:1527019563166};\\\", \\\"{x:1275,y:989,t:1527019563181};\\\", \\\"{x:1276,y:986,t:1527019563197};\\\", \\\"{x:1276,y:980,t:1527019563214};\\\", \\\"{x:1277,y:976,t:1527019563230};\\\", \\\"{x:1277,y:974,t:1527019563247};\\\", \\\"{x:1277,y:972,t:1527019563264};\\\", \\\"{x:1277,y:971,t:1527019563294};\\\", \\\"{x:1277,y:970,t:1527019563326};\\\", \\\"{x:1278,y:969,t:1527019563501};\\\", \\\"{x:1278,y:968,t:1527019563514};\\\", \\\"{x:1280,y:966,t:1527019563530};\\\", \\\"{x:1280,y:964,t:1527019563547};\\\", \\\"{x:1280,y:962,t:1527019563563};\\\", \\\"{x:1281,y:961,t:1527019563583};\\\", \\\"{x:1281,y:960,t:1527019563974};\\\", \\\"{x:1281,y:959,t:1527019563982};\\\", \\\"{x:1281,y:957,t:1527019563998};\\\", \\\"{x:1281,y:956,t:1527019564017};\\\", \\\"{x:1281,y:954,t:1527019564030};\\\", \\\"{x:1281,y:953,t:1527019564047};\\\", \\\"{x:1281,y:952,t:1527019564063};\\\", \\\"{x:1281,y:951,t:1527019564080};\\\", \\\"{x:1281,y:948,t:1527019564098};\\\", \\\"{x:1281,y:947,t:1527019564113};\\\", \\\"{x:1281,y:945,t:1527019564131};\\\", \\\"{x:1281,y:944,t:1527019564147};\\\", \\\"{x:1281,y:941,t:1527019564164};\\\", \\\"{x:1281,y:940,t:1527019564181};\\\", \\\"{x:1282,y:935,t:1527019564197};\\\", \\\"{x:1282,y:931,t:1527019564213};\\\", \\\"{x:1282,y:928,t:1527019564230};\\\", \\\"{x:1282,y:924,t:1527019564248};\\\", \\\"{x:1283,y:920,t:1527019564265};\\\", \\\"{x:1283,y:919,t:1527019564281};\\\", \\\"{x:1283,y:914,t:1527019564297};\\\", \\\"{x:1283,y:912,t:1527019564315};\\\", \\\"{x:1283,y:907,t:1527019564330};\\\", \\\"{x:1283,y:905,t:1527019564348};\\\", \\\"{x:1283,y:902,t:1527019564365};\\\", \\\"{x:1283,y:900,t:1527019564380};\\\", \\\"{x:1283,y:895,t:1527019564397};\\\", \\\"{x:1283,y:892,t:1527019564414};\\\", \\\"{x:1283,y:887,t:1527019564431};\\\", \\\"{x:1283,y:883,t:1527019564447};\\\", \\\"{x:1283,y:882,t:1527019564465};\\\", \\\"{x:1283,y:880,t:1527019564481};\\\", \\\"{x:1283,y:878,t:1527019564498};\\\", \\\"{x:1283,y:875,t:1527019564515};\\\", \\\"{x:1283,y:873,t:1527019564532};\\\", \\\"{x:1283,y:870,t:1527019564549};\\\", \\\"{x:1283,y:867,t:1527019564566};\\\", \\\"{x:1283,y:864,t:1527019564581};\\\", \\\"{x:1283,y:859,t:1527019564597};\\\", \\\"{x:1283,y:858,t:1527019564614};\\\", \\\"{x:1283,y:856,t:1527019564637};\\\", \\\"{x:1283,y:853,t:1527019564647};\\\", \\\"{x:1283,y:850,t:1527019564664};\\\", \\\"{x:1283,y:849,t:1527019564681};\\\", \\\"{x:1283,y:846,t:1527019564698};\\\", \\\"{x:1283,y:845,t:1527019564715};\\\", \\\"{x:1283,y:843,t:1527019564731};\\\", \\\"{x:1283,y:841,t:1527019564747};\\\", \\\"{x:1284,y:839,t:1527019564764};\\\", \\\"{x:1284,y:834,t:1527019564781};\\\", \\\"{x:1284,y:829,t:1527019564797};\\\", \\\"{x:1284,y:824,t:1527019564814};\\\", \\\"{x:1284,y:821,t:1527019564832};\\\", \\\"{x:1284,y:817,t:1527019564847};\\\", \\\"{x:1284,y:811,t:1527019564864};\\\", \\\"{x:1284,y:803,t:1527019564882};\\\", \\\"{x:1284,y:797,t:1527019564898};\\\", \\\"{x:1284,y:792,t:1527019564914};\\\", \\\"{x:1284,y:788,t:1527019564932};\\\", \\\"{x:1284,y:783,t:1527019564948};\\\", \\\"{x:1284,y:780,t:1527019564965};\\\", \\\"{x:1284,y:776,t:1527019564981};\\\", \\\"{x:1284,y:773,t:1527019564997};\\\", \\\"{x:1284,y:771,t:1527019565015};\\\", \\\"{x:1284,y:770,t:1527019565032};\\\", \\\"{x:1284,y:768,t:1527019565048};\\\", \\\"{x:1284,y:766,t:1527019565065};\\\", \\\"{x:1284,y:764,t:1527019565083};\\\", \\\"{x:1284,y:763,t:1527019565099};\\\", \\\"{x:1284,y:761,t:1527019565116};\\\", \\\"{x:1284,y:759,t:1527019565132};\\\", \\\"{x:1284,y:757,t:1527019565148};\\\", \\\"{x:1284,y:755,t:1527019565165};\\\", \\\"{x:1284,y:751,t:1527019565182};\\\", \\\"{x:1284,y:748,t:1527019565198};\\\", \\\"{x:1284,y:744,t:1527019565215};\\\", \\\"{x:1284,y:741,t:1527019565232};\\\", \\\"{x:1284,y:738,t:1527019565250};\\\", \\\"{x:1284,y:734,t:1527019565265};\\\", \\\"{x:1284,y:731,t:1527019565282};\\\", \\\"{x:1284,y:727,t:1527019565299};\\\", \\\"{x:1284,y:723,t:1527019565315};\\\", \\\"{x:1284,y:720,t:1527019565333};\\\", \\\"{x:1284,y:716,t:1527019565350};\\\", \\\"{x:1284,y:713,t:1527019565365};\\\", \\\"{x:1284,y:710,t:1527019565382};\\\", \\\"{x:1284,y:709,t:1527019565398};\\\", \\\"{x:1284,y:706,t:1527019565415};\\\", \\\"{x:1284,y:702,t:1527019565432};\\\", \\\"{x:1284,y:697,t:1527019565449};\\\", \\\"{x:1285,y:695,t:1527019565465};\\\", \\\"{x:1285,y:692,t:1527019565482};\\\", \\\"{x:1285,y:689,t:1527019565499};\\\", \\\"{x:1285,y:686,t:1527019565516};\\\", \\\"{x:1285,y:685,t:1527019565533};\\\", \\\"{x:1285,y:683,t:1527019565550};\\\", \\\"{x:1285,y:681,t:1527019565565};\\\", \\\"{x:1285,y:677,t:1527019565583};\\\", \\\"{x:1285,y:673,t:1527019565599};\\\", \\\"{x:1285,y:669,t:1527019565615};\\\", \\\"{x:1285,y:665,t:1527019565632};\\\", \\\"{x:1285,y:660,t:1527019565649};\\\", \\\"{x:1284,y:654,t:1527019565666};\\\", \\\"{x:1284,y:651,t:1527019565682};\\\", \\\"{x:1282,y:647,t:1527019565699};\\\", \\\"{x:1281,y:642,t:1527019565716};\\\", \\\"{x:1281,y:639,t:1527019565732};\\\", \\\"{x:1281,y:636,t:1527019565749};\\\", \\\"{x:1280,y:628,t:1527019565766};\\\", \\\"{x:1280,y:624,t:1527019565783};\\\", \\\"{x:1278,y:620,t:1527019565799};\\\", \\\"{x:1277,y:615,t:1527019565816};\\\", \\\"{x:1277,y:613,t:1527019565832};\\\", \\\"{x:1277,y:611,t:1527019565850};\\\", \\\"{x:1277,y:608,t:1527019565866};\\\", \\\"{x:1277,y:605,t:1527019565883};\\\", \\\"{x:1277,y:604,t:1527019565899};\\\", \\\"{x:1277,y:601,t:1527019565916};\\\", \\\"{x:1277,y:598,t:1527019565932};\\\", \\\"{x:1277,y:596,t:1527019565950};\\\", \\\"{x:1277,y:592,t:1527019565967};\\\", \\\"{x:1277,y:590,t:1527019565982};\\\", \\\"{x:1277,y:588,t:1527019565999};\\\", \\\"{x:1277,y:585,t:1527019566016};\\\", \\\"{x:1277,y:582,t:1527019566032};\\\", \\\"{x:1277,y:580,t:1527019566049};\\\", \\\"{x:1277,y:579,t:1527019566066};\\\", \\\"{x:1277,y:577,t:1527019566083};\\\", \\\"{x:1277,y:575,t:1527019566099};\\\", \\\"{x:1277,y:571,t:1527019566116};\\\", \\\"{x:1277,y:565,t:1527019566132};\\\", \\\"{x:1277,y:562,t:1527019566149};\\\", \\\"{x:1277,y:561,t:1527019566166};\\\", \\\"{x:1278,y:558,t:1527019566182};\\\", \\\"{x:1278,y:564,t:1527019570614};\\\", \\\"{x:1277,y:576,t:1527019570622};\\\", \\\"{x:1277,y:588,t:1527019570637};\\\", \\\"{x:1277,y:614,t:1527019570653};\\\", \\\"{x:1277,y:656,t:1527019570669};\\\", \\\"{x:1289,y:752,t:1527019570686};\\\", \\\"{x:1296,y:786,t:1527019570703};\\\", \\\"{x:1297,y:809,t:1527019570719};\\\", \\\"{x:1297,y:829,t:1527019570737};\\\", \\\"{x:1297,y:847,t:1527019570753};\\\", \\\"{x:1297,y:866,t:1527019570770};\\\", \\\"{x:1297,y:876,t:1527019570786};\\\", \\\"{x:1297,y:882,t:1527019570802};\\\", \\\"{x:1297,y:887,t:1527019570820};\\\", \\\"{x:1297,y:889,t:1527019570837};\\\", \\\"{x:1297,y:890,t:1527019570852};\\\", \\\"{x:1297,y:894,t:1527019570869};\\\", \\\"{x:1297,y:903,t:1527019570886};\\\", \\\"{x:1297,y:910,t:1527019570902};\\\", \\\"{x:1297,y:916,t:1527019570919};\\\", \\\"{x:1293,y:924,t:1527019570937};\\\", \\\"{x:1292,y:929,t:1527019570953};\\\", \\\"{x:1291,y:937,t:1527019570970};\\\", \\\"{x:1289,y:950,t:1527019570987};\\\", \\\"{x:1286,y:963,t:1527019571004};\\\", \\\"{x:1286,y:973,t:1527019571021};\\\", \\\"{x:1284,y:978,t:1527019571036};\\\", \\\"{x:1284,y:980,t:1527019571053};\\\", \\\"{x:1284,y:981,t:1527019571069};\\\", \\\"{x:1283,y:981,t:1527019571262};\\\", \\\"{x:1283,y:980,t:1527019571278};\\\", \\\"{x:1283,y:979,t:1527019571286};\\\", \\\"{x:1283,y:978,t:1527019571303};\\\", \\\"{x:1283,y:976,t:1527019571319};\\\", \\\"{x:1283,y:975,t:1527019571350};\\\", \\\"{x:1283,y:974,t:1527019571366};\\\", \\\"{x:1283,y:973,t:1527019571398};\\\", \\\"{x:1283,y:972,t:1527019571438};\\\", \\\"{x:1283,y:971,t:1527019571454};\\\", \\\"{x:1283,y:970,t:1527019571470};\\\", \\\"{x:1283,y:969,t:1527019571558};\\\", \\\"{x:1282,y:969,t:1527019572079};\\\", \\\"{x:1282,y:967,t:1527019572089};\\\", \\\"{x:1282,y:964,t:1527019572103};\\\", \\\"{x:1282,y:961,t:1527019572121};\\\", \\\"{x:1282,y:960,t:1527019572137};\\\", \\\"{x:1281,y:959,t:1527019572154};\\\", \\\"{x:1280,y:958,t:1527019572171};\\\", \\\"{x:1279,y:957,t:1527019572190};\\\", \\\"{x:1278,y:956,t:1527019572343};\\\", \\\"{x:1277,y:956,t:1527019572358};\\\", \\\"{x:1276,y:954,t:1527019572606};\\\", \\\"{x:1275,y:951,t:1527019572621};\\\", \\\"{x:1271,y:942,t:1527019572637};\\\", \\\"{x:1269,y:937,t:1527019572654};\\\", \\\"{x:1267,y:934,t:1527019572671};\\\", \\\"{x:1263,y:926,t:1527019572688};\\\", \\\"{x:1260,y:921,t:1527019572705};\\\", \\\"{x:1257,y:913,t:1527019572721};\\\", \\\"{x:1255,y:906,t:1527019572737};\\\", \\\"{x:1252,y:901,t:1527019572755};\\\", \\\"{x:1250,y:896,t:1527019572771};\\\", \\\"{x:1248,y:892,t:1527019572788};\\\", \\\"{x:1246,y:889,t:1527019572804};\\\", \\\"{x:1244,y:885,t:1527019572821};\\\", \\\"{x:1244,y:883,t:1527019572837};\\\", \\\"{x:1241,y:879,t:1527019572854};\\\", \\\"{x:1241,y:877,t:1527019572870};\\\", \\\"{x:1240,y:875,t:1527019572887};\\\", \\\"{x:1237,y:872,t:1527019572905};\\\", \\\"{x:1237,y:870,t:1527019572921};\\\", \\\"{x:1235,y:867,t:1527019572938};\\\", \\\"{x:1235,y:866,t:1527019572954};\\\", \\\"{x:1234,y:865,t:1527019572972};\\\", \\\"{x:1233,y:864,t:1527019572988};\\\", \\\"{x:1231,y:862,t:1527019573004};\\\", \\\"{x:1229,y:858,t:1527019573021};\\\", \\\"{x:1227,y:856,t:1527019573037};\\\", \\\"{x:1226,y:855,t:1527019573054};\\\", \\\"{x:1225,y:854,t:1527019573072};\\\", \\\"{x:1224,y:853,t:1527019573087};\\\", \\\"{x:1223,y:852,t:1527019573118};\\\", \\\"{x:1221,y:850,t:1527019573134};\\\", \\\"{x:1220,y:849,t:1527019573158};\\\", \\\"{x:1219,y:849,t:1527019573174};\\\", \\\"{x:1218,y:847,t:1527019573187};\\\", \\\"{x:1217,y:847,t:1527019573206};\\\", \\\"{x:1216,y:846,t:1527019573222};\\\", \\\"{x:1215,y:844,t:1527019573254};\\\", \\\"{x:1214,y:844,t:1527019573366};\\\", \\\"{x:1213,y:844,t:1527019573374};\\\", \\\"{x:1213,y:843,t:1527019573422};\\\", \\\"{x:1213,y:840,t:1527019574342};\\\", \\\"{x:1213,y:838,t:1527019574356};\\\", \\\"{x:1213,y:835,t:1527019574376};\\\", \\\"{x:1213,y:834,t:1527019574388};\\\", \\\"{x:1212,y:827,t:1527019574405};\\\", \\\"{x:1212,y:825,t:1527019574421};\\\", \\\"{x:1212,y:823,t:1527019574439};\\\", \\\"{x:1211,y:821,t:1527019574455};\\\", \\\"{x:1211,y:819,t:1527019574476};\\\", \\\"{x:1211,y:810,t:1527019578087};\\\", \\\"{x:1211,y:783,t:1527019578094};\\\", \\\"{x:1214,y:751,t:1527019578107};\\\", \\\"{x:1232,y:695,t:1527019578124};\\\", \\\"{x:1244,y:653,t:1527019578141};\\\", \\\"{x:1251,y:636,t:1527019578158};\\\", \\\"{x:1256,y:624,t:1527019578174};\\\", \\\"{x:1259,y:612,t:1527019578191};\\\", \\\"{x:1260,y:607,t:1527019578207};\\\", \\\"{x:1264,y:601,t:1527019578224};\\\", \\\"{x:1265,y:598,t:1527019578242};\\\", \\\"{x:1267,y:594,t:1527019578258};\\\", \\\"{x:1269,y:591,t:1527019578274};\\\", \\\"{x:1271,y:590,t:1527019578292};\\\", \\\"{x:1272,y:589,t:1527019578318};\\\", \\\"{x:1273,y:588,t:1527019578326};\\\", \\\"{x:1275,y:585,t:1527019578341};\\\", \\\"{x:1278,y:581,t:1527019578358};\\\", \\\"{x:1281,y:577,t:1527019578375};\\\", \\\"{x:1284,y:574,t:1527019578392};\\\", \\\"{x:1284,y:573,t:1527019578414};\\\", \\\"{x:1284,y:572,t:1527019578445};\\\", \\\"{x:1284,y:571,t:1527019578526};\\\", \\\"{x:1284,y:570,t:1527019578565};\\\", \\\"{x:1284,y:569,t:1527019578582};\\\", \\\"{x:1284,y:568,t:1527019578622};\\\", \\\"{x:1284,y:567,t:1527019578637};\\\", \\\"{x:1284,y:566,t:1527019578654};\\\", \\\"{x:1284,y:565,t:1527019578661};\\\", \\\"{x:1284,y:564,t:1527019578675};\\\", \\\"{x:1284,y:563,t:1527019578691};\\\", \\\"{x:1284,y:561,t:1527019578709};\\\", \\\"{x:1284,y:560,t:1527019578726};\\\", \\\"{x:1284,y:559,t:1527019581526};\\\", \\\"{x:1284,y:569,t:1527019581544};\\\", \\\"{x:1284,y:579,t:1527019581561};\\\", \\\"{x:1284,y:584,t:1527019581578};\\\", \\\"{x:1284,y:587,t:1527019581594};\\\", \\\"{x:1284,y:589,t:1527019581611};\\\", \\\"{x:1284,y:591,t:1527019581627};\\\", \\\"{x:1284,y:594,t:1527019581644};\\\", \\\"{x:1284,y:601,t:1527019581661};\\\", \\\"{x:1284,y:610,t:1527019581678};\\\", \\\"{x:1284,y:617,t:1527019581694};\\\", \\\"{x:1283,y:622,t:1527019581711};\\\", \\\"{x:1283,y:630,t:1527019581728};\\\", \\\"{x:1283,y:634,t:1527019581745};\\\", \\\"{x:1283,y:640,t:1527019581761};\\\", \\\"{x:1280,y:650,t:1527019581778};\\\", \\\"{x:1279,y:660,t:1527019581794};\\\", \\\"{x:1278,y:673,t:1527019581811};\\\", \\\"{x:1275,y:685,t:1527019581828};\\\", \\\"{x:1275,y:693,t:1527019581844};\\\", \\\"{x:1275,y:704,t:1527019581861};\\\", \\\"{x:1274,y:721,t:1527019581878};\\\", \\\"{x:1274,y:739,t:1527019581894};\\\", \\\"{x:1274,y:751,t:1527019581911};\\\", \\\"{x:1275,y:764,t:1527019581928};\\\", \\\"{x:1275,y:769,t:1527019581944};\\\", \\\"{x:1275,y:775,t:1527019581961};\\\", \\\"{x:1275,y:778,t:1527019581978};\\\", \\\"{x:1275,y:780,t:1527019581995};\\\", \\\"{x:1275,y:786,t:1527019582011};\\\", \\\"{x:1275,y:790,t:1527019582028};\\\", \\\"{x:1275,y:797,t:1527019582045};\\\", \\\"{x:1275,y:811,t:1527019582061};\\\", \\\"{x:1275,y:827,t:1527019582078};\\\", \\\"{x:1275,y:839,t:1527019582094};\\\", \\\"{x:1275,y:848,t:1527019582112};\\\", \\\"{x:1275,y:859,t:1527019582128};\\\", \\\"{x:1275,y:871,t:1527019582145};\\\", \\\"{x:1275,y:880,t:1527019582161};\\\", \\\"{x:1274,y:889,t:1527019582178};\\\", \\\"{x:1274,y:893,t:1527019582195};\\\", \\\"{x:1274,y:900,t:1527019582211};\\\", \\\"{x:1274,y:904,t:1527019582228};\\\", \\\"{x:1274,y:907,t:1527019582245};\\\", \\\"{x:1274,y:910,t:1527019582261};\\\", \\\"{x:1274,y:912,t:1527019582278};\\\", \\\"{x:1274,y:915,t:1527019582295};\\\", \\\"{x:1274,y:919,t:1527019582311};\\\", \\\"{x:1274,y:925,t:1527019582328};\\\", \\\"{x:1274,y:929,t:1527019582345};\\\", \\\"{x:1274,y:933,t:1527019582361};\\\", \\\"{x:1274,y:937,t:1527019582378};\\\", \\\"{x:1274,y:940,t:1527019582395};\\\", \\\"{x:1274,y:946,t:1527019582411};\\\", \\\"{x:1274,y:950,t:1527019582428};\\\", \\\"{x:1274,y:956,t:1527019582446};\\\", \\\"{x:1274,y:962,t:1527019582461};\\\", \\\"{x:1274,y:966,t:1527019582478};\\\", \\\"{x:1274,y:970,t:1527019582495};\\\", \\\"{x:1274,y:973,t:1527019582511};\\\", \\\"{x:1274,y:964,t:1527019582718};\\\", \\\"{x:1274,y:956,t:1527019582729};\\\", \\\"{x:1274,y:942,t:1527019582745};\\\", \\\"{x:1274,y:930,t:1527019582762};\\\", \\\"{x:1274,y:920,t:1527019582778};\\\", \\\"{x:1274,y:913,t:1527019582795};\\\", \\\"{x:1274,y:905,t:1527019582812};\\\", \\\"{x:1274,y:901,t:1527019582828};\\\", \\\"{x:1274,y:896,t:1527019582845};\\\", \\\"{x:1274,y:890,t:1527019582862};\\\", \\\"{x:1274,y:885,t:1527019582878};\\\", \\\"{x:1274,y:881,t:1527019582895};\\\", \\\"{x:1274,y:876,t:1527019582912};\\\", \\\"{x:1274,y:872,t:1527019582928};\\\", \\\"{x:1274,y:870,t:1527019582945};\\\", \\\"{x:1274,y:865,t:1527019582962};\\\", \\\"{x:1274,y:862,t:1527019582978};\\\", \\\"{x:1274,y:860,t:1527019582995};\\\", \\\"{x:1274,y:858,t:1527019583012};\\\", \\\"{x:1274,y:857,t:1527019583029};\\\", \\\"{x:1274,y:854,t:1527019583045};\\\", \\\"{x:1274,y:848,t:1527019583062};\\\", \\\"{x:1274,y:845,t:1527019583078};\\\", \\\"{x:1274,y:842,t:1527019583095};\\\", \\\"{x:1274,y:839,t:1527019583112};\\\", \\\"{x:1274,y:835,t:1527019583129};\\\", \\\"{x:1273,y:833,t:1527019583145};\\\", \\\"{x:1273,y:827,t:1527019583162};\\\", \\\"{x:1271,y:822,t:1527019583179};\\\", \\\"{x:1271,y:817,t:1527019583195};\\\", \\\"{x:1271,y:815,t:1527019583213};\\\", \\\"{x:1271,y:812,t:1527019583229};\\\", \\\"{x:1270,y:810,t:1527019583245};\\\", \\\"{x:1270,y:806,t:1527019583262};\\\", \\\"{x:1270,y:802,t:1527019583279};\\\", \\\"{x:1270,y:798,t:1527019583295};\\\", \\\"{x:1270,y:793,t:1527019583312};\\\", \\\"{x:1270,y:788,t:1527019583329};\\\", \\\"{x:1270,y:783,t:1527019583345};\\\", \\\"{x:1270,y:777,t:1527019583362};\\\", \\\"{x:1270,y:772,t:1527019583379};\\\", \\\"{x:1270,y:764,t:1527019583395};\\\", \\\"{x:1270,y:756,t:1527019583412};\\\", \\\"{x:1270,y:752,t:1527019583429};\\\", \\\"{x:1270,y:748,t:1527019583446};\\\", \\\"{x:1269,y:741,t:1527019583462};\\\", \\\"{x:1269,y:738,t:1527019583479};\\\", \\\"{x:1269,y:735,t:1527019583496};\\\", \\\"{x:1269,y:731,t:1527019583512};\\\", \\\"{x:1269,y:728,t:1527019583529};\\\", \\\"{x:1270,y:725,t:1527019583546};\\\", \\\"{x:1270,y:722,t:1527019583561};\\\", \\\"{x:1270,y:721,t:1527019583578};\\\", \\\"{x:1271,y:718,t:1527019583595};\\\", \\\"{x:1271,y:716,t:1527019583611};\\\", \\\"{x:1272,y:712,t:1527019583629};\\\", \\\"{x:1272,y:709,t:1527019583645};\\\", \\\"{x:1272,y:707,t:1527019583661};\\\", \\\"{x:1272,y:704,t:1527019583678};\\\", \\\"{x:1273,y:702,t:1527019583696};\\\", \\\"{x:1273,y:701,t:1527019583711};\\\", \\\"{x:1273,y:699,t:1527019583728};\\\", \\\"{x:1274,y:698,t:1527019583745};\\\", \\\"{x:1275,y:695,t:1527019583762};\\\", \\\"{x:1275,y:693,t:1527019583778};\\\", \\\"{x:1275,y:691,t:1527019583795};\\\", \\\"{x:1275,y:689,t:1527019583811};\\\", \\\"{x:1277,y:688,t:1527019583829};\\\", \\\"{x:1277,y:686,t:1527019583846};\\\", \\\"{x:1277,y:685,t:1527019583877};\\\", \\\"{x:1277,y:684,t:1527019583910};\\\", \\\"{x:1277,y:683,t:1527019583925};\\\", \\\"{x:1277,y:682,t:1527019583965};\\\", \\\"{x:1277,y:679,t:1527019584598};\\\", \\\"{x:1278,y:669,t:1527019584614};\\\", \\\"{x:1278,y:642,t:1527019584630};\\\", \\\"{x:1278,y:629,t:1527019584646};\\\", \\\"{x:1278,y:619,t:1527019584664};\\\", \\\"{x:1278,y:611,t:1527019584680};\\\", \\\"{x:1278,y:605,t:1527019584696};\\\", \\\"{x:1278,y:601,t:1527019584713};\\\", \\\"{x:1278,y:598,t:1527019584729};\\\", \\\"{x:1279,y:594,t:1527019584745};\\\", \\\"{x:1279,y:591,t:1527019584762};\\\", \\\"{x:1279,y:587,t:1527019584779};\\\", \\\"{x:1279,y:584,t:1527019584795};\\\", \\\"{x:1280,y:581,t:1527019584812};\\\", \\\"{x:1280,y:579,t:1527019584829};\\\", \\\"{x:1280,y:577,t:1527019584846};\\\", \\\"{x:1280,y:576,t:1527019584869};\\\", \\\"{x:1280,y:574,t:1527019584885};\\\", \\\"{x:1280,y:573,t:1527019584902};\\\", \\\"{x:1280,y:571,t:1527019584917};\\\", \\\"{x:1281,y:571,t:1527019584929};\\\", \\\"{x:1281,y:570,t:1527019584946};\\\", \\\"{x:1281,y:568,t:1527019584965};\\\", \\\"{x:1282,y:566,t:1527019584998};\\\", \\\"{x:1282,y:572,t:1527019586047};\\\", \\\"{x:1280,y:588,t:1527019586064};\\\", \\\"{x:1275,y:603,t:1527019586081};\\\", \\\"{x:1274,y:611,t:1527019586097};\\\", \\\"{x:1273,y:619,t:1527019586114};\\\", \\\"{x:1273,y:622,t:1527019586131};\\\", \\\"{x:1273,y:623,t:1527019586147};\\\", \\\"{x:1271,y:624,t:1527019586317};\\\", \\\"{x:1270,y:626,t:1527019586331};\\\", \\\"{x:1267,y:627,t:1527019586347};\\\", \\\"{x:1264,y:628,t:1527019586363};\\\", \\\"{x:1263,y:629,t:1527019586380};\\\", \\\"{x:1262,y:629,t:1527019586671};\\\", \\\"{x:1261,y:630,t:1527019586686};\\\", \\\"{x:1260,y:630,t:1527019586698};\\\", \\\"{x:1259,y:630,t:1527019586714};\\\", \\\"{x:1258,y:630,t:1527019586731};\\\", \\\"{x:1257,y:630,t:1527019586748};\\\", \\\"{x:1256,y:630,t:1527019586764};\\\", \\\"{x:1255,y:630,t:1527019586886};\\\", \\\"{x:1253,y:630,t:1527019586991};\\\", \\\"{x:1252,y:630,t:1527019587015};\\\", \\\"{x:1251,y:630,t:1527019587031};\\\", \\\"{x:1249,y:630,t:1527019587150};\\\", \\\"{x:1248,y:630,t:1527019587198};\\\", \\\"{x:1247,y:632,t:1527019587438};\\\", \\\"{x:1247,y:636,t:1527019587449};\\\", \\\"{x:1247,y:642,t:1527019587465};\\\", \\\"{x:1247,y:649,t:1527019587483};\\\", \\\"{x:1247,y:653,t:1527019587498};\\\", \\\"{x:1247,y:659,t:1527019587515};\\\", \\\"{x:1247,y:660,t:1527019587532};\\\", \\\"{x:1247,y:663,t:1527019587548};\\\", \\\"{x:1247,y:666,t:1527019587566};\\\", \\\"{x:1247,y:669,t:1527019587582};\\\", \\\"{x:1247,y:672,t:1527019587598};\\\", \\\"{x:1247,y:675,t:1527019587615};\\\", \\\"{x:1247,y:679,t:1527019587632};\\\", \\\"{x:1247,y:682,t:1527019587649};\\\", \\\"{x:1247,y:686,t:1527019587665};\\\", \\\"{x:1245,y:687,t:1527019587682};\\\", \\\"{x:1245,y:689,t:1527019587699};\\\", \\\"{x:1245,y:690,t:1527019587715};\\\", \\\"{x:1245,y:692,t:1527019587732};\\\", \\\"{x:1245,y:694,t:1527019587748};\\\", \\\"{x:1245,y:696,t:1527019587765};\\\", \\\"{x:1245,y:699,t:1527019587782};\\\", \\\"{x:1245,y:700,t:1527019587800};\\\", \\\"{x:1245,y:702,t:1527019587816};\\\", \\\"{x:1245,y:703,t:1527019587838};\\\", \\\"{x:1246,y:704,t:1527019587849};\\\", \\\"{x:1246,y:706,t:1527019587866};\\\", \\\"{x:1246,y:709,t:1527019587882};\\\", \\\"{x:1246,y:710,t:1527019587898};\\\", \\\"{x:1246,y:711,t:1527019587915};\\\", \\\"{x:1246,y:712,t:1527019587934};\\\", \\\"{x:1246,y:713,t:1527019587966};\\\", \\\"{x:1246,y:715,t:1527019587982};\\\", \\\"{x:1248,y:716,t:1527019587999};\\\", \\\"{x:1248,y:718,t:1527019588015};\\\", \\\"{x:1248,y:721,t:1527019588032};\\\", \\\"{x:1248,y:722,t:1527019588050};\\\", \\\"{x:1248,y:724,t:1527019588065};\\\", \\\"{x:1248,y:725,t:1527019588083};\\\", \\\"{x:1248,y:728,t:1527019588099};\\\", \\\"{x:1248,y:734,t:1527019588115};\\\", \\\"{x:1248,y:739,t:1527019588132};\\\", \\\"{x:1248,y:745,t:1527019588150};\\\", \\\"{x:1248,y:749,t:1527019588165};\\\", \\\"{x:1248,y:752,t:1527019588183};\\\", \\\"{x:1248,y:753,t:1527019588199};\\\", \\\"{x:1248,y:757,t:1527019588215};\\\", \\\"{x:1248,y:763,t:1527019588232};\\\", \\\"{x:1248,y:768,t:1527019588250};\\\", \\\"{x:1248,y:771,t:1527019588265};\\\", \\\"{x:1248,y:773,t:1527019588282};\\\", \\\"{x:1248,y:774,t:1527019588299};\\\", \\\"{x:1248,y:776,t:1527019588316};\\\", \\\"{x:1248,y:777,t:1527019588333};\\\", \\\"{x:1248,y:779,t:1527019588350};\\\", \\\"{x:1248,y:781,t:1527019588365};\\\", \\\"{x:1248,y:783,t:1527019588381};\\\", \\\"{x:1248,y:784,t:1527019588399};\\\", \\\"{x:1248,y:786,t:1527019588416};\\\", \\\"{x:1248,y:787,t:1527019588437};\\\", \\\"{x:1248,y:788,t:1527019588453};\\\", \\\"{x:1248,y:789,t:1527019588466};\\\", \\\"{x:1248,y:790,t:1527019588484};\\\", \\\"{x:1248,y:791,t:1527019588501};\\\", \\\"{x:1248,y:792,t:1527019588516};\\\", \\\"{x:1248,y:793,t:1527019588533};\\\", \\\"{x:1248,y:795,t:1527019588548};\\\", \\\"{x:1248,y:798,t:1527019588565};\\\", \\\"{x:1248,y:799,t:1527019588582};\\\", \\\"{x:1247,y:802,t:1527019588599};\\\", \\\"{x:1247,y:805,t:1527019588616};\\\", \\\"{x:1247,y:808,t:1527019588632};\\\", \\\"{x:1247,y:810,t:1527019588649};\\\", \\\"{x:1247,y:812,t:1527019588667};\\\", \\\"{x:1245,y:816,t:1527019588682};\\\", \\\"{x:1245,y:819,t:1527019588699};\\\", \\\"{x:1244,y:824,t:1527019588716};\\\", \\\"{x:1243,y:829,t:1527019588731};\\\", \\\"{x:1243,y:831,t:1527019588749};\\\", \\\"{x:1241,y:840,t:1527019588766};\\\", \\\"{x:1241,y:846,t:1527019588785};\\\", \\\"{x:1240,y:849,t:1527019588799};\\\", \\\"{x:1240,y:854,t:1527019588816};\\\", \\\"{x:1240,y:856,t:1527019588833};\\\", \\\"{x:1240,y:858,t:1527019588849};\\\", \\\"{x:1238,y:860,t:1527019588866};\\\", \\\"{x:1238,y:862,t:1527019588884};\\\", \\\"{x:1237,y:864,t:1527019588899};\\\", \\\"{x:1237,y:866,t:1527019588916};\\\", \\\"{x:1237,y:869,t:1527019588934};\\\", \\\"{x:1237,y:870,t:1527019588949};\\\", \\\"{x:1237,y:874,t:1527019588966};\\\", \\\"{x:1237,y:876,t:1527019588984};\\\", \\\"{x:1237,y:879,t:1527019588999};\\\", \\\"{x:1237,y:882,t:1527019589016};\\\", \\\"{x:1237,y:883,t:1527019589033};\\\", \\\"{x:1237,y:885,t:1527019589049};\\\", \\\"{x:1237,y:888,t:1527019589067};\\\", \\\"{x:1237,y:889,t:1527019589083};\\\", \\\"{x:1237,y:892,t:1527019589100};\\\", \\\"{x:1238,y:893,t:1527019589116};\\\", \\\"{x:1238,y:895,t:1527019589133};\\\", \\\"{x:1238,y:898,t:1527019589150};\\\", \\\"{x:1238,y:901,t:1527019589166};\\\", \\\"{x:1238,y:902,t:1527019589186};\\\", \\\"{x:1239,y:904,t:1527019589199};\\\", \\\"{x:1239,y:905,t:1527019589216};\\\", \\\"{x:1239,y:907,t:1527019589233};\\\", \\\"{x:1239,y:908,t:1527019589249};\\\", \\\"{x:1240,y:911,t:1527019589266};\\\", \\\"{x:1240,y:913,t:1527019589286};\\\", \\\"{x:1240,y:914,t:1527019589302};\\\", \\\"{x:1241,y:916,t:1527019589316};\\\", \\\"{x:1241,y:917,t:1527019589333};\\\", \\\"{x:1241,y:920,t:1527019589350};\\\", \\\"{x:1242,y:923,t:1527019589366};\\\", \\\"{x:1242,y:926,t:1527019589383};\\\", \\\"{x:1242,y:927,t:1527019589400};\\\", \\\"{x:1242,y:929,t:1527019589415};\\\", \\\"{x:1242,y:930,t:1527019589437};\\\", \\\"{x:1242,y:931,t:1527019589533};\\\", \\\"{x:1242,y:932,t:1527019589550};\\\", \\\"{x:1243,y:934,t:1527019589638};\\\", \\\"{x:1244,y:934,t:1527019589650};\\\", \\\"{x:1244,y:937,t:1527019589666};\\\", \\\"{x:1244,y:942,t:1527019589683};\\\", \\\"{x:1244,y:944,t:1527019589700};\\\", \\\"{x:1244,y:945,t:1527019589717};\\\", \\\"{x:1244,y:946,t:1527019589733};\\\", \\\"{x:1244,y:947,t:1527019589790};\\\", \\\"{x:1244,y:948,t:1527019589854};\\\", \\\"{x:1244,y:949,t:1527019590022};\\\", \\\"{x:1245,y:950,t:1527019590033};\\\", \\\"{x:1245,y:951,t:1527019590054};\\\", \\\"{x:1245,y:952,t:1527019590070};\\\", \\\"{x:1245,y:953,t:1527019590118};\\\", \\\"{x:1245,y:954,t:1527019590182};\\\", \\\"{x:1245,y:955,t:1527019590286};\\\", \\\"{x:1245,y:956,t:1527019590342};\\\", \\\"{x:1245,y:957,t:1527019590366};\\\", \\\"{x:1245,y:958,t:1527019590380};\\\", \\\"{x:1245,y:959,t:1527019590397};\\\", \\\"{x:1245,y:960,t:1527019590405};\\\", \\\"{x:1245,y:961,t:1527019590417};\\\", \\\"{x:1245,y:962,t:1527019590434};\\\", \\\"{x:1245,y:963,t:1527019590450};\\\", \\\"{x:1246,y:964,t:1527019591015};\\\", \\\"{x:1247,y:964,t:1527019593734};\\\", \\\"{x:1248,y:964,t:1527019593742};\\\", \\\"{x:1250,y:964,t:1527019593758};\\\", \\\"{x:1251,y:963,t:1527019593774};\\\", \\\"{x:1254,y:963,t:1527019593786};\\\", \\\"{x:1256,y:963,t:1527019593804};\\\", \\\"{x:1261,y:962,t:1527019593819};\\\", \\\"{x:1265,y:961,t:1527019593837};\\\", \\\"{x:1272,y:961,t:1527019593854};\\\", \\\"{x:1277,y:961,t:1527019593870};\\\", \\\"{x:1286,y:961,t:1527019593886};\\\", \\\"{x:1294,y:961,t:1527019593903};\\\", \\\"{x:1297,y:961,t:1527019593919};\\\", \\\"{x:1299,y:961,t:1527019593937};\\\", \\\"{x:1300,y:960,t:1527019593954};\\\", \\\"{x:1300,y:958,t:1527019594286};\\\", \\\"{x:1300,y:948,t:1527019594303};\\\", \\\"{x:1301,y:934,t:1527019594320};\\\", \\\"{x:1305,y:916,t:1527019594337};\\\", \\\"{x:1305,y:905,t:1527019594354};\\\", \\\"{x:1305,y:890,t:1527019594370};\\\", \\\"{x:1305,y:878,t:1527019594386};\\\", \\\"{x:1305,y:864,t:1527019594403};\\\", \\\"{x:1304,y:856,t:1527019594420};\\\", \\\"{x:1304,y:849,t:1527019594437};\\\", \\\"{x:1302,y:841,t:1527019594454};\\\", \\\"{x:1300,y:833,t:1527019594470};\\\", \\\"{x:1300,y:824,t:1527019594487};\\\", \\\"{x:1300,y:813,t:1527019594504};\\\", \\\"{x:1300,y:803,t:1527019594520};\\\", \\\"{x:1300,y:794,t:1527019594537};\\\", \\\"{x:1300,y:787,t:1527019594553};\\\", \\\"{x:1300,y:783,t:1527019594571};\\\", \\\"{x:1300,y:782,t:1527019594587};\\\", \\\"{x:1300,y:781,t:1527019594606};\\\", \\\"{x:1300,y:780,t:1527019594620};\\\", \\\"{x:1300,y:778,t:1527019594638};\\\", \\\"{x:1300,y:777,t:1527019594653};\\\", \\\"{x:1300,y:776,t:1527019594670};\\\", \\\"{x:1300,y:775,t:1527019594688};\\\", \\\"{x:1300,y:773,t:1527019594709};\\\", \\\"{x:1301,y:772,t:1527019594726};\\\", \\\"{x:1301,y:771,t:1527019594782};\\\", \\\"{x:1302,y:771,t:1527019594790};\\\", \\\"{x:1303,y:771,t:1527019594804};\\\", \\\"{x:1305,y:770,t:1527019594821};\\\", \\\"{x:1307,y:768,t:1527019594837};\\\", \\\"{x:1308,y:767,t:1527019594853};\\\", \\\"{x:1312,y:765,t:1527019594870};\\\", \\\"{x:1314,y:764,t:1527019594887};\\\", \\\"{x:1315,y:762,t:1527019594903};\\\", \\\"{x:1316,y:762,t:1527019594919};\\\", \\\"{x:1316,y:761,t:1527019594937};\\\", \\\"{x:1317,y:761,t:1527019594953};\\\", \\\"{x:1317,y:763,t:1527019595174};\\\", \\\"{x:1315,y:766,t:1527019595187};\\\", \\\"{x:1313,y:775,t:1527019595205};\\\", \\\"{x:1313,y:782,t:1527019595221};\\\", \\\"{x:1312,y:788,t:1527019595237};\\\", \\\"{x:1312,y:790,t:1527019595270};\\\", \\\"{x:1312,y:791,t:1527019595430};\\\", \\\"{x:1312,y:792,t:1527019595437};\\\", \\\"{x:1312,y:796,t:1527019595454};\\\", \\\"{x:1312,y:804,t:1527019595471};\\\", \\\"{x:1312,y:811,t:1527019595487};\\\", \\\"{x:1313,y:816,t:1527019595505};\\\", \\\"{x:1313,y:819,t:1527019595521};\\\", \\\"{x:1314,y:823,t:1527019595537};\\\", \\\"{x:1314,y:825,t:1527019595554};\\\", \\\"{x:1314,y:827,t:1527019595574};\\\", \\\"{x:1314,y:828,t:1527019595588};\\\", \\\"{x:1314,y:830,t:1527019595604};\\\", \\\"{x:1314,y:832,t:1527019595621};\\\", \\\"{x:1314,y:834,t:1527019595638};\\\", \\\"{x:1316,y:836,t:1527019595654};\\\", \\\"{x:1316,y:839,t:1527019595671};\\\", \\\"{x:1317,y:843,t:1527019595688};\\\", \\\"{x:1317,y:849,t:1527019595705};\\\", \\\"{x:1317,y:854,t:1527019595722};\\\", \\\"{x:1317,y:861,t:1527019595738};\\\", \\\"{x:1317,y:870,t:1527019595755};\\\", \\\"{x:1318,y:877,t:1527019595771};\\\", \\\"{x:1318,y:881,t:1527019595788};\\\", \\\"{x:1320,y:885,t:1527019595805};\\\", \\\"{x:1320,y:890,t:1527019595822};\\\", \\\"{x:1321,y:893,t:1527019595837};\\\", \\\"{x:1321,y:897,t:1527019595855};\\\", \\\"{x:1321,y:903,t:1527019595872};\\\", \\\"{x:1322,y:908,t:1527019595887};\\\", \\\"{x:1324,y:915,t:1527019595905};\\\", \\\"{x:1324,y:919,t:1527019595922};\\\", \\\"{x:1324,y:923,t:1527019595937};\\\", \\\"{x:1326,y:929,t:1527019595955};\\\", \\\"{x:1328,y:933,t:1527019595971};\\\", \\\"{x:1328,y:936,t:1527019595987};\\\", \\\"{x:1328,y:940,t:1527019596005};\\\", \\\"{x:1328,y:943,t:1527019596022};\\\", \\\"{x:1328,y:944,t:1527019596037};\\\", \\\"{x:1328,y:946,t:1527019596055};\\\", \\\"{x:1328,y:947,t:1527019596078};\\\", \\\"{x:1328,y:948,t:1527019596094};\\\", \\\"{x:1328,y:949,t:1527019596109};\\\", \\\"{x:1328,y:950,t:1527019596121};\\\", \\\"{x:1328,y:951,t:1527019596150};\\\", \\\"{x:1328,y:952,t:1527019596158};\\\", \\\"{x:1328,y:953,t:1527019596182};\\\", \\\"{x:1328,y:955,t:1527019596198};\\\", \\\"{x:1328,y:956,t:1527019596206};\\\", \\\"{x:1328,y:958,t:1527019596222};\\\", \\\"{x:1328,y:960,t:1527019596238};\\\", \\\"{x:1329,y:963,t:1527019596255};\\\", \\\"{x:1329,y:965,t:1527019596272};\\\", \\\"{x:1329,y:966,t:1527019596289};\\\", \\\"{x:1329,y:968,t:1527019596310};\\\", \\\"{x:1330,y:969,t:1527019596710};\\\", \\\"{x:1330,y:964,t:1527019597559};\\\", \\\"{x:1329,y:952,t:1527019597573};\\\", \\\"{x:1326,y:921,t:1527019597589};\\\", \\\"{x:1326,y:920,t:1527019597606};\\\", \\\"{x:1326,y:918,t:1527019598310};\\\", \\\"{x:1326,y:917,t:1527019598323};\\\", \\\"{x:1337,y:901,t:1527019598340};\\\", \\\"{x:1344,y:889,t:1527019598357};\\\", \\\"{x:1350,y:878,t:1527019598373};\\\", \\\"{x:1355,y:866,t:1527019598389};\\\", \\\"{x:1358,y:857,t:1527019598406};\\\", \\\"{x:1361,y:850,t:1527019598423};\\\", \\\"{x:1364,y:842,t:1527019598440};\\\", \\\"{x:1369,y:831,t:1527019598456};\\\", \\\"{x:1372,y:822,t:1527019598474};\\\", \\\"{x:1376,y:813,t:1527019598490};\\\", \\\"{x:1378,y:807,t:1527019598506};\\\", \\\"{x:1378,y:803,t:1527019598524};\\\", \\\"{x:1379,y:799,t:1527019598540};\\\", \\\"{x:1379,y:797,t:1527019598557};\\\", \\\"{x:1380,y:795,t:1527019598574};\\\", \\\"{x:1380,y:792,t:1527019598590};\\\", \\\"{x:1380,y:791,t:1527019598614};\\\", \\\"{x:1380,y:790,t:1527019598646};\\\", \\\"{x:1380,y:789,t:1527019599110};\\\", \\\"{x:1380,y:758,t:1527019599124};\\\", \\\"{x:1380,y:667,t:1527019599142};\\\", \\\"{x:1376,y:633,t:1527019599157};\\\", \\\"{x:1366,y:596,t:1527019599173};\\\", \\\"{x:1364,y:586,t:1527019599191};\\\", \\\"{x:1362,y:580,t:1527019599207};\\\", \\\"{x:1361,y:578,t:1527019599224};\\\", \\\"{x:1361,y:577,t:1527019599241};\\\", \\\"{x:1361,y:575,t:1527019599257};\\\", \\\"{x:1361,y:572,t:1527019599274};\\\", \\\"{x:1361,y:571,t:1527019599291};\\\", \\\"{x:1360,y:567,t:1527019599307};\\\", \\\"{x:1356,y:560,t:1527019599323};\\\", \\\"{x:1350,y:549,t:1527019599341};\\\", \\\"{x:1343,y:537,t:1527019599357};\\\", \\\"{x:1333,y:520,t:1527019599373};\\\", \\\"{x:1332,y:515,t:1527019599390};\\\", \\\"{x:1329,y:510,t:1527019599408};\\\", \\\"{x:1327,y:508,t:1527019599424};\\\", \\\"{x:1325,y:505,t:1527019599441};\\\", \\\"{x:1324,y:504,t:1527019599470};\\\", \\\"{x:1324,y:503,t:1527019599478};\\\", \\\"{x:1324,y:502,t:1527019599491};\\\", \\\"{x:1324,y:501,t:1527019599508};\\\", \\\"{x:1322,y:498,t:1527019599524};\\\", \\\"{x:1322,y:496,t:1527019599541};\\\", \\\"{x:1322,y:495,t:1527019599566};\\\", \\\"{x:1322,y:494,t:1527019599598};\\\", \\\"{x:1321,y:492,t:1527019599608};\\\", \\\"{x:1320,y:491,t:1527019599624};\\\", \\\"{x:1320,y:490,t:1527019599646};\\\", \\\"{x:1320,y:489,t:1527019599718};\\\", \\\"{x:1318,y:490,t:1527019599726};\\\", \\\"{x:1316,y:490,t:1527019599741};\\\", \\\"{x:1315,y:491,t:1527019599758};\\\", \\\"{x:1315,y:492,t:1527019599894};\\\", \\\"{x:1315,y:494,t:1527019599910};\\\", \\\"{x:1315,y:496,t:1527019599925};\\\", \\\"{x:1315,y:503,t:1527019599941};\\\", \\\"{x:1318,y:513,t:1527019599958};\\\", \\\"{x:1319,y:518,t:1527019599974};\\\", \\\"{x:1321,y:523,t:1527019599991};\\\", \\\"{x:1321,y:525,t:1527019600013};\\\", \\\"{x:1321,y:526,t:1527019600030};\\\", \\\"{x:1321,y:528,t:1527019600054};\\\", \\\"{x:1321,y:529,t:1527019600062};\\\", \\\"{x:1321,y:531,t:1527019600075};\\\", \\\"{x:1323,y:535,t:1527019600091};\\\", \\\"{x:1324,y:539,t:1527019600108};\\\", \\\"{x:1324,y:544,t:1527019600125};\\\", \\\"{x:1324,y:549,t:1527019600141};\\\", \\\"{x:1328,y:564,t:1527019600158};\\\", \\\"{x:1330,y:576,t:1527019600175};\\\", \\\"{x:1333,y:589,t:1527019600191};\\\", \\\"{x:1337,y:599,t:1527019600208};\\\", \\\"{x:1337,y:608,t:1527019600224};\\\", \\\"{x:1337,y:621,t:1527019600241};\\\", \\\"{x:1337,y:631,t:1527019600258};\\\", \\\"{x:1337,y:640,t:1527019600275};\\\", \\\"{x:1337,y:649,t:1527019600291};\\\", \\\"{x:1337,y:655,t:1527019600308};\\\", \\\"{x:1337,y:659,t:1527019600325};\\\", \\\"{x:1337,y:667,t:1527019600341};\\\", \\\"{x:1337,y:670,t:1527019600358};\\\", \\\"{x:1336,y:674,t:1527019600375};\\\", \\\"{x:1336,y:679,t:1527019600392};\\\", \\\"{x:1333,y:687,t:1527019600408};\\\", \\\"{x:1331,y:696,t:1527019600425};\\\", \\\"{x:1329,y:701,t:1527019600441};\\\", \\\"{x:1328,y:706,t:1527019600458};\\\", \\\"{x:1327,y:709,t:1527019600475};\\\", \\\"{x:1325,y:713,t:1527019600492};\\\", \\\"{x:1324,y:719,t:1527019600508};\\\", \\\"{x:1324,y:725,t:1527019600525};\\\", \\\"{x:1321,y:739,t:1527019600542};\\\", \\\"{x:1321,y:746,t:1527019600557};\\\", \\\"{x:1319,y:755,t:1527019600574};\\\", \\\"{x:1319,y:760,t:1527019600592};\\\", \\\"{x:1319,y:765,t:1527019600608};\\\", \\\"{x:1319,y:768,t:1527019600626};\\\", \\\"{x:1319,y:770,t:1527019600641};\\\", \\\"{x:1319,y:771,t:1527019600658};\\\", \\\"{x:1319,y:775,t:1527019600675};\\\", \\\"{x:1319,y:777,t:1527019600692};\\\", \\\"{x:1317,y:781,t:1527019600708};\\\", \\\"{x:1317,y:784,t:1527019600725};\\\", \\\"{x:1317,y:789,t:1527019600742};\\\", \\\"{x:1317,y:792,t:1527019600758};\\\", \\\"{x:1316,y:796,t:1527019600775};\\\", \\\"{x:1316,y:798,t:1527019600792};\\\", \\\"{x:1315,y:801,t:1527019600808};\\\", \\\"{x:1314,y:806,t:1527019600825};\\\", \\\"{x:1314,y:809,t:1527019600842};\\\", \\\"{x:1313,y:817,t:1527019600859};\\\", \\\"{x:1311,y:826,t:1527019600875};\\\", \\\"{x:1310,y:830,t:1527019600892};\\\", \\\"{x:1309,y:836,t:1527019600909};\\\", \\\"{x:1309,y:840,t:1527019600925};\\\", \\\"{x:1309,y:845,t:1527019600942};\\\", \\\"{x:1308,y:847,t:1527019600959};\\\", \\\"{x:1308,y:848,t:1527019600975};\\\", \\\"{x:1307,y:850,t:1527019600992};\\\", \\\"{x:1307,y:853,t:1527019601009};\\\", \\\"{x:1307,y:854,t:1527019601025};\\\", \\\"{x:1306,y:857,t:1527019601042};\\\", \\\"{x:1306,y:859,t:1527019601077};\\\", \\\"{x:1306,y:860,t:1527019601101};\\\", \\\"{x:1306,y:862,t:1527019601109};\\\", \\\"{x:1306,y:863,t:1527019601126};\\\", \\\"{x:1306,y:864,t:1527019601166};\\\", \\\"{x:1306,y:865,t:1527019601182};\\\", \\\"{x:1306,y:866,t:1527019601219};\\\", \\\"{x:1306,y:867,t:1527019601225};\\\", \\\"{x:1306,y:868,t:1527019601241};\\\", \\\"{x:1306,y:869,t:1527019601259};\\\", \\\"{x:1306,y:870,t:1527019601274};\\\", \\\"{x:1306,y:871,t:1527019601291};\\\", \\\"{x:1306,y:873,t:1527019601308};\\\", \\\"{x:1306,y:876,t:1527019601325};\\\", \\\"{x:1306,y:878,t:1527019601341};\\\", \\\"{x:1306,y:883,t:1527019601358};\\\", \\\"{x:1306,y:885,t:1527019601375};\\\", \\\"{x:1306,y:888,t:1527019601391};\\\", \\\"{x:1306,y:889,t:1527019601408};\\\", \\\"{x:1306,y:891,t:1527019601426};\\\", \\\"{x:1306,y:893,t:1527019601441};\\\", \\\"{x:1305,y:895,t:1527019601459};\\\", \\\"{x:1305,y:898,t:1527019601476};\\\", \\\"{x:1305,y:899,t:1527019601491};\\\", \\\"{x:1305,y:901,t:1527019601509};\\\", \\\"{x:1305,y:905,t:1527019601525};\\\", \\\"{x:1305,y:908,t:1527019601542};\\\", \\\"{x:1305,y:912,t:1527019601558};\\\", \\\"{x:1305,y:914,t:1527019601576};\\\", \\\"{x:1304,y:917,t:1527019601592};\\\", \\\"{x:1304,y:919,t:1527019601609};\\\", \\\"{x:1303,y:922,t:1527019601625};\\\", \\\"{x:1303,y:925,t:1527019601641};\\\", \\\"{x:1303,y:930,t:1527019601659};\\\", \\\"{x:1303,y:937,t:1527019601675};\\\", \\\"{x:1303,y:947,t:1527019601692};\\\", \\\"{x:1301,y:961,t:1527019601708};\\\", \\\"{x:1296,y:980,t:1527019601726};\\\", \\\"{x:1295,y:983,t:1527019601742};\\\", \\\"{x:1295,y:985,t:1527019601759};\\\", \\\"{x:1294,y:985,t:1527019601775};\\\", \\\"{x:1293,y:985,t:1527019601910};\\\", \\\"{x:1253,y:956,t:1527019601926};\\\", \\\"{x:1158,y:908,t:1527019601942};\\\", \\\"{x:1037,y:857,t:1527019601959};\\\", \\\"{x:888,y:820,t:1527019601976};\\\", \\\"{x:742,y:778,t:1527019601992};\\\", \\\"{x:606,y:737,t:1527019602008};\\\", \\\"{x:508,y:718,t:1527019602028};\\\", \\\"{x:446,y:707,t:1527019602042};\\\", \\\"{x:423,y:703,t:1527019602059};\\\", \\\"{x:410,y:697,t:1527019602079};\\\", \\\"{x:409,y:696,t:1527019602096};\\\", \\\"{x:409,y:695,t:1527019602173};\\\", \\\"{x:409,y:690,t:1527019602181};\\\", \\\"{x:413,y:681,t:1527019602196};\\\", \\\"{x:425,y:661,t:1527019602212};\\\", \\\"{x:458,y:612,t:1527019602230};\\\", \\\"{x:477,y:584,t:1527019602247};\\\", \\\"{x:492,y:564,t:1527019602265};\\\", \\\"{x:505,y:544,t:1527019602281};\\\", \\\"{x:517,y:531,t:1527019602299};\\\", \\\"{x:533,y:519,t:1527019602314};\\\", \\\"{x:551,y:508,t:1527019602330};\\\", \\\"{x:571,y:499,t:1527019602348};\\\", \\\"{x:583,y:495,t:1527019602365};\\\", \\\"{x:589,y:495,t:1527019602380};\\\", \\\"{x:599,y:495,t:1527019602397};\\\", \\\"{x:610,y:500,t:1527019602414};\\\", \\\"{x:630,y:510,t:1527019602430};\\\", \\\"{x:653,y:523,t:1527019602448};\\\", \\\"{x:685,y:540,t:1527019602465};\\\", \\\"{x:713,y:552,t:1527019602482};\\\", \\\"{x:740,y:564,t:1527019602497};\\\", \\\"{x:759,y:569,t:1527019602514};\\\", \\\"{x:768,y:571,t:1527019602530};\\\", \\\"{x:772,y:574,t:1527019602547};\\\", \\\"{x:773,y:574,t:1527019603830};\\\", \\\"{x:777,y:567,t:1527019603837};\\\", \\\"{x:782,y:561,t:1527019603850};\\\", \\\"{x:788,y:552,t:1527019603867};\\\", \\\"{x:800,y:540,t:1527019603884};\\\", \\\"{x:814,y:530,t:1527019603900};\\\", \\\"{x:821,y:524,t:1527019603915};\\\", \\\"{x:822,y:522,t:1527019603932};\\\", \\\"{x:822,y:521,t:1527019603950};\\\", \\\"{x:822,y:524,t:1527019604030};\\\", \\\"{x:822,y:529,t:1527019604037};\\\", \\\"{x:822,y:532,t:1527019604049};\\\", \\\"{x:822,y:534,t:1527019604067};\\\", \\\"{x:824,y:534,t:1527019604542};\\\", \\\"{x:831,y:525,t:1527019604553};\\\", \\\"{x:846,y:509,t:1527019604568};\\\", \\\"{x:850,y:503,t:1527019604583};\\\", \\\"{x:850,y:502,t:1527019604598};\\\", \\\"{x:848,y:507,t:1527019604790};\\\", \\\"{x:848,y:508,t:1527019604799};\\\", \\\"{x:844,y:512,t:1527019605158};\\\", \\\"{x:829,y:530,t:1527019605167};\\\", \\\"{x:780,y:600,t:1527019605183};\\\", \\\"{x:709,y:703,t:1527019605200};\\\", \\\"{x:617,y:786,t:1527019605216};\\\", \\\"{x:537,y:839,t:1527019605233};\\\", \\\"{x:500,y:851,t:1527019605249};\\\", \\\"{x:495,y:851,t:1527019605266};\\\", \\\"{x:494,y:851,t:1527019605283};\\\", \\\"{x:491,y:850,t:1527019605308};\\\", \\\"{x:491,y:849,t:1527019605374};\\\", \\\"{x:491,y:843,t:1527019605384};\\\", \\\"{x:491,y:822,t:1527019605399};\\\", \\\"{x:506,y:783,t:1527019605416};\\\", \\\"{x:529,y:740,t:1527019605434};\\\", \\\"{x:560,y:704,t:1527019605451};\\\", \\\"{x:600,y:657,t:1527019605466};\\\", \\\"{x:638,y:620,t:1527019605483};\\\", \\\"{x:666,y:594,t:1527019605501};\\\", \\\"{x:684,y:574,t:1527019605517};\\\", \\\"{x:692,y:563,t:1527019605533};\\\", \\\"{x:696,y:557,t:1527019605550};\\\", \\\"{x:701,y:553,t:1527019605566};\\\", \\\"{x:705,y:549,t:1527019605583};\\\", \\\"{x:709,y:546,t:1527019605600};\\\", \\\"{x:712,y:544,t:1527019605617};\\\", \\\"{x:717,y:541,t:1527019605634};\\\", \\\"{x:725,y:539,t:1527019605651};\\\", \\\"{x:734,y:535,t:1527019605667};\\\", \\\"{x:740,y:534,t:1527019605683};\\\", \\\"{x:747,y:534,t:1527019605701};\\\", \\\"{x:767,y:534,t:1527019605717};\\\", \\\"{x:775,y:535,t:1527019605734};\\\", \\\"{x:784,y:536,t:1527019605750};\\\", \\\"{x:790,y:537,t:1527019605767};\\\", \\\"{x:792,y:537,t:1527019605783};\\\", \\\"{x:794,y:537,t:1527019605801};\\\", \\\"{x:795,y:537,t:1527019605817};\\\", \\\"{x:796,y:537,t:1527019605902};\\\", \\\"{x:796,y:535,t:1527019605919};\\\", \\\"{x:800,y:532,t:1527019605933};\\\", \\\"{x:800,y:531,t:1527019605950};\\\", \\\"{x:801,y:531,t:1527019605967};\\\", \\\"{x:804,y:529,t:1527019605983};\\\", \\\"{x:807,y:527,t:1527019606000};\\\", \\\"{x:815,y:524,t:1527019606017};\\\", \\\"{x:820,y:522,t:1527019606033};\\\", \\\"{x:824,y:520,t:1527019606050};\\\", \\\"{x:825,y:520,t:1527019606067};\\\", \\\"{x:824,y:524,t:1527019606518};\\\", \\\"{x:813,y:543,t:1527019606536};\\\", \\\"{x:798,y:564,t:1527019606551};\\\", \\\"{x:783,y:593,t:1527019606568};\\\", \\\"{x:762,y:624,t:1527019606584};\\\", \\\"{x:737,y:650,t:1527019606600};\\\", \\\"{x:706,y:670,t:1527019606617};\\\", \\\"{x:663,y:685,t:1527019606634};\\\", \\\"{x:624,y:696,t:1527019606650};\\\", \\\"{x:597,y:699,t:1527019606668};\\\", \\\"{x:579,y:702,t:1527019606684};\\\", \\\"{x:577,y:703,t:1527019606701};\\\", \\\"{x:576,y:703,t:1527019606749};\\\", \\\"{x:576,y:702,t:1527019606757};\\\", \\\"{x:576,y:700,t:1527019606767};\\\", \\\"{x:575,y:699,t:1527019606784};\\\", \\\"{x:574,y:699,t:1527019606838};\\\", \\\"{x:572,y:699,t:1527019606851};\\\", \\\"{x:565,y:706,t:1527019606868};\\\", \\\"{x:553,y:719,t:1527019606885};\\\", \\\"{x:541,y:728,t:1527019606900};\\\", \\\"{x:527,y:733,t:1527019606918};\\\", \\\"{x:525,y:733,t:1527019606934};\\\", \\\"{x:525,y:734,t:1527019607044};\\\", \\\"{x:525,y:734,t:1527019607125};\\\", \\\"{x:524,y:735,t:1527019607654};\\\", \\\"{x:524,y:729,t:1527019608076};\\\", \\\"{x:530,y:707,t:1527019608085};\\\", \\\"{x:540,y:663,t:1527019608102};\\\", \\\"{x:578,y:528,t:1527019608165};\\\", \\\"{x:579,y:517,t:1527019608172};\\\", \\\"{x:580,y:506,t:1527019608185};\\\", \\\"{x:583,y:486,t:1527019608202};\\\", \\\"{x:583,y:473,t:1527019608220};\\\", \\\"{x:583,y:467,t:1527019608235};\\\" ] }, { \\\"rt\\\": 32400, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 264723, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-10 AM-11 AM-12 PM-02 PM-D -04 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:583,y:462,t:1527019608345};\\\", \\\"{x:583,y:461,t:1527019609278};\\\", \\\"{x:580,y:464,t:1527019609317};\\\", \\\"{x:579,y:475,t:1527019609325};\\\", \\\"{x:577,y:485,t:1527019609337};\\\", \\\"{x:574,y:500,t:1527019609353};\\\", \\\"{x:573,y:513,t:1527019609370};\\\", \\\"{x:570,y:526,t:1527019609386};\\\", \\\"{x:565,y:539,t:1527019609403};\\\", \\\"{x:563,y:546,t:1527019609420};\\\", \\\"{x:561,y:551,t:1527019609436};\\\", \\\"{x:570,y:551,t:1527019609718};\\\", \\\"{x:584,y:551,t:1527019609725};\\\", \\\"{x:600,y:551,t:1527019609737};\\\", \\\"{x:677,y:556,t:1527019609754};\\\", \\\"{x:789,y:580,t:1527019609771};\\\", \\\"{x:918,y:612,t:1527019609787};\\\", \\\"{x:1031,y:643,t:1527019609804};\\\", \\\"{x:1186,y:700,t:1527019609821};\\\", \\\"{x:1277,y:739,t:1527019609836};\\\", \\\"{x:1357,y:778,t:1527019609854};\\\", \\\"{x:1416,y:816,t:1527019609870};\\\", \\\"{x:1462,y:855,t:1527019609887};\\\", \\\"{x:1485,y:876,t:1527019609904};\\\", \\\"{x:1497,y:893,t:1527019609920};\\\", \\\"{x:1499,y:899,t:1527019609936};\\\", \\\"{x:1500,y:904,t:1527019609954};\\\", \\\"{x:1500,y:907,t:1527019609971};\\\", \\\"{x:1500,y:912,t:1527019609987};\\\", \\\"{x:1500,y:913,t:1527019610003};\\\", \\\"{x:1497,y:917,t:1527019610021};\\\", \\\"{x:1496,y:919,t:1527019610037};\\\", \\\"{x:1494,y:921,t:1527019610054};\\\", \\\"{x:1493,y:921,t:1527019610071};\\\", \\\"{x:1492,y:922,t:1527019610088};\\\", \\\"{x:1491,y:923,t:1527019610126};\\\", \\\"{x:1489,y:923,t:1527019610149};\\\", \\\"{x:1487,y:924,t:1527019610158};\\\", \\\"{x:1486,y:924,t:1527019610171};\\\", \\\"{x:1482,y:925,t:1527019610187};\\\", \\\"{x:1480,y:926,t:1527019610203};\\\", \\\"{x:1474,y:927,t:1527019610221};\\\", \\\"{x:1467,y:927,t:1527019610237};\\\", \\\"{x:1460,y:927,t:1527019610253};\\\", \\\"{x:1454,y:927,t:1527019610271};\\\", \\\"{x:1441,y:925,t:1527019610287};\\\", \\\"{x:1426,y:923,t:1527019610304};\\\", \\\"{x:1406,y:919,t:1527019610321};\\\", \\\"{x:1382,y:913,t:1527019610338};\\\", \\\"{x:1356,y:908,t:1527019610354};\\\", \\\"{x:1324,y:899,t:1527019610370};\\\", \\\"{x:1280,y:886,t:1527019610388};\\\", \\\"{x:1203,y:867,t:1527019610404};\\\", \\\"{x:1070,y:827,t:1527019610420};\\\", \\\"{x:973,y:799,t:1527019610438};\\\", \\\"{x:884,y:774,t:1527019610453};\\\", \\\"{x:817,y:755,t:1527019610471};\\\", \\\"{x:782,y:745,t:1527019610488};\\\", \\\"{x:772,y:744,t:1527019610503};\\\", \\\"{x:770,y:744,t:1527019610520};\\\", \\\"{x:771,y:751,t:1527019610566};\\\", \\\"{x:777,y:763,t:1527019610573};\\\", \\\"{x:786,y:780,t:1527019610588};\\\", \\\"{x:819,y:849,t:1527019610606};\\\", \\\"{x:854,y:897,t:1527019610622};\\\", \\\"{x:894,y:944,t:1527019610638};\\\", \\\"{x:938,y:985,t:1527019610655};\\\", \\\"{x:1002,y:1027,t:1527019610671};\\\", \\\"{x:1075,y:1065,t:1527019610688};\\\", \\\"{x:1130,y:1086,t:1527019610705};\\\", \\\"{x:1162,y:1094,t:1527019610721};\\\", \\\"{x:1197,y:1100,t:1527019610738};\\\", \\\"{x:1231,y:1105,t:1527019610755};\\\", \\\"{x:1260,y:1108,t:1527019610770};\\\", \\\"{x:1290,y:1110,t:1527019610788};\\\", \\\"{x:1330,y:1104,t:1527019610805};\\\", \\\"{x:1346,y:1098,t:1527019610822};\\\", \\\"{x:1356,y:1090,t:1527019610838};\\\", \\\"{x:1359,y:1084,t:1527019610855};\\\", \\\"{x:1359,y:1078,t:1527019610871};\\\", \\\"{x:1359,y:1068,t:1527019610888};\\\", \\\"{x:1359,y:1056,t:1527019610905};\\\", \\\"{x:1359,y:1047,t:1527019610922};\\\", \\\"{x:1358,y:1039,t:1527019610938};\\\", \\\"{x:1350,y:1027,t:1527019610955};\\\", \\\"{x:1338,y:1019,t:1527019610971};\\\", \\\"{x:1313,y:1005,t:1527019610988};\\\", \\\"{x:1262,y:989,t:1527019611006};\\\", \\\"{x:1242,y:985,t:1527019611022};\\\", \\\"{x:1232,y:983,t:1527019611038};\\\", \\\"{x:1228,y:983,t:1527019611055};\\\", \\\"{x:1227,y:983,t:1527019611072};\\\", \\\"{x:1223,y:983,t:1527019611087};\\\", \\\"{x:1222,y:983,t:1527019611105};\\\", \\\"{x:1219,y:983,t:1527019611122};\\\", \\\"{x:1218,y:983,t:1527019611138};\\\", \\\"{x:1215,y:985,t:1527019611156};\\\", \\\"{x:1213,y:985,t:1527019611172};\\\", \\\"{x:1212,y:985,t:1527019611188};\\\", \\\"{x:1217,y:985,t:1527019611414};\\\", \\\"{x:1228,y:980,t:1527019611422};\\\", \\\"{x:1253,y:974,t:1527019611440};\\\", \\\"{x:1279,y:971,t:1527019611455};\\\", \\\"{x:1300,y:969,t:1527019611472};\\\", \\\"{x:1315,y:969,t:1527019611490};\\\", \\\"{x:1329,y:969,t:1527019611506};\\\", \\\"{x:1340,y:970,t:1527019611522};\\\", \\\"{x:1353,y:971,t:1527019611539};\\\", \\\"{x:1362,y:973,t:1527019611555};\\\", \\\"{x:1367,y:973,t:1527019611572};\\\", \\\"{x:1378,y:974,t:1527019611590};\\\", \\\"{x:1382,y:975,t:1527019611605};\\\", \\\"{x:1387,y:975,t:1527019611622};\\\", \\\"{x:1389,y:975,t:1527019611654};\\\", \\\"{x:1391,y:975,t:1527019611685};\\\", \\\"{x:1392,y:973,t:1527019611693};\\\", \\\"{x:1394,y:972,t:1527019611705};\\\", \\\"{x:1400,y:968,t:1527019611722};\\\", \\\"{x:1406,y:964,t:1527019611739};\\\", \\\"{x:1410,y:962,t:1527019611755};\\\", \\\"{x:1413,y:961,t:1527019611773};\\\", \\\"{x:1420,y:961,t:1527019611789};\\\", \\\"{x:1428,y:961,t:1527019611805};\\\", \\\"{x:1440,y:961,t:1527019611822};\\\", \\\"{x:1479,y:973,t:1527019611839};\\\", \\\"{x:1547,y:996,t:1527019611856};\\\", \\\"{x:1616,y:1025,t:1527019611872};\\\", \\\"{x:1716,y:1059,t:1527019611889};\\\", \\\"{x:1798,y:1076,t:1527019611906};\\\", \\\"{x:1878,y:1096,t:1527019611921};\\\", \\\"{x:1919,y:1110,t:1527019611939};\\\", \\\"{x:1919,y:1118,t:1527019611956};\\\", \\\"{x:1919,y:1124,t:1527019611969};\\\", \\\"{x:1919,y:1126,t:1527019611985};\\\", \\\"{x:1919,y:1125,t:1527019612061};\\\", \\\"{x:1919,y:1124,t:1527019612078};\\\", \\\"{x:1919,y:1123,t:1527019612101};\\\", \\\"{x:1919,y:1122,t:1527019612125};\\\", \\\"{x:1919,y:1121,t:1527019612135};\\\", \\\"{x:1919,y:1120,t:1527019612157};\\\", \\\"{x:1919,y:1119,t:1527019612213};\\\", \\\"{x:1918,y:1119,t:1527019612526};\\\", \\\"{x:1913,y:1121,t:1527019612535};\\\", \\\"{x:1897,y:1127,t:1527019612553};\\\", \\\"{x:1879,y:1137,t:1527019612568};\\\", \\\"{x:1841,y:1152,t:1527019612589};\\\", \\\"{x:1815,y:1154,t:1527019612606};\\\", \\\"{x:1791,y:1147,t:1527019612623};\\\", \\\"{x:1760,y:1125,t:1527019612640};\\\", \\\"{x:1714,y:1078,t:1527019612656};\\\", \\\"{x:1668,y:1011,t:1527019612674};\\\", \\\"{x:1627,y:930,t:1527019612690};\\\", \\\"{x:1603,y:831,t:1527019612706};\\\", \\\"{x:1587,y:760,t:1527019612723};\\\", \\\"{x:1587,y:693,t:1527019612740};\\\", \\\"{x:1587,y:648,t:1527019612756};\\\", \\\"{x:1587,y:599,t:1527019612773};\\\", \\\"{x:1587,y:582,t:1527019612789};\\\", \\\"{x:1587,y:580,t:1527019612806};\\\", \\\"{x:1587,y:578,t:1527019612982};\\\", \\\"{x:1590,y:570,t:1527019612990};\\\", \\\"{x:1601,y:553,t:1527019613007};\\\", \\\"{x:1607,y:537,t:1527019613023};\\\", \\\"{x:1612,y:519,t:1527019613040};\\\", \\\"{x:1615,y:498,t:1527019613057};\\\", \\\"{x:1616,y:479,t:1527019613073};\\\", \\\"{x:1616,y:468,t:1527019613090};\\\", \\\"{x:1614,y:460,t:1527019613107};\\\", \\\"{x:1613,y:457,t:1527019613123};\\\", \\\"{x:1613,y:456,t:1527019613140};\\\", \\\"{x:1613,y:454,t:1527019613157};\\\", \\\"{x:1613,y:450,t:1527019613173};\\\", \\\"{x:1613,y:445,t:1527019613190};\\\", \\\"{x:1613,y:441,t:1527019613207};\\\", \\\"{x:1613,y:437,t:1527019613223};\\\", \\\"{x:1613,y:435,t:1527019613240};\\\", \\\"{x:1613,y:433,t:1527019613256};\\\", \\\"{x:1613,y:432,t:1527019613502};\\\", \\\"{x:1613,y:431,t:1527019613509};\\\", \\\"{x:1613,y:430,t:1527019613525};\\\", \\\"{x:1614,y:429,t:1527019613540};\\\", \\\"{x:1615,y:427,t:1527019613557};\\\", \\\"{x:1615,y:426,t:1527019613574};\\\", \\\"{x:1615,y:429,t:1527019613829};\\\", \\\"{x:1614,y:431,t:1527019613841};\\\", \\\"{x:1612,y:440,t:1527019613858};\\\", \\\"{x:1608,y:449,t:1527019613875};\\\", \\\"{x:1606,y:458,t:1527019613891};\\\", \\\"{x:1604,y:462,t:1527019613907};\\\", \\\"{x:1604,y:467,t:1527019613924};\\\", \\\"{x:1603,y:473,t:1527019613941};\\\", \\\"{x:1603,y:475,t:1527019613957};\\\", \\\"{x:1602,y:477,t:1527019613974};\\\", \\\"{x:1602,y:478,t:1527019613991};\\\", \\\"{x:1602,y:480,t:1527019614007};\\\", \\\"{x:1601,y:482,t:1527019614024};\\\", \\\"{x:1601,y:484,t:1527019614041};\\\", \\\"{x:1601,y:486,t:1527019614057};\\\", \\\"{x:1601,y:490,t:1527019614074};\\\", \\\"{x:1601,y:494,t:1527019614091};\\\", \\\"{x:1601,y:498,t:1527019614107};\\\", \\\"{x:1602,y:500,t:1527019614124};\\\", \\\"{x:1602,y:501,t:1527019614142};\\\", \\\"{x:1602,y:503,t:1527019614157};\\\", \\\"{x:1603,y:504,t:1527019614182};\\\", \\\"{x:1604,y:504,t:1527019614254};\\\", \\\"{x:1605,y:506,t:1527019614262};\\\", \\\"{x:1605,y:507,t:1527019614274};\\\", \\\"{x:1606,y:512,t:1527019614291};\\\", \\\"{x:1606,y:517,t:1527019614309};\\\", \\\"{x:1608,y:522,t:1527019614324};\\\", \\\"{x:1609,y:529,t:1527019614341};\\\", \\\"{x:1609,y:535,t:1527019614358};\\\", \\\"{x:1610,y:540,t:1527019614374};\\\", \\\"{x:1613,y:548,t:1527019614391};\\\", \\\"{x:1613,y:557,t:1527019614408};\\\", \\\"{x:1613,y:564,t:1527019614424};\\\", \\\"{x:1613,y:568,t:1527019614442};\\\", \\\"{x:1613,y:571,t:1527019614459};\\\", \\\"{x:1613,y:572,t:1527019614474};\\\", \\\"{x:1614,y:572,t:1527019614492};\\\", \\\"{x:1614,y:573,t:1527019614508};\\\", \\\"{x:1614,y:574,t:1527019614525};\\\", \\\"{x:1614,y:575,t:1527019614557};\\\", \\\"{x:1614,y:576,t:1527019614605};\\\", \\\"{x:1614,y:577,t:1527019614613};\\\", \\\"{x:1614,y:578,t:1527019614629};\\\", \\\"{x:1614,y:581,t:1527019614641};\\\", \\\"{x:1614,y:582,t:1527019614658};\\\", \\\"{x:1614,y:585,t:1527019614675};\\\", \\\"{x:1614,y:587,t:1527019614692};\\\", \\\"{x:1614,y:588,t:1527019614708};\\\", \\\"{x:1614,y:591,t:1527019614725};\\\", \\\"{x:1614,y:592,t:1527019614741};\\\", \\\"{x:1614,y:595,t:1527019614758};\\\", \\\"{x:1614,y:599,t:1527019614776};\\\", \\\"{x:1614,y:602,t:1527019614791};\\\", \\\"{x:1614,y:607,t:1527019614809};\\\", \\\"{x:1614,y:612,t:1527019614825};\\\", \\\"{x:1614,y:615,t:1527019614842};\\\", \\\"{x:1614,y:619,t:1527019614858};\\\", \\\"{x:1614,y:623,t:1527019614875};\\\", \\\"{x:1614,y:628,t:1527019614891};\\\", \\\"{x:1614,y:631,t:1527019614908};\\\", \\\"{x:1616,y:637,t:1527019614925};\\\", \\\"{x:1616,y:640,t:1527019614941};\\\", \\\"{x:1616,y:641,t:1527019614959};\\\", \\\"{x:1616,y:644,t:1527019614975};\\\", \\\"{x:1617,y:646,t:1527019614991};\\\", \\\"{x:1617,y:649,t:1527019615008};\\\", \\\"{x:1617,y:651,t:1527019615026};\\\", \\\"{x:1617,y:652,t:1527019615045};\\\", \\\"{x:1617,y:653,t:1527019615059};\\\", \\\"{x:1617,y:654,t:1527019615076};\\\", \\\"{x:1617,y:655,t:1527019615102};\\\", \\\"{x:1617,y:656,t:1527019615118};\\\", \\\"{x:1617,y:657,t:1527019615133};\\\", \\\"{x:1617,y:658,t:1527019615158};\\\", \\\"{x:1617,y:659,t:1527019615175};\\\", \\\"{x:1617,y:660,t:1527019615192};\\\", \\\"{x:1617,y:661,t:1527019615213};\\\", \\\"{x:1617,y:662,t:1527019615229};\\\", \\\"{x:1617,y:663,t:1527019615242};\\\", \\\"{x:1617,y:666,t:1527019615258};\\\", \\\"{x:1617,y:668,t:1527019615275};\\\", \\\"{x:1617,y:670,t:1527019615292};\\\", \\\"{x:1617,y:672,t:1527019615309};\\\", \\\"{x:1619,y:674,t:1527019615326};\\\", \\\"{x:1619,y:676,t:1527019615343};\\\", \\\"{x:1619,y:678,t:1527019615360};\\\", \\\"{x:1619,y:680,t:1527019615376};\\\", \\\"{x:1619,y:681,t:1527019615393};\\\", \\\"{x:1620,y:684,t:1527019615410};\\\", \\\"{x:1620,y:685,t:1527019615425};\\\", \\\"{x:1620,y:688,t:1527019615443};\\\", \\\"{x:1621,y:688,t:1527019615459};\\\", \\\"{x:1622,y:689,t:1527019615476};\\\", \\\"{x:1622,y:690,t:1527019615509};\\\", \\\"{x:1622,y:691,t:1527019615537};\\\", \\\"{x:1622,y:692,t:1527019615585};\\\", \\\"{x:1622,y:693,t:1527019615601};\\\", \\\"{x:1622,y:694,t:1527019615613};\\\", \\\"{x:1622,y:697,t:1527019615629};\\\", \\\"{x:1622,y:700,t:1527019615646};\\\", \\\"{x:1622,y:701,t:1527019615662};\\\", \\\"{x:1622,y:703,t:1527019615678};\\\", \\\"{x:1622,y:704,t:1527019615697};\\\", \\\"{x:1621,y:704,t:1527019615712};\\\", \\\"{x:1621,y:706,t:1527019615728};\\\", \\\"{x:1619,y:709,t:1527019615753};\\\", \\\"{x:1619,y:710,t:1527019615771};\\\", \\\"{x:1619,y:711,t:1527019615785};\\\", \\\"{x:1619,y:712,t:1527019615801};\\\", \\\"{x:1619,y:713,t:1527019615833};\\\", \\\"{x:1619,y:714,t:1527019615846};\\\", \\\"{x:1618,y:716,t:1527019615863};\\\", \\\"{x:1618,y:718,t:1527019615880};\\\", \\\"{x:1618,y:720,t:1527019615896};\\\", \\\"{x:1618,y:722,t:1527019615913};\\\", \\\"{x:1617,y:723,t:1527019615929};\\\", \\\"{x:1617,y:724,t:1527019615970};\\\", \\\"{x:1617,y:725,t:1527019615985};\\\", \\\"{x:1617,y:727,t:1527019615996};\\\", \\\"{x:1615,y:734,t:1527019616013};\\\", \\\"{x:1615,y:739,t:1527019616030};\\\", \\\"{x:1614,y:743,t:1527019616046};\\\", \\\"{x:1614,y:745,t:1527019616063};\\\", \\\"{x:1614,y:747,t:1527019616079};\\\", \\\"{x:1614,y:748,t:1527019616095};\\\", \\\"{x:1614,y:749,t:1527019616113};\\\", \\\"{x:1614,y:750,t:1527019616129};\\\", \\\"{x:1614,y:751,t:1527019616152};\\\", \\\"{x:1614,y:752,t:1527019616163};\\\", \\\"{x:1614,y:753,t:1527019616179};\\\", \\\"{x:1613,y:754,t:1527019616196};\\\", \\\"{x:1612,y:754,t:1527019616217};\\\", \\\"{x:1612,y:755,t:1527019616230};\\\", \\\"{x:1612,y:757,t:1527019616247};\\\", \\\"{x:1612,y:759,t:1527019616263};\\\", \\\"{x:1612,y:764,t:1527019616280};\\\", \\\"{x:1612,y:769,t:1527019616297};\\\", \\\"{x:1612,y:770,t:1527019616313};\\\", \\\"{x:1612,y:771,t:1527019616330};\\\", \\\"{x:1612,y:772,t:1527019616347};\\\", \\\"{x:1612,y:774,t:1527019616363};\\\", \\\"{x:1612,y:776,t:1527019616380};\\\", \\\"{x:1612,y:780,t:1527019616396};\\\", \\\"{x:1612,y:786,t:1527019616413};\\\", \\\"{x:1611,y:792,t:1527019616429};\\\", \\\"{x:1611,y:800,t:1527019616446};\\\", \\\"{x:1611,y:806,t:1527019616462};\\\", \\\"{x:1610,y:808,t:1527019616480};\\\", \\\"{x:1610,y:814,t:1527019616496};\\\", \\\"{x:1610,y:818,t:1527019616512};\\\", \\\"{x:1610,y:825,t:1527019616529};\\\", \\\"{x:1610,y:834,t:1527019616546};\\\", \\\"{x:1610,y:842,t:1527019616563};\\\", \\\"{x:1608,y:854,t:1527019616579};\\\", \\\"{x:1608,y:859,t:1527019616597};\\\", \\\"{x:1608,y:863,t:1527019616614};\\\", \\\"{x:1609,y:868,t:1527019616629};\\\", \\\"{x:1609,y:873,t:1527019616646};\\\", \\\"{x:1609,y:878,t:1527019616663};\\\", \\\"{x:1610,y:882,t:1527019616680};\\\", \\\"{x:1611,y:888,t:1527019616696};\\\", \\\"{x:1611,y:892,t:1527019616713};\\\", \\\"{x:1612,y:897,t:1527019616730};\\\", \\\"{x:1613,y:904,t:1527019616747};\\\", \\\"{x:1615,y:914,t:1527019616764};\\\", \\\"{x:1617,y:927,t:1527019616780};\\\", \\\"{x:1620,y:937,t:1527019616797};\\\", \\\"{x:1625,y:948,t:1527019616813};\\\", \\\"{x:1626,y:954,t:1527019616830};\\\", \\\"{x:1628,y:960,t:1527019616847};\\\", \\\"{x:1630,y:962,t:1527019616864};\\\", \\\"{x:1631,y:964,t:1527019616880};\\\", \\\"{x:1632,y:968,t:1527019616897};\\\", \\\"{x:1633,y:974,t:1527019616913};\\\", \\\"{x:1634,y:978,t:1527019616930};\\\", \\\"{x:1634,y:980,t:1527019616946};\\\", \\\"{x:1633,y:980,t:1527019617385};\\\", \\\"{x:1632,y:977,t:1527019620633};\\\", \\\"{x:1632,y:971,t:1527019620650};\\\", \\\"{x:1628,y:962,t:1527019620667};\\\", \\\"{x:1622,y:950,t:1527019620683};\\\", \\\"{x:1617,y:934,t:1527019620700};\\\", \\\"{x:1611,y:912,t:1527019620717};\\\", \\\"{x:1605,y:889,t:1527019620734};\\\", \\\"{x:1601,y:865,t:1527019620750};\\\", \\\"{x:1597,y:837,t:1527019620767};\\\", \\\"{x:1593,y:808,t:1527019620784};\\\", \\\"{x:1584,y:768,t:1527019620800};\\\", \\\"{x:1563,y:688,t:1527019620817};\\\", \\\"{x:1552,y:636,t:1527019620834};\\\", \\\"{x:1545,y:596,t:1527019620850};\\\", \\\"{x:1537,y:558,t:1527019620867};\\\", \\\"{x:1531,y:532,t:1527019620884};\\\", \\\"{x:1529,y:517,t:1527019620900};\\\", \\\"{x:1527,y:503,t:1527019620917};\\\", \\\"{x:1523,y:484,t:1527019620933};\\\", \\\"{x:1522,y:476,t:1527019620950};\\\", \\\"{x:1522,y:466,t:1527019620967};\\\", \\\"{x:1523,y:456,t:1527019620984};\\\", \\\"{x:1527,y:444,t:1527019621000};\\\", \\\"{x:1538,y:427,t:1527019621017};\\\", \\\"{x:1544,y:417,t:1527019621034};\\\", \\\"{x:1552,y:409,t:1527019621050};\\\", \\\"{x:1558,y:403,t:1527019621067};\\\", \\\"{x:1562,y:399,t:1527019621085};\\\", \\\"{x:1565,y:398,t:1527019621100};\\\", \\\"{x:1569,y:395,t:1527019621117};\\\", \\\"{x:1570,y:395,t:1527019621134};\\\", \\\"{x:1571,y:395,t:1527019621185};\\\", \\\"{x:1572,y:396,t:1527019621201};\\\", \\\"{x:1572,y:402,t:1527019621217};\\\", \\\"{x:1572,y:408,t:1527019621234};\\\", \\\"{x:1574,y:414,t:1527019621251};\\\", \\\"{x:1576,y:422,t:1527019621267};\\\", \\\"{x:1576,y:427,t:1527019621284};\\\", \\\"{x:1578,y:432,t:1527019621301};\\\", \\\"{x:1578,y:433,t:1527019621321};\\\", \\\"{x:1579,y:433,t:1527019621334};\\\", \\\"{x:1580,y:435,t:1527019621351};\\\", \\\"{x:1581,y:435,t:1527019621367};\\\", \\\"{x:1582,y:435,t:1527019621384};\\\", \\\"{x:1584,y:435,t:1527019621401};\\\", \\\"{x:1587,y:435,t:1527019621417};\\\", \\\"{x:1588,y:435,t:1527019621448};\\\", \\\"{x:1590,y:435,t:1527019621457};\\\", \\\"{x:1592,y:433,t:1527019621467};\\\", \\\"{x:1598,y:432,t:1527019621484};\\\", \\\"{x:1600,y:430,t:1527019621501};\\\", \\\"{x:1602,y:428,t:1527019621517};\\\", \\\"{x:1603,y:428,t:1527019621534};\\\", \\\"{x:1604,y:426,t:1527019621561};\\\", \\\"{x:1605,y:426,t:1527019621571};\\\", \\\"{x:1605,y:425,t:1527019621584};\\\", \\\"{x:1606,y:424,t:1527019621616};\\\", \\\"{x:1606,y:428,t:1527019621801};\\\", \\\"{x:1605,y:440,t:1527019621818};\\\", \\\"{x:1605,y:451,t:1527019621834};\\\", \\\"{x:1603,y:459,t:1527019621851};\\\", \\\"{x:1603,y:466,t:1527019621868};\\\", \\\"{x:1603,y:475,t:1527019621884};\\\", \\\"{x:1603,y:481,t:1527019621901};\\\", \\\"{x:1603,y:486,t:1527019621918};\\\", \\\"{x:1603,y:491,t:1527019621935};\\\", \\\"{x:1603,y:499,t:1527019621951};\\\", \\\"{x:1604,y:512,t:1527019621969};\\\", \\\"{x:1605,y:517,t:1527019621985};\\\", \\\"{x:1606,y:524,t:1527019622001};\\\", \\\"{x:1606,y:527,t:1527019622018};\\\", \\\"{x:1608,y:531,t:1527019622035};\\\", \\\"{x:1608,y:534,t:1527019622051};\\\", \\\"{x:1609,y:540,t:1527019622068};\\\", \\\"{x:1610,y:542,t:1527019622085};\\\", \\\"{x:1610,y:546,t:1527019622101};\\\", \\\"{x:1610,y:548,t:1527019622118};\\\", \\\"{x:1611,y:549,t:1527019622135};\\\", \\\"{x:1613,y:551,t:1527019622151};\\\", \\\"{x:1614,y:552,t:1527019622169};\\\", \\\"{x:1614,y:554,t:1527019622209};\\\", \\\"{x:1614,y:555,t:1527019622224};\\\", \\\"{x:1614,y:556,t:1527019622235};\\\", \\\"{x:1615,y:558,t:1527019622251};\\\", \\\"{x:1615,y:560,t:1527019622269};\\\", \\\"{x:1615,y:562,t:1527019622285};\\\", \\\"{x:1616,y:565,t:1527019622301};\\\", \\\"{x:1616,y:568,t:1527019622318};\\\", \\\"{x:1616,y:571,t:1527019622335};\\\", \\\"{x:1617,y:573,t:1527019622352};\\\", \\\"{x:1618,y:579,t:1527019622369};\\\", \\\"{x:1619,y:583,t:1527019622385};\\\", \\\"{x:1619,y:585,t:1527019622402};\\\", \\\"{x:1619,y:586,t:1527019622424};\\\", \\\"{x:1620,y:586,t:1527019622435};\\\", \\\"{x:1620,y:588,t:1527019622456};\\\", \\\"{x:1620,y:589,t:1527019622481};\\\", \\\"{x:1620,y:591,t:1527019622497};\\\", \\\"{x:1620,y:592,t:1527019622513};\\\", \\\"{x:1620,y:594,t:1527019622521};\\\", \\\"{x:1620,y:595,t:1527019622537};\\\", \\\"{x:1620,y:596,t:1527019622553};\\\", \\\"{x:1620,y:597,t:1527019622570};\\\", \\\"{x:1620,y:598,t:1527019622585};\\\", \\\"{x:1620,y:600,t:1527019622602};\\\", \\\"{x:1620,y:601,t:1527019622618};\\\", \\\"{x:1620,y:604,t:1527019622635};\\\", \\\"{x:1620,y:605,t:1527019622665};\\\", \\\"{x:1620,y:606,t:1527019622673};\\\", \\\"{x:1620,y:607,t:1527019622697};\\\", \\\"{x:1620,y:608,t:1527019622721};\\\", \\\"{x:1620,y:609,t:1527019622737};\\\", \\\"{x:1620,y:610,t:1527019622752};\\\", \\\"{x:1620,y:611,t:1527019622770};\\\", \\\"{x:1620,y:612,t:1527019622785};\\\", \\\"{x:1620,y:613,t:1527019622802};\\\", \\\"{x:1620,y:614,t:1527019622819};\\\", \\\"{x:1620,y:616,t:1527019622836};\\\", \\\"{x:1620,y:617,t:1527019622865};\\\", \\\"{x:1620,y:618,t:1527019622897};\\\", \\\"{x:1620,y:619,t:1527019622970};\\\", \\\"{x:1620,y:620,t:1527019623129};\\\", \\\"{x:1622,y:621,t:1527019623137};\\\", \\\"{x:1622,y:622,t:1527019623153};\\\", \\\"{x:1622,y:623,t:1527019623170};\\\", \\\"{x:1622,y:625,t:1527019623186};\\\", \\\"{x:1622,y:626,t:1527019623217};\\\", \\\"{x:1622,y:627,t:1527019623265};\\\", \\\"{x:1622,y:628,t:1527019623386};\\\", \\\"{x:1622,y:629,t:1527019623449};\\\", \\\"{x:1622,y:630,t:1527019623473};\\\", \\\"{x:1623,y:631,t:1527019623545};\\\", \\\"{x:1623,y:632,t:1527019623721};\\\", \\\"{x:1623,y:633,t:1527019623736};\\\", \\\"{x:1623,y:634,t:1527019623753};\\\", \\\"{x:1623,y:636,t:1527019623773};\\\", \\\"{x:1623,y:637,t:1527019623785};\\\", \\\"{x:1623,y:639,t:1527019623802};\\\", \\\"{x:1623,y:641,t:1527019623818};\\\", \\\"{x:1624,y:644,t:1527019623835};\\\", \\\"{x:1624,y:648,t:1527019623853};\\\", \\\"{x:1624,y:657,t:1527019623868};\\\", \\\"{x:1624,y:667,t:1527019623886};\\\", \\\"{x:1623,y:673,t:1527019623902};\\\", \\\"{x:1622,y:677,t:1527019623919};\\\", \\\"{x:1622,y:679,t:1527019623935};\\\", \\\"{x:1622,y:681,t:1527019623953};\\\", \\\"{x:1622,y:682,t:1527019623968};\\\", \\\"{x:1622,y:683,t:1527019623985};\\\", \\\"{x:1622,y:685,t:1527019624002};\\\", \\\"{x:1622,y:686,t:1527019624024};\\\", \\\"{x:1622,y:687,t:1527019624036};\\\", \\\"{x:1622,y:688,t:1527019624052};\\\", \\\"{x:1622,y:689,t:1527019624072};\\\", \\\"{x:1622,y:691,t:1527019624104};\\\", \\\"{x:1622,y:692,t:1527019624120};\\\", \\\"{x:1622,y:694,t:1527019624136};\\\", \\\"{x:1622,y:697,t:1527019624152};\\\", \\\"{x:1622,y:698,t:1527019624170};\\\", \\\"{x:1623,y:702,t:1527019624186};\\\", \\\"{x:1623,y:704,t:1527019624209};\\\", \\\"{x:1623,y:705,t:1527019624220};\\\", \\\"{x:1624,y:708,t:1527019624236};\\\", \\\"{x:1624,y:709,t:1527019624253};\\\", \\\"{x:1625,y:711,t:1527019624270};\\\", \\\"{x:1625,y:713,t:1527019624286};\\\", \\\"{x:1626,y:715,t:1527019624303};\\\", \\\"{x:1626,y:716,t:1527019624337};\\\", \\\"{x:1626,y:718,t:1527019624353};\\\", \\\"{x:1626,y:719,t:1527019624370};\\\", \\\"{x:1626,y:721,t:1527019624386};\\\", \\\"{x:1626,y:723,t:1527019624403};\\\", \\\"{x:1627,y:725,t:1527019624421};\\\", \\\"{x:1628,y:725,t:1527019624437};\\\", \\\"{x:1628,y:726,t:1527019624453};\\\", \\\"{x:1628,y:727,t:1527019624470};\\\", \\\"{x:1628,y:728,t:1527019624487};\\\", \\\"{x:1628,y:730,t:1527019624503};\\\", \\\"{x:1628,y:731,t:1527019624520};\\\", \\\"{x:1629,y:734,t:1527019624537};\\\", \\\"{x:1629,y:737,t:1527019624553};\\\", \\\"{x:1629,y:739,t:1527019624570};\\\", \\\"{x:1629,y:740,t:1527019624593};\\\", \\\"{x:1629,y:741,t:1527019624609};\\\", \\\"{x:1629,y:743,t:1527019624620};\\\", \\\"{x:1631,y:745,t:1527019624640};\\\", \\\"{x:1631,y:746,t:1527019624657};\\\", \\\"{x:1631,y:748,t:1527019624673};\\\", \\\"{x:1631,y:749,t:1527019624696};\\\", \\\"{x:1631,y:751,t:1527019624713};\\\", \\\"{x:1631,y:752,t:1527019624721};\\\", \\\"{x:1631,y:755,t:1527019624737};\\\", \\\"{x:1631,y:757,t:1527019624753};\\\", \\\"{x:1631,y:758,t:1527019624770};\\\", \\\"{x:1631,y:761,t:1527019624787};\\\", \\\"{x:1631,y:762,t:1527019624825};\\\", \\\"{x:1631,y:763,t:1527019624838};\\\", \\\"{x:1631,y:764,t:1527019624855};\\\", \\\"{x:1631,y:767,t:1527019624870};\\\", \\\"{x:1631,y:771,t:1527019624888};\\\", \\\"{x:1631,y:775,t:1527019624904};\\\", \\\"{x:1631,y:777,t:1527019624920};\\\", \\\"{x:1631,y:782,t:1527019624937};\\\", \\\"{x:1631,y:786,t:1527019624954};\\\", \\\"{x:1630,y:788,t:1527019624970};\\\", \\\"{x:1630,y:791,t:1527019624988};\\\", \\\"{x:1630,y:795,t:1527019625004};\\\", \\\"{x:1628,y:797,t:1527019625020};\\\", \\\"{x:1628,y:798,t:1527019625037};\\\", \\\"{x:1628,y:799,t:1527019625055};\\\", \\\"{x:1628,y:800,t:1527019625070};\\\", \\\"{x:1628,y:802,t:1527019625087};\\\", \\\"{x:1628,y:804,t:1527019625104};\\\", \\\"{x:1628,y:806,t:1527019625119};\\\", \\\"{x:1628,y:810,t:1527019625137};\\\", \\\"{x:1628,y:811,t:1527019625160};\\\", \\\"{x:1628,y:813,t:1527019625170};\\\", \\\"{x:1628,y:814,t:1527019625187};\\\", \\\"{x:1628,y:817,t:1527019625204};\\\", \\\"{x:1628,y:818,t:1527019625221};\\\", \\\"{x:1629,y:822,t:1527019625236};\\\", \\\"{x:1629,y:823,t:1527019625254};\\\", \\\"{x:1629,y:826,t:1527019625271};\\\", \\\"{x:1629,y:828,t:1527019625287};\\\", \\\"{x:1629,y:829,t:1527019625304};\\\", \\\"{x:1629,y:834,t:1527019625321};\\\", \\\"{x:1629,y:837,t:1527019625337};\\\", \\\"{x:1629,y:840,t:1527019625355};\\\", \\\"{x:1629,y:843,t:1527019625371};\\\", \\\"{x:1629,y:846,t:1527019625387};\\\", \\\"{x:1629,y:849,t:1527019625405};\\\", \\\"{x:1629,y:852,t:1527019625422};\\\", \\\"{x:1629,y:856,t:1527019625437};\\\", \\\"{x:1629,y:862,t:1527019625454};\\\", \\\"{x:1625,y:868,t:1527019625471};\\\", \\\"{x:1621,y:879,t:1527019625487};\\\", \\\"{x:1617,y:887,t:1527019625504};\\\", \\\"{x:1613,y:893,t:1527019625521};\\\", \\\"{x:1613,y:896,t:1527019625537};\\\", \\\"{x:1613,y:898,t:1527019625554};\\\", \\\"{x:1612,y:899,t:1527019625572};\\\", \\\"{x:1612,y:901,t:1527019625587};\\\", \\\"{x:1612,y:902,t:1527019625605};\\\", \\\"{x:1611,y:905,t:1527019625621};\\\", \\\"{x:1611,y:906,t:1527019625638};\\\", \\\"{x:1611,y:908,t:1527019625654};\\\", \\\"{x:1610,y:910,t:1527019625671};\\\", \\\"{x:1610,y:912,t:1527019625689};\\\", \\\"{x:1610,y:914,t:1527019625704};\\\", \\\"{x:1609,y:918,t:1527019625722};\\\", \\\"{x:1609,y:922,t:1527019625738};\\\", \\\"{x:1609,y:927,t:1527019625754};\\\", \\\"{x:1609,y:929,t:1527019625771};\\\", \\\"{x:1609,y:932,t:1527019625788};\\\", \\\"{x:1609,y:933,t:1527019625808};\\\", \\\"{x:1609,y:934,t:1527019625822};\\\", \\\"{x:1609,y:936,t:1527019625838};\\\", \\\"{x:1609,y:938,t:1527019625854};\\\", \\\"{x:1609,y:942,t:1527019625871};\\\", \\\"{x:1609,y:948,t:1527019625888};\\\", \\\"{x:1609,y:954,t:1527019625904};\\\", \\\"{x:1610,y:960,t:1527019625921};\\\", \\\"{x:1610,y:963,t:1527019625938};\\\", \\\"{x:1610,y:967,t:1527019625955};\\\", \\\"{x:1610,y:970,t:1527019625971};\\\", \\\"{x:1610,y:975,t:1527019625988};\\\", \\\"{x:1610,y:981,t:1527019626004};\\\", \\\"{x:1610,y:982,t:1527019626021};\\\", \\\"{x:1610,y:983,t:1527019626193};\\\", \\\"{x:1611,y:982,t:1527019626205};\\\", \\\"{x:1614,y:976,t:1527019626221};\\\", \\\"{x:1618,y:968,t:1527019626238};\\\", \\\"{x:1619,y:964,t:1527019626256};\\\", \\\"{x:1621,y:957,t:1527019626271};\\\", \\\"{x:1621,y:953,t:1527019626288};\\\", \\\"{x:1623,y:946,t:1527019626304};\\\", \\\"{x:1623,y:942,t:1527019626322};\\\", \\\"{x:1624,y:938,t:1527019626338};\\\", \\\"{x:1624,y:937,t:1527019626355};\\\", \\\"{x:1624,y:935,t:1527019626371};\\\", \\\"{x:1624,y:932,t:1527019626388};\\\", \\\"{x:1624,y:929,t:1527019626405};\\\", \\\"{x:1626,y:927,t:1527019626422};\\\", \\\"{x:1626,y:924,t:1527019626438};\\\", \\\"{x:1627,y:920,t:1527019626455};\\\", \\\"{x:1628,y:917,t:1527019626472};\\\", \\\"{x:1630,y:914,t:1527019626489};\\\", \\\"{x:1632,y:907,t:1527019626505};\\\", \\\"{x:1634,y:904,t:1527019626522};\\\", \\\"{x:1635,y:901,t:1527019626539};\\\", \\\"{x:1637,y:899,t:1527019626555};\\\", \\\"{x:1637,y:898,t:1527019626584};\\\", \\\"{x:1637,y:897,t:1527019626601};\\\", \\\"{x:1638,y:896,t:1527019626617};\\\", \\\"{x:1638,y:900,t:1527019626834};\\\", \\\"{x:1638,y:905,t:1527019626840};\\\", \\\"{x:1638,y:911,t:1527019626856};\\\", \\\"{x:1638,y:922,t:1527019626872};\\\", \\\"{x:1638,y:931,t:1527019626889};\\\", \\\"{x:1638,y:932,t:1527019626905};\\\", \\\"{x:1638,y:933,t:1527019626923};\\\", \\\"{x:1638,y:934,t:1527019626939};\\\", \\\"{x:1638,y:936,t:1527019626955};\\\", \\\"{x:1637,y:938,t:1527019626972};\\\", \\\"{x:1635,y:942,t:1527019626989};\\\", \\\"{x:1634,y:946,t:1527019627005};\\\", \\\"{x:1633,y:946,t:1527019627023};\\\", \\\"{x:1633,y:947,t:1527019627039};\\\", \\\"{x:1632,y:949,t:1527019627055};\\\", \\\"{x:1625,y:955,t:1527019627073};\\\", \\\"{x:1618,y:958,t:1527019627089};\\\", \\\"{x:1609,y:962,t:1527019627105};\\\", \\\"{x:1600,y:966,t:1527019627122};\\\", \\\"{x:1599,y:966,t:1527019627139};\\\", \\\"{x:1599,y:962,t:1527019627265};\\\", \\\"{x:1599,y:956,t:1527019627273};\\\", \\\"{x:1603,y:946,t:1527019627289};\\\", \\\"{x:1606,y:938,t:1527019627306};\\\", \\\"{x:1609,y:932,t:1527019627322};\\\", \\\"{x:1610,y:930,t:1527019627340};\\\", \\\"{x:1612,y:926,t:1527019627356};\\\", \\\"{x:1613,y:923,t:1527019627372};\\\", \\\"{x:1614,y:922,t:1527019627390};\\\", \\\"{x:1614,y:918,t:1527019627406};\\\", \\\"{x:1617,y:915,t:1527019627422};\\\", \\\"{x:1618,y:909,t:1527019627440};\\\", \\\"{x:1621,y:901,t:1527019627457};\\\", \\\"{x:1624,y:897,t:1527019627473};\\\", \\\"{x:1625,y:893,t:1527019627488};\\\", \\\"{x:1628,y:887,t:1527019627506};\\\", \\\"{x:1630,y:882,t:1527019627522};\\\", \\\"{x:1635,y:872,t:1527019627539};\\\", \\\"{x:1639,y:865,t:1527019627557};\\\", \\\"{x:1641,y:860,t:1527019627572};\\\", \\\"{x:1642,y:856,t:1527019627589};\\\", \\\"{x:1645,y:851,t:1527019627606};\\\", \\\"{x:1648,y:847,t:1527019627622};\\\", \\\"{x:1650,y:843,t:1527019627640};\\\", \\\"{x:1657,y:831,t:1527019627656};\\\", \\\"{x:1658,y:829,t:1527019627672};\\\", \\\"{x:1661,y:824,t:1527019627689};\\\", \\\"{x:1662,y:822,t:1527019627707};\\\", \\\"{x:1664,y:820,t:1527019627724};\\\", \\\"{x:1666,y:816,t:1527019627740};\\\", \\\"{x:1667,y:815,t:1527019627756};\\\", \\\"{x:1668,y:813,t:1527019627774};\\\", \\\"{x:1669,y:812,t:1527019627789};\\\", \\\"{x:1669,y:810,t:1527019627807};\\\", \\\"{x:1667,y:810,t:1527019634761};\\\", \\\"{x:1661,y:820,t:1527019634778};\\\", \\\"{x:1652,y:832,t:1527019634796};\\\", \\\"{x:1649,y:839,t:1527019634813};\\\", \\\"{x:1648,y:840,t:1527019634829};\\\", \\\"{x:1646,y:844,t:1527019634846};\\\", \\\"{x:1645,y:851,t:1527019634862};\\\", \\\"{x:1644,y:860,t:1527019634879};\\\", \\\"{x:1643,y:871,t:1527019634895};\\\", \\\"{x:1638,y:891,t:1527019634912};\\\", \\\"{x:1634,y:904,t:1527019634928};\\\", \\\"{x:1633,y:919,t:1527019634946};\\\", \\\"{x:1630,y:931,t:1527019634963};\\\", \\\"{x:1629,y:944,t:1527019634979};\\\", \\\"{x:1626,y:955,t:1527019634996};\\\", \\\"{x:1626,y:966,t:1527019635013};\\\", \\\"{x:1626,y:973,t:1527019635029};\\\", \\\"{x:1625,y:979,t:1527019635046};\\\", \\\"{x:1624,y:983,t:1527019635062};\\\", \\\"{x:1623,y:984,t:1527019635078};\\\", \\\"{x:1622,y:983,t:1527019635185};\\\", \\\"{x:1621,y:979,t:1527019635196};\\\", \\\"{x:1618,y:971,t:1527019635213};\\\", \\\"{x:1616,y:962,t:1527019635230};\\\", \\\"{x:1613,y:954,t:1527019635246};\\\", \\\"{x:1610,y:947,t:1527019635263};\\\", \\\"{x:1609,y:944,t:1527019635279};\\\", \\\"{x:1608,y:940,t:1527019635296};\\\", \\\"{x:1607,y:935,t:1527019635312};\\\", \\\"{x:1607,y:933,t:1527019635329};\\\", \\\"{x:1605,y:931,t:1527019635346};\\\", \\\"{x:1605,y:929,t:1527019635362};\\\", \\\"{x:1605,y:928,t:1527019635521};\\\", \\\"{x:1605,y:927,t:1527019635537};\\\", \\\"{x:1605,y:923,t:1527019635546};\\\", \\\"{x:1604,y:917,t:1527019635563};\\\", \\\"{x:1604,y:911,t:1527019635580};\\\", \\\"{x:1604,y:906,t:1527019635597};\\\", \\\"{x:1603,y:901,t:1527019635613};\\\", \\\"{x:1603,y:893,t:1527019635630};\\\", \\\"{x:1601,y:887,t:1527019635646};\\\", \\\"{x:1601,y:882,t:1527019635663};\\\", \\\"{x:1601,y:878,t:1527019635680};\\\", \\\"{x:1601,y:872,t:1527019635697};\\\", \\\"{x:1601,y:867,t:1527019635713};\\\", \\\"{x:1600,y:860,t:1527019635729};\\\", \\\"{x:1600,y:855,t:1527019635747};\\\", \\\"{x:1600,y:851,t:1527019635763};\\\", \\\"{x:1599,y:847,t:1527019635779};\\\", \\\"{x:1599,y:842,t:1527019635797};\\\", \\\"{x:1599,y:836,t:1527019635813};\\\", \\\"{x:1599,y:832,t:1527019635830};\\\", \\\"{x:1599,y:827,t:1527019635847};\\\", \\\"{x:1599,y:823,t:1527019635863};\\\", \\\"{x:1599,y:822,t:1527019635879};\\\", \\\"{x:1599,y:817,t:1527019635896};\\\", \\\"{x:1599,y:811,t:1527019635913};\\\", \\\"{x:1599,y:807,t:1527019635930};\\\", \\\"{x:1599,y:802,t:1527019635946};\\\", \\\"{x:1600,y:798,t:1527019635964};\\\", \\\"{x:1601,y:794,t:1527019635980};\\\", \\\"{x:1603,y:789,t:1527019635997};\\\", \\\"{x:1603,y:786,t:1527019636014};\\\", \\\"{x:1604,y:782,t:1527019636030};\\\", \\\"{x:1604,y:779,t:1527019636047};\\\", \\\"{x:1605,y:776,t:1527019636063};\\\", \\\"{x:1606,y:773,t:1527019636079};\\\", \\\"{x:1608,y:768,t:1527019636097};\\\", \\\"{x:1609,y:765,t:1527019636114};\\\", \\\"{x:1609,y:764,t:1527019636130};\\\", \\\"{x:1609,y:763,t:1527019636147};\\\", \\\"{x:1609,y:762,t:1527019636170};\\\", \\\"{x:1613,y:769,t:1527019636361};\\\", \\\"{x:1618,y:778,t:1527019636370};\\\", \\\"{x:1624,y:787,t:1527019636380};\\\", \\\"{x:1635,y:804,t:1527019636397};\\\", \\\"{x:1647,y:819,t:1527019636414};\\\", \\\"{x:1658,y:833,t:1527019636430};\\\", \\\"{x:1670,y:841,t:1527019636447};\\\", \\\"{x:1672,y:844,t:1527019636464};\\\", \\\"{x:1676,y:845,t:1527019636480};\\\", \\\"{x:1667,y:844,t:1527019636777};\\\", \\\"{x:1655,y:838,t:1527019636785};\\\", \\\"{x:1634,y:831,t:1527019636797};\\\", \\\"{x:1522,y:807,t:1527019636813};\\\", \\\"{x:1399,y:780,t:1527019636830};\\\", \\\"{x:1255,y:760,t:1527019636847};\\\", \\\"{x:1080,y:731,t:1527019636863};\\\", \\\"{x:846,y:672,t:1527019636880};\\\", \\\"{x:724,y:636,t:1527019636897};\\\", \\\"{x:619,y:620,t:1527019636913};\\\", \\\"{x:551,y:610,t:1527019636931};\\\", \\\"{x:515,y:600,t:1527019636945};\\\", \\\"{x:494,y:589,t:1527019636963};\\\", \\\"{x:486,y:584,t:1527019636978};\\\", \\\"{x:485,y:583,t:1527019636996};\\\", \\\"{x:485,y:580,t:1527019637017};\\\", \\\"{x:485,y:577,t:1527019637030};\\\", \\\"{x:485,y:571,t:1527019637047};\\\", \\\"{x:485,y:562,t:1527019637063};\\\", \\\"{x:485,y:553,t:1527019637079};\\\", \\\"{x:485,y:549,t:1527019637097};\\\", \\\"{x:485,y:543,t:1527019637114};\\\", \\\"{x:489,y:539,t:1527019637130};\\\", \\\"{x:496,y:535,t:1527019637147};\\\", \\\"{x:505,y:530,t:1527019637164};\\\", \\\"{x:515,y:526,t:1527019637180};\\\", \\\"{x:532,y:519,t:1527019637198};\\\", \\\"{x:552,y:510,t:1527019637213};\\\", \\\"{x:575,y:506,t:1527019637230};\\\", \\\"{x:596,y:504,t:1527019637248};\\\", \\\"{x:612,y:504,t:1527019637263};\\\", \\\"{x:636,y:504,t:1527019637280};\\\", \\\"{x:647,y:504,t:1527019637297};\\\", \\\"{x:657,y:504,t:1527019637313};\\\", \\\"{x:669,y:504,t:1527019637330};\\\", \\\"{x:684,y:504,t:1527019637346};\\\", \\\"{x:695,y:504,t:1527019637364};\\\", \\\"{x:708,y:504,t:1527019637379};\\\", \\\"{x:711,y:504,t:1527019637397};\\\", \\\"{x:712,y:504,t:1527019637413};\\\", \\\"{x:714,y:504,t:1527019637429};\\\", \\\"{x:714,y:506,t:1527019637514};\\\", \\\"{x:691,y:510,t:1527019637529};\\\", \\\"{x:628,y:510,t:1527019637548};\\\", \\\"{x:533,y:510,t:1527019637565};\\\", \\\"{x:453,y:510,t:1527019637581};\\\", \\\"{x:419,y:521,t:1527019637597};\\\", \\\"{x:400,y:527,t:1527019637614};\\\", \\\"{x:395,y:528,t:1527019637630};\\\", \\\"{x:391,y:528,t:1527019637647};\\\", \\\"{x:390,y:529,t:1527019637664};\\\", \\\"{x:388,y:529,t:1527019637800};\\\", \\\"{x:387,y:531,t:1527019637814};\\\", \\\"{x:384,y:533,t:1527019637831};\\\", \\\"{x:382,y:536,t:1527019637847};\\\", \\\"{x:374,y:545,t:1527019637866};\\\", \\\"{x:367,y:556,t:1527019637881};\\\", \\\"{x:361,y:567,t:1527019637897};\\\", \\\"{x:356,y:583,t:1527019637914};\\\", \\\"{x:349,y:599,t:1527019637931};\\\", \\\"{x:345,y:620,t:1527019637948};\\\", \\\"{x:343,y:640,t:1527019637965};\\\", \\\"{x:342,y:654,t:1527019637982};\\\", \\\"{x:342,y:661,t:1527019637997};\\\", \\\"{x:342,y:666,t:1527019638014};\\\", \\\"{x:342,y:670,t:1527019638030};\\\", \\\"{x:344,y:674,t:1527019638047};\\\", \\\"{x:347,y:680,t:1527019638064};\\\", \\\"{x:349,y:683,t:1527019638080};\\\", \\\"{x:350,y:685,t:1527019638098};\\\", \\\"{x:351,y:685,t:1527019638120};\\\", \\\"{x:352,y:686,t:1527019638265};\\\", \\\"{x:353,y:687,t:1527019638287};\\\", \\\"{x:354,y:687,t:1527019638297};\\\", \\\"{x:358,y:687,t:1527019638314};\\\", \\\"{x:360,y:687,t:1527019638331};\\\", \\\"{x:365,y:688,t:1527019638347};\\\", \\\"{x:369,y:688,t:1527019638364};\\\", \\\"{x:373,y:688,t:1527019638382};\\\", \\\"{x:378,y:683,t:1527019638397};\\\", \\\"{x:385,y:675,t:1527019638414};\\\", \\\"{x:387,y:668,t:1527019638431};\\\", \\\"{x:390,y:655,t:1527019638448};\\\", \\\"{x:390,y:640,t:1527019638464};\\\", \\\"{x:390,y:634,t:1527019638481};\\\", \\\"{x:390,y:632,t:1527019638498};\\\", \\\"{x:390,y:630,t:1527019638514};\\\", \\\"{x:390,y:629,t:1527019638531};\\\", \\\"{x:390,y:627,t:1527019638559};\\\", \\\"{x:391,y:627,t:1527019640376};\\\", \\\"{x:397,y:633,t:1527019640384};\\\", \\\"{x:408,y:652,t:1527019640400};\\\", \\\"{x:442,y:696,t:1527019640416};\\\", \\\"{x:451,y:703,t:1527019640433};\\\", \\\"{x:458,y:706,t:1527019640449};\\\", \\\"{x:461,y:708,t:1527019640466};\\\", \\\"{x:463,y:708,t:1527019640483};\\\", \\\"{x:465,y:708,t:1527019640499};\\\", \\\"{x:466,y:708,t:1527019640516};\\\", \\\"{x:469,y:708,t:1527019640533};\\\", \\\"{x:472,y:708,t:1527019640549};\\\", \\\"{x:474,y:707,t:1527019640566};\\\", \\\"{x:475,y:706,t:1527019640583};\\\", \\\"{x:476,y:706,t:1527019640599};\\\" ] }, { \\\"rt\\\": 43537, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 309494, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -2-11 AM-11 AM-12 PM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:722,t:1527019643976};\\\", \\\"{x:586,y:813,t:1527019643998};\\\", \\\"{x:787,y:936,t:1527019644017};\\\", \\\"{x:939,y:1010,t:1527019644035};\\\", \\\"{x:1102,y:1078,t:1527019644053};\\\", \\\"{x:1247,y:1133,t:1527019644069};\\\", \\\"{x:1344,y:1163,t:1527019644087};\\\", \\\"{x:1392,y:1167,t:1527019644102};\\\", \\\"{x:1405,y:1167,t:1527019644120};\\\", \\\"{x:1406,y:1166,t:1527019644135};\\\", \\\"{x:1406,y:1155,t:1527019644152};\\\", \\\"{x:1400,y:1134,t:1527019644169};\\\", \\\"{x:1392,y:1110,t:1527019644187};\\\", \\\"{x:1391,y:1093,t:1527019644203};\\\", \\\"{x:1391,y:1076,t:1527019644220};\\\", \\\"{x:1391,y:1056,t:1527019644237};\\\", \\\"{x:1391,y:1035,t:1527019644253};\\\", \\\"{x:1383,y:1012,t:1527019644270};\\\", \\\"{x:1373,y:986,t:1527019644287};\\\", \\\"{x:1352,y:953,t:1527019644303};\\\", \\\"{x:1316,y:920,t:1527019644320};\\\", \\\"{x:1293,y:906,t:1527019644336};\\\", \\\"{x:1277,y:900,t:1527019644353};\\\", \\\"{x:1270,y:894,t:1527019644370};\\\", \\\"{x:1268,y:893,t:1527019644387};\\\", \\\"{x:1268,y:892,t:1527019644403};\\\", \\\"{x:1268,y:891,t:1527019644425};\\\", \\\"{x:1268,y:890,t:1527019644449};\\\", \\\"{x:1268,y:888,t:1527019644457};\\\", \\\"{x:1268,y:886,t:1527019644472};\\\", \\\"{x:1269,y:885,t:1527019644487};\\\", \\\"{x:1270,y:882,t:1527019644504};\\\", \\\"{x:1270,y:880,t:1527019644520};\\\", \\\"{x:1270,y:879,t:1527019644537};\\\", \\\"{x:1268,y:876,t:1527019644554};\\\", \\\"{x:1260,y:872,t:1527019644570};\\\", \\\"{x:1244,y:866,t:1527019644587};\\\", \\\"{x:1235,y:862,t:1527019644606};\\\", \\\"{x:1227,y:858,t:1527019644620};\\\", \\\"{x:1225,y:856,t:1527019644637};\\\", \\\"{x:1223,y:856,t:1527019644654};\\\", \\\"{x:1222,y:856,t:1527019644721};\\\", \\\"{x:1220,y:856,t:1527019644737};\\\", \\\"{x:1219,y:856,t:1527019644857};\\\", \\\"{x:1218,y:856,t:1527019644871};\\\", \\\"{x:1216,y:855,t:1527019644887};\\\", \\\"{x:1214,y:854,t:1527019644904};\\\", \\\"{x:1213,y:854,t:1527019644921};\\\", \\\"{x:1213,y:853,t:1527019645097};\\\", \\\"{x:1213,y:850,t:1527019645104};\\\", \\\"{x:1215,y:846,t:1527019645120};\\\", \\\"{x:1218,y:843,t:1527019645138};\\\", \\\"{x:1218,y:842,t:1527019645392};\\\", \\\"{x:1217,y:842,t:1527019645417};\\\", \\\"{x:1216,y:841,t:1527019645440};\\\", \\\"{x:1215,y:840,t:1527019645457};\\\", \\\"{x:1214,y:840,t:1527019645473};\\\", \\\"{x:1214,y:839,t:1527019645488};\\\", \\\"{x:1213,y:839,t:1527019645785};\\\", \\\"{x:1213,y:838,t:1527019645792};\\\", \\\"{x:1213,y:837,t:1527019645805};\\\", \\\"{x:1213,y:836,t:1527019645822};\\\", \\\"{x:1213,y:833,t:1527019645841};\\\", \\\"{x:1213,y:832,t:1527019645854};\\\", \\\"{x:1213,y:830,t:1527019645871};\\\", \\\"{x:1213,y:832,t:1527019661825};\\\", \\\"{x:1213,y:833,t:1527019661841};\\\", \\\"{x:1213,y:835,t:1527019661872};\\\", \\\"{x:1213,y:836,t:1527019661944};\\\", \\\"{x:1213,y:838,t:1527019662016};\\\", \\\"{x:1213,y:839,t:1527019662040};\\\", \\\"{x:1213,y:841,t:1527019662056};\\\", \\\"{x:1213,y:845,t:1527019662072};\\\", \\\"{x:1213,y:850,t:1527019662090};\\\", \\\"{x:1213,y:859,t:1527019662106};\\\", \\\"{x:1213,y:869,t:1527019662122};\\\", \\\"{x:1213,y:879,t:1527019662140};\\\", \\\"{x:1213,y:890,t:1527019662155};\\\", \\\"{x:1213,y:905,t:1527019662172};\\\", \\\"{x:1213,y:918,t:1527019662189};\\\", \\\"{x:1213,y:923,t:1527019662206};\\\", \\\"{x:1213,y:929,t:1527019662223};\\\", \\\"{x:1213,y:933,t:1527019662239};\\\", \\\"{x:1213,y:940,t:1527019662256};\\\", \\\"{x:1215,y:945,t:1527019662273};\\\", \\\"{x:1216,y:948,t:1527019662290};\\\", \\\"{x:1216,y:950,t:1527019662307};\\\", \\\"{x:1216,y:951,t:1527019662323};\\\", \\\"{x:1218,y:953,t:1527019662340};\\\", \\\"{x:1218,y:955,t:1527019662357};\\\", \\\"{x:1218,y:956,t:1527019662372};\\\", \\\"{x:1218,y:957,t:1527019662433};\\\", \\\"{x:1218,y:958,t:1527019662472};\\\", \\\"{x:1218,y:961,t:1527019662490};\\\", \\\"{x:1218,y:963,t:1527019662507};\\\", \\\"{x:1218,y:964,t:1527019662524};\\\", \\\"{x:1218,y:965,t:1527019662545};\\\", \\\"{x:1218,y:966,t:1527019662557};\\\", \\\"{x:1218,y:967,t:1527019662609};\\\", \\\"{x:1218,y:968,t:1527019662673};\\\", \\\"{x:1218,y:964,t:1527019662993};\\\", \\\"{x:1218,y:958,t:1527019663007};\\\", \\\"{x:1220,y:945,t:1527019663024};\\\", \\\"{x:1222,y:938,t:1527019663040};\\\", \\\"{x:1223,y:933,t:1527019663057};\\\", \\\"{x:1225,y:927,t:1527019663074};\\\", \\\"{x:1225,y:926,t:1527019663090};\\\", \\\"{x:1226,y:923,t:1527019663107};\\\", \\\"{x:1226,y:922,t:1527019663124};\\\", \\\"{x:1226,y:919,t:1527019663141};\\\", \\\"{x:1226,y:916,t:1527019663158};\\\", \\\"{x:1226,y:912,t:1527019663174};\\\", \\\"{x:1226,y:908,t:1527019663191};\\\", \\\"{x:1226,y:904,t:1527019663208};\\\", \\\"{x:1226,y:901,t:1527019663224};\\\", \\\"{x:1226,y:898,t:1527019663240};\\\", \\\"{x:1226,y:893,t:1527019663258};\\\", \\\"{x:1225,y:888,t:1527019663274};\\\", \\\"{x:1225,y:884,t:1527019663291};\\\", \\\"{x:1225,y:879,t:1527019663307};\\\", \\\"{x:1223,y:873,t:1527019663324};\\\", \\\"{x:1222,y:868,t:1527019663341};\\\", \\\"{x:1222,y:861,t:1527019663358};\\\", \\\"{x:1221,y:856,t:1527019663374};\\\", \\\"{x:1221,y:853,t:1527019663391};\\\", \\\"{x:1221,y:849,t:1527019663408};\\\", \\\"{x:1221,y:846,t:1527019663424};\\\", \\\"{x:1221,y:843,t:1527019663442};\\\", \\\"{x:1221,y:841,t:1527019663458};\\\", \\\"{x:1221,y:840,t:1527019663475};\\\", \\\"{x:1221,y:837,t:1527019663491};\\\", \\\"{x:1219,y:836,t:1527019663508};\\\", \\\"{x:1219,y:835,t:1527019663525};\\\", \\\"{x:1219,y:833,t:1527019663542};\\\", \\\"{x:1219,y:831,t:1527019663584};\\\", \\\"{x:1219,y:830,t:1527019663616};\\\", \\\"{x:1219,y:828,t:1527019663688};\\\", \\\"{x:1218,y:828,t:1527019664535};\\\", \\\"{x:1217,y:828,t:1527019665713};\\\", \\\"{x:1215,y:828,t:1527019665728};\\\", \\\"{x:1214,y:828,t:1527019665841};\\\", \\\"{x:1212,y:829,t:1527019666360};\\\", \\\"{x:1204,y:831,t:1527019666379};\\\", \\\"{x:1195,y:832,t:1527019666394};\\\", \\\"{x:1179,y:833,t:1527019666411};\\\", \\\"{x:1168,y:835,t:1527019666428};\\\", \\\"{x:1158,y:835,t:1527019666444};\\\", \\\"{x:1154,y:835,t:1527019666461};\\\", \\\"{x:1153,y:835,t:1527019666478};\\\", \\\"{x:1150,y:835,t:1527019666494};\\\", \\\"{x:1147,y:835,t:1527019666511};\\\", \\\"{x:1139,y:835,t:1527019666527};\\\", \\\"{x:1135,y:835,t:1527019666544};\\\", \\\"{x:1129,y:835,t:1527019666561};\\\", \\\"{x:1124,y:835,t:1527019666578};\\\", \\\"{x:1120,y:835,t:1527019666594};\\\", \\\"{x:1114,y:835,t:1527019666611};\\\", \\\"{x:1106,y:835,t:1527019666628};\\\", \\\"{x:1095,y:835,t:1527019666644};\\\", \\\"{x:1082,y:834,t:1527019666661};\\\", \\\"{x:1072,y:833,t:1527019666679};\\\", \\\"{x:1063,y:832,t:1527019666696};\\\", \\\"{x:1056,y:832,t:1527019666711};\\\", \\\"{x:1042,y:832,t:1527019666729};\\\", \\\"{x:1032,y:832,t:1527019666744};\\\", \\\"{x:1025,y:832,t:1527019666762};\\\", \\\"{x:1023,y:832,t:1527019666778};\\\", \\\"{x:1024,y:832,t:1527019666961};\\\", \\\"{x:1032,y:832,t:1527019666968};\\\", \\\"{x:1043,y:832,t:1527019666979};\\\", \\\"{x:1064,y:832,t:1527019666996};\\\", \\\"{x:1079,y:832,t:1527019667012};\\\", \\\"{x:1091,y:832,t:1527019667028};\\\", \\\"{x:1095,y:832,t:1527019667045};\\\", \\\"{x:1097,y:832,t:1527019667062};\\\", \\\"{x:1101,y:832,t:1527019667078};\\\", \\\"{x:1106,y:833,t:1527019667095};\\\", \\\"{x:1122,y:836,t:1527019667112};\\\", \\\"{x:1127,y:836,t:1527019667128};\\\", \\\"{x:1131,y:836,t:1527019667145};\\\", \\\"{x:1135,y:836,t:1527019667162};\\\", \\\"{x:1141,y:836,t:1527019667179};\\\", \\\"{x:1151,y:836,t:1527019667195};\\\", \\\"{x:1166,y:836,t:1527019667212};\\\", \\\"{x:1183,y:836,t:1527019667228};\\\", \\\"{x:1192,y:836,t:1527019667245};\\\", \\\"{x:1198,y:836,t:1527019667262};\\\", \\\"{x:1207,y:836,t:1527019667280};\\\", \\\"{x:1215,y:836,t:1527019667295};\\\", \\\"{x:1222,y:838,t:1527019667312};\\\", \\\"{x:1223,y:838,t:1527019667329};\\\", \\\"{x:1223,y:842,t:1527019667697};\\\", \\\"{x:1224,y:864,t:1527019667712};\\\", \\\"{x:1228,y:889,t:1527019667729};\\\", \\\"{x:1230,y:915,t:1527019667746};\\\", \\\"{x:1231,y:941,t:1527019667762};\\\", \\\"{x:1236,y:967,t:1527019667779};\\\", \\\"{x:1238,y:989,t:1527019667796};\\\", \\\"{x:1239,y:1012,t:1527019667813};\\\", \\\"{x:1239,y:1034,t:1527019667829};\\\", \\\"{x:1239,y:1049,t:1527019667847};\\\", \\\"{x:1240,y:1059,t:1527019667862};\\\", \\\"{x:1240,y:1061,t:1527019667879};\\\", \\\"{x:1241,y:1057,t:1527019667976};\\\", \\\"{x:1241,y:1049,t:1527019667984};\\\", \\\"{x:1241,y:1040,t:1527019667996};\\\", \\\"{x:1241,y:1019,t:1527019668013};\\\", \\\"{x:1241,y:1001,t:1527019668029};\\\", \\\"{x:1241,y:992,t:1527019668046};\\\", \\\"{x:1241,y:987,t:1527019668063};\\\", \\\"{x:1241,y:984,t:1527019668080};\\\", \\\"{x:1242,y:977,t:1527019668097};\\\", \\\"{x:1243,y:976,t:1527019668113};\\\", \\\"{x:1244,y:975,t:1527019668129};\\\", \\\"{x:1245,y:971,t:1527019668146};\\\", \\\"{x:1249,y:968,t:1527019668163};\\\", \\\"{x:1252,y:964,t:1527019668180};\\\", \\\"{x:1258,y:958,t:1527019668197};\\\", \\\"{x:1265,y:954,t:1527019668213};\\\", \\\"{x:1267,y:952,t:1527019668230};\\\", \\\"{x:1272,y:950,t:1527019668246};\\\", \\\"{x:1273,y:950,t:1527019668263};\\\", \\\"{x:1274,y:949,t:1527019668281};\\\", \\\"{x:1276,y:949,t:1527019668297};\\\", \\\"{x:1278,y:949,t:1527019668313};\\\", \\\"{x:1280,y:949,t:1527019668330};\\\", \\\"{x:1281,y:949,t:1527019668346};\\\", \\\"{x:1282,y:949,t:1527019668363};\\\", \\\"{x:1285,y:950,t:1527019668381};\\\", \\\"{x:1290,y:952,t:1527019668396};\\\", \\\"{x:1295,y:955,t:1527019668413};\\\", \\\"{x:1296,y:955,t:1527019668431};\\\", \\\"{x:1297,y:955,t:1527019668447};\\\", \\\"{x:1298,y:957,t:1527019668463};\\\", \\\"{x:1300,y:957,t:1527019668576};\\\", \\\"{x:1301,y:958,t:1527019668592};\\\", \\\"{x:1302,y:960,t:1527019668633};\\\", \\\"{x:1302,y:961,t:1527019668737};\\\", \\\"{x:1302,y:963,t:1527019668748};\\\", \\\"{x:1300,y:968,t:1527019668764};\\\", \\\"{x:1282,y:969,t:1527019668781};\\\", \\\"{x:1256,y:969,t:1527019668797};\\\", \\\"{x:1235,y:967,t:1527019668813};\\\", \\\"{x:1231,y:965,t:1527019668829};\\\", \\\"{x:1230,y:965,t:1527019668864};\\\", \\\"{x:1230,y:964,t:1527019668880};\\\", \\\"{x:1229,y:964,t:1527019668968};\\\", \\\"{x:1228,y:964,t:1527019669073};\\\", \\\"{x:1227,y:963,t:1527019669080};\\\", \\\"{x:1221,y:963,t:1527019669098};\\\", \\\"{x:1219,y:963,t:1527019669114};\\\", \\\"{x:1218,y:963,t:1527019669130};\\\", \\\"{x:1217,y:963,t:1527019669361};\\\", \\\"{x:1219,y:965,t:1527019669369};\\\", \\\"{x:1229,y:966,t:1527019669382};\\\", \\\"{x:1242,y:968,t:1527019669397};\\\", \\\"{x:1251,y:968,t:1527019669414};\\\", \\\"{x:1259,y:968,t:1527019669431};\\\", \\\"{x:1263,y:968,t:1527019669447};\\\", \\\"{x:1264,y:969,t:1527019669464};\\\", \\\"{x:1268,y:970,t:1527019669481};\\\", \\\"{x:1271,y:972,t:1527019669497};\\\", \\\"{x:1274,y:972,t:1527019669514};\\\", \\\"{x:1277,y:974,t:1527019669531};\\\", \\\"{x:1279,y:974,t:1527019669681};\\\", \\\"{x:1281,y:973,t:1527019669698};\\\", \\\"{x:1281,y:971,t:1527019669714};\\\", \\\"{x:1282,y:971,t:1527019669731};\\\", \\\"{x:1286,y:971,t:1527019669929};\\\", \\\"{x:1292,y:972,t:1527019669937};\\\", \\\"{x:1298,y:973,t:1527019669948};\\\", \\\"{x:1306,y:973,t:1527019669966};\\\", \\\"{x:1316,y:973,t:1527019669981};\\\", \\\"{x:1319,y:973,t:1527019669998};\\\", \\\"{x:1321,y:973,t:1527019670015};\\\", \\\"{x:1322,y:973,t:1527019670032};\\\", \\\"{x:1327,y:974,t:1527019670048};\\\", \\\"{x:1331,y:974,t:1527019670065};\\\", \\\"{x:1334,y:974,t:1527019670081};\\\", \\\"{x:1335,y:974,t:1527019670098};\\\", \\\"{x:1336,y:974,t:1527019670115};\\\", \\\"{x:1337,y:974,t:1527019670216};\\\", \\\"{x:1338,y:974,t:1527019670233};\\\", \\\"{x:1339,y:974,t:1527019670273};\\\", \\\"{x:1339,y:973,t:1527019670282};\\\", \\\"{x:1340,y:973,t:1527019670298};\\\", \\\"{x:1342,y:972,t:1527019670316};\\\", \\\"{x:1342,y:970,t:1527019670332};\\\", \\\"{x:1344,y:969,t:1527019670349};\\\", \\\"{x:1346,y:967,t:1527019670366};\\\", \\\"{x:1347,y:966,t:1527019670382};\\\", \\\"{x:1350,y:964,t:1527019670399};\\\", \\\"{x:1352,y:963,t:1527019670415};\\\", \\\"{x:1353,y:962,t:1527019670433};\\\", \\\"{x:1353,y:964,t:1527019670801};\\\", \\\"{x:1353,y:965,t:1527019670817};\\\", \\\"{x:1353,y:966,t:1527019670832};\\\", \\\"{x:1353,y:967,t:1527019671065};\\\", \\\"{x:1353,y:968,t:1527019671073};\\\", \\\"{x:1352,y:968,t:1527019671083};\\\", \\\"{x:1352,y:969,t:1527019671100};\\\", \\\"{x:1351,y:971,t:1527019671217};\\\", \\\"{x:1351,y:972,t:1527019671249};\\\", \\\"{x:1350,y:973,t:1527019671266};\\\", \\\"{x:1348,y:972,t:1527019672729};\\\", \\\"{x:1346,y:970,t:1527019672736};\\\", \\\"{x:1346,y:968,t:1527019672752};\\\", \\\"{x:1341,y:962,t:1527019672769};\\\", \\\"{x:1340,y:961,t:1527019672785};\\\", \\\"{x:1339,y:961,t:1527019672969};\\\", \\\"{x:1333,y:961,t:1527019672985};\\\", \\\"{x:1326,y:963,t:1527019673002};\\\", \\\"{x:1319,y:967,t:1527019673018};\\\", \\\"{x:1313,y:970,t:1527019673035};\\\", \\\"{x:1311,y:970,t:1527019673052};\\\", \\\"{x:1310,y:970,t:1527019673068};\\\", \\\"{x:1309,y:970,t:1527019673088};\\\", \\\"{x:1310,y:970,t:1527019673232};\\\", \\\"{x:1315,y:968,t:1527019673240};\\\", \\\"{x:1318,y:966,t:1527019673252};\\\", \\\"{x:1330,y:963,t:1527019673269};\\\", \\\"{x:1345,y:963,t:1527019673285};\\\", \\\"{x:1353,y:963,t:1527019673302};\\\", \\\"{x:1354,y:963,t:1527019673318};\\\", \\\"{x:1353,y:963,t:1527019673512};\\\", \\\"{x:1352,y:963,t:1527019673552};\\\", \\\"{x:1349,y:963,t:1527019673729};\\\", \\\"{x:1345,y:963,t:1527019673736};\\\", \\\"{x:1340,y:963,t:1527019673753};\\\", \\\"{x:1338,y:962,t:1527019673770};\\\", \\\"{x:1337,y:962,t:1527019673800};\\\", \\\"{x:1337,y:961,t:1527019674056};\\\", \\\"{x:1337,y:960,t:1527019674072};\\\", \\\"{x:1337,y:959,t:1527019674096};\\\", \\\"{x:1337,y:958,t:1527019674336};\\\", \\\"{x:1337,y:953,t:1527019674354};\\\", \\\"{x:1337,y:948,t:1527019674369};\\\", \\\"{x:1337,y:943,t:1527019674386};\\\", \\\"{x:1337,y:937,t:1527019674403};\\\", \\\"{x:1337,y:931,t:1527019674419};\\\", \\\"{x:1337,y:926,t:1527019674436};\\\", \\\"{x:1337,y:920,t:1527019674453};\\\", \\\"{x:1337,y:912,t:1527019674469};\\\", \\\"{x:1337,y:899,t:1527019674486};\\\", \\\"{x:1337,y:889,t:1527019674503};\\\", \\\"{x:1337,y:880,t:1527019674519};\\\", \\\"{x:1336,y:867,t:1527019674536};\\\", \\\"{x:1336,y:859,t:1527019674553};\\\", \\\"{x:1333,y:854,t:1527019674570};\\\", \\\"{x:1333,y:851,t:1527019674586};\\\", \\\"{x:1333,y:847,t:1527019674603};\\\", \\\"{x:1333,y:845,t:1527019674620};\\\", \\\"{x:1333,y:841,t:1527019674637};\\\", \\\"{x:1333,y:839,t:1527019674664};\\\", \\\"{x:1333,y:838,t:1527019674688};\\\", \\\"{x:1333,y:836,t:1527019674720};\\\", \\\"{x:1333,y:835,t:1527019674736};\\\", \\\"{x:1333,y:832,t:1527019674754};\\\", \\\"{x:1335,y:828,t:1527019674770};\\\", \\\"{x:1336,y:826,t:1527019674786};\\\", \\\"{x:1336,y:822,t:1527019674804};\\\", \\\"{x:1336,y:820,t:1527019674820};\\\", \\\"{x:1336,y:818,t:1527019674836};\\\", \\\"{x:1336,y:814,t:1527019674853};\\\", \\\"{x:1337,y:811,t:1527019674870};\\\", \\\"{x:1337,y:808,t:1527019674887};\\\", \\\"{x:1337,y:806,t:1527019674904};\\\", \\\"{x:1338,y:803,t:1527019674920};\\\", \\\"{x:1339,y:801,t:1527019674937};\\\", \\\"{x:1340,y:799,t:1527019674954};\\\", \\\"{x:1340,y:795,t:1527019674971};\\\", \\\"{x:1340,y:792,t:1527019674987};\\\", \\\"{x:1340,y:787,t:1527019675003};\\\", \\\"{x:1341,y:784,t:1527019675021};\\\", \\\"{x:1343,y:780,t:1527019675037};\\\", \\\"{x:1343,y:775,t:1527019675054};\\\", \\\"{x:1343,y:771,t:1527019675070};\\\", \\\"{x:1344,y:766,t:1527019675088};\\\", \\\"{x:1345,y:759,t:1527019675104};\\\", \\\"{x:1345,y:750,t:1527019675120};\\\", \\\"{x:1345,y:743,t:1527019675137};\\\", \\\"{x:1345,y:736,t:1527019675153};\\\", \\\"{x:1345,y:731,t:1527019675171};\\\", \\\"{x:1345,y:728,t:1527019675187};\\\", \\\"{x:1345,y:725,t:1527019675206};\\\", \\\"{x:1345,y:722,t:1527019675220};\\\", \\\"{x:1346,y:720,t:1527019675237};\\\", \\\"{x:1347,y:717,t:1527019675254};\\\", \\\"{x:1348,y:714,t:1527019675271};\\\", \\\"{x:1348,y:711,t:1527019675287};\\\", \\\"{x:1348,y:705,t:1527019675304};\\\", \\\"{x:1348,y:703,t:1527019675321};\\\", \\\"{x:1348,y:701,t:1527019675338};\\\", \\\"{x:1348,y:700,t:1527019675355};\\\", \\\"{x:1348,y:699,t:1527019675370};\\\", \\\"{x:1349,y:698,t:1527019675387};\\\", \\\"{x:1350,y:697,t:1527019675405};\\\", \\\"{x:1350,y:695,t:1527019675421};\\\", \\\"{x:1350,y:694,t:1527019675438};\\\", \\\"{x:1350,y:692,t:1527019675454};\\\", \\\"{x:1350,y:689,t:1527019675471};\\\", \\\"{x:1350,y:686,t:1527019675488};\\\", \\\"{x:1350,y:679,t:1527019675504};\\\", \\\"{x:1350,y:675,t:1527019675522};\\\", \\\"{x:1351,y:669,t:1527019675541};\\\", \\\"{x:1351,y:664,t:1527019675558};\\\", \\\"{x:1351,y:656,t:1527019675575};\\\", \\\"{x:1354,y:640,t:1527019675590};\\\", \\\"{x:1355,y:628,t:1527019675609};\\\", \\\"{x:1357,y:615,t:1527019675625};\\\", \\\"{x:1359,y:603,t:1527019675641};\\\", \\\"{x:1359,y:592,t:1527019675658};\\\", \\\"{x:1362,y:582,t:1527019675675};\\\", \\\"{x:1363,y:577,t:1527019675691};\\\", \\\"{x:1363,y:571,t:1527019675708};\\\", \\\"{x:1363,y:566,t:1527019675725};\\\", \\\"{x:1363,y:560,t:1527019675742};\\\", \\\"{x:1363,y:556,t:1527019675758};\\\", \\\"{x:1363,y:551,t:1527019675775};\\\", \\\"{x:1363,y:546,t:1527019675791};\\\", \\\"{x:1363,y:544,t:1527019675809};\\\", \\\"{x:1363,y:541,t:1527019675825};\\\", \\\"{x:1363,y:538,t:1527019675842};\\\", \\\"{x:1363,y:536,t:1527019675858};\\\", \\\"{x:1363,y:534,t:1527019675875};\\\", \\\"{x:1363,y:529,t:1527019675891};\\\", \\\"{x:1363,y:526,t:1527019675908};\\\", \\\"{x:1364,y:521,t:1527019675925};\\\", \\\"{x:1364,y:517,t:1527019675942};\\\", \\\"{x:1364,y:512,t:1527019675958};\\\", \\\"{x:1364,y:507,t:1527019675975};\\\", \\\"{x:1364,y:506,t:1527019675992};\\\", \\\"{x:1364,y:503,t:1527019676008};\\\", \\\"{x:1364,y:502,t:1527019676025};\\\", \\\"{x:1364,y:497,t:1527019676042};\\\", \\\"{x:1364,y:494,t:1527019676058};\\\", \\\"{x:1364,y:490,t:1527019676075};\\\", \\\"{x:1364,y:485,t:1527019676091};\\\", \\\"{x:1364,y:483,t:1527019676108};\\\", \\\"{x:1364,y:480,t:1527019676125};\\\", \\\"{x:1364,y:479,t:1527019676141};\\\", \\\"{x:1364,y:475,t:1527019676159};\\\", \\\"{x:1364,y:471,t:1527019676175};\\\", \\\"{x:1364,y:468,t:1527019676192};\\\", \\\"{x:1365,y:465,t:1527019676209};\\\", \\\"{x:1365,y:463,t:1527019676228};\\\", \\\"{x:1365,y:462,t:1527019676252};\\\", \\\"{x:1365,y:461,t:1527019676292};\\\", \\\"{x:1365,y:462,t:1527019678068};\\\", \\\"{x:1365,y:463,t:1527019678084};\\\", \\\"{x:1365,y:464,t:1527019678124};\\\", \\\"{x:1365,y:465,t:1527019678179};\\\", \\\"{x:1365,y:467,t:1527019678204};\\\", \\\"{x:1366,y:468,t:1527019678228};\\\", \\\"{x:1366,y:470,t:1527019678259};\\\", \\\"{x:1366,y:472,t:1527019678292};\\\", \\\"{x:1366,y:475,t:1527019678299};\\\", \\\"{x:1367,y:475,t:1527019678311};\\\", \\\"{x:1367,y:477,t:1527019678332};\\\", \\\"{x:1367,y:478,t:1527019678356};\\\", \\\"{x:1367,y:480,t:1527019678372};\\\", \\\"{x:1367,y:481,t:1527019678388};\\\", \\\"{x:1367,y:484,t:1527019678395};\\\", \\\"{x:1367,y:487,t:1527019678411};\\\", \\\"{x:1367,y:495,t:1527019678428};\\\", \\\"{x:1367,y:500,t:1527019678444};\\\", \\\"{x:1367,y:503,t:1527019678461};\\\", \\\"{x:1366,y:513,t:1527019678478};\\\", \\\"{x:1366,y:517,t:1527019678495};\\\", \\\"{x:1366,y:523,t:1527019678511};\\\", \\\"{x:1366,y:532,t:1527019678528};\\\", \\\"{x:1366,y:538,t:1527019678544};\\\", \\\"{x:1366,y:549,t:1527019678561};\\\", \\\"{x:1366,y:561,t:1527019678578};\\\", \\\"{x:1366,y:573,t:1527019678594};\\\", \\\"{x:1366,y:586,t:1527019678611};\\\", \\\"{x:1366,y:605,t:1527019678627};\\\", \\\"{x:1366,y:626,t:1527019678644};\\\", \\\"{x:1366,y:649,t:1527019678661};\\\", \\\"{x:1366,y:672,t:1527019678678};\\\", \\\"{x:1366,y:699,t:1527019678696};\\\", \\\"{x:1366,y:721,t:1527019678711};\\\", \\\"{x:1366,y:742,t:1527019678728};\\\", \\\"{x:1366,y:763,t:1527019678745};\\\", \\\"{x:1366,y:772,t:1527019678761};\\\", \\\"{x:1366,y:780,t:1527019678778};\\\", \\\"{x:1366,y:794,t:1527019678795};\\\", \\\"{x:1366,y:809,t:1527019678812};\\\", \\\"{x:1366,y:833,t:1527019678827};\\\", \\\"{x:1366,y:848,t:1527019678844};\\\", \\\"{x:1366,y:864,t:1527019678861};\\\", \\\"{x:1366,y:875,t:1527019678878};\\\", \\\"{x:1365,y:887,t:1527019678895};\\\", \\\"{x:1362,y:900,t:1527019678910};\\\", \\\"{x:1361,y:915,t:1527019678928};\\\", \\\"{x:1358,y:926,t:1527019678945};\\\", \\\"{x:1358,y:934,t:1527019678961};\\\", \\\"{x:1358,y:942,t:1527019678978};\\\", \\\"{x:1358,y:945,t:1527019678995};\\\", \\\"{x:1357,y:955,t:1527019679011};\\\", \\\"{x:1356,y:957,t:1527019679028};\\\", \\\"{x:1354,y:960,t:1527019679045};\\\", \\\"{x:1354,y:962,t:1527019679062};\\\", \\\"{x:1353,y:963,t:1527019679078};\\\", \\\"{x:1353,y:964,t:1527019679095};\\\", \\\"{x:1353,y:966,t:1527019679112};\\\", \\\"{x:1354,y:969,t:1527019679128};\\\", \\\"{x:1354,y:970,t:1527019679145};\\\", \\\"{x:1354,y:972,t:1527019679163};\\\", \\\"{x:1355,y:973,t:1527019679178};\\\", \\\"{x:1355,y:974,t:1527019679227};\\\", \\\"{x:1354,y:974,t:1527019679300};\\\", \\\"{x:1353,y:972,t:1527019679312};\\\", \\\"{x:1350,y:964,t:1527019679330};\\\", \\\"{x:1349,y:956,t:1527019679346};\\\", \\\"{x:1346,y:948,t:1527019679362};\\\", \\\"{x:1344,y:938,t:1527019679379};\\\", \\\"{x:1343,y:928,t:1527019679395};\\\", \\\"{x:1343,y:911,t:1527019679412};\\\", \\\"{x:1340,y:902,t:1527019679429};\\\", \\\"{x:1340,y:894,t:1527019679445};\\\", \\\"{x:1339,y:888,t:1527019679462};\\\", \\\"{x:1339,y:883,t:1527019679479};\\\", \\\"{x:1337,y:880,t:1527019679496};\\\", \\\"{x:1337,y:875,t:1527019679512};\\\", \\\"{x:1337,y:870,t:1527019679529};\\\", \\\"{x:1337,y:863,t:1527019679545};\\\", \\\"{x:1337,y:858,t:1527019679562};\\\", \\\"{x:1337,y:855,t:1527019679579};\\\", \\\"{x:1337,y:848,t:1527019679596};\\\", \\\"{x:1337,y:847,t:1527019679612};\\\", \\\"{x:1337,y:845,t:1527019679629};\\\", \\\"{x:1337,y:841,t:1527019679645};\\\", \\\"{x:1337,y:839,t:1527019679662};\\\", \\\"{x:1337,y:835,t:1527019679679};\\\", \\\"{x:1337,y:832,t:1527019679696};\\\", \\\"{x:1338,y:828,t:1527019679712};\\\", \\\"{x:1338,y:826,t:1527019679729};\\\", \\\"{x:1338,y:825,t:1527019679746};\\\", \\\"{x:1338,y:823,t:1527019679763};\\\", \\\"{x:1338,y:819,t:1527019679779};\\\", \\\"{x:1338,y:815,t:1527019679796};\\\", \\\"{x:1338,y:811,t:1527019679813};\\\", \\\"{x:1338,y:805,t:1527019679828};\\\", \\\"{x:1338,y:802,t:1527019679846};\\\", \\\"{x:1338,y:799,t:1527019679861};\\\", \\\"{x:1338,y:792,t:1527019679879};\\\", \\\"{x:1338,y:781,t:1527019679895};\\\", \\\"{x:1338,y:770,t:1527019679912};\\\", \\\"{x:1338,y:763,t:1527019679928};\\\", \\\"{x:1338,y:754,t:1527019679946};\\\", \\\"{x:1339,y:743,t:1527019679962};\\\", \\\"{x:1341,y:723,t:1527019679979};\\\", \\\"{x:1342,y:711,t:1527019679996};\\\", \\\"{x:1342,y:701,t:1527019680013};\\\", \\\"{x:1343,y:686,t:1527019680029};\\\", \\\"{x:1343,y:668,t:1527019680046};\\\", \\\"{x:1343,y:649,t:1527019680063};\\\", \\\"{x:1343,y:639,t:1527019680079};\\\", \\\"{x:1343,y:633,t:1527019680096};\\\", \\\"{x:1343,y:626,t:1527019680113};\\\", \\\"{x:1343,y:616,t:1527019680129};\\\", \\\"{x:1343,y:611,t:1527019680146};\\\", \\\"{x:1345,y:596,t:1527019680163};\\\", \\\"{x:1345,y:586,t:1527019680179};\\\", \\\"{x:1346,y:579,t:1527019680195};\\\", \\\"{x:1347,y:572,t:1527019680213};\\\", \\\"{x:1348,y:566,t:1527019680229};\\\", \\\"{x:1348,y:559,t:1527019680245};\\\", \\\"{x:1349,y:550,t:1527019680263};\\\", \\\"{x:1350,y:538,t:1527019680280};\\\", \\\"{x:1351,y:526,t:1527019680296};\\\", \\\"{x:1351,y:513,t:1527019680312};\\\", \\\"{x:1351,y:506,t:1527019680330};\\\", \\\"{x:1351,y:497,t:1527019680345};\\\", \\\"{x:1351,y:480,t:1527019680363};\\\", \\\"{x:1351,y:474,t:1527019680379};\\\", \\\"{x:1351,y:468,t:1527019680396};\\\", \\\"{x:1351,y:463,t:1527019680413};\\\", \\\"{x:1351,y:456,t:1527019680430};\\\", \\\"{x:1351,y:448,t:1527019680446};\\\", \\\"{x:1351,y:442,t:1527019680463};\\\", \\\"{x:1351,y:432,t:1527019680480};\\\", \\\"{x:1351,y:427,t:1527019680496};\\\", \\\"{x:1351,y:424,t:1527019680513};\\\", \\\"{x:1351,y:420,t:1527019680531};\\\", \\\"{x:1350,y:419,t:1527019680788};\\\", \\\"{x:1348,y:420,t:1527019680844};\\\", \\\"{x:1348,y:421,t:1527019680860};\\\", \\\"{x:1347,y:421,t:1527019680868};\\\", \\\"{x:1346,y:422,t:1527019680948};\\\", \\\"{x:1346,y:424,t:1527019681564};\\\", \\\"{x:1346,y:431,t:1527019681581};\\\", \\\"{x:1346,y:441,t:1527019681598};\\\", \\\"{x:1348,y:449,t:1527019681614};\\\", \\\"{x:1349,y:456,t:1527019681631};\\\", \\\"{x:1350,y:467,t:1527019681648};\\\", \\\"{x:1354,y:481,t:1527019681665};\\\", \\\"{x:1355,y:496,t:1527019681682};\\\", \\\"{x:1359,y:513,t:1527019681698};\\\", \\\"{x:1361,y:522,t:1527019681714};\\\", \\\"{x:1362,y:530,t:1527019681731};\\\", \\\"{x:1363,y:534,t:1527019681748};\\\", \\\"{x:1364,y:540,t:1527019681764};\\\", \\\"{x:1364,y:544,t:1527019681782};\\\", \\\"{x:1366,y:547,t:1527019681798};\\\", \\\"{x:1366,y:550,t:1527019681815};\\\", \\\"{x:1366,y:553,t:1527019681830};\\\", \\\"{x:1367,y:556,t:1527019681848};\\\", \\\"{x:1368,y:561,t:1527019681864};\\\", \\\"{x:1368,y:566,t:1527019681880};\\\", \\\"{x:1370,y:574,t:1527019681897};\\\", \\\"{x:1370,y:587,t:1527019681914};\\\", \\\"{x:1370,y:598,t:1527019681931};\\\", \\\"{x:1371,y:613,t:1527019681948};\\\", \\\"{x:1371,y:627,t:1527019681965};\\\", \\\"{x:1371,y:643,t:1527019681980};\\\", \\\"{x:1371,y:664,t:1527019681997};\\\", \\\"{x:1371,y:680,t:1527019682014};\\\", \\\"{x:1371,y:694,t:1527019682031};\\\", \\\"{x:1372,y:704,t:1527019682048};\\\", \\\"{x:1373,y:715,t:1527019682065};\\\", \\\"{x:1375,y:725,t:1527019682081};\\\", \\\"{x:1375,y:732,t:1527019682098};\\\", \\\"{x:1375,y:745,t:1527019682115};\\\", \\\"{x:1375,y:752,t:1527019682130};\\\", \\\"{x:1375,y:755,t:1527019682148};\\\", \\\"{x:1375,y:758,t:1527019682165};\\\", \\\"{x:1375,y:761,t:1527019682181};\\\", \\\"{x:1375,y:764,t:1527019682198};\\\", \\\"{x:1375,y:768,t:1527019682215};\\\", \\\"{x:1375,y:772,t:1527019682232};\\\", \\\"{x:1375,y:776,t:1527019682248};\\\", \\\"{x:1375,y:781,t:1527019682265};\\\", \\\"{x:1375,y:785,t:1527019682282};\\\", \\\"{x:1375,y:789,t:1527019682298};\\\", \\\"{x:1375,y:793,t:1527019682315};\\\", \\\"{x:1374,y:796,t:1527019682331};\\\", \\\"{x:1373,y:803,t:1527019682348};\\\", \\\"{x:1370,y:812,t:1527019682365};\\\", \\\"{x:1366,y:821,t:1527019682383};\\\", \\\"{x:1363,y:826,t:1527019682398};\\\", \\\"{x:1361,y:830,t:1527019682415};\\\", \\\"{x:1360,y:833,t:1527019682432};\\\", \\\"{x:1359,y:836,t:1527019682448};\\\", \\\"{x:1357,y:842,t:1527019682466};\\\", \\\"{x:1353,y:848,t:1527019682482};\\\", \\\"{x:1349,y:855,t:1527019682498};\\\", \\\"{x:1341,y:873,t:1527019682515};\\\", \\\"{x:1337,y:881,t:1527019682532};\\\", \\\"{x:1332,y:890,t:1527019682549};\\\", \\\"{x:1326,y:903,t:1527019682565};\\\", \\\"{x:1320,y:911,t:1527019682582};\\\", \\\"{x:1316,y:914,t:1527019682599};\\\", \\\"{x:1314,y:915,t:1527019682615};\\\", \\\"{x:1282,y:900,t:1527019682633};\\\", \\\"{x:1164,y:831,t:1527019682649};\\\", \\\"{x:981,y:732,t:1527019682665};\\\", \\\"{x:746,y:621,t:1527019682683};\\\", \\\"{x:423,y:532,t:1527019682700};\\\", \\\"{x:321,y:521,t:1527019682715};\\\", \\\"{x:287,y:521,t:1527019682731};\\\", \\\"{x:273,y:521,t:1527019682755};\\\", \\\"{x:272,y:521,t:1527019682788};\\\", \\\"{x:271,y:527,t:1527019682805};\\\", \\\"{x:271,y:540,t:1527019682822};\\\", \\\"{x:269,y:544,t:1527019682839};\\\", \\\"{x:268,y:547,t:1527019682855};\\\", \\\"{x:267,y:552,t:1527019682872};\\\", \\\"{x:267,y:554,t:1527019682888};\\\", \\\"{x:267,y:555,t:1527019682963};\\\", \\\"{x:269,y:556,t:1527019682987};\\\", \\\"{x:272,y:556,t:1527019683003};\\\", \\\"{x:276,y:555,t:1527019683013};\\\", \\\"{x:282,y:551,t:1527019683022};\\\", \\\"{x:299,y:541,t:1527019683039};\\\", \\\"{x:315,y:529,t:1527019683056};\\\", \\\"{x:332,y:520,t:1527019683072};\\\", \\\"{x:338,y:515,t:1527019683089};\\\", \\\"{x:339,y:515,t:1527019683203};\\\", \\\"{x:340,y:515,t:1527019683226};\\\", \\\"{x:342,y:520,t:1527019683239};\\\", \\\"{x:344,y:524,t:1527019683256};\\\", \\\"{x:344,y:525,t:1527019683273};\\\", \\\"{x:346,y:527,t:1527019683289};\\\", \\\"{x:353,y:527,t:1527019683307};\\\", \\\"{x:367,y:527,t:1527019683323};\\\", \\\"{x:378,y:521,t:1527019683339};\\\", \\\"{x:386,y:516,t:1527019683356};\\\", \\\"{x:390,y:516,t:1527019683373};\\\", \\\"{x:392,y:516,t:1527019683698};\\\", \\\"{x:406,y:546,t:1527019683707};\\\", \\\"{x:439,y:631,t:1527019683723};\\\", \\\"{x:462,y:699,t:1527019683740};\\\", \\\"{x:478,y:723,t:1527019683757};\\\", \\\"{x:488,y:731,t:1527019683773};\\\", \\\"{x:494,y:733,t:1527019683790};\\\", \\\"{x:495,y:733,t:1527019683988};\\\", \\\"{x:496,y:733,t:1527019684003};\\\", \\\"{x:498,y:733,t:1527019684012};\\\", \\\"{x:500,y:732,t:1527019684023};\\\", \\\"{x:510,y:720,t:1527019684040};\\\", \\\"{x:530,y:690,t:1527019684057};\\\", \\\"{x:558,y:653,t:1527019684074};\\\", \\\"{x:583,y:623,t:1527019684091};\\\", \\\"{x:607,y:600,t:1527019684107};\\\", \\\"{x:608,y:596,t:1527019684122};\\\", \\\"{x:610,y:594,t:1527019684140};\\\", \\\"{x:611,y:591,t:1527019684157};\\\", \\\"{x:615,y:583,t:1527019684174};\\\", \\\"{x:619,y:573,t:1527019684191};\\\", \\\"{x:620,y:565,t:1527019684208};\\\", \\\"{x:623,y:559,t:1527019684224};\\\", \\\"{x:624,y:555,t:1527019684240};\\\", \\\"{x:624,y:553,t:1527019684257};\\\", \\\"{x:624,y:550,t:1527019684272};\\\", \\\"{x:624,y:549,t:1527019684290};\\\", \\\"{x:623,y:544,t:1527019684307};\\\", \\\"{x:620,y:538,t:1527019684324};\\\", \\\"{x:619,y:537,t:1527019684340};\\\", \\\"{x:618,y:536,t:1527019684396};\\\", \\\"{x:618,y:535,t:1527019684411};\\\", \\\"{x:617,y:535,t:1527019684426};\\\", \\\"{x:616,y:534,t:1527019684440};\\\", \\\"{x:616,y:528,t:1527019684457};\\\", \\\"{x:615,y:526,t:1527019684474};\\\", \\\"{x:615,y:525,t:1527019684489};\\\", \\\"{x:613,y:525,t:1527019684699};\\\", \\\"{x:601,y:535,t:1527019684706};\\\", \\\"{x:564,y:605,t:1527019684724};\\\", \\\"{x:524,y:699,t:1527019684741};\\\", \\\"{x:497,y:743,t:1527019684756};\\\", \\\"{x:485,y:756,t:1527019684773};\\\", \\\"{x:485,y:757,t:1527019684791};\\\", \\\"{x:485,y:748,t:1527019685004};\\\", \\\"{x:489,y:738,t:1527019685011};\\\", \\\"{x:494,y:726,t:1527019685025};\\\", \\\"{x:503,y:710,t:1527019685040};\\\", \\\"{x:504,y:705,t:1527019685058};\\\", \\\"{x:504,y:704,t:1527019685074};\\\", \\\"{x:504,y:705,t:1527019685339};\\\", \\\"{x:504,y:707,t:1527019685355};\\\", \\\"{x:504,y:708,t:1527019685371};\\\", \\\"{x:504,y:710,t:1527019685404};\\\", \\\"{x:503,y:712,t:1527019685419};\\\", \\\"{x:503,y:715,t:1527019685440};\\\", \\\"{x:503,y:717,t:1527019685458};\\\", \\\"{x:503,y:717,t:1527019685531};\\\", \\\"{x:503,y:714,t:1527019685980};\\\", \\\"{x:504,y:710,t:1527019685992};\\\", \\\"{x:509,y:702,t:1527019686008};\\\", \\\"{x:513,y:693,t:1527019686025};\\\", \\\"{x:517,y:688,t:1527019686042};\\\", \\\"{x:520,y:684,t:1527019686058};\\\", \\\"{x:525,y:680,t:1527019686075};\\\", \\\"{x:529,y:677,t:1527019686091};\\\", \\\"{x:539,y:670,t:1527019686108};\\\", \\\"{x:552,y:659,t:1527019686125};\\\", \\\"{x:567,y:643,t:1527019686142};\\\", \\\"{x:581,y:629,t:1527019686158};\\\", \\\"{x:595,y:615,t:1527019686175};\\\", \\\"{x:613,y:598,t:1527019686193};\\\", \\\"{x:632,y:579,t:1527019686209};\\\", \\\"{x:653,y:556,t:1527019686225};\\\", \\\"{x:673,y:530,t:1527019686242};\\\", \\\"{x:692,y:510,t:1527019686258};\\\", \\\"{x:711,y:487,t:1527019686275};\\\", \\\"{x:728,y:469,t:1527019686292};\\\", \\\"{x:737,y:460,t:1527019686308};\\\", \\\"{x:742,y:453,t:1527019686325};\\\", \\\"{x:744,y:450,t:1527019686342};\\\", \\\"{x:746,y:448,t:1527019686358};\\\", \\\"{x:746,y:447,t:1527019686375};\\\" ] }, { \\\"rt\\\": 56048, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 366769, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-05 PM-04 PM-04 PM-J -H -Z -Z -01 PM-04 PM-5-10 AM-11 AM-C -O -11 AM-I -A -F -F -F -F -F -Z -Z -Z -Z -F -F -O -O -10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:749,y:449,t:1527019687724};\\\", \\\"{x:757,y:519,t:1527019687743};\\\", \\\"{x:772,y:603,t:1527019687760};\\\", \\\"{x:772,y:703,t:1527019687776};\\\", \\\"{x:778,y:821,t:1527019687793};\\\", \\\"{x:798,y:935,t:1527019687810};\\\", \\\"{x:798,y:947,t:1527019687826};\\\", \\\"{x:798,y:949,t:1527019688236};\\\", \\\"{x:800,y:951,t:1527019688243};\\\", \\\"{x:812,y:953,t:1527019688261};\\\", \\\"{x:827,y:953,t:1527019688277};\\\", \\\"{x:846,y:953,t:1527019688293};\\\", \\\"{x:872,y:953,t:1527019688310};\\\", \\\"{x:903,y:953,t:1527019688327};\\\", \\\"{x:945,y:953,t:1527019688344};\\\", \\\"{x:998,y:953,t:1527019688361};\\\", \\\"{x:1062,y:953,t:1527019688378};\\\", \\\"{x:1146,y:953,t:1527019688393};\\\", \\\"{x:1241,y:957,t:1527019688411};\\\", \\\"{x:1365,y:976,t:1527019688428};\\\", \\\"{x:1424,y:984,t:1527019688445};\\\", \\\"{x:1485,y:993,t:1527019688461};\\\", \\\"{x:1519,y:998,t:1527019688477};\\\", \\\"{x:1544,y:1000,t:1527019688494};\\\", \\\"{x:1568,y:1000,t:1527019688511};\\\", \\\"{x:1587,y:1000,t:1527019688527};\\\", \\\"{x:1604,y:1000,t:1527019688543};\\\", \\\"{x:1620,y:1000,t:1527019688560};\\\", \\\"{x:1643,y:1000,t:1527019688577};\\\", \\\"{x:1665,y:1000,t:1527019688594};\\\", \\\"{x:1691,y:1000,t:1527019688611};\\\", \\\"{x:1722,y:1000,t:1527019688628};\\\", \\\"{x:1732,y:1000,t:1527019688644};\\\", \\\"{x:1740,y:1000,t:1527019688660};\\\", \\\"{x:1742,y:999,t:1527019688678};\\\", \\\"{x:1743,y:999,t:1527019688694};\\\", \\\"{x:1743,y:998,t:1527019688803};\\\", \\\"{x:1742,y:997,t:1527019688811};\\\", \\\"{x:1729,y:992,t:1527019688828};\\\", \\\"{x:1705,y:987,t:1527019688844};\\\", \\\"{x:1678,y:984,t:1527019688860};\\\", \\\"{x:1644,y:984,t:1527019688878};\\\", \\\"{x:1621,y:984,t:1527019688895};\\\", \\\"{x:1615,y:984,t:1527019688912};\\\", \\\"{x:1613,y:984,t:1527019688928};\\\", \\\"{x:1614,y:984,t:1527019689020};\\\", \\\"{x:1619,y:987,t:1527019689028};\\\", \\\"{x:1625,y:988,t:1527019689044};\\\", \\\"{x:1627,y:988,t:1527019689062};\\\", \\\"{x:1629,y:988,t:1527019689078};\\\", \\\"{x:1630,y:988,t:1527019689095};\\\", \\\"{x:1632,y:988,t:1527019689115};\\\", \\\"{x:1631,y:985,t:1527019689212};\\\", \\\"{x:1619,y:978,t:1527019689228};\\\", \\\"{x:1615,y:976,t:1527019689245};\\\", \\\"{x:1615,y:975,t:1527019689372};\\\", \\\"{x:1615,y:974,t:1527019689379};\\\", \\\"{x:1615,y:973,t:1527019689394};\\\", \\\"{x:1615,y:972,t:1527019689411};\\\", \\\"{x:1615,y:954,t:1527019694060};\\\", \\\"{x:1603,y:915,t:1527019694068};\\\", \\\"{x:1592,y:881,t:1527019694082};\\\", \\\"{x:1559,y:809,t:1527019694099};\\\", \\\"{x:1528,y:737,t:1527019694115};\\\", \\\"{x:1489,y:674,t:1527019694132};\\\", \\\"{x:1465,y:626,t:1527019694148};\\\", \\\"{x:1441,y:578,t:1527019694165};\\\", \\\"{x:1421,y:528,t:1527019694182};\\\", \\\"{x:1412,y:499,t:1527019694198};\\\", \\\"{x:1407,y:484,t:1527019694215};\\\", \\\"{x:1401,y:468,t:1527019694232};\\\", \\\"{x:1397,y:454,t:1527019694249};\\\", \\\"{x:1396,y:448,t:1527019694266};\\\", \\\"{x:1396,y:445,t:1527019694282};\\\", \\\"{x:1396,y:444,t:1527019694299};\\\", \\\"{x:1397,y:441,t:1527019694315};\\\", \\\"{x:1397,y:440,t:1527019694331};\\\", \\\"{x:1398,y:437,t:1527019694349};\\\", \\\"{x:1401,y:434,t:1527019694366};\\\", \\\"{x:1403,y:432,t:1527019694382};\\\", \\\"{x:1407,y:432,t:1527019694399};\\\", \\\"{x:1409,y:430,t:1527019694418};\\\", \\\"{x:1411,y:430,t:1527019694431};\\\", \\\"{x:1411,y:429,t:1527019694467};\\\", \\\"{x:1412,y:429,t:1527019695948};\\\", \\\"{x:1412,y:432,t:1527019695967};\\\", \\\"{x:1412,y:436,t:1527019695984};\\\", \\\"{x:1414,y:440,t:1527019696000};\\\", \\\"{x:1415,y:444,t:1527019696017};\\\", \\\"{x:1415,y:446,t:1527019696034};\\\", \\\"{x:1415,y:448,t:1527019696050};\\\", \\\"{x:1415,y:449,t:1527019696067};\\\", \\\"{x:1415,y:451,t:1527019696083};\\\", \\\"{x:1415,y:453,t:1527019696100};\\\", \\\"{x:1416,y:455,t:1527019696117};\\\", \\\"{x:1416,y:457,t:1527019696134};\\\", \\\"{x:1418,y:459,t:1527019696150};\\\", \\\"{x:1418,y:462,t:1527019696167};\\\", \\\"{x:1418,y:468,t:1527019696184};\\\", \\\"{x:1418,y:473,t:1527019696200};\\\", \\\"{x:1418,y:481,t:1527019696217};\\\", \\\"{x:1418,y:490,t:1527019696233};\\\", \\\"{x:1418,y:499,t:1527019696250};\\\", \\\"{x:1419,y:511,t:1527019696267};\\\", \\\"{x:1419,y:529,t:1527019696284};\\\", \\\"{x:1419,y:540,t:1527019696300};\\\", \\\"{x:1419,y:551,t:1527019696317};\\\", \\\"{x:1419,y:563,t:1527019696334};\\\", \\\"{x:1419,y:573,t:1527019696351};\\\", \\\"{x:1419,y:583,t:1527019696368};\\\", \\\"{x:1419,y:590,t:1527019696384};\\\", \\\"{x:1419,y:597,t:1527019696400};\\\", \\\"{x:1419,y:600,t:1527019696417};\\\", \\\"{x:1420,y:603,t:1527019696434};\\\", \\\"{x:1420,y:606,t:1527019696449};\\\", \\\"{x:1420,y:609,t:1527019696466};\\\", \\\"{x:1420,y:611,t:1527019696483};\\\", \\\"{x:1420,y:613,t:1527019696501};\\\", \\\"{x:1420,y:614,t:1527019696522};\\\", \\\"{x:1420,y:615,t:1527019696533};\\\", \\\"{x:1420,y:618,t:1527019696550};\\\", \\\"{x:1420,y:622,t:1527019696567};\\\", \\\"{x:1420,y:625,t:1527019696583};\\\", \\\"{x:1420,y:629,t:1527019696600};\\\", \\\"{x:1420,y:631,t:1527019696616};\\\", \\\"{x:1419,y:635,t:1527019696633};\\\", \\\"{x:1418,y:641,t:1527019696651};\\\", \\\"{x:1418,y:644,t:1527019696667};\\\", \\\"{x:1417,y:651,t:1527019696684};\\\", \\\"{x:1416,y:659,t:1527019696701};\\\", \\\"{x:1415,y:666,t:1527019696717};\\\", \\\"{x:1414,y:670,t:1527019696734};\\\", \\\"{x:1414,y:672,t:1527019696750};\\\", \\\"{x:1413,y:676,t:1527019696767};\\\", \\\"{x:1413,y:678,t:1527019696784};\\\", \\\"{x:1413,y:682,t:1527019696801};\\\", \\\"{x:1412,y:684,t:1527019696817};\\\", \\\"{x:1412,y:688,t:1527019696834};\\\", \\\"{x:1412,y:691,t:1527019696851};\\\", \\\"{x:1412,y:695,t:1527019696868};\\\", \\\"{x:1412,y:698,t:1527019696884};\\\", \\\"{x:1412,y:700,t:1527019696908};\\\", \\\"{x:1412,y:701,t:1527019696923};\\\", \\\"{x:1412,y:702,t:1527019696940};\\\", \\\"{x:1412,y:703,t:1527019696955};\\\", \\\"{x:1412,y:704,t:1527019696968};\\\", \\\"{x:1412,y:706,t:1527019696984};\\\", \\\"{x:1412,y:707,t:1527019697001};\\\", \\\"{x:1412,y:710,t:1527019697018};\\\", \\\"{x:1412,y:713,t:1527019697033};\\\", \\\"{x:1412,y:716,t:1527019697051};\\\", \\\"{x:1412,y:720,t:1527019697068};\\\", \\\"{x:1412,y:723,t:1527019697084};\\\", \\\"{x:1412,y:725,t:1527019697101};\\\", \\\"{x:1412,y:730,t:1527019697118};\\\", \\\"{x:1412,y:733,t:1527019697134};\\\", \\\"{x:1412,y:739,t:1527019697151};\\\", \\\"{x:1412,y:748,t:1527019697168};\\\", \\\"{x:1412,y:759,t:1527019697184};\\\", \\\"{x:1412,y:772,t:1527019697201};\\\", \\\"{x:1412,y:789,t:1527019697218};\\\", \\\"{x:1414,y:795,t:1527019697234};\\\", \\\"{x:1414,y:798,t:1527019697251};\\\", \\\"{x:1414,y:800,t:1527019697267};\\\", \\\"{x:1414,y:801,t:1527019697308};\\\", \\\"{x:1414,y:802,t:1527019697332};\\\", \\\"{x:1414,y:803,t:1527019697356};\\\", \\\"{x:1413,y:805,t:1527019697396};\\\", \\\"{x:1413,y:806,t:1527019697404};\\\", \\\"{x:1413,y:810,t:1527019697418};\\\", \\\"{x:1411,y:815,t:1527019697435};\\\", \\\"{x:1411,y:819,t:1527019697451};\\\", \\\"{x:1410,y:822,t:1527019697468};\\\", \\\"{x:1410,y:825,t:1527019697486};\\\", \\\"{x:1410,y:826,t:1527019697501};\\\", \\\"{x:1410,y:827,t:1527019697518};\\\", \\\"{x:1410,y:828,t:1527019697540};\\\", \\\"{x:1410,y:829,t:1527019697556};\\\", \\\"{x:1410,y:830,t:1527019697568};\\\", \\\"{x:1410,y:834,t:1527019697585};\\\", \\\"{x:1410,y:835,t:1527019697601};\\\", \\\"{x:1410,y:837,t:1527019697618};\\\", \\\"{x:1410,y:839,t:1527019697635};\\\", \\\"{x:1410,y:843,t:1527019697652};\\\", \\\"{x:1410,y:845,t:1527019697668};\\\", \\\"{x:1410,y:847,t:1527019697685};\\\", \\\"{x:1410,y:852,t:1527019697701};\\\", \\\"{x:1410,y:858,t:1527019697718};\\\", \\\"{x:1410,y:863,t:1527019697735};\\\", \\\"{x:1411,y:865,t:1527019697751};\\\", \\\"{x:1412,y:868,t:1527019697768};\\\", \\\"{x:1412,y:869,t:1527019697785};\\\", \\\"{x:1412,y:870,t:1527019697802};\\\", \\\"{x:1412,y:872,t:1527019697818};\\\", \\\"{x:1412,y:876,t:1527019697835};\\\", \\\"{x:1412,y:886,t:1527019697852};\\\", \\\"{x:1412,y:891,t:1527019697868};\\\", \\\"{x:1411,y:894,t:1527019697886};\\\", \\\"{x:1411,y:897,t:1527019697901};\\\", \\\"{x:1411,y:898,t:1527019697924};\\\", \\\"{x:1411,y:899,t:1527019697948};\\\", \\\"{x:1411,y:900,t:1527019697955};\\\", \\\"{x:1411,y:901,t:1527019698131};\\\", \\\"{x:1411,y:903,t:1527019698140};\\\", \\\"{x:1411,y:908,t:1527019698152};\\\", \\\"{x:1412,y:922,t:1527019698168};\\\", \\\"{x:1416,y:948,t:1527019698185};\\\", \\\"{x:1422,y:971,t:1527019698202};\\\", \\\"{x:1427,y:992,t:1527019698220};\\\", \\\"{x:1428,y:994,t:1527019698236};\\\", \\\"{x:1429,y:995,t:1527019701004};\\\", \\\"{x:1446,y:995,t:1527019701021};\\\", \\\"{x:1474,y:995,t:1527019701037};\\\", \\\"{x:1498,y:995,t:1527019701054};\\\", \\\"{x:1525,y:995,t:1527019701071};\\\", \\\"{x:1546,y:995,t:1527019701087};\\\", \\\"{x:1560,y:995,t:1527019701104};\\\", \\\"{x:1565,y:995,t:1527019701121};\\\", \\\"{x:1566,y:995,t:1527019701300};\\\", \\\"{x:1567,y:994,t:1527019701307};\\\", \\\"{x:1570,y:992,t:1527019701321};\\\", \\\"{x:1583,y:985,t:1527019701338};\\\", \\\"{x:1592,y:979,t:1527019701354};\\\", \\\"{x:1601,y:974,t:1527019701372};\\\", \\\"{x:1602,y:974,t:1527019701388};\\\", \\\"{x:1604,y:972,t:1527019701404};\\\", \\\"{x:1604,y:971,t:1527019701636};\\\", \\\"{x:1603,y:969,t:1527019701651};\\\", \\\"{x:1602,y:968,t:1527019701667};\\\", \\\"{x:1599,y:968,t:1527019701676};\\\", \\\"{x:1596,y:968,t:1527019701688};\\\", \\\"{x:1587,y:968,t:1527019701704};\\\", \\\"{x:1572,y:968,t:1527019701721};\\\", \\\"{x:1547,y:966,t:1527019701738};\\\", \\\"{x:1512,y:961,t:1527019701754};\\\", \\\"{x:1452,y:948,t:1527019701771};\\\", \\\"{x:1418,y:940,t:1527019701788};\\\", \\\"{x:1360,y:914,t:1527019701805};\\\", \\\"{x:1291,y:883,t:1527019701821};\\\", \\\"{x:1229,y:836,t:1527019701839};\\\", \\\"{x:1168,y:798,t:1527019701855};\\\", \\\"{x:1123,y:746,t:1527019701872};\\\", \\\"{x:1085,y:695,t:1527019701888};\\\", \\\"{x:1061,y:652,t:1527019701905};\\\", \\\"{x:1053,y:628,t:1527019701922};\\\", \\\"{x:1048,y:614,t:1527019701938};\\\", \\\"{x:1048,y:605,t:1527019701955};\\\", \\\"{x:1048,y:601,t:1527019701971};\\\", \\\"{x:1049,y:597,t:1527019701988};\\\", \\\"{x:1050,y:597,t:1527019702011};\\\", \\\"{x:1052,y:596,t:1527019702027};\\\", \\\"{x:1053,y:596,t:1527019702043};\\\", \\\"{x:1055,y:596,t:1527019702075};\\\", \\\"{x:1056,y:600,t:1527019702087};\\\", \\\"{x:1062,y:628,t:1527019702105};\\\", \\\"{x:1067,y:665,t:1527019702121};\\\", \\\"{x:1070,y:692,t:1527019702138};\\\", \\\"{x:1072,y:713,t:1527019702154};\\\", \\\"{x:1073,y:717,t:1527019702171};\\\", \\\"{x:1073,y:718,t:1527019702188};\\\", \\\"{x:1073,y:715,t:1527019702380};\\\", \\\"{x:1073,y:710,t:1527019702388};\\\", \\\"{x:1073,y:704,t:1527019702405};\\\", \\\"{x:1073,y:701,t:1527019702422};\\\", \\\"{x:1073,y:700,t:1527019702438};\\\", \\\"{x:1073,y:698,t:1527019702455};\\\", \\\"{x:1073,y:706,t:1527019703324};\\\", \\\"{x:1083,y:754,t:1527019703340};\\\", \\\"{x:1110,y:810,t:1527019703356};\\\", \\\"{x:1144,y:874,t:1527019703372};\\\", \\\"{x:1179,y:930,t:1527019703389};\\\", \\\"{x:1210,y:970,t:1527019703407};\\\", \\\"{x:1231,y:995,t:1527019703423};\\\", \\\"{x:1251,y:1015,t:1527019703439};\\\", \\\"{x:1262,y:1025,t:1527019703456};\\\", \\\"{x:1266,y:1029,t:1527019703472};\\\", \\\"{x:1267,y:1028,t:1527019703579};\\\", \\\"{x:1270,y:1022,t:1527019703589};\\\", \\\"{x:1273,y:1006,t:1527019703605};\\\", \\\"{x:1279,y:980,t:1527019703623};\\\", \\\"{x:1282,y:954,t:1527019703639};\\\", \\\"{x:1282,y:932,t:1527019703656};\\\", \\\"{x:1279,y:914,t:1527019703672};\\\", \\\"{x:1274,y:900,t:1527019703689};\\\", \\\"{x:1270,y:893,t:1527019703706};\\\", \\\"{x:1269,y:891,t:1527019703723};\\\", \\\"{x:1268,y:891,t:1527019703748};\\\", \\\"{x:1268,y:890,t:1527019703772};\\\", \\\"{x:1268,y:889,t:1527019703788};\\\", \\\"{x:1268,y:888,t:1527019703803};\\\", \\\"{x:1268,y:887,t:1527019703811};\\\", \\\"{x:1267,y:885,t:1527019703824};\\\", \\\"{x:1263,y:882,t:1527019703840};\\\", \\\"{x:1258,y:878,t:1527019703856};\\\", \\\"{x:1255,y:871,t:1527019703873};\\\", \\\"{x:1248,y:864,t:1527019703889};\\\", \\\"{x:1240,y:855,t:1527019703906};\\\", \\\"{x:1225,y:846,t:1527019703923};\\\", \\\"{x:1218,y:843,t:1527019703939};\\\", \\\"{x:1208,y:840,t:1527019703957};\\\", \\\"{x:1197,y:838,t:1527019703973};\\\", \\\"{x:1188,y:837,t:1527019703990};\\\", \\\"{x:1187,y:836,t:1527019704100};\\\", \\\"{x:1187,y:835,t:1527019704107};\\\", \\\"{x:1195,y:833,t:1527019704123};\\\", \\\"{x:1204,y:829,t:1527019704140};\\\", \\\"{x:1210,y:828,t:1527019704156};\\\", \\\"{x:1214,y:828,t:1527019704173};\\\", \\\"{x:1216,y:827,t:1527019704190};\\\", \\\"{x:1217,y:826,t:1527019704206};\\\", \\\"{x:1216,y:826,t:1527019704595};\\\", \\\"{x:1214,y:827,t:1527019704611};\\\", \\\"{x:1213,y:828,t:1527019704623};\\\", \\\"{x:1212,y:829,t:1527019704640};\\\", \\\"{x:1212,y:830,t:1527019704683};\\\", \\\"{x:1212,y:832,t:1527019705108};\\\", \\\"{x:1215,y:834,t:1527019705124};\\\", \\\"{x:1217,y:835,t:1527019705140};\\\", \\\"{x:1218,y:836,t:1527019705158};\\\", \\\"{x:1219,y:836,t:1527019705196};\\\", \\\"{x:1220,y:836,t:1527019705208};\\\", \\\"{x:1223,y:835,t:1527019705225};\\\", \\\"{x:1233,y:825,t:1527019705240};\\\", \\\"{x:1247,y:815,t:1527019705257};\\\", \\\"{x:1261,y:806,t:1527019705274};\\\", \\\"{x:1281,y:790,t:1527019705291};\\\", \\\"{x:1293,y:782,t:1527019705307};\\\", \\\"{x:1305,y:775,t:1527019705325};\\\", \\\"{x:1315,y:769,t:1527019705341};\\\", \\\"{x:1322,y:765,t:1527019705358};\\\", \\\"{x:1324,y:764,t:1527019705374};\\\", \\\"{x:1327,y:761,t:1527019705392};\\\", \\\"{x:1328,y:760,t:1527019705408};\\\", \\\"{x:1328,y:759,t:1527019705424};\\\", \\\"{x:1328,y:758,t:1527019705442};\\\", \\\"{x:1328,y:753,t:1527019705457};\\\", \\\"{x:1326,y:744,t:1527019705474};\\\", \\\"{x:1312,y:728,t:1527019705491};\\\", \\\"{x:1304,y:718,t:1527019705507};\\\", \\\"{x:1292,y:703,t:1527019705524};\\\", \\\"{x:1281,y:689,t:1527019705541};\\\", \\\"{x:1275,y:680,t:1527019705558};\\\", \\\"{x:1272,y:670,t:1527019705574};\\\", \\\"{x:1270,y:665,t:1527019705591};\\\", \\\"{x:1267,y:659,t:1527019705608};\\\", \\\"{x:1262,y:651,t:1527019705625};\\\", \\\"{x:1261,y:646,t:1527019705642};\\\", \\\"{x:1258,y:642,t:1527019705657};\\\", \\\"{x:1250,y:639,t:1527019705674};\\\", \\\"{x:1242,y:635,t:1527019705691};\\\", \\\"{x:1241,y:635,t:1527019705908};\\\", \\\"{x:1241,y:634,t:1527019705964};\\\", \\\"{x:1241,y:633,t:1527019705975};\\\", \\\"{x:1242,y:632,t:1527019705992};\\\", \\\"{x:1243,y:632,t:1527019706008};\\\", \\\"{x:1245,y:632,t:1527019706995};\\\", \\\"{x:1247,y:641,t:1527019707010};\\\", \\\"{x:1250,y:657,t:1527019707025};\\\", \\\"{x:1252,y:677,t:1527019707042};\\\", \\\"{x:1256,y:692,t:1527019707059};\\\", \\\"{x:1258,y:707,t:1527019707075};\\\", \\\"{x:1261,y:716,t:1527019707093};\\\", \\\"{x:1262,y:723,t:1527019707110};\\\", \\\"{x:1265,y:735,t:1527019707126};\\\", \\\"{x:1266,y:749,t:1527019707142};\\\", \\\"{x:1268,y:763,t:1527019707159};\\\", \\\"{x:1271,y:776,t:1527019707176};\\\", \\\"{x:1271,y:788,t:1527019707192};\\\", \\\"{x:1271,y:803,t:1527019707209};\\\", \\\"{x:1271,y:818,t:1527019707226};\\\", \\\"{x:1271,y:833,t:1527019707242};\\\", \\\"{x:1269,y:855,t:1527019707259};\\\", \\\"{x:1269,y:874,t:1527019707276};\\\", \\\"{x:1269,y:889,t:1527019707292};\\\", \\\"{x:1268,y:901,t:1527019707309};\\\", \\\"{x:1268,y:915,t:1527019707326};\\\", \\\"{x:1266,y:925,t:1527019707343};\\\", \\\"{x:1266,y:934,t:1527019707360};\\\", \\\"{x:1265,y:942,t:1527019707375};\\\", \\\"{x:1265,y:949,t:1527019707392};\\\", \\\"{x:1264,y:953,t:1527019707409};\\\", \\\"{x:1264,y:955,t:1527019707425};\\\", \\\"{x:1264,y:958,t:1527019707442};\\\", \\\"{x:1264,y:960,t:1527019707458};\\\", \\\"{x:1262,y:962,t:1527019707475};\\\", \\\"{x:1262,y:964,t:1527019707492};\\\", \\\"{x:1262,y:966,t:1527019707509};\\\", \\\"{x:1262,y:967,t:1527019707531};\\\", \\\"{x:1261,y:969,t:1527019707555};\\\", \\\"{x:1261,y:970,t:1527019707571};\\\", \\\"{x:1260,y:971,t:1527019707579};\\\", \\\"{x:1259,y:972,t:1527019707592};\\\", \\\"{x:1258,y:975,t:1527019707609};\\\", \\\"{x:1253,y:981,t:1527019707626};\\\", \\\"{x:1243,y:986,t:1527019707642};\\\", \\\"{x:1240,y:989,t:1527019707659};\\\", \\\"{x:1239,y:985,t:1527019707796};\\\", \\\"{x:1239,y:978,t:1527019707810};\\\", \\\"{x:1239,y:970,t:1527019707827};\\\", \\\"{x:1241,y:966,t:1527019707842};\\\", \\\"{x:1242,y:963,t:1527019707860};\\\", \\\"{x:1242,y:962,t:1527019707876};\\\", \\\"{x:1242,y:961,t:1527019707892};\\\", \\\"{x:1244,y:961,t:1527019708140};\\\", \\\"{x:1249,y:961,t:1527019708148};\\\", \\\"{x:1256,y:964,t:1527019708160};\\\", \\\"{x:1266,y:970,t:1527019708176};\\\", \\\"{x:1269,y:974,t:1527019708193};\\\", \\\"{x:1273,y:976,t:1527019708210};\\\", \\\"{x:1274,y:976,t:1527019708227};\\\", \\\"{x:1274,y:977,t:1527019708275};\\\", \\\"{x:1274,y:972,t:1527019711372};\\\", \\\"{x:1274,y:953,t:1527019711379};\\\", \\\"{x:1274,y:917,t:1527019711395};\\\", \\\"{x:1274,y:883,t:1527019711413};\\\", \\\"{x:1269,y:837,t:1527019711429};\\\", \\\"{x:1266,y:793,t:1527019711446};\\\", \\\"{x:1259,y:748,t:1527019711462};\\\", \\\"{x:1249,y:704,t:1527019711478};\\\", \\\"{x:1246,y:683,t:1527019711496};\\\", \\\"{x:1240,y:668,t:1527019711513};\\\", \\\"{x:1237,y:657,t:1527019711528};\\\", \\\"{x:1236,y:652,t:1527019711546};\\\", \\\"{x:1236,y:647,t:1527019711563};\\\", \\\"{x:1236,y:640,t:1527019711580};\\\", \\\"{x:1236,y:634,t:1527019711595};\\\", \\\"{x:1236,y:628,t:1527019711612};\\\", \\\"{x:1236,y:620,t:1527019711629};\\\", \\\"{x:1236,y:612,t:1527019711646};\\\", \\\"{x:1239,y:603,t:1527019711663};\\\", \\\"{x:1243,y:595,t:1527019711679};\\\", \\\"{x:1245,y:586,t:1527019711695};\\\", \\\"{x:1247,y:580,t:1527019711713};\\\", \\\"{x:1248,y:576,t:1527019711730};\\\", \\\"{x:1251,y:571,t:1527019711745};\\\", \\\"{x:1254,y:566,t:1527019711763};\\\", \\\"{x:1255,y:563,t:1527019711779};\\\", \\\"{x:1258,y:560,t:1527019711796};\\\", \\\"{x:1262,y:556,t:1527019711812};\\\", \\\"{x:1266,y:552,t:1527019711829};\\\", \\\"{x:1270,y:548,t:1527019711846};\\\", \\\"{x:1276,y:545,t:1527019711862};\\\", \\\"{x:1286,y:537,t:1527019711879};\\\", \\\"{x:1298,y:528,t:1527019711896};\\\", \\\"{x:1307,y:520,t:1527019711913};\\\", \\\"{x:1314,y:514,t:1527019711930};\\\", \\\"{x:1317,y:509,t:1527019711948};\\\", \\\"{x:1315,y:509,t:1527019712068};\\\", \\\"{x:1314,y:510,t:1527019712084};\\\", \\\"{x:1313,y:510,t:1527019712096};\\\", \\\"{x:1308,y:514,t:1527019712112};\\\", \\\"{x:1307,y:515,t:1527019712129};\\\", \\\"{x:1305,y:519,t:1527019712148};\\\", \\\"{x:1305,y:520,t:1527019712162};\\\", \\\"{x:1305,y:522,t:1527019712180};\\\", \\\"{x:1305,y:523,t:1527019712196};\\\", \\\"{x:1306,y:519,t:1527019712396};\\\", \\\"{x:1311,y:503,t:1527019712414};\\\", \\\"{x:1312,y:498,t:1527019712430};\\\", \\\"{x:1313,y:496,t:1527019712447};\\\", \\\"{x:1313,y:507,t:1527019713668};\\\", \\\"{x:1313,y:526,t:1527019713681};\\\", \\\"{x:1318,y:586,t:1527019713697};\\\", \\\"{x:1318,y:669,t:1527019713715};\\\", \\\"{x:1329,y:755,t:1527019713731};\\\", \\\"{x:1346,y:842,t:1527019713748};\\\", \\\"{x:1349,y:860,t:1527019713765};\\\", \\\"{x:1350,y:865,t:1527019713781};\\\", \\\"{x:1351,y:867,t:1527019713798};\\\", \\\"{x:1352,y:868,t:1527019713815};\\\", \\\"{x:1352,y:866,t:1527019713891};\\\", \\\"{x:1352,y:858,t:1527019713899};\\\", \\\"{x:1352,y:844,t:1527019713914};\\\", \\\"{x:1352,y:811,t:1527019713931};\\\", \\\"{x:1344,y:769,t:1527019713948};\\\", \\\"{x:1336,y:747,t:1527019713965};\\\", \\\"{x:1335,y:742,t:1527019713981};\\\", \\\"{x:1335,y:741,t:1527019714107};\\\", \\\"{x:1332,y:742,t:1527019714123};\\\", \\\"{x:1330,y:752,t:1527019714131};\\\", \\\"{x:1322,y:764,t:1527019714148};\\\", \\\"{x:1320,y:772,t:1527019714165};\\\", \\\"{x:1316,y:778,t:1527019714182};\\\", \\\"{x:1314,y:781,t:1527019714198};\\\", \\\"{x:1314,y:780,t:1527019714316};\\\", \\\"{x:1314,y:773,t:1527019714332};\\\", \\\"{x:1314,y:768,t:1527019714349};\\\", \\\"{x:1314,y:765,t:1527019714365};\\\", \\\"{x:1314,y:762,t:1527019714382};\\\", \\\"{x:1314,y:761,t:1527019714411};\\\", \\\"{x:1314,y:763,t:1527019715252};\\\", \\\"{x:1314,y:769,t:1527019715267};\\\", \\\"{x:1314,y:781,t:1527019715282};\\\", \\\"{x:1313,y:795,t:1527019715299};\\\", \\\"{x:1313,y:815,t:1527019715316};\\\", \\\"{x:1313,y:824,t:1527019715332};\\\", \\\"{x:1313,y:831,t:1527019715349};\\\", \\\"{x:1313,y:834,t:1527019715366};\\\", \\\"{x:1313,y:840,t:1527019715381};\\\", \\\"{x:1313,y:848,t:1527019715398};\\\", \\\"{x:1313,y:856,t:1527019715416};\\\", \\\"{x:1313,y:863,t:1527019715431};\\\", \\\"{x:1313,y:870,t:1527019715448};\\\", \\\"{x:1313,y:878,t:1527019715465};\\\", \\\"{x:1313,y:883,t:1527019715482};\\\", \\\"{x:1313,y:891,t:1527019715498};\\\", \\\"{x:1314,y:897,t:1527019715516};\\\", \\\"{x:1314,y:902,t:1527019715533};\\\", \\\"{x:1315,y:905,t:1527019715548};\\\", \\\"{x:1315,y:909,t:1527019715566};\\\", \\\"{x:1315,y:911,t:1527019715582};\\\", \\\"{x:1315,y:914,t:1527019715599};\\\", \\\"{x:1315,y:915,t:1527019715616};\\\", \\\"{x:1315,y:917,t:1527019715632};\\\", \\\"{x:1315,y:918,t:1527019715649};\\\", \\\"{x:1315,y:920,t:1527019715666};\\\", \\\"{x:1315,y:928,t:1527019715683};\\\", \\\"{x:1315,y:931,t:1527019715699};\\\", \\\"{x:1315,y:933,t:1527019715716};\\\", \\\"{x:1315,y:934,t:1527019715733};\\\", \\\"{x:1315,y:935,t:1527019715749};\\\", \\\"{x:1315,y:937,t:1527019715779};\\\", \\\"{x:1315,y:938,t:1527019715787};\\\", \\\"{x:1315,y:939,t:1527019715799};\\\", \\\"{x:1315,y:943,t:1527019715816};\\\", \\\"{x:1315,y:945,t:1527019715833};\\\", \\\"{x:1315,y:948,t:1527019715849};\\\", \\\"{x:1314,y:949,t:1527019715866};\\\", \\\"{x:1313,y:952,t:1527019715883};\\\", \\\"{x:1313,y:954,t:1527019715923};\\\", \\\"{x:1313,y:955,t:1527019715933};\\\", \\\"{x:1313,y:957,t:1527019715949};\\\", \\\"{x:1313,y:962,t:1527019715966};\\\", \\\"{x:1313,y:967,t:1527019715983};\\\", \\\"{x:1313,y:968,t:1527019716011};\\\", \\\"{x:1312,y:969,t:1527019716106};\\\", \\\"{x:1312,y:960,t:1527019718468};\\\", \\\"{x:1312,y:931,t:1527019718485};\\\", \\\"{x:1312,y:904,t:1527019718501};\\\", \\\"{x:1312,y:876,t:1527019718518};\\\", \\\"{x:1312,y:847,t:1527019718535};\\\", \\\"{x:1312,y:830,t:1527019718551};\\\", \\\"{x:1312,y:818,t:1527019718568};\\\", \\\"{x:1312,y:809,t:1527019718585};\\\", \\\"{x:1312,y:793,t:1527019718601};\\\", \\\"{x:1316,y:782,t:1527019718617};\\\", \\\"{x:1324,y:769,t:1527019718635};\\\", \\\"{x:1326,y:765,t:1527019718651};\\\", \\\"{x:1329,y:759,t:1527019718668};\\\", \\\"{x:1331,y:756,t:1527019718685};\\\", \\\"{x:1331,y:754,t:1527019718702};\\\", \\\"{x:1332,y:752,t:1527019718718};\\\", \\\"{x:1332,y:751,t:1527019718748};\\\", \\\"{x:1332,y:752,t:1527019718835};\\\", \\\"{x:1333,y:758,t:1527019718851};\\\", \\\"{x:1333,y:759,t:1527019718868};\\\", \\\"{x:1333,y:760,t:1527019718900};\\\", \\\"{x:1334,y:760,t:1527019718948};\\\", \\\"{x:1336,y:760,t:1527019718972};\\\", \\\"{x:1337,y:760,t:1527019718985};\\\", \\\"{x:1342,y:760,t:1527019719002};\\\", \\\"{x:1349,y:760,t:1527019719018};\\\", \\\"{x:1362,y:760,t:1527019719034};\\\", \\\"{x:1369,y:760,t:1527019719051};\\\", \\\"{x:1371,y:760,t:1527019719068};\\\", \\\"{x:1373,y:760,t:1527019719084};\\\", \\\"{x:1374,y:760,t:1527019719102};\\\", \\\"{x:1376,y:760,t:1527019719203};\\\", \\\"{x:1377,y:760,t:1527019719218};\\\", \\\"{x:1379,y:760,t:1527019719235};\\\", \\\"{x:1380,y:760,t:1527019719291};\\\", \\\"{x:1380,y:761,t:1527019719692};\\\", \\\"{x:1380,y:762,t:1527019719715};\\\", \\\"{x:1380,y:763,t:1527019719731};\\\", \\\"{x:1380,y:764,t:1527019719739};\\\", \\\"{x:1380,y:765,t:1527019719812};\\\", \\\"{x:1380,y:766,t:1527019719827};\\\", \\\"{x:1380,y:768,t:1527019719843};\\\", \\\"{x:1380,y:769,t:1527019719860};\\\", \\\"{x:1380,y:771,t:1527019719869};\\\", \\\"{x:1380,y:774,t:1527019719886};\\\", \\\"{x:1380,y:779,t:1527019719902};\\\", \\\"{x:1380,y:785,t:1527019719919};\\\", \\\"{x:1380,y:794,t:1527019719936};\\\", \\\"{x:1383,y:803,t:1527019719953};\\\", \\\"{x:1385,y:820,t:1527019719969};\\\", \\\"{x:1386,y:835,t:1527019719985};\\\", \\\"{x:1389,y:854,t:1527019720003};\\\", \\\"{x:1390,y:864,t:1527019720019};\\\", \\\"{x:1393,y:872,t:1527019720036};\\\", \\\"{x:1394,y:881,t:1527019720053};\\\", \\\"{x:1396,y:892,t:1527019720068};\\\", \\\"{x:1398,y:898,t:1527019720086};\\\", \\\"{x:1398,y:902,t:1527019720102};\\\", \\\"{x:1398,y:904,t:1527019720119};\\\", \\\"{x:1399,y:906,t:1527019720136};\\\", \\\"{x:1399,y:908,t:1527019720171};\\\", \\\"{x:1399,y:909,t:1527019720186};\\\", \\\"{x:1400,y:914,t:1527019720203};\\\", \\\"{x:1400,y:915,t:1527019720219};\\\", \\\"{x:1400,y:916,t:1527019720236};\\\", \\\"{x:1400,y:917,t:1527019720253};\\\", \\\"{x:1400,y:918,t:1527019720269};\\\", \\\"{x:1400,y:920,t:1527019720291};\\\", \\\"{x:1400,y:921,t:1527019720303};\\\", \\\"{x:1400,y:923,t:1527019720319};\\\", \\\"{x:1400,y:928,t:1527019720336};\\\", \\\"{x:1401,y:931,t:1527019720353};\\\", \\\"{x:1401,y:932,t:1527019720370};\\\", \\\"{x:1401,y:934,t:1527019720386};\\\", \\\"{x:1401,y:935,t:1527019720403};\\\", \\\"{x:1401,y:937,t:1527019720419};\\\", \\\"{x:1401,y:939,t:1527019720436};\\\", \\\"{x:1401,y:941,t:1527019720454};\\\", \\\"{x:1402,y:944,t:1527019720471};\\\", \\\"{x:1402,y:945,t:1527019720486};\\\", \\\"{x:1402,y:947,t:1527019720515};\\\", \\\"{x:1402,y:948,t:1527019720539};\\\", \\\"{x:1402,y:950,t:1527019720564};\\\", \\\"{x:1402,y:951,t:1527019720579};\\\", \\\"{x:1402,y:952,t:1527019720612};\\\", \\\"{x:1402,y:949,t:1527019720740};\\\", \\\"{x:1402,y:930,t:1527019720753};\\\", \\\"{x:1399,y:890,t:1527019720770};\\\", \\\"{x:1393,y:840,t:1527019720786};\\\", \\\"{x:1386,y:795,t:1527019720803};\\\", \\\"{x:1384,y:777,t:1527019720820};\\\", \\\"{x:1382,y:770,t:1527019720837};\\\", \\\"{x:1382,y:765,t:1527019720853};\\\", \\\"{x:1381,y:763,t:1527019720870};\\\", \\\"{x:1381,y:761,t:1527019720887};\\\", \\\"{x:1381,y:760,t:1527019720903};\\\", \\\"{x:1381,y:757,t:1527019720920};\\\", \\\"{x:1381,y:756,t:1527019720937};\\\", \\\"{x:1381,y:754,t:1527019720953};\\\", \\\"{x:1381,y:753,t:1527019720970};\\\", \\\"{x:1380,y:753,t:1527019721083};\\\", \\\"{x:1378,y:753,t:1527019721091};\\\", \\\"{x:1377,y:756,t:1527019721103};\\\", \\\"{x:1375,y:760,t:1527019721121};\\\", \\\"{x:1374,y:763,t:1527019721138};\\\", \\\"{x:1373,y:765,t:1527019721153};\\\", \\\"{x:1373,y:767,t:1527019721170};\\\", \\\"{x:1372,y:771,t:1527019721187};\\\", \\\"{x:1371,y:774,t:1527019721203};\\\", \\\"{x:1371,y:776,t:1527019721220};\\\", \\\"{x:1371,y:778,t:1527019721237};\\\", \\\"{x:1370,y:783,t:1527019721253};\\\", \\\"{x:1370,y:786,t:1527019721270};\\\", \\\"{x:1370,y:790,t:1527019721288};\\\", \\\"{x:1370,y:795,t:1527019721304};\\\", \\\"{x:1370,y:801,t:1527019721320};\\\", \\\"{x:1370,y:807,t:1527019721337};\\\", \\\"{x:1370,y:812,t:1527019721354};\\\", \\\"{x:1370,y:817,t:1527019721370};\\\", \\\"{x:1370,y:821,t:1527019721387};\\\", \\\"{x:1370,y:823,t:1527019721404};\\\", \\\"{x:1370,y:825,t:1527019721427};\\\", \\\"{x:1370,y:827,t:1527019721437};\\\", \\\"{x:1370,y:831,t:1527019721454};\\\", \\\"{x:1370,y:835,t:1527019721470};\\\", \\\"{x:1370,y:841,t:1527019721487};\\\", \\\"{x:1370,y:846,t:1527019721504};\\\", \\\"{x:1370,y:853,t:1527019721520};\\\", \\\"{x:1370,y:858,t:1527019721537};\\\", \\\"{x:1370,y:862,t:1527019721554};\\\", \\\"{x:1370,y:865,t:1527019721570};\\\", \\\"{x:1370,y:868,t:1527019721587};\\\", \\\"{x:1371,y:872,t:1527019721605};\\\", \\\"{x:1371,y:876,t:1527019721621};\\\", \\\"{x:1372,y:879,t:1527019721637};\\\", \\\"{x:1372,y:884,t:1527019721654};\\\", \\\"{x:1372,y:886,t:1527019721670};\\\", \\\"{x:1372,y:888,t:1527019721688};\\\", \\\"{x:1372,y:891,t:1527019721704};\\\", \\\"{x:1373,y:892,t:1527019721721};\\\", \\\"{x:1373,y:894,t:1527019721737};\\\", \\\"{x:1375,y:897,t:1527019721754};\\\", \\\"{x:1375,y:901,t:1527019721771};\\\", \\\"{x:1375,y:902,t:1527019721787};\\\", \\\"{x:1376,y:903,t:1527019721811};\\\", \\\"{x:1376,y:904,t:1527019721827};\\\", \\\"{x:1376,y:905,t:1527019721843};\\\", \\\"{x:1376,y:906,t:1527019721860};\\\", \\\"{x:1376,y:907,t:1527019721871};\\\", \\\"{x:1376,y:908,t:1527019721888};\\\", \\\"{x:1376,y:910,t:1527019721905};\\\", \\\"{x:1377,y:914,t:1527019721921};\\\", \\\"{x:1378,y:915,t:1527019721937};\\\", \\\"{x:1379,y:916,t:1527019721954};\\\", \\\"{x:1380,y:917,t:1527019721971};\\\", \\\"{x:1380,y:918,t:1527019721987};\\\", \\\"{x:1381,y:922,t:1527019722004};\\\", \\\"{x:1382,y:925,t:1527019722022};\\\", \\\"{x:1383,y:930,t:1527019722037};\\\", \\\"{x:1383,y:932,t:1527019722054};\\\", \\\"{x:1383,y:936,t:1527019722071};\\\", \\\"{x:1383,y:941,t:1527019722088};\\\", \\\"{x:1385,y:945,t:1527019722104};\\\", \\\"{x:1386,y:950,t:1527019722121};\\\", \\\"{x:1386,y:954,t:1527019722138};\\\", \\\"{x:1387,y:956,t:1527019722154};\\\", \\\"{x:1387,y:957,t:1527019722171};\\\", \\\"{x:1388,y:958,t:1527019722188};\\\", \\\"{x:1389,y:959,t:1527019722204};\\\", \\\"{x:1389,y:960,t:1527019722222};\\\", \\\"{x:1389,y:963,t:1527019722412};\\\", \\\"{x:1389,y:964,t:1527019722426};\\\", \\\"{x:1388,y:966,t:1527019722437};\\\", \\\"{x:1387,y:968,t:1527019722453};\\\", \\\"{x:1387,y:969,t:1527019722471};\\\", \\\"{x:1387,y:970,t:1527019722996};\\\", \\\"{x:1386,y:971,t:1527019723019};\\\", \\\"{x:1385,y:965,t:1527019726803};\\\", \\\"{x:1385,y:960,t:1527019726811};\\\", \\\"{x:1385,y:950,t:1527019726824};\\\", \\\"{x:1385,y:928,t:1527019726841};\\\", \\\"{x:1385,y:912,t:1527019726858};\\\", \\\"{x:1385,y:894,t:1527019726874};\\\", \\\"{x:1385,y:871,t:1527019726890};\\\", \\\"{x:1385,y:856,t:1527019726909};\\\", \\\"{x:1385,y:842,t:1527019726924};\\\", \\\"{x:1385,y:831,t:1527019726941};\\\", \\\"{x:1385,y:823,t:1527019726958};\\\", \\\"{x:1385,y:810,t:1527019726975};\\\", \\\"{x:1385,y:805,t:1527019726992};\\\", \\\"{x:1385,y:798,t:1527019727008};\\\", \\\"{x:1385,y:793,t:1527019727025};\\\", \\\"{x:1385,y:790,t:1527019727041};\\\", \\\"{x:1385,y:788,t:1527019727059};\\\", \\\"{x:1385,y:785,t:1527019727075};\\\", \\\"{x:1385,y:782,t:1527019727091};\\\", \\\"{x:1385,y:779,t:1527019727109};\\\", \\\"{x:1385,y:777,t:1527019727125};\\\", \\\"{x:1386,y:774,t:1527019727141};\\\", \\\"{x:1386,y:771,t:1527019727158};\\\", \\\"{x:1386,y:768,t:1527019727175};\\\", \\\"{x:1386,y:765,t:1527019727191};\\\", \\\"{x:1386,y:764,t:1527019727225};\\\", \\\"{x:1387,y:764,t:1527019727244};\\\", \\\"{x:1387,y:763,t:1527019727780};\\\", \\\"{x:1386,y:763,t:1527019727808};\\\", \\\"{x:1385,y:763,t:1527019727825};\\\", \\\"{x:1382,y:763,t:1527019728035};\\\", \\\"{x:1366,y:763,t:1527019728044};\\\", \\\"{x:1285,y:762,t:1527019728059};\\\", \\\"{x:1190,y:748,t:1527019728075};\\\", \\\"{x:1030,y:724,t:1527019728092};\\\", \\\"{x:869,y:702,t:1527019728109};\\\", \\\"{x:774,y:684,t:1527019728125};\\\", \\\"{x:740,y:679,t:1527019728143};\\\", \\\"{x:725,y:672,t:1527019728159};\\\", \\\"{x:716,y:667,t:1527019728176};\\\", \\\"{x:712,y:663,t:1527019728192};\\\", \\\"{x:711,y:661,t:1527019728209};\\\", \\\"{x:708,y:656,t:1527019728225};\\\", \\\"{x:704,y:647,t:1527019728244};\\\", \\\"{x:683,y:630,t:1527019728258};\\\", \\\"{x:649,y:611,t:1527019728275};\\\", \\\"{x:589,y:588,t:1527019728294};\\\", \\\"{x:532,y:566,t:1527019728312};\\\", \\\"{x:498,y:556,t:1527019728329};\\\", \\\"{x:471,y:549,t:1527019728343};\\\", \\\"{x:451,y:538,t:1527019728361};\\\", \\\"{x:438,y:533,t:1527019728378};\\\", \\\"{x:432,y:530,t:1527019728394};\\\", \\\"{x:432,y:529,t:1527019728411};\\\", \\\"{x:431,y:529,t:1527019728490};\\\", \\\"{x:430,y:529,t:1527019728499};\\\", \\\"{x:424,y:533,t:1527019728511};\\\", \\\"{x:413,y:541,t:1527019728529};\\\", \\\"{x:402,y:549,t:1527019728544};\\\", \\\"{x:395,y:554,t:1527019728560};\\\", \\\"{x:392,y:557,t:1527019728578};\\\", \\\"{x:391,y:558,t:1527019728594};\\\", \\\"{x:391,y:562,t:1527019729011};\\\", \\\"{x:411,y:569,t:1527019729028};\\\", \\\"{x:445,y:574,t:1527019729046};\\\", \\\"{x:485,y:581,t:1527019729061};\\\", \\\"{x:562,y:599,t:1527019729078};\\\", \\\"{x:629,y:618,t:1527019729095};\\\", \\\"{x:713,y:647,t:1527019729111};\\\", \\\"{x:793,y:683,t:1527019729128};\\\", \\\"{x:874,y:724,t:1527019729145};\\\", \\\"{x:973,y:764,t:1527019729161};\\\", \\\"{x:1071,y:798,t:1527019729178};\\\", \\\"{x:1187,y:831,t:1527019729194};\\\", \\\"{x:1238,y:839,t:1527019729211};\\\", \\\"{x:1271,y:842,t:1527019729228};\\\", \\\"{x:1294,y:842,t:1527019729245};\\\", \\\"{x:1307,y:835,t:1527019729262};\\\", \\\"{x:1315,y:831,t:1527019729278};\\\", \\\"{x:1319,y:825,t:1527019729296};\\\", \\\"{x:1322,y:821,t:1527019729312};\\\", \\\"{x:1324,y:816,t:1527019729328};\\\", \\\"{x:1333,y:807,t:1527019729346};\\\", \\\"{x:1344,y:796,t:1527019729363};\\\", \\\"{x:1353,y:784,t:1527019729378};\\\", \\\"{x:1363,y:766,t:1527019729395};\\\", \\\"{x:1368,y:759,t:1527019729412};\\\", \\\"{x:1370,y:755,t:1527019729428};\\\", \\\"{x:1375,y:753,t:1527019729446};\\\", \\\"{x:1384,y:748,t:1527019729462};\\\", \\\"{x:1392,y:745,t:1527019729479};\\\", \\\"{x:1393,y:743,t:1527019729496};\\\", \\\"{x:1395,y:743,t:1527019729512};\\\", \\\"{x:1396,y:743,t:1527019729571};\\\", \\\"{x:1399,y:743,t:1527019729580};\\\", \\\"{x:1406,y:752,t:1527019729596};\\\", \\\"{x:1409,y:763,t:1527019729613};\\\", \\\"{x:1411,y:779,t:1527019729628};\\\", \\\"{x:1411,y:788,t:1527019729645};\\\", \\\"{x:1411,y:792,t:1527019729662};\\\", \\\"{x:1411,y:796,t:1527019729679};\\\", \\\"{x:1411,y:802,t:1527019729695};\\\", \\\"{x:1411,y:812,t:1527019729713};\\\", \\\"{x:1411,y:822,t:1527019729729};\\\", \\\"{x:1411,y:833,t:1527019729745};\\\", \\\"{x:1411,y:846,t:1527019729762};\\\", \\\"{x:1411,y:869,t:1527019729779};\\\", \\\"{x:1411,y:883,t:1527019729796};\\\", \\\"{x:1411,y:895,t:1527019729813};\\\", \\\"{x:1414,y:908,t:1527019729830};\\\", \\\"{x:1415,y:915,t:1527019729845};\\\", \\\"{x:1418,y:923,t:1527019729862};\\\", \\\"{x:1420,y:929,t:1527019729880};\\\", \\\"{x:1420,y:934,t:1527019729895};\\\", \\\"{x:1423,y:941,t:1527019729912};\\\", \\\"{x:1424,y:946,t:1527019729929};\\\", \\\"{x:1427,y:953,t:1527019729945};\\\", \\\"{x:1427,y:956,t:1527019729962};\\\", \\\"{x:1427,y:952,t:1527019730179};\\\", \\\"{x:1427,y:948,t:1527019730196};\\\", \\\"{x:1427,y:941,t:1527019730212};\\\", \\\"{x:1426,y:937,t:1527019730229};\\\", \\\"{x:1426,y:934,t:1527019730246};\\\", \\\"{x:1424,y:930,t:1527019730262};\\\", \\\"{x:1423,y:927,t:1527019730279};\\\", \\\"{x:1422,y:924,t:1527019730296};\\\", \\\"{x:1422,y:921,t:1527019730313};\\\", \\\"{x:1422,y:920,t:1527019730330};\\\", \\\"{x:1421,y:915,t:1527019730349};\\\", \\\"{x:1421,y:913,t:1527019730362};\\\", \\\"{x:1421,y:910,t:1527019730380};\\\", \\\"{x:1421,y:908,t:1527019730397};\\\", \\\"{x:1421,y:907,t:1527019730413};\\\", \\\"{x:1421,y:905,t:1527019730430};\\\", \\\"{x:1420,y:903,t:1527019730447};\\\", \\\"{x:1420,y:902,t:1527019730463};\\\", \\\"{x:1420,y:901,t:1527019730480};\\\", \\\"{x:1419,y:899,t:1527019730497};\\\", \\\"{x:1419,y:894,t:1527019730513};\\\", \\\"{x:1416,y:888,t:1527019730530};\\\", \\\"{x:1411,y:873,t:1527019730548};\\\", \\\"{x:1406,y:858,t:1527019730563};\\\", \\\"{x:1399,y:841,t:1527019730579};\\\", \\\"{x:1392,y:826,t:1527019730597};\\\", \\\"{x:1389,y:820,t:1527019730614};\\\", \\\"{x:1384,y:810,t:1527019730630};\\\", \\\"{x:1381,y:802,t:1527019730646};\\\", \\\"{x:1380,y:799,t:1527019730663};\\\", \\\"{x:1380,y:795,t:1527019730680};\\\", \\\"{x:1379,y:789,t:1527019730697};\\\", \\\"{x:1379,y:784,t:1527019730713};\\\", \\\"{x:1378,y:779,t:1527019730729};\\\", \\\"{x:1378,y:774,t:1527019730748};\\\", \\\"{x:1378,y:771,t:1527019730763};\\\", \\\"{x:1378,y:769,t:1527019730780};\\\", \\\"{x:1378,y:768,t:1527019730797};\\\", \\\"{x:1377,y:764,t:1527019730813};\\\", \\\"{x:1377,y:763,t:1527019730835};\\\", \\\"{x:1377,y:760,t:1527019730851};\\\", \\\"{x:1377,y:758,t:1527019731620};\\\", \\\"{x:1377,y:756,t:1527019731630};\\\", \\\"{x:1377,y:755,t:1527019731651};\\\", \\\"{x:1377,y:754,t:1527019731667};\\\", \\\"{x:1377,y:753,t:1527019731691};\\\", \\\"{x:1376,y:750,t:1527019733180};\\\", \\\"{x:1375,y:744,t:1527019733187};\\\", \\\"{x:1374,y:741,t:1527019733199};\\\", \\\"{x:1372,y:733,t:1527019733216};\\\", \\\"{x:1370,y:726,t:1527019733232};\\\", \\\"{x:1369,y:722,t:1527019733249};\\\", \\\"{x:1368,y:720,t:1527019733266};\\\", \\\"{x:1368,y:717,t:1527019733282};\\\", \\\"{x:1365,y:712,t:1527019733299};\\\", \\\"{x:1362,y:707,t:1527019733315};\\\", \\\"{x:1362,y:703,t:1527019733333};\\\", \\\"{x:1361,y:699,t:1527019733348};\\\", \\\"{x:1360,y:696,t:1527019733366};\\\", \\\"{x:1359,y:695,t:1527019733571};\\\", \\\"{x:1357,y:693,t:1527019733582};\\\", \\\"{x:1346,y:690,t:1527019733598};\\\", \\\"{x:1333,y:686,t:1527019733616};\\\", \\\"{x:1319,y:682,t:1527019733632};\\\", \\\"{x:1310,y:680,t:1527019733648};\\\", \\\"{x:1306,y:678,t:1527019733666};\\\", \\\"{x:1301,y:674,t:1527019733683};\\\", \\\"{x:1299,y:672,t:1527019733698};\\\", \\\"{x:1293,y:662,t:1527019733716};\\\", \\\"{x:1288,y:656,t:1527019733732};\\\", \\\"{x:1282,y:648,t:1527019733749};\\\", \\\"{x:1278,y:642,t:1527019733765};\\\", \\\"{x:1274,y:639,t:1527019733783};\\\", \\\"{x:1270,y:636,t:1527019733799};\\\", \\\"{x:1264,y:632,t:1527019733816};\\\", \\\"{x:1258,y:631,t:1527019733833};\\\", \\\"{x:1253,y:631,t:1527019733851};\\\", \\\"{x:1242,y:631,t:1527019733866};\\\", \\\"{x:1235,y:631,t:1527019733884};\\\", \\\"{x:1234,y:631,t:1527019733972};\\\", \\\"{x:1235,y:631,t:1527019735076};\\\", \\\"{x:1236,y:631,t:1527019735099};\\\", \\\"{x:1237,y:631,t:1527019735220};\\\", \\\"{x:1238,y:632,t:1527019735234};\\\", \\\"{x:1239,y:632,t:1527019735250};\\\", \\\"{x:1240,y:632,t:1527019735395};\\\", \\\"{x:1241,y:632,t:1527019735403};\\\", \\\"{x:1243,y:633,t:1527019735419};\\\", \\\"{x:1244,y:635,t:1527019735451};\\\", \\\"{x:1245,y:636,t:1527019735540};\\\", \\\"{x:1245,y:637,t:1527019735567};\\\", \\\"{x:1246,y:639,t:1527019735574};\\\", \\\"{x:1246,y:642,t:1527019735587};\\\", \\\"{x:1246,y:647,t:1527019735604};\\\", \\\"{x:1247,y:655,t:1527019735621};\\\", \\\"{x:1247,y:666,t:1527019735637};\\\", \\\"{x:1250,y:686,t:1527019735654};\\\", \\\"{x:1254,y:697,t:1527019735670};\\\", \\\"{x:1255,y:703,t:1527019735686};\\\", \\\"{x:1255,y:704,t:1527019735703};\\\", \\\"{x:1255,y:705,t:1527019735720};\\\", \\\"{x:1256,y:707,t:1527019735757};\\\", \\\"{x:1256,y:708,t:1527019735773};\\\", \\\"{x:1256,y:710,t:1527019735789};\\\", \\\"{x:1256,y:711,t:1527019735803};\\\", \\\"{x:1256,y:713,t:1527019735821};\\\", \\\"{x:1256,y:718,t:1527019735837};\\\", \\\"{x:1256,y:722,t:1527019735854};\\\", \\\"{x:1256,y:727,t:1527019735871};\\\", \\\"{x:1256,y:733,t:1527019735888};\\\", \\\"{x:1255,y:740,t:1527019735903};\\\", \\\"{x:1255,y:745,t:1527019735921};\\\", \\\"{x:1254,y:748,t:1527019735936};\\\", \\\"{x:1254,y:750,t:1527019735954};\\\", \\\"{x:1254,y:753,t:1527019735971};\\\", \\\"{x:1253,y:755,t:1527019735987};\\\", \\\"{x:1251,y:758,t:1527019736004};\\\", \\\"{x:1251,y:761,t:1527019736021};\\\", \\\"{x:1251,y:764,t:1527019736038};\\\", \\\"{x:1251,y:765,t:1527019736054};\\\", \\\"{x:1251,y:767,t:1527019736071};\\\", \\\"{x:1251,y:769,t:1527019736088};\\\", \\\"{x:1251,y:770,t:1527019736103};\\\", \\\"{x:1251,y:773,t:1527019736121};\\\", \\\"{x:1251,y:774,t:1527019736138};\\\", \\\"{x:1251,y:777,t:1527019736154};\\\", \\\"{x:1251,y:779,t:1527019736171};\\\", \\\"{x:1251,y:780,t:1527019736188};\\\", \\\"{x:1251,y:784,t:1527019736205};\\\", \\\"{x:1251,y:785,t:1527019736221};\\\", \\\"{x:1251,y:787,t:1527019736238};\\\", \\\"{x:1251,y:789,t:1527019736254};\\\", \\\"{x:1251,y:790,t:1527019736271};\\\", \\\"{x:1251,y:792,t:1527019736288};\\\", \\\"{x:1251,y:793,t:1527019736305};\\\", \\\"{x:1251,y:796,t:1527019736321};\\\", \\\"{x:1251,y:797,t:1527019736342};\\\", \\\"{x:1251,y:798,t:1527019736359};\\\", \\\"{x:1251,y:799,t:1527019736390};\\\", \\\"{x:1251,y:801,t:1527019736414};\\\", \\\"{x:1251,y:802,t:1527019736446};\\\", \\\"{x:1251,y:804,t:1527019736462};\\\", \\\"{x:1251,y:805,t:1527019736471};\\\", \\\"{x:1251,y:807,t:1527019736488};\\\", \\\"{x:1251,y:810,t:1527019736505};\\\", \\\"{x:1251,y:812,t:1527019736521};\\\", \\\"{x:1251,y:815,t:1527019736538};\\\", \\\"{x:1252,y:820,t:1527019736555};\\\", \\\"{x:1252,y:822,t:1527019736571};\\\", \\\"{x:1252,y:825,t:1527019736588};\\\", \\\"{x:1252,y:827,t:1527019736605};\\\", \\\"{x:1252,y:832,t:1527019736622};\\\", \\\"{x:1252,y:836,t:1527019736638};\\\", \\\"{x:1254,y:839,t:1527019736655};\\\", \\\"{x:1254,y:843,t:1527019736672};\\\", \\\"{x:1254,y:846,t:1527019736688};\\\", \\\"{x:1255,y:851,t:1527019736705};\\\", \\\"{x:1255,y:856,t:1527019736721};\\\", \\\"{x:1255,y:860,t:1527019736737};\\\", \\\"{x:1255,y:865,t:1527019736754};\\\", \\\"{x:1255,y:873,t:1527019736771};\\\", \\\"{x:1255,y:884,t:1527019736787};\\\", \\\"{x:1255,y:894,t:1527019736804};\\\", \\\"{x:1255,y:909,t:1527019736821};\\\", \\\"{x:1258,y:927,t:1527019736837};\\\", \\\"{x:1261,y:945,t:1527019736854};\\\", \\\"{x:1261,y:953,t:1527019736872};\\\", \\\"{x:1261,y:958,t:1527019736887};\\\", \\\"{x:1261,y:961,t:1527019736904};\\\", \\\"{x:1261,y:964,t:1527019736922};\\\", \\\"{x:1261,y:965,t:1527019736938};\\\", \\\"{x:1261,y:966,t:1527019736954};\\\", \\\"{x:1261,y:967,t:1527019736974};\\\", \\\"{x:1261,y:968,t:1527019736997};\\\", \\\"{x:1261,y:969,t:1527019737006};\\\", \\\"{x:1261,y:970,t:1527019737022};\\\", \\\"{x:1261,y:971,t:1527019737038};\\\", \\\"{x:1261,y:973,t:1527019737055};\\\", \\\"{x:1261,y:974,t:1527019738726};\\\", \\\"{x:1261,y:976,t:1527019738740};\\\", \\\"{x:1261,y:981,t:1527019738757};\\\", \\\"{x:1261,y:986,t:1527019738773};\\\", \\\"{x:1261,y:991,t:1527019738789};\\\", \\\"{x:1261,y:992,t:1527019738806};\\\", \\\"{x:1251,y:988,t:1527019741773};\\\", \\\"{x:1206,y:970,t:1527019741780};\\\", \\\"{x:1155,y:952,t:1527019741791};\\\", \\\"{x:1003,y:908,t:1527019741809};\\\", \\\"{x:824,y:860,t:1527019741825};\\\", \\\"{x:628,y:808,t:1527019741841};\\\", \\\"{x:482,y:764,t:1527019741859};\\\", \\\"{x:441,y:749,t:1527019741875};\\\", \\\"{x:436,y:748,t:1527019741892};\\\", \\\"{x:436,y:747,t:1527019741908};\\\", \\\"{x:436,y:748,t:1527019741933};\\\", \\\"{x:437,y:748,t:1527019741949};\\\", \\\"{x:439,y:748,t:1527019741965};\\\", \\\"{x:441,y:748,t:1527019741989};\\\", \\\"{x:442,y:748,t:1527019741996};\\\", \\\"{x:444,y:749,t:1527019742009};\\\", \\\"{x:456,y:750,t:1527019742025};\\\", \\\"{x:472,y:753,t:1527019742043};\\\", \\\"{x:482,y:754,t:1527019742058};\\\", \\\"{x:489,y:754,t:1527019742075};\\\", \\\"{x:494,y:751,t:1527019742093};\\\", \\\"{x:500,y:744,t:1527019742109};\\\", \\\"{x:509,y:730,t:1527019742126};\\\", \\\"{x:513,y:724,t:1527019742142};\\\", \\\"{x:516,y:717,t:1527019742159};\\\", \\\"{x:518,y:711,t:1527019742176};\\\", \\\"{x:521,y:699,t:1527019742193};\\\", \\\"{x:523,y:690,t:1527019742208};\\\", \\\"{x:524,y:687,t:1527019742226};\\\", \\\"{x:524,y:688,t:1527019742533};\\\", \\\"{x:524,y:690,t:1527019742542};\\\", \\\"{x:523,y:700,t:1527019742558};\\\", \\\"{x:523,y:708,t:1527019742576};\\\", \\\"{x:523,y:715,t:1527019742592};\\\", \\\"{x:523,y:717,t:1527019742609};\\\", \\\"{x:522,y:718,t:1527019743542};\\\", \\\"{x:521,y:718,t:1527019743558};\\\" ] }, { \\\"rt\\\": 60599, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 428579, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-10 AM-I -A -A -A -12 PM-11 AM-12 PM-03 PM-I -I -A -A -7-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:718,t:1527019745366};\\\", \\\"{x:518,y:718,t:1527019745380};\\\", \\\"{x:517,y:718,t:1527019745398};\\\", \\\"{x:515,y:718,t:1527019745413};\\\", \\\"{x:514,y:719,t:1527019745430};\\\", \\\"{x:513,y:719,t:1527019745734};\\\", \\\"{x:512,y:720,t:1527019745747};\\\", \\\"{x:511,y:721,t:1527019745764};\\\", \\\"{x:508,y:723,t:1527019745780};\\\", \\\"{x:507,y:723,t:1527019745797};\\\", \\\"{x:506,y:724,t:1527019745814};\\\", \\\"{x:505,y:724,t:1527019745838};\\\", \\\"{x:504,y:725,t:1527019745990};\\\", \\\"{x:503,y:726,t:1527019746038};\\\", \\\"{x:502,y:727,t:1527019746061};\\\", \\\"{x:501,y:727,t:1527019746072};\\\", \\\"{x:500,y:728,t:1527019746085};\\\", \\\"{x:500,y:729,t:1527019746101};\\\", \\\"{x:499,y:729,t:1527019746133};\\\", \\\"{x:499,y:730,t:1527019746173};\\\", \\\"{x:497,y:731,t:1527019746214};\\\", \\\"{x:496,y:732,t:1527019746326};\\\", \\\"{x:494,y:732,t:1527019746381};\\\", \\\"{x:493,y:733,t:1527019746405};\\\", \\\"{x:492,y:733,t:1527019746966};\\\", \\\"{x:492,y:734,t:1527019746998};\\\", \\\"{x:491,y:734,t:1527019747006};\\\", \\\"{x:491,y:735,t:1527019747030};\\\", \\\"{x:490,y:735,t:1527019747054};\\\", \\\"{x:489,y:735,t:1527019747102};\\\", \\\"{x:489,y:736,t:1527019747118};\\\", \\\"{x:488,y:736,t:1527019747133};\\\", \\\"{x:486,y:736,t:1527019747158};\\\", \\\"{x:486,y:737,t:1527019747182};\\\", \\\"{x:485,y:738,t:1527019747255};\\\", \\\"{x:484,y:738,t:1527019747318};\\\", \\\"{x:483,y:739,t:1527019747430};\\\", \\\"{x:482,y:740,t:1527019747886};\\\", \\\"{x:482,y:741,t:1527019747901};\\\", \\\"{x:481,y:741,t:1527019747926};\\\", \\\"{x:480,y:741,t:1527019747942};\\\", \\\"{x:479,y:741,t:1527019748094};\\\", \\\"{x:479,y:742,t:1527019748135};\\\", \\\"{x:479,y:743,t:1527019748966};\\\", \\\"{x:479,y:746,t:1527019748974};\\\", \\\"{x:481,y:752,t:1527019748988};\\\", \\\"{x:510,y:773,t:1527019749003};\\\", \\\"{x:609,y:825,t:1527019749019};\\\", \\\"{x:744,y:889,t:1527019749031};\\\", \\\"{x:916,y:948,t:1527019749047};\\\", \\\"{x:1098,y:993,t:1527019749065};\\\", \\\"{x:1263,y:1033,t:1527019749080};\\\", \\\"{x:1402,y:1059,t:1527019749098};\\\", \\\"{x:1500,y:1074,t:1527019749115};\\\", \\\"{x:1535,y:1080,t:1527019749131};\\\", \\\"{x:1538,y:1080,t:1527019749148};\\\", \\\"{x:1536,y:1080,t:1527019749246};\\\", \\\"{x:1533,y:1080,t:1527019749253};\\\", \\\"{x:1532,y:1078,t:1527019749265};\\\", \\\"{x:1527,y:1075,t:1527019749282};\\\", \\\"{x:1521,y:1066,t:1527019749298};\\\", \\\"{x:1514,y:1056,t:1527019749316};\\\", \\\"{x:1503,y:1040,t:1527019749332};\\\", \\\"{x:1495,y:1028,t:1527019749348};\\\", \\\"{x:1488,y:1014,t:1527019749365};\\\", \\\"{x:1478,y:1000,t:1527019749381};\\\", \\\"{x:1473,y:991,t:1527019749398};\\\", \\\"{x:1464,y:982,t:1527019749416};\\\", \\\"{x:1455,y:976,t:1527019749433};\\\", \\\"{x:1448,y:971,t:1527019749448};\\\", \\\"{x:1441,y:967,t:1527019749465};\\\", \\\"{x:1437,y:965,t:1527019749482};\\\", \\\"{x:1435,y:964,t:1527019749500};\\\", \\\"{x:1432,y:963,t:1527019749515};\\\", \\\"{x:1428,y:961,t:1527019749533};\\\", \\\"{x:1416,y:960,t:1527019749549};\\\", \\\"{x:1401,y:960,t:1527019749565};\\\", \\\"{x:1381,y:960,t:1527019749582};\\\", \\\"{x:1352,y:960,t:1527019749599};\\\", \\\"{x:1319,y:960,t:1527019749615};\\\", \\\"{x:1270,y:963,t:1527019749632};\\\", \\\"{x:1220,y:970,t:1527019749649};\\\", \\\"{x:1186,y:975,t:1527019749665};\\\", \\\"{x:1172,y:976,t:1527019749681};\\\", \\\"{x:1170,y:977,t:1527019749698};\\\", \\\"{x:1169,y:977,t:1527019750990};\\\", \\\"{x:1171,y:977,t:1527019751255};\\\", \\\"{x:1181,y:960,t:1527019751267};\\\", \\\"{x:1224,y:876,t:1527019751284};\\\", \\\"{x:1294,y:745,t:1527019751301};\\\", \\\"{x:1396,y:520,t:1527019751318};\\\", \\\"{x:1418,y:453,t:1527019751334};\\\", \\\"{x:1452,y:303,t:1527019751350};\\\", \\\"{x:1454,y:262,t:1527019751367};\\\", \\\"{x:1454,y:248,t:1527019751384};\\\", \\\"{x:1454,y:246,t:1527019751401};\\\", \\\"{x:1454,y:245,t:1527019751469};\\\", \\\"{x:1451,y:246,t:1527019751493};\\\", \\\"{x:1442,y:252,t:1527019751501};\\\", \\\"{x:1418,y:286,t:1527019751517};\\\", \\\"{x:1393,y:332,t:1527019751533};\\\", \\\"{x:1368,y:373,t:1527019751550};\\\", \\\"{x:1348,y:410,t:1527019751567};\\\", \\\"{x:1341,y:429,t:1527019751584};\\\", \\\"{x:1338,y:435,t:1527019751601};\\\", \\\"{x:1338,y:437,t:1527019751617};\\\", \\\"{x:1338,y:438,t:1527019751710};\\\", \\\"{x:1338,y:440,t:1527019751718};\\\", \\\"{x:1338,y:450,t:1527019751734};\\\", \\\"{x:1337,y:464,t:1527019751751};\\\", \\\"{x:1337,y:479,t:1527019751767};\\\", \\\"{x:1337,y:492,t:1527019751784};\\\", \\\"{x:1337,y:497,t:1527019751800};\\\", \\\"{x:1337,y:500,t:1527019751818};\\\", \\\"{x:1337,y:502,t:1527019751834};\\\", \\\"{x:1337,y:503,t:1527019751851};\\\", \\\"{x:1336,y:504,t:1527019751966};\\\", \\\"{x:1335,y:504,t:1527019751990};\\\", \\\"{x:1334,y:504,t:1527019752000};\\\", \\\"{x:1331,y:504,t:1527019752018};\\\", \\\"{x:1330,y:503,t:1527019752038};\\\", \\\"{x:1329,y:503,t:1527019752051};\\\", \\\"{x:1326,y:502,t:1527019752068};\\\", \\\"{x:1325,y:502,t:1527019752085};\\\", \\\"{x:1322,y:500,t:1527019752102};\\\", \\\"{x:1321,y:500,t:1527019752118};\\\", \\\"{x:1319,y:500,t:1527019752136};\\\", \\\"{x:1318,y:500,t:1527019752167};\\\", \\\"{x:1316,y:500,t:1527019752319};\\\", \\\"{x:1315,y:500,t:1527019752350};\\\", \\\"{x:1313,y:500,t:1527019752357};\\\", \\\"{x:1311,y:499,t:1527019752382};\\\", \\\"{x:1311,y:501,t:1527019758030};\\\", \\\"{x:1309,y:504,t:1527019758040};\\\", \\\"{x:1308,y:509,t:1527019758055};\\\", \\\"{x:1307,y:513,t:1527019758072};\\\", \\\"{x:1307,y:514,t:1527019758089};\\\", \\\"{x:1307,y:515,t:1527019758106};\\\", \\\"{x:1307,y:516,t:1527019758125};\\\", \\\"{x:1307,y:517,t:1527019758141};\\\", \\\"{x:1306,y:518,t:1527019758156};\\\", \\\"{x:1306,y:520,t:1527019758173};\\\", \\\"{x:1305,y:522,t:1527019758190};\\\", \\\"{x:1305,y:524,t:1527019758205};\\\", \\\"{x:1304,y:527,t:1527019758223};\\\", \\\"{x:1304,y:530,t:1527019758240};\\\", \\\"{x:1304,y:535,t:1527019758256};\\\", \\\"{x:1303,y:537,t:1527019758272};\\\", \\\"{x:1302,y:542,t:1527019758290};\\\", \\\"{x:1301,y:547,t:1527019758307};\\\", \\\"{x:1300,y:553,t:1527019758323};\\\", \\\"{x:1300,y:559,t:1527019758340};\\\", \\\"{x:1300,y:571,t:1527019758357};\\\", \\\"{x:1300,y:584,t:1527019758373};\\\", \\\"{x:1300,y:601,t:1527019758391};\\\", \\\"{x:1300,y:610,t:1527019758407};\\\", \\\"{x:1300,y:616,t:1527019758423};\\\", \\\"{x:1300,y:622,t:1527019758439};\\\", \\\"{x:1300,y:627,t:1527019758457};\\\", \\\"{x:1300,y:629,t:1527019758472};\\\", \\\"{x:1300,y:632,t:1527019758489};\\\", \\\"{x:1300,y:635,t:1527019758507};\\\", \\\"{x:1300,y:638,t:1527019758522};\\\", \\\"{x:1299,y:639,t:1527019758539};\\\", \\\"{x:1299,y:640,t:1527019758556};\\\", \\\"{x:1299,y:641,t:1527019758573};\\\", \\\"{x:1299,y:642,t:1527019758590};\\\", \\\"{x:1299,y:644,t:1527019758607};\\\", \\\"{x:1299,y:645,t:1527019758623};\\\", \\\"{x:1299,y:648,t:1527019758640};\\\", \\\"{x:1299,y:655,t:1527019758657};\\\", \\\"{x:1299,y:658,t:1527019758674};\\\", \\\"{x:1300,y:663,t:1527019758689};\\\", \\\"{x:1302,y:669,t:1527019758706};\\\", \\\"{x:1302,y:673,t:1527019758724};\\\", \\\"{x:1302,y:679,t:1527019758740};\\\", \\\"{x:1303,y:684,t:1527019758757};\\\", \\\"{x:1304,y:690,t:1527019758774};\\\", \\\"{x:1305,y:693,t:1527019758790};\\\", \\\"{x:1305,y:698,t:1527019758807};\\\", \\\"{x:1306,y:703,t:1527019758823};\\\", \\\"{x:1307,y:706,t:1527019758840};\\\", \\\"{x:1308,y:710,t:1527019758857};\\\", \\\"{x:1309,y:715,t:1527019758873};\\\", \\\"{x:1309,y:718,t:1527019758890};\\\", \\\"{x:1310,y:722,t:1527019758907};\\\", \\\"{x:1310,y:728,t:1527019758924};\\\", \\\"{x:1311,y:733,t:1527019758941};\\\", \\\"{x:1311,y:741,t:1527019758957};\\\", \\\"{x:1314,y:749,t:1527019758974};\\\", \\\"{x:1315,y:754,t:1527019758990};\\\", \\\"{x:1315,y:759,t:1527019759008};\\\", \\\"{x:1315,y:763,t:1527019759023};\\\", \\\"{x:1317,y:771,t:1527019759041};\\\", \\\"{x:1318,y:781,t:1527019759056};\\\", \\\"{x:1320,y:788,t:1527019759073};\\\", \\\"{x:1320,y:795,t:1527019759091};\\\", \\\"{x:1320,y:801,t:1527019759107};\\\", \\\"{x:1321,y:806,t:1527019759124};\\\", \\\"{x:1321,y:811,t:1527019759141};\\\", \\\"{x:1321,y:818,t:1527019759157};\\\", \\\"{x:1321,y:827,t:1527019759174};\\\", \\\"{x:1322,y:832,t:1527019759191};\\\", \\\"{x:1322,y:840,t:1527019759207};\\\", \\\"{x:1322,y:845,t:1527019759224};\\\", \\\"{x:1322,y:849,t:1527019759241};\\\", \\\"{x:1323,y:851,t:1527019759257};\\\", \\\"{x:1323,y:854,t:1527019759274};\\\", \\\"{x:1323,y:859,t:1527019759291};\\\", \\\"{x:1323,y:862,t:1527019759307};\\\", \\\"{x:1323,y:866,t:1527019759324};\\\", \\\"{x:1322,y:870,t:1527019759341};\\\", \\\"{x:1322,y:873,t:1527019759357};\\\", \\\"{x:1321,y:878,t:1527019759374};\\\", \\\"{x:1321,y:883,t:1527019759391};\\\", \\\"{x:1321,y:886,t:1527019759408};\\\", \\\"{x:1320,y:891,t:1527019759423};\\\", \\\"{x:1320,y:893,t:1527019759441};\\\", \\\"{x:1320,y:897,t:1527019759458};\\\", \\\"{x:1320,y:900,t:1527019759474};\\\", \\\"{x:1320,y:903,t:1527019759491};\\\", \\\"{x:1320,y:906,t:1527019759508};\\\", \\\"{x:1320,y:910,t:1527019759524};\\\", \\\"{x:1320,y:914,t:1527019759540};\\\", \\\"{x:1320,y:922,t:1527019759557};\\\", \\\"{x:1320,y:926,t:1527019759573};\\\", \\\"{x:1320,y:932,t:1527019759591};\\\", \\\"{x:1320,y:935,t:1527019759608};\\\", \\\"{x:1320,y:937,t:1527019759624};\\\", \\\"{x:1320,y:940,t:1527019759641};\\\", \\\"{x:1320,y:946,t:1527019759655};\\\", \\\"{x:1320,y:952,t:1527019759674};\\\", \\\"{x:1320,y:958,t:1527019759691};\\\", \\\"{x:1320,y:964,t:1527019759708};\\\", \\\"{x:1319,y:971,t:1527019759724};\\\", \\\"{x:1319,y:977,t:1527019759740};\\\", \\\"{x:1319,y:978,t:1527019759757};\\\", \\\"{x:1319,y:978,t:1527019759822};\\\", \\\"{x:1319,y:980,t:1527019760214};\\\", \\\"{x:1321,y:983,t:1527019760224};\\\", \\\"{x:1322,y:986,t:1527019760241};\\\", \\\"{x:1325,y:994,t:1527019760258};\\\", \\\"{x:1327,y:998,t:1527019760275};\\\", \\\"{x:1329,y:1002,t:1527019760291};\\\", \\\"{x:1330,y:1004,t:1527019760308};\\\", \\\"{x:1330,y:1005,t:1527019760325};\\\", \\\"{x:1330,y:1007,t:1527019760414};\\\", \\\"{x:1330,y:1006,t:1527019760910};\\\", \\\"{x:1330,y:1004,t:1527019760925};\\\", \\\"{x:1330,y:1001,t:1527019760942};\\\", \\\"{x:1329,y:997,t:1527019760957};\\\", \\\"{x:1326,y:991,t:1527019760975};\\\", \\\"{x:1324,y:985,t:1527019760992};\\\", \\\"{x:1324,y:983,t:1527019761008};\\\", \\\"{x:1323,y:982,t:1527019761030};\\\", \\\"{x:1323,y:981,t:1527019761046};\\\", \\\"{x:1315,y:976,t:1527019761239};\\\", \\\"{x:1294,y:962,t:1527019761246};\\\", \\\"{x:1248,y:942,t:1527019761259};\\\", \\\"{x:1138,y:894,t:1527019761275};\\\", \\\"{x:1014,y:843,t:1527019761292};\\\", \\\"{x:888,y:794,t:1527019761309};\\\", \\\"{x:794,y:770,t:1527019761325};\\\", \\\"{x:685,y:773,t:1527019761341};\\\", \\\"{x:661,y:773,t:1527019761359};\\\", \\\"{x:653,y:773,t:1527019761375};\\\", \\\"{x:652,y:773,t:1527019761392};\\\", \\\"{x:654,y:772,t:1527019761494};\\\", \\\"{x:659,y:770,t:1527019761509};\\\", \\\"{x:671,y:761,t:1527019761526};\\\", \\\"{x:679,y:754,t:1527019761542};\\\", \\\"{x:687,y:747,t:1527019761559};\\\", \\\"{x:694,y:738,t:1527019761575};\\\", \\\"{x:699,y:730,t:1527019761592};\\\", \\\"{x:702,y:725,t:1527019761608};\\\", \\\"{x:704,y:721,t:1527019761626};\\\", \\\"{x:705,y:717,t:1527019761641};\\\", \\\"{x:705,y:716,t:1527019761659};\\\", \\\"{x:705,y:715,t:1527019761676};\\\", \\\"{x:705,y:713,t:1527019761694};\\\", \\\"{x:705,y:711,t:1527019761709};\\\", \\\"{x:705,y:709,t:1527019761726};\\\", \\\"{x:707,y:705,t:1527019761742};\\\", \\\"{x:718,y:698,t:1527019761759};\\\", \\\"{x:736,y:689,t:1527019761776};\\\", \\\"{x:753,y:678,t:1527019761793};\\\", \\\"{x:775,y:667,t:1527019761809};\\\", \\\"{x:792,y:656,t:1527019761826};\\\", \\\"{x:808,y:646,t:1527019761842};\\\", \\\"{x:825,y:638,t:1527019761859};\\\", \\\"{x:837,y:631,t:1527019761876};\\\", \\\"{x:842,y:628,t:1527019761892};\\\", \\\"{x:845,y:627,t:1527019761909};\\\", \\\"{x:845,y:626,t:1527019762056};\\\", \\\"{x:843,y:624,t:1527019762076};\\\", \\\"{x:841,y:623,t:1527019762092};\\\", \\\"{x:840,y:622,t:1527019762108};\\\", \\\"{x:827,y:613,t:1527019762125};\\\", \\\"{x:820,y:609,t:1527019762142};\\\", \\\"{x:813,y:607,t:1527019762158};\\\", \\\"{x:807,y:604,t:1527019762175};\\\", \\\"{x:798,y:601,t:1527019762192};\\\", \\\"{x:786,y:597,t:1527019762209};\\\", \\\"{x:776,y:596,t:1527019762225};\\\", \\\"{x:760,y:595,t:1527019762243};\\\", \\\"{x:747,y:595,t:1527019762259};\\\", \\\"{x:731,y:595,t:1527019762276};\\\", \\\"{x:714,y:595,t:1527019762292};\\\", \\\"{x:686,y:595,t:1527019762309};\\\", \\\"{x:667,y:592,t:1527019762326};\\\", \\\"{x:647,y:592,t:1527019762343};\\\", \\\"{x:633,y:592,t:1527019762360};\\\", \\\"{x:625,y:591,t:1527019762375};\\\", \\\"{x:624,y:591,t:1527019762392};\\\", \\\"{x:623,y:591,t:1527019762409};\\\", \\\"{x:622,y:591,t:1527019762470};\\\", \\\"{x:620,y:591,t:1527019762486};\\\", \\\"{x:619,y:593,t:1527019762493};\\\", \\\"{x:618,y:594,t:1527019762510};\\\", \\\"{x:618,y:597,t:1527019762528};\\\", \\\"{x:617,y:599,t:1527019762543};\\\", \\\"{x:623,y:607,t:1527019762560};\\\", \\\"{x:635,y:614,t:1527019762576};\\\", \\\"{x:654,y:623,t:1527019762592};\\\", \\\"{x:671,y:629,t:1527019762610};\\\", \\\"{x:715,y:642,t:1527019762627};\\\", \\\"{x:808,y:660,t:1527019762643};\\\", \\\"{x:910,y:671,t:1527019762660};\\\", \\\"{x:997,y:675,t:1527019762677};\\\", \\\"{x:1053,y:675,t:1527019762692};\\\", \\\"{x:1117,y:675,t:1527019762710};\\\", \\\"{x:1148,y:675,t:1527019762726};\\\", \\\"{x:1175,y:669,t:1527019762744};\\\", \\\"{x:1204,y:660,t:1527019762759};\\\", \\\"{x:1231,y:649,t:1527019762777};\\\", \\\"{x:1253,y:636,t:1527019762794};\\\", \\\"{x:1265,y:625,t:1527019762810};\\\", \\\"{x:1280,y:607,t:1527019762827};\\\", \\\"{x:1300,y:591,t:1527019762844};\\\", \\\"{x:1323,y:571,t:1527019762860};\\\", \\\"{x:1346,y:552,t:1527019762877};\\\", \\\"{x:1361,y:532,t:1527019762894};\\\", \\\"{x:1370,y:517,t:1527019762911};\\\", \\\"{x:1376,y:503,t:1527019762927};\\\", \\\"{x:1383,y:490,t:1527019762944};\\\", \\\"{x:1390,y:481,t:1527019762961};\\\", \\\"{x:1395,y:473,t:1527019762978};\\\", \\\"{x:1396,y:470,t:1527019762994};\\\", \\\"{x:1396,y:467,t:1527019763011};\\\", \\\"{x:1396,y:465,t:1527019763028};\\\", \\\"{x:1396,y:463,t:1527019763044};\\\", \\\"{x:1391,y:461,t:1527019763061};\\\", \\\"{x:1370,y:452,t:1527019763077};\\\", \\\"{x:1346,y:441,t:1527019763095};\\\", \\\"{x:1325,y:436,t:1527019763111};\\\", \\\"{x:1322,y:436,t:1527019763128};\\\", \\\"{x:1321,y:436,t:1527019763145};\\\", \\\"{x:1321,y:437,t:1527019763182};\\\", \\\"{x:1321,y:446,t:1527019763195};\\\", \\\"{x:1321,y:470,t:1527019763212};\\\", \\\"{x:1321,y:487,t:1527019763228};\\\", \\\"{x:1323,y:504,t:1527019763245};\\\", \\\"{x:1323,y:523,t:1527019763262};\\\", \\\"{x:1323,y:534,t:1527019763280};\\\", \\\"{x:1323,y:549,t:1527019763295};\\\", \\\"{x:1324,y:570,t:1527019763312};\\\", \\\"{x:1324,y:593,t:1527019763329};\\\", \\\"{x:1324,y:621,t:1527019763345};\\\", \\\"{x:1322,y:653,t:1527019763362};\\\", \\\"{x:1317,y:687,t:1527019763379};\\\", \\\"{x:1315,y:713,t:1527019763395};\\\", \\\"{x:1311,y:740,t:1527019763411};\\\", \\\"{x:1310,y:760,t:1527019763429};\\\", \\\"{x:1310,y:780,t:1527019763445};\\\", \\\"{x:1310,y:786,t:1527019763461};\\\", \\\"{x:1310,y:791,t:1527019763478};\\\", \\\"{x:1310,y:797,t:1527019763496};\\\", \\\"{x:1310,y:809,t:1527019763513};\\\", \\\"{x:1310,y:817,t:1527019763528};\\\", \\\"{x:1312,y:829,t:1527019763546};\\\", \\\"{x:1316,y:842,t:1527019763563};\\\", \\\"{x:1321,y:857,t:1527019763579};\\\", \\\"{x:1324,y:870,t:1527019763596};\\\", \\\"{x:1326,y:884,t:1527019763613};\\\", \\\"{x:1329,y:909,t:1527019763630};\\\", \\\"{x:1332,y:928,t:1527019763646};\\\", \\\"{x:1332,y:946,t:1527019763663};\\\", \\\"{x:1333,y:961,t:1527019763680};\\\", \\\"{x:1333,y:976,t:1527019763697};\\\", \\\"{x:1333,y:983,t:1527019763713};\\\", \\\"{x:1332,y:987,t:1527019763730};\\\", \\\"{x:1331,y:990,t:1527019763746};\\\", \\\"{x:1330,y:992,t:1527019763773};\\\", \\\"{x:1328,y:992,t:1527019763838};\\\", \\\"{x:1328,y:993,t:1527019763869};\\\", \\\"{x:1327,y:993,t:1527019763893};\\\", \\\"{x:1324,y:993,t:1527019763901};\\\", \\\"{x:1320,y:991,t:1527019763914};\\\", \\\"{x:1306,y:983,t:1527019763931};\\\", \\\"{x:1294,y:974,t:1527019763947};\\\", \\\"{x:1293,y:972,t:1527019763964};\\\", \\\"{x:1294,y:972,t:1527019764085};\\\", \\\"{x:1295,y:972,t:1527019764098};\\\", \\\"{x:1303,y:976,t:1527019764115};\\\", \\\"{x:1305,y:978,t:1527019764131};\\\", \\\"{x:1305,y:979,t:1527019764148};\\\", \\\"{x:1306,y:980,t:1527019764165};\\\", \\\"{x:1307,y:979,t:1527019764262};\\\", \\\"{x:1307,y:978,t:1527019764278};\\\", \\\"{x:1308,y:973,t:1527019764285};\\\", \\\"{x:1308,y:972,t:1527019764301};\\\", \\\"{x:1308,y:971,t:1527019764314};\\\", \\\"{x:1308,y:969,t:1527019764332};\\\", \\\"{x:1308,y:968,t:1527019764349};\\\", \\\"{x:1308,y:967,t:1527019764390};\\\", \\\"{x:1308,y:966,t:1527019764606};\\\", \\\"{x:1308,y:965,t:1527019764629};\\\", \\\"{x:1309,y:964,t:1527019764855};\\\", \\\"{x:1311,y:964,t:1527019764867};\\\", \\\"{x:1313,y:964,t:1527019764884};\\\", \\\"{x:1314,y:964,t:1527019764918};\\\", \\\"{x:1316,y:964,t:1527019778447};\\\", \\\"{x:1321,y:964,t:1527019778461};\\\", \\\"{x:1322,y:965,t:1527019778478};\\\", \\\"{x:1324,y:965,t:1527019778495};\\\", \\\"{x:1327,y:966,t:1527019778512};\\\", \\\"{x:1330,y:968,t:1527019778528};\\\", \\\"{x:1333,y:969,t:1527019778545};\\\", \\\"{x:1337,y:972,t:1527019778562};\\\", \\\"{x:1341,y:973,t:1527019778579};\\\", \\\"{x:1349,y:977,t:1527019778595};\\\", \\\"{x:1357,y:981,t:1527019778612};\\\", \\\"{x:1363,y:982,t:1527019778628};\\\", \\\"{x:1366,y:984,t:1527019778645};\\\", \\\"{x:1374,y:985,t:1527019778663};\\\", \\\"{x:1384,y:988,t:1527019778679};\\\", \\\"{x:1397,y:990,t:1527019778696};\\\", \\\"{x:1411,y:993,t:1527019778711};\\\", \\\"{x:1427,y:995,t:1527019778729};\\\", \\\"{x:1442,y:998,t:1527019778746};\\\", \\\"{x:1455,y:1001,t:1527019778762};\\\", \\\"{x:1474,y:1005,t:1527019778779};\\\", \\\"{x:1489,y:1006,t:1527019778796};\\\", \\\"{x:1513,y:1010,t:1527019778813};\\\", \\\"{x:1529,y:1011,t:1527019778828};\\\", \\\"{x:1552,y:1012,t:1527019778846};\\\", \\\"{x:1561,y:1012,t:1527019778863};\\\", \\\"{x:1566,y:1012,t:1527019778879};\\\", \\\"{x:1568,y:1012,t:1527019778896};\\\", \\\"{x:1569,y:1012,t:1527019778918};\\\", \\\"{x:1570,y:1011,t:1527019778942};\\\", \\\"{x:1571,y:1010,t:1527019778950};\\\", \\\"{x:1572,y:1009,t:1527019778963};\\\", \\\"{x:1574,y:1007,t:1527019778980};\\\", \\\"{x:1576,y:1006,t:1527019778997};\\\", \\\"{x:1576,y:1005,t:1527019779013};\\\", \\\"{x:1576,y:1002,t:1527019779030};\\\", \\\"{x:1576,y:998,t:1527019779047};\\\", \\\"{x:1575,y:992,t:1527019779063};\\\", \\\"{x:1574,y:990,t:1527019779080};\\\", \\\"{x:1573,y:989,t:1527019779109};\\\", \\\"{x:1571,y:988,t:1527019779133};\\\", \\\"{x:1571,y:987,t:1527019779147};\\\", \\\"{x:1570,y:987,t:1527019779164};\\\", \\\"{x:1568,y:985,t:1527019779180};\\\", \\\"{x:1568,y:984,t:1527019779197};\\\", \\\"{x:1567,y:983,t:1527019779214};\\\", \\\"{x:1566,y:980,t:1527019779231};\\\", \\\"{x:1565,y:977,t:1527019779247};\\\", \\\"{x:1563,y:972,t:1527019779264};\\\", \\\"{x:1560,y:969,t:1527019779281};\\\", \\\"{x:1557,y:965,t:1527019779298};\\\", \\\"{x:1557,y:963,t:1527019779315};\\\", \\\"{x:1556,y:962,t:1527019779342};\\\", \\\"{x:1556,y:961,t:1527019779366};\\\", \\\"{x:1556,y:960,t:1527019779380};\\\", \\\"{x:1555,y:958,t:1527019779397};\\\", \\\"{x:1554,y:957,t:1527019779415};\\\", \\\"{x:1554,y:956,t:1527019779431};\\\", \\\"{x:1553,y:953,t:1527019779447};\\\", \\\"{x:1553,y:952,t:1527019779464};\\\", \\\"{x:1553,y:948,t:1527019779480};\\\", \\\"{x:1553,y:945,t:1527019779497};\\\", \\\"{x:1552,y:936,t:1527019779514};\\\", \\\"{x:1552,y:925,t:1527019779532};\\\", \\\"{x:1550,y:914,t:1527019779547};\\\", \\\"{x:1550,y:899,t:1527019779564};\\\", \\\"{x:1550,y:885,t:1527019779581};\\\", \\\"{x:1550,y:876,t:1527019779598};\\\", \\\"{x:1551,y:870,t:1527019779615};\\\", \\\"{x:1552,y:859,t:1527019779632};\\\", \\\"{x:1555,y:843,t:1527019779648};\\\", \\\"{x:1557,y:830,t:1527019779665};\\\", \\\"{x:1560,y:819,t:1527019779682};\\\", \\\"{x:1561,y:806,t:1527019779698};\\\", \\\"{x:1562,y:797,t:1527019779716};\\\", \\\"{x:1565,y:784,t:1527019779732};\\\", \\\"{x:1565,y:775,t:1527019779749};\\\", \\\"{x:1565,y:766,t:1527019779765};\\\", \\\"{x:1566,y:759,t:1527019779782};\\\", \\\"{x:1566,y:751,t:1527019779799};\\\", \\\"{x:1566,y:746,t:1527019779815};\\\", \\\"{x:1566,y:743,t:1527019779832};\\\", \\\"{x:1566,y:735,t:1527019779848};\\\", \\\"{x:1566,y:728,t:1527019779865};\\\", \\\"{x:1566,y:722,t:1527019779882};\\\", \\\"{x:1566,y:714,t:1527019779898};\\\", \\\"{x:1566,y:705,t:1527019779916};\\\", \\\"{x:1566,y:699,t:1527019779932};\\\", \\\"{x:1565,y:694,t:1527019779949};\\\", \\\"{x:1565,y:689,t:1527019779965};\\\", \\\"{x:1564,y:687,t:1527019779983};\\\", \\\"{x:1563,y:684,t:1527019779999};\\\", \\\"{x:1561,y:681,t:1527019780016};\\\", \\\"{x:1561,y:679,t:1527019780033};\\\", \\\"{x:1560,y:677,t:1527019780049};\\\", \\\"{x:1560,y:676,t:1527019780069};\\\", \\\"{x:1560,y:674,t:1527019780085};\\\", \\\"{x:1560,y:672,t:1527019780100};\\\", \\\"{x:1560,y:671,t:1527019780117};\\\", \\\"{x:1560,y:668,t:1527019780134};\\\", \\\"{x:1559,y:665,t:1527019780150};\\\", \\\"{x:1559,y:664,t:1527019780167};\\\", \\\"{x:1559,y:663,t:1527019780183};\\\", \\\"{x:1559,y:662,t:1527019780200};\\\", \\\"{x:1557,y:662,t:1527019780318};\\\", \\\"{x:1530,y:673,t:1527019780334};\\\", \\\"{x:1410,y:698,t:1527019780351};\\\", \\\"{x:1234,y:709,t:1527019780368};\\\", \\\"{x:1035,y:709,t:1527019780384};\\\", \\\"{x:817,y:703,t:1527019780400};\\\", \\\"{x:606,y:696,t:1527019780417};\\\", \\\"{x:488,y:686,t:1527019780434};\\\", \\\"{x:473,y:682,t:1527019780450};\\\", \\\"{x:476,y:682,t:1527019780598};\\\", \\\"{x:480,y:682,t:1527019780606};\\\", \\\"{x:488,y:682,t:1527019780618};\\\", \\\"{x:504,y:680,t:1527019780635};\\\", \\\"{x:517,y:674,t:1527019780652};\\\", \\\"{x:519,y:670,t:1527019780669};\\\", \\\"{x:519,y:658,t:1527019780686};\\\", \\\"{x:497,y:629,t:1527019780702};\\\", \\\"{x:474,y:612,t:1527019780718};\\\", \\\"{x:460,y:604,t:1527019780736};\\\", \\\"{x:458,y:603,t:1527019780753};\\\", \\\"{x:456,y:602,t:1527019780805};\\\", \\\"{x:455,y:602,t:1527019780820};\\\", \\\"{x:452,y:602,t:1527019780836};\\\", \\\"{x:445,y:599,t:1527019780853};\\\", \\\"{x:440,y:599,t:1527019780870};\\\", \\\"{x:437,y:599,t:1527019780886};\\\", \\\"{x:433,y:599,t:1527019780903};\\\", \\\"{x:429,y:599,t:1527019780919};\\\", \\\"{x:424,y:599,t:1527019780936};\\\", \\\"{x:423,y:599,t:1527019780952};\\\", \\\"{x:422,y:599,t:1527019780981};\\\", \\\"{x:421,y:600,t:1527019781014};\\\", \\\"{x:420,y:604,t:1527019781334};\\\", \\\"{x:421,y:618,t:1527019781341};\\\", \\\"{x:425,y:627,t:1527019781352};\\\", \\\"{x:431,y:648,t:1527019781369};\\\", \\\"{x:444,y:674,t:1527019781394};\\\", \\\"{x:451,y:685,t:1527019781409};\\\", \\\"{x:456,y:691,t:1527019781425};\\\", \\\"{x:457,y:692,t:1527019781442};\\\", \\\"{x:452,y:692,t:1527019781518};\\\", \\\"{x:442,y:688,t:1527019781525};\\\", \\\"{x:419,y:679,t:1527019781543};\\\", \\\"{x:407,y:674,t:1527019781558};\\\", \\\"{x:403,y:673,t:1527019781575};\\\", \\\"{x:400,y:672,t:1527019781592};\\\", \\\"{x:399,y:671,t:1527019781608};\\\", \\\"{x:397,y:668,t:1527019781625};\\\", \\\"{x:396,y:660,t:1527019781643};\\\", \\\"{x:392,y:648,t:1527019781658};\\\", \\\"{x:391,y:640,t:1527019781675};\\\", \\\"{x:391,y:634,t:1527019781693};\\\", \\\"{x:391,y:630,t:1527019781709};\\\", \\\"{x:392,y:627,t:1527019781725};\\\", \\\"{x:392,y:624,t:1527019781743};\\\", \\\"{x:392,y:616,t:1527019781758};\\\", \\\"{x:389,y:613,t:1527019781775};\\\", \\\"{x:388,y:610,t:1527019781797};\\\", \\\"{x:387,y:610,t:1527019781808};\\\", \\\"{x:387,y:609,t:1527019781826};\\\", \\\"{x:387,y:607,t:1527019782502};\\\", \\\"{x:398,y:606,t:1527019782510};\\\", \\\"{x:475,y:632,t:1527019782529};\\\", \\\"{x:612,y:687,t:1527019782543};\\\", \\\"{x:759,y:733,t:1527019782560};\\\", \\\"{x:894,y:767,t:1527019782577};\\\", \\\"{x:996,y:779,t:1527019782593};\\\", \\\"{x:1056,y:785,t:1527019782610};\\\", \\\"{x:1081,y:785,t:1527019782627};\\\", \\\"{x:1095,y:784,t:1527019782643};\\\", \\\"{x:1106,y:781,t:1527019782659};\\\", \\\"{x:1109,y:779,t:1527019782677};\\\", \\\"{x:1110,y:778,t:1527019782693};\\\", \\\"{x:1116,y:771,t:1527019782710};\\\", \\\"{x:1122,y:756,t:1527019782727};\\\", \\\"{x:1128,y:739,t:1527019782742};\\\", \\\"{x:1143,y:717,t:1527019782760};\\\", \\\"{x:1159,y:701,t:1527019782777};\\\", \\\"{x:1176,y:691,t:1527019782793};\\\", \\\"{x:1194,y:676,t:1527019782810};\\\", \\\"{x:1217,y:666,t:1527019782827};\\\", \\\"{x:1246,y:655,t:1527019782844};\\\", \\\"{x:1272,y:650,t:1527019782860};\\\", \\\"{x:1292,y:645,t:1527019782877};\\\", \\\"{x:1310,y:643,t:1527019782893};\\\", \\\"{x:1319,y:642,t:1527019782909};\\\", \\\"{x:1321,y:641,t:1527019782927};\\\", \\\"{x:1322,y:641,t:1527019782944};\\\", \\\"{x:1323,y:641,t:1527019782960};\\\", \\\"{x:1323,y:642,t:1527019782977};\\\", \\\"{x:1306,y:650,t:1527019782994};\\\", \\\"{x:1267,y:669,t:1527019783010};\\\", \\\"{x:1199,y:691,t:1527019783027};\\\", \\\"{x:1113,y:718,t:1527019783043};\\\", \\\"{x:1046,y:749,t:1527019783059};\\\", \\\"{x:1000,y:778,t:1527019783077};\\\", \\\"{x:955,y:805,t:1527019783093};\\\", \\\"{x:934,y:814,t:1527019783109};\\\", \\\"{x:915,y:819,t:1527019783126};\\\", \\\"{x:900,y:823,t:1527019783143};\\\", \\\"{x:885,y:826,t:1527019783160};\\\", \\\"{x:869,y:828,t:1527019783176};\\\", \\\"{x:850,y:832,t:1527019783194};\\\", \\\"{x:833,y:836,t:1527019783209};\\\", \\\"{x:823,y:837,t:1527019783226};\\\", \\\"{x:817,y:837,t:1527019783243};\\\", \\\"{x:808,y:840,t:1527019783260};\\\", \\\"{x:798,y:840,t:1527019783277};\\\", \\\"{x:780,y:839,t:1527019783293};\\\", \\\"{x:762,y:832,t:1527019783311};\\\", \\\"{x:744,y:825,t:1527019783326};\\\", \\\"{x:731,y:822,t:1527019783344};\\\", \\\"{x:722,y:819,t:1527019783361};\\\", \\\"{x:719,y:818,t:1527019783377};\\\", \\\"{x:715,y:816,t:1527019783393};\\\", \\\"{x:711,y:815,t:1527019783410};\\\", \\\"{x:707,y:815,t:1527019783427};\\\", \\\"{x:700,y:812,t:1527019783443};\\\", \\\"{x:695,y:811,t:1527019783461};\\\", \\\"{x:690,y:810,t:1527019783477};\\\", \\\"{x:686,y:808,t:1527019783493};\\\", \\\"{x:684,y:808,t:1527019783510};\\\", \\\"{x:680,y:808,t:1527019783526};\\\", \\\"{x:677,y:808,t:1527019783543};\\\", \\\"{x:674,y:806,t:1527019783560};\\\", \\\"{x:672,y:805,t:1527019783576};\\\", \\\"{x:670,y:804,t:1527019783593};\\\", \\\"{x:664,y:804,t:1527019783611};\\\", \\\"{x:649,y:804,t:1527019783627};\\\", \\\"{x:639,y:804,t:1527019783644};\\\", \\\"{x:634,y:803,t:1527019783660};\\\", \\\"{x:632,y:801,t:1527019783677};\\\", \\\"{x:631,y:801,t:1527019783709};\\\", \\\"{x:629,y:800,t:1527019783717};\\\", \\\"{x:625,y:798,t:1527019783727};\\\", \\\"{x:615,y:789,t:1527019783743};\\\", \\\"{x:601,y:777,t:1527019783761};\\\", \\\"{x:581,y:760,t:1527019783778};\\\", \\\"{x:565,y:745,t:1527019783793};\\\", \\\"{x:552,y:734,t:1527019783811};\\\", \\\"{x:548,y:727,t:1527019783828};\\\", \\\"{x:547,y:727,t:1527019783843};\\\", \\\"{x:546,y:725,t:1527019783861};\\\", \\\"{x:546,y:724,t:1527019783997};\\\", \\\"{x:546,y:723,t:1527019784125};\\\", \\\"{x:545,y:723,t:1527019786886};\\\", \\\"{x:537,y:723,t:1527019786896};\\\", \\\"{x:511,y:716,t:1527019786913};\\\", \\\"{x:474,y:705,t:1527019786930};\\\", \\\"{x:451,y:699,t:1527019786947};\\\", \\\"{x:436,y:694,t:1527019786963};\\\", \\\"{x:433,y:694,t:1527019786980};\\\", \\\"{x:432,y:693,t:1527019786997};\\\", \\\"{x:430,y:693,t:1527019787125};\\\", \\\"{x:427,y:691,t:1527019787133};\\\", \\\"{x:424,y:685,t:1527019787147};\\\", \\\"{x:423,y:681,t:1527019787164};\\\", \\\"{x:423,y:678,t:1527019787180};\\\", \\\"{x:425,y:676,t:1527019787197};\\\", \\\"{x:425,y:672,t:1527019787213};\\\", \\\"{x:425,y:665,t:1527019787230};\\\", \\\"{x:425,y:659,t:1527019787248};\\\", \\\"{x:419,y:653,t:1527019787263};\\\", \\\"{x:415,y:649,t:1527019787281};\\\", \\\"{x:411,y:646,t:1527019787296};\\\", \\\"{x:410,y:645,t:1527019787313};\\\", \\\"{x:410,y:642,t:1527019787331};\\\", \\\"{x:407,y:638,t:1527019787346};\\\", \\\"{x:401,y:627,t:1527019787365};\\\", \\\"{x:391,y:609,t:1527019787382};\\\", \\\"{x:387,y:602,t:1527019787397};\\\", \\\"{x:387,y:598,t:1527019787414};\\\", \\\"{x:388,y:595,t:1527019787432};\\\", \\\"{x:390,y:594,t:1527019787447};\\\", \\\"{x:392,y:592,t:1527019787464};\\\", \\\"{x:393,y:591,t:1527019787481};\\\", \\\"{x:393,y:590,t:1527019787498};\\\", \\\"{x:393,y:589,t:1527019787533};\\\", \\\"{x:392,y:590,t:1527019787653};\\\", \\\"{x:389,y:590,t:1527019787666};\\\", \\\"{x:387,y:593,t:1527019787681};\\\", \\\"{x:385,y:593,t:1527019787698};\\\", \\\"{x:382,y:595,t:1527019787715};\\\", \\\"{x:381,y:596,t:1527019787733};\\\", \\\"{x:380,y:596,t:1527019787821};\\\", \\\"{x:380,y:598,t:1527019787832};\\\", \\\"{x:379,y:600,t:1527019787850};\\\", \\\"{x:379,y:603,t:1527019787865};\\\", \\\"{x:379,y:605,t:1527019787881};\\\", \\\"{x:379,y:608,t:1527019787898};\\\", \\\"{x:379,y:611,t:1527019787915};\\\", \\\"{x:379,y:612,t:1527019787931};\\\", \\\"{x:379,y:613,t:1527019788293};\\\", \\\"{x:387,y:611,t:1527019788301};\\\", \\\"{x:394,y:607,t:1527019788315};\\\", \\\"{x:417,y:596,t:1527019788331};\\\", \\\"{x:479,y:584,t:1527019788348};\\\", \\\"{x:594,y:574,t:1527019788365};\\\", \\\"{x:682,y:565,t:1527019788382};\\\", \\\"{x:755,y:550,t:1527019788398};\\\", \\\"{x:817,y:540,t:1527019788414};\\\", \\\"{x:878,y:532,t:1527019788432};\\\", \\\"{x:933,y:519,t:1527019788449};\\\", \\\"{x:958,y:511,t:1527019788464};\\\", \\\"{x:982,y:501,t:1527019788482};\\\", \\\"{x:1013,y:494,t:1527019788498};\\\", \\\"{x:1045,y:483,t:1527019788515};\\\", \\\"{x:1066,y:476,t:1527019788532};\\\", \\\"{x:1087,y:469,t:1527019788548};\\\", \\\"{x:1111,y:462,t:1527019788565};\\\", \\\"{x:1125,y:455,t:1527019788581};\\\", \\\"{x:1145,y:449,t:1527019788598};\\\", \\\"{x:1218,y:443,t:1527019788615};\\\", \\\"{x:1287,y:436,t:1527019788632};\\\", \\\"{x:1335,y:434,t:1527019788648};\\\", \\\"{x:1375,y:435,t:1527019788665};\\\", \\\"{x:1391,y:435,t:1527019788682};\\\", \\\"{x:1391,y:436,t:1527019788698};\\\", \\\"{x:1394,y:440,t:1527019788715};\\\", \\\"{x:1403,y:448,t:1527019788732};\\\", \\\"{x:1404,y:448,t:1527019788748};\\\", \\\"{x:1400,y:450,t:1527019788789};\\\", \\\"{x:1392,y:454,t:1527019788798};\\\", \\\"{x:1370,y:462,t:1527019788815};\\\", \\\"{x:1350,y:473,t:1527019788832};\\\", \\\"{x:1337,y:478,t:1527019788848};\\\", \\\"{x:1337,y:479,t:1527019788918};\\\", \\\"{x:1335,y:479,t:1527019789102};\\\", \\\"{x:1330,y:479,t:1527019789115};\\\", \\\"{x:1327,y:478,t:1527019789133};\\\", \\\"{x:1324,y:480,t:1527019789334};\\\", \\\"{x:1323,y:484,t:1527019789350};\\\", \\\"{x:1322,y:486,t:1527019789366};\\\", \\\"{x:1322,y:487,t:1527019789383};\\\", \\\"{x:1321,y:488,t:1527019789400};\\\", \\\"{x:1320,y:488,t:1527019789415};\\\", \\\"{x:1320,y:489,t:1527019789478};\\\", \\\"{x:1319,y:489,t:1527019789494};\\\", \\\"{x:1316,y:489,t:1527019789502};\\\", \\\"{x:1312,y:489,t:1527019789515};\\\", \\\"{x:1309,y:490,t:1527019789533};\\\", \\\"{x:1306,y:490,t:1527019789550};\\\", \\\"{x:1304,y:490,t:1527019789733};\\\", \\\"{x:1302,y:492,t:1527019789749};\\\", \\\"{x:1302,y:493,t:1527019790302};\\\", \\\"{x:1302,y:495,t:1527019790317};\\\", \\\"{x:1302,y:498,t:1527019790333};\\\", \\\"{x:1303,y:502,t:1527019790350};\\\", \\\"{x:1303,y:504,t:1527019790367};\\\", \\\"{x:1304,y:504,t:1527019790590};\\\", \\\"{x:1305,y:504,t:1527019790599};\\\", \\\"{x:1307,y:503,t:1527019790616};\\\", \\\"{x:1309,y:503,t:1527019790634};\\\", \\\"{x:1311,y:503,t:1527019790650};\\\", \\\"{x:1312,y:503,t:1527019790758};\\\", \\\"{x:1313,y:503,t:1527019790766};\\\", \\\"{x:1314,y:503,t:1527019790783};\\\", \\\"{x:1316,y:503,t:1527019790830};\\\", \\\"{x:1316,y:502,t:1527019790870};\\\", \\\"{x:1317,y:502,t:1527019790900};\\\", \\\"{x:1317,y:505,t:1527019791686};\\\", \\\"{x:1317,y:511,t:1527019791700};\\\", \\\"{x:1310,y:535,t:1527019791718};\\\", \\\"{x:1306,y:553,t:1527019791734};\\\", \\\"{x:1303,y:565,t:1527019791751};\\\", \\\"{x:1302,y:571,t:1527019791768};\\\", \\\"{x:1301,y:574,t:1527019791783};\\\", \\\"{x:1301,y:575,t:1527019791801};\\\", \\\"{x:1301,y:578,t:1527019791817};\\\", \\\"{x:1301,y:583,t:1527019791834};\\\", \\\"{x:1299,y:585,t:1527019791851};\\\", \\\"{x:1298,y:586,t:1527019791990};\\\", \\\"{x:1298,y:587,t:1527019792001};\\\", \\\"{x:1298,y:589,t:1527019792017};\\\", \\\"{x:1298,y:590,t:1527019792033};\\\", \\\"{x:1298,y:591,t:1527019792050};\\\", \\\"{x:1298,y:592,t:1527019792068};\\\", \\\"{x:1298,y:593,t:1527019792085};\\\", \\\"{x:1298,y:594,t:1527019792118};\\\", \\\"{x:1299,y:594,t:1527019792253};\\\", \\\"{x:1301,y:594,t:1527019792267};\\\", \\\"{x:1302,y:594,t:1527019792285};\\\", \\\"{x:1304,y:595,t:1527019792366};\\\", \\\"{x:1305,y:597,t:1527019792373};\\\", \\\"{x:1306,y:599,t:1527019792385};\\\", \\\"{x:1307,y:606,t:1527019792401};\\\", \\\"{x:1309,y:613,t:1527019792418};\\\", \\\"{x:1311,y:620,t:1527019792434};\\\", \\\"{x:1313,y:626,t:1527019792451};\\\", \\\"{x:1313,y:631,t:1527019792468};\\\", \\\"{x:1313,y:634,t:1527019792485};\\\", \\\"{x:1313,y:636,t:1527019792500};\\\", \\\"{x:1313,y:638,t:1527019792518};\\\", \\\"{x:1313,y:639,t:1527019792646};\\\", \\\"{x:1312,y:641,t:1527019792687};\\\", \\\"{x:1312,y:642,t:1527019792701};\\\", \\\"{x:1310,y:647,t:1527019792718};\\\", \\\"{x:1310,y:652,t:1527019792734};\\\", \\\"{x:1310,y:655,t:1527019792751};\\\", \\\"{x:1309,y:659,t:1527019792768};\\\", \\\"{x:1309,y:661,t:1527019792785};\\\", \\\"{x:1308,y:665,t:1527019792800};\\\", \\\"{x:1308,y:669,t:1527019792817};\\\", \\\"{x:1306,y:677,t:1527019792834};\\\", \\\"{x:1306,y:686,t:1527019792851};\\\", \\\"{x:1305,y:696,t:1527019792867};\\\", \\\"{x:1305,y:708,t:1527019792885};\\\", \\\"{x:1304,y:721,t:1527019792900};\\\", \\\"{x:1304,y:732,t:1527019792918};\\\", \\\"{x:1304,y:739,t:1527019792935};\\\", \\\"{x:1305,y:743,t:1527019792950};\\\", \\\"{x:1307,y:750,t:1527019792968};\\\", \\\"{x:1307,y:756,t:1527019792984};\\\", \\\"{x:1309,y:759,t:1527019793000};\\\", \\\"{x:1309,y:761,t:1527019793018};\\\", \\\"{x:1309,y:762,t:1527019793034};\\\", \\\"{x:1309,y:764,t:1527019793052};\\\", \\\"{x:1309,y:765,t:1527019793102};\\\", \\\"{x:1310,y:765,t:1527019793742};\\\", \\\"{x:1311,y:765,t:1527019793797};\\\", \\\"{x:1312,y:765,t:1527019793805};\\\", \\\"{x:1312,y:764,t:1527019793830};\\\", \\\"{x:1313,y:762,t:1527019793838};\\\", \\\"{x:1314,y:761,t:1527019793851};\\\", \\\"{x:1317,y:753,t:1527019793869};\\\", \\\"{x:1320,y:741,t:1527019793885};\\\", \\\"{x:1325,y:716,t:1527019793901};\\\", \\\"{x:1327,y:687,t:1527019793918};\\\", \\\"{x:1327,y:661,t:1527019793934};\\\", \\\"{x:1327,y:640,t:1527019793951};\\\", \\\"{x:1326,y:623,t:1527019793968};\\\", \\\"{x:1325,y:606,t:1527019793985};\\\", \\\"{x:1323,y:592,t:1527019794002};\\\", \\\"{x:1322,y:588,t:1527019794018};\\\", \\\"{x:1321,y:584,t:1527019794034};\\\", \\\"{x:1320,y:581,t:1527019794051};\\\", \\\"{x:1320,y:578,t:1527019794068};\\\", \\\"{x:1320,y:573,t:1527019794084};\\\", \\\"{x:1320,y:558,t:1527019794101};\\\", \\\"{x:1319,y:549,t:1527019794118};\\\", \\\"{x:1318,y:544,t:1527019794134};\\\", \\\"{x:1318,y:540,t:1527019794151};\\\", \\\"{x:1318,y:538,t:1527019794168};\\\", \\\"{x:1318,y:533,t:1527019794184};\\\", \\\"{x:1319,y:525,t:1527019794201};\\\", \\\"{x:1321,y:521,t:1527019794218};\\\", \\\"{x:1321,y:519,t:1527019794234};\\\", \\\"{x:1321,y:517,t:1527019794251};\\\", \\\"{x:1321,y:515,t:1527019794325};\\\", \\\"{x:1321,y:514,t:1527019794357};\\\", \\\"{x:1321,y:512,t:1527019794381};\\\", \\\"{x:1321,y:511,t:1527019794397};\\\", \\\"{x:1321,y:509,t:1527019794430};\\\", \\\"{x:1321,y:508,t:1527019794446};\\\", \\\"{x:1321,y:507,t:1527019794461};\\\", \\\"{x:1321,y:506,t:1527019794477};\\\", \\\"{x:1321,y:505,t:1527019794485};\\\", \\\"{x:1320,y:505,t:1527019794550};\\\", \\\"{x:1327,y:505,t:1527019795061};\\\", \\\"{x:1346,y:506,t:1527019795068};\\\", \\\"{x:1402,y:506,t:1527019795084};\\\", \\\"{x:1468,y:506,t:1527019795102};\\\", \\\"{x:1533,y:506,t:1527019795118};\\\", \\\"{x:1583,y:506,t:1527019795135};\\\", \\\"{x:1613,y:506,t:1527019795152};\\\", \\\"{x:1633,y:506,t:1527019795168};\\\", \\\"{x:1638,y:506,t:1527019795185};\\\", \\\"{x:1639,y:507,t:1527019795326};\\\", \\\"{x:1638,y:508,t:1527019795336};\\\", \\\"{x:1628,y:510,t:1527019795353};\\\", \\\"{x:1592,y:512,t:1527019795369};\\\", \\\"{x:1478,y:512,t:1527019795386};\\\", \\\"{x:1321,y:512,t:1527019795402};\\\", \\\"{x:1176,y:509,t:1527019795419};\\\", \\\"{x:1057,y:509,t:1527019795435};\\\", \\\"{x:1001,y:509,t:1527019795453};\\\", \\\"{x:977,y:506,t:1527019795468};\\\", \\\"{x:969,y:503,t:1527019795485};\\\", \\\"{x:970,y:502,t:1527019795577};\\\", \\\"{x:972,y:502,t:1527019795588};\\\", \\\"{x:982,y:499,t:1527019795605};\\\", \\\"{x:995,y:497,t:1527019795623};\\\", \\\"{x:1022,y:494,t:1527019795638};\\\", \\\"{x:1062,y:493,t:1527019795656};\\\", \\\"{x:1159,y:493,t:1527019795672};\\\", \\\"{x:1256,y:493,t:1527019795689};\\\", \\\"{x:1359,y:493,t:1527019795706};\\\", \\\"{x:1459,y:496,t:1527019795722};\\\", \\\"{x:1548,y:507,t:1527019795739};\\\", \\\"{x:1612,y:515,t:1527019795756};\\\", \\\"{x:1655,y:523,t:1527019795772};\\\", \\\"{x:1678,y:528,t:1527019795788};\\\", \\\"{x:1685,y:530,t:1527019795805};\\\", \\\"{x:1687,y:531,t:1527019795823};\\\", \\\"{x:1678,y:532,t:1527019795904};\\\", \\\"{x:1654,y:533,t:1527019795922};\\\", \\\"{x:1608,y:538,t:1527019795938};\\\", \\\"{x:1558,y:538,t:1527019795955};\\\", \\\"{x:1491,y:538,t:1527019795973};\\\", \\\"{x:1408,y:538,t:1527019795988};\\\", \\\"{x:1336,y:538,t:1527019796006};\\\", \\\"{x:1299,y:538,t:1527019796023};\\\", \\\"{x:1279,y:539,t:1527019796039};\\\", \\\"{x:1265,y:539,t:1527019796056};\\\", \\\"{x:1257,y:539,t:1527019796073};\\\", \\\"{x:1263,y:539,t:1527019796329};\\\", \\\"{x:1278,y:539,t:1527019796339};\\\", \\\"{x:1311,y:541,t:1527019796356};\\\", \\\"{x:1350,y:541,t:1527019796373};\\\", \\\"{x:1381,y:541,t:1527019796389};\\\", \\\"{x:1418,y:542,t:1527019796405};\\\", \\\"{x:1470,y:546,t:1527019796422};\\\", \\\"{x:1494,y:548,t:1527019796439};\\\", \\\"{x:1512,y:549,t:1527019796455};\\\", \\\"{x:1523,y:549,t:1527019796472};\\\", \\\"{x:1523,y:545,t:1527019797609};\\\", \\\"{x:1519,y:532,t:1527019797624};\\\", \\\"{x:1514,y:523,t:1527019797640};\\\", \\\"{x:1503,y:500,t:1527019797657};\\\", \\\"{x:1489,y:478,t:1527019797673};\\\", \\\"{x:1474,y:463,t:1527019797689};\\\", \\\"{x:1459,y:447,t:1527019797706};\\\", \\\"{x:1448,y:437,t:1527019797724};\\\", \\\"{x:1437,y:431,t:1527019797740};\\\", \\\"{x:1434,y:429,t:1527019797757};\\\", \\\"{x:1431,y:427,t:1527019797773};\\\", \\\"{x:1430,y:430,t:1527019798049};\\\", \\\"{x:1426,y:444,t:1527019798056};\\\", \\\"{x:1412,y:489,t:1527019798073};\\\", \\\"{x:1382,y:550,t:1527019798090};\\\", \\\"{x:1352,y:632,t:1527019798106};\\\", \\\"{x:1322,y:722,t:1527019798124};\\\", \\\"{x:1305,y:763,t:1527019798140};\\\", \\\"{x:1300,y:770,t:1527019798157};\\\", \\\"{x:1299,y:773,t:1527019798174};\\\", \\\"{x:1298,y:771,t:1527019798233};\\\", \\\"{x:1296,y:760,t:1527019798240};\\\", \\\"{x:1290,y:729,t:1527019798256};\\\", \\\"{x:1287,y:689,t:1527019798274};\\\", \\\"{x:1287,y:658,t:1527019798290};\\\", \\\"{x:1287,y:638,t:1527019798308};\\\", \\\"{x:1287,y:597,t:1527019798323};\\\", \\\"{x:1291,y:570,t:1527019798339};\\\", \\\"{x:1296,y:552,t:1527019798356};\\\", \\\"{x:1301,y:540,t:1527019798373};\\\", \\\"{x:1307,y:525,t:1527019798390};\\\", \\\"{x:1311,y:519,t:1527019798406};\\\", \\\"{x:1314,y:514,t:1527019798423};\\\", \\\"{x:1318,y:503,t:1527019798439};\\\", \\\"{x:1318,y:501,t:1527019798457};\\\", \\\"{x:1319,y:500,t:1527019798473};\\\", \\\"{x:1319,y:498,t:1527019798490};\\\", \\\"{x:1321,y:497,t:1527019798507};\\\", \\\"{x:1321,y:494,t:1527019798523};\\\", \\\"{x:1321,y:491,t:1527019798540};\\\", \\\"{x:1322,y:490,t:1527019798557};\\\", \\\"{x:1322,y:489,t:1527019798576};\\\", \\\"{x:1322,y:488,t:1527019798592};\\\", \\\"{x:1321,y:488,t:1527019798625};\\\", \\\"{x:1313,y:488,t:1527019798640};\\\", \\\"{x:1307,y:492,t:1527019798656};\\\", \\\"{x:1299,y:507,t:1527019798673};\\\", \\\"{x:1290,y:547,t:1527019798690};\\\", \\\"{x:1285,y:577,t:1527019798707};\\\", \\\"{x:1282,y:595,t:1527019798723};\\\", \\\"{x:1282,y:607,t:1527019798740};\\\", \\\"{x:1282,y:613,t:1527019798757};\\\", \\\"{x:1281,y:618,t:1527019798773};\\\", \\\"{x:1281,y:620,t:1527019798791};\\\", \\\"{x:1281,y:622,t:1527019798806};\\\", \\\"{x:1280,y:624,t:1527019798824};\\\", \\\"{x:1279,y:625,t:1527019798840};\\\", \\\"{x:1278,y:625,t:1527019798929};\\\", \\\"{x:1276,y:625,t:1527019798952};\\\", \\\"{x:1275,y:625,t:1527019798960};\\\", \\\"{x:1274,y:625,t:1527019798973};\\\", \\\"{x:1268,y:625,t:1527019798991};\\\", \\\"{x:1257,y:628,t:1527019799007};\\\", \\\"{x:1237,y:634,t:1527019799025};\\\", \\\"{x:1221,y:638,t:1527019799040};\\\", \\\"{x:1214,y:639,t:1527019799057};\\\", \\\"{x:1210,y:640,t:1527019799073};\\\", \\\"{x:1213,y:640,t:1527019799224};\\\", \\\"{x:1226,y:640,t:1527019799240};\\\", \\\"{x:1252,y:640,t:1527019799257};\\\", \\\"{x:1283,y:641,t:1527019799273};\\\", \\\"{x:1324,y:644,t:1527019799291};\\\", \\\"{x:1361,y:645,t:1527019799308};\\\", \\\"{x:1389,y:648,t:1527019799324};\\\", \\\"{x:1412,y:651,t:1527019799340};\\\", \\\"{x:1425,y:653,t:1527019799357};\\\", \\\"{x:1427,y:653,t:1527019799374};\\\", \\\"{x:1425,y:653,t:1527019799441};\\\", \\\"{x:1413,y:654,t:1527019799458};\\\", \\\"{x:1365,y:654,t:1527019799474};\\\", \\\"{x:1320,y:654,t:1527019799491};\\\", \\\"{x:1285,y:654,t:1527019799507};\\\", \\\"{x:1257,y:654,t:1527019799524};\\\", \\\"{x:1235,y:654,t:1527019799541};\\\", \\\"{x:1224,y:654,t:1527019799558};\\\", \\\"{x:1218,y:654,t:1527019799574};\\\", \\\"{x:1217,y:654,t:1527019799590};\\\", \\\"{x:1216,y:656,t:1527019799608};\\\", \\\"{x:1213,y:661,t:1527019799624};\\\", \\\"{x:1213,y:662,t:1527019799641};\\\", \\\"{x:1217,y:662,t:1527019799857};\\\", \\\"{x:1225,y:657,t:1527019799874};\\\", \\\"{x:1231,y:656,t:1527019799891};\\\", \\\"{x:1238,y:652,t:1527019799907};\\\", \\\"{x:1242,y:651,t:1527019799925};\\\", \\\"{x:1243,y:651,t:1527019799940};\\\", \\\"{x:1246,y:648,t:1527019800048};\\\", \\\"{x:1248,y:645,t:1527019800058};\\\", \\\"{x:1252,y:642,t:1527019800075};\\\", \\\"{x:1255,y:639,t:1527019800091};\\\", \\\"{x:1258,y:637,t:1527019800108};\\\", \\\"{x:1260,y:636,t:1527019800125};\\\", \\\"{x:1258,y:636,t:1527019800873};\\\", \\\"{x:1232,y:643,t:1527019800881};\\\", \\\"{x:1195,y:656,t:1527019800891};\\\", \\\"{x:1085,y:687,t:1527019800909};\\\", \\\"{x:937,y:713,t:1527019800925};\\\", \\\"{x:795,y:741,t:1527019800942};\\\", \\\"{x:679,y:757,t:1527019800958};\\\", \\\"{x:598,y:766,t:1527019800974};\\\", \\\"{x:553,y:769,t:1527019800992};\\\", \\\"{x:547,y:768,t:1527019801008};\\\", \\\"{x:545,y:766,t:1527019801024};\\\", \\\"{x:545,y:760,t:1527019801041};\\\", \\\"{x:542,y:747,t:1527019801059};\\\", \\\"{x:535,y:726,t:1527019801074};\\\", \\\"{x:529,y:706,t:1527019801091};\\\", \\\"{x:518,y:680,t:1527019801104};\\\", \\\"{x:506,y:659,t:1527019801121};\\\", \\\"{x:496,y:636,t:1527019801138};\\\", \\\"{x:483,y:621,t:1527019801162};\\\", \\\"{x:476,y:618,t:1527019801178};\\\", \\\"{x:474,y:617,t:1527019801195};\\\", \\\"{x:476,y:618,t:1527019801271};\\\", \\\"{x:489,y:622,t:1527019801279};\\\", \\\"{x:506,y:625,t:1527019801296};\\\", \\\"{x:603,y:630,t:1527019801312};\\\", \\\"{x:683,y:630,t:1527019801328};\\\", \\\"{x:778,y:630,t:1527019801345};\\\", \\\"{x:854,y:627,t:1527019801362};\\\", \\\"{x:894,y:626,t:1527019801379};\\\", \\\"{x:908,y:623,t:1527019801396};\\\", \\\"{x:909,y:623,t:1527019801412};\\\", \\\"{x:909,y:621,t:1527019801428};\\\", \\\"{x:900,y:617,t:1527019801445};\\\", \\\"{x:889,y:612,t:1527019801463};\\\", \\\"{x:883,y:609,t:1527019801479};\\\", \\\"{x:881,y:608,t:1527019801495};\\\", \\\"{x:881,y:607,t:1527019801512};\\\", \\\"{x:879,y:605,t:1527019801529};\\\", \\\"{x:878,y:602,t:1527019801545};\\\", \\\"{x:874,y:597,t:1527019801562};\\\", \\\"{x:869,y:592,t:1527019801580};\\\", \\\"{x:866,y:589,t:1527019801596};\\\", \\\"{x:866,y:587,t:1527019801613};\\\", \\\"{x:866,y:584,t:1527019801627};\\\", \\\"{x:863,y:581,t:1527019801645};\\\", \\\"{x:858,y:576,t:1527019801662};\\\", \\\"{x:851,y:570,t:1527019801678};\\\", \\\"{x:844,y:562,t:1527019801695};\\\", \\\"{x:838,y:554,t:1527019801712};\\\", \\\"{x:838,y:552,t:1527019801728};\\\", \\\"{x:838,y:551,t:1527019801745};\\\", \\\"{x:838,y:549,t:1527019801763};\\\", \\\"{x:838,y:548,t:1527019801779};\\\", \\\"{x:834,y:548,t:1527019802071};\\\", \\\"{x:827,y:551,t:1527019802080};\\\", \\\"{x:807,y:559,t:1527019802096};\\\", \\\"{x:653,y:648,t:1527019802113};\\\", \\\"{x:523,y:718,t:1527019802130};\\\", \\\"{x:422,y:774,t:1527019802145};\\\", \\\"{x:391,y:782,t:1527019802162};\\\", \\\"{x:395,y:779,t:1527019802296};\\\", \\\"{x:405,y:770,t:1527019802313};\\\", \\\"{x:421,y:757,t:1527019802330};\\\", \\\"{x:440,y:744,t:1527019802346};\\\", \\\"{x:464,y:731,t:1527019802363};\\\", \\\"{x:492,y:719,t:1527019802379};\\\", \\\"{x:530,y:698,t:1527019802397};\\\", \\\"{x:584,y:669,t:1527019802413};\\\", \\\"{x:623,y:652,t:1527019802430};\\\", \\\"{x:656,y:632,t:1527019802446};\\\", \\\"{x:664,y:627,t:1527019802463};\\\", \\\"{x:665,y:625,t:1527019803018};\\\", \\\"{x:670,y:622,t:1527019803031};\\\", \\\"{x:685,y:610,t:1527019803046};\\\", \\\"{x:707,y:597,t:1527019803063};\\\", \\\"{x:724,y:590,t:1527019803079};\\\", \\\"{x:734,y:585,t:1527019803097};\\\", \\\"{x:741,y:580,t:1527019803113};\\\", \\\"{x:749,y:575,t:1527019803130};\\\", \\\"{x:753,y:572,t:1527019803146};\\\", \\\"{x:757,y:571,t:1527019803163};\\\", \\\"{x:759,y:569,t:1527019803180};\\\", \\\"{x:761,y:568,t:1527019803196};\\\", \\\"{x:763,y:566,t:1527019803213};\\\", \\\"{x:765,y:564,t:1527019803230};\\\", \\\"{x:767,y:562,t:1527019803246};\\\", \\\"{x:772,y:555,t:1527019803264};\\\", \\\"{x:776,y:553,t:1527019803280};\\\", \\\"{x:788,y:548,t:1527019803297};\\\", \\\"{x:798,y:543,t:1527019803313};\\\", \\\"{x:805,y:542,t:1527019803330};\\\", \\\"{x:816,y:541,t:1527019803346};\\\", \\\"{x:824,y:539,t:1527019803363};\\\", \\\"{x:830,y:537,t:1527019803380};\\\", \\\"{x:833,y:537,t:1527019803396};\\\", \\\"{x:840,y:537,t:1527019803413};\\\", \\\"{x:847,y:537,t:1527019803430};\\\", \\\"{x:849,y:537,t:1527019803446};\\\", \\\"{x:849,y:536,t:1527019803783};\\\", \\\"{x:849,y:535,t:1527019803816};\\\", \\\"{x:849,y:534,t:1527019803839};\\\", \\\"{x:847,y:534,t:1527019803887};\\\", \\\"{x:845,y:534,t:1527019803904};\\\", \\\"{x:844,y:535,t:1527019803915};\\\", \\\"{x:832,y:539,t:1527019803930};\\\", \\\"{x:820,y:546,t:1527019803948};\\\", \\\"{x:790,y:575,t:1527019803964};\\\", \\\"{x:745,y:642,t:1527019803981};\\\", \\\"{x:700,y:726,t:1527019803997};\\\", \\\"{x:669,y:785,t:1527019804014};\\\", \\\"{x:641,y:827,t:1527019804030};\\\", \\\"{x:624,y:845,t:1527019804047};\\\", \\\"{x:622,y:846,t:1527019804064};\\\", \\\"{x:619,y:846,t:1527019804081};\\\", \\\"{x:618,y:846,t:1527019804097};\\\", \\\"{x:615,y:838,t:1527019804114};\\\", \\\"{x:602,y:819,t:1527019804130};\\\", \\\"{x:580,y:804,t:1527019804147};\\\", \\\"{x:562,y:796,t:1527019804164};\\\", \\\"{x:560,y:796,t:1527019804181};\\\", \\\"{x:560,y:795,t:1527019804198};\\\", \\\"{x:559,y:795,t:1527019804216};\\\", \\\"{x:557,y:793,t:1527019804240};\\\", \\\"{x:555,y:791,t:1527019804248};\\\", \\\"{x:552,y:785,t:1527019804264};\\\", \\\"{x:549,y:781,t:1527019804281};\\\", \\\"{x:548,y:779,t:1527019804297};\\\", \\\"{x:548,y:778,t:1527019804314};\\\", \\\"{x:548,y:775,t:1527019804332};\\\", \\\"{x:546,y:767,t:1527019804348};\\\", \\\"{x:545,y:756,t:1527019804364};\\\", \\\"{x:543,y:744,t:1527019804382};\\\", \\\"{x:539,y:733,t:1527019804397};\\\", \\\"{x:537,y:727,t:1527019804414};\\\", \\\"{x:535,y:724,t:1527019804430};\\\", \\\"{x:533,y:723,t:1527019804447};\\\", \\\"{x:533,y:722,t:1527019804464};\\\" ] }, { \\\"rt\\\": 6570, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 436696, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:732,t:1527019806151};\\\", \\\"{x:525,y:734,t:1527019806239};\\\", \\\"{x:520,y:749,t:1527019806321};\\\", \\\"{x:519,y:750,t:1527019806341};\\\", \\\"{x:519,y:751,t:1527019806349};\\\", \\\"{x:518,y:752,t:1527019806366};\\\", \\\"{x:518,y:754,t:1527019806382};\\\", \\\"{x:518,y:755,t:1527019806399};\\\", \\\"{x:518,y:754,t:1527019806680};\\\", \\\"{x:521,y:747,t:1527019806699};\\\", \\\"{x:522,y:745,t:1527019806717};\\\", \\\"{x:522,y:743,t:1527019806733};\\\", \\\"{x:523,y:743,t:1527019806749};\\\", \\\"{x:524,y:743,t:1527019806768};\\\", \\\"{x:524,y:742,t:1527019806784};\\\", \\\"{x:523,y:748,t:1527019807032};\\\", \\\"{x:523,y:752,t:1527019807040};\\\", \\\"{x:520,y:761,t:1527019807053};\\\", \\\"{x:518,y:773,t:1527019807066};\\\", \\\"{x:518,y:787,t:1527019807084};\\\", \\\"{x:518,y:796,t:1527019807101};\\\", \\\"{x:518,y:804,t:1527019807117};\\\", \\\"{x:518,y:808,t:1527019807133};\\\", \\\"{x:518,y:810,t:1527019807151};\\\", \\\"{x:518,y:811,t:1527019807167};\\\", \\\"{x:518,y:813,t:1527019807183};\\\", \\\"{x:518,y:814,t:1527019807199};\\\", \\\"{x:518,y:815,t:1527019807224};\\\", \\\"{x:518,y:816,t:1527019807233};\\\", \\\"{x:518,y:817,t:1527019807256};\\\", \\\"{x:517,y:818,t:1527019807280};\\\", \\\"{x:517,y:819,t:1527019807288};\\\", \\\"{x:517,y:821,t:1527019807312};\\\", \\\"{x:517,y:822,t:1527019807608};\\\", \\\"{x:515,y:824,t:1527019807664};\\\", \\\"{x:515,y:825,t:1527019807713};\\\", \\\"{x:515,y:826,t:1527019807777};\\\", \\\"{x:514,y:827,t:1527019807849};\\\", \\\"{x:514,y:828,t:1527019808000};\\\", \\\"{x:559,y:793,t:1527019808018};\\\", \\\"{x:644,y:720,t:1527019808035};\\\", \\\"{x:740,y:638,t:1527019808051};\\\", \\\"{x:822,y:572,t:1527019808069};\\\", \\\"{x:888,y:520,t:1527019808085};\\\", \\\"{x:919,y:496,t:1527019808101};\\\", \\\"{x:939,y:484,t:1527019808117};\\\", \\\"{x:958,y:476,t:1527019808135};\\\", \\\"{x:975,y:475,t:1527019808150};\\\", \\\"{x:993,y:475,t:1527019808167};\\\", \\\"{x:1006,y:475,t:1527019808185};\\\", \\\"{x:1033,y:485,t:1527019808200};\\\", \\\"{x:1086,y:502,t:1527019808217};\\\", \\\"{x:1144,y:516,t:1527019808234};\\\", \\\"{x:1169,y:522,t:1527019808250};\\\", \\\"{x:1183,y:523,t:1527019808268};\\\", \\\"{x:1190,y:523,t:1527019808284};\\\", \\\"{x:1191,y:523,t:1527019808300};\\\", \\\"{x:1192,y:523,t:1527019808335};\\\", \\\"{x:1193,y:523,t:1527019808351};\\\", \\\"{x:1201,y:528,t:1527019808368};\\\", \\\"{x:1210,y:537,t:1527019808385};\\\", \\\"{x:1219,y:546,t:1527019808402};\\\", \\\"{x:1226,y:552,t:1527019808418};\\\", \\\"{x:1229,y:554,t:1527019808435};\\\", \\\"{x:1230,y:554,t:1527019808452};\\\", \\\"{x:1231,y:555,t:1527019808468};\\\", \\\"{x:1236,y:556,t:1527019808485};\\\", \\\"{x:1247,y:559,t:1527019808502};\\\", \\\"{x:1264,y:561,t:1527019808518};\\\", \\\"{x:1282,y:564,t:1527019808537};\\\", \\\"{x:1306,y:568,t:1527019808552};\\\", \\\"{x:1311,y:568,t:1527019808567};\\\", \\\"{x:1315,y:568,t:1527019808585};\\\", \\\"{x:1319,y:568,t:1527019808945};\\\", \\\"{x:1324,y:568,t:1527019808952};\\\", \\\"{x:1339,y:568,t:1527019808968};\\\", \\\"{x:1361,y:568,t:1527019808984};\\\", \\\"{x:1383,y:569,t:1527019809002};\\\", \\\"{x:1397,y:570,t:1527019809019};\\\", \\\"{x:1406,y:573,t:1527019809035};\\\", \\\"{x:1408,y:573,t:1527019809052};\\\", \\\"{x:1409,y:573,t:1527019809233};\\\", \\\"{x:1408,y:575,t:1527019809240};\\\", \\\"{x:1407,y:576,t:1527019809252};\\\", \\\"{x:1399,y:579,t:1527019809269};\\\", \\\"{x:1391,y:581,t:1527019809286};\\\", \\\"{x:1371,y:583,t:1527019809302};\\\", \\\"{x:1333,y:587,t:1527019809319};\\\", \\\"{x:1227,y:600,t:1527019809336};\\\", \\\"{x:1152,y:609,t:1527019809352};\\\", \\\"{x:1108,y:617,t:1527019809369};\\\", \\\"{x:1071,y:622,t:1527019809386};\\\", \\\"{x:1042,y:626,t:1527019809402};\\\", \\\"{x:1020,y:627,t:1527019809419};\\\", \\\"{x:999,y:631,t:1527019809437};\\\", \\\"{x:981,y:633,t:1527019809452};\\\", \\\"{x:962,y:634,t:1527019809469};\\\", \\\"{x:941,y:636,t:1527019809486};\\\", \\\"{x:923,y:636,t:1527019809502};\\\", \\\"{x:903,y:637,t:1527019809519};\\\", \\\"{x:877,y:637,t:1527019809536};\\\", \\\"{x:854,y:637,t:1527019809552};\\\", \\\"{x:822,y:637,t:1527019809569};\\\", \\\"{x:794,y:631,t:1527019809587};\\\", \\\"{x:766,y:625,t:1527019809601};\\\", \\\"{x:698,y:622,t:1527019809620};\\\", \\\"{x:620,y:622,t:1527019809635};\\\", \\\"{x:549,y:615,t:1527019809651};\\\", \\\"{x:485,y:606,t:1527019809686};\\\", \\\"{x:470,y:603,t:1527019809702};\\\", \\\"{x:467,y:603,t:1527019809719};\\\", \\\"{x:460,y:603,t:1527019809735};\\\", \\\"{x:456,y:603,t:1527019809753};\\\", \\\"{x:446,y:603,t:1527019809768};\\\", \\\"{x:435,y:603,t:1527019809785};\\\", \\\"{x:426,y:603,t:1527019809802};\\\", \\\"{x:425,y:602,t:1527019809818};\\\", \\\"{x:424,y:602,t:1527019809836};\\\", \\\"{x:423,y:602,t:1527019809863};\\\", \\\"{x:422,y:601,t:1527019809880};\\\", \\\"{x:421,y:600,t:1527019809889};\\\", \\\"{x:420,y:600,t:1527019809903};\\\", \\\"{x:419,y:599,t:1527019809918};\\\", \\\"{x:415,y:596,t:1527019809935};\\\", \\\"{x:411,y:593,t:1527019809954};\\\", \\\"{x:403,y:587,t:1527019809969};\\\", \\\"{x:386,y:576,t:1527019809986};\\\", \\\"{x:374,y:568,t:1527019810003};\\\", \\\"{x:361,y:557,t:1527019810019};\\\", \\\"{x:354,y:549,t:1527019810036};\\\", \\\"{x:352,y:544,t:1527019810053};\\\", \\\"{x:350,y:538,t:1527019810069};\\\", \\\"{x:350,y:533,t:1527019810085};\\\", \\\"{x:348,y:531,t:1527019810103};\\\", \\\"{x:348,y:529,t:1527019810120};\\\", \\\"{x:350,y:526,t:1527019810184};\\\", \\\"{x:356,y:524,t:1527019810193};\\\", \\\"{x:369,y:522,t:1527019810203};\\\", \\\"{x:429,y:521,t:1527019810219};\\\", \\\"{x:518,y:519,t:1527019810236};\\\", \\\"{x:585,y:519,t:1527019810253};\\\", \\\"{x:619,y:519,t:1527019810269};\\\", \\\"{x:627,y:518,t:1527019810287};\\\", \\\"{x:627,y:517,t:1527019810319};\\\", \\\"{x:629,y:517,t:1527019810415};\\\", \\\"{x:630,y:516,t:1527019810424};\\\", \\\"{x:631,y:515,t:1527019810436};\\\", \\\"{x:631,y:513,t:1527019810452};\\\", \\\"{x:631,y:511,t:1527019810470};\\\", \\\"{x:631,y:508,t:1527019810486};\\\", \\\"{x:631,y:506,t:1527019810502};\\\", \\\"{x:626,y:503,t:1527019810519};\\\", \\\"{x:619,y:501,t:1527019810537};\\\", \\\"{x:613,y:500,t:1527019810552};\\\", \\\"{x:610,y:499,t:1527019810569};\\\", \\\"{x:606,y:499,t:1527019810587};\\\", \\\"{x:604,y:499,t:1527019810602};\\\", \\\"{x:621,y:503,t:1527019810944};\\\", \\\"{x:652,y:513,t:1527019810954};\\\", \\\"{x:708,y:530,t:1527019810971};\\\", \\\"{x:735,y:546,t:1527019810987};\\\", \\\"{x:759,y:557,t:1527019811004};\\\", \\\"{x:787,y:568,t:1527019811020};\\\", \\\"{x:795,y:571,t:1527019811037};\\\", \\\"{x:796,y:571,t:1527019811119};\\\", \\\"{x:798,y:571,t:1527019811136};\\\", \\\"{x:799,y:569,t:1527019811154};\\\", \\\"{x:800,y:563,t:1527019811170};\\\", \\\"{x:803,y:558,t:1527019811188};\\\", \\\"{x:804,y:553,t:1527019811204};\\\", \\\"{x:804,y:550,t:1527019811220};\\\", \\\"{x:806,y:546,t:1527019811236};\\\", \\\"{x:807,y:544,t:1527019811252};\\\", \\\"{x:807,y:542,t:1527019811269};\\\", \\\"{x:809,y:540,t:1527019811287};\\\", \\\"{x:810,y:539,t:1527019811303};\\\", \\\"{x:813,y:538,t:1527019811320};\\\", \\\"{x:815,y:537,t:1527019811337};\\\", \\\"{x:816,y:537,t:1527019811353};\\\", \\\"{x:817,y:537,t:1527019811392};\\\", \\\"{x:818,y:537,t:1527019811403};\\\", \\\"{x:823,y:535,t:1527019811420};\\\", \\\"{x:829,y:534,t:1527019811437};\\\", \\\"{x:838,y:534,t:1527019811452};\\\", \\\"{x:842,y:534,t:1527019811470};\\\", \\\"{x:843,y:534,t:1527019811703};\\\", \\\"{x:839,y:538,t:1527019811720};\\\", \\\"{x:808,y:551,t:1527019811738};\\\", \\\"{x:740,y:579,t:1527019811754};\\\", \\\"{x:642,y:615,t:1527019811771};\\\", \\\"{x:577,y:637,t:1527019811788};\\\", \\\"{x:560,y:652,t:1527019811803};\\\", \\\"{x:547,y:664,t:1527019811821};\\\", \\\"{x:540,y:679,t:1527019811837};\\\", \\\"{x:531,y:697,t:1527019811854};\\\", \\\"{x:511,y:723,t:1527019811871};\\\", \\\"{x:486,y:743,t:1527019811886};\\\", \\\"{x:412,y:779,t:1527019811904};\\\", \\\"{x:378,y:794,t:1527019811921};\\\", \\\"{x:360,y:800,t:1527019811937};\\\", \\\"{x:359,y:800,t:1527019811954};\\\", \\\"{x:358,y:799,t:1527019811984};\\\", \\\"{x:358,y:798,t:1527019811992};\\\", \\\"{x:358,y:797,t:1527019812004};\\\", \\\"{x:366,y:790,t:1527019812021};\\\", \\\"{x:385,y:784,t:1527019812038};\\\", \\\"{x:406,y:782,t:1527019812053};\\\", \\\"{x:434,y:777,t:1527019812071};\\\", \\\"{x:457,y:773,t:1527019812087};\\\", \\\"{x:460,y:773,t:1527019812104};\\\", \\\"{x:462,y:773,t:1527019812121};\\\", \\\"{x:463,y:772,t:1527019812138};\\\", \\\"{x:464,y:771,t:1527019812160};\\\", \\\"{x:465,y:769,t:1527019812171};\\\", \\\"{x:466,y:767,t:1527019812188};\\\", \\\"{x:468,y:763,t:1527019812204};\\\", \\\"{x:473,y:754,t:1527019812221};\\\", \\\"{x:474,y:749,t:1527019812238};\\\", \\\"{x:476,y:740,t:1527019812254};\\\", \\\"{x:476,y:734,t:1527019812271};\\\", \\\"{x:476,y:729,t:1527019812287};\\\", \\\"{x:476,y:728,t:1527019812304};\\\", \\\"{x:476,y:727,t:1527019812320};\\\" ] }, { \\\"rt\\\": 21557, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 459529, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:727,t:1527019814945};\\\", \\\"{x:541,y:739,t:1527019814965};\\\", \\\"{x:582,y:746,t:1527019814973};\\\", \\\"{x:669,y:773,t:1527019814990};\\\", \\\"{x:735,y:791,t:1527019815007};\\\", \\\"{x:761,y:792,t:1527019815023};\\\", \\\"{x:771,y:792,t:1527019815040};\\\", \\\"{x:777,y:790,t:1527019815057};\\\", \\\"{x:791,y:785,t:1527019815073};\\\", \\\"{x:803,y:780,t:1527019815090};\\\", \\\"{x:810,y:777,t:1527019815107};\\\", \\\"{x:812,y:776,t:1527019815124};\\\", \\\"{x:813,y:776,t:1527019815140};\\\", \\\"{x:812,y:776,t:1527019818720};\\\", \\\"{x:813,y:780,t:1527019818889};\\\", \\\"{x:836,y:806,t:1527019818895};\\\", \\\"{x:879,y:843,t:1527019818911};\\\", \\\"{x:1041,y:944,t:1527019818928};\\\", \\\"{x:1166,y:1007,t:1527019818944};\\\", \\\"{x:1257,y:1046,t:1527019818961};\\\", \\\"{x:1286,y:1063,t:1527019818978};\\\", \\\"{x:1298,y:1063,t:1527019818994};\\\", \\\"{x:1308,y:1062,t:1527019819012};\\\", \\\"{x:1316,y:1056,t:1527019819029};\\\", \\\"{x:1332,y:1036,t:1527019819044};\\\", \\\"{x:1342,y:990,t:1527019819061};\\\", \\\"{x:1351,y:921,t:1527019819079};\\\", \\\"{x:1351,y:843,t:1527019819094};\\\", \\\"{x:1342,y:773,t:1527019819112};\\\", \\\"{x:1294,y:623,t:1527019819128};\\\", \\\"{x:1245,y:565,t:1527019819146};\\\", \\\"{x:1207,y:543,t:1527019819162};\\\", \\\"{x:1178,y:528,t:1527019819179};\\\", \\\"{x:1152,y:526,t:1527019819196};\\\", \\\"{x:1129,y:526,t:1527019819212};\\\", \\\"{x:1115,y:527,t:1527019819228};\\\", \\\"{x:1108,y:532,t:1527019819246};\\\", \\\"{x:1101,y:539,t:1527019819261};\\\", \\\"{x:1091,y:553,t:1527019819278};\\\", \\\"{x:1081,y:571,t:1527019819296};\\\", \\\"{x:1078,y:591,t:1527019819312};\\\", \\\"{x:1076,y:622,t:1527019819328};\\\", \\\"{x:1077,y:640,t:1527019819345};\\\", \\\"{x:1081,y:651,t:1527019819361};\\\", \\\"{x:1082,y:653,t:1527019819378};\\\", \\\"{x:1082,y:651,t:1527019819488};\\\", \\\"{x:1082,y:648,t:1527019819496};\\\", \\\"{x:1082,y:644,t:1527019819512};\\\", \\\"{x:1081,y:640,t:1527019819529};\\\", \\\"{x:1081,y:639,t:1527019819545};\\\", \\\"{x:1081,y:637,t:1527019819768};\\\", \\\"{x:1089,y:633,t:1527019819780};\\\", \\\"{x:1108,y:628,t:1527019819795};\\\", \\\"{x:1132,y:627,t:1527019819812};\\\", \\\"{x:1154,y:626,t:1527019819829};\\\", \\\"{x:1186,y:626,t:1527019819846};\\\", \\\"{x:1217,y:626,t:1527019819863};\\\", \\\"{x:1243,y:623,t:1527019819879};\\\", \\\"{x:1266,y:623,t:1527019819896};\\\", \\\"{x:1302,y:628,t:1527019819912};\\\", \\\"{x:1333,y:630,t:1527019819930};\\\", \\\"{x:1368,y:637,t:1527019819946};\\\", \\\"{x:1395,y:641,t:1527019819962};\\\", \\\"{x:1409,y:641,t:1527019819979};\\\", \\\"{x:1411,y:642,t:1527019819996};\\\", \\\"{x:1412,y:642,t:1527019820016};\\\", \\\"{x:1413,y:642,t:1527019820032};\\\", \\\"{x:1415,y:642,t:1527019820048};\\\", \\\"{x:1416,y:642,t:1527019820062};\\\", \\\"{x:1418,y:641,t:1527019820079};\\\", \\\"{x:1419,y:641,t:1527019820104};\\\", \\\"{x:1421,y:640,t:1527019820128};\\\", \\\"{x:1425,y:640,t:1527019820146};\\\", \\\"{x:1429,y:640,t:1527019820162};\\\", \\\"{x:1430,y:638,t:1527019820179};\\\", \\\"{x:1432,y:638,t:1527019821809};\\\", \\\"{x:1433,y:638,t:1527019821824};\\\", \\\"{x:1435,y:638,t:1527019821832};\\\", \\\"{x:1436,y:638,t:1527019821873};\\\", \\\"{x:1437,y:638,t:1527019821912};\\\", \\\"{x:1438,y:638,t:1527019821953};\\\", \\\"{x:1439,y:638,t:1527019822033};\\\", \\\"{x:1439,y:639,t:1527019825785};\\\", \\\"{x:1417,y:645,t:1527019825803};\\\", \\\"{x:1391,y:656,t:1527019825819};\\\", \\\"{x:1363,y:669,t:1527019825836};\\\", \\\"{x:1346,y:683,t:1527019825853};\\\", \\\"{x:1336,y:694,t:1527019825869};\\\", \\\"{x:1334,y:697,t:1527019825886};\\\", \\\"{x:1334,y:698,t:1527019825953};\\\", \\\"{x:1334,y:699,t:1527019825969};\\\", \\\"{x:1345,y:702,t:1527019825986};\\\", \\\"{x:1358,y:703,t:1527019826003};\\\", \\\"{x:1361,y:703,t:1527019826019};\\\", \\\"{x:1363,y:703,t:1527019826036};\\\", \\\"{x:1364,y:703,t:1527019826209};\\\", \\\"{x:1363,y:702,t:1527019826220};\\\", \\\"{x:1362,y:701,t:1527019826236};\\\", \\\"{x:1360,y:701,t:1527019826253};\\\", \\\"{x:1358,y:701,t:1527019826269};\\\", \\\"{x:1355,y:698,t:1527019826286};\\\", \\\"{x:1344,y:697,t:1527019826305};\\\", \\\"{x:1333,y:694,t:1527019826319};\\\", \\\"{x:1329,y:693,t:1527019826335};\\\", \\\"{x:1327,y:693,t:1527019826352};\\\", \\\"{x:1326,y:693,t:1527019826375};\\\", \\\"{x:1326,y:694,t:1527019826625};\\\", \\\"{x:1328,y:694,t:1527019826637};\\\", \\\"{x:1333,y:695,t:1527019826653};\\\", \\\"{x:1336,y:697,t:1527019826670};\\\", \\\"{x:1338,y:697,t:1527019826687};\\\", \\\"{x:1339,y:697,t:1527019826703};\\\", \\\"{x:1340,y:697,t:1527019826720};\\\", \\\"{x:1340,y:702,t:1527019827393};\\\", \\\"{x:1340,y:706,t:1527019827404};\\\", \\\"{x:1340,y:716,t:1527019827421};\\\", \\\"{x:1340,y:721,t:1527019827438};\\\", \\\"{x:1340,y:725,t:1527019827454};\\\", \\\"{x:1340,y:726,t:1527019827471};\\\", \\\"{x:1340,y:728,t:1527019827488};\\\", \\\"{x:1340,y:729,t:1527019827504};\\\", \\\"{x:1340,y:731,t:1527019827521};\\\", \\\"{x:1340,y:732,t:1527019827544};\\\", \\\"{x:1340,y:733,t:1527019827560};\\\", \\\"{x:1340,y:734,t:1527019827571};\\\", \\\"{x:1340,y:735,t:1527019827593};\\\", \\\"{x:1340,y:737,t:1527019827604};\\\", \\\"{x:1340,y:742,t:1527019827621};\\\", \\\"{x:1340,y:751,t:1527019827638};\\\", \\\"{x:1340,y:758,t:1527019827654};\\\", \\\"{x:1340,y:765,t:1527019827671};\\\", \\\"{x:1342,y:773,t:1527019827688};\\\", \\\"{x:1342,y:776,t:1527019827704};\\\", \\\"{x:1344,y:778,t:1527019827721};\\\", \\\"{x:1344,y:779,t:1527019827738};\\\", \\\"{x:1300,y:779,t:1527019831561};\\\", \\\"{x:1200,y:782,t:1527019831576};\\\", \\\"{x:734,y:782,t:1527019831593};\\\", \\\"{x:417,y:743,t:1527019831609};\\\", \\\"{x:237,y:694,t:1527019831625};\\\", \\\"{x:221,y:679,t:1527019831643};\\\", \\\"{x:235,y:667,t:1527019831660};\\\", \\\"{x:272,y:646,t:1527019831675};\\\", \\\"{x:298,y:632,t:1527019831692};\\\", \\\"{x:315,y:617,t:1527019831703};\\\", \\\"{x:330,y:603,t:1527019831719};\\\", \\\"{x:341,y:593,t:1527019831737};\\\", \\\"{x:350,y:581,t:1527019831753};\\\", \\\"{x:355,y:571,t:1527019831771};\\\", \\\"{x:358,y:562,t:1527019831788};\\\", \\\"{x:362,y:554,t:1527019831805};\\\", \\\"{x:368,y:547,t:1527019831820};\\\", \\\"{x:372,y:541,t:1527019831837};\\\", \\\"{x:375,y:537,t:1527019831855};\\\", \\\"{x:377,y:533,t:1527019831870};\\\", \\\"{x:379,y:532,t:1527019831887};\\\", \\\"{x:380,y:531,t:1527019831976};\\\", \\\"{x:382,y:531,t:1527019832089};\\\", \\\"{x:404,y:531,t:1527019832105};\\\", \\\"{x:472,y:531,t:1527019832122};\\\", \\\"{x:542,y:531,t:1527019832138};\\\", \\\"{x:609,y:531,t:1527019832154};\\\", \\\"{x:627,y:529,t:1527019832171};\\\", \\\"{x:631,y:533,t:1527019832456};\\\", \\\"{x:642,y:553,t:1527019832473};\\\", \\\"{x:658,y:574,t:1527019832488};\\\", \\\"{x:676,y:583,t:1527019832504};\\\", \\\"{x:691,y:585,t:1527019832520};\\\", \\\"{x:696,y:583,t:1527019832538};\\\", \\\"{x:715,y:571,t:1527019832554};\\\", \\\"{x:743,y:554,t:1527019832572};\\\", \\\"{x:772,y:538,t:1527019832587};\\\", \\\"{x:788,y:528,t:1527019832604};\\\", \\\"{x:795,y:524,t:1527019832623};\\\", \\\"{x:798,y:520,t:1527019832638};\\\", \\\"{x:799,y:519,t:1527019832654};\\\", \\\"{x:800,y:518,t:1527019832688};\\\", \\\"{x:801,y:517,t:1527019832697};\\\", \\\"{x:802,y:517,t:1527019832704};\\\", \\\"{x:804,y:515,t:1527019832721};\\\", \\\"{x:807,y:513,t:1527019832738};\\\", \\\"{x:808,y:512,t:1527019832754};\\\", \\\"{x:809,y:512,t:1527019832775};\\\", \\\"{x:809,y:511,t:1527019832799};\\\", \\\"{x:810,y:510,t:1527019832807};\\\", \\\"{x:812,y:510,t:1527019832822};\\\", \\\"{x:815,y:509,t:1527019832839};\\\", \\\"{x:820,y:506,t:1527019832855};\\\", \\\"{x:826,y:503,t:1527019832873};\\\", \\\"{x:827,y:502,t:1527019832888};\\\", \\\"{x:829,y:501,t:1527019832911};\\\", \\\"{x:830,y:501,t:1527019832943};\\\", \\\"{x:831,y:501,t:1527019832959};\\\", \\\"{x:832,y:501,t:1527019832972};\\\", \\\"{x:826,y:502,t:1527019833223};\\\", \\\"{x:819,y:505,t:1527019833239};\\\", \\\"{x:770,y:534,t:1527019833256};\\\", \\\"{x:709,y:573,t:1527019833272};\\\", \\\"{x:628,y:614,t:1527019833290};\\\", \\\"{x:570,y:641,t:1527019833306};\\\", \\\"{x:544,y:652,t:1527019833321};\\\", \\\"{x:526,y:657,t:1527019833338};\\\", \\\"{x:518,y:660,t:1527019833355};\\\", \\\"{x:516,y:661,t:1527019833372};\\\", \\\"{x:515,y:661,t:1527019833407};\\\", \\\"{x:514,y:661,t:1527019833431};\\\", \\\"{x:513,y:661,t:1527019833463};\\\", \\\"{x:511,y:660,t:1527019833472};\\\", \\\"{x:507,y:655,t:1527019833489};\\\", \\\"{x:505,y:652,t:1527019833505};\\\", \\\"{x:501,y:646,t:1527019833523};\\\", \\\"{x:495,y:637,t:1527019833538};\\\", \\\"{x:492,y:632,t:1527019833555};\\\", \\\"{x:489,y:621,t:1527019833574};\\\", \\\"{x:489,y:614,t:1527019833588};\\\", \\\"{x:503,y:604,t:1527019833606};\\\", \\\"{x:516,y:596,t:1527019833623};\\\", \\\"{x:535,y:586,t:1527019833639};\\\", \\\"{x:566,y:573,t:1527019833655};\\\", \\\"{x:589,y:564,t:1527019833672};\\\", \\\"{x:601,y:557,t:1527019833689};\\\", \\\"{x:608,y:553,t:1527019833707};\\\", \\\"{x:610,y:552,t:1527019833722};\\\", \\\"{x:611,y:551,t:1527019833740};\\\", \\\"{x:611,y:550,t:1527019833767};\\\", \\\"{x:611,y:549,t:1527019833775};\\\", \\\"{x:611,y:548,t:1527019833789};\\\", \\\"{x:604,y:539,t:1527019833805};\\\", \\\"{x:582,y:526,t:1527019833823};\\\", \\\"{x:513,y:495,t:1527019833839};\\\", \\\"{x:439,y:470,t:1527019833856};\\\", \\\"{x:361,y:455,t:1527019833872};\\\", \\\"{x:313,y:450,t:1527019833889};\\\", \\\"{x:299,y:450,t:1527019833905};\\\", \\\"{x:296,y:450,t:1527019833923};\\\", \\\"{x:294,y:450,t:1527019833940};\\\", \\\"{x:294,y:451,t:1527019833955};\\\", \\\"{x:292,y:456,t:1527019833972};\\\", \\\"{x:292,y:466,t:1527019833990};\\\", \\\"{x:292,y:478,t:1527019834005};\\\", \\\"{x:292,y:493,t:1527019834024};\\\", \\\"{x:293,y:507,t:1527019834039};\\\", \\\"{x:294,y:514,t:1527019834055};\\\", \\\"{x:294,y:519,t:1527019834074};\\\", \\\"{x:297,y:528,t:1527019834089};\\\", \\\"{x:297,y:530,t:1527019834111};\\\", \\\"{x:297,y:531,t:1527019834143};\\\", \\\"{x:296,y:532,t:1527019834156};\\\", \\\"{x:290,y:535,t:1527019834172};\\\", \\\"{x:276,y:537,t:1527019834190};\\\", \\\"{x:251,y:540,t:1527019834209};\\\", \\\"{x:223,y:545,t:1527019834222};\\\", \\\"{x:187,y:550,t:1527019834239};\\\", \\\"{x:172,y:556,t:1527019834257};\\\", \\\"{x:168,y:557,t:1527019834273};\\\", \\\"{x:166,y:558,t:1527019834289};\\\", \\\"{x:165,y:559,t:1527019834307};\\\", \\\"{x:164,y:559,t:1527019834391};\\\", \\\"{x:163,y:559,t:1527019834407};\\\", \\\"{x:162,y:559,t:1527019834423};\\\", \\\"{x:161,y:559,t:1527019834440};\\\", \\\"{x:161,y:556,t:1527019834615};\\\", \\\"{x:161,y:555,t:1527019834623};\\\", \\\"{x:162,y:553,t:1527019834640};\\\", \\\"{x:162,y:551,t:1527019834657};\\\", \\\"{x:164,y:546,t:1527019834672};\\\", \\\"{x:166,y:544,t:1527019834690};\\\", \\\"{x:166,y:543,t:1527019834712};\\\", \\\"{x:167,y:542,t:1527019834879};\\\", \\\"{x:168,y:542,t:1527019834889};\\\", \\\"{x:173,y:542,t:1527019834907};\\\", \\\"{x:178,y:539,t:1527019834924};\\\", \\\"{x:206,y:547,t:1527019834940};\\\", \\\"{x:339,y:612,t:1527019834957};\\\", \\\"{x:511,y:702,t:1527019834974};\\\", \\\"{x:630,y:757,t:1527019834990};\\\", \\\"{x:657,y:774,t:1527019835006};\\\", \\\"{x:659,y:776,t:1527019835023};\\\", \\\"{x:655,y:776,t:1527019835144};\\\", \\\"{x:644,y:775,t:1527019835157};\\\", \\\"{x:579,y:764,t:1527019835174};\\\", \\\"{x:523,y:756,t:1527019835191};\\\", \\\"{x:491,y:751,t:1527019835209};\\\", \\\"{x:479,y:750,t:1527019835224};\\\", \\\"{x:478,y:748,t:1527019835360};\\\" ] }, { \\\"rt\\\": 66151, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 526972, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -8-L -03 PM-03 PM-04 PM-L -O -B -E -E -C -G -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:475,y:745,t:1527019838200};\\\", \\\"{x:466,y:719,t:1527019838212};\\\", \\\"{x:425,y:633,t:1527019838226};\\\", \\\"{x:377,y:555,t:1527019838242};\\\", \\\"{x:324,y:487,t:1527019838260};\\\", \\\"{x:277,y:445,t:1527019838276};\\\", \\\"{x:259,y:429,t:1527019838292};\\\", \\\"{x:255,y:426,t:1527019838309};\\\", \\\"{x:254,y:425,t:1527019838327};\\\", \\\"{x:258,y:426,t:1527019838359};\\\", \\\"{x:262,y:428,t:1527019838367};\\\", \\\"{x:268,y:431,t:1527019838377};\\\", \\\"{x:286,y:438,t:1527019838392};\\\", \\\"{x:308,y:450,t:1527019838410};\\\", \\\"{x:342,y:463,t:1527019838427};\\\", \\\"{x:374,y:472,t:1527019838443};\\\", \\\"{x:393,y:477,t:1527019838460};\\\", \\\"{x:410,y:482,t:1527019838477};\\\", \\\"{x:419,y:483,t:1527019838494};\\\", \\\"{x:421,y:483,t:1527019838510};\\\", \\\"{x:425,y:483,t:1527019838527};\\\", \\\"{x:428,y:483,t:1527019838544};\\\", \\\"{x:432,y:483,t:1527019838560};\\\", \\\"{x:433,y:483,t:1527019838577};\\\", \\\"{x:437,y:482,t:1527019838594};\\\", \\\"{x:445,y:481,t:1527019838610};\\\", \\\"{x:459,y:477,t:1527019838627};\\\", \\\"{x:469,y:476,t:1527019838644};\\\", \\\"{x:491,y:474,t:1527019838661};\\\", \\\"{x:526,y:474,t:1527019838677};\\\", \\\"{x:607,y:474,t:1527019838694};\\\", \\\"{x:732,y:474,t:1527019838711};\\\", \\\"{x:748,y:477,t:1527019838727};\\\", \\\"{x:750,y:477,t:1527019839168};\\\", \\\"{x:751,y:477,t:1527019839179};\\\", \\\"{x:752,y:477,t:1527019839196};\\\", \\\"{x:753,y:477,t:1527019839212};\\\", \\\"{x:754,y:477,t:1527019839229};\\\", \\\"{x:755,y:477,t:1527019839248};\\\", \\\"{x:756,y:477,t:1527019839280};\\\", \\\"{x:758,y:477,t:1527019839295};\\\", \\\"{x:761,y:477,t:1527019839312};\\\", \\\"{x:765,y:477,t:1527019839329};\\\", \\\"{x:769,y:477,t:1527019839346};\\\", \\\"{x:777,y:477,t:1527019839363};\\\", \\\"{x:790,y:477,t:1527019839379};\\\", \\\"{x:805,y:482,t:1527019839396};\\\", \\\"{x:828,y:488,t:1527019839414};\\\", \\\"{x:855,y:498,t:1527019839429};\\\", \\\"{x:916,y:513,t:1527019839444};\\\", \\\"{x:1004,y:534,t:1527019839462};\\\", \\\"{x:1105,y:554,t:1527019839477};\\\", \\\"{x:1191,y:565,t:1527019839493};\\\", \\\"{x:1318,y:584,t:1527019839511};\\\", \\\"{x:1358,y:589,t:1527019839527};\\\", \\\"{x:1462,y:601,t:1527019839544};\\\", \\\"{x:1502,y:602,t:1527019839561};\\\", \\\"{x:1531,y:602,t:1527019839576};\\\", \\\"{x:1550,y:602,t:1527019839594};\\\", \\\"{x:1556,y:602,t:1527019839610};\\\", \\\"{x:1564,y:600,t:1527019839627};\\\", \\\"{x:1568,y:597,t:1527019839644};\\\", \\\"{x:1574,y:595,t:1527019839660};\\\", \\\"{x:1577,y:594,t:1527019839677};\\\", \\\"{x:1579,y:592,t:1527019839694};\\\", \\\"{x:1581,y:587,t:1527019839710};\\\", \\\"{x:1589,y:575,t:1527019839728};\\\", \\\"{x:1593,y:566,t:1527019839744};\\\", \\\"{x:1596,y:551,t:1527019839760};\\\", \\\"{x:1596,y:538,t:1527019839777};\\\", \\\"{x:1596,y:523,t:1527019839794};\\\", \\\"{x:1595,y:508,t:1527019839811};\\\", \\\"{x:1589,y:497,t:1527019839828};\\\", \\\"{x:1581,y:486,t:1527019839845};\\\", \\\"{x:1570,y:473,t:1527019839862};\\\", \\\"{x:1551,y:460,t:1527019839878};\\\", \\\"{x:1524,y:448,t:1527019839895};\\\", \\\"{x:1502,y:439,t:1527019839911};\\\", \\\"{x:1482,y:430,t:1527019839928};\\\", \\\"{x:1477,y:426,t:1527019839944};\\\", \\\"{x:1475,y:426,t:1527019839961};\\\", \\\"{x:1474,y:426,t:1527019839978};\\\", \\\"{x:1471,y:426,t:1527019839994};\\\", \\\"{x:1469,y:426,t:1527019840010};\\\", \\\"{x:1461,y:426,t:1527019840028};\\\", \\\"{x:1438,y:426,t:1527019840045};\\\", \\\"{x:1373,y:433,t:1527019840060};\\\", \\\"{x:1264,y:449,t:1527019840078};\\\", \\\"{x:1154,y:459,t:1527019840094};\\\", \\\"{x:1077,y:459,t:1527019840111};\\\", \\\"{x:1051,y:459,t:1527019840127};\\\", \\\"{x:1052,y:458,t:1527019840208};\\\", \\\"{x:1054,y:458,t:1527019840216};\\\", \\\"{x:1056,y:457,t:1527019840227};\\\", \\\"{x:1059,y:454,t:1527019840244};\\\", \\\"{x:1065,y:449,t:1527019840261};\\\", \\\"{x:1069,y:445,t:1527019840278};\\\", \\\"{x:1073,y:441,t:1527019840294};\\\", \\\"{x:1074,y:439,t:1527019840310};\\\", \\\"{x:1075,y:436,t:1527019840328};\\\", \\\"{x:1075,y:432,t:1527019840344};\\\", \\\"{x:1075,y:429,t:1527019840360};\\\", \\\"{x:1075,y:426,t:1527019840378};\\\", \\\"{x:1075,y:422,t:1527019840393};\\\", \\\"{x:1071,y:415,t:1527019840410};\\\", \\\"{x:1066,y:409,t:1527019840427};\\\", \\\"{x:1064,y:407,t:1527019840444};\\\", \\\"{x:1064,y:406,t:1527019840461};\\\", \\\"{x:1062,y:406,t:1527019840488};\\\", \\\"{x:1061,y:406,t:1527019840496};\\\", \\\"{x:1060,y:406,t:1527019840512};\\\", \\\"{x:1060,y:422,t:1527019840528};\\\", \\\"{x:1060,y:438,t:1527019840544};\\\", \\\"{x:1065,y:453,t:1527019840560};\\\", \\\"{x:1070,y:461,t:1527019840578};\\\", \\\"{x:1071,y:466,t:1527019840594};\\\", \\\"{x:1072,y:467,t:1527019840611};\\\", \\\"{x:1072,y:468,t:1527019840627};\\\", \\\"{x:1075,y:473,t:1527019840761};\\\", \\\"{x:1083,y:489,t:1527019840776};\\\", \\\"{x:1087,y:504,t:1527019840793};\\\", \\\"{x:1089,y:513,t:1527019840811};\\\", \\\"{x:1090,y:516,t:1527019840827};\\\", \\\"{x:1090,y:517,t:1527019840844};\\\", \\\"{x:1091,y:517,t:1527019840864};\\\", \\\"{x:1090,y:517,t:1527019840920};\\\", \\\"{x:1089,y:517,t:1527019840936};\\\", \\\"{x:1087,y:517,t:1527019840944};\\\", \\\"{x:1085,y:517,t:1527019840984};\\\", \\\"{x:1084,y:517,t:1527019841000};\\\", \\\"{x:1084,y:516,t:1527019841010};\\\", \\\"{x:1084,y:512,t:1527019841027};\\\", \\\"{x:1089,y:505,t:1527019841043};\\\", \\\"{x:1096,y:502,t:1527019841061};\\\", \\\"{x:1106,y:500,t:1527019841076};\\\", \\\"{x:1120,y:499,t:1527019841093};\\\", \\\"{x:1146,y:499,t:1527019841110};\\\", \\\"{x:1193,y:501,t:1527019841126};\\\", \\\"{x:1314,y:519,t:1527019841144};\\\", \\\"{x:1373,y:529,t:1527019841160};\\\", \\\"{x:1413,y:532,t:1527019841177};\\\", \\\"{x:1435,y:532,t:1527019841194};\\\", \\\"{x:1439,y:532,t:1527019841211};\\\", \\\"{x:1448,y:532,t:1527019841227};\\\", \\\"{x:1461,y:529,t:1527019841244};\\\", \\\"{x:1478,y:525,t:1527019841260};\\\", \\\"{x:1500,y:522,t:1527019841276};\\\", \\\"{x:1516,y:520,t:1527019841294};\\\", \\\"{x:1522,y:518,t:1527019841309};\\\", \\\"{x:1523,y:517,t:1527019841327};\\\", \\\"{x:1525,y:517,t:1527019841489};\\\", \\\"{x:1533,y:514,t:1527019841496};\\\", \\\"{x:1543,y:513,t:1527019841509};\\\", \\\"{x:1557,y:512,t:1527019841526};\\\", \\\"{x:1565,y:511,t:1527019841544};\\\", \\\"{x:1565,y:510,t:1527019841560};\\\", \\\"{x:1567,y:510,t:1527019842313};\\\", \\\"{x:1568,y:510,t:1527019842326};\\\", \\\"{x:1569,y:510,t:1527019842343};\\\", \\\"{x:1571,y:510,t:1527019842360};\\\", \\\"{x:1573,y:510,t:1527019842376};\\\", \\\"{x:1574,y:510,t:1527019842393};\\\", \\\"{x:1575,y:510,t:1527019842433};\\\", \\\"{x:1577,y:510,t:1527019842456};\\\", \\\"{x:1578,y:509,t:1527019842488};\\\", \\\"{x:1579,y:509,t:1527019842496};\\\", \\\"{x:1580,y:507,t:1527019842510};\\\", \\\"{x:1581,y:506,t:1527019842526};\\\", \\\"{x:1582,y:502,t:1527019842545};\\\", \\\"{x:1583,y:497,t:1527019842560};\\\", \\\"{x:1584,y:496,t:1527019842576};\\\", \\\"{x:1583,y:507,t:1527019865220};\\\", \\\"{x:1578,y:545,t:1527019865232};\\\", \\\"{x:1566,y:636,t:1527019865248};\\\", \\\"{x:1555,y:725,t:1527019865266};\\\", \\\"{x:1536,y:851,t:1527019865282};\\\", \\\"{x:1531,y:900,t:1527019865298};\\\", \\\"{x:1530,y:954,t:1527019865316};\\\", \\\"{x:1530,y:980,t:1527019865334};\\\", \\\"{x:1530,y:991,t:1527019865349};\\\", \\\"{x:1530,y:992,t:1527019865366};\\\", \\\"{x:1530,y:985,t:1527019865475};\\\", \\\"{x:1530,y:974,t:1527019865482};\\\", \\\"{x:1537,y:955,t:1527019865498};\\\", \\\"{x:1552,y:937,t:1527019865516};\\\", \\\"{x:1564,y:928,t:1527019865533};\\\", \\\"{x:1575,y:923,t:1527019865548};\\\", \\\"{x:1581,y:923,t:1527019865566};\\\", \\\"{x:1588,y:923,t:1527019865585};\\\", \\\"{x:1600,y:925,t:1527019865598};\\\", \\\"{x:1612,y:933,t:1527019865615};\\\", \\\"{x:1621,y:943,t:1527019865633};\\\", \\\"{x:1624,y:951,t:1527019865649};\\\", \\\"{x:1625,y:952,t:1527019865665};\\\", \\\"{x:1625,y:953,t:1527019865682};\\\", \\\"{x:1625,y:954,t:1527019865739};\\\", \\\"{x:1622,y:955,t:1527019865749};\\\", \\\"{x:1616,y:957,t:1527019865766};\\\", \\\"{x:1608,y:961,t:1527019865782};\\\", \\\"{x:1604,y:965,t:1527019865799};\\\", \\\"{x:1601,y:966,t:1527019865816};\\\", \\\"{x:1600,y:966,t:1527019865831};\\\", \\\"{x:1603,y:966,t:1527019866019};\\\", \\\"{x:1607,y:966,t:1527019866032};\\\", \\\"{x:1608,y:966,t:1527019866048};\\\", \\\"{x:1610,y:966,t:1527019866074};\\\", \\\"{x:1611,y:966,t:1527019866915};\\\", \\\"{x:1612,y:966,t:1527019866932};\\\", \\\"{x:1612,y:964,t:1527019866948};\\\", \\\"{x:1612,y:963,t:1527019866965};\\\", \\\"{x:1612,y:962,t:1527019866995};\\\", \\\"{x:1613,y:961,t:1527019867010};\\\", \\\"{x:1613,y:959,t:1527019867131};\\\", \\\"{x:1613,y:954,t:1527019867147};\\\", \\\"{x:1613,y:948,t:1527019867165};\\\", \\\"{x:1613,y:944,t:1527019867181};\\\", \\\"{x:1612,y:935,t:1527019867198};\\\", \\\"{x:1609,y:926,t:1527019867215};\\\", \\\"{x:1608,y:919,t:1527019867230};\\\", \\\"{x:1606,y:912,t:1527019867248};\\\", \\\"{x:1605,y:907,t:1527019867264};\\\", \\\"{x:1604,y:901,t:1527019867280};\\\", \\\"{x:1602,y:895,t:1527019867297};\\\", \\\"{x:1601,y:892,t:1527019867314};\\\", \\\"{x:1601,y:891,t:1527019867394};\\\", \\\"{x:1600,y:893,t:1527019867410};\\\", \\\"{x:1600,y:903,t:1527019867418};\\\", \\\"{x:1600,y:909,t:1527019867430};\\\", \\\"{x:1600,y:921,t:1527019867447};\\\", \\\"{x:1602,y:932,t:1527019867465};\\\", \\\"{x:1604,y:945,t:1527019867481};\\\", \\\"{x:1605,y:952,t:1527019867497};\\\", \\\"{x:1605,y:955,t:1527019867514};\\\", \\\"{x:1605,y:956,t:1527019867539};\\\", \\\"{x:1606,y:956,t:1527019867675};\\\", \\\"{x:1607,y:958,t:1527019867683};\\\", \\\"{x:1608,y:961,t:1527019867697};\\\", \\\"{x:1611,y:966,t:1527019867714};\\\", \\\"{x:1612,y:969,t:1527019867731};\\\", \\\"{x:1614,y:970,t:1527019867747};\\\", \\\"{x:1615,y:969,t:1527019867826};\\\", \\\"{x:1617,y:968,t:1527019867835};\\\", \\\"{x:1619,y:965,t:1527019867847};\\\", \\\"{x:1620,y:961,t:1527019867862};\\\", \\\"{x:1621,y:957,t:1527019867880};\\\", \\\"{x:1622,y:950,t:1527019867897};\\\", \\\"{x:1622,y:946,t:1527019867913};\\\", \\\"{x:1622,y:936,t:1527019867930};\\\", \\\"{x:1622,y:931,t:1527019867947};\\\", \\\"{x:1622,y:927,t:1527019867963};\\\", \\\"{x:1622,y:921,t:1527019867980};\\\", \\\"{x:1622,y:915,t:1527019867998};\\\", \\\"{x:1622,y:912,t:1527019868013};\\\", \\\"{x:1622,y:909,t:1527019868031};\\\", \\\"{x:1622,y:905,t:1527019868047};\\\", \\\"{x:1620,y:898,t:1527019868063};\\\", \\\"{x:1619,y:892,t:1527019868081};\\\", \\\"{x:1617,y:885,t:1527019868097};\\\", \\\"{x:1617,y:878,t:1527019868114};\\\", \\\"{x:1615,y:868,t:1527019868131};\\\", \\\"{x:1614,y:862,t:1527019868147};\\\", \\\"{x:1614,y:859,t:1527019868164};\\\", \\\"{x:1613,y:854,t:1527019868181};\\\", \\\"{x:1612,y:850,t:1527019868198};\\\", \\\"{x:1611,y:841,t:1527019868213};\\\", \\\"{x:1611,y:836,t:1527019868231};\\\", \\\"{x:1609,y:830,t:1527019868247};\\\", \\\"{x:1607,y:823,t:1527019868264};\\\", \\\"{x:1604,y:809,t:1527019868281};\\\", \\\"{x:1602,y:798,t:1527019868298};\\\", \\\"{x:1601,y:783,t:1527019868314};\\\", \\\"{x:1598,y:767,t:1527019868330};\\\", \\\"{x:1595,y:753,t:1527019868348};\\\", \\\"{x:1594,y:739,t:1527019868364};\\\", \\\"{x:1593,y:733,t:1527019868381};\\\", \\\"{x:1593,y:727,t:1527019868396};\\\", \\\"{x:1593,y:723,t:1527019868413};\\\", \\\"{x:1590,y:716,t:1527019868430};\\\", \\\"{x:1590,y:713,t:1527019868446};\\\", \\\"{x:1590,y:710,t:1527019868464};\\\", \\\"{x:1590,y:708,t:1527019868480};\\\", \\\"{x:1590,y:705,t:1527019868497};\\\", \\\"{x:1590,y:703,t:1527019868514};\\\", \\\"{x:1591,y:699,t:1527019868531};\\\", \\\"{x:1593,y:698,t:1527019868547};\\\", \\\"{x:1594,y:696,t:1527019868564};\\\", \\\"{x:1595,y:694,t:1527019868581};\\\", \\\"{x:1596,y:691,t:1527019868597};\\\", \\\"{x:1598,y:688,t:1527019868613};\\\", \\\"{x:1599,y:685,t:1527019868631};\\\", \\\"{x:1600,y:681,t:1527019868647};\\\", \\\"{x:1602,y:676,t:1527019868663};\\\", \\\"{x:1602,y:671,t:1527019868681};\\\", \\\"{x:1602,y:665,t:1527019868697};\\\", \\\"{x:1604,y:662,t:1527019868714};\\\", \\\"{x:1604,y:658,t:1527019868730};\\\", \\\"{x:1604,y:657,t:1527019868746};\\\", \\\"{x:1604,y:654,t:1527019868763};\\\", \\\"{x:1604,y:653,t:1527019868780};\\\", \\\"{x:1604,y:651,t:1527019868797};\\\", \\\"{x:1604,y:649,t:1527019868814};\\\", \\\"{x:1604,y:648,t:1527019868831};\\\", \\\"{x:1604,y:647,t:1527019868845};\\\", \\\"{x:1604,y:646,t:1527019868863};\\\", \\\"{x:1604,y:644,t:1527019868879};\\\", \\\"{x:1604,y:642,t:1527019868896};\\\", \\\"{x:1604,y:641,t:1527019868913};\\\", \\\"{x:1604,y:639,t:1527019869019};\\\", \\\"{x:1604,y:632,t:1527019870251};\\\", \\\"{x:1604,y:625,t:1527019870263};\\\", \\\"{x:1604,y:609,t:1527019870280};\\\", \\\"{x:1604,y:599,t:1527019870296};\\\", \\\"{x:1604,y:593,t:1527019870313};\\\", \\\"{x:1604,y:586,t:1527019870329};\\\", \\\"{x:1604,y:575,t:1527019870345};\\\", \\\"{x:1604,y:570,t:1527019870362};\\\", \\\"{x:1604,y:567,t:1527019870380};\\\", \\\"{x:1604,y:564,t:1527019870396};\\\", \\\"{x:1604,y:562,t:1527019870413};\\\", \\\"{x:1604,y:561,t:1527019870435};\\\", \\\"{x:1604,y:559,t:1527019870458};\\\", \\\"{x:1604,y:558,t:1527019870466};\\\", \\\"{x:1603,y:557,t:1527019870482};\\\", \\\"{x:1603,y:555,t:1527019870496};\\\", \\\"{x:1601,y:550,t:1527019870513};\\\", \\\"{x:1600,y:547,t:1527019870529};\\\", \\\"{x:1599,y:543,t:1527019870545};\\\", \\\"{x:1596,y:535,t:1527019870563};\\\", \\\"{x:1596,y:531,t:1527019870579};\\\", \\\"{x:1595,y:526,t:1527019870596};\\\", \\\"{x:1594,y:522,t:1527019870613};\\\", \\\"{x:1594,y:521,t:1527019870629};\\\", \\\"{x:1594,y:519,t:1527019870651};\\\", \\\"{x:1594,y:518,t:1527019870666};\\\", \\\"{x:1594,y:517,t:1527019870690};\\\", \\\"{x:1594,y:516,t:1527019870698};\\\", \\\"{x:1594,y:515,t:1527019870713};\\\", \\\"{x:1594,y:513,t:1527019870731};\\\", \\\"{x:1594,y:512,t:1527019870763};\\\", \\\"{x:1593,y:512,t:1527019870779};\\\", \\\"{x:1592,y:507,t:1527019870796};\\\", \\\"{x:1589,y:504,t:1527019870813};\\\", \\\"{x:1588,y:501,t:1527019870829};\\\", \\\"{x:1587,y:498,t:1527019870846};\\\", \\\"{x:1586,y:496,t:1527019870907};\\\", \\\"{x:1586,y:499,t:1527019877395};\\\", \\\"{x:1582,y:512,t:1527019877409};\\\", \\\"{x:1575,y:539,t:1527019877425};\\\", \\\"{x:1548,y:613,t:1527019877442};\\\", \\\"{x:1532,y:658,t:1527019877458};\\\", \\\"{x:1524,y:688,t:1527019877475};\\\", \\\"{x:1520,y:713,t:1527019877493};\\\", \\\"{x:1516,y:731,t:1527019877508};\\\", \\\"{x:1513,y:743,t:1527019877525};\\\", \\\"{x:1511,y:752,t:1527019877542};\\\", \\\"{x:1509,y:760,t:1527019877559};\\\", \\\"{x:1504,y:770,t:1527019877575};\\\", \\\"{x:1502,y:774,t:1527019877592};\\\", \\\"{x:1496,y:782,t:1527019877609};\\\", \\\"{x:1489,y:785,t:1527019877625};\\\", \\\"{x:1477,y:788,t:1527019877642};\\\", \\\"{x:1462,y:788,t:1527019877658};\\\", \\\"{x:1440,y:788,t:1527019877675};\\\", \\\"{x:1434,y:788,t:1527019877692};\\\", \\\"{x:1432,y:788,t:1527019877708};\\\", \\\"{x:1429,y:788,t:1527019877725};\\\", \\\"{x:1428,y:788,t:1527019877742};\\\", \\\"{x:1426,y:788,t:1527019877758};\\\", \\\"{x:1425,y:788,t:1527019877777};\\\", \\\"{x:1423,y:788,t:1527019877792};\\\", \\\"{x:1419,y:788,t:1527019877807};\\\", \\\"{x:1411,y:788,t:1527019877824};\\\", \\\"{x:1401,y:788,t:1527019877842};\\\", \\\"{x:1398,y:788,t:1527019877858};\\\", \\\"{x:1396,y:788,t:1527019877875};\\\", \\\"{x:1393,y:786,t:1527019877891};\\\", \\\"{x:1387,y:784,t:1527019877908};\\\", \\\"{x:1376,y:781,t:1527019877925};\\\", \\\"{x:1369,y:780,t:1527019877941};\\\", \\\"{x:1364,y:777,t:1527019877958};\\\", \\\"{x:1364,y:776,t:1527019877974};\\\", \\\"{x:1361,y:775,t:1527019877991};\\\", \\\"{x:1357,y:772,t:1527019878008};\\\", \\\"{x:1353,y:769,t:1527019878025};\\\", \\\"{x:1350,y:768,t:1527019878041};\\\", \\\"{x:1349,y:766,t:1527019878058};\\\", \\\"{x:1347,y:766,t:1527019878083};\\\", \\\"{x:1342,y:752,t:1527019887347};\\\", \\\"{x:1337,y:739,t:1527019887355};\\\", \\\"{x:1335,y:732,t:1527019887370};\\\", \\\"{x:1325,y:706,t:1527019887386};\\\", \\\"{x:1319,y:688,t:1527019887402};\\\", \\\"{x:1313,y:667,t:1527019887420};\\\", \\\"{x:1310,y:647,t:1527019887437};\\\", \\\"{x:1310,y:636,t:1527019887453};\\\", \\\"{x:1310,y:626,t:1527019887469};\\\", \\\"{x:1310,y:614,t:1527019887485};\\\", \\\"{x:1310,y:603,t:1527019887503};\\\", \\\"{x:1310,y:590,t:1527019887520};\\\", \\\"{x:1310,y:580,t:1527019887536};\\\", \\\"{x:1310,y:572,t:1527019887553};\\\", \\\"{x:1309,y:566,t:1527019887570};\\\", \\\"{x:1309,y:561,t:1527019887586};\\\", \\\"{x:1309,y:559,t:1527019887603};\\\", \\\"{x:1306,y:558,t:1527019887619};\\\", \\\"{x:1305,y:557,t:1527019887635};\\\", \\\"{x:1302,y:557,t:1527019887652};\\\", \\\"{x:1294,y:558,t:1527019887670};\\\", \\\"{x:1285,y:565,t:1527019887686};\\\", \\\"{x:1283,y:571,t:1527019887704};\\\", \\\"{x:1280,y:577,t:1527019887719};\\\", \\\"{x:1280,y:579,t:1527019887735};\\\", \\\"{x:1280,y:580,t:1527019887946};\\\", \\\"{x:1280,y:581,t:1527019887953};\\\", \\\"{x:1280,y:583,t:1527019887968};\\\", \\\"{x:1280,y:585,t:1527019887985};\\\", \\\"{x:1280,y:590,t:1527019888001};\\\", \\\"{x:1280,y:593,t:1527019888018};\\\", \\\"{x:1280,y:596,t:1527019888035};\\\", \\\"{x:1280,y:598,t:1527019888052};\\\", \\\"{x:1281,y:601,t:1527019888068};\\\", \\\"{x:1281,y:603,t:1527019888085};\\\", \\\"{x:1281,y:605,t:1527019888103};\\\", \\\"{x:1281,y:608,t:1527019888119};\\\", \\\"{x:1281,y:610,t:1527019888135};\\\", \\\"{x:1282,y:612,t:1527019888152};\\\", \\\"{x:1282,y:615,t:1527019888168};\\\", \\\"{x:1282,y:619,t:1527019888186};\\\", \\\"{x:1284,y:626,t:1527019888203};\\\", \\\"{x:1284,y:630,t:1527019888219};\\\", \\\"{x:1285,y:634,t:1527019888236};\\\", \\\"{x:1285,y:637,t:1527019888253};\\\", \\\"{x:1285,y:641,t:1527019888268};\\\", \\\"{x:1286,y:646,t:1527019888285};\\\", \\\"{x:1287,y:653,t:1527019888303};\\\", \\\"{x:1287,y:659,t:1527019888319};\\\", \\\"{x:1289,y:668,t:1527019888336};\\\", \\\"{x:1289,y:675,t:1527019888353};\\\", \\\"{x:1289,y:682,t:1527019888369};\\\", \\\"{x:1289,y:687,t:1527019888385};\\\", \\\"{x:1292,y:698,t:1527019888402};\\\", \\\"{x:1293,y:703,t:1527019888418};\\\", \\\"{x:1293,y:708,t:1527019888436};\\\", \\\"{x:1293,y:712,t:1527019888453};\\\", \\\"{x:1294,y:716,t:1527019888469};\\\", \\\"{x:1296,y:721,t:1527019888486};\\\", \\\"{x:1296,y:726,t:1527019888503};\\\", \\\"{x:1296,y:730,t:1527019888519};\\\", \\\"{x:1296,y:735,t:1527019888536};\\\", \\\"{x:1296,y:742,t:1527019888551};\\\", \\\"{x:1296,y:748,t:1527019888568};\\\", \\\"{x:1296,y:754,t:1527019888586};\\\", \\\"{x:1296,y:761,t:1527019888601};\\\", \\\"{x:1297,y:770,t:1527019888618};\\\", \\\"{x:1297,y:775,t:1527019888636};\\\", \\\"{x:1297,y:780,t:1527019888651};\\\", \\\"{x:1297,y:787,t:1527019888669};\\\", \\\"{x:1297,y:796,t:1527019888685};\\\", \\\"{x:1297,y:804,t:1527019888701};\\\", \\\"{x:1297,y:809,t:1527019888718};\\\", \\\"{x:1297,y:818,t:1527019888736};\\\", \\\"{x:1296,y:825,t:1527019888752};\\\", \\\"{x:1296,y:833,t:1527019888768};\\\", \\\"{x:1295,y:840,t:1527019888785};\\\", \\\"{x:1295,y:846,t:1527019888802};\\\", \\\"{x:1295,y:857,t:1527019888818};\\\", \\\"{x:1295,y:864,t:1527019888836};\\\", \\\"{x:1296,y:875,t:1527019888851};\\\", \\\"{x:1298,y:888,t:1527019888868};\\\", \\\"{x:1299,y:901,t:1527019888885};\\\", \\\"{x:1302,y:915,t:1527019888901};\\\", \\\"{x:1302,y:923,t:1527019888919};\\\", \\\"{x:1303,y:928,t:1527019888935};\\\", \\\"{x:1303,y:930,t:1527019888952};\\\", \\\"{x:1303,y:931,t:1527019888970};\\\", \\\"{x:1303,y:917,t:1527019892979};\\\", \\\"{x:1303,y:892,t:1527019892987};\\\", \\\"{x:1303,y:859,t:1527019893000};\\\", \\\"{x:1309,y:771,t:1527019893015};\\\", \\\"{x:1309,y:696,t:1527019893034};\\\", \\\"{x:1305,y:600,t:1527019893050};\\\", \\\"{x:1301,y:574,t:1527019893066};\\\", \\\"{x:1300,y:556,t:1527019893083};\\\", \\\"{x:1300,y:550,t:1527019893099};\\\", \\\"{x:1299,y:548,t:1527019893116};\\\", \\\"{x:1299,y:547,t:1527019893132};\\\", \\\"{x:1297,y:547,t:1527019893306};\\\", \\\"{x:1293,y:550,t:1527019893316};\\\", \\\"{x:1277,y:560,t:1527019893333};\\\", \\\"{x:1252,y:570,t:1527019893349};\\\", \\\"{x:1163,y:580,t:1527019893366};\\\", \\\"{x:991,y:587,t:1527019893384};\\\", \\\"{x:781,y:587,t:1527019893400};\\\", \\\"{x:578,y:586,t:1527019893416};\\\", \\\"{x:459,y:584,t:1527019893432};\\\", \\\"{x:445,y:584,t:1527019893459};\\\", \\\"{x:448,y:584,t:1527019893522};\\\", \\\"{x:455,y:584,t:1527019893529};\\\", \\\"{x:463,y:584,t:1527019893542};\\\", \\\"{x:473,y:581,t:1527019893559};\\\", \\\"{x:479,y:577,t:1527019893577};\\\", \\\"{x:482,y:574,t:1527019893592};\\\", \\\"{x:484,y:572,t:1527019893609};\\\", \\\"{x:484,y:571,t:1527019893625};\\\", \\\"{x:486,y:571,t:1527019893642};\\\", \\\"{x:500,y:564,t:1527019893660};\\\", \\\"{x:531,y:555,t:1527019893677};\\\", \\\"{x:575,y:537,t:1527019893693};\\\", \\\"{x:612,y:518,t:1527019893709};\\\", \\\"{x:628,y:504,t:1527019893727};\\\", \\\"{x:635,y:497,t:1527019893743};\\\", \\\"{x:635,y:495,t:1527019893760};\\\", \\\"{x:635,y:493,t:1527019893776};\\\", \\\"{x:635,y:492,t:1527019893858};\\\", \\\"{x:634,y:492,t:1527019893874};\\\", \\\"{x:633,y:492,t:1527019893881};\\\", \\\"{x:631,y:491,t:1527019893894};\\\", \\\"{x:629,y:491,t:1527019893910};\\\", \\\"{x:627,y:491,t:1527019893927};\\\", \\\"{x:626,y:491,t:1527019893944};\\\", \\\"{x:624,y:491,t:1527019893960};\\\", \\\"{x:622,y:491,t:1527019893977};\\\", \\\"{x:622,y:492,t:1527019893994};\\\", \\\"{x:621,y:492,t:1527019894010};\\\", \\\"{x:619,y:493,t:1527019894027};\\\", \\\"{x:619,y:494,t:1527019894090};\\\", \\\"{x:619,y:495,t:1527019894106};\\\", \\\"{x:619,y:497,t:1527019894122};\\\", \\\"{x:619,y:498,t:1527019894138};\\\", \\\"{x:619,y:500,t:1527019894154};\\\", \\\"{x:619,y:502,t:1527019894170};\\\", \\\"{x:618,y:504,t:1527019894186};\\\", \\\"{x:617,y:504,t:1527019894211};\\\", \\\"{x:616,y:505,t:1527019894227};\\\", \\\"{x:613,y:507,t:1527019894244};\\\", \\\"{x:611,y:508,t:1527019894260};\\\", \\\"{x:610,y:508,t:1527019894277};\\\", \\\"{x:608,y:508,t:1527019894294};\\\", \\\"{x:607,y:508,t:1527019894309};\\\", \\\"{x:606,y:509,t:1527019894326};\\\", \\\"{x:605,y:509,t:1527019894370};\\\", \\\"{x:604,y:509,t:1527019894378};\\\", \\\"{x:619,y:513,t:1527019895003};\\\", \\\"{x:680,y:530,t:1527019895012};\\\", \\\"{x:888,y:579,t:1527019895028};\\\", \\\"{x:1166,y:642,t:1527019895043};\\\", \\\"{x:1379,y:672,t:1527019895060};\\\", \\\"{x:1487,y:672,t:1527019895077};\\\", \\\"{x:1527,y:672,t:1527019895093};\\\", \\\"{x:1530,y:672,t:1527019895110};\\\", \\\"{x:1530,y:671,t:1527019895210};\\\", \\\"{x:1523,y:665,t:1527019895227};\\\", \\\"{x:1496,y:650,t:1527019895245};\\\", \\\"{x:1461,y:632,t:1527019895261};\\\", \\\"{x:1448,y:621,t:1527019895277};\\\", \\\"{x:1440,y:614,t:1527019895294};\\\", \\\"{x:1433,y:600,t:1527019895310};\\\", \\\"{x:1426,y:587,t:1527019895328};\\\", \\\"{x:1421,y:576,t:1527019895344};\\\", \\\"{x:1419,y:567,t:1527019895361};\\\", \\\"{x:1418,y:563,t:1527019895378};\\\", \\\"{x:1418,y:561,t:1527019895394};\\\", \\\"{x:1417,y:561,t:1527019895411};\\\", \\\"{x:1414,y:561,t:1527019896226};\\\", \\\"{x:1404,y:564,t:1527019896235};\\\", \\\"{x:1397,y:567,t:1527019896245};\\\", \\\"{x:1373,y:576,t:1527019896262};\\\", \\\"{x:1356,y:584,t:1527019896279};\\\", \\\"{x:1339,y:589,t:1527019896295};\\\", \\\"{x:1330,y:592,t:1527019896312};\\\", \\\"{x:1328,y:592,t:1527019896329};\\\", \\\"{x:1326,y:592,t:1527019896363};\\\", \\\"{x:1325,y:592,t:1527019896386};\\\", \\\"{x:1322,y:592,t:1527019896395};\\\", \\\"{x:1318,y:592,t:1527019896412};\\\", \\\"{x:1314,y:591,t:1527019896429};\\\", \\\"{x:1313,y:591,t:1527019896445};\\\", \\\"{x:1310,y:590,t:1527019896462};\\\", \\\"{x:1308,y:588,t:1527019896479};\\\", \\\"{x:1303,y:586,t:1527019896495};\\\", \\\"{x:1299,y:584,t:1527019896512};\\\", \\\"{x:1296,y:581,t:1527019896529};\\\", \\\"{x:1292,y:578,t:1527019896546};\\\", \\\"{x:1287,y:574,t:1527019896562};\\\", \\\"{x:1283,y:573,t:1527019896579};\\\", \\\"{x:1281,y:571,t:1527019896594};\\\", \\\"{x:1280,y:571,t:1527019896611};\\\", \\\"{x:1279,y:570,t:1527019896628};\\\", \\\"{x:1278,y:571,t:1527019896697};\\\", \\\"{x:1278,y:580,t:1527019896711};\\\", \\\"{x:1273,y:601,t:1527019896729};\\\", \\\"{x:1271,y:629,t:1527019896745};\\\", \\\"{x:1271,y:649,t:1527019896762};\\\", \\\"{x:1271,y:672,t:1527019896778};\\\", \\\"{x:1271,y:703,t:1527019896796};\\\", \\\"{x:1266,y:740,t:1527019896812};\\\", \\\"{x:1261,y:777,t:1527019896828};\\\", \\\"{x:1261,y:802,t:1527019896846};\\\", \\\"{x:1262,y:828,t:1527019896862};\\\", \\\"{x:1264,y:844,t:1527019896878};\\\", \\\"{x:1266,y:850,t:1527019896895};\\\", \\\"{x:1266,y:851,t:1527019896912};\\\", \\\"{x:1265,y:852,t:1527019896987};\\\", \\\"{x:1260,y:851,t:1527019896996};\\\", \\\"{x:1245,y:844,t:1527019897011};\\\", \\\"{x:1219,y:832,t:1527019897028};\\\", \\\"{x:1204,y:824,t:1527019897046};\\\", \\\"{x:1196,y:818,t:1527019897061};\\\", \\\"{x:1192,y:814,t:1527019897078};\\\", \\\"{x:1188,y:807,t:1527019897096};\\\", \\\"{x:1184,y:802,t:1527019897111};\\\", \\\"{x:1181,y:796,t:1527019897128};\\\", \\\"{x:1178,y:789,t:1527019897145};\\\", \\\"{x:1178,y:788,t:1527019897161};\\\", \\\"{x:1178,y:785,t:1527019897179};\\\", \\\"{x:1178,y:784,t:1527019897196};\\\", \\\"{x:1178,y:782,t:1527019897213};\\\", \\\"{x:1178,y:780,t:1527019897229};\\\", \\\"{x:1178,y:778,t:1527019897246};\\\", \\\"{x:1178,y:776,t:1527019897263};\\\", \\\"{x:1179,y:774,t:1527019897279};\\\", \\\"{x:1179,y:772,t:1527019897296};\\\", \\\"{x:1179,y:771,t:1527019897313};\\\", \\\"{x:1179,y:770,t:1527019897330};\\\", \\\"{x:1179,y:769,t:1527019897346};\\\", \\\"{x:1179,y:768,t:1527019897394};\\\", \\\"{x:1175,y:764,t:1527019902028};\\\", \\\"{x:1159,y:759,t:1527019902034};\\\", \\\"{x:1143,y:757,t:1527019902050};\\\", \\\"{x:1048,y:738,t:1527019902066};\\\", \\\"{x:1010,y:732,t:1527019902083};\\\", \\\"{x:998,y:732,t:1527019902099};\\\", \\\"{x:997,y:732,t:1527019902117};\\\", \\\"{x:994,y:733,t:1527019902134};\\\", \\\"{x:986,y:743,t:1527019902149};\\\", \\\"{x:966,y:765,t:1527019902166};\\\", \\\"{x:936,y:780,t:1527019902183};\\\", \\\"{x:870,y:806,t:1527019902199};\\\", \\\"{x:779,y:827,t:1527019902216};\\\", \\\"{x:687,y:855,t:1527019902233};\\\", \\\"{x:656,y:865,t:1527019902249};\\\", \\\"{x:649,y:868,t:1527019902266};\\\", \\\"{x:647,y:868,t:1527019902283};\\\", \\\"{x:644,y:867,t:1527019902306};\\\", \\\"{x:640,y:865,t:1527019902316};\\\", \\\"{x:630,y:859,t:1527019902333};\\\", \\\"{x:608,y:849,t:1527019902349};\\\", \\\"{x:582,y:835,t:1527019902366};\\\", \\\"{x:563,y:822,t:1527019902384};\\\", \\\"{x:548,y:810,t:1527019902399};\\\", \\\"{x:531,y:793,t:1527019902416};\\\", \\\"{x:512,y:782,t:1527019902433};\\\", \\\"{x:499,y:775,t:1527019902449};\\\", \\\"{x:496,y:773,t:1527019902466};\\\", \\\"{x:495,y:772,t:1527019902483};\\\", \\\"{x:495,y:770,t:1527019902500};\\\", \\\"{x:495,y:765,t:1527019902516};\\\", \\\"{x:495,y:759,t:1527019902533};\\\", \\\"{x:495,y:755,t:1527019902550};\\\", \\\"{x:497,y:749,t:1527019902795};\\\", \\\"{x:498,y:747,t:1527019902802};\\\", \\\"{x:498,y:745,t:1527019902816};\\\", \\\"{x:499,y:743,t:1527019902834};\\\", \\\"{x:500,y:742,t:1527019902850};\\\", \\\"{x:500,y:741,t:1527019902898};\\\", \\\"{x:501,y:741,t:1527019902934};\\\", \\\"{x:501,y:741,t:1527019903016};\\\" ] }, { \\\"rt\\\": 20784, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 549343, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:741,t:1527019907923};\\\", \\\"{x:534,y:749,t:1527019907930};\\\", \\\"{x:609,y:775,t:1527019907945};\\\", \\\"{x:788,y:851,t:1527019907960};\\\", \\\"{x:984,y:913,t:1527019907977};\\\", \\\"{x:1136,y:950,t:1527019907987};\\\", \\\"{x:1217,y:965,t:1527019908004};\\\", \\\"{x:1243,y:969,t:1527019908022};\\\", \\\"{x:1245,y:969,t:1527019908037};\\\", \\\"{x:1246,y:969,t:1527019908065};\\\", \\\"{x:1248,y:969,t:1527019908090};\\\", \\\"{x:1250,y:969,t:1527019908104};\\\", \\\"{x:1252,y:967,t:1527019908121};\\\", \\\"{x:1254,y:966,t:1527019908137};\\\", \\\"{x:1258,y:966,t:1527019908154};\\\", \\\"{x:1264,y:966,t:1527019908172};\\\", \\\"{x:1275,y:965,t:1527019908188};\\\", \\\"{x:1288,y:964,t:1527019908204};\\\", \\\"{x:1299,y:963,t:1527019908221};\\\", \\\"{x:1306,y:961,t:1527019908238};\\\", \\\"{x:1308,y:961,t:1527019908254};\\\", \\\"{x:1309,y:960,t:1527019908272};\\\", \\\"{x:1310,y:959,t:1527019908290};\\\", \\\"{x:1311,y:958,t:1527019908305};\\\", \\\"{x:1311,y:957,t:1527019908387};\\\", \\\"{x:1311,y:956,t:1527019908394};\\\", \\\"{x:1311,y:955,t:1527019908410};\\\", \\\"{x:1311,y:954,t:1527019908442};\\\", \\\"{x:1311,y:953,t:1527019910930};\\\", \\\"{x:1311,y:944,t:1527019910939};\\\", \\\"{x:1306,y:917,t:1527019910956};\\\", \\\"{x:1305,y:877,t:1527019910973};\\\", \\\"{x:1303,y:835,t:1527019910990};\\\", \\\"{x:1300,y:794,t:1527019911007};\\\", \\\"{x:1293,y:751,t:1527019911024};\\\", \\\"{x:1287,y:732,t:1527019911039};\\\", \\\"{x:1285,y:727,t:1527019911057};\\\", \\\"{x:1284,y:725,t:1527019911123};\\\", \\\"{x:1281,y:723,t:1527019911139};\\\", \\\"{x:1278,y:721,t:1527019911157};\\\", \\\"{x:1276,y:721,t:1527019911174};\\\", \\\"{x:1275,y:721,t:1527019911202};\\\", \\\"{x:1272,y:722,t:1527019911211};\\\", \\\"{x:1270,y:726,t:1527019911224};\\\", \\\"{x:1267,y:732,t:1527019911239};\\\", \\\"{x:1262,y:743,t:1527019911256};\\\", \\\"{x:1260,y:755,t:1527019911274};\\\", \\\"{x:1259,y:760,t:1527019911290};\\\", \\\"{x:1259,y:768,t:1527019911307};\\\", \\\"{x:1259,y:774,t:1527019911323};\\\", \\\"{x:1259,y:779,t:1527019911339};\\\", \\\"{x:1260,y:781,t:1527019911357};\\\", \\\"{x:1260,y:783,t:1527019911374};\\\", \\\"{x:1260,y:786,t:1527019911390};\\\", \\\"{x:1260,y:790,t:1527019911407};\\\", \\\"{x:1260,y:793,t:1527019911424};\\\", \\\"{x:1260,y:796,t:1527019911440};\\\", \\\"{x:1259,y:799,t:1527019911456};\\\", \\\"{x:1255,y:804,t:1527019911474};\\\", \\\"{x:1251,y:809,t:1527019911490};\\\", \\\"{x:1244,y:814,t:1527019911507};\\\", \\\"{x:1238,y:819,t:1527019911524};\\\", \\\"{x:1230,y:824,t:1527019911540};\\\", \\\"{x:1225,y:828,t:1527019911556};\\\", \\\"{x:1223,y:829,t:1527019911573};\\\", \\\"{x:1222,y:829,t:1527019911922};\\\", \\\"{x:1222,y:831,t:1527019911941};\\\", \\\"{x:1220,y:832,t:1527019911957};\\\", \\\"{x:1219,y:833,t:1527019912797};\\\", \\\"{x:1218,y:834,t:1527019916351};\\\", \\\"{x:1216,y:835,t:1527019916624};\\\", \\\"{x:1216,y:836,t:1527019917177};\\\", \\\"{x:1216,y:837,t:1527019917191};\\\", \\\"{x:1214,y:839,t:1527019917207};\\\", \\\"{x:1210,y:841,t:1527019917224};\\\", \\\"{x:1209,y:841,t:1527019917241};\\\", \\\"{x:1206,y:842,t:1527019917257};\\\", \\\"{x:1205,y:842,t:1527019917303};\\\", \\\"{x:1204,y:842,t:1527019917328};\\\", \\\"{x:1203,y:842,t:1527019917341};\\\", \\\"{x:1202,y:841,t:1527019917358};\\\", \\\"{x:1208,y:840,t:1527019917503};\\\", \\\"{x:1217,y:837,t:1527019917511};\\\", \\\"{x:1223,y:836,t:1527019917524};\\\", \\\"{x:1231,y:835,t:1527019917542};\\\", \\\"{x:1237,y:834,t:1527019917558};\\\", \\\"{x:1241,y:833,t:1527019917574};\\\", \\\"{x:1246,y:832,t:1527019917591};\\\", \\\"{x:1247,y:832,t:1527019917640};\\\", \\\"{x:1243,y:832,t:1527019917727};\\\", \\\"{x:1240,y:832,t:1527019917752};\\\", \\\"{x:1238,y:833,t:1527019917759};\\\", \\\"{x:1235,y:834,t:1527019917774};\\\", \\\"{x:1228,y:836,t:1527019917791};\\\", \\\"{x:1225,y:836,t:1527019917808};\\\", \\\"{x:1224,y:836,t:1527019917824};\\\", \\\"{x:1221,y:837,t:1527019917841};\\\", \\\"{x:1220,y:837,t:1527019917859};\\\", \\\"{x:1219,y:837,t:1527019917874};\\\", \\\"{x:1218,y:837,t:1527019918744};\\\", \\\"{x:1219,y:836,t:1527019919223};\\\", \\\"{x:1220,y:836,t:1527019919231};\\\", \\\"{x:1220,y:835,t:1527019919242};\\\", \\\"{x:1221,y:835,t:1527019919259};\\\", \\\"{x:1221,y:834,t:1527019919275};\\\", \\\"{x:1221,y:833,t:1527019919663};\\\", \\\"{x:1221,y:832,t:1527019919687};\\\", \\\"{x:1221,y:831,t:1527019919695};\\\", \\\"{x:1221,y:830,t:1527019919711};\\\", \\\"{x:1221,y:829,t:1527019919727};\\\", \\\"{x:1221,y:828,t:1527019919743};\\\", \\\"{x:1221,y:827,t:1527019919759};\\\", \\\"{x:1221,y:825,t:1527019919775};\\\", \\\"{x:1221,y:821,t:1527019919792};\\\", \\\"{x:1222,y:818,t:1527019919809};\\\", \\\"{x:1222,y:812,t:1527019919826};\\\", \\\"{x:1222,y:808,t:1527019919842};\\\", \\\"{x:1221,y:802,t:1527019919860};\\\", \\\"{x:1218,y:798,t:1527019919876};\\\", \\\"{x:1216,y:796,t:1527019919893};\\\", \\\"{x:1214,y:795,t:1527019919909};\\\", \\\"{x:1214,y:794,t:1527019919926};\\\", \\\"{x:1214,y:793,t:1527019919942};\\\", \\\"{x:1214,y:792,t:1527019919959};\\\", \\\"{x:1211,y:791,t:1527019919977};\\\", \\\"{x:1209,y:790,t:1527019919999};\\\", \\\"{x:1208,y:790,t:1527019920009};\\\", \\\"{x:1207,y:790,t:1527019920026};\\\", \\\"{x:1205,y:789,t:1527019920042};\\\", \\\"{x:1204,y:788,t:1527019920059};\\\", \\\"{x:1202,y:787,t:1527019920076};\\\", \\\"{x:1201,y:787,t:1527019920092};\\\", \\\"{x:1199,y:787,t:1527019920108};\\\", \\\"{x:1197,y:785,t:1527019920126};\\\", \\\"{x:1195,y:785,t:1527019920142};\\\", \\\"{x:1195,y:784,t:1527019920158};\\\", \\\"{x:1194,y:784,t:1527019920199};\\\", \\\"{x:1192,y:784,t:1527019920239};\\\", \\\"{x:1190,y:783,t:1527019920352};\\\", \\\"{x:1190,y:782,t:1527019920367};\\\", \\\"{x:1189,y:782,t:1527019920416};\\\", \\\"{x:1189,y:781,t:1527019922096};\\\", \\\"{x:1189,y:780,t:1527019922111};\\\", \\\"{x:1189,y:777,t:1527019922127};\\\", \\\"{x:1189,y:775,t:1527019922145};\\\", \\\"{x:1189,y:774,t:1527019922160};\\\", \\\"{x:1189,y:773,t:1527019922177};\\\", \\\"{x:1189,y:772,t:1527019922215};\\\", \\\"{x:1189,y:771,t:1527019922231};\\\", \\\"{x:1189,y:770,t:1527019922246};\\\", \\\"{x:1189,y:769,t:1527019922375};\\\", \\\"{x:1188,y:767,t:1527019922839};\\\", \\\"{x:1187,y:766,t:1527019922847};\\\", \\\"{x:1146,y:748,t:1527019923159};\\\", \\\"{x:1076,y:720,t:1527019923168};\\\", \\\"{x:1031,y:702,t:1527019923178};\\\", \\\"{x:990,y:686,t:1527019923195};\\\", \\\"{x:974,y:680,t:1527019923212};\\\", \\\"{x:973,y:680,t:1527019923227};\\\", \\\"{x:968,y:678,t:1527019923367};\\\", \\\"{x:957,y:678,t:1527019923378};\\\", \\\"{x:869,y:676,t:1527019923394};\\\", \\\"{x:732,y:665,t:1527019923411};\\\", \\\"{x:555,y:636,t:1527019923428};\\\", \\\"{x:379,y:623,t:1527019923446};\\\", \\\"{x:253,y:615,t:1527019923462};\\\", \\\"{x:146,y:603,t:1527019923478};\\\", \\\"{x:52,y:589,t:1527019923498};\\\", \\\"{x:26,y:586,t:1527019923515};\\\", \\\"{x:15,y:583,t:1527019923532};\\\", \\\"{x:14,y:583,t:1527019923549};\\\", \\\"{x:13,y:582,t:1527019923565};\\\", \\\"{x:13,y:579,t:1527019923581};\\\", \\\"{x:32,y:569,t:1527019923598};\\\", \\\"{x:49,y:559,t:1527019923614};\\\", \\\"{x:64,y:549,t:1527019923633};\\\", \\\"{x:80,y:539,t:1527019923648};\\\", \\\"{x:95,y:532,t:1527019923665};\\\", \\\"{x:106,y:527,t:1527019923682};\\\", \\\"{x:111,y:525,t:1527019923698};\\\", \\\"{x:114,y:523,t:1527019923716};\\\", \\\"{x:117,y:523,t:1527019923732};\\\", \\\"{x:119,y:521,t:1527019923749};\\\", \\\"{x:121,y:521,t:1527019923764};\\\", \\\"{x:124,y:520,t:1527019923782};\\\", \\\"{x:125,y:518,t:1527019923799};\\\", \\\"{x:127,y:517,t:1527019923834};\\\", \\\"{x:127,y:516,t:1527019923849};\\\", \\\"{x:131,y:514,t:1527019923866};\\\", \\\"{x:145,y:508,t:1527019923882};\\\", \\\"{x:154,y:506,t:1527019923899};\\\", \\\"{x:162,y:503,t:1527019923916};\\\", \\\"{x:166,y:501,t:1527019923931};\\\", \\\"{x:171,y:501,t:1527019923949};\\\", \\\"{x:177,y:501,t:1527019923966};\\\", \\\"{x:185,y:501,t:1527019923981};\\\", \\\"{x:189,y:501,t:1527019923998};\\\", \\\"{x:189,y:500,t:1527019924150};\\\", \\\"{x:186,y:500,t:1527019924165};\\\", \\\"{x:175,y:500,t:1527019924182};\\\", \\\"{x:163,y:500,t:1527019924199};\\\", \\\"{x:161,y:501,t:1527019924216};\\\", \\\"{x:158,y:501,t:1527019924233};\\\", \\\"{x:157,y:501,t:1527019924249};\\\", \\\"{x:157,y:502,t:1527019924702};\\\", \\\"{x:159,y:503,t:1527019924716};\\\", \\\"{x:165,y:506,t:1527019924733};\\\", \\\"{x:174,y:514,t:1527019924751};\\\", \\\"{x:201,y:550,t:1527019924766};\\\", \\\"{x:250,y:591,t:1527019924783};\\\", \\\"{x:303,y:638,t:1527019924800};\\\", \\\"{x:342,y:674,t:1527019924816};\\\", \\\"{x:357,y:690,t:1527019924833};\\\", \\\"{x:364,y:698,t:1527019924850};\\\", \\\"{x:368,y:702,t:1527019924866};\\\", \\\"{x:375,y:709,t:1527019924883};\\\", \\\"{x:387,y:721,t:1527019924900};\\\", \\\"{x:417,y:742,t:1527019924916};\\\", \\\"{x:449,y:765,t:1527019924933};\\\", \\\"{x:465,y:777,t:1527019924950};\\\", \\\"{x:480,y:784,t:1527019924967};\\\", \\\"{x:485,y:787,t:1527019924983};\\\", \\\"{x:495,y:788,t:1527019925001};\\\", \\\"{x:506,y:787,t:1527019925018};\\\", \\\"{x:524,y:775,t:1527019925035};\\\", \\\"{x:537,y:764,t:1527019925050};\\\", \\\"{x:542,y:758,t:1527019925067};\\\", \\\"{x:543,y:756,t:1527019925085};\\\", \\\"{x:543,y:755,t:1527019925101};\\\", \\\"{x:544,y:754,t:1527019925118};\\\", \\\"{x:545,y:753,t:1527019925134};\\\", \\\"{x:545,y:750,t:1527019925150};\\\", \\\"{x:545,y:740,t:1527019925167};\\\", \\\"{x:545,y:735,t:1527019925183};\\\", \\\"{x:544,y:731,t:1527019925200};\\\", \\\"{x:543,y:728,t:1527019925218};\\\", \\\"{x:542,y:727,t:1527019925233};\\\", \\\"{x:541,y:727,t:1527019925278};\\\", \\\"{x:541,y:727,t:1527019925381};\\\", \\\"{x:540,y:727,t:1527019925400};\\\" ] }, { \\\"rt\\\": 37663, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 588228, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -F -03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:725,t:1527019927591};\\\", \\\"{x:545,y:711,t:1527019927604};\\\", \\\"{x:555,y:682,t:1527019927619};\\\", \\\"{x:565,y:605,t:1527019927640};\\\", \\\"{x:565,y:585,t:1527019927652};\\\", \\\"{x:565,y:548,t:1527019927668};\\\", \\\"{x:557,y:514,t:1527019927686};\\\", \\\"{x:548,y:496,t:1527019927702};\\\", \\\"{x:544,y:491,t:1527019927718};\\\", \\\"{x:544,y:488,t:1527019927735};\\\", \\\"{x:543,y:487,t:1527019927774};\\\", \\\"{x:550,y:487,t:1527019927871};\\\", \\\"{x:583,y:489,t:1527019927885};\\\", \\\"{x:648,y:500,t:1527019927902};\\\", \\\"{x:650,y:500,t:1527019928567};\\\", \\\"{x:653,y:500,t:1527019928575};\\\", \\\"{x:662,y:500,t:1527019928587};\\\", \\\"{x:703,y:507,t:1527019928603};\\\", \\\"{x:839,y:551,t:1527019928621};\\\", \\\"{x:1040,y:604,t:1527019928637};\\\", \\\"{x:1260,y:660,t:1527019928651};\\\", \\\"{x:1450,y:706,t:1527019928668};\\\", \\\"{x:1570,y:727,t:1527019928685};\\\", \\\"{x:1627,y:748,t:1527019928701};\\\", \\\"{x:1669,y:770,t:1527019928718};\\\", \\\"{x:1699,y:794,t:1527019928735};\\\", \\\"{x:1741,y:848,t:1527019928752};\\\", \\\"{x:1774,y:889,t:1527019928768};\\\", \\\"{x:1792,y:911,t:1527019928784};\\\", \\\"{x:1801,y:926,t:1527019928802};\\\", \\\"{x:1804,y:933,t:1527019928818};\\\", \\\"{x:1805,y:934,t:1527019928834};\\\", \\\"{x:1805,y:935,t:1527019928852};\\\", \\\"{x:1802,y:935,t:1527019928912};\\\", \\\"{x:1791,y:935,t:1527019928919};\\\", \\\"{x:1763,y:932,t:1527019928935};\\\", \\\"{x:1728,y:925,t:1527019928952};\\\", \\\"{x:1683,y:918,t:1527019928969};\\\", \\\"{x:1652,y:900,t:1527019928985};\\\", \\\"{x:1637,y:884,t:1527019929002};\\\", \\\"{x:1623,y:860,t:1527019929019};\\\", \\\"{x:1613,y:828,t:1527019929035};\\\", \\\"{x:1604,y:787,t:1527019929052};\\\", \\\"{x:1600,y:758,t:1527019929069};\\\", \\\"{x:1596,y:732,t:1527019929085};\\\", \\\"{x:1593,y:707,t:1527019929102};\\\", \\\"{x:1592,y:677,t:1527019929119};\\\", \\\"{x:1587,y:659,t:1527019929135};\\\", \\\"{x:1585,y:642,t:1527019929152};\\\", \\\"{x:1583,y:625,t:1527019929171};\\\", \\\"{x:1581,y:607,t:1527019929186};\\\", \\\"{x:1578,y:589,t:1527019929201};\\\", \\\"{x:1575,y:571,t:1527019929217};\\\", \\\"{x:1571,y:558,t:1527019929234};\\\", \\\"{x:1566,y:549,t:1527019929251};\\\", \\\"{x:1561,y:542,t:1527019929267};\\\", \\\"{x:1551,y:536,t:1527019929285};\\\", \\\"{x:1537,y:529,t:1527019929301};\\\", \\\"{x:1515,y:521,t:1527019929317};\\\", \\\"{x:1486,y:512,t:1527019929334};\\\", \\\"{x:1470,y:508,t:1527019929351};\\\", \\\"{x:1459,y:505,t:1527019929368};\\\", \\\"{x:1455,y:504,t:1527019929384};\\\", \\\"{x:1450,y:504,t:1527019929401};\\\", \\\"{x:1445,y:504,t:1527019929417};\\\", \\\"{x:1433,y:501,t:1527019929434};\\\", \\\"{x:1418,y:501,t:1527019929451};\\\", \\\"{x:1403,y:501,t:1527019929467};\\\", \\\"{x:1389,y:501,t:1527019929485};\\\", \\\"{x:1382,y:501,t:1527019929501};\\\", \\\"{x:1376,y:501,t:1527019929518};\\\", \\\"{x:1372,y:501,t:1527019929535};\\\", \\\"{x:1369,y:502,t:1527019929551};\\\", \\\"{x:1368,y:502,t:1527019929568};\\\", \\\"{x:1367,y:502,t:1527019929585};\\\", \\\"{x:1367,y:503,t:1527019929602};\\\", \\\"{x:1366,y:504,t:1527019929735};\\\", \\\"{x:1371,y:500,t:1527019929832};\\\", \\\"{x:1378,y:489,t:1527019929839};\\\", \\\"{x:1384,y:481,t:1527019929850};\\\", \\\"{x:1398,y:462,t:1527019929868};\\\", \\\"{x:1415,y:441,t:1527019929885};\\\", \\\"{x:1425,y:431,t:1527019929901};\\\", \\\"{x:1433,y:421,t:1527019929918};\\\", \\\"{x:1439,y:416,t:1527019929935};\\\", \\\"{x:1442,y:414,t:1527019929951};\\\", \\\"{x:1444,y:413,t:1527019929968};\\\", \\\"{x:1447,y:412,t:1527019929985};\\\", \\\"{x:1450,y:410,t:1527019930000};\\\", \\\"{x:1454,y:407,t:1527019930017};\\\", \\\"{x:1463,y:400,t:1527019930035};\\\", \\\"{x:1480,y:387,t:1527019930051};\\\", \\\"{x:1494,y:378,t:1527019930068};\\\", \\\"{x:1520,y:367,t:1527019930085};\\\", \\\"{x:1550,y:354,t:1527019930100};\\\", \\\"{x:1587,y:334,t:1527019930118};\\\", \\\"{x:1631,y:308,t:1527019930135};\\\", \\\"{x:1651,y:298,t:1527019930151};\\\", \\\"{x:1661,y:295,t:1527019930168};\\\", \\\"{x:1664,y:294,t:1527019930185};\\\", \\\"{x:1665,y:293,t:1527019930223};\\\", \\\"{x:1666,y:293,t:1527019930247};\\\", \\\"{x:1666,y:299,t:1527019930255};\\\", \\\"{x:1668,y:308,t:1527019930268};\\\", \\\"{x:1669,y:328,t:1527019930284};\\\", \\\"{x:1669,y:353,t:1527019930301};\\\", \\\"{x:1667,y:375,t:1527019930318};\\\", \\\"{x:1654,y:398,t:1527019930334};\\\", \\\"{x:1622,y:424,t:1527019930351};\\\", \\\"{x:1599,y:434,t:1527019930367};\\\", \\\"{x:1583,y:441,t:1527019930384};\\\", \\\"{x:1579,y:443,t:1527019930401};\\\", \\\"{x:1574,y:447,t:1527019930417};\\\", \\\"{x:1569,y:447,t:1527019930434};\\\", \\\"{x:1558,y:449,t:1527019930450};\\\", \\\"{x:1536,y:452,t:1527019930468};\\\", \\\"{x:1504,y:457,t:1527019930484};\\\", \\\"{x:1482,y:460,t:1527019930501};\\\", \\\"{x:1455,y:464,t:1527019930518};\\\", \\\"{x:1433,y:469,t:1527019930534};\\\", \\\"{x:1398,y:479,t:1527019930551};\\\", \\\"{x:1377,y:486,t:1527019930567};\\\", \\\"{x:1356,y:493,t:1527019930584};\\\", \\\"{x:1342,y:502,t:1527019930601};\\\", \\\"{x:1331,y:513,t:1527019930618};\\\", \\\"{x:1323,y:529,t:1527019930634};\\\", \\\"{x:1316,y:548,t:1527019930651};\\\", \\\"{x:1313,y:572,t:1527019930667};\\\", \\\"{x:1313,y:603,t:1527019930684};\\\", \\\"{x:1314,y:632,t:1527019930701};\\\", \\\"{x:1322,y:654,t:1527019930717};\\\", \\\"{x:1325,y:669,t:1527019930734};\\\", \\\"{x:1331,y:689,t:1527019930751};\\\", \\\"{x:1334,y:698,t:1527019930767};\\\", \\\"{x:1334,y:700,t:1527019930784};\\\", \\\"{x:1334,y:705,t:1527019930800};\\\", \\\"{x:1336,y:709,t:1527019930817};\\\", \\\"{x:1338,y:713,t:1527019930834};\\\", \\\"{x:1338,y:716,t:1527019930851};\\\", \\\"{x:1339,y:718,t:1527019930867};\\\", \\\"{x:1339,y:720,t:1527019930884};\\\", \\\"{x:1339,y:723,t:1527019930901};\\\", \\\"{x:1341,y:727,t:1527019930917};\\\", \\\"{x:1342,y:730,t:1527019930934};\\\", \\\"{x:1342,y:737,t:1527019930951};\\\", \\\"{x:1342,y:740,t:1527019930967};\\\", \\\"{x:1342,y:742,t:1527019930983};\\\", \\\"{x:1342,y:743,t:1527019931001};\\\", \\\"{x:1342,y:744,t:1527019931017};\\\", \\\"{x:1342,y:746,t:1527019931034};\\\", \\\"{x:1342,y:747,t:1527019931050};\\\", \\\"{x:1342,y:745,t:1527019931152};\\\", \\\"{x:1348,y:736,t:1527019931167};\\\", \\\"{x:1356,y:726,t:1527019931184};\\\", \\\"{x:1359,y:723,t:1527019931200};\\\", \\\"{x:1362,y:720,t:1527019931217};\\\", \\\"{x:1367,y:718,t:1527019931234};\\\", \\\"{x:1368,y:716,t:1527019931250};\\\", \\\"{x:1369,y:716,t:1527019931267};\\\", \\\"{x:1370,y:715,t:1527019931284};\\\", \\\"{x:1370,y:714,t:1527019931399};\\\", \\\"{x:1363,y:711,t:1527019931416};\\\", \\\"{x:1350,y:707,t:1527019931434};\\\", \\\"{x:1338,y:704,t:1527019931450};\\\", \\\"{x:1333,y:700,t:1527019931467};\\\", \\\"{x:1329,y:698,t:1527019931484};\\\", \\\"{x:1328,y:697,t:1527019931500};\\\", \\\"{x:1326,y:696,t:1527019931517};\\\", \\\"{x:1326,y:694,t:1527019931534};\\\", \\\"{x:1326,y:693,t:1527019931550};\\\", \\\"{x:1326,y:690,t:1527019931567};\\\", \\\"{x:1326,y:689,t:1527019931656};\\\", \\\"{x:1329,y:689,t:1527019931668};\\\", \\\"{x:1338,y:692,t:1527019931683};\\\", \\\"{x:1343,y:693,t:1527019931701};\\\", \\\"{x:1346,y:694,t:1527019931717};\\\", \\\"{x:1348,y:694,t:1527019931733};\\\", \\\"{x:1349,y:696,t:1527019952240};\\\", \\\"{x:1362,y:716,t:1527019952256};\\\", \\\"{x:1427,y:818,t:1527019952270};\\\", \\\"{x:1540,y:974,t:1527019952287};\\\", \\\"{x:1589,y:1039,t:1527019952304};\\\", \\\"{x:1621,y:1084,t:1527019952320};\\\", \\\"{x:1644,y:1114,t:1527019952337};\\\", \\\"{x:1654,y:1124,t:1527019952354};\\\", \\\"{x:1655,y:1125,t:1527019952369};\\\", \\\"{x:1660,y:1123,t:1527019952387};\\\", \\\"{x:1669,y:1112,t:1527019952404};\\\", \\\"{x:1673,y:1104,t:1527019952420};\\\", \\\"{x:1679,y:1097,t:1527019952436};\\\", \\\"{x:1684,y:1091,t:1527019952454};\\\", \\\"{x:1687,y:1086,t:1527019952469};\\\", \\\"{x:1688,y:1077,t:1527019952486};\\\", \\\"{x:1688,y:1071,t:1527019952503};\\\", \\\"{x:1688,y:1063,t:1527019952519};\\\", \\\"{x:1677,y:1048,t:1527019952537};\\\", \\\"{x:1663,y:1031,t:1527019952553};\\\", \\\"{x:1651,y:1018,t:1527019952570};\\\", \\\"{x:1637,y:1008,t:1527019952587};\\\", \\\"{x:1625,y:1000,t:1527019952603};\\\", \\\"{x:1616,y:993,t:1527019952620};\\\", \\\"{x:1613,y:989,t:1527019952637};\\\", \\\"{x:1609,y:986,t:1527019952653};\\\", \\\"{x:1607,y:983,t:1527019952670};\\\", \\\"{x:1604,y:980,t:1527019952687};\\\", \\\"{x:1602,y:978,t:1527019952702};\\\", \\\"{x:1601,y:976,t:1527019952720};\\\", \\\"{x:1600,y:975,t:1527019952737};\\\", \\\"{x:1600,y:973,t:1527019952753};\\\", \\\"{x:1600,y:972,t:1527019952791};\\\", \\\"{x:1601,y:970,t:1527019952803};\\\", \\\"{x:1605,y:970,t:1527019952819};\\\", \\\"{x:1612,y:970,t:1527019952837};\\\", \\\"{x:1616,y:970,t:1527019952853};\\\", \\\"{x:1617,y:970,t:1527019952870};\\\", \\\"{x:1620,y:969,t:1527019952886};\\\", \\\"{x:1619,y:968,t:1527019953128};\\\", \\\"{x:1618,y:968,t:1527019953151};\\\", \\\"{x:1617,y:967,t:1527019953200};\\\", \\\"{x:1616,y:967,t:1527019953375};\\\", \\\"{x:1615,y:966,t:1527019953386};\\\", \\\"{x:1614,y:966,t:1527019954247};\\\", \\\"{x:1609,y:963,t:1527019962735};\\\", \\\"{x:1577,y:944,t:1527019962747};\\\", \\\"{x:1391,y:844,t:1527019962763};\\\", \\\"{x:1150,y:719,t:1527019962780};\\\", \\\"{x:900,y:621,t:1527019962799};\\\", \\\"{x:664,y:532,t:1527019962814};\\\", \\\"{x:452,y:456,t:1527019962830};\\\", \\\"{x:424,y:444,t:1527019962865};\\\", \\\"{x:428,y:448,t:1527019962998};\\\", \\\"{x:443,y:468,t:1527019963016};\\\", \\\"{x:461,y:490,t:1527019963033};\\\", \\\"{x:491,y:523,t:1527019963049};\\\", \\\"{x:522,y:565,t:1527019963066};\\\", \\\"{x:548,y:596,t:1527019963082};\\\", \\\"{x:560,y:607,t:1527019963099};\\\", \\\"{x:562,y:609,t:1527019963115};\\\", \\\"{x:563,y:609,t:1527019963132};\\\", \\\"{x:566,y:610,t:1527019963149};\\\", \\\"{x:570,y:610,t:1527019963165};\\\", \\\"{x:581,y:610,t:1527019963182};\\\", \\\"{x:590,y:610,t:1527019963198};\\\", \\\"{x:600,y:607,t:1527019963216};\\\", \\\"{x:610,y:599,t:1527019963232};\\\", \\\"{x:615,y:594,t:1527019963249};\\\", \\\"{x:617,y:587,t:1527019963267};\\\", \\\"{x:618,y:584,t:1527019963283};\\\", \\\"{x:619,y:580,t:1527019963299};\\\", \\\"{x:619,y:579,t:1527019963318};\\\", \\\"{x:619,y:578,t:1527019963333};\\\", \\\"{x:619,y:577,t:1527019963349};\\\", \\\"{x:619,y:575,t:1527019963374};\\\", \\\"{x:618,y:574,t:1527019963399};\\\", \\\"{x:613,y:577,t:1527019963686};\\\", \\\"{x:604,y:585,t:1527019963699};\\\", \\\"{x:586,y:602,t:1527019963716};\\\", \\\"{x:572,y:615,t:1527019963732};\\\", \\\"{x:558,y:629,t:1527019963749};\\\", \\\"{x:547,y:641,t:1527019963766};\\\", \\\"{x:545,y:645,t:1527019963783};\\\", \\\"{x:544,y:648,t:1527019963799};\\\", \\\"{x:542,y:650,t:1527019963816};\\\", \\\"{x:539,y:656,t:1527019963833};\\\", \\\"{x:535,y:665,t:1527019963849};\\\", \\\"{x:527,y:678,t:1527019963866};\\\", \\\"{x:522,y:690,t:1527019963883};\\\", \\\"{x:521,y:693,t:1527019963899};\\\", \\\"{x:520,y:698,t:1527019963916};\\\", \\\"{x:519,y:698,t:1527019963933};\\\", \\\"{x:518,y:700,t:1527019963950};\\\", \\\"{x:518,y:706,t:1527019963966};\\\", \\\"{x:518,y:713,t:1527019963982};\\\", \\\"{x:518,y:718,t:1527019964000};\\\", \\\"{x:518,y:719,t:1527019964016};\\\", \\\"{x:518,y:720,t:1527019964035};\\\", \\\"{x:518,y:722,t:1527019964050};\\\", \\\"{x:518,y:726,t:1527019964065};\\\", \\\"{x:520,y:730,t:1527019964083};\\\", \\\"{x:520,y:733,t:1527019964099};\\\", \\\"{x:520,y:734,t:1527019964116};\\\", \\\"{x:521,y:734,t:1527019964134};\\\", \\\"{x:522,y:734,t:1527019964599};\\\", \\\"{x:523,y:734,t:1527019964606};\\\", \\\"{x:525,y:733,t:1527019964639};\\\", \\\"{x:525,y:732,t:1527019964650};\\\", \\\"{x:526,y:732,t:1527019964667};\\\", \\\"{x:528,y:731,t:1527019964683};\\\", \\\"{x:528,y:730,t:1527019964700};\\\", \\\"{x:529,y:729,t:1527019964717};\\\", \\\"{x:531,y:725,t:1527019964734};\\\", \\\"{x:531,y:724,t:1527019964750};\\\", \\\"{x:538,y:708,t:1527019964766};\\\", \\\"{x:542,y:691,t:1527019964784};\\\", \\\"{x:550,y:665,t:1527019964800};\\\", \\\"{x:567,y:612,t:1527019964817};\\\", \\\"{x:578,y:563,t:1527019964834};\\\", \\\"{x:583,y:528,t:1527019964850};\\\", \\\"{x:584,y:501,t:1527019964867};\\\", \\\"{x:584,y:481,t:1527019964884};\\\", \\\"{x:584,y:463,t:1527019964900};\\\", \\\"{x:584,y:450,t:1527019964917};\\\", \\\"{x:582,y:440,t:1527019964934};\\\", \\\"{x:581,y:438,t:1527019964950};\\\", \\\"{x:580,y:436,t:1527019964967};\\\" ] }, { \\\"rt\\\": 10666, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 600194, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:579,y:446,t:1527019966119};\\\", \\\"{x:592,y:531,t:1527019966135};\\\", \\\"{x:610,y:624,t:1527019966152};\\\", \\\"{x:627,y:693,t:1527019966169};\\\", \\\"{x:642,y:738,t:1527019966185};\\\", \\\"{x:650,y:759,t:1527019966201};\\\", \\\"{x:654,y:769,t:1527019966218};\\\", \\\"{x:656,y:773,t:1527019966235};\\\", \\\"{x:656,y:774,t:1527019966251};\\\", \\\"{x:656,y:775,t:1527019966268};\\\", \\\"{x:655,y:775,t:1527019966454};\\\", \\\"{x:655,y:774,t:1527019966478};\\\", \\\"{x:654,y:773,t:1527019966486};\\\", \\\"{x:654,y:772,t:1527019966534};\\\", \\\"{x:654,y:771,t:1527019966583};\\\", \\\"{x:654,y:770,t:1527019966606};\\\", \\\"{x:654,y:769,t:1527019966702};\\\", \\\"{x:654,y:768,t:1527019966749};\\\", \\\"{x:654,y:767,t:1527019966999};\\\", \\\"{x:656,y:767,t:1527019968887};\\\", \\\"{x:701,y:765,t:1527019968905};\\\", \\\"{x:834,y:807,t:1527019968920};\\\", \\\"{x:1006,y:863,t:1527019968938};\\\", \\\"{x:1149,y:920,t:1527019968955};\\\", \\\"{x:1253,y:961,t:1527019968970};\\\", \\\"{x:1296,y:977,t:1527019968988};\\\", \\\"{x:1306,y:979,t:1527019969006};\\\", \\\"{x:1306,y:976,t:1527019969071};\\\", \\\"{x:1300,y:969,t:1527019969088};\\\", \\\"{x:1298,y:967,t:1527019969105};\\\", \\\"{x:1301,y:969,t:1527019969215};\\\", \\\"{x:1310,y:977,t:1527019969223};\\\", \\\"{x:1317,y:982,t:1527019969238};\\\", \\\"{x:1327,y:993,t:1527019969254};\\\", \\\"{x:1331,y:995,t:1527019969271};\\\", \\\"{x:1333,y:996,t:1527019969288};\\\", \\\"{x:1334,y:996,t:1527019969305};\\\", \\\"{x:1337,y:996,t:1527019969343};\\\", \\\"{x:1338,y:996,t:1527019969355};\\\", \\\"{x:1339,y:996,t:1527019969371};\\\", \\\"{x:1342,y:996,t:1527019969388};\\\", \\\"{x:1344,y:993,t:1527019969405};\\\", \\\"{x:1346,y:990,t:1527019969422};\\\", \\\"{x:1350,y:987,t:1527019969438};\\\", \\\"{x:1354,y:983,t:1527019969455};\\\", \\\"{x:1354,y:982,t:1527019969471};\\\", \\\"{x:1354,y:981,t:1527019969488};\\\", \\\"{x:1355,y:980,t:1527019969505};\\\", \\\"{x:1355,y:979,t:1527019969527};\\\", \\\"{x:1355,y:978,t:1527019969599};\\\", \\\"{x:1354,y:977,t:1527019969615};\\\", \\\"{x:1354,y:975,t:1527019969655};\\\", \\\"{x:1353,y:975,t:1527019969671};\\\", \\\"{x:1351,y:974,t:1527019969688};\\\", \\\"{x:1351,y:973,t:1527019969704};\\\", \\\"{x:1349,y:972,t:1527019969722};\\\", \\\"{x:1348,y:971,t:1527019969738};\\\", \\\"{x:1346,y:968,t:1527019969755};\\\", \\\"{x:1342,y:963,t:1527019969772};\\\", \\\"{x:1339,y:956,t:1527019969789};\\\", \\\"{x:1335,y:948,t:1527019969805};\\\", \\\"{x:1333,y:941,t:1527019969822};\\\", \\\"{x:1332,y:936,t:1527019969839};\\\", \\\"{x:1331,y:932,t:1527019969855};\\\", \\\"{x:1331,y:929,t:1527019969871};\\\", \\\"{x:1329,y:925,t:1527019969889};\\\", \\\"{x:1329,y:920,t:1527019969905};\\\", \\\"{x:1329,y:915,t:1527019969921};\\\", \\\"{x:1329,y:907,t:1527019969939};\\\", \\\"{x:1329,y:899,t:1527019969954};\\\", \\\"{x:1330,y:888,t:1527019969971};\\\", \\\"{x:1334,y:875,t:1527019969989};\\\", \\\"{x:1339,y:860,t:1527019970004};\\\", \\\"{x:1341,y:848,t:1527019970022};\\\", \\\"{x:1346,y:833,t:1527019970039};\\\", \\\"{x:1348,y:822,t:1527019970056};\\\", \\\"{x:1348,y:812,t:1527019970072};\\\", \\\"{x:1349,y:805,t:1527019970089};\\\", \\\"{x:1350,y:801,t:1527019970106};\\\", \\\"{x:1352,y:796,t:1527019970122};\\\", \\\"{x:1352,y:794,t:1527019970138};\\\", \\\"{x:1352,y:790,t:1527019970155};\\\", \\\"{x:1352,y:789,t:1527019970172};\\\", \\\"{x:1352,y:787,t:1527019970189};\\\", \\\"{x:1352,y:786,t:1527019970207};\\\", \\\"{x:1351,y:785,t:1527019970360};\\\", \\\"{x:1348,y:786,t:1527019970372};\\\", \\\"{x:1339,y:795,t:1527019970389};\\\", \\\"{x:1337,y:820,t:1527019970406};\\\", \\\"{x:1337,y:850,t:1527019970422};\\\", \\\"{x:1335,y:888,t:1527019970439};\\\", \\\"{x:1334,y:901,t:1527019970455};\\\", \\\"{x:1334,y:912,t:1527019970473};\\\", \\\"{x:1334,y:924,t:1527019970489};\\\", \\\"{x:1334,y:933,t:1527019970506};\\\", \\\"{x:1334,y:937,t:1527019970523};\\\", \\\"{x:1334,y:938,t:1527019970539};\\\", \\\"{x:1334,y:929,t:1527019970671};\\\", \\\"{x:1334,y:918,t:1527019970679};\\\", \\\"{x:1334,y:908,t:1527019970688};\\\", \\\"{x:1334,y:884,t:1527019970705};\\\", \\\"{x:1334,y:861,t:1527019970723};\\\", \\\"{x:1334,y:840,t:1527019970738};\\\", \\\"{x:1334,y:821,t:1527019970755};\\\", \\\"{x:1334,y:811,t:1527019970773};\\\", \\\"{x:1334,y:804,t:1527019970789};\\\", \\\"{x:1334,y:800,t:1527019970806};\\\", \\\"{x:1335,y:795,t:1527019970823};\\\", \\\"{x:1335,y:792,t:1527019970839};\\\", \\\"{x:1335,y:791,t:1527019970856};\\\", \\\"{x:1335,y:789,t:1527019970873};\\\", \\\"{x:1335,y:787,t:1527019970889};\\\", \\\"{x:1335,y:786,t:1527019970905};\\\", \\\"{x:1335,y:783,t:1527019970923};\\\", \\\"{x:1335,y:780,t:1527019970940};\\\", \\\"{x:1335,y:778,t:1527019970956};\\\", \\\"{x:1335,y:774,t:1527019970973};\\\", \\\"{x:1335,y:771,t:1527019970990};\\\", \\\"{x:1335,y:769,t:1527019971006};\\\", \\\"{x:1335,y:766,t:1527019971023};\\\", \\\"{x:1335,y:765,t:1527019971039};\\\", \\\"{x:1336,y:763,t:1527019971056};\\\", \\\"{x:1337,y:763,t:1527019971072};\\\", \\\"{x:1337,y:761,t:1527019971095};\\\", \\\"{x:1337,y:760,t:1527019971127};\\\", \\\"{x:1338,y:758,t:1527019971167};\\\", \\\"{x:1337,y:758,t:1527019971335};\\\", \\\"{x:1334,y:759,t:1527019971343};\\\", \\\"{x:1333,y:760,t:1527019971356};\\\", \\\"{x:1325,y:763,t:1527019971373};\\\", \\\"{x:1317,y:766,t:1527019971390};\\\", \\\"{x:1311,y:771,t:1527019971406};\\\", \\\"{x:1309,y:771,t:1527019971423};\\\", \\\"{x:1308,y:773,t:1527019971440};\\\", \\\"{x:1307,y:773,t:1527019971457};\\\", \\\"{x:1305,y:773,t:1527019971719};\\\", \\\"{x:1303,y:773,t:1527019971735};\\\", \\\"{x:1302,y:773,t:1527019971751};\\\", \\\"{x:1300,y:773,t:1527019971758};\\\", \\\"{x:1300,y:772,t:1527019971774};\\\", \\\"{x:1296,y:771,t:1527019971790};\\\", \\\"{x:1268,y:763,t:1527019971807};\\\", \\\"{x:1201,y:754,t:1527019971824};\\\", \\\"{x:1104,y:743,t:1527019971840};\\\", \\\"{x:1000,y:733,t:1527019971857};\\\", \\\"{x:940,y:731,t:1527019971874};\\\", \\\"{x:919,y:731,t:1527019971890};\\\", \\\"{x:915,y:731,t:1527019971906};\\\", \\\"{x:914,y:731,t:1527019971923};\\\", \\\"{x:914,y:730,t:1527019971939};\\\", \\\"{x:904,y:729,t:1527019971956};\\\", \\\"{x:880,y:721,t:1527019971973};\\\", \\\"{x:840,y:700,t:1527019971990};\\\", \\\"{x:734,y:656,t:1527019972007};\\\", \\\"{x:671,y:628,t:1527019972025};\\\", \\\"{x:616,y:605,t:1527019972039};\\\", \\\"{x:600,y:598,t:1527019972056};\\\", \\\"{x:598,y:596,t:1527019972085};\\\", \\\"{x:595,y:591,t:1527019972102};\\\", \\\"{x:592,y:580,t:1527019972119};\\\", \\\"{x:590,y:571,t:1527019972139};\\\", \\\"{x:587,y:563,t:1527019972156};\\\", \\\"{x:586,y:558,t:1527019972174};\\\", \\\"{x:584,y:554,t:1527019972189};\\\", \\\"{x:581,y:547,t:1527019972206};\\\", \\\"{x:579,y:544,t:1527019972223};\\\", \\\"{x:576,y:540,t:1527019972240};\\\", \\\"{x:568,y:536,t:1527019972256};\\\", \\\"{x:561,y:532,t:1527019972273};\\\", \\\"{x:541,y:527,t:1527019972290};\\\", \\\"{x:519,y:522,t:1527019972307};\\\", \\\"{x:494,y:517,t:1527019972323};\\\", \\\"{x:475,y:514,t:1527019972340};\\\", \\\"{x:461,y:514,t:1527019972357};\\\", \\\"{x:456,y:514,t:1527019972373};\\\", \\\"{x:453,y:514,t:1527019972391};\\\", \\\"{x:449,y:513,t:1527019972407};\\\", \\\"{x:441,y:513,t:1527019972423};\\\", \\\"{x:431,y:515,t:1527019972440};\\\", \\\"{x:418,y:519,t:1527019972457};\\\", \\\"{x:407,y:523,t:1527019972474};\\\", \\\"{x:399,y:526,t:1527019972491};\\\", \\\"{x:393,y:531,t:1527019972507};\\\", \\\"{x:389,y:535,t:1527019972523};\\\", \\\"{x:386,y:537,t:1527019972540};\\\", \\\"{x:385,y:539,t:1527019972556};\\\", \\\"{x:384,y:540,t:1527019972573};\\\", \\\"{x:382,y:541,t:1527019972590};\\\", \\\"{x:382,y:543,t:1527019972614};\\\", \\\"{x:381,y:545,t:1527019972624};\\\", \\\"{x:382,y:555,t:1527019972641};\\\", \\\"{x:397,y:573,t:1527019972658};\\\", \\\"{x:423,y:596,t:1527019972674};\\\", \\\"{x:472,y:617,t:1527019972691};\\\", \\\"{x:528,y:634,t:1527019972707};\\\", \\\"{x:586,y:646,t:1527019972723};\\\", \\\"{x:628,y:648,t:1527019972740};\\\", \\\"{x:656,y:648,t:1527019972756};\\\", \\\"{x:670,y:648,t:1527019972773};\\\", \\\"{x:681,y:644,t:1527019972789};\\\", \\\"{x:691,y:640,t:1527019972806};\\\", \\\"{x:701,y:633,t:1527019972823};\\\", \\\"{x:710,y:626,t:1527019972840};\\\", \\\"{x:719,y:618,t:1527019972856};\\\", \\\"{x:724,y:612,t:1527019972874};\\\", \\\"{x:727,y:607,t:1527019972890};\\\", \\\"{x:729,y:602,t:1527019972907};\\\", \\\"{x:730,y:599,t:1527019972924};\\\", \\\"{x:730,y:598,t:1527019972940};\\\", \\\"{x:731,y:596,t:1527019972958};\\\", \\\"{x:731,y:594,t:1527019972973};\\\", \\\"{x:729,y:589,t:1527019972993};\\\", \\\"{x:724,y:583,t:1527019973007};\\\", \\\"{x:717,y:579,t:1527019973025};\\\", \\\"{x:710,y:578,t:1527019973040};\\\", \\\"{x:702,y:574,t:1527019973057};\\\", \\\"{x:696,y:573,t:1527019973074};\\\", \\\"{x:689,y:572,t:1527019973090};\\\", \\\"{x:681,y:571,t:1527019973107};\\\", \\\"{x:674,y:570,t:1527019973123};\\\", \\\"{x:669,y:570,t:1527019973140};\\\", \\\"{x:663,y:570,t:1527019973157};\\\", \\\"{x:657,y:570,t:1527019973173};\\\", \\\"{x:649,y:570,t:1527019973191};\\\", \\\"{x:643,y:572,t:1527019973208};\\\", \\\"{x:636,y:573,t:1527019973225};\\\", \\\"{x:630,y:576,t:1527019973240};\\\", \\\"{x:627,y:577,t:1527019973257};\\\", \\\"{x:623,y:579,t:1527019973274};\\\", \\\"{x:620,y:579,t:1527019973291};\\\", \\\"{x:616,y:580,t:1527019973307};\\\", \\\"{x:611,y:583,t:1527019973324};\\\", \\\"{x:608,y:584,t:1527019973340};\\\", \\\"{x:596,y:586,t:1527019973357};\\\", \\\"{x:565,y:588,t:1527019973373};\\\", \\\"{x:525,y:588,t:1527019973391};\\\", \\\"{x:458,y:578,t:1527019973408};\\\", \\\"{x:397,y:570,t:1527019973424};\\\", \\\"{x:338,y:562,t:1527019973441};\\\", \\\"{x:282,y:554,t:1527019973457};\\\", \\\"{x:252,y:551,t:1527019973475};\\\", \\\"{x:235,y:547,t:1527019973491};\\\", \\\"{x:226,y:547,t:1527019973507};\\\", \\\"{x:223,y:547,t:1527019973524};\\\", \\\"{x:220,y:546,t:1527019973541};\\\", \\\"{x:219,y:546,t:1527019973557};\\\", \\\"{x:216,y:544,t:1527019973574};\\\", \\\"{x:214,y:544,t:1527019973591};\\\", \\\"{x:213,y:544,t:1527019973607};\\\", \\\"{x:209,y:544,t:1527019973624};\\\", \\\"{x:206,y:544,t:1527019973641};\\\", \\\"{x:199,y:543,t:1527019973657};\\\", \\\"{x:196,y:543,t:1527019973674};\\\", \\\"{x:195,y:543,t:1527019973692};\\\", \\\"{x:192,y:543,t:1527019973707};\\\", \\\"{x:189,y:543,t:1527019973725};\\\", \\\"{x:188,y:544,t:1527019973741};\\\", \\\"{x:186,y:545,t:1527019973758};\\\", \\\"{x:185,y:545,t:1527019973774};\\\", \\\"{x:183,y:545,t:1527019973792};\\\", \\\"{x:182,y:545,t:1527019973814};\\\", \\\"{x:192,y:543,t:1527019974111};\\\", \\\"{x:206,y:543,t:1527019974125};\\\", \\\"{x:242,y:543,t:1527019974141};\\\", \\\"{x:287,y:543,t:1527019974158};\\\", \\\"{x:305,y:543,t:1527019974174};\\\", \\\"{x:319,y:543,t:1527019974191};\\\", \\\"{x:343,y:547,t:1527019974208};\\\", \\\"{x:373,y:552,t:1527019974224};\\\", \\\"{x:412,y:556,t:1527019974242};\\\", \\\"{x:433,y:556,t:1527019974259};\\\", \\\"{x:446,y:556,t:1527019974275};\\\", \\\"{x:460,y:556,t:1527019974292};\\\", \\\"{x:482,y:551,t:1527019974309};\\\", \\\"{x:509,y:545,t:1527019974327};\\\", \\\"{x:532,y:541,t:1527019974341};\\\", \\\"{x:551,y:537,t:1527019974358};\\\", \\\"{x:555,y:535,t:1527019974376};\\\", \\\"{x:560,y:534,t:1527019974391};\\\", \\\"{x:563,y:533,t:1527019974408};\\\", \\\"{x:565,y:531,t:1527019974426};\\\", \\\"{x:566,y:531,t:1527019974441};\\\", \\\"{x:567,y:530,t:1527019974462};\\\", \\\"{x:569,y:529,t:1527019974494};\\\", \\\"{x:573,y:527,t:1527019974511};\\\", \\\"{x:574,y:526,t:1527019974525};\\\", \\\"{x:579,y:524,t:1527019974542};\\\", \\\"{x:580,y:523,t:1527019974558};\\\", \\\"{x:583,y:523,t:1527019974574};\\\", \\\"{x:591,y:522,t:1527019974591};\\\", \\\"{x:610,y:519,t:1527019974607};\\\", \\\"{x:635,y:517,t:1527019974625};\\\", \\\"{x:658,y:513,t:1527019974640};\\\", \\\"{x:673,y:513,t:1527019974658};\\\", \\\"{x:687,y:511,t:1527019974675};\\\", \\\"{x:703,y:511,t:1527019974692};\\\", \\\"{x:725,y:511,t:1527019974710};\\\", \\\"{x:752,y:511,t:1527019974726};\\\", \\\"{x:778,y:511,t:1527019974741};\\\", \\\"{x:800,y:509,t:1527019974758};\\\", \\\"{x:805,y:508,t:1527019974775};\\\", \\\"{x:806,y:508,t:1527019974887};\\\", \\\"{x:808,y:508,t:1527019974967};\\\", \\\"{x:809,y:507,t:1527019974975};\\\", \\\"{x:813,y:505,t:1527019974992};\\\", \\\"{x:820,y:504,t:1527019975010};\\\", \\\"{x:829,y:501,t:1527019975026};\\\", \\\"{x:832,y:501,t:1527019975042};\\\", \\\"{x:835,y:501,t:1527019975059};\\\", \\\"{x:836,y:501,t:1527019975087};\\\", \\\"{x:837,y:501,t:1527019975094};\\\", \\\"{x:838,y:501,t:1527019975110};\\\", \\\"{x:839,y:501,t:1527019975190};\\\", \\\"{x:840,y:501,t:1527019975208};\\\", \\\"{x:841,y:501,t:1527019975230};\\\", \\\"{x:841,y:501,t:1527019975266};\\\", \\\"{x:841,y:502,t:1527019975333};\\\", \\\"{x:833,y:508,t:1527019975342};\\\", \\\"{x:813,y:535,t:1527019975360};\\\", \\\"{x:784,y:578,t:1527019975376};\\\", \\\"{x:768,y:603,t:1527019975393};\\\", \\\"{x:754,y:623,t:1527019975409};\\\", \\\"{x:746,y:642,t:1527019975426};\\\", \\\"{x:741,y:655,t:1527019975442};\\\", \\\"{x:738,y:664,t:1527019975459};\\\", \\\"{x:734,y:672,t:1527019975475};\\\", \\\"{x:732,y:678,t:1527019975492};\\\", \\\"{x:727,y:686,t:1527019975509};\\\", \\\"{x:721,y:692,t:1527019975525};\\\", \\\"{x:709,y:699,t:1527019975542};\\\", \\\"{x:696,y:704,t:1527019975559};\\\", \\\"{x:677,y:706,t:1527019975577};\\\", \\\"{x:651,y:706,t:1527019975592};\\\", \\\"{x:621,y:706,t:1527019975610};\\\", \\\"{x:595,y:706,t:1527019975624};\\\", \\\"{x:583,y:706,t:1527019975639};\\\", \\\"{x:579,y:706,t:1527019975656};\\\", \\\"{x:578,y:706,t:1527019975673};\\\", \\\"{x:577,y:706,t:1527019975690};\\\", \\\"{x:576,y:706,t:1527019975707};\\\", \\\"{x:574,y:706,t:1527019975747};\\\", \\\"{x:574,y:709,t:1527019975757};\\\", \\\"{x:573,y:716,t:1527019975773};\\\", \\\"{x:573,y:719,t:1527019975789};\\\", \\\"{x:573,y:720,t:1527019975806};\\\", \\\"{x:573,y:723,t:1527019975824};\\\", \\\"{x:573,y:724,t:1527019975840};\\\", \\\"{x:573,y:725,t:1527019975857};\\\", \\\"{x:573,y:726,t:1527019975874};\\\", \\\"{x:572,y:728,t:1527019975892};\\\", \\\"{x:571,y:728,t:1527019975907};\\\", \\\"{x:569,y:730,t:1527019975922};\\\", \\\"{x:568,y:730,t:1527019975940};\\\", \\\"{x:566,y:731,t:1527019975956};\\\", \\\"{x:564,y:732,t:1527019975979};\\\", \\\"{x:562,y:732,t:1527019975989};\\\", \\\"{x:555,y:733,t:1527019976006};\\\", \\\"{x:547,y:733,t:1527019976023};\\\", \\\"{x:538,y:733,t:1527019976040};\\\", \\\"{x:534,y:733,t:1527019976056};\\\", \\\"{x:533,y:733,t:1527019976083};\\\", \\\"{x:534,y:732,t:1527019976651};\\\", \\\"{x:539,y:730,t:1527019977003};\\\", \\\"{x:545,y:728,t:1527019977012};\\\", \\\"{x:554,y:723,t:1527019977025};\\\", \\\"{x:576,y:718,t:1527019977041};\\\", \\\"{x:613,y:711,t:1527019977057};\\\", \\\"{x:664,y:697,t:1527019977075};\\\", \\\"{x:685,y:693,t:1527019977090};\\\", \\\"{x:821,y:682,t:1527019977107};\\\", \\\"{x:900,y:678,t:1527019977125};\\\", \\\"{x:953,y:678,t:1527019977141};\\\", \\\"{x:974,y:675,t:1527019977158};\\\", \\\"{x:979,y:673,t:1527019977174};\\\", \\\"{x:982,y:672,t:1527019977192};\\\" ] }, { \\\"rt\\\": 8535, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 609989, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:988,y:679,t:1527019979412};\\\", \\\"{x:1031,y:716,t:1527019979426};\\\", \\\"{x:1203,y:869,t:1527019979443};\\\", \\\"{x:1265,y:914,t:1527019979460};\\\", \\\"{x:1266,y:915,t:1527019979477};\\\", \\\"{x:1266,y:916,t:1527019979493};\\\", \\\"{x:1266,y:917,t:1527019979509};\\\", \\\"{x:1266,y:918,t:1527019979571};\\\", \\\"{x:1266,y:917,t:1527019979602};\\\", \\\"{x:1267,y:910,t:1527019979611};\\\", \\\"{x:1271,y:902,t:1527019979626};\\\", \\\"{x:1278,y:875,t:1527019979642};\\\", \\\"{x:1285,y:843,t:1527019979660};\\\", \\\"{x:1288,y:818,t:1527019979676};\\\", \\\"{x:1291,y:793,t:1527019979693};\\\", \\\"{x:1296,y:768,t:1527019979710};\\\", \\\"{x:1303,y:743,t:1527019979727};\\\", \\\"{x:1309,y:724,t:1527019979742};\\\", \\\"{x:1316,y:702,t:1527019979759};\\\", \\\"{x:1316,y:683,t:1527019979777};\\\", \\\"{x:1313,y:660,t:1527019979793};\\\", \\\"{x:1312,y:647,t:1527019979810};\\\", \\\"{x:1312,y:639,t:1527019979827};\\\", \\\"{x:1312,y:633,t:1527019979843};\\\", \\\"{x:1312,y:631,t:1527019979860};\\\", \\\"{x:1309,y:632,t:1527019979932};\\\", \\\"{x:1307,y:642,t:1527019979944};\\\", \\\"{x:1306,y:660,t:1527019979961};\\\", \\\"{x:1306,y:678,t:1527019979977};\\\", \\\"{x:1308,y:687,t:1527019979994};\\\", \\\"{x:1311,y:690,t:1527019980010};\\\", \\\"{x:1312,y:692,t:1527019980027};\\\", \\\"{x:1312,y:693,t:1527019980043};\\\", \\\"{x:1314,y:695,t:1527019980060};\\\", \\\"{x:1318,y:702,t:1527019980077};\\\", \\\"{x:1323,y:710,t:1527019980094};\\\", \\\"{x:1325,y:713,t:1527019980110};\\\", \\\"{x:1329,y:717,t:1527019980127};\\\", \\\"{x:1331,y:717,t:1527019980145};\\\", \\\"{x:1332,y:717,t:1527019980187};\\\", \\\"{x:1333,y:717,t:1527019980204};\\\", \\\"{x:1337,y:714,t:1527019980212};\\\", \\\"{x:1341,y:707,t:1527019980228};\\\", \\\"{x:1353,y:693,t:1527019980244};\\\", \\\"{x:1359,y:687,t:1527019980259};\\\", \\\"{x:1362,y:683,t:1527019980276};\\\", \\\"{x:1362,y:684,t:1527019980419};\\\", \\\"{x:1362,y:687,t:1527019980427};\\\", \\\"{x:1359,y:696,t:1527019980443};\\\", \\\"{x:1357,y:700,t:1527019980461};\\\", \\\"{x:1356,y:702,t:1527019980477};\\\", \\\"{x:1355,y:703,t:1527019980494};\\\", \\\"{x:1355,y:701,t:1527019980764};\\\", \\\"{x:1355,y:700,t:1527019980779};\\\", \\\"{x:1355,y:699,t:1527019980812};\\\", \\\"{x:1355,y:698,t:1527019980828};\\\", \\\"{x:1353,y:698,t:1527019980942};\\\", \\\"{x:1348,y:713,t:1527019980961};\\\", \\\"{x:1346,y:729,t:1527019980977};\\\", \\\"{x:1344,y:744,t:1527019980994};\\\", \\\"{x:1344,y:757,t:1527019981010};\\\", \\\"{x:1344,y:758,t:1527019981027};\\\", \\\"{x:1344,y:759,t:1527019981044};\\\", \\\"{x:1344,y:760,t:1527019981106};\\\", \\\"{x:1343,y:761,t:1527019983444};\\\", \\\"{x:1319,y:761,t:1527019983453};\\\", \\\"{x:1255,y:761,t:1527019983463};\\\", \\\"{x:1106,y:742,t:1527019983480};\\\", \\\"{x:967,y:721,t:1527019983496};\\\", \\\"{x:890,y:712,t:1527019983513};\\\", \\\"{x:880,y:710,t:1527019983530};\\\", \\\"{x:879,y:709,t:1527019983596};\\\", \\\"{x:881,y:705,t:1527019983613};\\\", \\\"{x:882,y:696,t:1527019983630};\\\", \\\"{x:882,y:685,t:1527019983647};\\\", \\\"{x:882,y:671,t:1527019983663};\\\", \\\"{x:880,y:656,t:1527019983680};\\\", \\\"{x:875,y:633,t:1527019983696};\\\", \\\"{x:869,y:617,t:1527019983715};\\\", \\\"{x:856,y:593,t:1527019983730};\\\", \\\"{x:837,y:571,t:1527019983746};\\\", \\\"{x:776,y:540,t:1527019983763};\\\", \\\"{x:722,y:520,t:1527019983780};\\\", \\\"{x:691,y:514,t:1527019983797};\\\", \\\"{x:648,y:511,t:1527019983813};\\\", \\\"{x:616,y:511,t:1527019983829};\\\", \\\"{x:597,y:511,t:1527019983847};\\\", \\\"{x:587,y:511,t:1527019983863};\\\", \\\"{x:580,y:513,t:1527019983879};\\\", \\\"{x:571,y:517,t:1527019983896};\\\", \\\"{x:563,y:522,t:1527019983913};\\\", \\\"{x:554,y:528,t:1527019983930};\\\", \\\"{x:539,y:540,t:1527019983946};\\\", \\\"{x:533,y:543,t:1527019983963};\\\", \\\"{x:525,y:547,t:1527019983979};\\\", \\\"{x:512,y:550,t:1527019983996};\\\", \\\"{x:491,y:552,t:1527019984015};\\\", \\\"{x:457,y:555,t:1527019984029};\\\", \\\"{x:406,y:548,t:1527019984047};\\\", \\\"{x:358,y:539,t:1527019984062};\\\", \\\"{x:317,y:531,t:1527019984079};\\\", \\\"{x:285,y:524,t:1527019984097};\\\", \\\"{x:271,y:519,t:1527019984114};\\\", \\\"{x:263,y:517,t:1527019984131};\\\", \\\"{x:241,y:509,t:1527019984146};\\\", \\\"{x:215,y:503,t:1527019984164};\\\", \\\"{x:186,y:498,t:1527019984180};\\\", \\\"{x:167,y:495,t:1527019984196};\\\", \\\"{x:157,y:495,t:1527019984214};\\\", \\\"{x:155,y:495,t:1527019984229};\\\", \\\"{x:152,y:495,t:1527019984247};\\\", \\\"{x:150,y:497,t:1527019984263};\\\", \\\"{x:148,y:499,t:1527019984280};\\\", \\\"{x:147,y:502,t:1527019984297};\\\", \\\"{x:143,y:509,t:1527019984314};\\\", \\\"{x:140,y:517,t:1527019984330};\\\", \\\"{x:138,y:530,t:1527019984349};\\\", \\\"{x:138,y:547,t:1527019984364};\\\", \\\"{x:138,y:555,t:1527019984381};\\\", \\\"{x:138,y:560,t:1527019984396};\\\", \\\"{x:139,y:562,t:1527019984413};\\\", \\\"{x:140,y:562,t:1527019984435};\\\", \\\"{x:141,y:562,t:1527019984450};\\\", \\\"{x:142,y:562,t:1527019984464};\\\", \\\"{x:144,y:562,t:1527019984481};\\\", \\\"{x:149,y:562,t:1527019984496};\\\", \\\"{x:153,y:560,t:1527019984514};\\\", \\\"{x:156,y:557,t:1527019984530};\\\", \\\"{x:157,y:555,t:1527019984547};\\\", \\\"{x:158,y:552,t:1527019984564};\\\", \\\"{x:159,y:551,t:1527019984581};\\\", \\\"{x:159,y:550,t:1527019984597};\\\", \\\"{x:160,y:549,t:1527019984614};\\\", \\\"{x:160,y:548,t:1527019984652};\\\", \\\"{x:160,y:547,t:1527019984676};\\\", \\\"{x:160,y:546,t:1527019984691};\\\", \\\"{x:166,y:546,t:1527019984882};\\\", \\\"{x:187,y:571,t:1527019984898};\\\", \\\"{x:313,y:672,t:1527019984914};\\\", \\\"{x:542,y:860,t:1527019984930};\\\", \\\"{x:648,y:939,t:1527019984947};\\\", \\\"{x:691,y:968,t:1527019984964};\\\", \\\"{x:691,y:967,t:1527019985002};\\\", \\\"{x:685,y:949,t:1527019985013};\\\", \\\"{x:665,y:907,t:1527019985030};\\\", \\\"{x:654,y:884,t:1527019985047};\\\", \\\"{x:643,y:861,t:1527019985064};\\\", \\\"{x:633,y:838,t:1527019985081};\\\", \\\"{x:621,y:821,t:1527019985098};\\\", \\\"{x:612,y:810,t:1527019985114};\\\", \\\"{x:601,y:799,t:1527019985131};\\\", \\\"{x:583,y:791,t:1527019985147};\\\", \\\"{x:558,y:785,t:1527019985164};\\\", \\\"{x:515,y:770,t:1527019985181};\\\", \\\"{x:463,y:759,t:1527019985198};\\\", \\\"{x:435,y:749,t:1527019985214};\\\", \\\"{x:424,y:745,t:1527019985231};\\\", \\\"{x:423,y:745,t:1527019985248};\\\", \\\"{x:421,y:742,t:1527019985264};\\\", \\\"{x:421,y:740,t:1527019985281};\\\", \\\"{x:418,y:735,t:1527019985297};\\\", \\\"{x:417,y:728,t:1527019985315};\\\", \\\"{x:424,y:731,t:1527019985452};\\\", \\\"{x:445,y:739,t:1527019985465};\\\", \\\"{x:465,y:746,t:1527019985467};\\\", \\\"{x:493,y:755,t:1527019985480};\\\", \\\"{x:518,y:757,t:1527019985498};\\\", \\\"{x:520,y:757,t:1527019985514};\\\", \\\"{x:520,y:755,t:1527019985811};\\\", \\\"{x:520,y:752,t:1527019985821};\\\", \\\"{x:520,y:749,t:1527019985832};\\\", \\\"{x:520,y:744,t:1527019985848};\\\", \\\"{x:520,y:742,t:1527019985865};\\\", \\\"{x:520,y:741,t:1527019985882};\\\", \\\"{x:520,y:740,t:1527019985899};\\\", \\\"{x:520,y:744,t:1527019986275};\\\", \\\"{x:524,y:753,t:1527019986283};\\\", \\\"{x:537,y:775,t:1527019986299};\\\", \\\"{x:558,y:813,t:1527019986315};\\\", \\\"{x:579,y:856,t:1527019986331};\\\", \\\"{x:611,y:901,t:1527019986349};\\\", \\\"{x:629,y:923,t:1527019986366};\\\", \\\"{x:648,y:939,t:1527019986382};\\\", \\\"{x:660,y:948,t:1527019986399};\\\", \\\"{x:675,y:954,t:1527019986415};\\\", \\\"{x:688,y:958,t:1527019986432};\\\", \\\"{x:703,y:959,t:1527019986449};\\\", \\\"{x:714,y:959,t:1527019986465};\\\", \\\"{x:731,y:959,t:1527019986481};\\\", \\\"{x:756,y:949,t:1527019986498};\\\", \\\"{x:771,y:938,t:1527019986516};\\\", \\\"{x:787,y:917,t:1527019986532};\\\", \\\"{x:800,y:891,t:1527019986549};\\\", \\\"{x:808,y:865,t:1527019986565};\\\", \\\"{x:809,y:840,t:1527019986582};\\\", \\\"{x:805,y:815,t:1527019986599};\\\", \\\"{x:793,y:788,t:1527019986615};\\\", \\\"{x:775,y:763,t:1527019986632};\\\", \\\"{x:756,y:746,t:1527019986649};\\\", \\\"{x:737,y:729,t:1527019986666};\\\", \\\"{x:685,y:703,t:1527019986682};\\\", \\\"{x:633,y:680,t:1527019986699};\\\", \\\"{x:583,y:666,t:1527019986716};\\\", \\\"{x:536,y:655,t:1527019986732};\\\", \\\"{x:500,y:650,t:1527019986749};\\\", \\\"{x:471,y:645,t:1527019986765};\\\", \\\"{x:458,y:645,t:1527019986783};\\\", \\\"{x:455,y:645,t:1527019986799};\\\" ] }, { \\\"rt\\\": 24820, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 636116, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM-L -B -M -Z -C -Z -04 PM-M -M -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:454,y:645,t:1527019987916};\\\", \\\"{x:454,y:649,t:1527019987923};\\\", \\\"{x:456,y:659,t:1527019987935};\\\", \\\"{x:483,y:698,t:1527019987953};\\\", \\\"{x:528,y:748,t:1527019987968};\\\", \\\"{x:583,y:794,t:1527019987984};\\\", \\\"{x:662,y:855,t:1527019987999};\\\", \\\"{x:777,y:924,t:1527019988024};\\\", \\\"{x:809,y:940,t:1527019988034};\\\", \\\"{x:864,y:963,t:1527019988050};\\\", \\\"{x:923,y:990,t:1527019988066};\\\", \\\"{x:950,y:1000,t:1527019988084};\\\", \\\"{x:966,y:1005,t:1527019988100};\\\", \\\"{x:975,y:1007,t:1527019988117};\\\", \\\"{x:978,y:1007,t:1527019988134};\\\", \\\"{x:979,y:1007,t:1527019988149};\\\", \\\"{x:981,y:1006,t:1527019988187};\\\", \\\"{x:981,y:1005,t:1527019988202};\\\", \\\"{x:981,y:1004,t:1527019988217};\\\", \\\"{x:981,y:1001,t:1527019988234};\\\", \\\"{x:980,y:997,t:1527019988250};\\\", \\\"{x:980,y:995,t:1527019988267};\\\", \\\"{x:978,y:993,t:1527019988284};\\\", \\\"{x:977,y:991,t:1527019988299};\\\", \\\"{x:976,y:989,t:1527019988317};\\\", \\\"{x:974,y:987,t:1527019988334};\\\", \\\"{x:974,y:986,t:1527019988355};\\\", \\\"{x:973,y:984,t:1527019988396};\\\", \\\"{x:975,y:984,t:1527019989035};\\\", \\\"{x:1000,y:984,t:1527019989050};\\\", \\\"{x:1040,y:984,t:1527019989068};\\\", \\\"{x:1082,y:984,t:1527019989084};\\\", \\\"{x:1123,y:980,t:1527019989101};\\\", \\\"{x:1150,y:974,t:1527019989118};\\\", \\\"{x:1179,y:965,t:1527019989135};\\\", \\\"{x:1204,y:958,t:1527019989150};\\\", \\\"{x:1229,y:949,t:1527019989168};\\\", \\\"{x:1254,y:943,t:1527019989185};\\\", \\\"{x:1284,y:934,t:1527019989200};\\\", \\\"{x:1316,y:924,t:1527019989218};\\\", \\\"{x:1374,y:909,t:1527019989235};\\\", \\\"{x:1420,y:900,t:1527019989250};\\\", \\\"{x:1458,y:892,t:1527019989268};\\\", \\\"{x:1497,y:881,t:1527019989285};\\\", \\\"{x:1528,y:872,t:1527019989301};\\\", \\\"{x:1542,y:867,t:1527019989318};\\\", \\\"{x:1554,y:863,t:1527019989335};\\\", \\\"{x:1563,y:862,t:1527019989351};\\\", \\\"{x:1569,y:860,t:1527019989369};\\\", \\\"{x:1573,y:860,t:1527019989385};\\\", \\\"{x:1580,y:860,t:1527019989401};\\\", \\\"{x:1589,y:860,t:1527019989419};\\\", \\\"{x:1614,y:860,t:1527019989435};\\\", \\\"{x:1635,y:860,t:1527019989451};\\\", \\\"{x:1657,y:860,t:1527019989468};\\\", \\\"{x:1683,y:860,t:1527019989485};\\\", \\\"{x:1707,y:860,t:1527019989502};\\\", \\\"{x:1728,y:857,t:1527019989519};\\\", \\\"{x:1746,y:855,t:1527019989536};\\\", \\\"{x:1756,y:853,t:1527019989552};\\\", \\\"{x:1762,y:852,t:1527019989568};\\\", \\\"{x:1763,y:852,t:1527019989586};\\\", \\\"{x:1764,y:852,t:1527019989660};\\\", \\\"{x:1764,y:851,t:1527019989669};\\\", \\\"{x:1759,y:846,t:1527019989686};\\\", \\\"{x:1748,y:836,t:1527019989702};\\\", \\\"{x:1738,y:828,t:1527019989719};\\\", \\\"{x:1731,y:822,t:1527019989735};\\\", \\\"{x:1724,y:815,t:1527019989753};\\\", \\\"{x:1715,y:808,t:1527019989768};\\\", \\\"{x:1711,y:804,t:1527019989785};\\\", \\\"{x:1709,y:801,t:1527019989802};\\\", \\\"{x:1705,y:796,t:1527019989819};\\\", \\\"{x:1699,y:783,t:1527019989836};\\\", \\\"{x:1694,y:766,t:1527019989853};\\\", \\\"{x:1688,y:745,t:1527019989868};\\\", \\\"{x:1688,y:721,t:1527019989885};\\\", \\\"{x:1692,y:694,t:1527019989903};\\\", \\\"{x:1708,y:666,t:1527019989918};\\\", \\\"{x:1727,y:627,t:1527019989935};\\\", \\\"{x:1747,y:585,t:1527019989953};\\\", \\\"{x:1763,y:544,t:1527019989970};\\\", \\\"{x:1769,y:502,t:1527019989986};\\\", \\\"{x:1769,y:463,t:1527019990003};\\\", \\\"{x:1767,y:422,t:1527019990020};\\\", \\\"{x:1762,y:405,t:1527019990035};\\\", \\\"{x:1757,y:394,t:1527019990052};\\\", \\\"{x:1755,y:388,t:1527019990069};\\\", \\\"{x:1752,y:384,t:1527019990085};\\\", \\\"{x:1750,y:382,t:1527019990103};\\\", \\\"{x:1747,y:380,t:1527019990120};\\\", \\\"{x:1744,y:380,t:1527019990135};\\\", \\\"{x:1735,y:380,t:1527019990152};\\\", \\\"{x:1719,y:381,t:1527019990169};\\\", \\\"{x:1695,y:391,t:1527019990186};\\\", \\\"{x:1658,y:415,t:1527019990203};\\\", \\\"{x:1600,y:461,t:1527019990219};\\\", \\\"{x:1576,y:485,t:1527019990236};\\\", \\\"{x:1563,y:504,t:1527019990254};\\\", \\\"{x:1556,y:520,t:1527019990270};\\\", \\\"{x:1555,y:529,t:1527019990286};\\\", \\\"{x:1555,y:536,t:1527019990303};\\\", \\\"{x:1555,y:540,t:1527019990320};\\\", \\\"{x:1555,y:542,t:1527019990337};\\\", \\\"{x:1555,y:543,t:1527019990353};\\\", \\\"{x:1555,y:546,t:1527019990369};\\\", \\\"{x:1555,y:547,t:1527019990387};\\\", \\\"{x:1555,y:549,t:1527019990403};\\\", \\\"{x:1555,y:552,t:1527019990420};\\\", \\\"{x:1555,y:553,t:1527019990436};\\\", \\\"{x:1556,y:553,t:1527019990468};\\\", \\\"{x:1555,y:554,t:1527019991060};\\\", \\\"{x:1549,y:557,t:1527019991069};\\\", \\\"{x:1533,y:564,t:1527019991087};\\\", \\\"{x:1501,y:574,t:1527019991104};\\\", \\\"{x:1468,y:584,t:1527019991120};\\\", \\\"{x:1439,y:594,t:1527019991137};\\\", \\\"{x:1422,y:601,t:1527019991154};\\\", \\\"{x:1404,y:612,t:1527019991171};\\\", \\\"{x:1389,y:623,t:1527019991186};\\\", \\\"{x:1371,y:637,t:1527019991203};\\\", \\\"{x:1364,y:652,t:1527019991221};\\\", \\\"{x:1359,y:670,t:1527019991237};\\\", \\\"{x:1353,y:702,t:1527019991254};\\\", \\\"{x:1347,y:747,t:1527019991271};\\\", \\\"{x:1344,y:798,t:1527019991287};\\\", \\\"{x:1344,y:846,t:1527019991303};\\\", \\\"{x:1346,y:898,t:1527019991320};\\\", \\\"{x:1353,y:928,t:1527019991336};\\\", \\\"{x:1360,y:945,t:1527019991354};\\\", \\\"{x:1366,y:958,t:1527019991371};\\\", \\\"{x:1371,y:969,t:1527019991387};\\\", \\\"{x:1376,y:974,t:1527019991403};\\\", \\\"{x:1378,y:977,t:1527019991421};\\\", \\\"{x:1381,y:979,t:1527019991437};\\\", \\\"{x:1382,y:979,t:1527019991476};\\\", \\\"{x:1383,y:979,t:1527019991508};\\\", \\\"{x:1385,y:978,t:1527019991521};\\\", \\\"{x:1388,y:966,t:1527019991537};\\\", \\\"{x:1389,y:953,t:1527019991554};\\\", \\\"{x:1389,y:938,t:1527019991570};\\\", \\\"{x:1382,y:914,t:1527019991587};\\\", \\\"{x:1376,y:899,t:1527019991605};\\\", \\\"{x:1365,y:881,t:1527019991621};\\\", \\\"{x:1350,y:861,t:1527019991637};\\\", \\\"{x:1332,y:843,t:1527019991653};\\\", \\\"{x:1309,y:827,t:1527019991670};\\\", \\\"{x:1281,y:808,t:1527019991687};\\\", \\\"{x:1246,y:787,t:1527019991703};\\\", \\\"{x:1207,y:764,t:1527019991720};\\\", \\\"{x:1169,y:742,t:1527019991737};\\\", \\\"{x:1134,y:722,t:1527019991754};\\\", \\\"{x:1111,y:708,t:1527019991770};\\\", \\\"{x:1089,y:695,t:1527019991786};\\\", \\\"{x:1087,y:694,t:1527019991803};\\\", \\\"{x:1085,y:693,t:1527019991820};\\\", \\\"{x:1085,y:694,t:1527019991875};\\\", \\\"{x:1090,y:697,t:1527019991888};\\\", \\\"{x:1103,y:706,t:1527019991905};\\\", \\\"{x:1116,y:712,t:1527019991921};\\\", \\\"{x:1139,y:722,t:1527019991938};\\\", \\\"{x:1181,y:730,t:1527019991955};\\\", \\\"{x:1259,y:739,t:1527019991971};\\\", \\\"{x:1357,y:740,t:1527019991988};\\\", \\\"{x:1395,y:740,t:1527019992004};\\\", \\\"{x:1422,y:740,t:1527019992020};\\\", \\\"{x:1448,y:738,t:1527019992037};\\\", \\\"{x:1473,y:734,t:1527019992055};\\\", \\\"{x:1499,y:729,t:1527019992071};\\\", \\\"{x:1527,y:723,t:1527019992088};\\\", \\\"{x:1556,y:716,t:1527019992104};\\\", \\\"{x:1579,y:708,t:1527019992121};\\\", \\\"{x:1597,y:700,t:1527019992138};\\\", \\\"{x:1605,y:696,t:1527019992155};\\\", \\\"{x:1609,y:693,t:1527019992171};\\\", \\\"{x:1611,y:687,t:1527019992187};\\\", \\\"{x:1612,y:680,t:1527019992204};\\\", \\\"{x:1612,y:672,t:1527019992221};\\\", \\\"{x:1609,y:667,t:1527019992237};\\\", \\\"{x:1606,y:660,t:1527019992255};\\\", \\\"{x:1605,y:656,t:1527019992272};\\\", \\\"{x:1601,y:652,t:1527019992288};\\\", \\\"{x:1597,y:650,t:1527019992305};\\\", \\\"{x:1596,y:650,t:1527019992321};\\\", \\\"{x:1591,y:651,t:1527019992338};\\\", \\\"{x:1580,y:657,t:1527019992355};\\\", \\\"{x:1564,y:683,t:1527019992372};\\\", \\\"{x:1558,y:710,t:1527019992387};\\\", \\\"{x:1552,y:741,t:1527019992405};\\\", \\\"{x:1547,y:774,t:1527019992422};\\\", \\\"{x:1547,y:799,t:1527019992438};\\\", \\\"{x:1547,y:818,t:1527019992455};\\\", \\\"{x:1548,y:836,t:1527019992472};\\\", \\\"{x:1552,y:851,t:1527019992487};\\\", \\\"{x:1556,y:862,t:1527019992504};\\\", \\\"{x:1558,y:871,t:1527019992521};\\\", \\\"{x:1561,y:875,t:1527019992538};\\\", \\\"{x:1561,y:876,t:1527019992554};\\\", \\\"{x:1559,y:871,t:1527019992612};\\\", \\\"{x:1548,y:852,t:1527019992622};\\\", \\\"{x:1535,y:823,t:1527019992638};\\\", \\\"{x:1524,y:798,t:1527019992654};\\\", \\\"{x:1518,y:786,t:1527019992671};\\\", \\\"{x:1513,y:777,t:1527019992688};\\\", \\\"{x:1509,y:769,t:1527019992704};\\\", \\\"{x:1504,y:756,t:1527019992722};\\\", \\\"{x:1498,y:737,t:1527019992738};\\\", \\\"{x:1488,y:718,t:1527019992755};\\\", \\\"{x:1478,y:693,t:1527019992771};\\\", \\\"{x:1473,y:683,t:1527019992789};\\\", \\\"{x:1472,y:677,t:1527019992805};\\\", \\\"{x:1470,y:670,t:1527019992821};\\\", \\\"{x:1469,y:663,t:1527019992838};\\\", \\\"{x:1468,y:660,t:1527019992855};\\\", \\\"{x:1467,y:654,t:1527019992871};\\\", \\\"{x:1465,y:652,t:1527019992889};\\\", \\\"{x:1464,y:648,t:1527019992905};\\\", \\\"{x:1462,y:646,t:1527019992923};\\\", \\\"{x:1462,y:644,t:1527019992938};\\\", \\\"{x:1461,y:642,t:1527019992955};\\\", \\\"{x:1457,y:640,t:1527019992972};\\\", \\\"{x:1453,y:637,t:1527019992988};\\\", \\\"{x:1445,y:635,t:1527019993006};\\\", \\\"{x:1437,y:632,t:1527019993023};\\\", \\\"{x:1423,y:629,t:1527019993039};\\\", \\\"{x:1405,y:627,t:1527019993056};\\\", \\\"{x:1391,y:624,t:1527019993072};\\\", \\\"{x:1376,y:623,t:1527019993089};\\\", \\\"{x:1362,y:621,t:1527019993105};\\\", \\\"{x:1349,y:619,t:1527019993122};\\\", \\\"{x:1343,y:618,t:1527019993138};\\\", \\\"{x:1341,y:617,t:1527019993156};\\\", \\\"{x:1338,y:617,t:1527019993195};\\\", \\\"{x:1337,y:617,t:1527019993206};\\\", \\\"{x:1332,y:617,t:1527019993222};\\\", \\\"{x:1345,y:619,t:1527019995124};\\\", \\\"{x:1374,y:621,t:1527019995141};\\\", \\\"{x:1404,y:628,t:1527019995156};\\\", \\\"{x:1435,y:638,t:1527019995174};\\\", \\\"{x:1466,y:651,t:1527019995191};\\\", \\\"{x:1482,y:658,t:1527019995207};\\\", \\\"{x:1494,y:663,t:1527019995224};\\\", \\\"{x:1497,y:666,t:1527019995242};\\\", \\\"{x:1500,y:669,t:1527019995257};\\\", \\\"{x:1503,y:672,t:1527019995274};\\\", \\\"{x:1512,y:676,t:1527019995291};\\\", \\\"{x:1533,y:689,t:1527019995308};\\\", \\\"{x:1540,y:693,t:1527019995324};\\\", \\\"{x:1542,y:694,t:1527019995340};\\\", \\\"{x:1543,y:694,t:1527019995357};\\\", \\\"{x:1547,y:696,t:1527019995374};\\\", \\\"{x:1556,y:700,t:1527019995392};\\\", \\\"{x:1571,y:706,t:1527019995407};\\\", \\\"{x:1583,y:711,t:1527019995424};\\\", \\\"{x:1590,y:714,t:1527019995442};\\\", \\\"{x:1596,y:716,t:1527019995457};\\\", \\\"{x:1601,y:717,t:1527019995474};\\\", \\\"{x:1603,y:717,t:1527019995516};\\\", \\\"{x:1605,y:716,t:1527019995524};\\\", \\\"{x:1613,y:710,t:1527019995541};\\\", \\\"{x:1628,y:701,t:1527019995557};\\\", \\\"{x:1639,y:694,t:1527019995574};\\\", \\\"{x:1645,y:689,t:1527019995591};\\\", \\\"{x:1646,y:689,t:1527019995608};\\\", \\\"{x:1647,y:689,t:1527019995624};\\\", \\\"{x:1646,y:689,t:1527019995747};\\\", \\\"{x:1642,y:689,t:1527019995758};\\\", \\\"{x:1633,y:695,t:1527019995775};\\\", \\\"{x:1631,y:696,t:1527019995791};\\\", \\\"{x:1629,y:698,t:1527019995808};\\\", \\\"{x:1629,y:699,t:1527019995827};\\\", \\\"{x:1627,y:699,t:1527019996020};\\\", \\\"{x:1626,y:699,t:1527019996027};\\\", \\\"{x:1623,y:698,t:1527019996042};\\\", \\\"{x:1621,y:697,t:1527019996059};\\\", \\\"{x:1620,y:697,t:1527019996075};\\\", \\\"{x:1618,y:697,t:1527019996091};\\\", \\\"{x:1617,y:697,t:1527019996427};\\\", \\\"{x:1617,y:698,t:1527019996459};\\\", \\\"{x:1616,y:698,t:1527019996475};\\\", \\\"{x:1616,y:699,t:1527019996716};\\\", \\\"{x:1616,y:701,t:1527019996725};\\\", \\\"{x:1616,y:715,t:1527019996743};\\\", \\\"{x:1616,y:726,t:1527019996759};\\\", \\\"{x:1616,y:741,t:1527019996775};\\\", \\\"{x:1614,y:748,t:1527019996792};\\\", \\\"{x:1613,y:752,t:1527019996809};\\\", \\\"{x:1612,y:757,t:1527019996825};\\\", \\\"{x:1612,y:761,t:1527019996842};\\\", \\\"{x:1612,y:767,t:1527019996859};\\\", \\\"{x:1608,y:777,t:1527019996875};\\\", \\\"{x:1608,y:786,t:1527019996892};\\\", \\\"{x:1608,y:792,t:1527019996909};\\\", \\\"{x:1608,y:800,t:1527019996926};\\\", \\\"{x:1608,y:808,t:1527019996942};\\\", \\\"{x:1608,y:816,t:1527019996959};\\\", \\\"{x:1608,y:825,t:1527019996976};\\\", \\\"{x:1608,y:835,t:1527019996992};\\\", \\\"{x:1608,y:845,t:1527019997009};\\\", \\\"{x:1608,y:856,t:1527019997026};\\\", \\\"{x:1608,y:867,t:1527019997042};\\\", \\\"{x:1608,y:877,t:1527019997058};\\\", \\\"{x:1609,y:893,t:1527019997075};\\\", \\\"{x:1611,y:903,t:1527019997091};\\\", \\\"{x:1614,y:911,t:1527019997108};\\\", \\\"{x:1614,y:916,t:1527019997126};\\\", \\\"{x:1615,y:920,t:1527019997141};\\\", \\\"{x:1615,y:923,t:1527019997158};\\\", \\\"{x:1615,y:926,t:1527019997175};\\\", \\\"{x:1615,y:927,t:1527019997191};\\\", \\\"{x:1615,y:929,t:1527019997208};\\\", \\\"{x:1615,y:931,t:1527019997225};\\\", \\\"{x:1615,y:933,t:1527019997243};\\\", \\\"{x:1614,y:935,t:1527019997259};\\\", \\\"{x:1612,y:943,t:1527019997275};\\\", \\\"{x:1610,y:949,t:1527019997292};\\\", \\\"{x:1608,y:957,t:1527019997309};\\\", \\\"{x:1606,y:965,t:1527019997326};\\\", \\\"{x:1606,y:968,t:1527019997343};\\\", \\\"{x:1606,y:969,t:1527019997358};\\\", \\\"{x:1606,y:970,t:1527019997412};\\\", \\\"{x:1608,y:970,t:1527019997923};\\\", \\\"{x:1609,y:970,t:1527019997931};\\\", \\\"{x:1611,y:970,t:1527019997995};\\\", \\\"{x:1594,y:960,t:1527019999669};\\\", \\\"{x:1520,y:920,t:1527019999678};\\\", \\\"{x:1332,y:820,t:1527019999695};\\\", \\\"{x:1170,y:688,t:1527019999711};\\\", \\\"{x:1096,y:628,t:1527019999728};\\\", \\\"{x:1079,y:615,t:1527019999745};\\\", \\\"{x:1076,y:612,t:1527019999761};\\\", \\\"{x:1076,y:611,t:1527019999778};\\\", \\\"{x:1074,y:607,t:1527019999796};\\\", \\\"{x:1071,y:603,t:1527019999812};\\\", \\\"{x:1067,y:598,t:1527019999828};\\\", \\\"{x:1060,y:593,t:1527019999845};\\\", \\\"{x:1053,y:590,t:1527019999861};\\\", \\\"{x:1039,y:589,t:1527019999878};\\\", \\\"{x:1017,y:589,t:1527019999895};\\\", \\\"{x:998,y:592,t:1527019999911};\\\", \\\"{x:982,y:596,t:1527019999928};\\\", \\\"{x:952,y:598,t:1527019999945};\\\", \\\"{x:913,y:598,t:1527019999962};\\\", \\\"{x:878,y:587,t:1527019999979};\\\", \\\"{x:810,y:555,t:1527019999996};\\\", \\\"{x:773,y:531,t:1527020000021};\\\", \\\"{x:762,y:524,t:1527020000037};\\\", \\\"{x:759,y:521,t:1527020000053};\\\", \\\"{x:758,y:521,t:1527020000070};\\\", \\\"{x:753,y:521,t:1527020000087};\\\", \\\"{x:747,y:521,t:1527020000104};\\\", \\\"{x:740,y:521,t:1527020000119};\\\", \\\"{x:732,y:521,t:1527020000136};\\\", \\\"{x:725,y:524,t:1527020000154};\\\", \\\"{x:720,y:528,t:1527020000170};\\\", \\\"{x:711,y:538,t:1527020000186};\\\", \\\"{x:697,y:551,t:1527020000210};\\\", \\\"{x:687,y:556,t:1527020000227};\\\", \\\"{x:680,y:560,t:1527020000243};\\\", \\\"{x:677,y:561,t:1527020000260};\\\", \\\"{x:671,y:563,t:1527020000280};\\\", \\\"{x:664,y:566,t:1527020000293};\\\", \\\"{x:658,y:567,t:1527020000310};\\\", \\\"{x:650,y:568,t:1527020000327};\\\", \\\"{x:645,y:568,t:1527020000343};\\\", \\\"{x:641,y:568,t:1527020000361};\\\", \\\"{x:638,y:568,t:1527020000377};\\\", \\\"{x:635,y:568,t:1527020000393};\\\", \\\"{x:631,y:568,t:1527020000410};\\\", \\\"{x:629,y:568,t:1527020000443};\\\", \\\"{x:628,y:569,t:1527020000467};\\\", \\\"{x:626,y:569,t:1527020000499};\\\", \\\"{x:625,y:570,t:1527020000611};\\\", \\\"{x:628,y:570,t:1527020001228};\\\", \\\"{x:634,y:570,t:1527020001244};\\\", \\\"{x:651,y:570,t:1527020001262};\\\", \\\"{x:671,y:560,t:1527020001278};\\\", \\\"{x:687,y:553,t:1527020001296};\\\", \\\"{x:692,y:550,t:1527020001312};\\\", \\\"{x:700,y:548,t:1527020001327};\\\", \\\"{x:715,y:542,t:1527020001345};\\\", \\\"{x:730,y:536,t:1527020001363};\\\", \\\"{x:751,y:528,t:1527020001378};\\\", \\\"{x:771,y:522,t:1527020001395};\\\", \\\"{x:786,y:519,t:1527020001412};\\\", \\\"{x:808,y:516,t:1527020001428};\\\", \\\"{x:834,y:516,t:1527020001445};\\\", \\\"{x:866,y:516,t:1527020001461};\\\", \\\"{x:903,y:534,t:1527020001478};\\\", \\\"{x:964,y:562,t:1527020001495};\\\", \\\"{x:1057,y:615,t:1527020001512};\\\", \\\"{x:1148,y:674,t:1527020001528};\\\", \\\"{x:1237,y:736,t:1527020001544};\\\", \\\"{x:1319,y:800,t:1527020001561};\\\", \\\"{x:1412,y:874,t:1527020001579};\\\", \\\"{x:1456,y:909,t:1527020001594};\\\", \\\"{x:1483,y:931,t:1527020001611};\\\", \\\"{x:1493,y:940,t:1527020001629};\\\", \\\"{x:1494,y:942,t:1527020001645};\\\", \\\"{x:1495,y:942,t:1527020001661};\\\", \\\"{x:1495,y:941,t:1527020001860};\\\", \\\"{x:1495,y:933,t:1527020001867};\\\", \\\"{x:1495,y:928,t:1527020001879};\\\", \\\"{x:1495,y:911,t:1527020001896};\\\", \\\"{x:1495,y:896,t:1527020001913};\\\", \\\"{x:1495,y:882,t:1527020001930};\\\", \\\"{x:1495,y:868,t:1527020001946};\\\", \\\"{x:1495,y:858,t:1527020001964};\\\", \\\"{x:1495,y:855,t:1527020001979};\\\", \\\"{x:1495,y:853,t:1527020001997};\\\", \\\"{x:1495,y:852,t:1527020002020};\\\", \\\"{x:1495,y:851,t:1527020002036};\\\", \\\"{x:1495,y:850,t:1527020002046};\\\", \\\"{x:1494,y:848,t:1527020002067};\\\", \\\"{x:1494,y:847,t:1527020002079};\\\", \\\"{x:1493,y:845,t:1527020002096};\\\", \\\"{x:1492,y:840,t:1527020002113};\\\", \\\"{x:1492,y:839,t:1527020002130};\\\", \\\"{x:1489,y:834,t:1527020002146};\\\", \\\"{x:1486,y:826,t:1527020002164};\\\", \\\"{x:1486,y:825,t:1527020002179};\\\", \\\"{x:1485,y:824,t:1527020002197};\\\", \\\"{x:1493,y:823,t:1527020003116};\\\", \\\"{x:1509,y:810,t:1527020003131};\\\", \\\"{x:1526,y:796,t:1527020003148};\\\", \\\"{x:1539,y:782,t:1527020003164};\\\", \\\"{x:1543,y:770,t:1527020003181};\\\", \\\"{x:1544,y:761,t:1527020003199};\\\", \\\"{x:1544,y:757,t:1527020003214};\\\", \\\"{x:1544,y:755,t:1527020003292};\\\", \\\"{x:1544,y:756,t:1527020003380};\\\", \\\"{x:1543,y:759,t:1527020003398};\\\", \\\"{x:1542,y:759,t:1527020003415};\\\", \\\"{x:1541,y:759,t:1527020003431};\\\", \\\"{x:1539,y:760,t:1527020003449};\\\", \\\"{x:1538,y:761,t:1527020003465};\\\", \\\"{x:1537,y:761,t:1527020003499};\\\", \\\"{x:1535,y:761,t:1527020003524};\\\", \\\"{x:1534,y:761,t:1527020003532};\\\", \\\"{x:1531,y:762,t:1527020003548};\\\", \\\"{x:1530,y:763,t:1527020003564};\\\", \\\"{x:1527,y:764,t:1527020003582};\\\", \\\"{x:1525,y:765,t:1527020003598};\\\", \\\"{x:1523,y:767,t:1527020003650};\\\", \\\"{x:1521,y:768,t:1527020003667};\\\", \\\"{x:1518,y:769,t:1527020003682};\\\", \\\"{x:1517,y:770,t:1527020003707};\\\", \\\"{x:1516,y:770,t:1527020003715};\\\", \\\"{x:1515,y:772,t:1527020003732};\\\", \\\"{x:1512,y:776,t:1527020003749};\\\", \\\"{x:1507,y:785,t:1527020003765};\\\", \\\"{x:1504,y:795,t:1527020003782};\\\", \\\"{x:1500,y:810,t:1527020003799};\\\", \\\"{x:1494,y:831,t:1527020003815};\\\", \\\"{x:1486,y:856,t:1527020003832};\\\", \\\"{x:1479,y:878,t:1527020003849};\\\", \\\"{x:1470,y:902,t:1527020003865};\\\", \\\"{x:1462,y:916,t:1527020003882};\\\", \\\"{x:1454,y:927,t:1527020003899};\\\", \\\"{x:1451,y:928,t:1527020003915};\\\", \\\"{x:1447,y:930,t:1527020003932};\\\", \\\"{x:1442,y:930,t:1527020003949};\\\", \\\"{x:1429,y:930,t:1527020003966};\\\", \\\"{x:1411,y:930,t:1527020003982};\\\", \\\"{x:1388,y:922,t:1527020003999};\\\", \\\"{x:1366,y:913,t:1527020004016};\\\", \\\"{x:1351,y:907,t:1527020004033};\\\", \\\"{x:1344,y:902,t:1527020004049};\\\", \\\"{x:1343,y:902,t:1527020004065};\\\", \\\"{x:1342,y:901,t:1527020004082};\\\", \\\"{x:1343,y:898,t:1527020004099};\\\", \\\"{x:1345,y:894,t:1527020004116};\\\", \\\"{x:1347,y:891,t:1527020004132};\\\", \\\"{x:1347,y:888,t:1527020004148};\\\", \\\"{x:1349,y:886,t:1527020004166};\\\", \\\"{x:1351,y:885,t:1527020004183};\\\", \\\"{x:1353,y:884,t:1527020004199};\\\", \\\"{x:1354,y:883,t:1527020004236};\\\", \\\"{x:1356,y:883,t:1527020004267};\\\", \\\"{x:1361,y:884,t:1527020004283};\\\", \\\"{x:1365,y:887,t:1527020004299};\\\", \\\"{x:1368,y:889,t:1527020004316};\\\", \\\"{x:1369,y:890,t:1527020004334};\\\", \\\"{x:1371,y:891,t:1527020004349};\\\", \\\"{x:1372,y:891,t:1527020004366};\\\", \\\"{x:1374,y:891,t:1527020004387};\\\", \\\"{x:1374,y:892,t:1527020004401};\\\", \\\"{x:1376,y:894,t:1527020004417};\\\", \\\"{x:1378,y:895,t:1527020004433};\\\", \\\"{x:1378,y:896,t:1527020004450};\\\", \\\"{x:1379,y:897,t:1527020004466};\\\", \\\"{x:1380,y:898,t:1527020004483};\\\", \\\"{x:1381,y:899,t:1527020004499};\\\", \\\"{x:1382,y:900,t:1527020004532};\\\", \\\"{x:1382,y:899,t:1527020004740};\\\", \\\"{x:1382,y:896,t:1527020004750};\\\", \\\"{x:1385,y:891,t:1527020004768};\\\", \\\"{x:1390,y:883,t:1527020004784};\\\", \\\"{x:1393,y:879,t:1527020004800};\\\", \\\"{x:1395,y:875,t:1527020004817};\\\", \\\"{x:1396,y:875,t:1527020004832};\\\", \\\"{x:1397,y:874,t:1527020004850};\\\", \\\"{x:1397,y:871,t:1527020004867};\\\", \\\"{x:1398,y:864,t:1527020004883};\\\", \\\"{x:1398,y:858,t:1527020004901};\\\", \\\"{x:1400,y:851,t:1527020004917};\\\", \\\"{x:1400,y:848,t:1527020004934};\\\", \\\"{x:1397,y:842,t:1527020004951};\\\", \\\"{x:1395,y:839,t:1527020004967};\\\", \\\"{x:1393,y:837,t:1527020004984};\\\", \\\"{x:1393,y:836,t:1527020005000};\\\", \\\"{x:1391,y:834,t:1527020005017};\\\", \\\"{x:1389,y:833,t:1527020005034};\\\", \\\"{x:1387,y:831,t:1527020005050};\\\", \\\"{x:1386,y:831,t:1527020005067};\\\", \\\"{x:1384,y:831,t:1527020005099};\\\", \\\"{x:1383,y:831,t:1527020005124};\\\", \\\"{x:1381,y:831,t:1527020005134};\\\", \\\"{x:1375,y:833,t:1527020005151};\\\", \\\"{x:1366,y:842,t:1527020005167};\\\", \\\"{x:1358,y:853,t:1527020005184};\\\", \\\"{x:1352,y:862,t:1527020005201};\\\", \\\"{x:1346,y:876,t:1527020005217};\\\", \\\"{x:1343,y:884,t:1527020005235};\\\", \\\"{x:1343,y:892,t:1527020005252};\\\", \\\"{x:1347,y:899,t:1527020005268};\\\", \\\"{x:1357,y:908,t:1527020005284};\\\", \\\"{x:1369,y:916,t:1527020005301};\\\", \\\"{x:1388,y:923,t:1527020005318};\\\", \\\"{x:1411,y:927,t:1527020005334};\\\", \\\"{x:1441,y:930,t:1527020005351};\\\", \\\"{x:1476,y:932,t:1527020005368};\\\", \\\"{x:1506,y:932,t:1527020005385};\\\", \\\"{x:1546,y:932,t:1527020005401};\\\", \\\"{x:1570,y:930,t:1527020005418};\\\", \\\"{x:1597,y:922,t:1527020005434};\\\", \\\"{x:1625,y:913,t:1527020005451};\\\", \\\"{x:1634,y:908,t:1527020005468};\\\", \\\"{x:1640,y:906,t:1527020005484};\\\", \\\"{x:1643,y:904,t:1527020005501};\\\", \\\"{x:1644,y:904,t:1527020005580};\\\", \\\"{x:1647,y:906,t:1527020005587};\\\", \\\"{x:1652,y:918,t:1527020005601};\\\", \\\"{x:1663,y:950,t:1527020005618};\\\", \\\"{x:1673,y:988,t:1527020005636};\\\", \\\"{x:1679,y:1007,t:1527020005651};\\\", \\\"{x:1684,y:1018,t:1527020005668};\\\", \\\"{x:1686,y:1021,t:1527020005686};\\\", \\\"{x:1687,y:1022,t:1527020005702};\\\", \\\"{x:1686,y:1020,t:1527020005995};\\\", \\\"{x:1659,y:1004,t:1527020006003};\\\", \\\"{x:1590,y:974,t:1527020006020};\\\", \\\"{x:1477,y:925,t:1527020006035};\\\", \\\"{x:1376,y:893,t:1527020006052};\\\", \\\"{x:1333,y:879,t:1527020006069};\\\", \\\"{x:1325,y:874,t:1527020006085};\\\", \\\"{x:1323,y:872,t:1527020006102};\\\", \\\"{x:1323,y:870,t:1527020006120};\\\", \\\"{x:1323,y:868,t:1527020006136};\\\", \\\"{x:1323,y:867,t:1527020006153};\\\", \\\"{x:1326,y:865,t:1527020006169};\\\", \\\"{x:1330,y:864,t:1527020006185};\\\", \\\"{x:1332,y:862,t:1527020006202};\\\", \\\"{x:1337,y:856,t:1527020006220};\\\", \\\"{x:1344,y:844,t:1527020006235};\\\", \\\"{x:1351,y:827,t:1527020006253};\\\", \\\"{x:1363,y:806,t:1527020006269};\\\", \\\"{x:1374,y:789,t:1527020006287};\\\", \\\"{x:1387,y:771,t:1527020006302};\\\", \\\"{x:1395,y:759,t:1527020006319};\\\", \\\"{x:1403,y:744,t:1527020006336};\\\", \\\"{x:1411,y:728,t:1527020006352};\\\", \\\"{x:1417,y:710,t:1527020006370};\\\", \\\"{x:1421,y:697,t:1527020006387};\\\", \\\"{x:1424,y:683,t:1527020006402};\\\", \\\"{x:1424,y:660,t:1527020006419};\\\", \\\"{x:1422,y:639,t:1527020006436};\\\", \\\"{x:1413,y:618,t:1527020006454};\\\", \\\"{x:1401,y:597,t:1527020006469};\\\", \\\"{x:1389,y:577,t:1527020006486};\\\", \\\"{x:1380,y:562,t:1527020006504};\\\", \\\"{x:1377,y:559,t:1527020006520};\\\", \\\"{x:1376,y:558,t:1527020006536};\\\", \\\"{x:1380,y:559,t:1527020006731};\\\", \\\"{x:1385,y:570,t:1527020006740};\\\", \\\"{x:1395,y:584,t:1527020006754};\\\", \\\"{x:1423,y:619,t:1527020006770};\\\", \\\"{x:1446,y:638,t:1527020006786};\\\", \\\"{x:1478,y:662,t:1527020006804};\\\", \\\"{x:1490,y:671,t:1527020006820};\\\", \\\"{x:1498,y:676,t:1527020006836};\\\", \\\"{x:1508,y:680,t:1527020006853};\\\", \\\"{x:1512,y:681,t:1527020006870};\\\", \\\"{x:1515,y:682,t:1527020006887};\\\", \\\"{x:1516,y:683,t:1527020006903};\\\", \\\"{x:1519,y:684,t:1527020006920};\\\", \\\"{x:1524,y:685,t:1527020006937};\\\", \\\"{x:1529,y:688,t:1527020006953};\\\", \\\"{x:1536,y:690,t:1527020006971};\\\", \\\"{x:1547,y:691,t:1527020006987};\\\", \\\"{x:1556,y:692,t:1527020007003};\\\", \\\"{x:1559,y:692,t:1527020007021};\\\", \\\"{x:1565,y:692,t:1527020007037};\\\", \\\"{x:1570,y:691,t:1527020007053};\\\", \\\"{x:1574,y:689,t:1527020007070};\\\", \\\"{x:1579,y:688,t:1527020007087};\\\", \\\"{x:1582,y:687,t:1527020007104};\\\", \\\"{x:1584,y:686,t:1527020007119};\\\", \\\"{x:1585,y:686,t:1527020007137};\\\", \\\"{x:1586,y:686,t:1527020007154};\\\", \\\"{x:1587,y:686,t:1527020007195};\\\", \\\"{x:1588,y:686,t:1527020007828};\\\", \\\"{x:1588,y:687,t:1527020007859};\\\", \\\"{x:1588,y:689,t:1527020007875};\\\", \\\"{x:1587,y:690,t:1527020007888};\\\", \\\"{x:1586,y:691,t:1527020007904};\\\", \\\"{x:1585,y:692,t:1527020007921};\\\", \\\"{x:1584,y:693,t:1527020007938};\\\", \\\"{x:1584,y:694,t:1527020007955};\\\", \\\"{x:1584,y:695,t:1527020008083};\\\", \\\"{x:1583,y:696,t:1527020008620};\\\", \\\"{x:1576,y:696,t:1527020008628};\\\", \\\"{x:1562,y:694,t:1527020008639};\\\", \\\"{x:1529,y:688,t:1527020008656};\\\", \\\"{x:1468,y:675,t:1527020008672};\\\", \\\"{x:1373,y:661,t:1527020008689};\\\", \\\"{x:1254,y:645,t:1527020008706};\\\", \\\"{x:1141,y:640,t:1527020008723};\\\", \\\"{x:1124,y:640,t:1527020008739};\\\", \\\"{x:1120,y:640,t:1527020008756};\\\", \\\"{x:1122,y:640,t:1527020008827};\\\", \\\"{x:1126,y:640,t:1527020008839};\\\", \\\"{x:1145,y:642,t:1527020008856};\\\", \\\"{x:1169,y:644,t:1527020008874};\\\", \\\"{x:1202,y:644,t:1527020008889};\\\", \\\"{x:1229,y:644,t:1527020008906};\\\", \\\"{x:1275,y:635,t:1527020008923};\\\", \\\"{x:1293,y:628,t:1527020008940};\\\", \\\"{x:1304,y:623,t:1527020008956};\\\", \\\"{x:1310,y:614,t:1527020008973};\\\", \\\"{x:1315,y:607,t:1527020008991};\\\", \\\"{x:1316,y:604,t:1527020009007};\\\", \\\"{x:1316,y:601,t:1527020009024};\\\", \\\"{x:1316,y:594,t:1527020009042};\\\", \\\"{x:1316,y:588,t:1527020009056};\\\", \\\"{x:1315,y:581,t:1527020009073};\\\", \\\"{x:1313,y:576,t:1527020009090};\\\", \\\"{x:1313,y:572,t:1527020009107};\\\", \\\"{x:1309,y:566,t:1527020009123};\\\", \\\"{x:1305,y:561,t:1527020009140};\\\", \\\"{x:1300,y:558,t:1527020009158};\\\", \\\"{x:1298,y:556,t:1527020009174};\\\", \\\"{x:1297,y:556,t:1527020009191};\\\", \\\"{x:1296,y:556,t:1527020009207};\\\", \\\"{x:1295,y:556,t:1527020009260};\\\", \\\"{x:1293,y:556,t:1527020009275};\\\", \\\"{x:1291,y:556,t:1527020009290};\\\", \\\"{x:1288,y:558,t:1527020009308};\\\", \\\"{x:1283,y:560,t:1527020009324};\\\", \\\"{x:1277,y:564,t:1527020009341};\\\", \\\"{x:1276,y:567,t:1527020009358};\\\", \\\"{x:1275,y:569,t:1527020009373};\\\", \\\"{x:1274,y:569,t:1527020009390};\\\", \\\"{x:1272,y:571,t:1527020010499};\\\", \\\"{x:1251,y:581,t:1527020010510};\\\", \\\"{x:1157,y:621,t:1527020010526};\\\", \\\"{x:1042,y:648,t:1527020010543};\\\", \\\"{x:916,y:660,t:1527020010559};\\\", \\\"{x:794,y:660,t:1527020010576};\\\", \\\"{x:686,y:660,t:1527020010592};\\\", \\\"{x:635,y:660,t:1527020010609};\\\", \\\"{x:611,y:659,t:1527020010625};\\\", \\\"{x:601,y:658,t:1527020010642};\\\", \\\"{x:596,y:657,t:1527020010659};\\\", \\\"{x:594,y:655,t:1527020010676};\\\", \\\"{x:593,y:654,t:1527020010692};\\\", \\\"{x:584,y:649,t:1527020010709};\\\", \\\"{x:566,y:636,t:1527020010726};\\\", \\\"{x:533,y:620,t:1527020010744};\\\", \\\"{x:501,y:606,t:1527020010759};\\\", \\\"{x:476,y:595,t:1527020010776};\\\", \\\"{x:467,y:592,t:1527020010787};\\\", \\\"{x:444,y:584,t:1527020010802};\\\", \\\"{x:430,y:580,t:1527020010819};\\\", \\\"{x:422,y:579,t:1527020010835};\\\", \\\"{x:421,y:579,t:1527020010852};\\\", \\\"{x:420,y:579,t:1527020010882};\\\", \\\"{x:420,y:578,t:1527020010890};\\\", \\\"{x:419,y:577,t:1527020010907};\\\", \\\"{x:419,y:575,t:1527020010947};\\\", \\\"{x:423,y:571,t:1527020010955};\\\", \\\"{x:431,y:566,t:1527020010969};\\\", \\\"{x:457,y:554,t:1527020010987};\\\", \\\"{x:486,y:543,t:1527020011003};\\\", \\\"{x:497,y:538,t:1527020011019};\\\", \\\"{x:506,y:534,t:1527020011036};\\\", \\\"{x:514,y:530,t:1527020011053};\\\", \\\"{x:523,y:526,t:1527020011069};\\\", \\\"{x:537,y:520,t:1527020011087};\\\", \\\"{x:549,y:517,t:1527020011104};\\\", \\\"{x:558,y:513,t:1527020011120};\\\", \\\"{x:561,y:513,t:1527020011135};\\\", \\\"{x:562,y:512,t:1527020011153};\\\", \\\"{x:564,y:512,t:1527020011195};\\\", \\\"{x:567,y:512,t:1527020011203};\\\", \\\"{x:573,y:511,t:1527020011220};\\\", \\\"{x:579,y:510,t:1527020011237};\\\", \\\"{x:582,y:509,t:1527020011253};\\\", \\\"{x:585,y:508,t:1527020011270};\\\", \\\"{x:587,y:508,t:1527020011286};\\\", \\\"{x:591,y:507,t:1527020011303};\\\", \\\"{x:597,y:507,t:1527020011320};\\\", \\\"{x:606,y:505,t:1527020011337};\\\", \\\"{x:610,y:505,t:1527020011353};\\\", \\\"{x:613,y:504,t:1527020011370};\\\", \\\"{x:614,y:504,t:1527020011402};\\\", \\\"{x:611,y:511,t:1527020011618};\\\", \\\"{x:597,y:538,t:1527020011626};\\\", \\\"{x:581,y:570,t:1527020011638};\\\", \\\"{x:554,y:633,t:1527020011653};\\\", \\\"{x:550,y:666,t:1527020011670};\\\", \\\"{x:547,y:672,t:1527020011687};\\\", \\\"{x:547,y:673,t:1527020011702};\\\", \\\"{x:547,y:678,t:1527020011867};\\\", \\\"{x:545,y:684,t:1527020011874};\\\", \\\"{x:544,y:690,t:1527020011887};\\\", \\\"{x:541,y:699,t:1527020011904};\\\", \\\"{x:540,y:705,t:1527020011920};\\\", \\\"{x:538,y:713,t:1527020011937};\\\", \\\"{x:535,y:722,t:1527020011954};\\\", \\\"{x:535,y:725,t:1527020011970};\\\", \\\"{x:535,y:728,t:1527020011987};\\\", \\\"{x:535,y:730,t:1527020012010};\\\", \\\"{x:534,y:732,t:1527020012026};\\\", \\\"{x:535,y:731,t:1527020012524};\\\", \\\"{x:536,y:730,t:1527020012538};\\\", \\\"{x:537,y:729,t:1527020012554};\\\", \\\"{x:539,y:721,t:1527020012571};\\\", \\\"{x:540,y:714,t:1527020012587};\\\", \\\"{x:540,y:710,t:1527020012604};\\\", \\\"{x:540,y:706,t:1527020012622};\\\", \\\"{x:541,y:704,t:1527020012638};\\\", \\\"{x:541,y:703,t:1527020012654};\\\", \\\"{x:541,y:702,t:1527020012671};\\\", \\\"{x:541,y:701,t:1527020012691};\\\" ] }, { \\\"rt\\\": 16554, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 653894, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-B -12 PM-12 PM-01 PM-01 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:673,t:1527020013827};\\\", \\\"{x:548,y:660,t:1527020013840};\\\", \\\"{x:555,y:642,t:1527020013855};\\\", \\\"{x:564,y:630,t:1527020013872};\\\", \\\"{x:585,y:620,t:1527020013888};\\\", \\\"{x:620,y:600,t:1527020013905};\\\", \\\"{x:646,y:587,t:1527020013923};\\\", \\\"{x:673,y:574,t:1527020013938};\\\", \\\"{x:680,y:570,t:1527020013955};\\\", \\\"{x:685,y:567,t:1527020013972};\\\", \\\"{x:688,y:563,t:1527020013989};\\\", \\\"{x:689,y:562,t:1527020014005};\\\", \\\"{x:691,y:561,t:1527020014067};\\\", \\\"{x:697,y:559,t:1527020014428};\\\", \\\"{x:724,y:559,t:1527020014439};\\\", \\\"{x:922,y:583,t:1527020014458};\\\", \\\"{x:1245,y:624,t:1527020014473};\\\", \\\"{x:1576,y:678,t:1527020014489};\\\", \\\"{x:1806,y:749,t:1527020014506};\\\", \\\"{x:1919,y:801,t:1527020014522};\\\", \\\"{x:1919,y:819,t:1527020014539};\\\", \\\"{x:1919,y:820,t:1527020014556};\\\", \\\"{x:1919,y:819,t:1527020014572};\\\", \\\"{x:1919,y:818,t:1527020014610};\\\", \\\"{x:1919,y:817,t:1527020014731};\\\", \\\"{x:1919,y:816,t:1527020014770};\\\", \\\"{x:1916,y:815,t:1527020014779};\\\", \\\"{x:1912,y:812,t:1527020014790};\\\", \\\"{x:1908,y:811,t:1527020014805};\\\", \\\"{x:1907,y:811,t:1527020016379};\\\", \\\"{x:1901,y:814,t:1527020016389};\\\", \\\"{x:1880,y:837,t:1527020016405};\\\", \\\"{x:1851,y:877,t:1527020016425};\\\", \\\"{x:1819,y:922,t:1527020016442};\\\", \\\"{x:1785,y:968,t:1527020016457};\\\", \\\"{x:1742,y:1016,t:1527020016475};\\\", \\\"{x:1726,y:1027,t:1527020016491};\\\", \\\"{x:1718,y:1031,t:1527020016508};\\\", \\\"{x:1717,y:1031,t:1527020016525};\\\", \\\"{x:1716,y:1031,t:1527020016542};\\\", \\\"{x:1714,y:1031,t:1527020016563};\\\", \\\"{x:1708,y:1031,t:1527020016579};\\\", \\\"{x:1706,y:1031,t:1527020016591};\\\", \\\"{x:1685,y:1026,t:1527020016609};\\\", \\\"{x:1647,y:1018,t:1527020016625};\\\", \\\"{x:1605,y:1008,t:1527020016642};\\\", \\\"{x:1587,y:1004,t:1527020016658};\\\", \\\"{x:1575,y:1003,t:1527020016675};\\\", \\\"{x:1571,y:1001,t:1527020016692};\\\", \\\"{x:1568,y:1000,t:1527020016709};\\\", \\\"{x:1567,y:1000,t:1527020016725};\\\", \\\"{x:1567,y:999,t:1527020016836};\\\", \\\"{x:1568,y:998,t:1527020016843};\\\", \\\"{x:1569,y:997,t:1527020016858};\\\", \\\"{x:1578,y:992,t:1527020016875};\\\", \\\"{x:1580,y:989,t:1527020016891};\\\", \\\"{x:1581,y:988,t:1527020016909};\\\", \\\"{x:1582,y:987,t:1527020016931};\\\", \\\"{x:1582,y:985,t:1527020016971};\\\", \\\"{x:1576,y:983,t:1527020016979};\\\", \\\"{x:1564,y:979,t:1527020016992};\\\", \\\"{x:1543,y:976,t:1527020017009};\\\", \\\"{x:1533,y:975,t:1527020017026};\\\", \\\"{x:1532,y:972,t:1527020017123};\\\", \\\"{x:1533,y:968,t:1527020017132};\\\", \\\"{x:1536,y:966,t:1527020017143};\\\", \\\"{x:1540,y:963,t:1527020017159};\\\", \\\"{x:1544,y:959,t:1527020017176};\\\", \\\"{x:1546,y:956,t:1527020017193};\\\", \\\"{x:1547,y:954,t:1527020017209};\\\", \\\"{x:1549,y:954,t:1527020017226};\\\", \\\"{x:1550,y:953,t:1527020017243};\\\", \\\"{x:1551,y:952,t:1527020017388};\\\", \\\"{x:1551,y:951,t:1527020017396};\\\", \\\"{x:1551,y:949,t:1527020017410};\\\", \\\"{x:1551,y:946,t:1527020017426};\\\", \\\"{x:1551,y:943,t:1527020017443};\\\", \\\"{x:1551,y:939,t:1527020017459};\\\", \\\"{x:1550,y:932,t:1527020017476};\\\", \\\"{x:1550,y:928,t:1527020017493};\\\", \\\"{x:1549,y:922,t:1527020017510};\\\", \\\"{x:1549,y:918,t:1527020017526};\\\", \\\"{x:1548,y:914,t:1527020017543};\\\", \\\"{x:1547,y:912,t:1527020017560};\\\", \\\"{x:1547,y:910,t:1527020017579};\\\", \\\"{x:1547,y:909,t:1527020017595};\\\", \\\"{x:1547,y:908,t:1527020017610};\\\", \\\"{x:1547,y:906,t:1527020017626};\\\", \\\"{x:1547,y:901,t:1527020017644};\\\", \\\"{x:1547,y:897,t:1527020017659};\\\", \\\"{x:1547,y:894,t:1527020017677};\\\", \\\"{x:1547,y:890,t:1527020017693};\\\", \\\"{x:1547,y:888,t:1527020017710};\\\", \\\"{x:1547,y:884,t:1527020017727};\\\", \\\"{x:1547,y:881,t:1527020017743};\\\", \\\"{x:1547,y:879,t:1527020017759};\\\", \\\"{x:1547,y:876,t:1527020017777};\\\", \\\"{x:1547,y:874,t:1527020017793};\\\", \\\"{x:1547,y:873,t:1527020017810};\\\", \\\"{x:1547,y:869,t:1527020017827};\\\", \\\"{x:1547,y:868,t:1527020017843};\\\", \\\"{x:1547,y:866,t:1527020017859};\\\", \\\"{x:1547,y:864,t:1527020017877};\\\", \\\"{x:1547,y:860,t:1527020017893};\\\", \\\"{x:1547,y:857,t:1527020017910};\\\", \\\"{x:1547,y:852,t:1527020017927};\\\", \\\"{x:1547,y:850,t:1527020017943};\\\", \\\"{x:1547,y:846,t:1527020017960};\\\", \\\"{x:1547,y:843,t:1527020017976};\\\", \\\"{x:1547,y:840,t:1527020017994};\\\", \\\"{x:1547,y:839,t:1527020018010};\\\", \\\"{x:1547,y:838,t:1527020018076};\\\", \\\"{x:1547,y:837,t:1527020018123};\\\", \\\"{x:1547,y:836,t:1527020018147};\\\", \\\"{x:1547,y:834,t:1527020018171};\\\", \\\"{x:1547,y:833,t:1527020018187};\\\", \\\"{x:1547,y:831,t:1527020018204};\\\", \\\"{x:1547,y:830,t:1527020018259};\\\", \\\"{x:1546,y:830,t:1527020018563};\\\", \\\"{x:1545,y:832,t:1527020018578};\\\", \\\"{x:1545,y:852,t:1527020018594};\\\", \\\"{x:1543,y:864,t:1527020018611};\\\", \\\"{x:1542,y:868,t:1527020018627};\\\", \\\"{x:1542,y:872,t:1527020018644};\\\", \\\"{x:1542,y:873,t:1527020018667};\\\", \\\"{x:1542,y:874,t:1527020018683};\\\", \\\"{x:1542,y:875,t:1527020018699};\\\", \\\"{x:1542,y:877,t:1527020018711};\\\", \\\"{x:1542,y:881,t:1527020018727};\\\", \\\"{x:1541,y:884,t:1527020018745};\\\", \\\"{x:1541,y:887,t:1527020018761};\\\", \\\"{x:1541,y:889,t:1527020018778};\\\", \\\"{x:1539,y:893,t:1527020018795};\\\", \\\"{x:1539,y:898,t:1527020018811};\\\", \\\"{x:1539,y:908,t:1527020018827};\\\", \\\"{x:1539,y:915,t:1527020018845};\\\", \\\"{x:1539,y:919,t:1527020018861};\\\", \\\"{x:1539,y:922,t:1527020018878};\\\", \\\"{x:1540,y:927,t:1527020018895};\\\", \\\"{x:1542,y:933,t:1527020018911};\\\", \\\"{x:1543,y:942,t:1527020018928};\\\", \\\"{x:1544,y:952,t:1527020018945};\\\", \\\"{x:1545,y:959,t:1527020018961};\\\", \\\"{x:1545,y:964,t:1527020018979};\\\", \\\"{x:1545,y:956,t:1527020022084};\\\", \\\"{x:1545,y:941,t:1527020022099};\\\", \\\"{x:1545,y:930,t:1527020022116};\\\", \\\"{x:1545,y:922,t:1527020022132};\\\", \\\"{x:1544,y:914,t:1527020022149};\\\", \\\"{x:1544,y:910,t:1527020022165};\\\", \\\"{x:1543,y:899,t:1527020022182};\\\", \\\"{x:1541,y:886,t:1527020022200};\\\", \\\"{x:1539,y:872,t:1527020022215};\\\", \\\"{x:1537,y:862,t:1527020022233};\\\", \\\"{x:1533,y:852,t:1527020022249};\\\", \\\"{x:1531,y:846,t:1527020022266};\\\", \\\"{x:1531,y:842,t:1527020022282};\\\", \\\"{x:1528,y:839,t:1527020022299};\\\", \\\"{x:1525,y:838,t:1527020022315};\\\", \\\"{x:1518,y:837,t:1527020022332};\\\", \\\"{x:1515,y:837,t:1527020022349};\\\", \\\"{x:1511,y:835,t:1527020022366};\\\", \\\"{x:1509,y:835,t:1527020022382};\\\", \\\"{x:1508,y:834,t:1527020022399};\\\", \\\"{x:1506,y:834,t:1527020022416};\\\", \\\"{x:1504,y:834,t:1527020022433};\\\", \\\"{x:1502,y:834,t:1527020022449};\\\", \\\"{x:1501,y:834,t:1527020022466};\\\", \\\"{x:1499,y:833,t:1527020022483};\\\", \\\"{x:1498,y:832,t:1527020022514};\\\", \\\"{x:1497,y:832,t:1527020022530};\\\", \\\"{x:1496,y:831,t:1527020022546};\\\", \\\"{x:1495,y:831,t:1527020022570};\\\", \\\"{x:1494,y:831,t:1527020022582};\\\", \\\"{x:1493,y:830,t:1527020022598};\\\", \\\"{x:1492,y:830,t:1527020022615};\\\", \\\"{x:1491,y:829,t:1527020022632};\\\", \\\"{x:1490,y:825,t:1527020023194};\\\", \\\"{x:1495,y:816,t:1527020023202};\\\", \\\"{x:1498,y:810,t:1527020023217};\\\", \\\"{x:1505,y:798,t:1527020023232};\\\", \\\"{x:1511,y:789,t:1527020023249};\\\", \\\"{x:1515,y:782,t:1527020023266};\\\", \\\"{x:1516,y:779,t:1527020023282};\\\", \\\"{x:1516,y:778,t:1527020023306};\\\", \\\"{x:1517,y:777,t:1527020023531};\\\", \\\"{x:1518,y:776,t:1527020023555};\\\", \\\"{x:1519,y:776,t:1527020023567};\\\", \\\"{x:1519,y:775,t:1527020023584};\\\", \\\"{x:1519,y:774,t:1527020023603};\\\", \\\"{x:1519,y:773,t:1527020023660};\\\", \\\"{x:1519,y:772,t:1527020024427};\\\", \\\"{x:1515,y:772,t:1527020024434};\\\", \\\"{x:1494,y:782,t:1527020024451};\\\", \\\"{x:1471,y:790,t:1527020024468};\\\", \\\"{x:1451,y:797,t:1527020024484};\\\", \\\"{x:1442,y:799,t:1527020024501};\\\", \\\"{x:1439,y:799,t:1527020024518};\\\", \\\"{x:1437,y:798,t:1527020024587};\\\", \\\"{x:1435,y:797,t:1527020024602};\\\", \\\"{x:1433,y:795,t:1527020024618};\\\", \\\"{x:1428,y:788,t:1527020024635};\\\", \\\"{x:1425,y:784,t:1527020024652};\\\", \\\"{x:1420,y:780,t:1527020024669};\\\", \\\"{x:1415,y:777,t:1527020024685};\\\", \\\"{x:1409,y:776,t:1527020024702};\\\", \\\"{x:1402,y:774,t:1527020024719};\\\", \\\"{x:1396,y:772,t:1527020024736};\\\", \\\"{x:1386,y:771,t:1527020024752};\\\", \\\"{x:1374,y:768,t:1527020024769};\\\", \\\"{x:1371,y:768,t:1527020024786};\\\", \\\"{x:1369,y:768,t:1527020024802};\\\", \\\"{x:1367,y:767,t:1527020024819};\\\", \\\"{x:1365,y:765,t:1527020024835};\\\", \\\"{x:1364,y:764,t:1527020024852};\\\", \\\"{x:1361,y:763,t:1527020024869};\\\", \\\"{x:1359,y:761,t:1527020024885};\\\", \\\"{x:1358,y:760,t:1527020024902};\\\", \\\"{x:1358,y:759,t:1527020024923};\\\", \\\"{x:1358,y:758,t:1527020024939};\\\", \\\"{x:1356,y:757,t:1527020024952};\\\", \\\"{x:1356,y:756,t:1527020024969};\\\", \\\"{x:1355,y:754,t:1527020024987};\\\", \\\"{x:1354,y:754,t:1527020025002};\\\", \\\"{x:1353,y:754,t:1527020025227};\\\", \\\"{x:1352,y:754,t:1527020025243};\\\", \\\"{x:1351,y:756,t:1527020025259};\\\", \\\"{x:1351,y:758,t:1527020025269};\\\", \\\"{x:1350,y:761,t:1527020025288};\\\", \\\"{x:1348,y:765,t:1527020025302};\\\", \\\"{x:1347,y:772,t:1527020025319};\\\", \\\"{x:1346,y:777,t:1527020025336};\\\", \\\"{x:1345,y:782,t:1527020025353};\\\", \\\"{x:1343,y:791,t:1527020025369};\\\", \\\"{x:1341,y:802,t:1527020025385};\\\", \\\"{x:1337,y:819,t:1527020025402};\\\", \\\"{x:1335,y:833,t:1527020025419};\\\", \\\"{x:1334,y:846,t:1527020025436};\\\", \\\"{x:1332,y:859,t:1527020025453};\\\", \\\"{x:1332,y:871,t:1527020025469};\\\", \\\"{x:1332,y:882,t:1527020025486};\\\", \\\"{x:1332,y:900,t:1527020025503};\\\", \\\"{x:1332,y:915,t:1527020025520};\\\", \\\"{x:1332,y:928,t:1527020025536};\\\", \\\"{x:1332,y:945,t:1527020025553};\\\", \\\"{x:1332,y:958,t:1527020025569};\\\", \\\"{x:1331,y:972,t:1527020025586};\\\", \\\"{x:1331,y:984,t:1527020025603};\\\", \\\"{x:1331,y:991,t:1527020025621};\\\", \\\"{x:1331,y:995,t:1527020025636};\\\", \\\"{x:1332,y:997,t:1527020025653};\\\", \\\"{x:1332,y:1000,t:1527020025670};\\\", \\\"{x:1333,y:1001,t:1527020025691};\\\", \\\"{x:1334,y:1000,t:1527020025892};\\\", \\\"{x:1335,y:998,t:1527020025904};\\\", \\\"{x:1341,y:990,t:1527020025920};\\\", \\\"{x:1344,y:986,t:1527020025938};\\\", \\\"{x:1346,y:984,t:1527020025954};\\\", \\\"{x:1350,y:979,t:1527020025970};\\\", \\\"{x:1351,y:978,t:1527020025987};\\\", \\\"{x:1351,y:977,t:1527020026075};\\\", \\\"{x:1352,y:977,t:1527020026227};\\\", \\\"{x:1354,y:977,t:1527020026237};\\\", \\\"{x:1360,y:976,t:1527020026254};\\\", \\\"{x:1368,y:972,t:1527020026270};\\\", \\\"{x:1374,y:970,t:1527020026288};\\\", \\\"{x:1382,y:966,t:1527020026304};\\\", \\\"{x:1387,y:965,t:1527020026321};\\\", \\\"{x:1391,y:965,t:1527020026337};\\\", \\\"{x:1395,y:964,t:1527020026354};\\\", \\\"{x:1398,y:964,t:1527020026371};\\\", \\\"{x:1400,y:964,t:1527020026387};\\\", \\\"{x:1402,y:965,t:1527020026411};\\\", \\\"{x:1403,y:965,t:1527020026421};\\\", \\\"{x:1404,y:967,t:1527020026437};\\\", \\\"{x:1406,y:967,t:1527020026454};\\\", \\\"{x:1408,y:969,t:1527020026472};\\\", \\\"{x:1409,y:973,t:1527020026487};\\\", \\\"{x:1412,y:976,t:1527020026505};\\\", \\\"{x:1415,y:980,t:1527020026521};\\\", \\\"{x:1415,y:983,t:1527020026537};\\\", \\\"{x:1418,y:985,t:1527020026554};\\\", \\\"{x:1418,y:988,t:1527020026571};\\\", \\\"{x:1419,y:990,t:1527020026589};\\\", \\\"{x:1420,y:992,t:1527020026604};\\\", \\\"{x:1420,y:994,t:1527020026621};\\\", \\\"{x:1421,y:994,t:1527020026639};\\\", \\\"{x:1421,y:997,t:1527020026654};\\\", \\\"{x:1421,y:998,t:1527020026671};\\\", \\\"{x:1421,y:999,t:1527020026688};\\\", \\\"{x:1421,y:1001,t:1527020026739};\\\", \\\"{x:1421,y:1000,t:1527020026891};\\\", \\\"{x:1421,y:995,t:1527020026904};\\\", \\\"{x:1421,y:986,t:1527020026921};\\\", \\\"{x:1426,y:976,t:1527020026938};\\\", \\\"{x:1432,y:964,t:1527020026954};\\\", \\\"{x:1436,y:960,t:1527020026971};\\\", \\\"{x:1443,y:954,t:1527020026988};\\\", \\\"{x:1449,y:951,t:1527020027004};\\\", \\\"{x:1453,y:950,t:1527020027021};\\\", \\\"{x:1456,y:948,t:1527020027037};\\\", \\\"{x:1458,y:947,t:1527020027054};\\\", \\\"{x:1459,y:947,t:1527020027071};\\\", \\\"{x:1460,y:947,t:1527020027088};\\\", \\\"{x:1461,y:947,t:1527020027114};\\\", \\\"{x:1462,y:947,t:1527020027211};\\\", \\\"{x:1465,y:947,t:1527020027223};\\\", \\\"{x:1469,y:949,t:1527020027238};\\\", \\\"{x:1473,y:952,t:1527020027255};\\\", \\\"{x:1478,y:954,t:1527020027272};\\\", \\\"{x:1480,y:956,t:1527020027288};\\\", \\\"{x:1481,y:957,t:1527020027307};\\\", \\\"{x:1482,y:957,t:1527020027322};\\\", \\\"{x:1483,y:957,t:1527020027339};\\\", \\\"{x:1484,y:958,t:1527020027356};\\\", \\\"{x:1485,y:958,t:1527020027372};\\\", \\\"{x:1486,y:959,t:1527020027390};\\\", \\\"{x:1486,y:960,t:1527020027406};\\\", \\\"{x:1488,y:961,t:1527020027422};\\\", \\\"{x:1489,y:961,t:1527020027440};\\\", \\\"{x:1489,y:962,t:1527020027456};\\\", \\\"{x:1490,y:963,t:1527020027472};\\\", \\\"{x:1491,y:963,t:1527020027499};\\\", \\\"{x:1491,y:964,t:1527020027523};\\\", \\\"{x:1491,y:965,t:1527020027539};\\\", \\\"{x:1491,y:967,t:1527020027555};\\\", \\\"{x:1491,y:968,t:1527020027579};\\\", \\\"{x:1491,y:969,t:1527020027590};\\\", \\\"{x:1491,y:971,t:1527020027605};\\\", \\\"{x:1491,y:972,t:1527020027622};\\\", \\\"{x:1491,y:973,t:1527020027651};\\\", \\\"{x:1492,y:973,t:1527020027836};\\\", \\\"{x:1498,y:970,t:1527020027843};\\\", \\\"{x:1504,y:967,t:1527020027857};\\\", \\\"{x:1511,y:961,t:1527020027873};\\\", \\\"{x:1514,y:959,t:1527020027889};\\\", \\\"{x:1516,y:959,t:1527020027906};\\\", \\\"{x:1517,y:961,t:1527020027980};\\\", \\\"{x:1510,y:969,t:1527020027989};\\\", \\\"{x:1498,y:976,t:1527020028007};\\\", \\\"{x:1478,y:977,t:1527020028023};\\\", \\\"{x:1457,y:977,t:1527020028040};\\\", \\\"{x:1405,y:957,t:1527020028056};\\\", \\\"{x:1331,y:927,t:1527020028074};\\\", \\\"{x:1253,y:892,t:1527020028089};\\\", \\\"{x:1187,y:853,t:1527020028107};\\\", \\\"{x:1098,y:795,t:1527020028123};\\\", \\\"{x:1045,y:755,t:1527020028139};\\\", \\\"{x:1000,y:723,t:1527020028156};\\\", \\\"{x:960,y:696,t:1527020028173};\\\", \\\"{x:932,y:676,t:1527020028189};\\\", \\\"{x:900,y:655,t:1527020028206};\\\", \\\"{x:884,y:644,t:1527020028223};\\\", \\\"{x:867,y:635,t:1527020028240};\\\", \\\"{x:854,y:630,t:1527020028257};\\\", \\\"{x:847,y:627,t:1527020028272};\\\", \\\"{x:845,y:627,t:1527020028289};\\\", \\\"{x:844,y:626,t:1527020028300};\\\", \\\"{x:843,y:626,t:1527020028317};\\\", \\\"{x:841,y:625,t:1527020028334};\\\", \\\"{x:835,y:623,t:1527020028350};\\\", \\\"{x:821,y:617,t:1527020028368};\\\", \\\"{x:802,y:615,t:1527020028383};\\\", \\\"{x:775,y:611,t:1527020028400};\\\", \\\"{x:737,y:608,t:1527020028418};\\\", \\\"{x:659,y:599,t:1527020028434};\\\", \\\"{x:508,y:579,t:1527020028451};\\\", \\\"{x:430,y:567,t:1527020028468};\\\", \\\"{x:390,y:560,t:1527020028485};\\\", \\\"{x:377,y:555,t:1527020028501};\\\", \\\"{x:376,y:554,t:1527020028551};\\\", \\\"{x:376,y:553,t:1527020028568};\\\", \\\"{x:377,y:552,t:1527020028584};\\\", \\\"{x:379,y:551,t:1527020028601};\\\", \\\"{x:379,y:550,t:1527020028618};\\\", \\\"{x:380,y:548,t:1527020028633};\\\", \\\"{x:384,y:543,t:1527020028651};\\\", \\\"{x:386,y:541,t:1527020028668};\\\", \\\"{x:387,y:539,t:1527020028684};\\\", \\\"{x:389,y:538,t:1527020028701};\\\", \\\"{x:377,y:538,t:1527020028883};\\\", \\\"{x:347,y:538,t:1527020028902};\\\", \\\"{x:318,y:538,t:1527020028916};\\\", \\\"{x:274,y:541,t:1527020028935};\\\", \\\"{x:239,y:542,t:1527020028952};\\\", \\\"{x:224,y:543,t:1527020028968};\\\", \\\"{x:220,y:545,t:1527020028985};\\\", \\\"{x:219,y:545,t:1527020029115};\\\", \\\"{x:216,y:545,t:1527020029123};\\\", \\\"{x:213,y:545,t:1527020029134};\\\", \\\"{x:196,y:544,t:1527020029152};\\\", \\\"{x:180,y:540,t:1527020029168};\\\", \\\"{x:177,y:540,t:1527020029185};\\\", \\\"{x:176,y:540,t:1527020029235};\\\", \\\"{x:180,y:542,t:1527020029443};\\\", \\\"{x:192,y:550,t:1527020029452};\\\", \\\"{x:259,y:601,t:1527020029469};\\\", \\\"{x:336,y:668,t:1527020029486};\\\", \\\"{x:393,y:725,t:1527020029502};\\\", \\\"{x:423,y:757,t:1527020029519};\\\", \\\"{x:433,y:769,t:1527020029534};\\\", \\\"{x:434,y:771,t:1527020029552};\\\", \\\"{x:435,y:771,t:1527020029569};\\\", \\\"{x:438,y:771,t:1527020029584};\\\", \\\"{x:444,y:771,t:1527020029601};\\\", \\\"{x:456,y:771,t:1527020029618};\\\", \\\"{x:465,y:769,t:1527020029634};\\\", \\\"{x:476,y:766,t:1527020029652};\\\", \\\"{x:491,y:762,t:1527020029668};\\\", \\\"{x:502,y:759,t:1527020029685};\\\", \\\"{x:516,y:754,t:1527020029703};\\\", \\\"{x:532,y:752,t:1527020029719};\\\", \\\"{x:545,y:750,t:1527020029734};\\\", \\\"{x:550,y:747,t:1527020029752};\\\", \\\"{x:551,y:747,t:1527020029769};\\\", \\\"{x:551,y:746,t:1527020029970};\\\", \\\"{x:550,y:746,t:1527020029986};\\\", \\\"{x:548,y:745,t:1527020030002};\\\", \\\"{x:545,y:744,t:1527020030019};\\\", \\\"{x:542,y:744,t:1527020030035};\\\", \\\"{x:538,y:744,t:1527020030052};\\\", \\\"{x:534,y:743,t:1527020030068};\\\", \\\"{x:532,y:743,t:1527020030086};\\\", \\\"{x:529,y:743,t:1527020030102};\\\", \\\"{x:528,y:743,t:1527020030119};\\\", \\\"{x:527,y:743,t:1527020030136};\\\", \\\"{x:526,y:743,t:1527020030163};\\\", \\\"{x:525,y:743,t:1527020030227};\\\", \\\"{x:525,y:744,t:1527020030236};\\\", \\\"{x:523,y:745,t:1527020030252};\\\", \\\"{x:522,y:746,t:1527020030269};\\\", \\\"{x:522,y:747,t:1527020030286};\\\", \\\"{x:521,y:749,t:1527020030303};\\\", \\\"{x:520,y:750,t:1527020030323};\\\", \\\"{x:519,y:751,t:1527020030339};\\\", \\\"{x:519,y:752,t:1527020030355};\\\", \\\"{x:518,y:753,t:1527020030369};\\\", \\\"{x:517,y:755,t:1527020030387};\\\", \\\"{x:516,y:759,t:1527020030403};\\\", \\\"{x:516,y:762,t:1527020030419};\\\", \\\"{x:516,y:765,t:1527020030436};\\\", \\\"{x:516,y:766,t:1527020030453};\\\", \\\"{x:516,y:767,t:1527020030475};\\\", \\\"{x:515,y:767,t:1527020030486};\\\", \\\"{x:515,y:768,t:1527020030523};\\\", \\\"{x:515,y:769,t:1527020030546};\\\", \\\"{x:515,y:770,t:1527020030555};\\\", \\\"{x:515,y:771,t:1527020030571};\\\", \\\"{x:517,y:771,t:1527020030723};\\\", \\\"{x:519,y:771,t:1527020030736};\\\", \\\"{x:528,y:770,t:1527020030753};\\\", \\\"{x:540,y:766,t:1527020030770};\\\", \\\"{x:553,y:760,t:1527020030786};\\\", \\\"{x:554,y:760,t:1527020030803};\\\" ] }, { \\\"rt\\\": 10408, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 665528, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:760,t:1527020031803};\\\", \\\"{x:585,y:776,t:1527020031811};\\\", \\\"{x:634,y:800,t:1527020031821};\\\", \\\"{x:753,y:856,t:1527020031837};\\\", \\\"{x:859,y:914,t:1527020031854};\\\", \\\"{x:929,y:951,t:1527020031871};\\\", \\\"{x:951,y:962,t:1527020031886};\\\", \\\"{x:953,y:963,t:1527020031904};\\\", \\\"{x:954,y:965,t:1527020035688};\\\", \\\"{x:961,y:977,t:1527020035705};\\\", \\\"{x:975,y:986,t:1527020035722};\\\", \\\"{x:983,y:990,t:1527020035739};\\\", \\\"{x:988,y:994,t:1527020035755};\\\", \\\"{x:998,y:1004,t:1527020035771};\\\", \\\"{x:1032,y:1033,t:1527020035788};\\\", \\\"{x:1085,y:1071,t:1527020035805};\\\", \\\"{x:1136,y:1108,t:1527020035821};\\\", \\\"{x:1165,y:1122,t:1527020035838};\\\", \\\"{x:1196,y:1136,t:1527020035855};\\\", \\\"{x:1216,y:1141,t:1527020035871};\\\", \\\"{x:1245,y:1146,t:1527020035888};\\\", \\\"{x:1275,y:1147,t:1527020035905};\\\", \\\"{x:1292,y:1149,t:1527020035921};\\\", \\\"{x:1310,y:1141,t:1527020035938};\\\", \\\"{x:1333,y:1124,t:1527020035956};\\\", \\\"{x:1353,y:1104,t:1527020035971};\\\", \\\"{x:1364,y:1079,t:1527020035989};\\\", \\\"{x:1371,y:1051,t:1527020036006};\\\", \\\"{x:1374,y:1023,t:1527020036021};\\\", \\\"{x:1374,y:1005,t:1527020036038};\\\", \\\"{x:1370,y:985,t:1527020036056};\\\", \\\"{x:1370,y:982,t:1527020036072};\\\", \\\"{x:1370,y:980,t:1527020036089};\\\", \\\"{x:1369,y:979,t:1527020036106};\\\", \\\"{x:1368,y:979,t:1527020036123};\\\", \\\"{x:1367,y:978,t:1527020036139};\\\", \\\"{x:1364,y:977,t:1527020036156};\\\", \\\"{x:1360,y:975,t:1527020036172};\\\", \\\"{x:1353,y:974,t:1527020036188};\\\", \\\"{x:1344,y:974,t:1527020036206};\\\", \\\"{x:1325,y:974,t:1527020036224};\\\", \\\"{x:1297,y:975,t:1527020036239};\\\", \\\"{x:1228,y:985,t:1527020036257};\\\", \\\"{x:1173,y:988,t:1527020036272};\\\", \\\"{x:1129,y:992,t:1527020036289};\\\", \\\"{x:1092,y:993,t:1527020036305};\\\", \\\"{x:1068,y:993,t:1527020036323};\\\", \\\"{x:1055,y:993,t:1527020036339};\\\", \\\"{x:1052,y:993,t:1527020036356};\\\", \\\"{x:1052,y:1000,t:1527020038560};\\\", \\\"{x:1059,y:1007,t:1527020038575};\\\", \\\"{x:1080,y:1036,t:1527020038592};\\\", \\\"{x:1093,y:1052,t:1527020038608};\\\", \\\"{x:1105,y:1061,t:1527020038625};\\\", \\\"{x:1108,y:1063,t:1527020038642};\\\", \\\"{x:1111,y:1065,t:1527020038658};\\\", \\\"{x:1114,y:1065,t:1527020038675};\\\", \\\"{x:1121,y:1065,t:1527020038692};\\\", \\\"{x:1131,y:1064,t:1527020038707};\\\", \\\"{x:1146,y:1052,t:1527020038725};\\\", \\\"{x:1169,y:1026,t:1527020038743};\\\", \\\"{x:1198,y:976,t:1527020038758};\\\", \\\"{x:1229,y:892,t:1527020038776};\\\", \\\"{x:1255,y:774,t:1527020038792};\\\", \\\"{x:1260,y:714,t:1527020038808};\\\", \\\"{x:1260,y:682,t:1527020038825};\\\", \\\"{x:1255,y:664,t:1527020038842};\\\", \\\"{x:1249,y:656,t:1527020038858};\\\", \\\"{x:1246,y:655,t:1527020038875};\\\", \\\"{x:1245,y:654,t:1527020038892};\\\", \\\"{x:1244,y:654,t:1527020038908};\\\", \\\"{x:1240,y:654,t:1527020038925};\\\", \\\"{x:1228,y:665,t:1527020038943};\\\", \\\"{x:1223,y:690,t:1527020038959};\\\", \\\"{x:1215,y:721,t:1527020038975};\\\", \\\"{x:1196,y:776,t:1527020038992};\\\", \\\"{x:1187,y:799,t:1527020039008};\\\", \\\"{x:1185,y:810,t:1527020039025};\\\", \\\"{x:1185,y:811,t:1527020039041};\\\", \\\"{x:1185,y:808,t:1527020039168};\\\", \\\"{x:1188,y:798,t:1527020039175};\\\", \\\"{x:1193,y:784,t:1527020039192};\\\", \\\"{x:1197,y:772,t:1527020039208};\\\", \\\"{x:1199,y:763,t:1527020039225};\\\", \\\"{x:1199,y:758,t:1527020039241};\\\", \\\"{x:1199,y:755,t:1527020039259};\\\", \\\"{x:1197,y:755,t:1527020039464};\\\", \\\"{x:1195,y:759,t:1527020039475};\\\", \\\"{x:1192,y:763,t:1527020039491};\\\", \\\"{x:1189,y:765,t:1527020039509};\\\", \\\"{x:1186,y:769,t:1527020039525};\\\", \\\"{x:1180,y:772,t:1527020039542};\\\", \\\"{x:1178,y:773,t:1527020039558};\\\", \\\"{x:1177,y:773,t:1527020039575};\\\", \\\"{x:1176,y:773,t:1527020039591};\\\", \\\"{x:1175,y:774,t:1527020040072};\\\", \\\"{x:1174,y:775,t:1527020040105};\\\", \\\"{x:1173,y:775,t:1527020040225};\\\", \\\"{x:1171,y:776,t:1527020040264};\\\", \\\"{x:1168,y:776,t:1527020040276};\\\", \\\"{x:1149,y:779,t:1527020040293};\\\", \\\"{x:1104,y:780,t:1527020040310};\\\", \\\"{x:1012,y:780,t:1527020040326};\\\", \\\"{x:904,y:780,t:1527020040343};\\\", \\\"{x:746,y:765,t:1527020040360};\\\", \\\"{x:701,y:744,t:1527020040376};\\\", \\\"{x:689,y:735,t:1527020040393};\\\", \\\"{x:685,y:725,t:1527020040410};\\\", \\\"{x:684,y:710,t:1527020040427};\\\", \\\"{x:684,y:688,t:1527020040443};\\\", \\\"{x:690,y:663,t:1527020040460};\\\", \\\"{x:697,y:639,t:1527020040478};\\\", \\\"{x:709,y:618,t:1527020040492};\\\", \\\"{x:717,y:603,t:1527020040509};\\\", \\\"{x:722,y:599,t:1527020040525};\\\", \\\"{x:723,y:597,t:1527020040542};\\\", \\\"{x:724,y:596,t:1527020040558};\\\", \\\"{x:726,y:595,t:1527020040575};\\\", \\\"{x:729,y:595,t:1527020040591};\\\", \\\"{x:734,y:592,t:1527020040609};\\\", \\\"{x:751,y:592,t:1527020040626};\\\", \\\"{x:775,y:592,t:1527020040641};\\\", \\\"{x:801,y:592,t:1527020040658};\\\", \\\"{x:821,y:590,t:1527020040675};\\\", \\\"{x:826,y:588,t:1527020040692};\\\", \\\"{x:828,y:587,t:1527020040708};\\\", \\\"{x:823,y:589,t:1527020041000};\\\", \\\"{x:813,y:596,t:1527020041008};\\\", \\\"{x:791,y:612,t:1527020041025};\\\", \\\"{x:753,y:641,t:1527020041042};\\\", \\\"{x:707,y:675,t:1527020041059};\\\", \\\"{x:655,y:716,t:1527020041075};\\\", \\\"{x:597,y:757,t:1527020041091};\\\", \\\"{x:554,y:791,t:1527020041108};\\\", \\\"{x:529,y:808,t:1527020041126};\\\", \\\"{x:516,y:817,t:1527020041143};\\\", \\\"{x:513,y:820,t:1527020041159};\\\", \\\"{x:514,y:815,t:1527020041273};\\\", \\\"{x:515,y:804,t:1527020041280};\\\", \\\"{x:515,y:797,t:1527020041294};\\\", \\\"{x:515,y:783,t:1527020041309};\\\", \\\"{x:515,y:772,t:1527020041326};\\\", \\\"{x:515,y:766,t:1527020041344};\\\", \\\"{x:515,y:764,t:1527020041358};\\\", \\\"{x:515,y:762,t:1527020041376};\\\", \\\"{x:515,y:759,t:1527020041399};\\\", \\\"{x:515,y:757,t:1527020041415};\\\", \\\"{x:515,y:754,t:1527020041426};\\\", \\\"{x:514,y:751,t:1527020041443};\\\" ] }, { \\\"rt\\\": 60206, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 727046, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I use the mouse to line up where a letter and the time meet on the graph\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7303, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"25\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"the Philippines\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 735357, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 13737, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 750111, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 2856, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 754309, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"39GMD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"39GMD\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 105, dom: 1003, initialDom: 1108",
  "javascriptErrors": []
}