var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e00c545d06d381ab25acba195a2bba12",
  "created": "2018-05-22T15:06:52.8194866-07:00",
  "lastActivity": "2018-05-22T15:07:23.2712427-07:00",
  "pageViews": [
    {
      "id": "052252877fcf55f0833fef473b62f548fe2aac04",
      "startTime": "2018-05-22T15:06:53.101835-07:00",
      "endTime": "2018-05-22T15:07:23.2712427-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 30310,
      "engagementTime": 23210,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30310,
  "engagementTime": 23210,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Q3JLW",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3c357004204fee9e3506898f2a3f7e04",
  "gdpr": false
}