var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4247f08f26a4bc196b09e1d28f45134d",
  "created": "2018-05-22T14:12:00.9633936-07:00",
  "lastActivity": "2018-05-22T14:12:19.5214251-07:00",
  "pageViews": [
    {
      "id": "052201001e158209d9e2b9916c1c80afedaa7812",
      "startTime": "2018-05-22T14:12:01.1320066-07:00",
      "endTime": "2018-05-22T14:12:19.5214251-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 18466,
      "engagementTime": 18466,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18466,
  "engagementTime": 18466,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LK9M",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b524af2c15e56fc9bec7d70a648ad6ad",
  "gdpr": false
}