var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b477b2d0ca1b27c260b2bdc7daa02ddd",
  "created": "2018-05-14T14:12:17.2514836-07:00",
  "lastActivity": "2018-05-14T14:12:32.2820152-07:00",
  "pageViews": [
    {
      "id": "051417318c6b794904a0b298961e7d374b9c2d85",
      "startTime": "2018-05-14T14:12:17.2514836-07:00",
      "endTime": "2018-05-14T14:12:32.2820152-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 15153,
      "engagementTime": 15112,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15153,
  "engagementTime": 15112,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=L0W0F",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "55821ed7b8f47aca0f439ce52c1b13b7",
  "gdpr": false
}