var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "00a226629dc4b671e81530cf70c7d202",
  "created": "2018-05-21T12:17:11.5426189-07:00",
  "lastActivity": "2018-05-21T12:18:41.2196189-07:00",
  "pageViews": [
    {
      "id": "052111419401f06ad51779faf0295befac001a74",
      "startTime": "2018-05-21T12:17:11.5426189-07:00",
      "endTime": "2018-05-21T12:18:41.2196189-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 89677,
      "engagementTime": 53574,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 89677,
  "engagementTime": 53574,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WKBNA",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f2ff0af5b13535b060a6a424fed4cea8",
  "gdpr": false
}