var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052240910f2acbb179c5eef3636daea955d851fd"] = {
  "startTime": "2018-05-22T21:05:40.9169893Z",
  "websitePageUrl": "/",
  "visitTime": 94942,
  "engagementTime": 39770,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1639,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "8fb0bd062957aa9bd0812324c1b78e77",
    "created": "2018-05-22T21:05:40.7939313+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "109ad2e696e85f2ddc6b68a61038e40b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8fb0bd062957aa9bd0812324c1b78e77/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1639,
      "y": 1047
    },
    {
      "t": 239,
      "e": 239,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 1618,
      "e": 1618,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 2,
      "x": 483,
      "y": 79
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 16357,
      "y": 3933,
      "ta": "html > body"
    },
    {
      "t": 10001,
      "e": 6752,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 57701,
      "e": 6752,
      "ty": 2,
      "x": 446,
      "y": 81
    },
    {
      "t": 57751,
      "e": 6802,
      "ty": 41,
      "x": 6474,
      "y": 13960,
      "ta": "> div.masterdiv"
    },
    {
      "t": 57801,
      "e": 6852,
      "ty": 2,
      "x": 205,
      "y": 868
    },
    {
      "t": 57901,
      "e": 6952,
      "ty": 2,
      "x": 447,
      "y": 1199
    },
    {
      "t": 58001,
      "e": 7052,
      "ty": 2,
      "x": 568,
      "y": 1120
    },
    {
      "t": 58002,
      "e": 7053,
      "ty": 41,
      "x": 19285,
      "y": 61601,
      "ta": "> div.masterdiv"
    },
    {
      "t": 58101,
      "e": 7152,
      "ty": 2,
      "x": 751,
      "y": 950
    },
    {
      "t": 58201,
      "e": 7252,
      "ty": 2,
      "x": 738,
      "y": 909
    },
    {
      "t": 58251,
      "e": 7302,
      "ty": 41,
      "x": 22755,
      "y": 62016,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 58301,
      "e": 7352,
      "ty": 2,
      "x": 758,
      "y": 899
    },
    {
      "t": 58401,
      "e": 7452,
      "ty": 2,
      "x": 774,
      "y": 904
    },
    {
      "t": 58500,
      "e": 7551,
      "ty": 2,
      "x": 782,
      "y": 922
    },
    {
      "t": 58501,
      "e": 7552,
      "ty": 41,
      "x": 24035,
      "y": 38452,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 58600,
      "e": 7651,
      "ty": 2,
      "x": 803,
      "y": 929
    },
    {
      "t": 58700,
      "e": 7751,
      "ty": 2,
      "x": 815,
      "y": 928
    },
    {
      "t": 58751,
      "e": 7802,
      "ty": 41,
      "x": 37887,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58766,
      "e": 7817,
      "ty": 3,
      "x": 815,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58862,
      "e": 7913,
      "ty": 4,
      "x": 37887,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58864,
      "e": 7915,
      "ty": 5,
      "x": 815,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 58866,
      "e": 7917,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 58872,
      "e": 7923,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 59001,
      "e": 8052,
      "ty": 2,
      "x": 931,
      "y": 995
    },
    {
      "t": 59001,
      "e": 8052,
      "ty": 41,
      "x": 31365,
      "y": 60155,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59101,
      "e": 8152,
      "ty": 2,
      "x": 965,
      "y": 1028
    },
    {
      "t": 59201,
      "e": 8252,
      "ty": 2,
      "x": 968,
      "y": 1061
    },
    {
      "t": 59255,
      "e": 8306,
      "ty": 41,
      "x": 33284,
      "y": 65348,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59305,
      "e": 8356,
      "ty": 2,
      "x": 975,
      "y": 1084
    },
    {
      "t": 59405,
      "e": 8456,
      "ty": 2,
      "x": 978,
      "y": 1098
    },
    {
      "t": 59505,
      "e": 8556,
      "ty": 41,
      "x": 37409,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 59522,
      "e": 8573,
      "ty": 3,
      "x": 978,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 59523,
      "e": 8574,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 59524,
      "e": 8575,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 59601,
      "e": 8652,
      "ty": 4,
      "x": 37409,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 59602,
      "e": 8653,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 59603,
      "e": 8654,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 59603,
      "e": 8654,
      "ty": 5,
      "x": 978,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 60610,
      "e": 9661,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 60905,
      "e": 9956,
      "ty": 2,
      "x": 979,
      "y": 1098
    },
    {
      "t": 61005,
      "e": 10056,
      "ty": 41,
      "x": 33439,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 61305,
      "e": 10356,
      "ty": 2,
      "x": 981,
      "y": 1098
    },
    {
      "t": 61405,
      "e": 10456,
      "ty": 2,
      "x": 1051,
      "y": 874
    },
    {
      "t": 61470,
      "e": 10521,
      "ty": 6,
      "x": 1054,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61486,
      "e": 10537,
      "ty": 7,
      "x": 1045,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61504,
      "e": 10555,
      "ty": 2,
      "x": 1039,
      "y": 549
    },
    {
      "t": 61504,
      "e": 10555,
      "ty": 41,
      "x": 49962,
      "y": 21064,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 61605,
      "e": 10656,
      "ty": 2,
      "x": 983,
      "y": 484
    },
    {
      "t": 61704,
      "e": 10755,
      "ty": 2,
      "x": 941,
      "y": 536
    },
    {
      "t": 61755,
      "e": 10806,
      "ty": 41,
      "x": 25738,
      "y": 38052,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 61769,
      "e": 10820,
      "ty": 6,
      "x": 923,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61804,
      "e": 10855,
      "ty": 2,
      "x": 922,
      "y": 605
    },
    {
      "t": 61835,
      "e": 10886,
      "ty": 7,
      "x": 922,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61904,
      "e": 10955,
      "ty": 2,
      "x": 921,
      "y": 608
    },
    {
      "t": 62005,
      "e": 11056,
      "ty": 41,
      "x": 24440,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 62154,
      "e": 11205,
      "ty": 6,
      "x": 921,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62205,
      "e": 11256,
      "ty": 2,
      "x": 922,
      "y": 602
    },
    {
      "t": 62254,
      "e": 11305,
      "ty": 41,
      "x": 24656,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62313,
      "e": 11364,
      "ty": 3,
      "x": 922,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62314,
      "e": 11365,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62418,
      "e": 11469,
      "ty": 4,
      "x": 24656,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62418,
      "e": 11469,
      "ty": 5,
      "x": 922,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62705,
      "e": 11756,
      "ty": 2,
      "x": 925,
      "y": 602
    },
    {
      "t": 62755,
      "e": 11806,
      "ty": 41,
      "x": 25305,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64462,
      "e": 13513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 64462,
      "e": 13513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64556,
      "e": 13607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 64556,
      "e": 13607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64597,
      "e": 13648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hi"
    },
    {
      "t": 64661,
      "e": 13712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hi"
    },
    {
      "t": 64949,
      "e": 14000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 64950,
      "e": 14001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65029,
      "e": 14080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 65030,
      "e": 14081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65076,
      "e": 14127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hite"
    },
    {
      "t": 65157,
      "e": 14208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 65286,
      "e": 14337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 65286,
      "e": 14337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65364,
      "e": 14415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||l"
    },
    {
      "t": 66037,
      "e": 15088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 66101,
      "e": 15152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hite"
    },
    {
      "t": 66181,
      "e": 15232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 66236,
      "e": 15287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hit"
    },
    {
      "t": 66316,
      "e": 15367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 66381,
      "e": 15432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hi"
    },
    {
      "t": 66661,
      "e": 15712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 66726,
      "e": 15777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "h"
    },
    {
      "t": 67085,
      "e": 16136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 67087,
      "e": 16138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67148,
      "e": 16199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ho"
    },
    {
      "t": 67301,
      "e": 16352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 67302,
      "e": 16353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67373,
      "e": 16424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 67374,
      "e": 16425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67404,
      "e": 16455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hote"
    },
    {
      "t": 67468,
      "e": 16519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 67469,
      "e": 16520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67476,
      "e": 16527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||l"
    },
    {
      "t": 67532,
      "e": 16583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 68141,
      "e": 17192,
      "ty": 7,
      "x": 926,
      "y": 615,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68205,
      "e": 17256,
      "ty": 2,
      "x": 919,
      "y": 658
    },
    {
      "t": 68225,
      "e": 17276,
      "ty": 6,
      "x": 916,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68256,
      "e": 17307,
      "ty": 41,
      "x": 23359,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68305,
      "e": 17356,
      "ty": 2,
      "x": 916,
      "y": 683
    },
    {
      "t": 68405,
      "e": 17456,
      "ty": 2,
      "x": 916,
      "y": 684
    },
    {
      "t": 68491,
      "e": 17457,
      "ty": 3,
      "x": 916,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68493,
      "e": 17459,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hotel"
    },
    {
      "t": 68494,
      "e": 17460,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68495,
      "e": 17461,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68505,
      "e": 17471,
      "ty": 2,
      "x": 916,
      "y": 685
    },
    {
      "t": 68505,
      "e": 17471,
      "ty": 41,
      "x": 23359,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68568,
      "e": 17534,
      "ty": 4,
      "x": 23359,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68569,
      "e": 17535,
      "ty": 5,
      "x": 916,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69021,
      "e": 17987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 69022,
      "e": 17988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69108,
      "e": 18074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "98"
    },
    {
      "t": 69109,
      "e": 18075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69132,
      "e": 18098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 69205,
      "e": 18171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 69205,
      "e": 18171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69237,
      "e": 18203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 69269,
      "e": 18235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 69605,
      "e": 18571,
      "ty": 2,
      "x": 913,
      "y": 685
    },
    {
      "t": 69705,
      "e": 18671,
      "ty": 2,
      "x": 896,
      "y": 681
    },
    {
      "t": 69756,
      "e": 18722,
      "ty": 41,
      "x": 19033,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70205,
      "e": 19171,
      "ty": 2,
      "x": 903,
      "y": 697
    },
    {
      "t": 70243,
      "e": 19209,
      "ty": 7,
      "x": 906,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70256,
      "e": 19222,
      "ty": 41,
      "x": 21196,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70304,
      "e": 19270,
      "ty": 2,
      "x": 913,
      "y": 707
    },
    {
      "t": 70310,
      "e": 19276,
      "ty": 6,
      "x": 915,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70404,
      "e": 19370,
      "ty": 2,
      "x": 921,
      "y": 715
    },
    {
      "t": 70504,
      "e": 19470,
      "ty": 2,
      "x": 943,
      "y": 729
    },
    {
      "t": 70505,
      "e": 19471,
      "ty": 41,
      "x": 24263,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70570,
      "e": 19536,
      "ty": 3,
      "x": 943,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70570,
      "e": 19536,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 70572,
      "e": 19538,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70572,
      "e": 19538,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70681,
      "e": 19647,
      "ty": 4,
      "x": 24263,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70682,
      "e": 19648,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70682,
      "e": 19648,
      "ty": 5,
      "x": 943,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70682,
      "e": 19648,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 71769,
      "e": 20735,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 71799,
      "e": 20765,
      "ty": 6,
      "x": 943,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 72770,
      "e": 21736,
      "ty": 7,
      "x": 937,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 72770,
      "e": 21736,
      "ty": 6,
      "x": 937,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 72794,
      "e": 21760,
      "ty": 7,
      "x": 819,
      "y": 668,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 72805,
      "e": 21771,
      "ty": 2,
      "x": 819,
      "y": 668
    },
    {
      "t": 72905,
      "e": 21871,
      "ty": 2,
      "x": 374,
      "y": 539
    },
    {
      "t": 73005,
      "e": 21971,
      "ty": 2,
      "x": 371,
      "y": 539
    },
    {
      "t": 73005,
      "e": 21971,
      "ty": 41,
      "x": 3815,
      "y": 30453,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 73404,
      "e": 22370,
      "ty": 2,
      "x": 361,
      "y": 539
    },
    {
      "t": 73445,
      "e": 22411,
      "ty": 6,
      "x": 338,
      "y": 531,
      "ta": "#da1"
    },
    {
      "t": 73504,
      "e": 22470,
      "ty": 2,
      "x": 335,
      "y": 530
    },
    {
      "t": 73504,
      "e": 22470,
      "ty": 41,
      "x": 168,
      "y": 59032,
      "ta": "#da1"
    },
    {
      "t": 73529,
      "e": 22495,
      "ty": 7,
      "x": 332,
      "y": 524,
      "ta": "#da1"
    },
    {
      "t": 73604,
      "e": 22570,
      "ty": 2,
      "x": 330,
      "y": 508
    },
    {
      "t": 73704,
      "e": 22670,
      "ty": 2,
      "x": 331,
      "y": 502
    },
    {
      "t": 73755,
      "e": 22721,
      "ty": 41,
      "x": 64792,
      "y": 23423,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td"
    },
    {
      "t": 73804,
      "e": 22770,
      "ty": 2,
      "x": 337,
      "y": 499
    },
    {
      "t": 73904,
      "e": 22870,
      "ty": 2,
      "x": 354,
      "y": 492
    },
    {
      "t": 74004,
      "e": 22970,
      "ty": 2,
      "x": 392,
      "y": 487
    },
    {
      "t": 74005,
      "e": 22971,
      "ty": 41,
      "x": 6384,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 74104,
      "e": 23070,
      "ty": 2,
      "x": 579,
      "y": 484
    },
    {
      "t": 74204,
      "e": 23170,
      "ty": 2,
      "x": 789,
      "y": 476
    },
    {
      "t": 74254,
      "e": 23220,
      "ty": 41,
      "x": 31168,
      "y": 9762,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74304,
      "e": 23270,
      "ty": 2,
      "x": 976,
      "y": 431
    },
    {
      "t": 74404,
      "e": 23370,
      "ty": 2,
      "x": 509,
      "y": 124
    },
    {
      "t": 74504,
      "e": 23470,
      "ty": 2,
      "x": 0,
      "y": 87
    },
    {
      "t": 74504,
      "e": 23470,
      "ty": 41,
      "x": 0,
      "y": 4819,
      "ta": "html"
    },
    {
      "t": 74604,
      "e": 23570,
      "ty": 2,
      "x": 229,
      "y": 827
    },
    {
      "t": 74705,
      "e": 23671,
      "ty": 2,
      "x": 1183,
      "y": 1199
    },
    {
      "t": 74804,
      "e": 23770,
      "ty": 2,
      "x": 1436,
      "y": 1199
    },
    {
      "t": 74904,
      "e": 23870,
      "ty": 2,
      "x": 1466,
      "y": 1178
    },
    {
      "t": 75004,
      "e": 23970,
      "ty": 2,
      "x": 1466,
      "y": 1158
    },
    {
      "t": 75005,
      "e": 23971,
      "ty": 41,
      "x": 50210,
      "y": 63706,
      "ta": "> div.masterdiv"
    },
    {
      "t": 75104,
      "e": 24070,
      "ty": 2,
      "x": 1462,
      "y": 1135
    },
    {
      "t": 75204,
      "e": 24170,
      "ty": 2,
      "x": 1447,
      "y": 1105
    },
    {
      "t": 75255,
      "e": 24221,
      "ty": 41,
      "x": 49418,
      "y": 60493,
      "ta": "> div.masterdiv"
    },
    {
      "t": 75304,
      "e": 24270,
      "ty": 2,
      "x": 1438,
      "y": 1096
    },
    {
      "t": 75404,
      "e": 24370,
      "ty": 2,
      "x": 1398,
      "y": 1096
    },
    {
      "t": 75504,
      "e": 24470,
      "ty": 2,
      "x": 1390,
      "y": 1094
    },
    {
      "t": 75504,
      "e": 24470,
      "ty": 41,
      "x": 47592,
      "y": 60161,
      "ta": "> div.masterdiv"
    },
    {
      "t": 75754,
      "e": 24720,
      "ty": 41,
      "x": 47558,
      "y": 60161,
      "ta": "> div.masterdiv"
    },
    {
      "t": 75804,
      "e": 24770,
      "ty": 2,
      "x": 1389,
      "y": 1094
    },
    {
      "t": 76104,
      "e": 25070,
      "ty": 2,
      "x": 1389,
      "y": 1093
    },
    {
      "t": 76255,
      "e": 25221,
      "ty": 41,
      "x": 47558,
      "y": 60106,
      "ta": "> div.masterdiv"
    },
    {
      "t": 78704,
      "e": 27670,
      "ty": 2,
      "x": 1386,
      "y": 1095
    },
    {
      "t": 78755,
      "e": 27721,
      "ty": 41,
      "x": 47351,
      "y": 60493,
      "ta": "> div.masterdiv"
    },
    {
      "t": 78804,
      "e": 27770,
      "ty": 2,
      "x": 1381,
      "y": 1103
    },
    {
      "t": 78904,
      "e": 27870,
      "ty": 2,
      "x": 1380,
      "y": 1104
    },
    {
      "t": 79004,
      "e": 27970,
      "ty": 41,
      "x": 47248,
      "y": 60715,
      "ta": "> div.masterdiv"
    },
    {
      "t": 79104,
      "e": 28070,
      "ty": 2,
      "x": 1380,
      "y": 1105
    },
    {
      "t": 79255,
      "e": 28221,
      "ty": 41,
      "x": 47248,
      "y": 60770,
      "ta": "> div.masterdiv"
    },
    {
      "t": 80004,
      "e": 28970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 81005,
      "e": 29971,
      "ty": 2,
      "x": 1379,
      "y": 1106
    },
    {
      "t": 81005,
      "e": 29971,
      "ty": 41,
      "x": 47214,
      "y": 60826,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81105,
      "e": 30071,
      "ty": 2,
      "x": 1377,
      "y": 1108
    },
    {
      "t": 81254,
      "e": 30220,
      "ty": 41,
      "x": 47145,
      "y": 60937,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81404,
      "e": 30370,
      "ty": 2,
      "x": 1355,
      "y": 1138
    },
    {
      "t": 81504,
      "e": 30470,
      "ty": 2,
      "x": 1330,
      "y": 1155
    },
    {
      "t": 81504,
      "e": 30470,
      "ty": 41,
      "x": 45526,
      "y": 63540,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81604,
      "e": 30570,
      "ty": 2,
      "x": 1246,
      "y": 1170
    },
    {
      "t": 81705,
      "e": 30671,
      "ty": 2,
      "x": 1146,
      "y": 1170
    },
    {
      "t": 81755,
      "e": 30721,
      "ty": 41,
      "x": 36676,
      "y": 64371,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81805,
      "e": 30771,
      "ty": 2,
      "x": 1040,
      "y": 1164
    },
    {
      "t": 81904,
      "e": 30870,
      "ty": 2,
      "x": 1025,
      "y": 1157
    },
    {
      "t": 82005,
      "e": 30971,
      "ty": 2,
      "x": 1011,
      "y": 1138
    },
    {
      "t": 82005,
      "e": 30971,
      "ty": 41,
      "x": 56875,
      "y": 36182,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 82104,
      "e": 31070,
      "ty": 2,
      "x": 1003,
      "y": 1126
    },
    {
      "t": 82204,
      "e": 31170,
      "ty": 2,
      "x": 997,
      "y": 1118
    },
    {
      "t": 82255,
      "e": 31221,
      "ty": 41,
      "x": 48449,
      "y": 22886,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 82304,
      "e": 31270,
      "ty": 2,
      "x": 992,
      "y": 1112
    },
    {
      "t": 82404,
      "e": 31370,
      "ty": 2,
      "x": 990,
      "y": 1112
    },
    {
      "t": 82504,
      "e": 31470,
      "ty": 2,
      "x": 989,
      "y": 1109
    },
    {
      "t": 82504,
      "e": 31470,
      "ty": 41,
      "x": 46576,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 82604,
      "e": 31570,
      "ty": 2,
      "x": 989,
      "y": 1108
    },
    {
      "t": 82690,
      "e": 31656,
      "ty": 6,
      "x": 987,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 82704,
      "e": 31670,
      "ty": 2,
      "x": 987,
      "y": 1104
    },
    {
      "t": 82754,
      "e": 31720,
      "ty": 41,
      "x": 42324,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 82804,
      "e": 31770,
      "ty": 2,
      "x": 987,
      "y": 1102
    },
    {
      "t": 82904,
      "e": 31870,
      "ty": 2,
      "x": 987,
      "y": 1100
    },
    {
      "t": 83004,
      "e": 31970,
      "ty": 2,
      "x": 987,
      "y": 1098
    },
    {
      "t": 83004,
      "e": 31970,
      "ty": 41,
      "x": 42324,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 83146,
      "e": 32112,
      "ty": 3,
      "x": 987,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 83147,
      "e": 32113,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 83265,
      "e": 32231,
      "ty": 4,
      "x": 42324,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 83265,
      "e": 32231,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 83266,
      "e": 32232,
      "ty": 5,
      "x": 987,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 83268,
      "e": 32234,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 84269,
      "e": 33235,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 90005,
      "e": 37232,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92404,
      "e": 37232,
      "ty": 2,
      "x": 988,
      "y": 1095
    },
    {
      "t": 92505,
      "e": 37333,
      "ty": 41,
      "x": 33748,
      "y": 60216,
      "ta": "html > body"
    },
    {
      "t": 92605,
      "e": 37433,
      "ty": 2,
      "x": 991,
      "y": 1090
    },
    {
      "t": 92705,
      "e": 37533,
      "ty": 2,
      "x": 991,
      "y": 1084
    },
    {
      "t": 92756,
      "e": 37584,
      "ty": 41,
      "x": 33852,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 92805,
      "e": 37633,
      "ty": 2,
      "x": 991,
      "y": 1082
    },
    {
      "t": 93936,
      "e": 38764,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 94942,
      "e": 39770,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 94, dom: 561, initialDom: 565",
  "javascriptErrors": []
}