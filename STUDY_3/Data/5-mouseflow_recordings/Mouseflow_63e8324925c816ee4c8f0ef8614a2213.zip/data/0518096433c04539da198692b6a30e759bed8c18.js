var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0518096433c04539da198692b6a30e759bed8c18"] = {
  "startTime": "2018-05-18T18:08:09.9468273Z",
  "websitePageUrl": "/",
  "visitTime": 163157,
  "engagementTime": 53112,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "63e8324925c816ee4c8f0ef8614a2213",
    "created": "2018-05-18T18:08:09.9468273+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b463baa8224df714741d9c3ed4c4b7f7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/63e8324925c816ee4c8f0ef8614a2213/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 285,
      "e": 285,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 619,
      "y": 48
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 21041,
      "y": 2433,
      "ta": "html > body"
    },
    {
      "t": 607,
      "e": 607,
      "ty": 2,
      "x": 625,
      "y": 52
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 21041,
      "y": 3711,
      "ta": "html > body"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 605,
      "y": 101
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 603,
      "y": 111
    },
    {
      "t": 1004,
      "e": 1004,
      "ty": 41,
      "x": 20490,
      "y": 6267,
      "ta": "html > body"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 602,
      "y": 111
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 666,
      "y": 98
    },
    {
      "t": 2010,
      "e": 2010,
      "ty": 41,
      "x": 22660,
      "y": 5476,
      "ta": "html > body"
    },
    {
      "t": 10002,
      "e": 7010,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27800,
      "e": 7010,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 27800,
      "e": 7010,
      "ty": 2,
      "x": 666,
      "y": 164
    },
    {
      "t": 28000,
      "e": 7210,
      "ty": 41,
      "x": 22660,
      "y": 8641,
      "ta": "html > body"
    },
    {
      "t": 40001,
      "e": 12210,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50061,
      "e": 12210,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 50101,
      "e": 12210,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 50201,
      "e": 12310,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 50301,
      "e": 12410,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 51150,
      "e": 13259,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 60000,
      "e": 17410,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70000,
      "e": 17410,
      "ty": 2,
      "x": 800,
      "y": 430
    },
    {
      "t": 70001,
      "e": 17411,
      "ty": 41,
      "x": 24920,
      "y": 7025,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70100,
      "e": 17510,
      "ty": 2,
      "x": 955,
      "y": 735
    },
    {
      "t": 70201,
      "e": 17611,
      "ty": 2,
      "x": 997,
      "y": 828
    },
    {
      "t": 70251,
      "e": 17661,
      "ty": 41,
      "x": 35005,
      "y": 60670,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 70300,
      "e": 17710,
      "ty": 2,
      "x": 1001,
      "y": 938
    },
    {
      "t": 70400,
      "e": 17810,
      "ty": 2,
      "x": 901,
      "y": 983
    },
    {
      "t": 70500,
      "e": 17910,
      "ty": 2,
      "x": 866,
      "y": 970
    },
    {
      "t": 70500,
      "e": 17910,
      "ty": 41,
      "x": 28167,
      "y": 58424,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70601,
      "e": 18011,
      "ty": 2,
      "x": 856,
      "y": 897
    },
    {
      "t": 70701,
      "e": 18111,
      "ty": 2,
      "x": 829,
      "y": 907
    },
    {
      "t": 70751,
      "e": 18161,
      "ty": 41,
      "x": 14950,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 70801,
      "e": 18211,
      "ty": 2,
      "x": 807,
      "y": 925
    },
    {
      "t": 70901,
      "e": 18311,
      "ty": 2,
      "x": 835,
      "y": 941
    },
    {
      "t": 71000,
      "e": 18410,
      "ty": 2,
      "x": 1097,
      "y": 946
    },
    {
      "t": 71001,
      "e": 18411,
      "ty": 41,
      "x": 39532,
      "y": 56762,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71100,
      "e": 18510,
      "ty": 2,
      "x": 1124,
      "y": 949
    },
    {
      "t": 71251,
      "e": 18661,
      "ty": 41,
      "x": 40860,
      "y": 56969,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79999,
      "e": 23661,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 121898,
      "e": 23661,
      "ty": 2,
      "x": 1121,
      "y": 947
    },
    {
      "t": 121998,
      "e": 23761,
      "ty": 2,
      "x": 1054,
      "y": 943
    },
    {
      "t": 121998,
      "e": 23761,
      "ty": 41,
      "x": 37416,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122099,
      "e": 23862,
      "ty": 2,
      "x": 970,
      "y": 942
    },
    {
      "t": 122198,
      "e": 23961,
      "ty": 2,
      "x": 843,
      "y": 925
    },
    {
      "t": 122248,
      "e": 24011,
      "ty": 41,
      "x": 47717,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122298,
      "e": 24061,
      "ty": 2,
      "x": 818,
      "y": 917
    },
    {
      "t": 122398,
      "e": 24161,
      "ty": 2,
      "x": 835,
      "y": 912
    },
    {
      "t": 122498,
      "e": 24261,
      "ty": 2,
      "x": 809,
      "y": 912
    },
    {
      "t": 122498,
      "e": 24261,
      "ty": 41,
      "x": 18226,
      "y": 3327,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 122599,
      "e": 24362,
      "ty": 2,
      "x": 798,
      "y": 912
    },
    {
      "t": 122699,
      "e": 24462,
      "ty": 2,
      "x": 799,
      "y": 922
    },
    {
      "t": 122749,
      "e": 24512,
      "ty": 41,
      "x": 25018,
      "y": 45231,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 122798,
      "e": 24561,
      "ty": 2,
      "x": 808,
      "y": 926
    },
    {
      "t": 122999,
      "e": 24762,
      "ty": 41,
      "x": 14950,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123004,
      "e": 24767,
      "ty": 3,
      "x": 808,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123116,
      "e": 24879,
      "ty": 4,
      "x": 14950,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123117,
      "e": 24880,
      "ty": 5,
      "x": 808,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123120,
      "e": 24883,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 123123,
      "e": 24886,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 123298,
      "e": 25061,
      "ty": 2,
      "x": 833,
      "y": 940
    },
    {
      "t": 123398,
      "e": 25161,
      "ty": 2,
      "x": 1012,
      "y": 1023
    },
    {
      "t": 123498,
      "e": 25261,
      "ty": 2,
      "x": 1048,
      "y": 1065
    },
    {
      "t": 123499,
      "e": 25262,
      "ty": 41,
      "x": 37121,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 123549,
      "e": 25312,
      "ty": 6,
      "x": 1015,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 123598,
      "e": 25361,
      "ty": 2,
      "x": 989,
      "y": 1094
    },
    {
      "t": 123698,
      "e": 25461,
      "ty": 2,
      "x": 985,
      "y": 1095
    },
    {
      "t": 123748,
      "e": 25511,
      "ty": 41,
      "x": 41232,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 123885,
      "e": 25648,
      "ty": 3,
      "x": 985,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 123886,
      "e": 25649,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 123886,
      "e": 25649,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124021,
      "e": 25784,
      "ty": 4,
      "x": 41232,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 124023,
      "e": 25786,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124026,
      "e": 25789,
      "ty": 5,
      "x": 985,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 124028,
      "e": 25791,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 125034,
      "e": 26797,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 125698,
      "e": 27461,
      "ty": 2,
      "x": 988,
      "y": 905
    },
    {
      "t": 125748,
      "e": 27511,
      "ty": 41,
      "x": 34541,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 125749,
      "e": 27512,
      "ty": 6,
      "x": 1013,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 125798,
      "e": 27561,
      "ty": 2,
      "x": 1016,
      "y": 719
    },
    {
      "t": 125817,
      "e": 27580,
      "ty": 7,
      "x": 1018,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 125818,
      "e": 27581,
      "ty": 6,
      "x": 1018,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 125833,
      "e": 27596,
      "ty": 7,
      "x": 1020,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 125898,
      "e": 27661,
      "ty": 2,
      "x": 1023,
      "y": 646
    },
    {
      "t": 125998,
      "e": 27761,
      "ty": 2,
      "x": 1025,
      "y": 637
    },
    {
      "t": 125999,
      "e": 27762,
      "ty": 41,
      "x": 46934,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 126084,
      "e": 27847,
      "ty": 6,
      "x": 1025,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126099,
      "e": 27862,
      "ty": 2,
      "x": 1025,
      "y": 605
    },
    {
      "t": 126166,
      "e": 27929,
      "ty": 7,
      "x": 1026,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126199,
      "e": 27962,
      "ty": 2,
      "x": 1026,
      "y": 585
    },
    {
      "t": 126249,
      "e": 28012,
      "ty": 41,
      "x": 47366,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 126298,
      "e": 28061,
      "ty": 2,
      "x": 1027,
      "y": 582
    },
    {
      "t": 126332,
      "e": 28095,
      "ty": 3,
      "x": 1027,
      "y": 582,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 126452,
      "e": 28215,
      "ty": 4,
      "x": 47366,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 126452,
      "e": 28215,
      "ty": 5,
      "x": 1027,
      "y": 582,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 126485,
      "e": 28248,
      "ty": 6,
      "x": 1027,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126498,
      "e": 28261,
      "ty": 2,
      "x": 1027,
      "y": 586
    },
    {
      "t": 126498,
      "e": 28261,
      "ty": 41,
      "x": 47366,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126599,
      "e": 28362,
      "ty": 2,
      "x": 1030,
      "y": 596
    },
    {
      "t": 126692,
      "e": 28455,
      "ty": 3,
      "x": 1030,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126694,
      "e": 28457,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126748,
      "e": 28511,
      "ty": 41,
      "x": 48015,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126795,
      "e": 28558,
      "ty": 4,
      "x": 48015,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126795,
      "e": 28558,
      "ty": 5,
      "x": 1030,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128273,
      "e": 30036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 128376,
      "e": 30139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 128377,
      "e": 30140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128464,
      "e": 30227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 128568,
      "e": 30331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 128568,
      "e": 30331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128655,
      "e": 30418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ME"
    },
    {
      "t": 128695,
      "e": 30458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 128695,
      "e": 30458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128760,
      "e": 30523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 128832,
      "e": 30595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 129637,
      "e": 31400,
      "ty": 7,
      "x": 1029,
      "y": 620,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129699,
      "e": 31462,
      "ty": 2,
      "x": 1018,
      "y": 671
    },
    {
      "t": 129748,
      "e": 31511,
      "ty": 41,
      "x": 44987,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 129799,
      "e": 31562,
      "ty": 2,
      "x": 1016,
      "y": 674
    },
    {
      "t": 129888,
      "e": 31651,
      "ty": 6,
      "x": 1016,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129899,
      "e": 31662,
      "ty": 2,
      "x": 1016,
      "y": 683
    },
    {
      "t": 129999,
      "e": 31762,
      "ty": 2,
      "x": 1016,
      "y": 691
    },
    {
      "t": 129999,
      "e": 31762,
      "ty": 41,
      "x": 44987,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129999,
      "e": 31762,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130283,
      "e": 32046,
      "ty": 3,
      "x": 1016,
      "y": 691,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130284,
      "e": 32047,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 130284,
      "e": 32047,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 130284,
      "e": 32047,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130402,
      "e": 32165,
      "ty": 4,
      "x": 44987,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130403,
      "e": 32166,
      "ty": 5,
      "x": 1016,
      "y": 691,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131664,
      "e": 33427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 131664,
      "e": 33427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131719,
      "e": 33482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 131815,
      "e": 33578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 131815,
      "e": 33578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131872,
      "e": 33635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 131976,
      "e": 33739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 131977,
      "e": 33740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132055,
      "e": 33818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 132698,
      "e": 34461,
      "ty": 2,
      "x": 1021,
      "y": 683
    },
    {
      "t": 132706,
      "e": 34469,
      "ty": 7,
      "x": 1030,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132748,
      "e": 34511,
      "ty": 41,
      "x": 51908,
      "y": 60853,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 132797,
      "e": 34560,
      "ty": 2,
      "x": 1048,
      "y": 663
    },
    {
      "t": 132822,
      "e": 34585,
      "ty": 6,
      "x": 1039,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132856,
      "e": 34619,
      "ty": 7,
      "x": 1019,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132897,
      "e": 34660,
      "ty": 2,
      "x": 1015,
      "y": 705
    },
    {
      "t": 132956,
      "e": 34719,
      "ty": 6,
      "x": 1002,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132997,
      "e": 34760,
      "ty": 2,
      "x": 993,
      "y": 717
    },
    {
      "t": 132998,
      "e": 34761,
      "ty": 41,
      "x": 50033,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133097,
      "e": 34860,
      "ty": 2,
      "x": 990,
      "y": 721
    },
    {
      "t": 133248,
      "e": 35011,
      "ty": 41,
      "x": 48486,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133565,
      "e": 35328,
      "ty": 3,
      "x": 990,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133566,
      "e": 35329,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 133567,
      "e": 35330,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133568,
      "e": 35331,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133660,
      "e": 35423,
      "ty": 4,
      "x": 48486,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133660,
      "e": 35423,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133661,
      "e": 35424,
      "ty": 5,
      "x": 990,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 133662,
      "e": 35425,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 135001,
      "e": 36764,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 135028,
      "e": 36791,
      "ty": 6,
      "x": 990,
      "y": 721,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 135748,
      "e": 37511,
      "ty": 41,
      "x": 32930,
      "y": 51528,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 135791,
      "e": 37554,
      "ty": 7,
      "x": 929,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 135792,
      "e": 37555,
      "ty": 6,
      "x": 929,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 135797,
      "e": 37560,
      "ty": 2,
      "x": 929,
      "y": 698
    },
    {
      "t": 135876,
      "e": 37639,
      "ty": 7,
      "x": 836,
      "y": 667,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 135897,
      "e": 37660,
      "ty": 2,
      "x": 826,
      "y": 662
    },
    {
      "t": 135998,
      "e": 37761,
      "ty": 2,
      "x": 833,
      "y": 660
    },
    {
      "t": 135998,
      "e": 37761,
      "ty": 41,
      "x": 26544,
      "y": 39354,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 136098,
      "e": 37861,
      "ty": 2,
      "x": 931,
      "y": 649
    },
    {
      "t": 136197,
      "e": 37960,
      "ty": 2,
      "x": 982,
      "y": 649
    },
    {
      "t": 136248,
      "e": 38011,
      "ty": 41,
      "x": 33874,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 139997,
      "e": 41760,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 142398,
      "e": 43011,
      "ty": 2,
      "x": 963,
      "y": 645
    },
    {
      "t": 142498,
      "e": 43111,
      "ty": 2,
      "x": 954,
      "y": 645
    },
    {
      "t": 142498,
      "e": 43111,
      "ty": 41,
      "x": 32496,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 142598,
      "e": 43211,
      "ty": 2,
      "x": 948,
      "y": 645
    },
    {
      "t": 142698,
      "e": 43311,
      "ty": 2,
      "x": 927,
      "y": 645
    },
    {
      "t": 142748,
      "e": 43361,
      "ty": 41,
      "x": 29741,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 142798,
      "e": 43411,
      "ty": 2,
      "x": 854,
      "y": 651
    },
    {
      "t": 142898,
      "e": 43511,
      "ty": 2,
      "x": 815,
      "y": 659
    },
    {
      "t": 142949,
      "e": 43562,
      "ty": 6,
      "x": 800,
      "y": 679,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 142998,
      "e": 43611,
      "ty": 7,
      "x": 788,
      "y": 699,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 142998,
      "e": 43611,
      "ty": 6,
      "x": 788,
      "y": 699,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 142999,
      "e": 43612,
      "ty": 2,
      "x": 788,
      "y": 699
    },
    {
      "t": 143000,
      "e": 43613,
      "ty": 41,
      "x": 23101,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 143097,
      "e": 43710,
      "ty": 2,
      "x": 760,
      "y": 720
    },
    {
      "t": 143180,
      "e": 43793,
      "ty": 7,
      "x": 656,
      "y": 690,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 143181,
      "e": 43794,
      "ty": 6,
      "x": 656,
      "y": 690,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 143198,
      "e": 43811,
      "ty": 7,
      "x": 615,
      "y": 667,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 143198,
      "e": 43811,
      "ty": 2,
      "x": 615,
      "y": 667
    },
    {
      "t": 143247,
      "e": 43860,
      "ty": 6,
      "x": 481,
      "y": 521,
      "ta": "#da1"
    },
    {
      "t": 143247,
      "e": 43860,
      "ty": 41,
      "x": 16106,
      "y": 29541,
      "ta": "#da1"
    },
    {
      "t": 143264,
      "e": 43877,
      "ty": 7,
      "x": 456,
      "y": 493,
      "ta": "#da1"
    },
    {
      "t": 143297,
      "e": 43910,
      "ty": 2,
      "x": 420,
      "y": 469
    },
    {
      "t": 143398,
      "e": 44011,
      "ty": 2,
      "x": 406,
      "y": 464
    },
    {
      "t": 143498,
      "e": 44111,
      "ty": 2,
      "x": 419,
      "y": 445
    },
    {
      "t": 143499,
      "e": 44112,
      "ty": 41,
      "x": 6176,
      "y": 45658,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 143597,
      "e": 44210,
      "ty": 2,
      "x": 488,
      "y": 497
    },
    {
      "t": 143615,
      "e": 44228,
      "ty": 6,
      "x": 509,
      "y": 514,
      "ta": "#da1"
    },
    {
      "t": 143647,
      "e": 44260,
      "ty": 7,
      "x": 538,
      "y": 534,
      "ta": "#da1"
    },
    {
      "t": 143698,
      "e": 44311,
      "ty": 2,
      "x": 540,
      "y": 536
    },
    {
      "t": 143749,
      "e": 44362,
      "ty": 41,
      "x": 12719,
      "y": 33549,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 143797,
      "e": 44410,
      "ty": 2,
      "x": 608,
      "y": 583
    },
    {
      "t": 143882,
      "e": 44495,
      "ty": 6,
      "x": 774,
      "y": 675,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 143897,
      "e": 44510,
      "ty": 2,
      "x": 774,
      "y": 675
    },
    {
      "t": 143914,
      "e": 44527,
      "ty": 7,
      "x": 812,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 143914,
      "e": 44527,
      "ty": 6,
      "x": 812,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 143949,
      "e": 44562,
      "ty": 7,
      "x": 834,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 143949,
      "e": 44562,
      "ty": 6,
      "x": 834,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 143982,
      "e": 44595,
      "ty": 7,
      "x": 844,
      "y": 763,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 143983,
      "e": 44596,
      "ty": 6,
      "x": 844,
      "y": 763,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 143998,
      "e": 44611,
      "ty": 2,
      "x": 844,
      "y": 763
    },
    {
      "t": 143999,
      "e": 44612,
      "ty": 41,
      "x": 25938,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 144015,
      "e": 44628,
      "ty": 7,
      "x": 845,
      "y": 801,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 144098,
      "e": 44711,
      "ty": 2,
      "x": 831,
      "y": 975
    },
    {
      "t": 144198,
      "e": 44811,
      "ty": 2,
      "x": 831,
      "y": 1051
    },
    {
      "t": 144248,
      "e": 44861,
      "ty": 41,
      "x": 26691,
      "y": 64033,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144298,
      "e": 44911,
      "ty": 2,
      "x": 881,
      "y": 1036
    },
    {
      "t": 144398,
      "e": 45011,
      "ty": 2,
      "x": 1013,
      "y": 996
    },
    {
      "t": 144498,
      "e": 45111,
      "ty": 2,
      "x": 1031,
      "y": 1010
    },
    {
      "t": 144499,
      "e": 45112,
      "ty": 41,
      "x": 36285,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144567,
      "e": 45180,
      "ty": 6,
      "x": 986,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 144598,
      "e": 45211,
      "ty": 2,
      "x": 978,
      "y": 1080
    },
    {
      "t": 144698,
      "e": 45311,
      "ty": 2,
      "x": 951,
      "y": 1086
    },
    {
      "t": 144748,
      "e": 45361,
      "ty": 41,
      "x": 21025,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 144798,
      "e": 45411,
      "ty": 2,
      "x": 948,
      "y": 1091
    },
    {
      "t": 144898,
      "e": 45511,
      "ty": 2,
      "x": 960,
      "y": 1100
    },
    {
      "t": 144999,
      "e": 45612,
      "ty": 41,
      "x": 27579,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 145098,
      "e": 45711,
      "ty": 2,
      "x": 970,
      "y": 1098
    },
    {
      "t": 145198,
      "e": 45811,
      "ty": 2,
      "x": 979,
      "y": 1093
    },
    {
      "t": 145248,
      "e": 45861,
      "ty": 41,
      "x": 40140,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 145298,
      "e": 45911,
      "ty": 2,
      "x": 984,
      "y": 1087
    },
    {
      "t": 145429,
      "e": 46042,
      "ty": 3,
      "x": 984,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 145430,
      "e": 46043,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145498,
      "e": 46111,
      "ty": 41,
      "x": 40686,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 145587,
      "e": 46200,
      "ty": 4,
      "x": 40686,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 145588,
      "e": 46201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145589,
      "e": 46202,
      "ty": 5,
      "x": 984,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 145590,
      "e": 46203,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 146098,
      "e": 46711,
      "ty": 2,
      "x": 984,
      "y": 1085
    },
    {
      "t": 146198,
      "e": 46811,
      "ty": 2,
      "x": 984,
      "y": 1081
    },
    {
      "t": 146248,
      "e": 46861,
      "ty": 41,
      "x": 33507,
      "y": 59108,
      "ta": "html > body"
    },
    {
      "t": 146298,
      "e": 46911,
      "ty": 2,
      "x": 978,
      "y": 1063
    },
    {
      "t": 146398,
      "e": 47011,
      "ty": 2,
      "x": 950,
      "y": 1007
    },
    {
      "t": 146498,
      "e": 47111,
      "ty": 2,
      "x": 923,
      "y": 965
    },
    {
      "t": 146498,
      "e": 47111,
      "ty": 41,
      "x": 31510,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 146593,
      "e": 47206,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 146598,
      "e": 47211,
      "ty": 2,
      "x": 885,
      "y": 931
    },
    {
      "t": 146698,
      "e": 47311,
      "ty": 2,
      "x": 792,
      "y": 800
    },
    {
      "t": 146748,
      "e": 47361,
      "ty": 41,
      "x": 23422,
      "y": 47404,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 146798,
      "e": 47411,
      "ty": 2,
      "x": 761,
      "y": 743
    },
    {
      "t": 146898,
      "e": 47511,
      "ty": 2,
      "x": 759,
      "y": 739
    },
    {
      "t": 146999,
      "e": 47612,
      "ty": 41,
      "x": 23034,
      "y": 46084,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 147198,
      "e": 47811,
      "ty": 2,
      "x": 779,
      "y": 732
    },
    {
      "t": 147248,
      "e": 47861,
      "ty": 41,
      "x": 27112,
      "y": 44453,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 147298,
      "e": 47911,
      "ty": 2,
      "x": 895,
      "y": 716
    },
    {
      "t": 147399,
      "e": 48012,
      "ty": 2,
      "x": 980,
      "y": 717
    },
    {
      "t": 147499,
      "e": 48112,
      "ty": 41,
      "x": 33762,
      "y": 44375,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 149998,
      "e": 50611,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 162146,
      "e": 53112,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 163157,
      "e": 53112,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 113, dom: 1338, initialDom: 2717",
  "javascriptErrors": []
}