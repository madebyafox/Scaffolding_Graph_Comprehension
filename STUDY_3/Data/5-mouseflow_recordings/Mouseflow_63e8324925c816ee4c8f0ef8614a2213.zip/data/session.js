var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "63e8324925c816ee4c8f0ef8614a2213",
  "created": "2018-05-18T11:08:09.9468273-07:00",
  "lastActivity": "2018-05-18T11:10:52.2893762-07:00",
  "pageViews": [
    {
      "id": "0518096433c04539da198692b6a30e759bed8c18",
      "startTime": "2018-05-18T11:08:09.9468273-07:00",
      "endTime": "2018-05-18T11:10:52.2893762-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 163157,
      "engagementTime": 53112,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 163157,
  "engagementTime": 53112,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.42",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b463baa8224df714741d9c3ed4c4b7f7",
  "gdpr": false
}