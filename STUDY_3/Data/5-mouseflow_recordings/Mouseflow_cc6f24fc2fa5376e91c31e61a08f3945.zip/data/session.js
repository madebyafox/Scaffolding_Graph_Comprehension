var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cc6f24fc2fa5376e91c31e61a08f3945",
  "created": "2018-05-21T09:11:33.4046734-07:00",
  "lastActivity": "2018-05-21T09:12:42.8066949-07:00",
  "pageViews": [
    {
      "id": "052133694de89a851987235bc18ac4bdc1e28175",
      "startTime": "2018-05-21T09:11:33.4316949-07:00",
      "endTime": "2018-05-21T09:12:42.8066949-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 69375,
      "engagementTime": 68772,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 69375,
  "engagementTime": 68772,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=G72GB",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b0214168d631aa750c6fb207db71518d",
  "gdpr": false
}