var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052133694de89a851987235bc18ac4bdc1e28175"] = {
  "startTime": "2018-05-21T16:11:33.4316949Z",
  "websitePageUrl": "/16",
  "visitTime": 69375,
  "engagementTime": 68772,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1353,
  "viewportHeight": 780,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "cc6f24fc2fa5376e91c31e61a08f3945",
    "created": "2018-05-21T16:11:33.4046734+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.139",
    "os": "macOS",
    "osVersion": "10.12 Sierra",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1440x900",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=G72GB",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b0214168d631aa750c6fb207db71518d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/cc6f24fc2fa5376e91c31e61a08f3945/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 0,
      "x": 1353,
      "y": 780
    },
    {
      "t": 2,
      "e": 2,
      "ty": 1,
      "x": 8,
      "y": 16
    },
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 796
    },
    {
      "t": 259,
      "e": 259,
      "ty": 1,
      "x": 8,
      "y": 46
    },
    {
      "t": 1087,
      "e": 1087,
      "ty": 6,
      "x": 294,
      "y": 466,
      "ta": "#strategyButton"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 294,
      "y": 466
    },
    {
      "t": 1104,
      "e": 1104,
      "ty": 7,
      "x": 296,
      "y": 446,
      "ta": "#strategyButton"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 315,
      "y": 402
    },
    {
      "t": 1204,
      "e": 1204,
      "ty": 6,
      "x": 319,
      "y": 389,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1254,
      "e": 1254,
      "ty": 41,
      "x": 38564,
      "y": 38752,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 324,
      "y": 341
    },
    {
      "t": 1403,
      "e": 1403,
      "ty": 2,
      "x": 323,
      "y": 334
    },
    {
      "t": 1687,
      "e": 1687,
      "ty": 2,
      "x": 322,
      "y": 334
    },
    {
      "t": 1687,
      "e": 1687,
      "ty": 41,
      "x": 38434,
      "y": 8292,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2703,
      "e": 2703,
      "ty": 2,
      "x": 325,
      "y": 334
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 52794,
      "y": 43367,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2754,
      "e": 2754,
      "ty": 7,
      "x": 509,
      "y": 407,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 655,
      "y": 501
    },
    {
      "t": 2905,
      "e": 2905,
      "ty": 2,
      "x": 710,
      "y": 564
    },
    {
      "t": 3006,
      "e": 3006,
      "ty": 41,
      "x": 12712,
      "y": 44943,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 823,
      "y": 667
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 22578,
      "y": 55758,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 871,
      "y": 751
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 888,
      "y": 766
    },
    {
      "t": 3503,
      "e": 3503,
      "ty": 2,
      "x": 900,
      "y": 759
    },
    {
      "t": 3504,
      "e": 3504,
      "ty": 41,
      "x": 26101,
      "y": 58909,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 915,
      "y": 759
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 920,
      "y": 771
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 60683,
      "y": 18687,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 910,
      "y": 772
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 899,
      "y": 770
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 895,
      "y": 766
    },
    {
      "t": 4003,
      "e": 4003,
      "ty": 41,
      "x": 25749,
      "y": 59411,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 894,
      "y": 765
    },
    {
      "t": 4205,
      "e": 4205,
      "ty": 2,
      "x": 894,
      "y": 764
    },
    {
      "t": 4254,
      "e": 4254,
      "ty": 41,
      "x": 25678,
      "y": 59267,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6402,
      "e": 6402,
      "ty": 2,
      "x": 895,
      "y": 769
    },
    {
      "t": 6503,
      "e": 6503,
      "ty": 2,
      "x": 895,
      "y": 771
    },
    {
      "t": 6504,
      "e": 6504,
      "ty": 41,
      "x": 29902,
      "y": 14591,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 874,
      "y": 763
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 326,
      "y": 421
    },
    {
      "t": 7222,
      "e": 7222,
      "ty": 6,
      "x": 285,
      "y": 389,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 32559,
      "y": 52598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7303,
      "e": 7303,
      "ty": 2,
      "x": 272,
      "y": 380
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 272,
      "y": 376
    },
    {
      "t": 7448,
      "e": 7448,
      "ty": 3,
      "x": 267,
      "y": 369,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7449,
      "e": 7449,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 267,
      "y": 369
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 31253,
      "y": 40598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7512,
      "e": 7512,
      "ty": 4,
      "x": 31253,
      "y": 40598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7512,
      "e": 7512,
      "ty": 5,
      "x": 267,
      "y": 369,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9706,
      "e": 9706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 9709,
      "e": 9709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9749,
      "e": 9749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "f"
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10194,
      "e": 10194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10293,
      "e": 10293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10343,
      "e": 10343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10569,
      "e": 10569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 10579,
      "e": 10579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10579,
      "e": 10579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10617,
      "e": 10617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 10721,
      "e": 10721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 10739,
      "e": 10739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 10740,
      "e": 10740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10862,
      "e": 10862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 10952,
      "e": 10952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10953,
      "e": 10953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11032,
      "e": 11032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11032,
      "e": 11032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11114,
      "e": 11114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First"
    },
    {
      "t": 11130,
      "e": 11130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11130,
      "e": 11130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11171,
      "e": 11171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11219,
      "e": 11219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11224,
      "e": 11224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11225,
      "e": 11225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11260,
      "e": 11260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11261,
      "e": 11261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11307,
      "e": 11307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 11359,
      "e": 11359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11360,
      "e": 11360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11387,
      "e": 11387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 11438,
      "e": 11438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11438,
      "e": 11438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11475,
      "e": 11475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 11555,
      "e": 11555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11794,
      "e": 11794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11794,
      "e": 11794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11882,
      "e": 11882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11883,
      "e": 11883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11896,
      "e": 11896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 12004,
      "e": 12004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indica"
    },
    {
      "t": 12062,
      "e": 12062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12063,
      "e": 12063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12088,
      "e": 12088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12194,
      "e": 12194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12195,
      "e": 12195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12276,
      "e": 12276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12294,
      "e": 12294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12294,
      "e": 12294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12327,
      "e": 12327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12432,
      "e": 12432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12536,
      "e": 12536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12538,
      "e": 12538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12629,
      "e": 12629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12630,
      "e": 12630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12655,
      "e": 12655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 12697,
      "e": 12697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12697,
      "e": 12697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12715,
      "e": 12715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12789,
      "e": 12789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12789,
      "e": 12789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12831,
      "e": 12831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12891,
      "e": 12891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13113,
      "e": 13113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 13114,
      "e": 13114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13261,
      "e": 13261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 13261,
      "e": 13261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13271,
      "e": 13271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 13406,
      "e": 13406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12"
    },
    {
      "t": 13407,
      "e": 13407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13525,
      "e": 13525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 13525,
      "e": 13525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13624,
      "e": 13624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 13637,
      "e": 13637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 13637,
      "e": 13637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13755,
      "e": 13755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 13962,
      "e": 13962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13963,
      "e": 13963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14015,
      "e": 14015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16774,
      "e": 16774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16775,
      "e": 16775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16870,
      "e": 16870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16870,
      "e": 16870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16888,
      "e": 16888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sl"
    },
    {
      "t": 16940,
      "e": 16940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17040,
      "e": 17040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17040,
      "e": 17040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17111,
      "e": 17111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17113,
      "e": 17113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17175,
      "e": 17175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 17212,
      "e": 17212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17212,
      "e": 17212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17253,
      "e": 17253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17330,
      "e": 17330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17330,
      "e": 17330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17335,
      "e": 17335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17380,
      "e": 17380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17380,
      "e": 17380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17432,
      "e": 17432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17433,
      "e": 17433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17449,
      "e": 17449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 17498,
      "e": 17498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17504,
      "e": 17504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17505,
      "e": 17505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17561,
      "e": 17561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17613,
      "e": 17613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17619,
      "e": 17619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17621,
      "e": 17621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17675,
      "e": 17675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17676,
      "e": 17676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17722,
      "e": 17722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17760,
      "e": 17760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17858,
      "e": 17858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18200,
      "e": 18200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18200,
      "e": 18200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18339,
      "e": 18339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18446,
      "e": 18446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18447,
      "e": 18447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18524,
      "e": 18524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18764,
      "e": 18764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18764,
      "e": 18764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18913,
      "e": 18913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19056,
      "e": 19056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19057,
      "e": 19057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19132,
      "e": 19132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19132,
      "e": 19132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19170,
      "e": 19170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 19237,
      "e": 19237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19283,
      "e": 19283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19283,
      "e": 19283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19407,
      "e": 19283,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis"
    },
    {
      "t": 19481,
      "e": 19357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19510,
      "e": 19386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19511,
      "e": 19387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19675,
      "e": 19551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19675,
      "e": 19551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19725,
      "e": 19601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 19787,
      "e": 19663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19787,
      "e": 19663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19817,
      "e": 19693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19858,
      "e": 19734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19859,
      "e": 19735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19893,
      "e": 19769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19977,
      "e": 19853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19978,
      "e": 19854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19979,
      "e": 19855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20078,
      "e": 19954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20078,
      "e": 19954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20082,
      "e": 19958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 20159,
      "e": 20035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20273,
      "e": 20149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20273,
      "e": 20149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20320,
      "e": 20196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20321,
      "e": 20197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20370,
      "e": 20246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 20467,
      "e": 20343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20530,
      "e": 20406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 20530,
      "e": 20406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20639,
      "e": 20515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 20793,
      "e": 20669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20794,
      "e": 20670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20893,
      "e": 20769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20893,
      "e": 20769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20923,
      "e": 20799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 21012,
      "e": 20888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21012,
      "e": 20888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21017,
      "e": 20893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21104,
      "e": 20980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21104,
      "e": 20980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21106,
      "e": 20982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21171,
      "e": 21047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21172,
      "e": 21048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21197,
      "e": 21073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21244,
      "e": 21120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21244,
      "e": 21120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21299,
      "e": 21175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21332,
      "e": 21208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21333,
      "e": 21209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21370,
      "e": 21246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 21403,
      "e": 21279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21405,
      "e": 21281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21425,
      "e": 21301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21486,
      "e": 21362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21516,
      "e": 21392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 21517,
      "e": 21393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21600,
      "e": 21476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 21611,
      "e": 21487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21611,
      "e": 21487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21700,
      "e": 21576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21701,
      "e": 21577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21709,
      "e": 21585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 21799,
      "e": 21675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22100,
      "e": 21976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 22100,
      "e": 21976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22177,
      "e": 22053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 22401,
      "e": 22277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 22401,
      "e": 22277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22468,
      "e": 22344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22469,
      "e": 22345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22506,
      "e": 22382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mo"
    },
    {
      "t": 22553,
      "e": 22429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22554,
      "e": 22430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22617,
      "e": 22493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22618,
      "e": 22494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22620,
      "e": 22496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 22670,
      "e": 22546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22721,
      "e": 22597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22721,
      "e": 22597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22744,
      "e": 22620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22823,
      "e": 22699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22885,
      "e": 22761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22885,
      "e": 22761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22973,
      "e": 22849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22973,
      "e": 22849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22994,
      "e": 22870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 23046,
      "e": 22922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23121,
      "e": 22997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23121,
      "e": 22997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23269,
      "e": 23145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23339,
      "e": 23215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23341,
      "e": 23217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23413,
      "e": 23289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23621,
      "e": 23497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23622,
      "e": 23498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23714,
      "e": 23590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23715,
      "e": 23591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23755,
      "e": 23631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||no"
    },
    {
      "t": 23792,
      "e": 23668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23853,
      "e": 23729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23854,
      "e": 23730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23931,
      "e": 23807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24201,
      "e": 24077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24267,
      "e": 24143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagno"
    },
    {
      "t": 24341,
      "e": 24217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24386,
      "e": 24262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagn"
    },
    {
      "t": 24583,
      "e": 24459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24651,
      "e": 24461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diag"
    },
    {
      "t": 24720,
      "e": 24530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24810,
      "e": 24620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most dia"
    },
    {
      "t": 25280,
      "e": 25090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25281,
      "e": 25091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25352,
      "e": 25162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25353,
      "e": 25163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25387,
      "e": 25197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 25437,
      "e": 25247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25437,
      "e": 25247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25468,
      "e": 25278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25522,
      "e": 25332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25545,
      "e": 25355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25545,
      "e": 25355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25624,
      "e": 25434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25625,
      "e": 25435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25704,
      "e": 25514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 25718,
      "e": 25528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25775,
      "e": 25585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25775,
      "e": 25585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25812,
      "e": 25622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26004,
      "e": 25814,
      "ty": 2,
      "x": 267,
      "y": 377
    },
    {
      "t": 26004,
      "e": 25814,
      "ty": 41,
      "x": 31253,
      "y": 47983,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26102,
      "e": 25912,
      "ty": 2,
      "x": 316,
      "y": 393
    },
    {
      "t": 26205,
      "e": 26015,
      "ty": 2,
      "x": 305,
      "y": 373
    },
    {
      "t": 26252,
      "e": 26062,
      "ty": 41,
      "x": 37520,
      "y": 22138,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26302,
      "e": 26112,
      "ty": 2,
      "x": 343,
      "y": 347
    },
    {
      "t": 26402,
      "e": 26212,
      "ty": 2,
      "x": 357,
      "y": 350
    },
    {
      "t": 26501,
      "e": 26311,
      "ty": 41,
      "x": 43003,
      "y": 23061,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27228,
      "e": 27038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27229,
      "e": 27039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27280,
      "e": 27090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27281,
      "e": 27091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27369,
      "e": 27179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27370,
      "e": 27180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27382,
      "e": 27192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||con"
    },
    {
      "t": 27426,
      "e": 27236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27434,
      "e": 27244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27512,
      "e": 27322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27512,
      "e": 27322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27557,
      "e": 27367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27557,
      "e": 27367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27618,
      "e": 27428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 27662,
      "e": 27472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27723,
      "e": 27533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27723,
      "e": 27533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27816,
      "e": 27626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 27973,
      "e": 27783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27973,
      "e": 27783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28062,
      "e": 27872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28062,
      "e": 27872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28110,
      "e": 27920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 28143,
      "e": 27953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28220,
      "e": 28030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28220,
      "e": 28030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28299,
      "e": 28109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28300,
      "e": 28110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28302,
      "e": 28112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 28372,
      "e": 28182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28372,
      "e": 28182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28426,
      "e": 28236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28468,
      "e": 28278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28468,
      "e": 28278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28470,
      "e": 28280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28551,
      "e": 28361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28551,
      "e": 28361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28554,
      "e": 28364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28604,
      "e": 28414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28604,
      "e": 28414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28674,
      "e": 28484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28687,
      "e": 28497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28688,
      "e": 28498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28706,
      "e": 28516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28747,
      "e": 28557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28748,
      "e": 28558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28785,
      "e": 28595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28855,
      "e": 28665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28963,
      "e": 28773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28964,
      "e": 28774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29068,
      "e": 28878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29068,
      "e": 28878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29134,
      "e": 28944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 29214,
      "e": 29024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29305,
      "e": 29115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29306,
      "e": 29116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29423,
      "e": 29233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29836,
      "e": 29646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29836,
      "e": 29646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29906,
      "e": 29716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 30002,
      "e": 29812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30002,
      "e": 29812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30004,
      "e": 29814,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30076,
      "e": 29886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30077,
      "e": 29887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30115,
      "e": 29925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 30160,
      "e": 29970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30161,
      "e": 29971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30207,
      "e": 30017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30282,
      "e": 30092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30507,
      "e": 30317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 30507,
      "e": 30317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30555,
      "e": 30365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30557,
      "e": 30367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30597,
      "e": 30407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 30673,
      "e": 30483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31285,
      "e": 31095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31285,
      "e": 31095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31404,
      "e": 31214,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up "
    },
    {
      "t": 31417,
      "e": 31227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31471,
      "e": 31281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 31472,
      "e": 31282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31538,
      "e": 31348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 31647,
      "e": 31457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31647,
      "e": 31457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31726,
      "e": 31536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31743,
      "e": 31553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31743,
      "e": 31553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31815,
      "e": 31625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31816,
      "e": 31626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31845,
      "e": 31655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 31903,
      "e": 31713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31903,
      "e": 31713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31950,
      "e": 31760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32026,
      "e": 31836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32087,
      "e": 31897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32088,
      "e": 31898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32145,
      "e": 31955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32201,
      "e": 32011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 32201,
      "e": 32011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32271,
      "e": 32081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 32284,
      "e": 32094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32285,
      "e": 32095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32373,
      "e": 32183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32373,
      "e": 32183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32415,
      "e": 32225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 32455,
      "e": 32265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32548,
      "e": 32358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32549,
      "e": 32359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32677,
      "e": 32487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32678,
      "e": 32488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32715,
      "e": 32525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 32803,
      "e": 32613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32952,
      "e": 32762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33002,
      "e": 32812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until youf"
    },
    {
      "t": 33083,
      "e": 32893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33144,
      "e": 32954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you"
    },
    {
      "t": 33155,
      "e": 32965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33155,
      "e": 32965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33227,
      "e": 33037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 33228,
      "e": 33038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33268,
      "e": 33078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 33273,
      "e": 33083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33273,
      "e": 33083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33320,
      "e": 33130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33346,
      "e": 33156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33346,
      "e": 33156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33397,
      "e": 33207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33450,
      "e": 33260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33451,
      "e": 33261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33453,
      "e": 33263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33558,
      "e": 33368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33559,
      "e": 33369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33600,
      "e": 33410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33660,
      "e": 33470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34170,
      "e": 33980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34171,
      "e": 33981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34206,
      "e": 34016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34207,
      "e": 34017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34263,
      "e": 34073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||do"
    },
    {
      "t": 34296,
      "e": 34106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34404,
      "e": 34106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find do"
    },
    {
      "t": 34472,
      "e": 34174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34473,
      "e": 34175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34545,
      "e": 34247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34545,
      "e": 34247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34648,
      "e": 34350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34650,
      "e": 34352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34661,
      "e": 34363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts "
    },
    {
      "t": 34727,
      "e": 34429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34808,
      "e": 34510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34810,
      "e": 34512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34838,
      "e": 34540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34900,
      "e": 34602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34901,
      "e": 34603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34934,
      "e": 34636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34997,
      "e": 34699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35002,
      "e": 34704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35003,
      "e": 34705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35108,
      "e": 34810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35109,
      "e": 34811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35150,
      "e": 34852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 35188,
      "e": 34890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35188,
      "e": 34890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35249,
      "e": 34951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35290,
      "e": 34992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35291,
      "e": 34993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35321,
      "e": 35023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35371,
      "e": 35073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35371,
      "e": 35073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35417,
      "e": 35119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 35451,
      "e": 35153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35452,
      "e": 35154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35482,
      "e": 35184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35562,
      "e": 35264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35643,
      "e": 35345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35644,
      "e": 35346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35836,
      "e": 35538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36028,
      "e": 35730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36471,
      "e": 36173,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find dots that int"
    },
    {
      "t": 36532,
      "e": 36234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36615,
      "e": 36317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36702,
      "e": 36404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36784,
      "e": 36486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36870,
      "e": 36572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36955,
      "e": 36657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37042,
      "e": 36744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37130,
      "e": 36832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37217,
      "e": 36919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37303,
      "e": 37005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37392,
      "e": 37094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37479,
      "e": 37181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37509,
      "e": 37211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find d"
    },
    {
      "t": 37943,
      "e": 37645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38013,
      "e": 37715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find "
    },
    {
      "t": 38251,
      "e": 37953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38251,
      "e": 37953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38333,
      "e": 38035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 38607,
      "e": 38309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38608,
      "e": 38310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38735,
      "e": 38437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38735,
      "e": 38437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38782,
      "e": 38484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 38910,
      "e": 38612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39089,
      "e": 38791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39089,
      "e": 38791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39187,
      "e": 38889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39222,
      "e": 38924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39223,
      "e": 38925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39370,
      "e": 38925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39372,
      "e": 38927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39442,
      "e": 38997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39442,
      "e": 38997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39451,
      "e": 39006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts "
    },
    {
      "t": 39531,
      "e": 39086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39567,
      "e": 39122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39567,
      "e": 39122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39568,
      "e": 39123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39656,
      "e": 39211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39675,
      "e": 39230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39677,
      "e": 39232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39751,
      "e": 39306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39751,
      "e": 39306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39796,
      "e": 39351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 39855,
      "e": 39410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39855,
      "e": 39410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39888,
      "e": 39443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39932,
      "e": 39487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39932,
      "e": 39487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39976,
      "e": 39531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40018,
      "e": 39573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40019,
      "e": 39574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40053,
      "e": 39608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40112,
      "e": 39667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40113,
      "e": 39668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40116,
      "e": 39671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40195,
      "e": 39750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40196,
      "e": 39751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40253,
      "e": 39808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40299,
      "e": 39854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40299,
      "e": 39854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40332,
      "e": 39887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40372,
      "e": 39927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40429,
      "e": 39984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40429,
      "e": 39984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40552,
      "e": 40107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40553,
      "e": 40108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40573,
      "e": 40128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 40710,
      "e": 40265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40808,
      "e": 40363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40808,
      "e": 40363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40922,
      "e": 40477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 41052,
      "e": 40607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41053,
      "e": 40608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41061,
      "e": 40616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41061,
      "e": 40616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41084,
      "e": 40639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41085,
      "e": 40640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41145,
      "e": 40700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41147,
      "e": 40702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41166,
      "e": 40721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tion"
    },
    {
      "t": 41166,
      "e": 40721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41207,
      "e": 40762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41259,
      "e": 40814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41351,
      "e": 40906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 41353,
      "e": 40908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41437,
      "e": 40992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 41574,
      "e": 41129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41575,
      "e": 41130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41629,
      "e": 41184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41802,
      "e": 41357,
      "ty": 2,
      "x": 370,
      "y": 367
    },
    {
      "t": 41903,
      "e": 41458,
      "ty": 2,
      "x": 382,
      "y": 382
    },
    {
      "t": 42002,
      "e": 41557,
      "ty": 2,
      "x": 256,
      "y": 329
    },
    {
      "t": 42002,
      "e": 41557,
      "ty": 41,
      "x": 29817,
      "y": 3677,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42009,
      "e": 41564,
      "ty": 7,
      "x": 240,
      "y": 323,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42093,
      "e": 41648,
      "ty": 6,
      "x": 211,
      "y": 325,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42103,
      "e": 41658,
      "ty": 2,
      "x": 211,
      "y": 325
    },
    {
      "t": 42203,
      "e": 41758,
      "ty": 2,
      "x": 222,
      "y": 343
    },
    {
      "t": 42252,
      "e": 41807,
      "ty": 41,
      "x": 27206,
      "y": 30445,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42302,
      "e": 41857,
      "ty": 2,
      "x": 239,
      "y": 360
    },
    {
      "t": 42404,
      "e": 41959,
      "ty": 2,
      "x": 239,
      "y": 358
    },
    {
      "t": 42447,
      "e": 42002,
      "ty": 3,
      "x": 239,
      "y": 358,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42504,
      "e": 42059,
      "ty": 41,
      "x": 27598,
      "y": 30445,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43449,
      "e": 43004,
      "ty": 4,
      "x": 25770,
      "y": 18446,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43449,
      "e": 43004,
      "ty": 5,
      "x": 225,
      "y": 345,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43604,
      "e": 43159,
      "ty": 2,
      "x": 227,
      "y": 346
    },
    {
      "t": 43702,
      "e": 43257,
      "ty": 2,
      "x": 228,
      "y": 344
    },
    {
      "t": 43738,
      "e": 43293,
      "ty": 3,
      "x": 226,
      "y": 342,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43753,
      "e": 43308,
      "ty": 41,
      "x": 25901,
      "y": 15677,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43804,
      "e": 43359,
      "ty": 2,
      "x": 226,
      "y": 342
    },
    {
      "t": 43880,
      "e": 43435,
      "ty": 4,
      "x": 25901,
      "y": 15677,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43880,
      "e": 43435,
      "ty": 5,
      "x": 226,
      "y": 342,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44194,
      "e": 43749,
      "ty": 3,
      "x": 226,
      "y": 342,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44928,
      "e": 44483,
      "ty": 4,
      "x": 25901,
      "y": 15677,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46096,
      "e": 45651,
      "ty": 7,
      "x": 249,
      "y": 349,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46096,
      "e": 45651,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 46097,
      "e": 45652,
      "ty": 6,
      "x": 267,
      "y": 355,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46143,
      "e": 45698,
      "ty": 7,
      "x": 444,
      "y": 419,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46203,
      "e": 45758,
      "ty": 2,
      "x": 966,
      "y": 750
    },
    {
      "t": 46204,
      "e": 45759,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find points of intersection. "
    },
    {
      "t": 46254,
      "e": 45809,
      "ty": 41,
      "x": 41183,
      "y": 1560,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 46302,
      "e": 45857,
      "ty": 2,
      "x": 1075,
      "y": 825
    },
    {
      "t": 46501,
      "e": 46056,
      "ty": 2,
      "x": 983,
      "y": 765
    },
    {
      "t": 46503,
      "e": 46058,
      "ty": 41,
      "x": 31950,
      "y": 59339,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 46603,
      "e": 46158,
      "ty": 2,
      "x": 939,
      "y": 739
    },
    {
      "t": 46703,
      "e": 46258,
      "ty": 2,
      "x": 922,
      "y": 771
    },
    {
      "t": 46753,
      "e": 46308,
      "ty": 41,
      "x": 27088,
      "y": 59482,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 46803,
      "e": 46358,
      "ty": 2,
      "x": 903,
      "y": 752
    },
    {
      "t": 46903,
      "e": 46458,
      "ty": 2,
      "x": 898,
      "y": 746
    },
    {
      "t": 47004,
      "e": 46559,
      "ty": 2,
      "x": 911,
      "y": 736
    },
    {
      "t": 47004,
      "e": 46559,
      "ty": 41,
      "x": 26876,
      "y": 57262,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47103,
      "e": 46658,
      "ty": 2,
      "x": 929,
      "y": 702
    },
    {
      "t": 47205,
      "e": 46760,
      "ty": 2,
      "x": 931,
      "y": 699
    },
    {
      "t": 47254,
      "e": 46809,
      "ty": 41,
      "x": 51369,
      "y": 55522,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 47306,
      "e": 46861,
      "ty": 2,
      "x": 933,
      "y": 699
    },
    {
      "t": 47603,
      "e": 47158,
      "ty": 2,
      "x": 837,
      "y": 711
    },
    {
      "t": 47702,
      "e": 47257,
      "ty": 2,
      "x": 421,
      "y": 582
    },
    {
      "t": 47754,
      "e": 47258,
      "ty": 41,
      "x": 45875,
      "y": 44950,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47803,
      "e": 47307,
      "ty": 2,
      "x": 353,
      "y": 505
    },
    {
      "t": 47863,
      "e": 47367,
      "ty": 6,
      "x": 330,
      "y": 480,
      "ta": "#strategyButton"
    },
    {
      "t": 47902,
      "e": 47406,
      "ty": 2,
      "x": 323,
      "y": 477
    },
    {
      "t": 48005,
      "e": 47509,
      "ty": 2,
      "x": 321,
      "y": 477
    },
    {
      "t": 48005,
      "e": 47509,
      "ty": 41,
      "x": 50465,
      "y": 57794,
      "ta": "#strategyButton"
    },
    {
      "t": 48102,
      "e": 47606,
      "ty": 2,
      "x": 320,
      "y": 472
    },
    {
      "t": 48117,
      "e": 47621,
      "ty": 3,
      "x": 320,
      "y": 472,
      "ta": "#strategyButton"
    },
    {
      "t": 48118,
      "e": 47622,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find points of intersection. "
    },
    {
      "t": 48119,
      "e": 47623,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48119,
      "e": 47623,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48171,
      "e": 47675,
      "ty": 4,
      "x": 49919,
      "y": 48157,
      "ta": "#strategyButton"
    },
    {
      "t": 48206,
      "e": 47710,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48213,
      "e": 47717,
      "ty": 5,
      "x": 320,
      "y": 472,
      "ta": "#strategyButton"
    },
    {
      "t": 48241,
      "e": 47745,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 48243,
      "e": 47747,
      "ty": 5,
      "x": 320,
      "y": 472,
      "ta": "#strategyButton"
    },
    {
      "t": 48252,
      "e": 47756,
      "ty": 1,
      "x": 8,
      "y": 16
    },
    {
      "t": 48253,
      "e": 47757,
      "ty": 41,
      "x": 15112,
      "y": 38984,
      "ta": "html > body"
    },
    {
      "t": 49220,
      "e": 48724,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 49908,
      "e": 49412,
      "ty": 2,
      "x": 593,
      "y": 432
    },
    {
      "t": 50003,
      "e": 49507,
      "ty": 2,
      "x": 651,
      "y": 426
    },
    {
      "t": 50003,
      "e": 49507,
      "ty": 41,
      "x": 24388,
      "y": 62024,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 50103,
      "e": 49607,
      "ty": 2,
      "x": 642,
      "y": 397
    },
    {
      "t": 50177,
      "e": 49681,
      "ty": 6,
      "x": 621,
      "y": 368,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50202,
      "e": 49706,
      "ty": 2,
      "x": 617,
      "y": 364
    },
    {
      "t": 50253,
      "e": 49757,
      "ty": 41,
      "x": 14132,
      "y": 5173,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50303,
      "e": 49807,
      "ty": 2,
      "x": 608,
      "y": 356
    },
    {
      "t": 50350,
      "e": 49854,
      "ty": 3,
      "x": 607,
      "y": 356,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50352,
      "e": 49856,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50403,
      "e": 49907,
      "ty": 4,
      "x": 13382,
      "y": 5173,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50403,
      "e": 49907,
      "ty": 5,
      "x": 607,
      "y": 356,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50403,
      "e": 49907,
      "ty": 2,
      "x": 607,
      "y": 356
    },
    {
      "t": 50502,
      "e": 50006,
      "ty": 41,
      "x": 13382,
      "y": 5173,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50978,
      "e": 50482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 50978,
      "e": 50482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51067,
      "e": 50571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 51067,
      "e": 50571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51150,
      "e": 50654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 51203,
      "e": 50707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 51359,
      "e": 50863,
      "ty": 7,
      "x": 610,
      "y": 378,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51402,
      "e": 50906,
      "ty": 2,
      "x": 613,
      "y": 402
    },
    {
      "t": 51478,
      "e": 50982,
      "ty": 6,
      "x": 619,
      "y": 451,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51502,
      "e": 51006,
      "ty": 41,
      "x": 16383,
      "y": 22419,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51502,
      "e": 51006,
      "ty": 2,
      "x": 619,
      "y": 453
    },
    {
      "t": 51603,
      "e": 51107,
      "ty": 2,
      "x": 616,
      "y": 459
    },
    {
      "t": 51702,
      "e": 51206,
      "ty": 2,
      "x": 608,
      "y": 463
    },
    {
      "t": 51752,
      "e": 51256,
      "ty": 41,
      "x": 13382,
      "y": 56911,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51782,
      "e": 51286,
      "ty": 3,
      "x": 607,
      "y": 464,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51782,
      "e": 51286,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 51783,
      "e": 51287,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51783,
      "e": 51287,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51805,
      "e": 51309,
      "ty": 2,
      "x": 607,
      "y": 464
    },
    {
      "t": 51854,
      "e": 51358,
      "ty": 4,
      "x": 13382,
      "y": 60361,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51854,
      "e": 51358,
      "ty": 5,
      "x": 607,
      "y": 464,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52004,
      "e": 51508,
      "ty": 41,
      "x": 13382,
      "y": 60361,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52358,
      "e": 51862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 52362,
      "e": 51866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 52362,
      "e": 51866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52392,
      "e": 51896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 52528,
      "e": 52032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 52528,
      "e": 52032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52677,
      "e": 52181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 52678,
      "e": 52182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52698,
      "e": 52202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 52805,
      "e": 52309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 52829,
      "e": 52333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 52876,
      "e": 52380,
      "ty": 7,
      "x": 627,
      "y": 471,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52894,
      "e": 52398,
      "ty": 6,
      "x": 637,
      "y": 476,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52902,
      "e": 52406,
      "ty": 2,
      "x": 637,
      "y": 476
    },
    {
      "t": 53003,
      "e": 52507,
      "ty": 2,
      "x": 688,
      "y": 491
    },
    {
      "t": 53003,
      "e": 52507,
      "ty": 41,
      "x": 34571,
      "y": 34753,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53090,
      "e": 52594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 53103,
      "e": 52607,
      "ty": 2,
      "x": 694,
      "y": 491
    },
    {
      "t": 53203,
      "e": 52707,
      "ty": 2,
      "x": 694,
      "y": 490
    },
    {
      "t": 53253,
      "e": 52757,
      "ty": 41,
      "x": 37148,
      "y": 30781,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53303,
      "e": 52807,
      "ty": 2,
      "x": 691,
      "y": 488
    },
    {
      "t": 53344,
      "e": 52848,
      "ty": 3,
      "x": 689,
      "y": 488,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53345,
      "e": 52849,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 53347,
      "e": 52851,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53347,
      "e": 52851,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53407,
      "e": 52911,
      "ty": 2,
      "x": 689,
      "y": 488
    },
    {
      "t": 53424,
      "e": 52928,
      "ty": 4,
      "x": 35086,
      "y": 28795,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53427,
      "e": 52931,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53428,
      "e": 52932,
      "ty": 5,
      "x": 689,
      "y": 488,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53430,
      "e": 52934,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 53503,
      "e": 53007,
      "ty": 41,
      "x": 32985,
      "y": 40329,
      "ta": "html > body"
    },
    {
      "t": 54470,
      "e": 53974,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 54516,
      "e": 54020,
      "ty": 1,
      "x": 8,
      "y": 46
    },
    {
      "t": 55603,
      "e": 55107,
      "ty": 1,
      "x": 8,
      "y": 12
    },
    {
      "t": 55703,
      "e": 55207,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 56103,
      "e": 55607,
      "ty": 2,
      "x": 648,
      "y": 347
    },
    {
      "t": 56204,
      "e": 55708,
      "ty": 2,
      "x": 564,
      "y": 52
    },
    {
      "t": 56253,
      "e": 55757,
      "ty": 41,
      "x": 14997,
      "y": 54066,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56304,
      "e": 55808,
      "ty": 2,
      "x": 564,
      "y": 44
    },
    {
      "t": 56403,
      "e": 55907,
      "ty": 2,
      "x": 564,
      "y": 30
    },
    {
      "t": 56502,
      "e": 56006,
      "ty": 2,
      "x": 564,
      "y": 28
    },
    {
      "t": 56502,
      "e": 56006,
      "ty": 41,
      "x": 14997,
      "y": 1638,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56602,
      "e": 56106,
      "ty": 2,
      "x": 562,
      "y": 40
    },
    {
      "t": 56612,
      "e": 56107,
      "ty": 6,
      "x": 561,
      "y": 41,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56702,
      "e": 56197,
      "ty": 2,
      "x": 559,
      "y": 41
    },
    {
      "t": 56724,
      "e": 56219,
      "ty": 3,
      "x": 559,
      "y": 40,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56725,
      "e": 56220,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56754,
      "e": 56249,
      "ty": 41,
      "x": 52905,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56783,
      "e": 56278,
      "ty": 4,
      "x": 52905,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56784,
      "e": 56279,
      "ty": 5,
      "x": 559,
      "y": 40,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56786,
      "e": 56281,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 56803,
      "e": 56298,
      "ty": 2,
      "x": 559,
      "y": 40
    },
    {
      "t": 57845,
      "e": 57340,
      "ty": 7,
      "x": 559,
      "y": 52,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 57877,
      "e": 57372,
      "ty": 6,
      "x": 560,
      "y": 125,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57892,
      "e": 57387,
      "ty": 7,
      "x": 562,
      "y": 171,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57903,
      "e": 57398,
      "ty": 2,
      "x": 562,
      "y": 171
    },
    {
      "t": 58002,
      "e": 57497,
      "ty": 2,
      "x": 567,
      "y": 291
    },
    {
      "t": 58002,
      "e": 57497,
      "ty": 41,
      "x": 19321,
      "y": 11468,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 58103,
      "e": 57598,
      "ty": 2,
      "x": 567,
      "y": 302
    },
    {
      "t": 58203,
      "e": 57698,
      "ty": 2,
      "x": 571,
      "y": 264
    },
    {
      "t": 58252,
      "e": 57747,
      "ty": 41,
      "x": 18770,
      "y": 11468,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58303,
      "e": 57798,
      "ty": 2,
      "x": 567,
      "y": 228
    },
    {
      "t": 58403,
      "e": 57898,
      "ty": 2,
      "x": 564,
      "y": 232
    },
    {
      "t": 58502,
      "e": 57997,
      "ty": 2,
      "x": 558,
      "y": 259
    },
    {
      "t": 58503,
      "e": 57998,
      "ty": 41,
      "x": 12908,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 58510,
      "e": 58005,
      "ty": 6,
      "x": 558,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58544,
      "e": 58039,
      "ty": 7,
      "x": 558,
      "y": 280,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58576,
      "e": 58071,
      "ty": 6,
      "x": 558,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58602,
      "e": 58097,
      "ty": 2,
      "x": 558,
      "y": 294
    },
    {
      "t": 58693,
      "e": 58188,
      "ty": 7,
      "x": 561,
      "y": 307,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58703,
      "e": 58198,
      "ty": 2,
      "x": 561,
      "y": 307
    },
    {
      "t": 58754,
      "e": 58249,
      "ty": 41,
      "x": 3459,
      "y": 62024,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 58803,
      "e": 58298,
      "ty": 2,
      "x": 561,
      "y": 308
    },
    {
      "t": 58826,
      "e": 58321,
      "ty": 6,
      "x": 561,
      "y": 305,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58903,
      "e": 58398,
      "ty": 2,
      "x": 559,
      "y": 301
    },
    {
      "t": 58972,
      "e": 58467,
      "ty": 3,
      "x": 558,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58972,
      "e": 58467,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 58973,
      "e": 58468,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 59007,
      "e": 58502,
      "ty": 2,
      "x": 558,
      "y": 300
    },
    {
      "t": 59007,
      "e": 58502,
      "ty": 41,
      "x": 47444,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 59036,
      "e": 58531,
      "ty": 4,
      "x": 47444,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 59036,
      "e": 58531,
      "ty": 5,
      "x": 558,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 59036,
      "e": 58531,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 59504,
      "e": 58999,
      "ty": 1,
      "x": 8,
      "y": 26
    },
    {
      "t": 59602,
      "e": 59097,
      "ty": 1,
      "x": 8,
      "y": 57
    },
    {
      "t": 59630,
      "e": 59125,
      "ty": 7,
      "x": 558,
      "y": 357,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 59630,
      "e": 59125,
      "ty": 6,
      "x": 558,
      "y": 357,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 60043,
      "e": 59538,
      "ty": 7,
      "x": 558,
      "y": 364,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 60078,
      "e": 59573,
      "ty": 6,
      "x": 559,
      "y": 386,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 60093,
      "e": 59588,
      "ty": 7,
      "x": 560,
      "y": 413,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 60103,
      "e": 59598,
      "ty": 2,
      "x": 560,
      "y": 413
    },
    {
      "t": 60203,
      "e": 59698,
      "ty": 2,
      "x": 566,
      "y": 482
    },
    {
      "t": 60253,
      "e": 59748,
      "ty": 41,
      "x": 5760,
      "y": 14745,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60303,
      "e": 59798,
      "ty": 2,
      "x": 572,
      "y": 507
    },
    {
      "t": 60404,
      "e": 59899,
      "ty": 2,
      "x": 572,
      "y": 506
    },
    {
      "t": 60504,
      "e": 59999,
      "ty": 2,
      "x": 572,
      "y": 503
    },
    {
      "t": 60504,
      "e": 59999,
      "ty": 41,
      "x": 6525,
      "y": 37682,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60703,
      "e": 60198,
      "ty": 2,
      "x": 569,
      "y": 508
    },
    {
      "t": 60753,
      "e": 60248,
      "ty": 41,
      "x": 4995,
      "y": 57343,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60802,
      "e": 60297,
      "ty": 2,
      "x": 565,
      "y": 508
    },
    {
      "t": 60894,
      "e": 60389,
      "ty": 6,
      "x": 561,
      "y": 503,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60903,
      "e": 60398,
      "ty": 2,
      "x": 561,
      "y": 503
    },
    {
      "t": 61003,
      "e": 60498,
      "ty": 2,
      "x": 557,
      "y": 501
    },
    {
      "t": 61003,
      "e": 60498,
      "ty": 41,
      "x": 41983,
      "y": 22685,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61008,
      "e": 60503,
      "ty": 3,
      "x": 557,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61008,
      "e": 60503,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61008,
      "e": 60503,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61084,
      "e": 60579,
      "ty": 4,
      "x": 41983,
      "y": 22685,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61084,
      "e": 60579,
      "ty": 5,
      "x": 557,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61084,
      "e": 60579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 62744,
      "e": 62239,
      "ty": 7,
      "x": 557,
      "y": 513,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62755,
      "e": 62250,
      "ty": 41,
      "x": 2510,
      "y": 59683,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 62794,
      "e": 62289,
      "ty": 6,
      "x": 559,
      "y": 589,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62804,
      "e": 62299,
      "ty": 2,
      "x": 559,
      "y": 589
    },
    {
      "t": 62811,
      "e": 62306,
      "ty": 7,
      "x": 560,
      "y": 609,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62812,
      "e": 62307,
      "ty": 6,
      "x": 560,
      "y": 609,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62827,
      "e": 62322,
      "ty": 7,
      "x": 561,
      "y": 626,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62844,
      "e": 62339,
      "ty": 6,
      "x": 561,
      "y": 645,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62861,
      "e": 62356,
      "ty": 7,
      "x": 562,
      "y": 664,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62903,
      "e": 62398,
      "ty": 2,
      "x": 562,
      "y": 696
    },
    {
      "t": 63003,
      "e": 62498,
      "ty": 2,
      "x": 562,
      "y": 719
    },
    {
      "t": 63003,
      "e": 62498,
      "ty": 41,
      "x": 3697,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 63103,
      "e": 62598,
      "ty": 2,
      "x": 562,
      "y": 741
    },
    {
      "t": 63211,
      "e": 62608,
      "ty": 6,
      "x": 559,
      "y": 760,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63213,
      "e": 62610,
      "ty": 2,
      "x": 559,
      "y": 760
    },
    {
      "t": 63254,
      "e": 62651,
      "ty": 41,
      "x": 52905,
      "y": 27726,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63303,
      "e": 62700,
      "ty": 2,
      "x": 559,
      "y": 762
    },
    {
      "t": 63403,
      "e": 62800,
      "ty": 2,
      "x": 556,
      "y": 764
    },
    {
      "t": 63424,
      "e": 62821,
      "ty": 3,
      "x": 555,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63425,
      "e": 62822,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63425,
      "e": 62822,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63467,
      "e": 62864,
      "ty": 4,
      "x": 31060,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63467,
      "e": 62864,
      "ty": 5,
      "x": 555,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63468,
      "e": 62865,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 63504,
      "e": 62901,
      "ty": 2,
      "x": 555,
      "y": 764
    },
    {
      "t": 63505,
      "e": 62902,
      "ty": 41,
      "x": 31060,
      "y": 37808,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63777,
      "e": 63174,
      "ty": 7,
      "x": 558,
      "y": 772,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63803,
      "e": 63200,
      "ty": 2,
      "x": 564,
      "y": 780
    },
    {
      "t": 63862,
      "e": 63259,
      "ty": 6,
      "x": 584,
      "y": 803,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63903,
      "e": 63300,
      "ty": 2,
      "x": 590,
      "y": 806
    },
    {
      "t": 64004,
      "e": 63401,
      "ty": 2,
      "x": 607,
      "y": 814
    },
    {
      "t": 64004,
      "e": 63401,
      "ty": 41,
      "x": 27098,
      "y": 20852,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64104,
      "e": 63501,
      "ty": 2,
      "x": 611,
      "y": 817
    },
    {
      "t": 64204,
      "e": 63601,
      "ty": 2,
      "x": 614,
      "y": 821
    },
    {
      "t": 64255,
      "e": 63652,
      "ty": 41,
      "x": 30705,
      "y": 36739,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64303,
      "e": 63700,
      "ty": 2,
      "x": 614,
      "y": 822
    },
    {
      "t": 64311,
      "e": 63708,
      "ty": 3,
      "x": 614,
      "y": 822,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64312,
      "e": 63709,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64313,
      "e": 63710,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64400,
      "e": 63797,
      "ty": 4,
      "x": 30705,
      "y": 36739,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64400,
      "e": 63797,
      "ty": 5,
      "x": 614,
      "y": 822,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64421,
      "e": 63818,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64424,
      "e": 63821,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64424,
      "e": 63821,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 64428,
      "e": 63825,
      "ty": 1,
      "x": 8,
      "y": 16
    },
    {
      "t": 64903,
      "e": 64300,
      "ty": 2,
      "x": 614,
      "y": 671
    },
    {
      "t": 65003,
      "e": 64400,
      "ty": 2,
      "x": 638,
      "y": 206
    },
    {
      "t": 65003,
      "e": 64400,
      "ty": 41,
      "x": 30515,
      "y": 16635,
      "ta": "html > body"
    },
    {
      "t": 65107,
      "e": 64504,
      "ty": 2,
      "x": 640,
      "y": 189
    },
    {
      "t": 65258,
      "e": 64655,
      "ty": 41,
      "x": 30612,
      "y": 15207,
      "ta": "html > body"
    },
    {
      "t": 65759,
      "e": 65156,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 66403,
      "e": 65800,
      "ty": 2,
      "x": 640,
      "y": 194
    },
    {
      "t": 66504,
      "e": 65901,
      "ty": 2,
      "x": 693,
      "y": 672
    },
    {
      "t": 66504,
      "e": 65901,
      "ty": 41,
      "x": 33355,
      "y": 25745,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 66544,
      "e": 65941,
      "ty": 6,
      "x": 702,
      "y": 719,
      "ta": "#start"
    },
    {
      "t": 66603,
      "e": 66000,
      "ty": 2,
      "x": 703,
      "y": 726
    },
    {
      "t": 66705,
      "e": 66102,
      "ty": 2,
      "x": 697,
      "y": 727
    },
    {
      "t": 66753,
      "e": 66150,
      "ty": 41,
      "x": 34132,
      "y": 32767,
      "ta": "#start"
    },
    {
      "t": 66804,
      "e": 66201,
      "ty": 2,
      "x": 696,
      "y": 726
    },
    {
      "t": 66904,
      "e": 66301,
      "ty": 2,
      "x": 695,
      "y": 726
    },
    {
      "t": 67004,
      "e": 66401,
      "ty": 2,
      "x": 695,
      "y": 727
    },
    {
      "t": 67004,
      "e": 66401,
      "ty": 41,
      "x": 33040,
      "y": 32767,
      "ta": "#start"
    },
    {
      "t": 67012,
      "e": 66409,
      "ty": 3,
      "x": 695,
      "y": 727,
      "ta": "#start"
    },
    {
      "t": 67014,
      "e": 66411,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 67101,
      "e": 66498,
      "ty": 4,
      "x": 33040,
      "y": 32767,
      "ta": "#start"
    },
    {
      "t": 67101,
      "e": 66498,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 67102,
      "e": 66499,
      "ty": 5,
      "x": 695,
      "y": 727,
      "ta": "#start"
    },
    {
      "t": 67103,
      "e": 66500,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 67503,
      "e": 66900,
      "ty": 2,
      "x": 695,
      "y": 725
    },
    {
      "t": 67503,
      "e": 66900,
      "ty": 41,
      "x": 33276,
      "y": 60241,
      "ta": "html > body"
    },
    {
      "t": 67604,
      "e": 67001,
      "ty": 2,
      "x": 787,
      "y": 388
    },
    {
      "t": 67703,
      "e": 67100,
      "ty": 2,
      "x": 895,
      "y": 250
    },
    {
      "t": 67755,
      "e": 67152,
      "ty": 41,
      "x": 43011,
      "y": 20248,
      "ta": "html > body"
    },
    {
      "t": 67804,
      "e": 67201,
      "ty": 2,
      "x": 896,
      "y": 249
    },
    {
      "t": 68157,
      "e": 67554,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 69268,
      "e": 68665,
      "ty": 1,
      "x": 8,
      "y": 57
    },
    {
      "t": 69375,
      "e": 68772,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 816927, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 816933, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 150089, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 968360, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7603, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"STRATEGY-SATISFICING\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 976974, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 979468, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 1957774, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3429, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 1962210, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 12491, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 1976109, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-F -4\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:464,y:510,t:1526918865928};\\\", \\\"{x:467,y:508,t:1526918865944};\\\", \\\"{x:479,y:498,t:1526918865959};\\\", \\\"{x:494,y:485,t:1526918865975};\\\", \\\"{x:520,y:459,t:1526918865992};\\\", \\\"{x:542,y:424,t:1526918866009};\\\", \\\"{x:551,y:396,t:1526918866025};\\\", \\\"{x:554,y:369,t:1526918866042};\\\", \\\"{x:555,y:352,t:1526918866059};\\\", \\\"{x:554,y:340,t:1526918866075};\\\", \\\"{x:551,y:333,t:1526918866092};\\\", \\\"{x:546,y:329,t:1526918866109};\\\", \\\"{x:540,y:329,t:1526918866125};\\\", \\\"{x:633,y:410,t:1526918868142};\\\", \\\"{x:640,y:426,t:1526918868159};\\\", \\\"{x:653,y:460,t:1526918868176};\\\", \\\"{x:677,y:529,t:1526918868193};\\\", \\\"{x:722,y:663,t:1526918868210};\\\", \\\"{x:738,y:717,t:1526918868227};\\\", \\\"{x:744,y:736,t:1526918868244};\\\", \\\"{x:750,y:754,t:1526918868259};\\\", \\\"{x:753,y:767,t:1526918868277};\\\", \\\"{x:754,y:772,t:1526918868294};\\\", \\\"{x:754,y:773,t:1526918868310};\\\", \\\"{x:755,y:773,t:1526918868327};\\\", \\\"{x:755,y:774,t:1526918868343};\\\", \\\"{x:756,y:774,t:1526918868360};\\\", \\\"{x:760,y:771,t:1526918868376};\\\", \\\"{x:773,y:761,t:1526918868392};\\\", \\\"{x:793,y:745,t:1526918868410};\\\", \\\"{x:812,y:733,t:1526918868425};\\\", \\\"{x:833,y:722,t:1526918868443};\\\", \\\"{x:854,y:713,t:1526918868460};\\\", \\\"{x:873,y:707,t:1526918868477};\\\", \\\"{x:880,y:705,t:1526918868493};\\\", \\\"{x:888,y:702,t:1526918868510};\\\", \\\"{x:892,y:701,t:1526918868526};\\\", \\\"{x:893,y:701,t:1526918868543};\\\", \\\"{x:894,y:701,t:1526918868560};\\\", \\\"{x:894,y:702,t:1526918868577};\\\", \\\"{x:894,y:705,t:1526918868592};\\\", \\\"{x:893,y:710,t:1526918868609};\\\", \\\"{x:890,y:715,t:1526918868626};\\\", \\\"{x:889,y:717,t:1526918868643};\\\", \\\"{x:888,y:719,t:1526918868660};\\\", \\\"{x:888,y:720,t:1526918868677};\\\", \\\"{x:888,y:720,t:1526918868693};\\\", \\\"{x:888,y:721,t:1526918868710};\\\", \\\"{x:888,y:721,t:1526918868771};\\\", \\\"{x:888,y:720,t:1526918868778};\\\", \\\"{x:888,y:720,t:1526918868793};\\\", \\\"{x:888,y:718,t:1526918868809};\\\", \\\"{x:888,y:715,t:1526918868826};\\\", \\\"{x:894,y:706,t:1526918868842};\\\", \\\"{x:899,y:698,t:1526918868860};\\\", \\\"{x:905,y:690,t:1526918868877};\\\", \\\"{x:911,y:681,t:1526918868894};\\\", \\\"{x:915,y:673,t:1526918868909};\\\", \\\"{x:919,y:666,t:1526918868927};\\\", \\\"{x:921,y:663,t:1526918868944};\\\", \\\"{x:923,y:660,t:1526918868961};\\\", \\\"{x:923,y:658,t:1526918868977};\\\", \\\"{x:924,y:658,t:1526918868994};\\\", \\\"{x:924,y:657,t:1526918869009};\\\", \\\"{x:924,y:658,t:1526918869051};\\\", \\\"{x:923,y:658,t:1526918869059};\\\", \\\"{x:923,y:658,t:1526918869076};\\\", \\\"{x:923,y:658,t:1526918869094};\\\", \\\"{x:923,y:657,t:1526918869148};\\\", \\\"{x:923,y:656,t:1526918869160};\\\", \\\"{x:923,y:654,t:1526918869177};\\\", \\\"{x:923,y:653,t:1526918869193};\\\", \\\"{x:923,y:649,t:1526918869210};\\\", \\\"{x:923,y:645,t:1526918869226};\\\", \\\"{x:923,y:640,t:1526918869242};\\\", \\\"{x:923,y:633,t:1526918869259};\\\", \\\"{x:924,y:628,t:1526918869276};\\\", \\\"{x:925,y:624,t:1526918869294};\\\", \\\"{x:926,y:622,t:1526918869310};\\\", \\\"{x:926,y:621,t:1526918869327};\\\", \\\"{x:926,y:621,t:1526918869343};\\\", \\\"{x:926,y:622,t:1526918869363};\\\", \\\"{x:926,y:626,t:1526918869377};\\\", \\\"{x:921,y:641,t:1526918869394};\\\", \\\"{x:912,y:666,t:1526918869410};\\\", \\\"{x:905,y:686,t:1526918869427};\\\", \\\"{x:897,y:708,t:1526918869443};\\\", \\\"{x:890,y:729,t:1526918869459};\\\", \\\"{x:880,y:758,t:1526918869476};\\\", \\\"{x:875,y:770,t:1526918869494};\\\", \\\"{x:870,y:781,t:1526918869509};\\\", \\\"{x:867,y:787,t:1526918869526};\\\", \\\"{x:865,y:791,t:1526918869544};\\\", \\\"{x:864,y:793,t:1526918869559};\\\", \\\"{x:864,y:793,t:1526918869576};\\\", \\\"{x:863,y:794,t:1526918869594};\\\", \\\"{x:863,y:794,t:1526918869609};\\\", \\\"{x:863,y:793,t:1526918869668};\\\", \\\"{x:863,y:793,t:1526918869676};\\\", \\\"{x:863,y:792,t:1526918869694};\\\", \\\"{x:863,y:791,t:1526918870350};\\\", \\\"{x:863,y:789,t:1526918870360};\\\", \\\"{x:863,y:785,t:1526918870376};\\\", \\\"{x:864,y:780,t:1526918870394};\\\", \\\"{x:866,y:777,t:1526918870410};\\\", \\\"{x:866,y:774,t:1526918870427};\\\", \\\"{x:867,y:773,t:1526918870443};\\\", \\\"{x:867,y:773,t:1526918870459};\\\", \\\"{x:867,y:773,t:1526918870501};\\\", \\\"{x:867,y:774,t:1526918870510};\\\", \\\"{x:867,y:774,t:1526918870526};\\\", \\\"{x:867,y:776,t:1526918870543};\\\", \\\"{x:867,y:779,t:1526918870560};\\\", \\\"{x:867,y:783,t:1526918870577};\\\", \\\"{x:866,y:786,t:1526918870595};\\\", \\\"{x:864,y:788,t:1526918870610};\\\", \\\"{x:863,y:790,t:1526918870625};\\\", \\\"{x:862,y:790,t:1526918870644};\\\", \\\"{x:862,y:790,t:1526918870660};\\\", \\\"{x:862,y:790,t:1526918870676};\\\", \\\"{x:862,y:790,t:1526918870693};\\\", \\\"{x:861,y:789,t:1526918870710};\\\", \\\"{x:859,y:786,t:1526918870726};\\\", \\\"{x:858,y:782,t:1526918870743};\\\", \\\"{x:857,y:775,t:1526918870760};\\\", \\\"{x:857,y:767,t:1526918870777};\\\", \\\"{x:857,y:761,t:1526918870792};\\\", \\\"{x:857,y:755,t:1526918870811};\\\", \\\"{x:857,y:751,t:1526918870826};\\\", \\\"{x:858,y:749,t:1526918870843};\\\", \\\"{x:858,y:748,t:1526918870860};\\\", \\\"{x:858,y:748,t:1526918870876};\\\", \\\"{x:858,y:748,t:1526918870918};\\\", \\\"{x:858,y:746,t:1526918871122};\\\", \\\"{x:859,y:741,t:1526918871131};\\\", \\\"{x:863,y:732,t:1526918871143};\\\", \\\"{x:869,y:719,t:1526918871160};\\\", \\\"{x:874,y:708,t:1526918871177};\\\", \\\"{x:886,y:686,t:1526918871194};\\\", \\\"{x:895,y:667,t:1526918871209};\\\", \\\"{x:903,y:650,t:1526918871226};\\\", \\\"{x:908,y:638,t:1526918871243};\\\", \\\"{x:915,y:620,t:1526918871259};\\\", \\\"{x:919,y:612,t:1526918871276};\\\", \\\"{x:922,y:604,t:1526918871292};\\\", \\\"{x:925,y:596,t:1526918871310};\\\", \\\"{x:928,y:589,t:1526918871327};\\\", \\\"{x:931,y:582,t:1526918871344};\\\", \\\"{x:934,y:575,t:1526918871361};\\\", \\\"{x:937,y:570,t:1526918871377};\\\", \\\"{x:940,y:564,t:1526918871395};\\\", \\\"{x:943,y:557,t:1526918871410};\\\", \\\"{x:947,y:551,t:1526918871427};\\\", \\\"{x:949,y:547,t:1526918871443};\\\", \\\"{x:955,y:538,t:1526918871460};\\\", \\\"{x:959,y:532,t:1526918871476};\\\", \\\"{x:963,y:525,t:1526918871493};\\\", \\\"{x:968,y:517,t:1526918871510};\\\", \\\"{x:974,y:506,t:1526918871527};\\\", \\\"{x:980,y:495,t:1526918871544};\\\", \\\"{x:986,y:482,t:1526918871560};\\\", \\\"{x:997,y:461,t:1526918871578};\\\", \\\"{x:1006,y:440,t:1526918871594};\\\", \\\"{x:1021,y:410,t:1526918871610};\\\", \\\"{x:1033,y:386,t:1526918871628};\\\", \\\"{x:1040,y:371,t:1526918871644};\\\", \\\"{x:1048,y:356,t:1526918871660};\\\", \\\"{x:1062,y:333,t:1526918871676};\\\", \\\"{x:1070,y:319,t:1526918871693};\\\", \\\"{x:1076,y:308,t:1526918871709};\\\", \\\"{x:1083,y:295,t:1526918871729};\\\", \\\"{x:1095,y:271,t:1526918871753};\\\", \\\"{x:1098,y:265,t:1526918871760};\\\", \\\"{x:1106,y:251,t:1526918871777};\\\", \\\"{x:1113,y:238,t:1526918871794};\\\", \\\"{x:1118,y:228,t:1526918871811};\\\", \\\"{x:1123,y:217,t:1526918871827};\\\", \\\"{x:1127,y:208,t:1526918871842};\\\", \\\"{x:1128,y:202,t:1526918871860};\\\", \\\"{x:1130,y:193,t:1526918871876};\\\", \\\"{x:1130,y:190,t:1526918871892};\\\", \\\"{x:1130,y:187,t:1526918871910};\\\", \\\"{x:1130,y:186,t:1526918871927};\\\", \\\"{x:1130,y:186,t:1526918871943};\\\", \\\"{x:1130,y:186,t:1526918871960};\\\", \\\"{x:1129,y:186,t:1526918871976};\\\", \\\"{x:1128,y:188,t:1526918871994};\\\", \\\"{x:1124,y:201,t:1526918872011};\\\", \\\"{x:1112,y:221,t:1526918872027};\\\", \\\"{x:1081,y:266,t:1526918872044};\\\", \\\"{x:1041,y:307,t:1526918872060};\\\", \\\"{x:1013,y:328,t:1526918872077};\\\", \\\"{x:847,y:389,t:1526918872093};\\\", \\\"{x:686,y:423,t:1526918872111};\\\", \\\"{x:488,y:478,t:1526918872127};\\\", \\\"{x:289,y:537,t:1526918872145};\\\", \\\"{x:172,y:566,t:1526918872161};\\\", \\\"{x:144,y:570,t:1526918872173};\\\", \\\"{x:98,y:517,t:1526918872495};\\\", \\\"{x:105,y:515,t:1526918872510};\\\", \\\"{x:112,y:514,t:1526918872526};\\\", \\\"{x:117,y:514,t:1526918872543};\\\", \\\"{x:123,y:513,t:1526918872560};\\\", \\\"{x:129,y:511,t:1526918872576};\\\", \\\"{x:138,y:508,t:1526918872593};\\\", \\\"{x:152,y:503,t:1526918872610};\\\", \\\"{x:167,y:497,t:1526918872626};\\\", \\\"{x:193,y:486,t:1526918872644};\\\", \\\"{x:219,y:471,t:1526918872661};\\\", \\\"{x:250,y:455,t:1526918872678};\\\", \\\"{x:273,y:445,t:1526918872694};\\\", \\\"{x:312,y:432,t:1526918872711};\\\", \\\"{x:330,y:425,t:1526918872727};\\\", \\\"{x:343,y:418,t:1526918872745};\\\", \\\"{x:348,y:412,t:1526918872760};\\\", \\\"{x:348,y:408,t:1526918872927};\\\", \\\"{x:356,y:388,t:1526918872944};\\\", \\\"{x:361,y:375,t:1526918872961};\\\", \\\"{x:364,y:366,t:1526918872976};\\\", \\\"{x:367,y:361,t:1526918872994};\\\", \\\"{x:370,y:355,t:1526918873016};\\\", \\\"{x:371,y:353,t:1526918873029};\\\", \\\"{x:372,y:351,t:1526918873043};\\\", \\\"{x:373,y:349,t:1526918873060};\\\", \\\"{x:374,y:348,t:1526918873077};\\\", \\\"{x:375,y:346,t:1526918873095};\\\", \\\"{x:377,y:344,t:1526918873109};\\\", \\\"{x:378,y:342,t:1526918873127};\\\", \\\"{x:380,y:340,t:1526918873143};\\\", \\\"{x:381,y:340,t:1526918873160};\\\", \\\"{x:381,y:339,t:1526918873176};\\\", \\\"{x:382,y:339,t:1526918873193};\\\", \\\"{x:383,y:338,t:1526918873210};\\\", \\\"{x:385,y:337,t:1526918873227};\\\", \\\"{x:386,y:337,t:1526918873243};\\\", \\\"{x:388,y:336,t:1526918873260};\\\", \\\"{x:389,y:335,t:1526918873278};\\\", \\\"{x:391,y:334,t:1526918873294};\\\", \\\"{x:393,y:333,t:1526918873310};\\\", \\\"{x:394,y:332,t:1526918873326};\\\", \\\"{x:395,y:332,t:1526918873343};\\\", \\\"{x:396,y:332,t:1526918873359};\\\", \\\"{x:396,y:335,t:1526918874490};\\\", \\\"{x:397,y:343,t:1526918874497};\\\", \\\"{x:403,y:354,t:1526918874513};\\\", \\\"{x:420,y:376,t:1526918874529};\\\", \\\"{x:446,y:398,t:1526918874545};\\\", \\\"{x:517,y:454,t:1526918874560};\\\", \\\"{x:595,y:510,t:1526918874577};\\\", \\\"{x:647,y:547,t:1526918874593};\\\", \\\"{x:682,y:569,t:1526918874610};\\\", \\\"{x:680,y:492,t:1526918875167};\\\", \\\"{x:674,y:492,t:1526918875177};\\\", \\\"{x:654,y:495,t:1526918875193};\\\", \\\"{x:627,y:497,t:1526918875210};\\\", \\\"{x:560,y:500,t:1526918875228};\\\", \\\"{x:480,y:503,t:1526918875243};\\\", \\\"{x:426,y:504,t:1526918875261};\\\", \\\"{x:367,y:505,t:1526918875277};\\\", \\\"{x:337,y:505,t:1526918875294};\\\", \\\"{x:309,y:505,t:1526918875310};\\\", \\\"{x:289,y:505,t:1526918875327};\\\", \\\"{x:272,y:505,t:1526918875343};\\\", \\\"{x:267,y:507,t:1526918875361};\\\", \\\"{x:262,y:509,t:1526918875376};\\\", \\\"{x:260,y:510,t:1526918875394};\\\", \\\"{x:259,y:511,t:1526918875410};\\\", \\\"{x:259,y:513,t:1526918875428};\\\", \\\"{x:259,y:516,t:1526918875444};\\\", \\\"{x:259,y:518,t:1526918875460};\\\", \\\"{x:259,y:521,t:1526918875478};\\\", \\\"{x:259,y:522,t:1526918875494};\\\", \\\"{x:261,y:525,t:1526918875510};\\\", \\\"{x:264,y:527,t:1526918875527};\\\", \\\"{x:266,y:529,t:1526918875543};\\\", \\\"{x:269,y:532,t:1526918875560};\\\", \\\"{x:271,y:533,t:1526918875577};\\\", \\\"{x:273,y:533,t:1526918875594};\\\", \\\"{x:274,y:534,t:1526918875610};\\\", \\\"{x:275,y:534,t:1526918875624};\\\" ] }, { \\\"rt\\\": 14373, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 1991793, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:190,y:508,t:1526918877543};\\\", \\\"{x:203,y:446,t:1526918877566};\\\", \\\"{x:210,y:421,t:1526918877580};\\\", \\\"{x:221,y:388,t:1526918877595};\\\", \\\"{x:234,y:358,t:1526918877611};\\\", \\\"{x:241,y:345,t:1526918877629};\\\", \\\"{x:254,y:328,t:1526918877644};\\\", \\\"{x:263,y:324,t:1526918877660};\\\", \\\"{x:272,y:323,t:1526918877677};\\\", \\\"{x:280,y:323,t:1526918877694};\\\", \\\"{x:287,y:323,t:1526918877711};\\\", \\\"{x:293,y:325,t:1526918877728};\\\", \\\"{x:300,y:327,t:1526918877744};\\\", \\\"{x:312,y:333,t:1526918877761};\\\", \\\"{x:321,y:339,t:1526918877777};\\\", \\\"{x:331,y:347,t:1526918877796};\\\", \\\"{x:338,y:352,t:1526918877811};\\\", \\\"{x:343,y:355,t:1526918877828};\\\", \\\"{x:466,y:402,t:1526918880471};\\\", \\\"{x:470,y:405,t:1526918880477};\\\", \\\"{x:483,y:411,t:1526918880493};\\\", \\\"{x:526,y:435,t:1526918880511};\\\", \\\"{x:579,y:458,t:1526918880529};\\\", \\\"{x:647,y:484,t:1526918880544};\\\", \\\"{x:724,y:511,t:1526918880561};\\\", \\\"{x:805,y:540,t:1526918880578};\\\", \\\"{x:885,y:572,t:1526918880595};\\\", \\\"{x:953,y:601,t:1526918880612};\\\", \\\"{x:1012,y:634,t:1526918880628};\\\", \\\"{x:1046,y:654,t:1526918880645};\\\", \\\"{x:1063,y:662,t:1526918880661};\\\", \\\"{x:1087,y:672,t:1526918880678};\\\", \\\"{x:1096,y:675,t:1526918880694};\\\", \\\"{x:1099,y:675,t:1526918880710};\\\", \\\"{x:1100,y:675,t:1526918880727};\\\", \\\"{x:1101,y:671,t:1526918880745};\\\", \\\"{x:1101,y:660,t:1526918880761};\\\", \\\"{x:1098,y:647,t:1526918880778};\\\", \\\"{x:1088,y:625,t:1526918880795};\\\", \\\"{x:1078,y:609,t:1526918880811};\\\", \\\"{x:1063,y:579,t:1526918880828};\\\", \\\"{x:1051,y:548,t:1526918880845};\\\", \\\"{x:1041,y:510,t:1526918880861};\\\", \\\"{x:1037,y:476,t:1526918880878};\\\", \\\"{x:1032,y:436,t:1526918880894};\\\", \\\"{x:1027,y:406,t:1526918880911};\\\", \\\"{x:1025,y:398,t:1526918880928};\\\", \\\"{x:1023,y:390,t:1526918880944};\\\", \\\"{x:1023,y:390,t:1526918881448};\\\", \\\"{x:1026,y:390,t:1526918881461};\\\", \\\"{x:1034,y:390,t:1526918881478};\\\", \\\"{x:1045,y:390,t:1526918881495};\\\", \\\"{x:1062,y:390,t:1526918881510};\\\", \\\"{x:1079,y:390,t:1526918881527};\\\", \\\"{x:1094,y:390,t:1526918881544};\\\", \\\"{x:1100,y:390,t:1526918881560};\\\", \\\"{x:1103,y:390,t:1526918881578};\\\", \\\"{x:1104,y:390,t:1526918881595};\\\", \\\"{x:1104,y:391,t:1526918881611};\\\", \\\"{x:1104,y:391,t:1526918881628};\\\", \\\"{x:1104,y:391,t:1526918881644};\\\", \\\"{x:1101,y:393,t:1526918881662};\\\", \\\"{x:1090,y:397,t:1526918881677};\\\", \\\"{x:1071,y:403,t:1526918881694};\\\", \\\"{x:1046,y:409,t:1526918881710};\\\", \\\"{x:1017,y:414,t:1526918881727};\\\", \\\"{x:986,y:417,t:1526918881744};\\\", \\\"{x:954,y:420,t:1526918881761};\\\", \\\"{x:926,y:421,t:1526918881778};\\\", \\\"{x:912,y:422,t:1526918881795};\\\", \\\"{x:896,y:423,t:1526918881811};\\\", \\\"{x:889,y:424,t:1526918881828};\\\", \\\"{x:882,y:425,t:1526918881845};\\\", \\\"{x:879,y:425,t:1526918881861};\\\", \\\"{x:878,y:425,t:1526918881878};\\\", \\\"{x:878,y:424,t:1526918881895};\\\", \\\"{x:879,y:417,t:1526918881911};\\\", \\\"{x:887,y:402,t:1526918881927};\\\", \\\"{x:894,y:388,t:1526918881944};\\\", \\\"{x:907,y:369,t:1526918881961};\\\", \\\"{x:918,y:354,t:1526918881977};\\\", \\\"{x:930,y:343,t:1526918881994};\\\", \\\"{x:953,y:327,t:1526918882011};\\\", \\\"{x:982,y:312,t:1526918882028};\\\", \\\"{x:1022,y:295,t:1526918882044};\\\", \\\"{x:1051,y:284,t:1526918882062};\\\", \\\"{x:1090,y:275,t:1526918882078};\\\", \\\"{x:1122,y:270,t:1526918882095};\\\", \\\"{x:1148,y:269,t:1526918882111};\\\", \\\"{x:1164,y:269,t:1526918882128};\\\", \\\"{x:1179,y:269,t:1526918882144};\\\", \\\"{x:1186,y:270,t:1526918882161};\\\", \\\"{x:1193,y:272,t:1526918882177};\\\", \\\"{x:1195,y:273,t:1526918882195};\\\", \\\"{x:1195,y:273,t:1526918882210};\\\", \\\"{x:1194,y:273,t:1526918882266};\\\", \\\"{x:1193,y:272,t:1526918882278};\\\", \\\"{x:1191,y:269,t:1526918882295};\\\", \\\"{x:1187,y:266,t:1526918882312};\\\", \\\"{x:1185,y:262,t:1526918882328};\\\", \\\"{x:1182,y:257,t:1526918882345};\\\", \\\"{x:1180,y:253,t:1526918882361};\\\", \\\"{x:1179,y:246,t:1526918882378};\\\", \\\"{x:1178,y:242,t:1526918882394};\\\", \\\"{x:1178,y:239,t:1526918882411};\\\", \\\"{x:1178,y:236,t:1526918882428};\\\", \\\"{x:1178,y:234,t:1526918882444};\\\", \\\"{x:1179,y:233,t:1526918882464};\\\", \\\"{x:1179,y:232,t:1526918882478};\\\", \\\"{x:1179,y:232,t:1526918882494};\\\", \\\"{x:1180,y:232,t:1526918882511};\\\", \\\"{x:1180,y:235,t:1526918883269};\\\", \\\"{x:1178,y:239,t:1526918883278};\\\", \\\"{x:1175,y:249,t:1526918883295};\\\", \\\"{x:1169,y:266,t:1526918883312};\\\", \\\"{x:1161,y:285,t:1526918883328};\\\", \\\"{x:1156,y:298,t:1526918883345};\\\", \\\"{x:1149,y:317,t:1526918883362};\\\", \\\"{x:1141,y:335,t:1526918883379};\\\", \\\"{x:1138,y:343,t:1526918883394};\\\", \\\"{x:1133,y:353,t:1526918883411};\\\", \\\"{x:1127,y:367,t:1526918883428};\\\", \\\"{x:1123,y:376,t:1526918883444};\\\", \\\"{x:1120,y:383,t:1526918883461};\\\", \\\"{x:1117,y:390,t:1526918883478};\\\", \\\"{x:1113,y:397,t:1526918883494};\\\", \\\"{x:1109,y:403,t:1526918883512};\\\", \\\"{x:1107,y:408,t:1526918883528};\\\", \\\"{x:1102,y:415,t:1526918883545};\\\", \\\"{x:1099,y:419,t:1526918883562};\\\", \\\"{x:1096,y:423,t:1526918883579};\\\", \\\"{x:1094,y:426,t:1526918883594};\\\", \\\"{x:1091,y:429,t:1526918883611};\\\", \\\"{x:1090,y:431,t:1526918883627};\\\", \\\"{x:1088,y:432,t:1526918883644};\\\", \\\"{x:1087,y:433,t:1526918883662};\\\", \\\"{x:1087,y:433,t:1526918883678};\\\", \\\"{x:1086,y:434,t:1526918883695};\\\", \\\"{x:1086,y:434,t:1526918883711};\\\", \\\"{x:1085,y:434,t:1526918883728};\\\", \\\"{x:1085,y:434,t:1526918883764};\\\", \\\"{x:1085,y:434,t:1526918883778};\\\", \\\"{x:1085,y:433,t:1526918883796};\\\", \\\"{x:1085,y:433,t:1526918883812};\\\", \\\"{x:1085,y:432,t:1526918883827};\\\", \\\"{x:1085,y:432,t:1526918883845};\\\", \\\"{x:1084,y:432,t:1526918883861};\\\", \\\"{x:1082,y:431,t:1526918883878};\\\", \\\"{x:1070,y:431,t:1526918883896};\\\", \\\"{x:1025,y:437,t:1526918883912};\\\", \\\"{x:942,y:453,t:1526918883928};\\\", \\\"{x:818,y:466,t:1526918883945};\\\", \\\"{x:680,y:470,t:1526918883962};\\\", \\\"{x:564,y:466,t:1526918883979};\\\", \\\"{x:511,y:452,t:1526918883996};\\\", \\\"{x:472,y:438,t:1526918884011};\\\", \\\"{x:467,y:434,t:1526918884027};\\\", \\\"{x:466,y:433,t:1526918884270};\\\", \\\"{x:463,y:430,t:1526918884277};\\\", \\\"{x:455,y:419,t:1526918884296};\\\", \\\"{x:445,y:407,t:1526918884311};\\\", \\\"{x:438,y:399,t:1526918884327};\\\", \\\"{x:430,y:392,t:1526918884346};\\\", \\\"{x:424,y:388,t:1526918884362};\\\", \\\"{x:419,y:385,t:1526918884380};\\\", \\\"{x:414,y:381,t:1526918884395};\\\", \\\"{x:411,y:378,t:1526918884412};\\\", \\\"{x:409,y:375,t:1526918884427};\\\", \\\"{x:408,y:371,t:1526918884444};\\\", \\\"{x:407,y:369,t:1526918884461};\\\", \\\"{x:407,y:368,t:1526918884477};\\\", \\\"{x:407,y:368,t:1526918884495};\\\", \\\"{x:407,y:368,t:1526918884526};\\\", \\\"{x:407,y:368,t:1526918884541};\\\", \\\"{x:407,y:368,t:1526918884557};\\\", \\\"{x:407,y:367,t:1526918884566};\\\", \\\"{x:407,y:367,t:1526918884578};\\\", \\\"{x:406,y:367,t:1526918884622};\\\", \\\"{x:406,y:367,t:1526918884654};\\\", \\\"{x:406,y:367,t:1526918884661};\\\", \\\"{x:406,y:367,t:1526918884678};\\\", \\\"{x:406,y:368,t:1526918884694};\\\", \\\"{x:404,y:369,t:1526918884710};\\\", \\\"{x:400,y:370,t:1526918884728};\\\", \\\"{x:394,y:371,t:1526918884745};\\\", \\\"{x:389,y:372,t:1526918884761};\\\", \\\"{x:381,y:373,t:1526918884779};\\\", \\\"{x:377,y:374,t:1526918884794};\\\", \\\"{x:373,y:375,t:1526918884811};\\\", \\\"{x:371,y:376,t:1526918884828};\\\", \\\"{x:372,y:376,t:1526918884995};\\\", \\\"{x:377,y:376,t:1526918885010};\\\", \\\"{x:378,y:376,t:1526918885028};\\\", \\\"{x:378,y:377,t:1526918885044};\\\", \\\"{x:378,y:378,t:1526918885061};\\\", \\\"{x:374,y:381,t:1526918885078};\\\", \\\"{x:364,y:388,t:1526918885096};\\\", \\\"{x:349,y:396,t:1526918885111};\\\", \\\"{x:335,y:401,t:1526918885129};\\\", \\\"{x:323,y:404,t:1526918885147};\\\", \\\"{x:312,y:408,t:1526918885160};\\\", \\\"{x:304,y:410,t:1526918885177};\\\", \\\"{x:295,y:412,t:1526918885194};\\\", \\\"{x:287,y:412,t:1526918885211};\\\", \\\"{x:272,y:413,t:1526918885227};\\\", \\\"{x:261,y:413,t:1526918885245};\\\", \\\"{x:250,y:413,t:1526918885261};\\\", \\\"{x:237,y:411,t:1526918885279};\\\", \\\"{x:223,y:410,t:1526918885295};\\\", \\\"{x:209,y:408,t:1526918885311};\\\", \\\"{x:196,y:407,t:1526918885328};\\\", \\\"{x:190,y:405,t:1526918885345};\\\", \\\"{x:184,y:404,t:1526918885364};\\\", \\\"{x:180,y:403,t:1526918885378};\\\", \\\"{x:178,y:403,t:1526918885395};\\\", \\\"{x:175,y:402,t:1526918885411};\\\", \\\"{x:170,y:402,t:1526918885427};\\\", \\\"{x:168,y:402,t:1526918885444};\\\", \\\"{x:165,y:402,t:1526918885461};\\\", \\\"{x:163,y:402,t:1526918885478};\\\", \\\"{x:162,y:402,t:1526918885494};\\\", \\\"{x:160,y:402,t:1526918885512};\\\", \\\"{x:159,y:402,t:1526918885527};\\\", \\\"{x:159,y:402,t:1526918885544};\\\", \\\"{x:159,y:402,t:1526918885562};\\\", \\\"{x:160,y:401,t:1526918885579};\\\", \\\"{x:166,y:401,t:1526918885594};\\\", \\\"{x:176,y:401,t:1526918885611};\\\", \\\"{x:186,y:401,t:1526918885627};\\\", \\\"{x:193,y:401,t:1526918885645};\\\", \\\"{x:66,y:401,t:1526918886061};\\\", \\\"{x:69,y:401,t:1526918886077};\\\", \\\"{x:74,y:402,t:1526918886095};\\\", \\\"{x:80,y:403,t:1526918886111};\\\", \\\"{x:89,y:404,t:1526918886127};\\\", \\\"{x:93,y:405,t:1526918886145};\\\", \\\"{x:97,y:407,t:1526918886162};\\\", \\\"{x:100,y:408,t:1526918886178};\\\", \\\"{x:102,y:408,t:1526918886196};\\\", \\\"{x:102,y:409,t:1526918886212};\\\", \\\"{x:103,y:409,t:1526918886228};\\\", \\\"{x:104,y:409,t:1526918886244};\\\", \\\"{x:105,y:409,t:1526918886262};\\\", \\\"{x:107,y:409,t:1526918886278};\\\", \\\"{x:108,y:409,t:1526918886294};\\\", \\\"{x:109,y:409,t:1526918886311};\\\", \\\"{x:109,y:409,t:1526918886326};\\\", \\\"{x:110,y:409,t:1526918886631};\\\", \\\"{x:115,y:409,t:1526918886644};\\\", \\\"{x:138,y:409,t:1526918886661};\\\", \\\"{x:240,y:409,t:1526918886678};\\\", \\\"{x:365,y:417,t:1526918886695};\\\", \\\"{x:496,y:430,t:1526918886712};\\\", \\\"{x:575,y:443,t:1526918886727};\\\", \\\"{x:647,y:463,t:1526918886745};\\\", \\\"{x:663,y:471,t:1526918886761};\\\", \\\"{x:677,y:478,t:1526918886777};\\\", \\\"{x:683,y:481,t:1526918886795};\\\", \\\"{x:812,y:481,t:1526918888763};\\\", \\\"{x:827,y:478,t:1526918888779};\\\", \\\"{x:865,y:466,t:1526918888795};\\\", \\\"{x:900,y:454,t:1526918888812};\\\", \\\"{x:950,y:437,t:1526918888829};\\\", \\\"{x:980,y:428,t:1526918888846};\\\", \\\"{x:1014,y:420,t:1526918888863};\\\", \\\"{x:1031,y:417,t:1526918888879};\\\", \\\"{x:1049,y:415,t:1526918888896};\\\", \\\"{x:1060,y:414,t:1526918888913};\\\", \\\"{x:1066,y:414,t:1526918888929};\\\", \\\"{x:1070,y:414,t:1526918888946};\\\", \\\"{x:1073,y:415,t:1526918888962};\\\", \\\"{x:1075,y:416,t:1526918888978};\\\", \\\"{x:1076,y:417,t:1526918888995};\\\", \\\"{x:1077,y:418,t:1526918889013};\\\", \\\"{x:1077,y:418,t:1526918889029};\\\", \\\"{x:1078,y:419,t:1526918889046};\\\", \\\"{x:1078,y:420,t:1526918889062};\\\", \\\"{x:1078,y:420,t:1526918889079};\\\", \\\"{x:1078,y:421,t:1526918889096};\\\", \\\"{x:1078,y:422,t:1526918889112};\\\", \\\"{x:1078,y:422,t:1526918889129};\\\", \\\"{x:1079,y:422,t:1526918889145};\\\", \\\"{x:1079,y:422,t:1526918889165};\\\", \\\"{x:1079,y:422,t:1526918889179};\\\", \\\"{x:1079,y:421,t:1526918889196};\\\", \\\"{x:1080,y:420,t:1526918889212};\\\", \\\"{x:1080,y:420,t:1526918889229};\\\", \\\"{x:1080,y:420,t:1526918889246};\\\", \\\"{x:1080,y:420,t:1526918889263};\\\", \\\"{x:1080,y:420,t:1526918889421};\\\", \\\"{x:1080,y:420,t:1526918889452};\\\", \\\"{x:1080,y:420,t:1526918889492};\\\", \\\"{x:1080,y:420,t:1526918889653};\\\", \\\"{x:1080,y:420,t:1526918889662};\\\", \\\"{x:1081,y:419,t:1526918889679};\\\", \\\"{x:1081,y:418,t:1526918889695};\\\", \\\"{x:1082,y:417,t:1526918889713};\\\", \\\"{x:1084,y:416,t:1526918889729};\\\", \\\"{x:1086,y:413,t:1526918889747};\\\", \\\"{x:1089,y:410,t:1526918889763};\\\", \\\"{x:1092,y:407,t:1526918889779};\\\", \\\"{x:1094,y:404,t:1526918889796};\\\", \\\"{x:1097,y:400,t:1526918889812};\\\", \\\"{x:1099,y:396,t:1526918889829};\\\", \\\"{x:1102,y:390,t:1526918889845};\\\", \\\"{x:1106,y:381,t:1526918889862};\\\", \\\"{x:1110,y:372,t:1526918889878};\\\", \\\"{x:1115,y:360,t:1526918889896};\\\", \\\"{x:1119,y:350,t:1526918889912};\\\", \\\"{x:1124,y:340,t:1526918889929};\\\", \\\"{x:1128,y:331,t:1526918889946};\\\", \\\"{x:1131,y:323,t:1526918889962};\\\", \\\"{x:1135,y:315,t:1526918889979};\\\", \\\"{x:1139,y:307,t:1526918889995};\\\", \\\"{x:1143,y:298,t:1526918890011};\\\", \\\"{x:1147,y:291,t:1526918890029};\\\", \\\"{x:1151,y:283,t:1526918890045};\\\", \\\"{x:1157,y:272,t:1526918890062};\\\", \\\"{x:1160,y:264,t:1526918890080};\\\", \\\"{x:1164,y:258,t:1526918890095};\\\", \\\"{x:1165,y:255,t:1526918890112};\\\", \\\"{x:1166,y:252,t:1526918890130};\\\", \\\"{x:1167,y:251,t:1526918890145};\\\", \\\"{x:1167,y:251,t:1526918890163};\\\", \\\"{x:1167,y:251,t:1526918890182};\\\", \\\"{x:1167,y:253,t:1526918890196};\\\", \\\"{x:1163,y:263,t:1526918890212};\\\", \\\"{x:1155,y:282,t:1526918890228};\\\", \\\"{x:1141,y:310,t:1526918890245};\\\", \\\"{x:1122,y:350,t:1526918890263};\\\", \\\"{x:1108,y:379,t:1526918890278};\\\", \\\"{x:1097,y:400,t:1526918890296};\\\", \\\"{x:1088,y:418,t:1526918890312};\\\", \\\"{x:1079,y:437,t:1526918890329};\\\", \\\"{x:1070,y:457,t:1526918890346};\\\", \\\"{x:1061,y:477,t:1526918890363};\\\", \\\"{x:1053,y:497,t:1526918890379};\\\", \\\"{x:1044,y:517,t:1526918890396};\\\", \\\"{x:1032,y:545,t:1526918890412};\\\", \\\"{x:1015,y:582,t:1526918890429};\\\", \\\"{x:1002,y:609,t:1526918890445};\\\", \\\"{x:987,y:639,t:1526918890461};\\\", \\\"{x:970,y:670,t:1526918890478};\\\", \\\"{x:956,y:699,t:1526918890495};\\\", \\\"{x:948,y:715,t:1526918890512};\\\", \\\"{x:940,y:729,t:1526918890529};\\\", \\\"{x:931,y:739,t:1526918890546};\\\", \\\"{x:925,y:744,t:1526918890562};\\\", \\\"{x:919,y:747,t:1526918890579};\\\", \\\"{x:914,y:748,t:1526918890597};\\\", \\\"{x:910,y:748,t:1526918890613};\\\", \\\"{x:907,y:744,t:1526918890629};\\\", \\\"{x:907,y:744,t:1526918890739};\\\", \\\"{x:904,y:744,t:1526918890747};\\\", \\\"{x:895,y:742,t:1526918890762};\\\", \\\"{x:852,y:726,t:1526918890778};\\\", \\\"{x:711,y:661,t:1526918890795};\\\", \\\"{x:643,y:619,t:1526918890813};\\\", \\\"{x:559,y:565,t:1526918890829};\\\", \\\"{x:516,y:536,t:1526918890846};\\\", \\\"{x:484,y:517,t:1526918890862};\\\", \\\"{x:465,y:506,t:1526918890879};\\\", \\\"{x:455,y:500,t:1526918890895};\\\", \\\"{x:449,y:497,t:1526918890912};\\\", \\\"{x:447,y:495,t:1526918890929};\\\", \\\"{x:446,y:495,t:1526918891100};\\\", \\\"{x:442,y:498,t:1526918891112};\\\", \\\"{x:429,y:504,t:1526918891129};\\\", \\\"{x:413,y:511,t:1526918891146};\\\", \\\"{x:393,y:517,t:1526918891162};\\\", \\\"{x:379,y:521,t:1526918891178};\\\", \\\"{x:364,y:524,t:1526918891195};\\\", \\\"{x:345,y:526,t:1526918891213};\\\", \\\"{x:336,y:526,t:1526918891228};\\\", \\\"{x:330,y:526,t:1526918891245};\\\", \\\"{x:324,y:524,t:1526918891262};\\\", \\\"{x:320,y:523,t:1526918891279};\\\", \\\"{x:317,y:522,t:1526918891297};\\\", \\\"{x:315,y:521,t:1526918891312};\\\", \\\"{x:197,y:491,t:1526918892006};\\\", \\\"{x:200,y:491,t:1526918892014};\\\", \\\"{x:203,y:491,t:1526918892028};\\\", \\\"{x:211,y:488,t:1526918892044};\\\", \\\"{x:235,y:479,t:1526918892062};\\\", \\\"{x:255,y:470,t:1526918892079};\\\", \\\"{x:277,y:459,t:1526918892095};\\\", \\\"{x:309,y:443,t:1526918892112};\\\", \\\"{x:326,y:434,t:1526918892129};\\\", \\\"{x:341,y:426,t:1526918892146};\\\", \\\"{x:355,y:418,t:1526918892162};\\\", \\\"{x:361,y:415,t:1526918892179};\\\", \\\"{x:366,y:412,t:1526918892196};\\\", \\\"{x:369,y:411,t:1526918892213};\\\", \\\"{x:370,y:410,t:1526918892229};\\\", \\\"{x:371,y:410,t:1526918892245};\\\", \\\"{x:371,y:410,t:1526918892262};\\\", \\\"{x:371,y:409,t:1526918892420};\\\", \\\"{x:371,y:409,t:1526918892469};\\\", \\\"{x:370,y:409,t:1526918892486};\\\", \\\"{x:370,y:409,t:1526918892495};\\\", \\\"{x:369,y:409,t:1526918892512};\\\", \\\"{x:369,y:409,t:1526918892529};\\\", \\\"{x:367,y:409,t:1526918892545};\\\" ] }, { \\\"rt\\\": 9186, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 2002292, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:362,y:441,t:1526918892683};\\\", \\\"{x:361,y:441,t:1526918892702};\\\", \\\"{x:361,y:441,t:1526918892734};\\\", \\\"{x:361,y:441,t:1526918892746};\\\", \\\"{x:361,y:441,t:1526918892840};\\\", \\\"{x:361,y:441,t:1526918892848};\\\", \\\"{x:361,y:441,t:1526918892879};\\\", \\\"{x:361,y:441,t:1526918892911};\\\", \\\"{x:360,y:441,t:1526918892992};\\\", \\\"{x:360,y:441,t:1526918893008};\\\", \\\"{x:360,y:441,t:1526918893014};\\\", \\\"{x:358,y:441,t:1526918893030};\\\", \\\"{x:352,y:438,t:1526918893045};\\\", \\\"{x:254,y:220,t:1526918893207};\\\", \\\"{x:254,y:214,t:1526918893217};\\\", \\\"{x:256,y:211,t:1526918893228};\\\", \\\"{x:259,y:207,t:1526918893246};\\\", \\\"{x:260,y:207,t:1526918893513};\\\", \\\"{x:267,y:209,t:1526918893528};\\\", \\\"{x:280,y:212,t:1526918893546};\\\", \\\"{x:312,y:218,t:1526918893563};\\\", \\\"{x:372,y:231,t:1526918893579};\\\", \\\"{x:413,y:241,t:1526918893597};\\\", \\\"{x:468,y:257,t:1526918893613};\\\", \\\"{x:501,y:269,t:1526918893630};\\\", \\\"{x:533,y:283,t:1526918893646};\\\", \\\"{x:549,y:291,t:1526918893663};\\\", \\\"{x:564,y:300,t:1526918893678};\\\", \\\"{x:569,y:303,t:1526918893698};\\\", \\\"{x:689,y:304,t:1526918895520};\\\", \\\"{x:690,y:309,t:1526918895528};\\\", \\\"{x:696,y:328,t:1526918895546};\\\", \\\"{x:715,y:381,t:1526918895563};\\\", \\\"{x:744,y:452,t:1526918895580};\\\", \\\"{x:782,y:528,t:1526918895595};\\\", \\\"{x:807,y:572,t:1526918895613};\\\", \\\"{x:825,y:600,t:1526918895629};\\\", \\\"{x:836,y:617,t:1526918895646};\\\", \\\"{x:842,y:626,t:1526918895663};\\\", \\\"{x:846,y:634,t:1526918895680};\\\", \\\"{x:847,y:637,t:1526918895696};\\\", \\\"{x:847,y:639,t:1526918895713};\\\", \\\"{x:847,y:641,t:1526918895729};\\\", \\\"{x:847,y:642,t:1526918895745};\\\", \\\"{x:843,y:643,t:1526918895763};\\\", \\\"{x:833,y:645,t:1526918895780};\\\", \\\"{x:817,y:646,t:1526918895795};\\\", \\\"{x:804,y:646,t:1526918895813};\\\", \\\"{x:791,y:644,t:1526918895830};\\\", \\\"{x:783,y:641,t:1526918895846};\\\", \\\"{x:780,y:638,t:1526918895864};\\\", \\\"{x:777,y:635,t:1526918895879};\\\", \\\"{x:775,y:633,t:1526918895896};\\\", \\\"{x:774,y:632,t:1526918895913};\\\", \\\"{x:773,y:631,t:1526918895929};\\\", \\\"{x:773,y:631,t:1526918895946};\\\", \\\"{x:773,y:630,t:1526918895963};\\\", \\\"{x:773,y:630,t:1526918895979};\\\", \\\"{x:773,y:630,t:1526918895995};\\\", \\\"{x:774,y:629,t:1526918896012};\\\", \\\"{x:774,y:629,t:1526918896029};\\\", \\\"{x:775,y:628,t:1526918896047};\\\", \\\"{x:776,y:627,t:1526918896064};\\\", \\\"{x:776,y:626,t:1526918896080};\\\", \\\"{x:777,y:625,t:1526918896096};\\\", \\\"{x:778,y:624,t:1526918896113};\\\", \\\"{x:778,y:623,t:1526918896129};\\\", \\\"{x:779,y:621,t:1526918896146};\\\", \\\"{x:779,y:621,t:1526918896161};\\\", \\\"{x:779,y:620,t:1526918896179};\\\", \\\"{x:779,y:619,t:1526918896196};\\\", \\\"{x:780,y:619,t:1526918896213};\\\", \\\"{x:780,y:619,t:1526918896229};\\\", \\\"{x:780,y:619,t:1526918896250};\\\", \\\"{x:780,y:619,t:1526918896273};\\\", \\\"{x:780,y:619,t:1526918896282};\\\", \\\"{x:780,y:620,t:1526918896295};\\\", \\\"{x:781,y:620,t:1526918896313};\\\", \\\"{x:781,y:621,t:1526918896329};\\\", \\\"{x:781,y:622,t:1526918896346};\\\", \\\"{x:782,y:623,t:1526918896362};\\\", \\\"{x:782,y:624,t:1526918896381};\\\", \\\"{x:782,y:624,t:1526918896396};\\\", \\\"{x:782,y:624,t:1526918896426};\\\", \\\"{x:782,y:623,t:1526918896796};\\\", \\\"{x:782,y:623,t:1526918896812};\\\", \\\"{x:782,y:624,t:1526918897862};\\\", \\\"{x:783,y:626,t:1526918897880};\\\", \\\"{x:786,y:632,t:1526918897896};\\\", \\\"{x:791,y:643,t:1526918897913};\\\", \\\"{x:798,y:659,t:1526918897930};\\\", \\\"{x:805,y:676,t:1526918897946};\\\", \\\"{x:810,y:688,t:1526918897964};\\\", \\\"{x:815,y:700,t:1526918897979};\\\", \\\"{x:818,y:710,t:1526918897996};\\\", \\\"{x:821,y:719,t:1526918898013};\\\", \\\"{x:823,y:726,t:1526918898029};\\\", \\\"{x:827,y:737,t:1526918898046};\\\", \\\"{x:828,y:742,t:1526918898062};\\\", \\\"{x:830,y:749,t:1526918898079};\\\", \\\"{x:830,y:752,t:1526918898096};\\\", \\\"{x:831,y:755,t:1526918898112};\\\", \\\"{x:832,y:758,t:1526918898129};\\\", \\\"{x:832,y:759,t:1526918898147};\\\", \\\"{x:833,y:760,t:1526918898164};\\\", \\\"{x:833,y:761,t:1526918898180};\\\", \\\"{x:833,y:762,t:1526918898196};\\\", \\\"{x:833,y:762,t:1526918898212};\\\", \\\"{x:833,y:762,t:1526918898229};\\\", \\\"{x:834,y:762,t:1526918898246};\\\", \\\"{x:834,y:762,t:1526918898277};\\\", \\\"{x:834,y:762,t:1526918898302};\\\", \\\"{x:834,y:762,t:1526918898317};\\\", \\\"{x:835,y:762,t:1526918898330};\\\", \\\"{x:835,y:762,t:1526918898346};\\\", \\\"{x:837,y:762,t:1526918898363};\\\", \\\"{x:839,y:762,t:1526918898380};\\\", \\\"{x:840,y:762,t:1526918898397};\\\", \\\"{x:842,y:762,t:1526918898413};\\\", \\\"{x:844,y:762,t:1526918898429};\\\", \\\"{x:845,y:762,t:1526918898446};\\\", \\\"{x:846,y:762,t:1526918898462};\\\", \\\"{x:847,y:763,t:1526918898480};\\\", \\\"{x:847,y:763,t:1526918898495};\\\", \\\"{x:848,y:763,t:1526918898513};\\\", \\\"{x:848,y:763,t:1526918898530};\\\", \\\"{x:848,y:763,t:1526918898547};\\\", \\\"{x:849,y:763,t:1526918898563};\\\", \\\"{x:849,y:761,t:1526918898579};\\\", \\\"{x:850,y:757,t:1526918898597};\\\", \\\"{x:852,y:753,t:1526918898613};\\\", \\\"{x:855,y:748,t:1526918898630};\\\", \\\"{x:859,y:743,t:1526918898646};\\\", \\\"{x:864,y:736,t:1526918898663};\\\", \\\"{x:868,y:731,t:1526918898679};\\\", \\\"{x:873,y:723,t:1526918898696};\\\", \\\"{x:877,y:717,t:1526918898713};\\\", \\\"{x:882,y:710,t:1526918898730};\\\", \\\"{x:886,y:703,t:1526918898747};\\\", \\\"{x:889,y:697,t:1526918898763};\\\", \\\"{x:892,y:692,t:1526918898779};\\\", \\\"{x:894,y:687,t:1526918898797};\\\", \\\"{x:896,y:681,t:1526918898813};\\\", \\\"{x:900,y:674,t:1526918898830};\\\", \\\"{x:904,y:666,t:1526918898846};\\\", \\\"{x:908,y:657,t:1526918898862};\\\", \\\"{x:913,y:645,t:1526918898879};\\\", \\\"{x:916,y:637,t:1526918898897};\\\", \\\"{x:919,y:630,t:1526918898912};\\\", \\\"{x:922,y:623,t:1526918898930};\\\", \\\"{x:925,y:615,t:1526918898946};\\\", \\\"{x:929,y:607,t:1526918898964};\\\", \\\"{x:932,y:599,t:1526918898980};\\\", \\\"{x:936,y:590,t:1526918898997};\\\", \\\"{x:939,y:584,t:1526918899012};\\\", \\\"{x:941,y:579,t:1526918899029};\\\", \\\"{x:943,y:576,t:1526918899046};\\\", \\\"{x:944,y:573,t:1526918899063};\\\", \\\"{x:944,y:572,t:1526918899079};\\\", \\\"{x:945,y:571,t:1526918899096};\\\", \\\"{x:945,y:571,t:1526918899113};\\\", \\\"{x:945,y:570,t:1526918899129};\\\", \\\"{x:945,y:570,t:1526918899356};\\\", \\\"{x:945,y:568,t:1526918899365};\\\", \\\"{x:945,y:564,t:1526918899380};\\\", \\\"{x:949,y:551,t:1526918899397};\\\", \\\"{x:956,y:527,t:1526918899412};\\\", \\\"{x:962,y:510,t:1526918899430};\\\", \\\"{x:967,y:495,t:1526918899445};\\\", \\\"{x:973,y:479,t:1526918899463};\\\", \\\"{x:979,y:464,t:1526918899479};\\\", \\\"{x:986,y:446,t:1526918899496};\\\", \\\"{x:993,y:427,t:1526918899513};\\\", \\\"{x:998,y:415,t:1526918899530};\\\", \\\"{x:1004,y:401,t:1526918899547};\\\", \\\"{x:1012,y:381,t:1526918899563};\\\", \\\"{x:1023,y:353,t:1526918899579};\\\", \\\"{x:1036,y:323,t:1526918899596};\\\", \\\"{x:1060,y:270,t:1526918899612};\\\", \\\"{x:1071,y:246,t:1526918899629};\\\", \\\"{x:1089,y:209,t:1526918899646};\\\", \\\"{x:1104,y:181,t:1526918899663};\\\", \\\"{x:1115,y:161,t:1526918899680};\\\", \\\"{x:1125,y:145,t:1526918899697};\\\", \\\"{x:1133,y:130,t:1526918899713};\\\", \\\"{x:1137,y:123,t:1526918899730};\\\", \\\"{x:1141,y:117,t:1526918899747};\\\", \\\"{x:1143,y:115,t:1526918899763};\\\", \\\"{x:1143,y:113,t:1526918899780};\\\", \\\"{x:1144,y:113,t:1526918899797};\\\", \\\"{x:1143,y:113,t:1526918899829};\\\", \\\"{x:1136,y:122,t:1526918899846};\\\", \\\"{x:1120,y:139,t:1526918899863};\\\", \\\"{x:1078,y:175,t:1526918899879};\\\", \\\"{x:998,y:235,t:1526918899896};\\\", \\\"{x:908,y:294,t:1526918899913};\\\", \\\"{x:797,y:367,t:1526918899930};\\\", \\\"{x:713,y:421,t:1526918899946};\\\", \\\"{x:600,y:487,t:1526918899963};\\\", \\\"{x:545,y:514,t:1526918899980};\\\", \\\"{x:509,y:528,t:1526918899996};\\\", \\\"{x:486,y:534,t:1526918900012};\\\", \\\"{x:465,y:538,t:1526918900029};\\\", \\\"{x:457,y:539,t:1526918900046};\\\", \\\"{x:453,y:539,t:1526918900062};\\\", \\\"{x:452,y:538,t:1526918900406};\\\", \\\"{x:448,y:533,t:1526918900414};\\\", \\\"{x:436,y:524,t:1526918900429};\\\", \\\"{x:365,y:471,t:1526918900446};\\\", \\\"{x:296,y:422,t:1526918900464};\\\", \\\"{x:273,y:404,t:1526918900480};\\\", \\\"{x:249,y:386,t:1526918900497};\\\", \\\"{x:238,y:377,t:1526918900514};\\\", \\\"{x:231,y:372,t:1526918900529};\\\", \\\"{x:230,y:368,t:1526918900546};\\\", \\\"{x:233,y:363,t:1526918900564};\\\", \\\"{x:251,y:355,t:1526918900580};\\\", \\\"{x:273,y:347,t:1526918900598};\\\", \\\"{x:293,y:343,t:1526918900613};\\\", \\\"{x:312,y:337,t:1526918900630};\\\", \\\"{x:327,y:333,t:1526918900649};\\\", \\\"{x:336,y:330,t:1526918900663};\\\", \\\"{x:342,y:328,t:1526918900681};\\\", \\\"{x:346,y:328,t:1526918900697};\\\", \\\"{x:351,y:328,t:1526918900713};\\\", \\\"{x:354,y:328,t:1526918900730};\\\", \\\"{x:356,y:328,t:1526918900747};\\\", \\\"{x:357,y:328,t:1526918900764};\\\", \\\"{x:359,y:328,t:1526918900780};\\\", \\\"{x:361,y:328,t:1526918900797};\\\", \\\"{x:363,y:328,t:1526918900814};\\\", \\\"{x:365,y:328,t:1526918900829};\\\", \\\"{x:366,y:328,t:1526918900847};\\\", \\\"{x:367,y:329,t:1526918900863};\\\", \\\"{x:367,y:329,t:1526918900880};\\\", \\\"{x:367,y:329,t:1526918900897};\\\", \\\"{x:368,y:329,t:1526918900914};\\\", \\\"{x:368,y:329,t:1526918900930};\\\", \\\"{x:370,y:329,t:1526918900947};\\\", \\\"{x:371,y:329,t:1526918900963};\\\", \\\"{x:373,y:329,t:1526918900980};\\\", \\\"{x:375,y:329,t:1526918900998};\\\", \\\"{x:379,y:329,t:1526918901014};\\\", \\\"{x:381,y:329,t:1526918901030};\\\", \\\"{x:384,y:329,t:1526918901048};\\\", \\\"{x:385,y:329,t:1526918901063};\\\", \\\"{x:386,y:329,t:1526918901080};\\\", \\\"{x:386,y:331,t:1526918901336};\\\", \\\"{x:385,y:344,t:1526918901348};\\\", \\\"{x:380,y:377,t:1526918901364};\\\", \\\"{x:376,y:399,t:1526918901382};\\\", \\\"{x:372,y:416,t:1526918901397};\\\", \\\"{x:365,y:445,t:1526918901414};\\\", \\\"{x:360,y:460,t:1526918901431};\\\", \\\"{x:354,y:473,t:1526918901448};\\\", \\\"{x:349,y:483,t:1526918901463};\\\", \\\"{x:346,y:487,t:1526918901480};\\\", \\\"{x:339,y:494,t:1526918901496};\\\", \\\"{x:334,y:498,t:1526918901514};\\\", \\\"{x:328,y:503,t:1526918901530};\\\", \\\"{x:323,y:508,t:1526918901546};\\\", \\\"{x:320,y:510,t:1526918901564};\\\", \\\"{x:317,y:513,t:1526918901582};\\\", \\\"{x:315,y:514,t:1526918901597};\\\", \\\"{x:313,y:514,t:1526918901615};\\\", \\\"{x:311,y:516,t:1526918901631};\\\", \\\"{x:309,y:517,t:1526918901647};\\\", \\\"{x:307,y:518,t:1526918901663};\\\", \\\"{x:306,y:519,t:1526918901680};\\\", \\\"{x:304,y:521,t:1526918901697};\\\", \\\"{x:303,y:523,t:1526918901713};\\\", \\\"{x:302,y:526,t:1526918901730};\\\", \\\"{x:301,y:528,t:1526918901747};\\\", \\\"{x:301,y:529,t:1526918901763};\\\", \\\"{x:300,y:530,t:1526918901780};\\\", \\\"{x:299,y:531,t:1526918901797};\\\", \\\"{x:299,y:531,t:1526918901809};\\\" ] }, { \\\"rt\\\": 6917, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 2010463, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:181,y:531,t:1526918903658};\\\", \\\"{x:183,y:523,t:1526918903674};\\\", \\\"{x:186,y:515,t:1526918903680};\\\", \\\"{x:198,y:483,t:1526918903696};\\\", \\\"{x:216,y:439,t:1526918903715};\\\", \\\"{x:240,y:388,t:1526918903732};\\\", \\\"{x:264,y:340,t:1526918903748};\\\", \\\"{x:280,y:312,t:1526918903765};\\\", \\\"{x:299,y:286,t:1526918903781};\\\", \\\"{x:309,y:276,t:1526918903798};\\\", \\\"{x:316,y:271,t:1526918903813};\\\", \\\"{x:322,y:267,t:1526918903831};\\\", \\\"{x:330,y:265,t:1526918903848};\\\", \\\"{x:341,y:265,t:1526918903863};\\\", \\\"{x:355,y:265,t:1526918903880};\\\", \\\"{x:380,y:272,t:1526918903897};\\\", \\\"{x:391,y:277,t:1526918903913};\\\", \\\"{x:401,y:282,t:1526918903932};\\\", \\\"{x:408,y:287,t:1526918903947};\\\", \\\"{x:413,y:290,t:1526918903964};\\\", \\\"{x:417,y:292,t:1526918903980};\\\", \\\"{x:421,y:295,t:1526918903997};\\\", \\\"{x:423,y:296,t:1526918904015};\\\", \\\"{x:426,y:296,t:1526918904306};\\\", \\\"{x:432,y:296,t:1526918904314};\\\", \\\"{x:450,y:302,t:1526918904330};\\\", \\\"{x:487,y:315,t:1526918904348};\\\", \\\"{x:559,y:339,t:1526918904364};\\\", \\\"{x:644,y:364,t:1526918904381};\\\", \\\"{x:697,y:382,t:1526918904397};\\\", \\\"{x:753,y:401,t:1526918904414};\\\", \\\"{x:780,y:415,t:1526918904432};\\\", \\\"{x:799,y:426,t:1526918904447};\\\", \\\"{x:815,y:437,t:1526918904465};\\\", \\\"{x:820,y:442,t:1526918904480};\\\", \\\"{x:820,y:442,t:1526918904860};\\\", \\\"{x:822,y:445,t:1526918904868};\\\", \\\"{x:825,y:450,t:1526918904881};\\\", \\\"{x:850,y:480,t:1526918904897};\\\", \\\"{x:893,y:524,t:1526918904914};\\\", \\\"{x:953,y:586,t:1526918904931};\\\", \\\"{x:1011,y:649,t:1526918904947};\\\", \\\"{x:1054,y:697,t:1526918904963};\\\", \\\"{x:1071,y:713,t:1526918904981};\\\", \\\"{x:1080,y:721,t:1526918904997};\\\", \\\"{x:1087,y:727,t:1526918905014};\\\", \\\"{x:1089,y:730,t:1526918905031};\\\", \\\"{x:1090,y:730,t:1526918905048};\\\", \\\"{x:1090,y:731,t:1526918905064};\\\", \\\"{x:1090,y:731,t:1526918905081};\\\", \\\"{x:1089,y:731,t:1526918905097};\\\", \\\"{x:1089,y:731,t:1526918905114};\\\", \\\"{x:1089,y:731,t:1526918905132};\\\", \\\"{x:1089,y:731,t:1526918905147};\\\", \\\"{x:1088,y:732,t:1526918905163};\\\", \\\"{x:1086,y:733,t:1526918905179};\\\", \\\"{x:1083,y:733,t:1526918905197};\\\", \\\"{x:1081,y:734,t:1526918905214};\\\", \\\"{x:1079,y:735,t:1526918905230};\\\", \\\"{x:1076,y:735,t:1526918905248};\\\", \\\"{x:1074,y:736,t:1526918905264};\\\", \\\"{x:1073,y:737,t:1526918905281};\\\", \\\"{x:1072,y:738,t:1526918905298};\\\", \\\"{x:1071,y:738,t:1526918905314};\\\", \\\"{x:1070,y:738,t:1526918905331};\\\", \\\"{x:1071,y:742,t:1526918905862};\\\", \\\"{x:1074,y:747,t:1526918905869};\\\", \\\"{x:1078,y:755,t:1526918905881};\\\", \\\"{x:1091,y:782,t:1526918905898};\\\", \\\"{x:1101,y:801,t:1526918905914};\\\", \\\"{x:1109,y:818,t:1526918905930};\\\", \\\"{x:1115,y:825,t:1526918905948};\\\", \\\"{x:1119,y:825,t:1526918905963};\\\", \\\"{x:1121,y:825,t:1526918905981};\\\", \\\"{x:1122,y:825,t:1526918905997};\\\", \\\"{x:1122,y:825,t:1526918906013};\\\", \\\"{x:1121,y:825,t:1526918906045};\\\", \\\"{x:1120,y:825,t:1526918906053};\\\", \\\"{x:1118,y:823,t:1526918906065};\\\", \\\"{x:1113,y:816,t:1526918906080};\\\", \\\"{x:1106,y:804,t:1526918906097};\\\", \\\"{x:1100,y:787,t:1526918906114};\\\", \\\"{x:1097,y:774,t:1526918906131};\\\", \\\"{x:1095,y:764,t:1526918906149};\\\", \\\"{x:1094,y:756,t:1526918906165};\\\", \\\"{x:1094,y:750,t:1526918906181};\\\", \\\"{x:1094,y:747,t:1526918906197};\\\", \\\"{x:1097,y:745,t:1526918906214};\\\", \\\"{x:1105,y:744,t:1526918906230};\\\", \\\"{x:1116,y:744,t:1526918906248};\\\", \\\"{x:1126,y:747,t:1526918906264};\\\", \\\"{x:1134,y:751,t:1526918906281};\\\", \\\"{x:1143,y:755,t:1526918906298};\\\", \\\"{x:1150,y:759,t:1526918906314};\\\", \\\"{x:1155,y:760,t:1526918906331};\\\", \\\"{x:1161,y:762,t:1526918906348};\\\", \\\"{x:1164,y:763,t:1526918906364};\\\", \\\"{x:1166,y:764,t:1526918906380};\\\", \\\"{x:1167,y:764,t:1526918906398};\\\", \\\"{x:1168,y:765,t:1526918906414};\\\", \\\"{x:1168,y:766,t:1526918906430};\\\", \\\"{x:1168,y:766,t:1526918906446};\\\", \\\"{x:1168,y:767,t:1526918906463};\\\", \\\"{x:1168,y:767,t:1526918906480};\\\", \\\"{x:1169,y:768,t:1526918906498};\\\", \\\"{x:1169,y:768,t:1526918906525};\\\", \\\"{x:1169,y:768,t:1526918906533};\\\", \\\"{x:1169,y:768,t:1526918906547};\\\", \\\"{x:1170,y:767,t:1526918906565};\\\", \\\"{x:1171,y:766,t:1526918906580};\\\", \\\"{x:1172,y:765,t:1526918906597};\\\", \\\"{x:1174,y:763,t:1526918906614};\\\", \\\"{x:1176,y:760,t:1526918906630};\\\", \\\"{x:1177,y:759,t:1526918906646};\\\", \\\"{x:1178,y:758,t:1526918906664};\\\", \\\"{x:1178,y:757,t:1526918906681};\\\", \\\"{x:1179,y:757,t:1526918906697};\\\", \\\"{x:1179,y:757,t:1526918906714};\\\", \\\"{x:1179,y:756,t:1526918906731};\\\", \\\"{x:1179,y:756,t:1526918906749};\\\", \\\"{x:1179,y:756,t:1526918906773};\\\", \\\"{x:1179,y:756,t:1526918906782};\\\", \\\"{x:1179,y:755,t:1526918906797};\\\", \\\"{x:1178,y:754,t:1526918906814};\\\", \\\"{x:1176,y:752,t:1526918906830};\\\", \\\"{x:1172,y:746,t:1526918906847};\\\", \\\"{x:1169,y:741,t:1526918906863};\\\", \\\"{x:1164,y:734,t:1526918906881};\\\", \\\"{x:1159,y:728,t:1526918906897};\\\", \\\"{x:1154,y:722,t:1526918906914};\\\", \\\"{x:1150,y:716,t:1526918906931};\\\", \\\"{x:1146,y:710,t:1526918906948};\\\", \\\"{x:1144,y:705,t:1526918906965};\\\", \\\"{x:1141,y:700,t:1526918906982};\\\", \\\"{x:1139,y:698,t:1526918906997};\\\", \\\"{x:1136,y:693,t:1526918907013};\\\", \\\"{x:1134,y:689,t:1526918907031};\\\", \\\"{x:1132,y:685,t:1526918907047};\\\", \\\"{x:1127,y:672,t:1526918907064};\\\", \\\"{x:1125,y:662,t:1526918907082};\\\", \\\"{x:1123,y:649,t:1526918907097};\\\", \\\"{x:1122,y:640,t:1526918907114};\\\", \\\"{x:1121,y:634,t:1526918907131};\\\", \\\"{x:1120,y:630,t:1526918907148};\\\", \\\"{x:1120,y:627,t:1526918907164};\\\", \\\"{x:1120,y:627,t:1526918907388};\\\", \\\"{x:1118,y:626,t:1526918907397};\\\", \\\"{x:1113,y:620,t:1526918907414};\\\", \\\"{x:1107,y:613,t:1526918907430};\\\", \\\"{x:1101,y:607,t:1526918907447};\\\", \\\"{x:1095,y:601,t:1526918907464};\\\", \\\"{x:1091,y:596,t:1526918907480};\\\", \\\"{x:1088,y:593,t:1526918907497};\\\", \\\"{x:1086,y:590,t:1526918907514};\\\", \\\"{x:1084,y:588,t:1526918907532};\\\", \\\"{x:1082,y:586,t:1526918907548};\\\", \\\"{x:1081,y:585,t:1526918907564};\\\", \\\"{x:1079,y:582,t:1526918907581};\\\", \\\"{x:1078,y:580,t:1526918907597};\\\", \\\"{x:1077,y:577,t:1526918907614};\\\", \\\"{x:1076,y:575,t:1526918907631};\\\", \\\"{x:1074,y:572,t:1526918907647};\\\", \\\"{x:1072,y:569,t:1526918907663};\\\", \\\"{x:1070,y:564,t:1526918907681};\\\", \\\"{x:1066,y:555,t:1526918907698};\\\", \\\"{x:1061,y:543,t:1526918907715};\\\", \\\"{x:1056,y:533,t:1526918907731};\\\", \\\"{x:1048,y:517,t:1526918907748};\\\", \\\"{x:1042,y:510,t:1526918907764};\\\", \\\"{x:1033,y:497,t:1526918907781};\\\", \\\"{x:1022,y:480,t:1526918907797};\\\", \\\"{x:1018,y:471,t:1526918907813};\\\", \\\"{x:1013,y:459,t:1526918907831};\\\", \\\"{x:1010,y:447,t:1526918907848};\\\", \\\"{x:1007,y:437,t:1526918907864};\\\", \\\"{x:1005,y:428,t:1526918907882};\\\", \\\"{x:1004,y:423,t:1526918907898};\\\", \\\"{x:1003,y:419,t:1526918907914};\\\", \\\"{x:1002,y:416,t:1526918907931};\\\", \\\"{x:1001,y:414,t:1526918907949};\\\", \\\"{x:999,y:411,t:1526918907964};\\\", \\\"{x:998,y:408,t:1526918907981};\\\", \\\"{x:995,y:405,t:1526918907997};\\\", \\\"{x:992,y:401,t:1526918908014};\\\", \\\"{x:989,y:397,t:1526918908031};\\\", \\\"{x:986,y:395,t:1526918908047};\\\", \\\"{x:983,y:392,t:1526918908065};\\\", \\\"{x:979,y:389,t:1526918908081};\\\", \\\"{x:978,y:387,t:1526918908098};\\\", \\\"{x:975,y:383,t:1526918908114};\\\", \\\"{x:974,y:379,t:1526918908131};\\\", \\\"{x:973,y:375,t:1526918908148};\\\", \\\"{x:973,y:373,t:1526918908165};\\\", \\\"{x:972,y:373,t:1526918908401};\\\", \\\"{x:964,y:373,t:1526918908414};\\\", \\\"{x:887,y:367,t:1526918908430};\\\", \\\"{x:778,y:358,t:1526918908447};\\\", \\\"{x:649,y:350,t:1526918908464};\\\", \\\"{x:563,y:350,t:1526918908481};\\\", \\\"{x:472,y:350,t:1526918908499};\\\", \\\"{x:424,y:350,t:1526918908514};\\\", \\\"{x:375,y:350,t:1526918908530};\\\", \\\"{x:350,y:350,t:1526918908548};\\\", \\\"{x:328,y:348,t:1526918908566};\\\", \\\"{x:318,y:348,t:1526918908581};\\\", \\\"{x:314,y:348,t:1526918908597};\\\", \\\"{x:314,y:348,t:1526918908792};\\\", \\\"{x:312,y:348,t:1526918908801};\\\", \\\"{x:310,y:349,t:1526918908814};\\\", \\\"{x:306,y:351,t:1526918908830};\\\", \\\"{x:303,y:352,t:1526918908847};\\\", \\\"{x:287,y:360,t:1526918908865};\\\", \\\"{x:275,y:363,t:1526918908881};\\\", \\\"{x:263,y:366,t:1526918908897};\\\", \\\"{x:248,y:368,t:1526918908913};\\\", \\\"{x:235,y:371,t:1526918908931};\\\", \\\"{x:218,y:376,t:1526918908948};\\\", \\\"{x:209,y:379,t:1526918908964};\\\", \\\"{x:198,y:382,t:1526918908981};\\\", \\\"{x:187,y:384,t:1526918908998};\\\", \\\"{x:177,y:384,t:1526918909016};\\\", \\\"{x:168,y:384,t:1526918909030};\\\", \\\"{x:161,y:384,t:1526918909048};\\\", \\\"{x:150,y:382,t:1526918909064};\\\", \\\"{x:143,y:381,t:1526918909080};\\\", \\\"{x:138,y:380,t:1526918909097};\\\", \\\"{x:132,y:378,t:1526918909113};\\\", \\\"{x:128,y:376,t:1526918909130};\\\", \\\"{x:125,y:375,t:1526918909148};\\\", \\\"{x:123,y:373,t:1526918909164};\\\", \\\"{x:121,y:373,t:1526918909180};\\\", \\\"{x:120,y:373,t:1526918909199};\\\", \\\"{x:119,y:372,t:1526918909215};\\\", \\\"{x:119,y:372,t:1526918909234};\\\", \\\"{x:123,y:374,t:1526918909489};\\\", \\\"{x:131,y:378,t:1526918909497};\\\", \\\"{x:153,y:393,t:1526918909515};\\\", \\\"{x:179,y:413,t:1526918909531};\\\", \\\"{x:211,y:445,t:1526918909548};\\\", \\\"{x:234,y:465,t:1526918909565};\\\", \\\"{x:255,y:488,t:1526918909581};\\\", \\\"{x:269,y:504,t:1526918909598};\\\", \\\"{x:280,y:518,t:1526918909617};\\\", \\\"{x:292,y:531,t:1526918909630};\\\", \\\"{x:300,y:538,t:1526918909647};\\\", \\\"{x:306,y:544,t:1526918909664};\\\", \\\"{x:311,y:549,t:1526918909681};\\\", \\\"{x:314,y:551,t:1526918909698};\\\", \\\"{x:314,y:552,t:1526918909714};\\\", \\\"{x:315,y:552,t:1526918909731};\\\", \\\"{x:315,y:551,t:1526918909794};\\\", \\\"{x:315,y:551,t:1526918909802};\\\", \\\"{x:315,y:550,t:1526918909814};\\\", \\\"{x:313,y:548,t:1526918909830};\\\", \\\"{x:311,y:545,t:1526918909848};\\\", \\\"{x:308,y:542,t:1526918909864};\\\", \\\"{x:304,y:538,t:1526918909882};\\\", \\\"{x:302,y:536,t:1526918909897};\\\", \\\"{x:299,y:533,t:1526918909914};\\\", \\\"{x:297,y:531,t:1526918909930};\\\", \\\"{x:295,y:530,t:1526918909947};\\\", \\\"{x:294,y:529,t:1526918909964};\\\", \\\"{x:294,y:529,t:1526918909977};\\\" ] }, { \\\"rt\\\": 7063, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 2018801, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:294,y:525,t:1526918911595};\\\", \\\"{x:292,y:507,t:1526918911615};\\\", \\\"{x:287,y:477,t:1526918911631};\\\", \\\"{x:274,y:407,t:1526918911649};\\\", \\\"{x:236,y:145,t:1526918911835};\\\", \\\"{x:236,y:145,t:1526918911850};\\\", \\\"{x:236,y:146,t:1526918911865};\\\", \\\"{x:236,y:149,t:1526918911882};\\\", \\\"{x:235,y:160,t:1526918911898};\\\", \\\"{x:235,y:169,t:1526918911915};\\\", \\\"{x:235,y:190,t:1526918911931};\\\", \\\"{x:235,y:201,t:1526918911949};\\\", \\\"{x:235,y:206,t:1526918911965};\\\", \\\"{x:235,y:211,t:1526918911981};\\\", \\\"{x:235,y:213,t:1526918911998};\\\", \\\"{x:235,y:214,t:1526918912015};\\\", \\\"{x:235,y:215,t:1526918912032};\\\", \\\"{x:235,y:215,t:1526918912048};\\\", \\\"{x:235,y:215,t:1526918912065};\\\", \\\"{x:235,y:216,t:1526918912082};\\\", \\\"{x:235,y:216,t:1526918912098};\\\", \\\"{x:235,y:216,t:1526918912114};\\\", \\\"{x:235,y:217,t:1526918912131};\\\", \\\"{x:235,y:219,t:1526918912149};\\\", \\\"{x:236,y:224,t:1526918912166};\\\", \\\"{x:239,y:231,t:1526918912181};\\\", \\\"{x:242,y:237,t:1526918912198};\\\", \\\"{x:245,y:241,t:1526918912215};\\\", \\\"{x:247,y:244,t:1526918912232};\\\", \\\"{x:249,y:246,t:1526918912248};\\\", \\\"{x:249,y:247,t:1526918912265};\\\", \\\"{x:250,y:247,t:1526918912282};\\\", \\\"{x:368,y:247,t:1526918914233};\\\", \\\"{x:371,y:247,t:1526918914248};\\\", \\\"{x:395,y:250,t:1526918914265};\\\", \\\"{x:434,y:257,t:1526918914281};\\\", \\\"{x:489,y:266,t:1526918914298};\\\", \\\"{x:559,y:276,t:1526918914315};\\\", \\\"{x:631,y:284,t:1526918914331};\\\", \\\"{x:700,y:289,t:1526918914348};\\\", \\\"{x:740,y:292,t:1526918914365};\\\", \\\"{x:783,y:296,t:1526918914382};\\\", \\\"{x:813,y:302,t:1526918914398};\\\", \\\"{x:833,y:307,t:1526918914416};\\\", \\\"{x:843,y:312,t:1526918914431};\\\", \\\"{x:849,y:314,t:1526918914448};\\\", \\\"{x:851,y:315,t:1526918914465};\\\", \\\"{x:851,y:315,t:1526918914722};\\\", \\\"{x:853,y:315,t:1526918914732};\\\", \\\"{x:859,y:314,t:1526918914748};\\\", \\\"{x:868,y:311,t:1526918914765};\\\", \\\"{x:877,y:307,t:1526918914782};\\\", \\\"{x:886,y:305,t:1526918914799};\\\", \\\"{x:891,y:303,t:1526918914814};\\\", \\\"{x:895,y:302,t:1526918914832};\\\", \\\"{x:897,y:302,t:1526918914849};\\\", \\\"{x:898,y:302,t:1526918914865};\\\", \\\"{x:899,y:302,t:1526918914882};\\\", \\\"{x:898,y:302,t:1526918914947};\\\", \\\"{x:898,y:302,t:1526918914954};\\\", \\\"{x:897,y:301,t:1526918914966};\\\", \\\"{x:895,y:301,t:1526918914982};\\\", \\\"{x:893,y:301,t:1526918914999};\\\", \\\"{x:890,y:300,t:1526918915016};\\\", \\\"{x:887,y:300,t:1526918915032};\\\", \\\"{x:885,y:300,t:1526918915051};\\\", \\\"{x:883,y:300,t:1526918915065};\\\", \\\"{x:882,y:300,t:1526918915082};\\\", \\\"{x:881,y:300,t:1526918915098};\\\", \\\"{x:881,y:300,t:1526918915116};\\\", \\\"{x:881,y:302,t:1526918915370};\\\", \\\"{x:881,y:307,t:1526918915382};\\\", \\\"{x:881,y:317,t:1526918915399};\\\", \\\"{x:880,y:331,t:1526918915415};\\\", \\\"{x:879,y:364,t:1526918915431};\\\", \\\"{x:879,y:423,t:1526918915448};\\\", \\\"{x:879,y:449,t:1526918915465};\\\", \\\"{x:879,y:474,t:1526918915482};\\\", \\\"{x:879,y:493,t:1526918915499};\\\", \\\"{x:878,y:505,t:1526918915515};\\\", \\\"{x:878,y:516,t:1526918915532};\\\", \\\"{x:877,y:526,t:1526918915549};\\\", \\\"{x:877,y:535,t:1526918915566};\\\", \\\"{x:877,y:544,t:1526918915583};\\\", \\\"{x:877,y:549,t:1526918915600};\\\", \\\"{x:877,y:554,t:1526918915615};\\\", \\\"{x:876,y:556,t:1526918915631};\\\", \\\"{x:875,y:558,t:1526918915648};\\\", \\\"{x:873,y:558,t:1526918915665};\\\", \\\"{x:861,y:556,t:1526918915683};\\\", \\\"{x:834,y:550,t:1526918915699};\\\", \\\"{x:784,y:542,t:1526918915715};\\\", \\\"{x:714,y:536,t:1526918915732};\\\", \\\"{x:640,y:536,t:1526918915749};\\\", \\\"{x:596,y:536,t:1526918915765};\\\", \\\"{x:567,y:537,t:1526918915782};\\\", \\\"{x:538,y:538,t:1526918915800};\\\", \\\"{x:536,y:538,t:1526918916018};\\\", \\\"{x:530,y:537,t:1526918916032};\\\", \\\"{x:508,y:527,t:1526918916048};\\\", \\\"{x:482,y:508,t:1526918916064};\\\", \\\"{x:431,y:467,t:1526918916083};\\\", \\\"{x:417,y:457,t:1526918916099};\\\", \\\"{x:403,y:448,t:1526918916115};\\\", \\\"{x:392,y:443,t:1526918916133};\\\", \\\"{x:388,y:441,t:1526918916148};\\\", \\\"{x:387,y:441,t:1526918916165};\\\", \\\"{x:387,y:440,t:1526918916182};\\\", \\\"{x:387,y:439,t:1526918916199};\\\", \\\"{x:387,y:438,t:1526918916215};\\\", \\\"{x:387,y:434,t:1526918916234};\\\", \\\"{x:385,y:425,t:1526918916248};\\\", \\\"{x:372,y:407,t:1526918916265};\\\", \\\"{x:346,y:365,t:1526918916282};\\\", \\\"{x:331,y:343,t:1526918916300};\\\", \\\"{x:321,y:330,t:1526918916316};\\\", \\\"{x:309,y:319,t:1526918916332};\\\", \\\"{x:304,y:316,t:1526918916348};\\\", \\\"{x:298,y:314,t:1526918916365};\\\", \\\"{x:292,y:313,t:1526918916382};\\\", \\\"{x:287,y:311,t:1526918916399};\\\", \\\"{x:284,y:309,t:1526918916416};\\\", \\\"{x:280,y:308,t:1526918916432};\\\", \\\"{x:276,y:307,t:1526918916448};\\\", \\\"{x:273,y:307,t:1526918916464};\\\", \\\"{x:270,y:307,t:1526918916481};\\\", \\\"{x:269,y:307,t:1526918916498};\\\", \\\"{x:268,y:307,t:1526918916514};\\\", \\\"{x:267,y:309,t:1526918916533};\\\", \\\"{x:265,y:309,t:1526918916550};\\\", \\\"{x:264,y:310,t:1526918916565};\\\", \\\"{x:263,y:310,t:1526918916582};\\\", \\\"{x:262,y:310,t:1526918916599};\\\", \\\"{x:262,y:310,t:1526918916615};\\\", \\\"{x:261,y:311,t:1526918916634};\\\", \\\"{x:261,y:311,t:1526918916648};\\\", \\\"{x:261,y:311,t:1526918916665};\\\", \\\"{x:263,y:312,t:1526918916955};\\\", \\\"{x:265,y:316,t:1526918916965};\\\", \\\"{x:269,y:325,t:1526918916983};\\\", \\\"{x:274,y:343,t:1526918917000};\\\", \\\"{x:281,y:372,t:1526918917017};\\\", \\\"{x:290,y:403,t:1526918917033};\\\", \\\"{x:298,y:433,t:1526918917050};\\\", \\\"{x:306,y:459,t:1526918917067};\\\", \\\"{x:309,y:476,t:1526918917083};\\\", \\\"{x:311,y:494,t:1526918917098};\\\", \\\"{x:313,y:508,t:1526918917115};\\\", \\\"{x:314,y:519,t:1526918917132};\\\", \\\"{x:314,y:525,t:1526918917149};\\\", \\\"{x:314,y:530,t:1526918917167};\\\", \\\"{x:314,y:541,t:1526918917199};\\\", \\\"{x:313,y:547,t:1526918917216};\\\", \\\"{x:312,y:552,t:1526918917232};\\\", \\\"{x:311,y:555,t:1526918917249};\\\", \\\"{x:310,y:557,t:1526918917266};\\\", \\\"{x:310,y:558,t:1526918917282};\\\", \\\"{x:310,y:558,t:1526918917299};\\\", \\\"{x:310,y:558,t:1526918917314};\\\", \\\"{x:309,y:558,t:1526918917332};\\\", \\\"{x:308,y:558,t:1526918917348};\\\", \\\"{x:307,y:558,t:1526918917365};\\\", \\\"{x:307,y:556,t:1526918917382};\\\", \\\"{x:306,y:555,t:1526918917399};\\\", \\\"{x:305,y:554,t:1526918917416};\\\", \\\"{x:304,y:553,t:1526918917432};\\\", \\\"{x:302,y:551,t:1526918917449};\\\", \\\"{x:301,y:549,t:1526918917466};\\\", \\\"{x:299,y:548,t:1526918917482};\\\", \\\"{x:298,y:547,t:1526918917499};\\\", \\\"{x:297,y:546,t:1526918917515};\\\", \\\"{x:297,y:545,t:1526918917532};\\\", \\\"{x:296,y:545,t:1526918917548};\\\", \\\"{x:296,y:544,t:1526918917564};\\\", \\\"{x:296,y:544,t:1526918917582};\\\", \\\"{x:296,y:544,t:1526918917757};\\\", \\\"{x:296,y:544,t:1526918917773};\\\", \\\"{x:296,y:545,t:1526918917788};\\\", \\\"{x:297,y:545,t:1526918917837};\\\", \\\"{x:297,y:545,t:1526918918038};\\\", \\\"{x:297,y:545,t:1526918918049};\\\", \\\"{x:297,y:544,t:1526918918066};\\\", \\\"{x:297,y:544,t:1526918918086};\\\", \\\"{x:297,y:544,t:1526918918099};\\\", \\\"{x:298,y:544,t:1526918918149};\\\", \\\"{x:298,y:544,t:1526918918215};\\\", \\\"{x:298,y:543,t:1526918918262};\\\", \\\"{x:297,y:543,t:1526918918278};\\\" ] }, { \\\"rt\\\": -5954, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 2014099, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:295,y:332,t:1526918920261};\\\", \\\"{x:309,y:328,t:1526918920268};\\\", \\\"{x:358,y:325,t:1526918920304};\\\", \\\"{x:370,y:325,t:1526918920315};\\\", \\\"{x:381,y:328,t:1526918920332};\\\", \\\"{x:388,y:331,t:1526918920350};\\\", \\\"{x:394,y:333,t:1526918920365};\\\", \\\"{x:401,y:336,t:1526918920383};\\\", \\\"{x:526,y:338,t:1526918921450};\\\", \\\"{x:537,y:341,t:1526918921466};\\\", \\\"{x:565,y:346,t:1526918921483};\\\", \\\"{x:607,y:351,t:1526918921499};\\\", \\\"{x:637,y:353,t:1526918921515};\\\", \\\"{x:670,y:353,t:1526918921533};\\\", \\\"{x:686,y:353,t:1526918921550};\\\", \\\"{x:700,y:349,t:1526918921566};\\\", \\\"{x:706,y:347,t:1526918921585};\\\", \\\"{x:711,y:346,t:1526918921600};\\\", \\\"{x:712,y:345,t:1526918921616};\\\", \\\"{x:713,y:345,t:1526918921632};\\\", \\\"{x:713,y:345,t:1526918921648};\\\", \\\"{x:713,y:346,t:1526918921674};\\\", \\\"{x:713,y:347,t:1526918921683};\\\", \\\"{x:707,y:354,t:1526918921699};\\\", \\\"{x:699,y:361,t:1526918921717};\\\", \\\"{x:691,y:367,t:1526918921733};\\\", \\\"{x:685,y:371,t:1526918921750};\\\", \\\"{x:679,y:375,t:1526918921766};\\\", \\\"{x:676,y:376,t:1526918921783};\\\", \\\"{x:675,y:377,t:1526918921800};\\\", \\\"{x:674,y:377,t:1526918921816};\\\", \\\"{x:674,y:376,t:1526918921842};\\\", \\\"{x:674,y:376,t:1526918921850};\\\", \\\"{x:674,y:376,t:1526918921865};\\\", \\\"{x:674,y:374,t:1526918921883};\\\", \\\"{x:675,y:372,t:1526918921900};\\\", \\\"{x:678,y:370,t:1526918921915};\\\", \\\"{x:687,y:365,t:1526918921933};\\\", \\\"{x:701,y:361,t:1526918921949};\\\", \\\"{x:737,y:354,t:1526918921967};\\\", \\\"{x:783,y:352,t:1526918921982};\\\", \\\"{x:840,y:352,t:1526918922000};\\\", \\\"{x:880,y:360,t:1526918922017};\\\", \\\"{x:905,y:369,t:1526918922033};\\\", \\\"{x:912,y:373,t:1526918922050};\\\", \\\"{x:925,y:378,t:1526918922066};\\\", \\\"{x:928,y:380,t:1526918922083};\\\", \\\"{x:928,y:381,t:1526918922100};\\\", \\\"{x:927,y:381,t:1526918922179};\\\", \\\"{x:926,y:381,t:1526918922186};\\\", \\\"{x:924,y:380,t:1526918922200};\\\", \\\"{x:919,y:379,t:1526918922217};\\\", \\\"{x:913,y:379,t:1526918922233};\\\", \\\"{x:902,y:379,t:1526918922249};\\\", \\\"{x:885,y:379,t:1526918922267};\\\", \\\"{x:865,y:380,t:1526918922283};\\\", \\\"{x:809,y:383,t:1526918922299};\\\", \\\"{x:769,y:388,t:1526918922316};\\\", \\\"{x:717,y:397,t:1526918922333};\\\", \\\"{x:659,y:409,t:1526918922351};\\\", \\\"{x:598,y:415,t:1526918922366};\\\", \\\"{x:543,y:416,t:1526918922383};\\\", \\\"{x:509,y:416,t:1526918922400};\\\", \\\"{x:484,y:414,t:1526918922417};\\\", \\\"{x:459,y:412,t:1526918922435};\\\", \\\"{x:440,y:412,t:1526918922449};\\\", \\\"{x:427,y:412,t:1526918922466};\\\", \\\"{x:421,y:411,t:1526918922484};\\\", \\\"{x:417,y:410,t:1526918922499};\\\", \\\"{x:311,y:407,t:1526918923149};\\\", \\\"{x:322,y:392,t:1526918923167};\\\", \\\"{x:334,y:376,t:1526918923187};\\\", \\\"{x:342,y:365,t:1526918923202};\\\", \\\"{x:352,y:353,t:1526918923216};\\\", \\\"{x:361,y:342,t:1526918923232};\\\", \\\"{x:365,y:338,t:1526918923250};\\\", \\\"{x:369,y:334,t:1526918923268};\\\", \\\"{x:372,y:330,t:1526918923283};\\\", \\\"{x:374,y:328,t:1526918923300};\\\", \\\"{x:375,y:326,t:1526918923316};\\\", \\\"{x:376,y:323,t:1526918923334};\\\", \\\"{x:376,y:323,t:1526918923349};\\\", \\\"{x:377,y:320,t:1526918923366};\\\", \\\"{x:377,y:319,t:1526918923383};\\\", \\\"{x:378,y:317,t:1526918923400};\\\", \\\"{x:378,y:316,t:1526918923416};\\\", \\\"{x:378,y:314,t:1526918923432};\\\", \\\"{x:378,y:311,t:1526918923449};\\\", \\\"{x:379,y:306,t:1526918923466};\\\", \\\"{x:380,y:303,t:1526918923482};\\\", \\\"{x:381,y:298,t:1526918923499};\\\", \\\"{x:382,y:296,t:1526918923517};\\\", \\\"{x:383,y:293,t:1526918923533};\\\", \\\"{x:385,y:291,t:1526918923550};\\\", \\\"{x:387,y:288,t:1526918923568};\\\", \\\"{x:388,y:287,t:1526918923583};\\\", \\\"{x:389,y:286,t:1526918923600};\\\", \\\"{x:390,y:286,t:1526918923616};\\\", \\\"{x:391,y:285,t:1526918923633};\\\", \\\"{x:391,y:285,t:1526918923650};\\\", \\\"{x:391,y:285,t:1526918923667};\\\", \\\"{x:392,y:285,t:1526918923683};\\\", \\\"{x:392,y:286,t:1526918923916};\\\", \\\"{x:388,y:292,t:1526918923934};\\\", \\\"{x:382,y:297,t:1526918923950};\\\", \\\"{x:374,y:304,t:1526918923967};\\\", \\\"{x:362,y:313,t:1526918923982};\\\", \\\"{x:347,y:325,t:1526918923999};\\\", \\\"{x:331,y:335,t:1526918924019};\\\", \\\"{x:317,y:341,t:1526918924034};\\\", \\\"{x:307,y:346,t:1526918924049};\\\", \\\"{x:296,y:349,t:1526918924065};\\\", \\\"{x:287,y:351,t:1526918924083};\\\", \\\"{x:279,y:352,t:1526918924099};\\\", \\\"{x:275,y:353,t:1526918924117};\\\", \\\"{x:272,y:353,t:1526918924133};\\\", \\\"{x:269,y:353,t:1526918924149};\\\", \\\"{x:266,y:353,t:1526918924166};\\\", \\\"{x:264,y:353,t:1526918924183};\\\", \\\"{x:262,y:353,t:1526918924200};\\\", \\\"{x:259,y:353,t:1526918912277};\\\", \\\"{x:258,y:353,t:1526918912474};\\\", \\\"{x:258,y:354,t:1526918912558};\\\", \\\"{x:266,y:374,t:1526918912576};\\\", \\\"{x:283,y:419,t:1526918912601};\\\", \\\"{x:289,y:434,t:1526918912608};\\\", \\\"{x:300,y:464,t:1526918912625};\\\", \\\"{x:306,y:484,t:1526918912646};\\\", \\\"{x:312,y:502,t:1526918912656};\\\", \\\"{x:317,y:513,t:1526918912672};\\\", \\\"{x:322,y:521,t:1526918912690};\\\", \\\"{x:325,y:526,t:1526918912709};\\\", \\\"{x:327,y:528,t:1526918912725};\\\", \\\"{x:328,y:530,t:1526918912741};\\\", \\\"{x:329,y:530,t:1526918912756};\\\", \\\"{x:329,y:530,t:1526918912772};\\\", \\\"{x:329,y:530,t:1526918912790};\\\", \\\"{x:329,y:529,t:1526918912807};\\\", \\\"{x:329,y:528,t:1526918912822};\\\", \\\"{x:330,y:528,t:1526918912839};\\\", \\\"{x:330,y:528,t:1526918912901};\\\", \\\"{x:330,y:528,t:1526918912909};\\\", \\\"{x:330,y:529,t:1526918912922};\\\", \\\"{x:329,y:532,t:1526918912944};\\\", \\\"{x:328,y:533,t:1526918912962};\\\", \\\"{x:323,y:538,t:1526918912976};\\\", \\\"{x:315,y:544,t:1526918912991};\\\", \\\"{x:310,y:548,t:1526918913007};\\\", \\\"{x:309,y:549,t:1526918913023};\\\", \\\"{x:304,y:553,t:1526918913039};\\\", \\\"{x:301,y:555,t:1526918913056};\\\", \\\"{x:299,y:557,t:1526918913073};\\\", \\\"{x:298,y:558,t:1526918913089};\\\", \\\"{x:297,y:558,t:1526918913105};\\\", \\\"{x:297,y:558,t:1526918913122};\\\", \\\"{x:297,y:558,t:1526918913140};\\\", \\\"{x:297,y:558,t:1526918913156};\\\", \\\"{x:297,y:557,t:1526918913173};\\\", \\\"{x:296,y:556,t:1526918913190};\\\", \\\"{x:296,y:555,t:1526918913207};\\\", \\\"{x:295,y:554,t:1526918913222};\\\", \\\"{x:295,y:553,t:1526918913240};\\\", \\\"{x:294,y:552,t:1526918913256};\\\", \\\"{x:294,y:552,t:1526918913272};\\\", \\\"{x:293,y:551,t:1526918913290};\\\", \\\"{x:292,y:551,t:1526918913306};\\\", \\\"{x:292,y:551,t:1526918913322};\\\", \\\"{x:291,y:551,t:1526918913342};\\\", \\\"{x:291,y:551,t:1526918913356};\\\", \\\"{x:291,y:551,t:1526918913372};\\\", \\\"{x:290,y:551,t:1526918913390};\\\", \\\"{x:291,y:551,t:1526918913472};\\\", \\\"{x:291,y:551,t:1526918913478};\\\" ] }, { \\\"rt\\\": 25788, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 2041133, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -J -J -J -J -M -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:280,y:548,t:1526918917720};\\\", \\\"{x:282,y:544,t:1526918917728};\\\", \\\"{x:286,y:536,t:1526918917741};\\\", \\\"{x:308,y:497,t:1526918917758};\\\", \\\"{x:341,y:446,t:1526918917773};\\\", \\\"{x:457,y:303,t:1526918917816};\\\", \\\"{x:466,y:293,t:1526918917824};\\\", \\\"{x:499,y:252,t:1526918917840};\\\", \\\"{x:511,y:236,t:1526918917856};\\\", \\\"{x:521,y:221,t:1526918917873};\\\", \\\"{x:527,y:212,t:1526918917890};\\\", \\\"{x:529,y:208,t:1526918917907};\\\", \\\"{x:532,y:205,t:1526918917923};\\\", \\\"{x:533,y:203,t:1526918917940};\\\", \\\"{x:533,y:202,t:1526918917957};\\\", \\\"{x:533,y:202,t:1526918917973};\\\", \\\"{x:551,y:205,t:1526918920812};\\\", \\\"{x:556,y:212,t:1526918920824};\\\", \\\"{x:577,y:247,t:1526918920841};\\\", \\\"{x:607,y:303,t:1526918920857};\\\", \\\"{x:639,y:373,t:1526918920874};\\\", \\\"{x:659,y:420,t:1526918920891};\\\", \\\"{x:681,y:472,t:1526918920908};\\\", \\\"{x:688,y:490,t:1526918920924};\\\", \\\"{x:695,y:507,t:1526918920940};\\\", \\\"{x:698,y:514,t:1526918920957};\\\", \\\"{x:699,y:519,t:1526918920973};\\\", \\\"{x:700,y:521,t:1526918920990};\\\", \\\"{x:700,y:521,t:1526918921007};\\\", \\\"{x:701,y:521,t:1526918921023};\\\", \\\"{x:701,y:521,t:1526918921040};\\\", \\\"{x:702,y:520,t:1526918921057};\\\", \\\"{x:703,y:517,t:1526918921090};\\\", \\\"{x:703,y:515,t:1526918921107};\\\", \\\"{x:703,y:510,t:1526918921124};\\\", \\\"{x:700,y:501,t:1526918921144};\\\", \\\"{x:697,y:493,t:1526918921157};\\\", \\\"{x:695,y:486,t:1526918921174};\\\", \\\"{x:693,y:480,t:1526918921190};\\\", \\\"{x:690,y:473,t:1526918921207};\\\", \\\"{x:688,y:469,t:1526918921224};\\\", \\\"{x:685,y:464,t:1526918921241};\\\", \\\"{x:681,y:458,t:1526918921258};\\\", \\\"{x:678,y:453,t:1526918921274};\\\", \\\"{x:676,y:448,t:1526918921291};\\\", \\\"{x:675,y:445,t:1526918921307};\\\", \\\"{x:674,y:443,t:1526918921324};\\\", \\\"{x:673,y:442,t:1526918921341};\\\", \\\"{x:673,y:441,t:1526918921358};\\\", \\\"{x:673,y:441,t:1526918921396};\\\", \\\"{x:673,y:441,t:1526918921412};\\\", \\\"{x:672,y:441,t:1526918921428};\\\", \\\"{x:672,y:441,t:1526918921441};\\\", \\\"{x:672,y:441,t:1526918921458};\\\", \\\"{x:671,y:441,t:1526918921475};\\\", \\\"{x:671,y:441,t:1526918921490};\\\", \\\"{x:670,y:441,t:1526918921507};\\\", \\\"{x:670,y:441,t:1526918921548};\\\", \\\"{x:670,y:441,t:1526918921556};\\\", \\\"{x:669,y:441,t:1526918921574};\\\", \\\"{x:669,y:441,t:1526918921591};\\\", \\\"{x:668,y:440,t:1526918921606};\\\", \\\"{x:668,y:440,t:1526918921625};\\\", \\\"{x:667,y:439,t:1526918921642};\\\", \\\"{x:667,y:439,t:1526918921658};\\\", \\\"{x:667,y:438,t:1526918921674};\\\", \\\"{x:666,y:437,t:1526918921691};\\\", \\\"{x:666,y:437,t:1526918921707};\\\", \\\"{x:665,y:437,t:1526918921723};\\\", \\\"{x:665,y:437,t:1526918921741};\\\", \\\"{x:666,y:437,t:1526918922791};\\\", \\\"{x:667,y:437,t:1526918922808};\\\", \\\"{x:672,y:437,t:1526918922824};\\\", \\\"{x:678,y:437,t:1526918922841};\\\", \\\"{x:686,y:437,t:1526918922858};\\\", \\\"{x:693,y:438,t:1526918922874};\\\", \\\"{x:700,y:439,t:1526918922891};\\\", \\\"{x:707,y:440,t:1526918922908};\\\", \\\"{x:712,y:442,t:1526918922925};\\\", \\\"{x:717,y:446,t:1526918922942};\\\", \\\"{x:721,y:452,t:1526918922958};\\\", \\\"{x:726,y:460,t:1526918922974};\\\", \\\"{x:730,y:468,t:1526918922990};\\\", \\\"{x:734,y:475,t:1526918923007};\\\", \\\"{x:737,y:482,t:1526918923024};\\\", \\\"{x:739,y:486,t:1526918923041};\\\", \\\"{x:739,y:490,t:1526918923057};\\\", \\\"{x:740,y:494,t:1526918923074};\\\", \\\"{x:740,y:496,t:1526918923091};\\\", \\\"{x:740,y:497,t:1526918923107};\\\", \\\"{x:740,y:498,t:1526918923125};\\\", \\\"{x:740,y:498,t:1526918923141};\\\", \\\"{x:741,y:498,t:1526918923158};\\\", \\\"{x:741,y:498,t:1526918923200};\\\", \\\"{x:741,y:498,t:1526918923209};\\\", \\\"{x:741,y:497,t:1526918923225};\\\", \\\"{x:741,y:497,t:1526918923241};\\\", \\\"{x:741,y:498,t:1526918923280};\\\", \\\"{x:741,y:500,t:1526918923291};\\\", \\\"{x:741,y:508,t:1526918923308};\\\", \\\"{x:741,y:519,t:1526918923324};\\\", \\\"{x:741,y:527,t:1526918923340};\\\", \\\"{x:741,y:535,t:1526918923358};\\\", \\\"{x:741,y:540,t:1526918923375};\\\", \\\"{x:741,y:543,t:1526918923391};\\\", \\\"{x:740,y:546,t:1526918923408};\\\", \\\"{x:740,y:548,t:1526918923423};\\\", \\\"{x:739,y:550,t:1526918923441};\\\", \\\"{x:739,y:552,t:1526918923457};\\\", \\\"{x:738,y:552,t:1526918923474};\\\", \\\"{x:738,y:553,t:1526918923490};\\\", \\\"{x:738,y:553,t:1526918923626};\\\", \\\"{x:738,y:554,t:1526918923641};\\\", \\\"{x:739,y:555,t:1526918923658};\\\", \\\"{x:740,y:556,t:1526918923674};\\\", \\\"{x:741,y:556,t:1526918923690};\\\", \\\"{x:741,y:557,t:1526918923708};\\\", \\\"{x:741,y:558,t:1526918923724};\\\", \\\"{x:741,y:558,t:1526918923741};\\\", \\\"{x:741,y:558,t:1526918923758};\\\", \\\"{x:742,y:558,t:1526918923780};\\\", \\\"{x:742,y:559,t:1526918923827};\\\", \\\"{x:742,y:559,t:1526918923841};\\\", \\\"{x:742,y:559,t:1526918923857};\\\", \\\"{x:742,y:559,t:1526918923875};\\\", \\\"{x:742,y:560,t:1526918923891};\\\", \\\"{x:742,y:560,t:1526918923908};\\\", \\\"{x:742,y:560,t:1526918923923};\\\", \\\"{x:742,y:560,t:1526918923941};\\\", \\\"{x:742,y:560,t:1526918923958};\\\", \\\"{x:742,y:561,t:1526918923975};\\\", \\\"{x:742,y:561,t:1526918923994};\\\", \\\"{x:744,y:564,t:1526918925491};\\\", \\\"{x:752,y:579,t:1526918925509};\\\", \\\"{x:760,y:595,t:1526918925524};\\\", \\\"{x:770,y:616,t:1526918925541};\\\", \\\"{x:777,y:628,t:1526918925558};\\\", \\\"{x:782,y:636,t:1526918925574};\\\", \\\"{x:786,y:642,t:1526918925590};\\\", \\\"{x:788,y:645,t:1526918925607};\\\", \\\"{x:789,y:646,t:1526918925624};\\\", \\\"{x:789,y:647,t:1526918925640};\\\", \\\"{x:790,y:647,t:1526918925658};\\\", \\\"{x:790,y:646,t:1526918925689};\\\", \\\"{x:790,y:646,t:1526918925697};\\\", \\\"{x:790,y:645,t:1526918925707};\\\", \\\"{x:790,y:644,t:1526918925724};\\\", \\\"{x:790,y:642,t:1526918925740};\\\", \\\"{x:790,y:640,t:1526918925758};\\\", \\\"{x:790,y:637,t:1526918925775};\\\", \\\"{x:789,y:635,t:1526918925792};\\\", \\\"{x:787,y:631,t:1526918925808};\\\", \\\"{x:786,y:628,t:1526918925824};\\\", \\\"{x:784,y:626,t:1526918925841};\\\", \\\"{x:782,y:624,t:1526918925857};\\\", \\\"{x:780,y:623,t:1526918925875};\\\", \\\"{x:779,y:622,t:1526918925890};\\\", \\\"{x:778,y:622,t:1526918925908};\\\", \\\"{x:777,y:622,t:1526918925924};\\\", \\\"{x:777,y:622,t:1526918925941};\\\", \\\"{x:777,y:622,t:1526918925970};\\\", \\\"{x:777,y:622,t:1526918925978};\\\", \\\"{x:777,y:622,t:1526918925991};\\\", \\\"{x:777,y:623,t:1526918926007};\\\", \\\"{x:777,y:623,t:1526918926621};\\\", \\\"{x:778,y:624,t:1526918926628};\\\", \\\"{x:779,y:625,t:1526918926641};\\\", \\\"{x:780,y:626,t:1526918926658};\\\", \\\"{x:782,y:627,t:1526918926674};\\\", \\\"{x:783,y:627,t:1526918926691};\\\", \\\"{x:783,y:628,t:1526918926707};\\\", \\\"{x:785,y:628,t:1526918926724};\\\", \\\"{x:787,y:627,t:1526918926741};\\\", \\\"{x:791,y:625,t:1526918926758};\\\", \\\"{x:798,y:622,t:1526918926774};\\\", \\\"{x:811,y:618,t:1526918926790};\\\", \\\"{x:823,y:614,t:1526918926807};\\\", \\\"{x:839,y:609,t:1526918926824};\\\", \\\"{x:851,y:605,t:1526918926841};\\\", \\\"{x:864,y:600,t:1526918926858};\\\", \\\"{x:870,y:598,t:1526918926875};\\\", \\\"{x:876,y:596,t:1526918926891};\\\", \\\"{x:880,y:595,t:1526918926907};\\\", \\\"{x:882,y:594,t:1526918926924};\\\", \\\"{x:884,y:593,t:1526918926941};\\\", \\\"{x:885,y:592,t:1526918926958};\\\", \\\"{x:886,y:591,t:1526918926974};\\\", \\\"{x:888,y:589,t:1526918926991};\\\", \\\"{x:891,y:587,t:1526918927007};\\\", \\\"{x:893,y:585,t:1526918927024};\\\", \\\"{x:895,y:583,t:1526918927042};\\\", \\\"{x:896,y:581,t:1526918927059};\\\", \\\"{x:898,y:580,t:1526918927075};\\\", \\\"{x:898,y:579,t:1526918927091};\\\", \\\"{x:898,y:579,t:1526918927107};\\\", \\\"{x:898,y:579,t:1526918927197};\\\", \\\"{x:898,y:580,t:1526918927207};\\\", \\\"{x:897,y:580,t:1526918927225};\\\", \\\"{x:896,y:580,t:1526918927242};\\\", \\\"{x:895,y:580,t:1526918927259};\\\", \\\"{x:895,y:580,t:1526918927275};\\\", \\\"{x:894,y:580,t:1526918927292};\\\", \\\"{x:894,y:580,t:1526918927307};\\\", \\\"{x:893,y:580,t:1526918927325};\\\", \\\"{x:893,y:579,t:1526918927341};\\\", \\\"{x:892,y:578,t:1526918927357};\\\", \\\"{x:892,y:577,t:1526918927374};\\\", \\\"{x:892,y:575,t:1526918927391};\\\", \\\"{x:892,y:571,t:1526918927407};\\\", \\\"{x:892,y:566,t:1526918927424};\\\", \\\"{x:892,y:557,t:1526918927441};\\\", \\\"{x:896,y:542,t:1526918927458};\\\", \\\"{x:900,y:528,t:1526918927475};\\\", \\\"{x:904,y:520,t:1526918927492};\\\", \\\"{x:907,y:514,t:1526918927508};\\\", \\\"{x:908,y:510,t:1526918927525};\\\", \\\"{x:910,y:508,t:1526918927541};\\\", \\\"{x:910,y:508,t:1526918927557};\\\", \\\"{x:910,y:507,t:1526918927575};\\\", \\\"{x:910,y:507,t:1526918927590};\\\", \\\"{x:911,y:507,t:1526918927631};\\\", \\\"{x:911,y:507,t:1526918927654};\\\", \\\"{x:911,y:507,t:1526918927662};\\\", \\\"{x:911,y:506,t:1526918927675};\\\", \\\"{x:911,y:506,t:1526918927691};\\\", \\\"{x:911,y:505,t:1526918927708};\\\", \\\"{x:912,y:505,t:1526918927725};\\\", \\\"{x:912,y:505,t:1526918927741};\\\", \\\"{x:912,y:504,t:1526918927758};\\\", \\\"{x:912,y:505,t:1526918928308};\\\", \\\"{x:912,y:510,t:1526918928324};\\\", \\\"{x:911,y:522,t:1526918928341};\\\", \\\"{x:909,y:538,t:1526918928358};\\\", \\\"{x:907,y:553,t:1526918928375};\\\", \\\"{x:905,y:570,t:1526918928391};\\\", \\\"{x:904,y:578,t:1526918928408};\\\", \\\"{x:904,y:583,t:1526918928425};\\\", \\\"{x:904,y:586,t:1526918928442};\\\", \\\"{x:904,y:587,t:1526918928458};\\\", \\\"{x:904,y:587,t:1526918928474};\\\", \\\"{x:904,y:587,t:1526918928492};\\\", \\\"{x:905,y:587,t:1526918928507};\\\", \\\"{x:907,y:587,t:1526918928524};\\\", \\\"{x:908,y:587,t:1526918928541};\\\", \\\"{x:909,y:587,t:1526918928558};\\\", \\\"{x:909,y:587,t:1526918928575};\\\", \\\"{x:910,y:587,t:1526918928590};\\\", \\\"{x:910,y:586,t:1526918928608};\\\", \\\"{x:911,y:585,t:1526918928625};\\\", \\\"{x:911,y:583,t:1526918928641};\\\", \\\"{x:912,y:581,t:1526918928658};\\\", \\\"{x:912,y:579,t:1526918928676};\\\", \\\"{x:912,y:577,t:1526918928691};\\\", \\\"{x:912,y:574,t:1526918928708};\\\", \\\"{x:912,y:572,t:1526918928725};\\\", \\\"{x:913,y:570,t:1526918928741};\\\", \\\"{x:913,y:569,t:1526918928758};\\\", \\\"{x:913,y:569,t:1526918928775};\\\", \\\"{x:913,y:571,t:1526918929294};\\\", \\\"{x:914,y:572,t:1526918929309};\\\", \\\"{x:918,y:576,t:1526918929325};\\\", \\\"{x:921,y:578,t:1526918929342};\\\", \\\"{x:924,y:581,t:1526918929357};\\\", \\\"{x:926,y:584,t:1526918929374};\\\", \\\"{x:927,y:585,t:1526918929392};\\\", \\\"{x:928,y:585,t:1526918929408};\\\", \\\"{x:928,y:585,t:1526918929425};\\\", \\\"{x:928,y:585,t:1526918929462};\\\", \\\"{x:928,y:585,t:1526918929494};\\\", \\\"{x:928,y:586,t:1526918929509};\\\", \\\"{x:929,y:586,t:1526918929525};\\\", \\\"{x:929,y:586,t:1526918929541};\\\", \\\"{x:929,y:586,t:1526918929558};\\\", \\\"{x:929,y:586,t:1526918929574};\\\", \\\"{x:930,y:587,t:1526918929590};\\\", \\\"{x:930,y:587,t:1526918929615};\\\", \\\"{x:930,y:587,t:1526918929638};\\\", \\\"{x:931,y:587,t:1526918929655};\\\", \\\"{x:931,y:587,t:1526918929670};\\\", \\\"{x:931,y:588,t:1526918929679};\\\", \\\"{x:931,y:588,t:1526918929694};\\\", \\\"{x:931,y:588,t:1526918929711};\\\", \\\"{x:932,y:588,t:1526918929725};\\\", \\\"{x:932,y:589,t:1526918929741};\\\", \\\"{x:932,y:589,t:1526918929757};\\\", \\\"{x:933,y:590,t:1526918929774};\\\", \\\"{x:934,y:592,t:1526918929791};\\\", \\\"{x:934,y:594,t:1526918929808};\\\", \\\"{x:934,y:597,t:1526918929824};\\\", \\\"{x:934,y:603,t:1526918929841};\\\", \\\"{x:934,y:613,t:1526918929858};\\\", \\\"{x:934,y:625,t:1526918929876};\\\", \\\"{x:934,y:636,t:1526918929891};\\\", \\\"{x:934,y:646,t:1526918929909};\\\", \\\"{x:934,y:653,t:1526918929925};\\\", \\\"{x:934,y:658,t:1526918929942};\\\", \\\"{x:935,y:661,t:1526918929958};\\\", \\\"{x:936,y:664,t:1526918929974};\\\", \\\"{x:937,y:666,t:1526918929991};\\\", \\\"{x:941,y:668,t:1526918930008};\\\", \\\"{x:942,y:670,t:1526918930024};\\\", \\\"{x:945,y:672,t:1526918930041};\\\", \\\"{x:947,y:674,t:1526918930058};\\\", \\\"{x:949,y:675,t:1526918930075};\\\", \\\"{x:950,y:676,t:1526918930092};\\\", \\\"{x:950,y:677,t:1526918930107};\\\", \\\"{x:951,y:678,t:1526918930124};\\\", \\\"{x:951,y:679,t:1526918930142};\\\", \\\"{x:951,y:679,t:1526918930158};\\\", \\\"{x:952,y:680,t:1526918930174};\\\", \\\"{x:952,y:680,t:1526918930191};\\\", \\\"{x:952,y:680,t:1526918930207};\\\", \\\"{x:954,y:680,t:1526918930224};\\\", \\\"{x:954,y:680,t:1526918930241};\\\", \\\"{x:955,y:680,t:1526918930258};\\\", \\\"{x:956,y:680,t:1526918930275};\\\", \\\"{x:957,y:680,t:1526918930601};\\\", \\\"{x:960,y:678,t:1526918930609};\\\", \\\"{x:965,y:675,t:1526918930624};\\\", \\\"{x:993,y:657,t:1526918930641};\\\", \\\"{x:1013,y:645,t:1526918930659};\\\", \\\"{x:1029,y:637,t:1526918930674};\\\", \\\"{x:1040,y:633,t:1526918930691};\\\", \\\"{x:1050,y:629,t:1526918930708};\\\", \\\"{x:1055,y:628,t:1526918930725};\\\", \\\"{x:1057,y:627,t:1526918930743};\\\", \\\"{x:1059,y:627,t:1526918930759};\\\", \\\"{x:1059,y:627,t:1526918930775};\\\", \\\"{x:1060,y:627,t:1526918930791};\\\", \\\"{x:1060,y:627,t:1526918930842};\\\", \\\"{x:1060,y:628,t:1526918930858};\\\", \\\"{x:1060,y:628,t:1526918930875};\\\", \\\"{x:1059,y:629,t:1526918930891};\\\", \\\"{x:1059,y:629,t:1526918930908};\\\", \\\"{x:1059,y:630,t:1526918930925};\\\", \\\"{x:1058,y:630,t:1526918930942};\\\", \\\"{x:1057,y:631,t:1526918930958};\\\", \\\"{x:1056,y:631,t:1526918930976};\\\", \\\"{x:1055,y:631,t:1526918930993};\\\", \\\"{x:1054,y:631,t:1526918931009};\\\", \\\"{x:1053,y:631,t:1526918931025};\\\", \\\"{x:1053,y:631,t:1526918931042};\\\", \\\"{x:1052,y:631,t:1526918931058};\\\", \\\"{x:1052,y:631,t:1526918931075};\\\", \\\"{x:1052,y:630,t:1526918931092};\\\", \\\"{x:1052,y:630,t:1526918931108};\\\", \\\"{x:1052,y:630,t:1526918931130};\\\", \\\"{x:1051,y:630,t:1526918936632};\\\", \\\"{x:1050,y:630,t:1526918936640};\\\", \\\"{x:1047,y:630,t:1526918936659};\\\", \\\"{x:1042,y:630,t:1526918936676};\\\", \\\"{x:1034,y:630,t:1526918936692};\\\", \\\"{x:1021,y:630,t:1526918936708};\\\", \\\"{x:989,y:630,t:1526918936725};\\\", \\\"{x:931,y:618,t:1526918936743};\\\", \\\"{x:856,y:590,t:1526918936758};\\\", \\\"{x:723,y:529,t:1526918936774};\\\", \\\"{x:602,y:460,t:1526918936791};\\\", \\\"{x:523,y:404,t:1526918936808};\\\", \\\"{x:484,y:374,t:1526918936825};\\\", \\\"{x:461,y:357,t:1526918936842};\\\", \\\"{x:436,y:338,t:1526918936857};\\\", \\\"{x:432,y:332,t:1526918936876};\\\", \\\"{x:432,y:333,t:1526918937090};\\\", \\\"{x:432,y:338,t:1526918937098};\\\", \\\"{x:432,y:343,t:1526918937108};\\\", \\\"{x:430,y:361,t:1526918937125};\\\", \\\"{x:428,y:379,t:1526918937145};\\\", \\\"{x:427,y:392,t:1526918937160};\\\", \\\"{x:426,y:404,t:1526918937176};\\\", \\\"{x:425,y:411,t:1526918937193};\\\", \\\"{x:425,y:414,t:1526918937211};\\\", \\\"{x:424,y:417,t:1526918937226};\\\", \\\"{x:424,y:419,t:1526918937242};\\\", \\\"{x:423,y:419,t:1526918937259};\\\", \\\"{x:422,y:420,t:1526918937276};\\\", \\\"{x:420,y:420,t:1526918937292};\\\", \\\"{x:415,y:421,t:1526918937309};\\\", \\\"{x:408,y:422,t:1526918937326};\\\", \\\"{x:399,y:423,t:1526918937343};\\\", \\\"{x:386,y:427,t:1526918937359};\\\", \\\"{x:373,y:432,t:1526918937377};\\\", \\\"{x:357,y:438,t:1526918937392};\\\", \\\"{x:341,y:442,t:1526918937409};\\\", \\\"{x:323,y:445,t:1526918937427};\\\", \\\"{x:299,y:447,t:1526918937443};\\\", \\\"{x:288,y:447,t:1526918937458};\\\", \\\"{x:280,y:446,t:1526918937475};\\\", \\\"{x:276,y:445,t:1526918937492};\\\", \\\"{x:271,y:444,t:1526918937509};\\\", \\\"{x:268,y:443,t:1526918937527};\\\", \\\"{x:265,y:442,t:1526918937544};\\\", \\\"{x:265,y:442,t:1526918937558};\\\", \\\"{x:264,y:442,t:1526918937828};\\\", \\\"{x:262,y:442,t:1526918937842};\\\", \\\"{x:257,y:442,t:1526918937859};\\\", \\\"{x:247,y:442,t:1526918937874};\\\", \\\"{x:239,y:444,t:1526918937894};\\\", \\\"{x:230,y:445,t:1526918937909};\\\", \\\"{x:221,y:446,t:1526918937925};\\\", \\\"{x:211,y:447,t:1526918937943};\\\", \\\"{x:203,y:448,t:1526918937959};\\\", \\\"{x:196,y:449,t:1526918937976};\\\", \\\"{x:191,y:451,t:1526918937995};\\\", \\\"{x:184,y:453,t:1526918938011};\\\", \\\"{x:178,y:455,t:1526918938025};\\\", \\\"{x:172,y:457,t:1526918938042};\\\", \\\"{x:167,y:458,t:1526918938058};\\\", \\\"{x:160,y:459,t:1526918938075};\\\", \\\"{x:158,y:459,t:1526918938091};\\\", \\\"{x:157,y:459,t:1526918938109};\\\", \\\"{x:156,y:459,t:1526918938126};\\\", \\\"{x:156,y:459,t:1526918938147};\\\", \\\"{x:156,y:459,t:1526918938172};\\\", \\\"{x:155,y:459,t:1526918938182};\\\", \\\"{x:155,y:459,t:1526918938192};\\\", \\\"{x:154,y:459,t:1526918938209};\\\", \\\"{x:154,y:459,t:1526918938226};\\\", \\\"{x:154,y:459,t:1526918938242};\\\", \\\"{x:154,y:458,t:1526918938259};\\\", \\\"{x:155,y:456,t:1526918938275};\\\", \\\"{x:169,y:444,t:1526918938294};\\\", \\\"{x:189,y:430,t:1526918938310};\\\", \\\"{x:214,y:412,t:1526918938325};\\\", \\\"{x:245,y:394,t:1526918938344};\\\", \\\"{x:267,y:384,t:1526918938360};\\\", \\\"{x:284,y:376,t:1526918938377};\\\", \\\"{x:303,y:370,t:1526918938394};\\\", \\\"{x:318,y:366,t:1526918938410};\\\", \\\"{x:332,y:365,t:1526918938427};\\\", \\\"{x:345,y:364,t:1526918938442};\\\", \\\"{x:359,y:364,t:1526918938459};\\\", \\\"{x:374,y:364,t:1526918938475};\\\", \\\"{x:389,y:364,t:1526918938492};\\\", \\\"{x:407,y:365,t:1526918938508};\\\", \\\"{x:414,y:366,t:1526918938526};\\\", \\\"{x:420,y:367,t:1526918938544};\\\", \\\"{x:424,y:368,t:1526918938559};\\\", \\\"{x:427,y:369,t:1526918938575};\\\", \\\"{x:429,y:369,t:1526918938593};\\\", \\\"{x:431,y:370,t:1526918938609};\\\", \\\"{x:431,y:370,t:1526918938626};\\\", \\\"{x:432,y:370,t:1526918938642};\\\", \\\"{x:432,y:371,t:1526918938659};\\\", \\\"{x:432,y:371,t:1526918938676};\\\", \\\"{x:432,y:372,t:1526918938692};\\\", \\\"{x:431,y:375,t:1526918938710};\\\", \\\"{x:428,y:378,t:1526918938726};\\\", \\\"{x:427,y:380,t:1526918938743};\\\", \\\"{x:424,y:383,t:1526918938759};\\\", \\\"{x:423,y:386,t:1526918938775};\\\", \\\"{x:421,y:388,t:1526918938792};\\\", \\\"{x:419,y:390,t:1526918938809};\\\", \\\"{x:418,y:391,t:1526918938826};\\\", \\\"{x:417,y:391,t:1526918938843};\\\", \\\"{x:416,y:392,t:1526918938860};\\\", \\\"{x:414,y:392,t:1526918938876};\\\", \\\"{x:412,y:392,t:1526918938892};\\\", \\\"{x:410,y:392,t:1526918938908};\\\", \\\"{x:405,y:392,t:1526918938925};\\\", \\\"{x:402,y:391,t:1526918938943};\\\", \\\"{x:400,y:391,t:1526918938958};\\\", \\\"{x:398,y:390,t:1526918938976};\\\", \\\"{x:397,y:390,t:1526918938992};\\\", \\\"{x:396,y:389,t:1526918939010};\\\", \\\"{x:396,y:389,t:1526918939026};\\\", \\\"{x:394,y:389,t:1526918939367};\\\", \\\"{x:390,y:391,t:1526918939376};\\\", \\\"{x:383,y:394,t:1526918939393};\\\", \\\"{x:377,y:397,t:1526918939409};\\\", \\\"{x:366,y:402,t:1526918939427};\\\", \\\"{x:352,y:407,t:1526918939443};\\\", \\\"{x:342,y:411,t:1526918939460};\\\", \\\"{x:330,y:414,t:1526918939478};\\\", \\\"{x:322,y:417,t:1526918939494};\\\", \\\"{x:314,y:418,t:1526918939509};\\\", \\\"{x:308,y:420,t:1526918939526};\\\", \\\"{x:303,y:420,t:1526918939542};\\\", \\\"{x:296,y:421,t:1526918939559};\\\", \\\"{x:291,y:421,t:1526918939576};\\\", \\\"{x:289,y:420,t:1526918939592};\\\", \\\"{x:287,y:418,t:1526918939609};\\\", \\\"{x:285,y:415,t:1526918939627};\\\", \\\"{x:283,y:412,t:1526918939643};\\\", \\\"{x:280,y:410,t:1526918939662};\\\", \\\"{x:277,y:407,t:1526918939676};\\\", \\\"{x:275,y:405,t:1526918939693};\\\", \\\"{x:272,y:403,t:1526918939711};\\\", \\\"{x:269,y:401,t:1526918939725};\\\", \\\"{x:267,y:400,t:1526918939742};\\\", \\\"{x:264,y:399,t:1526918939760};\\\", \\\"{x:262,y:398,t:1526918939775};\\\", \\\"{x:261,y:397,t:1526918939793};\\\", \\\"{x:259,y:397,t:1526918939809};\\\", \\\"{x:259,y:397,t:1526918939826};\\\", \\\"{x:258,y:397,t:1526918939843};\\\", \\\"{x:258,y:397,t:1526918939855};\\\", \\\"{x:259,y:402,t:1526918940089};\\\", \\\"{x:261,y:407,t:1526918940097};\\\", \\\"{x:264,y:415,t:1526918940111};\\\", \\\"{x:267,y:429,t:1526918940126};\\\", \\\"{x:269,y:438,t:1526918940144};\\\", \\\"{x:271,y:448,t:1526918940160};\\\", \\\"{x:275,y:464,t:1526918940177};\\\", \\\"{x:278,y:482,t:1526918940193};\\\", \\\"{x:279,y:489,t:1526918940208};\\\", \\\"{x:279,y:499,t:1526918940226};\\\", \\\"{x:279,y:505,t:1526918940243};\\\", \\\"{x:279,y:508,t:1526918940259};\\\", \\\"{x:279,y:512,t:1526918940276};\\\", \\\"{x:279,y:515,t:1526918940293};\\\", \\\"{x:279,y:518,t:1526918940310};\\\", \\\"{x:279,y:519,t:1526918940327};\\\", \\\"{x:278,y:520,t:1526918940343};\\\", \\\"{x:278,y:521,t:1526918940359};\\\", \\\"{x:278,y:522,t:1526918940375};\\\", \\\"{x:278,y:522,t:1526918940393};\\\", \\\"{x:277,y:523,t:1526918940409};\\\", \\\"{x:277,y:525,t:1526918940427};\\\", \\\"{x:276,y:528,t:1526918940442};\\\", \\\"{x:275,y:531,t:1526918940460};\\\", \\\"{x:274,y:535,t:1526918940475};\\\", \\\"{x:274,y:536,t:1526918940492};\\\", \\\"{x:273,y:538,t:1526918940509};\\\", \\\"{x:273,y:539,t:1526918940526};\\\", \\\"{x:273,y:540,t:1526918940543};\\\", \\\"{x:273,y:540,t:1526918940559};\\\", \\\"{x:273,y:541,t:1526918940576};\\\", \\\"{x:272,y:541,t:1526918940592};\\\", \\\"{x:272,y:542,t:1526918940609};\\\", \\\"{x:272,y:542,t:1526918940625};\\\" ] }, { \\\"rt\\\": 43837, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 2086256, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:256,y:541,t:1526918943180};\\\", \\\"{x:256,y:537,t:1526918943194};\\\", \\\"{x:260,y:526,t:1526918943210};\\\", \\\"{x:278,y:495,t:1526918943226};\\\", \\\"{x:307,y:458,t:1526918943243};\\\", \\\"{x:376,y:394,t:1526918943261};\\\", \\\"{x:434,y:359,t:1526918943276};\\\", \\\"{x:479,y:339,t:1526918943294};\\\", \\\"{x:520,y:326,t:1526918943309};\\\", \\\"{x:567,y:319,t:1526918943326};\\\", \\\"{x:593,y:317,t:1526918943343};\\\", \\\"{x:617,y:317,t:1526918943360};\\\", \\\"{x:633,y:317,t:1526918943376};\\\", \\\"{x:643,y:318,t:1526918943395};\\\", \\\"{x:644,y:319,t:1526918943410};\\\", \\\"{x:646,y:317,t:1526918943669};\\\", \\\"{x:649,y:314,t:1526918943676};\\\", \\\"{x:654,y:309,t:1526918943693};\\\", \\\"{x:664,y:298,t:1526918943709};\\\", \\\"{x:671,y:291,t:1526918943726};\\\", \\\"{x:676,y:286,t:1526918943743};\\\", \\\"{x:681,y:282,t:1526918943758};\\\", \\\"{x:683,y:281,t:1526918943776};\\\", \\\"{x:683,y:280,t:1526918943792};\\\", \\\"{x:684,y:280,t:1526918943809};\\\", \\\"{x:684,y:281,t:1526918943836};\\\", \\\"{x:684,y:282,t:1526918943845};\\\", \\\"{x:684,y:284,t:1526918943859};\\\", \\\"{x:684,y:288,t:1526918943876};\\\", \\\"{x:684,y:292,t:1526918943891};\\\", \\\"{x:684,y:295,t:1526918943910};\\\", \\\"{x:684,y:296,t:1526918943926};\\\", \\\"{x:683,y:297,t:1526918943942};\\\", \\\"{x:683,y:298,t:1526918943959};\\\", \\\"{x:683,y:299,t:1526918943975};\\\", \\\"{x:683,y:301,t:1526918943992};\\\", \\\"{x:682,y:302,t:1526918944008};\\\", \\\"{x:682,y:302,t:1526918944026};\\\", \\\"{x:682,y:303,t:1526918944043};\\\", \\\"{x:682,y:303,t:1526918944059};\\\", \\\"{x:682,y:303,t:1526918947670};\\\", \\\"{x:682,y:303,t:1526918947726};\\\", \\\"{x:682,y:302,t:1526918948623};\\\", \\\"{x:682,y:302,t:1526918949313};\\\", \\\"{x:682,y:302,t:1526918949329};\\\", \\\"{x:683,y:302,t:1526918949352};\\\", \\\"{x:683,y:302,t:1526918949376};\\\", \\\"{x:683,y:302,t:1526918949417};\\\", \\\"{x:683,y:302,t:1526918949458};\\\", \\\"{x:684,y:302,t:1526918949465};\\\", \\\"{x:684,y:302,t:1526918949476};\\\", \\\"{x:685,y:302,t:1526918949493};\\\", \\\"{x:688,y:305,t:1526918949509};\\\", \\\"{x:694,y:311,t:1526918949526};\\\", \\\"{x:700,y:320,t:1526918949543};\\\", \\\"{x:712,y:341,t:1526918949560};\\\", \\\"{x:726,y:369,t:1526918949575};\\\", \\\"{x:749,y:426,t:1526918949593};\\\", \\\"{x:760,y:451,t:1526918949610};\\\", \\\"{x:768,y:469,t:1526918949626};\\\", \\\"{x:776,y:485,t:1526918949643};\\\", \\\"{x:779,y:492,t:1526918949660};\\\", \\\"{x:782,y:498,t:1526918949676};\\\", \\\"{x:783,y:502,t:1526918949694};\\\", \\\"{x:784,y:504,t:1526918949710};\\\", \\\"{x:785,y:506,t:1526918949726};\\\", \\\"{x:786,y:508,t:1526918949743};\\\", \\\"{x:789,y:511,t:1526918949759};\\\", \\\"{x:795,y:516,t:1526918949776};\\\", \\\"{x:804,y:521,t:1526918949794};\\\", \\\"{x:817,y:528,t:1526918949809};\\\", \\\"{x:837,y:538,t:1526918949826};\\\", \\\"{x:851,y:544,t:1526918949842};\\\", \\\"{x:862,y:549,t:1526918949859};\\\", \\\"{x:875,y:555,t:1526918949876};\\\", \\\"{x:886,y:559,t:1526918949893};\\\", \\\"{x:896,y:563,t:1526918949910};\\\", \\\"{x:905,y:566,t:1526918949926};\\\", \\\"{x:910,y:568,t:1526918949943};\\\", \\\"{x:915,y:570,t:1526918949960};\\\", \\\"{x:919,y:570,t:1526918949977};\\\", \\\"{x:921,y:571,t:1526918949993};\\\", \\\"{x:923,y:571,t:1526918950010};\\\", \\\"{x:923,y:571,t:1526918950026};\\\", \\\"{x:924,y:571,t:1526918950043};\\\", \\\"{x:924,y:571,t:1526918950115};\\\", \\\"{x:924,y:571,t:1526918950146};\\\", \\\"{x:924,y:571,t:1526918950162};\\\", \\\"{x:923,y:570,t:1526918950177};\\\", \\\"{x:922,y:570,t:1526918950193};\\\", \\\"{x:921,y:569,t:1526918950209};\\\", \\\"{x:921,y:568,t:1526918950226};\\\", \\\"{x:920,y:567,t:1526918950244};\\\", \\\"{x:919,y:566,t:1526918950261};\\\", \\\"{x:918,y:565,t:1526918950276};\\\", \\\"{x:918,y:565,t:1526918950292};\\\", \\\"{x:918,y:565,t:1526918950309};\\\", \\\"{x:918,y:565,t:1526918951105};\\\", \\\"{x:918,y:566,t:1526918951113};\\\", \\\"{x:917,y:567,t:1526918951127};\\\", \\\"{x:916,y:571,t:1526918951144};\\\", \\\"{x:911,y:581,t:1526918951159};\\\", \\\"{x:904,y:598,t:1526918951176};\\\", \\\"{x:895,y:619,t:1526918951193};\\\", \\\"{x:882,y:654,t:1526918951210};\\\", \\\"{x:876,y:668,t:1526918951227};\\\", \\\"{x:871,y:681,t:1526918951244};\\\", \\\"{x:867,y:692,t:1526918951260};\\\", \\\"{x:865,y:701,t:1526918951276};\\\", \\\"{x:862,y:708,t:1526918951293};\\\", \\\"{x:859,y:716,t:1526918951311};\\\", \\\"{x:856,y:724,t:1526918951327};\\\", \\\"{x:853,y:731,t:1526918951345};\\\", \\\"{x:851,y:735,t:1526918951361};\\\", \\\"{x:849,y:740,t:1526918951376};\\\", \\\"{x:847,y:744,t:1526918951395};\\\", \\\"{x:846,y:745,t:1526918951409};\\\", \\\"{x:843,y:748,t:1526918951426};\\\", \\\"{x:841,y:749,t:1526918951444};\\\", \\\"{x:839,y:750,t:1526918951460};\\\", \\\"{x:837,y:752,t:1526918951476};\\\", \\\"{x:834,y:753,t:1526918951493};\\\", \\\"{x:832,y:755,t:1526918951511};\\\", \\\"{x:830,y:756,t:1526918951527};\\\", \\\"{x:828,y:756,t:1526918951544};\\\", \\\"{x:827,y:757,t:1526918951561};\\\", \\\"{x:826,y:757,t:1526918951577};\\\", \\\"{x:825,y:757,t:1526918951595};\\\", \\\"{x:824,y:757,t:1526918951610};\\\", \\\"{x:824,y:757,t:1526918951627};\\\", \\\"{x:824,y:757,t:1526918951644};\\\", \\\"{x:823,y:757,t:1526918951661};\\\", \\\"{x:823,y:757,t:1526918951939};\\\", \\\"{x:823,y:757,t:1526918951964};\\\", \\\"{x:823,y:758,t:1526918951978};\\\", \\\"{x:822,y:758,t:1526918951995};\\\", \\\"{x:822,y:758,t:1526918952010};\\\", \\\"{x:822,y:758,t:1526918952026};\\\", \\\"{x:822,y:758,t:1526918952043};\\\", \\\"{x:821,y:758,t:1526918952060};\\\", \\\"{x:821,y:758,t:1526918952075};\\\", \\\"{x:821,y:759,t:1526918952093};\\\", \\\"{x:821,y:759,t:1526918952110};\\\", \\\"{x:820,y:759,t:1526918980494};\\\", \\\"{x:816,y:759,t:1526918980512};\\\", \\\"{x:810,y:759,t:1526918980529};\\\", \\\"{x:799,y:755,t:1526918980546};\\\", \\\"{x:783,y:746,t:1526918980561};\\\", \\\"{x:765,y:734,t:1526918980578};\\\", \\\"{x:749,y:721,t:1526918980596};\\\", \\\"{x:745,y:716,t:1526918980611};\\\", \\\"{x:741,y:711,t:1526918980629};\\\", \\\"{x:737,y:705,t:1526918980646};\\\", \\\"{x:733,y:698,t:1526918980662};\\\", \\\"{x:724,y:682,t:1526918980678};\\\", \\\"{x:710,y:659,t:1526918980694};\\\", \\\"{x:680,y:619,t:1526918980711};\\\", \\\"{x:639,y:583,t:1526918980728};\\\", \\\"{x:598,y:560,t:1526918980745};\\\", \\\"{x:542,y:544,t:1526918980763};\\\", \\\"{x:507,y:540,t:1526918980778};\\\", \\\"{x:462,y:540,t:1526918980796};\\\", \\\"{x:449,y:540,t:1526918980811};\\\", \\\"{x:432,y:540,t:1526918980827};\\\", \\\"{x:423,y:540,t:1526918980844};\\\", \\\"{x:420,y:540,t:1526918980861};\\\", \\\"{x:419,y:542,t:1526918980878};\\\", \\\"{x:419,y:559,t:1526918980894};\\\", \\\"{x:420,y:576,t:1526918980912};\\\", \\\"{x:421,y:594,t:1526918980929};\\\", \\\"{x:420,y:611,t:1526918980945};\\\", \\\"{x:416,y:618,t:1526918980962};\\\", \\\"{x:413,y:621,t:1526918980978};\\\", \\\"{x:408,y:623,t:1526918980995};\\\", \\\"{x:406,y:623,t:1526918981010};\\\", \\\"{x:406,y:618,t:1526918981229};\\\", \\\"{x:387,y:578,t:1526918981245};\\\", \\\"{x:360,y:519,t:1526918981260};\\\", \\\"{x:339,y:464,t:1526918981281};\\\", \\\"{x:326,y:425,t:1526918981295};\\\", \\\"{x:313,y:388,t:1526918981312};\\\", \\\"{x:305,y:374,t:1526918981330};\\\", \\\"{x:297,y:361,t:1526918981345};\\\", \\\"{x:290,y:353,t:1526918981363};\\\", \\\"{x:284,y:348,t:1526918981381};\\\", \\\"{x:274,y:341,t:1526918981398};\\\", \\\"{x:270,y:338,t:1526918981413};\\\", \\\"{x:267,y:337,t:1526918981430};\\\", \\\"{x:265,y:336,t:1526918981447};\\\", \\\"{x:263,y:336,t:1526918981464};\\\", \\\"{x:261,y:336,t:1526918981480};\\\", \\\"{x:259,y:336,t:1526918981497};\\\", \\\"{x:258,y:336,t:1526918981514};\\\", \\\"{x:256,y:337,t:1526918981531};\\\", \\\"{x:254,y:338,t:1526918981547};\\\", \\\"{x:253,y:340,t:1526918981565};\\\", \\\"{x:253,y:341,t:1526918981580};\\\", \\\"{x:253,y:342,t:1526918981596};\\\", \\\"{x:253,y:344,t:1526918981615};\\\", \\\"{x:253,y:345,t:1526918981630};\\\", \\\"{x:255,y:348,t:1526918981647};\\\", \\\"{x:257,y:353,t:1526918981666};\\\", \\\"{x:258,y:357,t:1526918981681};\\\", \\\"{x:260,y:361,t:1526918981696};\\\", \\\"{x:260,y:364,t:1526918981714};\\\", \\\"{x:261,y:365,t:1526918981730};\\\", \\\"{x:261,y:366,t:1526918981747};\\\", \\\"{x:261,y:366,t:1526918981764};\\\", \\\"{x:261,y:366,t:1526918981782};\\\", \\\"{x:261,y:367,t:1526918981797};\\\", \\\"{x:261,y:367,t:1526918981813};\\\", \\\"{x:261,y:368,t:1526918981830};\\\", \\\"{x:270,y:432,t:1526918985323};\\\", \\\"{x:274,y:451,t:1526918985330};\\\", \\\"{x:280,y:477,t:1526918985349};\\\", \\\"{x:283,y:504,t:1526918985365};\\\", \\\"{x:287,y:529,t:1526918985381};\\\", \\\"{x:295,y:577,t:1526918985400};\\\", \\\"{x:302,y:604,t:1526918985415};\\\", \\\"{x:305,y:614,t:1526918985431};\\\", \\\"{x:308,y:626,t:1526918985447};\\\", \\\"{x:310,y:631,t:1526918985464};\\\", \\\"{x:311,y:633,t:1526918985480};\\\", \\\"{x:311,y:633,t:1526918985498};\\\", \\\"{x:311,y:633,t:1526918985513};\\\", \\\"{x:311,y:630,t:1526918985531};\\\", \\\"{x:308,y:625,t:1526918985548};\\\", \\\"{x:304,y:615,t:1526918985563};\\\", \\\"{x:298,y:603,t:1526918985581};\\\", \\\"{x:294,y:591,t:1526918985598};\\\", \\\"{x:290,y:582,t:1526918985614};\\\", \\\"{x:286,y:571,t:1526918985631};\\\", \\\"{x:284,y:564,t:1526918985648};\\\", \\\"{x:282,y:558,t:1526918985664};\\\", \\\"{x:281,y:555,t:1526918985680};\\\", \\\"{x:280,y:554,t:1526918985696};\\\", \\\"{x:280,y:553,t:1526918985715};\\\", \\\"{x:280,y:553,t:1526918985737};\\\" ] }, { \\\"rt\\\": 23711, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 2111217, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B -B -J -I -J -J -E -F -F -B -I -J -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:280,y:553,t:1526918987747};\\\", \\\"{x:280,y:540,t:1526918987764};\\\", \\\"{x:280,y:508,t:1526918987782};\\\", \\\"{x:280,y:461,t:1526918987799};\\\", \\\"{x:280,y:402,t:1526918987816};\\\", \\\"{x:280,y:364,t:1526918987832};\\\", \\\"{x:282,y:324,t:1526918987849};\\\", \\\"{x:285,y:307,t:1526918987865};\\\", \\\"{x:288,y:291,t:1526918987882};\\\", \\\"{x:291,y:284,t:1526918987898};\\\", \\\"{x:292,y:277,t:1526918987913};\\\", \\\"{x:294,y:272,t:1526918987930};\\\", \\\"{x:296,y:265,t:1526918987947};\\\", \\\"{x:297,y:260,t:1526918987964};\\\", \\\"{x:298,y:254,t:1526918987982};\\\", \\\"{x:300,y:249,t:1526918987997};\\\", \\\"{x:302,y:245,t:1526918988014};\\\", \\\"{x:304,y:242,t:1526918988030};\\\", \\\"{x:306,y:240,t:1526918988048};\\\", \\\"{x:308,y:238,t:1526918988064};\\\", \\\"{x:310,y:237,t:1526918988083};\\\", \\\"{x:312,y:236,t:1526918988097};\\\", \\\"{x:317,y:236,t:1526918988114};\\\", \\\"{x:322,y:236,t:1526918988131};\\\", \\\"{x:328,y:236,t:1526918988147};\\\", \\\"{x:336,y:236,t:1526918988164};\\\", \\\"{x:341,y:236,t:1526918988181};\\\", \\\"{x:344,y:236,t:1526918988197};\\\", \\\"{x:348,y:236,t:1526918988214};\\\", \\\"{x:387,y:236,t:1526918990144};\\\", \\\"{x:389,y:236,t:1526918990152};\\\", \\\"{x:392,y:236,t:1526918990164};\\\", \\\"{x:400,y:236,t:1526918990181};\\\", \\\"{x:414,y:239,t:1526918990197};\\\", \\\"{x:430,y:243,t:1526918990215};\\\", \\\"{x:463,y:250,t:1526918990231};\\\", \\\"{x:498,y:258,t:1526918990248};\\\", \\\"{x:542,y:271,t:1526918990264};\\\", \\\"{x:622,y:297,t:1526918990281};\\\", \\\"{x:698,y:329,t:1526918990297};\\\", \\\"{x:751,y:359,t:1526918990314};\\\", \\\"{x:804,y:403,t:1526918990331};\\\", \\\"{x:849,y:453,t:1526918990347};\\\", \\\"{x:865,y:474,t:1526918990364};\\\", \\\"{x:882,y:496,t:1526918990382};\\\", \\\"{x:890,y:509,t:1526918990398};\\\", \\\"{x:890,y:509,t:1526918991135};\\\", \\\"{x:885,y:509,t:1526918991148};\\\", \\\"{x:875,y:516,t:1526918991165};\\\", \\\"{x:862,y:530,t:1526918991181};\\\", \\\"{x:850,y:545,t:1526918991197};\\\", \\\"{x:833,y:567,t:1526918991213};\\\", \\\"{x:812,y:596,t:1526918991231};\\\", \\\"{x:802,y:610,t:1526918991248};\\\", \\\"{x:795,y:618,t:1526918991265};\\\", \\\"{x:792,y:622,t:1526918991281};\\\", \\\"{x:789,y:624,t:1526918991298};\\\", \\\"{x:787,y:625,t:1526918991318};\\\", \\\"{x:785,y:626,t:1526918991332};\\\", \\\"{x:784,y:627,t:1526918991348};\\\", \\\"{x:783,y:628,t:1526918991365};\\\", \\\"{x:782,y:628,t:1526918991382};\\\", \\\"{x:782,y:629,t:1526918991398};\\\", \\\"{x:781,y:629,t:1526918991414};\\\", \\\"{x:781,y:629,t:1526918991503};\\\", \\\"{x:781,y:628,t:1526918991514};\\\", \\\"{x:782,y:628,t:1526918991531};\\\", \\\"{x:782,y:628,t:1526918991547};\\\", \\\"{x:782,y:628,t:1526918991600};\\\", \\\"{x:783,y:628,t:1526918991632};\\\", \\\"{x:782,y:629,t:1526918992675};\\\", \\\"{x:781,y:629,t:1526918992682};\\\", \\\"{x:781,y:630,t:1526918992697};\\\", \\\"{x:780,y:631,t:1526918992714};\\\", \\\"{x:777,y:634,t:1526918992732};\\\", \\\"{x:775,y:635,t:1526918992748};\\\", \\\"{x:773,y:637,t:1526918992764};\\\", \\\"{x:770,y:640,t:1526918992782};\\\", \\\"{x:767,y:643,t:1526918992798};\\\", \\\"{x:765,y:645,t:1526918992814};\\\", \\\"{x:761,y:649,t:1526918992832};\\\", \\\"{x:757,y:652,t:1526918992849};\\\", \\\"{x:754,y:654,t:1526918992865};\\\", \\\"{x:751,y:657,t:1526918992882};\\\", \\\"{x:748,y:660,t:1526918992898};\\\", \\\"{x:746,y:662,t:1526918992914};\\\", \\\"{x:745,y:663,t:1526918992931};\\\", \\\"{x:743,y:664,t:1526918992947};\\\", \\\"{x:743,y:665,t:1526918992965};\\\", \\\"{x:743,y:664,t:1526918992995};\\\", \\\"{x:743,y:663,t:1526918993003};\\\", \\\"{x:745,y:661,t:1526918993015};\\\", \\\"{x:751,y:656,t:1526918993031};\\\", \\\"{x:758,y:651,t:1526918993048};\\\", \\\"{x:765,y:646,t:1526918993065};\\\", \\\"{x:769,y:642,t:1526918993082};\\\", \\\"{x:773,y:640,t:1526918993098};\\\", \\\"{x:775,y:639,t:1526918993114};\\\", \\\"{x:775,y:638,t:1526918993131};\\\", \\\"{x:775,y:638,t:1526918993147};\\\", \\\"{x:776,y:638,t:1526918993477};\\\", \\\"{x:779,y:638,t:1526918993485};\\\", \\\"{x:783,y:638,t:1526918993499};\\\", \\\"{x:804,y:634,t:1526918993515};\\\", \\\"{x:837,y:628,t:1526918993531};\\\", \\\"{x:865,y:624,t:1526918993547};\\\", \\\"{x:901,y:619,t:1526918993564};\\\", \\\"{x:933,y:616,t:1526918993580};\\\", \\\"{x:942,y:615,t:1526918993598};\\\", \\\"{x:950,y:615,t:1526918993614};\\\", \\\"{x:952,y:615,t:1526918993631};\\\", \\\"{x:954,y:615,t:1526918993648};\\\", \\\"{x:954,y:615,t:1526918993664};\\\", \\\"{x:954,y:615,t:1526918993692};\\\", \\\"{x:952,y:615,t:1526918993702};\\\", \\\"{x:948,y:612,t:1526918993715};\\\", \\\"{x:942,y:603,t:1526918993731};\\\", \\\"{x:940,y:598,t:1526918993747};\\\", \\\"{x:937,y:592,t:1526918993764};\\\", \\\"{x:933,y:584,t:1526918993781};\\\", \\\"{x:933,y:582,t:1526918993798};\\\", \\\"{x:932,y:581,t:1526918993814};\\\", \\\"{x:932,y:580,t:1526918993831};\\\", \\\"{x:931,y:579,t:1526918993848};\\\", \\\"{x:930,y:578,t:1526918993865};\\\", \\\"{x:928,y:576,t:1526918993882};\\\", \\\"{x:927,y:573,t:1526918993898};\\\", \\\"{x:926,y:570,t:1526918993915};\\\", \\\"{x:924,y:567,t:1526918993931};\\\", \\\"{x:922,y:564,t:1526918993947};\\\", \\\"{x:919,y:561,t:1526918993965};\\\", \\\"{x:918,y:559,t:1526918993981};\\\", \\\"{x:916,y:556,t:1526918993998};\\\", \\\"{x:915,y:555,t:1526918994014};\\\", \\\"{x:915,y:554,t:1526918994031};\\\", \\\"{x:915,y:554,t:1526918994048};\\\", \\\"{x:915,y:554,t:1526918994118};\\\", \\\"{x:915,y:554,t:1526918994130};\\\", \\\"{x:915,y:555,t:1526918994147};\\\", \\\"{x:915,y:556,t:1526918994164};\\\", \\\"{x:915,y:556,t:1526918994180};\\\", \\\"{x:915,y:557,t:1526918994198};\\\", \\\"{x:915,y:557,t:1526918994213};\\\", \\\"{x:915,y:558,t:1526918994246};\\\", \\\"{x:915,y:558,t:1526918994261};\\\", \\\"{x:915,y:558,t:1526918994285};\\\", \\\"{x:915,y:559,t:1526918994302};\\\", \\\"{x:915,y:559,t:1526918994314};\\\", \\\"{x:915,y:559,t:1526918994330};\\\", \\\"{x:915,y:560,t:1526918994352};\\\", \\\"{x:915,y:560,t:1526918995228};\\\", \\\"{x:911,y:560,t:1526918995236};\\\", \\\"{x:903,y:564,t:1526918995249};\\\", \\\"{x:881,y:574,t:1526918995265};\\\", \\\"{x:849,y:586,t:1526918995281};\\\", \\\"{x:825,y:597,t:1526918995299};\\\", \\\"{x:800,y:609,t:1526918995315};\\\", \\\"{x:788,y:616,t:1526918995331};\\\", \\\"{x:780,y:621,t:1526918995348};\\\", \\\"{x:775,y:627,t:1526918995365};\\\", \\\"{x:774,y:629,t:1526918995380};\\\", \\\"{x:773,y:633,t:1526918995398};\\\", \\\"{x:773,y:640,t:1526918995415};\\\", \\\"{x:776,y:646,t:1526918995431};\\\", \\\"{x:779,y:654,t:1526918995447};\\\", \\\"{x:782,y:658,t:1526918995465};\\\", \\\"{x:785,y:660,t:1526918995482};\\\", \\\"{x:788,y:661,t:1526918995498};\\\", \\\"{x:790,y:661,t:1526918995515};\\\", \\\"{x:791,y:661,t:1526918995532};\\\", \\\"{x:792,y:660,t:1526918995549};\\\", \\\"{x:793,y:658,t:1526918995565};\\\", \\\"{x:794,y:655,t:1526918995581};\\\", \\\"{x:794,y:654,t:1526918995597};\\\", \\\"{x:794,y:653,t:1526918995614};\\\", \\\"{x:794,y:652,t:1526918995632};\\\", \\\"{x:794,y:651,t:1526918995648};\\\", \\\"{x:794,y:650,t:1526918995664};\\\", \\\"{x:794,y:649,t:1526918995682};\\\", \\\"{x:792,y:648,t:1526918995698};\\\", \\\"{x:791,y:648,t:1526918995715};\\\", \\\"{x:776,y:647,t:1526918995784};\\\", \\\"{x:769,y:646,t:1526918995798};\\\", \\\"{x:763,y:646,t:1526918995815};\\\", \\\"{x:756,y:646,t:1526918995831};\\\", \\\"{x:747,y:646,t:1526918995848};\\\", \\\"{x:738,y:646,t:1526918995865};\\\", \\\"{x:728,y:646,t:1526918995881};\\\", \\\"{x:721,y:648,t:1526918995898};\\\", \\\"{x:710,y:655,t:1526918995915};\\\", \\\"{x:705,y:660,t:1526918995932};\\\", \\\"{x:698,y:668,t:1526918995948};\\\", \\\"{x:692,y:677,t:1526918995965};\\\", \\\"{x:686,y:686,t:1526918995981};\\\", \\\"{x:682,y:694,t:1526918995997};\\\", \\\"{x:677,y:703,t:1526918996014};\\\", \\\"{x:674,y:709,t:1526918996032};\\\", \\\"{x:672,y:714,t:1526918996048};\\\", \\\"{x:670,y:718,t:1526918996065};\\\", \\\"{x:669,y:721,t:1526918996082};\\\", \\\"{x:669,y:722,t:1526918996098};\\\", \\\"{x:668,y:723,t:1526918996115};\\\", \\\"{x:668,y:724,t:1526918996131};\\\", \\\"{x:667,y:725,t:1526918996147};\\\", \\\"{x:666,y:726,t:1526918996165};\\\", \\\"{x:665,y:727,t:1526918996182};\\\", \\\"{x:664,y:730,t:1526918996198};\\\", \\\"{x:663,y:732,t:1526918996215};\\\", \\\"{x:661,y:736,t:1526918996231};\\\", \\\"{x:660,y:739,t:1526918996248};\\\", \\\"{x:659,y:744,t:1526918996264};\\\", \\\"{x:658,y:750,t:1526918996282};\\\", \\\"{x:657,y:754,t:1526918996297};\\\", \\\"{x:656,y:758,t:1526918996315};\\\", \\\"{x:656,y:760,t:1526918996332};\\\", \\\"{x:655,y:761,t:1526918996349};\\\", \\\"{x:655,y:761,t:1526918996369};\\\", \\\"{x:655,y:760,t:1526918996435};\\\", \\\"{x:655,y:759,t:1526918996447};\\\", \\\"{x:655,y:757,t:1526918996464};\\\", \\\"{x:655,y:753,t:1526918996480};\\\", \\\"{x:656,y:750,t:1526918996498};\\\", \\\"{x:659,y:745,t:1526918996516};\\\", \\\"{x:663,y:738,t:1526918996532};\\\", \\\"{x:669,y:728,t:1526918996549};\\\", \\\"{x:676,y:716,t:1526918996566};\\\", \\\"{x:685,y:701,t:1526918996581};\\\", \\\"{x:692,y:691,t:1526918996598};\\\", \\\"{x:699,y:680,t:1526918996614};\\\", \\\"{x:702,y:674,t:1526918996631};\\\", \\\"{x:708,y:665,t:1526918996647};\\\", \\\"{x:712,y:657,t:1526918996665};\\\", \\\"{x:719,y:647,t:1526918996681};\\\", \\\"{x:724,y:639,t:1526918996698};\\\", \\\"{x:731,y:627,t:1526918996714};\\\", \\\"{x:738,y:617,t:1526918996732};\\\", \\\"{x:742,y:611,t:1526918996748};\\\", \\\"{x:745,y:606,t:1526918996765};\\\", \\\"{x:749,y:600,t:1526918996782};\\\", \\\"{x:751,y:597,t:1526918996798};\\\", \\\"{x:752,y:594,t:1526918996815};\\\", \\\"{x:753,y:591,t:1526918996831};\\\", \\\"{x:755,y:586,t:1526918996848};\\\", \\\"{x:757,y:582,t:1526918996864};\\\", \\\"{x:757,y:579,t:1526918996880};\\\", \\\"{x:758,y:576,t:1526918996898};\\\", \\\"{x:759,y:573,t:1526918996915};\\\", \\\"{x:760,y:572,t:1526918996931};\\\", \\\"{x:760,y:571,t:1526918996948};\\\", \\\"{x:760,y:570,t:1526918996965};\\\", \\\"{x:760,y:570,t:1526918996980};\\\", \\\"{x:760,y:569,t:1526918996998};\\\", \\\"{x:760,y:569,t:1526918997014};\\\", \\\"{x:760,y:568,t:1526918997031};\\\", \\\"{x:759,y:568,t:1526918997048};\\\", \\\"{x:759,y:567,t:1526918997064};\\\", \\\"{x:758,y:566,t:1526918997080};\\\", \\\"{x:757,y:565,t:1526918997098};\\\", \\\"{x:757,y:564,t:1526918997114};\\\", \\\"{x:756,y:563,t:1526918997131};\\\", \\\"{x:756,y:562,t:1526918997148};\\\", \\\"{x:755,y:562,t:1526918997166};\\\", \\\"{x:755,y:561,t:1526918997181};\\\", \\\"{x:755,y:561,t:1526918997198};\\\", \\\"{x:754,y:561,t:1526918997215};\\\", \\\"{x:754,y:561,t:1526918997231};\\\", \\\"{x:754,y:561,t:1526918997247};\\\", \\\"{x:753,y:561,t:1526918997264};\\\", \\\"{x:753,y:561,t:1526918997281};\\\", \\\"{x:753,y:561,t:1526918997303};\\\", \\\"{x:752,y:561,t:1526918997336};\\\", \\\"{x:752,y:561,t:1526918997360};\\\", \\\"{x:752,y:561,t:1526918997369};\\\", \\\"{x:752,y:562,t:1526918997381};\\\", \\\"{x:752,y:562,t:1526918997397};\\\", \\\"{x:752,y:563,t:1526918997414};\\\", \\\"{x:752,y:563,t:1526918997430};\\\", \\\"{x:752,y:565,t:1526918997447};\\\", \\\"{x:752,y:566,t:1526918997464};\\\", \\\"{x:753,y:569,t:1526918997481};\\\", \\\"{x:754,y:571,t:1526918997497};\\\", \\\"{x:755,y:574,t:1526918997514};\\\", \\\"{x:756,y:576,t:1526918997530};\\\", \\\"{x:757,y:578,t:1526918997548};\\\", \\\"{x:758,y:580,t:1526918997564};\\\", \\\"{x:759,y:581,t:1526918997581};\\\", \\\"{x:760,y:583,t:1526918997597};\\\", \\\"{x:760,y:585,t:1526918997614};\\\", \\\"{x:762,y:587,t:1526918997632};\\\", \\\"{x:763,y:589,t:1526918997648};\\\", \\\"{x:764,y:591,t:1526918997665};\\\", \\\"{x:765,y:594,t:1526918997681};\\\", \\\"{x:767,y:597,t:1526918997697};\\\", \\\"{x:768,y:600,t:1526918997714};\\\", \\\"{x:771,y:603,t:1526918997731};\\\", \\\"{x:773,y:606,t:1526918997748};\\\", \\\"{x:775,y:609,t:1526918997765};\\\", \\\"{x:779,y:614,t:1526918997782};\\\", \\\"{x:781,y:617,t:1526918997798};\\\", \\\"{x:784,y:623,t:1526918997814};\\\", \\\"{x:787,y:627,t:1526918997831};\\\", \\\"{x:789,y:631,t:1526918997849};\\\", \\\"{x:791,y:635,t:1526918997865};\\\", \\\"{x:793,y:639,t:1526918997882};\\\", \\\"{x:796,y:645,t:1526918997897};\\\", \\\"{x:797,y:648,t:1526918997914};\\\", \\\"{x:799,y:652,t:1526918997931};\\\", \\\"{x:801,y:656,t:1526918997948};\\\", \\\"{x:803,y:660,t:1526918997964};\\\", \\\"{x:805,y:666,t:1526918997980};\\\", \\\"{x:808,y:672,t:1526918997998};\\\", \\\"{x:810,y:677,t:1526918998014};\\\", \\\"{x:813,y:682,t:1526918998031};\\\", \\\"{x:815,y:687,t:1526918998049};\\\", \\\"{x:817,y:691,t:1526918998064};\\\", \\\"{x:818,y:694,t:1526918998081};\\\", \\\"{x:820,y:698,t:1526918998097};\\\", \\\"{x:822,y:702,t:1526918998114};\\\", \\\"{x:823,y:706,t:1526918998131};\\\", \\\"{x:824,y:708,t:1526918998148};\\\", \\\"{x:825,y:710,t:1526918998164};\\\", \\\"{x:826,y:711,t:1526918998181};\\\", \\\"{x:827,y:713,t:1526918998197};\\\", \\\"{x:828,y:716,t:1526918998213};\\\", \\\"{x:830,y:719,t:1526918998231};\\\", \\\"{x:831,y:721,t:1526918998248};\\\", \\\"{x:833,y:724,t:1526918998265};\\\", \\\"{x:834,y:726,t:1526918998282};\\\", \\\"{x:835,y:728,t:1526918998297};\\\", \\\"{x:836,y:730,t:1526918998314};\\\", \\\"{x:838,y:733,t:1526918998330};\\\", \\\"{x:839,y:735,t:1526918998347};\\\", \\\"{x:840,y:737,t:1526918998365};\\\", \\\"{x:842,y:740,t:1526918998382};\\\", \\\"{x:843,y:742,t:1526918998398};\\\", \\\"{x:844,y:744,t:1526918998414};\\\", \\\"{x:845,y:746,t:1526918998431};\\\", \\\"{x:846,y:747,t:1526918998447};\\\", \\\"{x:846,y:748,t:1526918998465};\\\", \\\"{x:847,y:748,t:1526918998481};\\\", \\\"{x:847,y:749,t:1526918998497};\\\", \\\"{x:847,y:749,t:1526918998514};\\\", \\\"{x:847,y:747,t:1526918998556};\\\", \\\"{x:846,y:744,t:1526918998564};\\\", \\\"{x:844,y:739,t:1526918998581};\\\", \\\"{x:843,y:736,t:1526918998598};\\\", \\\"{x:842,y:732,t:1526918998615};\\\", \\\"{x:841,y:730,t:1526918998632};\\\", \\\"{x:840,y:728,t:1526918998649};\\\", \\\"{x:840,y:725,t:1526918998664};\\\", \\\"{x:837,y:718,t:1526918998682};\\\", \\\"{x:833,y:705,t:1526918998699};\\\", \\\"{x:828,y:688,t:1526918998715};\\\", \\\"{x:824,y:675,t:1526918998731};\\\", \\\"{x:821,y:665,t:1526918998747};\\\", \\\"{x:816,y:650,t:1526918998765};\\\", \\\"{x:815,y:645,t:1526918998781};\\\", \\\"{x:813,y:642,t:1526918998799};\\\", \\\"{x:812,y:640,t:1526918998816};\\\", \\\"{x:811,y:639,t:1526918998831};\\\", \\\"{x:809,y:638,t:1526918998848};\\\", \\\"{x:807,y:637,t:1526918998865};\\\", \\\"{x:805,y:637,t:1526918998882};\\\", \\\"{x:803,y:636,t:1526918998899};\\\", \\\"{x:801,y:636,t:1526918998915};\\\", \\\"{x:798,y:636,t:1526918998932};\\\", \\\"{x:794,y:636,t:1526918998948};\\\", \\\"{x:790,y:637,t:1526918998964};\\\", \\\"{x:784,y:638,t:1526918998981};\\\", \\\"{x:779,y:638,t:1526918998998};\\\", \\\"{x:776,y:638,t:1526918999015};\\\", \\\"{x:772,y:638,t:1526918999032};\\\", \\\"{x:768,y:638,t:1526918999049};\\\", \\\"{x:764,y:639,t:1526918999066};\\\", \\\"{x:760,y:640,t:1526918999082};\\\", \\\"{x:754,y:643,t:1526918999098};\\\", \\\"{x:746,y:647,t:1526918999116};\\\", \\\"{x:736,y:656,t:1526918999131};\\\", \\\"{x:719,y:672,t:1526918999148};\\\", \\\"{x:700,y:693,t:1526918999165};\\\", \\\"{x:687,y:709,t:1526918999181};\\\", \\\"{x:676,y:722,t:1526918999197};\\\", \\\"{x:669,y:729,t:1526918999215};\\\", \\\"{x:665,y:732,t:1526918999231};\\\", \\\"{x:664,y:733,t:1526918999248};\\\", \\\"{x:663,y:733,t:1526918999265};\\\", \\\"{x:663,y:732,t:1526918999282};\\\", \\\"{x:664,y:723,t:1526918999299};\\\", \\\"{x:672,y:707,t:1526918999316};\\\", \\\"{x:688,y:680,t:1526918999332};\\\", \\\"{x:707,y:648,t:1526918999348};\\\", \\\"{x:730,y:615,t:1526918999365};\\\", \\\"{x:745,y:594,t:1526918999381};\\\", \\\"{x:770,y:561,t:1526918999398};\\\", \\\"{x:784,y:542,t:1526918999414};\\\", \\\"{x:796,y:526,t:1526918999432};\\\", \\\"{x:806,y:512,t:1526918999448};\\\", \\\"{x:815,y:499,t:1526918999464};\\\", \\\"{x:821,y:490,t:1526918999481};\\\", \\\"{x:828,y:479,t:1526918999498};\\\", \\\"{x:834,y:469,t:1526918999515};\\\", \\\"{x:839,y:460,t:1526918999532};\\\", \\\"{x:843,y:450,t:1526918999548};\\\", \\\"{x:849,y:435,t:1526918999565};\\\", \\\"{x:851,y:425,t:1526918999581};\\\", \\\"{x:853,y:417,t:1526918999597};\\\", \\\"{x:855,y:408,t:1526918999615};\\\", \\\"{x:856,y:403,t:1526918999631};\\\", \\\"{x:857,y:399,t:1526918999648};\\\", \\\"{x:857,y:395,t:1526918999665};\\\", \\\"{x:858,y:392,t:1526918999681};\\\", \\\"{x:858,y:388,t:1526918999699};\\\", \\\"{x:858,y:386,t:1526918999715};\\\", \\\"{x:858,y:384,t:1526918999732};\\\", \\\"{x:858,y:382,t:1526918999749};\\\", \\\"{x:858,y:380,t:1526918999765};\\\", \\\"{x:857,y:378,t:1526918999782};\\\", \\\"{x:857,y:377,t:1526918999798};\\\", \\\"{x:857,y:375,t:1526918999815};\\\", \\\"{x:856,y:374,t:1526918999831};\\\", \\\"{x:856,y:374,t:1526918999848};\\\", \\\"{x:856,y:374,t:1526918999864};\\\", \\\"{x:856,y:373,t:1526918999882};\\\", \\\"{x:856,y:371,t:1526918999899};\\\", \\\"{x:855,y:369,t:1526918999915};\\\", \\\"{x:855,y:367,t:1526918999932};\\\", \\\"{x:854,y:366,t:1526918999949};\\\", \\\"{x:854,y:365,t:1526918999966};\\\", \\\"{x:853,y:365,t:1526918999982};\\\", \\\"{x:853,y:365,t:1526918999997};\\\", \\\"{x:853,y:364,t:1526919000023};\\\", \\\"{x:853,y:365,t:1526919002474};\\\", \\\"{x:853,y:367,t:1526919002482};\\\", \\\"{x:854,y:373,t:1526919002498};\\\", \\\"{x:856,y:381,t:1526919002514};\\\", \\\"{x:858,y:389,t:1526919002532};\\\", \\\"{x:860,y:395,t:1526919002548};\\\", \\\"{x:863,y:401,t:1526919002566};\\\", \\\"{x:865,y:407,t:1526919002582};\\\", \\\"{x:867,y:413,t:1526919002598};\\\", \\\"{x:869,y:420,t:1526919002616};\\\", \\\"{x:872,y:429,t:1526919002632};\\\", \\\"{x:876,y:439,t:1526919002648};\\\", \\\"{x:879,y:449,t:1526919002664};\\\", \\\"{x:882,y:455,t:1526919002681};\\\", \\\"{x:884,y:462,t:1526919002698};\\\", \\\"{x:886,y:465,t:1526919002715};\\\", \\\"{x:886,y:466,t:1526919002731};\\\", \\\"{x:887,y:467,t:1526919002748};\\\", \\\"{x:887,y:468,t:1526919002766};\\\", \\\"{x:888,y:469,t:1526919002782};\\\", \\\"{x:889,y:470,t:1526919002798};\\\", \\\"{x:889,y:471,t:1526919002815};\\\", \\\"{x:890,y:471,t:1526919002832};\\\", \\\"{x:891,y:472,t:1526919002848};\\\", \\\"{x:892,y:473,t:1526919002865};\\\", \\\"{x:892,y:474,t:1526919002881};\\\", \\\"{x:893,y:474,t:1526919002897};\\\", \\\"{x:895,y:476,t:1526919002914};\\\", \\\"{x:896,y:476,t:1526919002932};\\\", \\\"{x:898,y:478,t:1526919002948};\\\", \\\"{x:900,y:479,t:1526919002965};\\\", \\\"{x:901,y:480,t:1526919002982};\\\", \\\"{x:903,y:480,t:1526919002998};\\\", \\\"{x:906,y:482,t:1526919003015};\\\", \\\"{x:909,y:484,t:1526919003032};\\\", \\\"{x:912,y:487,t:1526919003049};\\\", \\\"{x:915,y:492,t:1526919003066};\\\", \\\"{x:918,y:498,t:1526919003081};\\\", \\\"{x:921,y:504,t:1526919003098};\\\", \\\"{x:925,y:514,t:1526919003114};\\\", \\\"{x:928,y:522,t:1526919003132};\\\", \\\"{x:931,y:528,t:1526919003148};\\\", \\\"{x:934,y:535,t:1526919003165};\\\", \\\"{x:936,y:539,t:1526919003182};\\\", \\\"{x:939,y:544,t:1526919003198};\\\", \\\"{x:941,y:547,t:1526919003214};\\\", \\\"{x:942,y:549,t:1526919003232};\\\", \\\"{x:943,y:551,t:1526919003248};\\\", \\\"{x:944,y:552,t:1526919003265};\\\", \\\"{x:944,y:553,t:1526919003282};\\\", \\\"{x:945,y:553,t:1526919003299};\\\", \\\"{x:945,y:554,t:1526919003315};\\\", \\\"{x:945,y:555,t:1526919003331};\\\", \\\"{x:945,y:555,t:1526919003349};\\\", \\\"{x:945,y:556,t:1526919003365};\\\", \\\"{x:945,y:558,t:1526919003381};\\\", \\\"{x:945,y:560,t:1526919003398};\\\", \\\"{x:945,y:562,t:1526919003415};\\\", \\\"{x:945,y:563,t:1526919003432};\\\", \\\"{x:945,y:564,t:1526919003449};\\\", \\\"{x:945,y:565,t:1526919003465};\\\", \\\"{x:945,y:566,t:1526919003483};\\\", \\\"{x:945,y:567,t:1526919003499};\\\", \\\"{x:945,y:567,t:1526919003514};\\\", \\\"{x:945,y:568,t:1526919003532};\\\", \\\"{x:945,y:568,t:1526919004052};\\\", \\\"{x:944,y:568,t:1526919004066};\\\", \\\"{x:942,y:568,t:1526919004082};\\\", \\\"{x:939,y:568,t:1526919004099};\\\", \\\"{x:936,y:568,t:1526919004114};\\\", \\\"{x:933,y:568,t:1526919004132};\\\", \\\"{x:929,y:568,t:1526919004149};\\\", \\\"{x:927,y:568,t:1526919004164};\\\", \\\"{x:926,y:568,t:1526919004182};\\\", \\\"{x:924,y:568,t:1526919004198};\\\", \\\"{x:924,y:567,t:1526919004215};\\\", \\\"{x:923,y:566,t:1526919004232};\\\", \\\"{x:922,y:564,t:1526919004249};\\\", \\\"{x:921,y:563,t:1526919004266};\\\", \\\"{x:921,y:561,t:1526919004282};\\\", \\\"{x:921,y:560,t:1526919004299};\\\", \\\"{x:920,y:559,t:1526919004315};\\\", \\\"{x:920,y:559,t:1526919004332};\\\", \\\"{x:920,y:559,t:1526919004348};\\\", \\\"{x:920,y:558,t:1526919004364};\\\", \\\"{x:919,y:558,t:1526919004381};\\\", \\\"{x:919,y:558,t:1526919004399};\\\", \\\"{x:919,y:558,t:1526919004415};\\\", \\\"{x:918,y:558,t:1526919004437};\\\", \\\"{x:918,y:558,t:1526919004516};\\\", \\\"{x:918,y:558,t:1526919004532};\\\", \\\"{x:918,y:559,t:1526919004548};\\\", \\\"{x:919,y:559,t:1526919004621};\\\", \\\"{x:919,y:559,t:1526919004648};\\\", \\\"{x:920,y:558,t:1526919004665};\\\", \\\"{x:921,y:558,t:1526919004682};\\\", \\\"{x:922,y:557,t:1526919004699};\\\", \\\"{x:924,y:557,t:1526919004716};\\\", \\\"{x:926,y:556,t:1526919004731};\\\", \\\"{x:927,y:555,t:1526919004748};\\\", \\\"{x:928,y:555,t:1526919004765};\\\", \\\"{x:929,y:555,t:1526919004782};\\\", \\\"{x:930,y:555,t:1526919004798};\\\", \\\"{x:931,y:555,t:1526919004814};\\\", \\\"{x:932,y:555,t:1526919004832};\\\", \\\"{x:933,y:555,t:1526919004847};\\\", \\\"{x:934,y:555,t:1526919004865};\\\", \\\"{x:935,y:555,t:1526919004882};\\\", \\\"{x:935,y:555,t:1526919004898};\\\", \\\"{x:935,y:555,t:1526919004915};\\\", \\\"{x:935,y:555,t:1526919004933};\\\", \\\"{x:935,y:555,t:1526919004949};\\\", \\\"{x:935,y:556,t:1526919004965};\\\", \\\"{x:935,y:556,t:1526919005006};\\\", \\\"{x:934,y:556,t:1526919005327};\\\", \\\"{x:932,y:556,t:1526919005335};\\\", \\\"{x:928,y:558,t:1526919005349};\\\", \\\"{x:910,y:564,t:1526919005365};\\\", \\\"{x:882,y:573,t:1526919005382};\\\", \\\"{x:847,y:584,t:1526919005398};\\\", \\\"{x:810,y:595,t:1526919005415};\\\", \\\"{x:778,y:603,t:1526919005431};\\\", \\\"{x:757,y:607,t:1526919005449};\\\", \\\"{x:742,y:608,t:1526919005466};\\\", \\\"{x:737,y:608,t:1526919005482};\\\", \\\"{x:731,y:608,t:1526919005499};\\\", \\\"{x:729,y:605,t:1526919005516};\\\", \\\"{x:727,y:602,t:1526919005532};\\\", \\\"{x:726,y:599,t:1526919005549};\\\", \\\"{x:725,y:596,t:1526919005566};\\\", \\\"{x:725,y:595,t:1526919005582};\\\", \\\"{x:725,y:593,t:1526919005598};\\\", \\\"{x:725,y:591,t:1526919005615};\\\", \\\"{x:726,y:589,t:1526919005632};\\\", \\\"{x:729,y:586,t:1526919005647};\\\", \\\"{x:732,y:582,t:1526919005665};\\\", \\\"{x:737,y:577,t:1526919005682};\\\", \\\"{x:741,y:572,t:1526919005699};\\\", \\\"{x:745,y:568,t:1526919005715};\\\", \\\"{x:747,y:565,t:1526919005732};\\\", \\\"{x:749,y:564,t:1526919005749};\\\", \\\"{x:749,y:563,t:1526919005766};\\\", \\\"{x:750,y:563,t:1526919005782};\\\", \\\"{x:750,y:563,t:1526919005798};\\\", \\\"{x:750,y:563,t:1526919005824};\\\", \\\"{x:750,y:564,t:1526919005832};\\\", \\\"{x:750,y:564,t:1526919005848};\\\", \\\"{x:751,y:565,t:1526919005865};\\\", \\\"{x:751,y:565,t:1526919005881};\\\", \\\"{x:751,y:567,t:1526919005899};\\\", \\\"{x:753,y:568,t:1526919005915};\\\", \\\"{x:754,y:570,t:1526919005932};\\\", \\\"{x:756,y:573,t:1526919005949};\\\", \\\"{x:758,y:577,t:1526919005966};\\\", \\\"{x:760,y:581,t:1526919005982};\\\", \\\"{x:763,y:585,t:1526919005999};\\\", \\\"{x:767,y:591,t:1526919006015};\\\", \\\"{x:771,y:597,t:1526919006032};\\\", \\\"{x:778,y:606,t:1526919006048};\\\", \\\"{x:782,y:613,t:1526919006065};\\\", \\\"{x:786,y:619,t:1526919006081};\\\", \\\"{x:790,y:625,t:1526919006098};\\\", \\\"{x:795,y:632,t:1526919006115};\\\", \\\"{x:799,y:638,t:1526919006131};\\\", \\\"{x:803,y:644,t:1526919006148};\\\", \\\"{x:807,y:650,t:1526919006166};\\\", \\\"{x:810,y:657,t:1526919006182};\\\", \\\"{x:813,y:663,t:1526919006199};\\\", \\\"{x:816,y:669,t:1526919006215};\\\", \\\"{x:818,y:673,t:1526919006232};\\\", \\\"{x:820,y:678,t:1526919006248};\\\", \\\"{x:824,y:686,t:1526919006265};\\\", \\\"{x:826,y:691,t:1526919006281};\\\", \\\"{x:829,y:695,t:1526919006298};\\\", \\\"{x:831,y:700,t:1526919006316};\\\", \\\"{x:833,y:705,t:1526919006332};\\\", \\\"{x:834,y:709,t:1526919006348};\\\", \\\"{x:837,y:714,t:1526919006365};\\\", \\\"{x:838,y:718,t:1526919006382};\\\", \\\"{x:840,y:722,t:1526919006399};\\\", \\\"{x:841,y:725,t:1526919006416};\\\", \\\"{x:843,y:728,t:1526919006432};\\\", \\\"{x:844,y:731,t:1526919006448};\\\", \\\"{x:845,y:734,t:1526919006465};\\\", \\\"{x:847,y:736,t:1526919006481};\\\", \\\"{x:848,y:738,t:1526919006499};\\\", \\\"{x:848,y:738,t:1526919006514};\\\", \\\"{x:849,y:739,t:1526919006532};\\\", \\\"{x:849,y:739,t:1526919006549};\\\", \\\"{x:849,y:740,t:1526919006566};\\\", \\\"{x:850,y:740,t:1526919006582};\\\", \\\"{x:850,y:740,t:1526919006597};\\\", \\\"{x:850,y:740,t:1526919006615};\\\", \\\"{x:850,y:741,t:1526919006631};\\\", \\\"{x:851,y:741,t:1526919006648};\\\", \\\"{x:851,y:741,t:1526919006665};\\\", \\\"{x:851,y:742,t:1526919006683};\\\", \\\"{x:851,y:742,t:1526919006698};\\\", \\\"{x:851,y:742,t:1526919006715};\\\", \\\"{x:851,y:742,t:1526919006794};\\\", \\\"{x:851,y:741,t:1526919006802};\\\", \\\"{x:851,y:741,t:1526919006816};\\\", \\\"{x:851,y:741,t:1526919006832};\\\", \\\"{x:851,y:740,t:1526919006848};\\\", \\\"{x:851,y:740,t:1526919006864};\\\", \\\"{x:851,y:740,t:1526919006881};\\\", \\\"{x:851,y:739,t:1526919006898};\\\", \\\"{x:852,y:737,t:1526919006915};\\\", \\\"{x:852,y:732,t:1526919006932};\\\", \\\"{x:856,y:722,t:1526919006949};\\\", \\\"{x:862,y:705,t:1526919006965};\\\", \\\"{x:874,y:675,t:1526919006983};\\\", \\\"{x:882,y:656,t:1526919006999};\\\", \\\"{x:892,y:633,t:1526919007015};\\\", \\\"{x:896,y:621,t:1526919007033};\\\", \\\"{x:900,y:613,t:1526919007049};\\\", \\\"{x:903,y:606,t:1526919007065};\\\", \\\"{x:905,y:602,t:1526919007082};\\\", \\\"{x:907,y:599,t:1526919007098};\\\", \\\"{x:908,y:597,t:1526919007114};\\\", \\\"{x:909,y:595,t:1526919007132};\\\", \\\"{x:910,y:594,t:1526919007149};\\\", \\\"{x:911,y:591,t:1526919007165};\\\", \\\"{x:913,y:587,t:1526919007182};\\\", \\\"{x:915,y:584,t:1526919007199};\\\", \\\"{x:916,y:581,t:1526919007215};\\\", \\\"{x:917,y:579,t:1526919007233};\\\", \\\"{x:917,y:578,t:1526919007248};\\\", \\\"{x:917,y:577,t:1526919007266};\\\", \\\"{x:917,y:576,t:1526919007282};\\\", \\\"{x:917,y:574,t:1526919007298};\\\", \\\"{x:917,y:572,t:1526919007315};\\\", \\\"{x:917,y:570,t:1526919007331};\\\", \\\"{x:916,y:569,t:1526919007349};\\\", \\\"{x:916,y:568,t:1526919007365};\\\", \\\"{x:915,y:568,t:1526919007382};\\\", \\\"{x:915,y:567,t:1526919007399};\\\", \\\"{x:915,y:567,t:1526919007415};\\\", \\\"{x:915,y:567,t:1526919007432};\\\", \\\"{x:914,y:567,t:1526919007449};\\\", \\\"{x:914,y:567,t:1526919007465};\\\", \\\"{x:914,y:567,t:1526919007481};\\\", \\\"{x:914,y:567,t:1526919007498};\\\", \\\"{x:913,y:567,t:1526919007516};\\\", \\\"{x:913,y:567,t:1526919007531};\\\", \\\"{x:912,y:567,t:1526919007548};\\\", \\\"{x:912,y:568,t:1526919007565};\\\", \\\"{x:911,y:569,t:1526919007583};\\\", \\\"{x:909,y:571,t:1526919007598};\\\", \\\"{x:907,y:575,t:1526919007615};\\\", \\\"{x:903,y:582,t:1526919007633};\\\", \\\"{x:897,y:591,t:1526919007649};\\\", \\\"{x:893,y:599,t:1526919007667};\\\", \\\"{x:887,y:609,t:1526919007682};\\\", \\\"{x:884,y:618,t:1526919007699};\\\", \\\"{x:881,y:625,t:1526919007715};\\\", \\\"{x:879,y:631,t:1526919007731};\\\", \\\"{x:876,y:640,t:1526919007748};\\\", \\\"{x:873,y:646,t:1526919007766};\\\", \\\"{x:871,y:651,t:1526919007782};\\\", \\\"{x:869,y:657,t:1526919007799};\\\", \\\"{x:866,y:664,t:1526919007815};\\\", \\\"{x:864,y:671,t:1526919007832};\\\", \\\"{x:861,y:679,t:1526919007849};\\\", \\\"{x:857,y:688,t:1526919007866};\\\", \\\"{x:854,y:696,t:1526919007882};\\\", \\\"{x:851,y:704,t:1526919007899};\\\", \\\"{x:847,y:712,t:1526919007915};\\\", \\\"{x:843,y:720,t:1526919007932};\\\", \\\"{x:838,y:731,t:1526919007949};\\\", \\\"{x:834,y:738,t:1526919007965};\\\", \\\"{x:831,y:745,t:1526919007982};\\\", \\\"{x:828,y:751,t:1526919007998};\\\", \\\"{x:826,y:755,t:1526919008015};\\\", \\\"{x:824,y:759,t:1526919008032};\\\", \\\"{x:822,y:762,t:1526919008049};\\\", \\\"{x:821,y:765,t:1526919008066};\\\", \\\"{x:820,y:766,t:1526919008082};\\\", \\\"{x:819,y:767,t:1526919008099};\\\", \\\"{x:819,y:767,t:1526919008114};\\\", \\\"{x:818,y:768,t:1526919008132};\\\", \\\"{x:818,y:768,t:1526919008148};\\\", \\\"{x:818,y:768,t:1526919008165};\\\", \\\"{x:818,y:768,t:1526919008181};\\\", \\\"{x:818,y:767,t:1526919008199};\\\", \\\"{x:818,y:766,t:1526919008215};\\\", \\\"{x:817,y:766,t:1526919008231};\\\", \\\"{x:816,y:765,t:1526919008249};\\\", \\\"{x:815,y:763,t:1526919008266};\\\", \\\"{x:803,y:756,t:1526919008283};\\\", \\\"{x:769,y:733,t:1526919008299};\\\", \\\"{x:722,y:696,t:1526919008316};\\\", \\\"{x:685,y:660,t:1526919008332};\\\", \\\"{x:646,y:616,t:1526919008348};\\\", \\\"{x:627,y:593,t:1526919008365};\\\", \\\"{x:604,y:557,t:1526919008382};\\\", \\\"{x:598,y:537,t:1526919008398};\\\", \\\"{x:597,y:517,t:1526919008415};\\\", \\\"{x:599,y:517,t:1526919008739};\\\", \\\"{x:602,y:517,t:1526919008749};\\\", \\\"{x:612,y:517,t:1526919008766};\\\", \\\"{x:632,y:517,t:1526919008782};\\\", \\\"{x:655,y:523,t:1526919008799};\\\", \\\"{x:683,y:536,t:1526919008815};\\\", \\\"{x:702,y:551,t:1526919008832};\\\", \\\"{x:730,y:577,t:1526919008849};\\\", \\\"{x:742,y:596,t:1526919008865};\\\", \\\"{x:751,y:611,t:1526919008882};\\\", \\\"{x:760,y:627,t:1526919008898};\\\", \\\"{x:767,y:639,t:1526919008915};\\\", \\\"{x:769,y:643,t:1526919008932};\\\", \\\"{x:770,y:646,t:1526919008948};\\\", \\\"{x:770,y:646,t:1526919008965};\\\", \\\"{x:770,y:647,t:1526919008981};\\\", \\\"{x:768,y:645,t:1526919008998};\\\", \\\"{x:768,y:645,t:1526919009147};\\\", \\\"{x:759,y:640,t:1526919009165};\\\", \\\"{x:738,y:627,t:1526919009182};\\\", \\\"{x:688,y:602,t:1526919009199};\\\", \\\"{x:622,y:576,t:1526919009215};\\\", \\\"{x:544,y:550,t:1526919009232};\\\", \\\"{x:490,y:532,t:1526919009249};\\\", \\\"{x:429,y:507,t:1526919009265};\\\", \\\"{x:382,y:483,t:1526919009283};\\\", \\\"{x:359,y:465,t:1526919009300};\\\", \\\"{x:336,y:443,t:1526919009316};\\\", \\\"{x:318,y:408,t:1526919009331};\\\", \\\"{x:316,y:396,t:1526919009350};\\\", \\\"{x:316,y:396,t:1526919009533};\\\", \\\"{x:308,y:391,t:1526919009550};\\\", \\\"{x:294,y:380,t:1526919009567};\\\", \\\"{x:276,y:367,t:1526919009584};\\\", \\\"{x:262,y:359,t:1526919009601};\\\", \\\"{x:249,y:352,t:1526919009616};\\\", \\\"{x:240,y:349,t:1526919009634};\\\", \\\"{x:232,y:347,t:1526919009650};\\\", \\\"{x:224,y:344,t:1526919009666};\\\", \\\"{x:216,y:340,t:1526919009683};\\\", \\\"{x:208,y:336,t:1526919009699};\\\", \\\"{x:196,y:327,t:1526919009718};\\\", \\\"{x:186,y:319,t:1526919009734};\\\", \\\"{x:181,y:313,t:1526919009749};\\\", \\\"{x:173,y:304,t:1526919009766};\\\", \\\"{x:167,y:296,t:1526919009784};\\\", \\\"{x:162,y:289,t:1526919009801};\\\", \\\"{x:158,y:284,t:1526919009816};\\\", \\\"{x:155,y:282,t:1526919009833};\\\", \\\"{x:153,y:280,t:1526919009850};\\\", \\\"{x:151,y:280,t:1526919009867};\\\", \\\"{x:149,y:280,t:1526919009883};\\\", \\\"{x:148,y:280,t:1526919009900};\\\", \\\"{x:146,y:280,t:1526919009916};\\\", \\\"{x:144,y:280,t:1526919009934};\\\", \\\"{x:143,y:280,t:1526919009950};\\\", \\\"{x:142,y:281,t:1526919009966};\\\", \\\"{x:141,y:281,t:1526919009984};\\\", \\\"{x:141,y:282,t:1526919010000};\\\", \\\"{x:141,y:282,t:1526919010014};\\\", \\\"{x:154,y:293,t:1526919010239};\\\", \\\"{x:160,y:303,t:1526919010252};\\\", \\\"{x:180,y:334,t:1526919010268};\\\", \\\"{x:200,y:364,t:1526919010284};\\\", \\\"{x:231,y:415,t:1526919010301};\\\", \\\"{x:271,y:477,t:1526919010317};\\\", \\\"{x:296,y:518,t:1526919010334};\\\", \\\"{x:326,y:569,t:1526919010350};\\\", \\\"{x:332,y:580,t:1526919010366};\\\", \\\"{x:340,y:595,t:1526919010383};\\\", \\\"{x:343,y:601,t:1526919010400};\\\", \\\"{x:345,y:604,t:1526919010416};\\\", \\\"{x:345,y:604,t:1526919010433};\\\", \\\"{x:345,y:605,t:1526919010450};\\\", \\\"{x:345,y:605,t:1526919010467};\\\", \\\"{x:343,y:605,t:1526919010519};\\\", \\\"{x:339,y:604,t:1526919010532};\\\", \\\"{x:324,y:590,t:1526919010550};\\\", \\\"{x:308,y:571,t:1526919010566};\\\", \\\"{x:300,y:560,t:1526919010584};\\\", \\\"{x:293,y:551,t:1526919010600};\\\", \\\"{x:289,y:545,t:1526919010616};\\\", \\\"{x:285,y:541,t:1526919010633};\\\", \\\"{x:283,y:539,t:1526919010650};\\\", \\\"{x:282,y:538,t:1526919010667};\\\", \\\"{x:281,y:538,t:1526919010684};\\\", \\\"{x:281,y:537,t:1526919010700};\\\", \\\"{x:280,y:537,t:1526919010716};\\\", \\\"{x:245,y:507,t:1526919011191};\\\", \\\"{x:251,y:507,t:1526919011199};\\\", \\\"{x:278,y:503,t:1526919011217};\\\", \\\"{x:323,y:496,t:1526919011233};\\\", \\\"{x:391,y:485,t:1526919011250};\\\", \\\"{x:464,y:476,t:1526919011266};\\\", \\\"{x:536,y:468,t:1526919011284};\\\", \\\"{x:580,y:463,t:1526919011300};\\\", \\\"{x:606,y:458,t:1526919011317};\\\", \\\"{x:633,y:449,t:1526919011334};\\\", \\\"{x:644,y:438,t:1526919011350};\\\", \\\"{x:652,y:420,t:1526919011367};\\\", \\\"{x:658,y:399,t:1526919011382};\\\", \\\"{x:664,y:366,t:1526919011399};\\\", \\\"{x:667,y:332,t:1526919011416};\\\", \\\"{x:667,y:310,t:1526919011433};\\\", \\\"{x:665,y:299,t:1526919011450};\\\", \\\"{x:661,y:289,t:1526919011466};\\\", \\\"{x:656,y:281,t:1526919011484};\\\", \\\"{x:651,y:275,t:1526919011500};\\\", \\\"{x:643,y:267,t:1526919011517};\\\", \\\"{x:636,y:258,t:1526919011534};\\\", \\\"{x:631,y:251,t:1526919011550};\\\", \\\"{x:626,y:242,t:1526919011566};\\\", \\\"{x:622,y:234,t:1526919011583};\\\", \\\"{x:618,y:227,t:1526919011599};\\\", \\\"{x:617,y:219,t:1526919011616};\\\" ] }, { \\\"rt\\\": 6291, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 2118776, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:618,y:249,t:1526919015233};\\\", \\\"{x:629,y:252,t:1526919015250};\\\", \\\"{x:645,y:257,t:1526919015267};\\\", \\\"{x:689,y:275,t:1526919015285};\\\", \\\"{x:746,y:303,t:1526919015301};\\\", \\\"{x:808,y:338,t:1526919015318};\\\", \\\"{x:854,y:369,t:1526919015334};\\\", \\\"{x:903,y:403,t:1526919015350};\\\", \\\"{x:925,y:420,t:1526919015367};\\\", \\\"{x:933,y:427,t:1526919015384};\\\", \\\"{x:945,y:439,t:1526919015400};\\\", \\\"{x:948,y:442,t:1526919015417};\\\", \\\"{x:948,y:443,t:1526919015433};\\\", \\\"{x:949,y:444,t:1526919015451};\\\", \\\"{x:949,y:444,t:1526919015503};\\\", \\\"{x:949,y:444,t:1526919015517};\\\", \\\"{x:949,y:444,t:1526919015534};\\\", \\\"{x:949,y:445,t:1526919015550};\\\", \\\"{x:947,y:449,t:1526919015567};\\\", \\\"{x:944,y:456,t:1526919015583};\\\", \\\"{x:938,y:467,t:1526919015600};\\\", \\\"{x:935,y:474,t:1526919015617};\\\", \\\"{x:932,y:477,t:1526919015634};\\\", \\\"{x:930,y:480,t:1526919015650};\\\", \\\"{x:928,y:482,t:1526919015667};\\\", \\\"{x:926,y:483,t:1526919015684};\\\", \\\"{x:923,y:483,t:1526919015700};\\\", \\\"{x:921,y:483,t:1526919015717};\\\", \\\"{x:919,y:483,t:1526919015734};\\\", \\\"{x:917,y:483,t:1526919015753};\\\", \\\"{x:916,y:483,t:1526919015766};\\\", \\\"{x:916,y:483,t:1526919015784};\\\", \\\"{x:916,y:483,t:1526919015799};\\\", \\\"{x:915,y:483,t:1526919015816};\\\", \\\"{x:915,y:483,t:1526919015848};\\\", \\\"{x:915,y:483,t:1526919016097};\\\", \\\"{x:915,y:483,t:1526919016120};\\\", \\\"{x:915,y:482,t:1526919016134};\\\", \\\"{x:915,y:482,t:1526919016150};\\\", \\\"{x:915,y:482,t:1526919016167};\\\", \\\"{x:915,y:482,t:1526919016183};\\\", \\\"{x:915,y:482,t:1526919016554};\\\", \\\"{x:912,y:482,t:1526919016568};\\\", \\\"{x:885,y:489,t:1526919016585};\\\", \\\"{x:820,y:503,t:1526919016601};\\\", \\\"{x:716,y:518,t:1526919016616};\\\", \\\"{x:633,y:525,t:1526919016633};\\\", \\\"{x:529,y:526,t:1526919016650};\\\", \\\"{x:484,y:523,t:1526919016668};\\\", \\\"{x:461,y:513,t:1526919016684};\\\", \\\"{x:455,y:507,t:1526919016701};\\\", \\\"{x:455,y:506,t:1526919016926};\\\", \\\"{x:455,y:501,t:1526919016935};\\\", \\\"{x:453,y:476,t:1526919016952};\\\", \\\"{x:443,y:438,t:1526919016967};\\\", \\\"{x:427,y:399,t:1526919016984};\\\", \\\"{x:410,y:377,t:1526919017000};\\\", \\\"{x:376,y:348,t:1526919017018};\\\", \\\"{x:352,y:340,t:1526919017034};\\\", \\\"{x:318,y:333,t:1526919017052};\\\", \\\"{x:284,y:326,t:1526919017069};\\\", \\\"{x:255,y:318,t:1526919017084};\\\", \\\"{x:230,y:308,t:1526919017101};\\\", \\\"{x:214,y:300,t:1526919017117};\\\", \\\"{x:200,y:291,t:1526919017135};\\\", \\\"{x:190,y:284,t:1526919017152};\\\", \\\"{x:184,y:276,t:1526919017169};\\\", \\\"{x:182,y:269,t:1526919017184};\\\", \\\"{x:184,y:263,t:1526919017200};\\\", \\\"{x:204,y:252,t:1526919017218};\\\", \\\"{x:237,y:248,t:1526919017233};\\\", \\\"{x:280,y:248,t:1526919017250};\\\", \\\"{x:323,y:256,t:1526919017267};\\\", \\\"{x:351,y:264,t:1526919017286};\\\", \\\"{x:379,y:273,t:1526919017300};\\\", \\\"{x:394,y:279,t:1526919017318};\\\", \\\"{x:403,y:283,t:1526919017333};\\\", \\\"{x:409,y:286,t:1526919017351};\\\", \\\"{x:412,y:288,t:1526919017366};\\\", \\\"{x:413,y:289,t:1526919017384};\\\", \\\"{x:413,y:289,t:1526919017400};\\\", \\\"{x:412,y:289,t:1526919017431};\\\", \\\"{x:411,y:289,t:1526919017439};\\\", \\\"{x:410,y:289,t:1526919017451};\\\", \\\"{x:407,y:289,t:1526919017467};\\\", \\\"{x:404,y:288,t:1526919017484};\\\", \\\"{x:401,y:286,t:1526919017502};\\\", \\\"{x:399,y:285,t:1526919017518};\\\", \\\"{x:397,y:283,t:1526919017534};\\\", \\\"{x:396,y:282,t:1526919017550};\\\", \\\"{x:395,y:281,t:1526919017566};\\\", \\\"{x:395,y:286,t:1526919017816};\\\", \\\"{x:391,y:308,t:1526919017834};\\\", \\\"{x:379,y:355,t:1526919017852};\\\", \\\"{x:360,y:430,t:1526919017868};\\\", \\\"{x:348,y:480,t:1526919017884};\\\", \\\"{x:339,y:516,t:1526919017901};\\\", \\\"{x:332,y:543,t:1526919017918};\\\", \\\"{x:327,y:565,t:1526919017934};\\\", \\\"{x:324,y:574,t:1526919017951};\\\", \\\"{x:321,y:582,t:1526919017966};\\\", \\\"{x:320,y:585,t:1526919017984};\\\", \\\"{x:316,y:589,t:1526919018000};\\\", \\\"{x:314,y:590,t:1526919018017};\\\", \\\"{x:311,y:591,t:1526919018034};\\\", \\\"{x:308,y:592,t:1526919018050};\\\", \\\"{x:305,y:593,t:1526919018067};\\\", \\\"{x:302,y:593,t:1526919018084};\\\", \\\"{x:298,y:593,t:1526919018100};\\\", \\\"{x:296,y:593,t:1526919018117};\\\", \\\"{x:294,y:590,t:1526919018134};\\\", \\\"{x:292,y:586,t:1526919018151};\\\", \\\"{x:289,y:580,t:1526919018167};\\\", \\\"{x:285,y:574,t:1526919018183};\\\", \\\"{x:282,y:569,t:1526919018200};\\\", \\\"{x:279,y:563,t:1526919018218};\\\", \\\"{x:277,y:560,t:1526919018233};\\\", \\\"{x:276,y:558,t:1526919018250};\\\", \\\"{x:274,y:556,t:1526919018267};\\\", \\\"{x:274,y:556,t:1526919018284};\\\", \\\"{x:273,y:555,t:1526919018300};\\\", \\\"{x:273,y:522,t:1526919018834};\\\", \\\"{x:278,y:513,t:1526919018849};\\\", \\\"{x:289,y:495,t:1526919018867};\\\", \\\"{x:310,y:466,t:1526919018883};\\\", \\\"{x:343,y:432,t:1526919018900};\\\", \\\"{x:387,y:397,t:1526919018918};\\\", \\\"{x:434,y:372,t:1526919018934};\\\", \\\"{x:481,y:353,t:1526919018950};\\\", \\\"{x:509,y:347,t:1526919018967};\\\", \\\"{x:533,y:343,t:1526919018984};\\\", \\\"{x:549,y:343,t:1526919019001};\\\", \\\"{x:563,y:343,t:1526919019019};\\\", \\\"{x:568,y:343,t:1526919019033};\\\", \\\"{x:570,y:343,t:1526919019050};\\\" ] }, { \\\"rt\\\": 6392, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 2126404, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:571,y:373,t:1526919021058};\\\", \\\"{x:574,y:373,t:1526919021068};\\\", \\\"{x:587,y:377,t:1526919021085};\\\", \\\"{x:625,y:395,t:1526919021102};\\\", \\\"{x:688,y:430,t:1526919021117};\\\", \\\"{x:802,y:503,t:1526919021135};\\\", \\\"{x:896,y:568,t:1526919021152};\\\", \\\"{x:957,y:615,t:1526919021168};\\\", \\\"{x:1003,y:655,t:1526919021184};\\\", \\\"{x:1029,y:687,t:1526919021201};\\\", \\\"{x:1042,y:716,t:1526919021218};\\\", \\\"{x:1045,y:732,t:1526919021234};\\\", \\\"{x:1042,y:739,t:1526919021252};\\\", \\\"{x:1036,y:743,t:1526919021268};\\\", \\\"{x:1030,y:745,t:1526919021285};\\\", \\\"{x:1019,y:746,t:1526919021301};\\\", \\\"{x:1008,y:746,t:1526919021319};\\\", \\\"{x:997,y:744,t:1526919021335};\\\", \\\"{x:984,y:741,t:1526919021352};\\\", \\\"{x:972,y:739,t:1526919021368};\\\", \\\"{x:963,y:739,t:1526919021384};\\\", \\\"{x:958,y:739,t:1526919021401};\\\", \\\"{x:953,y:739,t:1526919021418};\\\", \\\"{x:947,y:739,t:1526919021434};\\\", \\\"{x:944,y:741,t:1526919021450};\\\", \\\"{x:941,y:743,t:1526919021467};\\\", \\\"{x:938,y:746,t:1526919021484};\\\", \\\"{x:936,y:748,t:1526919021502};\\\", \\\"{x:933,y:751,t:1526919021519};\\\", \\\"{x:932,y:752,t:1526919021534};\\\", \\\"{x:931,y:753,t:1526919021552};\\\", \\\"{x:931,y:754,t:1526919021568};\\\", \\\"{x:931,y:754,t:1526919021584};\\\", \\\"{x:931,y:755,t:1526919021601};\\\", \\\"{x:931,y:755,t:1526919021617};\\\", \\\"{x:931,y:756,t:1526919021635};\\\", \\\"{x:931,y:755,t:1526919021703};\\\", \\\"{x:931,y:755,t:1526919021718};\\\", \\\"{x:930,y:754,t:1526919021735};\\\", \\\"{x:929,y:753,t:1526919021751};\\\", \\\"{x:928,y:752,t:1526919021769};\\\", \\\"{x:928,y:751,t:1526919021785};\\\", \\\"{x:928,y:750,t:1526919021802};\\\", \\\"{x:928,y:749,t:1526919021817};\\\", \\\"{x:928,y:746,t:1526919021834};\\\", \\\"{x:931,y:739,t:1526919021851};\\\", \\\"{x:934,y:733,t:1526919021869};\\\", \\\"{x:937,y:727,t:1526919021884};\\\", \\\"{x:939,y:724,t:1526919021901};\\\", \\\"{x:942,y:720,t:1526919021917};\\\", \\\"{x:943,y:717,t:1526919021935};\\\", \\\"{x:944,y:716,t:1526919021952};\\\", \\\"{x:945,y:715,t:1526919021968};\\\", \\\"{x:946,y:714,t:1526919021986};\\\", \\\"{x:946,y:713,t:1526919022002};\\\", \\\"{x:947,y:712,t:1526919022018};\\\", \\\"{x:948,y:710,t:1526919022035};\\\", \\\"{x:949,y:709,t:1526919022051};\\\", \\\"{x:951,y:705,t:1526919022068};\\\", \\\"{x:953,y:702,t:1526919022085};\\\", \\\"{x:955,y:699,t:1526919022101};\\\", \\\"{x:957,y:694,t:1526919022118};\\\", \\\"{x:959,y:690,t:1526919022135};\\\", \\\"{x:961,y:686,t:1526919022152};\\\", \\\"{x:963,y:683,t:1526919022168};\\\", \\\"{x:964,y:680,t:1526919022186};\\\", \\\"{x:966,y:677,t:1526919022202};\\\", \\\"{x:967,y:673,t:1526919022217};\\\", \\\"{x:969,y:669,t:1526919022235};\\\", \\\"{x:971,y:663,t:1526919022250};\\\", \\\"{x:975,y:652,t:1526919022268};\\\", \\\"{x:978,y:646,t:1526919022285};\\\", \\\"{x:980,y:641,t:1526919022302};\\\", \\\"{x:983,y:636,t:1526919022318};\\\", \\\"{x:987,y:627,t:1526919022335};\\\", \\\"{x:993,y:614,t:1526919022351};\\\", \\\"{x:1000,y:598,t:1526919022368};\\\", \\\"{x:1008,y:579,t:1526919022385};\\\", \\\"{x:1013,y:567,t:1526919022402};\\\", \\\"{x:1020,y:551,t:1526919022418};\\\", \\\"{x:1028,y:533,t:1526919022434};\\\", \\\"{x:1035,y:516,t:1526919022451};\\\", \\\"{x:1050,y:488,t:1526919022468};\\\", \\\"{x:1065,y:463,t:1526919022484};\\\", \\\"{x:1074,y:448,t:1526919022502};\\\", \\\"{x:1083,y:430,t:1526919022517};\\\", \\\"{x:1090,y:416,t:1526919022535};\\\", \\\"{x:1094,y:405,t:1526919022552};\\\", \\\"{x:1097,y:396,t:1526919022568};\\\", \\\"{x:1099,y:387,t:1526919022585};\\\", \\\"{x:1102,y:379,t:1526919022602};\\\", \\\"{x:1105,y:370,t:1526919022619};\\\", \\\"{x:1110,y:360,t:1526919022634};\\\", \\\"{x:1116,y:347,t:1526919022651};\\\", \\\"{x:1120,y:335,t:1526919022667};\\\", \\\"{x:1125,y:321,t:1526919022686};\\\", \\\"{x:1127,y:315,t:1526919022701};\\\", \\\"{x:1128,y:311,t:1526919022718};\\\", \\\"{x:1129,y:309,t:1526919022735};\\\", \\\"{x:1129,y:308,t:1526919022751};\\\", \\\"{x:1129,y:308,t:1526919022768};\\\", \\\"{x:1129,y:308,t:1526919022785};\\\", \\\"{x:1129,y:308,t:1526919022804};\\\", \\\"{x:1125,y:314,t:1526919022819};\\\", \\\"{x:1112,y:335,t:1526919022835};\\\", \\\"{x:1072,y:377,t:1526919022852};\\\", \\\"{x:1015,y:420,t:1526919022868};\\\", \\\"{x:901,y:490,t:1526919022885};\\\", \\\"{x:705,y:594,t:1526919022901};\\\", \\\"{x:618,y:639,t:1526919022919};\\\", \\\"{x:583,y:654,t:1526919022933};\\\", \\\"{x:548,y:666,t:1526919022951};\\\", \\\"{x:530,y:671,t:1526919022969};\\\", \\\"{x:530,y:670,t:1526919023189};\\\", \\\"{x:525,y:661,t:1526919023202};\\\", \\\"{x:492,y:607,t:1526919023218};\\\", \\\"{x:451,y:550,t:1526919023235};\\\", \\\"{x:392,y:483,t:1526919023252};\\\", \\\"{x:355,y:452,t:1526919023269};\\\", \\\"{x:327,y:434,t:1526919023285};\\\", \\\"{x:296,y:417,t:1526919023303};\\\", \\\"{x:275,y:406,t:1526919023318};\\\", \\\"{x:266,y:402,t:1526919023336};\\\", \\\"{x:258,y:398,t:1526919023352};\\\", \\\"{x:252,y:396,t:1526919023367};\\\", \\\"{x:245,y:393,t:1526919023385};\\\", \\\"{x:237,y:389,t:1526919023402};\\\", \\\"{x:228,y:385,t:1526919023418};\\\", \\\"{x:216,y:380,t:1526919023435};\\\", \\\"{x:205,y:376,t:1526919023452};\\\", \\\"{x:197,y:373,t:1526919023470};\\\", \\\"{x:189,y:369,t:1526919023484};\\\", \\\"{x:183,y:366,t:1526919023503};\\\", \\\"{x:177,y:363,t:1526919023518};\\\", \\\"{x:173,y:361,t:1526919023534};\\\", \\\"{x:171,y:359,t:1526919023551};\\\", \\\"{x:170,y:358,t:1526919023568};\\\", \\\"{x:170,y:357,t:1526919023584};\\\", \\\"{x:173,y:356,t:1526919023601};\\\", \\\"{x:189,y:354,t:1526919023619};\\\", \\\"{x:213,y:354,t:1526919023634};\\\", \\\"{x:239,y:354,t:1526919023651};\\\", \\\"{x:257,y:355,t:1526919023669};\\\", \\\"{x:277,y:356,t:1526919023685};\\\", \\\"{x:300,y:357,t:1526919023702};\\\", \\\"{x:320,y:357,t:1526919023718};\\\", \\\"{x:330,y:357,t:1526919023735};\\\", \\\"{x:337,y:355,t:1526919023751};\\\", \\\"{x:341,y:353,t:1526919023767};\\\", \\\"{x:344,y:352,t:1526919023784};\\\", \\\"{x:346,y:350,t:1526919023802};\\\", \\\"{x:348,y:349,t:1526919023818};\\\", \\\"{x:350,y:347,t:1526919023835};\\\", \\\"{x:352,y:345,t:1526919023852};\\\", \\\"{x:355,y:341,t:1526919023868};\\\", \\\"{x:359,y:338,t:1526919023884};\\\", \\\"{x:362,y:335,t:1526919023903};\\\", \\\"{x:364,y:333,t:1526919023917};\\\", \\\"{x:365,y:331,t:1526919023934};\\\", \\\"{x:366,y:330,t:1526919023951};\\\", \\\"{x:367,y:329,t:1526919023968};\\\", \\\"{x:368,y:328,t:1526919023986};\\\", \\\"{x:368,y:327,t:1526919024000};\\\", \\\"{x:369,y:326,t:1526919024018};\\\", \\\"{x:370,y:325,t:1526919024035};\\\", \\\"{x:372,y:324,t:1526919024051};\\\", \\\"{x:375,y:323,t:1526919024067};\\\", \\\"{x:377,y:321,t:1526919024085};\\\", \\\"{x:381,y:320,t:1526919024101};\\\", \\\"{x:383,y:320,t:1526919024118};\\\", \\\"{x:385,y:319,t:1526919024135};\\\", \\\"{x:386,y:319,t:1526919024151};\\\", \\\"{x:386,y:318,t:1526919024168};\\\", \\\"{x:387,y:318,t:1526919024185};\\\", \\\"{x:388,y:317,t:1526919024201};\\\", \\\"{x:388,y:317,t:1526919024218};\\\", \\\"{x:389,y:316,t:1526919024235};\\\", \\\"{x:389,y:316,t:1526919024251};\\\", \\\"{x:388,y:316,t:1526919024558};\\\", \\\"{x:386,y:316,t:1526919024568};\\\", \\\"{x:370,y:316,t:1526919024584};\\\", \\\"{x:338,y:315,t:1526919024600};\\\", \\\"{x:309,y:314,t:1526919024620};\\\", \\\"{x:274,y:313,t:1526919024635};\\\", \\\"{x:245,y:313,t:1526919024651};\\\", \\\"{x:229,y:313,t:1526919024668};\\\", \\\"{x:212,y:315,t:1526919024684};\\\", \\\"{x:198,y:319,t:1526919024701};\\\", \\\"{x:187,y:325,t:1526919024718};\\\", \\\"{x:179,y:331,t:1526919024736};\\\", \\\"{x:172,y:338,t:1526919024751};\\\", \\\"{x:164,y:351,t:1526919024768};\\\", \\\"{x:160,y:359,t:1526919024785};\\\", \\\"{x:156,y:365,t:1526919024801};\\\", \\\"{x:152,y:371,t:1526919024818};\\\", \\\"{x:149,y:376,t:1526919024836};\\\", \\\"{x:145,y:380,t:1526919024850};\\\", \\\"{x:141,y:385,t:1526919024868};\\\", \\\"{x:138,y:390,t:1526919024885};\\\", \\\"{x:135,y:394,t:1526919024901};\\\", \\\"{x:133,y:399,t:1526919024918};\\\", \\\"{x:132,y:404,t:1526919024934};\\\", \\\"{x:132,y:412,t:1526919024953};\\\", \\\"{x:134,y:417,t:1526919024968};\\\", \\\"{x:143,y:423,t:1526919024984};\\\", \\\"{x:155,y:426,t:1526919025001};\\\", \\\"{x:173,y:426,t:1526919025017};\\\", \\\"{x:197,y:426,t:1526919025036};\\\", \\\"{x:221,y:426,t:1526919025051};\\\", \\\"{x:237,y:426,t:1526919025068};\\\", \\\"{x:247,y:426,t:1526919025085};\\\", \\\"{x:260,y:426,t:1526919025101};\\\", \\\"{x:267,y:426,t:1526919025118};\\\", \\\"{x:272,y:426,t:1526919025134};\\\", \\\"{x:275,y:426,t:1526919025151};\\\", \\\"{x:276,y:426,t:1526919025167};\\\", \\\"{x:277,y:426,t:1526919025184};\\\", \\\"{x:278,y:426,t:1526919025201};\\\", \\\"{x:278,y:427,t:1526919025224};\\\", \\\"{x:278,y:427,t:1526919025234};\\\", \\\"{x:277,y:428,t:1526919025251};\\\", \\\"{x:275,y:428,t:1526919025268};\\\", \\\"{x:273,y:428,t:1526919025284};\\\", \\\"{x:272,y:428,t:1526919025301};\\\", \\\"{x:270,y:428,t:1526919025317};\\\", \\\"{x:268,y:428,t:1526919025336};\\\", \\\"{x:267,y:428,t:1526919025345};\\\", \\\"{x:267,y:431,t:1526919025589};\\\", \\\"{x:267,y:439,t:1526919025601};\\\", \\\"{x:270,y:466,t:1526919025621};\\\", \\\"{x:274,y:487,t:1526919025636};\\\", \\\"{x:275,y:500,t:1526919025651};\\\", \\\"{x:277,y:506,t:1526919025668};\\\", \\\"{x:278,y:515,t:1526919025684};\\\", \\\"{x:279,y:521,t:1526919025701};\\\", \\\"{x:279,y:523,t:1526919025717};\\\", \\\"{x:279,y:525,t:1526919025735};\\\", \\\"{x:279,y:527,t:1526919025752};\\\", \\\"{x:279,y:529,t:1526919025768};\\\", \\\"{x:279,y:531,t:1526919025786};\\\", \\\"{x:279,y:534,t:1526919025801};\\\", \\\"{x:278,y:535,t:1526919025818};\\\", \\\"{x:278,y:537,t:1526919025835};\\\", \\\"{x:277,y:538,t:1526919025852};\\\", \\\"{x:277,y:539,t:1526919025868};\\\", \\\"{x:277,y:539,t:1526919025884};\\\", \\\"{x:277,y:540,t:1526919025901};\\\", \\\"{x:277,y:542,t:1526919025918};\\\", \\\"{x:278,y:512,t:1526919026278};\\\", \\\"{x:281,y:510,t:1526919026285};\\\", \\\"{x:296,y:502,t:1526919026301};\\\", \\\"{x:363,y:463,t:1526919026318};\\\", \\\"{x:448,y:426,t:1526919026333};\\\", \\\"{x:558,y:389,t:1526919026351};\\\", \\\"{x:684,y:363,t:1526919026368};\\\", \\\"{x:808,y:356,t:1526919026384};\\\", \\\"{x:904,y:365,t:1526919026400};\\\", \\\"{x:927,y:378,t:1526919026417};\\\", \\\"{x:937,y:385,t:1526919026434};\\\", \\\"{x:949,y:393,t:1526919026451};\\\", \\\"{x:953,y:398,t:1526919026468};\\\" ] }, { \\\"rt\\\": 6137, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 2133794, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:953,y:430,t:1526919029951};\\\", \\\"{x:953,y:435,t:1526919029968};\\\", \\\"{x:953,y:444,t:1526919029984};\\\", \\\"{x:950,y:462,t:1526919030002};\\\", \\\"{x:948,y:474,t:1526919030019};\\\", \\\"{x:945,y:488,t:1526919030036};\\\", \\\"{x:942,y:500,t:1526919030051};\\\", \\\"{x:940,y:509,t:1526919030069};\\\", \\\"{x:938,y:513,t:1526919030086};\\\", \\\"{x:937,y:516,t:1526919030102};\\\", \\\"{x:936,y:518,t:1526919030119};\\\", \\\"{x:935,y:519,t:1526919030135};\\\", \\\"{x:934,y:519,t:1526919030152};\\\", \\\"{x:933,y:518,t:1526919030168};\\\", \\\"{x:931,y:515,t:1526919030185};\\\", \\\"{x:929,y:511,t:1526919030202};\\\", \\\"{x:927,y:509,t:1526919030218};\\\", \\\"{x:926,y:505,t:1526919030234};\\\", \\\"{x:925,y:502,t:1526919030251};\\\", \\\"{x:924,y:500,t:1526919030268};\\\", \\\"{x:924,y:498,t:1526919030285};\\\", \\\"{x:923,y:497,t:1526919030303};\\\", \\\"{x:922,y:497,t:1526919030318};\\\", \\\"{x:922,y:497,t:1526919030335};\\\", \\\"{x:922,y:497,t:1526919030351};\\\", \\\"{x:921,y:497,t:1526919030377};\\\", \\\"{x:921,y:497,t:1526919030401};\\\", \\\"{x:921,y:498,t:1526919030419};\\\", \\\"{x:921,y:498,t:1526919030434};\\\", \\\"{x:921,y:499,t:1526919030452};\\\", \\\"{x:921,y:499,t:1526919030467};\\\", \\\"{x:920,y:500,t:1526919030484};\\\", \\\"{x:920,y:500,t:1526919030502};\\\", \\\"{x:920,y:501,t:1526919030518};\\\", \\\"{x:919,y:501,t:1526919030535};\\\", \\\"{x:918,y:502,t:1526919030551};\\\", \\\"{x:917,y:502,t:1526919030568};\\\", \\\"{x:917,y:502,t:1526919030585};\\\", \\\"{x:917,y:502,t:1526919030601};\\\", \\\"{x:916,y:502,t:1526919030618};\\\", \\\"{x:916,y:502,t:1526919030708};\\\", \\\"{x:916,y:501,t:1526919030717};\\\", \\\"{x:916,y:501,t:1526919030735};\\\", \\\"{x:916,y:500,t:1526919030752};\\\", \\\"{x:916,y:500,t:1526919030767};\\\", \\\"{x:916,y:499,t:1526919030786};\\\", \\\"{x:916,y:499,t:1526919030801};\\\", \\\"{x:916,y:499,t:1526919030818};\\\", \\\"{x:916,y:498,t:1526919030835};\\\", \\\"{x:916,y:498,t:1526919030852};\\\", \\\"{x:916,y:498,t:1526919030868};\\\", \\\"{x:916,y:497,t:1526919030885};\\\", \\\"{x:915,y:497,t:1526919030904};\\\", \\\"{x:915,y:497,t:1526919030920};\\\", \\\"{x:915,y:497,t:1526919030936};\\\", \\\"{x:915,y:497,t:1526919030953};\\\", \\\"{x:914,y:497,t:1526919030968};\\\", \\\"{x:914,y:498,t:1526919030984};\\\", \\\"{x:914,y:498,t:1526919031001};\\\", \\\"{x:914,y:498,t:1526919031018};\\\", \\\"{x:914,y:499,t:1526919031035};\\\", \\\"{x:914,y:500,t:1526919031051};\\\", \\\"{x:914,y:500,t:1526919031067};\\\", \\\"{x:913,y:501,t:1526919031085};\\\", \\\"{x:913,y:501,t:1526919031101};\\\", \\\"{x:913,y:502,t:1526919031119};\\\", \\\"{x:913,y:503,t:1526919031135};\\\", \\\"{x:911,y:506,t:1526919031152};\\\", \\\"{x:909,y:511,t:1526919031168};\\\", \\\"{x:904,y:522,t:1526919031184};\\\", \\\"{x:899,y:532,t:1526919031201};\\\", \\\"{x:895,y:541,t:1526919031219};\\\", \\\"{x:892,y:547,t:1526919031235};\\\", \\\"{x:890,y:553,t:1526919031251};\\\", \\\"{x:889,y:555,t:1526919031268};\\\", \\\"{x:889,y:556,t:1526919031285};\\\", \\\"{x:889,y:557,t:1526919031301};\\\", \\\"{x:889,y:556,t:1526919031318};\\\", \\\"{x:889,y:551,t:1526919031335};\\\", \\\"{x:894,y:542,t:1526919031351};\\\", \\\"{x:901,y:528,t:1526919031368};\\\", \\\"{x:909,y:514,t:1526919031385};\\\", \\\"{x:919,y:497,t:1526919031402};\\\", \\\"{x:925,y:485,t:1526919031419};\\\", \\\"{x:930,y:476,t:1526919031435};\\\", \\\"{x:933,y:468,t:1526919031451};\\\", \\\"{x:936,y:463,t:1526919031469};\\\", \\\"{x:939,y:458,t:1526919031484};\\\", \\\"{x:942,y:450,t:1526919031502};\\\", \\\"{x:945,y:443,t:1526919031517};\\\", \\\"{x:949,y:436,t:1526919031535};\\\", \\\"{x:951,y:429,t:1526919031551};\\\", \\\"{x:954,y:422,t:1526919031568};\\\", \\\"{x:957,y:415,t:1526919031586};\\\", \\\"{x:961,y:405,t:1526919031601};\\\", \\\"{x:966,y:392,t:1526919031618};\\\", \\\"{x:969,y:385,t:1526919031635};\\\", \\\"{x:972,y:378,t:1526919031652};\\\", \\\"{x:973,y:374,t:1526919031668};\\\", \\\"{x:974,y:372,t:1526919031685};\\\", \\\"{x:974,y:372,t:1526919031701};\\\", \\\"{x:974,y:372,t:1526919031718};\\\", \\\"{x:972,y:372,t:1526919032146};\\\", \\\"{x:961,y:378,t:1526919032154};\\\", \\\"{x:944,y:384,t:1526919032168};\\\", \\\"{x:847,y:411,t:1526919032185};\\\", \\\"{x:705,y:432,t:1526919032202};\\\", \\\"{x:592,y:442,t:1526919032218};\\\", \\\"{x:495,y:443,t:1526919032235};\\\", \\\"{x:395,y:443,t:1526919032251};\\\", \\\"{x:369,y:440,t:1526919032270};\\\", \\\"{x:354,y:437,t:1526919032285};\\\", \\\"{x:341,y:432,t:1526919032301};\\\", \\\"{x:341,y:427,t:1526919032491};\\\", \\\"{x:338,y:422,t:1526919032501};\\\", \\\"{x:332,y:410,t:1526919032519};\\\", \\\"{x:325,y:400,t:1526919032535};\\\", \\\"{x:317,y:389,t:1526919032552};\\\", \\\"{x:307,y:378,t:1526919032569};\\\", \\\"{x:299,y:371,t:1526919032587};\\\", \\\"{x:291,y:366,t:1526919032604};\\\", \\\"{x:285,y:361,t:1526919032619};\\\", \\\"{x:281,y:359,t:1526919032638};\\\", \\\"{x:276,y:356,t:1526919032651};\\\", \\\"{x:274,y:354,t:1526919032668};\\\", \\\"{x:271,y:353,t:1526919032686};\\\", \\\"{x:269,y:353,t:1526919032702};\\\", \\\"{x:267,y:352,t:1526919032719};\\\", \\\"{x:266,y:352,t:1526919032735};\\\", \\\"{x:265,y:352,t:1526919032752};\\\", \\\"{x:265,y:352,t:1526919032769};\\\", \\\"{x:265,y:353,t:1526919032989};\\\", \\\"{x:265,y:364,t:1526919033003};\\\", \\\"{x:265,y:397,t:1526919033021};\\\", \\\"{x:265,y:431,t:1526919033036};\\\", \\\"{x:268,y:460,t:1526919033054};\\\", \\\"{x:271,y:509,t:1526919033069};\\\", \\\"{x:273,y:534,t:1526919033086};\\\", \\\"{x:274,y:543,t:1526919033103};\\\", \\\"{x:275,y:551,t:1526919033118};\\\", \\\"{x:275,y:555,t:1526919033136};\\\", \\\"{x:275,y:557,t:1526919033153};\\\", \\\"{x:275,y:558,t:1526919033169};\\\", \\\"{x:275,y:558,t:1526919033186};\\\", \\\"{x:275,y:559,t:1526919033203};\\\", \\\"{x:275,y:559,t:1526919033219};\\\", \\\"{x:275,y:559,t:1526919033237};\\\", \\\"{x:274,y:559,t:1526919033253};\\\", \\\"{x:273,y:557,t:1526919033268};\\\", \\\"{x:272,y:557,t:1526919033286};\\\", \\\"{x:272,y:557,t:1526919033301};\\\", \\\"{x:272,y:526,t:1526919033770};\\\", \\\"{x:278,y:520,t:1526919033785};\\\", \\\"{x:288,y:511,t:1526919033802};\\\", \\\"{x:311,y:490,t:1526919033819};\\\", \\\"{x:342,y:466,t:1526919033835};\\\", \\\"{x:377,y:441,t:1526919033852};\\\", \\\"{x:412,y:419,t:1526919033871};\\\", \\\"{x:433,y:407,t:1526919033885};\\\", \\\"{x:451,y:397,t:1526919033902};\\\", \\\"{x:461,y:391,t:1526919033920};\\\", \\\"{x:470,y:386,t:1526919033935};\\\", \\\"{x:473,y:384,t:1526919033952};\\\", \\\"{x:474,y:384,t:1526919033969};\\\", \\\"{x:474,y:384,t:1526919033985};\\\" ] }, { \\\"rt\\\": 31416, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 2166501, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O -M -C -N -H -Z -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:491,y:423,t:1526919039043};\\\", \\\"{x:498,y:426,t:1526919039052};\\\", \\\"{x:522,y:436,t:1526919039069};\\\", \\\"{x:547,y:444,t:1526919039085};\\\", \\\"{x:573,y:454,t:1526919039104};\\\", \\\"{x:642,y:485,t:1526919039121};\\\", \\\"{x:691,y:512,t:1526919039136};\\\", \\\"{x:727,y:536,t:1526919039152};\\\", \\\"{x:768,y:568,t:1526919039169};\\\", \\\"{x:791,y:588,t:1526919039186};\\\", \\\"{x:829,y:617,t:1526919039202};\\\", \\\"{x:848,y:631,t:1526919039220};\\\", \\\"{x:859,y:639,t:1526919039236};\\\", \\\"{x:865,y:643,t:1526919039252};\\\", \\\"{x:865,y:643,t:1526919039498};\\\", \\\"{x:868,y:643,t:1526919039506};\\\", \\\"{x:872,y:643,t:1526919039519};\\\", \\\"{x:888,y:643,t:1526919039536};\\\", \\\"{x:921,y:646,t:1526919039552};\\\", \\\"{x:953,y:655,t:1526919039569};\\\", \\\"{x:986,y:668,t:1526919039587};\\\", \\\"{x:1006,y:678,t:1526919039603};\\\", \\\"{x:1026,y:690,t:1526919039619};\\\", \\\"{x:1034,y:694,t:1526919039635};\\\", \\\"{x:1041,y:697,t:1526919039652};\\\", \\\"{x:1045,y:699,t:1526919039670};\\\", \\\"{x:1047,y:700,t:1526919039686};\\\", \\\"{x:1047,y:700,t:1526919039704};\\\", \\\"{x:1048,y:700,t:1526919039719};\\\", \\\"{x:1048,y:700,t:1526919039736};\\\", \\\"{x:1048,y:701,t:1526919039753};\\\", \\\"{x:1048,y:701,t:1526919039786};\\\", \\\"{x:1047,y:701,t:1526919039803};\\\", \\\"{x:1042,y:700,t:1526919039819};\\\", \\\"{x:1037,y:697,t:1526919039835};\\\", \\\"{x:1033,y:695,t:1526919039853};\\\", \\\"{x:1029,y:693,t:1526919039870};\\\", \\\"{x:1025,y:690,t:1526919039888};\\\", \\\"{x:1019,y:684,t:1526919039904};\\\", \\\"{x:1012,y:674,t:1526919039920};\\\", \\\"{x:1006,y:660,t:1526919039937};\\\", \\\"{x:1001,y:640,t:1526919039953};\\\", \\\"{x:999,y:615,t:1526919039970};\\\", \\\"{x:999,y:591,t:1526919039986};\\\", \\\"{x:999,y:577,t:1526919040002};\\\", \\\"{x:1010,y:546,t:1526919040020};\\\", \\\"{x:1016,y:536,t:1526919040035};\\\", \\\"{x:1023,y:525,t:1526919040052};\\\", \\\"{x:1029,y:515,t:1526919040069};\\\", \\\"{x:1036,y:506,t:1526919040086};\\\", \\\"{x:1040,y:500,t:1526919040102};\\\", \\\"{x:1045,y:495,t:1526919040120};\\\", \\\"{x:1046,y:493,t:1526919040136};\\\", \\\"{x:1048,y:492,t:1526919040152};\\\", \\\"{x:1048,y:492,t:1526919040169};\\\", \\\"{x:1050,y:492,t:1526919040548};\\\", \\\"{x:1052,y:492,t:1526919040556};\\\", \\\"{x:1053,y:492,t:1526919040569};\\\", \\\"{x:1057,y:492,t:1526919040588};\\\", \\\"{x:1060,y:489,t:1526919040603};\\\", \\\"{x:1066,y:479,t:1526919040619};\\\", \\\"{x:1069,y:463,t:1526919040636};\\\", \\\"{x:1069,y:411,t:1526919040652};\\\", \\\"{x:1063,y:363,t:1526919040668};\\\", \\\"{x:1055,y:310,t:1526919040686};\\\", \\\"{x:1050,y:273,t:1526919040703};\\\", \\\"{x:1046,y:232,t:1526919040719};\\\", \\\"{x:1045,y:210,t:1526919040736};\\\", \\\"{x:1043,y:188,t:1526919040753};\\\", \\\"{x:1043,y:179,t:1526919040769};\\\", \\\"{x:1042,y:172,t:1526919040785};\\\", \\\"{x:1041,y:169,t:1526919040804};\\\", \\\"{x:1041,y:168,t:1526919040819};\\\", \\\"{x:1041,y:167,t:1526919040836};\\\", \\\"{x:1040,y:167,t:1526919040852};\\\", \\\"{x:1033,y:194,t:1526919040975};\\\", \\\"{x:1030,y:205,t:1526919040986};\\\", \\\"{x:1024,y:227,t:1526919041002};\\\", \\\"{x:1020,y:242,t:1526919041019};\\\", \\\"{x:1015,y:256,t:1526919041036};\\\", \\\"{x:1012,y:267,t:1526919041052};\\\", \\\"{x:1009,y:281,t:1526919041069};\\\", \\\"{x:1006,y:292,t:1526919041086};\\\", \\\"{x:1005,y:305,t:1526919041102};\\\", \\\"{x:1004,y:313,t:1526919041119};\\\", \\\"{x:1004,y:322,t:1526919041136};\\\", \\\"{x:1004,y:326,t:1526919041153};\\\", \\\"{x:1004,y:329,t:1526919041169};\\\", \\\"{x:1004,y:331,t:1526919041185};\\\", \\\"{x:1004,y:333,t:1526919041203};\\\", \\\"{x:1003,y:336,t:1526919041219};\\\", \\\"{x:1003,y:340,t:1526919041236};\\\", \\\"{x:1003,y:344,t:1526919041253};\\\", \\\"{x:1003,y:346,t:1526919041269};\\\", \\\"{x:1004,y:349,t:1526919042300};\\\", \\\"{x:1009,y:355,t:1526919042308};\\\", \\\"{x:1014,y:362,t:1526919042320};\\\", \\\"{x:1041,y:391,t:1526919042337};\\\", \\\"{x:1077,y:425,t:1526919042352};\\\", \\\"{x:1121,y:466,t:1526919042369};\\\", \\\"{x:1148,y:493,t:1526919042386};\\\", \\\"{x:1161,y:505,t:1526919042403};\\\", \\\"{x:1172,y:518,t:1526919042419};\\\", \\\"{x:1181,y:530,t:1526919042436};\\\", \\\"{x:1182,y:532,t:1526919042452};\\\", \\\"{x:1183,y:533,t:1526919042469};\\\", \\\"{x:1183,y:532,t:1526919042516};\\\", \\\"{x:1183,y:531,t:1526919042524};\\\", \\\"{x:1183,y:529,t:1526919042536};\\\", \\\"{x:1183,y:524,t:1526919042552};\\\", \\\"{x:1182,y:518,t:1526919042569};\\\", \\\"{x:1181,y:513,t:1526919042586};\\\", \\\"{x:1180,y:509,t:1526919042603};\\\", \\\"{x:1179,y:505,t:1526919042619};\\\", \\\"{x:1179,y:501,t:1526919042637};\\\", \\\"{x:1179,y:500,t:1526919042653};\\\", \\\"{x:1179,y:498,t:1526919042671};\\\", \\\"{x:1179,y:497,t:1526919042685};\\\", \\\"{x:1179,y:497,t:1526919042702};\\\", \\\"{x:1179,y:497,t:1526919042853};\\\", \\\"{x:1179,y:497,t:1526919042869};\\\", \\\"{x:1179,y:497,t:1526919042886};\\\", \\\"{x:1180,y:497,t:1526919042902};\\\", \\\"{x:1180,y:497,t:1526919045074};\\\", \\\"{x:1180,y:499,t:1526919045086};\\\", \\\"{x:1178,y:505,t:1526919045104};\\\", \\\"{x:1176,y:512,t:1526919045120};\\\", \\\"{x:1173,y:521,t:1526919045136};\\\", \\\"{x:1169,y:531,t:1526919045152};\\\", \\\"{x:1164,y:546,t:1526919045169};\\\", \\\"{x:1160,y:553,t:1526919045186};\\\", \\\"{x:1159,y:557,t:1526919045203};\\\", \\\"{x:1156,y:560,t:1526919045219};\\\", \\\"{x:1155,y:562,t:1526919045236};\\\", \\\"{x:1154,y:564,t:1526919045253};\\\", \\\"{x:1152,y:566,t:1526919045270};\\\", \\\"{x:1150,y:569,t:1526919045286};\\\", \\\"{x:1148,y:571,t:1526919045302};\\\", \\\"{x:1146,y:574,t:1526919045320};\\\", \\\"{x:1145,y:576,t:1526919045335};\\\", \\\"{x:1144,y:577,t:1526919045353};\\\", \\\"{x:1143,y:578,t:1526919045369};\\\", \\\"{x:1142,y:578,t:1526919045386};\\\", \\\"{x:1142,y:578,t:1526919045403};\\\", \\\"{x:1142,y:578,t:1526919045419};\\\", \\\"{x:1141,y:578,t:1526919045436};\\\", \\\"{x:1141,y:578,t:1526919045453};\\\", \\\"{x:1141,y:577,t:1526919045469};\\\", \\\"{x:1140,y:574,t:1526919045486};\\\", \\\"{x:1138,y:568,t:1526919045502};\\\", \\\"{x:1131,y:562,t:1526919045520};\\\", \\\"{x:1119,y:558,t:1526919045537};\\\", \\\"{x:1088,y:560,t:1526919045553};\\\", \\\"{x:1033,y:618,t:1526919045571};\\\", \\\"{x:1007,y:653,t:1526919045586};\\\", \\\"{x:983,y:682,t:1526919045602};\\\", \\\"{x:968,y:700,t:1526919045619};\\\", \\\"{x:954,y:712,t:1526919045636};\\\", \\\"{x:946,y:714,t:1526919045652};\\\", \\\"{x:946,y:700,t:1526919045862};\\\", \\\"{x:946,y:679,t:1526919045870};\\\", \\\"{x:946,y:658,t:1526919045887};\\\", \\\"{x:954,y:439,t:1526919045903};\\\", \\\"{x:976,y:257,t:1526919045930};\\\", \\\"{x:1023,y:64,t:1526919045936};\\\", \\\"{x:1000,y:92,t:1526919050815};\\\", \\\"{x:924,y:146,t:1526919050821};\\\", \\\"{x:813,y:233,t:1526919050837};\\\", \\\"{x:716,y:314,t:1526919050853};\\\", \\\"{x:649,y:367,t:1526919050870};\\\", \\\"{x:611,y:396,t:1526919050887};\\\", \\\"{x:601,y:402,t:1526919050903};\\\", \\\"{x:585,y:412,t:1526919050921};\\\", \\\"{x:581,y:414,t:1526919050937};\\\", \\\"{x:582,y:414,t:1526919051910};\\\", \\\"{x:585,y:414,t:1526919051920};\\\", \\\"{x:606,y:418,t:1526919051937};\\\", \\\"{x:669,y:432,t:1526919051954};\\\", \\\"{x:752,y:450,t:1526919051971};\\\", \\\"{x:844,y:482,t:1526919051986};\\\", \\\"{x:902,y:510,t:1526919052005};\\\", \\\"{x:940,y:535,t:1526919052020};\\\", \\\"{x:971,y:562,t:1526919052037};\\\", \\\"{x:981,y:576,t:1526919052054};\\\", \\\"{x:992,y:598,t:1526919052070};\\\", \\\"{x:993,y:603,t:1526919052087};\\\", \\\"{x:995,y:607,t:1526919052104};\\\", \\\"{x:995,y:609,t:1526919052120};\\\", \\\"{x:995,y:610,t:1526919052137};\\\", \\\"{x:995,y:609,t:1526919053057};\\\", \\\"{x:995,y:605,t:1526919053071};\\\", \\\"{x:996,y:593,t:1526919053088};\\\", \\\"{x:999,y:566,t:1526919053103};\\\", \\\"{x:1011,y:476,t:1526919053124};\\\", \\\"{x:1017,y:427,t:1526919053138};\\\", \\\"{x:1023,y:384,t:1526919053155};\\\", \\\"{x:1028,y:357,t:1526919053171};\\\", \\\"{x:1031,y:344,t:1526919053187};\\\", \\\"{x:1033,y:335,t:1526919053204};\\\", \\\"{x:1034,y:332,t:1526919053221};\\\", \\\"{x:1035,y:331,t:1526919053237};\\\", \\\"{x:1035,y:332,t:1526919053256};\\\", \\\"{x:1035,y:337,t:1526919053270};\\\", \\\"{x:1028,y:357,t:1526919053287};\\\", \\\"{x:1017,y:390,t:1526919053307};\\\", \\\"{x:1008,y:422,t:1526919053321};\\\", \\\"{x:995,y:465,t:1526919053337};\\\", \\\"{x:991,y:482,t:1526919053353};\\\", \\\"{x:988,y:495,t:1526919053377};\\\", \\\"{x:987,y:501,t:1526919053388};\\\", \\\"{x:986,y:503,t:1526919053404};\\\", \\\"{x:986,y:504,t:1526919053421};\\\", \\\"{x:986,y:504,t:1526919053436};\\\", \\\"{x:986,y:504,t:1526919056255};\\\", \\\"{x:992,y:507,t:1526919056271};\\\", \\\"{x:1009,y:518,t:1526919056287};\\\", \\\"{x:1029,y:534,t:1526919056303};\\\", \\\"{x:1044,y:550,t:1526919056321};\\\", \\\"{x:1060,y:571,t:1526919056337};\\\", \\\"{x:1068,y:584,t:1526919056354};\\\", \\\"{x:1077,y:597,t:1526919056370};\\\", \\\"{x:1084,y:608,t:1526919056388};\\\", \\\"{x:1090,y:616,t:1526919056405};\\\", \\\"{x:1093,y:620,t:1526919056421};\\\", \\\"{x:1096,y:623,t:1526919056437};\\\", \\\"{x:1097,y:625,t:1526919056454};\\\", \\\"{x:1099,y:627,t:1526919056471};\\\", \\\"{x:1099,y:627,t:1526919056487};\\\", \\\"{x:1099,y:628,t:1526919056505};\\\", \\\"{x:1099,y:628,t:1526919056521};\\\", \\\"{x:1099,y:628,t:1526919056655};\\\", \\\"{x:1098,y:628,t:1526919056671};\\\", \\\"{x:1095,y:628,t:1526919056687};\\\", \\\"{x:1093,y:629,t:1526919056704};\\\", \\\"{x:1089,y:631,t:1526919056721};\\\", \\\"{x:1086,y:632,t:1526919056737};\\\", \\\"{x:1082,y:632,t:1526919056754};\\\", \\\"{x:1078,y:633,t:1526919056770};\\\", \\\"{x:1073,y:634,t:1526919056787};\\\", \\\"{x:1070,y:635,t:1526919056804};\\\", \\\"{x:1065,y:635,t:1526919056821};\\\", \\\"{x:1062,y:635,t:1526919056837};\\\", \\\"{x:1059,y:635,t:1526919056854};\\\", \\\"{x:1055,y:635,t:1526919056871};\\\", \\\"{x:1054,y:635,t:1526919056888};\\\", \\\"{x:1054,y:635,t:1526919056903};\\\", \\\"{x:1052,y:635,t:1526919057305};\\\", \\\"{x:1045,y:633,t:1526919057321};\\\", \\\"{x:1033,y:627,t:1526919057338};\\\", \\\"{x:1018,y:618,t:1526919057354};\\\", \\\"{x:1003,y:607,t:1526919057371};\\\", \\\"{x:990,y:595,t:1526919057387};\\\", \\\"{x:979,y:582,t:1526919057404};\\\", \\\"{x:972,y:573,t:1526919057421};\\\", \\\"{x:964,y:563,t:1526919057438};\\\", \\\"{x:958,y:555,t:1526919057455};\\\", \\\"{x:953,y:548,t:1526919057472};\\\", \\\"{x:949,y:541,t:1526919057488};\\\", \\\"{x:944,y:533,t:1526919057504};\\\", \\\"{x:940,y:519,t:1526919057521};\\\", \\\"{x:936,y:510,t:1526919057537};\\\", \\\"{x:934,y:502,t:1526919057554};\\\", \\\"{x:932,y:494,t:1526919057571};\\\", \\\"{x:931,y:488,t:1526919057587};\\\", \\\"{x:930,y:482,t:1526919057604};\\\", \\\"{x:929,y:477,t:1526919057621};\\\", \\\"{x:927,y:472,t:1526919057637};\\\", \\\"{x:925,y:467,t:1526919057655};\\\", \\\"{x:923,y:461,t:1526919057671};\\\", \\\"{x:921,y:456,t:1526919057688};\\\", \\\"{x:919,y:450,t:1526919057704};\\\", \\\"{x:916,y:445,t:1526919057721};\\\", \\\"{x:912,y:437,t:1526919057738};\\\", \\\"{x:909,y:433,t:1526919057754};\\\", \\\"{x:907,y:430,t:1526919057771};\\\", \\\"{x:905,y:427,t:1526919057788};\\\", \\\"{x:902,y:425,t:1526919057804};\\\", \\\"{x:901,y:424,t:1526919057821};\\\", \\\"{x:899,y:424,t:1526919057837};\\\", \\\"{x:898,y:424,t:1526919057854};\\\", \\\"{x:897,y:424,t:1526919057871};\\\", \\\"{x:896,y:428,t:1526919057887};\\\", \\\"{x:894,y:436,t:1526919057904};\\\", \\\"{x:893,y:447,t:1526919057921};\\\", \\\"{x:892,y:473,t:1526919057938};\\\", \\\"{x:892,y:486,t:1526919057954};\\\", \\\"{x:892,y:500,t:1526919057971};\\\", \\\"{x:892,y:508,t:1526919057987};\\\", \\\"{x:893,y:515,t:1526919058004};\\\", \\\"{x:893,y:521,t:1526919058021};\\\", \\\"{x:893,y:525,t:1526919058038};\\\", \\\"{x:894,y:529,t:1526919058055};\\\", \\\"{x:897,y:531,t:1526919058072};\\\", \\\"{x:901,y:533,t:1526919058088};\\\", \\\"{x:906,y:535,t:1526919058104};\\\", \\\"{x:911,y:535,t:1526919058122};\\\", \\\"{x:918,y:532,t:1526919058137};\\\", \\\"{x:935,y:508,t:1526919058154};\\\", \\\"{x:957,y:468,t:1526919058171};\\\", \\\"{x:984,y:416,t:1526919058187};\\\", \\\"{x:1015,y:351,t:1526919058203};\\\", \\\"{x:1034,y:311,t:1526919058220};\\\", \\\"{x:1043,y:293,t:1526919058238};\\\", \\\"{x:1056,y:269,t:1526919058255};\\\", \\\"{x:1063,y:256,t:1526919058271};\\\", \\\"{x:1069,y:249,t:1526919058289};\\\", \\\"{x:1071,y:245,t:1526919058304};\\\", \\\"{x:1073,y:242,t:1526919058321};\\\", \\\"{x:1074,y:240,t:1526919058338};\\\", \\\"{x:1075,y:239,t:1526919058355};\\\", \\\"{x:1076,y:239,t:1526919058371};\\\", \\\"{x:1076,y:239,t:1526919058389};\\\", \\\"{x:1075,y:239,t:1526919058466};\\\", \\\"{x:1075,y:239,t:1526919058474};\\\", \\\"{x:1075,y:238,t:1526919058488};\\\", \\\"{x:1073,y:237,t:1526919058504};\\\", \\\"{x:1071,y:235,t:1526919058521};\\\", \\\"{x:1068,y:231,t:1526919058538};\\\", \\\"{x:1066,y:227,t:1526919058554};\\\", \\\"{x:1063,y:221,t:1526919058571};\\\", \\\"{x:1061,y:216,t:1526919058587};\\\", \\\"{x:1061,y:213,t:1526919058604};\\\", \\\"{x:1060,y:209,t:1526919058636};\\\", \\\"{x:1060,y:209,t:1526919058653};\\\", \\\"{x:1060,y:209,t:1526919058975};\\\", \\\"{x:1062,y:212,t:1526919058988};\\\", \\\"{x:1069,y:219,t:1526919059004};\\\", \\\"{x:1087,y:239,t:1526919059021};\\\", \\\"{x:1109,y:269,t:1526919059037};\\\", \\\"{x:1141,y:322,t:1526919059054};\\\", \\\"{x:1168,y:381,t:1526919059072};\\\", \\\"{x:1207,y:489,t:1526919059088};\\\", \\\"{x:1223,y:539,t:1526919059105};\\\", \\\"{x:1234,y:573,t:1526919059121};\\\", \\\"{x:1243,y:606,t:1526919059137};\\\", \\\"{x:1248,y:623,t:1526919059155};\\\", \\\"{x:1251,y:639,t:1526919059172};\\\", \\\"{x:1252,y:646,t:1526919059187};\\\", \\\"{x:1253,y:651,t:1526919059204};\\\", \\\"{x:1253,y:653,t:1526919059222};\\\", \\\"{x:1251,y:653,t:1526919059237};\\\", \\\"{x:1246,y:650,t:1526919059254};\\\", \\\"{x:1235,y:636,t:1526919059271};\\\", \\\"{x:1221,y:615,t:1526919059287};\\\", \\\"{x:1195,y:569,t:1526919059305};\\\", \\\"{x:1184,y:546,t:1526919059321};\\\", \\\"{x:1171,y:523,t:1526919059338};\\\", \\\"{x:1163,y:510,t:1526919059354};\\\", \\\"{x:1154,y:493,t:1526919059372};\\\", \\\"{x:1148,y:483,t:1526919059388};\\\", \\\"{x:1143,y:475,t:1526919059404};\\\", \\\"{x:1140,y:469,t:1526919059420};\\\", \\\"{x:1137,y:463,t:1526919059437};\\\", \\\"{x:1136,y:459,t:1526919059454};\\\", \\\"{x:1135,y:453,t:1526919059470};\\\", \\\"{x:1134,y:448,t:1526919059487};\\\", \\\"{x:1132,y:442,t:1526919059504};\\\", \\\"{x:1131,y:434,t:1526919059520};\\\", \\\"{x:1131,y:428,t:1526919059538};\\\", \\\"{x:1131,y:424,t:1526919059555};\\\", \\\"{x:1132,y:421,t:1526919059571};\\\", \\\"{x:1136,y:420,t:1526919059587};\\\", \\\"{x:1142,y:420,t:1526919059604};\\\", \\\"{x:1149,y:420,t:1526919059621};\\\", \\\"{x:1154,y:420,t:1526919059637};\\\", \\\"{x:1159,y:420,t:1526919059654};\\\", \\\"{x:1162,y:420,t:1526919059671};\\\", \\\"{x:1163,y:420,t:1526919059688};\\\", \\\"{x:1164,y:420,t:1526919059705};\\\", \\\"{x:1164,y:420,t:1526919059720};\\\", \\\"{x:1164,y:418,t:1526919059737};\\\", \\\"{x:1164,y:414,t:1526919059754};\\\", \\\"{x:1162,y:407,t:1526919059770};\\\", \\\"{x:1160,y:398,t:1526919059788};\\\", \\\"{x:1158,y:393,t:1526919059804};\\\", \\\"{x:1157,y:389,t:1526919059822};\\\", \\\"{x:1157,y:387,t:1526919059838};\\\", \\\"{x:1157,y:387,t:1526919059854};\\\", \\\"{x:1157,y:387,t:1526919059874};\\\", \\\"{x:1157,y:388,t:1526919059889};\\\", \\\"{x:1158,y:393,t:1526919059906};\\\", \\\"{x:1159,y:397,t:1526919059921};\\\", \\\"{x:1161,y:407,t:1526919059938};\\\", \\\"{x:1162,y:413,t:1526919059955};\\\", \\\"{x:1162,y:421,t:1526919059970};\\\", \\\"{x:1163,y:425,t:1526919059989};\\\", \\\"{x:1165,y:430,t:1526919060004};\\\", \\\"{x:1166,y:434,t:1526919060020};\\\", \\\"{x:1167,y:440,t:1526919060038};\\\", \\\"{x:1168,y:447,t:1526919060054};\\\", \\\"{x:1170,y:454,t:1526919060072};\\\", \\\"{x:1171,y:458,t:1526919060089};\\\", \\\"{x:1173,y:466,t:1526919060105};\\\", \\\"{x:1175,y:470,t:1526919060120};\\\", \\\"{x:1176,y:475,t:1526919060138};\\\", \\\"{x:1178,y:481,t:1526919060155};\\\", \\\"{x:1179,y:484,t:1526919060171};\\\", \\\"{x:1180,y:487,t:1526919060187};\\\", \\\"{x:1180,y:490,t:1526919060207};\\\", \\\"{x:1181,y:492,t:1526919060221};\\\", \\\"{x:1181,y:493,t:1526919060237};\\\", \\\"{x:1181,y:494,t:1526919060255};\\\", \\\"{x:1181,y:495,t:1526919060271};\\\", \\\"{x:1181,y:495,t:1526919060288};\\\", \\\"{x:1181,y:495,t:1526919060306};\\\", \\\"{x:1182,y:495,t:1526919060370};\\\", \\\"{x:1182,y:495,t:1526919061368};\\\", \\\"{x:1182,y:496,t:1526919061372};\\\", \\\"{x:1182,y:496,t:1526919061387};\\\", \\\"{x:1181,y:498,t:1526919061404};\\\", \\\"{x:1181,y:499,t:1526919061421};\\\", \\\"{x:1181,y:501,t:1526919061439};\\\", \\\"{x:1180,y:502,t:1526919061454};\\\", \\\"{x:1180,y:503,t:1526919061470};\\\", \\\"{x:1179,y:504,t:1526919061487};\\\", \\\"{x:1179,y:506,t:1526919061505};\\\", \\\"{x:1177,y:509,t:1526919061521};\\\", \\\"{x:1174,y:514,t:1526919061537};\\\", \\\"{x:1171,y:521,t:1526919061554};\\\", \\\"{x:1166,y:528,t:1526919061572};\\\", \\\"{x:1162,y:534,t:1526919061588};\\\", \\\"{x:1156,y:542,t:1526919061605};\\\", \\\"{x:1152,y:546,t:1526919061620};\\\", \\\"{x:1148,y:552,t:1526919061638};\\\", \\\"{x:1144,y:556,t:1526919061654};\\\", \\\"{x:1142,y:560,t:1526919061671};\\\", \\\"{x:1138,y:565,t:1526919061687};\\\", \\\"{x:1134,y:570,t:1526919061704};\\\", \\\"{x:1130,y:576,t:1526919061721};\\\", \\\"{x:1127,y:581,t:1526919061738};\\\", \\\"{x:1123,y:586,t:1526919061756};\\\", \\\"{x:1121,y:591,t:1526919061771};\\\", \\\"{x:1119,y:595,t:1526919061788};\\\", \\\"{x:1116,y:600,t:1526919061804};\\\", \\\"{x:1112,y:610,t:1526919061821};\\\", \\\"{x:1109,y:618,t:1526919061838};\\\", \\\"{x:1106,y:626,t:1526919061854};\\\", \\\"{x:1103,y:635,t:1526919061872};\\\", \\\"{x:1100,y:644,t:1526919061888};\\\", \\\"{x:1096,y:656,t:1526919061904};\\\", \\\"{x:1093,y:664,t:1526919061921};\\\", \\\"{x:1089,y:673,t:1526919061937};\\\", \\\"{x:1086,y:682,t:1526919061954};\\\", \\\"{x:1083,y:690,t:1526919061972};\\\", \\\"{x:1079,y:698,t:1526919061988};\\\", \\\"{x:1077,y:704,t:1526919062005};\\\", \\\"{x:1072,y:714,t:1526919062021};\\\", \\\"{x:1070,y:721,t:1526919062038};\\\", \\\"{x:1066,y:730,t:1526919062055};\\\", \\\"{x:1062,y:737,t:1526919062071};\\\", \\\"{x:1059,y:743,t:1526919062087};\\\", \\\"{x:1056,y:746,t:1526919062104};\\\", \\\"{x:1054,y:748,t:1526919062121};\\\", \\\"{x:1054,y:749,t:1526919062374};\\\", \\\"{x:1054,y:753,t:1526919062387};\\\", \\\"{x:1052,y:760,t:1526919062404};\\\", \\\"{x:1049,y:766,t:1526919062422};\\\", \\\"{x:1045,y:773,t:1526919062438};\\\", \\\"{x:1043,y:776,t:1526919062454};\\\", \\\"{x:1042,y:777,t:1526919062471};\\\", \\\"{x:1042,y:778,t:1526919062488};\\\", \\\"{x:1042,y:778,t:1526919062504};\\\", \\\"{x:1041,y:778,t:1526919062521};\\\", \\\"{x:1041,y:778,t:1526919062542};\\\", \\\"{x:1041,y:778,t:1526919062566};\\\", \\\"{x:1041,y:777,t:1526919062574};\\\", \\\"{x:1041,y:777,t:1526919062587};\\\", \\\"{x:1041,y:776,t:1526919062604};\\\", \\\"{x:1040,y:773,t:1526919062622};\\\", \\\"{x:1038,y:770,t:1526919062637};\\\", \\\"{x:1033,y:759,t:1526919062671};\\\", \\\"{x:1022,y:735,t:1526919062688};\\\", \\\"{x:1016,y:718,t:1526919062704};\\\", \\\"{x:1013,y:704,t:1526919062720};\\\", \\\"{x:1010,y:689,t:1526919062738};\\\", \\\"{x:1007,y:679,t:1526919062754};\\\", \\\"{x:1005,y:675,t:1526919062771};\\\", \\\"{x:1003,y:671,t:1526919062787};\\\", \\\"{x:1002,y:668,t:1526919062804};\\\", \\\"{x:1001,y:666,t:1526919062821};\\\", \\\"{x:1000,y:664,t:1526919062837};\\\", \\\"{x:999,y:662,t:1526919062855};\\\", \\\"{x:999,y:661,t:1526919062871};\\\", \\\"{x:999,y:661,t:1526919063115};\\\", \\\"{x:999,y:658,t:1526919063125};\\\", \\\"{x:998,y:654,t:1526919063137};\\\", \\\"{x:993,y:643,t:1526919063154};\\\", \\\"{x:984,y:626,t:1526919063171};\\\", \\\"{x:967,y:589,t:1526919063189};\\\", \\\"{x:960,y:574,t:1526919063205};\\\", \\\"{x:955,y:566,t:1526919063221};\\\", \\\"{x:947,y:555,t:1526919063238};\\\", \\\"{x:942,y:551,t:1526919063254};\\\", \\\"{x:937,y:547,t:1526919063270};\\\", \\\"{x:933,y:544,t:1526919063288};\\\", \\\"{x:930,y:541,t:1526919063305};\\\", \\\"{x:928,y:539,t:1526919063321};\\\", \\\"{x:927,y:538,t:1526919063338};\\\", \\\"{x:926,y:536,t:1526919063354};\\\", \\\"{x:925,y:535,t:1526919063371};\\\", \\\"{x:922,y:532,t:1526919063387};\\\", \\\"{x:915,y:525,t:1526919063404};\\\", \\\"{x:897,y:511,t:1526919063421};\\\", \\\"{x:856,y:481,t:1526919063438};\\\", \\\"{x:823,y:466,t:1526919063454};\\\", \\\"{x:776,y:455,t:1526919063472};\\\", \\\"{x:746,y:454,t:1526919063488};\\\", \\\"{x:726,y:454,t:1526919063505};\\\", \\\"{x:710,y:454,t:1526919063522};\\\", \\\"{x:688,y:444,t:1526919063782};\\\", \\\"{x:674,y:438,t:1526919063789};\\\", \\\"{x:641,y:428,t:1526919063805};\\\", \\\"{x:609,y:418,t:1526919063821};\\\", \\\"{x:578,y:411,t:1526919063838};\\\", \\\"{x:529,y:396,t:1526919063856};\\\", \\\"{x:504,y:387,t:1526919063870};\\\", \\\"{x:485,y:381,t:1526919063887};\\\", \\\"{x:467,y:376,t:1526919063904};\\\", \\\"{x:453,y:372,t:1526919063920};\\\", \\\"{x:441,y:369,t:1526919063938};\\\", \\\"{x:431,y:366,t:1526919063993};\\\", \\\"{x:401,y:335,t:1526919064039};\\\", \\\"{x:397,y:326,t:1526919064055};\\\", \\\"{x:393,y:318,t:1526919064075};\\\", \\\"{x:390,y:311,t:1526919064088};\\\", \\\"{x:388,y:305,t:1526919064104};\\\", \\\"{x:386,y:302,t:1526919064124};\\\", \\\"{x:385,y:298,t:1526919064139};\\\", \\\"{x:384,y:296,t:1526919064155};\\\", \\\"{x:384,y:295,t:1526919064171};\\\", \\\"{x:384,y:295,t:1526919064189};\\\", \\\"{x:386,y:294,t:1526919064206};\\\", \\\"{x:389,y:293,t:1526919064222};\\\", \\\"{x:395,y:292,t:1526919064238};\\\", \\\"{x:400,y:291,t:1526919064256};\\\", \\\"{x:406,y:290,t:1526919064273};\\\", \\\"{x:410,y:289,t:1526919064288};\\\", \\\"{x:412,y:288,t:1526919064305};\\\", \\\"{x:413,y:288,t:1526919064321};\\\", \\\"{x:413,y:287,t:1526919064339};\\\", \\\"{x:413,y:286,t:1526919064356};\\\", \\\"{x:413,y:285,t:1526919064373};\\\", \\\"{x:413,y:284,t:1526919064389};\\\", \\\"{x:413,y:282,t:1526919064405};\\\", \\\"{x:412,y:280,t:1526919064421};\\\", \\\"{x:411,y:279,t:1526919064439};\\\", \\\"{x:410,y:278,t:1526919064455};\\\", \\\"{x:409,y:278,t:1526919064472};\\\", \\\"{x:407,y:278,t:1526919064489};\\\", \\\"{x:405,y:278,t:1526919064750};\\\", \\\"{x:396,y:278,t:1526919064758};\\\", \\\"{x:384,y:278,t:1526919064772};\\\", \\\"{x:358,y:278,t:1526919064789};\\\", \\\"{x:331,y:278,t:1526919064805};\\\", \\\"{x:284,y:278,t:1526919064824};\\\", \\\"{x:249,y:279,t:1526919064839};\\\", \\\"{x:231,y:282,t:1526919064855};\\\", \\\"{x:214,y:284,t:1526919064872};\\\", \\\"{x:203,y:285,t:1526919064889};\\\", \\\"{x:197,y:286,t:1526919064905};\\\", \\\"{x:190,y:287,t:1526919064922};\\\", \\\"{x:185,y:287,t:1526919064941};\\\", \\\"{x:182,y:288,t:1526919064955};\\\", \\\"{x:178,y:290,t:1526919064972};\\\", \\\"{x:174,y:290,t:1526919064989};\\\", \\\"{x:171,y:291,t:1526919065006};\\\", \\\"{x:169,y:291,t:1526919065021};\\\", \\\"{x:167,y:292,t:1526919065039};\\\", \\\"{x:166,y:294,t:1526919065055};\\\", \\\"{x:165,y:296,t:1526919065072};\\\", \\\"{x:164,y:297,t:1526919065088};\\\", \\\"{x:163,y:299,t:1526919065106};\\\", \\\"{x:162,y:300,t:1526919065122};\\\", \\\"{x:159,y:301,t:1526919065138};\\\", \\\"{x:156,y:302,t:1526919065155};\\\", \\\"{x:152,y:303,t:1526919065172};\\\", \\\"{x:149,y:304,t:1526919065189};\\\", \\\"{x:145,y:306,t:1526919065206};\\\", \\\"{x:142,y:307,t:1526919065221};\\\", \\\"{x:141,y:307,t:1526919065239};\\\", \\\"{x:139,y:308,t:1526919065255};\\\", \\\"{x:142,y:311,t:1526919065520};\\\", \\\"{x:148,y:317,t:1526919065527};\\\", \\\"{x:155,y:324,t:1526919065538};\\\", \\\"{x:181,y:354,t:1526919065558};\\\", \\\"{x:213,y:391,t:1526919065573};\\\", \\\"{x:235,y:418,t:1526919065589};\\\", \\\"{x:250,y:433,t:1526919065605};\\\", \\\"{x:268,y:456,t:1526919065623};\\\", \\\"{x:277,y:469,t:1526919065639};\\\", \\\"{x:283,y:480,t:1526919065655};\\\", \\\"{x:290,y:495,t:1526919065672};\\\", \\\"{x:294,y:505,t:1526919065689};\\\", \\\"{x:296,y:511,t:1526919065704};\\\", \\\"{x:297,y:515,t:1526919065722};\\\", \\\"{x:299,y:520,t:1526919065739};\\\", \\\"{x:300,y:526,t:1526919065756};\\\", \\\"{x:301,y:532,t:1526919065781};\\\", \\\"{x:302,y:538,t:1526919065788};\\\", \\\"{x:302,y:542,t:1526919065805};\\\", \\\"{x:302,y:546,t:1526919065822};\\\", \\\"{x:302,y:549,t:1526919065838};\\\", \\\"{x:302,y:552,t:1526919065855};\\\", \\\"{x:302,y:555,t:1526919065872};\\\", \\\"{x:302,y:558,t:1526919065888};\\\", \\\"{x:302,y:558,t:1526919065904};\\\", \\\"{x:302,y:558,t:1526919065928};\\\", \\\"{x:302,y:558,t:1526919065938};\\\", \\\"{x:301,y:558,t:1526919065956};\\\", \\\"{x:300,y:558,t:1526919065972};\\\", \\\"{x:299,y:558,t:1526919065984};\\\", \\\"{x:300,y:528,t:1526919066586};\\\", \\\"{x:304,y:526,t:1526919066593};\\\", \\\"{x:309,y:524,t:1526919066605};\\\", \\\"{x:347,y:505,t:1526919066622};\\\", \\\"{x:440,y:464,t:1526919066639};\\\", \\\"{x:559,y:424,t:1526919066655};\\\", \\\"{x:666,y:398,t:1526919066672};\\\", \\\"{x:803,y:376,t:1526919066689};\\\", \\\"{x:879,y:369,t:1526919066705};\\\", \\\"{x:937,y:364,t:1526919066721};\\\", \\\"{x:956,y:362,t:1526919066738};\\\", \\\"{x:968,y:362,t:1526919066755};\\\", \\\"{x:970,y:362,t:1526919066772};\\\" ] }, { \\\"rt\\\": 14490, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 2182307, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:972,y:392,t:1526919068589};\\\", \\\"{x:980,y:397,t:1526919068605};\\\", \\\"{x:1014,y:423,t:1526919068623};\\\", \\\"{x:1091,y:494,t:1526919068642};\\\", \\\"{x:1176,y:586,t:1526919068655};\\\", \\\"{x:1228,y:647,t:1526919068673};\\\", \\\"{x:1266,y:692,t:1526919068688};\\\", \\\"{x:1276,y:706,t:1526919068705};\\\", \\\"{x:1288,y:724,t:1526919068722};\\\", \\\"{x:1290,y:729,t:1526919068739};\\\", \\\"{x:1291,y:731,t:1526919068755};\\\", \\\"{x:1286,y:728,t:1526919068772};\\\", \\\"{x:1278,y:717,t:1526919068789};\\\", \\\"{x:1269,y:704,t:1526919068806};\\\", \\\"{x:1261,y:695,t:1526919068823};\\\", \\\"{x:1253,y:685,t:1526919068840};\\\", \\\"{x:1239,y:674,t:1526919068856};\\\", \\\"{x:1221,y:672,t:1526919068874};\\\", \\\"{x:1199,y:672,t:1526919068889};\\\", \\\"{x:1177,y:680,t:1526919068906};\\\", \\\"{x:1159,y:691,t:1526919068922};\\\", \\\"{x:1142,y:712,t:1526919068939};\\\", \\\"{x:1137,y:721,t:1526919068956};\\\", \\\"{x:1132,y:732,t:1526919068972};\\\", \\\"{x:1130,y:738,t:1526919068990};\\\", \\\"{x:1129,y:743,t:1526919069006};\\\", \\\"{x:1128,y:743,t:1526919069260};\\\", \\\"{x:1126,y:745,t:1526919069273};\\\", \\\"{x:1123,y:748,t:1526919069290};\\\", \\\"{x:1119,y:751,t:1526919069307};\\\", \\\"{x:1115,y:753,t:1526919069323};\\\", \\\"{x:1113,y:755,t:1526919069339};\\\", \\\"{x:1111,y:756,t:1526919069356};\\\", \\\"{x:1111,y:756,t:1526919069372};\\\", \\\"{x:1111,y:756,t:1526919069533};\\\", \\\"{x:1111,y:756,t:1526919069540};\\\", \\\"{x:1111,y:757,t:1526919069555};\\\", \\\"{x:1111,y:757,t:1526919069572};\\\", \\\"{x:1111,y:757,t:1526919069604};\\\", \\\"{x:1110,y:756,t:1526919069612};\\\", \\\"{x:1108,y:754,t:1526919069624};\\\", \\\"{x:1103,y:747,t:1526919069640};\\\", \\\"{x:1091,y:730,t:1526919069656};\\\", \\\"{x:1081,y:715,t:1526919069673};\\\", \\\"{x:1073,y:699,t:1526919069690};\\\", \\\"{x:1065,y:683,t:1526919069707};\\\", \\\"{x:1060,y:672,t:1526919069723};\\\", \\\"{x:1057,y:667,t:1526919069739};\\\", \\\"{x:1055,y:663,t:1526919069755};\\\", \\\"{x:1053,y:660,t:1526919069772};\\\", \\\"{x:1052,y:657,t:1526919069788};\\\", \\\"{x:1052,y:656,t:1526919069805};\\\", \\\"{x:1052,y:655,t:1526919069822};\\\", \\\"{x:1051,y:654,t:1526919069839};\\\", \\\"{x:1051,y:653,t:1526919069857};\\\", \\\"{x:1051,y:652,t:1526919069874};\\\", \\\"{x:1051,y:651,t:1526919069890};\\\", \\\"{x:1051,y:650,t:1526919069907};\\\", \\\"{x:1051,y:649,t:1526919069924};\\\", \\\"{x:1051,y:648,t:1526919069940};\\\", \\\"{x:1051,y:646,t:1526919069955};\\\", \\\"{x:1051,y:645,t:1526919069972};\\\", \\\"{x:1051,y:643,t:1526919069989};\\\", \\\"{x:1051,y:641,t:1526919070005};\\\", \\\"{x:1051,y:639,t:1526919070023};\\\", \\\"{x:1051,y:637,t:1526919070040};\\\", \\\"{x:1051,y:636,t:1526919070056};\\\", \\\"{x:1051,y:635,t:1526919070073};\\\", \\\"{x:1051,y:635,t:1526919070089};\\\", \\\"{x:1051,y:635,t:1526919070106};\\\", \\\"{x:1051,y:635,t:1526919070123};\\\", \\\"{x:1050,y:635,t:1526919070140};\\\", \\\"{x:1050,y:634,t:1526919070158};\\\", \\\"{x:1050,y:634,t:1526919070173};\\\", \\\"{x:1050,y:634,t:1526919073096};\\\", \\\"{x:1050,y:635,t:1526919073107};\\\", \\\"{x:1051,y:637,t:1526919073123};\\\", \\\"{x:1053,y:639,t:1526919073140};\\\", \\\"{x:1054,y:641,t:1526919073156};\\\", \\\"{x:1055,y:643,t:1526919073173};\\\", \\\"{x:1057,y:644,t:1526919073190};\\\", \\\"{x:1059,y:647,t:1526919073207};\\\", \\\"{x:1061,y:651,t:1526919073222};\\\", \\\"{x:1064,y:655,t:1526919073239};\\\", \\\"{x:1066,y:659,t:1526919073256};\\\", \\\"{x:1068,y:664,t:1526919073272};\\\", \\\"{x:1072,y:672,t:1526919073288};\\\", \\\"{x:1074,y:679,t:1526919073307};\\\", \\\"{x:1078,y:686,t:1526919073323};\\\", \\\"{x:1080,y:690,t:1526919073339};\\\", \\\"{x:1082,y:694,t:1526919073356};\\\", \\\"{x:1083,y:697,t:1526919073373};\\\", \\\"{x:1084,y:698,t:1526919073391};\\\", \\\"{x:1084,y:699,t:1526919073407};\\\", \\\"{x:1084,y:700,t:1526919073423};\\\", \\\"{x:1084,y:700,t:1526919073465};\\\", \\\"{x:1083,y:699,t:1526919073473};\\\", \\\"{x:1079,y:695,t:1526919073489};\\\", \\\"{x:1074,y:687,t:1526919073506};\\\", \\\"{x:1070,y:678,t:1526919073522};\\\", \\\"{x:1064,y:666,t:1526919073539};\\\", \\\"{x:1058,y:655,t:1526919073555};\\\", \\\"{x:1053,y:646,t:1526919073572};\\\", \\\"{x:1049,y:639,t:1526919073590};\\\", \\\"{x:1048,y:636,t:1526919073606};\\\", \\\"{x:1045,y:632,t:1526919073624};\\\", \\\"{x:1044,y:630,t:1526919073639};\\\", \\\"{x:1043,y:627,t:1526919073657};\\\", \\\"{x:1043,y:626,t:1526919073673};\\\", \\\"{x:1043,y:625,t:1526919073689};\\\", \\\"{x:1043,y:624,t:1526919073706};\\\", \\\"{x:1043,y:624,t:1526919073722};\\\", \\\"{x:1043,y:623,t:1526919073745};\\\", \\\"{x:1043,y:623,t:1526919073826};\\\", \\\"{x:1043,y:623,t:1526919073865};\\\", \\\"{x:1044,y:624,t:1526919073930};\\\", \\\"{x:1044,y:624,t:1526919073946};\\\", \\\"{x:1044,y:624,t:1526919073956};\\\", \\\"{x:1044,y:624,t:1526919073972};\\\", \\\"{x:1044,y:625,t:1526919073990};\\\", \\\"{x:1044,y:625,t:1526919074006};\\\", \\\"{x:1044,y:626,t:1526919074023};\\\", \\\"{x:1044,y:626,t:1526919074040};\\\", \\\"{x:1044,y:626,t:1526919074056};\\\", \\\"{x:1044,y:626,t:1526919074072};\\\", \\\"{x:1044,y:627,t:1526919074090};\\\", \\\"{x:1044,y:626,t:1526919074530};\\\", \\\"{x:1043,y:626,t:1526919077245};\\\", \\\"{x:1038,y:626,t:1526919077256};\\\", \\\"{x:1012,y:625,t:1526919077274};\\\", \\\"{x:949,y:617,t:1526919077289};\\\", \\\"{x:872,y:598,t:1526919077306};\\\", \\\"{x:789,y:575,t:1526919077323};\\\", \\\"{x:665,y:536,t:1526919077340};\\\", \\\"{x:586,y:509,t:1526919077355};\\\", \\\"{x:541,y:493,t:1526919077374};\\\", \\\"{x:509,y:482,t:1526919077389};\\\", \\\"{x:488,y:477,t:1526919077406};\\\", \\\"{x:469,y:474,t:1526919077423};\\\", \\\"{x:457,y:474,t:1526919077441};\\\", \\\"{x:450,y:474,t:1526919077456};\\\", \\\"{x:447,y:474,t:1526919077708};\\\", \\\"{x:444,y:472,t:1526919077722};\\\", \\\"{x:435,y:466,t:1526919077739};\\\", \\\"{x:421,y:454,t:1526919077757};\\\", \\\"{x:399,y:436,t:1526919077773};\\\", \\\"{x:382,y:428,t:1526919077790};\\\", \\\"{x:362,y:423,t:1526919077806};\\\", \\\"{x:335,y:421,t:1526919077823};\\\", \\\"{x:307,y:421,t:1526919077841};\\\", \\\"{x:278,y:421,t:1526919077858};\\\", \\\"{x:261,y:421,t:1526919077874};\\\", \\\"{x:241,y:421,t:1526919077890};\\\", \\\"{x:224,y:421,t:1526919077907};\\\", \\\"{x:209,y:420,t:1526919077924};\\\", \\\"{x:199,y:419,t:1526919077940};\\\", \\\"{x:188,y:417,t:1526919077956};\\\", \\\"{x:183,y:417,t:1526919077974};\\\", \\\"{x:179,y:416,t:1526919077990};\\\", \\\"{x:176,y:416,t:1526919078006};\\\", \\\"{x:172,y:416,t:1526919078023};\\\", \\\"{x:170,y:416,t:1526919078040};\\\", \\\"{x:166,y:416,t:1526919078057};\\\", \\\"{x:164,y:416,t:1526919078074};\\\", \\\"{x:162,y:416,t:1526919078091};\\\", \\\"{x:161,y:417,t:1526919078107};\\\", \\\"{x:158,y:420,t:1526919078124};\\\", \\\"{x:155,y:424,t:1526919078140};\\\", \\\"{x:151,y:428,t:1526919078157};\\\", \\\"{x:146,y:433,t:1526919078174};\\\", \\\"{x:143,y:437,t:1526919078189};\\\", \\\"{x:140,y:442,t:1526919078208};\\\", \\\"{x:136,y:447,t:1526919078224};\\\", \\\"{x:133,y:451,t:1526919078241};\\\", \\\"{x:130,y:455,t:1526919078258};\\\", \\\"{x:128,y:457,t:1526919078274};\\\", \\\"{x:127,y:458,t:1526919078290};\\\", \\\"{x:126,y:459,t:1526919078308};\\\", \\\"{x:125,y:459,t:1526919078323};\\\", \\\"{x:125,y:459,t:1526919078340};\\\", \\\"{x:125,y:459,t:1526919078357};\\\", \\\"{x:126,y:459,t:1526919078397};\\\", \\\"{x:128,y:459,t:1526919078408};\\\", \\\"{x:140,y:459,t:1526919078424};\\\", \\\"{x:156,y:458,t:1526919078441};\\\", \\\"{x:177,y:455,t:1526919078457};\\\", \\\"{x:209,y:447,t:1526919078475};\\\", \\\"{x:229,y:439,t:1526919078492};\\\", \\\"{x:254,y:429,t:1526919078507};\\\", \\\"{x:268,y:424,t:1526919078525};\\\", \\\"{x:281,y:419,t:1526919078540};\\\", \\\"{x:291,y:416,t:1526919078558};\\\", \\\"{x:304,y:412,t:1526919078573};\\\", \\\"{x:313,y:409,t:1526919078591};\\\", \\\"{x:322,y:406,t:1526919078606};\\\", \\\"{x:328,y:404,t:1526919078625};\\\", \\\"{x:333,y:401,t:1526919078639};\\\", \\\"{x:336,y:399,t:1526919078657};\\\", \\\"{x:338,y:398,t:1526919078673};\\\", \\\"{x:339,y:397,t:1526919078690};\\\", \\\"{x:339,y:397,t:1526919078707};\\\", \\\"{x:340,y:396,t:1526919078724};\\\", \\\"{x:341,y:394,t:1526919078740};\\\", \\\"{x:343,y:392,t:1526919078757};\\\", \\\"{x:346,y:389,t:1526919078774};\\\", \\\"{x:348,y:387,t:1526919078790};\\\", \\\"{x:349,y:386,t:1526919078806};\\\", \\\"{x:350,y:384,t:1526919078824};\\\", \\\"{x:351,y:383,t:1526919078841};\\\", \\\"{x:351,y:381,t:1526919078857};\\\", \\\"{x:352,y:378,t:1526919078874};\\\", \\\"{x:353,y:376,t:1526919078890};\\\", \\\"{x:354,y:373,t:1526919078909};\\\", \\\"{x:355,y:371,t:1526919078924};\\\", \\\"{x:355,y:369,t:1526919078939};\\\", \\\"{x:355,y:365,t:1526919078958};\\\", \\\"{x:352,y:360,t:1526919078974};\\\", \\\"{x:346,y:352,t:1526919078990};\\\", \\\"{x:328,y:339,t:1526919079007};\\\", \\\"{x:307,y:330,t:1526919079023};\\\", \\\"{x:285,y:326,t:1526919079041};\\\", \\\"{x:269,y:324,t:1526919079056};\\\", \\\"{x:251,y:322,t:1526919079074};\\\", \\\"{x:237,y:321,t:1526919079090};\\\", \\\"{x:228,y:321,t:1526919079107};\\\", \\\"{x:218,y:321,t:1526919079123};\\\", \\\"{x:209,y:324,t:1526919079140};\\\", \\\"{x:201,y:328,t:1526919079157};\\\", \\\"{x:195,y:329,t:1526919079174};\\\", \\\"{x:191,y:331,t:1526919079189};\\\", \\\"{x:184,y:334,t:1526919079206};\\\", \\\"{x:179,y:338,t:1526919079224};\\\", \\\"{x:174,y:342,t:1526919079240};\\\", \\\"{x:170,y:346,t:1526919079257};\\\", \\\"{x:166,y:349,t:1526919079274};\\\", \\\"{x:163,y:351,t:1526919079291};\\\", \\\"{x:160,y:352,t:1526919079307};\\\", \\\"{x:158,y:353,t:1526919079323};\\\", \\\"{x:156,y:354,t:1526919079341};\\\", \\\"{x:154,y:355,t:1526919079357};\\\", \\\"{x:152,y:356,t:1526919079373};\\\", \\\"{x:151,y:357,t:1526919079390};\\\", \\\"{x:149,y:358,t:1526919079406};\\\", \\\"{x:146,y:362,t:1526919079423};\\\", \\\"{x:144,y:367,t:1526919079440};\\\", \\\"{x:142,y:370,t:1526919079457};\\\", \\\"{x:140,y:373,t:1526919079473};\\\", \\\"{x:139,y:375,t:1526919079491};\\\", \\\"{x:139,y:376,t:1526919079507};\\\", \\\"{x:139,y:376,t:1526919079523};\\\", \\\"{x:139,y:376,t:1526919079624};\\\", \\\"{x:139,y:375,t:1526919079640};\\\", \\\"{x:140,y:374,t:1526919079658};\\\", \\\"{x:140,y:373,t:1526919079675};\\\", \\\"{x:141,y:372,t:1526919079691};\\\", \\\"{x:141,y:371,t:1526919079706};\\\", \\\"{x:142,y:370,t:1526919079724};\\\", \\\"{x:143,y:370,t:1526919079740};\\\", \\\"{x:144,y:369,t:1526919079758};\\\", \\\"{x:147,y:367,t:1526919079774};\\\", \\\"{x:154,y:363,t:1526919079791};\\\", \\\"{x:165,y:359,t:1526919079806};\\\", \\\"{x:174,y:356,t:1526919079824};\\\", \\\"{x:201,y:351,t:1526919079841};\\\", \\\"{x:221,y:351,t:1526919079857};\\\", \\\"{x:243,y:350,t:1526919079874};\\\", \\\"{x:258,y:349,t:1526919079892};\\\", \\\"{x:267,y:347,t:1526919079907};\\\", \\\"{x:275,y:346,t:1526919079924};\\\", \\\"{x:280,y:345,t:1526919079941};\\\", \\\"{x:284,y:343,t:1526919079957};\\\", \\\"{x:289,y:342,t:1526919079975};\\\", \\\"{x:301,y:340,t:1526919079990};\\\", \\\"{x:312,y:339,t:1526919080007};\\\", \\\"{x:325,y:339,t:1526919080024};\\\", \\\"{x:336,y:339,t:1526919080041};\\\", \\\"{x:346,y:340,t:1526919080057};\\\", \\\"{x:351,y:343,t:1526919080074};\\\", \\\"{x:356,y:348,t:1526919080090};\\\", \\\"{x:360,y:358,t:1526919080107};\\\", \\\"{x:363,y:373,t:1526919080124};\\\", \\\"{x:364,y:388,t:1526919080141};\\\", \\\"{x:365,y:406,t:1526919080157};\\\", \\\"{x:365,y:421,t:1526919080175};\\\", \\\"{x:365,y:434,t:1526919080190};\\\", \\\"{x:365,y:447,t:1526919080209};\\\", \\\"{x:365,y:458,t:1526919080224};\\\", \\\"{x:365,y:469,t:1526919080240};\\\", \\\"{x:365,y:478,t:1526919080256};\\\", \\\"{x:365,y:483,t:1526919080274};\\\", \\\"{x:365,y:486,t:1526919080290};\\\", \\\"{x:365,y:489,t:1526919080307};\\\", \\\"{x:364,y:492,t:1526919080324};\\\", \\\"{x:362,y:494,t:1526919080340};\\\", \\\"{x:360,y:496,t:1526919080357};\\\", \\\"{x:353,y:498,t:1526919080373};\\\", \\\"{x:343,y:499,t:1526919080391};\\\", \\\"{x:331,y:500,t:1526919080407};\\\", \\\"{x:320,y:500,t:1526919080424};\\\", \\\"{x:311,y:500,t:1526919080441};\\\", \\\"{x:302,y:497,t:1526919080457};\\\", \\\"{x:297,y:492,t:1526919080473};\\\", \\\"{x:293,y:487,t:1526919080491};\\\", \\\"{x:290,y:483,t:1526919080507};\\\", \\\"{x:288,y:479,t:1526919080526};\\\", \\\"{x:286,y:476,t:1526919080540};\\\", \\\"{x:285,y:473,t:1526919080558};\\\", \\\"{x:285,y:470,t:1526919080573};\\\", \\\"{x:285,y:465,t:1526919080590};\\\", \\\"{x:285,y:460,t:1526919080607};\\\", \\\"{x:285,y:454,t:1526919080624};\\\", \\\"{x:287,y:448,t:1526919080641};\\\", \\\"{x:289,y:443,t:1526919080658};\\\", \\\"{x:290,y:440,t:1526919080675};\\\", \\\"{x:291,y:438,t:1526919080690};\\\", \\\"{x:291,y:436,t:1526919080706};\\\", \\\"{x:291,y:431,t:1526919080723};\\\", \\\"{x:290,y:420,t:1526919080740};\\\", \\\"{x:286,y:405,t:1526919080757};\\\", \\\"{x:282,y:394,t:1526919080775};\\\", \\\"{x:278,y:386,t:1526919080790};\\\", \\\"{x:272,y:379,t:1526919080806};\\\", \\\"{x:268,y:376,t:1526919080824};\\\", \\\"{x:266,y:374,t:1526919080840};\\\", \\\"{x:265,y:374,t:1526919080856};\\\", \\\"{x:264,y:374,t:1526919080873};\\\", \\\"{x:262,y:374,t:1526919080889};\\\", \\\"{x:261,y:375,t:1526919080907};\\\", \\\"{x:259,y:376,t:1526919080924};\\\", \\\"{x:258,y:377,t:1526919080941};\\\", \\\"{x:256,y:378,t:1526919080956};\\\", \\\"{x:255,y:379,t:1526919080973};\\\", \\\"{x:254,y:380,t:1526919080990};\\\", \\\"{x:253,y:380,t:1526919081008};\\\", \\\"{x:253,y:380,t:1526919081019};\\\", \\\"{x:253,y:384,t:1526919081294};\\\", \\\"{x:253,y:392,t:1526919081307};\\\", \\\"{x:253,y:407,t:1526919081325};\\\", \\\"{x:253,y:421,t:1526919081341};\\\", \\\"{x:254,y:435,t:1526919081356};\\\", \\\"{x:258,y:460,t:1526919081374};\\\", \\\"{x:264,y:488,t:1526919081391};\\\", \\\"{x:266,y:499,t:1526919081409};\\\", \\\"{x:269,y:508,t:1526919081423};\\\", \\\"{x:271,y:518,t:1526919081440};\\\", \\\"{x:272,y:524,t:1526919081457};\\\", \\\"{x:272,y:527,t:1526919081474};\\\", \\\"{x:272,y:531,t:1526919081492};\\\", \\\"{x:272,y:533,t:1526919081507};\\\", \\\"{x:272,y:534,t:1526919081523};\\\", \\\"{x:272,y:534,t:1526919081541};\\\", \\\"{x:272,y:535,t:1526919081672};\\\", \\\"{x:272,y:535,t:1526919081680};\\\", \\\"{x:272,y:535,t:1526919081690};\\\", \\\"{x:272,y:536,t:1526919081706};\\\", \\\"{x:272,y:537,t:1526919081723};\\\", \\\"{x:272,y:538,t:1526919081740};\\\", \\\"{x:272,y:538,t:1526919081757};\\\", \\\"{x:272,y:539,t:1526919081774};\\\", \\\"{x:272,y:539,t:1526919081790};\\\", \\\"{x:272,y:540,t:1526919081807};\\\", \\\"{x:272,y:540,t:1526919081824};\\\" ] }, { \\\"rt\\\": 9246, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 2192802, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1479,y:1479,t:0};\\\", \\\"{x:272,y:538,t:1526919083884};\\\", \\\"{x:272,y:535,t:1526919083891};\\\", \\\"{x:274,y:531,t:1526919083907};\\\", \\\"{x:281,y:510,t:1526919083924};\\\", \\\"{x:289,y:479,t:1526919083941};\\\", \\\"{x:298,y:448,t:1526919083959};\\\", \\\"{x:305,y:425,t:1526919083974};\\\", \\\"{x:312,y:395,t:1526919083992};\\\", \\\"{x:317,y:368,t:1526919084008};\\\", \\\"{x:323,y:343,t:1526919084024};\\\", \\\"{x:326,y:317,t:1526919084041};\\\", \\\"{x:328,y:299,t:1526919084058};\\\", \\\"{x:331,y:278,t:1526919084074};\\\", \\\"{x:333,y:263,t:1526919084091};\\\", \\\"{x:333,y:255,t:1526919084108};\\\", \\\"{x:334,y:248,t:1526919084124};\\\", \\\"{x:334,y:246,t:1526919084140};\\\", \\\"{x:334,y:245,t:1526919084158};\\\", \\\"{x:334,y:245,t:1526919084175};\\\", \\\"{x:334,y:245,t:1526919084190};\\\", \\\"{x:334,y:244,t:1526919084208};\\\", \\\"{x:334,y:244,t:1526919084224};\\\", \\\"{x:334,y:243,t:1526919084241};\\\", \\\"{x:334,y:241,t:1526919084257};\\\", \\\"{x:334,y:240,t:1526919084274};\\\", \\\"{x:335,y:238,t:1526919084290};\\\", \\\"{x:335,y:237,t:1526919084307};\\\", \\\"{x:335,y:236,t:1526919084325};\\\", \\\"{x:336,y:235,t:1526919084341};\\\", \\\"{x:336,y:234,t:1526919084357};\\\", \\\"{x:336,y:234,t:1526919085144};\\\", \\\"{x:339,y:235,t:1526919085157};\\\", \\\"{x:348,y:239,t:1526919085174};\\\", \\\"{x:406,y:270,t:1526919085190};\\\", \\\"{x:469,y:299,t:1526919085207};\\\", \\\"{x:541,y:334,t:1526919085224};\\\", \\\"{x:584,y:360,t:1526919085242};\\\", \\\"{x:609,y:379,t:1526919085258};\\\", \\\"{x:629,y:398,t:1526919085274};\\\", \\\"{x:636,y:410,t:1526919085290};\\\", \\\"{x:642,y:425,t:1526919085307};\\\", \\\"{x:644,y:432,t:1526919085324};\\\", \\\"{x:645,y:432,t:1526919085571};\\\", \\\"{x:648,y:433,t:1526919085579};\\\", \\\"{x:658,y:439,t:1526919085590};\\\", \\\"{x:694,y:463,t:1526919085607};\\\", \\\"{x:774,y:522,t:1526919085624};\\\", \\\"{x:830,y:568,t:1526919085641};\\\", \\\"{x:895,y:633,t:1526919085657};\\\", \\\"{x:913,y:654,t:1526919085674};\\\", \\\"{x:931,y:679,t:1526919085690};\\\", \\\"{x:947,y:706,t:1526919085708};\\\", \\\"{x:948,y:711,t:1526919085724};\\\", \\\"{x:948,y:715,t:1526919085740};\\\", \\\"{x:947,y:715,t:1526919085758};\\\", \\\"{x:945,y:715,t:1526919085774};\\\", \\\"{x:943,y:714,t:1526919085791};\\\", \\\"{x:942,y:714,t:1526919085808};\\\", \\\"{x:940,y:714,t:1526919085824};\\\", \\\"{x:939,y:714,t:1526919085840};\\\", \\\"{x:937,y:714,t:1526919085858};\\\", \\\"{x:937,y:714,t:1526919085874};\\\", \\\"{x:937,y:715,t:1526919085891};\\\", \\\"{x:938,y:715,t:1526919085916};\\\", \\\"{x:939,y:715,t:1526919085924};\\\", \\\"{x:941,y:717,t:1526919085941};\\\", \\\"{x:943,y:720,t:1526919085959};\\\", \\\"{x:944,y:723,t:1526919085974};\\\", \\\"{x:946,y:725,t:1526919085991};\\\", \\\"{x:948,y:730,t:1526919086007};\\\", \\\"{x:955,y:735,t:1526919086024};\\\", \\\"{x:966,y:744,t:1526919086040};\\\", \\\"{x:979,y:752,t:1526919086057};\\\", \\\"{x:990,y:757,t:1526919086074};\\\", \\\"{x:999,y:762,t:1526919086091};\\\", \\\"{x:1007,y:766,t:1526919086108};\\\", \\\"{x:1017,y:771,t:1526919086125};\\\", \\\"{x:1021,y:773,t:1526919086140};\\\", \\\"{x:1025,y:775,t:1526919086157};\\\", \\\"{x:1026,y:776,t:1526919086174};\\\", \\\"{x:1027,y:777,t:1526919086191};\\\", \\\"{x:1029,y:777,t:1526919086207};\\\", \\\"{x:1032,y:777,t:1526919086224};\\\", \\\"{x:1034,y:777,t:1526919086241};\\\", \\\"{x:1037,y:776,t:1526919086258};\\\", \\\"{x:1039,y:775,t:1526919086275};\\\", \\\"{x:1041,y:774,t:1526919086291};\\\", \\\"{x:1043,y:772,t:1526919086307};\\\", \\\"{x:1045,y:770,t:1526919086324};\\\", \\\"{x:1047,y:767,t:1526919086342};\\\", \\\"{x:1049,y:765,t:1526919086358};\\\", \\\"{x:1050,y:763,t:1526919086374};\\\", \\\"{x:1051,y:761,t:1526919086392};\\\", \\\"{x:1052,y:759,t:1526919086407};\\\", \\\"{x:1053,y:758,t:1526919086424};\\\", \\\"{x:1053,y:757,t:1526919086440};\\\", \\\"{x:1054,y:757,t:1526919086458};\\\", \\\"{x:1054,y:756,t:1526919086475};\\\", \\\"{x:1054,y:755,t:1526919086492};\\\", \\\"{x:1054,y:753,t:1526919086508};\\\", \\\"{x:1054,y:750,t:1526919086524};\\\", \\\"{x:1054,y:741,t:1526919086541};\\\", \\\"{x:1051,y:728,t:1526919086557};\\\", \\\"{x:1047,y:715,t:1526919086573};\\\", \\\"{x:1044,y:703,t:1526919086591};\\\", \\\"{x:1041,y:688,t:1526919086607};\\\", \\\"{x:1038,y:672,t:1526919086624};\\\", \\\"{x:1037,y:661,t:1526919086641};\\\", \\\"{x:1036,y:652,t:1526919086657};\\\", \\\"{x:1036,y:646,t:1526919086673};\\\", \\\"{x:1036,y:642,t:1526919086691};\\\", \\\"{x:1036,y:641,t:1526919086707};\\\", \\\"{x:1036,y:640,t:1526919086724};\\\", \\\"{x:1036,y:639,t:1526919086741};\\\", \\\"{x:1036,y:639,t:1526919086756};\\\", \\\"{x:1036,y:639,t:1526919086773};\\\", \\\"{x:1037,y:638,t:1526919086790};\\\", \\\"{x:1037,y:638,t:1526919086807};\\\", \\\"{x:1038,y:638,t:1526919086824};\\\", \\\"{x:1039,y:637,t:1526919086840};\\\", \\\"{x:1040,y:636,t:1526919086857};\\\", \\\"{x:1042,y:635,t:1526919086873};\\\", \\\"{x:1043,y:634,t:1526919086890};\\\", \\\"{x:1044,y:634,t:1526919086907};\\\", \\\"{x:1045,y:633,t:1526919086924};\\\", \\\"{x:1045,y:633,t:1526919086940};\\\", \\\"{x:1045,y:633,t:1526919086957};\\\", \\\"{x:1043,y:633,t:1526919088313};\\\", \\\"{x:1037,y:633,t:1526919088325};\\\", \\\"{x:991,y:633,t:1526919088341};\\\", \\\"{x:915,y:626,t:1526919088360};\\\", \\\"{x:801,y:608,t:1526919088376};\\\", \\\"{x:666,y:581,t:1526919088391};\\\", \\\"{x:524,y:540,t:1526919088408};\\\", \\\"{x:471,y:521,t:1526919088424};\\\", \\\"{x:440,y:510,t:1526919088441};\\\", \\\"{x:422,y:502,t:1526919088460};\\\", \\\"{x:412,y:497,t:1526919088474};\\\", \\\"{x:409,y:496,t:1526919088491};\\\", \\\"{x:408,y:496,t:1526919088689};\\\", \\\"{x:403,y:496,t:1526919088697};\\\", \\\"{x:396,y:496,t:1526919088707};\\\", \\\"{x:373,y:492,t:1526919088725};\\\", \\\"{x:348,y:486,t:1526919088740};\\\", \\\"{x:326,y:481,t:1526919088757};\\\", \\\"{x:305,y:476,t:1526919088775};\\\", \\\"{x:289,y:471,t:1526919088791};\\\", \\\"{x:274,y:466,t:1526919088807};\\\", \\\"{x:265,y:463,t:1526919088825};\\\", \\\"{x:249,y:457,t:1526919088841};\\\", \\\"{x:239,y:453,t:1526919088858};\\\", \\\"{x:230,y:450,t:1526919088874};\\\", \\\"{x:223,y:448,t:1526919088892};\\\", \\\"{x:218,y:446,t:1526919088907};\\\", \\\"{x:215,y:444,t:1526919088924};\\\", \\\"{x:211,y:443,t:1526919088941};\\\", \\\"{x:207,y:441,t:1526919088958};\\\", \\\"{x:205,y:440,t:1526919088974};\\\", \\\"{x:203,y:439,t:1526919088992};\\\", \\\"{x:200,y:437,t:1526919089008};\\\", \\\"{x:198,y:436,t:1526919089024};\\\", \\\"{x:194,y:434,t:1526919089041};\\\", \\\"{x:191,y:434,t:1526919089058};\\\", \\\"{x:186,y:433,t:1526919089076};\\\", \\\"{x:182,y:433,t:1526919089091};\\\", \\\"{x:178,y:432,t:1526919089108};\\\", \\\"{x:174,y:431,t:1526919089125};\\\", \\\"{x:170,y:431,t:1526919089141};\\\", \\\"{x:167,y:431,t:1526919089158};\\\", \\\"{x:163,y:431,t:1526919089174};\\\", \\\"{x:161,y:431,t:1526919089192};\\\", \\\"{x:158,y:431,t:1526919089208};\\\", \\\"{x:155,y:431,t:1526919089224};\\\", \\\"{x:153,y:432,t:1526919089241};\\\", \\\"{x:150,y:432,t:1526919089258};\\\", \\\"{x:148,y:431,t:1526919089275};\\\", \\\"{x:146,y:430,t:1526919089291};\\\", \\\"{x:145,y:428,t:1526919089308};\\\", \\\"{x:144,y:426,t:1526919089324};\\\", \\\"{x:143,y:424,t:1526919089342};\\\", \\\"{x:143,y:423,t:1526919089358};\\\", \\\"{x:142,y:423,t:1526919089375};\\\", \\\"{x:142,y:422,t:1526919089392};\\\", \\\"{x:141,y:422,t:1526919089409};\\\", \\\"{x:141,y:422,t:1526919089424};\\\", \\\"{x:141,y:423,t:1526919089441};\\\", \\\"{x:141,y:424,t:1526919089458};\\\", \\\"{x:140,y:425,t:1526919089474};\\\", \\\"{x:140,y:426,t:1526919089492};\\\", \\\"{x:140,y:427,t:1526919089507};\\\", \\\"{x:139,y:427,t:1526919089524};\\\", \\\"{x:139,y:428,t:1526919089541};\\\", \\\"{x:138,y:428,t:1526919089559};\\\", \\\"{x:137,y:429,t:1526919089574};\\\", \\\"{x:137,y:429,t:1526919089592};\\\", \\\"{x:136,y:429,t:1526919089607};\\\", \\\"{x:135,y:429,t:1526919089624};\\\", \\\"{x:135,y:429,t:1526919089641};\\\", \\\"{x:133,y:427,t:1526919089659};\\\", \\\"{x:133,y:425,t:1526919089675};\\\", \\\"{x:132,y:423,t:1526919089691};\\\", \\\"{x:131,y:422,t:1526919089707};\\\", \\\"{x:130,y:421,t:1526919089724};\\\", \\\"{x:129,y:419,t:1526919089742};\\\", \\\"{x:128,y:418,t:1526919089759};\\\", \\\"{x:127,y:417,t:1526919089775};\\\", \\\"{x:127,y:416,t:1526919089791};\\\", \\\"{x:126,y:415,t:1526919089807};\\\", \\\"{x:125,y:413,t:1526919089825};\\\", \\\"{x:125,y:412,t:1526919089841};\\\", \\\"{x:124,y:411,t:1526919089858};\\\", \\\"{x:124,y:409,t:1526919089874};\\\", \\\"{x:123,y:408,t:1526919089891};\\\", \\\"{x:123,y:407,t:1526919089907};\\\", \\\"{x:123,y:407,t:1526919089925};\\\", \\\"{x:125,y:407,t:1526919090393};\\\", \\\"{x:130,y:406,t:1526919090408};\\\", \\\"{x:145,y:403,t:1526919090424};\\\", \\\"{x:164,y:399,t:1526919090442};\\\", \\\"{x:195,y:395,t:1526919090459};\\\", \\\"{x:215,y:392,t:1526919090475};\\\", \\\"{x:236,y:390,t:1526919090491};\\\", \\\"{x:260,y:389,t:1526919090508};\\\", \\\"{x:282,y:388,t:1526919090525};\\\", \\\"{x:308,y:387,t:1526919090542};\\\", \\\"{x:329,y:385,t:1526919090557};\\\", \\\"{x:342,y:384,t:1526919090574};\\\", \\\"{x:353,y:384,t:1526919090592};\\\", \\\"{x:362,y:384,t:1526919090607};\\\", \\\"{x:370,y:387,t:1526919090624};\\\", \\\"{x:375,y:390,t:1526919090641};\\\", \\\"{x:380,y:394,t:1526919090658};\\\", \\\"{x:384,y:398,t:1526919090674};\\\", \\\"{x:386,y:402,t:1526919090691};\\\", \\\"{x:387,y:407,t:1526919090708};\\\", \\\"{x:387,y:412,t:1526919090724};\\\", \\\"{x:387,y:417,t:1526919090742};\\\", \\\"{x:383,y:424,t:1526919090759};\\\", \\\"{x:375,y:432,t:1526919090775};\\\", \\\"{x:369,y:437,t:1526919090790};\\\", \\\"{x:359,y:443,t:1526919090807};\\\", \\\"{x:350,y:446,t:1526919090825};\\\", \\\"{x:335,y:450,t:1526919090841};\\\", \\\"{x:325,y:451,t:1526919090859};\\\", \\\"{x:314,y:452,t:1526919090875};\\\", \\\"{x:308,y:452,t:1526919090891};\\\", \\\"{x:300,y:453,t:1526919090908};\\\", \\\"{x:294,y:453,t:1526919090924};\\\", \\\"{x:288,y:453,t:1526919090941};\\\", \\\"{x:281,y:453,t:1526919090958};\\\", \\\"{x:274,y:453,t:1526919090974};\\\", \\\"{x:267,y:453,t:1526919090991};\\\", \\\"{x:264,y:453,t:1526919091008};\\\", \\\"{x:260,y:453,t:1526919091024};\\\", \\\"{x:255,y:453,t:1526919091041};\\\", \\\"{x:254,y:453,t:1526919091057};\\\", \\\"{x:254,y:453,t:1526919091075};\\\", \\\"{x:254,y:452,t:1526919091092};\\\", \\\"{x:254,y:452,t:1526919091108};\\\", \\\"{x:254,y:452,t:1526919091125};\\\", \\\"{x:254,y:451,t:1526919091141};\\\", \\\"{x:254,y:450,t:1526919091158};\\\", \\\"{x:255,y:449,t:1526919091175};\\\", \\\"{x:255,y:448,t:1526919091191};\\\", \\\"{x:256,y:445,t:1526919091207};\\\", \\\"{x:258,y:443,t:1526919091224};\\\", \\\"{x:259,y:441,t:1526919091241};\\\", \\\"{x:261,y:438,t:1526919091257};\\\", \\\"{x:262,y:435,t:1526919091274};\\\", \\\"{x:264,y:432,t:1526919091291};\\\", \\\"{x:265,y:429,t:1526919091307};\\\", \\\"{x:266,y:426,t:1526919091325};\\\", \\\"{x:267,y:423,t:1526919091342};\\\", \\\"{x:267,y:422,t:1526919091359};\\\", \\\"{x:267,y:421,t:1526919091374};\\\", \\\"{x:267,y:419,t:1526919091391};\\\", \\\"{x:267,y:418,t:1526919091409};\\\", \\\"{x:267,y:416,t:1526919091424};\\\", \\\"{x:266,y:415,t:1526919091441};\\\", \\\"{x:265,y:411,t:1526919091459};\\\", \\\"{x:264,y:409,t:1526919091475};\\\", \\\"{x:263,y:406,t:1526919091491};\\\", \\\"{x:263,y:405,t:1526919091508};\\\", \\\"{x:262,y:404,t:1526919091525};\\\", \\\"{x:262,y:404,t:1526919091555};\\\", \\\"{x:262,y:404,t:1526919091811};\\\", \\\"{x:262,y:407,t:1526919091825};\\\", \\\"{x:267,y:416,t:1526919091842};\\\", \\\"{x:271,y:425,t:1526919091859};\\\", \\\"{x:274,y:434,t:1526919091876};\\\", \\\"{x:280,y:452,t:1526919091892};\\\", \\\"{x:284,y:463,t:1526919091909};\\\", \\\"{x:287,y:474,t:1526919091926};\\\", \\\"{x:289,y:485,t:1526919091943};\\\", \\\"{x:292,y:496,t:1526919091959};\\\", \\\"{x:293,y:507,t:1526919091974};\\\", \\\"{x:294,y:514,t:1526919091991};\\\", \\\"{x:294,y:520,t:1526919092009};\\\", \\\"{x:294,y:524,t:1526919092026};\\\", \\\"{x:294,y:527,t:1526919092042};\\\", \\\"{x:294,y:528,t:1526919092058};\\\", \\\"{x:294,y:529,t:1526919092075};\\\", \\\"{x:294,y:530,t:1526919092092};\\\", \\\"{x:294,y:531,t:1526919092108};\\\", \\\"{x:293,y:531,t:1526919092125};\\\", \\\"{x:293,y:533,t:1526919092141};\\\", \\\"{x:292,y:535,t:1526919092157};\\\", \\\"{x:291,y:537,t:1526919092174};\\\", \\\"{x:290,y:540,t:1526919092191};\\\", \\\"{x:290,y:542,t:1526919092208};\\\", \\\"{x:289,y:544,t:1526919092224};\\\", \\\"{x:289,y:546,t:1526919092242};\\\", \\\"{x:289,y:548,t:1526919092259};\\\", \\\"{x:289,y:550,t:1526919092276};\\\", \\\"{x:288,y:552,t:1526919092291};\\\", \\\"{x:288,y:553,t:1526919092301};\\\" ] }, { \\\"rt\\\": 47921, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 2242091, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"First indicate the 12pm slot on the x-axis and trace the right-most diagonal connected to this slot up until you find points of intersection. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 4206, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 2247308, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9952, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 2258303, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 1347, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 2260982, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"G72GB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"strategy-satisficing\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"G72GB\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 278, dom: 999, initialDom: 1012",
  "javascriptErrors": []
}