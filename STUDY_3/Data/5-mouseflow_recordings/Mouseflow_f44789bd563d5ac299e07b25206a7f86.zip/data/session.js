var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f44789bd563d5ac299e07b25206a7f86",
  "created": "2018-05-25T10:06:06.7340278-07:00",
  "lastActivity": "2018-05-25T10:08:22.2688302-07:00",
  "pageViews": [
    {
      "id": "05250684ef965f60902a8de019014cfa35047f85",
      "startTime": "2018-05-25T10:06:06.773212-07:00",
      "endTime": "2018-05-25T10:08:22.2688302-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 135690,
      "engagementTime": 52749,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 135690,
  "engagementTime": 52749,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "225fab9759709d68b4451f1bd5eab1b1",
  "gdpr": false
}