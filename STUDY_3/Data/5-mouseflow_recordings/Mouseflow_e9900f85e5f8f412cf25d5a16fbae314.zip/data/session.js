var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e9900f85e5f8f412cf25d5a16fbae314",
  "created": "2018-05-21T10:10:11.0480873-07:00",
  "lastActivity": "2018-05-21T10:10:25.3230873-07:00",
  "pageViews": [
    {
      "id": "052111531a8f70f4aee6773ad33693346a47a9e6",
      "startTime": "2018-05-21T10:10:11.0480873-07:00",
      "endTime": "2018-05-21T10:10:25.3230873-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 14275,
      "engagementTime": 13426,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14275,
  "engagementTime": 13426,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DKL3R",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6013fccffa83ef10fadd3c3fb5257a36",
  "gdpr": false
}