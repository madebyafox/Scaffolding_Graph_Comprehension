var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "80546a8ba03969cf5be23d3c929e5e1b",
  "created": "2018-05-22T14:14:42.6829625-07:00",
  "lastActivity": "2018-05-22T14:14:56.6827663-07:00",
  "pageViews": [
    {
      "id": "05224298a05449187b3bd2cd561bfc9d2c790ad0",
      "startTime": "2018-05-22T14:14:42.6829625-07:00",
      "endTime": "2018-05-22T14:14:56.6827663-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 14057,
      "engagementTime": 14057,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14057,
  "engagementTime": 14057,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QOJ6L",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a8a3965fe46989618de2fc01038e10f8",
  "gdpr": false
}