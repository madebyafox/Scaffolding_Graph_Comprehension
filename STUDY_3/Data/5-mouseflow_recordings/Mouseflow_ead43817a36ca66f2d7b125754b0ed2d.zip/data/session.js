var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ead43817a36ca66f2d7b125754b0ed2d",
  "created": "2018-05-22T14:11:35.4629211-07:00",
  "lastActivity": "2018-05-22T14:12:01.1329938-07:00",
  "pageViews": [
    {
      "id": "052235814d6d1c2d4be3b2ab93ef7ee39329c5d0",
      "startTime": "2018-05-22T14:11:35.6159938-07:00",
      "endTime": "2018-05-22T14:12:01.1329938-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 25517,
      "engagementTime": 25168,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25517,
  "engagementTime": 25168,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LK9M",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "84cc1feae23249388e57fea1247b1cc8",
  "gdpr": false
}