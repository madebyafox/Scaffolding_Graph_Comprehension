var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522274117b828d05b389ed887bc4f40f5723e1a"] = {
  "startTime": "2018-05-22T22:16:27.6907565Z",
  "websitePageUrl": "/16",
  "visitTime": 100699,
  "engagementTime": 90948,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c98a208f9c13853a5bc6371ffd2cf142",
    "created": "2018-05-22T22:16:27.3704239+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=Q3JLW",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ee3a7404e9c67565b84b9b45eefadd80",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c98a208f9c13853a5bc6371ffd2cf142/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 102,
      "e": 102,
      "ty": 2,
      "x": 819,
      "y": 719
    },
    {
      "t": 299,
      "e": 299,
      "ty": 2,
      "x": 1072,
      "y": 730
    },
    {
      "t": 300,
      "e": 300,
      "ty": 41,
      "x": 20154,
      "y": 42400,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 1073,
      "y": 731
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 20225,
      "y": 42472,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 562,
      "y": 763
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 393,
      "y": 783
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 33262,
      "y": 42932,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 392,
      "y": 759
    },
    {
      "t": 1199,
      "e": 1199,
      "ty": 6,
      "x": 403,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 403,
      "y": 684
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 37358,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 408,
      "y": 667
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 408,
      "y": 666
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 37904,
      "y": 21714,
      "ta": "#strategyButton"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 416,
      "y": 660
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 42273,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 2032,
      "e": 2032,
      "ty": 7,
      "x": 432,
      "y": 645,
      "ta": "#strategyButton"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 475,
      "y": 618
    },
    {
      "t": 2183,
      "e": 2183,
      "ty": 6,
      "x": 494,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 495,
      "y": 599
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 45065,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 499,
      "y": 588
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 499,
      "y": 570
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 486,
      "y": 546
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 43716,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 485,
      "y": 544
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 43604,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2816,
      "e": 2816,
      "ty": 3,
      "x": 485,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2817,
      "e": 2817,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2927,
      "e": 2927,
      "ty": 4,
      "x": 43604,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2927,
      "e": 2927,
      "ty": 5,
      "x": 485,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 7927,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15388,
      "e": 7927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15507,
      "e": 8046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 15507,
      "e": 8046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15602,
      "e": 8141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 15626,
      "e": 8165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 15787,
      "e": 8326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15788,
      "e": 8327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15842,
      "e": 8381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 15922,
      "e": 8461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15922,
      "e": 8461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15994,
      "e": 8533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 16107,
      "e": 8646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 16107,
      "e": 8646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16186,
      "e": 8725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16187,
      "e": 8726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16194,
      "e": 8733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look "
    },
    {
      "t": 16298,
      "e": 8837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16434,
      "e": 8973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16434,
      "e": 8973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16571,
      "e": 9110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17019,
      "e": 9558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17020,
      "e": 9559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17123,
      "e": 9662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17171,
      "e": 9710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17171,
      "e": 9710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17290,
      "e": 9829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17355,
      "e": 9894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17355,
      "e": 9894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17442,
      "e": 9981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17579,
      "e": 10118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17580,
      "e": 10119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17690,
      "e": 10229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17739,
      "e": 10278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17739,
      "e": 10278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17835,
      "e": 10374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17899,
      "e": 10438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17900,
      "e": 10439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18004,
      "e": 10543,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the "
    },
    {
      "t": 18019,
      "e": 10558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18395,
      "e": 10934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18675,
      "e": 11214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18675,
      "e": 11214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18802,
      "e": 11341,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X"
    },
    {
      "t": 18842,
      "e": 11381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 18867,
      "e": 11406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19115,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 19116,
      "e": 11655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19226,
      "e": 11765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 19315,
      "e": 11854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19315,
      "e": 11854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19427,
      "e": 11966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19634,
      "e": 12173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19635,
      "e": 12174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19754,
      "e": 12293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19819,
      "e": 12358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19820,
      "e": 12359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19899,
      "e": 12438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19922,
      "e": 12461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19922,
      "e": 12461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20051,
      "e": 12590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20130,
      "e": 12669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20130,
      "e": 12669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20234,
      "e": 12773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24027,
      "e": 16566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24027,
      "e": 16566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24114,
      "e": 16653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24114,
      "e": 16653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24122,
      "e": 16661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 24210,
      "e": 16749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24243,
      "e": 16782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24243,
      "e": 16782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24323,
      "e": 16862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24323,
      "e": 16862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24346,
      "e": 16885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 24442,
      "e": 16981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24563,
      "e": 17102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24563,
      "e": 17102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24658,
      "e": 17197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 24666,
      "e": 17205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24666,
      "e": 17205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24730,
      "e": 17269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24867,
      "e": 17406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24868,
      "e": 17407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24946,
      "e": 17485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24947,
      "e": 17486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24954,
      "e": 17493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 25002,
      "e": 17541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25002,
      "e": 17541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25003,
      "e": 17542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25107,
      "e": 17646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25219,
      "e": 17758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 25220,
      "e": 17759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25307,
      "e": 17846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 25315,
      "e": 17854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25316,
      "e": 17855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25386,
      "e": 17925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25522,
      "e": 18061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25523,
      "e": 18062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25586,
      "e": 18125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25618,
      "e": 18157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 25619,
      "e": 18158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25714,
      "e": 18253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 25755,
      "e": 18294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25755,
      "e": 18294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25834,
      "e": 18373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25834,
      "e": 18373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25834,
      "e": 18373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25947,
      "e": 18486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 22540,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32475,
      "e": 23486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32476,
      "e": 23487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32570,
      "e": 23581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32675,
      "e": 23686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32675,
      "e": 23686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32746,
      "e": 23757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32883,
      "e": 23894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32884,
      "e": 23895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32938,
      "e": 23949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33106,
      "e": 24117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33107,
      "e": 24118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33154,
      "e": 24165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33156,
      "e": 24167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33162,
      "e": 24173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 33259,
      "e": 24270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33484,
      "e": 24495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33484,
      "e": 24495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33586,
      "e": 24597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33602,
      "e": 24613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33602,
      "e": 24613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33706,
      "e": 24717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33763,
      "e": 24774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33763,
      "e": 24774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33834,
      "e": 24845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33955,
      "e": 24966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33955,
      "e": 24966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33993,
      "e": 25004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34154,
      "e": 25165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34154,
      "e": 25165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34226,
      "e": 25237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 34322,
      "e": 25333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34322,
      "e": 25333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34322,
      "e": 25333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34322,
      "e": 25333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34418,
      "e": 25429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 34451,
      "e": 25462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35692,
      "e": 26703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35692,
      "e": 26703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35770,
      "e": 26781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 35994,
      "e": 27005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35995,
      "e": 27006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36004,
      "e": 27015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36004,
      "e": 27015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36050,
      "e": 27061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 36058,
      "e": 27069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36073,
      "e": 27084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36073,
      "e": 27084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36186,
      "e": 27197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36794,
      "e": 27805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36866,
      "e": 27877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line upo"
    },
    {
      "t": 36954,
      "e": 27965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37019,
      "e": 28030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up"
    },
    {
      "t": 37291,
      "e": 28302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37291,
      "e": 28302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37378,
      "e": 28389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37610,
      "e": 28621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 37611,
      "e": 28622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37691,
      "e": 28702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 37730,
      "e": 28741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37732,
      "e": 28743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37826,
      "e": 28837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37930,
      "e": 28941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37931,
      "e": 28942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38017,
      "e": 29028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38204,
      "e": 29215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38205,
      "e": 29216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38274,
      "e": 29285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38403,
      "e": 29414,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up veet"
    },
    {
      "t": 38442,
      "e": 29453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38443,
      "e": 29454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38513,
      "e": 29524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38586,
      "e": 29597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38588,
      "e": 29599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38683,
      "e": 29694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 38827,
      "e": 29838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38828,
      "e": 29839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38897,
      "e": 29908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39002,
      "e": 30013,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up veetica"
    },
    {
      "t": 39010,
      "e": 30021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39011,
      "e": 30022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39074,
      "e": 30085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39154,
      "e": 30165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39155,
      "e": 30166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39259,
      "e": 30270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39467,
      "e": 30478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 39467,
      "e": 30478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39562,
      "e": 30573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39562,
      "e": 30573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39569,
      "e": 30580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 39658,
      "e": 30669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39770,
      "e": 30781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 39771,
      "e": 30782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39858,
      "e": 30869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 39883,
      "e": 30894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39883,
      "e": 30894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39986,
      "e": 30997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40000,
      "e": 31011,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40090,
      "e": 31101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40090,
      "e": 31101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40162,
      "e": 31173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40226,
      "e": 31237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40227,
      "e": 31238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40282,
      "e": 31293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40282,
      "e": 31293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40289,
      "e": 31300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 40370,
      "e": 31381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40667,
      "e": 31678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 40670,
      "e": 31681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40794,
      "e": 31805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 41018,
      "e": 32029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 41018,
      "e": 32029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41129,
      "e": 32140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 43900,
      "e": 34911,
      "ty": 2,
      "x": 467,
      "y": 533
    },
    {
      "t": 44000,
      "e": 35011,
      "ty": 41,
      "x": 41581,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44100,
      "e": 35111,
      "ty": 2,
      "x": 474,
      "y": 529
    },
    {
      "t": 44201,
      "e": 35212,
      "ty": 2,
      "x": 476,
      "y": 529
    },
    {
      "t": 44251,
      "e": 35262,
      "ty": 41,
      "x": 42705,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44300,
      "e": 35311,
      "ty": 2,
      "x": 477,
      "y": 530
    },
    {
      "t": 44500,
      "e": 35511,
      "ty": 2,
      "x": 479,
      "y": 531
    },
    {
      "t": 44501,
      "e": 35512,
      "ty": 41,
      "x": 42930,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44600,
      "e": 35611,
      "ty": 2,
      "x": 480,
      "y": 533
    },
    {
      "t": 44615,
      "e": 35626,
      "ty": 3,
      "x": 480,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44700,
      "e": 35711,
      "ty": 2,
      "x": 481,
      "y": 534
    },
    {
      "t": 44703,
      "e": 35714,
      "ty": 4,
      "x": 43154,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44703,
      "e": 35714,
      "ty": 5,
      "x": 481,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44751,
      "e": 35762,
      "ty": 41,
      "x": 43154,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44900,
      "e": 35911,
      "ty": 2,
      "x": 484,
      "y": 557
    },
    {
      "t": 45000,
      "e": 36011,
      "ty": 2,
      "x": 489,
      "y": 564
    },
    {
      "t": 45001,
      "e": 36012,
      "ty": 41,
      "x": 44054,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45876,
      "e": 36887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45962,
      "e": 36973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up vetically with 12"
    },
    {
      "t": 47090,
      "e": 38101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47092,
      "e": 38103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47203,
      "e": 38214,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up vertically with 12"
    },
    {
      "t": 47204,
      "e": 38215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up vertically with 12"
    },
    {
      "t": 48467,
      "e": 39478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 48966,
      "e": 39977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 48997,
      "e": 40008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49031,
      "e": 40042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49064,
      "e": 40075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49096,
      "e": 40107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49130,
      "e": 40141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49163,
      "e": 40174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49196,
      "e": 40207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49229,
      "e": 40240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49263,
      "e": 40274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49295,
      "e": 40306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49322,
      "e": 40333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49538,
      "e": 40549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49618,
      "e": 40629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49722,
      "e": 40733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49810,
      "e": 40821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49842,
      "e": 40853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 49978,
      "e": 40989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50000,
      "e": 41011,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50297,
      "e": 41308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50298,
      "e": 41309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50394,
      "e": 41405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50618,
      "e": 41629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50755,
      "e": 41766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50755,
      "e": 41766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50834,
      "e": 41845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 50986,
      "e": 41997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50986,
      "e": 41997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51074,
      "e": 42085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 51218,
      "e": 42229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51700,
      "e": 42711,
      "ty": 2,
      "x": 527,
      "y": 549
    },
    {
      "t": 51751,
      "e": 42762,
      "ty": 41,
      "x": 48438,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51800,
      "e": 42811,
      "ty": 2,
      "x": 518,
      "y": 546
    },
    {
      "t": 51900,
      "e": 42911,
      "ty": 2,
      "x": 357,
      "y": 603
    },
    {
      "t": 51906,
      "e": 42917,
      "ty": 7,
      "x": 355,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52001,
      "e": 43012,
      "ty": 2,
      "x": 367,
      "y": 640
    },
    {
      "t": 52001,
      "e": 43012,
      "ty": 41,
      "x": 22659,
      "y": 11970,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 52091,
      "e": 43102,
      "ty": 6,
      "x": 375,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 52100,
      "e": 43111,
      "ty": 2,
      "x": 375,
      "y": 657
    },
    {
      "t": 52201,
      "e": 43212,
      "ty": 2,
      "x": 384,
      "y": 669
    },
    {
      "t": 52250,
      "e": 43261,
      "ty": 41,
      "x": 27528,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 52300,
      "e": 43311,
      "ty": 2,
      "x": 396,
      "y": 670
    },
    {
      "t": 52391,
      "e": 43402,
      "ty": 3,
      "x": 401,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 52392,
      "e": 43403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the X-axis and find which points line up vertically with 12 PM"
    },
    {
      "t": 52393,
      "e": 43404,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52394,
      "e": 43405,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 52400,
      "e": 43411,
      "ty": 2,
      "x": 401,
      "y": 670
    },
    {
      "t": 52478,
      "e": 43489,
      "ty": 4,
      "x": 34081,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 52488,
      "e": 43499,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 52490,
      "e": 43501,
      "ty": 5,
      "x": 401,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 52496,
      "e": 43507,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 52500,
      "e": 43511,
      "ty": 41,
      "x": 13534,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 53101,
      "e": 44112,
      "ty": 2,
      "x": 523,
      "y": 609
    },
    {
      "t": 53201,
      "e": 44212,
      "ty": 2,
      "x": 757,
      "y": 0
    },
    {
      "t": 53251,
      "e": 44262,
      "ty": 41,
      "x": 26241,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 53301,
      "e": 44312,
      "ty": 2,
      "x": 774,
      "y": 51
    },
    {
      "t": 53401,
      "e": 44412,
      "ty": 2,
      "x": 787,
      "y": 83
    },
    {
      "t": 53496,
      "e": 44507,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 53500,
      "e": 44511,
      "ty": 41,
      "x": 26826,
      "y": 4154,
      "ta": "html > body"
    },
    {
      "t": 53600,
      "e": 44611,
      "ty": 2,
      "x": 766,
      "y": 95
    },
    {
      "t": 53701,
      "e": 44712,
      "ty": 2,
      "x": 765,
      "y": 95
    },
    {
      "t": 53751,
      "e": 44762,
      "ty": 41,
      "x": 26069,
      "y": 4819,
      "ta": "html > body"
    },
    {
      "t": 53801,
      "e": 44812,
      "ty": 2,
      "x": 764,
      "y": 98
    },
    {
      "t": 53901,
      "e": 44912,
      "ty": 2,
      "x": 921,
      "y": 267
    },
    {
      "t": 54009,
      "e": 45020,
      "ty": 2,
      "x": 969,
      "y": 340
    },
    {
      "t": 54010,
      "e": 45021,
      "ty": 41,
      "x": 33094,
      "y": 18391,
      "ta": "html > body"
    },
    {
      "t": 54101,
      "e": 45112,
      "ty": 2,
      "x": 945,
      "y": 376
    },
    {
      "t": 54201,
      "e": 45212,
      "ty": 2,
      "x": 911,
      "y": 451
    },
    {
      "t": 54251,
      "e": 45262,
      "ty": 41,
      "x": 31028,
      "y": 26202,
      "ta": "html > body"
    },
    {
      "t": 54301,
      "e": 45312,
      "ty": 2,
      "x": 909,
      "y": 501
    },
    {
      "t": 54401,
      "e": 45412,
      "ty": 2,
      "x": 904,
      "y": 532
    },
    {
      "t": 54476,
      "e": 45487,
      "ty": 6,
      "x": 897,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54501,
      "e": 45512,
      "ty": 2,
      "x": 897,
      "y": 559
    },
    {
      "t": 54501,
      "e": 45512,
      "ty": 41,
      "x": 19249,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54601,
      "e": 45612,
      "ty": 2,
      "x": 897,
      "y": 560
    },
    {
      "t": 54638,
      "e": 45649,
      "ty": 3,
      "x": 897,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54640,
      "e": 45651,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54710,
      "e": 45721,
      "ty": 4,
      "x": 19249,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54710,
      "e": 45721,
      "ty": 5,
      "x": 897,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54751,
      "e": 45762,
      "ty": 41,
      "x": 19249,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55451,
      "e": 46462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 55451,
      "e": 46462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55538,
      "e": 46549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 56107,
      "e": 47118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 56107,
      "e": 47118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56178,
      "e": 47189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 56750,
      "e": 47761,
      "ty": 41,
      "x": 19898,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56793,
      "e": 47804,
      "ty": 7,
      "x": 920,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56801,
      "e": 47812,
      "ty": 2,
      "x": 920,
      "y": 577
    },
    {
      "t": 56901,
      "e": 47912,
      "ty": 2,
      "x": 932,
      "y": 622
    },
    {
      "t": 56994,
      "e": 48005,
      "ty": 6,
      "x": 937,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57001,
      "e": 48012,
      "ty": 2,
      "x": 937,
      "y": 652
    },
    {
      "t": 57001,
      "e": 48012,
      "ty": 41,
      "x": 27901,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57101,
      "e": 48112,
      "ty": 2,
      "x": 937,
      "y": 659
    },
    {
      "t": 57251,
      "e": 48262,
      "ty": 41,
      "x": 27901,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57407,
      "e": 48418,
      "ty": 3,
      "x": 937,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57408,
      "e": 48419,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 57409,
      "e": 48420,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57409,
      "e": 48420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57510,
      "e": 48521,
      "ty": 4,
      "x": 27901,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57510,
      "e": 48521,
      "ty": 5,
      "x": 937,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58802,
      "e": 49813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 58997,
      "e": 50008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 58998,
      "e": 50009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59093,
      "e": 50104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 59309,
      "e": 50320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 59870,
      "e": 50881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 59870,
      "e": 50881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59948,
      "e": 50959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 60003,
      "e": 51014,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60085,
      "e": 51096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 60085,
      "e": 51096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60164,
      "e": 51175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 60196,
      "e": 51207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 60196,
      "e": 51207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60285,
      "e": 51296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 60462,
      "e": 51473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 60462,
      "e": 51473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60556,
      "e": 51567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 60749,
      "e": 51760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 60750,
      "e": 51761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60845,
      "e": 51856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 60965,
      "e": 51976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 60966,
      "e": 51977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61117,
      "e": 52128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 61197,
      "e": 52208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 61373,
      "e": 52384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 61374,
      "e": 52385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61461,
      "e": 52472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 61501,
      "e": 52512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 61629,
      "e": 52640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 61630,
      "e": 52641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61725,
      "e": 52736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 61821,
      "e": 52832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 61822,
      "e": 52833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61902,
      "e": 52913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 61933,
      "e": 52944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 61934,
      "e": 52945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62021,
      "e": 53032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 62501,
      "e": 53512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 62502,
      "e": 53513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62548,
      "e": 53559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 62933,
      "e": 53944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 62989,
      "e": 54000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Sate"
    },
    {
      "t": 63077,
      "e": 54088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 63145,
      "e": 54156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Sat"
    },
    {
      "t": 63220,
      "e": 54231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 63285,
      "e": 54296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Sa"
    },
    {
      "t": 63381,
      "e": 54392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 63421,
      "e": 54432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United S"
    },
    {
      "t": 63966,
      "e": 54977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 63966,
      "e": 54977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64069,
      "e": 55080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 64182,
      "e": 55193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 64182,
      "e": 55193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64285,
      "e": 55296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 64285,
      "e": 55296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64293,
      "e": 55304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 64366,
      "e": 55377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 64389,
      "e": 55400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 64389,
      "e": 55400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64484,
      "e": 55495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 64590,
      "e": 55601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 64590,
      "e": 55601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64701,
      "e": 55712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 65370,
      "e": 56381,
      "ty": 7,
      "x": 935,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65371,
      "e": 56382,
      "ty": 6,
      "x": 935,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65403,
      "e": 56414,
      "ty": 2,
      "x": 932,
      "y": 695
    },
    {
      "t": 65420,
      "e": 56431,
      "ty": 7,
      "x": 933,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65503,
      "e": 56514,
      "ty": 2,
      "x": 938,
      "y": 722
    },
    {
      "t": 65503,
      "e": 56514,
      "ty": 41,
      "x": 32027,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 65603,
      "e": 56614,
      "ty": 2,
      "x": 942,
      "y": 722
    },
    {
      "t": 65704,
      "e": 56715,
      "ty": 2,
      "x": 950,
      "y": 717
    },
    {
      "t": 65753,
      "e": 56764,
      "ty": 41,
      "x": 32646,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 65754,
      "e": 56765,
      "ty": 6,
      "x": 957,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65803,
      "e": 56814,
      "ty": 2,
      "x": 961,
      "y": 703
    },
    {
      "t": 65903,
      "e": 56914,
      "ty": 2,
      "x": 963,
      "y": 700
    },
    {
      "t": 66003,
      "e": 57014,
      "ty": 2,
      "x": 964,
      "y": 700
    },
    {
      "t": 66004,
      "e": 57015,
      "ty": 41,
      "x": 35086,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66115,
      "e": 57126,
      "ty": 3,
      "x": 964,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66115,
      "e": 57126,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 66116,
      "e": 57127,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66117,
      "e": 57128,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66153,
      "e": 57164,
      "ty": 4,
      "x": 35086,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66155,
      "e": 57166,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66157,
      "e": 57168,
      "ty": 5,
      "x": 964,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66158,
      "e": 57169,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 66504,
      "e": 57515,
      "ty": 2,
      "x": 1015,
      "y": 699
    },
    {
      "t": 66504,
      "e": 57515,
      "ty": 41,
      "x": 34678,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 66603,
      "e": 57614,
      "ty": 2,
      "x": 1919,
      "y": 937
    },
    {
      "t": 66703,
      "e": 57714,
      "ty": 2,
      "x": 1919,
      "y": 979
    },
    {
      "t": 66803,
      "e": 57814,
      "ty": 2,
      "x": 1849,
      "y": 995
    },
    {
      "t": 66903,
      "e": 57914,
      "ty": 2,
      "x": 1460,
      "y": 1052
    },
    {
      "t": 67003,
      "e": 58014,
      "ty": 2,
      "x": 1456,
      "y": 1053
    },
    {
      "t": 67004,
      "e": 58015,
      "ty": 41,
      "x": 49865,
      "y": 57890,
      "ta": "html > body"
    },
    {
      "t": 67103,
      "e": 58114,
      "ty": 2,
      "x": 1350,
      "y": 1068
    },
    {
      "t": 67173,
      "e": 58184,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 67203,
      "e": 58214,
      "ty": 2,
      "x": 1002,
      "y": 1131
    },
    {
      "t": 67254,
      "e": 58265,
      "ty": 41,
      "x": 34231,
      "y": 62211,
      "ta": "html > body"
    },
    {
      "t": 67303,
      "e": 58314,
      "ty": 2,
      "x": 1016,
      "y": 1122
    },
    {
      "t": 67403,
      "e": 58414,
      "ty": 2,
      "x": 1063,
      "y": 1080
    },
    {
      "t": 67504,
      "e": 58515,
      "ty": 2,
      "x": 1111,
      "y": 1040
    },
    {
      "t": 67504,
      "e": 58515,
      "ty": 41,
      "x": 37984,
      "y": 57170,
      "ta": "html > body"
    },
    {
      "t": 67604,
      "e": 58615,
      "ty": 2,
      "x": 1139,
      "y": 966
    },
    {
      "t": 67704,
      "e": 58715,
      "ty": 2,
      "x": 1134,
      "y": 877
    },
    {
      "t": 67753,
      "e": 58764,
      "ty": 41,
      "x": 62790,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 67803,
      "e": 58814,
      "ty": 2,
      "x": 1058,
      "y": 770
    },
    {
      "t": 67904,
      "e": 58915,
      "ty": 2,
      "x": 836,
      "y": 710
    },
    {
      "t": 68004,
      "e": 59015,
      "ty": 2,
      "x": 826,
      "y": 695
    },
    {
      "t": 68004,
      "e": 59015,
      "ty": 41,
      "x": 1153,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 68103,
      "e": 59114,
      "ty": 2,
      "x": 957,
      "y": 515
    },
    {
      "t": 68204,
      "e": 59215,
      "ty": 2,
      "x": 964,
      "y": 0
    },
    {
      "t": 68254,
      "e": 59265,
      "ty": 41,
      "x": 30477,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 68303,
      "e": 59314,
      "ty": 2,
      "x": 880,
      "y": 5
    },
    {
      "t": 68404,
      "e": 59415,
      "ty": 2,
      "x": 839,
      "y": 98
    },
    {
      "t": 68503,
      "e": 59514,
      "ty": 2,
      "x": 862,
      "y": 179
    },
    {
      "t": 68503,
      "e": 59514,
      "ty": 41,
      "x": 9630,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 68604,
      "e": 59615,
      "ty": 2,
      "x": 863,
      "y": 241
    },
    {
      "t": 68703,
      "e": 59714,
      "ty": 2,
      "x": 860,
      "y": 246
    },
    {
      "t": 68755,
      "e": 59715,
      "ty": 41,
      "x": 31590,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69004,
      "e": 59964,
      "ty": 2,
      "x": 859,
      "y": 241
    },
    {
      "t": 69004,
      "e": 59964,
      "ty": 41,
      "x": 30771,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69034,
      "e": 59994,
      "ty": 3,
      "x": 859,
      "y": 241,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69105,
      "e": 60065,
      "ty": 4,
      "x": 30771,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69105,
      "e": 60065,
      "ty": 5,
      "x": 859,
      "y": 241,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69106,
      "e": 60066,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69106,
      "e": 60066,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 69403,
      "e": 60363,
      "ty": 2,
      "x": 853,
      "y": 240
    },
    {
      "t": 69504,
      "e": 60464,
      "ty": 2,
      "x": 851,
      "y": 240
    },
    {
      "t": 69504,
      "e": 60464,
      "ty": 41,
      "x": 24220,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69704,
      "e": 60664,
      "ty": 2,
      "x": 851,
      "y": 248
    },
    {
      "t": 69754,
      "e": 60714,
      "ty": 41,
      "x": 35319,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 69804,
      "e": 60764,
      "ty": 2,
      "x": 870,
      "y": 361
    },
    {
      "t": 69904,
      "e": 60864,
      "ty": 2,
      "x": 876,
      "y": 374
    },
    {
      "t": 70003,
      "e": 60963,
      "ty": 2,
      "x": 879,
      "y": 381
    },
    {
      "t": 70004,
      "e": 60964,
      "ty": 41,
      "x": 13664,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 70403,
      "e": 61363,
      "ty": 2,
      "x": 879,
      "y": 385
    },
    {
      "t": 70503,
      "e": 61463,
      "ty": 2,
      "x": 860,
      "y": 409
    },
    {
      "t": 70504,
      "e": 61464,
      "ty": 41,
      "x": 45159,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 70604,
      "e": 61564,
      "ty": 2,
      "x": 860,
      "y": 414
    },
    {
      "t": 70704,
      "e": 61664,
      "ty": 2,
      "x": 860,
      "y": 415
    },
    {
      "t": 70753,
      "e": 61713,
      "ty": 41,
      "x": 45159,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 70937,
      "e": 61897,
      "ty": 3,
      "x": 860,
      "y": 415,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 70939,
      "e": 61899,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71000,
      "e": 61960,
      "ty": 4,
      "x": 45159,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71001,
      "e": 61961,
      "ty": 5,
      "x": 860,
      "y": 415,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71001,
      "e": 61961,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 71001,
      "e": 61961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 71503,
      "e": 62463,
      "ty": 2,
      "x": 862,
      "y": 432
    },
    {
      "t": 71504,
      "e": 62464,
      "ty": 41,
      "x": 9630,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 71604,
      "e": 62564,
      "ty": 2,
      "x": 895,
      "y": 490
    },
    {
      "t": 71703,
      "e": 62663,
      "ty": 2,
      "x": 896,
      "y": 500
    },
    {
      "t": 71754,
      "e": 62714,
      "ty": 41,
      "x": 17699,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 71804,
      "e": 62764,
      "ty": 2,
      "x": 896,
      "y": 508
    },
    {
      "t": 71904,
      "e": 62864,
      "ty": 2,
      "x": 904,
      "y": 558
    },
    {
      "t": 72004,
      "e": 62964,
      "ty": 2,
      "x": 918,
      "y": 580
    },
    {
      "t": 72004,
      "e": 62964,
      "ty": 41,
      "x": 22920,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 72104,
      "e": 63064,
      "ty": 2,
      "x": 919,
      "y": 582
    },
    {
      "t": 72254,
      "e": 63214,
      "ty": 41,
      "x": 23157,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 72504,
      "e": 63464,
      "ty": 2,
      "x": 920,
      "y": 588
    },
    {
      "t": 72504,
      "e": 63464,
      "ty": 41,
      "x": 23395,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 72604,
      "e": 63564,
      "ty": 2,
      "x": 922,
      "y": 593
    },
    {
      "t": 72753,
      "e": 63713,
      "ty": 41,
      "x": 23869,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 73004,
      "e": 63964,
      "ty": 2,
      "x": 922,
      "y": 595
    },
    {
      "t": 73004,
      "e": 63964,
      "ty": 41,
      "x": 23869,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 73103,
      "e": 64063,
      "ty": 2,
      "x": 927,
      "y": 617
    },
    {
      "t": 73204,
      "e": 64164,
      "ty": 2,
      "x": 927,
      "y": 618
    },
    {
      "t": 73254,
      "e": 64214,
      "ty": 41,
      "x": 25056,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 73403,
      "e": 64363,
      "ty": 2,
      "x": 930,
      "y": 619
    },
    {
      "t": 73503,
      "e": 64463,
      "ty": 2,
      "x": 930,
      "y": 612
    },
    {
      "t": 73504,
      "e": 64464,
      "ty": 41,
      "x": 25768,
      "y": 33701,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 73603,
      "e": 64563,
      "ty": 2,
      "x": 930,
      "y": 610
    },
    {
      "t": 73754,
      "e": 64563,
      "ty": 41,
      "x": 25768,
      "y": 33552,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74003,
      "e": 64812,
      "ty": 2,
      "x": 930,
      "y": 607
    },
    {
      "t": 74004,
      "e": 64813,
      "ty": 41,
      "x": 25768,
      "y": 33327,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74104,
      "e": 64913,
      "ty": 2,
      "x": 867,
      "y": 577
    },
    {
      "t": 74204,
      "e": 65013,
      "ty": 2,
      "x": 855,
      "y": 568
    },
    {
      "t": 74254,
      "e": 65063,
      "ty": 41,
      "x": 7968,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 74404,
      "e": 65213,
      "ty": 2,
      "x": 844,
      "y": 568
    },
    {
      "t": 74503,
      "e": 65312,
      "ty": 2,
      "x": 864,
      "y": 600
    },
    {
      "t": 74503,
      "e": 65312,
      "ty": 41,
      "x": 10104,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74604,
      "e": 65413,
      "ty": 2,
      "x": 973,
      "y": 741
    },
    {
      "t": 74703,
      "e": 65512,
      "ty": 2,
      "x": 976,
      "y": 743
    },
    {
      "t": 74754,
      "e": 65563,
      "ty": 41,
      "x": 37397,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 74804,
      "e": 65613,
      "ty": 2,
      "x": 982,
      "y": 745
    },
    {
      "t": 75004,
      "e": 65813,
      "ty": 41,
      "x": 38109,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 75204,
      "e": 66013,
      "ty": 2,
      "x": 983,
      "y": 745
    },
    {
      "t": 75254,
      "e": 66063,
      "ty": 41,
      "x": 38109,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 75304,
      "e": 66113,
      "ty": 2,
      "x": 971,
      "y": 753
    },
    {
      "t": 75403,
      "e": 66212,
      "ty": 2,
      "x": 950,
      "y": 755
    },
    {
      "t": 75504,
      "e": 66313,
      "ty": 2,
      "x": 939,
      "y": 755
    },
    {
      "t": 75505,
      "e": 66314,
      "ty": 41,
      "x": 49059,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 75603,
      "e": 66412,
      "ty": 2,
      "x": 848,
      "y": 717
    },
    {
      "t": 75704,
      "e": 66513,
      "ty": 2,
      "x": 843,
      "y": 714
    },
    {
      "t": 75753,
      "e": 66562,
      "ty": 41,
      "x": 5121,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 75804,
      "e": 66613,
      "ty": 2,
      "x": 846,
      "y": 713
    },
    {
      "t": 75904,
      "e": 66713,
      "ty": 2,
      "x": 848,
      "y": 712
    },
    {
      "t": 76004,
      "e": 66813,
      "ty": 41,
      "x": 6697,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 76104,
      "e": 66913,
      "ty": 2,
      "x": 849,
      "y": 707
    },
    {
      "t": 76138,
      "e": 66947,
      "ty": 3,
      "x": 849,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 76139,
      "e": 66948,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 76200,
      "e": 67009,
      "ty": 4,
      "x": 6949,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 76200,
      "e": 67009,
      "ty": 5,
      "x": 849,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 76200,
      "e": 67009,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76201,
      "e": 67010,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 76254,
      "e": 67063,
      "ty": 41,
      "x": 6949,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 76304,
      "e": 67113,
      "ty": 2,
      "x": 853,
      "y": 709
    },
    {
      "t": 76404,
      "e": 67213,
      "ty": 2,
      "x": 995,
      "y": 841
    },
    {
      "t": 76504,
      "e": 67313,
      "ty": 2,
      "x": 1012,
      "y": 841
    },
    {
      "t": 76505,
      "e": 67314,
      "ty": 41,
      "x": 45228,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 76604,
      "e": 67413,
      "ty": 2,
      "x": 1106,
      "y": 833
    },
    {
      "t": 76704,
      "e": 67513,
      "ty": 2,
      "x": 1148,
      "y": 789
    },
    {
      "t": 76754,
      "e": 67563,
      "ty": 41,
      "x": 40257,
      "y": 41270,
      "ta": "html > body"
    },
    {
      "t": 76804,
      "e": 67613,
      "ty": 2,
      "x": 1215,
      "y": 706
    },
    {
      "t": 76904,
      "e": 67713,
      "ty": 2,
      "x": 1222,
      "y": 696
    },
    {
      "t": 77004,
      "e": 67813,
      "ty": 2,
      "x": 1155,
      "y": 760
    },
    {
      "t": 77004,
      "e": 67813,
      "ty": 41,
      "x": 39500,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 77103,
      "e": 67912,
      "ty": 2,
      "x": 1006,
      "y": 930
    },
    {
      "t": 77204,
      "e": 68013,
      "ty": 2,
      "x": 1002,
      "y": 937
    },
    {
      "t": 77254,
      "e": 68063,
      "ty": 41,
      "x": 41194,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 77304,
      "e": 68113,
      "ty": 2,
      "x": 947,
      "y": 924
    },
    {
      "t": 77404,
      "e": 68213,
      "ty": 2,
      "x": 832,
      "y": 919
    },
    {
      "t": 77504,
      "e": 68313,
      "ty": 2,
      "x": 820,
      "y": 918
    },
    {
      "t": 77505,
      "e": 68314,
      "ty": 41,
      "x": 27963,
      "y": 50411,
      "ta": "html > body"
    },
    {
      "t": 77704,
      "e": 68513,
      "ty": 2,
      "x": 828,
      "y": 927
    },
    {
      "t": 77714,
      "e": 68523,
      "ty": 6,
      "x": 831,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77755,
      "e": 68564,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77804,
      "e": 68613,
      "ty": 2,
      "x": 832,
      "y": 929
    },
    {
      "t": 77865,
      "e": 68674,
      "ty": 3,
      "x": 834,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77865,
      "e": 68674,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77865,
      "e": 68674,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77904,
      "e": 68713,
      "ty": 2,
      "x": 834,
      "y": 930
    },
    {
      "t": 77937,
      "e": 68746,
      "ty": 4,
      "x": 38202,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77937,
      "e": 68746,
      "ty": 5,
      "x": 834,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77938,
      "e": 68747,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 78001,
      "e": 68810,
      "ty": 7,
      "x": 840,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78003,
      "e": 68812,
      "ty": 2,
      "x": 840,
      "y": 933
    },
    {
      "t": 78003,
      "e": 68812,
      "ty": 41,
      "x": 20291,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 78065,
      "e": 68813,
      "ty": 6,
      "x": 928,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78080,
      "e": 68828,
      "ty": 7,
      "x": 979,
      "y": 1053,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78104,
      "e": 68852,
      "ty": 2,
      "x": 1007,
      "y": 1075
    },
    {
      "t": 78203,
      "e": 68951,
      "ty": 2,
      "x": 1014,
      "y": 1082
    },
    {
      "t": 78254,
      "e": 69002,
      "ty": 41,
      "x": 34575,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 78304,
      "e": 69052,
      "ty": 2,
      "x": 1003,
      "y": 1078
    },
    {
      "t": 78404,
      "e": 69152,
      "ty": 2,
      "x": 976,
      "y": 1056
    },
    {
      "t": 78499,
      "e": 69247,
      "ty": 6,
      "x": 938,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78504,
      "e": 69252,
      "ty": 2,
      "x": 938,
      "y": 1037
    },
    {
      "t": 78504,
      "e": 69252,
      "ty": 41,
      "x": 55960,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78604,
      "e": 69352,
      "ty": 2,
      "x": 908,
      "y": 1028
    },
    {
      "t": 78689,
      "e": 69437,
      "ty": 3,
      "x": 908,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78690,
      "e": 69438,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78691,
      "e": 69439,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78744,
      "e": 69492,
      "ty": 4,
      "x": 40498,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78745,
      "e": 69493,
      "ty": 5,
      "x": 908,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78747,
      "e": 69495,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78748,
      "e": 69496,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 78748,
      "e": 69496,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 78754,
      "e": 69502,
      "ty": 41,
      "x": 30993,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 78804,
      "e": 69552,
      "ty": 2,
      "x": 908,
      "y": 1027
    },
    {
      "t": 78904,
      "e": 69652,
      "ty": 2,
      "x": 1126,
      "y": 1113
    },
    {
      "t": 79003,
      "e": 69751,
      "ty": 2,
      "x": 1760,
      "y": 1199
    },
    {
      "t": 79104,
      "e": 69852,
      "ty": 2,
      "x": 1863,
      "y": 1130
    },
    {
      "t": 79204,
      "e": 69952,
      "ty": 2,
      "x": 1625,
      "y": 790
    },
    {
      "t": 79254,
      "e": 70002,
      "ty": 41,
      "x": 45939,
      "y": 32518,
      "ta": "html > body"
    },
    {
      "t": 79304,
      "e": 70052,
      "ty": 2,
      "x": 1107,
      "y": 524
    },
    {
      "t": 79404,
      "e": 70152,
      "ty": 2,
      "x": 979,
      "y": 547
    },
    {
      "t": 79504,
      "e": 70252,
      "ty": 41,
      "x": 33439,
      "y": 29859,
      "ta": "html > body"
    },
    {
      "t": 80082,
      "e": 70830,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 80104,
      "e": 70852,
      "ty": 2,
      "x": 982,
      "y": 549
    },
    {
      "t": 80204,
      "e": 70952,
      "ty": 2,
      "x": 989,
      "y": 551
    },
    {
      "t": 80254,
      "e": 71002,
      "ty": 41,
      "x": 34218,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80404,
      "e": 71152,
      "ty": 2,
      "x": 990,
      "y": 552
    },
    {
      "t": 80504,
      "e": 71252,
      "ty": 41,
      "x": 34268,
      "y": 27117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80904,
      "e": 71652,
      "ty": 2,
      "x": 991,
      "y": 553
    },
    {
      "t": 81005,
      "e": 71753,
      "ty": 41,
      "x": 34317,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81254,
      "e": 72002,
      "ty": 41,
      "x": 34169,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81304,
      "e": 72052,
      "ty": 2,
      "x": 986,
      "y": 553
    },
    {
      "t": 81404,
      "e": 72152,
      "ty": 2,
      "x": 983,
      "y": 553
    },
    {
      "t": 81504,
      "e": 72252,
      "ty": 2,
      "x": 982,
      "y": 554
    },
    {
      "t": 81504,
      "e": 72252,
      "ty": 41,
      "x": 33874,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81604,
      "e": 72352,
      "ty": 2,
      "x": 981,
      "y": 554
    },
    {
      "t": 81704,
      "e": 72452,
      "ty": 2,
      "x": 979,
      "y": 554
    },
    {
      "t": 81755,
      "e": 72503,
      "ty": 41,
      "x": 33726,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82604,
      "e": 73352,
      "ty": 2,
      "x": 980,
      "y": 554
    },
    {
      "t": 82755,
      "e": 73503,
      "ty": 41,
      "x": 33776,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82804,
      "e": 73552,
      "ty": 2,
      "x": 977,
      "y": 557
    },
    {
      "t": 83005,
      "e": 73753,
      "ty": 41,
      "x": 33628,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83204,
      "e": 73952,
      "ty": 2,
      "x": 976,
      "y": 557
    },
    {
      "t": 83254,
      "e": 74002,
      "ty": 41,
      "x": 33579,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83604,
      "e": 74352,
      "ty": 2,
      "x": 976,
      "y": 558
    },
    {
      "t": 83755,
      "e": 74503,
      "ty": 41,
      "x": 33579,
      "y": 29457,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84604,
      "e": 75352,
      "ty": 2,
      "x": 984,
      "y": 557
    },
    {
      "t": 84755,
      "e": 75503,
      "ty": 41,
      "x": 33972,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85204,
      "e": 75952,
      "ty": 2,
      "x": 1011,
      "y": 587
    },
    {
      "t": 85255,
      "e": 76003,
      "ty": 41,
      "x": 39482,
      "y": 9663,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85305,
      "e": 76053,
      "ty": 2,
      "x": 1225,
      "y": 783
    },
    {
      "t": 85404,
      "e": 76152,
      "ty": 2,
      "x": 1299,
      "y": 816
    },
    {
      "t": 85505,
      "e": 76253,
      "ty": 41,
      "x": 49469,
      "y": 20497,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 85904,
      "e": 76652,
      "ty": 2,
      "x": 1300,
      "y": 851
    },
    {
      "t": 86003,
      "e": 76751,
      "ty": 2,
      "x": 1274,
      "y": 879
    },
    {
      "t": 86003,
      "e": 76751,
      "ty": 41,
      "x": 48239,
      "y": 15250,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 86104,
      "e": 76852,
      "ty": 2,
      "x": 1193,
      "y": 918
    },
    {
      "t": 86204,
      "e": 76952,
      "ty": 2,
      "x": 1094,
      "y": 949
    },
    {
      "t": 86255,
      "e": 77003,
      "ty": 41,
      "x": 39138,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86303,
      "e": 77051,
      "ty": 2,
      "x": 1086,
      "y": 968
    },
    {
      "t": 86404,
      "e": 77152,
      "ty": 2,
      "x": 1085,
      "y": 972
    },
    {
      "t": 86503,
      "e": 77251,
      "ty": 2,
      "x": 1049,
      "y": 1013
    },
    {
      "t": 86503,
      "e": 77251,
      "ty": 41,
      "x": 37170,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86603,
      "e": 77351,
      "ty": 2,
      "x": 1036,
      "y": 1052
    },
    {
      "t": 86655,
      "e": 77403,
      "ty": 6,
      "x": 1029,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 86688,
      "e": 77436,
      "ty": 7,
      "x": 1021,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 86703,
      "e": 77451,
      "ty": 2,
      "x": 1021,
      "y": 1109
    },
    {
      "t": 86753,
      "e": 77501,
      "ty": 41,
      "x": 58747,
      "y": 27318,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 86803,
      "e": 77551,
      "ty": 2,
      "x": 1014,
      "y": 1123
    },
    {
      "t": 86903,
      "e": 77651,
      "ty": 2,
      "x": 1013,
      "y": 1119
    },
    {
      "t": 86987,
      "e": 77735,
      "ty": 6,
      "x": 1009,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 87003,
      "e": 77751,
      "ty": 2,
      "x": 1009,
      "y": 1106
    },
    {
      "t": 87004,
      "e": 77752,
      "ty": 41,
      "x": 54339,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 87103,
      "e": 77851,
      "ty": 2,
      "x": 1009,
      "y": 1103
    },
    {
      "t": 87253,
      "e": 78001,
      "ty": 41,
      "x": 54339,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 90003,
      "e": 80751,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 91004,
      "e": 81752,
      "ty": 2,
      "x": 1018,
      "y": 1077
    },
    {
      "t": 91004,
      "e": 81752,
      "ty": 41,
      "x": 59254,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 91104,
      "e": 81852,
      "ty": 2,
      "x": 1018,
      "y": 1073
    },
    {
      "t": 91253,
      "e": 82001,
      "ty": 41,
      "x": 54885,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 91303,
      "e": 82051,
      "ty": 2,
      "x": 1003,
      "y": 1077
    },
    {
      "t": 91403,
      "e": 82151,
      "ty": 2,
      "x": 997,
      "y": 1079
    },
    {
      "t": 91503,
      "e": 82251,
      "ty": 2,
      "x": 996,
      "y": 1080
    },
    {
      "t": 91504,
      "e": 82252,
      "ty": 41,
      "x": 47239,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 97003,
      "e": 87252,
      "ty": 2,
      "x": 987,
      "y": 1083
    },
    {
      "t": 97004,
      "e": 87253,
      "ty": 41,
      "x": 42324,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 98322,
      "e": 88571,
      "ty": 3,
      "x": 987,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 98323,
      "e": 88572,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98400,
      "e": 88649,
      "ty": 4,
      "x": 42324,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 98401,
      "e": 88650,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98401,
      "e": 88650,
      "ty": 5,
      "x": 987,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 98401,
      "e": 88650,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 98704,
      "e": 88953,
      "ty": 2,
      "x": 1050,
      "y": 1189
    },
    {
      "t": 98803,
      "e": 89052,
      "ty": 2,
      "x": 1367,
      "y": 1199
    },
    {
      "t": 98904,
      "e": 89153,
      "ty": 2,
      "x": 1591,
      "y": 1095
    },
    {
      "t": 99004,
      "e": 89253,
      "ty": 2,
      "x": 1562,
      "y": 845
    },
    {
      "t": 99004,
      "e": 89253,
      "ty": 41,
      "x": 53516,
      "y": 46367,
      "ta": "html > body"
    },
    {
      "t": 99104,
      "e": 89353,
      "ty": 2,
      "x": 1453,
      "y": 726
    },
    {
      "t": 99204,
      "e": 89453,
      "ty": 2,
      "x": 1408,
      "y": 692
    },
    {
      "t": 99253,
      "e": 89502,
      "ty": 41,
      "x": 46559,
      "y": 36229,
      "ta": "html > body"
    },
    {
      "t": 99303,
      "e": 89552,
      "ty": 2,
      "x": 1295,
      "y": 634
    },
    {
      "t": 99441,
      "e": 89690,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 100111,
      "e": 90360,
      "ty": 2,
      "x": 856,
      "y": 823
    },
    {
      "t": 100111,
      "e": 90360,
      "ty": 41,
      "x": 26702,
      "y": 32825,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 100165,
      "e": 90414,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100403,
      "e": 90652,
      "ty": 2,
      "x": 857,
      "y": 823
    },
    {
      "t": 100504,
      "e": 90753,
      "ty": 2,
      "x": 876,
      "y": 821
    },
    {
      "t": 100504,
      "e": 90753,
      "ty": 41,
      "x": 27874,
      "y": 32824,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 100604,
      "e": 90853,
      "ty": 2,
      "x": 888,
      "y": 818
    },
    {
      "t": 100699,
      "e": 90948,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 64795, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 64798, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 37744, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 103876, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9710, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"india\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 114593, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 20753, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 136430, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8009, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 145442, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 28904, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 175707, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:647,y:59,t:1527026813326};\\\", \\\"{x:685,y:29,t:1527026813354};\\\", \\\"{x:696,y:19,t:1527026813357};\\\", \\\"{x:730,y:0,t:1527026813569};\\\", \\\"{x:698,y:0,t:1527026813677};\\\", \\\"{x:688,y:1,t:1527026813692};\\\", \\\"{x:676,y:7,t:1527026813708};\\\", \\\"{x:664,y:12,t:1527026813725};\\\", \\\"{x:656,y:18,t:1527026813742};\\\", \\\"{x:646,y:25,t:1527026813758};\\\", \\\"{x:638,y:30,t:1527026813774};\\\", \\\"{x:633,y:37,t:1527026813792};\\\", \\\"{x:628,y:48,t:1527026813808};\\\", \\\"{x:621,y:69,t:1527026813824};\\\", \\\"{x:617,y:92,t:1527026813842};\\\", \\\"{x:612,y:122,t:1527026813858};\\\", \\\"{x:610,y:159,t:1527026813875};\\\", \\\"{x:607,y:216,t:1527026813892};\\\", \\\"{x:607,y:247,t:1527026813909};\\\", \\\"{x:609,y:285,t:1527026813926};\\\", \\\"{x:614,y:327,t:1527026813941};\\\", \\\"{x:619,y:354,t:1527026813958};\\\", \\\"{x:620,y:379,t:1527026813975};\\\", \\\"{x:620,y:394,t:1527026813992};\\\", \\\"{x:620,y:408,t:1527026814009};\\\", \\\"{x:620,y:418,t:1527026814024};\\\", \\\"{x:619,y:422,t:1527026814041};\\\", \\\"{x:619,y:428,t:1527026814059};\\\", \\\"{x:619,y:434,t:1527026814075};\\\", \\\"{x:621,y:446,t:1527026814091};\\\", \\\"{x:624,y:452,t:1527026814108};\\\", \\\"{x:625,y:457,t:1527026814125};\\\", \\\"{x:628,y:462,t:1527026814142};\\\", \\\"{x:629,y:470,t:1527026814159};\\\", \\\"{x:634,y:479,t:1527026814174};\\\", \\\"{x:639,y:493,t:1527026814192};\\\", \\\"{x:644,y:506,t:1527026814210};\\\", \\\"{x:649,y:518,t:1527026814225};\\\", \\\"{x:652,y:528,t:1527026814242};\\\", \\\"{x:654,y:537,t:1527026814260};\\\", \\\"{x:656,y:543,t:1527026814275};\\\", \\\"{x:657,y:544,t:1527026814293};\\\", \\\"{x:657,y:545,t:1527026814309};\\\", \\\"{x:658,y:545,t:1527026814340};\\\", \\\"{x:659,y:546,t:1527026814356};\\\", \\\"{x:660,y:547,t:1527026814389};\\\", \\\"{x:661,y:547,t:1527026814397};\\\", \\\"{x:663,y:549,t:1527026814409};\\\", \\\"{x:669,y:552,t:1527026814426};\\\", \\\"{x:671,y:553,t:1527026814441};\\\", \\\"{x:675,y:555,t:1527026814459};\\\", \\\"{x:678,y:555,t:1527026814476};\\\", \\\"{x:680,y:555,t:1527026814492};\\\", \\\"{x:684,y:555,t:1527026814509};\\\", \\\"{x:692,y:551,t:1527026814526};\\\", \\\"{x:701,y:550,t:1527026814542};\\\", \\\"{x:709,y:546,t:1527026814559};\\\", \\\"{x:716,y:544,t:1527026814576};\\\", \\\"{x:727,y:542,t:1527026814593};\\\", \\\"{x:739,y:539,t:1527026814608};\\\", \\\"{x:749,y:536,t:1527026814626};\\\", \\\"{x:759,y:531,t:1527026814642};\\\", \\\"{x:767,y:525,t:1527026814659};\\\", \\\"{x:772,y:519,t:1527026814675};\\\", \\\"{x:772,y:516,t:1527026814692};\\\", \\\"{x:774,y:512,t:1527026814708};\\\", \\\"{x:774,y:505,t:1527026814727};\\\", \\\"{x:774,y:497,t:1527026814743};\\\", \\\"{x:769,y:486,t:1527026814759};\\\", \\\"{x:765,y:474,t:1527026814776};\\\", \\\"{x:763,y:469,t:1527026814793};\\\", \\\"{x:761,y:466,t:1527026814810};\\\", \\\"{x:761,y:465,t:1527026814826};\\\", \\\"{x:760,y:465,t:1527026814844};\\\", \\\"{x:760,y:464,t:1527026814860};\\\", \\\"{x:757,y:461,t:1527026814876};\\\", \\\"{x:754,y:459,t:1527026814893};\\\", \\\"{x:750,y:454,t:1527026814911};\\\", \\\"{x:746,y:451,t:1527026814926};\\\", \\\"{x:742,y:448,t:1527026814943};\\\", \\\"{x:738,y:445,t:1527026814961};\\\", \\\"{x:735,y:442,t:1527026814977};\\\", \\\"{x:734,y:441,t:1527026814993};\\\", \\\"{x:733,y:439,t:1527026815010};\\\", \\\"{x:732,y:439,t:1527026815140};\\\", \\\"{x:732,y:438,t:1527026815148};\\\", \\\"{x:730,y:437,t:1527026815164};\\\", \\\"{x:728,y:436,t:1527026815236};\\\", \\\"{x:727,y:436,t:1527026815251};\\\", \\\"{x:726,y:436,t:1527026815268};\\\", \\\"{x:724,y:436,t:1527026815291};\\\", \\\"{x:723,y:436,t:1527026815308};\\\", \\\"{x:722,y:436,t:1527026815316};\\\", \\\"{x:721,y:436,t:1527026815327};\\\", \\\"{x:720,y:436,t:1527026815344};\\\", \\\"{x:719,y:436,t:1527026815361};\\\", \\\"{x:718,y:436,t:1527026815378};\\\", \\\"{x:717,y:436,t:1527026815394};\\\", \\\"{x:715,y:436,t:1527026815411};\\\", \\\"{x:714,y:436,t:1527026815429};\\\", \\\"{x:712,y:437,t:1527026815444};\\\", \\\"{x:711,y:437,t:1527026815461};\\\", \\\"{x:710,y:437,t:1527026815478};\\\", \\\"{x:707,y:438,t:1527026815494};\\\", \\\"{x:705,y:438,t:1527026815511};\\\", \\\"{x:703,y:439,t:1527026815528};\\\", \\\"{x:702,y:439,t:1527026815545};\\\", \\\"{x:701,y:440,t:1527026815561};\\\", \\\"{x:699,y:440,t:1527026815578};\\\", \\\"{x:697,y:440,t:1527026815597};\\\", \\\"{x:696,y:441,t:1527026815611};\\\", \\\"{x:691,y:443,t:1527026815628};\\\", \\\"{x:689,y:443,t:1527026816381};\\\", \\\"{x:687,y:444,t:1527026816397};\\\", \\\"{x:686,y:444,t:1527026816414};\\\", \\\"{x:684,y:444,t:1527026816433};\\\", \\\"{x:682,y:445,t:1527026816447};\\\", \\\"{x:681,y:446,t:1527026816463};\\\", \\\"{x:678,y:446,t:1527026816480};\\\", \\\"{x:676,y:446,t:1527026816497};\\\", \\\"{x:675,y:446,t:1527026816514};\\\", \\\"{x:673,y:446,t:1527026816530};\\\", \\\"{x:669,y:446,t:1527026816547};\\\", \\\"{x:661,y:447,t:1527026816564};\\\", \\\"{x:654,y:447,t:1527026816580};\\\", \\\"{x:649,y:447,t:1527026816597};\\\", \\\"{x:644,y:448,t:1527026816614};\\\", \\\"{x:640,y:450,t:1527026816630};\\\", \\\"{x:638,y:450,t:1527026816647};\\\", \\\"{x:635,y:450,t:1527026816664};\\\", \\\"{x:633,y:450,t:1527026816681};\\\", \\\"{x:632,y:450,t:1527026816698};\\\", \\\"{x:631,y:450,t:1527026816715};\\\", \\\"{x:631,y:451,t:1527026816731};\\\", \\\"{x:630,y:451,t:1527026816869};\\\", \\\"{x:632,y:450,t:1527026817781};\\\", \\\"{x:635,y:450,t:1527026817789};\\\", \\\"{x:637,y:450,t:1527026817800};\\\", \\\"{x:647,y:450,t:1527026817818};\\\", \\\"{x:657,y:450,t:1527026817833};\\\", \\\"{x:673,y:450,t:1527026817851};\\\", \\\"{x:693,y:453,t:1527026817867};\\\", \\\"{x:720,y:462,t:1527026817884};\\\", \\\"{x:766,y:478,t:1527026817901};\\\", \\\"{x:793,y:487,t:1527026817917};\\\", \\\"{x:835,y:501,t:1527026817935};\\\", \\\"{x:874,y:511,t:1527026817951};\\\", \\\"{x:898,y:521,t:1527026817967};\\\", \\\"{x:909,y:526,t:1527026817978};\\\", \\\"{x:930,y:535,t:1527026817996};\\\", \\\"{x:932,y:536,t:1527026818012};\\\", \\\"{x:936,y:536,t:1527026818180};\\\", \\\"{x:943,y:536,t:1527026818196};\\\", \\\"{x:953,y:536,t:1527026818212};\\\", \\\"{x:970,y:536,t:1527026818230};\\\", \\\"{x:992,y:538,t:1527026818245};\\\", \\\"{x:1013,y:542,t:1527026818263};\\\", \\\"{x:1030,y:543,t:1527026818280};\\\", \\\"{x:1044,y:546,t:1527026818295};\\\", \\\"{x:1049,y:547,t:1527026818312};\\\", \\\"{x:1053,y:549,t:1527026818329};\\\", \\\"{x:1056,y:551,t:1527026818345};\\\", \\\"{x:1061,y:554,t:1527026818363};\\\", \\\"{x:1061,y:555,t:1527026818381};\\\", \\\"{x:1062,y:557,t:1527026818397};\\\", \\\"{x:1062,y:559,t:1527026818412};\\\", \\\"{x:1062,y:560,t:1527026818437};\\\", \\\"{x:1062,y:561,t:1527026818445};\\\", \\\"{x:1062,y:562,t:1527026818462};\\\", \\\"{x:1062,y:566,t:1527026818480};\\\", \\\"{x:1062,y:569,t:1527026818495};\\\", \\\"{x:1062,y:577,t:1527026818513};\\\", \\\"{x:1059,y:584,t:1527026818529};\\\", \\\"{x:1058,y:590,t:1527026818545};\\\", \\\"{x:1057,y:594,t:1527026818562};\\\", \\\"{x:1055,y:599,t:1527026818578};\\\", \\\"{x:1054,y:606,t:1527026818595};\\\", \\\"{x:1051,y:614,t:1527026818612};\\\", \\\"{x:1050,y:621,t:1527026818629};\\\", \\\"{x:1047,y:627,t:1527026818645};\\\", \\\"{x:1045,y:641,t:1527026818662};\\\", \\\"{x:1040,y:658,t:1527026818679};\\\", \\\"{x:1034,y:675,t:1527026818695};\\\", \\\"{x:1029,y:692,t:1527026818712};\\\", \\\"{x:1024,y:709,t:1527026818729};\\\", \\\"{x:1019,y:726,t:1527026818746};\\\", \\\"{x:1015,y:743,t:1527026818762};\\\", \\\"{x:1013,y:763,t:1527026818779};\\\", \\\"{x:1013,y:783,t:1527026818796};\\\", \\\"{x:1013,y:794,t:1527026818812};\\\", \\\"{x:1016,y:806,t:1527026818829};\\\", \\\"{x:1021,y:815,t:1527026818846};\\\", \\\"{x:1032,y:829,t:1527026818862};\\\", \\\"{x:1051,y:844,t:1527026818879};\\\", \\\"{x:1077,y:858,t:1527026818896};\\\", \\\"{x:1099,y:869,t:1527026818912};\\\", \\\"{x:1123,y:879,t:1527026818929};\\\", \\\"{x:1146,y:884,t:1527026818946};\\\", \\\"{x:1167,y:890,t:1527026818962};\\\", \\\"{x:1194,y:892,t:1527026818979};\\\", \\\"{x:1222,y:895,t:1527026818997};\\\", \\\"{x:1234,y:895,t:1527026819012};\\\", \\\"{x:1240,y:895,t:1527026819030};\\\", \\\"{x:1250,y:895,t:1527026819046};\\\", \\\"{x:1258,y:894,t:1527026819062};\\\", \\\"{x:1262,y:893,t:1527026819080};\\\", \\\"{x:1265,y:892,t:1527026819096};\\\", \\\"{x:1268,y:891,t:1527026819113};\\\", \\\"{x:1270,y:891,t:1527026819130};\\\", \\\"{x:1271,y:890,t:1527026819146};\\\", \\\"{x:1273,y:890,t:1527026819164};\\\", \\\"{x:1274,y:888,t:1527026819188};\\\", \\\"{x:1275,y:887,t:1527026819228};\\\", \\\"{x:1276,y:885,t:1527026819235};\\\", \\\"{x:1276,y:884,t:1527026819246};\\\", \\\"{x:1278,y:880,t:1527026819263};\\\", \\\"{x:1280,y:871,t:1527026819279};\\\", \\\"{x:1283,y:866,t:1527026819295};\\\", \\\"{x:1286,y:859,t:1527026819313};\\\", \\\"{x:1287,y:852,t:1527026819329};\\\", \\\"{x:1288,y:849,t:1527026819346};\\\", \\\"{x:1288,y:848,t:1527026819363};\\\", \\\"{x:1288,y:846,t:1527026819378};\\\", \\\"{x:1289,y:844,t:1527026819404};\\\", \\\"{x:1289,y:843,t:1527026819428};\\\", \\\"{x:1289,y:842,t:1527026819453};\\\", \\\"{x:1289,y:841,t:1527026819477};\\\", \\\"{x:1289,y:840,t:1527026819484};\\\", \\\"{x:1289,y:839,t:1527026819565};\\\", \\\"{x:1289,y:838,t:1527026819580};\\\", \\\"{x:1287,y:837,t:1527026819597};\\\", \\\"{x:1286,y:836,t:1527026819614};\\\", \\\"{x:1283,y:835,t:1527026819633};\\\", \\\"{x:1283,y:834,t:1527026819668};\\\", \\\"{x:1282,y:834,t:1527026819680};\\\", \\\"{x:1282,y:833,t:1527026819696};\\\", \\\"{x:1282,y:832,t:1527026819712};\\\", \\\"{x:1281,y:832,t:1527026819730};\\\", \\\"{x:1281,y:831,t:1527026819763};\\\", \\\"{x:1280,y:831,t:1527026819803};\\\", \\\"{x:1279,y:830,t:1527026821916};\\\", \\\"{x:1277,y:830,t:1527026821931};\\\", \\\"{x:1246,y:830,t:1527026821948};\\\", \\\"{x:1196,y:830,t:1527026821965};\\\", \\\"{x:1113,y:830,t:1527026821981};\\\", \\\"{x:1002,y:830,t:1527026821998};\\\", \\\"{x:878,y:830,t:1527026822015};\\\", \\\"{x:764,y:830,t:1527026822031};\\\", \\\"{x:661,y:830,t:1527026822048};\\\", \\\"{x:586,y:830,t:1527026822064};\\\", \\\"{x:554,y:825,t:1527026822081};\\\", \\\"{x:540,y:822,t:1527026822098};\\\", \\\"{x:539,y:821,t:1527026822115};\\\", \\\"{x:539,y:820,t:1527026822195};\\\", \\\"{x:537,y:816,t:1527026822204};\\\", \\\"{x:537,y:814,t:1527026822215};\\\", \\\"{x:536,y:805,t:1527026822231};\\\", \\\"{x:534,y:795,t:1527026822248};\\\", \\\"{x:532,y:790,t:1527026822265};\\\", \\\"{x:528,y:779,t:1527026822281};\\\", \\\"{x:521,y:760,t:1527026822298};\\\", \\\"{x:506,y:714,t:1527026822316};\\\", \\\"{x:485,y:662,t:1527026822331};\\\", \\\"{x:460,y:600,t:1527026822349};\\\", \\\"{x:446,y:556,t:1527026822366};\\\", \\\"{x:432,y:505,t:1527026822383};\\\", \\\"{x:420,y:456,t:1527026822398};\\\", \\\"{x:414,y:430,t:1527026822415};\\\", \\\"{x:409,y:411,t:1527026822432};\\\", \\\"{x:406,y:404,t:1527026822448};\\\", \\\"{x:406,y:400,t:1527026822465};\\\", \\\"{x:405,y:396,t:1527026822482};\\\", \\\"{x:403,y:396,t:1527026822548};\\\", \\\"{x:401,y:396,t:1527026822555};\\\", \\\"{x:399,y:399,t:1527026822565};\\\", \\\"{x:397,y:422,t:1527026822582};\\\", \\\"{x:397,y:449,t:1527026822599};\\\", \\\"{x:397,y:469,t:1527026822615};\\\", \\\"{x:396,y:478,t:1527026822632};\\\", \\\"{x:393,y:487,t:1527026822649};\\\", \\\"{x:392,y:491,t:1527026822665};\\\", \\\"{x:392,y:495,t:1527026822682};\\\", \\\"{x:392,y:498,t:1527026822699};\\\", \\\"{x:392,y:499,t:1527026822732};\\\", \\\"{x:393,y:501,t:1527026822749};\\\", \\\"{x:394,y:505,t:1527026822765};\\\", \\\"{x:395,y:506,t:1527026822783};\\\", \\\"{x:395,y:508,t:1527026822812};\\\", \\\"{x:396,y:510,t:1527026822828};\\\", \\\"{x:396,y:511,t:1527026822835};\\\", \\\"{x:396,y:512,t:1527026822849};\\\", \\\"{x:396,y:515,t:1527026822866};\\\", \\\"{x:396,y:516,t:1527026822882};\\\", \\\"{x:396,y:517,t:1527026822899};\\\", \\\"{x:398,y:520,t:1527026823188};\\\", \\\"{x:406,y:523,t:1527026823199};\\\", \\\"{x:430,y:534,t:1527026823216};\\\", \\\"{x:460,y:545,t:1527026823232};\\\", \\\"{x:491,y:555,t:1527026823249};\\\", \\\"{x:528,y:561,t:1527026823266};\\\", \\\"{x:567,y:567,t:1527026823282};\\\", \\\"{x:596,y:573,t:1527026823299};\\\", \\\"{x:627,y:578,t:1527026823317};\\\", \\\"{x:645,y:583,t:1527026823334};\\\", \\\"{x:659,y:587,t:1527026823349};\\\", \\\"{x:676,y:594,t:1527026823366};\\\", \\\"{x:690,y:600,t:1527026823382};\\\", \\\"{x:704,y:605,t:1527026823399};\\\", \\\"{x:718,y:610,t:1527026823417};\\\", \\\"{x:736,y:615,t:1527026823433};\\\", \\\"{x:754,y:621,t:1527026823449};\\\", \\\"{x:778,y:629,t:1527026823466};\\\", \\\"{x:806,y:636,t:1527026823484};\\\", \\\"{x:835,y:647,t:1527026823499};\\\", \\\"{x:863,y:656,t:1527026823516};\\\", \\\"{x:876,y:661,t:1527026823533};\\\", \\\"{x:883,y:662,t:1527026823549};\\\", \\\"{x:886,y:662,t:1527026823567};\\\", \\\"{x:888,y:664,t:1527026823584};\\\", \\\"{x:890,y:665,t:1527026823599};\\\", \\\"{x:892,y:665,t:1527026823616};\\\", \\\"{x:893,y:666,t:1527026823633};\\\", \\\"{x:894,y:668,t:1527026823649};\\\", \\\"{x:898,y:672,t:1527026823667};\\\", \\\"{x:900,y:676,t:1527026823683};\\\", \\\"{x:902,y:680,t:1527026823699};\\\", \\\"{x:905,y:686,t:1527026823716};\\\", \\\"{x:906,y:687,t:1527026823734};\\\", \\\"{x:908,y:690,t:1527026823749};\\\", \\\"{x:908,y:692,t:1527026823766};\\\", \\\"{x:908,y:694,t:1527026823783};\\\", \\\"{x:909,y:696,t:1527026823800};\\\", \\\"{x:910,y:697,t:1527026823816};\\\", \\\"{x:911,y:698,t:1527026823833};\\\", \\\"{x:912,y:699,t:1527026823850};\\\", \\\"{x:912,y:700,t:1527026823868};\\\", \\\"{x:913,y:701,t:1527026823884};\\\", \\\"{x:913,y:702,t:1527026823901};\\\", \\\"{x:913,y:703,t:1527026823917};\\\", \\\"{x:914,y:703,t:1527026823934};\\\", \\\"{x:915,y:705,t:1527026823951};\\\", \\\"{x:915,y:706,t:1527026823966};\\\", \\\"{x:917,y:709,t:1527026823984};\\\", \\\"{x:917,y:711,t:1527026824005};\\\", \\\"{x:918,y:712,t:1527026824029};\\\", \\\"{x:917,y:712,t:1527026824165};\\\", \\\"{x:916,y:712,t:1527026824173};\\\", \\\"{x:915,y:712,t:1527026824184};\\\", \\\"{x:914,y:712,t:1527026825053};\\\", \\\"{x:909,y:709,t:1527026837213};\\\", \\\"{x:900,y:700,t:1527026837229};\\\", \\\"{x:899,y:699,t:1527026837245};\\\", \\\"{x:898,y:698,t:1527026837269};\\\", \\\"{x:894,y:698,t:1527026838333};\\\", \\\"{x:892,y:698,t:1527026838346};\\\", \\\"{x:887,y:699,t:1527026838362};\\\", \\\"{x:882,y:701,t:1527026838380};\\\", \\\"{x:875,y:701,t:1527026838397};\\\", \\\"{x:870,y:701,t:1527026838412};\\\", \\\"{x:867,y:704,t:1527026838430};\\\", \\\"{x:863,y:704,t:1527026838446};\\\", \\\"{x:862,y:705,t:1527026838463};\\\", \\\"{x:861,y:705,t:1527026838484};\\\", \\\"{x:859,y:706,t:1527026838812};\\\", \\\"{x:858,y:707,t:1527026838845};\\\", \\\"{x:858,y:708,t:1527026838853};\\\", \\\"{x:857,y:708,t:1527026838876};\\\", \\\"{x:856,y:709,t:1527026838909};\\\", \\\"{x:855,y:709,t:1527026838917};\\\", \\\"{x:854,y:709,t:1527026838932};\\\", \\\"{x:853,y:710,t:1527026838957};\\\", \\\"{x:852,y:710,t:1527026838981};\\\", \\\"{x:851,y:710,t:1527026839109};\\\", \\\"{x:850,y:710,t:1527026841484};\\\", \\\"{x:848,y:710,t:1527026841498};\\\", \\\"{x:833,y:715,t:1527026841515};\\\", \\\"{x:781,y:723,t:1527026841532};\\\", \\\"{x:750,y:728,t:1527026841548};\\\", \\\"{x:722,y:730,t:1527026841565};\\\", \\\"{x:681,y:733,t:1527026841583};\\\", \\\"{x:641,y:733,t:1527026841598};\\\", \\\"{x:585,y:734,t:1527026841616};\\\", \\\"{x:540,y:734,t:1527026841633};\\\", \\\"{x:512,y:734,t:1527026841648};\\\", \\\"{x:495,y:734,t:1527026841665};\\\", \\\"{x:484,y:732,t:1527026841681};\\\", \\\"{x:477,y:732,t:1527026841697};\\\", \\\"{x:474,y:729,t:1527026841714};\\\", \\\"{x:472,y:727,t:1527026841731};\\\", \\\"{x:470,y:726,t:1527026841748};\\\", \\\"{x:470,y:724,t:1527026841788};\\\", \\\"{x:469,y:724,t:1527026841803};\\\", \\\"{x:469,y:723,t:1527026841820};\\\", \\\"{x:469,y:720,t:1527026841836};\\\", \\\"{x:469,y:719,t:1527026841848};\\\", \\\"{x:468,y:716,t:1527026841864};\\\", \\\"{x:468,y:712,t:1527026841881};\\\", \\\"{x:468,y:709,t:1527026841898};\\\", \\\"{x:468,y:707,t:1527026841915};\\\", \\\"{x:468,y:706,t:1527026841931};\\\", \\\"{x:468,y:707,t:1527026842484};\\\", \\\"{x:468,y:712,t:1527026842498};\\\", \\\"{x:474,y:725,t:1527026842515};\\\", \\\"{x:496,y:748,t:1527026842531};\\\", \\\"{x:509,y:766,t:1527026842548};\\\", \\\"{x:523,y:780,t:1527026842564};\\\", \\\"{x:537,y:790,t:1527026842582};\\\", \\\"{x:552,y:801,t:1527026842598};\\\", \\\"{x:561,y:807,t:1527026842615};\\\", \\\"{x:575,y:812,t:1527026842632};\\\", \\\"{x:586,y:813,t:1527026842649};\\\", \\\"{x:602,y:814,t:1527026842666};\\\", \\\"{x:620,y:814,t:1527026842682};\\\", \\\"{x:646,y:814,t:1527026842698};\\\", \\\"{x:671,y:809,t:1527026842715};\\\", \\\"{x:710,y:794,t:1527026842732};\\\", \\\"{x:731,y:781,t:1527026842748};\\\", \\\"{x:748,y:770,t:1527026842765};\\\", \\\"{x:758,y:761,t:1527026842782};\\\", \\\"{x:768,y:753,t:1527026842799};\\\", \\\"{x:776,y:742,t:1527026842815};\\\", \\\"{x:784,y:731,t:1527026842832};\\\", \\\"{x:793,y:717,t:1527026842849};\\\", \\\"{x:801,y:704,t:1527026842865};\\\", \\\"{x:809,y:688,t:1527026842883};\\\", \\\"{x:817,y:668,t:1527026842899};\\\", \\\"{x:820,y:652,t:1527026842916};\\\", \\\"{x:820,y:630,t:1527026842932};\\\", \\\"{x:815,y:619,t:1527026842949};\\\", \\\"{x:811,y:612,t:1527026842966};\\\", \\\"{x:799,y:601,t:1527026842982};\\\", \\\"{x:783,y:587,t:1527026842998};\\\", \\\"{x:765,y:575,t:1527026843015};\\\", \\\"{x:745,y:561,t:1527026843032};\\\", \\\"{x:723,y:547,t:1527026843049};\\\", \\\"{x:692,y:532,t:1527026843065};\\\", \\\"{x:667,y:521,t:1527026843082};\\\", \\\"{x:643,y:512,t:1527026843099};\\\", \\\"{x:623,y:506,t:1527026843115};\\\", \\\"{x:594,y:498,t:1527026843132};\\\", \\\"{x:578,y:494,t:1527026843149};\\\", \\\"{x:569,y:493,t:1527026843164};\\\", \\\"{x:563,y:493,t:1527026843182};\\\", \\\"{x:562,y:493,t:1527026843203};\\\", \\\"{x:560,y:493,t:1527026843219};\\\", \\\"{x:559,y:493,t:1527026843235};\\\", \\\"{x:556,y:493,t:1527026843302};\\\", \\\"{x:553,y:493,t:1527026843332};\\\", \\\"{x:551,y:494,t:1527026843349};\\\", \\\"{x:548,y:495,t:1527026843366};\\\", \\\"{x:547,y:496,t:1527026843382};\\\" ] }, { \\\"rt\\\": 33290, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 210256, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -D -E -E -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:497,t:1527026843484};\\\", \\\"{x:547,y:501,t:1527026843499};\\\", \\\"{x:550,y:502,t:1527026843515};\\\", \\\"{x:554,y:505,t:1527026843531};\\\", \\\"{x:565,y:510,t:1527026843549};\\\", \\\"{x:581,y:516,t:1527026843575};\\\", \\\"{x:587,y:519,t:1527026843582};\\\", \\\"{x:599,y:525,t:1527026843598};\\\", \\\"{x:614,y:533,t:1527026843616};\\\", \\\"{x:626,y:541,t:1527026843632};\\\", \\\"{x:640,y:547,t:1527026843649};\\\", \\\"{x:650,y:552,t:1527026843666};\\\", \\\"{x:661,y:556,t:1527026843682};\\\", \\\"{x:669,y:561,t:1527026843699};\\\", \\\"{x:680,y:565,t:1527026843715};\\\", \\\"{x:685,y:568,t:1527026843732};\\\", \\\"{x:689,y:568,t:1527026843748};\\\", \\\"{x:691,y:568,t:1527026843766};\\\", \\\"{x:693,y:568,t:1527026843782};\\\", \\\"{x:694,y:568,t:1527026843799};\\\", \\\"{x:695,y:565,t:1527026843816};\\\", \\\"{x:695,y:546,t:1527026843832};\\\", \\\"{x:682,y:515,t:1527026843850};\\\", \\\"{x:664,y:492,t:1527026843866};\\\", \\\"{x:605,y:458,t:1527026843976};\\\", \\\"{x:604,y:458,t:1527026843983};\\\", \\\"{x:600,y:459,t:1527026843999};\\\", \\\"{x:598,y:461,t:1527026844019};\\\", \\\"{x:597,y:462,t:1527026844035};\\\", \\\"{x:596,y:463,t:1527026844059};\\\", \\\"{x:596,y:464,t:1527026844067};\\\", \\\"{x:596,y:465,t:1527026844082};\\\", \\\"{x:594,y:470,t:1527026844099};\\\", \\\"{x:594,y:477,t:1527026844116};\\\", \\\"{x:594,y:483,t:1527026844133};\\\", \\\"{x:599,y:489,t:1527026844149};\\\", \\\"{x:601,y:492,t:1527026844166};\\\", \\\"{x:604,y:495,t:1527026844183};\\\", \\\"{x:609,y:495,t:1527026844199};\\\", \\\"{x:614,y:495,t:1527026844216};\\\", \\\"{x:628,y:487,t:1527026844233};\\\", \\\"{x:642,y:475,t:1527026844249};\\\", \\\"{x:655,y:465,t:1527026844266};\\\", \\\"{x:663,y:451,t:1527026844284};\\\", \\\"{x:667,y:442,t:1527026844300};\\\", \\\"{x:667,y:428,t:1527026844316};\\\", \\\"{x:667,y:420,t:1527026844333};\\\", \\\"{x:667,y:416,t:1527026844350};\\\", \\\"{x:667,y:413,t:1527026844366};\\\", \\\"{x:667,y:411,t:1527026844383};\\\", \\\"{x:667,y:409,t:1527026844400};\\\", \\\"{x:666,y:408,t:1527026844417};\\\", \\\"{x:665,y:406,t:1527026844433};\\\", \\\"{x:663,y:406,t:1527026844580};\\\", \\\"{x:662,y:406,t:1527026844588};\\\", \\\"{x:660,y:405,t:1527026844604};\\\", \\\"{x:659,y:404,t:1527026844636};\\\", \\\"{x:658,y:404,t:1527026844652};\\\", \\\"{x:658,y:403,t:1527026844772};\\\", \\\"{x:657,y:402,t:1527026844876};\\\", \\\"{x:657,y:401,t:1527026844892};\\\", \\\"{x:657,y:400,t:1527026844908};\\\", \\\"{x:657,y:399,t:1527026844924};\\\", \\\"{x:657,y:398,t:1527026844933};\\\", \\\"{x:656,y:397,t:1527026845148};\\\", \\\"{x:655,y:397,t:1527026845156};\\\", \\\"{x:654,y:397,t:1527026845188};\\\", \\\"{x:653,y:397,t:1527026845221};\\\", \\\"{x:650,y:397,t:1527026845858};\\\", \\\"{x:649,y:398,t:1527026845985};\\\", \\\"{x:648,y:398,t:1527026846042};\\\", \\\"{x:647,y:398,t:1527026846050};\\\", \\\"{x:646,y:399,t:1527026846081};\\\", \\\"{x:644,y:399,t:1527026846098};\\\", \\\"{x:641,y:402,t:1527026846114};\\\", \\\"{x:640,y:402,t:1527026846131};\\\", \\\"{x:647,y:403,t:1527026846970};\\\", \\\"{x:654,y:405,t:1527026846982};\\\", \\\"{x:664,y:406,t:1527026846998};\\\", \\\"{x:678,y:406,t:1527026847015};\\\", \\\"{x:692,y:405,t:1527026847031};\\\", \\\"{x:715,y:405,t:1527026847049};\\\", \\\"{x:746,y:405,t:1527026847065};\\\", \\\"{x:769,y:405,t:1527026847081};\\\", \\\"{x:798,y:405,t:1527026847099};\\\", \\\"{x:826,y:405,t:1527026847116};\\\", \\\"{x:862,y:405,t:1527026847131};\\\", \\\"{x:904,y:405,t:1527026847149};\\\", \\\"{x:949,y:405,t:1527026847166};\\\", \\\"{x:994,y:405,t:1527026847182};\\\", \\\"{x:1050,y:405,t:1527026847198};\\\", \\\"{x:1103,y:405,t:1527026847216};\\\", \\\"{x:1142,y:405,t:1527026847231};\\\", \\\"{x:1206,y:405,t:1527026847250};\\\", \\\"{x:1241,y:405,t:1527026847266};\\\", \\\"{x:1272,y:405,t:1527026847282};\\\", \\\"{x:1309,y:405,t:1527026847298};\\\", \\\"{x:1354,y:405,t:1527026847316};\\\", \\\"{x:1417,y:409,t:1527026847331};\\\", \\\"{x:1503,y:424,t:1527026847349};\\\", \\\"{x:1587,y:435,t:1527026847365};\\\", \\\"{x:1665,y:439,t:1527026847381};\\\", \\\"{x:1708,y:439,t:1527026847398};\\\", \\\"{x:1723,y:436,t:1527026847415};\\\", \\\"{x:1730,y:432,t:1527026847431};\\\", \\\"{x:1728,y:432,t:1527026847705};\\\", \\\"{x:1727,y:432,t:1527026847715};\\\", \\\"{x:1723,y:432,t:1527026847733};\\\", \\\"{x:1719,y:432,t:1527026847749};\\\", \\\"{x:1713,y:432,t:1527026847766};\\\", \\\"{x:1708,y:432,t:1527026847782};\\\", \\\"{x:1703,y:433,t:1527026847799};\\\", \\\"{x:1697,y:434,t:1527026847816};\\\", \\\"{x:1690,y:437,t:1527026847833};\\\", \\\"{x:1689,y:437,t:1527026847849};\\\", \\\"{x:1687,y:438,t:1527026847865};\\\", \\\"{x:1684,y:440,t:1527026847883};\\\", \\\"{x:1679,y:442,t:1527026847898};\\\", \\\"{x:1675,y:447,t:1527026847916};\\\", \\\"{x:1666,y:455,t:1527026847932};\\\", \\\"{x:1658,y:467,t:1527026847949};\\\", \\\"{x:1649,y:475,t:1527026847966};\\\", \\\"{x:1635,y:487,t:1527026847983};\\\", \\\"{x:1620,y:499,t:1527026847999};\\\", \\\"{x:1599,y:515,t:1527026848016};\\\", \\\"{x:1577,y:536,t:1527026848033};\\\", \\\"{x:1533,y:582,t:1527026848049};\\\", \\\"{x:1402,y:694,t:1527026848065};\\\", \\\"{x:1288,y:780,t:1527026848083};\\\", \\\"{x:1209,y:842,t:1527026848099};\\\", \\\"{x:1175,y:866,t:1527026848116};\\\", \\\"{x:1151,y:884,t:1527026848133};\\\", \\\"{x:1135,y:897,t:1527026848149};\\\", \\\"{x:1125,y:903,t:1527026848165};\\\", \\\"{x:1120,y:907,t:1527026848183};\\\", \\\"{x:1123,y:907,t:1527026848354};\\\", \\\"{x:1128,y:907,t:1527026848366};\\\", \\\"{x:1136,y:906,t:1527026848383};\\\", \\\"{x:1145,y:903,t:1527026848400};\\\", \\\"{x:1156,y:899,t:1527026848416};\\\", \\\"{x:1177,y:891,t:1527026848433};\\\", \\\"{x:1195,y:886,t:1527026848450};\\\", \\\"{x:1212,y:884,t:1527026848466};\\\", \\\"{x:1225,y:879,t:1527026848483};\\\", \\\"{x:1230,y:877,t:1527026848499};\\\", \\\"{x:1238,y:873,t:1527026848515};\\\", \\\"{x:1245,y:870,t:1527026848533};\\\", \\\"{x:1253,y:866,t:1527026848550};\\\", \\\"{x:1264,y:859,t:1527026848566};\\\", \\\"{x:1272,y:854,t:1527026848582};\\\", \\\"{x:1275,y:852,t:1527026848599};\\\", \\\"{x:1277,y:851,t:1527026848615};\\\", \\\"{x:1278,y:850,t:1527026848633};\\\", \\\"{x:1279,y:850,t:1527026848770};\\\", \\\"{x:1280,y:849,t:1527026848784};\\\", \\\"{x:1280,y:847,t:1527026848800};\\\", \\\"{x:1282,y:845,t:1527026848817};\\\", \\\"{x:1283,y:840,t:1527026848833};\\\", \\\"{x:1284,y:831,t:1527026848850};\\\", \\\"{x:1286,y:821,t:1527026848866};\\\", \\\"{x:1288,y:803,t:1527026848882};\\\", \\\"{x:1289,y:787,t:1527026848900};\\\", \\\"{x:1289,y:770,t:1527026848916};\\\", \\\"{x:1289,y:763,t:1527026848933};\\\", \\\"{x:1289,y:757,t:1527026848950};\\\", \\\"{x:1289,y:754,t:1527026848967};\\\", \\\"{x:1289,y:753,t:1527026848982};\\\", \\\"{x:1289,y:752,t:1527026848999};\\\", \\\"{x:1289,y:750,t:1527026849017};\\\", \\\"{x:1289,y:749,t:1527026849032};\\\", \\\"{x:1289,y:748,t:1527026849049};\\\", \\\"{x:1289,y:745,t:1527026849067};\\\", \\\"{x:1289,y:744,t:1527026849083};\\\", \\\"{x:1289,y:743,t:1527026849100};\\\", \\\"{x:1289,y:742,t:1527026849121};\\\", \\\"{x:1289,y:741,t:1527026849133};\\\", \\\"{x:1289,y:740,t:1527026849186};\\\", \\\"{x:1289,y:739,t:1527026849217};\\\", \\\"{x:1290,y:736,t:1527026849233};\\\", \\\"{x:1291,y:736,t:1527026849362};\\\", \\\"{x:1293,y:736,t:1527026849369};\\\", \\\"{x:1294,y:736,t:1527026849383};\\\", \\\"{x:1298,y:740,t:1527026849400};\\\", \\\"{x:1305,y:746,t:1527026849417};\\\", \\\"{x:1307,y:750,t:1527026849434};\\\", \\\"{x:1313,y:757,t:1527026849450};\\\", \\\"{x:1316,y:762,t:1527026849467};\\\", \\\"{x:1320,y:766,t:1527026849483};\\\", \\\"{x:1321,y:767,t:1527026849500};\\\", \\\"{x:1322,y:768,t:1527026849517};\\\", \\\"{x:1322,y:770,t:1527026849534};\\\", \\\"{x:1323,y:774,t:1527026849550};\\\", \\\"{x:1324,y:776,t:1527026849567};\\\", \\\"{x:1324,y:779,t:1527026849584};\\\", \\\"{x:1324,y:782,t:1527026849599};\\\", \\\"{x:1324,y:788,t:1527026849617};\\\", \\\"{x:1324,y:791,t:1527026849633};\\\", \\\"{x:1323,y:794,t:1527026849650};\\\", \\\"{x:1321,y:796,t:1527026849667};\\\", \\\"{x:1319,y:798,t:1527026849683};\\\", \\\"{x:1318,y:799,t:1527026849700};\\\", \\\"{x:1315,y:801,t:1527026849717};\\\", \\\"{x:1314,y:802,t:1527026849734};\\\", \\\"{x:1309,y:803,t:1527026849750};\\\", \\\"{x:1303,y:807,t:1527026849767};\\\", \\\"{x:1297,y:810,t:1527026849784};\\\", \\\"{x:1289,y:812,t:1527026849801};\\\", \\\"{x:1279,y:816,t:1527026849818};\\\", \\\"{x:1274,y:818,t:1527026849834};\\\", \\\"{x:1271,y:819,t:1527026849850};\\\", \\\"{x:1269,y:820,t:1527026849867};\\\", \\\"{x:1268,y:820,t:1527026849884};\\\", \\\"{x:1267,y:821,t:1527026849900};\\\", \\\"{x:1266,y:822,t:1527026849921};\\\", \\\"{x:1265,y:823,t:1527026849934};\\\", \\\"{x:1263,y:825,t:1527026849950};\\\", \\\"{x:1263,y:828,t:1527026849967};\\\", \\\"{x:1261,y:832,t:1527026849985};\\\", \\\"{x:1261,y:834,t:1527026850000};\\\", \\\"{x:1261,y:839,t:1527026850017};\\\", \\\"{x:1265,y:842,t:1527026850033};\\\", \\\"{x:1281,y:848,t:1527026850051};\\\", \\\"{x:1297,y:853,t:1527026850067};\\\", \\\"{x:1314,y:859,t:1527026850084};\\\", \\\"{x:1326,y:864,t:1527026850101};\\\", \\\"{x:1340,y:865,t:1527026850117};\\\", \\\"{x:1352,y:868,t:1527026850134};\\\", \\\"{x:1360,y:868,t:1527026850151};\\\", \\\"{x:1367,y:868,t:1527026850168};\\\", \\\"{x:1373,y:869,t:1527026850184};\\\", \\\"{x:1380,y:870,t:1527026850200};\\\", \\\"{x:1392,y:872,t:1527026850217};\\\", \\\"{x:1400,y:872,t:1527026850234};\\\", \\\"{x:1411,y:872,t:1527026850251};\\\", \\\"{x:1424,y:872,t:1527026850267};\\\", \\\"{x:1433,y:872,t:1527026850284};\\\", \\\"{x:1439,y:872,t:1527026850302};\\\", \\\"{x:1446,y:872,t:1527026850317};\\\", \\\"{x:1453,y:872,t:1527026850334};\\\", \\\"{x:1462,y:872,t:1527026850351};\\\", \\\"{x:1470,y:872,t:1527026850367};\\\", \\\"{x:1477,y:871,t:1527026850384};\\\", \\\"{x:1489,y:869,t:1527026850400};\\\", \\\"{x:1497,y:867,t:1527026850416};\\\", \\\"{x:1509,y:864,t:1527026850433};\\\", \\\"{x:1518,y:861,t:1527026850450};\\\", \\\"{x:1527,y:858,t:1527026850467};\\\", \\\"{x:1538,y:853,t:1527026850483};\\\", \\\"{x:1551,y:847,t:1527026850501};\\\", \\\"{x:1560,y:842,t:1527026850516};\\\", \\\"{x:1570,y:833,t:1527026850534};\\\", \\\"{x:1583,y:823,t:1527026850551};\\\", \\\"{x:1596,y:813,t:1527026850567};\\\", \\\"{x:1605,y:804,t:1527026850584};\\\", \\\"{x:1615,y:790,t:1527026850601};\\\", \\\"{x:1619,y:784,t:1527026850617};\\\", \\\"{x:1624,y:775,t:1527026850633};\\\", \\\"{x:1630,y:762,t:1527026850651};\\\", \\\"{x:1637,y:748,t:1527026850667};\\\", \\\"{x:1645,y:730,t:1527026850684};\\\", \\\"{x:1650,y:718,t:1527026850701};\\\", \\\"{x:1657,y:705,t:1527026850717};\\\", \\\"{x:1664,y:691,t:1527026850734};\\\", \\\"{x:1671,y:676,t:1527026850751};\\\", \\\"{x:1679,y:657,t:1527026850768};\\\", \\\"{x:1687,y:639,t:1527026850784};\\\", \\\"{x:1699,y:613,t:1527026850801};\\\", \\\"{x:1704,y:599,t:1527026850817};\\\", \\\"{x:1708,y:591,t:1527026850834};\\\", \\\"{x:1709,y:587,t:1527026850850};\\\", \\\"{x:1711,y:582,t:1527026850868};\\\", \\\"{x:1711,y:581,t:1527026850884};\\\", \\\"{x:1711,y:576,t:1527026850901};\\\", \\\"{x:1711,y:569,t:1527026850918};\\\", \\\"{x:1711,y:561,t:1527026850934};\\\", \\\"{x:1711,y:553,t:1527026850950};\\\", \\\"{x:1711,y:545,t:1527026850967};\\\", \\\"{x:1710,y:540,t:1527026850984};\\\", \\\"{x:1707,y:529,t:1527026851001};\\\", \\\"{x:1702,y:522,t:1527026851018};\\\", \\\"{x:1696,y:514,t:1527026851035};\\\", \\\"{x:1693,y:510,t:1527026851051};\\\", \\\"{x:1691,y:508,t:1527026851068};\\\", \\\"{x:1689,y:504,t:1527026851084};\\\", \\\"{x:1680,y:498,t:1527026851101};\\\", \\\"{x:1672,y:492,t:1527026851118};\\\", \\\"{x:1660,y:485,t:1527026851134};\\\", \\\"{x:1653,y:481,t:1527026851151};\\\", \\\"{x:1650,y:480,t:1527026851168};\\\", \\\"{x:1648,y:479,t:1527026851184};\\\", \\\"{x:1645,y:477,t:1527026851201};\\\", \\\"{x:1642,y:475,t:1527026851217};\\\", \\\"{x:1641,y:475,t:1527026851234};\\\", \\\"{x:1641,y:473,t:1527026851251};\\\", \\\"{x:1640,y:472,t:1527026851268};\\\", \\\"{x:1639,y:469,t:1527026851284};\\\", \\\"{x:1638,y:464,t:1527026851302};\\\", \\\"{x:1636,y:462,t:1527026851318};\\\", \\\"{x:1635,y:461,t:1527026851334};\\\", \\\"{x:1635,y:460,t:1527026851351};\\\", \\\"{x:1635,y:459,t:1527026851367};\\\", \\\"{x:1634,y:457,t:1527026851383};\\\", \\\"{x:1632,y:454,t:1527026851400};\\\", \\\"{x:1628,y:451,t:1527026851417};\\\", \\\"{x:1626,y:448,t:1527026851434};\\\", \\\"{x:1624,y:447,t:1527026851451};\\\", \\\"{x:1624,y:446,t:1527026851468};\\\", \\\"{x:1622,y:444,t:1527026851484};\\\", \\\"{x:1621,y:443,t:1527026851501};\\\", \\\"{x:1620,y:441,t:1527026851517};\\\", \\\"{x:1619,y:440,t:1527026851535};\\\", \\\"{x:1618,y:440,t:1527026851551};\\\", \\\"{x:1616,y:440,t:1527026851722};\\\", \\\"{x:1616,y:439,t:1527026851735};\\\", \\\"{x:1615,y:437,t:1527026851751};\\\", \\\"{x:1614,y:436,t:1527026851768};\\\", \\\"{x:1613,y:433,t:1527026851786};\\\", \\\"{x:1612,y:432,t:1527026851801};\\\", \\\"{x:1612,y:431,t:1527026851818};\\\", \\\"{x:1611,y:433,t:1527026852018};\\\", \\\"{x:1609,y:440,t:1527026852036};\\\", \\\"{x:1608,y:448,t:1527026852052};\\\", \\\"{x:1605,y:456,t:1527026852068};\\\", \\\"{x:1603,y:462,t:1527026852085};\\\", \\\"{x:1601,y:466,t:1527026852102};\\\", \\\"{x:1601,y:467,t:1527026852118};\\\", \\\"{x:1600,y:472,t:1527026852135};\\\", \\\"{x:1600,y:478,t:1527026852151};\\\", \\\"{x:1600,y:483,t:1527026852168};\\\", \\\"{x:1597,y:497,t:1527026852185};\\\", \\\"{x:1595,y:506,t:1527026852201};\\\", \\\"{x:1594,y:512,t:1527026852218};\\\", \\\"{x:1594,y:516,t:1527026852234};\\\", \\\"{x:1593,y:518,t:1527026852252};\\\", \\\"{x:1593,y:521,t:1527026852268};\\\", \\\"{x:1593,y:525,t:1527026852285};\\\", \\\"{x:1593,y:530,t:1527026852302};\\\", \\\"{x:1593,y:536,t:1527026852318};\\\", \\\"{x:1593,y:541,t:1527026852335};\\\", \\\"{x:1593,y:545,t:1527026852351};\\\", \\\"{x:1593,y:549,t:1527026852368};\\\", \\\"{x:1596,y:557,t:1527026852385};\\\", \\\"{x:1597,y:562,t:1527026852402};\\\", \\\"{x:1598,y:566,t:1527026852418};\\\", \\\"{x:1598,y:569,t:1527026852435};\\\", \\\"{x:1598,y:570,t:1527026852452};\\\", \\\"{x:1600,y:572,t:1527026852468};\\\", \\\"{x:1600,y:575,t:1527026852484};\\\", \\\"{x:1601,y:576,t:1527026852502};\\\", \\\"{x:1602,y:578,t:1527026852517};\\\", \\\"{x:1603,y:578,t:1527026852649};\\\", \\\"{x:1605,y:578,t:1527026852664};\\\", \\\"{x:1606,y:578,t:1527026852672};\\\", \\\"{x:1606,y:577,t:1527026855450};\\\", \\\"{x:1605,y:577,t:1527026855474};\\\", \\\"{x:1603,y:577,t:1527026855487};\\\", \\\"{x:1603,y:578,t:1527026855503};\\\", \\\"{x:1602,y:578,t:1527026855521};\\\", \\\"{x:1603,y:578,t:1527026856201};\\\", \\\"{x:1604,y:578,t:1527026856258};\\\", \\\"{x:1605,y:578,t:1527026856297};\\\", \\\"{x:1606,y:578,t:1527026856321};\\\", \\\"{x:1606,y:577,t:1527026856337};\\\", \\\"{x:1607,y:576,t:1527026856360};\\\", \\\"{x:1609,y:575,t:1527026856400};\\\", \\\"{x:1610,y:575,t:1527026856433};\\\", \\\"{x:1611,y:575,t:1527026856449};\\\", \\\"{x:1612,y:574,t:1527026856457};\\\", \\\"{x:1613,y:573,t:1527026856489};\\\", \\\"{x:1614,y:572,t:1527026856520};\\\", \\\"{x:1615,y:571,t:1527026856585};\\\", \\\"{x:1615,y:562,t:1527026864122};\\\", \\\"{x:1612,y:551,t:1527026864142};\\\", \\\"{x:1608,y:543,t:1527026864160};\\\", \\\"{x:1596,y:527,t:1527026864174};\\\", \\\"{x:1587,y:513,t:1527026864192};\\\", \\\"{x:1580,y:502,t:1527026864209};\\\", \\\"{x:1575,y:496,t:1527026864225};\\\", \\\"{x:1574,y:491,t:1527026864242};\\\", \\\"{x:1573,y:485,t:1527026864258};\\\", \\\"{x:1571,y:480,t:1527026864275};\\\", \\\"{x:1571,y:473,t:1527026864291};\\\", \\\"{x:1571,y:468,t:1527026864308};\\\", \\\"{x:1571,y:464,t:1527026864326};\\\", \\\"{x:1571,y:459,t:1527026864342};\\\", \\\"{x:1573,y:454,t:1527026864359};\\\", \\\"{x:1576,y:451,t:1527026864375};\\\", \\\"{x:1579,y:448,t:1527026864391};\\\", \\\"{x:1585,y:446,t:1527026864409};\\\", \\\"{x:1587,y:444,t:1527026864425};\\\", \\\"{x:1588,y:444,t:1527026864442};\\\", \\\"{x:1589,y:443,t:1527026864514};\\\", \\\"{x:1590,y:443,t:1527026864525};\\\", \\\"{x:1592,y:442,t:1527026864542};\\\", \\\"{x:1595,y:442,t:1527026864558};\\\", \\\"{x:1599,y:439,t:1527026864576};\\\", \\\"{x:1600,y:439,t:1527026864592};\\\", \\\"{x:1602,y:438,t:1527026864618};\\\", \\\"{x:1604,y:437,t:1527026864666};\\\", \\\"{x:1606,y:436,t:1527026864689};\\\", \\\"{x:1607,y:436,t:1527026864786};\\\", \\\"{x:1608,y:436,t:1527026864793};\\\", \\\"{x:1609,y:435,t:1527026864808};\\\", \\\"{x:1612,y:434,t:1527026864826};\\\", \\\"{x:1613,y:433,t:1527026864842};\\\", \\\"{x:1613,y:432,t:1527026864859};\\\", \\\"{x:1612,y:433,t:1527026865562};\\\", \\\"{x:1612,y:434,t:1527026865575};\\\", \\\"{x:1611,y:438,t:1527026865594};\\\", \\\"{x:1609,y:446,t:1527026865609};\\\", \\\"{x:1609,y:452,t:1527026865626};\\\", \\\"{x:1609,y:462,t:1527026865643};\\\", \\\"{x:1609,y:469,t:1527026865660};\\\", \\\"{x:1609,y:476,t:1527026865676};\\\", \\\"{x:1609,y:482,t:1527026865692};\\\", \\\"{x:1609,y:490,t:1527026865710};\\\", \\\"{x:1609,y:496,t:1527026865726};\\\", \\\"{x:1609,y:501,t:1527026865743};\\\", \\\"{x:1609,y:508,t:1527026865759};\\\", \\\"{x:1609,y:516,t:1527026865775};\\\", \\\"{x:1609,y:521,t:1527026865792};\\\", \\\"{x:1604,y:531,t:1527026865809};\\\", \\\"{x:1594,y:540,t:1527026865825};\\\", \\\"{x:1570,y:552,t:1527026865843};\\\", \\\"{x:1531,y:565,t:1527026865860};\\\", \\\"{x:1454,y:581,t:1527026865875};\\\", \\\"{x:1356,y:598,t:1527026865893};\\\", \\\"{x:1253,y:619,t:1527026865910};\\\", \\\"{x:1154,y:640,t:1527026865926};\\\", \\\"{x:1068,y:652,t:1527026865943};\\\", \\\"{x:991,y:659,t:1527026865959};\\\", \\\"{x:946,y:666,t:1527026865976};\\\", \\\"{x:929,y:668,t:1527026865993};\\\", \\\"{x:928,y:668,t:1527026866009};\\\", \\\"{x:926,y:668,t:1527026866050};\\\", \\\"{x:924,y:668,t:1527026866059};\\\", \\\"{x:913,y:668,t:1527026866076};\\\", \\\"{x:895,y:668,t:1527026866093};\\\", \\\"{x:879,y:666,t:1527026866109};\\\", \\\"{x:863,y:664,t:1527026866125};\\\", \\\"{x:845,y:661,t:1527026866141};\\\", \\\"{x:828,y:659,t:1527026866159};\\\", \\\"{x:800,y:650,t:1527026866176};\\\", \\\"{x:768,y:641,t:1527026866192};\\\", \\\"{x:715,y:629,t:1527026866210};\\\", \\\"{x:649,y:621,t:1527026866225};\\\", \\\"{x:605,y:618,t:1527026866242};\\\", \\\"{x:579,y:617,t:1527026866263};\\\", \\\"{x:547,y:617,t:1527026866280};\\\", \\\"{x:520,y:617,t:1527026866297};\\\", \\\"{x:492,y:614,t:1527026866313};\\\", \\\"{x:473,y:614,t:1527026866330};\\\", \\\"{x:457,y:614,t:1527026866347};\\\", \\\"{x:447,y:614,t:1527026866363};\\\", \\\"{x:435,y:614,t:1527026866380};\\\", \\\"{x:420,y:614,t:1527026866397};\\\", \\\"{x:407,y:614,t:1527026866414};\\\", \\\"{x:396,y:614,t:1527026866430};\\\", \\\"{x:383,y:613,t:1527026866447};\\\", \\\"{x:358,y:608,t:1527026866465};\\\", \\\"{x:334,y:601,t:1527026866480};\\\", \\\"{x:308,y:595,t:1527026866498};\\\", \\\"{x:282,y:590,t:1527026866515};\\\", \\\"{x:262,y:586,t:1527026866532};\\\", \\\"{x:247,y:584,t:1527026866548};\\\", \\\"{x:233,y:583,t:1527026866564};\\\", \\\"{x:222,y:580,t:1527026866581};\\\", \\\"{x:210,y:578,t:1527026866598};\\\", \\\"{x:193,y:575,t:1527026866615};\\\", \\\"{x:180,y:574,t:1527026866632};\\\", \\\"{x:170,y:572,t:1527026866648};\\\", \\\"{x:167,y:572,t:1527026866665};\\\", \\\"{x:166,y:571,t:1527026866688};\\\", \\\"{x:166,y:572,t:1527026866849};\\\", \\\"{x:166,y:575,t:1527026866866};\\\", \\\"{x:166,y:582,t:1527026866882};\\\", \\\"{x:167,y:590,t:1527026866898};\\\", \\\"{x:167,y:594,t:1527026866915};\\\", \\\"{x:168,y:599,t:1527026866931};\\\", \\\"{x:168,y:602,t:1527026866948};\\\", \\\"{x:168,y:606,t:1527026866965};\\\", \\\"{x:168,y:609,t:1527026866983};\\\", \\\"{x:168,y:610,t:1527026866998};\\\", \\\"{x:168,y:611,t:1527026867015};\\\", \\\"{x:168,y:612,t:1527026867032};\\\", \\\"{x:168,y:613,t:1527026867064};\\\", \\\"{x:168,y:615,t:1527026867081};\\\", \\\"{x:168,y:616,t:1527026867105};\\\", \\\"{x:168,y:617,t:1527026867115};\\\", \\\"{x:168,y:618,t:1527026867132};\\\", \\\"{x:168,y:621,t:1527026867150};\\\", \\\"{x:168,y:623,t:1527026867166};\\\", \\\"{x:168,y:624,t:1527026867182};\\\", \\\"{x:168,y:626,t:1527026867200};\\\", \\\"{x:168,y:628,t:1527026867215};\\\", \\\"{x:168,y:630,t:1527026867232};\\\", \\\"{x:169,y:631,t:1527026867249};\\\", \\\"{x:170,y:631,t:1527026867266};\\\", \\\"{x:170,y:632,t:1527026867289};\\\", \\\"{x:170,y:633,t:1527026867312};\\\", \\\"{x:170,y:634,t:1527026867344};\\\", \\\"{x:170,y:635,t:1527026868505};\\\", \\\"{x:172,y:638,t:1527026868516};\\\", \\\"{x:185,y:648,t:1527026868534};\\\", \\\"{x:214,y:664,t:1527026868551};\\\", \\\"{x:258,y:682,t:1527026868566};\\\", \\\"{x:304,y:701,t:1527026868583};\\\", \\\"{x:373,y:719,t:1527026868600};\\\", \\\"{x:412,y:731,t:1527026868617};\\\", \\\"{x:442,y:734,t:1527026868634};\\\", \\\"{x:470,y:739,t:1527026868650};\\\", \\\"{x:493,y:741,t:1527026868667};\\\", \\\"{x:512,y:744,t:1527026868683};\\\", \\\"{x:528,y:745,t:1527026868701};\\\", \\\"{x:538,y:748,t:1527026868716};\\\", \\\"{x:547,y:749,t:1527026868733};\\\", \\\"{x:558,y:749,t:1527026868751};\\\", \\\"{x:569,y:749,t:1527026868766};\\\", \\\"{x:580,y:749,t:1527026868783};\\\", \\\"{x:600,y:745,t:1527026868800};\\\", \\\"{x:610,y:740,t:1527026868817};\\\", \\\"{x:615,y:737,t:1527026868833};\\\", \\\"{x:617,y:736,t:1527026868850};\\\", \\\"{x:618,y:735,t:1527026868867};\\\", \\\"{x:619,y:733,t:1527026868905};\\\", \\\"{x:620,y:733,t:1527026868917};\\\", \\\"{x:620,y:732,t:1527026868934};\\\", \\\"{x:621,y:731,t:1527026868951};\\\", \\\"{x:622,y:730,t:1527026868967};\\\", \\\"{x:624,y:729,t:1527026868983};\\\", \\\"{x:627,y:727,t:1527026869001};\\\", \\\"{x:632,y:725,t:1527026869017};\\\", \\\"{x:636,y:724,t:1527026869034};\\\", \\\"{x:641,y:723,t:1527026869050};\\\", \\\"{x:648,y:720,t:1527026869068};\\\", \\\"{x:655,y:719,t:1527026869084};\\\", \\\"{x:665,y:716,t:1527026869102};\\\", \\\"{x:673,y:714,t:1527026869117};\\\", \\\"{x:679,y:713,t:1527026869134};\\\", \\\"{x:685,y:712,t:1527026869150};\\\", \\\"{x:691,y:710,t:1527026869167};\\\", \\\"{x:694,y:709,t:1527026869183};\\\", \\\"{x:700,y:707,t:1527026869201};\\\", \\\"{x:702,y:707,t:1527026869217};\\\", \\\"{x:704,y:707,t:1527026869233};\\\", \\\"{x:706,y:705,t:1527026869251};\\\", \\\"{x:708,y:705,t:1527026869268};\\\", \\\"{x:709,y:704,t:1527026869284};\\\", \\\"{x:710,y:704,t:1527026869302};\\\", \\\"{x:713,y:703,t:1527026869318};\\\", \\\"{x:716,y:702,t:1527026869334};\\\", \\\"{x:720,y:701,t:1527026869350};\\\", \\\"{x:724,y:700,t:1527026869368};\\\", \\\"{x:729,y:700,t:1527026869383};\\\", \\\"{x:740,y:697,t:1527026869401};\\\", \\\"{x:747,y:697,t:1527026869417};\\\", \\\"{x:753,y:696,t:1527026869434};\\\", \\\"{x:762,y:694,t:1527026869451};\\\", \\\"{x:769,y:694,t:1527026869468};\\\", \\\"{x:777,y:694,t:1527026869484};\\\", \\\"{x:783,y:694,t:1527026869502};\\\", \\\"{x:790,y:693,t:1527026869517};\\\", \\\"{x:798,y:692,t:1527026869534};\\\", \\\"{x:805,y:689,t:1527026869550};\\\", \\\"{x:811,y:688,t:1527026869567};\\\", \\\"{x:820,y:685,t:1527026869585};\\\", \\\"{x:822,y:684,t:1527026869601};\\\", \\\"{x:825,y:683,t:1527026869617};\\\", \\\"{x:826,y:682,t:1527026869634};\\\", \\\"{x:827,y:682,t:1527026869651};\\\", \\\"{x:828,y:682,t:1527026869697};\\\", \\\"{x:830,y:681,t:1527026869720};\\\", \\\"{x:831,y:680,t:1527026869736};\\\", \\\"{x:832,y:680,t:1527026869761};\\\", \\\"{x:833,y:680,t:1527026869769};\\\", \\\"{x:833,y:679,t:1527026869784};\\\", \\\"{x:835,y:678,t:1527026869800};\\\", \\\"{x:836,y:678,t:1527026869817};\\\", \\\"{x:837,y:678,t:1527026869834};\\\", \\\"{x:838,y:677,t:1527026869851};\\\", \\\"{x:839,y:676,t:1527026869872};\\\", \\\"{x:840,y:675,t:1527026869929};\\\", \\\"{x:841,y:674,t:1527026869953};\\\", \\\"{x:841,y:673,t:1527026869977};\\\", \\\"{x:842,y:672,t:1527026869993};\\\", \\\"{x:842,y:670,t:1527026870001};\\\", \\\"{x:844,y:668,t:1527026870018};\\\", \\\"{x:844,y:667,t:1527026870034};\\\", \\\"{x:845,y:665,t:1527026870052};\\\", \\\"{x:845,y:664,t:1527026870068};\\\", \\\"{x:846,y:663,t:1527026870085};\\\", \\\"{x:847,y:662,t:1527026870102};\\\", \\\"{x:847,y:660,t:1527026870117};\\\", \\\"{x:847,y:657,t:1527026870134};\\\", \\\"{x:850,y:653,t:1527026870151};\\\", \\\"{x:850,y:651,t:1527026870167};\\\", \\\"{x:851,y:646,t:1527026870184};\\\", \\\"{x:851,y:644,t:1527026870201};\\\", \\\"{x:851,y:643,t:1527026870218};\\\", \\\"{x:852,y:643,t:1527026870234};\\\", \\\"{x:852,y:642,t:1527026870328};\\\", \\\"{x:852,y:641,t:1527026870336};\\\", \\\"{x:852,y:640,t:1527026870352};\\\", \\\"{x:852,y:639,t:1527026870368};\\\", \\\"{x:852,y:637,t:1527026870384};\\\", \\\"{x:852,y:636,t:1527026870408};\\\", \\\"{x:852,y:635,t:1527026870432};\\\", \\\"{x:852,y:634,t:1527026870489};\\\", \\\"{x:852,y:633,t:1527026870512};\\\", \\\"{x:852,y:632,t:1527026870520};\\\", \\\"{x:852,y:631,t:1527026870536};\\\", \\\"{x:852,y:630,t:1527026870561};\\\", \\\"{x:852,y:629,t:1527026870576};\\\", \\\"{x:852,y:628,t:1527026870585};\\\", \\\"{x:852,y:627,t:1527026870641};\\\", \\\"{x:851,y:624,t:1527026870657};\\\", \\\"{x:850,y:624,t:1527026870669};\\\", \\\"{x:849,y:621,t:1527026870685};\\\", \\\"{x:847,y:617,t:1527026870701};\\\", \\\"{x:844,y:613,t:1527026870718};\\\", \\\"{x:843,y:612,t:1527026870736};\\\", \\\"{x:840,y:609,t:1527026870751};\\\", \\\"{x:840,y:607,t:1527026870824};\\\", \\\"{x:839,y:607,t:1527026870840};\\\", \\\"{x:839,y:606,t:1527026870851};\\\", \\\"{x:839,y:605,t:1527026870868};\\\", \\\"{x:839,y:604,t:1527026870888};\\\", \\\"{x:837,y:604,t:1527026876105};\\\", \\\"{x:834,y:604,t:1527026876121};\\\", \\\"{x:828,y:606,t:1527026876139};\\\", \\\"{x:820,y:609,t:1527026876157};\\\", \\\"{x:811,y:614,t:1527026876173};\\\", \\\"{x:799,y:619,t:1527026876188};\\\", \\\"{x:787,y:624,t:1527026876205};\\\", \\\"{x:773,y:632,t:1527026876222};\\\", \\\"{x:764,y:638,t:1527026876239};\\\", \\\"{x:742,y:651,t:1527026876255};\\\", \\\"{x:728,y:660,t:1527026876272};\\\", \\\"{x:709,y:671,t:1527026876290};\\\", \\\"{x:686,y:682,t:1527026876306};\\\", \\\"{x:663,y:690,t:1527026876322};\\\", \\\"{x:641,y:700,t:1527026876339};\\\", \\\"{x:623,y:705,t:1527026876357};\\\", \\\"{x:603,y:711,t:1527026876373};\\\", \\\"{x:586,y:716,t:1527026876389};\\\", \\\"{x:568,y:720,t:1527026876406};\\\", \\\"{x:554,y:721,t:1527026876423};\\\", \\\"{x:541,y:725,t:1527026876439};\\\", \\\"{x:530,y:731,t:1527026876456};\\\", \\\"{x:529,y:731,t:1527026876473};\\\", \\\"{x:529,y:732,t:1527026877129};\\\", \\\"{x:530,y:735,t:1527026877140};\\\", \\\"{x:546,y:745,t:1527026877156};\\\", \\\"{x:569,y:755,t:1527026877174};\\\", \\\"{x:607,y:766,t:1527026877190};\\\", \\\"{x:652,y:777,t:1527026877206};\\\", \\\"{x:703,y:786,t:1527026877224};\\\", \\\"{x:780,y:799,t:1527026877240};\\\", \\\"{x:844,y:807,t:1527026877257};\\\", \\\"{x:884,y:809,t:1527026877274};\\\", \\\"{x:912,y:811,t:1527026877291};\\\", \\\"{x:933,y:812,t:1527026877307};\\\", \\\"{x:950,y:812,t:1527026877324};\\\", \\\"{x:960,y:812,t:1527026877341};\\\", \\\"{x:965,y:812,t:1527026877357};\\\", \\\"{x:966,y:812,t:1527026877374};\\\", \\\"{x:967,y:812,t:1527026877390};\\\", \\\"{x:967,y:810,t:1527026877849};\\\", \\\"{x:967,y:808,t:1527026877857};\\\", \\\"{x:968,y:806,t:1527026877874};\\\", \\\"{x:968,y:805,t:1527026877890};\\\", \\\"{x:968,y:803,t:1527026877908};\\\" ] }, { \\\"rt\\\": 29961, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 241458, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:968,y:802,t:1527026878022};\\\", \\\"{x:968,y:800,t:1527026878272};\\\", \\\"{x:968,y:798,t:1527026878304};\\\", \\\"{x:967,y:797,t:1527026878328};\\\", \\\"{x:966,y:796,t:1527026878361};\\\", \\\"{x:965,y:795,t:1527026878375};\\\", \\\"{x:964,y:794,t:1527026878391};\\\", \\\"{x:960,y:790,t:1527026878408};\\\", \\\"{x:900,y:777,t:1527026878506};\\\", \\\"{x:894,y:776,t:1527026878514};\\\", \\\"{x:888,y:776,t:1527026878524};\\\", \\\"{x:879,y:773,t:1527026878541};\\\", \\\"{x:874,y:772,t:1527026878558};\\\", \\\"{x:867,y:772,t:1527026878575};\\\", \\\"{x:862,y:772,t:1527026878591};\\\", \\\"{x:856,y:772,t:1527026878607};\\\", \\\"{x:847,y:772,t:1527026878624};\\\", \\\"{x:843,y:772,t:1527026878641};\\\", \\\"{x:837,y:773,t:1527026878657};\\\", \\\"{x:834,y:774,t:1527026878674};\\\", \\\"{x:830,y:774,t:1527026878692};\\\", \\\"{x:829,y:774,t:1527026878707};\\\", \\\"{x:828,y:774,t:1527026878725};\\\", \\\"{x:827,y:774,t:1527026878741};\\\", \\\"{x:826,y:774,t:1527026878768};\\\", \\\"{x:824,y:774,t:1527026878881};\\\", \\\"{x:823,y:774,t:1527026878905};\\\", \\\"{x:821,y:773,t:1527026878936};\\\", \\\"{x:820,y:773,t:1527026879073};\\\", \\\"{x:819,y:773,t:1527026879121};\\\", \\\"{x:818,y:773,t:1527026879152};\\\", \\\"{x:817,y:774,t:1527026879761};\\\", \\\"{x:816,y:774,t:1527026879825};\\\", \\\"{x:815,y:774,t:1527026880001};\\\", \\\"{x:814,y:774,t:1527026880194};\\\", \\\"{x:813,y:774,t:1527026880209};\\\", \\\"{x:812,y:774,t:1527026880226};\\\", \\\"{x:811,y:774,t:1527026880273};\\\", \\\"{x:810,y:774,t:1527026880281};\\\", \\\"{x:809,y:774,t:1527026880296};\\\", \\\"{x:808,y:774,t:1527026880312};\\\", \\\"{x:806,y:774,t:1527026880329};\\\", \\\"{x:805,y:774,t:1527026880353};\\\", \\\"{x:804,y:774,t:1527026880361};\\\", \\\"{x:802,y:774,t:1527026880376};\\\", \\\"{x:801,y:774,t:1527026880393};\\\", \\\"{x:800,y:774,t:1527026880410};\\\", \\\"{x:799,y:774,t:1527026880465};\\\", \\\"{x:798,y:774,t:1527026880488};\\\", \\\"{x:797,y:774,t:1527026880689};\\\", \\\"{x:796,y:774,t:1527026880737};\\\", \\\"{x:795,y:774,t:1527026880744};\\\", \\\"{x:794,y:774,t:1527026880849};\\\", \\\"{x:793,y:774,t:1527026881617};\\\", \\\"{x:792,y:773,t:1527026881626};\\\", \\\"{x:791,y:772,t:1527026881649};\\\", \\\"{x:790,y:772,t:1527026881672};\\\", \\\"{x:788,y:771,t:1527026881697};\\\", \\\"{x:788,y:770,t:1527026881720};\\\", \\\"{x:787,y:770,t:1527026881752};\\\", \\\"{x:786,y:770,t:1527026881784};\\\", \\\"{x:785,y:769,t:1527026881873};\\\", \\\"{x:784,y:769,t:1527026881937};\\\", \\\"{x:784,y:768,t:1527026881993};\\\", \\\"{x:783,y:767,t:1527026882010};\\\", \\\"{x:782,y:767,t:1527026882065};\\\", \\\"{x:781,y:766,t:1527026882217};\\\", \\\"{x:780,y:766,t:1527026882409};\\\", \\\"{x:779,y:766,t:1527026882480};\\\", \\\"{x:778,y:766,t:1527026882511};\\\", \\\"{x:777,y:766,t:1527026882576};\\\", \\\"{x:776,y:766,t:1527026882592};\\\", \\\"{x:775,y:766,t:1527026882616};\\\", \\\"{x:774,y:766,t:1527026882627};\\\", \\\"{x:773,y:766,t:1527026882643};\\\", \\\"{x:772,y:766,t:1527026882673};\\\", \\\"{x:771,y:766,t:1527026882833};\\\", \\\"{x:769,y:767,t:1527026882872};\\\", \\\"{x:768,y:767,t:1527026882913};\\\", \\\"{x:767,y:767,t:1527026882969};\\\", \\\"{x:766,y:768,t:1527026882993};\\\", \\\"{x:765,y:768,t:1527026883025};\\\", \\\"{x:764,y:768,t:1527026883073};\\\", \\\"{x:763,y:768,t:1527026883081};\\\", \\\"{x:760,y:770,t:1527026884057};\\\", \\\"{x:759,y:770,t:1527026884072};\\\", \\\"{x:758,y:771,t:1527026884097};\\\", \\\"{x:757,y:771,t:1527026884112};\\\", \\\"{x:756,y:771,t:1527026884129};\\\", \\\"{x:755,y:771,t:1527026884193};\\\", \\\"{x:754,y:771,t:1527026884880};\\\", \\\"{x:753,y:771,t:1527026891281};\\\", \\\"{x:752,y:771,t:1527026891288};\\\", \\\"{x:749,y:771,t:1527026891302};\\\", \\\"{x:739,y:766,t:1527026891318};\\\", \\\"{x:730,y:759,t:1527026891334};\\\", \\\"{x:722,y:754,t:1527026891351};\\\", \\\"{x:712,y:746,t:1527026891366};\\\", \\\"{x:704,y:740,t:1527026891384};\\\", \\\"{x:699,y:737,t:1527026891400};\\\", \\\"{x:693,y:734,t:1527026891417};\\\", \\\"{x:688,y:731,t:1527026891434};\\\", \\\"{x:683,y:728,t:1527026891450};\\\", \\\"{x:677,y:726,t:1527026891467};\\\", \\\"{x:671,y:723,t:1527026891484};\\\", \\\"{x:657,y:718,t:1527026891501};\\\", \\\"{x:646,y:714,t:1527026891517};\\\", \\\"{x:631,y:709,t:1527026891534};\\\", \\\"{x:614,y:704,t:1527026891551};\\\", \\\"{x:596,y:698,t:1527026891567};\\\", \\\"{x:565,y:693,t:1527026891584};\\\", \\\"{x:540,y:688,t:1527026891601};\\\", \\\"{x:522,y:684,t:1527026891617};\\\", \\\"{x:502,y:679,t:1527026891634};\\\", \\\"{x:483,y:674,t:1527026891652};\\\", \\\"{x:464,y:670,t:1527026891667};\\\", \\\"{x:447,y:665,t:1527026891685};\\\", \\\"{x:425,y:657,t:1527026891701};\\\", \\\"{x:404,y:655,t:1527026891718};\\\", \\\"{x:384,y:648,t:1527026891735};\\\", \\\"{x:361,y:641,t:1527026891751};\\\", \\\"{x:322,y:626,t:1527026891768};\\\", \\\"{x:298,y:615,t:1527026891786};\\\", \\\"{x:276,y:604,t:1527026891802};\\\", \\\"{x:255,y:594,t:1527026891818};\\\", \\\"{x:238,y:589,t:1527026891835};\\\", \\\"{x:225,y:582,t:1527026891852};\\\", \\\"{x:209,y:576,t:1527026891868};\\\", \\\"{x:193,y:572,t:1527026891885};\\\", \\\"{x:176,y:566,t:1527026891903};\\\", \\\"{x:166,y:565,t:1527026891919};\\\", \\\"{x:157,y:562,t:1527026891934};\\\", \\\"{x:152,y:560,t:1527026891952};\\\", \\\"{x:151,y:560,t:1527026891969};\\\", \\\"{x:150,y:560,t:1527026891985};\\\", \\\"{x:151,y:564,t:1527026894025};\\\", \\\"{x:156,y:569,t:1527026894038};\\\", \\\"{x:170,y:581,t:1527026894055};\\\", \\\"{x:195,y:598,t:1527026894071};\\\", \\\"{x:229,y:616,t:1527026894087};\\\", \\\"{x:292,y:642,t:1527026894104};\\\", \\\"{x:344,y:665,t:1527026894120};\\\", \\\"{x:387,y:680,t:1527026894137};\\\", \\\"{x:427,y:693,t:1527026894154};\\\", \\\"{x:460,y:701,t:1527026894170};\\\", \\\"{x:480,y:706,t:1527026894187};\\\", \\\"{x:495,y:709,t:1527026894204};\\\", \\\"{x:504,y:711,t:1527026894220};\\\", \\\"{x:512,y:715,t:1527026894237};\\\", \\\"{x:518,y:716,t:1527026894254};\\\", \\\"{x:519,y:716,t:1527026894312};\\\", \\\"{x:523,y:718,t:1527026894320};\\\", \\\"{x:532,y:721,t:1527026894337};\\\", \\\"{x:538,y:723,t:1527026894353};\\\", \\\"{x:541,y:724,t:1527026894370};\\\", \\\"{x:542,y:724,t:1527026894387};\\\", \\\"{x:543,y:724,t:1527026894449};\\\" ] }, { \\\"rt\\\": 50198, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 292899, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -I -O -O -U -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:725,t:1527026909413};\\\", \\\"{x:545,y:732,t:1527026909421};\\\", \\\"{x:554,y:740,t:1527026909430};\\\", \\\"{x:575,y:756,t:1527026909447};\\\", \\\"{x:599,y:771,t:1527026909463};\\\", \\\"{x:625,y:785,t:1527026909480};\\\", \\\"{x:662,y:804,t:1527026909497};\\\", \\\"{x:697,y:816,t:1527026909513};\\\", \\\"{x:729,y:825,t:1527026909530};\\\", \\\"{x:758,y:834,t:1527026909548};\\\", \\\"{x:783,y:838,t:1527026909563};\\\", \\\"{x:802,y:840,t:1527026909580};\\\", \\\"{x:819,y:840,t:1527026909597};\\\", \\\"{x:829,y:837,t:1527026909614};\\\", \\\"{x:847,y:801,t:1527026909705};\\\", \\\"{x:847,y:797,t:1527026909716};\\\", \\\"{x:847,y:786,t:1527026909730};\\\", \\\"{x:843,y:770,t:1527026909747};\\\", \\\"{x:831,y:749,t:1527026909764};\\\", \\\"{x:814,y:728,t:1527026909780};\\\", \\\"{x:775,y:697,t:1527026909797};\\\", \\\"{x:743,y:681,t:1527026909814};\\\", \\\"{x:709,y:665,t:1527026909830};\\\", \\\"{x:671,y:655,t:1527026909847};\\\", \\\"{x:641,y:648,t:1527026909865};\\\", \\\"{x:616,y:643,t:1527026909881};\\\", \\\"{x:600,y:640,t:1527026909898};\\\", \\\"{x:591,y:639,t:1527026909914};\\\", \\\"{x:590,y:639,t:1527026909930};\\\", \\\"{x:589,y:639,t:1527026909947};\\\", \\\"{x:589,y:638,t:1527026910126};\\\", \\\"{x:590,y:637,t:1527026910134};\\\", \\\"{x:596,y:635,t:1527026910147};\\\", \\\"{x:609,y:635,t:1527026910165};\\\", \\\"{x:632,y:635,t:1527026910181};\\\", \\\"{x:647,y:635,t:1527026910197};\\\", \\\"{x:660,y:635,t:1527026910214};\\\", \\\"{x:673,y:635,t:1527026910231};\\\", \\\"{x:687,y:635,t:1527026910247};\\\", \\\"{x:698,y:637,t:1527026910264};\\\", \\\"{x:710,y:638,t:1527026910281};\\\", \\\"{x:722,y:642,t:1527026910297};\\\", \\\"{x:736,y:646,t:1527026910315};\\\", \\\"{x:749,y:649,t:1527026910331};\\\", \\\"{x:764,y:656,t:1527026910347};\\\", \\\"{x:776,y:663,t:1527026910365};\\\", \\\"{x:792,y:674,t:1527026910381};\\\", \\\"{x:800,y:679,t:1527026910399};\\\", \\\"{x:804,y:682,t:1527026910414};\\\", \\\"{x:809,y:687,t:1527026910431};\\\", \\\"{x:814,y:693,t:1527026910449};\\\", \\\"{x:820,y:704,t:1527026910464};\\\", \\\"{x:822,y:709,t:1527026910481};\\\", \\\"{x:824,y:716,t:1527026910499};\\\", \\\"{x:824,y:723,t:1527026910515};\\\", \\\"{x:825,y:731,t:1527026910532};\\\", \\\"{x:825,y:736,t:1527026910549};\\\", \\\"{x:825,y:747,t:1527026910566};\\\", \\\"{x:825,y:755,t:1527026910582};\\\", \\\"{x:820,y:764,t:1527026910598};\\\", \\\"{x:817,y:771,t:1527026910615};\\\", \\\"{x:813,y:780,t:1527026910631};\\\", \\\"{x:811,y:784,t:1527026910649};\\\", \\\"{x:809,y:787,t:1527026910666};\\\", \\\"{x:808,y:788,t:1527026910694};\\\", \\\"{x:808,y:789,t:1527026910701};\\\", \\\"{x:807,y:790,t:1527026910734};\\\", \\\"{x:806,y:790,t:1527026910830};\\\", \\\"{x:804,y:790,t:1527026911078};\\\", \\\"{x:803,y:790,t:1527026911086};\\\", \\\"{x:802,y:790,t:1527026911099};\\\", \\\"{x:799,y:790,t:1527026911116};\\\", \\\"{x:795,y:790,t:1527026911132};\\\", \\\"{x:790,y:790,t:1527026911148};\\\", \\\"{x:789,y:790,t:1527026911166};\\\", \\\"{x:787,y:790,t:1527026911318};\\\", \\\"{x:786,y:790,t:1527026911358};\\\", \\\"{x:785,y:790,t:1527026911533};\\\", \\\"{x:784,y:790,t:1527026911590};\\\", \\\"{x:783,y:790,t:1527026911710};\\\", \\\"{x:782,y:790,t:1527026911742};\\\", \\\"{x:781,y:790,t:1527026911751};\\\", \\\"{x:780,y:790,t:1527026911878};\\\", \\\"{x:780,y:791,t:1527026911974};\\\", \\\"{x:779,y:792,t:1527026912223};\\\", \\\"{x:779,y:793,t:1527026912253};\\\", \\\"{x:778,y:793,t:1527026912334};\\\", \\\"{x:777,y:793,t:1527026912358};\\\", \\\"{x:776,y:793,t:1527026912390};\\\", \\\"{x:775,y:793,t:1527026912414};\\\", \\\"{x:774,y:793,t:1527026912534};\\\", \\\"{x:773,y:793,t:1527026912582};\\\", \\\"{x:772,y:793,t:1527026912590};\\\", \\\"{x:771,y:793,t:1527026912605};\\\", \\\"{x:770,y:793,t:1527026912710};\\\", \\\"{x:769,y:793,t:1527026912734};\\\", \\\"{x:768,y:793,t:1527026912741};\\\", \\\"{x:767,y:793,t:1527026912765};\\\", \\\"{x:766,y:793,t:1527026912774};\\\", \\\"{x:765,y:793,t:1527026912786};\\\", \\\"{x:764,y:793,t:1527026912802};\\\", \\\"{x:763,y:793,t:1527026912819};\\\", \\\"{x:762,y:793,t:1527026913798};\\\", \\\"{x:761,y:793,t:1527026913814};\\\", \\\"{x:760,y:793,t:1527026913822};\\\", \\\"{x:760,y:792,t:1527026913837};\\\", \\\"{x:759,y:791,t:1527026913934};\\\", \\\"{x:758,y:791,t:1527026913950};\\\", \\\"{x:757,y:789,t:1527026913958};\\\", \\\"{x:756,y:789,t:1527026913973};\\\", \\\"{x:756,y:788,t:1527026913988};\\\", \\\"{x:755,y:788,t:1527026914004};\\\", \\\"{x:754,y:788,t:1527026914021};\\\", \\\"{x:753,y:788,t:1527026914213};\\\", \\\"{x:751,y:788,t:1527026914245};\\\", \\\"{x:750,y:788,t:1527026914254};\\\", \\\"{x:748,y:788,t:1527026914270};\\\", \\\"{x:747,y:788,t:1527026914287};\\\", \\\"{x:745,y:788,t:1527026914304};\\\", \\\"{x:744,y:788,t:1527026914365};\\\", \\\"{x:742,y:788,t:1527026914430};\\\", \\\"{x:741,y:788,t:1527026914542};\\\", \\\"{x:739,y:788,t:1527026914566};\\\", \\\"{x:738,y:788,t:1527026914581};\\\", \\\"{x:736,y:788,t:1527026914598};\\\", \\\"{x:733,y:788,t:1527026914605};\\\", \\\"{x:728,y:788,t:1527026914621};\\\", \\\"{x:719,y:788,t:1527026914639};\\\", \\\"{x:708,y:790,t:1527026914654};\\\", \\\"{x:695,y:792,t:1527026914672};\\\", \\\"{x:681,y:798,t:1527026914689};\\\", \\\"{x:665,y:802,t:1527026914705};\\\", \\\"{x:653,y:806,t:1527026914722};\\\", \\\"{x:644,y:808,t:1527026914739};\\\", \\\"{x:636,y:809,t:1527026914756};\\\", \\\"{x:632,y:809,t:1527026914772};\\\", \\\"{x:630,y:809,t:1527026914789};\\\", \\\"{x:629,y:809,t:1527026914806};\\\", \\\"{x:627,y:809,t:1527026914829};\\\", \\\"{x:626,y:809,t:1527026914990};\\\", \\\"{x:624,y:809,t:1527026915086};\\\", \\\"{x:623,y:809,t:1527026915182};\\\", \\\"{x:621,y:809,t:1527026915214};\\\", \\\"{x:620,y:809,t:1527026915229};\\\", \\\"{x:619,y:809,t:1527026915248};\\\", \\\"{x:618,y:809,t:1527026915256};\\\", \\\"{x:616,y:810,t:1527026915273};\\\", \\\"{x:614,y:811,t:1527026915290};\\\", \\\"{x:610,y:813,t:1527026915305};\\\", \\\"{x:608,y:813,t:1527026915334};\\\", \\\"{x:607,y:814,t:1527026915342};\\\", \\\"{x:606,y:815,t:1527026915357};\\\", \\\"{x:605,y:815,t:1527026915373};\\\", \\\"{x:604,y:815,t:1527026915406};\\\", \\\"{x:602,y:815,t:1527026915710};\\\", \\\"{x:600,y:815,t:1527026915726};\\\", \\\"{x:599,y:816,t:1527026915740};\\\", \\\"{x:596,y:817,t:1527026915757};\\\", \\\"{x:591,y:818,t:1527026915774};\\\", \\\"{x:589,y:818,t:1527026915790};\\\", \\\"{x:588,y:818,t:1527026915807};\\\", \\\"{x:587,y:818,t:1527026915824};\\\", \\\"{x:586,y:818,t:1527026915841};\\\", \\\"{x:585,y:818,t:1527026915857};\\\", \\\"{x:588,y:818,t:1527026915998};\\\", \\\"{x:596,y:815,t:1527026916008};\\\", \\\"{x:617,y:808,t:1527026916024};\\\", \\\"{x:639,y:804,t:1527026916041};\\\", \\\"{x:666,y:802,t:1527026916058};\\\", \\\"{x:705,y:797,t:1527026916073};\\\", \\\"{x:753,y:797,t:1527026916090};\\\", \\\"{x:808,y:797,t:1527026916108};\\\", \\\"{x:870,y:797,t:1527026916124};\\\", \\\"{x:922,y:803,t:1527026916140};\\\", \\\"{x:991,y:811,t:1527026916157};\\\", \\\"{x:1041,y:817,t:1527026916175};\\\", \\\"{x:1077,y:817,t:1527026916190};\\\", \\\"{x:1109,y:817,t:1527026916208};\\\", \\\"{x:1137,y:817,t:1527026916225};\\\", \\\"{x:1155,y:817,t:1527026916240};\\\", \\\"{x:1174,y:816,t:1527026916257};\\\", \\\"{x:1192,y:815,t:1527026916275};\\\", \\\"{x:1217,y:815,t:1527026916291};\\\", \\\"{x:1240,y:815,t:1527026916309};\\\", \\\"{x:1269,y:821,t:1527026916324};\\\", \\\"{x:1296,y:829,t:1527026916340};\\\", \\\"{x:1338,y:840,t:1527026916358};\\\", \\\"{x:1364,y:844,t:1527026916374};\\\", \\\"{x:1391,y:849,t:1527026916391};\\\", \\\"{x:1411,y:853,t:1527026916407};\\\", \\\"{x:1428,y:856,t:1527026916425};\\\", \\\"{x:1435,y:858,t:1527026916442};\\\", \\\"{x:1442,y:860,t:1527026916458};\\\", \\\"{x:1443,y:860,t:1527026916494};\\\", \\\"{x:1444,y:860,t:1527026916630};\\\", \\\"{x:1443,y:860,t:1527026916642};\\\", \\\"{x:1440,y:859,t:1527026916659};\\\", \\\"{x:1428,y:854,t:1527026916675};\\\", \\\"{x:1405,y:848,t:1527026916692};\\\", \\\"{x:1388,y:838,t:1527026916710};\\\", \\\"{x:1386,y:836,t:1527026916725};\\\", \\\"{x:1385,y:836,t:1527026917151};\\\", \\\"{x:1383,y:835,t:1527026917159};\\\", \\\"{x:1381,y:833,t:1527026917176};\\\", \\\"{x:1379,y:832,t:1527026917193};\\\", \\\"{x:1375,y:830,t:1527026917210};\\\", \\\"{x:1372,y:827,t:1527026917226};\\\", \\\"{x:1367,y:823,t:1527026917243};\\\", \\\"{x:1353,y:815,t:1527026917260};\\\", \\\"{x:1333,y:803,t:1527026917276};\\\", \\\"{x:1311,y:797,t:1527026917293};\\\", \\\"{x:1291,y:792,t:1527026917310};\\\", \\\"{x:1285,y:791,t:1527026917326};\\\", \\\"{x:1280,y:789,t:1527026917343};\\\", \\\"{x:1276,y:788,t:1527026917360};\\\", \\\"{x:1272,y:787,t:1527026917377};\\\", \\\"{x:1267,y:786,t:1527026917393};\\\", \\\"{x:1261,y:786,t:1527026917410};\\\", \\\"{x:1254,y:786,t:1527026917427};\\\", \\\"{x:1248,y:786,t:1527026917444};\\\", \\\"{x:1241,y:786,t:1527026917460};\\\", \\\"{x:1231,y:786,t:1527026917478};\\\", \\\"{x:1230,y:786,t:1527026917493};\\\", \\\"{x:1227,y:786,t:1527026917510};\\\", \\\"{x:1225,y:785,t:1527026917527};\\\", \\\"{x:1224,y:785,t:1527026917590};\\\", \\\"{x:1223,y:784,t:1527026917598};\\\", \\\"{x:1222,y:784,t:1527026917611};\\\", \\\"{x:1221,y:784,t:1527026917628};\\\", \\\"{x:1217,y:782,t:1527026917644};\\\", \\\"{x:1216,y:782,t:1527026917660};\\\", \\\"{x:1214,y:782,t:1527026917677};\\\", \\\"{x:1212,y:782,t:1527026917702};\\\", \\\"{x:1211,y:782,t:1527026917710};\\\", \\\"{x:1209,y:782,t:1527026917728};\\\", \\\"{x:1206,y:782,t:1527026917744};\\\", \\\"{x:1202,y:782,t:1527026917761};\\\", \\\"{x:1198,y:782,t:1527026917777};\\\", \\\"{x:1194,y:783,t:1527026917794};\\\", \\\"{x:1191,y:783,t:1527026917810};\\\", \\\"{x:1187,y:783,t:1527026917827};\\\", \\\"{x:1186,y:784,t:1527026917844};\\\", \\\"{x:1185,y:784,t:1527026918959};\\\", \\\"{x:1184,y:784,t:1527026919014};\\\", \\\"{x:1183,y:785,t:1527026919030};\\\", \\\"{x:1181,y:786,t:1527026919049};\\\", \\\"{x:1177,y:787,t:1527026919062};\\\", \\\"{x:1174,y:789,t:1527026919079};\\\", \\\"{x:1169,y:792,t:1527026919095};\\\", \\\"{x:1163,y:794,t:1527026919112};\\\", \\\"{x:1158,y:796,t:1527026919129};\\\", \\\"{x:1154,y:798,t:1527026919146};\\\", \\\"{x:1150,y:799,t:1527026919162};\\\", \\\"{x:1149,y:799,t:1527026919188};\\\", \\\"{x:1147,y:799,t:1527026919421};\\\", \\\"{x:1146,y:799,t:1527026919534};\\\", \\\"{x:1145,y:799,t:1527026919549};\\\", \\\"{x:1144,y:799,t:1527026919622};\\\", \\\"{x:1143,y:799,t:1527026920247};\\\", \\\"{x:1142,y:799,t:1527026920265};\\\", \\\"{x:1141,y:799,t:1527026920282};\\\", \\\"{x:1139,y:799,t:1527026920470};\\\", \\\"{x:1138,y:799,t:1527026920575};\\\", \\\"{x:1137,y:799,t:1527026920606};\\\", \\\"{x:1136,y:799,t:1527026920638};\\\", \\\"{x:1135,y:799,t:1527026920662};\\\", \\\"{x:1134,y:799,t:1527026920686};\\\", \\\"{x:1132,y:799,t:1527026920699};\\\", \\\"{x:1131,y:799,t:1527026920726};\\\", \\\"{x:1130,y:799,t:1527026920734};\\\", \\\"{x:1147,y:792,t:1527026923318};\\\", \\\"{x:1190,y:756,t:1527026923336};\\\", \\\"{x:1225,y:714,t:1527026923353};\\\", \\\"{x:1279,y:675,t:1527026923369};\\\", \\\"{x:1315,y:652,t:1527026923386};\\\", \\\"{x:1328,y:642,t:1527026923403};\\\", \\\"{x:1338,y:634,t:1527026923419};\\\", \\\"{x:1344,y:628,t:1527026923436};\\\", \\\"{x:1349,y:619,t:1527026923452};\\\", \\\"{x:1354,y:605,t:1527026923470};\\\", \\\"{x:1359,y:594,t:1527026923486};\\\", \\\"{x:1364,y:585,t:1527026923502};\\\", \\\"{x:1368,y:571,t:1527026923520};\\\", \\\"{x:1369,y:565,t:1527026923536};\\\", \\\"{x:1369,y:556,t:1527026923553};\\\", \\\"{x:1369,y:548,t:1527026923570};\\\", \\\"{x:1367,y:536,t:1527026923586};\\\", \\\"{x:1365,y:530,t:1527026923602};\\\", \\\"{x:1363,y:527,t:1527026923620};\\\", \\\"{x:1360,y:519,t:1527026923636};\\\", \\\"{x:1358,y:512,t:1527026923653};\\\", \\\"{x:1358,y:510,t:1527026923670};\\\", \\\"{x:1356,y:507,t:1527026923686};\\\", \\\"{x:1354,y:505,t:1527026923703};\\\", \\\"{x:1352,y:503,t:1527026923720};\\\", \\\"{x:1349,y:501,t:1527026923737};\\\", \\\"{x:1346,y:498,t:1527026923753};\\\", \\\"{x:1342,y:498,t:1527026923770};\\\", \\\"{x:1337,y:498,t:1527026923787};\\\", \\\"{x:1330,y:498,t:1527026923803};\\\", \\\"{x:1321,y:498,t:1527026923820};\\\", \\\"{x:1318,y:499,t:1527026923839};\\\", \\\"{x:1317,y:502,t:1527026924143};\\\", \\\"{x:1317,y:506,t:1527026924155};\\\", \\\"{x:1318,y:514,t:1527026924172};\\\", \\\"{x:1319,y:519,t:1527026924187};\\\", \\\"{x:1322,y:524,t:1527026924204};\\\", \\\"{x:1323,y:529,t:1527026924222};\\\", \\\"{x:1323,y:532,t:1527026924238};\\\", \\\"{x:1324,y:533,t:1527026924254};\\\", \\\"{x:1324,y:536,t:1527026924272};\\\", \\\"{x:1324,y:538,t:1527026924287};\\\", \\\"{x:1324,y:543,t:1527026924304};\\\", \\\"{x:1324,y:547,t:1527026924322};\\\", \\\"{x:1324,y:552,t:1527026924339};\\\", \\\"{x:1324,y:556,t:1527026924354};\\\", \\\"{x:1324,y:561,t:1527026924371};\\\", \\\"{x:1324,y:567,t:1527026924389};\\\", \\\"{x:1324,y:572,t:1527026924404};\\\", \\\"{x:1324,y:580,t:1527026924422};\\\", \\\"{x:1324,y:586,t:1527026924438};\\\", \\\"{x:1322,y:588,t:1527026924455};\\\", \\\"{x:1322,y:593,t:1527026924471};\\\", \\\"{x:1321,y:601,t:1527026924489};\\\", \\\"{x:1318,y:608,t:1527026924504};\\\", \\\"{x:1317,y:622,t:1527026924522};\\\", \\\"{x:1316,y:635,t:1527026924539};\\\", \\\"{x:1314,y:646,t:1527026924557};\\\", \\\"{x:1313,y:655,t:1527026924572};\\\", \\\"{x:1313,y:664,t:1527026924589};\\\", \\\"{x:1312,y:678,t:1527026924606};\\\", \\\"{x:1311,y:684,t:1527026924622};\\\", \\\"{x:1309,y:688,t:1527026924638};\\\", \\\"{x:1309,y:691,t:1527026924656};\\\", \\\"{x:1309,y:696,t:1527026924671};\\\", \\\"{x:1309,y:700,t:1527026924689};\\\", \\\"{x:1309,y:703,t:1527026924705};\\\", \\\"{x:1308,y:709,t:1527026924723};\\\", \\\"{x:1307,y:713,t:1527026924738};\\\", \\\"{x:1306,y:716,t:1527026924756};\\\", \\\"{x:1306,y:717,t:1527026924773};\\\", \\\"{x:1306,y:720,t:1527026924788};\\\", \\\"{x:1306,y:727,t:1527026924805};\\\", \\\"{x:1306,y:733,t:1527026924822};\\\", \\\"{x:1304,y:740,t:1527026924839};\\\", \\\"{x:1303,y:747,t:1527026924855};\\\", \\\"{x:1302,y:750,t:1527026924873};\\\", \\\"{x:1300,y:754,t:1527026924888};\\\", \\\"{x:1300,y:756,t:1527026924905};\\\", \\\"{x:1300,y:759,t:1527026924923};\\\", \\\"{x:1302,y:765,t:1527026924939};\\\", \\\"{x:1303,y:773,t:1527026924956};\\\", \\\"{x:1305,y:781,t:1527026924973};\\\", \\\"{x:1306,y:790,t:1527026924990};\\\", \\\"{x:1307,y:798,t:1527026925005};\\\", \\\"{x:1308,y:803,t:1527026925022};\\\", \\\"{x:1309,y:809,t:1527026925039};\\\", \\\"{x:1311,y:816,t:1527026925055};\\\", \\\"{x:1314,y:824,t:1527026925072};\\\", \\\"{x:1318,y:837,t:1527026925090};\\\", \\\"{x:1320,y:848,t:1527026925106};\\\", \\\"{x:1320,y:859,t:1527026925123};\\\", \\\"{x:1320,y:871,t:1527026925140};\\\", \\\"{x:1320,y:883,t:1527026925157};\\\", \\\"{x:1320,y:894,t:1527026925172};\\\", \\\"{x:1320,y:911,t:1527026925189};\\\", \\\"{x:1323,y:919,t:1527026925206};\\\", \\\"{x:1323,y:924,t:1527026925222};\\\", \\\"{x:1323,y:929,t:1527026925240};\\\", \\\"{x:1323,y:934,t:1527026925257};\\\", \\\"{x:1323,y:939,t:1527026925272};\\\", \\\"{x:1323,y:943,t:1527026925290};\\\", \\\"{x:1323,y:946,t:1527026925306};\\\", \\\"{x:1323,y:947,t:1527026925325};\\\", \\\"{x:1323,y:948,t:1527026925350};\\\", \\\"{x:1323,y:949,t:1527026925357};\\\", \\\"{x:1323,y:951,t:1527026925374};\\\", \\\"{x:1323,y:953,t:1527026925389};\\\", \\\"{x:1323,y:956,t:1527026925406};\\\", \\\"{x:1323,y:958,t:1527026925424};\\\", \\\"{x:1323,y:959,t:1527026925440};\\\", \\\"{x:1322,y:959,t:1527026925502};\\\", \\\"{x:1321,y:959,t:1527026925510};\\\", \\\"{x:1320,y:959,t:1527026925630};\\\", \\\"{x:1319,y:961,t:1527026925641};\\\", \\\"{x:1318,y:961,t:1527026925657};\\\", \\\"{x:1317,y:963,t:1527026925674};\\\", \\\"{x:1316,y:963,t:1527026925690};\\\", \\\"{x:1316,y:964,t:1527026925707};\\\", \\\"{x:1316,y:965,t:1527026925766};\\\", \\\"{x:1316,y:967,t:1527026925773};\\\", \\\"{x:1316,y:968,t:1527026925790};\\\", \\\"{x:1314,y:968,t:1527026926958};\\\", \\\"{x:1314,y:961,t:1527026926975};\\\", \\\"{x:1314,y:957,t:1527026926992};\\\", \\\"{x:1313,y:953,t:1527026927009};\\\", \\\"{x:1312,y:945,t:1527026927025};\\\", \\\"{x:1310,y:937,t:1527026927043};\\\", \\\"{x:1309,y:932,t:1527026927059};\\\", \\\"{x:1309,y:929,t:1527026927075};\\\", \\\"{x:1308,y:926,t:1527026927093};\\\", \\\"{x:1308,y:925,t:1527026927110};\\\", \\\"{x:1307,y:925,t:1527026927125};\\\", \\\"{x:1307,y:923,t:1527026927143};\\\", \\\"{x:1307,y:922,t:1527026927160};\\\", \\\"{x:1307,y:920,t:1527026927176};\\\", \\\"{x:1307,y:916,t:1527026927192};\\\", \\\"{x:1307,y:912,t:1527026927210};\\\", \\\"{x:1307,y:909,t:1527026927226};\\\", \\\"{x:1307,y:906,t:1527026927243};\\\", \\\"{x:1307,y:902,t:1527026927260};\\\", \\\"{x:1307,y:900,t:1527026927277};\\\", \\\"{x:1307,y:898,t:1527026927293};\\\", \\\"{x:1307,y:895,t:1527026927309};\\\", \\\"{x:1306,y:893,t:1527026927326};\\\", \\\"{x:1306,y:892,t:1527026927342};\\\", \\\"{x:1305,y:890,t:1527026927359};\\\", \\\"{x:1304,y:889,t:1527026927377};\\\", \\\"{x:1304,y:887,t:1527026927398};\\\", \\\"{x:1304,y:885,t:1527026927414};\\\", \\\"{x:1304,y:884,t:1527026927427};\\\", \\\"{x:1304,y:883,t:1527026927443};\\\", \\\"{x:1304,y:880,t:1527026927460};\\\", \\\"{x:1304,y:879,t:1527026927477};\\\", \\\"{x:1304,y:878,t:1527026927493};\\\", \\\"{x:1304,y:877,t:1527026927509};\\\", \\\"{x:1304,y:875,t:1527026927678};\\\", \\\"{x:1304,y:873,t:1527026927694};\\\", \\\"{x:1303,y:873,t:1527026927717};\\\", \\\"{x:1303,y:872,t:1527026927758};\\\", \\\"{x:1302,y:871,t:1527026927854};\\\", \\\"{x:1302,y:870,t:1527026927862};\\\", \\\"{x:1301,y:870,t:1527026927886};\\\", \\\"{x:1300,y:870,t:1527026927894};\\\", \\\"{x:1300,y:869,t:1527026927926};\\\", \\\"{x:1299,y:868,t:1527026927941};\\\", \\\"{x:1298,y:867,t:1527026927949};\\\", \\\"{x:1297,y:867,t:1527026927961};\\\", \\\"{x:1294,y:865,t:1527026927978};\\\", \\\"{x:1289,y:861,t:1527026927993};\\\", \\\"{x:1288,y:860,t:1527026928011};\\\", \\\"{x:1287,y:859,t:1527026928027};\\\", \\\"{x:1286,y:858,t:1527026928048};\\\", \\\"{x:1286,y:857,t:1527026928068};\\\", \\\"{x:1286,y:856,t:1527026928085};\\\", \\\"{x:1286,y:855,t:1527026928100};\\\", \\\"{x:1286,y:854,t:1527026928133};\\\", \\\"{x:1286,y:853,t:1527026928148};\\\", \\\"{x:1286,y:852,t:1527026928173};\\\", \\\"{x:1286,y:850,t:1527026928366};\\\", \\\"{x:1286,y:849,t:1527026928430};\\\", \\\"{x:1286,y:848,t:1527026928444};\\\", \\\"{x:1286,y:845,t:1527026928461};\\\", \\\"{x:1286,y:841,t:1527026928478};\\\", \\\"{x:1286,y:838,t:1527026928494};\\\", \\\"{x:1287,y:834,t:1527026928511};\\\", \\\"{x:1289,y:830,t:1527026928529};\\\", \\\"{x:1290,y:828,t:1527026928545};\\\", \\\"{x:1291,y:827,t:1527026928562};\\\", \\\"{x:1293,y:826,t:1527026928579};\\\", \\\"{x:1294,y:824,t:1527026928595};\\\", \\\"{x:1298,y:823,t:1527026928612};\\\", \\\"{x:1303,y:819,t:1527026928628};\\\", \\\"{x:1309,y:818,t:1527026928645};\\\", \\\"{x:1317,y:813,t:1527026928661};\\\", \\\"{x:1320,y:812,t:1527026928679};\\\", \\\"{x:1326,y:809,t:1527026928695};\\\", \\\"{x:1337,y:807,t:1527026928711};\\\", \\\"{x:1351,y:804,t:1527026928729};\\\", \\\"{x:1373,y:799,t:1527026928745};\\\", \\\"{x:1395,y:796,t:1527026928761};\\\", \\\"{x:1412,y:791,t:1527026928779};\\\", \\\"{x:1421,y:787,t:1527026928796};\\\", \\\"{x:1429,y:786,t:1527026928811};\\\", \\\"{x:1433,y:785,t:1527026928829};\\\", \\\"{x:1434,y:784,t:1527026928846};\\\", \\\"{x:1436,y:783,t:1527026928862};\\\", \\\"{x:1437,y:781,t:1527026928878};\\\", \\\"{x:1438,y:780,t:1527026928896};\\\", \\\"{x:1438,y:777,t:1527026928933};\\\", \\\"{x:1440,y:776,t:1527026928945};\\\", \\\"{x:1446,y:766,t:1527026928963};\\\", \\\"{x:1458,y:753,t:1527026928979};\\\", \\\"{x:1476,y:736,t:1527026928996};\\\", \\\"{x:1498,y:722,t:1527026929012};\\\", \\\"{x:1513,y:718,t:1527026929028};\\\", \\\"{x:1521,y:718,t:1527026929049};\\\", \\\"{x:1522,y:719,t:1527026929861};\\\", \\\"{x:1522,y:722,t:1527026929869};\\\", \\\"{x:1519,y:727,t:1527026929880};\\\", \\\"{x:1519,y:731,t:1527026929896};\\\", \\\"{x:1518,y:735,t:1527026929913};\\\", \\\"{x:1516,y:739,t:1527026929930};\\\", \\\"{x:1516,y:740,t:1527026929949};\\\", \\\"{x:1515,y:741,t:1527026930293};\\\", \\\"{x:1514,y:741,t:1527026930317};\\\", \\\"{x:1513,y:742,t:1527026930331};\\\", \\\"{x:1512,y:743,t:1527026930348};\\\", \\\"{x:1509,y:746,t:1527026930365};\\\", \\\"{x:1508,y:747,t:1527026930382};\\\", \\\"{x:1506,y:749,t:1527026930398};\\\", \\\"{x:1506,y:750,t:1527026931678};\\\", \\\"{x:1504,y:754,t:1527026931694};\\\", \\\"{x:1503,y:756,t:1527026931701};\\\", \\\"{x:1501,y:759,t:1527026931716};\\\", \\\"{x:1493,y:769,t:1527026931733};\\\", \\\"{x:1489,y:776,t:1527026931749};\\\", \\\"{x:1487,y:781,t:1527026931766};\\\", \\\"{x:1485,y:784,t:1527026931783};\\\", \\\"{x:1485,y:786,t:1527026931800};\\\", \\\"{x:1485,y:789,t:1527026931816};\\\", \\\"{x:1483,y:791,t:1527026931833};\\\", \\\"{x:1483,y:793,t:1527026931849};\\\", \\\"{x:1481,y:796,t:1527026931866};\\\", \\\"{x:1479,y:801,t:1527026931883};\\\", \\\"{x:1477,y:806,t:1527026931900};\\\", \\\"{x:1477,y:811,t:1527026931916};\\\", \\\"{x:1477,y:815,t:1527026931933};\\\", \\\"{x:1477,y:819,t:1527026931950};\\\", \\\"{x:1477,y:820,t:1527026931966};\\\", \\\"{x:1477,y:821,t:1527026931989};\\\", \\\"{x:1477,y:823,t:1527026932652};\\\", \\\"{x:1477,y:825,t:1527026932669};\\\", \\\"{x:1477,y:827,t:1527026932684};\\\", \\\"{x:1477,y:831,t:1527026932701};\\\", \\\"{x:1477,y:834,t:1527026932718};\\\", \\\"{x:1477,y:835,t:1527026932735};\\\", \\\"{x:1477,y:836,t:1527026932751};\\\", \\\"{x:1477,y:837,t:1527026932769};\\\", \\\"{x:1477,y:836,t:1527026933118};\\\", \\\"{x:1477,y:835,t:1527026933136};\\\", \\\"{x:1477,y:832,t:1527026933153};\\\", \\\"{x:1477,y:829,t:1527026933168};\\\", \\\"{x:1479,y:826,t:1527026933185};\\\", \\\"{x:1480,y:824,t:1527026933204};\\\", \\\"{x:1482,y:824,t:1527026933219};\\\", \\\"{x:1481,y:824,t:1527026933405};\\\", \\\"{x:1477,y:824,t:1527026933419};\\\", \\\"{x:1470,y:824,t:1527026933436};\\\", \\\"{x:1445,y:826,t:1527026933453};\\\", \\\"{x:1415,y:826,t:1527026933469};\\\", \\\"{x:1365,y:826,t:1527026933487};\\\", \\\"{x:1311,y:819,t:1527026933503};\\\", \\\"{x:1272,y:808,t:1527026933520};\\\", \\\"{x:1227,y:794,t:1527026933537};\\\", \\\"{x:1185,y:781,t:1527026933553};\\\", \\\"{x:1137,y:766,t:1527026933570};\\\", \\\"{x:1085,y:753,t:1527026933586};\\\", \\\"{x:1040,y:741,t:1527026933602};\\\", \\\"{x:998,y:728,t:1527026933619};\\\", \\\"{x:967,y:717,t:1527026933636};\\\", \\\"{x:936,y:707,t:1527026933652};\\\", \\\"{x:896,y:689,t:1527026933669};\\\", \\\"{x:872,y:680,t:1527026933686};\\\", \\\"{x:851,y:670,t:1527026933703};\\\", \\\"{x:827,y:663,t:1527026933720};\\\", \\\"{x:800,y:656,t:1527026933736};\\\", \\\"{x:763,y:649,t:1527026933754};\\\", \\\"{x:733,y:644,t:1527026933769};\\\", \\\"{x:707,y:639,t:1527026933787};\\\", \\\"{x:683,y:637,t:1527026933803};\\\", \\\"{x:661,y:633,t:1527026933819};\\\", \\\"{x:643,y:631,t:1527026933833};\\\", \\\"{x:635,y:631,t:1527026933850};\\\", \\\"{x:633,y:631,t:1527026934029};\\\", \\\"{x:632,y:631,t:1527026934037};\\\", \\\"{x:630,y:630,t:1527026934050};\\\", \\\"{x:627,y:625,t:1527026934067};\\\", \\\"{x:624,y:622,t:1527026934084};\\\", \\\"{x:623,y:619,t:1527026934100};\\\", \\\"{x:622,y:616,t:1527026934116};\\\", \\\"{x:622,y:613,t:1527026934133};\\\", \\\"{x:622,y:610,t:1527026934151};\\\", \\\"{x:621,y:608,t:1527026934167};\\\", \\\"{x:620,y:606,t:1527026934184};\\\", \\\"{x:620,y:605,t:1527026934200};\\\", \\\"{x:621,y:605,t:1527026934468};\\\", \\\"{x:622,y:605,t:1527026934484};\\\", \\\"{x:630,y:611,t:1527026934501};\\\", \\\"{x:678,y:649,t:1527026934517};\\\", \\\"{x:744,y:675,t:1527026934535};\\\", \\\"{x:818,y:701,t:1527026934550};\\\", \\\"{x:885,y:711,t:1527026934567};\\\", \\\"{x:950,y:723,t:1527026934584};\\\", \\\"{x:1012,y:733,t:1527026934600};\\\", \\\"{x:1064,y:748,t:1527026934617};\\\", \\\"{x:1098,y:757,t:1527026934634};\\\", \\\"{x:1132,y:767,t:1527026934650};\\\", \\\"{x:1155,y:776,t:1527026934667};\\\", \\\"{x:1178,y:786,t:1527026934685};\\\", \\\"{x:1198,y:796,t:1527026934700};\\\", \\\"{x:1225,y:807,t:1527026934717};\\\", \\\"{x:1243,y:814,t:1527026934734};\\\", \\\"{x:1257,y:820,t:1527026934751};\\\", \\\"{x:1273,y:824,t:1527026934767};\\\", \\\"{x:1289,y:829,t:1527026934784};\\\", \\\"{x:1308,y:832,t:1527026934802};\\\", \\\"{x:1334,y:838,t:1527026934817};\\\", \\\"{x:1358,y:842,t:1527026934835};\\\", \\\"{x:1381,y:845,t:1527026934851};\\\", \\\"{x:1399,y:847,t:1527026934867};\\\", \\\"{x:1427,y:850,t:1527026934884};\\\", \\\"{x:1439,y:850,t:1527026934900};\\\", \\\"{x:1452,y:850,t:1527026934917};\\\", \\\"{x:1462,y:850,t:1527026934934};\\\", \\\"{x:1468,y:850,t:1527026934952};\\\", \\\"{x:1469,y:850,t:1527026934967};\\\", \\\"{x:1471,y:850,t:1527026934985};\\\", \\\"{x:1472,y:849,t:1527026935002};\\\", \\\"{x:1473,y:849,t:1527026935254};\\\", \\\"{x:1473,y:848,t:1527026935269};\\\", \\\"{x:1474,y:846,t:1527026935342};\\\", \\\"{x:1475,y:845,t:1527026935358};\\\", \\\"{x:1475,y:844,t:1527026935374};\\\", \\\"{x:1475,y:843,t:1527026935385};\\\", \\\"{x:1475,y:841,t:1527026935402};\\\", \\\"{x:1475,y:840,t:1527026935422};\\\", \\\"{x:1476,y:839,t:1527026935435};\\\", \\\"{x:1476,y:838,t:1527026935452};\\\", \\\"{x:1477,y:838,t:1527026935470};\\\", \\\"{x:1477,y:837,t:1527026935622};\\\", \\\"{x:1477,y:836,t:1527026935652};\\\", \\\"{x:1477,y:835,t:1527026935677};\\\", \\\"{x:1478,y:835,t:1527026935692};\\\", \\\"{x:1479,y:834,t:1527026941598};\\\", \\\"{x:1479,y:833,t:1527026941623};\\\", \\\"{x:1480,y:831,t:1527026941640};\\\", \\\"{x:1477,y:831,t:1527026955701};\\\", \\\"{x:1476,y:831,t:1527026955718};\\\", \\\"{x:1473,y:831,t:1527026955736};\\\", \\\"{x:1471,y:832,t:1527026955752};\\\", \\\"{x:1470,y:832,t:1527026955768};\\\", \\\"{x:1469,y:832,t:1527026958438};\\\", \\\"{x:1464,y:835,t:1527026958453};\\\", \\\"{x:1449,y:838,t:1527026958471};\\\", \\\"{x:1433,y:840,t:1527026958487};\\\", \\\"{x:1410,y:843,t:1527026958504};\\\", \\\"{x:1395,y:846,t:1527026958521};\\\", \\\"{x:1382,y:848,t:1527026958537};\\\", \\\"{x:1376,y:850,t:1527026958554};\\\", \\\"{x:1368,y:850,t:1527026958570};\\\", \\\"{x:1362,y:850,t:1527026958587};\\\", \\\"{x:1356,y:850,t:1527026958604};\\\", \\\"{x:1345,y:850,t:1527026958621};\\\", \\\"{x:1338,y:850,t:1527026958638};\\\", \\\"{x:1328,y:850,t:1527026958654};\\\", \\\"{x:1276,y:850,t:1527026958671};\\\", \\\"{x:1193,y:839,t:1527026958687};\\\", \\\"{x:1094,y:829,t:1527026958704};\\\", \\\"{x:964,y:816,t:1527026958721};\\\", \\\"{x:827,y:808,t:1527026958736};\\\", \\\"{x:696,y:802,t:1527026958754};\\\", \\\"{x:591,y:802,t:1527026958771};\\\", \\\"{x:499,y:800,t:1527026958788};\\\", \\\"{x:449,y:800,t:1527026958804};\\\", \\\"{x:409,y:800,t:1527026958821};\\\", \\\"{x:399,y:800,t:1527026958837};\\\", \\\"{x:399,y:799,t:1527026958924};\\\", \\\"{x:401,y:799,t:1527026958937};\\\", \\\"{x:406,y:796,t:1527026958953};\\\", \\\"{x:410,y:794,t:1527026958970};\\\", \\\"{x:415,y:792,t:1527026958987};\\\", \\\"{x:424,y:788,t:1527026959003};\\\", \\\"{x:441,y:782,t:1527026959020};\\\", \\\"{x:451,y:777,t:1527026959037};\\\", \\\"{x:462,y:773,t:1527026959053};\\\", \\\"{x:474,y:767,t:1527026959070};\\\", \\\"{x:485,y:761,t:1527026959087};\\\", \\\"{x:497,y:752,t:1527026959103};\\\", \\\"{x:513,y:745,t:1527026959121};\\\", \\\"{x:527,y:738,t:1527026959137};\\\", \\\"{x:534,y:733,t:1527026959154};\\\", \\\"{x:536,y:732,t:1527026959170};\\\", \\\"{x:537,y:731,t:1527026959187};\\\", \\\"{x:538,y:731,t:1527026959203};\\\", \\\"{x:538,y:730,t:1527026959252};\\\", \\\"{x:539,y:730,t:1527026959268};\\\", \\\"{x:539,y:729,t:1527026959333};\\\", \\\"{x:539,y:728,t:1527026959677};\\\", \\\"{x:542,y:731,t:1527026959688};\\\", \\\"{x:548,y:741,t:1527026959704};\\\", \\\"{x:551,y:746,t:1527026959721};\\\", \\\"{x:556,y:753,t:1527026959737};\\\", \\\"{x:560,y:758,t:1527026959754};\\\", \\\"{x:570,y:765,t:1527026959772};\\\", \\\"{x:579,y:769,t:1527026959788};\\\", \\\"{x:597,y:777,t:1527026959804};\\\", \\\"{x:608,y:780,t:1527026959822};\\\", \\\"{x:618,y:781,t:1527026959837};\\\", \\\"{x:625,y:781,t:1527026959854};\\\", \\\"{x:633,y:781,t:1527026959871};\\\", \\\"{x:638,y:780,t:1527026959888};\\\", \\\"{x:649,y:769,t:1527026959904};\\\", \\\"{x:658,y:761,t:1527026959922};\\\", \\\"{x:668,y:749,t:1527026959939};\\\", \\\"{x:675,y:740,t:1527026959954};\\\", \\\"{x:683,y:729,t:1527026959971};\\\", \\\"{x:689,y:715,t:1527026959988};\\\", \\\"{x:692,y:707,t:1527026960004};\\\", \\\"{x:694,y:700,t:1527026960021};\\\", \\\"{x:695,y:698,t:1527026960038};\\\", \\\"{x:695,y:696,t:1527026960055};\\\", \\\"{x:696,y:692,t:1527026960071};\\\", \\\"{x:696,y:687,t:1527026960088};\\\", \\\"{x:696,y:680,t:1527026960105};\\\", \\\"{x:696,y:671,t:1527026960121};\\\", \\\"{x:695,y:659,t:1527026960138};\\\", \\\"{x:693,y:649,t:1527026960155};\\\", \\\"{x:684,y:634,t:1527026960172};\\\", \\\"{x:651,y:592,t:1527026960188};\\\", \\\"{x:600,y:551,t:1527026960205};\\\", \\\"{x:524,y:511,t:1527026960222};\\\", \\\"{x:458,y:482,t:1527026960239};\\\", \\\"{x:392,y:466,t:1527026960256};\\\", \\\"{x:345,y:454,t:1527026960271};\\\", \\\"{x:313,y:448,t:1527026960288};\\\", \\\"{x:301,y:446,t:1527026960305};\\\", \\\"{x:300,y:446,t:1527026960322};\\\", \\\"{x:299,y:445,t:1527026960429};\\\", \\\"{x:299,y:444,t:1527026960472};\\\", \\\"{x:299,y:442,t:1527026960488};\\\", \\\"{x:300,y:440,t:1527026960505};\\\", \\\"{x:300,y:439,t:1527026960524};\\\", \\\"{x:301,y:438,t:1527026960539};\\\" ] }, { \\\"rt\\\": 130962, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 425075, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-I -O -O -O -F -O -O -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:301,y:437,t:1527026960640};\\\", \\\"{x:303,y:435,t:1527026961124};\\\", \\\"{x:308,y:433,t:1527026961139};\\\", \\\"{x:319,y:432,t:1527026961155};\\\", \\\"{x:369,y:438,t:1527026961172};\\\", \\\"{x:428,y:456,t:1527026961189};\\\", \\\"{x:494,y:485,t:1527026961205};\\\", \\\"{x:550,y:512,t:1527026961223};\\\", \\\"{x:583,y:523,t:1527026961240};\\\", \\\"{x:601,y:527,t:1527026961255};\\\", \\\"{x:607,y:527,t:1527026961272};\\\", \\\"{x:610,y:527,t:1527026961289};\\\", \\\"{x:612,y:529,t:1527026961524};\\\", \\\"{x:613,y:534,t:1527026961539};\\\", \\\"{x:615,y:551,t:1527026961556};\\\", \\\"{x:619,y:589,t:1527026961572};\\\", \\\"{x:620,y:612,t:1527026961590};\\\", \\\"{x:619,y:632,t:1527026961607};\\\", \\\"{x:618,y:642,t:1527026961623};\\\", \\\"{x:615,y:646,t:1527026961640};\\\", \\\"{x:616,y:649,t:1527026961781};\\\", \\\"{x:618,y:652,t:1527026961790};\\\", \\\"{x:625,y:663,t:1527026961808};\\\", \\\"{x:633,y:674,t:1527026961822};\\\", \\\"{x:642,y:684,t:1527026961839};\\\", \\\"{x:652,y:695,t:1527026961856};\\\", \\\"{x:662,y:706,t:1527026961872};\\\", \\\"{x:673,y:720,t:1527026961888};\\\", \\\"{x:680,y:728,t:1527026961905};\\\", \\\"{x:685,y:732,t:1527026961922};\\\", \\\"{x:690,y:738,t:1527026961938};\\\", \\\"{x:692,y:740,t:1527026961955};\\\", \\\"{x:693,y:742,t:1527026961972};\\\", \\\"{x:696,y:746,t:1527026961988};\\\", \\\"{x:698,y:750,t:1527026962005};\\\", \\\"{x:700,y:753,t:1527026962021};\\\", \\\"{x:702,y:756,t:1527026962039};\\\", \\\"{x:704,y:759,t:1527026962055};\\\", \\\"{x:705,y:761,t:1527026962072};\\\", \\\"{x:706,y:762,t:1527026962089};\\\", \\\"{x:707,y:764,t:1527026962106};\\\", \\\"{x:707,y:766,t:1527026964838};\\\", \\\"{x:707,y:767,t:1527026964849};\\\", \\\"{x:706,y:769,t:1527026964866};\\\", \\\"{x:704,y:773,t:1527026964882};\\\", \\\"{x:702,y:777,t:1527026964898};\\\", \\\"{x:700,y:780,t:1527026964916};\\\", \\\"{x:699,y:780,t:1527026964931};\\\", \\\"{x:698,y:781,t:1527026967312};\\\", \\\"{x:695,y:783,t:1527026967329};\\\", \\\"{x:694,y:784,t:1527026967359};\\\", \\\"{x:693,y:784,t:1527026967455};\\\", \\\"{x:692,y:784,t:1527026967495};\\\", \\\"{x:691,y:784,t:1527026967518};\\\", \\\"{x:690,y:784,t:1527026967542};\\\", \\\"{x:689,y:784,t:1527026967566};\\\", \\\"{x:688,y:785,t:1527026967578};\\\", \\\"{x:687,y:786,t:1527026967595};\\\", \\\"{x:686,y:786,t:1527026967663};\\\", \\\"{x:685,y:787,t:1527026967679};\\\", \\\"{x:681,y:788,t:1527026967695};\\\", \\\"{x:680,y:788,t:1527026968887};\\\", \\\"{x:678,y:788,t:1527026968968};\\\", \\\"{x:678,y:789,t:1527026970760};\\\", \\\"{x:682,y:790,t:1527026970771};\\\", \\\"{x:748,y:790,t:1527026970789};\\\", \\\"{x:912,y:789,t:1527026970805};\\\", \\\"{x:1156,y:775,t:1527026970822};\\\", \\\"{x:1312,y:787,t:1527026970838};\\\", \\\"{x:1365,y:803,t:1527026970855};\\\", \\\"{x:1395,y:836,t:1527026970871};\\\", \\\"{x:1398,y:843,t:1527026970888};\\\", \\\"{x:1398,y:857,t:1527026970905};\\\", \\\"{x:1398,y:870,t:1527026970922};\\\", \\\"{x:1398,y:872,t:1527026970938};\\\", \\\"{x:1397,y:872,t:1527026970955};\\\", \\\"{x:1395,y:872,t:1527026970971};\\\", \\\"{x:1387,y:872,t:1527026970988};\\\", \\\"{x:1383,y:873,t:1527026971005};\\\", \\\"{x:1382,y:874,t:1527026971021};\\\", \\\"{x:1359,y:885,t:1527026971038};\\\", \\\"{x:1346,y:905,t:1527026971055};\\\", \\\"{x:1343,y:927,t:1527026971071};\\\", \\\"{x:1347,y:936,t:1527026971088};\\\", \\\"{x:1348,y:937,t:1527026971142};\\\", \\\"{x:1347,y:939,t:1527026971255};\\\", \\\"{x:1342,y:939,t:1527026971270};\\\", \\\"{x:1328,y:939,t:1527026971286};\\\", \\\"{x:1315,y:939,t:1527026971303};\\\", \\\"{x:1313,y:939,t:1527026971320};\\\", \\\"{x:1310,y:939,t:1527026971336};\\\", \\\"{x:1306,y:940,t:1527026971354};\\\", \\\"{x:1305,y:941,t:1527026971370};\\\", \\\"{x:1305,y:942,t:1527026971448};\\\", \\\"{x:1305,y:943,t:1527026971455};\\\", \\\"{x:1305,y:946,t:1527026971528};\\\", \\\"{x:1302,y:947,t:1527026971543};\\\", \\\"{x:1296,y:950,t:1527026971553};\\\", \\\"{x:1287,y:952,t:1527026971570};\\\", \\\"{x:1274,y:955,t:1527026971587};\\\", \\\"{x:1257,y:957,t:1527026971603};\\\", \\\"{x:1237,y:960,t:1527026971619};\\\", \\\"{x:1222,y:963,t:1527026971637};\\\", \\\"{x:1219,y:964,t:1527026971653};\\\", \\\"{x:1218,y:965,t:1527026971671};\\\", \\\"{x:1221,y:965,t:1527026971776};\\\", \\\"{x:1222,y:965,t:1527026971786};\\\", \\\"{x:1229,y:961,t:1527026971802};\\\", \\\"{x:1238,y:959,t:1527026971818};\\\", \\\"{x:1247,y:955,t:1527026971836};\\\", \\\"{x:1252,y:952,t:1527026971853};\\\", \\\"{x:1253,y:951,t:1527026971869};\\\", \\\"{x:1254,y:950,t:1527026971927};\\\", \\\"{x:1255,y:950,t:1527026971943};\\\", \\\"{x:1257,y:950,t:1527026971953};\\\", \\\"{x:1262,y:950,t:1527026971969};\\\", \\\"{x:1263,y:952,t:1527026971986};\\\", \\\"{x:1265,y:953,t:1527026972144};\\\", \\\"{x:1266,y:953,t:1527026972183};\\\", \\\"{x:1267,y:953,t:1527026972191};\\\", \\\"{x:1268,y:953,t:1527026972223};\\\", \\\"{x:1269,y:953,t:1527026972239};\\\", \\\"{x:1271,y:951,t:1527026972252};\\\", \\\"{x:1275,y:947,t:1527026972268};\\\", \\\"{x:1279,y:944,t:1527026972285};\\\", \\\"{x:1286,y:940,t:1527026972302};\\\", \\\"{x:1294,y:934,t:1527026972317};\\\", \\\"{x:1313,y:928,t:1527026972336};\\\", \\\"{x:1326,y:921,t:1527026972351};\\\", \\\"{x:1336,y:918,t:1527026972368};\\\", \\\"{x:1341,y:914,t:1527026972385};\\\", \\\"{x:1344,y:914,t:1527026972401};\\\", \\\"{x:1342,y:916,t:1527026972704};\\\", \\\"{x:1339,y:917,t:1527026972717};\\\", \\\"{x:1326,y:925,t:1527026972734};\\\", \\\"{x:1306,y:939,t:1527026972751};\\\", \\\"{x:1301,y:945,t:1527026972767};\\\", \\\"{x:1299,y:948,t:1527026972784};\\\", \\\"{x:1298,y:949,t:1527026972801};\\\", \\\"{x:1299,y:951,t:1527026972951};\\\", \\\"{x:1300,y:956,t:1527026972966};\\\", \\\"{x:1301,y:960,t:1527026972983};\\\", \\\"{x:1301,y:964,t:1527026972999};\\\", \\\"{x:1301,y:969,t:1527026973016};\\\", \\\"{x:1301,y:972,t:1527026973032};\\\", \\\"{x:1301,y:974,t:1527026973049};\\\", \\\"{x:1301,y:977,t:1527026973066};\\\", \\\"{x:1300,y:978,t:1527026973519};\\\", \\\"{x:1299,y:978,t:1527026973543};\\\", \\\"{x:1298,y:978,t:1527026973567};\\\", \\\"{x:1297,y:978,t:1527026973584};\\\", \\\"{x:1297,y:977,t:1527026973599};\\\", \\\"{x:1295,y:976,t:1527026973615};\\\", \\\"{x:1293,y:976,t:1527026973632};\\\", \\\"{x:1292,y:975,t:1527026973648};\\\", \\\"{x:1291,y:975,t:1527026973665};\\\", \\\"{x:1290,y:974,t:1527026973682};\\\", \\\"{x:1289,y:973,t:1527026973711};\\\", \\\"{x:1287,y:973,t:1527026973839};\\\", \\\"{x:1286,y:973,t:1527026973847};\\\", \\\"{x:1282,y:975,t:1527026973865};\\\", \\\"{x:1279,y:975,t:1527026973881};\\\", \\\"{x:1275,y:978,t:1527026973898};\\\", \\\"{x:1274,y:980,t:1527026973915};\\\", \\\"{x:1274,y:978,t:1527026974023};\\\", \\\"{x:1276,y:973,t:1527026974031};\\\", \\\"{x:1283,y:959,t:1527026974048};\\\", \\\"{x:1292,y:939,t:1527026974064};\\\", \\\"{x:1300,y:913,t:1527026974080};\\\", \\\"{x:1312,y:868,t:1527026974097};\\\", \\\"{x:1320,y:804,t:1527026974113};\\\", \\\"{x:1331,y:726,t:1527026974130};\\\", \\\"{x:1343,y:659,t:1527026974146};\\\", \\\"{x:1361,y:590,t:1527026974164};\\\", \\\"{x:1386,y:524,t:1527026974181};\\\", \\\"{x:1401,y:479,t:1527026974197};\\\", \\\"{x:1408,y:454,t:1527026974214};\\\", \\\"{x:1411,y:440,t:1527026974231};\\\", \\\"{x:1411,y:437,t:1527026974247};\\\", \\\"{x:1408,y:433,t:1527026974263};\\\", \\\"{x:1400,y:430,t:1527026974280};\\\", \\\"{x:1398,y:429,t:1527026974297};\\\", \\\"{x:1395,y:428,t:1527026974314};\\\", \\\"{x:1394,y:427,t:1527026974330};\\\", \\\"{x:1391,y:426,t:1527026974347};\\\", \\\"{x:1383,y:423,t:1527026974364};\\\", \\\"{x:1375,y:417,t:1527026974380};\\\", \\\"{x:1367,y:412,t:1527026974397};\\\", \\\"{x:1362,y:411,t:1527026974413};\\\", \\\"{x:1359,y:409,t:1527026974430};\\\", \\\"{x:1358,y:409,t:1527026974447};\\\", \\\"{x:1354,y:409,t:1527026974464};\\\", \\\"{x:1351,y:417,t:1527026974480};\\\", \\\"{x:1349,y:427,t:1527026974496};\\\", \\\"{x:1347,y:440,t:1527026974512};\\\", \\\"{x:1345,y:449,t:1527026974529};\\\", \\\"{x:1344,y:455,t:1527026974546};\\\", \\\"{x:1343,y:463,t:1527026974562};\\\", \\\"{x:1343,y:470,t:1527026974580};\\\", \\\"{x:1343,y:480,t:1527026974595};\\\", \\\"{x:1341,y:488,t:1527026974612};\\\", \\\"{x:1336,y:499,t:1527026974629};\\\", \\\"{x:1331,y:506,t:1527026974646};\\\", \\\"{x:1326,y:509,t:1527026974663};\\\", \\\"{x:1324,y:509,t:1527026974679};\\\", \\\"{x:1323,y:509,t:1527026974783};\\\", \\\"{x:1322,y:508,t:1527026974816};\\\", \\\"{x:1321,y:507,t:1527026974829};\\\", \\\"{x:1318,y:503,t:1527026974846};\\\", \\\"{x:1315,y:498,t:1527026974862};\\\", \\\"{x:1313,y:496,t:1527026974878};\\\", \\\"{x:1313,y:495,t:1527026974896};\\\", \\\"{x:1311,y:495,t:1527026974926};\\\", \\\"{x:1312,y:496,t:1527026975135};\\\", \\\"{x:1312,y:497,t:1527026975144};\\\", \\\"{x:1313,y:500,t:1527026975162};\\\", \\\"{x:1315,y:504,t:1527026975179};\\\", \\\"{x:1317,y:509,t:1527026975195};\\\", \\\"{x:1318,y:513,t:1527026975212};\\\", \\\"{x:1320,y:519,t:1527026975228};\\\", \\\"{x:1322,y:524,t:1527026975245};\\\", \\\"{x:1327,y:540,t:1527026975263};\\\", \\\"{x:1329,y:548,t:1527026975278};\\\", \\\"{x:1340,y:577,t:1527026975295};\\\", \\\"{x:1346,y:594,t:1527026975311};\\\", \\\"{x:1354,y:609,t:1527026975328};\\\", \\\"{x:1355,y:616,t:1527026975345};\\\", \\\"{x:1356,y:623,t:1527026975361};\\\", \\\"{x:1356,y:628,t:1527026975378};\\\", \\\"{x:1356,y:630,t:1527026975395};\\\", \\\"{x:1356,y:632,t:1527026975412};\\\", \\\"{x:1354,y:636,t:1527026975427};\\\", \\\"{x:1353,y:641,t:1527026975444};\\\", \\\"{x:1350,y:644,t:1527026975461};\\\", \\\"{x:1350,y:646,t:1527026975478};\\\", \\\"{x:1349,y:648,t:1527026975494};\\\", \\\"{x:1348,y:650,t:1527026975511};\\\", \\\"{x:1347,y:650,t:1527026975536};\\\", \\\"{x:1346,y:651,t:1527026975544};\\\", \\\"{x:1344,y:652,t:1527026975575};\\\", \\\"{x:1343,y:653,t:1527026975623};\\\", \\\"{x:1343,y:654,t:1527026975631};\\\", \\\"{x:1342,y:657,t:1527026975644};\\\", \\\"{x:1339,y:664,t:1527026975662};\\\", \\\"{x:1335,y:673,t:1527026975677};\\\", \\\"{x:1332,y:687,t:1527026975694};\\\", \\\"{x:1330,y:707,t:1527026975712};\\\", \\\"{x:1330,y:719,t:1527026975727};\\\", \\\"{x:1330,y:728,t:1527026975743};\\\", \\\"{x:1328,y:738,t:1527026975760};\\\", \\\"{x:1327,y:748,t:1527026975777};\\\", \\\"{x:1326,y:754,t:1527026975794};\\\", \\\"{x:1325,y:761,t:1527026975810};\\\", \\\"{x:1324,y:772,t:1527026975827};\\\", \\\"{x:1322,y:784,t:1527026975844};\\\", \\\"{x:1322,y:800,t:1527026975861};\\\", \\\"{x:1322,y:812,t:1527026975877};\\\", \\\"{x:1324,y:826,t:1527026975893};\\\", \\\"{x:1328,y:836,t:1527026975910};\\\", \\\"{x:1330,y:848,t:1527026975927};\\\", \\\"{x:1331,y:855,t:1527026975943};\\\", \\\"{x:1333,y:864,t:1527026975959};\\\", \\\"{x:1336,y:878,t:1527026975977};\\\", \\\"{x:1341,y:894,t:1527026975993};\\\", \\\"{x:1342,y:908,t:1527026976010};\\\", \\\"{x:1342,y:919,t:1527026976026};\\\", \\\"{x:1342,y:930,t:1527026976043};\\\", \\\"{x:1340,y:939,t:1527026976061};\\\", \\\"{x:1336,y:947,t:1527026976076};\\\", \\\"{x:1335,y:950,t:1527026976093};\\\", \\\"{x:1333,y:954,t:1527026976110};\\\", \\\"{x:1333,y:955,t:1527026976126};\\\", \\\"{x:1332,y:956,t:1527026976143};\\\", \\\"{x:1332,y:957,t:1527026976159};\\\", \\\"{x:1332,y:958,t:1527026976176};\\\", \\\"{x:1331,y:958,t:1527026976215};\\\", \\\"{x:1330,y:958,t:1527026976226};\\\", \\\"{x:1328,y:960,t:1527026976243};\\\", \\\"{x:1327,y:962,t:1527026976259};\\\", \\\"{x:1326,y:970,t:1527026976276};\\\", \\\"{x:1325,y:975,t:1527026976292};\\\", \\\"{x:1323,y:981,t:1527026976309};\\\", \\\"{x:1323,y:983,t:1527026976326};\\\", \\\"{x:1323,y:984,t:1527026976342};\\\", \\\"{x:1323,y:982,t:1527026976470};\\\", \\\"{x:1323,y:979,t:1527026976478};\\\", \\\"{x:1323,y:978,t:1527026976494};\\\", \\\"{x:1323,y:976,t:1527026976509};\\\", \\\"{x:1322,y:975,t:1527026976524};\\\", \\\"{x:1322,y:974,t:1527026976831};\\\", \\\"{x:1321,y:972,t:1527026976855};\\\", \\\"{x:1320,y:972,t:1527026976888};\\\", \\\"{x:1320,y:971,t:1527026977360};\\\", \\\"{x:1320,y:970,t:1527026977375};\\\", \\\"{x:1319,y:969,t:1527026977464};\\\", \\\"{x:1319,y:968,t:1527026979424};\\\", \\\"{x:1319,y:966,t:1527026979435};\\\", \\\"{x:1319,y:965,t:1527026979452};\\\", \\\"{x:1319,y:963,t:1527026979469};\\\", \\\"{x:1319,y:962,t:1527026979485};\\\", \\\"{x:1319,y:960,t:1527026979502};\\\", \\\"{x:1318,y:959,t:1527026979672};\\\", \\\"{x:1317,y:959,t:1527026979687};\\\", \\\"{x:1316,y:959,t:1527026979703};\\\", \\\"{x:1315,y:959,t:1527026979718};\\\", \\\"{x:1314,y:960,t:1527026979735};\\\", \\\"{x:1313,y:961,t:1527026979759};\\\", \\\"{x:1313,y:962,t:1527026980008};\\\", \\\"{x:1313,y:963,t:1527026980017};\\\", \\\"{x:1313,y:964,t:1527026980034};\\\", \\\"{x:1314,y:965,t:1527026980050};\\\", \\\"{x:1314,y:966,t:1527026980067};\\\", \\\"{x:1315,y:967,t:1527026980143};\\\", \\\"{x:1313,y:967,t:1527026987848};\\\", \\\"{x:1306,y:964,t:1527026987855};\\\", \\\"{x:1303,y:960,t:1527026987867};\\\", \\\"{x:1291,y:955,t:1527026987883};\\\", \\\"{x:1275,y:949,t:1527026987900};\\\", \\\"{x:1262,y:944,t:1527026987917};\\\", \\\"{x:1248,y:937,t:1527026987932};\\\", \\\"{x:1239,y:934,t:1527026987950};\\\", \\\"{x:1234,y:931,t:1527026987967};\\\", \\\"{x:1231,y:928,t:1527026987982};\\\", \\\"{x:1227,y:926,t:1527026987999};\\\", \\\"{x:1222,y:921,t:1527026988016};\\\", \\\"{x:1218,y:918,t:1527026988033};\\\", \\\"{x:1214,y:915,t:1527026988050};\\\", \\\"{x:1207,y:909,t:1527026988066};\\\", \\\"{x:1196,y:901,t:1527026988082};\\\", \\\"{x:1186,y:895,t:1527026988099};\\\", \\\"{x:1171,y:886,t:1527026988116};\\\", \\\"{x:1162,y:880,t:1527026988133};\\\", \\\"{x:1148,y:873,t:1527026988149};\\\", \\\"{x:1133,y:864,t:1527026988165};\\\", \\\"{x:1113,y:851,t:1527026988182};\\\", \\\"{x:1095,y:837,t:1527026988198};\\\", \\\"{x:1071,y:818,t:1527026988215};\\\", \\\"{x:1053,y:804,t:1527026988232};\\\", \\\"{x:1034,y:791,t:1527026988248};\\\", \\\"{x:1015,y:779,t:1527026988266};\\\", \\\"{x:996,y:764,t:1527026988282};\\\", \\\"{x:985,y:757,t:1527026988298};\\\", \\\"{x:977,y:750,t:1527026988315};\\\", \\\"{x:974,y:748,t:1527026988331};\\\", \\\"{x:971,y:745,t:1527026988348};\\\", \\\"{x:968,y:743,t:1527026988366};\\\", \\\"{x:967,y:743,t:1527026988382};\\\", \\\"{x:966,y:742,t:1527026988398};\\\", \\\"{x:966,y:743,t:1527026988816};\\\", \\\"{x:981,y:755,t:1527026988831};\\\", \\\"{x:1004,y:771,t:1527026988847};\\\", \\\"{x:1031,y:779,t:1527026988864};\\\", \\\"{x:1060,y:784,t:1527026988880};\\\", \\\"{x:1087,y:787,t:1527026988897};\\\", \\\"{x:1119,y:787,t:1527026988913};\\\", \\\"{x:1150,y:787,t:1527026988930};\\\", \\\"{x:1180,y:787,t:1527026988947};\\\", \\\"{x:1207,y:780,t:1527026988963};\\\", \\\"{x:1232,y:768,t:1527026988980};\\\", \\\"{x:1260,y:743,t:1527026988997};\\\", \\\"{x:1292,y:704,t:1527026989013};\\\", \\\"{x:1321,y:663,t:1527026989030};\\\", \\\"{x:1326,y:654,t:1527026989047};\\\", \\\"{x:1327,y:654,t:1527026989063};\\\", \\\"{x:1328,y:651,t:1527026989080};\\\", \\\"{x:1328,y:649,t:1527026989096};\\\", \\\"{x:1328,y:648,t:1527026989113};\\\", \\\"{x:1328,y:646,t:1527026989130};\\\", \\\"{x:1328,y:645,t:1527026989160};\\\", \\\"{x:1328,y:642,t:1527026989191};\\\", \\\"{x:1327,y:642,t:1527026989199};\\\", \\\"{x:1327,y:641,t:1527026989213};\\\", \\\"{x:1324,y:639,t:1527026989230};\\\", \\\"{x:1322,y:638,t:1527026989247};\\\", \\\"{x:1319,y:637,t:1527026989264};\\\", \\\"{x:1318,y:636,t:1527026989280};\\\", \\\"{x:1316,y:635,t:1527026989297};\\\", \\\"{x:1314,y:634,t:1527026989343};\\\", \\\"{x:1313,y:632,t:1527026989384};\\\", \\\"{x:1312,y:629,t:1527026989399};\\\", \\\"{x:1312,y:628,t:1527026989415};\\\", \\\"{x:1311,y:628,t:1527026989430};\\\", \\\"{x:1310,y:626,t:1527026989447};\\\", \\\"{x:1309,y:625,t:1527026989463};\\\", \\\"{x:1307,y:620,t:1527026989479};\\\", \\\"{x:1305,y:619,t:1527026989495};\\\", \\\"{x:1304,y:617,t:1527026989512};\\\", \\\"{x:1304,y:616,t:1527026989542};\\\", \\\"{x:1303,y:616,t:1527026989550};\\\", \\\"{x:1304,y:616,t:1527026990143};\\\", \\\"{x:1306,y:617,t:1527026990161};\\\", \\\"{x:1308,y:619,t:1527026990177};\\\", \\\"{x:1309,y:621,t:1527026990195};\\\", \\\"{x:1309,y:622,t:1527026990210};\\\", \\\"{x:1309,y:623,t:1527026990228};\\\", \\\"{x:1310,y:624,t:1527026990244};\\\", \\\"{x:1309,y:624,t:1527026990648};\\\", \\\"{x:1309,y:625,t:1527026992336};\\\", \\\"{x:1309,y:630,t:1527026992343};\\\", \\\"{x:1313,y:634,t:1527026992355};\\\", \\\"{x:1315,y:642,t:1527026992372};\\\", \\\"{x:1316,y:647,t:1527026992389};\\\", \\\"{x:1321,y:657,t:1527026992406};\\\", \\\"{x:1327,y:675,t:1527026992422};\\\", \\\"{x:1327,y:681,t:1527026992439};\\\", \\\"{x:1328,y:688,t:1527026992455};\\\", \\\"{x:1331,y:699,t:1527026992472};\\\", \\\"{x:1333,y:718,t:1527026992489};\\\", \\\"{x:1336,y:740,t:1527026992505};\\\", \\\"{x:1340,y:769,t:1527026992522};\\\", \\\"{x:1345,y:801,t:1527026992538};\\\", \\\"{x:1349,y:827,t:1527026992556};\\\", \\\"{x:1355,y:844,t:1527026992572};\\\", \\\"{x:1361,y:862,t:1527026992589};\\\", \\\"{x:1371,y:881,t:1527026992605};\\\", \\\"{x:1384,y:905,t:1527026992623};\\\", \\\"{x:1391,y:918,t:1527026992639};\\\", \\\"{x:1393,y:921,t:1527026992655};\\\", \\\"{x:1395,y:921,t:1527026992712};\\\", \\\"{x:1395,y:916,t:1527026992722};\\\", \\\"{x:1395,y:913,t:1527026992739};\\\", \\\"{x:1395,y:912,t:1527026992755};\\\", \\\"{x:1395,y:911,t:1527026992772};\\\", \\\"{x:1394,y:909,t:1527026992788};\\\", \\\"{x:1391,y:903,t:1527026992805};\\\", \\\"{x:1390,y:900,t:1527026992822};\\\", \\\"{x:1389,y:891,t:1527026992839};\\\", \\\"{x:1389,y:888,t:1527026992855};\\\", \\\"{x:1389,y:883,t:1527026992872};\\\", \\\"{x:1388,y:878,t:1527026992889};\\\", \\\"{x:1387,y:872,t:1527026992904};\\\", \\\"{x:1385,y:867,t:1527026992922};\\\", \\\"{x:1384,y:863,t:1527026992937};\\\", \\\"{x:1384,y:857,t:1527026992954};\\\", \\\"{x:1383,y:853,t:1527026992972};\\\", \\\"{x:1382,y:849,t:1527026992988};\\\", \\\"{x:1382,y:844,t:1527026993005};\\\", \\\"{x:1382,y:841,t:1527026993021};\\\", \\\"{x:1382,y:839,t:1527026993037};\\\", \\\"{x:1380,y:835,t:1527026993055};\\\", \\\"{x:1380,y:833,t:1527026993071};\\\", \\\"{x:1379,y:828,t:1527026993087};\\\", \\\"{x:1376,y:820,t:1527026993105};\\\", \\\"{x:1376,y:814,t:1527026993121};\\\", \\\"{x:1376,y:809,t:1527026993137};\\\", \\\"{x:1375,y:805,t:1527026993154};\\\", \\\"{x:1373,y:801,t:1527026993170};\\\", \\\"{x:1371,y:796,t:1527026993188};\\\", \\\"{x:1369,y:792,t:1527026993205};\\\", \\\"{x:1368,y:786,t:1527026993221};\\\", \\\"{x:1367,y:783,t:1527026993238};\\\", \\\"{x:1367,y:782,t:1527026993254};\\\", \\\"{x:1367,y:781,t:1527026993359};\\\", \\\"{x:1367,y:780,t:1527026993371};\\\", \\\"{x:1367,y:778,t:1527026993386};\\\", \\\"{x:1367,y:777,t:1527026993403};\\\", \\\"{x:1368,y:776,t:1527026993420};\\\", \\\"{x:1369,y:775,t:1527026993437};\\\", \\\"{x:1369,y:774,t:1527026993503};\\\", \\\"{x:1369,y:773,t:1527026993520};\\\", \\\"{x:1370,y:772,t:1527026993536};\\\", \\\"{x:1371,y:769,t:1527026993553};\\\", \\\"{x:1372,y:767,t:1527026993569};\\\", \\\"{x:1372,y:766,t:1527026993587};\\\", \\\"{x:1373,y:765,t:1527026993607};\\\", \\\"{x:1374,y:765,t:1527026993631};\\\", \\\"{x:1375,y:764,t:1527026994487};\\\", \\\"{x:1376,y:763,t:1527026994502};\\\", \\\"{x:1377,y:763,t:1527026994518};\\\", \\\"{x:1378,y:763,t:1527026994534};\\\", \\\"{x:1380,y:762,t:1527026994550};\\\", \\\"{x:1381,y:762,t:1527026994640};\\\", \\\"{x:1380,y:762,t:1527026997911};\\\", \\\"{x:1379,y:762,t:1527026997943};\\\", \\\"{x:1378,y:762,t:1527026998903};\\\", \\\"{x:1376,y:762,t:1527026998910};\\\", \\\"{x:1375,y:762,t:1527026999016};\\\", \\\"{x:1374,y:762,t:1527026999024};\\\", \\\"{x:1374,y:763,t:1527026999041};\\\", \\\"{x:1372,y:763,t:1527027024735};\\\", \\\"{x:1363,y:763,t:1527027024749};\\\", \\\"{x:1344,y:763,t:1527027024766};\\\", \\\"{x:1306,y:763,t:1527027024782};\\\", \\\"{x:1276,y:763,t:1527027024799};\\\", \\\"{x:1248,y:763,t:1527027024816};\\\", \\\"{x:1222,y:764,t:1527027024833};\\\", \\\"{x:1197,y:766,t:1527027024849};\\\", \\\"{x:1169,y:768,t:1527027024866};\\\", \\\"{x:1140,y:768,t:1527027024883};\\\", \\\"{x:1113,y:768,t:1527027024899};\\\", \\\"{x:1090,y:768,t:1527027024916};\\\", \\\"{x:1068,y:768,t:1527027024932};\\\", \\\"{x:1040,y:768,t:1527027024949};\\\", \\\"{x:1013,y:768,t:1527027024966};\\\", \\\"{x:975,y:762,t:1527027024982};\\\", \\\"{x:896,y:753,t:1527027024998};\\\", \\\"{x:840,y:745,t:1527027025016};\\\", \\\"{x:774,y:738,t:1527027025031};\\\", \\\"{x:717,y:735,t:1527027025049};\\\", \\\"{x:668,y:733,t:1527027025065};\\\", \\\"{x:639,y:733,t:1527027025081};\\\", \\\"{x:614,y:731,t:1527027025099};\\\", \\\"{x:596,y:730,t:1527027025115};\\\", \\\"{x:588,y:730,t:1527027025132};\\\", \\\"{x:586,y:730,t:1527027025149};\\\", \\\"{x:585,y:729,t:1527027025287};\\\", \\\"{x:585,y:727,t:1527027025302};\\\", \\\"{x:589,y:726,t:1527027025314};\\\", \\\"{x:597,y:722,t:1527027025332};\\\", \\\"{x:604,y:720,t:1527027025348};\\\", \\\"{x:614,y:719,t:1527027025364};\\\", \\\"{x:623,y:718,t:1527027025380};\\\", \\\"{x:632,y:716,t:1527027025398};\\\", \\\"{x:650,y:714,t:1527027025414};\\\", \\\"{x:656,y:713,t:1527027025434};\\\", \\\"{x:670,y:709,t:1527027025447};\\\", \\\"{x:679,y:707,t:1527027025464};\\\", \\\"{x:684,y:704,t:1527027025480};\\\", \\\"{x:689,y:703,t:1527027025498};\\\", \\\"{x:691,y:701,t:1527027025513};\\\", \\\"{x:693,y:701,t:1527027025530};\\\", \\\"{x:693,y:700,t:1527027025548};\\\", \\\"{x:695,y:700,t:1527027025563};\\\", \\\"{x:695,y:699,t:1527027025663};\\\", \\\"{x:697,y:697,t:1527027025670};\\\", \\\"{x:699,y:696,t:1527027025680};\\\", \\\"{x:708,y:693,t:1527027025697};\\\", \\\"{x:720,y:687,t:1527027025713};\\\", \\\"{x:736,y:682,t:1527027025731};\\\", \\\"{x:756,y:676,t:1527027025747};\\\", \\\"{x:780,y:669,t:1527027025764};\\\", \\\"{x:813,y:659,t:1527027025779};\\\", \\\"{x:843,y:659,t:1527027025797};\\\", \\\"{x:888,y:654,t:1527027025814};\\\", \\\"{x:908,y:653,t:1527027025830};\\\", \\\"{x:919,y:653,t:1527027025846};\\\", \\\"{x:921,y:653,t:1527027025873};\\\", \\\"{x:922,y:653,t:1527027025889};\\\", \\\"{x:929,y:653,t:1527027026056};\\\", \\\"{x:963,y:653,t:1527027026072};\\\", \\\"{x:1011,y:653,t:1527027026090};\\\", \\\"{x:1075,y:653,t:1527027026105};\\\", \\\"{x:1136,y:653,t:1527027026122};\\\", \\\"{x:1208,y:653,t:1527027026140};\\\", \\\"{x:1259,y:653,t:1527027026155};\\\", \\\"{x:1298,y:653,t:1527027026173};\\\", \\\"{x:1326,y:653,t:1527027026189};\\\", \\\"{x:1344,y:653,t:1527027026205};\\\", \\\"{x:1357,y:654,t:1527027026222};\\\", \\\"{x:1361,y:655,t:1527027026239};\\\", \\\"{x:1361,y:657,t:1527027026256};\\\", \\\"{x:1361,y:660,t:1527027026272};\\\", \\\"{x:1351,y:666,t:1527027026289};\\\", \\\"{x:1342,y:669,t:1527027026305};\\\", \\\"{x:1340,y:671,t:1527027026323};\\\", \\\"{x:1339,y:671,t:1527027026338};\\\", \\\"{x:1343,y:671,t:1527027026384};\\\", \\\"{x:1349,y:669,t:1527027026392};\\\", \\\"{x:1356,y:666,t:1527027026406};\\\", \\\"{x:1373,y:664,t:1527027026422};\\\", \\\"{x:1385,y:661,t:1527027026438};\\\", \\\"{x:1387,y:661,t:1527027026456};\\\", \\\"{x:1385,y:661,t:1527027026534};\\\", \\\"{x:1382,y:661,t:1527027026543};\\\", \\\"{x:1380,y:659,t:1527027026554};\\\", \\\"{x:1379,y:659,t:1527027026570};\\\", \\\"{x:1377,y:659,t:1527027026587};\\\", \\\"{x:1377,y:658,t:1527027026615};\\\", \\\"{x:1376,y:657,t:1527027026623};\\\", \\\"{x:1375,y:657,t:1527027026638};\\\", \\\"{x:1374,y:656,t:1527027026654};\\\", \\\"{x:1369,y:653,t:1527027026671};\\\", \\\"{x:1360,y:649,t:1527027026687};\\\", \\\"{x:1348,y:641,t:1527027026704};\\\", \\\"{x:1333,y:631,t:1527027026722};\\\", \\\"{x:1318,y:621,t:1527027026738};\\\", \\\"{x:1310,y:614,t:1527027026754};\\\", \\\"{x:1305,y:608,t:1527027026771};\\\", \\\"{x:1304,y:602,t:1527027026787};\\\", \\\"{x:1304,y:596,t:1527027026804};\\\", \\\"{x:1302,y:589,t:1527027026820};\\\", \\\"{x:1300,y:580,t:1527027026837};\\\", \\\"{x:1300,y:573,t:1527027026854};\\\", \\\"{x:1300,y:566,t:1527027026871};\\\", \\\"{x:1300,y:558,t:1527027026888};\\\", \\\"{x:1300,y:555,t:1527027026904};\\\", \\\"{x:1301,y:551,t:1527027026921};\\\", \\\"{x:1301,y:550,t:1527027026938};\\\", \\\"{x:1301,y:548,t:1527027026954};\\\", \\\"{x:1301,y:547,t:1527027026971};\\\", \\\"{x:1301,y:546,t:1527027026988};\\\", \\\"{x:1301,y:545,t:1527027027004};\\\", \\\"{x:1301,y:544,t:1527027027021};\\\", \\\"{x:1301,y:543,t:1527027027038};\\\", \\\"{x:1301,y:542,t:1527027027054};\\\", \\\"{x:1301,y:541,t:1527027027071};\\\", \\\"{x:1300,y:540,t:1527027027088};\\\", \\\"{x:1299,y:540,t:1527027027103};\\\", \\\"{x:1298,y:540,t:1527027027120};\\\", \\\"{x:1295,y:540,t:1527027027136};\\\", \\\"{x:1293,y:540,t:1527027027154};\\\", \\\"{x:1287,y:540,t:1527027027170};\\\", \\\"{x:1281,y:541,t:1527027027186};\\\", \\\"{x:1270,y:547,t:1527027027203};\\\", \\\"{x:1262,y:551,t:1527027027220};\\\", \\\"{x:1251,y:557,t:1527027027237};\\\", \\\"{x:1241,y:563,t:1527027027254};\\\", \\\"{x:1223,y:573,t:1527027027273};\\\", \\\"{x:1217,y:576,t:1527027027286};\\\", \\\"{x:1199,y:586,t:1527027027303};\\\", \\\"{x:1183,y:593,t:1527027027319};\\\", \\\"{x:1175,y:596,t:1527027027335};\\\", \\\"{x:1167,y:602,t:1527027027354};\\\", \\\"{x:1157,y:605,t:1527027027369};\\\", \\\"{x:1145,y:610,t:1527027027386};\\\", \\\"{x:1133,y:612,t:1527027027403};\\\", \\\"{x:1118,y:615,t:1527027027420};\\\", \\\"{x:1107,y:616,t:1527027027437};\\\", \\\"{x:1092,y:616,t:1527027027453};\\\", \\\"{x:1077,y:617,t:1527027027470};\\\", \\\"{x:1063,y:617,t:1527027027487};\\\", \\\"{x:1046,y:617,t:1527027027502};\\\", \\\"{x:1027,y:617,t:1527027027520};\\\", \\\"{x:1017,y:617,t:1527027027536};\\\", \\\"{x:1009,y:617,t:1527027027552};\\\", \\\"{x:1001,y:617,t:1527027027570};\\\", \\\"{x:997,y:617,t:1527027027585};\\\", \\\"{x:993,y:616,t:1527027027602};\\\", \\\"{x:993,y:615,t:1527027027680};\\\", \\\"{x:994,y:613,t:1527027027696};\\\", \\\"{x:995,y:612,t:1527027027704};\\\", \\\"{x:1001,y:609,t:1527027027719};\\\", \\\"{x:1013,y:604,t:1527027027735};\\\", \\\"{x:1024,y:599,t:1527027027751};\\\", \\\"{x:1034,y:597,t:1527027027768};\\\", \\\"{x:1052,y:597,t:1527027027785};\\\", \\\"{x:1073,y:597,t:1527027027803};\\\", \\\"{x:1089,y:597,t:1527027027818};\\\", \\\"{x:1109,y:597,t:1527027027836};\\\", \\\"{x:1131,y:597,t:1527027027851};\\\", \\\"{x:1148,y:597,t:1527027027869};\\\", \\\"{x:1161,y:597,t:1527027027886};\\\", \\\"{x:1176,y:599,t:1527027027901};\\\", \\\"{x:1189,y:604,t:1527027027918};\\\", \\\"{x:1214,y:606,t:1527027027936};\\\", \\\"{x:1227,y:608,t:1527027027952};\\\", \\\"{x:1235,y:610,t:1527027027968};\\\", \\\"{x:1242,y:610,t:1527027027984};\\\", \\\"{x:1245,y:611,t:1527027028002};\\\", \\\"{x:1250,y:612,t:1527027028018};\\\", \\\"{x:1253,y:613,t:1527027028034};\\\", \\\"{x:1254,y:613,t:1527027028051};\\\", \\\"{x:1255,y:613,t:1527027028068};\\\", \\\"{x:1257,y:613,t:1527027028084};\\\", \\\"{x:1258,y:613,t:1527027028101};\\\", \\\"{x:1259,y:614,t:1527027028118};\\\", \\\"{x:1261,y:614,t:1527027028134};\\\", \\\"{x:1267,y:615,t:1527027028151};\\\", \\\"{x:1272,y:616,t:1527027028167};\\\", \\\"{x:1277,y:618,t:1527027028184};\\\", \\\"{x:1281,y:620,t:1527027028201};\\\", \\\"{x:1284,y:621,t:1527027028217};\\\", \\\"{x:1287,y:623,t:1527027028234};\\\", \\\"{x:1290,y:624,t:1527027028250};\\\", \\\"{x:1292,y:625,t:1527027028267};\\\", \\\"{x:1294,y:627,t:1527027028284};\\\", \\\"{x:1295,y:628,t:1527027028300};\\\", \\\"{x:1297,y:629,t:1527027028317};\\\", \\\"{x:1297,y:630,t:1527027028334};\\\", \\\"{x:1298,y:630,t:1527027028416};\\\", \\\"{x:1299,y:630,t:1527027028520};\\\", \\\"{x:1300,y:630,t:1527027028576};\\\", \\\"{x:1302,y:630,t:1527027029104};\\\", \\\"{x:1303,y:630,t:1527027029320};\\\", \\\"{x:1305,y:630,t:1527027029335};\\\", \\\"{x:1306,y:630,t:1527027029349};\\\", \\\"{x:1308,y:630,t:1527027029365};\\\", \\\"{x:1312,y:631,t:1527027029382};\\\", \\\"{x:1318,y:633,t:1527027029398};\\\", \\\"{x:1321,y:634,t:1527027029415};\\\", \\\"{x:1325,y:634,t:1527027029431};\\\", \\\"{x:1326,y:634,t:1527027029448};\\\", \\\"{x:1327,y:634,t:1527027029472};\\\", \\\"{x:1328,y:634,t:1527027029481};\\\", \\\"{x:1330,y:634,t:1527027029499};\\\", \\\"{x:1334,y:635,t:1527027029515};\\\", \\\"{x:1338,y:636,t:1527027029531};\\\", \\\"{x:1344,y:637,t:1527027029548};\\\", \\\"{x:1349,y:637,t:1527027029564};\\\", \\\"{x:1356,y:638,t:1527027029581};\\\", \\\"{x:1361,y:639,t:1527027029598};\\\", \\\"{x:1368,y:640,t:1527027029614};\\\", \\\"{x:1379,y:642,t:1527027029631};\\\", \\\"{x:1383,y:643,t:1527027029647};\\\", \\\"{x:1386,y:643,t:1527027029664};\\\", \\\"{x:1395,y:645,t:1527027029682};\\\", \\\"{x:1411,y:650,t:1527027029698};\\\", \\\"{x:1425,y:655,t:1527027029715};\\\", \\\"{x:1436,y:657,t:1527027029730};\\\", \\\"{x:1446,y:660,t:1527027029747};\\\", \\\"{x:1456,y:660,t:1527027029764};\\\", \\\"{x:1471,y:661,t:1527027029780};\\\", \\\"{x:1488,y:667,t:1527027029797};\\\", \\\"{x:1511,y:673,t:1527027029814};\\\", \\\"{x:1528,y:678,t:1527027029831};\\\", \\\"{x:1546,y:683,t:1527027029848};\\\", \\\"{x:1557,y:686,t:1527027029864};\\\", \\\"{x:1571,y:691,t:1527027029880};\\\", \\\"{x:1578,y:694,t:1527027029898};\\\", \\\"{x:1582,y:697,t:1527027029914};\\\", \\\"{x:1588,y:703,t:1527027029930};\\\", \\\"{x:1594,y:711,t:1527027029948};\\\", \\\"{x:1599,y:719,t:1527027029963};\\\", \\\"{x:1604,y:728,t:1527027029980};\\\", \\\"{x:1606,y:735,t:1527027029996};\\\", \\\"{x:1609,y:744,t:1527027030013};\\\", \\\"{x:1609,y:752,t:1527027030031};\\\", \\\"{x:1609,y:762,t:1527027030047};\\\", \\\"{x:1609,y:776,t:1527027030064};\\\", \\\"{x:1607,y:785,t:1527027030080};\\\", \\\"{x:1604,y:792,t:1527027030097};\\\", \\\"{x:1600,y:800,t:1527027030114};\\\", \\\"{x:1596,y:807,t:1527027030130};\\\", \\\"{x:1591,y:815,t:1527027030147};\\\", \\\"{x:1586,y:820,t:1527027030163};\\\", \\\"{x:1574,y:826,t:1527027030179};\\\", \\\"{x:1562,y:834,t:1527027030197};\\\", \\\"{x:1547,y:842,t:1527027030213};\\\", \\\"{x:1535,y:850,t:1527027030229};\\\", \\\"{x:1520,y:858,t:1527027030247};\\\", \\\"{x:1493,y:873,t:1527027030264};\\\", \\\"{x:1476,y:880,t:1527027030280};\\\", \\\"{x:1461,y:888,t:1527027030296};\\\", \\\"{x:1444,y:895,t:1527027030312};\\\", \\\"{x:1418,y:906,t:1527027030330};\\\", \\\"{x:1377,y:922,t:1527027030346};\\\", \\\"{x:1319,y:938,t:1527027030363};\\\", \\\"{x:1252,y:960,t:1527027030380};\\\", \\\"{x:1174,y:980,t:1527027030396};\\\", \\\"{x:1098,y:996,t:1527027030413};\\\", \\\"{x:1031,y:1007,t:1527027030429};\\\", \\\"{x:969,y:1015,t:1527027030446};\\\", \\\"{x:909,y:1021,t:1527027030462};\\\", \\\"{x:819,y:1021,t:1527027030479};\\\", \\\"{x:766,y:1021,t:1527027030495};\\\", \\\"{x:716,y:1021,t:1527027030511};\\\", \\\"{x:671,y:1021,t:1527027030529};\\\", \\\"{x:644,y:1015,t:1527027030545};\\\", \\\"{x:631,y:1009,t:1527027030562};\\\", \\\"{x:626,y:1006,t:1527027030578};\\\", \\\"{x:622,y:1003,t:1527027030595};\\\", \\\"{x:617,y:998,t:1527027030612};\\\", \\\"{x:608,y:986,t:1527027030628};\\\", \\\"{x:598,y:973,t:1527027030645};\\\", \\\"{x:590,y:962,t:1527027030662};\\\", \\\"{x:585,y:955,t:1527027030678};\\\", \\\"{x:577,y:942,t:1527027030695};\\\", \\\"{x:571,y:931,t:1527027030711};\\\", \\\"{x:565,y:921,t:1527027030728};\\\", \\\"{x:562,y:916,t:1527027030746};\\\", \\\"{x:560,y:910,t:1527027030761};\\\", \\\"{x:560,y:905,t:1527027030779};\\\", \\\"{x:560,y:901,t:1527027030796};\\\", \\\"{x:560,y:899,t:1527027030812};\\\", \\\"{x:560,y:897,t:1527027030828};\\\", \\\"{x:560,y:896,t:1527027030846};\\\", \\\"{x:560,y:895,t:1527027030864};\\\", \\\"{x:560,y:894,t:1527027030887};\\\", \\\"{x:561,y:892,t:1527027030894};\\\", \\\"{x:564,y:891,t:1527027030911};\\\", \\\"{x:572,y:887,t:1527027030928};\\\", \\\"{x:577,y:886,t:1527027030944};\\\", \\\"{x:583,y:884,t:1527027030961};\\\", \\\"{x:592,y:882,t:1527027030978};\\\", \\\"{x:598,y:880,t:1527027030994};\\\", \\\"{x:603,y:879,t:1527027031011};\\\", \\\"{x:608,y:879,t:1527027031026};\\\", \\\"{x:610,y:878,t:1527027031044};\\\", \\\"{x:611,y:878,t:1527027031061};\\\", \\\"{x:613,y:878,t:1527027031077};\\\", \\\"{x:614,y:878,t:1527027031304};\\\", \\\"{x:615,y:878,t:1527027031311};\\\", \\\"{x:615,y:877,t:1527027031327};\\\", \\\"{x:615,y:876,t:1527027035592};\\\", \\\"{x:611,y:876,t:1527027035655};\\\", \\\"{x:611,y:875,t:1527027035668};\\\", \\\"{x:606,y:875,t:1527027038680};\\\", \\\"{x:593,y:875,t:1527027038693};\\\", \\\"{x:556,y:878,t:1527027038710};\\\", \\\"{x:552,y:880,t:1527027038726};\\\", \\\"{x:592,y:880,t:1527027073877};\\\", \\\"{x:695,y:871,t:1527027073886};\\\", \\\"{x:818,y:843,t:1527027073896};\\\", \\\"{x:1069,y:771,t:1527027073914};\\\", \\\"{x:1279,y:708,t:1527027073930};\\\", \\\"{x:1429,y:662,t:1527027073946};\\\", \\\"{x:1522,y:624,t:1527027073963};\\\", \\\"{x:1588,y:588,t:1527027073981};\\\", \\\"{x:1619,y:566,t:1527027073996};\\\", \\\"{x:1642,y:554,t:1527027074013};\\\", \\\"{x:1646,y:550,t:1527027074029};\\\", \\\"{x:1640,y:547,t:1527027074078};\\\", \\\"{x:1629,y:544,t:1527027074085};\\\", \\\"{x:1611,y:540,t:1527027074097};\\\", \\\"{x:1558,y:534,t:1527027074113};\\\", \\\"{x:1503,y:534,t:1527027074129};\\\", \\\"{x:1452,y:534,t:1527027074147};\\\", \\\"{x:1416,y:531,t:1527027074162};\\\", \\\"{x:1395,y:527,t:1527027074180};\\\", \\\"{x:1391,y:526,t:1527027074196};\\\", \\\"{x:1390,y:526,t:1527027074212};\\\", \\\"{x:1388,y:527,t:1527027074334};\\\", \\\"{x:1383,y:532,t:1527027074345};\\\", \\\"{x:1371,y:541,t:1527027074362};\\\", \\\"{x:1361,y:546,t:1527027074379};\\\", \\\"{x:1352,y:552,t:1527027074395};\\\", \\\"{x:1344,y:554,t:1527027074413};\\\", \\\"{x:1341,y:555,t:1527027074429};\\\", \\\"{x:1340,y:556,t:1527027074469};\\\", \\\"{x:1338,y:556,t:1527027082549};\\\", \\\"{x:1336,y:557,t:1527027082561};\\\", \\\"{x:1335,y:559,t:1527027082577};\\\", \\\"{x:1333,y:560,t:1527027082594};\\\", \\\"{x:1331,y:562,t:1527027082611};\\\", \\\"{x:1330,y:564,t:1527027082627};\\\", \\\"{x:1330,y:565,t:1527027082758};\\\", \\\"{x:1327,y:565,t:1527027083270};\\\", \\\"{x:1319,y:572,t:1527027083277};\\\", \\\"{x:1313,y:576,t:1527027083292};\\\", \\\"{x:1309,y:579,t:1527027083309};\\\", \\\"{x:1308,y:579,t:1527027083325};\\\", \\\"{x:1303,y:581,t:1527027083342};\\\", \\\"{x:1299,y:583,t:1527027083359};\\\", \\\"{x:1296,y:584,t:1527027083375};\\\", \\\"{x:1295,y:584,t:1527027083392};\\\", \\\"{x:1299,y:588,t:1527027084013};\\\", \\\"{x:1304,y:589,t:1527027084024};\\\", \\\"{x:1312,y:589,t:1527027084041};\\\", \\\"{x:1319,y:589,t:1527027084056};\\\", \\\"{x:1327,y:590,t:1527027084074};\\\", \\\"{x:1332,y:591,t:1527027084091};\\\", \\\"{x:1339,y:591,t:1527027084106};\\\", \\\"{x:1350,y:591,t:1527027084124};\\\", \\\"{x:1358,y:592,t:1527027084140};\\\", \\\"{x:1363,y:594,t:1527027084156};\\\", \\\"{x:1365,y:594,t:1527027084173};\\\", \\\"{x:1366,y:595,t:1527027084197};\\\", \\\"{x:1367,y:598,t:1527027089975};\\\", \\\"{x:1367,y:609,t:1527027089988};\\\", \\\"{x:1365,y:621,t:1527027090004};\\\", \\\"{x:1357,y:634,t:1527027090020};\\\", \\\"{x:1333,y:649,t:1527027090037};\\\", \\\"{x:1278,y:674,t:1527027090054};\\\", \\\"{x:1200,y:697,t:1527027090070};\\\", \\\"{x:1093,y:707,t:1527027090087};\\\", \\\"{x:960,y:707,t:1527027090103};\\\", \\\"{x:769,y:707,t:1527027090120};\\\", \\\"{x:683,y:707,t:1527027090137};\\\", \\\"{x:651,y:705,t:1527027090153};\\\", \\\"{x:634,y:700,t:1527027090170};\\\", \\\"{x:624,y:697,t:1527027090187};\\\", \\\"{x:621,y:696,t:1527027090203};\\\", \\\"{x:619,y:695,t:1527027090220};\\\", \\\"{x:619,y:694,t:1527027090240};\\\", \\\"{x:619,y:691,t:1527027090253};\\\", \\\"{x:619,y:686,t:1527027090271};\\\", \\\"{x:619,y:677,t:1527027090286};\\\", \\\"{x:619,y:668,t:1527027090303};\\\", \\\"{x:623,y:649,t:1527027090320};\\\", \\\"{x:625,y:639,t:1527027090336};\\\", \\\"{x:625,y:629,t:1527027090354};\\\", \\\"{x:625,y:627,t:1527027090365};\\\", \\\"{x:625,y:626,t:1527027090383};\\\", \\\"{x:624,y:626,t:1527027090463};\\\", \\\"{x:623,y:626,t:1527027090495};\\\", \\\"{x:622,y:627,t:1527027090552};\\\", \\\"{x:621,y:627,t:1527027090565};\\\", \\\"{x:617,y:628,t:1527027090582};\\\", \\\"{x:615,y:628,t:1527027090598};\\\", \\\"{x:614,y:628,t:1527027090615};\\\", \\\"{x:611,y:626,t:1527027090632};\\\", \\\"{x:611,y:624,t:1527027090648};\\\", \\\"{x:611,y:622,t:1527027090665};\\\", \\\"{x:611,y:621,t:1527027090682};\\\", \\\"{x:611,y:621,t:1527027090752};\\\", \\\"{x:615,y:627,t:1527027091032};\\\", \\\"{x:626,y:639,t:1527027091050};\\\", \\\"{x:634,y:651,t:1527027091065};\\\", \\\"{x:641,y:664,t:1527027091082};\\\", \\\"{x:647,y:674,t:1527027091100};\\\", \\\"{x:648,y:682,t:1527027091116};\\\", \\\"{x:650,y:691,t:1527027091132};\\\", \\\"{x:651,y:700,t:1527027091149};\\\", \\\"{x:650,y:702,t:1527027091166};\\\", \\\"{x:647,y:706,t:1527027091183};\\\", \\\"{x:644,y:708,t:1527027091199};\\\", \\\"{x:641,y:708,t:1527027091216};\\\", \\\"{x:636,y:708,t:1527027091232};\\\", \\\"{x:631,y:708,t:1527027091249};\\\", \\\"{x:625,y:708,t:1527027091266};\\\", \\\"{x:621,y:708,t:1527027091282};\\\", \\\"{x:606,y:708,t:1527027091299};\\\", \\\"{x:587,y:708,t:1527027091316};\\\", \\\"{x:572,y:709,t:1527027091332};\\\", \\\"{x:562,y:713,t:1527027091349};\\\", \\\"{x:555,y:718,t:1527027091367};\\\", \\\"{x:547,y:721,t:1527027091382};\\\", \\\"{x:538,y:727,t:1527027091399};\\\", \\\"{x:533,y:729,t:1527027091416};\\\", \\\"{x:532,y:730,t:1527027091432};\\\", \\\"{x:531,y:730,t:1527027091633};\\\", \\\"{x:529,y:728,t:1527027091649};\\\", \\\"{x:527,y:727,t:1527027091666};\\\", \\\"{x:527,y:726,t:1527027091735};\\\", \\\"{x:528,y:726,t:1527027091749};\\\", \\\"{x:532,y:726,t:1527027091766};\\\", \\\"{x:535,y:726,t:1527027091783};\\\", \\\"{x:539,y:726,t:1527027091799};\\\", \\\"{x:558,y:727,t:1527027091816};\\\", \\\"{x:578,y:729,t:1527027091833};\\\", \\\"{x:600,y:729,t:1527027091849};\\\", \\\"{x:624,y:727,t:1527027091866};\\\", \\\"{x:718,y:727,t:1527027091883};\\\", \\\"{x:840,y:727,t:1527027091900};\\\", \\\"{x:955,y:722,t:1527027091916};\\\", \\\"{x:1106,y:702,t:1527027091933};\\\", \\\"{x:1256,y:678,t:1527027091950};\\\", \\\"{x:1380,y:649,t:1527027091966};\\\", \\\"{x:1491,y:618,t:1527027091983};\\\", \\\"{x:1620,y:574,t:1527027091999};\\\", \\\"{x:1669,y:544,t:1527027092016};\\\", \\\"{x:1701,y:525,t:1527027092033};\\\", \\\"{x:1719,y:514,t:1527027092050};\\\", \\\"{x:1727,y:507,t:1527027092066};\\\", \\\"{x:1727,y:504,t:1527027092083};\\\", \\\"{x:1727,y:502,t:1527027092100};\\\", \\\"{x:1711,y:493,t:1527027092116};\\\", \\\"{x:1687,y:483,t:1527027092133};\\\", \\\"{x:1654,y:473,t:1527027092150};\\\", \\\"{x:1605,y:461,t:1527027092166};\\\", \\\"{x:1567,y:452,t:1527027092183};\\\", \\\"{x:1536,y:446,t:1527027092200};\\\", \\\"{x:1520,y:440,t:1527027092216};\\\", \\\"{x:1511,y:438,t:1527027092233};\\\", \\\"{x:1505,y:436,t:1527027092250};\\\", \\\"{x:1503,y:435,t:1527027092266};\\\", \\\"{x:1501,y:434,t:1527027092283};\\\", \\\"{x:1500,y:434,t:1527027092300};\\\", \\\"{x:1499,y:434,t:1527027092335};\\\", \\\"{x:1498,y:434,t:1527027092350};\\\", \\\"{x:1495,y:434,t:1527027092367};\\\", \\\"{x:1494,y:434,t:1527027092383};\\\", \\\"{x:1493,y:432,t:1527027092880};\\\", \\\"{x:1493,y:429,t:1527027092887};\\\", \\\"{x:1493,y:427,t:1527027092900};\\\", \\\"{x:1494,y:424,t:1527027092917};\\\" ] }, { \\\"rt\\\": 10110, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 436674, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1488,y:417,t:1527027093091};\\\", \\\"{x:1488,y:415,t:1527027093104};\\\", \\\"{x:1488,y:409,t:1527027093120};\\\", \\\"{x:1489,y:404,t:1527027093135};\\\", \\\"{x:1492,y:397,t:1527027093150};\\\", \\\"{x:1493,y:390,t:1527027093177};\\\", \\\"{x:1493,y:389,t:1527027093184};\\\", \\\"{x:1489,y:387,t:1527027093258};\\\", \\\"{x:1487,y:387,t:1527027093268};\\\", \\\"{x:1483,y:387,t:1527027093284};\\\", \\\"{x:1478,y:387,t:1527027093302};\\\", \\\"{x:1472,y:387,t:1527027093318};\\\", \\\"{x:1467,y:387,t:1527027093334};\\\", \\\"{x:1452,y:391,t:1527027093351};\\\", \\\"{x:1442,y:393,t:1527027093367};\\\", \\\"{x:1381,y:402,t:1527027093385};\\\", \\\"{x:1323,y:410,t:1527027093401};\\\", \\\"{x:1259,y:418,t:1527027093417};\\\", \\\"{x:1211,y:426,t:1527027093434};\\\", \\\"{x:1181,y:430,t:1527027093452};\\\", \\\"{x:1158,y:430,t:1527027093467};\\\", \\\"{x:1135,y:430,t:1527027093485};\\\", \\\"{x:1117,y:430,t:1527027093501};\\\", \\\"{x:1107,y:430,t:1527027093517};\\\", \\\"{x:1096,y:430,t:1527027093534};\\\", \\\"{x:1081,y:430,t:1527027093551};\\\", \\\"{x:1072,y:433,t:1527027093567};\\\", \\\"{x:1065,y:433,t:1527027093584};\\\", \\\"{x:1051,y:433,t:1527027093601};\\\", \\\"{x:1030,y:433,t:1527027093618};\\\", \\\"{x:1001,y:433,t:1527027093634};\\\", \\\"{x:969,y:433,t:1527027093651};\\\", \\\"{x:931,y:433,t:1527027093667};\\\", \\\"{x:892,y:433,t:1527027093684};\\\", \\\"{x:855,y:433,t:1527027093701};\\\", \\\"{x:829,y:433,t:1527027093718};\\\", \\\"{x:806,y:433,t:1527027093735};\\\", \\\"{x:783,y:433,t:1527027093751};\\\", \\\"{x:767,y:431,t:1527027093768};\\\", \\\"{x:755,y:429,t:1527027093784};\\\", \\\"{x:749,y:428,t:1527027093802};\\\", \\\"{x:744,y:427,t:1527027093819};\\\", \\\"{x:743,y:427,t:1527027093839};\\\", \\\"{x:743,y:426,t:1527027093919};\\\", \\\"{x:743,y:425,t:1527027093935};\\\", \\\"{x:743,y:422,t:1527027093951};\\\", \\\"{x:744,y:420,t:1527027093968};\\\", \\\"{x:744,y:418,t:1527027093985};\\\", \\\"{x:746,y:417,t:1527027094015};\\\", \\\"{x:746,y:416,t:1527027094240};\\\", \\\"{x:749,y:416,t:1527027094455};\\\", \\\"{x:755,y:420,t:1527027094469};\\\", \\\"{x:760,y:424,t:1527027094486};\\\", \\\"{x:761,y:424,t:1527027094501};\\\", \\\"{x:762,y:424,t:1527027094518};\\\", \\\"{x:762,y:425,t:1527027094536};\\\", \\\"{x:762,y:426,t:1527027094743};\\\", \\\"{x:762,y:428,t:1527027094753};\\\", \\\"{x:761,y:429,t:1527027094769};\\\", \\\"{x:760,y:430,t:1527027094785};\\\", \\\"{x:759,y:431,t:1527027094802};\\\", \\\"{x:758,y:432,t:1527027094863};\\\", \\\"{x:757,y:432,t:1527027095207};\\\", \\\"{x:756,y:432,t:1527027095219};\\\", \\\"{x:756,y:433,t:1527027095808};\\\", \\\"{x:755,y:434,t:1527027095832};\\\", \\\"{x:755,y:435,t:1527027095848};\\\", \\\"{x:754,y:435,t:1527027095871};\\\", \\\"{x:753,y:435,t:1527027095887};\\\", \\\"{x:751,y:436,t:1527027095903};\\\", \\\"{x:750,y:436,t:1527027095984};\\\", \\\"{x:749,y:437,t:1527027096024};\\\", \\\"{x:748,y:438,t:1527027097032};\\\", \\\"{x:747,y:438,t:1527027097071};\\\", \\\"{x:746,y:439,t:1527027097087};\\\", \\\"{x:745,y:439,t:1527027097103};\\\", \\\"{x:744,y:441,t:1527027097121};\\\", \\\"{x:743,y:441,t:1527027097138};\\\", \\\"{x:739,y:444,t:1527027098024};\\\", \\\"{x:738,y:444,t:1527027098038};\\\", \\\"{x:736,y:444,t:1527027098054};\\\", \\\"{x:735,y:445,t:1527027098071};\\\", \\\"{x:740,y:445,t:1527027098520};\\\", \\\"{x:745,y:445,t:1527027098527};\\\", \\\"{x:755,y:447,t:1527027098538};\\\", \\\"{x:768,y:449,t:1527027098555};\\\", \\\"{x:771,y:449,t:1527027098571};\\\", \\\"{x:772,y:449,t:1527027098591};\\\", \\\"{x:773,y:449,t:1527027098615};\\\", \\\"{x:774,y:449,t:1527027098624};\\\", \\\"{x:775,y:449,t:1527027098639};\\\", \\\"{x:776,y:449,t:1527027098656};\\\", \\\"{x:777,y:449,t:1527027098671};\\\", \\\"{x:777,y:448,t:1527027098689};\\\", \\\"{x:778,y:448,t:1527027098706};\\\", \\\"{x:779,y:447,t:1527027098743};\\\", \\\"{x:779,y:449,t:1527027098816};\\\", \\\"{x:775,y:458,t:1527027098824};\\\", \\\"{x:767,y:468,t:1527027098838};\\\", \\\"{x:741,y:498,t:1527027098856};\\\", \\\"{x:724,y:512,t:1527027098872};\\\", \\\"{x:710,y:525,t:1527027098889};\\\", \\\"{x:694,y:538,t:1527027098904};\\\", \\\"{x:676,y:549,t:1527027098921};\\\", \\\"{x:659,y:560,t:1527027098939};\\\", \\\"{x:647,y:568,t:1527027098955};\\\", \\\"{x:640,y:573,t:1527027098972};\\\", \\\"{x:635,y:576,t:1527027098988};\\\", \\\"{x:632,y:577,t:1527027099006};\\\", \\\"{x:631,y:577,t:1527027099022};\\\", \\\"{x:631,y:572,t:1527027099135};\\\", \\\"{x:631,y:569,t:1527027099143};\\\", \\\"{x:631,y:566,t:1527027099156};\\\", \\\"{x:631,y:560,t:1527027099173};\\\", \\\"{x:631,y:552,t:1527027099188};\\\", \\\"{x:630,y:543,t:1527027099205};\\\", \\\"{x:628,y:537,t:1527027099222};\\\", \\\"{x:627,y:534,t:1527027099238};\\\", \\\"{x:627,y:532,t:1527027099255};\\\", \\\"{x:627,y:531,t:1527027099273};\\\", \\\"{x:626,y:529,t:1527027099289};\\\", \\\"{x:626,y:528,t:1527027099305};\\\", \\\"{x:625,y:525,t:1527027099323};\\\", \\\"{x:622,y:522,t:1527027099339};\\\", \\\"{x:616,y:514,t:1527027099357};\\\", \\\"{x:611,y:505,t:1527027099373};\\\", \\\"{x:610,y:500,t:1527027099389};\\\", \\\"{x:609,y:498,t:1527027099406};\\\", \\\"{x:609,y:497,t:1527027099423};\\\", \\\"{x:608,y:495,t:1527027099439};\\\", \\\"{x:608,y:494,t:1527027099775};\\\", \\\"{x:616,y:497,t:1527027099790};\\\", \\\"{x:639,y:506,t:1527027099805};\\\", \\\"{x:662,y:512,t:1527027099823};\\\", \\\"{x:697,y:518,t:1527027099840};\\\", \\\"{x:714,y:521,t:1527027099856};\\\", \\\"{x:733,y:521,t:1527027099872};\\\", \\\"{x:752,y:521,t:1527027099890};\\\", \\\"{x:770,y:522,t:1527027099907};\\\", \\\"{x:788,y:522,t:1527027099923};\\\", \\\"{x:797,y:522,t:1527027099940};\\\", \\\"{x:807,y:522,t:1527027099957};\\\", \\\"{x:822,y:522,t:1527027099973};\\\", \\\"{x:831,y:522,t:1527027099989};\\\", \\\"{x:843,y:522,t:1527027100006};\\\", \\\"{x:856,y:522,t:1527027100024};\\\", \\\"{x:859,y:522,t:1527027100040};\\\", \\\"{x:861,y:522,t:1527027100057};\\\", \\\"{x:864,y:523,t:1527027100074};\\\", \\\"{x:866,y:523,t:1527027100095};\\\", \\\"{x:866,y:525,t:1527027100233};\\\", \\\"{x:864,y:527,t:1527027100241};\\\", \\\"{x:859,y:531,t:1527027100257};\\\", \\\"{x:858,y:533,t:1527027100273};\\\", \\\"{x:855,y:535,t:1527027100289};\\\", \\\"{x:851,y:537,t:1527027100307};\\\", \\\"{x:847,y:539,t:1527027100324};\\\", \\\"{x:844,y:541,t:1527027100341};\\\", \\\"{x:843,y:542,t:1527027100356};\\\", \\\"{x:842,y:542,t:1527027100375};\\\", \\\"{x:841,y:542,t:1527027100390};\\\", \\\"{x:841,y:543,t:1527027100406};\\\", \\\"{x:839,y:544,t:1527027100864};\\\", \\\"{x:834,y:549,t:1527027100874};\\\", \\\"{x:828,y:560,t:1527027100891};\\\", \\\"{x:825,y:565,t:1527027100907};\\\", \\\"{x:823,y:567,t:1527027100924};\\\", \\\"{x:821,y:569,t:1527027100941};\\\", \\\"{x:819,y:572,t:1527027100957};\\\", \\\"{x:817,y:574,t:1527027100974};\\\", \\\"{x:815,y:575,t:1527027100990};\\\", \\\"{x:814,y:576,t:1527027101006};\\\", \\\"{x:813,y:578,t:1527027101023};\\\", \\\"{x:812,y:578,t:1527027101041};\\\", \\\"{x:812,y:579,t:1527027101056};\\\", \\\"{x:811,y:580,t:1527027101074};\\\", \\\"{x:810,y:581,t:1527027101096};\\\", \\\"{x:809,y:583,t:1527027101107};\\\", \\\"{x:807,y:584,t:1527027101123};\\\", \\\"{x:804,y:587,t:1527027101140};\\\", \\\"{x:801,y:590,t:1527027101158};\\\", \\\"{x:798,y:595,t:1527027101174};\\\", \\\"{x:794,y:599,t:1527027101191};\\\", \\\"{x:790,y:602,t:1527027101207};\\\", \\\"{x:786,y:606,t:1527027101223};\\\", \\\"{x:783,y:609,t:1527027101240};\\\", \\\"{x:780,y:611,t:1527027101258};\\\", \\\"{x:779,y:612,t:1527027101273};\\\", \\\"{x:777,y:613,t:1527027101291};\\\", \\\"{x:776,y:615,t:1527027101308};\\\", \\\"{x:773,y:617,t:1527027101323};\\\", \\\"{x:772,y:620,t:1527027101340};\\\", \\\"{x:771,y:623,t:1527027101358};\\\", \\\"{x:769,y:624,t:1527027101374};\\\", \\\"{x:769,y:625,t:1527027101412};\\\", \\\"{x:768,y:626,t:1527027101736};\\\", \\\"{x:767,y:628,t:1527027101743};\\\", \\\"{x:766,y:630,t:1527027101758};\\\", \\\"{x:764,y:634,t:1527027101775};\\\", \\\"{x:763,y:640,t:1527027101790};\\\", \\\"{x:758,y:649,t:1527027101807};\\\", \\\"{x:751,y:658,t:1527027101824};\\\", \\\"{x:745,y:665,t:1527027101842};\\\", \\\"{x:739,y:670,t:1527027101858};\\\", \\\"{x:731,y:675,t:1527027101875};\\\", \\\"{x:721,y:681,t:1527027101891};\\\", \\\"{x:711,y:688,t:1527027101908};\\\", \\\"{x:697,y:694,t:1527027101925};\\\", \\\"{x:679,y:702,t:1527027101942};\\\", \\\"{x:663,y:709,t:1527027101957};\\\", \\\"{x:642,y:716,t:1527027101974};\\\", \\\"{x:618,y:727,t:1527027101991};\\\", \\\"{x:603,y:730,t:1527027102008};\\\", \\\"{x:588,y:734,t:1527027102032};\\\", \\\"{x:583,y:735,t:1527027102041};\\\", \\\"{x:577,y:736,t:1527027102057};\\\", \\\"{x:575,y:736,t:1527027102074};\\\", \\\"{x:573,y:736,t:1527027102092};\\\", \\\"{x:572,y:736,t:1527027102108};\\\", \\\"{x:569,y:738,t:1527027102124};\\\", \\\"{x:563,y:740,t:1527027102142};\\\", \\\"{x:557,y:742,t:1527027102159};\\\", \\\"{x:552,y:743,t:1527027102175};\\\", \\\"{x:544,y:745,t:1527027102192};\\\", \\\"{x:543,y:745,t:1527027102208};\\\", \\\"{x:540,y:745,t:1527027102224};\\\", \\\"{x:539,y:745,t:1527027102242};\\\", \\\"{x:538,y:745,t:1527027102257};\\\", \\\"{x:538,y:746,t:1527027103639};\\\", \\\"{x:544,y:750,t:1527027103648};\\\", \\\"{x:551,y:750,t:1527027103659};\\\", \\\"{x:565,y:750,t:1527027103676};\\\", \\\"{x:582,y:739,t:1527027103692};\\\", \\\"{x:599,y:715,t:1527027103709};\\\", \\\"{x:635,y:661,t:1527027103726};\\\", \\\"{x:674,y:586,t:1527027103743};\\\", \\\"{x:705,y:501,t:1527027103759};\\\", \\\"{x:718,y:410,t:1527027103776};\\\", \\\"{x:718,y:391,t:1527027103792};\\\", \\\"{x:719,y:383,t:1527027103809};\\\", \\\"{x:719,y:379,t:1527027103825};\\\", \\\"{x:718,y:376,t:1527027103843};\\\", \\\"{x:717,y:375,t:1527027103860};\\\", \\\"{x:716,y:373,t:1527027103875};\\\", \\\"{x:713,y:370,t:1527027103892};\\\", \\\"{x:709,y:369,t:1527027103910};\\\", \\\"{x:707,y:367,t:1527027103926};\\\", \\\"{x:702,y:366,t:1527027103943};\\\", \\\"{x:697,y:364,t:1527027103959};\\\", \\\"{x:694,y:363,t:1527027103975};\\\", \\\"{x:694,y:361,t:1527027104191};\\\", \\\"{x:694,y:360,t:1527027104199};\\\", \\\"{x:694,y:358,t:1527027104209};\\\", \\\"{x:694,y:355,t:1527027104255};\\\", \\\"{x:694,y:354,t:1527027104271};\\\", \\\"{x:694,y:353,t:1527027104287};\\\", \\\"{x:694,y:352,t:1527027104304};\\\" ] }, { \\\"rt\\\": 17604, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 455508, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:695,y:348,t:1527027104428};\\\", \\\"{x:694,y:346,t:1527027104775};\\\", \\\"{x:693,y:345,t:1527027104783};\\\", \\\"{x:691,y:344,t:1527027104794};\\\", \\\"{x:688,y:344,t:1527027104810};\\\", \\\"{x:684,y:341,t:1527027104827};\\\", \\\"{x:681,y:340,t:1527027104844};\\\", \\\"{x:680,y:340,t:1527027104860};\\\", \\\"{x:679,y:339,t:1527027104912};\\\", \\\"{x:679,y:338,t:1527027105053};\\\", \\\"{x:680,y:337,t:1527027105072};\\\", \\\"{x:682,y:335,t:1527027105087};\\\", \\\"{x:684,y:334,t:1527027105095};\\\", \\\"{x:687,y:333,t:1527027105111};\\\", \\\"{x:692,y:331,t:1527027105126};\\\", \\\"{x:698,y:329,t:1527027105143};\\\", \\\"{x:700,y:327,t:1527027105161};\\\", \\\"{x:702,y:327,t:1527027105177};\\\", \\\"{x:706,y:325,t:1527027105194};\\\", \\\"{x:709,y:324,t:1527027105211};\\\", \\\"{x:711,y:324,t:1527027105227};\\\", \\\"{x:712,y:324,t:1527027105244};\\\", \\\"{x:713,y:323,t:1527027105261};\\\", \\\"{x:714,y:323,t:1527027105288};\\\", \\\"{x:716,y:321,t:1527027105592};\\\", \\\"{x:715,y:321,t:1527027107792};\\\", \\\"{x:714,y:321,t:1527027107799};\\\", \\\"{x:713,y:321,t:1527027107812};\\\", \\\"{x:712,y:321,t:1527027107829};\\\", \\\"{x:711,y:321,t:1527027107846};\\\", \\\"{x:709,y:321,t:1527027107862};\\\", \\\"{x:707,y:321,t:1527027107936};\\\", \\\"{x:706,y:321,t:1527027107984};\\\", \\\"{x:704,y:321,t:1527027108007};\\\", \\\"{x:703,y:321,t:1527027108023};\\\", \\\"{x:701,y:321,t:1527027108048};\\\", \\\"{x:700,y:321,t:1527027108072};\\\", \\\"{x:698,y:321,t:1527027108224};\\\", \\\"{x:697,y:321,t:1527027108239};\\\", \\\"{x:695,y:322,t:1527027108264};\\\", \\\"{x:694,y:323,t:1527027108303};\\\", \\\"{x:693,y:323,t:1527027108313};\\\", \\\"{x:692,y:323,t:1527027108352};\\\", \\\"{x:690,y:323,t:1527027108367};\\\", \\\"{x:689,y:324,t:1527027108380};\\\", \\\"{x:687,y:324,t:1527027108396};\\\", \\\"{x:684,y:325,t:1527027108413};\\\", \\\"{x:682,y:325,t:1527027108430};\\\", \\\"{x:679,y:325,t:1527027108446};\\\", \\\"{x:677,y:326,t:1527027108463};\\\", \\\"{x:676,y:327,t:1527027108480};\\\", \\\"{x:675,y:327,t:1527027108496};\\\", \\\"{x:675,y:331,t:1527027111463};\\\", \\\"{x:680,y:338,t:1527027111472};\\\", \\\"{x:687,y:345,t:1527027111482};\\\", \\\"{x:695,y:353,t:1527027111498};\\\", \\\"{x:707,y:363,t:1527027111515};\\\", \\\"{x:723,y:373,t:1527027111532};\\\", \\\"{x:744,y:382,t:1527027111548};\\\", \\\"{x:773,y:394,t:1527027111565};\\\", \\\"{x:802,y:408,t:1527027111583};\\\", \\\"{x:832,y:417,t:1527027111598};\\\", \\\"{x:868,y:431,t:1527027111615};\\\", \\\"{x:885,y:436,t:1527027111632};\\\", \\\"{x:894,y:439,t:1527027111649};\\\", \\\"{x:901,y:442,t:1527027111665};\\\", \\\"{x:904,y:445,t:1527027111681};\\\", \\\"{x:908,y:447,t:1527027111699};\\\", \\\"{x:910,y:449,t:1527027111715};\\\", \\\"{x:914,y:452,t:1527027111732};\\\", \\\"{x:920,y:459,t:1527027111749};\\\", \\\"{x:925,y:465,t:1527027111765};\\\", \\\"{x:931,y:476,t:1527027111782};\\\", \\\"{x:941,y:494,t:1527027111800};\\\", \\\"{x:945,y:501,t:1527027111815};\\\", \\\"{x:948,y:505,t:1527027111832};\\\", \\\"{x:948,y:507,t:1527027111849};\\\", \\\"{x:949,y:509,t:1527027111866};\\\", \\\"{x:950,y:511,t:1527027111888};\\\", \\\"{x:951,y:512,t:1527027111900};\\\", \\\"{x:953,y:513,t:1527027111916};\\\", \\\"{x:956,y:515,t:1527027111933};\\\", \\\"{x:962,y:517,t:1527027111949};\\\", \\\"{x:973,y:519,t:1527027111966};\\\", \\\"{x:991,y:524,t:1527027111983};\\\", \\\"{x:1009,y:530,t:1527027111999};\\\", \\\"{x:1027,y:535,t:1527027112016};\\\", \\\"{x:1040,y:539,t:1527027112033};\\\", \\\"{x:1051,y:543,t:1527027112050};\\\", \\\"{x:1064,y:548,t:1527027112066};\\\", \\\"{x:1075,y:557,t:1527027112083};\\\", \\\"{x:1083,y:563,t:1527027112100};\\\", \\\"{x:1094,y:571,t:1527027112116};\\\", \\\"{x:1104,y:579,t:1527027112133};\\\", \\\"{x:1114,y:586,t:1527027112150};\\\", \\\"{x:1122,y:593,t:1527027112166};\\\", \\\"{x:1131,y:598,t:1527027112184};\\\", \\\"{x:1136,y:602,t:1527027112199};\\\", \\\"{x:1138,y:602,t:1527027112216};\\\", \\\"{x:1140,y:604,t:1527027112239};\\\", \\\"{x:1141,y:604,t:1527027112287};\\\", \\\"{x:1143,y:604,t:1527027112904};\\\", \\\"{x:1144,y:604,t:1527027113008};\\\", \\\"{x:1144,y:603,t:1527027113240};\\\", \\\"{x:1147,y:603,t:1527027114344};\\\", \\\"{x:1148,y:603,t:1527027114351};\\\", \\\"{x:1150,y:603,t:1527027114368};\\\", \\\"{x:1151,y:603,t:1527027114385};\\\", \\\"{x:1152,y:603,t:1527027114664};\\\", \\\"{x:1153,y:605,t:1527027114671};\\\", \\\"{x:1153,y:610,t:1527027114684};\\\", \\\"{x:1154,y:616,t:1527027114701};\\\", \\\"{x:1156,y:621,t:1527027114718};\\\", \\\"{x:1159,y:635,t:1527027114735};\\\", \\\"{x:1162,y:645,t:1527027114751};\\\", \\\"{x:1164,y:654,t:1527027114768};\\\", \\\"{x:1170,y:662,t:1527027114785};\\\", \\\"{x:1177,y:669,t:1527027114801};\\\", \\\"{x:1179,y:671,t:1527027114818};\\\", \\\"{x:1181,y:673,t:1527027114835};\\\", \\\"{x:1182,y:674,t:1527027114851};\\\", \\\"{x:1184,y:674,t:1527027114868};\\\", \\\"{x:1186,y:676,t:1527027114885};\\\", \\\"{x:1187,y:676,t:1527027114903};\\\", \\\"{x:1187,y:677,t:1527027115744};\\\", \\\"{x:1187,y:678,t:1527027116303};\\\", \\\"{x:1186,y:679,t:1527027116680};\\\", \\\"{x:1186,y:680,t:1527027117471};\\\", \\\"{x:1199,y:690,t:1527027117486};\\\", \\\"{x:1243,y:718,t:1527027117503};\\\", \\\"{x:1263,y:731,t:1527027117520};\\\", \\\"{x:1286,y:746,t:1527027117537};\\\", \\\"{x:1308,y:760,t:1527027117553};\\\", \\\"{x:1328,y:769,t:1527027117570};\\\", \\\"{x:1351,y:774,t:1527027117586};\\\", \\\"{x:1363,y:778,t:1527027117603};\\\", \\\"{x:1364,y:778,t:1527027117621};\\\", \\\"{x:1354,y:778,t:1527027117887};\\\", \\\"{x:1332,y:778,t:1527027117903};\\\", \\\"{x:1310,y:780,t:1527027117920};\\\", \\\"{x:1284,y:782,t:1527027117937};\\\", \\\"{x:1249,y:786,t:1527027117953};\\\", \\\"{x:1187,y:788,t:1527027117970};\\\", \\\"{x:1134,y:788,t:1527027117987};\\\", \\\"{x:1075,y:788,t:1527027118003};\\\", \\\"{x:1022,y:788,t:1527027118020};\\\", \\\"{x:987,y:788,t:1527027118037};\\\", \\\"{x:972,y:788,t:1527027118053};\\\", \\\"{x:961,y:788,t:1527027118070};\\\", \\\"{x:951,y:786,t:1527027118087};\\\", \\\"{x:945,y:786,t:1527027118104};\\\", \\\"{x:932,y:784,t:1527027118120};\\\", \\\"{x:924,y:782,t:1527027118137};\\\", \\\"{x:908,y:781,t:1527027118154};\\\", \\\"{x:892,y:779,t:1527027118170};\\\", \\\"{x:875,y:776,t:1527027118187};\\\", \\\"{x:853,y:775,t:1527027118204};\\\", \\\"{x:831,y:770,t:1527027118220};\\\", \\\"{x:811,y:768,t:1527027118237};\\\", \\\"{x:784,y:759,t:1527027118255};\\\", \\\"{x:770,y:753,t:1527027118270};\\\", \\\"{x:749,y:747,t:1527027118287};\\\", \\\"{x:733,y:737,t:1527027118304};\\\", \\\"{x:718,y:728,t:1527027118320};\\\", \\\"{x:702,y:716,t:1527027118338};\\\", \\\"{x:680,y:704,t:1527027118355};\\\", \\\"{x:654,y:688,t:1527027118370};\\\", \\\"{x:619,y:672,t:1527027118387};\\\", \\\"{x:573,y:656,t:1527027118404};\\\", \\\"{x:525,y:640,t:1527027118421};\\\", \\\"{x:495,y:632,t:1527027118437};\\\", \\\"{x:471,y:624,t:1527027118455};\\\", \\\"{x:459,y:618,t:1527027118471};\\\", \\\"{x:446,y:609,t:1527027118488};\\\", \\\"{x:445,y:607,t:1527027118505};\\\", \\\"{x:443,y:604,t:1527027118521};\\\", \\\"{x:442,y:601,t:1527027118538};\\\", \\\"{x:442,y:600,t:1527027118555};\\\", \\\"{x:442,y:599,t:1527027118575};\\\", \\\"{x:442,y:598,t:1527027118588};\\\", \\\"{x:440,y:597,t:1527027118604};\\\", \\\"{x:438,y:596,t:1527027118621};\\\", \\\"{x:434,y:594,t:1527027118638};\\\", \\\"{x:427,y:591,t:1527027118655};\\\", \\\"{x:409,y:584,t:1527027118671};\\\", \\\"{x:394,y:578,t:1527027118688};\\\", \\\"{x:377,y:573,t:1527027118704};\\\", \\\"{x:361,y:569,t:1527027118722};\\\", \\\"{x:348,y:568,t:1527027118739};\\\", \\\"{x:334,y:567,t:1527027118756};\\\", \\\"{x:322,y:566,t:1527027118771};\\\", \\\"{x:308,y:566,t:1527027118788};\\\", \\\"{x:297,y:566,t:1527027118806};\\\", \\\"{x:289,y:566,t:1527027118821};\\\", \\\"{x:283,y:566,t:1527027118839};\\\", \\\"{x:275,y:566,t:1527027118855};\\\", \\\"{x:270,y:567,t:1527027118873};\\\", \\\"{x:267,y:568,t:1527027118889};\\\", \\\"{x:263,y:569,t:1527027118905};\\\", \\\"{x:260,y:571,t:1527027118922};\\\", \\\"{x:254,y:573,t:1527027118939};\\\", \\\"{x:247,y:576,t:1527027118954};\\\", \\\"{x:236,y:580,t:1527027118971};\\\", \\\"{x:225,y:584,t:1527027118989};\\\", \\\"{x:215,y:587,t:1527027119004};\\\", \\\"{x:206,y:590,t:1527027119021};\\\", \\\"{x:192,y:591,t:1527027119038};\\\", \\\"{x:180,y:594,t:1527027119055};\\\", \\\"{x:174,y:595,t:1527027119071};\\\", \\\"{x:173,y:596,t:1527027119095};\\\", \\\"{x:173,y:595,t:1527027119303};\\\", \\\"{x:173,y:593,t:1527027119312};\\\", \\\"{x:173,y:591,t:1527027119322};\\\", \\\"{x:173,y:588,t:1527027119339};\\\", \\\"{x:173,y:584,t:1527027119356};\\\", \\\"{x:172,y:582,t:1527027119372};\\\", \\\"{x:171,y:581,t:1527027119389};\\\", \\\"{x:171,y:580,t:1527027119406};\\\", \\\"{x:171,y:579,t:1527027119423};\\\", \\\"{x:171,y:577,t:1527027119439};\\\", \\\"{x:171,y:575,t:1527027119456};\\\", \\\"{x:171,y:573,t:1527027119472};\\\", \\\"{x:171,y:572,t:1527027119488};\\\", \\\"{x:171,y:571,t:1527027119505};\\\", \\\"{x:171,y:568,t:1527027119522};\\\", \\\"{x:170,y:566,t:1527027119538};\\\", \\\"{x:170,y:564,t:1527027119556};\\\", \\\"{x:169,y:562,t:1527027119573};\\\", \\\"{x:168,y:561,t:1527027119588};\\\", \\\"{x:167,y:560,t:1527027119607};\\\", \\\"{x:167,y:559,t:1527027119622};\\\", \\\"{x:167,y:558,t:1527027119639};\\\", \\\"{x:166,y:555,t:1527027119656};\\\", \\\"{x:166,y:553,t:1527027119672};\\\", \\\"{x:164,y:550,t:1527027119688};\\\", \\\"{x:164,y:549,t:1527027119705};\\\", \\\"{x:163,y:546,t:1527027119722};\\\", \\\"{x:162,y:545,t:1527027119743};\\\", \\\"{x:162,y:544,t:1527027119756};\\\", \\\"{x:161,y:543,t:1527027119773};\\\", \\\"{x:163,y:545,t:1527027120151};\\\", \\\"{x:167,y:547,t:1527027120159};\\\", \\\"{x:169,y:549,t:1527027120172};\\\", \\\"{x:176,y:554,t:1527027120190};\\\", \\\"{x:186,y:561,t:1527027120206};\\\", \\\"{x:204,y:572,t:1527027120223};\\\", \\\"{x:239,y:591,t:1527027120240};\\\", \\\"{x:266,y:601,t:1527027120256};\\\", \\\"{x:301,y:609,t:1527027120273};\\\", \\\"{x:344,y:622,t:1527027120289};\\\", \\\"{x:374,y:629,t:1527027120307};\\\", \\\"{x:405,y:634,t:1527027120323};\\\", \\\"{x:434,y:637,t:1527027120340};\\\", \\\"{x:463,y:639,t:1527027120357};\\\", \\\"{x:493,y:639,t:1527027120372};\\\", \\\"{x:522,y:638,t:1527027120390};\\\", \\\"{x:557,y:630,t:1527027120407};\\\", \\\"{x:588,y:624,t:1527027120423};\\\", \\\"{x:630,y:613,t:1527027120439};\\\", \\\"{x:652,y:607,t:1527027120457};\\\", \\\"{x:675,y:601,t:1527027120472};\\\", \\\"{x:696,y:596,t:1527027120490};\\\", \\\"{x:715,y:589,t:1527027120508};\\\", \\\"{x:735,y:580,t:1527027120523};\\\", \\\"{x:754,y:572,t:1527027120539};\\\", \\\"{x:769,y:566,t:1527027120556};\\\", \\\"{x:786,y:560,t:1527027120573};\\\", \\\"{x:806,y:555,t:1527027120590};\\\", \\\"{x:821,y:550,t:1527027120606};\\\", \\\"{x:831,y:548,t:1527027120623};\\\", \\\"{x:839,y:544,t:1527027120639};\\\", \\\"{x:845,y:539,t:1527027120656};\\\", \\\"{x:853,y:532,t:1527027120673};\\\", \\\"{x:857,y:526,t:1527027120689};\\\", \\\"{x:861,y:521,t:1527027120706};\\\", \\\"{x:862,y:519,t:1527027120723};\\\", \\\"{x:862,y:517,t:1527027120740};\\\", \\\"{x:863,y:515,t:1527027120756};\\\", \\\"{x:863,y:513,t:1527027120774};\\\", \\\"{x:863,y:510,t:1527027120790};\\\", \\\"{x:863,y:504,t:1527027120807};\\\", \\\"{x:863,y:501,t:1527027120823};\\\", \\\"{x:863,y:500,t:1527027120840};\\\", \\\"{x:862,y:497,t:1527027120857};\\\", \\\"{x:860,y:496,t:1527027120873};\\\", \\\"{x:860,y:495,t:1527027120889};\\\", \\\"{x:860,y:494,t:1527027120907};\\\", \\\"{x:859,y:494,t:1527027121039};\\\", \\\"{x:858,y:494,t:1527027121057};\\\", \\\"{x:857,y:494,t:1527027121073};\\\", \\\"{x:856,y:494,t:1527027121087};\\\", \\\"{x:855,y:494,t:1527027121247};\\\", \\\"{x:853,y:495,t:1527027121257};\\\", \\\"{x:846,y:499,t:1527027121273};\\\", \\\"{x:839,y:509,t:1527027121290};\\\", \\\"{x:830,y:521,t:1527027121307};\\\", \\\"{x:818,y:536,t:1527027121324};\\\", \\\"{x:805,y:551,t:1527027121340};\\\", \\\"{x:794,y:565,t:1527027121357};\\\", \\\"{x:781,y:577,t:1527027121373};\\\", \\\"{x:767,y:590,t:1527027121390};\\\", \\\"{x:756,y:602,t:1527027121407};\\\", \\\"{x:745,y:614,t:1527027121424};\\\", \\\"{x:740,y:620,t:1527027121440};\\\", \\\"{x:735,y:629,t:1527027121458};\\\", \\\"{x:727,y:636,t:1527027121474};\\\", \\\"{x:722,y:644,t:1527027121491};\\\", \\\"{x:714,y:654,t:1527027121507};\\\", \\\"{x:705,y:662,t:1527027121524};\\\", \\\"{x:694,y:672,t:1527027121540};\\\", \\\"{x:682,y:683,t:1527027121557};\\\", \\\"{x:671,y:693,t:1527027121573};\\\", \\\"{x:661,y:701,t:1527027121590};\\\", \\\"{x:652,y:707,t:1527027121607};\\\", \\\"{x:650,y:708,t:1527027121624};\\\", \\\"{x:649,y:709,t:1527027121640};\\\", \\\"{x:647,y:709,t:1527027121658};\\\", \\\"{x:645,y:710,t:1527027121675};\\\", \\\"{x:640,y:713,t:1527027121690};\\\", \\\"{x:636,y:716,t:1527027121707};\\\", \\\"{x:629,y:719,t:1527027121724};\\\", \\\"{x:623,y:722,t:1527027121741};\\\", \\\"{x:611,y:726,t:1527027121757};\\\", \\\"{x:599,y:729,t:1527027121775};\\\", \\\"{x:585,y:733,t:1527027121790};\\\", \\\"{x:563,y:739,t:1527027121808};\\\", \\\"{x:551,y:741,t:1527027121824};\\\", \\\"{x:543,y:742,t:1527027121840};\\\", \\\"{x:539,y:742,t:1527027121857};\\\", \\\"{x:534,y:742,t:1527027121875};\\\", \\\"{x:530,y:743,t:1527027121891};\\\", \\\"{x:528,y:743,t:1527027121907};\\\", \\\"{x:527,y:743,t:1527027121925};\\\", \\\"{x:526,y:744,t:1527027121951};\\\", \\\"{x:525,y:744,t:1527027122015};\\\", \\\"{x:525,y:744,t:1527027122052};\\\", \\\"{x:528,y:745,t:1527027122272};\\\", \\\"{x:541,y:745,t:1527027122280};\\\", \\\"{x:556,y:745,t:1527027122291};\\\", \\\"{x:582,y:745,t:1527027122308};\\\", \\\"{x:629,y:739,t:1527027122324};\\\", \\\"{x:706,y:728,t:1527027122341};\\\", \\\"{x:798,y:714,t:1527027122358};\\\", \\\"{x:898,y:700,t:1527027122375};\\\", \\\"{x:995,y:687,t:1527027122391};\\\", \\\"{x:1137,y:685,t:1527027122407};\\\", \\\"{x:1209,y:667,t:1527027122424};\\\", \\\"{x:1276,y:644,t:1527027122441};\\\", \\\"{x:1345,y:615,t:1527027122457};\\\", \\\"{x:1408,y:579,t:1527027122474};\\\", \\\"{x:1457,y:550,t:1527027122492};\\\", \\\"{x:1507,y:529,t:1527027122507};\\\", \\\"{x:1529,y:515,t:1527027122524};\\\", \\\"{x:1537,y:511,t:1527027122542};\\\", \\\"{x:1537,y:510,t:1527027122559};\\\", \\\"{x:1537,y:508,t:1527027122574};\\\", \\\"{x:1536,y:483,t:1527027122591};\\\", \\\"{x:1528,y:459,t:1527027122607};\\\", \\\"{x:1515,y:436,t:1527027122624};\\\", \\\"{x:1497,y:413,t:1527027122641};\\\", \\\"{x:1483,y:394,t:1527027122658};\\\", \\\"{x:1460,y:367,t:1527027122675};\\\", \\\"{x:1434,y:346,t:1527027122691};\\\", \\\"{x:1415,y:326,t:1527027122708};\\\", \\\"{x:1403,y:314,t:1527027122725};\\\", \\\"{x:1396,y:306,t:1527027122742};\\\", \\\"{x:1388,y:292,t:1527027122758};\\\", \\\"{x:1386,y:287,t:1527027122775};\\\", \\\"{x:1385,y:284,t:1527027122792};\\\", \\\"{x:1385,y:283,t:1527027122808};\\\", \\\"{x:1385,y:282,t:1527027122824};\\\", \\\"{x:1385,y:281,t:1527027122841};\\\", \\\"{x:1385,y:280,t:1527027122858};\\\", \\\"{x:1384,y:278,t:1527027122874};\\\", \\\"{x:1384,y:276,t:1527027122891};\\\", \\\"{x:1384,y:274,t:1527027122908};\\\", \\\"{x:1384,y:271,t:1527027122925};\\\", \\\"{x:1384,y:267,t:1527027122942};\\\", \\\"{x:1384,y:263,t:1527027122959};\\\", \\\"{x:1384,y:260,t:1527027122974};\\\", \\\"{x:1384,y:257,t:1527027122991};\\\", \\\"{x:1384,y:254,t:1527027123071};\\\", \\\"{x:1382,y:252,t:1527027123079};\\\", \\\"{x:1378,y:248,t:1527027123091};\\\", \\\"{x:1371,y:242,t:1527027123109};\\\", \\\"{x:1363,y:235,t:1527027123124};\\\" ] }, { \\\"rt\\\": 54946, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 511643, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1341,y:217,t:1527027123223};\\\", \\\"{x:1337,y:214,t:1527027123248};\\\", \\\"{x:1335,y:213,t:1527027123259};\\\", \\\"{x:1333,y:211,t:1527027123276};\\\", \\\"{x:1328,y:207,t:1527027123291};\\\", \\\"{x:1318,y:200,t:1527027123312};\\\", \\\"{x:1314,y:197,t:1527027123326};\\\", \\\"{x:1308,y:192,t:1527027123342};\\\", \\\"{x:1304,y:191,t:1527027123359};\\\", \\\"{x:1302,y:187,t:1527027123376};\\\", \\\"{x:1301,y:187,t:1527027123391};\\\", \\\"{x:1299,y:186,t:1527027123409};\\\", \\\"{x:1298,y:186,t:1527027123426};\\\", \\\"{x:1297,y:186,t:1527027123442};\\\", \\\"{x:1295,y:185,t:1527027123459};\\\", \\\"{x:1291,y:183,t:1527027123476};\\\", \\\"{x:1289,y:182,t:1527027123492};\\\", \\\"{x:1286,y:181,t:1527027123509};\\\", \\\"{x:1285,y:181,t:1527027123526};\\\", \\\"{x:1283,y:180,t:1527027123541};\\\", \\\"{x:1278,y:180,t:1527027123558};\\\", \\\"{x:1256,y:182,t:1527027123575};\\\", \\\"{x:1234,y:184,t:1527027123592};\\\", \\\"{x:1208,y:187,t:1527027123608};\\\", \\\"{x:1184,y:190,t:1527027123625};\\\", \\\"{x:1115,y:191,t:1527027123690};\\\", \\\"{x:1109,y:191,t:1527027123697};\\\", \\\"{x:1101,y:191,t:1527027123709};\\\", \\\"{x:1084,y:191,t:1527027123726};\\\", \\\"{x:1057,y:193,t:1527027123742};\\\", \\\"{x:1003,y:213,t:1527027123758};\\\", \\\"{x:900,y:332,t:1527027123776};\\\", \\\"{x:835,y:434,t:1527027123792};\\\", \\\"{x:768,y:495,t:1527027123809};\\\", \\\"{x:714,y:528,t:1527027123826};\\\", \\\"{x:695,y:538,t:1527027123843};\\\", \\\"{x:693,y:540,t:1527027123859};\\\", \\\"{x:693,y:541,t:1527027123903};\\\", \\\"{x:693,y:542,t:1527027123935};\\\", \\\"{x:693,y:544,t:1527027123943};\\\", \\\"{x:696,y:546,t:1527027123959};\\\", \\\"{x:705,y:549,t:1527027123975};\\\", \\\"{x:711,y:550,t:1527027123993};\\\", \\\"{x:713,y:550,t:1527027124008};\\\", \\\"{x:716,y:552,t:1527027124025};\\\", \\\"{x:719,y:553,t:1527027124042};\\\", \\\"{x:724,y:556,t:1527027124059};\\\", \\\"{x:732,y:562,t:1527027124076};\\\", \\\"{x:750,y:582,t:1527027124093};\\\", \\\"{x:765,y:607,t:1527027124110};\\\", \\\"{x:776,y:631,t:1527027124126};\\\", \\\"{x:784,y:649,t:1527027124142};\\\", \\\"{x:786,y:679,t:1527027124159};\\\", \\\"{x:786,y:697,t:1527027124176};\\\", \\\"{x:786,y:720,t:1527027124193};\\\", \\\"{x:777,y:752,t:1527027124209};\\\", \\\"{x:768,y:791,t:1527027124226};\\\", \\\"{x:757,y:830,t:1527027124243};\\\", \\\"{x:754,y:855,t:1527027124260};\\\", \\\"{x:750,y:879,t:1527027124276};\\\", \\\"{x:748,y:895,t:1527027124292};\\\", \\\"{x:748,y:899,t:1527027124310};\\\", \\\"{x:748,y:900,t:1527027124326};\\\", \\\"{x:748,y:896,t:1527027124383};\\\", \\\"{x:748,y:891,t:1527027124392};\\\", \\\"{x:744,y:879,t:1527027124410};\\\", \\\"{x:741,y:872,t:1527027124425};\\\", \\\"{x:741,y:869,t:1527027124442};\\\", \\\"{x:740,y:867,t:1527027124460};\\\", \\\"{x:739,y:862,t:1527027124476};\\\", \\\"{x:738,y:859,t:1527027124493};\\\", \\\"{x:736,y:856,t:1527027124510};\\\", \\\"{x:736,y:855,t:1527027124526};\\\", \\\"{x:736,y:854,t:1527027124559};\\\", \\\"{x:736,y:852,t:1527027124577};\\\", \\\"{x:734,y:850,t:1527027124615};\\\", \\\"{x:734,y:849,t:1527027124671};\\\", \\\"{x:733,y:849,t:1527027124832};\\\", \\\"{x:731,y:848,t:1527027124863};\\\", \\\"{x:730,y:848,t:1527027125175};\\\", \\\"{x:729,y:848,t:1527027125239};\\\", \\\"{x:728,y:848,t:1527027125279};\\\", \\\"{x:727,y:848,t:1527027125303};\\\", \\\"{x:726,y:848,t:1527027125311};\\\", \\\"{x:725,y:848,t:1527027125343};\\\", \\\"{x:724,y:848,t:1527027125407};\\\", \\\"{x:723,y:848,t:1527027125423};\\\", \\\"{x:722,y:848,t:1527027125439};\\\", \\\"{x:721,y:848,t:1527027125719};\\\", \\\"{x:720,y:848,t:1527027125767};\\\", \\\"{x:719,y:848,t:1527027125816};\\\", \\\"{x:718,y:848,t:1527027126655};\\\", \\\"{x:718,y:849,t:1527027126663};\\\", \\\"{x:717,y:849,t:1527027126759};\\\", \\\"{x:716,y:849,t:1527027126840};\\\", \\\"{x:715,y:849,t:1527027127479};\\\", \\\"{x:714,y:849,t:1527027127495};\\\", \\\"{x:713,y:849,t:1527027127735};\\\", \\\"{x:712,y:849,t:1527027127775};\\\", \\\"{x:711,y:849,t:1527027128551};\\\", \\\"{x:710,y:849,t:1527027128563};\\\", \\\"{x:707,y:849,t:1527027128579};\\\", \\\"{x:703,y:849,t:1527027128596};\\\", \\\"{x:702,y:850,t:1527027128612};\\\", \\\"{x:701,y:850,t:1527027128631};\\\", \\\"{x:700,y:850,t:1527027128647};\\\", \\\"{x:702,y:850,t:1527027129095};\\\", \\\"{x:713,y:849,t:1527027129103};\\\", \\\"{x:724,y:848,t:1527027129113};\\\", \\\"{x:739,y:848,t:1527027129130};\\\", \\\"{x:745,y:846,t:1527027129147};\\\", \\\"{x:756,y:842,t:1527027129162};\\\", \\\"{x:778,y:838,t:1527027129180};\\\", \\\"{x:850,y:838,t:1527027129197};\\\", \\\"{x:971,y:838,t:1527027129213};\\\", \\\"{x:1118,y:836,t:1527027129230};\\\", \\\"{x:1329,y:836,t:1527027129247};\\\", \\\"{x:1437,y:836,t:1527027129263};\\\", \\\"{x:1525,y:836,t:1527027129279};\\\", \\\"{x:1601,y:836,t:1527027129296};\\\", \\\"{x:1648,y:841,t:1527027129313};\\\", \\\"{x:1667,y:844,t:1527027129329};\\\", \\\"{x:1672,y:844,t:1527027129347};\\\", \\\"{x:1673,y:844,t:1527027129363};\\\", \\\"{x:1673,y:845,t:1527027129440};\\\", \\\"{x:1670,y:845,t:1527027129464};\\\", \\\"{x:1664,y:845,t:1527027129480};\\\", \\\"{x:1651,y:845,t:1527027129497};\\\", \\\"{x:1636,y:845,t:1527027129514};\\\", \\\"{x:1621,y:845,t:1527027129530};\\\", \\\"{x:1604,y:845,t:1527027129547};\\\", \\\"{x:1584,y:843,t:1527027129564};\\\", \\\"{x:1561,y:843,t:1527027129579};\\\", \\\"{x:1535,y:843,t:1527027129597};\\\", \\\"{x:1513,y:843,t:1527027129614};\\\", \\\"{x:1496,y:836,t:1527027129630};\\\", \\\"{x:1475,y:832,t:1527027129647};\\\", \\\"{x:1468,y:830,t:1527027129664};\\\", \\\"{x:1468,y:829,t:1527027129976};\\\", \\\"{x:1469,y:828,t:1527027129991};\\\", \\\"{x:1470,y:828,t:1527027129998};\\\", \\\"{x:1469,y:828,t:1527027130271};\\\", \\\"{x:1468,y:828,t:1527027130287};\\\", \\\"{x:1467,y:828,t:1527027130311};\\\", \\\"{x:1466,y:828,t:1527027130335};\\\", \\\"{x:1465,y:828,t:1527027130351};\\\", \\\"{x:1464,y:828,t:1527027130375};\\\", \\\"{x:1463,y:828,t:1527027130383};\\\", \\\"{x:1462,y:828,t:1527027130398};\\\", \\\"{x:1461,y:828,t:1527027130414};\\\", \\\"{x:1459,y:828,t:1527027130431};\\\", \\\"{x:1458,y:828,t:1527027130448};\\\", \\\"{x:1457,y:828,t:1527027130464};\\\", \\\"{x:1456,y:828,t:1527027130487};\\\", \\\"{x:1455,y:828,t:1527027130543};\\\", \\\"{x:1454,y:828,t:1527027130550};\\\", \\\"{x:1453,y:828,t:1527027130565};\\\", \\\"{x:1449,y:828,t:1527027130581};\\\", \\\"{x:1443,y:829,t:1527027130598};\\\", \\\"{x:1429,y:829,t:1527027130614};\\\", \\\"{x:1416,y:829,t:1527027130630};\\\", \\\"{x:1399,y:829,t:1527027130648};\\\", \\\"{x:1378,y:829,t:1527027130665};\\\", \\\"{x:1349,y:829,t:1527027130680};\\\", \\\"{x:1323,y:827,t:1527027130698};\\\", \\\"{x:1299,y:823,t:1527027130715};\\\", \\\"{x:1276,y:818,t:1527027130731};\\\", \\\"{x:1254,y:815,t:1527027130748};\\\", \\\"{x:1241,y:812,t:1527027130765};\\\", \\\"{x:1229,y:811,t:1527027130781};\\\", \\\"{x:1221,y:808,t:1527027130798};\\\", \\\"{x:1218,y:808,t:1527027130815};\\\", \\\"{x:1216,y:808,t:1527027131016};\\\", \\\"{x:1214,y:807,t:1527027131030};\\\", \\\"{x:1210,y:807,t:1527027131048};\\\", \\\"{x:1205,y:807,t:1527027131065};\\\", \\\"{x:1186,y:807,t:1527027131082};\\\", \\\"{x:1157,y:807,t:1527027131098};\\\", \\\"{x:1127,y:807,t:1527027131115};\\\", \\\"{x:1077,y:807,t:1527027131132};\\\", \\\"{x:1033,y:802,t:1527027131148};\\\", \\\"{x:994,y:798,t:1527027131165};\\\", \\\"{x:971,y:794,t:1527027131182};\\\", \\\"{x:960,y:790,t:1527027131198};\\\", \\\"{x:959,y:790,t:1527027131495};\\\", \\\"{x:957,y:790,t:1527027131510};\\\", \\\"{x:954,y:790,t:1527027131518};\\\", \\\"{x:949,y:790,t:1527027131532};\\\", \\\"{x:940,y:790,t:1527027131549};\\\", \\\"{x:937,y:790,t:1527027131565};\\\", \\\"{x:936,y:790,t:1527027131582};\\\", \\\"{x:937,y:790,t:1527027133663};\\\", \\\"{x:937,y:789,t:1527027133670};\\\", \\\"{x:938,y:789,t:1527027133695};\\\", \\\"{x:936,y:789,t:1527027134671};\\\", \\\"{x:933,y:789,t:1527027134684};\\\", \\\"{x:930,y:790,t:1527027134701};\\\", \\\"{x:931,y:790,t:1527027135815};\\\", \\\"{x:934,y:791,t:1527027135823};\\\", \\\"{x:936,y:792,t:1527027135834};\\\", \\\"{x:942,y:796,t:1527027135852};\\\", \\\"{x:944,y:798,t:1527027135869};\\\", \\\"{x:945,y:799,t:1527027135885};\\\", \\\"{x:946,y:801,t:1527027135902};\\\", \\\"{x:947,y:801,t:1527027135919};\\\", \\\"{x:948,y:802,t:1527027135935};\\\", \\\"{x:949,y:802,t:1527027135952};\\\", \\\"{x:950,y:802,t:1527027135975};\\\", \\\"{x:951,y:803,t:1527027136319};\\\", \\\"{x:954,y:805,t:1527027136336};\\\", \\\"{x:959,y:809,t:1527027136352};\\\", \\\"{x:962,y:811,t:1527027136369};\\\", \\\"{x:967,y:811,t:1527027136551};\\\", \\\"{x:974,y:812,t:1527027136559};\\\", \\\"{x:984,y:813,t:1527027136570};\\\", \\\"{x:1003,y:814,t:1527027136586};\\\", \\\"{x:1017,y:814,t:1527027136602};\\\", \\\"{x:1033,y:814,t:1527027136619};\\\", \\\"{x:1057,y:814,t:1527027136636};\\\", \\\"{x:1089,y:814,t:1527027136652};\\\", \\\"{x:1120,y:814,t:1527027136669};\\\", \\\"{x:1150,y:814,t:1527027136686};\\\", \\\"{x:1176,y:811,t:1527027136702};\\\", \\\"{x:1205,y:810,t:1527027136718};\\\", \\\"{x:1214,y:810,t:1527027136736};\\\", \\\"{x:1220,y:809,t:1527027136753};\\\", \\\"{x:1224,y:808,t:1527027136769};\\\", \\\"{x:1225,y:808,t:1527027136786};\\\", \\\"{x:1226,y:807,t:1527027136839};\\\", \\\"{x:1227,y:807,t:1527027136854};\\\", \\\"{x:1230,y:805,t:1527027136869};\\\", \\\"{x:1235,y:800,t:1527027136886};\\\", \\\"{x:1241,y:796,t:1527027136903};\\\", \\\"{x:1245,y:794,t:1527027136918};\\\", \\\"{x:1249,y:791,t:1527027136936};\\\", \\\"{x:1251,y:789,t:1527027136953};\\\", \\\"{x:1251,y:788,t:1527027136975};\\\", \\\"{x:1253,y:787,t:1527027136986};\\\", \\\"{x:1253,y:785,t:1527027137007};\\\", \\\"{x:1253,y:783,t:1527027137023};\\\", \\\"{x:1254,y:783,t:1527027137036};\\\", \\\"{x:1255,y:778,t:1527027137053};\\\", \\\"{x:1258,y:776,t:1527027137069};\\\", \\\"{x:1260,y:773,t:1527027137086};\\\", \\\"{x:1265,y:771,t:1527027137102};\\\", \\\"{x:1268,y:769,t:1527027137119};\\\", \\\"{x:1270,y:768,t:1527027137136};\\\", \\\"{x:1276,y:763,t:1527027137154};\\\", \\\"{x:1284,y:757,t:1527027137169};\\\", \\\"{x:1297,y:748,t:1527027137186};\\\", \\\"{x:1310,y:737,t:1527027137203};\\\", \\\"{x:1326,y:726,t:1527027137220};\\\", \\\"{x:1339,y:717,t:1527027137237};\\\", \\\"{x:1346,y:711,t:1527027137254};\\\", \\\"{x:1348,y:709,t:1527027137270};\\\", \\\"{x:1345,y:710,t:1527027137471};\\\", \\\"{x:1344,y:711,t:1527027137486};\\\", \\\"{x:1338,y:714,t:1527027137502};\\\", \\\"{x:1336,y:716,t:1527027137520};\\\", \\\"{x:1334,y:718,t:1527027137536};\\\", \\\"{x:1332,y:719,t:1527027137554};\\\", \\\"{x:1331,y:720,t:1527027137571};\\\", \\\"{x:1330,y:722,t:1527027137586};\\\", \\\"{x:1328,y:724,t:1527027137603};\\\", \\\"{x:1327,y:725,t:1527027137623};\\\", \\\"{x:1327,y:726,t:1527027137647};\\\", \\\"{x:1326,y:727,t:1527027137727};\\\", \\\"{x:1326,y:728,t:1527027137743};\\\", \\\"{x:1326,y:729,t:1527027137767};\\\", \\\"{x:1326,y:730,t:1527027137807};\\\", \\\"{x:1326,y:731,t:1527027137823};\\\", \\\"{x:1326,y:732,t:1527027137837};\\\", \\\"{x:1326,y:733,t:1527027137855};\\\", \\\"{x:1326,y:734,t:1527027137871};\\\", \\\"{x:1326,y:736,t:1527027137887};\\\", \\\"{x:1326,y:737,t:1527027137911};\\\", \\\"{x:1326,y:738,t:1527027137926};\\\", \\\"{x:1326,y:739,t:1527027137943};\\\", \\\"{x:1328,y:741,t:1527027137953};\\\", \\\"{x:1330,y:746,t:1527027137970};\\\", \\\"{x:1333,y:750,t:1527027137987};\\\", \\\"{x:1334,y:752,t:1527027138003};\\\", \\\"{x:1335,y:753,t:1527027138020};\\\", \\\"{x:1337,y:756,t:1527027138037};\\\", \\\"{x:1337,y:759,t:1527027138054};\\\", \\\"{x:1339,y:760,t:1527027138070};\\\", \\\"{x:1339,y:761,t:1527027139200};\\\", \\\"{x:1336,y:761,t:1527027147744};\\\", \\\"{x:1316,y:756,t:1527027147754};\\\", \\\"{x:1273,y:742,t:1527027147771};\\\", \\\"{x:1244,y:735,t:1527027147788};\\\", \\\"{x:1228,y:734,t:1527027147804};\\\", \\\"{x:1215,y:732,t:1527027147821};\\\", \\\"{x:1212,y:732,t:1527027147838};\\\", \\\"{x:1212,y:731,t:1527027148649};\\\", \\\"{x:1213,y:731,t:1527027148656};\\\", \\\"{x:1226,y:728,t:1527027148672};\\\", \\\"{x:1247,y:732,t:1527027148688};\\\", \\\"{x:1253,y:733,t:1527027148705};\\\", \\\"{x:1255,y:734,t:1527027148722};\\\", \\\"{x:1256,y:734,t:1527027148817};\\\", \\\"{x:1260,y:735,t:1527027148824};\\\", \\\"{x:1267,y:735,t:1527027148838};\\\", \\\"{x:1281,y:738,t:1527027148855};\\\", \\\"{x:1287,y:739,t:1527027148873};\\\", \\\"{x:1288,y:739,t:1527027148888};\\\", \\\"{x:1289,y:739,t:1527027148905};\\\", \\\"{x:1289,y:741,t:1527027149000};\\\", \\\"{x:1291,y:743,t:1527027149009};\\\", \\\"{x:1292,y:744,t:1527027149023};\\\", \\\"{x:1296,y:749,t:1527027149040};\\\", \\\"{x:1298,y:752,t:1527027149056};\\\", \\\"{x:1303,y:754,t:1527027149073};\\\", \\\"{x:1305,y:755,t:1527027149088};\\\", \\\"{x:1309,y:757,t:1527027149105};\\\", \\\"{x:1311,y:758,t:1527027149122};\\\", \\\"{x:1316,y:759,t:1527027149139};\\\", \\\"{x:1321,y:760,t:1527027149155};\\\", \\\"{x:1331,y:760,t:1527027149173};\\\", \\\"{x:1343,y:760,t:1527027149190};\\\", \\\"{x:1357,y:760,t:1527027149205};\\\", \\\"{x:1366,y:760,t:1527027149222};\\\", \\\"{x:1372,y:760,t:1527027149239};\\\", \\\"{x:1373,y:760,t:1527027149255};\\\", \\\"{x:1374,y:761,t:1527027149345};\\\", \\\"{x:1373,y:761,t:1527027149457};\\\", \\\"{x:1372,y:763,t:1527027149504};\\\", \\\"{x:1370,y:763,t:1527027149528};\\\", \\\"{x:1369,y:763,t:1527027149539};\\\", \\\"{x:1367,y:763,t:1527027149556};\\\", \\\"{x:1364,y:763,t:1527027149572};\\\", \\\"{x:1362,y:763,t:1527027149589};\\\", \\\"{x:1360,y:763,t:1527027149606};\\\", \\\"{x:1359,y:763,t:1527027149622};\\\", \\\"{x:1359,y:762,t:1527027149639};\\\", \\\"{x:1358,y:762,t:1527027149656};\\\", \\\"{x:1357,y:762,t:1527027149672};\\\", \\\"{x:1356,y:762,t:1527027149689};\\\", \\\"{x:1353,y:760,t:1527027149706};\\\", \\\"{x:1351,y:760,t:1527027149729};\\\", \\\"{x:1350,y:760,t:1527027149739};\\\", \\\"{x:1348,y:760,t:1527027149756};\\\", \\\"{x:1344,y:760,t:1527027149772};\\\", \\\"{x:1341,y:760,t:1527027149790};\\\", \\\"{x:1337,y:760,t:1527027149806};\\\", \\\"{x:1335,y:760,t:1527027149822};\\\", \\\"{x:1331,y:759,t:1527027149839};\\\", \\\"{x:1326,y:759,t:1527027149856};\\\", \\\"{x:1322,y:759,t:1527027149872};\\\", \\\"{x:1319,y:759,t:1527027149889};\\\", \\\"{x:1317,y:759,t:1527027149906};\\\", \\\"{x:1316,y:759,t:1527027149923};\\\", \\\"{x:1317,y:759,t:1527027150225};\\\", \\\"{x:1318,y:759,t:1527027150240};\\\", \\\"{x:1319,y:759,t:1527027150256};\\\", \\\"{x:1320,y:759,t:1527027150288};\\\", \\\"{x:1321,y:759,t:1527027150296};\\\", \\\"{x:1322,y:759,t:1527027150306};\\\", \\\"{x:1323,y:759,t:1527027150323};\\\", \\\"{x:1325,y:759,t:1527027150341};\\\", \\\"{x:1328,y:759,t:1527027150356};\\\", \\\"{x:1330,y:759,t:1527027150373};\\\", \\\"{x:1331,y:759,t:1527027150392};\\\", \\\"{x:1329,y:759,t:1527027153353};\\\", \\\"{x:1299,y:769,t:1527027153359};\\\", \\\"{x:1230,y:781,t:1527027153375};\\\", \\\"{x:971,y:828,t:1527027153392};\\\", \\\"{x:902,y:830,t:1527027153410};\\\", \\\"{x:872,y:795,t:1527027153425};\\\", \\\"{x:814,y:721,t:1527027153442};\\\", \\\"{x:737,y:635,t:1527027153459};\\\", \\\"{x:669,y:568,t:1527027153475};\\\", \\\"{x:616,y:518,t:1527027153493};\\\", \\\"{x:569,y:469,t:1527027153509};\\\", \\\"{x:524,y:417,t:1527027153525};\\\", \\\"{x:487,y:382,t:1527027153542};\\\", \\\"{x:469,y:363,t:1527027153559};\\\", \\\"{x:457,y:353,t:1527027153576};\\\", \\\"{x:456,y:352,t:1527027153592};\\\", \\\"{x:468,y:351,t:1527027153640};\\\", \\\"{x:486,y:348,t:1527027153648};\\\", \\\"{x:506,y:348,t:1527027153659};\\\", \\\"{x:526,y:348,t:1527027153677};\\\", \\\"{x:532,y:348,t:1527027153692};\\\", \\\"{x:533,y:348,t:1527027153709};\\\", \\\"{x:535,y:348,t:1527027153727};\\\", \\\"{x:542,y:349,t:1527027153743};\\\", \\\"{x:551,y:362,t:1527027153760};\\\", \\\"{x:563,y:393,t:1527027153776};\\\", \\\"{x:569,y:414,t:1527027153793};\\\", \\\"{x:574,y:434,t:1527027153810};\\\", \\\"{x:576,y:445,t:1527027153826};\\\", \\\"{x:579,y:459,t:1527027153844};\\\", \\\"{x:579,y:469,t:1527027153859};\\\", \\\"{x:579,y:475,t:1527027153876};\\\", \\\"{x:579,y:484,t:1527027153893};\\\", \\\"{x:579,y:486,t:1527027153909};\\\", \\\"{x:578,y:486,t:1527027153926};\\\", \\\"{x:578,y:488,t:1527027154064};\\\", \\\"{x:580,y:489,t:1527027154076};\\\", \\\"{x:584,y:492,t:1527027154093};\\\", \\\"{x:585,y:492,t:1527027154112};\\\", \\\"{x:586,y:493,t:1527027154126};\\\", \\\"{x:587,y:493,t:1527027154144};\\\", \\\"{x:588,y:493,t:1527027154160};\\\", \\\"{x:589,y:493,t:1527027154232};\\\", \\\"{x:590,y:493,t:1527027154264};\\\", \\\"{x:591,y:499,t:1527027154680};\\\", \\\"{x:595,y:502,t:1527027154692};\\\", \\\"{x:600,y:507,t:1527027154710};\\\", \\\"{x:609,y:517,t:1527027154726};\\\", \\\"{x:621,y:530,t:1527027154744};\\\", \\\"{x:639,y:544,t:1527027154760};\\\", \\\"{x:642,y:547,t:1527027154777};\\\", \\\"{x:643,y:547,t:1527027154808};\\\", \\\"{x:645,y:547,t:1527027154827};\\\", \\\"{x:643,y:542,t:1527027154905};\\\", \\\"{x:626,y:523,t:1527027154913};\\\", \\\"{x:605,y:504,t:1527027154927};\\\", \\\"{x:578,y:482,t:1527027154944};\\\", \\\"{x:554,y:468,t:1527027154961};\\\", \\\"{x:545,y:462,t:1527027154977};\\\", \\\"{x:539,y:460,t:1527027154994};\\\", \\\"{x:539,y:459,t:1527027155024};\\\", \\\"{x:539,y:458,t:1527027155056};\\\", \\\"{x:541,y:458,t:1527027155104};\\\", \\\"{x:543,y:459,t:1527027155112};\\\", \\\"{x:546,y:461,t:1527027155127};\\\", \\\"{x:551,y:465,t:1527027155143};\\\", \\\"{x:556,y:469,t:1527027155160};\\\", \\\"{x:557,y:470,t:1527027155177};\\\", \\\"{x:560,y:473,t:1527027155193};\\\", \\\"{x:562,y:476,t:1527027155210};\\\", \\\"{x:566,y:478,t:1527027155227};\\\", \\\"{x:570,y:480,t:1527027155245};\\\", \\\"{x:579,y:483,t:1527027155260};\\\", \\\"{x:584,y:485,t:1527027155277};\\\", \\\"{x:586,y:486,t:1527027155294};\\\", \\\"{x:589,y:487,t:1527027155311};\\\", \\\"{x:591,y:487,t:1527027155327};\\\", \\\"{x:592,y:488,t:1527027155342};\\\", \\\"{x:594,y:490,t:1527027155359};\\\", \\\"{x:595,y:491,t:1527027155375};\\\", \\\"{x:597,y:492,t:1527027155393};\\\", \\\"{x:599,y:493,t:1527027155409};\\\", \\\"{x:599,y:494,t:1527027155425};\\\", \\\"{x:601,y:494,t:1527027155442};\\\", \\\"{x:602,y:495,t:1527027155832};\\\", \\\"{x:607,y:503,t:1527027155844};\\\", \\\"{x:622,y:524,t:1527027155862};\\\", \\\"{x:642,y:551,t:1527027155878};\\\", \\\"{x:691,y:602,t:1527027155895};\\\", \\\"{x:769,y:671,t:1527027155911};\\\", \\\"{x:879,y:745,t:1527027155928};\\\", \\\"{x:1072,y:866,t:1527027155944};\\\", \\\"{x:1207,y:925,t:1527027155961};\\\", \\\"{x:1330,y:971,t:1527027155978};\\\", \\\"{x:1449,y:1005,t:1527027155994};\\\", \\\"{x:1541,y:1034,t:1527027156011};\\\", \\\"{x:1582,y:1044,t:1527027156027};\\\", \\\"{x:1592,y:1046,t:1527027156044};\\\", \\\"{x:1592,y:1042,t:1527027156105};\\\", \\\"{x:1581,y:1033,t:1527027156112};\\\", \\\"{x:1570,y:1025,t:1527027156127};\\\", \\\"{x:1542,y:1003,t:1527027156144};\\\", \\\"{x:1517,y:983,t:1527027156161};\\\", \\\"{x:1495,y:956,t:1527027156178};\\\", \\\"{x:1477,y:930,t:1527027156194};\\\", \\\"{x:1464,y:905,t:1527027156211};\\\", \\\"{x:1455,y:888,t:1527027156228};\\\", \\\"{x:1450,y:878,t:1527027156244};\\\", \\\"{x:1444,y:868,t:1527027156261};\\\", \\\"{x:1434,y:850,t:1527027156279};\\\", \\\"{x:1424,y:830,t:1527027156294};\\\", \\\"{x:1412,y:806,t:1527027156311};\\\", \\\"{x:1393,y:773,t:1527027156328};\\\", \\\"{x:1374,y:749,t:1527027156345};\\\", \\\"{x:1361,y:735,t:1527027156361};\\\", \\\"{x:1353,y:728,t:1527027156378};\\\", \\\"{x:1352,y:727,t:1527027156400};\\\", \\\"{x:1351,y:727,t:1527027156412};\\\", \\\"{x:1350,y:725,t:1527027156449};\\\", \\\"{x:1350,y:724,t:1527027156592};\\\", \\\"{x:1350,y:723,t:1527027156600};\\\", \\\"{x:1350,y:722,t:1527027156615};\\\", \\\"{x:1351,y:721,t:1527027156628};\\\", \\\"{x:1350,y:721,t:1527027156832};\\\", \\\"{x:1350,y:722,t:1527027156848};\\\", \\\"{x:1349,y:722,t:1527027156861};\\\", \\\"{x:1349,y:723,t:1527027156879};\\\", \\\"{x:1349,y:726,t:1527027156895};\\\", \\\"{x:1349,y:728,t:1527027156911};\\\", \\\"{x:1349,y:732,t:1527027156928};\\\", \\\"{x:1350,y:736,t:1527027156946};\\\", \\\"{x:1351,y:739,t:1527027156961};\\\", \\\"{x:1353,y:741,t:1527027156978};\\\", \\\"{x:1353,y:742,t:1527027156996};\\\", \\\"{x:1348,y:743,t:1527027176840};\\\", \\\"{x:1285,y:745,t:1527027176857};\\\", \\\"{x:1190,y:745,t:1527027176874};\\\", \\\"{x:1082,y:745,t:1527027176891};\\\", \\\"{x:980,y:736,t:1527027176907};\\\", \\\"{x:875,y:720,t:1527027176924};\\\", \\\"{x:764,y:691,t:1527027176941};\\\", \\\"{x:651,y:658,t:1527027176957};\\\", \\\"{x:537,y:625,t:1527027176975};\\\", \\\"{x:438,y:597,t:1527027176992};\\\", \\\"{x:363,y:576,t:1527027177008};\\\", \\\"{x:332,y:572,t:1527027177028};\\\", \\\"{x:331,y:572,t:1527027177045};\\\", \\\"{x:330,y:572,t:1527027177064};\\\", \\\"{x:330,y:573,t:1527027177078};\\\", \\\"{x:330,y:577,t:1527027177095};\\\", \\\"{x:330,y:580,t:1527027177112};\\\", \\\"{x:330,y:586,t:1527027177128};\\\", \\\"{x:330,y:594,t:1527027177146};\\\", \\\"{x:330,y:603,t:1527027177161};\\\", \\\"{x:332,y:614,t:1527027177178};\\\", \\\"{x:336,y:620,t:1527027177195};\\\", \\\"{x:340,y:624,t:1527027177213};\\\", \\\"{x:347,y:627,t:1527027177228};\\\", \\\"{x:354,y:630,t:1527027177245};\\\", \\\"{x:358,y:632,t:1527027177263};\\\", \\\"{x:360,y:633,t:1527027177278};\\\", \\\"{x:364,y:635,t:1527027177295};\\\", \\\"{x:376,y:641,t:1527027177312};\\\", \\\"{x:381,y:643,t:1527027177329};\\\", \\\"{x:388,y:647,t:1527027177346};\\\", \\\"{x:395,y:653,t:1527027177361};\\\", \\\"{x:404,y:659,t:1527027177378};\\\", \\\"{x:417,y:670,t:1527027177396};\\\", \\\"{x:436,y:682,t:1527027177412};\\\", \\\"{x:462,y:700,t:1527027177428};\\\", \\\"{x:483,y:711,t:1527027177445};\\\", \\\"{x:506,y:720,t:1527027177463};\\\", \\\"{x:523,y:728,t:1527027177479};\\\", \\\"{x:536,y:736,t:1527027177496};\\\", \\\"{x:542,y:739,t:1527027177512};\\\", \\\"{x:542,y:740,t:1527027177528};\\\", \\\"{x:541,y:740,t:1527027177768};\\\", \\\"{x:540,y:740,t:1527027177832};\\\", \\\"{x:538,y:740,t:1527027177855};\\\", \\\"{x:536,y:740,t:1527027177871};\\\", \\\"{x:536,y:739,t:1527027177879};\\\", \\\"{x:535,y:739,t:1527027177895};\\\", \\\"{x:534,y:739,t:1527027178088};\\\", \\\"{x:532,y:739,t:1527027178119};\\\", \\\"{x:532,y:739,t:1527027178187};\\\", \\\"{x:534,y:739,t:1527027178543};\\\", \\\"{x:539,y:739,t:1527027178551};\\\", \\\"{x:544,y:739,t:1527027178562};\\\", \\\"{x:560,y:736,t:1527027178579};\\\", \\\"{x:578,y:732,t:1527027178596};\\\", \\\"{x:602,y:732,t:1527027178613};\\\", \\\"{x:626,y:729,t:1527027178629};\\\", \\\"{x:651,y:725,t:1527027178646};\\\", \\\"{x:682,y:714,t:1527027178662};\\\", \\\"{x:731,y:703,t:1527027178679};\\\", \\\"{x:851,y:679,t:1527027178696};\\\", \\\"{x:937,y:668,t:1527027178713};\\\", \\\"{x:1006,y:650,t:1527027178729};\\\", \\\"{x:1042,y:635,t:1527027178746};\\\", \\\"{x:1066,y:623,t:1527027178763};\\\", \\\"{x:1082,y:610,t:1527027178779};\\\", \\\"{x:1091,y:602,t:1527027178796};\\\", \\\"{x:1094,y:598,t:1527027178813};\\\", \\\"{x:1100,y:587,t:1527027178829};\\\", \\\"{x:1107,y:562,t:1527027178846};\\\", \\\"{x:1113,y:509,t:1527027178863};\\\", \\\"{x:1113,y:461,t:1527027178879};\\\", \\\"{x:1114,y:412,t:1527027178896};\\\", \\\"{x:1114,y:383,t:1527027178913};\\\", \\\"{x:1114,y:353,t:1527027178930};\\\", \\\"{x:1114,y:325,t:1527027178946};\\\", \\\"{x:1118,y:294,t:1527027178963};\\\", \\\"{x:1124,y:257,t:1527027178979};\\\", \\\"{x:1132,y:227,t:1527027178996};\\\", \\\"{x:1136,y:203,t:1527027179014};\\\", \\\"{x:1143,y:177,t:1527027179029};\\\", \\\"{x:1151,y:143,t:1527027179046};\\\", \\\"{x:1160,y:97,t:1527027179063};\\\", \\\"{x:1181,y:30,t:1527027179079};\\\", \\\"{x:1213,y:0,t:1527027179096};\\\", \\\"{x:1250,y:0,t:1527027179113};\\\", \\\"{x:1279,y:0,t:1527027179129};\\\", \\\"{x:1318,y:0,t:1527027179146};\\\", \\\"{x:1353,y:0,t:1527027179163};\\\", \\\"{x:1415,y:0,t:1527027179190};\\\", \\\"{x:1435,y:0,t:1527027179196};\\\", \\\"{x:1472,y:0,t:1527027179214};\\\", \\\"{x:1514,y:0,t:1527027179229};\\\", \\\"{x:1564,y:0,t:1527027179246};\\\", \\\"{x:1616,y:0,t:1527027179262};\\\" ] }, { \\\"rt\\\": 29864, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 542710, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:0,t:1527027179370};\\\", \\\"{x:1919,y:2,t:1527027179696};\\\", \\\"{x:1919,y:4,t:1527027179703};\\\", \\\"{x:1919,y:8,t:1527027179713};\\\", \\\"{x:1919,y:12,t:1527027179731};\\\", \\\"{x:1919,y:14,t:1527027179748};\\\", \\\"{x:1767,y:85,t:1527027179823};\\\", \\\"{x:1741,y:96,t:1527027179831};\\\", \\\"{x:1711,y:113,t:1527027179847};\\\", \\\"{x:1691,y:128,t:1527027179863};\\\", \\\"{x:1662,y:152,t:1527027179881};\\\", \\\"{x:1644,y:166,t:1527027179897};\\\", \\\"{x:1625,y:183,t:1527027179913};\\\", \\\"{x:1606,y:204,t:1527027179930};\\\", \\\"{x:1575,y:236,t:1527027179947};\\\", \\\"{x:1533,y:275,t:1527027179964};\\\", \\\"{x:1478,y:323,t:1527027179980};\\\", \\\"{x:1412,y:377,t:1527027179997};\\\", \\\"{x:1355,y:434,t:1527027180015};\\\", \\\"{x:1312,y:486,t:1527027180031};\\\", \\\"{x:1292,y:521,t:1527027180047};\\\", \\\"{x:1289,y:541,t:1527027180064};\\\", \\\"{x:1290,y:552,t:1527027180080};\\\", \\\"{x:1302,y:567,t:1527027180097};\\\", \\\"{x:1319,y:580,t:1527027180114};\\\", \\\"{x:1336,y:593,t:1527027180130};\\\", \\\"{x:1349,y:604,t:1527027180148};\\\", \\\"{x:1358,y:613,t:1527027180165};\\\", \\\"{x:1363,y:620,t:1527027180180};\\\", \\\"{x:1364,y:625,t:1527027180197};\\\", \\\"{x:1365,y:626,t:1527027180215};\\\", \\\"{x:1366,y:628,t:1527027180230};\\\", \\\"{x:1367,y:629,t:1527027180247};\\\", \\\"{x:1368,y:629,t:1527027180265};\\\", \\\"{x:1371,y:631,t:1527027181616};\\\", \\\"{x:1356,y:640,t:1527027181632};\\\", \\\"{x:1224,y:709,t:1527027181648};\\\", \\\"{x:1130,y:751,t:1527027181665};\\\", \\\"{x:1069,y:775,t:1527027181682};\\\", \\\"{x:996,y:792,t:1527027181698};\\\", \\\"{x:911,y:811,t:1527027181716};\\\", \\\"{x:836,y:829,t:1527027181732};\\\", \\\"{x:772,y:829,t:1527027181748};\\\", \\\"{x:750,y:829,t:1527027181766};\\\", \\\"{x:749,y:829,t:1527027181872};\\\", \\\"{x:749,y:830,t:1527027181881};\\\", \\\"{x:749,y:832,t:1527027181898};\\\", \\\"{x:749,y:833,t:1527027181915};\\\", \\\"{x:747,y:834,t:1527027182016};\\\", \\\"{x:746,y:834,t:1527027182056};\\\", \\\"{x:746,y:835,t:1527027182065};\\\", \\\"{x:745,y:835,t:1527027182087};\\\", \\\"{x:744,y:836,t:1527027182127};\\\", \\\"{x:743,y:836,t:1527027182135};\\\", \\\"{x:741,y:837,t:1527027182148};\\\", \\\"{x:740,y:837,t:1527027182165};\\\", \\\"{x:739,y:837,t:1527027182191};\\\", \\\"{x:738,y:837,t:1527027182207};\\\", \\\"{x:737,y:838,t:1527027182240};\\\", \\\"{x:738,y:838,t:1527027183008};\\\", \\\"{x:740,y:838,t:1527027183031};\\\", \\\"{x:741,y:838,t:1527027183056};\\\", \\\"{x:743,y:838,t:1527027183080};\\\", \\\"{x:744,y:838,t:1527027183112};\\\", \\\"{x:745,y:837,t:1527027183119};\\\", \\\"{x:746,y:837,t:1527027183151};\\\", \\\"{x:745,y:837,t:1527027183623};\\\", \\\"{x:744,y:837,t:1527027183633};\\\", \\\"{x:742,y:837,t:1527027183655};\\\", \\\"{x:741,y:837,t:1527027183667};\\\", \\\"{x:739,y:837,t:1527027183684};\\\", \\\"{x:737,y:837,t:1527027183700};\\\", \\\"{x:735,y:837,t:1527027183716};\\\", \\\"{x:734,y:837,t:1527027183734};\\\", \\\"{x:732,y:837,t:1527027183749};\\\", \\\"{x:731,y:837,t:1527027183766};\\\", \\\"{x:729,y:837,t:1527027183783};\\\", \\\"{x:728,y:837,t:1527027183808};\\\", \\\"{x:727,y:837,t:1527027183840};\\\", \\\"{x:726,y:837,t:1527027183856};\\\", \\\"{x:725,y:837,t:1527027183867};\\\", \\\"{x:724,y:837,t:1527027183884};\\\", \\\"{x:723,y:837,t:1527027183899};\\\", \\\"{x:721,y:837,t:1527027183916};\\\", \\\"{x:719,y:837,t:1527027183933};\\\", \\\"{x:717,y:837,t:1527027183968};\\\", \\\"{x:716,y:837,t:1527027183991};\\\", \\\"{x:715,y:837,t:1527027184000};\\\", \\\"{x:714,y:838,t:1527027184016};\\\", \\\"{x:713,y:838,t:1527027184033};\\\", \\\"{x:711,y:838,t:1527027184050};\\\", \\\"{x:710,y:838,t:1527027184066};\\\", \\\"{x:709,y:839,t:1527027184084};\\\", \\\"{x:708,y:839,t:1527027184128};\\\", \\\"{x:707,y:839,t:1527027184264};\\\", \\\"{x:708,y:839,t:1527027185639};\\\", \\\"{x:712,y:837,t:1527027185651};\\\", \\\"{x:719,y:834,t:1527027185667};\\\", \\\"{x:724,y:830,t:1527027185685};\\\", \\\"{x:735,y:825,t:1527027185702};\\\", \\\"{x:749,y:819,t:1527027185717};\\\", \\\"{x:766,y:813,t:1527027185734};\\\", \\\"{x:797,y:803,t:1527027185751};\\\", \\\"{x:821,y:796,t:1527027185768};\\\", \\\"{x:849,y:791,t:1527027185785};\\\", \\\"{x:871,y:786,t:1527027185801};\\\", \\\"{x:895,y:785,t:1527027185818};\\\", \\\"{x:920,y:780,t:1527027185834};\\\", \\\"{x:938,y:778,t:1527027185852};\\\", \\\"{x:955,y:775,t:1527027185868};\\\", \\\"{x:976,y:774,t:1527027185884};\\\", \\\"{x:996,y:769,t:1527027185902};\\\", \\\"{x:1017,y:767,t:1527027185917};\\\", \\\"{x:1037,y:764,t:1527027185934};\\\", \\\"{x:1059,y:760,t:1527027185952};\\\", \\\"{x:1069,y:759,t:1527027185969};\\\", \\\"{x:1073,y:759,t:1527027185985};\\\", \\\"{x:1074,y:758,t:1527027186002};\\\", \\\"{x:1075,y:758,t:1527027186018};\\\", \\\"{x:1076,y:758,t:1527027186035};\\\", \\\"{x:1077,y:757,t:1527027186052};\\\", \\\"{x:1081,y:757,t:1527027186068};\\\", \\\"{x:1087,y:754,t:1527027186085};\\\", \\\"{x:1097,y:752,t:1527027186102};\\\", \\\"{x:1105,y:750,t:1527027186117};\\\", \\\"{x:1114,y:747,t:1527027186135};\\\", \\\"{x:1121,y:745,t:1527027186152};\\\", \\\"{x:1123,y:745,t:1527027186168};\\\", \\\"{x:1125,y:745,t:1527027186185};\\\", \\\"{x:1126,y:744,t:1527027186202};\\\", \\\"{x:1127,y:744,t:1527027186239};\\\", \\\"{x:1128,y:744,t:1527027186272};\\\", \\\"{x:1128,y:743,t:1527027186285};\\\", \\\"{x:1129,y:743,t:1527027186301};\\\", \\\"{x:1132,y:742,t:1527027186319};\\\", \\\"{x:1140,y:742,t:1527027186334};\\\", \\\"{x:1157,y:741,t:1527027186351};\\\", \\\"{x:1166,y:740,t:1527027186368};\\\", \\\"{x:1171,y:740,t:1527027186385};\\\", \\\"{x:1175,y:740,t:1527027186402};\\\", \\\"{x:1176,y:740,t:1527027186423};\\\", \\\"{x:1176,y:741,t:1527027186552};\\\", \\\"{x:1176,y:742,t:1527027186569};\\\", \\\"{x:1175,y:743,t:1527027186584};\\\", \\\"{x:1174,y:743,t:1527027186607};\\\", \\\"{x:1173,y:745,t:1527027186672};\\\", \\\"{x:1172,y:745,t:1527027186848};\\\", \\\"{x:1172,y:746,t:1527027186856};\\\", \\\"{x:1170,y:746,t:1527027186869};\\\", \\\"{x:1169,y:747,t:1527027186886};\\\", \\\"{x:1168,y:748,t:1527027186901};\\\", \\\"{x:1168,y:749,t:1527027187280};\\\", \\\"{x:1168,y:750,t:1527027187288};\\\", \\\"{x:1168,y:752,t:1527027187302};\\\", \\\"{x:1168,y:755,t:1527027187319};\\\", \\\"{x:1170,y:758,t:1527027187335};\\\", \\\"{x:1172,y:761,t:1527027187353};\\\", \\\"{x:1173,y:763,t:1527027187368};\\\", \\\"{x:1174,y:765,t:1527027187386};\\\", \\\"{x:1176,y:767,t:1527027187403};\\\", \\\"{x:1176,y:768,t:1527027187418};\\\", \\\"{x:1177,y:771,t:1527027187436};\\\", \\\"{x:1177,y:772,t:1527027187453};\\\", \\\"{x:1178,y:772,t:1527027187468};\\\", \\\"{x:1179,y:772,t:1527027187888};\\\", \\\"{x:1180,y:772,t:1527027187944};\\\", \\\"{x:1181,y:772,t:1527027187959};\\\", \\\"{x:1182,y:772,t:1527027187984};\\\", \\\"{x:1183,y:772,t:1527027188032};\\\", \\\"{x:1183,y:771,t:1527027188040};\\\", \\\"{x:1184,y:770,t:1527027188056};\\\", \\\"{x:1185,y:770,t:1527027188072};\\\", \\\"{x:1186,y:769,t:1527027188085};\\\", \\\"{x:1188,y:768,t:1527027188104};\\\", \\\"{x:1189,y:767,t:1527027188144};\\\", \\\"{x:1190,y:767,t:1527027188304};\\\", \\\"{x:1191,y:767,t:1527027188319};\\\", \\\"{x:1198,y:765,t:1527027188336};\\\", \\\"{x:1207,y:764,t:1527027188353};\\\", \\\"{x:1217,y:762,t:1527027188370};\\\", \\\"{x:1227,y:760,t:1527027188387};\\\", \\\"{x:1238,y:760,t:1527027188403};\\\", \\\"{x:1246,y:760,t:1527027188419};\\\", \\\"{x:1252,y:760,t:1527027188436};\\\", \\\"{x:1256,y:760,t:1527027188453};\\\", \\\"{x:1257,y:760,t:1527027188469};\\\", \\\"{x:1259,y:760,t:1527027188487};\\\", \\\"{x:1261,y:760,t:1527027188519};\\\", \\\"{x:1262,y:760,t:1527027188543};\\\", \\\"{x:1262,y:761,t:1527027188695};\\\", \\\"{x:1262,y:762,t:1527027188711};\\\", \\\"{x:1260,y:763,t:1527027188720};\\\", \\\"{x:1258,y:763,t:1527027188736};\\\", \\\"{x:1257,y:763,t:1527027188753};\\\", \\\"{x:1256,y:764,t:1527027188770};\\\", \\\"{x:1255,y:764,t:1527027188786};\\\", \\\"{x:1259,y:763,t:1527027189568};\\\", \\\"{x:1262,y:763,t:1527027189576};\\\", \\\"{x:1266,y:763,t:1527027189587};\\\", \\\"{x:1271,y:763,t:1527027189604};\\\", \\\"{x:1274,y:762,t:1527027189621};\\\", \\\"{x:1276,y:762,t:1527027189637};\\\", \\\"{x:1278,y:762,t:1527027189654};\\\", \\\"{x:1284,y:762,t:1527027189671};\\\", \\\"{x:1294,y:762,t:1527027189686};\\\", \\\"{x:1316,y:762,t:1527027189704};\\\", \\\"{x:1328,y:762,t:1527027189720};\\\", \\\"{x:1340,y:762,t:1527027189736};\\\", \\\"{x:1358,y:762,t:1527027189754};\\\", \\\"{x:1378,y:763,t:1527027189770};\\\", \\\"{x:1390,y:764,t:1527027189787};\\\", \\\"{x:1396,y:765,t:1527027189804};\\\", \\\"{x:1397,y:765,t:1527027189821};\\\", \\\"{x:1398,y:766,t:1527027189838};\\\", \\\"{x:1396,y:766,t:1527027189896};\\\", \\\"{x:1393,y:767,t:1527027189903};\\\", \\\"{x:1381,y:768,t:1527027189921};\\\", \\\"{x:1367,y:770,t:1527027189938};\\\", \\\"{x:1354,y:772,t:1527027189954};\\\", \\\"{x:1342,y:773,t:1527027189971};\\\", \\\"{x:1329,y:773,t:1527027189988};\\\", \\\"{x:1321,y:773,t:1527027190004};\\\", \\\"{x:1315,y:773,t:1527027190021};\\\", \\\"{x:1312,y:773,t:1527027190038};\\\", \\\"{x:1309,y:773,t:1527027190054};\\\", \\\"{x:1311,y:773,t:1527027190176};\\\", \\\"{x:1313,y:773,t:1527027190188};\\\", \\\"{x:1320,y:771,t:1527027190204};\\\", \\\"{x:1328,y:767,t:1527027190221};\\\", \\\"{x:1338,y:764,t:1527027190237};\\\", \\\"{x:1345,y:763,t:1527027190255};\\\", \\\"{x:1350,y:762,t:1527027190271};\\\", \\\"{x:1351,y:762,t:1527027190328};\\\", \\\"{x:1352,y:762,t:1527027190352};\\\", \\\"{x:1353,y:762,t:1527027190359};\\\", \\\"{x:1354,y:762,t:1527027190400};\\\", \\\"{x:1357,y:762,t:1527027190432};\\\", \\\"{x:1360,y:763,t:1527027190456};\\\", \\\"{x:1362,y:764,t:1527027190471};\\\", \\\"{x:1366,y:764,t:1527027190487};\\\", \\\"{x:1370,y:765,t:1527027190505};\\\", \\\"{x:1373,y:765,t:1527027190520};\\\", \\\"{x:1375,y:765,t:1527027190538};\\\", \\\"{x:1376,y:765,t:1527027190555};\\\", \\\"{x:1378,y:765,t:1527027190571};\\\", \\\"{x:1381,y:765,t:1527027190587};\\\", \\\"{x:1384,y:765,t:1527027190605};\\\", \\\"{x:1385,y:765,t:1527027190621};\\\", \\\"{x:1386,y:765,t:1527027190744};\\\", \\\"{x:1385,y:765,t:1527027200167};\\\", \\\"{x:1374,y:769,t:1527027201479};\\\", \\\"{x:1304,y:802,t:1527027201495};\\\", \\\"{x:1167,y:859,t:1527027201512};\\\", \\\"{x:966,y:914,t:1527027201528};\\\", \\\"{x:728,y:954,t:1527027201545};\\\", \\\"{x:544,y:968,t:1527027201562};\\\", \\\"{x:400,y:968,t:1527027201578};\\\", \\\"{x:336,y:968,t:1527027201595};\\\", \\\"{x:308,y:962,t:1527027201612};\\\", \\\"{x:304,y:960,t:1527027201628};\\\", \\\"{x:304,y:959,t:1527027201648};\\\", \\\"{x:308,y:956,t:1527027201662};\\\", \\\"{x:332,y:948,t:1527027201678};\\\", \\\"{x:396,y:933,t:1527027201695};\\\", \\\"{x:434,y:927,t:1527027201713};\\\", \\\"{x:463,y:917,t:1527027201728};\\\", \\\"{x:491,y:911,t:1527027201745};\\\", \\\"{x:512,y:903,t:1527027201762};\\\", \\\"{x:525,y:896,t:1527027201779};\\\", \\\"{x:534,y:892,t:1527027201795};\\\", \\\"{x:542,y:886,t:1527027201812};\\\", \\\"{x:550,y:881,t:1527027201829};\\\", \\\"{x:562,y:870,t:1527027201845};\\\", \\\"{x:571,y:858,t:1527027201862};\\\", \\\"{x:581,y:842,t:1527027201879};\\\", \\\"{x:586,y:833,t:1527027201895};\\\", \\\"{x:588,y:818,t:1527027201912};\\\", \\\"{x:592,y:803,t:1527027201929};\\\", \\\"{x:592,y:788,t:1527027201945};\\\", \\\"{x:592,y:771,t:1527027201962};\\\", \\\"{x:592,y:751,t:1527027201979};\\\", \\\"{x:592,y:727,t:1527027201995};\\\", \\\"{x:592,y:703,t:1527027202012};\\\", \\\"{x:592,y:683,t:1527027202029};\\\", \\\"{x:592,y:659,t:1527027202046};\\\", \\\"{x:592,y:633,t:1527027202063};\\\", \\\"{x:585,y:592,t:1527027202080};\\\", \\\"{x:578,y:565,t:1527027202095};\\\", \\\"{x:571,y:543,t:1527027202113};\\\", \\\"{x:566,y:524,t:1527027202128};\\\", \\\"{x:562,y:515,t:1527027202145};\\\", \\\"{x:561,y:509,t:1527027202161};\\\", \\\"{x:559,y:508,t:1527027202182};\\\", \\\"{x:559,y:506,t:1527027202447};\\\", \\\"{x:560,y:505,t:1527027202456};\\\", \\\"{x:561,y:505,t:1527027202488};\\\", \\\"{x:562,y:504,t:1527027202528};\\\", \\\"{x:562,y:503,t:1527027202583};\\\", \\\"{x:562,y:502,t:1527027202599};\\\", \\\"{x:562,y:501,t:1527027202615};\\\", \\\"{x:562,y:500,t:1527027202632};\\\", \\\"{x:562,y:499,t:1527027202671};\\\", \\\"{x:562,y:498,t:1527027202775};\\\", \\\"{x:561,y:497,t:1527027202832};\\\", \\\"{x:560,y:497,t:1527027202856};\\\", \\\"{x:559,y:497,t:1527027202866};\\\", \\\"{x:557,y:495,t:1527027202882};\\\", \\\"{x:555,y:495,t:1527027202899};\\\", \\\"{x:554,y:495,t:1527027202927};\\\", \\\"{x:553,y:494,t:1527027202935};\\\", \\\"{x:552,y:493,t:1527027202951};\\\", \\\"{x:550,y:492,t:1527027202976};\\\", \\\"{x:549,y:492,t:1527027202991};\\\", \\\"{x:548,y:491,t:1527027202999};\\\", \\\"{x:546,y:490,t:1527027203015};\\\", \\\"{x:545,y:489,t:1527027203032};\\\", \\\"{x:543,y:488,t:1527027203049};\\\", \\\"{x:541,y:487,t:1527027203066};\\\", \\\"{x:540,y:486,t:1527027203083};\\\", \\\"{x:539,y:485,t:1527027203099};\\\", \\\"{x:538,y:485,t:1527027203143};\\\", \\\"{x:537,y:485,t:1527027203160};\\\", \\\"{x:537,y:484,t:1527027203168};\\\", \\\"{x:535,y:483,t:1527027203248};\\\", \\\"{x:533,y:483,t:1527027203264};\\\", \\\"{x:531,y:483,t:1527027203279};\\\", \\\"{x:530,y:483,t:1527027203296};\\\", \\\"{x:528,y:483,t:1527027203313};\\\", \\\"{x:527,y:483,t:1527027203488};\\\", \\\"{x:523,y:489,t:1527027203497};\\\", \\\"{x:513,y:520,t:1527027203513};\\\", \\\"{x:505,y:570,t:1527027203533};\\\", \\\"{x:521,y:599,t:1527027203550};\\\", \\\"{x:563,y:611,t:1527027203567};\\\", \\\"{x:634,y:607,t:1527027203584};\\\", \\\"{x:676,y:595,t:1527027203599};\\\", \\\"{x:690,y:590,t:1527027203616};\\\", \\\"{x:692,y:589,t:1527027203633};\\\", \\\"{x:693,y:588,t:1527027203649};\\\", \\\"{x:693,y:587,t:1527027203667};\\\", \\\"{x:694,y:587,t:1527027203683};\\\", \\\"{x:694,y:584,t:1527027203792};\\\", \\\"{x:694,y:580,t:1527027203801};\\\", \\\"{x:694,y:577,t:1527027203817};\\\", \\\"{x:694,y:575,t:1527027203835};\\\", \\\"{x:694,y:574,t:1527027203904};\\\", \\\"{x:694,y:572,t:1527027203944};\\\", \\\"{x:693,y:571,t:1527027203960};\\\", \\\"{x:690,y:570,t:1527027203968};\\\", \\\"{x:688,y:570,t:1527027203985};\\\", \\\"{x:685,y:569,t:1527027204002};\\\", \\\"{x:682,y:569,t:1527027204019};\\\", \\\"{x:679,y:567,t:1527027204034};\\\", \\\"{x:675,y:567,t:1527027204052};\\\", \\\"{x:672,y:567,t:1527027204068};\\\", \\\"{x:670,y:567,t:1527027204086};\\\", \\\"{x:669,y:567,t:1527027204102};\\\", \\\"{x:667,y:567,t:1527027204118};\\\", \\\"{x:661,y:571,t:1527027204136};\\\", \\\"{x:656,y:574,t:1527027204152};\\\", \\\"{x:651,y:578,t:1527027204169};\\\", \\\"{x:650,y:579,t:1527027204185};\\\", \\\"{x:648,y:579,t:1527027204202};\\\", \\\"{x:647,y:580,t:1527027204219};\\\", \\\"{x:645,y:580,t:1527027204236};\\\", \\\"{x:638,y:583,t:1527027204254};\\\", \\\"{x:627,y:584,t:1527027204269};\\\", \\\"{x:614,y:587,t:1527027204285};\\\", \\\"{x:599,y:587,t:1527027204302};\\\", \\\"{x:580,y:587,t:1527027204317};\\\", \\\"{x:556,y:587,t:1527027204333};\\\", \\\"{x:529,y:587,t:1527027204351};\\\", \\\"{x:510,y:589,t:1527027204368};\\\", \\\"{x:507,y:592,t:1527027204383};\\\", \\\"{x:506,y:592,t:1527027204449};\\\", \\\"{x:503,y:592,t:1527027204464};\\\", \\\"{x:498,y:592,t:1527027204475};\\\", \\\"{x:487,y:592,t:1527027204484};\\\", \\\"{x:458,y:592,t:1527027204500};\\\", \\\"{x:419,y:592,t:1527027204517};\\\", \\\"{x:385,y:592,t:1527027204533};\\\", \\\"{x:351,y:588,t:1527027204551};\\\", \\\"{x:320,y:583,t:1527027204567};\\\", \\\"{x:315,y:582,t:1527027204583};\\\", \\\"{x:314,y:582,t:1527027204601};\\\", \\\"{x:313,y:582,t:1527027204743};\\\", \\\"{x:313,y:581,t:1527027204776};\\\", \\\"{x:312,y:581,t:1527027204783};\\\", \\\"{x:307,y:579,t:1527027204801};\\\", \\\"{x:300,y:576,t:1527027204818};\\\", \\\"{x:290,y:570,t:1527027204835};\\\", \\\"{x:281,y:562,t:1527027204851};\\\", \\\"{x:280,y:561,t:1527027204867};\\\", \\\"{x:278,y:559,t:1527027204884};\\\", \\\"{x:276,y:555,t:1527027204902};\\\", \\\"{x:273,y:551,t:1527027204918};\\\", \\\"{x:269,y:548,t:1527027204936};\\\", \\\"{x:263,y:543,t:1527027204950};\\\", \\\"{x:241,y:535,t:1527027204968};\\\", \\\"{x:232,y:530,t:1527027204984};\\\", \\\"{x:227,y:527,t:1527027205001};\\\", \\\"{x:225,y:527,t:1527027205018};\\\", \\\"{x:223,y:526,t:1527027205035};\\\", \\\"{x:222,y:526,t:1527027205056};\\\", \\\"{x:221,y:526,t:1527027205068};\\\", \\\"{x:220,y:526,t:1527027205085};\\\", \\\"{x:219,y:526,t:1527027205101};\\\", \\\"{x:216,y:526,t:1527027205118};\\\", \\\"{x:211,y:526,t:1527027205135};\\\", \\\"{x:198,y:526,t:1527027205152};\\\", \\\"{x:193,y:526,t:1527027205168};\\\", \\\"{x:173,y:526,t:1527027205185};\\\", \\\"{x:164,y:526,t:1527027205200};\\\", \\\"{x:154,y:526,t:1527027205218};\\\", \\\"{x:140,y:526,t:1527027205235};\\\", \\\"{x:130,y:526,t:1527027205251};\\\", \\\"{x:128,y:526,t:1527027205268};\\\", \\\"{x:127,y:526,t:1527027205285};\\\", \\\"{x:128,y:525,t:1527027205376};\\\", \\\"{x:131,y:522,t:1527027205385};\\\", \\\"{x:140,y:516,t:1527027205402};\\\", \\\"{x:145,y:512,t:1527027205418};\\\", \\\"{x:145,y:511,t:1527027205568};\\\", \\\"{x:146,y:511,t:1527027205977};\\\", \\\"{x:149,y:511,t:1527027205986};\\\", \\\"{x:156,y:512,t:1527027206004};\\\", \\\"{x:163,y:515,t:1527027206018};\\\", \\\"{x:165,y:516,t:1527027206034};\\\", \\\"{x:167,y:517,t:1527027206050};\\\", \\\"{x:169,y:518,t:1527027206067};\\\", \\\"{x:175,y:520,t:1527027206084};\\\", \\\"{x:179,y:522,t:1527027206101};\\\", \\\"{x:183,y:523,t:1527027206118};\\\", \\\"{x:185,y:523,t:1527027206135};\\\", \\\"{x:187,y:523,t:1527027206152};\\\", \\\"{x:190,y:523,t:1527027206168};\\\", \\\"{x:201,y:524,t:1527027206186};\\\", \\\"{x:220,y:528,t:1527027206203};\\\", \\\"{x:238,y:535,t:1527027206219};\\\", \\\"{x:253,y:542,t:1527027206236};\\\", \\\"{x:273,y:553,t:1527027206254};\\\", \\\"{x:307,y:579,t:1527027206278};\\\", \\\"{x:359,y:620,t:1527027206296};\\\", \\\"{x:421,y:667,t:1527027206312};\\\", \\\"{x:459,y:698,t:1527027206329};\\\", \\\"{x:478,y:716,t:1527027206344};\\\", \\\"{x:484,y:726,t:1527027206362};\\\", \\\"{x:488,y:734,t:1527027206378};\\\", \\\"{x:493,y:742,t:1527027206395};\\\", \\\"{x:498,y:751,t:1527027206411};\\\", \\\"{x:501,y:757,t:1527027206429};\\\", \\\"{x:503,y:760,t:1527027206445};\\\", \\\"{x:504,y:762,t:1527027206462};\\\", \\\"{x:504,y:764,t:1527027206478};\\\", \\\"{x:504,y:765,t:1527027206498};\\\", \\\"{x:504,y:766,t:1527027206537};\\\", \\\"{x:503,y:768,t:1527027206546};\\\", \\\"{x:503,y:771,t:1527027206562};\\\", \\\"{x:501,y:776,t:1527027206580};\\\", \\\"{x:501,y:778,t:1527027206595};\\\", \\\"{x:501,y:779,t:1527027206612};\\\", \\\"{x:501,y:782,t:1527027206629};\\\", \\\"{x:501,y:785,t:1527027206644};\\\", \\\"{x:501,y:789,t:1527027206662};\\\", \\\"{x:501,y:792,t:1527027206679};\\\", \\\"{x:501,y:793,t:1527027206697};\\\", \\\"{x:503,y:793,t:1527027206777};\\\", \\\"{x:504,y:793,t:1527027206793};\\\", \\\"{x:508,y:792,t:1527027206801};\\\", \\\"{x:511,y:791,t:1527027206812};\\\", \\\"{x:517,y:787,t:1527027206829};\\\", \\\"{x:523,y:786,t:1527027206847};\\\", \\\"{x:527,y:783,t:1527027206863};\\\", \\\"{x:530,y:782,t:1527027206879};\\\", \\\"{x:536,y:779,t:1527027206896};\\\", \\\"{x:548,y:773,t:1527027206914};\\\", \\\"{x:553,y:771,t:1527027206929};\\\", \\\"{x:554,y:770,t:1527027206946};\\\", \\\"{x:556,y:770,t:1527027206986};\\\", \\\"{x:556,y:769,t:1527027207018};\\\", \\\"{x:556,y:768,t:1527027207042};\\\", \\\"{x:556,y:767,t:1527027207057};\\\", \\\"{x:556,y:766,t:1527027207065};\\\", \\\"{x:555,y:766,t:1527027207081};\\\", \\\"{x:553,y:763,t:1527027207097};\\\", \\\"{x:547,y:758,t:1527027207114};\\\", \\\"{x:541,y:755,t:1527027207130};\\\", \\\"{x:539,y:753,t:1527027207148};\\\", \\\"{x:536,y:750,t:1527027207163};\\\", \\\"{x:535,y:748,t:1527027207180};\\\", \\\"{x:534,y:747,t:1527027207195};\\\", \\\"{x:532,y:745,t:1527027207418};\\\", \\\"{x:527,y:743,t:1527027207429};\\\", \\\"{x:502,y:738,t:1527027207446};\\\", \\\"{x:463,y:731,t:1527027207462};\\\", \\\"{x:419,y:720,t:1527027207480};\\\", \\\"{x:385,y:708,t:1527027207496};\\\", \\\"{x:356,y:697,t:1527027207511};\\\", \\\"{x:333,y:686,t:1527027207529};\\\", \\\"{x:323,y:682,t:1527027207545};\\\", \\\"{x:317,y:677,t:1527027207562};\\\", \\\"{x:310,y:669,t:1527027207579};\\\", \\\"{x:306,y:665,t:1527027207596};\\\", \\\"{x:304,y:661,t:1527027207612};\\\", \\\"{x:298,y:654,t:1527027207629};\\\", \\\"{x:290,y:643,t:1527027207646};\\\", \\\"{x:282,y:631,t:1527027207662};\\\", \\\"{x:275,y:621,t:1527027207679};\\\", \\\"{x:270,y:606,t:1527027207697};\\\", \\\"{x:262,y:579,t:1527027207713};\\\", \\\"{x:255,y:564,t:1527027207729};\\\", \\\"{x:245,y:549,t:1527027207747};\\\", \\\"{x:236,y:537,t:1527027207763};\\\", \\\"{x:230,y:528,t:1527027207779};\\\", \\\"{x:229,y:525,t:1527027207796};\\\", \\\"{x:227,y:523,t:1527027207814};\\\", \\\"{x:226,y:522,t:1527027207841};\\\", \\\"{x:226,y:520,t:1527027207857};\\\", \\\"{x:224,y:520,t:1527027207873};\\\", \\\"{x:223,y:520,t:1527027207890};\\\", \\\"{x:222,y:520,t:1527027207938};\\\", \\\"{x:221,y:520,t:1527027207947};\\\", \\\"{x:218,y:520,t:1527027207964};\\\", \\\"{x:212,y:520,t:1527027207979};\\\", \\\"{x:204,y:520,t:1527027207996};\\\", \\\"{x:193,y:518,t:1527027208013};\\\", \\\"{x:186,y:516,t:1527027208031};\\\", \\\"{x:185,y:515,t:1527027208046};\\\", \\\"{x:182,y:513,t:1527027208063};\\\", \\\"{x:176,y:512,t:1527027208080};\\\", \\\"{x:175,y:511,t:1527027208096};\\\", \\\"{x:173,y:510,t:1527027208146};\\\", \\\"{x:173,y:511,t:1527027208361};\\\", \\\"{x:174,y:511,t:1527027208369};\\\", \\\"{x:178,y:513,t:1527027208380};\\\", \\\"{x:191,y:525,t:1527027208398};\\\", \\\"{x:226,y:556,t:1527027208414};\\\", \\\"{x:281,y:602,t:1527027208430};\\\", \\\"{x:342,y:653,t:1527027208447};\\\", \\\"{x:390,y:688,t:1527027208464};\\\", \\\"{x:425,y:717,t:1527027208480};\\\", \\\"{x:440,y:728,t:1527027208496};\\\", \\\"{x:454,y:739,t:1527027208513};\\\", \\\"{x:456,y:741,t:1527027208530};\\\", \\\"{x:459,y:743,t:1527027208546};\\\", \\\"{x:461,y:745,t:1527027208563};\\\", \\\"{x:463,y:747,t:1527027208580};\\\", \\\"{x:465,y:748,t:1527027208597};\\\", \\\"{x:468,y:751,t:1527027208613};\\\", \\\"{x:472,y:754,t:1527027208630};\\\", \\\"{x:484,y:759,t:1527027208647};\\\", \\\"{x:501,y:765,t:1527027208663};\\\", \\\"{x:520,y:768,t:1527027208681};\\\", \\\"{x:546,y:773,t:1527027208697};\\\", \\\"{x:560,y:777,t:1527027208713};\\\", \\\"{x:576,y:782,t:1527027208731};\\\", \\\"{x:583,y:782,t:1527027208747};\\\", \\\"{x:584,y:782,t:1527027208763};\\\", \\\"{x:585,y:782,t:1527027208780};\\\", \\\"{x:586,y:782,t:1527027208817};\\\", \\\"{x:588,y:782,t:1527027208830};\\\", \\\"{x:588,y:778,t:1527027208847};\\\", \\\"{x:588,y:776,t:1527027208864};\\\", \\\"{x:588,y:774,t:1527027208881};\\\", \\\"{x:588,y:771,t:1527027208898};\\\", \\\"{x:587,y:767,t:1527027208914};\\\", \\\"{x:584,y:765,t:1527027208930};\\\", \\\"{x:580,y:763,t:1527027208947};\\\", \\\"{x:575,y:760,t:1527027208963};\\\", \\\"{x:570,y:757,t:1527027208980};\\\", \\\"{x:567,y:753,t:1527027208997};\\\", \\\"{x:564,y:751,t:1527027209013};\\\", \\\"{x:561,y:749,t:1527027209031};\\\", \\\"{x:560,y:748,t:1527027209047};\\\", \\\"{x:558,y:746,t:1527027209064};\\\", \\\"{x:556,y:744,t:1527027209080};\\\", \\\"{x:554,y:742,t:1527027209098};\\\", \\\"{x:552,y:739,t:1527027209113};\\\", \\\"{x:552,y:738,t:1527027209130};\\\", \\\"{x:554,y:738,t:1527027209409};\\\", \\\"{x:567,y:741,t:1527027209417};\\\", \\\"{x:586,y:745,t:1527027209431};\\\", \\\"{x:650,y:762,t:1527027209447};\\\", \\\"{x:742,y:775,t:1527027209464};\\\", \\\"{x:925,y:798,t:1527027209481};\\\", \\\"{x:1071,y:813,t:1527027209496};\\\", \\\"{x:1241,y:824,t:1527027209514};\\\", \\\"{x:1407,y:824,t:1527027209531};\\\", \\\"{x:1543,y:824,t:1527027209547};\\\", \\\"{x:1654,y:824,t:1527027209564};\\\", \\\"{x:1737,y:814,t:1527027209581};\\\", \\\"{x:1776,y:808,t:1527027209597};\\\", \\\"{x:1796,y:802,t:1527027209614};\\\", \\\"{x:1800,y:799,t:1527027209632};\\\", \\\"{x:1801,y:797,t:1527027209658};\\\", \\\"{x:1801,y:792,t:1527027209665};\\\", \\\"{x:1779,y:759,t:1527027209682};\\\", \\\"{x:1714,y:696,t:1527027209698};\\\", \\\"{x:1611,y:625,t:1527027209715};\\\", \\\"{x:1501,y:555,t:1527027209732};\\\", \\\"{x:1386,y:491,t:1527027209749};\\\", \\\"{x:1277,y:433,t:1527027209764};\\\", \\\"{x:1161,y:380,t:1527027209781};\\\", \\\"{x:1064,y:333,t:1527027209799};\\\", \\\"{x:989,y:295,t:1527027209814};\\\", \\\"{x:938,y:271,t:1527027209831};\\\", \\\"{x:917,y:261,t:1527027209848};\\\", \\\"{x:908,y:258,t:1527027209865};\\\", \\\"{x:904,y:256,t:1527027209882};\\\" ] }, { \\\"rt\\\": 43181, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 587100, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:905,y:251,t:1527027210929};\\\", \\\"{x:905,y:248,t:1527027210946};\\\", \\\"{x:906,y:248,t:1527027211322};\\\", \\\"{x:907,y:248,t:1527027211346};\\\", \\\"{x:908,y:245,t:1527027211642};\\\", \\\"{x:908,y:239,t:1527027211650};\\\", \\\"{x:908,y:224,t:1527027211666};\\\", \\\"{x:909,y:220,t:1527027211682};\\\", \\\"{x:909,y:219,t:1527027211762};\\\", \\\"{x:908,y:219,t:1527027211946};\\\", \\\"{x:908,y:220,t:1527027211954};\\\", \\\"{x:908,y:221,t:1527027211970};\\\", \\\"{x:909,y:222,t:1527027211986};\\\", \\\"{x:912,y:224,t:1527027212001};\\\", \\\"{x:915,y:224,t:1527027212017};\\\", \\\"{x:918,y:225,t:1527027212033};\\\", \\\"{x:923,y:226,t:1527027212050};\\\", \\\"{x:924,y:226,t:1527027212066};\\\", \\\"{x:925,y:227,t:1527027212083};\\\", \\\"{x:924,y:226,t:1527027213161};\\\", \\\"{x:923,y:226,t:1527027213176};\\\", \\\"{x:922,y:224,t:1527027213185};\\\", \\\"{x:922,y:223,t:1527027213225};\\\", \\\"{x:921,y:222,t:1527027213233};\\\", \\\"{x:921,y:221,t:1527027213250};\\\", \\\"{x:921,y:219,t:1527027213338};\\\", \\\"{x:921,y:218,t:1527027213350};\\\", \\\"{x:921,y:215,t:1527027213368};\\\", \\\"{x:922,y:211,t:1527027213383};\\\", \\\"{x:926,y:203,t:1527027213400};\\\", \\\"{x:928,y:200,t:1527027213418};\\\", \\\"{x:929,y:199,t:1527027213433};\\\", \\\"{x:929,y:197,t:1527027213450};\\\", \\\"{x:930,y:196,t:1527027213481};\\\", \\\"{x:931,y:193,t:1527027213496};\\\", \\\"{x:932,y:191,t:1527027213512};\\\", \\\"{x:932,y:189,t:1527027213529};\\\", \\\"{x:933,y:189,t:1527027213560};\\\", \\\"{x:933,y:187,t:1527027213569};\\\", \\\"{x:934,y:186,t:1527027213584};\\\", \\\"{x:935,y:182,t:1527027213600};\\\", \\\"{x:941,y:162,t:1527027213616};\\\", \\\"{x:948,y:138,t:1527027213634};\\\", \\\"{x:953,y:116,t:1527027213650};\\\", \\\"{x:961,y:96,t:1527027213667};\\\", \\\"{x:964,y:82,t:1527027213684};\\\", \\\"{x:967,y:74,t:1527027213700};\\\", \\\"{x:968,y:73,t:1527027213717};\\\", \\\"{x:968,y:72,t:1527027213734};\\\", \\\"{x:968,y:71,t:1527027213752};\\\", \\\"{x:968,y:70,t:1527027213767};\\\", \\\"{x:968,y:69,t:1527027213784};\\\", \\\"{x:968,y:68,t:1527027213801};\\\", \\\"{x:967,y:68,t:1527027215034};\\\", \\\"{x:962,y:68,t:1527027215041};\\\", \\\"{x:952,y:66,t:1527027215052};\\\", \\\"{x:931,y:61,t:1527027215068};\\\", \\\"{x:890,y:45,t:1527027215085};\\\", \\\"{x:869,y:38,t:1527027215102};\\\", \\\"{x:864,y:38,t:1527027215118};\\\", \\\"{x:863,y:38,t:1527027215135};\\\", \\\"{x:865,y:42,t:1527027215578};\\\", \\\"{x:870,y:50,t:1527027215586};\\\", \\\"{x:877,y:62,t:1527027215603};\\\", \\\"{x:888,y:75,t:1527027215619};\\\", \\\"{x:903,y:88,t:1527027215635};\\\", \\\"{x:932,y:110,t:1527027215652};\\\", \\\"{x:971,y:144,t:1527027215669};\\\", \\\"{x:1010,y:180,t:1527027215686};\\\", \\\"{x:1034,y:208,t:1527027215703};\\\", \\\"{x:1056,y:233,t:1527027215719};\\\", \\\"{x:1074,y:255,t:1527027215737};\\\", \\\"{x:1092,y:277,t:1527027215753};\\\", \\\"{x:1125,y:299,t:1527027215770};\\\", \\\"{x:1141,y:307,t:1527027215786};\\\", \\\"{x:1145,y:309,t:1527027215803};\\\", \\\"{x:1145,y:311,t:1527027215850};\\\", \\\"{x:1144,y:312,t:1527027216090};\\\", \\\"{x:1141,y:313,t:1527027216103};\\\", \\\"{x:1139,y:313,t:1527027216120};\\\", \\\"{x:1138,y:314,t:1527027216161};\\\", \\\"{x:1136,y:315,t:1527027216186};\\\", \\\"{x:1132,y:316,t:1527027216203};\\\", \\\"{x:1129,y:318,t:1527027216220};\\\", \\\"{x:1127,y:318,t:1527027216236};\\\", \\\"{x:1126,y:318,t:1527027216257};\\\", \\\"{x:1124,y:318,t:1527027216270};\\\", \\\"{x:1115,y:322,t:1527027216286};\\\", \\\"{x:1094,y:328,t:1527027216302};\\\", \\\"{x:1060,y:334,t:1527027216319};\\\", \\\"{x:1030,y:338,t:1527027216335};\\\", \\\"{x:1004,y:340,t:1527027216352};\\\", \\\"{x:964,y:336,t:1527027216369};\\\", \\\"{x:941,y:329,t:1527027216385};\\\", \\\"{x:922,y:322,t:1527027216403};\\\", \\\"{x:912,y:321,t:1527027216419};\\\", \\\"{x:906,y:320,t:1527027216435};\\\", \\\"{x:900,y:320,t:1527027216453};\\\", \\\"{x:897,y:319,t:1527027216469};\\\", \\\"{x:893,y:318,t:1527027216487};\\\", \\\"{x:892,y:318,t:1527027216503};\\\", \\\"{x:888,y:315,t:1527027216520};\\\", \\\"{x:879,y:310,t:1527027216537};\\\", \\\"{x:862,y:295,t:1527027216554};\\\", \\\"{x:851,y:289,t:1527027216570};\\\", \\\"{x:841,y:284,t:1527027216586};\\\", \\\"{x:835,y:283,t:1527027216602};\\\", \\\"{x:833,y:283,t:1527027216619};\\\", \\\"{x:832,y:283,t:1527027216681};\\\", \\\"{x:832,y:282,t:1527027216770};\\\", \\\"{x:827,y:282,t:1527027216787};\\\", \\\"{x:817,y:280,t:1527027216802};\\\", \\\"{x:809,y:276,t:1527027216819};\\\", \\\"{x:804,y:275,t:1527027216836};\\\", \\\"{x:803,y:275,t:1527027216853};\\\", \\\"{x:803,y:274,t:1527027216985};\\\", \\\"{x:808,y:273,t:1527027217004};\\\", \\\"{x:809,y:271,t:1527027217020};\\\", \\\"{x:809,y:270,t:1527027217036};\\\", \\\"{x:807,y:272,t:1527027217210};\\\", \\\"{x:805,y:272,t:1527027217220};\\\", \\\"{x:803,y:274,t:1527027217237};\\\", \\\"{x:802,y:275,t:1527027217254};\\\", \\\"{x:800,y:276,t:1527027217270};\\\", \\\"{x:799,y:276,t:1527027217286};\\\", \\\"{x:799,y:277,t:1527027217304};\\\", \\\"{x:798,y:277,t:1527027217320};\\\", \\\"{x:796,y:277,t:1527027217337};\\\", \\\"{x:795,y:278,t:1527027217353};\\\", \\\"{x:793,y:278,t:1527027217370};\\\", \\\"{x:793,y:279,t:1527027217387};\\\", \\\"{x:794,y:279,t:1527027217570};\\\", \\\"{x:796,y:279,t:1527027217682};\\\", \\\"{x:813,y:271,t:1527027217689};\\\", \\\"{x:834,y:258,t:1527027217703};\\\", \\\"{x:890,y:233,t:1527027217720};\\\", \\\"{x:919,y:225,t:1527027217737};\\\", \\\"{x:933,y:224,t:1527027217754};\\\", \\\"{x:936,y:223,t:1527027217771};\\\", \\\"{x:938,y:223,t:1527027217786};\\\", \\\"{x:939,y:222,t:1527027217922};\\\", \\\"{x:937,y:222,t:1527027217962};\\\", \\\"{x:936,y:222,t:1527027217971};\\\", \\\"{x:931,y:222,t:1527027217988};\\\", \\\"{x:930,y:223,t:1527027218004};\\\", \\\"{x:927,y:223,t:1527027218021};\\\", \\\"{x:925,y:223,t:1527027218038};\\\", \\\"{x:922,y:223,t:1527027218054};\\\", \\\"{x:919,y:224,t:1527027218071};\\\", \\\"{x:915,y:224,t:1527027218087};\\\", \\\"{x:909,y:224,t:1527027218104};\\\", \\\"{x:904,y:224,t:1527027218121};\\\", \\\"{x:897,y:224,t:1527027218137};\\\", \\\"{x:895,y:224,t:1527027218186};\\\", \\\"{x:893,y:225,t:1527027218194};\\\", \\\"{x:889,y:226,t:1527027218204};\\\", \\\"{x:879,y:231,t:1527027218221};\\\", \\\"{x:863,y:238,t:1527027218238};\\\", \\\"{x:844,y:248,t:1527027218254};\\\", \\\"{x:825,y:258,t:1527027218271};\\\", \\\"{x:810,y:267,t:1527027218287};\\\", \\\"{x:807,y:270,t:1527027218304};\\\", \\\"{x:806,y:270,t:1527027218321};\\\", \\\"{x:804,y:272,t:1527027218570};\\\", \\\"{x:802,y:274,t:1527027218588};\\\", \\\"{x:797,y:285,t:1527027218605};\\\", \\\"{x:789,y:296,t:1527027218621};\\\", \\\"{x:777,y:307,t:1527027218638};\\\", \\\"{x:765,y:316,t:1527027218655};\\\", \\\"{x:757,y:322,t:1527027218671};\\\", \\\"{x:750,y:327,t:1527027218688};\\\", \\\"{x:745,y:330,t:1527027218705};\\\", \\\"{x:743,y:333,t:1527027218721};\\\", \\\"{x:742,y:335,t:1527027218738};\\\", \\\"{x:742,y:336,t:1527027218850};\\\", \\\"{x:742,y:337,t:1527027218857};\\\", \\\"{x:741,y:339,t:1527027218872};\\\", \\\"{x:741,y:340,t:1527027218945};\\\", \\\"{x:741,y:341,t:1527027218955};\\\", \\\"{x:745,y:343,t:1527027218972};\\\", \\\"{x:750,y:345,t:1527027218988};\\\", \\\"{x:753,y:347,t:1527027219005};\\\", \\\"{x:757,y:348,t:1527027219022};\\\", \\\"{x:761,y:350,t:1527027219038};\\\", \\\"{x:762,y:351,t:1527027219055};\\\", \\\"{x:763,y:351,t:1527027219072};\\\", \\\"{x:764,y:351,t:1527027219088};\\\", \\\"{x:765,y:351,t:1527027219105};\\\", \\\"{x:768,y:351,t:1527027219122};\\\", \\\"{x:773,y:349,t:1527027219138};\\\", \\\"{x:778,y:346,t:1527027219155};\\\", \\\"{x:785,y:342,t:1527027219172};\\\", \\\"{x:791,y:339,t:1527027219188};\\\", \\\"{x:791,y:335,t:1527027219370};\\\", \\\"{x:790,y:333,t:1527027219378};\\\", \\\"{x:788,y:331,t:1527027219389};\\\", \\\"{x:788,y:328,t:1527027219404};\\\", \\\"{x:785,y:323,t:1527027219422};\\\", \\\"{x:782,y:316,t:1527027219439};\\\", \\\"{x:781,y:311,t:1527027219455};\\\", \\\"{x:780,y:303,t:1527027219472};\\\", \\\"{x:780,y:301,t:1527027219506};\\\", \\\"{x:785,y:295,t:1527027219521};\\\", \\\"{x:787,y:294,t:1527027219539};\\\", \\\"{x:786,y:294,t:1527027220898};\\\", \\\"{x:785,y:294,t:1527027220914};\\\", \\\"{x:783,y:292,t:1527027220922};\\\", \\\"{x:781,y:291,t:1527027220939};\\\", \\\"{x:781,y:290,t:1527027220956};\\\", \\\"{x:780,y:290,t:1527027220973};\\\", \\\"{x:785,y:294,t:1527027221105};\\\", \\\"{x:821,y:324,t:1527027221123};\\\", \\\"{x:858,y:353,t:1527027221139};\\\", \\\"{x:879,y:364,t:1527027221156};\\\", \\\"{x:886,y:371,t:1527027221172};\\\", \\\"{x:886,y:377,t:1527027221190};\\\", \\\"{x:886,y:387,t:1527027221206};\\\", \\\"{x:886,y:393,t:1527027221222};\\\", \\\"{x:889,y:402,t:1527027221239};\\\", \\\"{x:894,y:413,t:1527027221257};\\\", \\\"{x:899,y:420,t:1527027221272};\\\", \\\"{x:905,y:429,t:1527027221290};\\\", \\\"{x:916,y:446,t:1527027221307};\\\", \\\"{x:927,y:461,t:1527027221323};\\\", \\\"{x:941,y:480,t:1527027221340};\\\", \\\"{x:962,y:517,t:1527027221356};\\\", \\\"{x:977,y:546,t:1527027221373};\\\", \\\"{x:1002,y:572,t:1527027221390};\\\", \\\"{x:1047,y:595,t:1527027221407};\\\", \\\"{x:1110,y:610,t:1527027221423};\\\", \\\"{x:1182,y:628,t:1527027221440};\\\", \\\"{x:1244,y:630,t:1527027221457};\\\", \\\"{x:1269,y:630,t:1527027221474};\\\", \\\"{x:1288,y:630,t:1527027221490};\\\", \\\"{x:1308,y:635,t:1527027221508};\\\", \\\"{x:1323,y:646,t:1527027221523};\\\", \\\"{x:1328,y:654,t:1527027221540};\\\", \\\"{x:1328,y:656,t:1527027221557};\\\", \\\"{x:1328,y:657,t:1527027221593};\\\", \\\"{x:1328,y:660,t:1527027221608};\\\", \\\"{x:1309,y:666,t:1527027221622};\\\", \\\"{x:1287,y:669,t:1527027221640};\\\", \\\"{x:1247,y:674,t:1527027221657};\\\", \\\"{x:1234,y:674,t:1527027221673};\\\", \\\"{x:1231,y:676,t:1527027221690};\\\", \\\"{x:1233,y:680,t:1527027221729};\\\", \\\"{x:1245,y:691,t:1527027221740};\\\", \\\"{x:1302,y:737,t:1527027221756};\\\", \\\"{x:1374,y:780,t:1527027221774};\\\", \\\"{x:1448,y:810,t:1527027221790};\\\", \\\"{x:1489,y:826,t:1527027221807};\\\", \\\"{x:1508,y:831,t:1527027221824};\\\", \\\"{x:1516,y:832,t:1527027221840};\\\", \\\"{x:1517,y:833,t:1527027221930};\\\", \\\"{x:1512,y:833,t:1527027221945};\\\", \\\"{x:1501,y:829,t:1527027221957};\\\", \\\"{x:1466,y:816,t:1527027221974};\\\", \\\"{x:1443,y:803,t:1527027221991};\\\", \\\"{x:1429,y:792,t:1527027222007};\\\", \\\"{x:1422,y:782,t:1527027222024};\\\", \\\"{x:1416,y:770,t:1527027222040};\\\", \\\"{x:1405,y:748,t:1527027222058};\\\", \\\"{x:1392,y:732,t:1527027222074};\\\", \\\"{x:1380,y:721,t:1527027222090};\\\", \\\"{x:1368,y:715,t:1527027222107};\\\", \\\"{x:1357,y:710,t:1527027222124};\\\", \\\"{x:1349,y:708,t:1527027222141};\\\", \\\"{x:1339,y:703,t:1527027222158};\\\", \\\"{x:1331,y:700,t:1527027222175};\\\", \\\"{x:1324,y:697,t:1527027222192};\\\", \\\"{x:1323,y:696,t:1527027222207};\\\", \\\"{x:1321,y:693,t:1527027222225};\\\", \\\"{x:1320,y:689,t:1527027222240};\\\", \\\"{x:1319,y:687,t:1527027222256};\\\", \\\"{x:1319,y:686,t:1527027222273};\\\", \\\"{x:1319,y:685,t:1527027222369};\\\", \\\"{x:1320,y:684,t:1527027222385};\\\", \\\"{x:1321,y:683,t:1527027222393};\\\", \\\"{x:1324,y:683,t:1527027222407};\\\", \\\"{x:1327,y:682,t:1527027222424};\\\", \\\"{x:1331,y:682,t:1527027222441};\\\", \\\"{x:1336,y:682,t:1527027222457};\\\", \\\"{x:1341,y:683,t:1527027222474};\\\", \\\"{x:1345,y:686,t:1527027222491};\\\", \\\"{x:1349,y:687,t:1527027222507};\\\", \\\"{x:1351,y:688,t:1527027222524};\\\", \\\"{x:1352,y:690,t:1527027222540};\\\", \\\"{x:1353,y:691,t:1527027222762};\\\", \\\"{x:1353,y:692,t:1527027222777};\\\", \\\"{x:1352,y:692,t:1527027222790};\\\", \\\"{x:1349,y:692,t:1527027222810};\\\", \\\"{x:1346,y:692,t:1527027222824};\\\", \\\"{x:1344,y:692,t:1527027222841};\\\", \\\"{x:1340,y:692,t:1527027222858};\\\", \\\"{x:1335,y:692,t:1527027222874};\\\", \\\"{x:1332,y:692,t:1527027222891};\\\", \\\"{x:1328,y:692,t:1527027222908};\\\", \\\"{x:1324,y:691,t:1527027222924};\\\", \\\"{x:1322,y:691,t:1527027222941};\\\", \\\"{x:1321,y:690,t:1527027222958};\\\", \\\"{x:1321,y:689,t:1527027223266};\\\", \\\"{x:1322,y:689,t:1527027223298};\\\", \\\"{x:1324,y:689,t:1527027223308};\\\", \\\"{x:1325,y:689,t:1527027223370};\\\", \\\"{x:1328,y:688,t:1527027223385};\\\", \\\"{x:1331,y:688,t:1527027223393};\\\", \\\"{x:1333,y:688,t:1527027223408};\\\", \\\"{x:1339,y:687,t:1527027223425};\\\", \\\"{x:1340,y:687,t:1527027223441};\\\", \\\"{x:1341,y:686,t:1527027223569};\\\", \\\"{x:1340,y:686,t:1527027224474};\\\", \\\"{x:1339,y:688,t:1527027224493};\\\", \\\"{x:1338,y:688,t:1527027224545};\\\", \\\"{x:1333,y:693,t:1527027226770};\\\", \\\"{x:1329,y:695,t:1527027226777};\\\", \\\"{x:1321,y:702,t:1527027226793};\\\", \\\"{x:1313,y:707,t:1527027226810};\\\", \\\"{x:1309,y:711,t:1527027226827};\\\", \\\"{x:1299,y:718,t:1527027226844};\\\", \\\"{x:1289,y:726,t:1527027226862};\\\", \\\"{x:1278,y:733,t:1527027226877};\\\", \\\"{x:1265,y:742,t:1527027226895};\\\", \\\"{x:1247,y:753,t:1527027226910};\\\", \\\"{x:1232,y:759,t:1527027226928};\\\", \\\"{x:1222,y:763,t:1527027226945};\\\", \\\"{x:1211,y:767,t:1527027226962};\\\", \\\"{x:1205,y:767,t:1527027226978};\\\", \\\"{x:1201,y:767,t:1527027226994};\\\", \\\"{x:1190,y:767,t:1527027227012};\\\", \\\"{x:1173,y:764,t:1527027227027};\\\", \\\"{x:1148,y:758,t:1527027227044};\\\", \\\"{x:1107,y:744,t:1527027227062};\\\", \\\"{x:1048,y:727,t:1527027227078};\\\", \\\"{x:971,y:709,t:1527027227095};\\\", \\\"{x:907,y:690,t:1527027227112};\\\", \\\"{x:846,y:671,t:1527027227128};\\\", \\\"{x:789,y:651,t:1527027227144};\\\", \\\"{x:704,y:623,t:1527027227163};\\\", \\\"{x:650,y:603,t:1527027227176};\\\", \\\"{x:597,y:587,t:1527027227194};\\\", \\\"{x:556,y:577,t:1527027227212};\\\", \\\"{x:524,y:567,t:1527027227228};\\\", \\\"{x:504,y:561,t:1527027227245};\\\", \\\"{x:498,y:559,t:1527027227261};\\\", \\\"{x:497,y:557,t:1527027227279};\\\", \\\"{x:497,y:556,t:1527027227304};\\\", \\\"{x:500,y:555,t:1527027227313};\\\", \\\"{x:502,y:553,t:1527027227328};\\\", \\\"{x:506,y:550,t:1527027227345};\\\", \\\"{x:509,y:549,t:1527027227362};\\\", \\\"{x:512,y:548,t:1527027227378};\\\", \\\"{x:513,y:547,t:1527027227394};\\\", \\\"{x:515,y:547,t:1527027227449};\\\", \\\"{x:517,y:549,t:1527027227462};\\\", \\\"{x:522,y:556,t:1527027227479};\\\", \\\"{x:529,y:562,t:1527027227495};\\\", \\\"{x:536,y:569,t:1527027227513};\\\", \\\"{x:549,y:578,t:1527027227528};\\\", \\\"{x:556,y:579,t:1527027227544};\\\", \\\"{x:560,y:580,t:1527027227561};\\\", \\\"{x:563,y:580,t:1527027227578};\\\", \\\"{x:570,y:580,t:1527027227596};\\\", \\\"{x:579,y:580,t:1527027227612};\\\", \\\"{x:593,y:580,t:1527027227628};\\\", \\\"{x:608,y:580,t:1527027227646};\\\", \\\"{x:623,y:580,t:1527027227661};\\\", \\\"{x:635,y:582,t:1527027227679};\\\", \\\"{x:640,y:584,t:1527027227695};\\\", \\\"{x:642,y:584,t:1527027227711};\\\", \\\"{x:640,y:584,t:1527027227858};\\\", \\\"{x:638,y:584,t:1527027227865};\\\", \\\"{x:634,y:586,t:1527027227878};\\\", \\\"{x:635,y:586,t:1527027228241};\\\", \\\"{x:642,y:588,t:1527027228249};\\\", \\\"{x:645,y:590,t:1527027228264};\\\", \\\"{x:666,y:597,t:1527027228279};\\\", \\\"{x:692,y:609,t:1527027228296};\\\", \\\"{x:757,y:636,t:1527027228312};\\\", \\\"{x:812,y:651,t:1527027228329};\\\", \\\"{x:876,y:668,t:1527027228345};\\\", \\\"{x:952,y:685,t:1527027228363};\\\", \\\"{x:1019,y:704,t:1527027228379};\\\", \\\"{x:1103,y:729,t:1527027228395};\\\", \\\"{x:1161,y:745,t:1527027228413};\\\", \\\"{x:1204,y:754,t:1527027228429};\\\", \\\"{x:1230,y:758,t:1527027228446};\\\", \\\"{x:1248,y:760,t:1527027228463};\\\", \\\"{x:1261,y:762,t:1527027228479};\\\", \\\"{x:1270,y:763,t:1527027228496};\\\", \\\"{x:1289,y:768,t:1527027228513};\\\", \\\"{x:1302,y:771,t:1527027228530};\\\", \\\"{x:1311,y:778,t:1527027228546};\\\", \\\"{x:1321,y:784,t:1527027228563};\\\", \\\"{x:1330,y:790,t:1527027228580};\\\", \\\"{x:1352,y:799,t:1527027228596};\\\", \\\"{x:1374,y:808,t:1527027228613};\\\", \\\"{x:1394,y:817,t:1527027228630};\\\", \\\"{x:1408,y:823,t:1527027228646};\\\", \\\"{x:1417,y:827,t:1527027228664};\\\", \\\"{x:1426,y:831,t:1527027228680};\\\", \\\"{x:1433,y:835,t:1527027228697};\\\", \\\"{x:1439,y:837,t:1527027228714};\\\", \\\"{x:1441,y:838,t:1527027228730};\\\", \\\"{x:1441,y:839,t:1527027228786};\\\", \\\"{x:1441,y:842,t:1527027228796};\\\", \\\"{x:1435,y:842,t:1527027228814};\\\", \\\"{x:1422,y:838,t:1527027228831};\\\", \\\"{x:1407,y:832,t:1527027228847};\\\", \\\"{x:1403,y:830,t:1527027228864};\\\", \\\"{x:1403,y:829,t:1527027228881};\\\", \\\"{x:1401,y:828,t:1527027228896};\\\", \\\"{x:1399,y:823,t:1527027228913};\\\", \\\"{x:1399,y:818,t:1527027228931};\\\", \\\"{x:1397,y:809,t:1527027228947};\\\", \\\"{x:1396,y:797,t:1527027228963};\\\", \\\"{x:1396,y:779,t:1527027228981};\\\", \\\"{x:1396,y:760,t:1527027228998};\\\", \\\"{x:1398,y:739,t:1527027229014};\\\", \\\"{x:1403,y:719,t:1527027229030};\\\", \\\"{x:1409,y:702,t:1527027229048};\\\", \\\"{x:1410,y:688,t:1527027229063};\\\", \\\"{x:1410,y:679,t:1527027229081};\\\", \\\"{x:1408,y:669,t:1527027229097};\\\", \\\"{x:1403,y:664,t:1527027229114};\\\", \\\"{x:1402,y:663,t:1527027229130};\\\", \\\"{x:1402,y:662,t:1527027229147};\\\", \\\"{x:1401,y:662,t:1527027229290};\\\", \\\"{x:1400,y:662,t:1527027229298};\\\", \\\"{x:1398,y:662,t:1527027229313};\\\", \\\"{x:1396,y:664,t:1527027229331};\\\", \\\"{x:1394,y:664,t:1527027229347};\\\", \\\"{x:1393,y:665,t:1527027229363};\\\", \\\"{x:1391,y:666,t:1527027229546};\\\", \\\"{x:1390,y:667,t:1527027229666};\\\", \\\"{x:1388,y:667,t:1527027229681};\\\", \\\"{x:1387,y:668,t:1527027229698};\\\", \\\"{x:1387,y:669,t:1527027229715};\\\", \\\"{x:1385,y:672,t:1527027229731};\\\", \\\"{x:1384,y:673,t:1527027229748};\\\", \\\"{x:1383,y:675,t:1527027229765};\\\", \\\"{x:1380,y:678,t:1527027229781};\\\", \\\"{x:1379,y:680,t:1527027229797};\\\", \\\"{x:1378,y:681,t:1527027229815};\\\", \\\"{x:1377,y:682,t:1527027230354};\\\", \\\"{x:1376,y:683,t:1527027235776};\\\", \\\"{x:1374,y:683,t:1527027235784};\\\", \\\"{x:1371,y:685,t:1527027235801};\\\", \\\"{x:1367,y:686,t:1527027235818};\\\", \\\"{x:1365,y:686,t:1527027235835};\\\", \\\"{x:1363,y:686,t:1527027235851};\\\", \\\"{x:1361,y:686,t:1527027235868};\\\", \\\"{x:1360,y:686,t:1527027235885};\\\", \\\"{x:1358,y:687,t:1527027237065};\\\", \\\"{x:1356,y:688,t:1527027237104};\\\", \\\"{x:1355,y:689,t:1527027237137};\\\", \\\"{x:1354,y:689,t:1527027237152};\\\", \\\"{x:1353,y:690,t:1527027237169};\\\", \\\"{x:1351,y:691,t:1527027237186};\\\", \\\"{x:1350,y:692,t:1527027237233};\\\", \\\"{x:1346,y:696,t:1527027250480};\\\", \\\"{x:1344,y:697,t:1527027250495};\\\", \\\"{x:1343,y:697,t:1527027250512};\\\", \\\"{x:1327,y:703,t:1527027252632};\\\", \\\"{x:1280,y:717,t:1527027252647};\\\", \\\"{x:1173,y:762,t:1527027252663};\\\", \\\"{x:1124,y:794,t:1527027252680};\\\", \\\"{x:1108,y:813,t:1527027252697};\\\", \\\"{x:1079,y:835,t:1527027252714};\\\", \\\"{x:1030,y:861,t:1527027252730};\\\", \\\"{x:961,y:882,t:1527027252748};\\\", \\\"{x:874,y:896,t:1527027252763};\\\", \\\"{x:783,y:896,t:1527027252781};\\\", \\\"{x:680,y:896,t:1527027252798};\\\", \\\"{x:564,y:884,t:1527027252814};\\\", \\\"{x:457,y:874,t:1527027252830};\\\", \\\"{x:382,y:864,t:1527027252848};\\\", \\\"{x:337,y:856,t:1527027252864};\\\", \\\"{x:303,y:835,t:1527027252881};\\\", \\\"{x:288,y:820,t:1527027252897};\\\", \\\"{x:272,y:809,t:1527027252913};\\\", \\\"{x:266,y:803,t:1527027252931};\\\", \\\"{x:266,y:802,t:1527027252952};\\\", \\\"{x:266,y:800,t:1527027252964};\\\", \\\"{x:272,y:788,t:1527027252980};\\\", \\\"{x:290,y:770,t:1527027252998};\\\", \\\"{x:323,y:750,t:1527027253014};\\\", \\\"{x:365,y:729,t:1527027253031};\\\", \\\"{x:405,y:712,t:1527027253048};\\\", \\\"{x:415,y:707,t:1527027253063};\\\", \\\"{x:437,y:698,t:1527027253080};\\\", \\\"{x:445,y:696,t:1527027253097};\\\", \\\"{x:452,y:696,t:1527027253114};\\\", \\\"{x:462,y:696,t:1527027253130};\\\", \\\"{x:467,y:696,t:1527027253148};\\\", \\\"{x:469,y:696,t:1527027253164};\\\", \\\"{x:471,y:696,t:1527027253200};\\\", \\\"{x:473,y:696,t:1527027253214};\\\", \\\"{x:481,y:697,t:1527027253231};\\\", \\\"{x:482,y:697,t:1527027253247};\\\", \\\"{x:485,y:698,t:1527027253264};\\\", \\\"{x:488,y:700,t:1527027253281};\\\", \\\"{x:495,y:705,t:1527027253298};\\\", \\\"{x:504,y:713,t:1527027253315};\\\", \\\"{x:513,y:719,t:1527027253331};\\\", \\\"{x:519,y:724,t:1527027253348};\\\", \\\"{x:522,y:726,t:1527027253365};\\\", \\\"{x:524,y:727,t:1527027253380};\\\", \\\"{x:527,y:728,t:1527027253392};\\\", \\\"{x:529,y:730,t:1527027253408};\\\", \\\"{x:532,y:733,t:1527027253426};\\\", \\\"{x:533,y:734,t:1527027253442};\\\", \\\"{x:534,y:734,t:1527027253459};\\\", \\\"{x:538,y:731,t:1527027254560};\\\", \\\"{x:539,y:721,t:1527027254568};\\\", \\\"{x:540,y:711,t:1527027254584};\\\", \\\"{x:540,y:709,t:1527027254600};\\\", \\\"{x:540,y:708,t:1527027254616};\\\", \\\"{x:539,y:708,t:1527027254672};\\\", \\\"{x:535,y:708,t:1527027254684};\\\", \\\"{x:516,y:715,t:1527027254700};\\\", \\\"{x:496,y:725,t:1527027254716};\\\" ] }, { \\\"rt\\\": 10447, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 598742, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:746,t:1527027254813};\\\", \\\"{x:490,y:747,t:1527027254820};\\\", \\\"{x:491,y:747,t:1527027254839};\\\", \\\"{x:493,y:747,t:1527027254863};\\\", \\\"{x:494,y:747,t:1527027255009};\\\", \\\"{x:496,y:746,t:1527027255018};\\\", \\\"{x:499,y:745,t:1527027255034};\\\", \\\"{x:502,y:743,t:1527027255051};\\\", \\\"{x:503,y:743,t:1527027255068};\\\", \\\"{x:504,y:742,t:1527027255084};\\\", \\\"{x:505,y:742,t:1527027255101};\\\", \\\"{x:506,y:742,t:1527027255273};\\\", \\\"{x:507,y:742,t:1527027255296};\\\", \\\"{x:509,y:741,t:1527027255312};\\\", \\\"{x:520,y:737,t:1527027255400};\\\", \\\"{x:521,y:736,t:1527027255404};\\\", \\\"{x:523,y:735,t:1527027255419};\\\", \\\"{x:526,y:734,t:1527027255434};\\\", \\\"{x:527,y:733,t:1527027255451};\\\", \\\"{x:530,y:732,t:1527027255816};\\\", \\\"{x:535,y:731,t:1527027255823};\\\", \\\"{x:545,y:729,t:1527027255835};\\\", \\\"{x:561,y:728,t:1527027255850};\\\", \\\"{x:576,y:726,t:1527027255868};\\\", \\\"{x:593,y:723,t:1527027255885};\\\", \\\"{x:614,y:718,t:1527027255902};\\\", \\\"{x:633,y:718,t:1527027255917};\\\", \\\"{x:652,y:718,t:1527027255934};\\\", \\\"{x:675,y:718,t:1527027255952};\\\", \\\"{x:681,y:718,t:1527027255968};\\\", \\\"{x:698,y:717,t:1527027255985};\\\", \\\"{x:705,y:717,t:1527027256002};\\\", \\\"{x:710,y:717,t:1527027256018};\\\", \\\"{x:711,y:717,t:1527027256035};\\\", \\\"{x:715,y:719,t:1527027258016};\\\", \\\"{x:725,y:728,t:1527027258024};\\\", \\\"{x:736,y:737,t:1527027258036};\\\", \\\"{x:763,y:761,t:1527027258054};\\\", \\\"{x:790,y:783,t:1527027258070};\\\", \\\"{x:812,y:805,t:1527027258086};\\\", \\\"{x:843,y:830,t:1527027258104};\\\", \\\"{x:856,y:844,t:1527027258120};\\\", \\\"{x:868,y:856,t:1527027258136};\\\", \\\"{x:879,y:862,t:1527027258153};\\\", \\\"{x:882,y:864,t:1527027258170};\\\", \\\"{x:886,y:864,t:1527027258187};\\\", \\\"{x:892,y:864,t:1527027258204};\\\", \\\"{x:899,y:864,t:1527027258220};\\\", \\\"{x:905,y:864,t:1527027258237};\\\", \\\"{x:909,y:865,t:1527027258253};\\\", \\\"{x:917,y:868,t:1527027258270};\\\", \\\"{x:942,y:879,t:1527027258287};\\\", \\\"{x:1006,y:906,t:1527027258304};\\\", \\\"{x:1064,y:928,t:1527027258320};\\\", \\\"{x:1122,y:944,t:1527027258337};\\\", \\\"{x:1159,y:955,t:1527027258354};\\\", \\\"{x:1195,y:959,t:1527027258370};\\\", \\\"{x:1229,y:965,t:1527027258386};\\\", \\\"{x:1259,y:969,t:1527027258404};\\\", \\\"{x:1288,y:974,t:1527027258420};\\\", \\\"{x:1312,y:974,t:1527027258437};\\\", \\\"{x:1326,y:974,t:1527027258454};\\\", \\\"{x:1331,y:974,t:1527027258470};\\\", \\\"{x:1333,y:973,t:1527027258487};\\\", \\\"{x:1340,y:967,t:1527027258504};\\\", \\\"{x:1343,y:964,t:1527027258521};\\\", \\\"{x:1345,y:962,t:1527027258537};\\\", \\\"{x:1346,y:960,t:1527027258554};\\\", \\\"{x:1346,y:959,t:1527027258571};\\\", \\\"{x:1346,y:958,t:1527027258592};\\\", \\\"{x:1347,y:957,t:1527027258604};\\\", \\\"{x:1348,y:955,t:1527027258848};\\\", \\\"{x:1348,y:953,t:1527027258856};\\\", \\\"{x:1350,y:951,t:1527027258871};\\\", \\\"{x:1350,y:949,t:1527027258887};\\\", \\\"{x:1350,y:947,t:1527027258904};\\\", \\\"{x:1350,y:945,t:1527027258921};\\\", \\\"{x:1350,y:943,t:1527027258938};\\\", \\\"{x:1350,y:940,t:1527027258954};\\\", \\\"{x:1349,y:932,t:1527027258971};\\\", \\\"{x:1348,y:924,t:1527027258988};\\\", \\\"{x:1345,y:913,t:1527027259003};\\\", \\\"{x:1342,y:900,t:1527027259020};\\\", \\\"{x:1339,y:890,t:1527027259038};\\\", \\\"{x:1331,y:873,t:1527027259054};\\\", \\\"{x:1325,y:853,t:1527027259071};\\\", \\\"{x:1323,y:825,t:1527027259088};\\\", \\\"{x:1323,y:802,t:1527027259104};\\\", \\\"{x:1323,y:780,t:1527027259121};\\\", \\\"{x:1326,y:755,t:1527027259138};\\\", \\\"{x:1331,y:737,t:1527027259154};\\\", \\\"{x:1333,y:723,t:1527027259171};\\\", \\\"{x:1333,y:713,t:1527027259188};\\\", \\\"{x:1335,y:709,t:1527027259204};\\\", \\\"{x:1336,y:706,t:1527027259221};\\\", \\\"{x:1336,y:703,t:1527027259238};\\\", \\\"{x:1336,y:701,t:1527027259254};\\\", \\\"{x:1336,y:700,t:1527027259271};\\\", \\\"{x:1335,y:700,t:1527027259368};\\\", \\\"{x:1333,y:700,t:1527027259385};\\\", \\\"{x:1331,y:701,t:1527027259424};\\\", \\\"{x:1330,y:701,t:1527027259438};\\\", \\\"{x:1328,y:702,t:1527027259455};\\\", \\\"{x:1326,y:703,t:1527027259471};\\\", \\\"{x:1323,y:706,t:1527027259633};\\\", \\\"{x:1320,y:707,t:1527027259640};\\\", \\\"{x:1311,y:712,t:1527027259655};\\\", \\\"{x:1289,y:721,t:1527027259671};\\\", \\\"{x:1249,y:729,t:1527027259689};\\\", \\\"{x:1209,y:734,t:1527027259705};\\\", \\\"{x:1166,y:741,t:1527027259722};\\\", \\\"{x:1130,y:746,t:1527027259739};\\\", \\\"{x:1094,y:749,t:1527027259755};\\\", \\\"{x:1065,y:750,t:1527027259772};\\\", \\\"{x:1025,y:750,t:1527027259788};\\\", \\\"{x:981,y:745,t:1527027259805};\\\", \\\"{x:932,y:734,t:1527027259822};\\\", \\\"{x:872,y:714,t:1527027259838};\\\", \\\"{x:804,y:700,t:1527027259855};\\\", \\\"{x:735,y:689,t:1527027259871};\\\", \\\"{x:708,y:686,t:1527027259887};\\\", \\\"{x:691,y:682,t:1527027259905};\\\", \\\"{x:677,y:676,t:1527027259922};\\\", \\\"{x:666,y:673,t:1527027259938};\\\", \\\"{x:662,y:671,t:1527027259955};\\\", \\\"{x:655,y:668,t:1527027259972};\\\", \\\"{x:643,y:663,t:1527027259988};\\\", \\\"{x:624,y:657,t:1527027260005};\\\", \\\"{x:603,y:651,t:1527027260022};\\\", \\\"{x:582,y:640,t:1527027260038};\\\", \\\"{x:568,y:637,t:1527027260055};\\\", \\\"{x:550,y:633,t:1527027260072};\\\", \\\"{x:537,y:630,t:1527027260090};\\\", \\\"{x:524,y:626,t:1527027260104};\\\", \\\"{x:507,y:620,t:1527027260122};\\\", \\\"{x:493,y:615,t:1527027260138};\\\", \\\"{x:475,y:605,t:1527027260154};\\\", \\\"{x:460,y:598,t:1527027260173};\\\", \\\"{x:442,y:590,t:1527027260188};\\\", \\\"{x:423,y:584,t:1527027260204};\\\", \\\"{x:406,y:579,t:1527027260222};\\\", \\\"{x:385,y:576,t:1527027260238};\\\", \\\"{x:366,y:573,t:1527027260255};\\\", \\\"{x:329,y:573,t:1527027260271};\\\", \\\"{x:300,y:573,t:1527027260288};\\\", \\\"{x:270,y:571,t:1527027260305};\\\", \\\"{x:237,y:567,t:1527027260322};\\\", \\\"{x:218,y:563,t:1527027260338};\\\", \\\"{x:210,y:561,t:1527027260356};\\\", \\\"{x:206,y:558,t:1527027260372};\\\", \\\"{x:203,y:557,t:1527027260387};\\\", \\\"{x:202,y:556,t:1527027260447};\\\", \\\"{x:202,y:555,t:1527027260464};\\\", \\\"{x:200,y:554,t:1527027260471};\\\", \\\"{x:195,y:552,t:1527027260487};\\\", \\\"{x:194,y:551,t:1527027260504};\\\", \\\"{x:193,y:551,t:1527027260522};\\\", \\\"{x:193,y:549,t:1527027260537};\\\", \\\"{x:192,y:548,t:1527027260560};\\\", \\\"{x:189,y:546,t:1527027260575};\\\", \\\"{x:189,y:545,t:1527027260588};\\\", \\\"{x:188,y:544,t:1527027260604};\\\", \\\"{x:186,y:544,t:1527027260622};\\\", \\\"{x:185,y:544,t:1527027260639};\\\", \\\"{x:184,y:544,t:1527027260663};\\\", \\\"{x:183,y:543,t:1527027260671};\\\", \\\"{x:181,y:542,t:1527027260689};\\\", \\\"{x:178,y:541,t:1527027260704};\\\", \\\"{x:174,y:540,t:1527027260722};\\\", \\\"{x:170,y:539,t:1527027260739};\\\", \\\"{x:169,y:538,t:1527027260755};\\\", \\\"{x:172,y:538,t:1527027260984};\\\", \\\"{x:182,y:541,t:1527027260991};\\\", \\\"{x:192,y:542,t:1527027261006};\\\", \\\"{x:220,y:554,t:1527027261022};\\\", \\\"{x:259,y:575,t:1527027261040};\\\", \\\"{x:351,y:634,t:1527027261056};\\\", \\\"{x:386,y:662,t:1527027261073};\\\", \\\"{x:399,y:675,t:1527027261089};\\\", \\\"{x:404,y:679,t:1527027261106};\\\", \\\"{x:409,y:683,t:1527027261122};\\\", \\\"{x:423,y:693,t:1527027261139};\\\", \\\"{x:435,y:701,t:1527027261156};\\\", \\\"{x:437,y:703,t:1527027261172};\\\", \\\"{x:438,y:703,t:1527027261248};\\\", \\\"{x:439,y:702,t:1527027261272};\\\", \\\"{x:439,y:701,t:1527027261280};\\\", \\\"{x:441,y:698,t:1527027261290};\\\", \\\"{x:445,y:694,t:1527027261306};\\\", \\\"{x:450,y:691,t:1527027261323};\\\", \\\"{x:466,y:682,t:1527027261341};\\\", \\\"{x:485,y:674,t:1527027261356};\\\", \\\"{x:509,y:665,t:1527027261373};\\\", \\\"{x:537,y:658,t:1527027261390};\\\", \\\"{x:560,y:653,t:1527027261407};\\\", \\\"{x:581,y:648,t:1527027261423};\\\", \\\"{x:608,y:645,t:1527027261441};\\\", \\\"{x:620,y:643,t:1527027261457};\\\", \\\"{x:638,y:641,t:1527027261473};\\\", \\\"{x:658,y:638,t:1527027261490};\\\", \\\"{x:678,y:636,t:1527027261507};\\\", \\\"{x:695,y:632,t:1527027261524};\\\", \\\"{x:709,y:630,t:1527027261541};\\\", \\\"{x:715,y:629,t:1527027261557};\\\", \\\"{x:716,y:628,t:1527027261573};\\\", \\\"{x:717,y:628,t:1527027261589};\\\", \\\"{x:717,y:627,t:1527027261656};\\\", \\\"{x:711,y:620,t:1527027261673};\\\", \\\"{x:700,y:613,t:1527027261689};\\\", \\\"{x:689,y:605,t:1527027261706};\\\", \\\"{x:687,y:603,t:1527027261723};\\\", \\\"{x:687,y:602,t:1527027261739};\\\", \\\"{x:687,y:601,t:1527027261881};\\\", \\\"{x:688,y:601,t:1527027262409};\\\", \\\"{x:691,y:600,t:1527027262424};\\\", \\\"{x:704,y:593,t:1527027262440};\\\", \\\"{x:709,y:592,t:1527027262457};\\\", \\\"{x:715,y:589,t:1527027262473};\\\", \\\"{x:724,y:589,t:1527027262490};\\\", \\\"{x:738,y:587,t:1527027262507};\\\", \\\"{x:753,y:584,t:1527027262523};\\\", \\\"{x:770,y:584,t:1527027262540};\\\", \\\"{x:785,y:582,t:1527027262557};\\\", \\\"{x:802,y:581,t:1527027262574};\\\", \\\"{x:822,y:578,t:1527027262590};\\\", \\\"{x:838,y:577,t:1527027262608};\\\", \\\"{x:864,y:573,t:1527027262624};\\\", \\\"{x:882,y:573,t:1527027262640};\\\", \\\"{x:904,y:571,t:1527027262657};\\\", \\\"{x:922,y:570,t:1527027262674};\\\", \\\"{x:932,y:567,t:1527027262690};\\\", \\\"{x:939,y:567,t:1527027262707};\\\", \\\"{x:945,y:567,t:1527027262723};\\\", \\\"{x:951,y:567,t:1527027262741};\\\", \\\"{x:952,y:567,t:1527027262757};\\\", \\\"{x:953,y:566,t:1527027262776};\\\", \\\"{x:954,y:566,t:1527027262791};\\\", \\\"{x:954,y:565,t:1527027262806};\\\", \\\"{x:955,y:563,t:1527027262824};\\\", \\\"{x:955,y:559,t:1527027262841};\\\", \\\"{x:955,y:555,t:1527027262857};\\\", \\\"{x:954,y:550,t:1527027262874};\\\", \\\"{x:950,y:543,t:1527027262892};\\\", \\\"{x:947,y:538,t:1527027262907};\\\", \\\"{x:946,y:535,t:1527027262924};\\\", \\\"{x:945,y:533,t:1527027262940};\\\", \\\"{x:943,y:531,t:1527027262957};\\\", \\\"{x:937,y:528,t:1527027262975};\\\", \\\"{x:928,y:526,t:1527027262990};\\\", \\\"{x:916,y:522,t:1527027263009};\\\", \\\"{x:908,y:521,t:1527027263024};\\\", \\\"{x:904,y:519,t:1527027263040};\\\", \\\"{x:901,y:519,t:1527027263057};\\\", \\\"{x:894,y:519,t:1527027263074};\\\", \\\"{x:885,y:518,t:1527027263091};\\\", \\\"{x:877,y:517,t:1527027263107};\\\", \\\"{x:874,y:515,t:1527027263124};\\\", \\\"{x:872,y:514,t:1527027263140};\\\", \\\"{x:871,y:513,t:1527027263157};\\\", \\\"{x:869,y:511,t:1527027263174};\\\", \\\"{x:866,y:507,t:1527027263191};\\\", \\\"{x:859,y:503,t:1527027263207};\\\", \\\"{x:853,y:497,t:1527027263225};\\\", \\\"{x:848,y:494,t:1527027263241};\\\", \\\"{x:846,y:493,t:1527027263258};\\\", \\\"{x:845,y:493,t:1527027263275};\\\", \\\"{x:844,y:492,t:1527027263672};\\\", \\\"{x:843,y:498,t:1527027263688};\\\", \\\"{x:841,y:509,t:1527027263696};\\\", \\\"{x:838,y:523,t:1527027263708};\\\", \\\"{x:833,y:552,t:1527027263724};\\\", \\\"{x:825,y:582,t:1527027263741};\\\", \\\"{x:814,y:616,t:1527027263759};\\\", \\\"{x:802,y:646,t:1527027263774};\\\", \\\"{x:792,y:671,t:1527027263791};\\\", \\\"{x:782,y:697,t:1527027263808};\\\", \\\"{x:779,y:711,t:1527027263824};\\\", \\\"{x:777,y:731,t:1527027263841};\\\", \\\"{x:772,y:745,t:1527027263858};\\\", \\\"{x:767,y:764,t:1527027263875};\\\", \\\"{x:761,y:783,t:1527027263892};\\\", \\\"{x:756,y:800,t:1527027263909};\\\", \\\"{x:746,y:818,t:1527027263925};\\\", \\\"{x:735,y:839,t:1527027263941};\\\", \\\"{x:723,y:858,t:1527027263958};\\\", \\\"{x:711,y:876,t:1527027263975};\\\", \\\"{x:696,y:895,t:1527027263991};\\\", \\\"{x:678,y:909,t:1527027264009};\\\", \\\"{x:670,y:916,t:1527027264025};\\\", \\\"{x:667,y:918,t:1527027264042};\\\", \\\"{x:666,y:919,t:1527027264058};\\\", \\\"{x:663,y:920,t:1527027264075};\\\", \\\"{x:663,y:921,t:1527027264092};\\\", \\\"{x:661,y:924,t:1527027264109};\\\", \\\"{x:659,y:929,t:1527027264125};\\\", \\\"{x:655,y:937,t:1527027264142};\\\", \\\"{x:648,y:947,t:1527027264166};\\\", \\\"{x:640,y:956,t:1527027264214};\\\", \\\"{x:639,y:956,t:1527027264225};\\\", \\\"{x:638,y:957,t:1527027264264};\\\", \\\"{x:636,y:957,t:1527027264287};\\\", \\\"{x:634,y:957,t:1527027264296};\\\", \\\"{x:629,y:956,t:1527027264308};\\\", \\\"{x:620,y:951,t:1527027264325};\\\", \\\"{x:609,y:942,t:1527027264342};\\\", \\\"{x:598,y:933,t:1527027264358};\\\", \\\"{x:590,y:926,t:1527027264375};\\\", \\\"{x:575,y:916,t:1527027264392};\\\", \\\"{x:564,y:909,t:1527027264408};\\\", \\\"{x:554,y:902,t:1527027264426};\\\", \\\"{x:546,y:897,t:1527027264442};\\\", \\\"{x:542,y:894,t:1527027264458};\\\", \\\"{x:537,y:890,t:1527027264475};\\\", \\\"{x:535,y:886,t:1527027264492};\\\", \\\"{x:534,y:883,t:1527027264508};\\\", \\\"{x:533,y:877,t:1527027264526};\\\", \\\"{x:532,y:872,t:1527027264542};\\\", \\\"{x:531,y:866,t:1527027264558};\\\", \\\"{x:530,y:860,t:1527027264576};\\\", \\\"{x:530,y:853,t:1527027264592};\\\", \\\"{x:527,y:838,t:1527027264609};\\\", \\\"{x:525,y:821,t:1527027264625};\\\", \\\"{x:525,y:807,t:1527027264643};\\\", \\\"{x:525,y:799,t:1527027264660};\\\", \\\"{x:525,y:794,t:1527027264676};\\\", \\\"{x:525,y:789,t:1527027264693};\\\", \\\"{x:525,y:783,t:1527027264710};\\\", \\\"{x:525,y:779,t:1527027264726};\\\", \\\"{x:525,y:773,t:1527027264743};\\\", \\\"{x:525,y:768,t:1527027264760};\\\", \\\"{x:526,y:765,t:1527027264776};\\\", \\\"{x:526,y:761,t:1527027264792};\\\", \\\"{x:526,y:759,t:1527027264809};\\\", \\\"{x:526,y:758,t:1527027264831};\\\", \\\"{x:526,y:757,t:1527027264872};\\\", \\\"{x:526,y:756,t:1527027264880};\\\", \\\"{x:526,y:755,t:1527027264892};\\\", \\\"{x:526,y:752,t:1527027264909};\\\", \\\"{x:526,y:749,t:1527027264925};\\\", \\\"{x:526,y:746,t:1527027264942};\\\", \\\"{x:526,y:743,t:1527027264960};\\\", \\\"{x:526,y:742,t:1527027264976};\\\", \\\"{x:525,y:736,t:1527027264992};\\\", \\\"{x:525,y:732,t:1527027265009};\\\", \\\"{x:525,y:731,t:1527027265026};\\\", \\\"{x:525,y:729,t:1527027265048};\\\" ] }, { \\\"rt\\\": 8009, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 608026, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:728,t:1527027266800};\\\", \\\"{x:524,y:729,t:1527027266808};\\\", \\\"{x:532,y:736,t:1527027266818};\\\", \\\"{x:543,y:749,t:1527027266835};\\\", \\\"{x:547,y:755,t:1527027266852};\\\", \\\"{x:551,y:761,t:1527027266868};\\\", \\\"{x:557,y:770,t:1527027266886};\\\", \\\"{x:566,y:783,t:1527027266903};\\\", \\\"{x:578,y:797,t:1527027266919};\\\", \\\"{x:593,y:813,t:1527027266936};\\\", \\\"{x:613,y:826,t:1527027266953};\\\", \\\"{x:629,y:834,t:1527027266968};\\\", \\\"{x:644,y:840,t:1527027266986};\\\", \\\"{x:656,y:842,t:1527027267002};\\\", \\\"{x:669,y:843,t:1527027267019};\\\", \\\"{x:679,y:843,t:1527027267035};\\\", \\\"{x:725,y:827,t:1527027267146};\\\", \\\"{x:726,y:826,t:1527027267152};\\\", \\\"{x:727,y:826,t:1527027267170};\\\", \\\"{x:734,y:824,t:1527027270049};\\\", \\\"{x:748,y:824,t:1527027270057};\\\", \\\"{x:787,y:824,t:1527027270074};\\\", \\\"{x:851,y:824,t:1527027270091};\\\", \\\"{x:918,y:824,t:1527027270107};\\\", \\\"{x:971,y:824,t:1527027270124};\\\", \\\"{x:999,y:824,t:1527027270141};\\\", \\\"{x:1015,y:824,t:1527027270157};\\\", \\\"{x:1017,y:824,t:1527027270174};\\\", \\\"{x:1018,y:824,t:1527027270225};\\\", \\\"{x:1013,y:828,t:1527027270241};\\\", \\\"{x:997,y:834,t:1527027270258};\\\", \\\"{x:970,y:846,t:1527027270275};\\\", \\\"{x:943,y:858,t:1527027270291};\\\", \\\"{x:916,y:869,t:1527027270308};\\\", \\\"{x:896,y:877,t:1527027270325};\\\", \\\"{x:884,y:885,t:1527027270341};\\\", \\\"{x:878,y:888,t:1527027270358};\\\", \\\"{x:875,y:888,t:1527027270375};\\\", \\\"{x:872,y:890,t:1527027270392};\\\", \\\"{x:868,y:892,t:1527027270408};\\\", \\\"{x:860,y:896,t:1527027270424};\\\", \\\"{x:855,y:897,t:1527027270441};\\\", \\\"{x:853,y:898,t:1527027270458};\\\", \\\"{x:852,y:898,t:1527027270537};\\\", \\\"{x:850,y:898,t:1527027271041};\\\", \\\"{x:846,y:898,t:1527027271049};\\\", \\\"{x:842,y:898,t:1527027271058};\\\", \\\"{x:831,y:894,t:1527027271076};\\\", \\\"{x:818,y:888,t:1527027271093};\\\", \\\"{x:802,y:880,t:1527027271108};\\\", \\\"{x:782,y:873,t:1527027271126};\\\", \\\"{x:765,y:868,t:1527027271142};\\\", \\\"{x:746,y:863,t:1527027271158};\\\", \\\"{x:735,y:859,t:1527027271175};\\\", \\\"{x:727,y:857,t:1527027271192};\\\", \\\"{x:726,y:857,t:1527027271209};\\\", \\\"{x:725,y:857,t:1527027271425};\\\", \\\"{x:723,y:857,t:1527027271432};\\\", \\\"{x:718,y:852,t:1527027271442};\\\", \\\"{x:709,y:845,t:1527027271459};\\\", \\\"{x:695,y:836,t:1527027271477};\\\", \\\"{x:682,y:823,t:1527027271493};\\\", \\\"{x:666,y:810,t:1527027271510};\\\", \\\"{x:649,y:793,t:1527027271527};\\\", \\\"{x:638,y:777,t:1527027271543};\\\", \\\"{x:630,y:762,t:1527027271560};\\\", \\\"{x:622,y:744,t:1527027271576};\\\", \\\"{x:617,y:733,t:1527027271593};\\\", \\\"{x:613,y:725,t:1527027271609};\\\", \\\"{x:609,y:720,t:1527027271627};\\\", \\\"{x:604,y:712,t:1527027271643};\\\", \\\"{x:599,y:706,t:1527027271660};\\\", \\\"{x:592,y:697,t:1527027271677};\\\", \\\"{x:589,y:693,t:1527027271694};\\\", \\\"{x:586,y:689,t:1527027271710};\\\", \\\"{x:582,y:685,t:1527027271727};\\\", \\\"{x:578,y:681,t:1527027271743};\\\", \\\"{x:574,y:678,t:1527027271759};\\\", \\\"{x:561,y:671,t:1527027271777};\\\", \\\"{x:549,y:664,t:1527027271794};\\\", \\\"{x:536,y:658,t:1527027271809};\\\", \\\"{x:525,y:653,t:1527027271826};\\\", \\\"{x:516,y:649,t:1527027271844};\\\", \\\"{x:505,y:644,t:1527027271860};\\\", \\\"{x:492,y:640,t:1527027271878};\\\", \\\"{x:481,y:637,t:1527027271895};\\\", \\\"{x:472,y:634,t:1527027271926};\\\", \\\"{x:471,y:634,t:1527027271943};\\\", \\\"{x:471,y:632,t:1527027271956};\\\", \\\"{x:475,y:627,t:1527027271973};\\\", \\\"{x:483,y:622,t:1527027271989};\\\", \\\"{x:491,y:618,t:1527027272005};\\\", \\\"{x:503,y:612,t:1527027272023};\\\", \\\"{x:518,y:603,t:1527027272039};\\\", \\\"{x:543,y:592,t:1527027272056};\\\", \\\"{x:556,y:588,t:1527027272072};\\\", \\\"{x:563,y:586,t:1527027272089};\\\", \\\"{x:567,y:583,t:1527027272106};\\\", \\\"{x:569,y:583,t:1527027272122};\\\", \\\"{x:572,y:581,t:1527027272139};\\\", \\\"{x:575,y:580,t:1527027272155};\\\", \\\"{x:578,y:579,t:1527027272172};\\\", \\\"{x:582,y:577,t:1527027272190};\\\", \\\"{x:584,y:576,t:1527027272206};\\\", \\\"{x:582,y:576,t:1527027272265};\\\", \\\"{x:569,y:576,t:1527027272272};\\\", \\\"{x:541,y:579,t:1527027272290};\\\", \\\"{x:498,y:586,t:1527027272308};\\\", \\\"{x:447,y:594,t:1527027272322};\\\", \\\"{x:401,y:597,t:1527027272339};\\\", \\\"{x:363,y:600,t:1527027272357};\\\", \\\"{x:336,y:600,t:1527027272373};\\\", \\\"{x:327,y:600,t:1527027272389};\\\", \\\"{x:326,y:600,t:1527027272423};\\\", \\\"{x:324,y:600,t:1527027272528};\\\", \\\"{x:323,y:600,t:1527027272539};\\\", \\\"{x:310,y:595,t:1527027272556};\\\", \\\"{x:293,y:591,t:1527027272573};\\\", \\\"{x:276,y:585,t:1527027272589};\\\", \\\"{x:263,y:578,t:1527027272606};\\\", \\\"{x:249,y:570,t:1527027272622};\\\", \\\"{x:226,y:557,t:1527027272640};\\\", \\\"{x:214,y:549,t:1527027272657};\\\", \\\"{x:204,y:543,t:1527027272673};\\\", \\\"{x:195,y:538,t:1527027272689};\\\", \\\"{x:196,y:538,t:1527027273023};\\\", \\\"{x:199,y:539,t:1527027273041};\\\", \\\"{x:210,y:558,t:1527027273058};\\\", \\\"{x:240,y:603,t:1527027273075};\\\", \\\"{x:282,y:667,t:1527027273090};\\\", \\\"{x:322,y:723,t:1527027273106};\\\", \\\"{x:349,y:760,t:1527027273124};\\\", \\\"{x:370,y:781,t:1527027273140};\\\", \\\"{x:387,y:794,t:1527027273156};\\\", \\\"{x:418,y:812,t:1527027273173};\\\", \\\"{x:446,y:821,t:1527027273190};\\\", \\\"{x:459,y:825,t:1527027273206};\\\", \\\"{x:463,y:825,t:1527027273224};\\\", \\\"{x:464,y:821,t:1527027273289};\\\", \\\"{x:464,y:813,t:1527027273296};\\\", \\\"{x:464,y:803,t:1527027273307};\\\", \\\"{x:460,y:788,t:1527027273324};\\\", \\\"{x:448,y:768,t:1527027273341};\\\", \\\"{x:427,y:748,t:1527027273358};\\\", \\\"{x:395,y:724,t:1527027273374};\\\", \\\"{x:363,y:705,t:1527027273391};\\\", \\\"{x:329,y:690,t:1527027273408};\\\", \\\"{x:310,y:679,t:1527027273425};\\\", \\\"{x:290,y:668,t:1527027273441};\\\", \\\"{x:268,y:657,t:1527027273458};\\\", \\\"{x:250,y:647,t:1527027273472};\\\", \\\"{x:228,y:637,t:1527027273490};\\\", \\\"{x:207,y:628,t:1527027273507};\\\", \\\"{x:191,y:620,t:1527027273523};\\\", \\\"{x:182,y:616,t:1527027273541};\\\", \\\"{x:178,y:613,t:1527027273558};\\\", \\\"{x:177,y:610,t:1527027273573};\\\", \\\"{x:176,y:606,t:1527027273591};\\\", \\\"{x:174,y:600,t:1527027273608};\\\", \\\"{x:174,y:585,t:1527027273624};\\\", \\\"{x:174,y:577,t:1527027273640};\\\", \\\"{x:174,y:572,t:1527027273656};\\\", \\\"{x:174,y:563,t:1527027273674};\\\", \\\"{x:174,y:551,t:1527027273691};\\\", \\\"{x:174,y:546,t:1527027273708};\\\", \\\"{x:173,y:541,t:1527027273724};\\\", \\\"{x:172,y:538,t:1527027273741};\\\", \\\"{x:172,y:536,t:1527027273758};\\\", \\\"{x:172,y:535,t:1527027273773};\\\", \\\"{x:172,y:533,t:1527027273790};\\\", \\\"{x:171,y:532,t:1527027273808};\\\", \\\"{x:184,y:553,t:1527027274024};\\\", \\\"{x:223,y:616,t:1527027274041};\\\", \\\"{x:263,y:670,t:1527027274058};\\\", \\\"{x:291,y:705,t:1527027274075};\\\", \\\"{x:314,y:725,t:1527027274091};\\\", \\\"{x:333,y:736,t:1527027274107};\\\", \\\"{x:348,y:741,t:1527027274124};\\\", \\\"{x:364,y:744,t:1527027274141};\\\", \\\"{x:380,y:744,t:1527027274157};\\\", \\\"{x:396,y:745,t:1527027274174};\\\", \\\"{x:409,y:745,t:1527027274190};\\\", \\\"{x:418,y:745,t:1527027274208};\\\", \\\"{x:419,y:745,t:1527027274224};\\\", \\\"{x:421,y:745,t:1527027274256};\\\", \\\"{x:423,y:745,t:1527027274264};\\\", \\\"{x:425,y:744,t:1527027274276};\\\", \\\"{x:435,y:739,t:1527027274291};\\\", \\\"{x:447,y:734,t:1527027274309};\\\", \\\"{x:458,y:732,t:1527027274325};\\\", \\\"{x:467,y:729,t:1527027274342};\\\", \\\"{x:474,y:729,t:1527027274358};\\\", \\\"{x:477,y:729,t:1527027274375};\\\", \\\"{x:483,y:729,t:1527027274392};\\\", \\\"{x:489,y:729,t:1527027274408};\\\", \\\"{x:492,y:729,t:1527027274425};\\\", \\\"{x:494,y:729,t:1527027274442};\\\", \\\"{x:495,y:729,t:1527027274464};\\\", \\\"{x:496,y:729,t:1527027274524};\\\", \\\"{x:497,y:729,t:1527027274542};\\\", \\\"{x:499,y:730,t:1527027274551};\\\", \\\"{x:499,y:730,t:1527027274569};\\\", \\\"{x:501,y:733,t:1527027274736};\\\", \\\"{x:513,y:751,t:1527027274744};\\\", \\\"{x:544,y:786,t:1527027274757};\\\", \\\"{x:632,y:859,t:1527027274775};\\\", \\\"{x:794,y:960,t:1527027274791};\\\", \\\"{x:903,y:1000,t:1527027274808};\\\", \\\"{x:1002,y:1021,t:1527027274824};\\\", \\\"{x:1085,y:1032,t:1527027274842};\\\", \\\"{x:1158,y:1034,t:1527027274858};\\\", \\\"{x:1219,y:1034,t:1527027274875};\\\", \\\"{x:1267,y:1034,t:1527027274892};\\\", \\\"{x:1297,y:1029,t:1527027274907};\\\", \\\"{x:1317,y:1020,t:1527027274925};\\\", \\\"{x:1328,y:1014,t:1527027274941};\\\", \\\"{x:1336,y:1008,t:1527027274958};\\\", \\\"{x:1340,y:1002,t:1527027274975};\\\", \\\"{x:1342,y:994,t:1527027274992};\\\", \\\"{x:1344,y:984,t:1527027275008};\\\", \\\"{x:1345,y:968,t:1527027275025};\\\", \\\"{x:1345,y:947,t:1527027275041};\\\", \\\"{x:1332,y:917,t:1527027275059};\\\", \\\"{x:1314,y:883,t:1527027275074};\\\", \\\"{x:1290,y:849,t:1527027275092};\\\", \\\"{x:1258,y:817,t:1527027275109};\\\", \\\"{x:1227,y:793,t:1527027275125};\\\", \\\"{x:1192,y:773,t:1527027275142};\\\", \\\"{x:1154,y:753,t:1527027275158};\\\", \\\"{x:1118,y:738,t:1527027275175};\\\", \\\"{x:1065,y:716,t:1527027275192};\\\", \\\"{x:1034,y:704,t:1527027275209};\\\", \\\"{x:996,y:691,t:1527027275225};\\\", \\\"{x:956,y:683,t:1527027275242};\\\", \\\"{x:929,y:675,t:1527027275258};\\\", \\\"{x:910,y:669,t:1527027275274};\\\", \\\"{x:891,y:668,t:1527027275291};\\\", \\\"{x:876,y:668,t:1527027275309};\\\", \\\"{x:862,y:668,t:1527027275325};\\\", \\\"{x:848,y:670,t:1527027275341};\\\", \\\"{x:839,y:674,t:1527027275359};\\\", \\\"{x:829,y:681,t:1527027275375};\\\", \\\"{x:825,y:687,t:1527027275391};\\\", \\\"{x:818,y:698,t:1527027275408};\\\", \\\"{x:814,y:707,t:1527027275425};\\\", \\\"{x:811,y:714,t:1527027275442};\\\", \\\"{x:808,y:719,t:1527027275459};\\\", \\\"{x:807,y:721,t:1527027275475};\\\", \\\"{x:805,y:724,t:1527027275492};\\\", \\\"{x:805,y:725,t:1527027275509};\\\", \\\"{x:804,y:725,t:1527027275561};\\\" ] }, { \\\"rt\\\": 23384, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 632606, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -Z -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:799,y:727,t:1527027275747};\\\", \\\"{x:799,y:728,t:1527027275758};\\\", \\\"{x:797,y:728,t:1527027275912};\\\", \\\"{x:796,y:728,t:1527027275927};\\\", \\\"{x:795,y:728,t:1527027275943};\\\", \\\"{x:794,y:729,t:1527027275959};\\\", \\\"{x:790,y:731,t:1527027275975};\\\", \\\"{x:789,y:732,t:1527027275992};\\\", \\\"{x:788,y:732,t:1527027276008};\\\", \\\"{x:787,y:732,t:1527027276025};\\\", \\\"{x:786,y:732,t:1527027276043};\\\", \\\"{x:785,y:732,t:1527027276393};\\\", \\\"{x:783,y:733,t:1527027276409};\\\", \\\"{x:783,y:734,t:1527027276425};\\\", \\\"{x:782,y:734,t:1527027276455};\\\", \\\"{x:781,y:734,t:1527027276464};\\\", \\\"{x:780,y:735,t:1527027276480};\\\", \\\"{x:777,y:736,t:1527027276495};\\\", \\\"{x:776,y:736,t:1527027276536};\\\", \\\"{x:776,y:737,t:1527027276551};\\\", \\\"{x:775,y:737,t:1527027276559};\\\", \\\"{x:773,y:737,t:1527027276577};\\\", \\\"{x:771,y:737,t:1527027276592};\\\", \\\"{x:768,y:738,t:1527027276610};\\\", \\\"{x:765,y:739,t:1527027276627};\\\", \\\"{x:763,y:740,t:1527027276643};\\\", \\\"{x:762,y:740,t:1527027276659};\\\", \\\"{x:760,y:740,t:1527027276677};\\\", \\\"{x:759,y:741,t:1527027276696};\\\", \\\"{x:758,y:741,t:1527027276736};\\\", \\\"{x:757,y:741,t:1527027276745};\\\", \\\"{x:756,y:741,t:1527027276777};\\\", \\\"{x:755,y:741,t:1527027276793};\\\", \\\"{x:754,y:741,t:1527027276810};\\\", \\\"{x:753,y:741,t:1527027276840};\\\", \\\"{x:752,y:741,t:1527027276856};\\\", \\\"{x:751,y:741,t:1527027276872};\\\", \\\"{x:750,y:741,t:1527027276929};\\\", \\\"{x:749,y:741,t:1527027276944};\\\", \\\"{x:748,y:741,t:1527027276985};\\\", \\\"{x:747,y:741,t:1527027277009};\\\", \\\"{x:745,y:741,t:1527027277024};\\\", \\\"{x:746,y:741,t:1527027277897};\\\", \\\"{x:747,y:741,t:1527027277911};\\\", \\\"{x:750,y:740,t:1527027277928};\\\", \\\"{x:752,y:739,t:1527027277944};\\\", \\\"{x:754,y:738,t:1527027277961};\\\", \\\"{x:756,y:738,t:1527027277992};\\\", \\\"{x:756,y:739,t:1527027278041};\\\", \\\"{x:755,y:740,t:1527027278265};\\\", \\\"{x:755,y:741,t:1527027278496};\\\", \\\"{x:756,y:742,t:1527027278664};\\\", \\\"{x:756,y:743,t:1527027278768};\\\", \\\"{x:756,y:741,t:1527027279025};\\\", \\\"{x:756,y:740,t:1527027279049};\\\", \\\"{x:756,y:736,t:1527027279064};\\\", \\\"{x:757,y:736,t:1527027279078};\\\", \\\"{x:758,y:734,t:1527027279095};\\\", \\\"{x:763,y:728,t:1527027279112};\\\", \\\"{x:767,y:722,t:1527027279128};\\\", \\\"{x:771,y:717,t:1527027279145};\\\", \\\"{x:776,y:712,t:1527027279162};\\\", \\\"{x:783,y:704,t:1527027279178};\\\", \\\"{x:788,y:701,t:1527027279195};\\\", \\\"{x:792,y:699,t:1527027279212};\\\", \\\"{x:793,y:698,t:1527027279228};\\\", \\\"{x:795,y:697,t:1527027279245};\\\", \\\"{x:795,y:698,t:1527027279321};\\\", \\\"{x:794,y:699,t:1527027279328};\\\", \\\"{x:791,y:700,t:1527027279345};\\\", \\\"{x:790,y:701,t:1527027279368};\\\", \\\"{x:789,y:701,t:1527027279378};\\\", \\\"{x:788,y:701,t:1527027279395};\\\", \\\"{x:786,y:702,t:1527027279856};\\\", \\\"{x:785,y:702,t:1527027279864};\\\", \\\"{x:783,y:703,t:1527027279879};\\\", \\\"{x:781,y:704,t:1527027279895};\\\", \\\"{x:778,y:705,t:1527027279912};\\\", \\\"{x:776,y:705,t:1527027279928};\\\", \\\"{x:775,y:705,t:1527027279945};\\\", \\\"{x:774,y:705,t:1527027279969};\\\", \\\"{x:773,y:705,t:1527027279984};\\\", \\\"{x:772,y:706,t:1527027280121};\\\", \\\"{x:771,y:707,t:1527027280136};\\\", \\\"{x:770,y:707,t:1527027280161};\\\", \\\"{x:769,y:707,t:1527027280169};\\\", \\\"{x:768,y:708,t:1527027280192};\\\", \\\"{x:767,y:708,t:1527027280208};\\\", \\\"{x:765,y:709,t:1527027280216};\\\", \\\"{x:764,y:710,t:1527027280232};\\\", \\\"{x:763,y:710,t:1527027280246};\\\", \\\"{x:760,y:711,t:1527027280263};\\\", \\\"{x:755,y:711,t:1527027280279};\\\", \\\"{x:748,y:714,t:1527027280297};\\\", \\\"{x:745,y:714,t:1527027280312};\\\", \\\"{x:742,y:714,t:1527027280329};\\\", \\\"{x:740,y:714,t:1527027280346};\\\", \\\"{x:738,y:714,t:1527027280362};\\\", \\\"{x:735,y:715,t:1527027280379};\\\", \\\"{x:732,y:716,t:1527027280396};\\\", \\\"{x:731,y:716,t:1527027280412};\\\", \\\"{x:729,y:716,t:1527027280429};\\\", \\\"{x:728,y:716,t:1527027280446};\\\", \\\"{x:727,y:717,t:1527027280464};\\\", \\\"{x:724,y:718,t:1527027280480};\\\", \\\"{x:721,y:719,t:1527027280496};\\\", \\\"{x:715,y:720,t:1527027280513};\\\", \\\"{x:711,y:721,t:1527027280529};\\\", \\\"{x:708,y:722,t:1527027280546};\\\", \\\"{x:707,y:722,t:1527027280563};\\\", \\\"{x:706,y:722,t:1527027280579};\\\", \\\"{x:707,y:723,t:1527027281136};\\\", \\\"{x:712,y:726,t:1527027281146};\\\", \\\"{x:725,y:731,t:1527027281163};\\\", \\\"{x:738,y:734,t:1527027281180};\\\", \\\"{x:759,y:741,t:1527027281196};\\\", \\\"{x:788,y:748,t:1527027281213};\\\", \\\"{x:831,y:761,t:1527027281230};\\\", \\\"{x:876,y:776,t:1527027281246};\\\", \\\"{x:934,y:791,t:1527027281263};\\\", \\\"{x:1016,y:809,t:1527027281281};\\\", \\\"{x:1064,y:816,t:1527027281296};\\\", \\\"{x:1117,y:824,t:1527027281313};\\\", \\\"{x:1162,y:830,t:1527027281330};\\\", \\\"{x:1211,y:834,t:1527027281349};\\\", \\\"{x:1254,y:838,t:1527027281364};\\\", \\\"{x:1290,y:840,t:1527027281380};\\\", \\\"{x:1315,y:840,t:1527027281397};\\\", \\\"{x:1334,y:840,t:1527027281413};\\\", \\\"{x:1346,y:840,t:1527027281430};\\\", \\\"{x:1358,y:840,t:1527027281447};\\\", \\\"{x:1366,y:840,t:1527027281463};\\\", \\\"{x:1379,y:841,t:1527027281480};\\\", \\\"{x:1387,y:841,t:1527027281497};\\\", \\\"{x:1391,y:841,t:1527027281513};\\\", \\\"{x:1395,y:841,t:1527027281530};\\\", \\\"{x:1400,y:839,t:1527027281547};\\\", \\\"{x:1406,y:837,t:1527027281563};\\\", \\\"{x:1411,y:834,t:1527027281580};\\\", \\\"{x:1420,y:829,t:1527027281597};\\\", \\\"{x:1429,y:827,t:1527027281614};\\\", \\\"{x:1434,y:826,t:1527027281630};\\\", \\\"{x:1436,y:825,t:1527027281647};\\\", \\\"{x:1438,y:825,t:1527027281663};\\\", \\\"{x:1441,y:823,t:1527027281681};\\\", \\\"{x:1442,y:822,t:1527027281697};\\\", \\\"{x:1444,y:822,t:1527027281714};\\\", \\\"{x:1444,y:821,t:1527027281824};\\\", \\\"{x:1445,y:820,t:1527027281840};\\\", \\\"{x:1447,y:819,t:1527027281849};\\\", \\\"{x:1448,y:818,t:1527027281865};\\\", \\\"{x:1450,y:818,t:1527027281881};\\\", \\\"{x:1451,y:816,t:1527027281898};\\\", \\\"{x:1452,y:816,t:1527027281915};\\\", \\\"{x:1453,y:816,t:1527027281931};\\\", \\\"{x:1453,y:815,t:1527027281947};\\\", \\\"{x:1454,y:814,t:1527027281965};\\\", \\\"{x:1455,y:814,t:1527027282017};\\\", \\\"{x:1455,y:813,t:1527027282031};\\\", \\\"{x:1457,y:812,t:1527027282048};\\\", \\\"{x:1459,y:810,t:1527027282064};\\\", \\\"{x:1460,y:809,t:1527027282088};\\\", \\\"{x:1461,y:808,t:1527027282097};\\\", \\\"{x:1462,y:808,t:1527027282115};\\\", \\\"{x:1463,y:806,t:1527027282130};\\\", \\\"{x:1464,y:806,t:1527027282148};\\\", \\\"{x:1465,y:805,t:1527027282165};\\\", \\\"{x:1466,y:804,t:1527027282180};\\\", \\\"{x:1467,y:802,t:1527027282198};\\\", \\\"{x:1469,y:800,t:1527027282214};\\\", \\\"{x:1471,y:799,t:1527027282230};\\\", \\\"{x:1472,y:798,t:1527027282248};\\\", \\\"{x:1473,y:797,t:1527027282273};\\\", \\\"{x:1474,y:797,t:1527027282337};\\\", \\\"{x:1475,y:796,t:1527027282352};\\\", \\\"{x:1476,y:796,t:1527027282378};\\\", \\\"{x:1477,y:796,t:1527027282417};\\\", \\\"{x:1478,y:796,t:1527027282432};\\\", \\\"{x:1479,y:795,t:1527027282448};\\\", \\\"{x:1480,y:793,t:1527027282601};\\\", \\\"{x:1482,y:789,t:1527027282615};\\\", \\\"{x:1487,y:777,t:1527027282631};\\\", \\\"{x:1491,y:768,t:1527027282648};\\\", \\\"{x:1494,y:753,t:1527027282664};\\\", \\\"{x:1496,y:744,t:1527027282681};\\\", \\\"{x:1498,y:737,t:1527027282698};\\\", \\\"{x:1501,y:730,t:1527027282714};\\\", \\\"{x:1501,y:726,t:1527027282731};\\\", \\\"{x:1502,y:724,t:1527027282748};\\\", \\\"{x:1503,y:723,t:1527027282832};\\\", \\\"{x:1505,y:725,t:1527027282985};\\\", \\\"{x:1507,y:728,t:1527027282998};\\\", \\\"{x:1514,y:734,t:1527027283015};\\\", \\\"{x:1523,y:742,t:1527027283032};\\\", \\\"{x:1540,y:757,t:1527027283048};\\\", \\\"{x:1550,y:766,t:1527027283065};\\\", \\\"{x:1560,y:777,t:1527027283082};\\\", \\\"{x:1567,y:784,t:1527027283099};\\\", \\\"{x:1574,y:791,t:1527027283114};\\\", \\\"{x:1582,y:796,t:1527027283132};\\\", \\\"{x:1587,y:801,t:1527027283148};\\\", \\\"{x:1590,y:802,t:1527027283164};\\\", \\\"{x:1592,y:804,t:1527027283181};\\\", \\\"{x:1593,y:805,t:1527027283199};\\\", \\\"{x:1599,y:807,t:1527027284113};\\\", \\\"{x:1608,y:808,t:1527027284120};\\\", \\\"{x:1617,y:808,t:1527027284133};\\\", \\\"{x:1638,y:808,t:1527027284149};\\\", \\\"{x:1658,y:802,t:1527027284166};\\\", \\\"{x:1689,y:789,t:1527027284183};\\\", \\\"{x:1742,y:764,t:1527027284198};\\\", \\\"{x:1770,y:746,t:1527027284216};\\\", \\\"{x:1783,y:734,t:1527027284233};\\\", \\\"{x:1785,y:730,t:1527027284249};\\\", \\\"{x:1785,y:728,t:1527027284265};\\\", \\\"{x:1785,y:725,t:1527027284282};\\\", \\\"{x:1773,y:717,t:1527027284299};\\\", \\\"{x:1757,y:708,t:1527027284315};\\\", \\\"{x:1736,y:698,t:1527027284333};\\\", \\\"{x:1713,y:692,t:1527027284350};\\\", \\\"{x:1688,y:685,t:1527027284365};\\\", \\\"{x:1664,y:680,t:1527027284382};\\\", \\\"{x:1644,y:677,t:1527027284400};\\\", \\\"{x:1630,y:676,t:1527027284416};\\\", \\\"{x:1620,y:676,t:1527027284433};\\\", \\\"{x:1619,y:676,t:1527027284450};\\\", \\\"{x:1618,y:677,t:1527027284505};\\\", \\\"{x:1618,y:680,t:1527027284516};\\\", \\\"{x:1619,y:684,t:1527027284533};\\\", \\\"{x:1619,y:686,t:1527027284550};\\\", \\\"{x:1619,y:687,t:1527027284566};\\\", \\\"{x:1620,y:688,t:1527027284583};\\\", \\\"{x:1621,y:688,t:1527027284599};\\\", \\\"{x:1621,y:689,t:1527027284617};\\\", \\\"{x:1621,y:690,t:1527027284705};\\\", \\\"{x:1620,y:690,t:1527027284769};\\\", \\\"{x:1619,y:690,t:1527027284782};\\\", \\\"{x:1618,y:690,t:1527027284800};\\\", \\\"{x:1617,y:690,t:1527027284816};\\\", \\\"{x:1616,y:690,t:1527027284833};\\\", \\\"{x:1614,y:690,t:1527027284849};\\\", \\\"{x:1612,y:690,t:1527027284867};\\\", \\\"{x:1612,y:691,t:1527027284882};\\\", \\\"{x:1618,y:689,t:1527027288666};\\\", \\\"{x:1630,y:682,t:1527027288673};\\\", \\\"{x:1636,y:678,t:1527027288686};\\\", \\\"{x:1641,y:672,t:1527027288703};\\\", \\\"{x:1636,y:664,t:1527027288719};\\\", \\\"{x:1591,y:648,t:1527027288736};\\\", \\\"{x:1464,y:612,t:1527027288752};\\\", \\\"{x:1361,y:596,t:1527027288769};\\\", \\\"{x:1269,y:585,t:1527027288785};\\\", \\\"{x:1210,y:575,t:1527027288803};\\\", \\\"{x:1164,y:565,t:1527027288819};\\\", \\\"{x:1143,y:556,t:1527027288836};\\\", \\\"{x:1131,y:546,t:1527027288852};\\\", \\\"{x:1130,y:545,t:1527027288869};\\\", \\\"{x:1129,y:544,t:1527027288886};\\\", \\\"{x:1128,y:544,t:1527027288904};\\\", \\\"{x:1123,y:544,t:1527027288918};\\\", \\\"{x:1110,y:548,t:1527027288935};\\\", \\\"{x:1084,y:550,t:1527027288953};\\\", \\\"{x:1062,y:550,t:1527027288969};\\\", \\\"{x:1030,y:550,t:1527027288986};\\\", \\\"{x:996,y:550,t:1527027289003};\\\", \\\"{x:963,y:547,t:1527027289019};\\\", \\\"{x:935,y:541,t:1527027289037};\\\", \\\"{x:922,y:536,t:1527027289052};\\\", \\\"{x:915,y:535,t:1527027289069};\\\", \\\"{x:910,y:532,t:1527027289085};\\\", \\\"{x:908,y:531,t:1527027289103};\\\", \\\"{x:904,y:529,t:1527027289119};\\\", \\\"{x:893,y:527,t:1527027289136};\\\", \\\"{x:882,y:524,t:1527027289153};\\\", \\\"{x:871,y:519,t:1527027289170};\\\", \\\"{x:860,y:514,t:1527027289187};\\\", \\\"{x:854,y:512,t:1527027289203};\\\", \\\"{x:852,y:510,t:1527027289221};\\\", \\\"{x:851,y:509,t:1527027289236};\\\", \\\"{x:850,y:507,t:1527027289253};\\\", \\\"{x:849,y:504,t:1527027289270};\\\", \\\"{x:847,y:503,t:1527027289286};\\\", \\\"{x:847,y:502,t:1527027289304};\\\", \\\"{x:851,y:504,t:1527027289560};\\\", \\\"{x:881,y:529,t:1527027289570};\\\", \\\"{x:1008,y:617,t:1527027289588};\\\", \\\"{x:1162,y:708,t:1527027289603};\\\", \\\"{x:1307,y:786,t:1527027289620};\\\", \\\"{x:1418,y:838,t:1527027289637};\\\", \\\"{x:1474,y:864,t:1527027289654};\\\", \\\"{x:1496,y:874,t:1527027289670};\\\", \\\"{x:1499,y:875,t:1527027289687};\\\", \\\"{x:1499,y:874,t:1527027289849};\\\", \\\"{x:1493,y:870,t:1527027289856};\\\", \\\"{x:1488,y:866,t:1527027289871};\\\", \\\"{x:1477,y:857,t:1527027289888};\\\", \\\"{x:1472,y:850,t:1527027289904};\\\", \\\"{x:1469,y:850,t:1527027289928};\\\", \\\"{x:1467,y:850,t:1527027289938};\\\", \\\"{x:1463,y:850,t:1527027289954};\\\", \\\"{x:1461,y:850,t:1527027289970};\\\", \\\"{x:1460,y:850,t:1527027289988};\\\", \\\"{x:1456,y:851,t:1527027291425};\\\", \\\"{x:1455,y:851,t:1527027292097};\\\", \\\"{x:1453,y:852,t:1527027292106};\\\", \\\"{x:1454,y:852,t:1527027294985};\\\", \\\"{x:1457,y:852,t:1527027294992};\\\", \\\"{x:1462,y:851,t:1527027295008};\\\", \\\"{x:1470,y:848,t:1527027295025};\\\", \\\"{x:1486,y:841,t:1527027295041};\\\", \\\"{x:1501,y:839,t:1527027295057};\\\", \\\"{x:1524,y:839,t:1527027295074};\\\", \\\"{x:1549,y:839,t:1527027295090};\\\", \\\"{x:1568,y:839,t:1527027295107};\\\", \\\"{x:1581,y:835,t:1527027295124};\\\", \\\"{x:1589,y:835,t:1527027295140};\\\", \\\"{x:1594,y:834,t:1527027295158};\\\", \\\"{x:1595,y:833,t:1527027295257};\\\", \\\"{x:1598,y:832,t:1527027295275};\\\", \\\"{x:1603,y:827,t:1527027295291};\\\", \\\"{x:1606,y:823,t:1527027295308};\\\", \\\"{x:1610,y:816,t:1527027295325};\\\", \\\"{x:1613,y:810,t:1527027295342};\\\", \\\"{x:1617,y:805,t:1527027295358};\\\", \\\"{x:1621,y:802,t:1527027295375};\\\", \\\"{x:1623,y:802,t:1527027295392};\\\", \\\"{x:1624,y:802,t:1527027295408};\\\", \\\"{x:1627,y:804,t:1527027295425};\\\", \\\"{x:1631,y:813,t:1527027295442};\\\", \\\"{x:1634,y:827,t:1527027295458};\\\", \\\"{x:1639,y:841,t:1527027295475};\\\", \\\"{x:1643,y:852,t:1527027295492};\\\", \\\"{x:1646,y:859,t:1527027295508};\\\", \\\"{x:1646,y:861,t:1527027295525};\\\", \\\"{x:1646,y:862,t:1527027295542};\\\", \\\"{x:1645,y:861,t:1527027295624};\\\", \\\"{x:1643,y:859,t:1527027295631};\\\", \\\"{x:1641,y:857,t:1527027295641};\\\", \\\"{x:1637,y:853,t:1527027295657};\\\", \\\"{x:1633,y:850,t:1527027295674};\\\", \\\"{x:1630,y:847,t:1527027295691};\\\", \\\"{x:1628,y:847,t:1527027295708};\\\", \\\"{x:1627,y:847,t:1527027295881};\\\", \\\"{x:1625,y:847,t:1527027295892};\\\", \\\"{x:1624,y:847,t:1527027295909};\\\", \\\"{x:1622,y:847,t:1527027295925};\\\", \\\"{x:1620,y:847,t:1527027295942};\\\", \\\"{x:1617,y:854,t:1527027295959};\\\", \\\"{x:1612,y:863,t:1527027295975};\\\", \\\"{x:1609,y:876,t:1527027295992};\\\", \\\"{x:1604,y:888,t:1527027296008};\\\", \\\"{x:1595,y:902,t:1527027296025};\\\", \\\"{x:1583,y:918,t:1527027296042};\\\", \\\"{x:1576,y:929,t:1527027296058};\\\", \\\"{x:1573,y:932,t:1527027296075};\\\", \\\"{x:1573,y:933,t:1527027296092};\\\", \\\"{x:1572,y:933,t:1527027296145};\\\", \\\"{x:1572,y:931,t:1527027296159};\\\", \\\"{x:1568,y:923,t:1527027296175};\\\", \\\"{x:1559,y:908,t:1527027296193};\\\", \\\"{x:1553,y:899,t:1527027296209};\\\", \\\"{x:1549,y:895,t:1527027296225};\\\", \\\"{x:1546,y:890,t:1527027296242};\\\", \\\"{x:1543,y:886,t:1527027296260};\\\", \\\"{x:1539,y:882,t:1527027296275};\\\", \\\"{x:1536,y:878,t:1527027296292};\\\", \\\"{x:1531,y:874,t:1527027296309};\\\", \\\"{x:1527,y:871,t:1527027296327};\\\", \\\"{x:1523,y:868,t:1527027296342};\\\", \\\"{x:1519,y:866,t:1527027296359};\\\", \\\"{x:1516,y:865,t:1527027296378};\\\", \\\"{x:1515,y:864,t:1527027296392};\\\", \\\"{x:1513,y:863,t:1527027296409};\\\", \\\"{x:1511,y:859,t:1527027296426};\\\", \\\"{x:1505,y:854,t:1527027296442};\\\", \\\"{x:1503,y:852,t:1527027296459};\\\", \\\"{x:1500,y:850,t:1527027296476};\\\", \\\"{x:1499,y:850,t:1527027296492};\\\", \\\"{x:1497,y:849,t:1527027296510};\\\", \\\"{x:1491,y:846,t:1527027296526};\\\", \\\"{x:1474,y:844,t:1527027296542};\\\", \\\"{x:1435,y:838,t:1527027296560};\\\", \\\"{x:1325,y:810,t:1527027296577};\\\", \\\"{x:1240,y:792,t:1527027296592};\\\", \\\"{x:1159,y:779,t:1527027296609};\\\", \\\"{x:1100,y:771,t:1527027296626};\\\", \\\"{x:1058,y:764,t:1527027296642};\\\", \\\"{x:1028,y:759,t:1527027296661};\\\", \\\"{x:1015,y:755,t:1527027296675};\\\", \\\"{x:1011,y:753,t:1527027296691};\\\", \\\"{x:1011,y:752,t:1527027296752};\\\", \\\"{x:1010,y:749,t:1527027296760};\\\", \\\"{x:992,y:735,t:1527027296776};\\\", \\\"{x:965,y:721,t:1527027296793};\\\", \\\"{x:943,y:708,t:1527027296808};\\\", \\\"{x:922,y:694,t:1527027296826};\\\", \\\"{x:890,y:674,t:1527027296842};\\\", \\\"{x:855,y:654,t:1527027296858};\\\", \\\"{x:819,y:633,t:1527027296875};\\\", \\\"{x:784,y:611,t:1527027296893};\\\", \\\"{x:759,y:596,t:1527027296908};\\\", \\\"{x:739,y:584,t:1527027296926};\\\", \\\"{x:724,y:575,t:1527027296942};\\\", \\\"{x:715,y:569,t:1527027296960};\\\", \\\"{x:713,y:569,t:1527027296977};\\\", \\\"{x:709,y:567,t:1527027296992};\\\", \\\"{x:705,y:567,t:1527027297009};\\\", \\\"{x:698,y:566,t:1527027297025};\\\", \\\"{x:686,y:566,t:1527027297042};\\\", \\\"{x:675,y:566,t:1527027297060};\\\", \\\"{x:667,y:566,t:1527027297077};\\\", \\\"{x:655,y:563,t:1527027297092};\\\", \\\"{x:648,y:562,t:1527027297110};\\\", \\\"{x:642,y:561,t:1527027297127};\\\", \\\"{x:640,y:560,t:1527027297143};\\\", \\\"{x:639,y:560,t:1527027297168};\\\", \\\"{x:638,y:560,t:1527027297191};\\\", \\\"{x:636,y:560,t:1527027297199};\\\", \\\"{x:635,y:560,t:1527027297210};\\\", \\\"{x:631,y:562,t:1527027297226};\\\", \\\"{x:627,y:565,t:1527027297244};\\\", \\\"{x:623,y:568,t:1527027297261};\\\", \\\"{x:620,y:573,t:1527027297277};\\\", \\\"{x:617,y:576,t:1527027297293};\\\", \\\"{x:614,y:578,t:1527027297309};\\\", \\\"{x:613,y:578,t:1527027297326};\\\", \\\"{x:612,y:581,t:1527027297640};\\\", \\\"{x:612,y:596,t:1527027297648};\\\", \\\"{x:612,y:610,t:1527027297660};\\\", \\\"{x:612,y:630,t:1527027297677};\\\", \\\"{x:610,y:644,t:1527027297694};\\\", \\\"{x:609,y:652,t:1527027297709};\\\", \\\"{x:609,y:660,t:1527027297726};\\\", \\\"{x:609,y:667,t:1527027297743};\\\", \\\"{x:608,y:671,t:1527027297760};\\\", \\\"{x:608,y:674,t:1527027297776};\\\", \\\"{x:606,y:677,t:1527027297793};\\\", \\\"{x:605,y:678,t:1527027297810};\\\", \\\"{x:602,y:682,t:1527027297826};\\\", \\\"{x:599,y:687,t:1527027297843};\\\", \\\"{x:597,y:690,t:1527027297860};\\\", \\\"{x:590,y:696,t:1527027297877};\\\", \\\"{x:588,y:699,t:1527027297894};\\\", \\\"{x:583,y:703,t:1527027297911};\\\", \\\"{x:579,y:704,t:1527027297927};\\\", \\\"{x:576,y:707,t:1527027297944};\\\", \\\"{x:573,y:707,t:1527027297960};\\\", \\\"{x:571,y:710,t:1527027297979};\\\", \\\"{x:568,y:711,t:1527027297994};\\\", \\\"{x:565,y:712,t:1527027298011};\\\", \\\"{x:557,y:713,t:1527027298027};\\\", \\\"{x:547,y:714,t:1527027298043};\\\", \\\"{x:535,y:715,t:1527027298061};\\\", \\\"{x:526,y:717,t:1527027298077};\\\", \\\"{x:519,y:717,t:1527027298094};\\\", \\\"{x:513,y:717,t:1527027298111};\\\", \\\"{x:510,y:717,t:1527027298126};\\\", \\\"{x:505,y:717,t:1527027298144};\\\", \\\"{x:503,y:717,t:1527027298160};\\\", \\\"{x:502,y:717,t:1527027298183};\\\", \\\"{x:501,y:717,t:1527027298224};\\\", \\\"{x:501,y:721,t:1527027298914};\\\", \\\"{x:502,y:730,t:1527027298928};\\\", \\\"{x:503,y:734,t:1527027298945};\\\", \\\"{x:503,y:736,t:1527027298960};\\\", \\\"{x:503,y:737,t:1527027298977};\\\", \\\"{x:504,y:740,t:1527027298995};\\\", \\\"{x:507,y:747,t:1527027299440};\\\", \\\"{x:519,y:754,t:1527027299447};\\\", \\\"{x:538,y:766,t:1527027299461};\\\", \\\"{x:581,y:789,t:1527027299478};\\\", \\\"{x:641,y:811,t:1527027299494};\\\", \\\"{x:721,y:832,t:1527027299511};\\\", \\\"{x:776,y:839,t:1527027299529};\\\", \\\"{x:804,y:839,t:1527027299545};\\\", \\\"{x:827,y:831,t:1527027299561};\\\", \\\"{x:843,y:823,t:1527027299578};\\\", \\\"{x:854,y:815,t:1527027299595};\\\", \\\"{x:864,y:807,t:1527027299611};\\\", \\\"{x:869,y:800,t:1527027299628};\\\", \\\"{x:869,y:795,t:1527027299645};\\\", \\\"{x:869,y:790,t:1527027299661};\\\", \\\"{x:869,y:782,t:1527027299679};\\\", \\\"{x:867,y:771,t:1527027299694};\\\", \\\"{x:857,y:749,t:1527027299711};\\\", \\\"{x:855,y:735,t:1527027299728};\\\", \\\"{x:850,y:720,t:1527027299744};\\\", \\\"{x:846,y:703,t:1527027299761};\\\", \\\"{x:845,y:689,t:1527027299779};\\\", \\\"{x:844,y:673,t:1527027299795};\\\", \\\"{x:842,y:657,t:1527027299811};\\\", \\\"{x:842,y:642,t:1527027299829};\\\", \\\"{x:842,y:623,t:1527027299844};\\\", \\\"{x:842,y:604,t:1527027299862};\\\", \\\"{x:839,y:584,t:1527027299879};\\\", \\\"{x:828,y:557,t:1527027299895};\\\", \\\"{x:819,y:542,t:1527027299912};\\\", \\\"{x:817,y:536,t:1527027299929};\\\", \\\"{x:815,y:534,t:1527027299946};\\\", \\\"{x:814,y:531,t:1527027299962};\\\", \\\"{x:811,y:528,t:1527027299978};\\\", \\\"{x:808,y:525,t:1527027299996};\\\", \\\"{x:805,y:523,t:1527027300012};\\\", \\\"{x:804,y:522,t:1527027300032};\\\" ] }, { \\\"rt\\\": 35897, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 669713, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:803,y:522,t:1527027300560};\\\", \\\"{x:802,y:521,t:1527027300576};\\\", \\\"{x:801,y:521,t:1527027300584};\\\", \\\"{x:800,y:521,t:1527027300607};\\\", \\\"{x:799,y:521,t:1527027300615};\\\", \\\"{x:798,y:521,t:1527027300639};\\\", \\\"{x:797,y:521,t:1527027300648};\\\", \\\"{x:796,y:521,t:1527027300671};\\\", \\\"{x:795,y:521,t:1527027300688};\\\", \\\"{x:793,y:521,t:1527027300704};\\\", \\\"{x:792,y:521,t:1527027300713};\\\", \\\"{x:782,y:523,t:1527027300814};\\\", \\\"{x:776,y:525,t:1527027300831};\\\", \\\"{x:772,y:527,t:1527027300845};\\\", \\\"{x:765,y:527,t:1527027300862};\\\", \\\"{x:760,y:527,t:1527027300878};\\\", \\\"{x:747,y:527,t:1527027300895};\\\", \\\"{x:739,y:527,t:1527027300912};\\\", \\\"{x:725,y:527,t:1527027300928};\\\", \\\"{x:708,y:527,t:1527027300946};\\\", \\\"{x:694,y:527,t:1527027300962};\\\", \\\"{x:680,y:527,t:1527027300979};\\\", \\\"{x:665,y:527,t:1527027300996};\\\", \\\"{x:654,y:527,t:1527027301013};\\\", \\\"{x:646,y:527,t:1527027301029};\\\", \\\"{x:641,y:525,t:1527027301046};\\\", \\\"{x:638,y:523,t:1527027301064};\\\", \\\"{x:637,y:522,t:1527027301080};\\\", \\\"{x:635,y:520,t:1527027301095};\\\", \\\"{x:634,y:511,t:1527027301113};\\\", \\\"{x:630,y:499,t:1527027301130};\\\", \\\"{x:626,y:486,t:1527027301146};\\\", \\\"{x:621,y:471,t:1527027301162};\\\", \\\"{x:613,y:455,t:1527027301179};\\\", \\\"{x:607,y:438,t:1527027301196};\\\", \\\"{x:601,y:425,t:1527027301213};\\\", \\\"{x:600,y:417,t:1527027301229};\\\", \\\"{x:600,y:414,t:1527027301246};\\\", \\\"{x:599,y:409,t:1527027301263};\\\", \\\"{x:598,y:405,t:1527027301279};\\\", \\\"{x:598,y:402,t:1527027301296};\\\", \\\"{x:597,y:399,t:1527027301312};\\\", \\\"{x:596,y:396,t:1527027301330};\\\", \\\"{x:596,y:395,t:1527027301346};\\\", \\\"{x:596,y:393,t:1527027301363};\\\", \\\"{x:596,y:391,t:1527027301391};\\\", \\\"{x:595,y:391,t:1527027301408};\\\", \\\"{x:594,y:389,t:1527027301424};\\\", \\\"{x:593,y:389,t:1527027301440};\\\", \\\"{x:593,y:388,t:1527027301455};\\\", \\\"{x:592,y:388,t:1527027301464};\\\", \\\"{x:590,y:387,t:1527027301480};\\\", \\\"{x:589,y:386,t:1527027301497};\\\", \\\"{x:587,y:385,t:1527027301514};\\\", \\\"{x:584,y:384,t:1527027301531};\\\", \\\"{x:582,y:383,t:1527027301546};\\\", \\\"{x:580,y:382,t:1527027301564};\\\", \\\"{x:579,y:382,t:1527027301581};\\\", \\\"{x:577,y:381,t:1527027301597};\\\", \\\"{x:574,y:381,t:1527027301614};\\\", \\\"{x:570,y:380,t:1527027301631};\\\", \\\"{x:566,y:380,t:1527027301647};\\\", \\\"{x:559,y:380,t:1527027301664};\\\", \\\"{x:549,y:378,t:1527027301680};\\\", \\\"{x:543,y:378,t:1527027301697};\\\", \\\"{x:538,y:378,t:1527027301713};\\\", \\\"{x:533,y:378,t:1527027301730};\\\", \\\"{x:529,y:377,t:1527027301747};\\\", \\\"{x:526,y:377,t:1527027301763};\\\", \\\"{x:524,y:376,t:1527027301781};\\\", \\\"{x:522,y:376,t:1527027301797};\\\", \\\"{x:521,y:375,t:1527027301814};\\\", \\\"{x:519,y:375,t:1527027301831};\\\", \\\"{x:518,y:375,t:1527027301847};\\\", \\\"{x:516,y:375,t:1527027301863};\\\", \\\"{x:515,y:375,t:1527027301895};\\\", \\\"{x:513,y:375,t:1527027301935};\\\", \\\"{x:512,y:375,t:1527027301951};\\\", \\\"{x:510,y:374,t:1527027301983};\\\", \\\"{x:509,y:374,t:1527027302015};\\\", \\\"{x:507,y:374,t:1527027302039};\\\", \\\"{x:506,y:374,t:1527027302063};\\\", \\\"{x:504,y:374,t:1527027302079};\\\", \\\"{x:503,y:374,t:1527027302095};\\\", \\\"{x:501,y:374,t:1527027302103};\\\", \\\"{x:500,y:374,t:1527027302115};\\\", \\\"{x:497,y:374,t:1527027302132};\\\", \\\"{x:495,y:374,t:1527027302148};\\\", \\\"{x:493,y:374,t:1527027302165};\\\", \\\"{x:490,y:374,t:1527027302182};\\\", \\\"{x:487,y:374,t:1527027302198};\\\", \\\"{x:485,y:374,t:1527027302215};\\\", \\\"{x:482,y:374,t:1527027302232};\\\", \\\"{x:480,y:374,t:1527027302248};\\\", \\\"{x:478,y:374,t:1527027302265};\\\", \\\"{x:476,y:374,t:1527027302282};\\\", \\\"{x:471,y:375,t:1527027302299};\\\", \\\"{x:468,y:375,t:1527027302315};\\\", \\\"{x:464,y:376,t:1527027302331};\\\", \\\"{x:461,y:376,t:1527027302349};\\\", \\\"{x:457,y:377,t:1527027302365};\\\", \\\"{x:455,y:377,t:1527027302382};\\\", \\\"{x:454,y:378,t:1527027302399};\\\", \\\"{x:450,y:378,t:1527027302416};\\\", \\\"{x:448,y:379,t:1527027302432};\\\", \\\"{x:447,y:379,t:1527027302449};\\\", \\\"{x:445,y:379,t:1527027302466};\\\", \\\"{x:444,y:379,t:1527027302481};\\\", \\\"{x:442,y:380,t:1527027302499};\\\", \\\"{x:441,y:380,t:1527027302516};\\\", \\\"{x:439,y:380,t:1527027302531};\\\", \\\"{x:438,y:380,t:1527027302551};\\\", \\\"{x:437,y:380,t:1527027302575};\\\", \\\"{x:436,y:380,t:1527027302582};\\\", \\\"{x:435,y:380,t:1527027302599};\\\", \\\"{x:433,y:380,t:1527027302616};\\\", \\\"{x:432,y:380,t:1527027302632};\\\", \\\"{x:430,y:380,t:1527027302649};\\\", \\\"{x:429,y:380,t:1527027302666};\\\", \\\"{x:428,y:380,t:1527027302683};\\\", \\\"{x:427,y:380,t:1527027302699};\\\", \\\"{x:426,y:381,t:1527027302716};\\\", \\\"{x:425,y:381,t:1527027302733};\\\", \\\"{x:423,y:381,t:1527027302750};\\\", \\\"{x:422,y:382,t:1527027302766};\\\", \\\"{x:421,y:382,t:1527027302849};\\\", \\\"{x:420,y:382,t:1527027302864};\\\", \\\"{x:419,y:382,t:1527027302896};\\\", \\\"{x:417,y:383,t:1527027302904};\\\", \\\"{x:416,y:383,t:1527027302920};\\\", \\\"{x:414,y:383,t:1527027302933};\\\", \\\"{x:411,y:383,t:1527027302950};\\\", \\\"{x:409,y:383,t:1527027302968};\\\", \\\"{x:407,y:384,t:1527027302983};\\\", \\\"{x:405,y:384,t:1527027303000};\\\", \\\"{x:404,y:384,t:1527027303017};\\\", \\\"{x:403,y:384,t:1527027303048};\\\", \\\"{x:402,y:384,t:1527027303056};\\\", \\\"{x:401,y:384,t:1527027303067};\\\", \\\"{x:399,y:384,t:1527027303084};\\\", \\\"{x:394,y:385,t:1527027303100};\\\", \\\"{x:390,y:386,t:1527027303117};\\\", \\\"{x:381,y:387,t:1527027303134};\\\", \\\"{x:367,y:389,t:1527027303150};\\\", \\\"{x:358,y:392,t:1527027303167};\\\", \\\"{x:342,y:397,t:1527027303184};\\\", \\\"{x:334,y:398,t:1527027303200};\\\", \\\"{x:330,y:400,t:1527027303217};\\\", \\\"{x:327,y:401,t:1527027303234};\\\", \\\"{x:326,y:401,t:1527027303272};\\\", \\\"{x:325,y:401,t:1527027303312};\\\", \\\"{x:324,y:401,t:1527027303328};\\\", \\\"{x:323,y:401,t:1527027303336};\\\", \\\"{x:322,y:401,t:1527027303385};\\\", \\\"{x:321,y:401,t:1527027303401};\\\", \\\"{x:328,y:396,t:1527027303418};\\\", \\\"{x:343,y:392,t:1527027303434};\\\", \\\"{x:369,y:391,t:1527027303451};\\\", \\\"{x:396,y:391,t:1527027303468};\\\", \\\"{x:424,y:391,t:1527027303484};\\\", \\\"{x:456,y:391,t:1527027303501};\\\", \\\"{x:490,y:391,t:1527027303517};\\\", \\\"{x:523,y:391,t:1527027303535};\\\", \\\"{x:549,y:391,t:1527027303552};\\\", \\\"{x:573,y:391,t:1527027303568};\\\", \\\"{x:580,y:393,t:1527027303585};\\\", \\\"{x:585,y:395,t:1527027303602};\\\", \\\"{x:587,y:395,t:1527027303618};\\\", \\\"{x:588,y:395,t:1527027303648};\\\", \\\"{x:589,y:395,t:1527027303689};\\\", \\\"{x:590,y:395,t:1527027303745};\\\", \\\"{x:591,y:394,t:1527027304249};\\\", \\\"{x:590,y:394,t:1527027304408};\\\", \\\"{x:589,y:394,t:1527027304424};\\\", \\\"{x:588,y:394,t:1527027304528};\\\", \\\"{x:588,y:395,t:1527027304544};\\\", \\\"{x:587,y:395,t:1527027304568};\\\", \\\"{x:586,y:395,t:1527027305464};\\\", \\\"{x:585,y:395,t:1527027306456};\\\", \\\"{x:583,y:396,t:1527027306474};\\\", \\\"{x:581,y:396,t:1527027306816};\\\", \\\"{x:580,y:396,t:1527027306824};\\\", \\\"{x:576,y:396,t:1527027306841};\\\", \\\"{x:575,y:396,t:1527027306858};\\\", \\\"{x:574,y:396,t:1527027307272};\\\", \\\"{x:573,y:396,t:1527027307280};\\\", \\\"{x:570,y:396,t:1527027309769};\\\", \\\"{x:568,y:396,t:1527027309781};\\\", \\\"{x:566,y:396,t:1527027309797};\\\", \\\"{x:563,y:397,t:1527027309813};\\\", \\\"{x:557,y:404,t:1527027309831};\\\", \\\"{x:552,y:416,t:1527027309848};\\\", \\\"{x:547,y:419,t:1527027309864};\\\", \\\"{x:541,y:420,t:1527027309881};\\\", \\\"{x:534,y:421,t:1527027309898};\\\", \\\"{x:528,y:421,t:1527027309915};\\\", \\\"{x:527,y:421,t:1527027309968};\\\", \\\"{x:523,y:421,t:1527027310496};\\\", \\\"{x:520,y:421,t:1527027310504};\\\", \\\"{x:516,y:421,t:1527027310515};\\\", \\\"{x:513,y:421,t:1527027310531};\\\", \\\"{x:512,y:421,t:1527027310548};\\\", \\\"{x:509,y:421,t:1527027310565};\\\", \\\"{x:519,y:418,t:1527027319192};\\\", \\\"{x:556,y:412,t:1527027319199};\\\", \\\"{x:643,y:426,t:1527027319216};\\\", \\\"{x:707,y:445,t:1527027319233};\\\", \\\"{x:732,y:457,t:1527027319250};\\\", \\\"{x:738,y:460,t:1527027319266};\\\", \\\"{x:739,y:462,t:1527027319282};\\\", \\\"{x:739,y:466,t:1527027319300};\\\", \\\"{x:739,y:474,t:1527027319316};\\\", \\\"{x:735,y:490,t:1527027319334};\\\", \\\"{x:727,y:505,t:1527027319349};\\\", \\\"{x:716,y:524,t:1527027319365};\\\", \\\"{x:703,y:543,t:1527027319375};\\\", \\\"{x:690,y:558,t:1527027319392};\\\", \\\"{x:675,y:569,t:1527027319410};\\\", \\\"{x:662,y:576,t:1527027319427};\\\", \\\"{x:647,y:582,t:1527027319444};\\\", \\\"{x:639,y:585,t:1527027319461};\\\", \\\"{x:636,y:586,t:1527027319477};\\\", \\\"{x:635,y:586,t:1527027319551};\\\", \\\"{x:632,y:586,t:1527027319560};\\\", \\\"{x:623,y:581,t:1527027319577};\\\", \\\"{x:610,y:577,t:1527027319595};\\\", \\\"{x:598,y:575,t:1527027319611};\\\", \\\"{x:582,y:575,t:1527027319627};\\\", \\\"{x:564,y:575,t:1527027319644};\\\", \\\"{x:545,y:575,t:1527027319661};\\\", \\\"{x:522,y:575,t:1527027319678};\\\", \\\"{x:500,y:575,t:1527027319695};\\\", \\\"{x:463,y:572,t:1527027319712};\\\", \\\"{x:436,y:567,t:1527027319728};\\\", \\\"{x:403,y:557,t:1527027319745};\\\", \\\"{x:379,y:551,t:1527027319762};\\\", \\\"{x:354,y:543,t:1527027319777};\\\", \\\"{x:337,y:538,t:1527027319794};\\\", \\\"{x:328,y:536,t:1527027319811};\\\", \\\"{x:322,y:534,t:1527027319828};\\\", \\\"{x:320,y:533,t:1527027319844};\\\", \\\"{x:319,y:532,t:1527027319861};\\\", \\\"{x:318,y:530,t:1527027319878};\\\", \\\"{x:318,y:529,t:1527027319894};\\\", \\\"{x:320,y:524,t:1527027319911};\\\", \\\"{x:324,y:521,t:1527027319927};\\\", \\\"{x:327,y:517,t:1527027319945};\\\", \\\"{x:329,y:514,t:1527027319961};\\\", \\\"{x:333,y:512,t:1527027319978};\\\", \\\"{x:338,y:510,t:1527027319994};\\\", \\\"{x:340,y:508,t:1527027320011};\\\", \\\"{x:333,y:511,t:1527027320072};\\\", \\\"{x:327,y:515,t:1527027320079};\\\", \\\"{x:322,y:518,t:1527027320096};\\\", \\\"{x:302,y:530,t:1527027320111};\\\", \\\"{x:290,y:533,t:1527027320128};\\\", \\\"{x:275,y:534,t:1527027320144};\\\", \\\"{x:260,y:534,t:1527027320161};\\\", \\\"{x:250,y:534,t:1527027320177};\\\", \\\"{x:245,y:534,t:1527027320194};\\\", \\\"{x:242,y:534,t:1527027320211};\\\", \\\"{x:241,y:534,t:1527027320247};\\\", \\\"{x:240,y:534,t:1527027320262};\\\", \\\"{x:239,y:534,t:1527027320279};\\\", \\\"{x:233,y:534,t:1527027320295};\\\", \\\"{x:231,y:534,t:1527027320312};\\\", \\\"{x:229,y:534,t:1527027320328};\\\", \\\"{x:226,y:534,t:1527027320345};\\\", \\\"{x:219,y:534,t:1527027320362};\\\", \\\"{x:211,y:534,t:1527027320379};\\\", \\\"{x:201,y:535,t:1527027320395};\\\", \\\"{x:196,y:535,t:1527027320412};\\\", \\\"{x:192,y:536,t:1527027320429};\\\", \\\"{x:192,y:537,t:1527027320487};\\\", \\\"{x:191,y:537,t:1527027320503};\\\", \\\"{x:196,y:537,t:1527027320752};\\\", \\\"{x:226,y:545,t:1527027320761};\\\", \\\"{x:331,y:577,t:1527027320779};\\\", \\\"{x:451,y:620,t:1527027320796};\\\", \\\"{x:561,y:659,t:1527027320812};\\\", \\\"{x:650,y:690,t:1527027320829};\\\", \\\"{x:741,y:729,t:1527027320845};\\\", \\\"{x:853,y:771,t:1527027320861};\\\", \\\"{x:956,y:799,t:1527027320879};\\\", \\\"{x:1093,y:848,t:1527027320895};\\\", \\\"{x:1146,y:864,t:1527027320912};\\\", \\\"{x:1169,y:871,t:1527027320928};\\\", \\\"{x:1171,y:871,t:1527027320945};\\\", \\\"{x:1168,y:871,t:1527027321231};\\\", \\\"{x:1165,y:871,t:1527027321244};\\\", \\\"{x:1158,y:871,t:1527027321261};\\\", \\\"{x:1152,y:871,t:1527027321278};\\\", \\\"{x:1142,y:871,t:1527027321294};\\\", \\\"{x:1131,y:871,t:1527027321311};\\\", \\\"{x:1127,y:871,t:1527027321328};\\\", \\\"{x:1122,y:871,t:1527027321344};\\\", \\\"{x:1116,y:871,t:1527027321361};\\\", \\\"{x:1114,y:871,t:1527027321378};\\\", \\\"{x:1110,y:870,t:1527027321394};\\\", \\\"{x:1108,y:870,t:1527027321411};\\\", \\\"{x:1105,y:869,t:1527027321428};\\\", \\\"{x:1100,y:869,t:1527027321444};\\\", \\\"{x:1096,y:869,t:1527027321461};\\\", \\\"{x:1091,y:869,t:1527027321478};\\\", \\\"{x:1085,y:869,t:1527027321494};\\\", \\\"{x:1079,y:869,t:1527027321511};\\\", \\\"{x:1075,y:869,t:1527027321528};\\\", \\\"{x:1073,y:869,t:1527027321545};\\\", \\\"{x:1069,y:867,t:1527027321561};\\\", \\\"{x:1067,y:867,t:1527027321578};\\\", \\\"{x:1064,y:867,t:1527027321594};\\\", \\\"{x:1062,y:867,t:1527027321611};\\\", \\\"{x:1061,y:867,t:1527027321629};\\\", \\\"{x:1059,y:867,t:1527027321644};\\\", \\\"{x:1058,y:867,t:1527027321663};\\\", \\\"{x:1056,y:867,t:1527027321727};\\\", \\\"{x:1055,y:867,t:1527027321870};\\\", \\\"{x:1053,y:867,t:1527027322087};\\\", \\\"{x:1052,y:867,t:1527027322110};\\\", \\\"{x:1051,y:867,t:1527027322142};\\\", \\\"{x:1049,y:867,t:1527027329979};\\\", \\\"{x:1047,y:867,t:1527027329991};\\\", \\\"{x:1042,y:867,t:1527027330009};\\\", \\\"{x:1038,y:867,t:1527027330024};\\\", \\\"{x:1033,y:867,t:1527027330041};\\\", \\\"{x:1030,y:867,t:1527027330059};\\\", \\\"{x:1028,y:867,t:1527027330075};\\\", \\\"{x:1027,y:867,t:1527027330122};\\\", \\\"{x:1026,y:867,t:1527027330141};\\\", \\\"{x:1025,y:867,t:1527027330157};\\\", \\\"{x:1023,y:867,t:1527027330174};\\\", \\\"{x:1021,y:867,t:1527027330190};\\\", \\\"{x:1018,y:867,t:1527027330207};\\\", \\\"{x:1014,y:867,t:1527027330224};\\\", \\\"{x:1011,y:867,t:1527027330241};\\\", \\\"{x:1009,y:867,t:1527027330257};\\\", \\\"{x:1002,y:867,t:1527027330274};\\\", \\\"{x:996,y:867,t:1527027330291};\\\", \\\"{x:985,y:867,t:1527027330307};\\\", \\\"{x:974,y:867,t:1527027330324};\\\", \\\"{x:961,y:867,t:1527027330341};\\\", \\\"{x:953,y:868,t:1527027330357};\\\", \\\"{x:943,y:870,t:1527027330374};\\\", \\\"{x:940,y:870,t:1527027330391};\\\", \\\"{x:939,y:870,t:1527027330407};\\\", \\\"{x:939,y:871,t:1527027330424};\\\", \\\"{x:937,y:871,t:1527027332323};\\\", \\\"{x:936,y:871,t:1527027332339};\\\", \\\"{x:934,y:871,t:1527027332356};\\\", \\\"{x:932,y:871,t:1527027332373};\\\", \\\"{x:931,y:871,t:1527027334027};\\\", \\\"{x:930,y:871,t:1527027334037};\\\", \\\"{x:929,y:872,t:1527027334054};\\\", \\\"{x:928,y:872,t:1527027335019};\\\", \\\"{x:927,y:872,t:1527027335131};\\\", \\\"{x:926,y:872,t:1527027335226};\\\", \\\"{x:924,y:872,t:1527027335251};\\\", \\\"{x:923,y:872,t:1527027335259};\\\", \\\"{x:920,y:872,t:1527027335270};\\\", \\\"{x:907,y:872,t:1527027335286};\\\", \\\"{x:896,y:872,t:1527027335303};\\\", \\\"{x:884,y:872,t:1527027335320};\\\", \\\"{x:873,y:872,t:1527027335337};\\\", \\\"{x:866,y:872,t:1527027335353};\\\", \\\"{x:823,y:863,t:1527027335370};\\\", \\\"{x:781,y:856,t:1527027335387};\\\", \\\"{x:738,y:849,t:1527027335403};\\\", \\\"{x:695,y:840,t:1527027335420};\\\", \\\"{x:655,y:833,t:1527027335437};\\\", \\\"{x:627,y:827,t:1527027335453};\\\", \\\"{x:611,y:824,t:1527027335471};\\\", \\\"{x:607,y:821,t:1527027335486};\\\", \\\"{x:605,y:821,t:1527027335503};\\\", \\\"{x:604,y:819,t:1527027335522};\\\", \\\"{x:604,y:818,t:1527027335546};\\\", \\\"{x:602,y:815,t:1527027335554};\\\", \\\"{x:599,y:810,t:1527027335570};\\\", \\\"{x:584,y:794,t:1527027335587};\\\", \\\"{x:577,y:785,t:1527027335603};\\\", \\\"{x:571,y:780,t:1527027335620};\\\", \\\"{x:567,y:777,t:1527027335636};\\\", \\\"{x:563,y:773,t:1527027335654};\\\", \\\"{x:560,y:770,t:1527027335669};\\\", \\\"{x:558,y:768,t:1527027335687};\\\", \\\"{x:556,y:766,t:1527027335704};\\\", \\\"{x:553,y:762,t:1527027335719};\\\", \\\"{x:552,y:761,t:1527027335739};\\\", \\\"{x:552,y:760,t:1527027335753};\\\", \\\"{x:551,y:759,t:1527027335770};\\\", \\\"{x:550,y:759,t:1527027336019};\\\", \\\"{x:550,y:757,t:1527027336036};\\\", \\\"{x:550,y:756,t:1527027336053};\\\", \\\"{x:550,y:754,t:1527027336071};\\\", \\\"{x:549,y:753,t:1527027336086};\\\", \\\"{x:548,y:750,t:1527027336101};\\\", \\\"{x:546,y:747,t:1527027336127};\\\", \\\"{x:547,y:747,t:1527027336561};\\\", \\\"{x:548,y:747,t:1527027336586};\\\", \\\"{x:551,y:747,t:1527027336593};\\\", \\\"{x:573,y:756,t:1527027336611};\\\", \\\"{x:615,y:786,t:1527027336627};\\\", \\\"{x:676,y:814,t:1527027336643};\\\", \\\"{x:748,y:834,t:1527027336661};\\\", \\\"{x:836,y:857,t:1527027336677};\\\", \\\"{x:933,y:880,t:1527027336693};\\\", \\\"{x:1018,y:890,t:1527027336711};\\\", \\\"{x:1056,y:890,t:1527027336727};\\\", \\\"{x:1075,y:885,t:1527027336744};\\\", \\\"{x:1082,y:881,t:1527027336761};\\\", \\\"{x:1085,y:878,t:1527027336777};\\\", \\\"{x:1086,y:873,t:1527027336794};\\\", \\\"{x:1086,y:870,t:1527027336811};\\\", \\\"{x:1088,y:860,t:1527027336827};\\\", \\\"{x:1089,y:826,t:1527027336845};\\\", \\\"{x:1089,y:765,t:1527027336861};\\\", \\\"{x:1073,y:709,t:1527027336877};\\\", \\\"{x:1057,y:675,t:1527027336894};\\\", \\\"{x:1046,y:656,t:1527027336911};\\\", \\\"{x:1036,y:640,t:1527027336927};\\\", \\\"{x:1029,y:627,t:1527027336944};\\\", \\\"{x:1020,y:614,t:1527027336961};\\\", \\\"{x:1012,y:606,t:1527027336977};\\\", \\\"{x:1000,y:593,t:1527027336994};\\\", \\\"{x:990,y:583,t:1527027337012};\\\", \\\"{x:982,y:577,t:1527027337027};\\\", \\\"{x:973,y:570,t:1527027337044};\\\", \\\"{x:961,y:559,t:1527027337061};\\\", \\\"{x:946,y:549,t:1527027337077};\\\", \\\"{x:934,y:539,t:1527027337094};\\\", \\\"{x:927,y:535,t:1527027337111};\\\", \\\"{x:924,y:532,t:1527027337127};\\\", \\\"{x:919,y:529,t:1527027337144};\\\", \\\"{x:913,y:526,t:1527027337162};\\\", \\\"{x:911,y:525,t:1527027337178};\\\", \\\"{x:909,y:523,t:1527027337194};\\\", \\\"{x:908,y:522,t:1527027337212};\\\", \\\"{x:907,y:522,t:1527027337228};\\\", \\\"{x:905,y:521,t:1527027337244};\\\", \\\"{x:901,y:519,t:1527027337270};\\\", \\\"{x:900,y:518,t:1527027337282};\\\", \\\"{x:899,y:518,t:1527027337294};\\\", \\\"{x:898,y:517,t:1527027337310};\\\", \\\"{x:895,y:516,t:1527027337328};\\\", \\\"{x:893,y:515,t:1527027337345};\\\" ] }, { \\\"rt\\\": 49022, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 719962, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:884,y:512,t:1527027337464};\\\", \\\"{x:881,y:512,t:1527027337645};\\\", \\\"{x:873,y:519,t:1527027337662};\\\", \\\"{x:869,y:523,t:1527027337678};\\\", \\\"{x:864,y:528,t:1527027337695};\\\", \\\"{x:858,y:531,t:1527027337712};\\\", \\\"{x:854,y:535,t:1527027337728};\\\", \\\"{x:850,y:538,t:1527027337745};\\\", \\\"{x:846,y:549,t:1527027337762};\\\", \\\"{x:842,y:558,t:1527027337780};\\\", \\\"{x:842,y:568,t:1527027337795};\\\", \\\"{x:841,y:577,t:1527027337812};\\\", \\\"{x:841,y:584,t:1527027337829};\\\", \\\"{x:841,y:589,t:1527027337845};\\\", \\\"{x:841,y:590,t:1527027337862};\\\", \\\"{x:834,y:576,t:1527027338052};\\\", \\\"{x:829,y:562,t:1527027338067};\\\", \\\"{x:826,y:553,t:1527027338079};\\\", \\\"{x:816,y:535,t:1527027338096};\\\", \\\"{x:802,y:509,t:1527027338112};\\\", \\\"{x:786,y:486,t:1527027338130};\\\", \\\"{x:779,y:473,t:1527027338145};\\\", \\\"{x:766,y:451,t:1527027338162};\\\", \\\"{x:758,y:438,t:1527027338179};\\\", \\\"{x:751,y:427,t:1527027338196};\\\", \\\"{x:741,y:414,t:1527027338212};\\\", \\\"{x:734,y:403,t:1527027338229};\\\", \\\"{x:728,y:395,t:1527027338246};\\\", \\\"{x:725,y:391,t:1527027338262};\\\", \\\"{x:722,y:386,t:1527027338279};\\\", \\\"{x:720,y:381,t:1527027338296};\\\", \\\"{x:718,y:379,t:1527027338313};\\\", \\\"{x:718,y:377,t:1527027338579};\\\", \\\"{x:718,y:374,t:1527027338586};\\\", \\\"{x:718,y:371,t:1527027338596};\\\", \\\"{x:719,y:365,t:1527027338613};\\\", \\\"{x:720,y:360,t:1527027338630};\\\", \\\"{x:720,y:356,t:1527027338646};\\\", \\\"{x:720,y:353,t:1527027338663};\\\", \\\"{x:720,y:348,t:1527027338681};\\\", \\\"{x:720,y:342,t:1527027338697};\\\", \\\"{x:722,y:336,t:1527027338713};\\\", \\\"{x:723,y:330,t:1527027338730};\\\", \\\"{x:723,y:327,t:1527027338747};\\\", \\\"{x:723,y:325,t:1527027338764};\\\", \\\"{x:723,y:322,t:1527027338780};\\\", \\\"{x:723,y:321,t:1527027338802};\\\", \\\"{x:723,y:319,t:1527027338813};\\\", \\\"{x:724,y:312,t:1527027338830};\\\", \\\"{x:724,y:299,t:1527027338847};\\\", \\\"{x:726,y:291,t:1527027338864};\\\", \\\"{x:726,y:281,t:1527027338880};\\\", \\\"{x:727,y:274,t:1527027338898};\\\", \\\"{x:728,y:271,t:1527027338913};\\\", \\\"{x:728,y:266,t:1527027338931};\\\", \\\"{x:728,y:263,t:1527027338947};\\\", \\\"{x:728,y:261,t:1527027338964};\\\", \\\"{x:728,y:260,t:1527027338981};\\\", \\\"{x:728,y:258,t:1527027338998};\\\", \\\"{x:728,y:257,t:1527027339014};\\\", \\\"{x:728,y:255,t:1527027339031};\\\", \\\"{x:728,y:254,t:1527027339047};\\\", \\\"{x:727,y:253,t:1527027339064};\\\", \\\"{x:727,y:251,t:1527027339081};\\\", \\\"{x:727,y:250,t:1527027339098};\\\", \\\"{x:727,y:248,t:1527027339114};\\\", \\\"{x:727,y:245,t:1527027339131};\\\", \\\"{x:727,y:244,t:1527027339154};\\\", \\\"{x:727,y:243,t:1527027339178};\\\", \\\"{x:727,y:242,t:1527027339194};\\\", \\\"{x:727,y:241,t:1527027339554};\\\", \\\"{x:727,y:240,t:1527027339565};\\\", \\\"{x:727,y:239,t:1527027339582};\\\", \\\"{x:727,y:238,t:1527027339602};\\\", \\\"{x:728,y:238,t:1527027339642};\\\", \\\"{x:728,y:237,t:1527027339650};\\\", \\\"{x:729,y:237,t:1527027339666};\\\", \\\"{x:730,y:236,t:1527027339682};\\\", \\\"{x:731,y:236,t:1527027339714};\\\", \\\"{x:731,y:235,t:1527027339738};\\\", \\\"{x:732,y:234,t:1527027339749};\\\", \\\"{x:733,y:234,t:1527027339765};\\\", \\\"{x:733,y:233,t:1527027339802};\\\", \\\"{x:734,y:233,t:1527027340113};\\\", \\\"{x:734,y:232,t:1527027340162};\\\", \\\"{x:734,y:231,t:1527027340442};\\\", \\\"{x:733,y:231,t:1527027340450};\\\", \\\"{x:732,y:231,t:1527027340467};\\\", \\\"{x:731,y:231,t:1527027340489};\\\", \\\"{x:730,y:231,t:1527027340762};\\\", \\\"{x:729,y:231,t:1527027340786};\\\", \\\"{x:727,y:231,t:1527027340802};\\\", \\\"{x:726,y:232,t:1527027340818};\\\", \\\"{x:725,y:233,t:1527027340834};\\\", \\\"{x:727,y:233,t:1527027341115};\\\", \\\"{x:732,y:231,t:1527027341122};\\\", \\\"{x:737,y:227,t:1527027341135};\\\", \\\"{x:747,y:220,t:1527027341151};\\\", \\\"{x:756,y:213,t:1527027341169};\\\", \\\"{x:760,y:209,t:1527027341184};\\\", \\\"{x:763,y:208,t:1527027341201};\\\", \\\"{x:765,y:206,t:1527027341219};\\\", \\\"{x:764,y:206,t:1527027342243};\\\", \\\"{x:763,y:207,t:1527027343219};\\\", \\\"{x:762,y:207,t:1527027343250};\\\", \\\"{x:761,y:207,t:1527027343266};\\\", \\\"{x:760,y:207,t:1527027343282};\\\", \\\"{x:759,y:207,t:1527027343290};\\\", \\\"{x:757,y:208,t:1527027343306};\\\", \\\"{x:756,y:209,t:1527027343338};\\\", \\\"{x:755,y:209,t:1527027343643};\\\", \\\"{x:755,y:211,t:1527027343666};\\\", \\\"{x:756,y:213,t:1527027343674};\\\", \\\"{x:757,y:216,t:1527027343690};\\\", \\\"{x:766,y:234,t:1527027343706};\\\", \\\"{x:796,y:265,t:1527027343723};\\\", \\\"{x:837,y:334,t:1527027343739};\\\", \\\"{x:887,y:396,t:1527027343757};\\\", \\\"{x:923,y:408,t:1527027343774};\\\", \\\"{x:945,y:433,t:1527027343790};\\\", \\\"{x:950,y:439,t:1527027343807};\\\", \\\"{x:1043,y:483,t:1527027343824};\\\", \\\"{x:1095,y:517,t:1527027343840};\\\", \\\"{x:1131,y:544,t:1527027343857};\\\", \\\"{x:1160,y:578,t:1527027343874};\\\", \\\"{x:1206,y:633,t:1527027343890};\\\", \\\"{x:1265,y:714,t:1527027343907};\\\", \\\"{x:1288,y:747,t:1527027343924};\\\", \\\"{x:1300,y:765,t:1527027343941};\\\", \\\"{x:1304,y:774,t:1527027343957};\\\", \\\"{x:1309,y:785,t:1527027343974};\\\", \\\"{x:1313,y:794,t:1527027343991};\\\", \\\"{x:1314,y:800,t:1527027344007};\\\", \\\"{x:1316,y:806,t:1527027344024};\\\", \\\"{x:1318,y:812,t:1527027344041};\\\", \\\"{x:1319,y:815,t:1527027344057};\\\", \\\"{x:1321,y:819,t:1527027344074};\\\", \\\"{x:1329,y:834,t:1527027344091};\\\", \\\"{x:1341,y:856,t:1527027344107};\\\", \\\"{x:1354,y:878,t:1527027344124};\\\", \\\"{x:1366,y:899,t:1527027344141};\\\", \\\"{x:1371,y:913,t:1527027344158};\\\", \\\"{x:1376,y:926,t:1527027344174};\\\", \\\"{x:1383,y:940,t:1527027344191};\\\", \\\"{x:1388,y:952,t:1527027344208};\\\", \\\"{x:1391,y:959,t:1527027344224};\\\", \\\"{x:1392,y:961,t:1527027344240};\\\", \\\"{x:1393,y:962,t:1527027344257};\\\", \\\"{x:1394,y:963,t:1527027344283};\\\", \\\"{x:1394,y:964,t:1527027344354};\\\", \\\"{x:1394,y:965,t:1527027344362};\\\", \\\"{x:1396,y:969,t:1527027344375};\\\", \\\"{x:1398,y:975,t:1527027344391};\\\", \\\"{x:1402,y:982,t:1527027344408};\\\", \\\"{x:1410,y:992,t:1527027344426};\\\", \\\"{x:1421,y:1006,t:1527027344440};\\\", \\\"{x:1446,y:1029,t:1527027344458};\\\", \\\"{x:1487,y:1066,t:1527027344474};\\\", \\\"{x:1516,y:1087,t:1527027344492};\\\", \\\"{x:1540,y:1098,t:1527027344508};\\\", \\\"{x:1552,y:1101,t:1527027344525};\\\", \\\"{x:1555,y:1101,t:1527027344542};\\\", \\\"{x:1558,y:1101,t:1527027344558};\\\", \\\"{x:1559,y:1101,t:1527027344574};\\\", \\\"{x:1559,y:1095,t:1527027344591};\\\", \\\"{x:1559,y:1087,t:1527027344608};\\\", \\\"{x:1555,y:1068,t:1527027344625};\\\", \\\"{x:1546,y:1052,t:1527027344642};\\\", \\\"{x:1536,y:1033,t:1527027344658};\\\", \\\"{x:1530,y:1022,t:1527027344676};\\\", \\\"{x:1526,y:1017,t:1527027344692};\\\", \\\"{x:1522,y:1012,t:1527027344709};\\\", \\\"{x:1519,y:1008,t:1527027344725};\\\", \\\"{x:1516,y:1006,t:1527027344741};\\\", \\\"{x:1516,y:1005,t:1527027344758};\\\", \\\"{x:1515,y:1004,t:1527027344819};\\\", \\\"{x:1515,y:1003,t:1527027345235};\\\", \\\"{x:1513,y:1003,t:1527027345242};\\\", \\\"{x:1511,y:1001,t:1527027345260};\\\", \\\"{x:1507,y:996,t:1527027345275};\\\", \\\"{x:1501,y:987,t:1527027345292};\\\", \\\"{x:1499,y:983,t:1527027345309};\\\", \\\"{x:1497,y:981,t:1527027345325};\\\", \\\"{x:1496,y:980,t:1527027345342};\\\", \\\"{x:1494,y:978,t:1527027345569};\\\", \\\"{x:1494,y:977,t:1527027345625};\\\", \\\"{x:1494,y:975,t:1527027345643};\\\", \\\"{x:1494,y:974,t:1527027345660};\\\", \\\"{x:1493,y:972,t:1527027345676};\\\", \\\"{x:1491,y:970,t:1527027345694};\\\", \\\"{x:1490,y:970,t:1527027345714};\\\", \\\"{x:1487,y:968,t:1527027345727};\\\", \\\"{x:1479,y:967,t:1527027345744};\\\", \\\"{x:1471,y:966,t:1527027345761};\\\", \\\"{x:1470,y:965,t:1527027346019};\\\", \\\"{x:1471,y:963,t:1527027346035};\\\", \\\"{x:1472,y:963,t:1527027346044};\\\", \\\"{x:1474,y:963,t:1527027346061};\\\", \\\"{x:1476,y:961,t:1527027346080};\\\", \\\"{x:1477,y:961,t:1527027346106};\\\", \\\"{x:1478,y:961,t:1527027346138};\\\", \\\"{x:1479,y:960,t:1527027346146};\\\", \\\"{x:1479,y:961,t:1527027346403};\\\", \\\"{x:1479,y:962,t:1527027361306};\\\", \\\"{x:1421,y:939,t:1527027361324};\\\", \\\"{x:1329,y:888,t:1527027361340};\\\", \\\"{x:1235,y:846,t:1527027361357};\\\", \\\"{x:1134,y:812,t:1527027361373};\\\", \\\"{x:1020,y:777,t:1527027361389};\\\", \\\"{x:893,y:743,t:1527027361407};\\\", \\\"{x:780,y:708,t:1527027361423};\\\", \\\"{x:674,y:673,t:1527027361439};\\\", \\\"{x:581,y:642,t:1527027361458};\\\", \\\"{x:471,y:586,t:1527027361474};\\\", \\\"{x:422,y:558,t:1527027361489};\\\", \\\"{x:396,y:540,t:1527027361510};\\\", \\\"{x:384,y:532,t:1527027361527};\\\", \\\"{x:382,y:531,t:1527027361544};\\\", \\\"{x:381,y:530,t:1527027361593};\\\", \\\"{x:381,y:529,t:1527027361617};\\\", \\\"{x:382,y:528,t:1527027361630};\\\", \\\"{x:385,y:527,t:1527027361649};\\\", \\\"{x:391,y:525,t:1527027361665};\\\", \\\"{x:397,y:525,t:1527027361681};\\\", \\\"{x:413,y:525,t:1527027361698};\\\", \\\"{x:443,y:531,t:1527027361715};\\\", \\\"{x:502,y:548,t:1527027361733};\\\", \\\"{x:587,y:567,t:1527027361748};\\\", \\\"{x:673,y:580,t:1527027361765};\\\", \\\"{x:765,y:597,t:1527027361781};\\\", \\\"{x:829,y:606,t:1527027361798};\\\", \\\"{x:880,y:614,t:1527027361815};\\\", \\\"{x:909,y:618,t:1527027361832};\\\", \\\"{x:919,y:618,t:1527027361848};\\\", \\\"{x:921,y:618,t:1527027361865};\\\", \\\"{x:922,y:617,t:1527027362002};\\\", \\\"{x:922,y:613,t:1527027362016};\\\", \\\"{x:915,y:603,t:1527027362032};\\\", \\\"{x:908,y:599,t:1527027362047};\\\", \\\"{x:873,y:587,t:1527027362065};\\\", \\\"{x:826,y:573,t:1527027362082};\\\", \\\"{x:764,y:564,t:1527027362098};\\\", \\\"{x:712,y:558,t:1527027362115};\\\", \\\"{x:669,y:551,t:1527027362132};\\\", \\\"{x:645,y:546,t:1527027362148};\\\", \\\"{x:631,y:544,t:1527027362165};\\\", \\\"{x:621,y:544,t:1527027362182};\\\", \\\"{x:614,y:542,t:1527027362198};\\\", \\\"{x:606,y:541,t:1527027362216};\\\", \\\"{x:602,y:540,t:1527027362232};\\\", \\\"{x:599,y:540,t:1527027362248};\\\", \\\"{x:599,y:539,t:1527027362265};\\\", \\\"{x:599,y:538,t:1527027362298};\\\", \\\"{x:597,y:537,t:1527027362315};\\\", \\\"{x:596,y:536,t:1527027362332};\\\", \\\"{x:597,y:536,t:1527027362419};\\\", \\\"{x:598,y:536,t:1527027362432};\\\", \\\"{x:603,y:534,t:1527027362450};\\\", \\\"{x:605,y:533,t:1527027362465};\\\", \\\"{x:612,y:529,t:1527027362485};\\\", \\\"{x:613,y:527,t:1527027363003};\\\", \\\"{x:615,y:526,t:1527027363015};\\\", \\\"{x:615,y:525,t:1527027363031};\\\", \\\"{x:615,y:527,t:1527027370154};\\\", \\\"{x:609,y:529,t:1527027370163};\\\", \\\"{x:603,y:532,t:1527027370173};\\\", \\\"{x:602,y:532,t:1527027370189};\\\", \\\"{x:602,y:533,t:1527027370362};\\\", \\\"{x:602,y:535,t:1527027370369};\\\", \\\"{x:602,y:536,t:1527027370387};\\\", \\\"{x:602,y:538,t:1527027370404};\\\", \\\"{x:620,y:541,t:1527027370420};\\\", \\\"{x:664,y:548,t:1527027370436};\\\", \\\"{x:729,y:562,t:1527027370457};\\\", \\\"{x:807,y:584,t:1527027370472};\\\", \\\"{x:868,y:610,t:1527027370489};\\\", \\\"{x:933,y:638,t:1527027370505};\\\", \\\"{x:956,y:655,t:1527027370522};\\\", \\\"{x:965,y:662,t:1527027370538};\\\", \\\"{x:967,y:667,t:1527027370555};\\\", \\\"{x:969,y:669,t:1527027370572};\\\", \\\"{x:970,y:670,t:1527027370588};\\\", \\\"{x:970,y:671,t:1527027370617};\\\", \\\"{x:971,y:673,t:1527027370649};\\\", \\\"{x:972,y:674,t:1527027370657};\\\", \\\"{x:973,y:675,t:1527027370672};\\\", \\\"{x:978,y:681,t:1527027370689};\\\", \\\"{x:980,y:684,t:1527027370706};\\\", \\\"{x:984,y:687,t:1527027370722};\\\", \\\"{x:984,y:686,t:1527027371026};\\\", \\\"{x:983,y:684,t:1527027371042};\\\", \\\"{x:979,y:681,t:1527027371058};\\\", \\\"{x:969,y:676,t:1527027371074};\\\", \\\"{x:947,y:666,t:1527027371089};\\\", \\\"{x:919,y:656,t:1527027371107};\\\", \\\"{x:895,y:648,t:1527027371124};\\\", \\\"{x:877,y:642,t:1527027371142};\\\", \\\"{x:866,y:638,t:1527027371157};\\\", \\\"{x:864,y:635,t:1527027371172};\\\", \\\"{x:863,y:630,t:1527027371190};\\\", \\\"{x:863,y:624,t:1527027371205};\\\", \\\"{x:863,y:620,t:1527027371222};\\\", \\\"{x:864,y:619,t:1527027371240};\\\", \\\"{x:864,y:617,t:1527027371256};\\\", \\\"{x:864,y:614,t:1527027371273};\\\", \\\"{x:855,y:604,t:1527027371289};\\\", \\\"{x:851,y:598,t:1527027371305};\\\", \\\"{x:845,y:586,t:1527027371322};\\\", \\\"{x:836,y:573,t:1527027371340};\\\", \\\"{x:834,y:569,t:1527027371356};\\\", \\\"{x:830,y:564,t:1527027371372};\\\", \\\"{x:827,y:560,t:1527027371390};\\\", \\\"{x:824,y:555,t:1527027371406};\\\", \\\"{x:820,y:547,t:1527027371423};\\\", \\\"{x:812,y:528,t:1527027371439};\\\", \\\"{x:809,y:521,t:1527027371455};\\\", \\\"{x:809,y:517,t:1527027371472};\\\", \\\"{x:809,y:513,t:1527027371489};\\\", \\\"{x:810,y:511,t:1527027371507};\\\", \\\"{x:811,y:509,t:1527027371522};\\\", \\\"{x:812,y:509,t:1527027371610};\\\", \\\"{x:813,y:509,t:1527027371626};\\\", \\\"{x:814,y:508,t:1527027371682};\\\", \\\"{x:815,y:507,t:1527027371705};\\\", \\\"{x:816,y:507,t:1527027371769};\\\", \\\"{x:818,y:507,t:1527027371785};\\\", \\\"{x:820,y:507,t:1527027371809};\\\", \\\"{x:820,y:508,t:1527027371841};\\\", \\\"{x:821,y:508,t:1527027371858};\\\", \\\"{x:822,y:508,t:1527027371873};\\\", \\\"{x:823,y:510,t:1527027371921};\\\", \\\"{x:824,y:510,t:1527027371954};\\\", \\\"{x:825,y:510,t:1527027371962};\\\", \\\"{x:825,y:512,t:1527027372186};\\\", \\\"{x:823,y:514,t:1527027372194};\\\", \\\"{x:823,y:518,t:1527027372207};\\\", \\\"{x:820,y:525,t:1527027372223};\\\", \\\"{x:819,y:533,t:1527027372242};\\\", \\\"{x:819,y:558,t:1527027372258};\\\", \\\"{x:819,y:578,t:1527027372274};\\\", \\\"{x:819,y:599,t:1527027372289};\\\", \\\"{x:823,y:620,t:1527027372306};\\\", \\\"{x:828,y:637,t:1527027372324};\\\", \\\"{x:830,y:654,t:1527027372339};\\\", \\\"{x:834,y:672,t:1527027372356};\\\", \\\"{x:841,y:690,t:1527027372373};\\\", \\\"{x:844,y:703,t:1527027372389};\\\", \\\"{x:848,y:715,t:1527027372406};\\\", \\\"{x:849,y:724,t:1527027372423};\\\", \\\"{x:849,y:727,t:1527027372439};\\\", \\\"{x:849,y:731,t:1527027372457};\\\", \\\"{x:848,y:734,t:1527027372473};\\\", \\\"{x:853,y:730,t:1527027372537};\\\", \\\"{x:866,y:716,t:1527027372545};\\\", \\\"{x:875,y:693,t:1527027372557};\\\", \\\"{x:900,y:640,t:1527027372575};\\\", \\\"{x:914,y:604,t:1527027372591};\\\", \\\"{x:919,y:591,t:1527027372607};\\\", \\\"{x:921,y:586,t:1527027372624};\\\", \\\"{x:922,y:581,t:1527027372640};\\\", \\\"{x:922,y:577,t:1527027372656};\\\", \\\"{x:921,y:573,t:1527027372674};\\\", \\\"{x:920,y:569,t:1527027372691};\\\", \\\"{x:916,y:561,t:1527027372706};\\\", \\\"{x:908,y:551,t:1527027372723};\\\", \\\"{x:903,y:546,t:1527027372740};\\\", \\\"{x:901,y:544,t:1527027372756};\\\", \\\"{x:900,y:543,t:1527027372773};\\\", \\\"{x:898,y:543,t:1527027372790};\\\", \\\"{x:895,y:542,t:1527027372808};\\\", \\\"{x:889,y:542,t:1527027372824};\\\", \\\"{x:884,y:540,t:1527027372841};\\\", \\\"{x:880,y:539,t:1527027372857};\\\", \\\"{x:879,y:539,t:1527027372873};\\\", \\\"{x:876,y:539,t:1527027372891};\\\", \\\"{x:871,y:538,t:1527027372908};\\\", \\\"{x:863,y:538,t:1527027372923};\\\", \\\"{x:854,y:535,t:1527027372941};\\\", \\\"{x:850,y:534,t:1527027372957};\\\", \\\"{x:846,y:532,t:1527027372974};\\\", \\\"{x:840,y:531,t:1527027372992};\\\", \\\"{x:835,y:530,t:1527027373006};\\\", \\\"{x:827,y:527,t:1527027373023};\\\", \\\"{x:820,y:526,t:1527027373040};\\\", \\\"{x:818,y:525,t:1527027373057};\\\", \\\"{x:818,y:524,t:1527027373586};\\\", \\\"{x:820,y:523,t:1527027373698};\\\", \\\"{x:820,y:523,t:1527027373701};\\\", \\\"{x:822,y:522,t:1527027373755};\\\", \\\"{x:823,y:522,t:1527027373818};\\\", \\\"{x:824,y:521,t:1527027373898};\\\", \\\"{x:825,y:521,t:1527027374018};\\\", \\\"{x:825,y:520,t:1527027374026};\\\", \\\"{x:826,y:518,t:1527027374044};\\\", \\\"{x:826,y:517,t:1527027374058};\\\", \\\"{x:827,y:516,t:1527027374075};\\\", \\\"{x:827,y:515,t:1527027374098};\\\", \\\"{x:828,y:514,t:1527027374320};\\\", \\\"{x:829,y:514,t:1527027374418};\\\", \\\"{x:830,y:514,t:1527027374425};\\\", \\\"{x:831,y:514,t:1527027374441};\\\", \\\"{x:829,y:514,t:1527027375330};\\\", \\\"{x:828,y:514,t:1527027376530};\\\", \\\"{x:826,y:514,t:1527027376543};\\\", \\\"{x:824,y:516,t:1527027376561};\\\", \\\"{x:822,y:516,t:1527027376576};\\\", \\\"{x:820,y:516,t:1527027380186};\\\", \\\"{x:818,y:516,t:1527027380196};\\\", \\\"{x:816,y:517,t:1527027380213};\\\", \\\"{x:814,y:518,t:1527027385657};\\\", \\\"{x:808,y:522,t:1527027385667};\\\", \\\"{x:802,y:525,t:1527027385683};\\\", \\\"{x:800,y:525,t:1527027385700};\\\", \\\"{x:800,y:526,t:1527027385717};\\\", \\\"{x:799,y:526,t:1527027385734};\\\", \\\"{x:797,y:527,t:1527027385750};\\\", \\\"{x:792,y:530,t:1527027385767};\\\", \\\"{x:788,y:531,t:1527027385784};\\\", \\\"{x:778,y:536,t:1527027385801};\\\", \\\"{x:750,y:547,t:1527027385818};\\\", \\\"{x:726,y:557,t:1527027385834};\\\", \\\"{x:701,y:570,t:1527027385850};\\\", \\\"{x:680,y:585,t:1527027385869};\\\", \\\"{x:663,y:597,t:1527027385884};\\\", \\\"{x:634,y:615,t:1527027385901};\\\", \\\"{x:597,y:632,t:1527027385918};\\\", \\\"{x:551,y:659,t:1527027385934};\\\", \\\"{x:514,y:679,t:1527027385951};\\\", \\\"{x:488,y:698,t:1527027385968};\\\", \\\"{x:461,y:712,t:1527027385984};\\\", \\\"{x:417,y:731,t:1527027386001};\\\", \\\"{x:394,y:738,t:1527027386018};\\\", \\\"{x:378,y:742,t:1527027386034};\\\", \\\"{x:372,y:745,t:1527027386051};\\\", \\\"{x:373,y:745,t:1527027386097};\\\", \\\"{x:376,y:745,t:1527027386105};\\\", \\\"{x:381,y:745,t:1527027386118};\\\", \\\"{x:389,y:745,t:1527027386134};\\\", \\\"{x:397,y:745,t:1527027386151};\\\", \\\"{x:407,y:745,t:1527027386168};\\\", \\\"{x:422,y:745,t:1527027386184};\\\", \\\"{x:449,y:745,t:1527027386201};\\\", \\\"{x:462,y:745,t:1527027386218};\\\", \\\"{x:466,y:745,t:1527027386234};\\\", \\\"{x:471,y:745,t:1527027386251};\\\", \\\"{x:474,y:746,t:1527027386268};\\\", \\\"{x:475,y:746,t:1527027386285};\\\", \\\"{x:476,y:746,t:1527027386300};\\\", \\\"{x:477,y:746,t:1527027386336};\\\", \\\"{x:480,y:746,t:1527027386353};\\\", \\\"{x:481,y:746,t:1527027386372};\\\", \\\"{x:484,y:746,t:1527027386389};\\\", \\\"{x:484,y:747,t:1527027386460};\\\", \\\"{x:484,y:747,t:1527027386508};\\\", \\\"{x:489,y:748,t:1527027386661};\\\", \\\"{x:510,y:769,t:1527027386672};\\\", \\\"{x:616,y:850,t:1527027386689};\\\", \\\"{x:769,y:930,t:1527027386706};\\\", \\\"{x:945,y:1008,t:1527027386722};\\\", \\\"{x:1139,y:1075,t:1527027386739};\\\", \\\"{x:1351,y:1127,t:1527027386755};\\\", \\\"{x:1568,y:1173,t:1527027386771};\\\", \\\"{x:1815,y:1199,t:1527027386789};\\\", \\\"{x:1919,y:1199,t:1527027386806};\\\", \\\"{x:1919,y:1197,t:1527027386837};\\\", \\\"{x:1919,y:1196,t:1527027386868};\\\", \\\"{x:1912,y:1190,t:1527027386877};\\\", \\\"{x:1888,y:1172,t:1527027386889};\\\", \\\"{x:1757,y:1108,t:1527027386906};\\\", \\\"{x:1585,y:1044,t:1527027386922};\\\", \\\"{x:1361,y:973,t:1527027386939};\\\", \\\"{x:1157,y:915,t:1527027386956};\\\", \\\"{x:1012,y:862,t:1527027386972};\\\", \\\"{x:914,y:816,t:1527027386989};\\\", \\\"{x:905,y:809,t:1527027387005};\\\", \\\"{x:907,y:805,t:1527027387053};\\\", \\\"{x:915,y:800,t:1527027387061};\\\", \\\"{x:933,y:791,t:1527027387073};\\\", \\\"{x:972,y:775,t:1527027387089};\\\", \\\"{x:1028,y:765,t:1527027387106};\\\", \\\"{x:1076,y:764,t:1527027387122};\\\", \\\"{x:1087,y:761,t:1527027387139};\\\", \\\"{x:1086,y:758,t:1527027387342};\\\", \\\"{x:1063,y:756,t:1527027387356};\\\", \\\"{x:912,y:752,t:1527027387373};\\\", \\\"{x:801,y:767,t:1527027387390};\\\", \\\"{x:768,y:767,t:1527027387406};\\\", \\\"{x:765,y:767,t:1527027387423};\\\", \\\"{x:763,y:767,t:1527027387469};\\\", \\\"{x:759,y:767,t:1527027387476};\\\", \\\"{x:755,y:767,t:1527027387489};\\\", \\\"{x:760,y:761,t:1527027387544};\\\", \\\"{x:765,y:753,t:1527027387556};\\\", \\\"{x:790,y:736,t:1527027387572};\\\", \\\"{x:801,y:730,t:1527027387589};\\\", \\\"{x:808,y:725,t:1527027387606};\\\", \\\"{x:814,y:721,t:1527027387623};\\\", \\\"{x:819,y:719,t:1527027387639};\\\", \\\"{x:822,y:718,t:1527027387656};\\\", \\\"{x:827,y:715,t:1527027387672};\\\", \\\"{x:831,y:715,t:1527027387690};\\\", \\\"{x:840,y:713,t:1527027387706};\\\", \\\"{x:857,y:710,t:1527027387723};\\\" ] }, { \\\"rt\\\": 52181, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 773497, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the X-axis and find which points line up vertically with 12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12659, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 787164, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11574, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 799754, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18324, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 819408, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"Q3JLW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"Q3JLW\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 104, dom: 613, initialDom: 692",
  "javascriptErrors": []
}