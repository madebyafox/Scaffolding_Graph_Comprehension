var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c98a208f9c13853a5bc6371ffd2cf142",
  "created": "2018-05-22T15:16:27.3704239-07:00",
  "lastActivity": "2018-05-22T15:18:08.2027709-07:00",
  "pageViews": [
    {
      "id": "0522274117b828d05b389ed887bc4f40f5723e1a",
      "startTime": "2018-05-22T15:16:27.6907565-07:00",
      "endTime": "2018-05-22T15:18:08.2027709-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 100699,
      "engagementTime": 90948,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 100699,
  "engagementTime": 90948,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=Q3JLW",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ee3a7404e9c67565b84b9b45eefadd80",
  "gdpr": false
}