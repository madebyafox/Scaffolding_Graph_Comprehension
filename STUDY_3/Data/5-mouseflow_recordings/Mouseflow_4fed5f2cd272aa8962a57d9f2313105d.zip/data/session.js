var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4fed5f2cd272aa8962a57d9f2313105d",
  "created": "2018-05-15T14:11:16.833146-07:00",
  "lastActivity": "2018-05-15T14:11:29.5511535-07:00",
  "pageViews": [
    {
      "id": "05151737f6ee3b8dc2bc89b4e690f03bb584589c",
      "startTime": "2018-05-15T14:11:16.9560613-07:00",
      "endTime": "2018-05-15T14:11:29.5511535-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 12954,
      "engagementTime": 8316,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12954,
  "engagementTime": 8316,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DD3DE",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5052cb9d2054bb0a82cf6e00441af32d",
  "gdpr": false
}