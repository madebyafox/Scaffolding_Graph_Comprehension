var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cbf8231c30453682fed2e5a759aa1056",
  "created": "2018-05-19T13:15:01.3110848-07:00",
  "lastActivity": "2018-05-19T13:15:18.5325621-07:00",
  "pageViews": [
    {
      "id": "05190158ba37ef473cac093da053479e537b6776",
      "startTime": "2018-05-19T13:15:01.3110848-07:00",
      "endTime": "2018-05-19T13:15:18.5325621-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 17462,
      "engagementTime": 17448,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17462,
  "engagementTime": 17448,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7VQV2",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d2cd41412308e78ff748f47eb2a94c1c",
  "gdpr": false
}