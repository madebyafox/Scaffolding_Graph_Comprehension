var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c1d62d40b35accf4048505e4de65a5cd",
  "created": "2018-05-16T11:13:30.0502669-07:00",
  "lastActivity": "2018-05-16T11:13:43.6622669-07:00",
  "pageViews": [
    {
      "id": "051630805f5a3290ad5c1d055f92c5974d4a3635",
      "startTime": "2018-05-16T11:13:30.0502669-07:00",
      "endTime": "2018-05-16T11:13:43.6622669-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 13612,
      "engagementTime": 13612,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13612,
  "engagementTime": 13612,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BKTUJ",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "389af362bfcf3e29966f6406a85b8760",
  "gdpr": false
}