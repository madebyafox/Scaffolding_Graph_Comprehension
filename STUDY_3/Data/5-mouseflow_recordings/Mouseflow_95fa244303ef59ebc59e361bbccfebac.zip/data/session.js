var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "95fa244303ef59ebc59e361bbccfebac",
  "created": "2018-05-29T14:10:11.4099406-07:00",
  "lastActivity": "2018-05-29T14:10:44.4729406-07:00",
  "pageViews": [
    {
      "id": "052912485fb11a490722ac27797032cecd57e659",
      "startTime": "2018-05-29T14:10:11.4099406-07:00",
      "endTime": "2018-05-29T14:10:44.4729406-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 33063,
      "engagementTime": 23833,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33063,
  "engagementTime": 23833,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=F92ER",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "98e32e57fa366f25952037ca9e6c31d2",
  "gdpr": false
}