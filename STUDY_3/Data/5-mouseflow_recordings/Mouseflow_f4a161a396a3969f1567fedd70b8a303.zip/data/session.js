var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f4a161a396a3969f1567fedd70b8a303",
  "created": "2018-05-18T11:14:20.5058265-07:00",
  "lastActivity": "2018-05-18T11:14:34.2968265-07:00",
  "pageViews": [
    {
      "id": "05182025cb875ff33e305a3bec7557df5ce1e663",
      "startTime": "2018-05-18T11:14:20.5058265-07:00",
      "endTime": "2018-05-18T11:14:34.2968265-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 13791,
      "engagementTime": 13791,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13791,
  "engagementTime": 13791,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.51",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T2OHS",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b0088c4e515209eee8822b312c242ac3",
  "gdpr": false
}